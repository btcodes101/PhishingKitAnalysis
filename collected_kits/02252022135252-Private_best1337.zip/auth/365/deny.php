<?php 
if (isset($_COOKIE['PHPSESSID'])) {
	header("location: https://login.live.com/");
	exit();
}
