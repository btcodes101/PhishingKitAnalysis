<?php
  header('Location: SSLAuthUI.html');
  exit();
?>