=== BoldGrid Connect ===
Contributors: boldgrid, imh_brad, joemoto, rramo012, timph
Tags: boldgrid, connect, manage
Requires at least: 4.4
Tested up to: 4.9.8
Requires PHP: 5.4
Stable tag: 1.0.0

Connects users and sites with BoldGrid Central.

== Description ==

Connects users and sites with BoldGrid Central.

== Installation ==

= Minimum Requirements =
* PHP 5.3 or higher

= Manually =
1. Upload the entire boldgrid-connect folder to the /wp-content/plugins/ directory.
1. Activate the plugin through the Plugins menu in WordPress.

== Changelog ==

= 1.0.0 =

Release Date: August 13th, 2018

* Initial release.
