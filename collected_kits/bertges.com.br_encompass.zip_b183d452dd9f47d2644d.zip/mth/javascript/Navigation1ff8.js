﻿var SPEC_NAV = "SpecialNav";
var REG_NAV = "RegNav";
var REG_NAV_TYPE = "RegNavType";
var REGULAR_NAV_CURRENT_ID = "RegCurrent";
var SPECIAL_NAV_CURRENT_ID = "SpecCurrent";
var DEFAULT_PAGE_NAME = "Default.aspx";
var CUSTOM_PAGE_NAME = "PageContent.aspx";
var FOOTER_CONTAINER = "FooterContainer";




function setNavigationCurrentPage()
{
    var pageFileName = location.pathname.substring(location.pathname.lastIndexOf("https://www.mortgage-application.net/")+1, location.pathname.length).toLowerCase();
    var dir = location.pathname.substring(0,location.pathname.lastIndexOf("https://www.mortgage-application.net/")).toLowerCase();
    dir = dir.substring(dir.lastIndexOf("https://www.mortgage-application.net/")+1, dir.length).toLowerCase();
    var isCurrentFound = false;
    DEFAULT_PAGE_NAME = DEFAULT_PAGE_NAME.toLowerCase();
    CUSTOM_PAGE_NAME = CUSTOM_PAGE_NAME.toLowerCase();
    
    if(pageFileName == "")
    {
        scanSection($(SPEC_NAV), SPECIAL_NAV_CURRENT_ID, DEFAULT_PAGE_NAME);
    }
    else
    {
        scanSection($(SPEC_NAV), SPECIAL_NAV_CURRENT_ID, pageFileName,dir);
        if($(REG_NAV_TYPE)!=null && $(REG_NAV_TYPE).value=="Horizontal")
            scanHorizontalSection(pageFileName,dir); 
        else    
            scanSection($(REG_NAV), REGULAR_NAV_CURRENT_ID, pageFileName,dir); 
    }
    buildFooter($(REG_NAV));
}
function scanHorizontalSection(pageFileName, dir)
{
    var selectedCategoryID="0";
    for(i=1;;i++)
    {
        if($("categoryMenu"+i)==null)
            break;
            
        if(scanDropDownSection($("dropMenu"+i),pageFileName,dir))
        {
            selectedCategoryID=i+"";
            if(selectedCategoryID!="0")
                selectedCategoryID="categoryMenu"+selectedCategoryID;
                
            if($(selectedCategoryID)!=null)
                $(selectedCategoryID).className="itemselected line";
        }
    
    }

}
function scanDropDownSection(navSectionUl, pageFileName,dir)
{
    var isCurrentFound = false;
    if(navSectionUl != null)
    {
        var href = null;
        var liChildren = navSectionUl.childNodes;
        var liChildrenIndex = 0;
        while(liChildrenIndex < liChildren.length)
        {
            if(liChildren[liChildrenIndex].childNodes.length>0  && liChildren[liChildrenIndex].childNodes[0].getAttribute("href") != null)
            {
                href = liChildren[liChildrenIndex].childNodes[0].getAttribute("href").toLowerCase();
                if(pageFileName == CUSTOM_PAGE_NAME)
                {
                    var locationQS = location.search.replace("?","").toLowerCase();
                    if(endsWith(href,locationQS))
                    {
                        findInShowCaseByName(inText(liChildren[liChildrenIndex].childNodes[0]));
                        isCurrentFound = true; 
                    }                    
                }
                else if (href.match(pageFileName))
                { 
                    isCurrentFound = true; 
                }
                
                // Special case for Loan Status
                if (pageFileName == "detail.aspx" && endsWith(href,"status.aspx"))
                {
                    isCurrentFound = true;
                }
                
                // Special case for Employee detail
                if (pageFileName == "employeedetail.aspx" && endsWith(href,"employeelist.aspx"))
                {
                    isCurrentFound = true;
                }                    
                
                // Special case for Mortgage Calculators 
                if (dir == "calculators" && endsWith(href,"menu.aspx"))
                {
                    isCurrentFound = true;
                }                    
            }
            liChildrenIndex++
        }
    }
    return isCurrentFound;
}

function scanSection(navSectionUl, idAttribute, pageFileName,dir)
{
    var isCurrentFound = false;
    if(navSectionUl != null)
    {
        var href = null;
        var sectionLIs = navSectionUl.childNodes;
        
        var liChildren;
        var liIndex = 0, liChildrenIndex = 0;
        while (liIndex < sectionLIs.length)
        {
            liChildren = sectionLIs[liIndex].childNodes;
            while(liChildrenIndex < liChildren.length)
            {
                if(liChildren[liChildrenIndex]!= null && liChildren[liChildrenIndex].getAttribute("href") != null)
                {
                    href = liChildren[liChildrenIndex].getAttribute("href").toLowerCase();
                    if(pageFileName == CUSTOM_PAGE_NAME)
                    {
                        var locationQS = location.search.replace("?","").toLowerCase();
                        if(endsWith(href,locationQS))
                        {
                            findInHorizontalRegularNavigationByName(inText(liChildren[liChildrenIndex]));
                            sectionLIs[liIndex].setAttribute("id", idAttribute);
                            isCurrentFound = true; 
                        }
                    }
                    else if (href.match(pageFileName))
                    { 
                        sectionLIs[liIndex].setAttribute("id", idAttribute);
                        isCurrentFound = true; 
                    }
                    
                   // Special case for Loan Status
                    if (pageFileName == "detail.aspx" && endsWith(href,"status.aspx"))
                    {
                        sectionLIs[liIndex].setAttribute("id", idAttribute);
                        isCurrentFound = true;
                    }
                    
                    // Special case for Employee detail
                    if (pageFileName == "employeedetail.aspx" && endsWith(href,"employeelist.aspx"))
                    {
                        sectionLIs[liIndex].setAttribute("id", idAttribute);
                        isCurrentFound = true;
                    }                    
                    
                    // Special case for Mortgage Calculators 
                    if (dir == "calculators" && endsWith(href,"menu.aspx"))
                    {
                        sectionLIs[liIndex].setAttribute("id", idAttribute);
                        isCurrentFound = true;
                    }                    
                }
                liChildrenIndex++
            }
            liChildrenIndex = 0;
            liIndex++;
        }
    }
   
   if(!isCurrentFound)
   {
        isCurrentFound = scanLink(navSectionUl,idAttribute,pageFileName);  
        if(!isCurrentFound)
        {
            isCurrentFound = scanByName(navSectionUl,idAttribute,pageFileName);
        }
    }
        
    return isCurrentFound;
}

function scanLink(navSectionUl,idAttribute,pageFileName)
{
    if(pageFileName.toLowerCase() == "link.aspx")
    {
        if(location.search.length == 0) return; 
        var qsArray = location.search.substring(1,location.search.length).split("&");
        if( qsArray[0])
        {
            var linkid =  qsArray[0].split("=")[1];
            var liArray = document.getElementsByTagName("li");
            for(var i=0;i<liArray.length;i++)
            {
                if(liArray[i].id == linkid)
                {
                    liArray[i].setAttribute("id", idAttribute);
                    return true; 
                } 
            }
        }
    } 
   
   return false; 
}
function findInShowCaseByName(itemName)
{
    var idAttribute = SPECIAL_NAV_CURRENT_ID;
    var lu = document.getElementById("SpecialNav"); 
    if(!lu) return;
    
    itemName=">"+itemName;
    
    for(var i=0;i<lu.childNodes.length;i++)
    {
        var anchor = lu.childNodes[i].lastChild;

        if(inText(anchor) && inText(anchor) == itemName)
        {
            lu.childNodes[i].setAttribute("id", idAttribute,0);
            break; 
        }     
    }
}
function findInHorizontalRegularNavigationByName(itemName)
{
   if($(REG_NAV_TYPE)!=null && $(REG_NAV_TYPE).value=="Horizontal")
    {
        itemName=itemName.replace(">","");

        var selectedCategoryID="0";
        for(i=1;;i++)
        {
            if($("categoryMenu"+i)==null)
                break;
                
            //Search in drop down menu div
            if(selectedCategoryID=="0")
            {
                if(findnDropDownSection($("dropMenu"+i),itemName))
                    selectedCategoryID=i+"";
            }    
        
        }
        
        if(selectedCategoryID!="0")
            selectedCategoryID="categoryMenu"+selectedCategoryID;
            
        if($(selectedCategoryID)!=null)
            $(selectedCategoryID).className="itemselected line";
    }
}
function findnDropDownSection(navSectionUl, itemName)
{
    var isCurrentFound = false;
    if(navSectionUl != null)
    {
        var currentItemName = null;
        var liChildren = navSectionUl.childNodes;
        var liChildrenIndex = 0;
        while(!isCurrentFound && liChildrenIndex < liChildren.length)
        {
            if(liChildren[liChildrenIndex].innerHTML!=null && inText(liChildren[liChildrenIndex].childNodes[0]) != null)
            {
                currentItemName = inText(liChildren[liChildrenIndex].childNodes[0]).toUpperCase();
                if(currentItemName==itemName)
                    isCurrentFound = true; 
            }
            liChildrenIndex++
        }
    }
    return isCurrentFound;
}

function scanByName(navSectionUl,idAttribute,pageFileName)
{
    if(pageFileName.toUpperCase() == "PAGECONTENT.ASPX")
    { 
        var href = location;
        var liArray = document.getElementsByTagName("li"); 
        var itemName = ""; 
        var luName = ""; 
        
        var pageName="";
        var pagenamelable=$(pageNameLabel);
        if(pagenamelable)
        {
            pageName=inText(pagenamelable);
        }

        for(var i=0;i<liArray.length;i++)
        {
            var anchor = liArray[i].lastChild;

            if(inText(anchor) == pageName)
            {
                itemName = inText(anchor).toUpperCase();
                luName = liArray[i].parentNode.getAttribute("id");
                if(navSectionUl != null)
                {
                    if(navSectionUl.getAttribute("id") == liArray[i].parentNode.getAttribute("id"))
                    { 
                        liArray[i].setAttribute("id", idAttribute,0);
                    }
                }
               break;  
            } 
        }
        //debugger; 
        if(luName == "SpecialNav") 
        {
            luName ="RegNav";
            idAttribute = REGULAR_NAV_CURRENT_ID;
        }
        else if(luName == "RegNav") 
        {
            luName ="SpecialNav";
            idAttribute  = SPECIAL_NAV_CURRENT_ID;
        }
       
        var lu = document.getElementById(luName); 
        if(!lu) return;
        
        for(var i=0;i<lu.childNodes.length;i++)
        {
            var anchor = lu.childNodes[i].lastChild;
            if(anchor==null)
                continue;
            if(inText(anchor) && inText(anchor) == itemName)
            {
                lu.childNodes[i].setAttribute("id", idAttribute,0);
                break; 
            }     
        }
   } 
}

function inText(obj)
{
    if (obj.innerText)
    {
        return obj.innerText.toUpperCase();
    }
    else if(obj.textContent)
    {
        return obj.textContent.toUpperCase();
    }
    else
    {
        return "";
    }
}


function endsWith(href,search)
{
    
    var subhref = href.substr(href.length - search.length,search.length);
    if (subhref == search)
    {
        return true;
    }
    else
    {
        return false;
    }
}


function buildFooter(navSectionUl)
{
//    if($(FOOTER_CONTAINER) != null)
//    {
//        $(FOOTER_CONTAINER).innerText = "";
//        var sectionLis = navSectionUl.childNodes;
//        var clone = null;
//        for(var i = 0; i < sectionLis.length; i++)
//        {
//            var currentNode = sectionLis[i].firstChild;
//            if(currentNode.tagName == "A")
//            {
//                clone = currentNode.cloneNode(true);
//                if(clone != null)
//                {
//                    clone.className = "Sm5";
//                    $(FOOTER_CONTAINER).appendChild(clone);
//                }
//                if(i !=  sectionLis.length-1)
//                {
//                    $(FOOTER_CONTAINER).innerHTML += "&nbsp;&nbsp;|&nbsp;&nbsp;";
//                }
//            }
//        }
//    }
}

