﻿// JScript File

    function NewXmlHttpRequest() {  
        var httpRequest = null;  
        try {  
         httpRequest = new XMLHttpRequest();  
        }  
        catch (tryMSIE) {  
         try {  
             httpRequest = new ActiveXObject("Msxml2.XMLHTTP");  
         }  
         catch (tryMSIE2) {  
             try {  
                 httpRequest = new ActiveXObject("Microsoft.XMLHTTP");  
             }  
             catch (NotSupported) {  
                 httpRequest=null;  
             }  
         }  
        }  
        return httpRequest;  
    } 
   
    function saveresluation()
    {
        var resolution = screen.width + "*" + screen.height;    
        xmlhttp = NewXmlHttpRequest();
        if (!xmlhttp) {return;}
        
        xmlhttp.open("AccountLogin.html", "/SaveResolution.aspx?resolution=" + resolution,true);
        xmlhttp.onreadystatechange=function() {
        }
        xmlhttp.send(null);
    }
    saveresluation();