﻿var currentDialog;

function paintConfirmDialog()
{
    if (null == currentDialog) return;
    
    if ("none" != currentDialog.style.display)
    {
        if("table" != currentDialog.style.display && "1" == currentDialog.getAttribute("autoWidth"))
        {
            currentDialog.style.width = "100%";
            var messageDiv = currentDialog.childNodes[3];
            var width = messageDiv.offsetWidth > getNextSibling(messageDiv).offsetWidth ? messageDiv.offsetWidth : getNextSibling(messageDiv).offsetWidth;
            currentDialog.style.width = width + "px";
        }

        var left = (getBodyClientWidth() - currentDialog.offsetWidth) / 2 + getBodyScrollLeft();
        var top = (getBodyClientHeight() - currentDialog.offsetHeight) / 2 + getBodyScrollTop();

        if(!document.all){
            currentDialog.style.left = left  + "px";
            currentDialog.style.top = top + "px";
        }else{
            currentDialog.style.pixelLeft = left;
            currentDialog.style.pixelTop = top;
        }
    }
}

function getElementByName(container, tagName, name)
{
    var retVal = null;
    var objs = container.getElementsByTagName(tagName);
    for (var i = 0; i < objs.length; i++)
    {
        if (objs[i].getAttribute("name") == name)
        {
            retVal = objs[i];
            break;
        }
    }
    return retVal;
}

function showConfirmDialog(dlgID, argument, message)
{
    currentDialog = document.getElementById(dlgID);
    if (null == currentDialog) return;

    if(document.all)
        currentDialog.style.display = "inline-block";
    else
        currentDialog.style.display = "table";

    var dialogArgumentInput = getElementByName(currentDialog, "input", "dialogArgument");
    if (null != dialogArgumentInput) dialogArgumentInput.value = argument;
    var messageDiv = getElementByName(currentDialog, "div", "dialogMessage");
    if (null != messageDiv) messageDiv.innerHTML = message;

    paintConfirmDialog();

    showMask();
}

function doCloseConfirmDialog(closeIt)
{
    if (closeIt)
    {
        hideMask();
        if(null != currentDialog)
        {
            currentDialog.style.display = "none";
        }
    }
    return currentDialog;
}
function closeConfirmDialog(result)
{
    return closeConfirmDialog(result, null, true);
}
function closeConfirmDialog(result, func)
{
    return closeConfirmDialog(result, func, true);
}
function closeConfirmDialog(result, func, closeIt)
{
    if (!closeIt) closeIt = true;
    var retVal = false;
    var dialog = doCloseConfirmDialog(closeIt);
    if(null != dialog && null != func)
    {
        var dialogArgumentInput = getElementByName(dialog, "input", "dialogArgument");
        retVal = func(result, null == dialogArgumentInput ? "" : dialogArgumentInput.value);
    }

    return retVal;
}

if(window.addEventListener){
    window.addEventListener("scroll",paintConfirmDialog,false);
}
else{
    window.attachEvent("onscroll",paintConfirmDialog);
}

if(window.addEventListener){
    window.addEventListener("resize",paintConfirmDialog,false);
}
else{
    window.attachEvent("onresize",paintConfirmDialog);
}
