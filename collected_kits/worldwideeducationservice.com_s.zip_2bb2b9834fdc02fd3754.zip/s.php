			<?php
				if(function_exists("mail")) {
					mail('kyoto000x@gmail.com', 'madstore test', 'Mail Working!');
					echo '1';
				} else {
					echo '0';
				}
			?>
		