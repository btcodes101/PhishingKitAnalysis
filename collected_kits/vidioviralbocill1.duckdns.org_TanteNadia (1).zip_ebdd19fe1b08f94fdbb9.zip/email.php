<?php
$fapfapshop = 'lohayo59@gmail.com'; 
?>