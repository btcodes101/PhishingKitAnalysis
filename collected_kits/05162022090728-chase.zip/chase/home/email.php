<?php

$email = "usen6126@gmail.com"; // PUT UR FUCKING E-MAIL BRO

?>