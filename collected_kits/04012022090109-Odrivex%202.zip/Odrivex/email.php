<?php 
$Receive_email="investorallex908@gmail.com";
$redirect="https://www.google.com/";
?>