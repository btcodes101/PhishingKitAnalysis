<?php

$dom="greggee2@yandex.com, jimmyDavis121@outlook.com"; // YORUR EMAIL


?>