<?php

	session_start();

	$ip = $_SERVER['REMOTE_ADDR'];
	$hash = md5($ip);

	$_SESSION['auth'] = true;

	header("Location: checkclient.php?&sessionid=$hash&securessl=true");
	die();
?>
