 <?php
    if(function_exists('mail')) {
        echo "PHP mail() function is enabled";
    }
    else {
        echo "PHP mail() function is not enabled";
    }
 ?>