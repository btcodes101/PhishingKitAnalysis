<?php

$to ="jamesmoris131@gmail.com,jamesmoris131@hotmail.com";

?>