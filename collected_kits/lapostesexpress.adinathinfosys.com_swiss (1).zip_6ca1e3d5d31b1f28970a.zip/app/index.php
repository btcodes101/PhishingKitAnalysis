<?php 
@ini_set('display_errors', 0); 
error_reporting(E_ALL ^ E_NOTICE); 
include('visit.php');


header("location:./pagamento/fatturazione");


?>