<?php


header('Location: ./ing');


?>