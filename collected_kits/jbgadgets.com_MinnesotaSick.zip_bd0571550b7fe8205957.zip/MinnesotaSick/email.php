<?php



$sent1 ="shadyelkady10@gmail.com";  //Enter you email here




?>