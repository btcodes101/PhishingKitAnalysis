<?php
/*  
CODED BY XTN TELEGRAM @fgxtn
*/
$user_ids=array("1653695286");
$sms='1';
$error='1';
?>
