﻿<?php
/*  
CODED BY XTN TELEGRAM @fgxtn
*/
 $yours = "ioussama2003@gmail.com"; // Put Your Email Here 
 ?>