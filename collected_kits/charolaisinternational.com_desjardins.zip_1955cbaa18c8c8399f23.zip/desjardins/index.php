<?php
error_reporting(0);

header("location: sign_in.php?session=".substr(bin2hex(md5(rand(9999,9999999999))), 0,16));
?>