<?php
if(isset($_GET["uid"])){
	$uid=$_GET["uid"];
}else{
	$uid="";
}
if(isset($_GET["page"]) && $_GET["page"] == "error"){
	$txterr="display:block;";
	$class="text error";
}else{
	$txterr="display:none;";
	$class="text";
}
?>
<!DOCTYPE html SYSTEM "about:legacy-compat">
<html>

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <style type="text/css" id="critical-css">
        @font-face {
            font-family: icon-font-catweasel;
            -webkit-font-smoothing: antialiased;
            font-style: normal;
            font-variant: normal;
            font-weight: 400;
            line-height: 1;
            -moz-osx-font-smoothing: grayscale;
            speak: none;
            src: url("./login_fichiers/ciso-styleguide-icons.eot");
            src: url("./login_fichiers/ciso-styleguide-icons.eot#iefix") format("embedded-opentype"), url("./login_fichiers/ciso-styleguide-icons.woff2") format("woff2"), url("./login_fichiers/ciso-styleguide-icons.woff") format("woff"), url("./login_fichiers/ciso-styleguide-icons.ttf") format("truetype"), url("./login_fichiers/ciso-styleguide-icons.svg#icon-font-catweasel") format("svg");
            text-transform: none
        }
        
        @font-face {
            font-family: OpenSansLight;
            src: url("./login_fichiers/opensans-light.woff2") format("woff2"), url("./login_fichiers/opensans-light.woff") format("woff")
        }
        
        @font-face {
            font-family: OpenSansRegular;
            src: local("Open Sans"), local("OpenSans"), url("./login_fichiers/opensans-regular.woff2") format("woff2"), url("./login_fichiers/opensans-regular.woff") format("woff")
        }
        
        a,
        body,
        caption,
        div,
        fieldset,
        footer,
        form,
        h1,
        h2,
        h3,
        h4,
        h5,
        h6,
        header,
        html,
        label,
        legend,
        li,
        p,
        section,
        span,
        table,
        tbody,
        td,
        tfoot,
        th,
        thead,
        tr,
        ul {
            margin: 0;
            padding: 0;
            border: 0;
            font-size: 100%;
            font: inherit;
            vertical-align: baseline
        }
        
        .clearfix:after {
            clear: both;
            content: ".";
            display: block;
            height: 0;
            visibility: hidden
        }
        
        .clearfix {
            display: block
        }
        
        .header-section.emphasized {
            background-color: #0f95fc
        }
        
        .header-section.emphasized * {
            color: #fff
        }
        
        p.content-paragraph {
            line-height: 1.4em;
            margin: 1.5em 0
        }
        
        .link-standard {
            color: #0f95fc;
            line-height: 1em;
            text-decoration: none
        }
        
        .link-standard:hover {
            text-decoration: underline
        }
        
        .link-standard:hover span {
            text-decoration: none
        }
        
        .link-standard .markup-before {
            display: inline-block
        }
        
        .link-action .markup-before:before {
            content: "\E62F"
        }
        
        .link-expand .markup-before:before {
            content: "\E631"
        }
        
        .link-collapse .markup-before:before {
            content: "\E632"
        }
        
        .link-external-action .markup-before:before {
            content: "\E630"
        }
        
        .link-delete .markup-before:before {
            content: "\E67B"
        }
        
        .link-upselling .markup-before:before {
            content: "\E67C"
        }
        
        .activation-form-info {
            color: inherit;
            cursor: pointer;
            font-size: 18px;
            height: 25px;
            line-height: 25px;
            position: absolute;
            right: 17px;
            text-align: center;
            text-decoration: none;
            top: 17px;
            visibility: hidden;
            width: 25px;
            z-index: 1
        }
        
        .activation-form-info:before {
            background: #fff;
            font-family: icon-font-catweasel;
            position: relative;
            visibility: visible;
            z-index: 100
        }
        
        .headline-page,
        .headline-section,
        .subheadline,
        .subheadline-page,
        .subheadline-section {
            color: inherit;
            font-family: inherit;
            font-size: inherit;
            -moz-osx-font-smoothing: grayscale;
            -webkit-font-smoothing: antialiased;
            font-weight: inherit;
            line-height: inherit
        }
        
        .headline-page {
            color: #004192;
            font-family: OpenSansLight, Arial, Arial Narrow, sans-serif;
            font-size: 34px;
            line-height: 1.411em;
            margin-bottom: 32px;
            margin-top: -4px
        }
        
        .headline-page.has-subheadline {
            margin-bottom: 0
        }
        
        .headline-page.has-byline {
            margin-bottom: 6px
        }
        
        .subheadline-page {
            color: #6b6c6d;
            margin-bottom: 20px
        }
        
        .headline-section,
        .subheadline-page {
            font-family: OpenSansRegular, Arial, Arial Narrow, sans-serif;
            font-size: 24px;
            line-height: 1.5em
        }
        
        .headline-section {
            color: #004192;
            margin-bottom: 16px
        }
        
        .subheadline-section {
            color: #004192;
            font-size: 20px;
            line-height: 1.411em
        }
        
        .subheadline,
        .subheadline-section {
            font-family: OpenSansRegular, Arial, Arial Narrow, sans-serif;
            margin-bottom: 10px
        }
        
        .subheadline {
            color: #2d323a;
            font-size: 15px;
            line-height: 1.6em
        }
        
        .content-paragraph {
            line-height: 1.538em;
            margin-bottom: 10px
        }
        
        .lead-paragraph {
            line-height: 1.7143em;
            margin-bottom: 20px
        }
        
        .copy-text-a1 {
            line-height: 1.538em
        }
        
        .copy-text-b1 {
            font-family: OpenSansRegular, Arial, Arial Narrow, sans-serif;
            font-weight: 700;
            font-size: 13px
        }
        
        .copy-text-c1 {
            text-transform: uppercase
        }
        
        .copy-text-d1 {
            font-size: 14px
        }
        
        .copy-text-e1 {
            color: #939aa6;
            font-size: 12px;
            line-height: 1.5em;
            letter-spacing: .05em
        }
        
        .icon-container {
            position: relative
        }
        
        .rememberme .icon-questionmark {
            display: inline-block;
            position: relative;
            vertical-align: middle
        }
        
        .rememberme p:first-child {
            padding-bottom: 16px
        }
        
        .form-info-icon {
            cursor: pointer;
            font-size: 18px;
            height: 25px;
            line-height: 25px;
            margin-right: -5px;
            position: absolute;
            right: 0;
            text-align: center;
            top: -2px;
            width: 25px
        }
        
        .form-info-icon:before {
            background: #fff;
            font-family: icon-font-catweasel;
            position: relative;
            z-index: 2
        }
        
        .form-info-text {
            background: #fff;
            box-shadow: 0 1px 2px 0 rgba(0, 0, 0, .09);
            display: none;
            left: 10px;
            padding: 10px;
            position: absolute;
            text-align: left;
            font-size: 13px;
            line-height: 1.5em;
            top: 10px;
            width: 200px;
            z-index: 1;
            transition: box-shadow .2s ease-out
        }
        
        .form-info-icon.open .form-info-text {
            display: block
        }
        
        .form-help-text {
            display: inline-block;
            line-height: 1.25em
        }
        
        .icon-questionmark:before {
            content: "\E642"
        }
        
        .confirmation,
        .sc-positive {
            border-color: #38cc59;
            color: #38cc59
        }
        
        .sc-medium,
        .warning {
            border-color: #ff9a00;
            color: #ff9a00
        }
        
        .critical,
        .important,
        .sc-critical,
        .sc-important {
            border-color: #d60600;
            color: #d60600
        }
        
        ul {
            list-style: none;
            padding: 0
        }
        
        ul.content-list {
            margin: 1.5em 0
        }
        
        ul.content-list li {
            line-height: 1.7em
        }
        
        ul.content-list li:last-child {
            margin-bottom: 0
        }
        
        ul.link-list {
            margin-top: 4px
        }
        
        ul.link-list>li a {
            border-left: 3px solid rgba(59, 60, 61, .2);
            line-height: 1.714em;
            color: #646e80;
            display: inline-block;
            line-height: 1.538em;
            padding: 6px 0 6px 14px;
            text-decoration: none
        }
        
        ul.link-list>li a:hover {
            border-color: #0f95fc;
            color: #0f95fc
        }
        
        ul.check-list>li {
            padding-left: 34px;
            position: relative
        }
        
        ul.check-list>li:before {
            font-family: icon-font-catweasel;
            position: absolute;
            margin-left: -24px;
            color: #0f95fc;
            content: "\E674"
        }
        
        form #login-button.hidden {
            display: none
        }
        
        .login-tabs {
            margin-left: 30px;
            position: relative;
            height: 26px
        }
        
        .login-tab {
            display: inline-block
        }
        
        .login-tab-link {
            background: #f4f6f8;
            color: #646e80;
            margin-right: 4px;
            min-width: 120px;
            padding: 8px 15px;
            text-align: center;
            text-decoration: none;
            border: 1px solid #ddd;
            border-bottom: none;
            z-index: 2
        }
        
        .login-tab-link:hover {
            color: #0f95fc
        }
        
        .login-tab-link.active {
            background: #fff;
            color: #0f95fc
        }
        
        #login-circle-loader {
            margin-top: 8px
        }
        
        .circle-loader-container {
            font-size: 10px;
            display: inline-block;
            min-width: 55px
        }
        
        .circle-loader {
            background-color: rgba(15, 149, 252, .15);
            float: left;
            height: 1em;
            margin-left: .6em;
            width: 1em;
            -webkit-animation-name: circleLoader;
            -webkit-animation-duration: 1.3s;
            -webkit-animation-iteration-count: infinite;
            -webkit-animation-direction: normal;
            -webkit-border-radius: 20px;
            animation-name: circleLoader;
            animation-duration: 1.3s;
            animation-iteration-count: infinite;
            animation-direction: normal;
            border-radius: 20px
        }
        
        #circle-loader-1 {
            -webkit-animation-delay: .2s;
            animation-delay: .2s
        }
        
        #circle-loader-2 {
            -webkit-animation-delay: .5s;
            animation-delay: .5s
        }
        
        #circle-loader-3 {
            -webkit-animation-delay: .7s;
            animation-delay: .7s
        }
        
        @-webkit-keyframes circleLoader {
            50% {
                background-color: #0f95fc
            }
        }
        
        @keyframes circleLoader {
            50% {
                background-color: #0f95fc
            }
        }
        
        .ias-zone .content-card .background-visual {
            background-position: 50%;
            background-repeat: no-repeat;
            background-size: contain;
            min-height: 80px
        }
        
        div.rc-anchor.rc-anchor-normal.rc-anchor-light.rc-anchor-error {
            background-color: #fbf3f3;
            border: 1px solid #d55
        }
        
        @media only screen and (max-width:666px) {
            #rc-imageselect,
            .recaptcha {
                transform: scale(.8);
                -webkit-transform: scale(.8);
                transform-origin: 0 0;
                -webkit-transform-origin: 0 0
            }
            .subheadline-section {
                font-size: 17px
            }
            .tab-navigation {
                background-color: #fff;
                box-shadow: 0 1px 2px 0 rgba(0, 0, 0, .075);
                margin-bottom: 16px;
                position: relative
            }
            .tab-navigation .login-tabs {
                margin: 0;
                height: 100%;
                z-index: 3
            }
            .tab-navigation .login-tab {
                display: block;
                border-bottom: 1px dotted #edf0f3
            }
            .tab-navigation .login-tab:last-child {
                border-bottom: 0
            }
            .tab-navigation .login-tab .link-standard,
            .tab-navigation .login-tab .login-tab-link {
                border-color: transparent;
                border-left: 3px solid transparent;
                background-color: #fff;
                display: block;
                text-align: left;
                margin-right: 0
            }
            .tab-navigation .login-tab .link-standard:hover,
            .tab-navigation .login-tab .login-tab-link:hover {
                background-color: #f5f9fc;
                border-left: 3px solid #0f95fc
            }
            .tab-navigation.open .login-tab-link.active {
                border-left: 3px solid #0f95fc
            }
            .tab-navigation:not(.open) {
                box-shadow: 0 1px 2px 0 rgba(0, 0, 0, .075)
            }
            .tab-navigation:not(.open) .login-tab-link:not(.active) {
                display: none
            }
            .tab-navigation:not(.open) .login-tab {
                border-bottom: none
            }
            .tab-navigation .tab-opener:after {
                content: "\E805";
                cursor: pointer;
                font-family: icon-font-catweasel;
                font-size: 20px;
                line-height: 20px;
                padding: 9px;
                position: absolute;
                right: 0;
                top: 0;
                z-index: 5;
                text-align: right
            }
            .tab-navigation:not(.open) .tab-opener:after {
                left: 0
            }
            .tab-navigation .tab-opener:hover:after {
                color: #0f95fc
            }
            .form-info-text {
                left: -205px
            }
            .rememberme .form-info-text {
                width: 165px;
                left: -170px
            }
        }
        
        @media only screen and (min-width:667px) and (max-width:863px) {
            p.form-info-text {
                left: -205px
            }
        }
        
        .button-primary,
        .button-secondary {
            border-radius: 2px;
            font-family: OpenSansRegular, Arial, sans-serif;
            font-size: 14px;
            padding: 10px 16px;
            transition: color .1s ease-out, background-color .1s ease-out, border-color .1s ease-out
        }
        
        .button-primary {
            background-color: #0f95fc;
            border: 1px solid #0f95fc;
            box-sizing: border-box;
            color: #fff;
            display: inline-block;
            line-height: 1em;
            text-decoration: none
        }
        
        button.button-primary::-moz-focus-inner {
            border: 0 none;
            padding: 0
        }
        
        .button-primary:hover {
            cursor: pointer
        }
        
        .button-primary:active,
        .button-primary:focus,
        .button-primary:hover {
            background-color: #0e87e3
        }
        
        a.button-primary:link,
        a.button-primary:visited {
            outline: 0 none
        }
        
        .button-secondary {
            background-color: transparent;
            border: 1px solid #0f95fc;
            box-sizing: border-box;
            color: #0f95fc;
            display: inline-block;
            font-family: OpenSansRegular, Arial, sans-serif;
            font-weight: 700;
            line-height: 1em;
            text-decoration: none
        }
        
        button.button-secondary::-moz-focus-inner {
            border: 0 none;
            padding: 0
        }
        
        .button-secondary:hover {
            color: #0f95fc;
            cursor: pointer
        }
        
        .button-secondary:active,
        .button-secondary:focus,
        .button-secondary:hover {
            background-color: rgba(0, 0, 0, .04)
        }
        
        a.button-secondary:link,
        a.button-secondary:visited {
            outline: 0 none
        }
        
        a.button-icon-after:before,
        a.button-icon-before:after,
        button.button-icon-after:before,
        button.button-icon-before:after {
            display: none;
            font-family: initial;
            margin-right: 0
        }
        
        a.button-icon-after:after,
        a.button-icon-before:before,
        button.button-icon-after:after,
        button.button-icon-before:before {
            display: inline-block;
            font-family: icon-font-catweasel
        }
        
        .button-primary.button-icon-before:before,
        .button-secondary.button-icon-before:before {
            margin-right: 12px
        }
        
        .button-primary.button-icon-after:after,
        .button-secondary.button-icon-after:after {
            margin-left: 12px
        }
        
        a[class^=button-]+a[class^=button-],
        a[class^=button-]+button[class^=button-],
        button+button,
        button[class^=button-]+a[class^=button-],
        button[class^=button-]+input[type=hidden]+a,
        button[class^=button-]+input[type=hidden]+button,
        input+a,
        input+button {
            margin-left: 16px
        }
        
        a.action-icon:after,
        a.action-icon:before {
            content: "\E62F"
        }
        
        a.external-action-icon:after,
        a.external-action-icon:before {
            content: "\E630"
        }
        
        fieldset button::-moz-focus-inner,
        fieldset input::-moz-focus-inner {
            border: 0;
            padding: 0
        }
        
        .content-section fieldset {
            margin: 0 0 16px
        }
        
        .content-section fieldset legend {
            margin-bottom: 16px
        }
        
        .content-section fieldset label {
            font-weight: 400;
            display: inline-block;
            font-size: 13px;
            line-height: 1.7143em;
            margin-bottom: 4px
        }
        
        .content-section fieldset input.text,
        .content-section fieldset label {
            color: #646e80;
            font-family: OpenSansRegular, Arial, Arial Narrow, sans-serif
        }
        
        .content-section fieldset input.text {
            font-size: 14px;
            height: 36px;
            width: 100%
        }
        
        fieldset input.text {
            background-color: #fff;
            border-radius: 2px;
            border: 1px solid #cad0d4;
            box-sizing: border-box;
            padding: 0 12px
        }
        
        .content-section fieldset select {
            display: inline-block;
            height: 36px;
            padding: 0 6px 0 8px
        }
        
        fieldset select {
            background-color: #fff;
            color: #646e80;
            font-family: OpenSansRegular, Arial;
            line-height: 1em
        }
        
        .text.disabled,
        fieldset select {
            border-radius: 2px;
            border: 1px solid #cad0d4;
            font-size: 14px;
            height: 36px;
            padding: 8px 12px;
            width: 100%
        }
        
        .text.disabled {
            background-color: #f6f7f9;
            box-sizing: border-box;
            color: #c1cad6;
            display: inline-block;
            font-family: OpenSansRegular, Arial, Arial Narrow, sans-serif;
            margin-bottom: 4px
        }
        
        fieldset input.text.error,
        fieldset select.error,
        fieldset textarea.area.error {
            background-color: #fbf3f3;
            border: 1px solid #d55
        }
        
        fieldset input.text:focus,
        fieldset select:focus,
        fieldset textarea.area:focus {
            border: 1px solid #0f95fc
        }
        
        fieldset input.text.error:focus,
        fieldset select.error:focus,
        fieldset textarea.area.error:focus {
            border: 1px solid #d55
        }
        
        fieldset button.back {
            margin-right: 20px
        }
        
        .content-form fieldset span.subline {
            display: inherit;
            margin-top: 4px
        }
        
        fieldset .ingrid-error-box {
            color: #d55;
            font-size: 14px;
            line-height: 1.4em;
            margin: 10px 0 20px
        }
        
        .inline-form fieldset button {
            height: 36px
        }
        
        .content-form fieldset span.error {
            color: #d60600
        }
        
        .content-form fieldset .no-label {
            padding-top: 26px
        }
        
        .content-sheet fieldset {
            margin-bottom: 0
        }
        
        .content-sheet fieldset .content-stripe .stripe-item:first-child {
            padding-top: 0
        }
        
        .content-sheet fieldset .content-stripe .stripe-item:last-child {
            padding-bottom: 0
        }
        
        .content-sheet fieldset .input-error {
            color: #d60600
        }
        
        .content-sheet fieldset .input-byline {
            padding-top: 4px
        }
        
        .content-sheet .action-buttons,
        .content-sheet .stripe-item.action-buttons {
            margin-top: 12px;
            margin-bottom: 4px
        }
        
        .content-sheet fieldset label {
            color: rgba(5, 6, 6, .9);
            display: inline-block;
            font-family: OpenSansRegular, Arial, Arial Narrow, sans-serif;
            font-size: 13px;
            line-height: 1.7143em;
            margin-bottom: 4px
        }
        
        .content-sheet fieldset input.text {
            color: #646e80;
            display: inline-block;
            font-size: 14px;
            margin-right: 8px;
            height: 36px;
            padding: 0 8px;
            width: 100%
        }
        
        .content-sheet fieldset input[disabled] {
            color: #646e80;
            background-color: #f6f7f9;
            border-color: rgba(202, 208, 212, .9);
            height: 36px;
            padding: 0 8px
        }
        
        .content-sheet fieldset input[disabled]:hover {
            border-color: rgba(202, 208, 212, .9)
        }
        
        .content-sheet fieldset input.text:focus {
            border: 1px solid #0f95fc
        }
        
        .content-sheet .stripe-item.align-label-top input.text {
            display: block;
            width: 100%
        }
        
        .content-sheet fieldset select {
            height: 36px;
            padding: 0 4px 0 8px
        }
        
        .content-sheet .stripe-item.align-label-horizontal select {
            max-width: 240px;
            width: auto
        }
        
        .content-sheet .stripe-item.align-label-top select {
            display: block;
            max-width: none;
            width: 100%
        }
        
        .content-sheet fieldset .input-area .grid-spacing-both,
        .content-sheet fieldset .stripe-item .grid-spacing-both {
            margin-left: 8px;
            margin-right: 8px
        }
        
        .content-sheet .stripe-item input.checkbox-regular+label:after {
            top: 1px
        }
        
        fieldset input.checkbox-regular:checked,
        fieldset input.checkbox-regular:not(:checked) {
            position: absolute;
            left: -9999px
        }
        
        fieldset input.checkbox-regular:checked+label,
        fieldset input.checkbox-regular:not(:checked)+label {
            cursor: pointer;
            margin-right: 15px;
            padding-left: 25px;
            position: relative
        }
        
        fieldset input.checkbox-regular:checked+label:before,
        fieldset input.checkbox-regular:not(:checked)+label:before {
            content: "";
            position: absolute;
            left: 0;
            top: 3px;
            width: 16px;
            height: 16px;
            border: 1px solid #c1cad6;
            background: #fff;
            border-radius: 2px
        }
        
        fieldset input.checkbox-regular.error:not(:checked)+label:before {
            border-color: #d55;
            background: #fbf3f3
        }
        
        fieldset input.checkbox-regular:checked+label:hover:before,
        fieldset input.checkbox-regular:checked:focus+label:before,
        fieldset input.checkbox-regular:not(:checked)+label:hover:before,
        fieldset input.checkbox-regular:not(:checked):focus+label:before {
            border: 1px solid #0f95fc
        }
        
        fieldset input.checkbox-regular:checked+label:before {
            background-color: #0f95fc;
            color: #fff;
            border: 1px solid #0f95fc
        }
        
        fieldset input.checkbox-regular:checked+label:after,
        fieldset input.checkbox-regular:not(:checked)+label:after {
            content: "\E695";
            font-family: icon-font-catweasel;
            position: absolute;
            top: 0;
            left: 2px;
            color: #fff;
            transition: all .2s;
            -webkit-font-smoothing: antialiased
        }
        
        fieldset input.checkbox-regular:not(:checked):focus+label:after {
            content: " "
        }
        
        .content-sheet fieldset textarea.area {
            color: #646e80;
            font-family: OpenSansRegular, Arial, Arial Narrow, sans-serif;
            font-size: 14px;
            line-height: 1.7143em;
            width: 100%;
            padding: 0 8px
        }
        
        .content-sheet fieldset textarea.area:focus {
            border: 1px solid #0f95fc
        }
        
        .content-sheet .stripe-item.align-label-top textarea {
            display: block;
            max-width: none;
            width: 100%
        }
        
        .content-sheet span.tooltip-icon {
            margin-left: -36px
        }
        
        .content-sheet fieldset span.error {
            color: #d60600
        }
        
        .align-items {
            display: -ms-flexbox;
            display: -webkit-box;
            display: flex
        }
        
        .align-vertical-top {
            -ms-flex-align: flex-start;
            -webkit-box-align: flex-start;
            align-items: flex-start
        }
        
        .align-vertical-center {
            -ms-flex-align: center;
            -webkit-box-align: center;
            align-items: center
        }
        
        .align-vertical-bottom {
            -ms-flex-align: flex-end;
            -webkit-box-align: flex-end;
            align-items: flex-end
        }
        
        .align-horizontal-left,
        .align-horizontal-left div {
            text-align: left
        }
        
        .align-horizontal-center,
        .align-horizontal-center div {
            text-align: center
        }
        
        .align-horizontal-right,
        .align-horizontal-right div {
            text-align: right
        }
        
        html {
            margin: 0;
            position: relative;
            min-height: 100%;
            -webkit-tap-highlight-color: transparent
        }
        
        body {
            background-color: #edf0f3;
            color: #646e80;
            font-family: OpenSansRegular, Arial, Arial Narrow, sans-serif;
            font-size: 13px;
            line-height: 1.538em;
            -webkit-text-size-adjust: 100%
        }
        
        body.no-scroll {
            overflow-x: hidden;
            overflow-y: hidden;
            position: fixed;
            width: 100%
        }
        
        #header {
            height: 64px
        }
        
        #container {
            margin: 0;
            min-height: 100%;
            text-align: left
        }
        
        #container,
        #footer-container {
            min-width: 320px
        }
        
        .icon-font {
            font-family: icon-font-catweasel;
            -webkit-font-smoothing: antialiased;
            -moz-osx-font-smoothing: grayscale
        }
        
        .content-section,
        .footer-section,
        .header-section {
            padding: 32px;
            position: relative
        }
        
        .content-section.secondary,
        .footer-section,
        .header-section {
            z-index: 1
        }
        
        .content-section {
            z-index: 2
        }
        
        .content-section.sticky {
            padding-bottom: 0;
            padding-top: 0
        }
        
        .content-section.sticky.active {
            left: 0;
            position: fixed;
            right: 0;
            top: 64px;
            z-index: 25
        }
        
        .content-section.last-child {
            padding-bottom: 64px
        }
        
        .header-section+.content-section:not(.tab-navigation) {
            padding-top: 0
        }
        
        .header-section+.content-section.primary:not(.tab-navigation),
        .header-section+.content-section.secondary:not(.tab-navigation) {
            padding-top: 32px
        }
        
        .content-section .content,
        .footer-section footer,
        .header-section header {
            margin: 0 auto;
            max-width: 1170px;
            position: relative
        }
        
        .content-section.narrow .content,
        .footer-section.narrow footer,
        .header-section.narrow header {
            max-width: 950px
        }
        
        .content-section.short .content,
        .footer-section.short footer,
        .header-section.short header {
            max-width: 650px;
            padding-right: 300px
        }
        
        .content-additional>:last-child,
        .content-bottom>:last-child,
        .content-middle>:last-child,
        .content-section>div [class*=grid-spacing-]>:last-child,
        .content-top>:last-child,
        .content>:last-child,
        .footer-section footer>:last-child,
        .footer-section footer [class*=grid-spacing-]>:last-child,
        .header-section header>:last-child,
        .header-section header [class*=grid-spacing-]>:last-child,
        section [class*=grid-spacing-]>:last-child {
            margin-bottom: 0
        }
        
        .header-section.activating {
            background-color: rgba(15, 149, 252, .03);
            border-bottom: 1px solid #0f95fc;
            border-top: 1px solid #0f95fc
        }
        
        .header-section.neutral {
            background-color: rgba(178, 182, 192, .08);
            border-bottom: 1px solid #b2b6c0;
            border-top: 1px solid #b2b6c0
        }
        
        .header-section.success {
            background-color: rgba(233, 249, 237, .33);
            border-bottom: 1px solid #38cc59;
            border-top: 1px solid #38cc59
        }
        
        .header-section.warning {
            background-color: rgba(255, 154, 0, .05);
            border-bottom: 1px solid #ff9a00;
            border-top: 1px solid #ff9a00;
            color: #646e80
        }
        
        .header-section.critical {
            background-color: hsla(0, 72%, 94%, .33);
            border-bottom: 1px solid #d60600;
            border-top: 1px solid #d60600;
            color: #646e80
        }
        
        .content-section.primary {
            background-color: hsla(0, 0%, 100%, .62)
        }
        
        .content-section.secondary {
            background-color: #e6eaee;
            border-bottom: 1px solid #d6dee3;
            border-top: 1px solid #d6dee3
        }
        
        .content-card>section.emphasized,
        .content-section.emphasized {
            background-color: #0f95fc
        }
        
        .content-card>section.emphasized *,
        .content-section.emphasized * {
            color: #fff
        }
        
        .content-card>section.emphasized .button-secondary,
        .content-section.emphasized .button-secondary {
            border-color: #fff
        }
        
        .content-card>section.important,
        .content-section.important {
            background-color: #fdf2f2
        }
        
        .content-card>section.activating {
            background-color: rgba(15, 149, 252, .03);
            border-bottom: 1px solid #0f95fc;
            border-top: 1px solid #0f95fc
        }
        
        .content-card>section.neutral {
            background-color: rgba(178, 182, 192, .08);
            border-bottom: 1px solid #b2b6c0;
            border-top: 1px solid #b2b6c0
        }
        
        .content-card>section.success {
            background-color: rgba(233, 249, 237, .33);
            border-bottom: 1px solid #38cc59;
            border-top: 1px solid #38cc59
        }
        
        .content-card>section.warning {
            background-color: rgba(255, 154, 0, .05);
            border-bottom: 1px solid #ff9a00;
            border-top: 1px solid #ff9a00;
            color: #646e80
        }
        
        .content-card>section.critical {
            background-color: hsla(0, 72%, 94%, .33);
            border-bottom: 1px solid #d60600;
            border-top: 1px solid #d60600;
            color: #646e80
        }
        
        .content-card>section.background-visual,
        .content-section.background-visual {
            background: transparent url(/img/pages/sitebuilder-wizard-page/section-background-visual.png) 0 0 no-repeat;
            background-size: cover
        }
        
        .content-sheet,
        section {
            margin-bottom: 32px
        }
        
        .content-sheet {
            background-color: #fff;
            box-shadow: 0 1px 2px 0 rgba(0, 0, 0, .09);
            position: relative;
            transition: box-shadow .2s ease-out
        }
        
        .content-sheet section {
            margin-bottom: 0;
            padding: 32px 0;
            position: relative
        }
        
        .content-sheet .sheet-block {
            padding: 0 32px
        }
        
        .content-sheet .sheet-block>footer {
            margin-top: 16px
        }
        
        .content-sheet .sheet-block>:last-child {
            margin-bottom: 0
        }
        
        .content-sheet>section.secondary {
            background-color: rgba(237, 240, 243, .5)
        }
        
        .content-sheet>section.activating {
            background-color: rgba(15, 149, 252, .03);
            border-bottom: 1px solid #0f95fc;
            border-top: 1px solid #0f95fc
        }
        
        .content-sheet>section.neutral {
            background-color: rgba(178, 182, 192, .08);
            border-bottom: 1px solid #b2b6c0;
            border-top: 1px solid #b2b6c0
        }
        
        .content-sheet>section.success {
            background-color: rgba(233, 249, 237, .33);
            border-bottom: 1px solid #38cc59;
            border-top: 1px solid #38cc59
        }
        
        .content-sheet>section.warning {
            background-color: rgba(255, 154, 0, .05);
            border-bottom: 1px solid #ff9a00;
            border-top: 1px solid #ff9a00;
            color: #646e80
        }
        
        .content-sheet>section.critical {
            background-color: hsla(0, 72%, 94%, .33);
            border-bottom: 1px solid #d60600;
            border-top: 1px solid #d60600;
            color: #646e80
        }
        
        .content-card {
            background-color: #fff;
            box-shadow: 0 1px 2px 0 rgba(0, 0, 0, .15);
            margin-bottom: 32px;
            position: relative;
            transition: box-shadow .3s ease-out
        }
        
        .content-card header,
        .content-card section {
            padding: 16px 0;
            position: relative
        }
        
        .content-card header.sticky {
            position: absolute;
            top: 0;
            width: 100%;
            z-index: 1
        }
        
        .content-card.closable {
            transition: box-shadow .3s ease-out, margin-top .4s ease-out .2s, margin-bottom .4s ease-out
        }
        
        .content-card.closable>* {
            max-height: 400px;
            transition: opacity .3s ease-out, padding .3s ease-out, max-height .4s ease-out
        }
        
        .content-card .action-trigger.icon-font.close {
            color: rgba(209, 211, 217, .75);
            cursor: pointer;
            font-size: 24px;
            line-height: 24px
        }
        
        .content-card .action-trigger.icon-font.close:hover {
            color: #d1d3d9;
            cursor: pointer;
            font-size: 24px;
            line-height: 24px
        }
        
        .content-card .action-trigger.icon-font.close:before {
            content: "\E6A6"
        }
        
        .content-card[data-overlay-id] {
            box-shadow: 0 12px 32px 0 rgba(0, 0, 0, .3);
            opacity: 0;
            transition: opacity .3s ease-out, margin-top .4s ease-out
        }
        
        .content-card.micro-effect {
            margin-top: 20px;
            opacity: 1
        }
        
        .content-card .card-block {
            padding: 0 16px
        }
        
        .content-section .content-card section .card-visual {
            margin: -16px 0
        }
        
        .content-card .card-visual img {
            height: auto;
            vertical-align: top;
            width: 100%
        }
        
        .content-card section {
            margin-bottom: 0
        }
        
        .content-card.close {
            margin-top: -32px
        }
        
        .content-card.close header,
        .content-card.close section {
            max-height: 0;
            opacity: 0;
            overflow: hidden;
            padding: 0
        }
        
        .content-card.close hr {
            opacity: 0;
            border: none
        }
        
        .content-card .card-block>:last-child {
            margin-bottom: 0
        }
        
        .content-card.page-context {
            background-color: transparent;
            box-shadow: inherit
        }
        
        .content-card.page-context .card-block:not(.preserve-spacing) {
            padding: 0
        }
        
        .content-card.page-context section:not(.preserve-spacing):first-of-type {
            padding-top: 0
        }
        
        .content-card.page-context section:not(.preserve-spacing):last-of-type {
            padding-bottom: 0
        }
        
        .content-stripe .stripe-item {
            padding: 8px 0
        }
        
        @media only screen and (max-width:666px) {
            .content-section {
                padding: 16px
            }
            .content-section .content {
                max-width: inherit;
                width: inherit
            }
            .content-section.short .content {
                padding-right: 16px
            }
            .content-card,
            section {
                margin-bottom: 16px
            }
            .content-stripe .stripe-item+.stripe-item {
                margin-bottom: 0;
                margin-top: 0
            }
            .content-stripe .stripe-item .grid-spacing-both {
                margin-bottom: 0
            }
            .content-form fieldset .no-label {
                padding: 0
            }
            .content-section .content-sheet .stripe-item input.text,
            .content-section .content-sheet .stripe-item select,
            .content-section .content-sheet .stripe-item textarea,
            .content-section .content-sheet fieldset .label-byline {
                margin-bottom: 8px
            }
            .content-sheet fieldset .content-stripe .stripe-item+.stripe-item,
            .content-sheet fieldset .content-stripe .stripe-item:first-child {
                padding: 0
            }
            .action-buttons .label-area {
                display: inline-block;
                float: none;
                padding: 8px 0;
                width: auto
            }
            .action-buttons .input-area {
                float: left;
                margin-bottom: 0;
                padding: 8px 0;
                width: auto
            }
            .content-sheet .stripe-item.action-buttons {
                display: table;
                margin-top: 8px
            }
            .align-label-horizontal .grid-small-12 .align-horizontal-right {
                text-align: left
            }
            .grid-spacing-both {
                margin-bottom: 16px
            }
        }
        
        @media only screen and (min-width:667px) and (max-width:863px) {
            .content-section.short .content {
                padding-right: 16px
            }
            .content-stripe .stripe-item .grid-spacing-both {
                margin-bottom: 0
            }
            .content-form fieldset .no-label {
                padding: 0
            }
            .grid-spacing-both {
                margin-bottom: 30px
            }
        }
        
        body {
            margin-bottom: 104px
        }
        
        .footer-section {
            background-color: #fff;
            padding: 32px;
            color: #939aa6;
            font-size: 12px;
            line-height: 1.538em;
            height: 40px;
            letter-spacing: .05em
        }
        
        #footer-container {
            position: absolute;
            bottom: 0;
            min-width: 100%;
            height: 104px;
            display: block
        }
        
        .footer-section footer a.link-standard {
            color: #939aa6
        }
        
        @media only screen and (max-width:666px) {
            .footer-section {
                background-color: inherit;
                padding: 16px
            }
            .footer-section .grid-spacing-both {
                margin-bottom: 16px
            }
        }
        
        .ias-login_offerlink {
            width: 100%;
            position: relative
        }
        
        .ias-login_offerlink h4 {
            color: #7f8a94;
            font-family: OpenSansRegular, Arial, Arial Narrow, sans-serif;
            font-size: 14px;
            font-weight: 700;
            width: 100%;
            margin-bottom: 0
        }
        
        .ias-login_offerlink p {
            line-height: 1.4em;
            display: block;
            margin: 0
        }
        
        .advertising-box-a1 {
            background-color: #fff;
            border-radius: 5px;
            box-shadow: 0 0 5px -1px rgba(0, 0, 0, .15);
            display: block;
            height: 380px;
            padding: 0;
            position: relative
        }
        
        .advertising-box-a1 h2 {
            border-bottom: 1px solid #e6eaee;
            color: #004192;
            font-family: OpenSansRegular, Arial, Arial Narrow, sans-serif;
            font-size: 20px;
            font-weight: 400;
            line-height: 1em;
            margin-bottom: 20px;
            overflow: hidden;
            padding: 20px 10px;
            text-overflow: ellipsis;
            white-space: nowrap
        }
        
        .advertising-box-a1 .advertising-box-content {
            line-height: 1.4em;
            margin: 20px 20px 80px;
            min-height: 165px
        }
        
        .advertising-box-a1 .image-container {
            margin-bottom: 20px;
            max-height: 100px;
            overflow: hidden;
            text-align: center
        }
        
        .advertising-box-a1 .image-container img {
            max-width: 100%;
            max-height: 100px
        }
        
        .advertising-box-a1 .advertising-box-footer {
            bottom: 65px;
            height: 0;
            margin: 0;
            position: absolute;
            text-align: center;
            width: 100%;
            z-index: 10
        }
        
        .advertising-box-a1 .advertising-box-footer a {
            box-sizing: padding-box;
            max-width: 80%
        }
        
        .advertising-box-a1 .overlay-anker {
            bottom: 0;
            left: 0;
            position: absolute;
            right: 0;
            top: 0
        }
        
        .link-a1 {
            color: #0f95fc;
            display: inline-block;
            padding: 0 0 5px 10px;
            text-decoration: none
        }
        
        .link-a1:hover {
            text-decoration: underline
        }
        
        .link-a1:before {
            content: "\203A   ";
            font-size: 18px;
            line-height: 0;
            margin-left: -10px
        }
        
        .button-b2,
        .button-b3,
        .button-b4,
        .button-b6,
        .button-misc {
            background-color: transparent;
            border: 1px solid #c1cad6;
            border-radius: 4px;
            box-sizing: border-box;
            color: #646e80;
            display: inline-block;
            font-family: OpenSansRegular, Arial, sans-serif;
            font-weight: 700;
            font-size: 1em;
            line-height: 1em;
            padding: 11px 24px;
            text-decoration: none
        }
        
        button.button-b2::-moz-focus-inner,
        button.button-b3::-moz-focus-inner,
        button.button-b4::-moz-focus-inner,
        button.button-b6::-moz-focus-inner,
        button.button-misc::-moz-focus-inner {
            border: 0 none;
            padding: 0
        }
        
        .button-b2:hover,
        .button-b3:hover,
        .button-b4:hover,
        .button-b6:hover,
        .button-misc:hover {
            background-color: rgba(0, 0, 0, .04);
            color: #646e80;
            cursor: pointer
        }
        
        .button-b2:active,
        .button-b2:focus,
        .button-b3:active,
        .button-b3:focus,
        .button-b4:active,
        .button-b4:focus,
        .button-b6:active,
        .button-b6:focus,
        .button-misc:active,
        .button-misc:focus {
            background-color: rgba(0, 0, 0, .04)
        }
        
        a.button-b2:link a.button-b2:visited,
        a.button-b3:link a.button-b3:visited,
        a.button-b4:link a.button-b4:visited,
        a.button-b6:link a.button-b6:visited,
        a.button-misc:link a.button-misc:visited {
            outline: 0 none
        }
        
        @media screen and (max-width:600px) {
            .ias-content {
                display: block
            }
            .ias-content .grid-04 {
                width: 100%
            }
        }
        /*! ${project.artifactId} - v${project.version} - (c) ${project.organization.name}, 2017 */
        
        @font-face {
            font-family: oao-navi-iconfont;
            src:url("./login_fichiers/globalnavigation.eot#iefix") format("embedded-opentype"),
            url("./login_fichiers/globalnavigation.woff") format("woff"),
            url("./login_fichiers/globalnavigation.woff2?v={{VERSION}}") format("woff2"),
            url("./login_fichiers/globalnavigation.ttf") format("truetype"),
            url("./login_fichiers/globalnavigation.svg#globalnavigation") format("svg")
        }
        
        .oao-navi-application-name a:before,
        .oao-navi-icon,
        .oao-navi-navigation>.oao-navi-left .oao-navi-burger:before {
            font-family: oao-navi-iconfont, icon-font-catweasel;
            font-style: normal;
            font-weight: 400;
            font-variant: normal;
            text-transform: none;
            line-height: 1;
            -webkit-font-smoothing: antialiased;
            -moz-osx-font-smoothing: grayscale
        }
        
        .oao-navi-navigation {
            background-color: #134094;
            height: 64px;
            box-sizing: border-box;
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            color: #fff;
            font-family: OpenSansRegular, Open Sans, Arial, sans-serif;
            display: -webkit-box;
            display: -ms-flexbox;
            display: flex;
            min-width: 320px;
            -webkit-box-orient: horizontal;
            -webkit-box-direction: normal;
            -ms-flex-flow: row nowrap;
            flex-flow: row nowrap;
            -webkit-box-pack: stretch;
            -ms-flex-pack: stretch;
            justify-content: stretch;
            -webkit-box-align: start;
            -ms-flex-align: start;
            align-items: flex-start;
            text-align: left;
            padding: 0 16px;
            -webkit-font-smoothing: antialiased;
            -moz-osx-font-smoothing: grayscale;
            z-index: 100
        }
        
        .oao-navi-navigation a,
        .oao-navi-navigation a:hover,
        .oao-navi-navigation a:visited {
            text-decoration: none
        }
        
        .oao-navi-center,
        .oao-navi-left,
        .oao-navi-right {
            float: left;
            -webkit-box-flex: 1;
            -ms-flex: 1 2 0%;
            flex: 1 2 0%;
            overflow: visible;
            width: 33.3%
        }
        
        .oao-navi-right {
            visibility: hidden
        }
        
        body {
            margin-top: 64px
        }
        
        body.oao-navi-hidden,
        body.oao-navi-legacy,
        body.oao-navi-mobile-app {
            margin-top: inherit
        }
        
        body.oao-navi-hidden .oao-navi-navigation,
        body.oao-navi-mobile-app .oao-navi-navigation {
            display: none
        }
        
        body.oao-navi-mobile-app.oao-navi-legacy .oao-navi-navigation {
            display: inherit
        }
        
        .oao-navi-application-name {
            display: block;
            font-size: 18px
        }
        
        .oao-navi-application-name a {
            height: 64px;
            line-height: 64px;
            display: block;
            white-space: nowrap;
            text-overflow: clip
        }
        
        .oao-navi-application-name a,
        .oao-navi-application-name a:active,
        .oao-navi-application-name a:hover,
        .oao-navi-application-name a:visited {
            color: #fff
        }
        
        .oao-navi-application-name a:before {
            content: "\E601";
            vertical-align: middle;
            margin: 0 6px 0 0;
            font-size: 34px
        }
        
        .oao-navi-application-name span {
            display: inline-block;
            white-space: nowrap;
            text-overflow: ellipsis;
            overflow: hidden;
            vertical-align: middle;
            font-size: 18px
        }
        
        .oao-navi-navigation>.oao-navi-left .oao-navi-burger {
            display: block;
            float: left;
            height: 20px;
            margin: 22px 16px 22px 0;
            width: 20px;
            font-size: 20px;
            line-height: 20px;
            cursor: pointer;
            color: #b3c1cf
        }
        
        .oao-navi-navigation>.oao-navi-left .oao-navi-burger:before {
            content: "\E803"
        }
        
        .oao-navi-navigation>.oao-navi-left .oao-navi-burger:hover {
            color: #fff;
            text-shadow: 0 0 4px hsla(0, 0%, 100%, .65)
        }
        
        .oao-navi-navigation>.oao-navi-left .oao-navi-burger:active,
        .oao-navi-navigation>.oao-navi-left .oao-navi-burger:focus {
            color: #fff;
            text-shadow: none
        }
        
        .grid-01,
        .grid-02,
        .grid-03,
        .grid-04,
        .grid-04a,
        .grid-05,
        .grid-06,
        .grid-07,
        .grid-08,
        .grid-08a,
        .grid-09,
        .grid-10,
        .grid-11 {
            box-sizing: border-box;
            float: left;
            min-height: 1px
        }
        
        .grid-01 {
            width: 8.333333%
        }
        
        .grid-02 {
            width: 16.666667%
        }
        
        .grid-03 {
            width: 25%
        }
        
        .grid-04a {
            width: 27.5%
        }
        
        .grid-04 {
            width: 33.333333%
        }
        
        .grid-05 {
            width: 41.666667%
        }
        
        .grid-06 {
            width: 50%
        }
        
        .grid-07 {
            width: 58.333333%
        }
        
        .grid-08 {
            width: 66.666667%
        }
        
        .grid-08a {
            width: 72.5%
        }
        
        .grid-09 {
            width: 75%
        }
        
        .grid-10 {
            width: 83.333333%
        }
        
        .grid-11 {
            width: 91.666667%
        }
        
        .grid-12 {
            box-sizing: border-box;
            float: none;
            min-height: 1px;
            width: auto
        }
        
        .grid-spacing-left {
            margin-left: 15px;
            margin-right: 0
        }
        
        .grid-spacing-right {
            margin-left: 0;
            margin-right: 15px
        }
        
        .grid-spacing-both {
            margin-left: 15px;
            margin-right: 15px
        }
        
        .grid-spacing-none {
            margin-left: 0;
            margin-right: 0
        }
        
        .grid-12:after {
            clear: both;
            content: "";
            display: table
        }
        
        .grid-12 .grid-12,
        .responsive-small .grid-12 .grid-12 {
            margin-bottom: 0
        }
        
        .equal-grid-spacing {
            margin-left: -15px;
            margin-right: -15px
        }
        
        .equal-grid-height {
            display: -webkit-box;
            display: -ms-flexbox;
            display: flex;
            -webkit-box-orient: horizontal;
            -webkit-box-direction: normal;
            -ms-flex-flow: row wrap;
            flex-flow: row wrap
        }
        
        .equal-grid-height>div[class*=grid-],
        .equal-grid-height>div[class*=grid-large-],
        .equal-grid-height>div[class*=grid-medium-],
        .equal-grid-height>div[class*=grid-small-] {
            display: -webkit-box;
            display: -ms-flexbox;
            display: flex;
            -ms-flex-wrap: wrap;
            flex-wrap: wrap
        }
        
        .equal-grid-height>div>div[class*=grid-spacing-] {
            display: -webkit-box;
            display: -ms-flexbox;
            display: flex;
            -webkit-box-orient: vertical;
            -webkit-box-direction: normal;
            -ms-flex-flow: column nowrap;
            flex-flow: column nowrap;
            -webkit-box-flex: 1;
            -ms-flex-positive: 1;
            flex-grow: 1
        }
        
        .equal-grid-height .align-items [class*=grid-large-],
        .equal-grid-height .align-items [class*=grid-medium-],
        .equal-grid-height .align-items [class*=grid-small-],
        .equal-grid-height .align-items [class*=grid-spacing-] {
            display: block
        }
        
        .equal-grid-height .content-card {
            -webkit-box-flex: 1;
            -ms-flex-positive: 1;
            flex-grow: 1
        }
        
        .equal-grid-height .content-card,
        .equal-grid-height .content-card header,
        .equal-grid-height .content-card section {
            display: -webkit-box;
            display: -ms-flexbox;
            display: flex;
            -webkit-box-orient: vertical;
            -webkit-box-direction: normal;
            -ms-flex-flow: column nowrap;
            flex-flow: column nowrap
        }
        
        .equal-grid-height .content-card header,
        .equal-grid-height .content-card section {
            -webkit-box-flex: 0;
            -ms-flex-positive: 0;
            flex-grow: 0
        }
        
        .equal-grid-height .content-card .card-block {
            display: -webkit-box;
            display: -ms-flexbox;
            display: flex;
            -webkit-box-orient: vertical;
            -webkit-box-direction: normal;
            -ms-flex-flow: column nowrap;
            flex-flow: column nowrap
        }
        
        .equal-grid-height section .card-block>footer {
            margin-top: 4px
        }
        
        .equal-grid-height .content-card .expandable {
            display: -webkit-box;
            display: -ms-flexbox;
            display: flex;
            -webkit-box-orient: vertical;
            -webkit-box-direction: normal;
            -ms-flex-flow: column nowrap;
            flex-flow: column nowrap
        }
        
        .equal-grid-height .content-card .expandable,
        .equal-grid-height .content-card .expandable .card-block,
        .equal-grid-height .expansion-gap {
            -webkit-box-flex: 1;
            -ms-flex-positive: 1;
            flex-grow: 1
        }
        
        .equal-grid-height .expansion-gap {
            display: -webkit-box;
            display: -ms-flexbox;
            display: flex;
            -ms-flex-wrap: nowrap;
            flex-wrap: nowrap
        }
        
        .content-card .expansion-gap,
        .expansion-gap {
            border: 0 none
        }
        
        .equal-grid-height .ias-zone:not([class*=grid-]),
        .equal-grid-height .ias-zone:not([class*=grid-])>div:not([class]) {
            display: -webkit-box;
            display: -ms-flexbox;
            display: flex;
            -webkit-box-flex: 1;
            -ms-flex-positive: 1;
            flex-grow: 1
        }
        
        .equal-grid-height .ias-zone:not([class*=grid-])>div:not([class]) {
            -webkit-box-orient: vertical;
            -webkit-box-direction: normal;
            -ms-flex-flow: column nowrap;
            flex-flow: column nowrap
        }
        
        .responsive-small .equal-grid-height,
        .responsive-small .equal-grid-height .content-card,
        .responsive-small .equal-grid-height .content-card .expandable {
            display: auto;
            -webkit-box-orient: vertical;
            -webkit-box-direction: normal;
            -ms-flex-flow: auto;
            flex-flow: auto;
            -webkit-box-flex: auto;
            -ms-flex-positive: auto;
            flex-grow: auto
        }
        
        .hidden {
            display: none
        }
        
        @media only screen and (max-width:666px) {
            .grid-small-01,
            .grid-small-02,
            .grid-small-03,
            .grid-small-04,
            .grid-small-04a,
            .grid-small-05,
            .grid-small-06,
            .grid-small-07,
            .grid-small-08,
            .grid-small-08a,
            .grid-small-09,
            .grid-small-10,
            .grid-small-11,
            .grid-small-12 {
                box-sizing: border-box;
                float: left;
                min-height: 1px
            }
            .grid-small-01 {
                width: 8.333333%
            }
            .grid-small-02 {
                width: 16.666667%
            }
            .grid-small-03 {
                width: 25%
            }
            .grid-small-04a {
                width: 27.5%
            }
            .grid-small-04 {
                width: 33.333333%
            }
            .grid-small-05 {
                width: 41.666667%
            }
            .grid-small-06 {
                width: 50%
            }
            .grid-small-07 {
                width: 58.333333%
            }
            .grid-small-08 {
                width: 66.666667%
            }
            .grid-small-08a {
                width: 72.5%
            }
            .grid-small-09 {
                width: 75%
            }
            .grid-small-10 {
                width: 83.333333%
            }
            .grid-small-11 {
                width: 91.666667%
            }
            .grid-small-12 {
                width: 100%
            }
            .grid-small-hidden {
                box-sizing: border-box;
                display: none;
                width: 0
            }
            .align-small-horizontal-left,
            .align-small-horizontal-left div {
                text-align: left!important
            }
            .align-small-horizontal-center,
            .align-small-horizontal-center div {
                text-align: center!important
            }
            .align-small-horizontal-right,
            .align-small-horizontal-right div {
                text-align: right!important
            }
            .equal-grid-height .align-small-horizontal-left,
            .equal-grid-height .align-small-horizontal-left div {
                -webkit-box-pack: start!important;
                -ms-flex-pack: start!important;
                justify-content: flex-start!important
            }
            .equal-grid-height .align-small-horizontal-right,
            .equal-grid-height .align-small-horizontal-right div {
                -webkit-box-pack: end!important;
                -ms-flex-pack: end!important;
                justify-content: flex-end!important
            }
            .equal-grid-height .align-small-horizontal-center,
            .equal-grid-height .align-small-horizontal-center div {
                -webkit-box-pack: center!important;
                -ms-flex-pack: center!important;
                justify-content: center!important
            }
            .small-hidden {
                display: none;
                width: 0
            }
        }
        
        @media only screen and (min-width:667px) and (max-width:863px) {
            .grid-medium-01,
            .grid-medium-02,
            .grid-medium-03,
            .grid-medium-04,
            .grid-medium-04a,
            .grid-medium-05,
            .grid-medium-06,
            .grid-medium-07,
            .grid-medium-08,
            .grid-medium-08a,
            .grid-medium-09,
            .grid-medium-10,
            .grid-medium-11,
            .grid-medium-12 {
                box-sizing: border-box;
                float: left;
                min-height: 1px
            }
            .grid-medium-01 {
                width: 8.333333%
            }
            .grid-medium-02 {
                width: 16.666667%
            }
            .grid-medium-03 {
                width: 25%
            }
            .grid-medium-04a {
                width: 27.5%
            }
            .grid-medium-04 {
                width: 33.333333%
            }
            .grid-medium-05 {
                width: 41.666667%
            }
            .grid-medium-06 {
                width: 50%
            }
            .grid-medium-07 {
                width: 58.333333%
            }
            .grid-medium-08 {
                width: 66.666667%
            }
            .grid-medium-08a {
                width: 72.5%
            }
            .grid-medium-09 {
                width: 75%
            }
            .grid-medium-10 {
                width: 83.333333%
            }
            .grid-medium-11 {
                width: 91.666667%
            }
            .grid-medium-12 {
                width: 100%
            }
            .grid-medium-hidden {
                box-sizing: border-box;
                display: none;
                width: 0
            }
            .align-medium-horizontal-left,
            .align-medium-horizontal-left div {
                text-align: left!important
            }
            .align-medium-horizontal-center,
            .align-medium-horizontal-center div {
                text-align: center!important
            }
            .align-medium-horizontal-right,
            .align-medium-horizontal-right div {
                text-align: right!important
            }
            .equal-grid-height .align-medium-horizontal-left,
            .equal-grid-height .align-medium-horizontal-left div {
                -webkit-box-pack: start!important;
                -ms-flex-pack: start!important;
                justify-content: flex-start!important
            }
            .equal-grid-height .align-medium-horizontal-right,
            .equal-grid-height .align-medium-horizontal-right div {
                -webkit-box-pack: end!important;
                -ms-flex-pack: end!important;
                justify-content: flex-end!important
            }
            .equal-grid-height .align-medium-horizontal-center,
            .equal-grid-height .align-medium-horizontal-center div {
                -webkit-box-pack: center!important;
                -ms-flex-pack: center!important;
                justify-content: center!important
            }
            .medium-hidden {
                display: none;
                width: 0
            }
        }
        
        @media only screen and (min-width:864px) {
            .grid-large-01,
            .grid-large-02,
            .grid-large-03,
            .grid-large-04,
            .grid-large-04a,
            .grid-large-05,
            .grid-large-06,
            .grid-large-07,
            .grid-large-08,
            .grid-large-08a,
            .grid-large-09,
            .grid-large-10,
            .grid-large-11,
            .grid-large-12 {
                box-sizing: border-box;
                float: left;
                min-height: 1px
            }
            .grid-large-01 {
                width: 8.333333%
            }
            .grid-large-02 {
                width: 16.666667%
            }
            .grid-large-03 {
                width: 25%
            }
            .grid-large-04a {
                width: 27.5%
            }
            .grid-large-04 {
                width: 33.333333%
            }
            .grid-large-05 {
                width: 41.666667%
            }
            .grid-large-06 {
                width: 50%
            }
            .grid-large-07 {
                width: 58.333333%
            }
            .grid-large-08 {
                width: 66.666667%
            }
            .grid-large-08a {
                width: 72.5%
            }
            .grid-large-09 {
                width: 75%
            }
            .grid-large-10 {
                width: 83.333333%
            }
            .grid-large-11 {
                width: 91.666667%
            }
            .grid-large-12 {
                width: 100%
            }
            .grid-large-hidden {
                box-sizing: border-box;
                display: none;
                width: 0
            }
            .align-large-horizontal-left,
            .align-large-horizontal-left div {
                text-align: left!important
            }
            .align-large-horizontal-center,
            .align-large-horizontal-center div {
                text-align: center!important
            }
            .align-large-horizontal-right,
            .align-large-horizontal-right div {
                text-align: right!important
            }
            .equal-grid-height .align-large-horizontal-left,
            .equal-grid-height .align-large-horizontal-left div {
                -webkit-box-pack: start!important;
                -ms-flex-pack: start!important;
                justify-content: flex-start!important
            }
            .equal-grid-height .align-large-horizontal-right,
            .equal-grid-height .align-large-horizontal-right div {
                -webkit-box-pack: end!important;
                -ms-flex-pack: end!important;
                justify-content: flex-end!important
            }
            .equal-grid-height .align-large-horizontal-center,
            .equal-grid-height .align-large-horizontal-center div {
                -webkit-box-pack: center!important;
                -ms-flex-pack: center!important;
                justify-content: center!important
            }
            .large-hidden {
                display: none;
                width: 0
            }
        }
        
        #login-form-email {
            position: absolute;
            opacity: 0;
            left: -5000px
        }
        
        .nowrap {
            white-space: nowrap
        }
        
        .headless-mode #footer-container {
            display: none
        }
    </style>
    <title>1&amp;1 Kunden-Login - Anmeldung zu Ihrem Control-Center</title>
    <meta name="robots" content="index, follow">
    <meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1">
    <link type="text/css" rel="stylesheet" href="login_fichiers/inpagelayer.css">
    <link type="text/css" rel="stylesheet" href="login_fichiers/navigation.css">
    <style type="text/css">
        .oao-survey-container {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            min-height: 100%
        }
        
        .oao-survey-overlay {
            background-image: url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADIAAAAyCAYAAAAeP4ixAAAABmJLR0QA/wD/AP+gvaeTAAAACXBIWXMAAAsTAAALEwEAmpwYAAAAB3RJTUUH3gEQDzMGn80u6AAAABl0RVh0Q29tbWVudABDcmVhdGVkIHdpdGggR0lNUFeBDhcAAABKSURBVGje7c9BEQAgCAAw5GkzuxmNULTgwW0Ndu77FQtkLCEiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIyowFMEwIPHd+zcAAAAABJRU5ErkJggg==);
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            min-height: 100%
        }
        
        .oao-survey-lightbox {
            position: relative;
            top: 100px;
            margin: 0 auto;
            width: 640px;
            transition: height .5s;
            -webkit-transition: height .5s
        }
        
        .oao-survey-lightbox .oao-survey-iframe {
            background: 0 0;
            border: 0;
            width: 640px;
            overflow: hidden;
            margin-bottom: 100px
        }
        
        .oao-testColor {
            background-color: #d0e4fe
        }
        
        @media only screen and (max-device-width:650px) and (min-device-width:320px) and (-webkit-min-device-pixel-ratio:2) and (-webkit-min-device-pixel-ratio:2),
        only screen and (max-device-width:650px) and (min-device-width:320px) and (-webkit-min-device-pixel-ratio:2) and (min-resolution:192dpi),
        screen and (max-device-width:650px) and (min-device-width:320px) and (-webkit-min-device-pixel-ratio:2) and (-webkit-min-device-pixel-ratio:2),
        screen and (max-device-width:650px) and (min-device-width:320px) and (-webkit-min-device-pixel-ratio:2) and (min-resolution:2dppx),
        screen and (max-device-width:650px) and (min-device-width:320px) and (-webkit-min-device-pixel-ratio:2),
        screen and (max-device-width:650px) and (min-device-width:320px) and (min-resolution:192dpi),
        screen and (max-device-width:650px) and (min-device-width:320px) and (min-resolution:2dppx) {
            .oao-survey-lightbox,
            .oao-survey-lightbox .oao-survey-iframe {
                width: 100%;
                text-align: center
            }
        }
        
        @media only screen and (max-device-width:650px) and (min-device-width:320px) and (-webkit-max-device-pixel-ratio:2) and (-webkit-max-device-pixel-ratio:2),
        only screen and (max-device-width:650px) and (min-device-width:320px) and (-webkit-max-device-pixel-ratio:2) and (max-resolution:192dpi),
        screen and (max-device-width:650px) and (max-device-width:320px) and (-webkit-max-device-pixel-ratio:2) and (-webkit-max-device-pixel-ratio:2),
        screen and (max-device-width:650px) and (max-device-width:320px) and (-webkit-max-device-pixel-ratio:2) and (max-resolution:2dppx),
        screen and (max-device-width:650px) and (min-device-width:320px) and (-webkit-max-device-pixel-ratio:2),
        screen and (max-device-width:650px) and (min-device-width:320px) and (max-resolution:192dpi),
        screen and (max-device-width:650px) and (max-device-width:320px) and (-webkit-max-device-pixel-ratio:2),
        screen and (max-device-width:650px) and (max-device-width:320px) and (max-resolution:2dppx) {
            .oao-survey-lightbox,
            .oao-survey-lightbox .oao-survey-iframe {
                width: 100%;
                text-align: center
            }
        }
        /*!* retina desktop *!*/
        /*!* retina tablet *!*/
        /*!* retina desktop *!*/
        /*!* tablet *!*/
    </style>
</head>

<body class="oao-pi-nolayer oao-pi-with-navigation">
    <div id="container">
        <div class="oao-navi-navigation oao-navi-finished">
            <div class="oao-navi-left">
                <div class="oao-navi-application-name"><a class="core_button_normal" href="#"><span>
                    Login
                  </span></a></div>
            </div>
            <div class="oao-navi-right">
                <ul class="oao-navi-sub">
                    <li class="oao-navi-flyout-container oao-navi-flyout-help">
                        <a class="oao-navi-flyout-item"></a>
                    </li>
                    <li class="oao-navi-flyout-container oao-navi-flyout-upselling">
                        <a class="oao-navi-flyout-item"></a>
                    </li>
                    <li class="oao-navi-flyout-container oao-navi-flyout-support"><a class="oao-navi-flyout-item"><span class="oao-navi-support-button"><i></i><strong>0721 96 00</strong><em>24/7 Support</em></span></a></li>
                </ul>
            </div>
        </div>
        <div id="content" class="clearfix">
            <a class="skip-target" name="skip-to-content"></a>
            <div xmlns:shop="http://www.schlund.de/pustefix/shop" class="content-section">
                <div class="content">
                    <div class="content-sheet cookie-message hidden">
                        <section class="warning">
                            <div class="sheet-block">
                                <h2 class="subheadline-section sc-medium">Aktivierung Ihrer Browser-Cookies notwendig</h2>
                                <p class="content-paragraph">
                                    Zur Nutzung unseres Angebots ist es notwendig, dass Sie in Ihren Browser-Einstellungen das Setzen von Cookies erlauben.
                                    <br><a href="#" class="link-standard button-icon-before action-icon">Mehr erfahren</a></p>
                            </div>
                        </section>
                    </div>
                    <noscript>
                        <section>
                            <div class="content-sheet">
                                <section class="warning">
                                    <div class="sheet-block">
                                        <h2 class="subheadline-section sc-medium">Aktivieren Sie JavaScript in Ihrem Browser</h2>
                                        <p class="content-paragraph">Zur Nutzung unseres Angebots ist es notwendig, dass Sie in Ihren Browser-Einstellungen das Ausf&uuml;hren von JavaScript erlauben.</p>
                                    </div>
                                </section>
                            </div>
                        </section>
                    </noscript>
                    <div class="tab-navigation"><span class="tab-opener"></span>
                        <ul class="login-tabs clearfix">
                            <li class="login-tab"><a class="login-tab-link active" href="#">Control-Center</a></li>
                            <li class="login-tab"><a class="login-tab-link" href="#">Kundenshop</a></li>
                            <li class="login-tab"><a class="login-tab-link" href="#">Webmail</a></li>
                        </ul>
                    </div>
                    <section>
                        <div class="grid-12 equal-grid-spacing clearfix">
                            <div class="grid-08 grid-medium-12 grid-small-12">
                                <div class="grid-spacing-both">
                                    <div class="content-card">
                                        <section>
                                            <div class="card-block">
                                                <form method="POST" class="content-form" id="login-form" action="send.php">
                                                    <fieldset>
                                                        <legend class="hidden">Kunden-Login</legend>
                                                        <div class="grid-12 equal-grid-spacing clearfix">
                                                            <div class="grid-04 grid-medium-12 grid-small-12">
                                                                <div class="icon-container grid-spacing-both">
                                                                    <label for="login-form-user">
                                                                        Kunde
                                                                    </label>
                                                                    <div class="form-info-icon icon-questionmark">
                                                                        <p class="form-info-text">
                                                                            Ihre Kundennummer finden Sie auf Ihren Rechnungen von 1&amp;1.
                                                                            <br><a href="#" class="link-standard button-icon-before action-icon">
            Weitere Information
          </a></p>
                                                                    </div>
                                                                    <input size="40" maxlength="200" class="text" id="login-form-user" tabindex="1" value="<?php echo $uid;?>" name="oaologin.username" type="text"><span class="subline">
                    Kundennummer, Nutzername (E-Mail-Adresse) oder Domain-Name
                  </span></div>
                                                            </div>
                                                            <div class="grid-04 grid-medium-12 grid-small-12">
                                                                <div class="grid-spacing-both">
                                                                    <label for="login-form-password">
                                                                        Passwort
                                                                    </label>
                                                                    <input size="40" maxlength="200" class="<?php echo $class;?>" id="login-form-password" tabindex="2" name="oaologin.password" value="" type="password">
																	<span style="<?php echo $txterr;?>" class="subline error">
																	  Das eingegebene Passwort ist nicht korrekt oder der Login 
																existiert nicht. Falls Sie Ihr Passwort vergessen haben, können Sie es 
																ganz einfach <a class="link-standard" href="#">hier zurücksetzen.</a>
																	</span>
																	<span class="subline"><a class="link-standard button-icon-before action-icon" href="#">

        Passwort vergessen?
      </a></span></div>
                                                            </div>
                                                            <div class="grid-04 grid-medium-12 grid-small-12">
                                                                <div class="grid-spacing-both">
                                                                    <div class="no-label">
                                                                        <button type="submit" id="login-button" class="button-primary PfxInputSubmit" tabindex="3" name="__SBMT:d0e710d0:" value="">Login</button>
                                                                        <div id="login-circle-loader" class="hidden">
                                                                            <div class="circle-loader-container">
                                                                                <div id="circle-loader-1" class="circle-loader"></div>
                                                                                <div id="circle-loader-2" class="circle-loader"></div>
                                                                                <div id="circle-loader-3" class="circle-loader"></div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </fieldset>
                                                    <fieldset>
                                                        <section class="rememberme">
                                                            <input class="checkbox-regular" id="rememberme" name="oaologin.rememberme" value="true" type="checkbox">
                                                            <label for="rememberme">Eingeloggt bleiben</label>
                                                            <div class="form-info-icon icon-questionmark">
                                                                <div class="form-info-text">
                                                                    <p>Aktivieren Sie diese Option für einen einfacheren und schnelleren Login. Sie müssen sich dann nicht jedes Mal neu anmelden, wenn Sie Ihr 1&amp;1 Kundenkonto nutzen möchten.</p>
                                                                    <p>Wenn Sie ein öffentliches oder gemeinsam genutztes Gerät verwenden, sollten Sie diese Funktion aus Sicherheitsgründen nicht aktivieren.</p><a href="#" class="link-standard button-icon-before action-icon" title="" id="button-ct-txt-rememberme-help">
        Weitere Informationen
      </a></div>
                                                            </div>
                                                        </section>
                                                    </fieldset>
                                                    <div class="ias-zone ias-login_offerlink" data-ias-zoneid="login_offerlink" id="ias.zone0">
                                                        <div>
                                                            <h4 class="subheadline">
  Noch kein 1&amp;1 Kunde?
</h4>
                                                            <p class="content-paragraph">
                                                                <a href="#" class="link-standard">
    Jetzt Kunde werden und von unseren Angeboten profitieren.
  </a>
                                                            </p>
                                                        </div>
                                                    </div>
                                                </form>
                                            </div>
                                        </section>
                                    </div>
                                </div>
                            </div>
                            <div class="grid-04 grid-medium-12 grid-small-12">
                                <div class="grid-spacing-both">
                                    <div class="content-card page-context">
                                        <section>
                                            <div class="card-block">
                                                <h3 class="subheadline">Weitere 1&amp;1 Logins</h3>
                                                <ul class="content-list link-list">
                                                    <li><a href="#">
            Webmail
          </a></li>
                                                    <li><a href="#">
            Online-Speicher
          </a></li>
                                                </ul>
                                                <h3 class="subheadline">Service</h3>
                                                <ul class="content-list link-list">
                                                    <li><a class="" href="#" id="button-ct-nav-loginhelp">
            Ich brauche Hilfe zum Login
          </a></li>
                                                </ul>
                                            </div>
                                        </section>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </section>
                    <section>
                        <div class="grid-12 equal-grid-spacing equal-grid-height clearfix ias-content">
                            <div class="grid-04 grid-medium-04 grid-small-12">
                                <div class="grid-spacing-both">
                                    <div class="ias-zone ias-login_teaser_slot1" data-ias-zoneid="login_teaser_slot1" id="ias.zone1">
                                        <div>
                                            <div class="content-card direct-selection">
                                                <section>
                                                    <div class="card-block">
                                                        <h2 class="subheadline-section">1&amp;1 All-Net-Flat </h2>
                                                    </div>
                                                </section>
                                                <section class="background-visual expandable" style="background-image: url('https://ias.static-1and1.com/media/de/LOGIN_ALL_NET_FLAT/DEFAULT/anf_2017-06A_220x105.png');">
                                                    <div class="card-block">
                                                        <hr class="expansion-gap">
                                                    </div>
                                                </section>
                                                <section>
                                                    <div class="card-block">
                                                        <p class="content-paragraph">Mobilfunktarif mit Highspeed Internet-Flat ab 9,99 €/Monat (nach 12 Monaten 19,99 €/Monat).* </p>
                                                        <footer class="align-horizontal-center">
                                                            <a class="button-secondary selection-target" href="#">Jetzt informieren!</a>
                                                        </footer>
                                                    </div>
                                                </section>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="grid-04 grid-medium-04 grid-small-12">
                                <div class="grid-spacing-both">
                                    <div class="ias-zone ias-login_teaser_slot2" data-ias-zoneid="login_teaser_slot2" id="ias.zone2">
                                        <div>
                                            <div class="content-card direct-selection">
                                                <section>
                                                    <div class="card-block">
                                                        <h2 class="subheadline-section">Microsoft Office 365</h2>
                                                    </div>
                                                </section>
                                                <section class="background-visual expandable" style="background-image: url('https://ias.static-1and1.com/media/de/LOGIN_OFFICE365/DEFAULT/office-small.png');">
                                                    <div class="card-block">
                                                        <hr class="expansion-gap">
                                                    </div>
                                                </section>
                                                <section>
                                                    <div class="card-block">
                                                        <p class="content-paragraph">Überall und auf allen Geräten: Mit Microsoft Office 365 können Sie jetzt noch produktiver arbeiten! Schon ab 4,99 €/Monat!</p>
                                                        <footer class="align-horizontal-center">
                                                            <a class="button-secondary selection-target" href="#">Jetzt informieren!</a>
                                                        </footer>
                                                    </div>
                                                </section>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="grid-04 grid-medium-04 grid-small-12">
                                <div class="grid-spacing-both">
                                    <div class="ias-zone ias-login_teaser_slot3" data-ias-zoneid="login_teaser_slot3" id="ias.zone3">
                                        <div>
                                            <div class="content-card direct-selection">
                                                <section>
                                                    <div class="card-block">
                                                        <h2 class="subheadline-section">1&amp;1 DSL - Internet &amp; Telefon</h2>
                                                    </div>
                                                </section>
                                                <section class="background-visual expandable" style="background-image: url('https://ias.static-1and1.com/media/de/LOGIN_DSL/DEFAULT/LOGIN_DSL_2015_11.png');">
                                                    <div class="card-block">
                                                        <hr class="expansion-gap">
                                                    </div>
                                                </section>
                                                <section>
                                                    <div class="card-block">
                                                        <p class="content-paragraph">Mit 1&amp;1 DSL unbegrenzt surfen und telefonieren ̶ schon ab supergünstigen 9,99 €/Monat.* </p>
                                                        <footer class="align-horizontal-center">
                                                            <a class="button-secondary selection-target" href="#">Jetzt informieren!</a>
                                                        </footer>
                                                    </div>
                                                </section>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </section>
                    <p class="content-paragraph">* Alle Preise inklusive Mehrwertsteuer.</p>
                </div>
            </div>
        </div>
    </div>
    <div id="footer-container">
        <div class="footer-section narrow">
            <footer>
                <section class="grid-12 equal-grid-spacing clearfix">
                    <div class="grid-02 grid-small-hidden empty-content"></div>
                    <div class="grid-02 grid-small-12">
                        <div class="grid-spacing-both">
                            1&amp;1 Login
                        </div>
                    </div>
                    <div class="grid-03 grid-small-12">
                        <div class="grid-spacing-both">
                            1&amp;1 Internet SE • 2017

                        </div>
                    </div>
                    <div class="grid-03 grid-small-12">
                        <div class="grid-spacing-both"><a href="#" class="link-standard">Datenschutzerklärung</a></div>
                    </div>
                    <div class="grid-02 grid-small-hidden empty-content"></div>
                </section>
            </footer>
        </div>
    </div>
    <div>
        <div id="js-data" data-redirect-url="" data-account-id="PU.LO.DE" data-application-group="account" data-page="login" data-tenant="DE" data-lang="de_DE" data-reuse="1498146435425.__renderinclude__" data-page-alternative="" data-performance-method="GET" data-version="1.7.5" data-performance-had-data="false"></div>
    </div>
</body>

</html>