# Facebook-Responsive-Phishing-Page 2020
A responsive phishing site for facebook 

There are many ways to hack facebook accounts, but unfortunately, Everything won't work properly in nowadays because today’s IT security system is developed so far especially Facebook.<br>
<strong>Phishing</strong> is the popular method to hack FB but there is a lot of problems in present days, everybody can create a phishing page but the problem comes when we need responsive page (to work fine on all devices).

Here is it. 

Live <strong>demo</strong>:: <a href="http://iphonexfree.herobo.com/" target="_blank">Facebook Page</a>

<br>

You can host this on a free server, and it does not get traced down by the automated phishing page detector :)

This is purely for the educational purposes and is not intended to hurt anyone

<pre>

<img src="https://raw.githubusercontent.com/Xuntron/Facebook-Responsive-Phishing-Page/master/mobile_demo.png">

<img src="https://raw.githubusercontent.com/Xuntron/Facebook-Responsive-Phishing-Page/master/desktop_demo.png">

</pre>
