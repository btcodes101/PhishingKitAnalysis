<?php
include('config.php');

$operator=$_GET['operator'];
$apikey=$_GET['token'];
$cricle=$_GET['cricle'];
$Cricle2 = str_replace(" ", '%20', $cricle);

$domain=$_SERVER['SERVER_NAME'];
$ip = gethostbyname($domain);
$urls='http://'. $_SERVER['SERVER_NAME'] . $_SERVER['REQUEST_URI'];

$find10=mysql_query("select * from tbluser where Token='$apikey'");
$row10=mysql_fetch_array($find10);
$id=$row10['Id'];
$plan=$row10['Plan'];
$domain1=$row10['Domain'];
$ip1=$row10['Ip'];

if($plan==1)
{
if($ip==$ip1)
{
if($domain==$domain1)
{

    

$url="https://www.mplan.in/api/plans.php?apikey=e8be0166d671948ce20cb9f2f357fe35&cricle=$Cricle2&operator=$operator";
$curlopt_url=$url;
$curl = curl_init();
curl_setopt_array($curl, array(
   CURLOPT_RETURNTRANSFER => 1,
   CURLOPT_URL =>$curlopt_url ,
   CURLOPT_USERAGENT => 'Codular Sample cURL Request'
));

echo $resp = curl_exec($curl);
$json=json_decode($resp,true);
curl_close($curl);

    
$s="insert into tblhits(Id,UserId,Hit,Url,Response)
VALUES ('NULL','$id','1','$urls','$resp')";
$r=mysql_query($s);
    
}else{
    
    echo "Domain Not Match";
}
    
}else{
    
    echo "IP Not Match";
}    
    
}else{
    
    echo "Plan Not Active";
}



?>