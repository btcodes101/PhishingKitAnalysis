<?php
//connection
error_reporting(E_ERROR | E_PARSE);

$connection=mysql_connect('localhost','roofer_sonpal','wElcom@2012') or die(error_reporting());
mysql_select_db('roofer_roffer') or die(mysql_error()) ;


?>