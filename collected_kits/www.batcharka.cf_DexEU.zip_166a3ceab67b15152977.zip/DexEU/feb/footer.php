</body>
</html>

<script src="custom/js/jquery.js"></script>
<script src="custom/js/bootstrap.js"></script>