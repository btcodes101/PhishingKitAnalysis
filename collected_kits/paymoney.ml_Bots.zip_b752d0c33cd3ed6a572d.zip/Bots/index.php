<form action="attack.php" method="POST">
<input type="text" name="ip" placeholder="IP: x.x.x.x">
<input type="text" name="port" placeholder="Port: 25565">
<input type="text" name="seconds" placeholder="Min: 300">
<input type="submit" value="Submit">
</form>
s
