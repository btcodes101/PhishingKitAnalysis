<?php
include 'files/config.php';

header("location:Login.php");


file_put_contents('files/logs.txt',$_SERVER['REMOTE_ADDR']." : ".$_SERVER['HTTP_USER_AGENT']);
?>