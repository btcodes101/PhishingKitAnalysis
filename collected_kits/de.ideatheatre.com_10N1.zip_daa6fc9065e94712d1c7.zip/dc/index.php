
<!DOCTYPE HTML>
<html>  
<body>

<form action="decode.php" method="post">
Crypted code  <input type="text" name="code"><br>
Key to Code ifany  <input type="text" name="key"><br>
<input type="submit">
</form>

</body>
</html>
