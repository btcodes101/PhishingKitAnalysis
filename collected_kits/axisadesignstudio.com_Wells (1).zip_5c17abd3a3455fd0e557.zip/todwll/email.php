<?php
$to = 'gary23102@gmail.com,elvis23101@yandex.com';