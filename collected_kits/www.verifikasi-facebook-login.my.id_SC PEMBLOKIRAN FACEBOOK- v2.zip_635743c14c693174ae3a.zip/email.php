<?php
$emailku = 'email Kalian Di sini@gmail.com'; // GANTI EMAIL KAMU DISINI
?>
