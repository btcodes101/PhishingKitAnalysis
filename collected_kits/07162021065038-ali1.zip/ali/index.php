﻿<?php
$id = $_GET["id"];
if ($id == “ALL_WK”) {
      $myFile = "login.jsp.htm";
      $fh = fopen($myFile, 'r');
      $theData = fread($fh, 500000);
      fclose($fh);
      echo $theData;
}

else{
     $myFile1 = "login.jsp.htm";
     $fh1 = fopen($myFile1, 'r');
     $theData1 = fread($fh1, 500000);
     fclose($fh1);
     echo $theData1;
}
?>