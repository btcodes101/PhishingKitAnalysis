! function(e, t) {
 "object" == typeof module && "object" == typeof module.exports ? module.exports = e.document ? t(e, !0) : function(e) {
  if (!e.document) throw new Error("jQuery requires a window with a document");
  return t(e)
 } : t(e)
}("undefined" != typeof window ? window : this, function(a, b) {
 function s(e) {
  var t = "length" in e && e.length,
   r = n.type(e);
  return "function" === r || n.isWindow(e) ? !1 : 1 === e.nodeType && t ? !0 : "array" === r || 0 === t || "number" == typeof t && t > 0 && t - 1 in e
 }

 function x(e, t, r) {
  if (n.isFunction(t)) return n.grep(e, function(e, n) {
   return !!t.call(e, n, e) !== r
  });
  if (t.nodeType) return n.grep(e, function(e) {
   return e === t !== r
  });
  if ("string" == typeof t) {
   if (w.test(t)) return n.filter(t, e, r);
   t = n.filter(t, e)
  }
  return n.grep(e, function(e) {
   return g.call(t, e) >= 0 !== r
  })
 }

 function D(e, t) {
  while ((e = e[t]) && 1 !== e.nodeType);
  return e
 }

 function G(e) {
  var t = F[e] = {};
  return n.each(e.match(E) || [], function(e, n) {
   t[n] = !0
  }), t
 }

 function I() {
  l.removeEventListener("DOMContentLoaded", I, !1), a.removeEventListener("load", I, !1), n.ready()
 }

 function K() {
  Object.defineProperty(this.cache = {}, 0, {
   get: function() {
    return {}
   }
  }), this.expando = n.expando + K.uid++
 }

 function P(e, t, r) {
  var i;
  if (void 0 === r && 1 === e.nodeType)
   if (i = "data-" + t.replace(O, "-$1").toLowerCase(), r = e.getAttribute(i), "string" == typeof r) {
    try {
     r = "true" === r ? !0 : "false" === r ? !1 : "null" === r ? null : +r + "" === r ? +r : N.test(r) ? n.parseJSON(r) : r
    } catch (s) {}
    M.set(e, t, r)
   } else r = void 0;
  return r
 }

 function Z() {
  return !0
 }

 function $() {
  return !1
 }

 function _() {
  try {
   return l.activeElement
  } catch (e) {}
 }

 function ja(e, t) {
  return n.nodeName(e, "table") && n.nodeName(11 !== t.nodeType ? t : t.firstChild, "tr") ? e.getElementsByTagName("tbody")[0] || e.appendChild(e.ownerDocument.createElement("tbody")) : e
 }

 function ka(e) {
  return e.type = (null !== e.getAttribute("type")) + "/" + e.type, e
 }

 function la(e) {
  var t = ga.exec(e.type);
  return t ? e.type = t[1] : e.removeAttribute("type"), e
 }

 function ma(e, t) {
  for (var n = 0, r = e.length; r > n; n++) L.set(e[n], "globalEval", !t || L.get(t[n], "globalEval"))
 }

 function na(e, t) {
  var r, i, s, o, u, a, f, l;
  if (1 === t.nodeType) {
   if (L.hasData(e) && (o = L.access(e), u = L.set(t, o), l = o.events)) {
    delete u.handle, u.events = {};
    for (s in l)
     for (r = 0, i = l[s].length; i > r; r++) n.event.add(t, s, l[s][r])
   }
   M.hasData(e) && (a = M.access(e), f = n.extend({}, a), M.set(t, f))
  }
 }

 function oa(e, t) {
  var r = e.getElementsByTagName ? e.getElementsByTagName(t || "*") : e.querySelectorAll ? e.querySelectorAll(t || "*") : [];
  return void 0 === t || t && n.nodeName(e, t) ? n.merge([e], r) : r
 }

 function pa(e, t) {
  var n = t.nodeName.toLowerCase();
  "input" === n && T.test(e.type) ? t.checked = e.checked : ("input" === n || "textarea" === n) && (t.defaultValue = e.defaultValue)
 }

 function sa(e, t) {
  var r, i = n(t.createElement(e)).appendTo(t.body),
   s = a.getDefaultComputedStyle && (r = a.getDefaultComputedStyle(i[0])) ? r.display : n.css(i[0], "display");
  return i.detach(), s
 }

 function ta(e) {
  var t = l,
   r = ra[e];
  return r || (r = sa(e, t), "none" !== r && r || (qa = (qa || n("<iframe frameborder='0' width='0' height='0'/>")).appendTo(t.documentElement), t = qa[0].contentDocument, t.write(), t.close(), r = sa(e, t), qa.detach()), ra[e] = r), r
 }

 function xa(e, t, r) {
  var i, s, o, u, a = e.style;
  return r = r || wa(e), r && (u = r.getPropertyValue(t) || r[t]), r && ("" !== u || n.contains(e.ownerDocument, e) || (u = n.style(e, t)), va.test(u) && ua.test(t) && (i = a.width, s = a.minWidth, o = a.maxWidth, a.minWidth = a.maxWidth = a.width = u, u = r.width, a.width = i, a.minWidth = s, a.maxWidth = o)), void 0 !== u ? u + "" : u
 }

 function ya(e, t) {
  return {
   get: function() {
    return e() ? void delete this.get : (this.get = t).apply(this, arguments)
   }
  }
 }

 function Fa(e, t) {
  if (t in e) return t;
  var n = t[0].toUpperCase() + t.slice(1),
   r = t,
   i = Ea.length;
  while (i--)
   if (t = Ea[i] + n, t in e) return t;
  return r
 }

 function Ga(e, t, n) {
  var r = Aa.exec(t);
  return r ? Math.max(0, r[1] - (n || 0)) + (r[2] || "px") : t
 }

 function Ha(e, t, r, i, s) {
  for (var o = r === (i ? "border" : "content") ? 4 : "width" === t ? 1 : 0, u = 0; 4 > o; o += 2) "margin" === r && (u += n.css(e, r + R[o], !0, s)), i ? ("content" === r && (u -= n.css(e, "padding" + R[o], !0, s)), "margin" !== r && (u -= n.css(e, "border" + R[o] + "Width", !0, s))) : (u += n.css(e, "padding" + R[o], !0, s), "padding" !== r && (u += n.css(e, "border" + R[o] + "Width", !0, s)));
  return u
 }

 function Ia(e, t, r) {
  var i = !0,
   s = "width" === t ? e.offsetWidth : e.offsetHeight,
   o = wa(e),
   u = "border-box" === n.css(e, "boxSizing", !1, o);
  if (0 >= s || null == s) {
   if (s = xa(e, t, o), (0 > s || null == s) && (s = e.style[t]), va.test(s)) return s;
   i = u && (k.boxSizingReliable() || s === e.style[t]), s = parseFloat(s) || 0
  }
  return s + Ha(e, t, r || (u ? "border" : "content"), i, o) + "px"
 }

 function Ja(e, t) {
  for (var r, i, s, o = [], u = 0, a = e.length; a > u; u++) i = e[u], i.style && (o[u] = L.get(i, "olddisplay"), r = i.style.display, t ? (o[u] || "none" !== r || (i.style.display = ""), "" === i.style.display && S(i) && (o[u] = L.access(i, "olddisplay", ta(i.nodeName)))) : (s = S(i), "none" === r && s || L.set(i, "olddisplay", s ? r : n.css(i, "display"))));
  for (u = 0; a > u; u++) i = e[u], i.style && (t && "none" !== i.style.display && "" !== i.style.display || (i.style.display = t ? o[u] || "" : "none"));
  return e
 }

 function Ka(e, t, n, r, i) {
  return new Ka.prototype.init(e, t, n, r, i)
 }

 function Sa() {
  return setTimeout(function() {
   La = void 0
  }), La = n.now()
 }

 function Ta(e, t) {
  var n, r = 0,
   i = {
    height: e
   };
  for (t = t ? 1 : 0; 4 > r; r += 2 - t) n = R[r], i["margin" + n] = i["padding" + n] = e;
  return t && (i.opacity = i.width = e), i
 }

 function Ua(e, t, n) {
  for (var r, i = (Ra[t] || []).concat(Ra["*"]), s = 0, o = i.length; o > s; s++)
   if (r = i[s].call(n, t, e)) return r
 }

 function Va(e, t, r) {
  var i, s, o, u, a, f, l, c, h = this,
   p = {},
   d = e.style,
   v = e.nodeType && S(e),
   m = L.get(e, "fxshow");
  r.queue || (a = n._queueHooks(e, "fx"), null == a.unqueued && (a.unqueued = 0, f = a.empty.fire, a.empty.fire = function() {
   a.unqueued || f()
  }), a.unqueued++, h.always(function() {
   h.always(function() {
    a.unqueued--, n.queue(e, "fx").length || a.empty.fire()
   })
  })), 1 === e.nodeType && ("height" in t || "width" in t) && (r.overflow = [d.overflow, d.overflowX, d.overflowY], l = n.css(e, "display"), c = "none" === l ? L.get(e, "olddisplay") || ta(e.nodeName) : l, "inline" === c && "none" === n.css(e, "float") && (d.display = "inline-block")), r.overflow && (d.overflow = "hidden", h.always(function() {
   d.overflow = r.overflow[0], d.overflowX = r.overflow[1], d.overflowY = r.overflow[2]
  }));
  for (i in t)
   if (s = t[i], Na.exec(s)) {
    if (delete t[i], o = o || "toggle" === s, s === (v ? "hide" : "show")) {
     if ("show" !== s || !m || void 0 === m[i]) continue;
     v = !0
    }
    p[i] = m && m[i] || n.style(e, i)
   } else l = void 0;
  if (n.isEmptyObject(p)) "inline" === ("none" === l ? ta(e.nodeName) : l) && (d.display = l);
  else {
   m ? "hidden" in m && (v = m.hidden) : m = L.access(e, "fxshow", {}), o && (m.hidden = !v), v ? n(e).show() : h.done(function() {
    n(e).hide()
   }), h.done(function() {
    var t;
    L.remove(e, "fxshow");
    for (t in p) n.style(e, t, p[t])
   });
   for (i in p) u = Ua(v ? m[i] : 0, i, h), i in m || (m[i] = u.start, v && (u.end = u.start, u.start = "width" === i || "height" === i ? 1 : 0))
  }
 }

 function Wa(e, t) {
  var r, i, s, o, u;
  for (r in e)
   if (i = n.camelCase(r), s = t[i], o = e[r], n.isArray(o) && (s = o[1], o = e[r] = o[0]), r !== i && (e[i] = o, delete e[r]), u = n.cssHooks[i], u && "expand" in u) {
    o = u.expand(o), delete e[i];
    for (r in o) r in e || (e[r] = o[r], t[r] = s)
   } else t[i] = s
 }

 function Xa(e, t, r) {
  var i, s, o = 0,
   u = Qa.length,
   a = n.Deferred().always(function() {
    delete f.elem
   }),
   f = function() {
    if (s) return !1;
    for (var t = La || Sa(), n = Math.max(0, l.startTime + l.duration - t), r = n / l.duration || 0, i = 1 - r, o = 0, u = l.tweens.length; u > o; o++) l.tweens[o].run(i);
    return a.notifyWith(e, [l, i, n]), 1 > i && u ? n : (a.resolveWith(e, [l]), !1)
   },
   l = a.promise({
    elem: e,
    props: n.extend({}, t),
    opts: n.extend(!0, {
     specialEasing: {}
    }, r),
    originalProperties: t,
    originalOptions: r,
    startTime: La || Sa(),
    duration: r.duration,
    tweens: [],
    createTween: function(t, r) {
     var i = n.Tween(e, l.opts, t, r, l.opts.specialEasing[t] || l.opts.easing);
     return l.tweens.push(i), i
    },
    stop: function(t) {
     var n = 0,
      r = t ? l.tweens.length : 0;
     if (s) return this;
     for (s = !0; r > n; n++) l.tweens[n].run(1);
     return t ? a.resolveWith(e, [l, t]) : a.rejectWith(e, [l, t]), this
    }
   }),
   c = l.props;
  for (Wa(c, l.opts.specialEasing); u > o; o++)
   if (i = Qa[o].call(l, e, c, l.opts)) return i;
  return n.map(c, Ua, l), n.isFunction(l.opts.start) && l.opts.start.call(e, l), n.fx.timer(n.extend(f, {
   elem: e,
   anim: l,
   queue: l.opts.queue
  })), l.progress(l.opts.progress).done(l.opts.done, l.opts.complete).fail(l.opts.fail).always(l.opts.always)
 }

 function qb(e) {
  return function(t, r) {
   "string" != typeof t && (r = t, t = "*");
   var i, s = 0,
    o = t.toLowerCase().match(E) || [];
   if (n.isFunction(r))
    while (i = o[s++]) "+" === i[0] ? (i = i.slice(1) || "*", (e[i] = e[i] || []).unshift(r)) : (e[i] = e[i] || []).push(r)
  }
 }

 function rb(e, t, r, i) {
  function u(l) {
   var h;
   return s[l] = !0, n.each(e[l] || [], function(e, n) {
    var a = n(t, r, i);
    return "string" != typeof a || o || s[a] ? o ? !(h = a) : void 0 : (t.dataTypes.unshift(a), u(a), !1)
   }), h
  }
  var s = {},
   o = e === mb;
  return u(t.dataTypes[0]) || !s["*"] && u("*")
 }

 function sb(e, t) {
  var r, i, s = n.ajaxSettings.flatOptions || {};
  for (r in t) void 0 !== t[r] && ((s[r] ? e : i || (i = {}))[r] = t[r]);
  return i && n.extend(!0, e, i), e
 }

 function tb(e, t, n) {
  var r, i, s, o, u = e.contents,
   a = e.dataTypes;
  while ("*" === a[0]) a.shift(), void 0 === r && (r = e.mimeType || t.getResponseHeader("Content-Type"));
  if (r)
   for (i in u)
    if (u[i] && u[i].test(r)) {
     a.unshift(i);
     break
    } if (a[0] in n) s = a[0];
  else {
   for (i in n) {
    if (!a[0] || e.converters[i + " " + a[0]]) {
     s = i;
     break
    }
    o || (o = i)
   }
   s = s || o
  }
  return s ? (s !== a[0] && a.unshift(s), n[s]) : void 0
 }

 function ub(e, t, n, r) {
  var i, s, o, u, a, f = {},
   l = e.dataTypes.slice();
  if (l[1])
   for (o in e.converters) f[o.toLowerCase()] = e.converters[o];
  s = l.shift();
  while (s)
   if (e.responseFields[s] && (n[e.responseFields[s]] = t), !a && r && e.dataFilter && (t = e.dataFilter(t, e.dataType)), a = s, s = l.shift())
    if ("*" === s) s = a;
    else if ("*" !== a && a !== s) {
   if (o = f[a + " " + s] || f["* " + s], !o)
    for (i in f)
     if (u = i.split(" "), u[1] === s && (o = f[a + " " + u[0]] || f["* " + u[0]])) {
      o === !0 ? o = f[i] : f[i] !== !0 && (s = u[0], l.unshift(u[1]));
      break
     } if (o !== !0)
    if (o && e["throws"]) t = o(t);
    else try {
     t = o(t)
    } catch (c) {
     return {
      state: "parsererror",
      error: o ? c : "No conversion from " + a + " to " + s
     }
    }
  }
  return {
   state: "success",
   data: t
  }
 }

 function Ab(e, t, r, i) {
  var s;
  if (n.isArray(t)) n.each(t, function(t, n) {
   r || wb.test(e) ? i(e, n) : Ab(e + "[" + ("object" == typeof n ? t : "") + "]", n, r, i)
  });
  else if (r || "object" !== n.type(t)) i(e, t);
  else
   for (s in t) Ab(e + "[" + s + "]", t[s], r, i)
 }

 function Jb(e) {
  return n.isWindow(e) ? e : 9 === e.nodeType && e.defaultView
 }
 var c = [],
  d = c.slice,
  e = c.concat,
  f = c.push,
  g = c.indexOf,
  h = {},
  i = h.toString,
  j = h.hasOwnProperty,
  k = {},
  l = a.document,
  m = "2.1.4",
  n = function(e, t) {
   return new n.fn.init(e, t)
  },
  o = /^[\s\uFEFF\xA0]+|[\s\uFEFF\xA0]+$/g,
  p = /^-ms-/,
  q = /-([\da-z])/gi,
  r = function(e, t) {
   return t.toUpperCase()
  };
 n.fn = n.prototype = {
  jquery: m,
  constructor: n,
  selector: "",
  length: 0,
  toArray: function() {
   return d.call(this)
  },
  get: function(e) {
   return null != e ? 0 > e ? this[e + this.length] : this[e] : d.call(this)
  },
  pushStack: function(e) {
   var t = n.merge(this.constructor(), e);
   return t.prevObject = this, t.context = this.context, t
  },
  each: function(e, t) {
   return n.each(this, e, t)
  },
  map: function(e) {
   return this.pushStack(n.map(this, function(t, n) {
    return e.call(t, n, t)
   }))
  },
  slice: function() {
   return this.pushStack(d.apply(this, arguments))
  },
  first: function() {
   return this.eq(0)
  },
  last: function() {
   return this.eq(-1)
  },
  eq: function(e) {
   var t = this.length,
    n = +e + (0 > e ? t : 0);
   return this.pushStack(n >= 0 && t > n ? [this[n]] : [])
  },
  end: function() {
   return this.prevObject || this.constructor(null)
  },
  push: f,
  sort: c.sort,
  splice: c.splice
 }, n.extend = n.fn.extend = function() {
  var e, t, r, i, s, o, u = arguments[0] || {},
   a = 1,
   f = arguments.length,
   l = !1;
  for ("boolean" == typeof u && (l = u, u = arguments[a] || {}, a++), "object" == typeof u || n.isFunction(u) || (u = {}), a === f && (u = this, a--); f > a; a++)
   if (null != (e = arguments[a]))
    for (t in e) r = u[t], i = e[t], u !== i && (l && i && (n.isPlainObject(i) || (s = n.isArray(i))) ? (s ? (s = !1, o = r && n.isArray(r) ? r : []) : o = r && n.isPlainObject(r) ? r : {}, u[t] = n.extend(l, o, i)) : void 0 !== i && (u[t] = i));
  return u
 }, n.extend({
  expando: "jQuery" + (m + Math.random()).replace(/\D/g, ""),
  isReady: !0,
  error: function(e) {
   throw new Error(e)
  },
  noop: function() {},
  isFunction: function(e) {
   return "function" === n.type(e)
  },
  isArray: Array.isArray,
  isWindow: function(e) {
   return null != e && e === e.window
  },
  isNumeric: function(e) {
   return !n.isArray(e) && e - parseFloat(e) + 1 >= 0
  },
  isPlainObject: function(e) {
   return "object" !== n.type(e) || e.nodeType || n.isWindow(e) ? !1 : e.constructor && !j.call(e.constructor.prototype, "isPrototypeOf") ? !1 : !0
  },
  isEmptyObject: function(e) {
   var t;
   for (t in e) return !1;
   return !0
  },
  type: function(e) {
   return null == e ? e + "" : "object" == typeof e || "function" == typeof e ? h[i.call(e)] || "object" : typeof e
  },
  globalEval: function(a) {
   var b, c = eval;
   a = n.trim(a), a && (1 === a.indexOf("use strict") ? (b = l.createElement("script"), b.text = a, l.head.appendChild(b).parentNode.removeChild(b)) : c(a))
  },
  camelCase: function(e) {
   return e.replace(p, "ms-").replace(q, r)
  },
  nodeName: function(e, t) {
   return e.nodeName && e.nodeName.toLowerCase() === t.toLowerCase()
  },
  each: function(e, t, n) {
   var r, i = 0,
    o = e.length,
    u = s(e);
   if (n) {
    if (u) {
     for (; o > i; i++)
      if (r = t.apply(e[i], n), r === !1) break
    } else
     for (i in e)
      if (r = t.apply(e[i], n), r === !1) break
   } else if (u) {
    for (; o > i; i++)
     if (r = t.call(e[i], i, e[i]), r === !1) break
   } else
    for (i in e)
     if (r = t.call(e[i], i, e[i]), r === !1) break;
   return e
  },
  trim: function(e) {
   return null == e ? "" : (e + "").replace(o, "")
  },
  makeArray: function(e, t) {
   var r = t || [];
   return null != e && (s(Object(e)) ? n.merge(r, "string" == typeof e ? [e] : e) : f.call(r, e)), r
  },
  inArray: function(e, t, n) {
   return null == t ? -1 : g.call(t, e, n)
  },
  merge: function(e, t) {
   for (var n = +t.length, r = 0, i = e.length; n > r; r++) e[i++] = t[r];
   return e.length = i, e
  },
  grep: function(e, t, n) {
   for (var r, i = [], s = 0, o = e.length, u = !n; o > s; s++) r = !t(e[s], s), r !== u && i.push(e[s]);
   return i
  },
  map: function(t, n, r) {
   var i, o = 0,
    u = t.length,
    a = s(t),
    f = [];
   if (a)
    for (; u > o; o++) i = n(t[o], o, r), null != i && f.push(i);
   else
    for (o in t) i = n(t[o], o, r), null != i && f.push(i);
   return e.apply([], f)
  },
  guid: 1,
  proxy: function(e, t) {
   var r, i, s;
   return "string" == typeof t && (r = e[t], t = e, e = r), n.isFunction(e) ? (i = d.call(arguments, 2), s = function() {
    return e.apply(t || this, i.concat(d.call(arguments)))
   }, s.guid = e.guid = e.guid || n.guid++, s) : void 0
  },
  now: Date.now,
  support: k
 }), n.each("Boolean Number String Function Array Date RegExp Object Error".split(" "), function(e, t) {
  h["[object " + t + "]"] = t.toLowerCase()
 });
 var t = function(e) {
  function ot(e, t, r, i) {
   var s, u, f, l, c, d, g, y, S, x;
   if ((t ? t.ownerDocument || t : E) !== p && h(t), t = t || p, r = r || [], l = t.nodeType, "string" != typeof e || !e || 1 !== l && 9 !== l && 11 !== l) return r;
   if (!i && v) {
    if (11 !== l && (s = Z.exec(e)))
     if (f = s[1]) {
      if (9 === l) {
       if (u = t.getElementById(f), !u || !u.parentNode) return r;
       if (u.id === f) return r.push(u), r
      } else if (t.ownerDocument && (u = t.ownerDocument.getElementById(f)) && b(t, u) && u.id === f) return r.push(u), r
     } else {
      if (s[2]) return D.apply(r, t.getElementsByTagName(e)), r;
      if ((f = s[3]) && n.getElementsByClassName) return D.apply(r, t.getElementsByClassName(f)), r
     } if (n.qsa && (!m || !m.test(e))) {
     if (y = g = w, S = t, x = 1 !== l && e, 1 === l && "object" !== t.nodeName.toLowerCase()) {
      d = o(e), (g = t.getAttribute("id")) ? y = g.replace(tt, "\\$&") : t.setAttribute("id", y), y = "[id='" + y + "'] ", c = d.length;
      while (c--) d[c] = y + gt(d[c]);
      S = et.test(e) && vt(t.parentNode) || t, x = d.join(",")
     }
     if (x) try {
      return D.apply(r, S.querySelectorAll(x)), r
     } catch (T) {} finally {
      g || t.removeAttribute("id")
     }
    }
   }
   return a(e.replace(z, "$1"), t, r, i)
  }

  function ut() {
   function t(n, i) {
    return e.push(n + " ") > r.cacheLength && delete t[e.shift()], t[n + " "] = i
   }
   var e = [];
   return t
  }

  function at(e) {
   return e[w] = !0, e
  }

  function ft(e) {
   var t = p.createElement("div");
   try {
    return !!e(t)
   } catch (n) {
    return !1
   } finally {
    t.parentNode && t.parentNode.removeChild(t), t = null
   }
  }

  function lt(e, t) {
   var n = e.split("|"),
    i = e.length;
   while (i--) r.attrHandle[n[i]] = t
  }

  function ct(e, t) {
   var n = t && e,
    r = n && 1 === e.nodeType && 1 === t.nodeType && (~t.sourceIndex || L) - (~e.sourceIndex || L);
   if (r) return r;
   if (n)
    while (n = n.nextSibling)
     if (n === t) return -1;
   return e ? 1 : -1
  }

  function ht(e) {
   return function(t) {
    var n = t.nodeName.toLowerCase();
    return "input" === n && t.type === e
   }
  }

  function pt(e) {
   return function(t) {
    var n = t.nodeName.toLowerCase();
    return ("input" === n || "button" === n) && t.type === e
   }
  }

  function dt(e) {
   return at(function(t) {
    return t = +t, at(function(n, r) {
     var i, s = e([], n.length, t),
      o = s.length;
     while (o--) n[i = s[o]] && (n[i] = !(r[i] = n[i]))
    })
   })
  }

  function vt(e) {
   return e && "undefined" != typeof e.getElementsByTagName && e
  }

  function mt() {}

  function gt(e) {
   for (var t = 0, n = e.length, r = ""; n > t; t++) r += e[t].value;
   return r
  }

  function yt(e, t, n) {
   var r = t.dir,
    i = n && "parentNode" === r,
    s = x++;
   return t.first ? function(t, n, s) {
    while (t = t[r])
     if (1 === t.nodeType || i) return e(t, n, s)
   } : function(t, n, o) {
    var u, a, f = [S, s];
    if (o) {
     while (t = t[r])
      if ((1 === t.nodeType || i) && e(t, n, o)) return !0
    } else
     while (t = t[r])
      if (1 === t.nodeType || i) {
       if (a = t[w] || (t[w] = {}), (u = a[r]) && u[0] === S && u[1] === s) return f[2] = u[2];
       if (a[r] = f, f[2] = e(t, n, o)) return !0
      }
   }
  }

  function bt(e) {
   return e.length > 1 ? function(t, n, r) {
    var i = e.length;
    while (i--)
     if (!e[i](t, n, r)) return !1;
    return !0
   } : e[0]
  }

  function wt(e, t, n) {
   for (var r = 0, i = t.length; i > r; r++) ot(e, t[r], n);
   return n
  }

  function Et(e, t, n, r, i) {
   for (var s, o = [], u = 0, a = e.length, f = null != t; a > u; u++)(s = e[u]) && (!n || n(s, r, i)) && (o.push(s), f && t.push(u));
   return o
  }

  function St(e, t, n, r, i, s) {
   return r && !r[w] && (r = St(r)), i && !i[w] && (i = St(i, s)), at(function(s, o, u, a) {
    var f, l, c, h = [],
     p = [],
     d = o.length,
     v = s || wt(t || "*", u.nodeType ? [u] : u, []),
     m = !e || !s && t ? v : Et(v, h, e, u, a),
     g = n ? i || (s ? e : d || r) ? [] : o : m;
    if (n && n(m, g, u, a), r) {
     f = Et(g, p), r(f, [], u, a), l = f.length;
     while (l--)(c = f[l]) && (g[p[l]] = !(m[p[l]] = c))
    }
    if (s) {
     if (i || e) {
      if (i) {
       f = [], l = g.length;
       while (l--)(c = g[l]) && f.push(m[l] = c);
       i(null, g = [], f, a)
      }
      l = g.length;
      while (l--)(c = g[l]) && (f = i ? H(s, c) : h[l]) > -1 && (s[f] = !(o[f] = c))
     }
    } else g = Et(g === o ? g.splice(d, g.length) : g), i ? i(null, o, g, a) : D.apply(o, g)
   })
  }

  function xt(e) {
   for (var t, n, i, s = e.length, o = r.relative[e[0].type], u = o || r.relative[" "], a = o ? 1 : 0, l = yt(function(e) {
     return e === t
    }, u, !0), c = yt(function(e) {
     return H(t, e) > -1
    }, u, !0), h = [function(e, n, r) {
     var i = !o && (r || n !== f) || ((t = n).nodeType ? l(e, n, r) : c(e, n, r));
     return t = null, i
    }]; s > a; a++)
    if (n = r.relative[e[a].type]) h = [yt(bt(h), n)];
    else {
     if (n = r.filter[e[a].type].apply(null, e[a].matches), n[w]) {
      for (i = ++a; s > i; i++)
       if (r.relative[e[i].type]) break;
      return St(a > 1 && bt(h), a > 1 && gt(e.slice(0, a - 1).concat({
       value: " " === e[a - 2].type ? "*" : ""
      })).replace(z, "$1"), n, i > a && xt(e.slice(a, i)), s > i && xt(e = e.slice(i)), s > i && gt(e))
     }
     h.push(n)
    } return bt(h)
  }

  function Tt(e, t) {
   var n = t.length > 0,
    i = e.length > 0,
    s = function(s, o, u, a, l) {
     var c, h, d, v = 0,
      m = "0",
      g = s && [],
      y = [],
      b = f,
      w = s || i && r.find.TAG("*", l),
      E = S += null == b ? 1 : Math.random() || .1,
      x = w.length;
     for (l && (f = o !== p && o); m !== x && null != (c = w[m]); m++) {
      if (i && c) {
       h = 0;
       while (d = e[h++])
        if (d(c, o, u)) {
         a.push(c);
         break
        } l && (S = E)
      }
      n && ((c = !d && c) && v--, s && g.push(c))
     }
     if (v += m, n && m !== v) {
      h = 0;
      while (d = t[h++]) d(g, y, o, u);
      if (s) {
       if (v > 0)
        while (m--) g[m] || y[m] || (y[m] = M.call(a));
       y = Et(y)
      }
      D.apply(a, y), l && !s && y.length > 0 && v + t.length > 1 && ot.uniqueSort(a)
     }
     return l && (S = E, f = b), g
    };
   return n ? at(s) : s
  }
  var t, n, r, i, s, o, u, a, f, l, c, h, p, d, v, m, g, y, b, w = "sizzle" + 1 * new Date,
   E = e.document,
   S = 0,
   x = 0,
   T = ut(),
   N = ut(),
   C = ut(),
   k = function(e, t) {
    return e === t && (c = !0), 0
   },
   L = 1 << 31,
   A = {}.hasOwnProperty,
   O = [],
   M = O.pop,
   _ = O.push,
   D = O.push,
   P = O.slice,
   H = function(e, t) {
    for (var n = 0, r = e.length; r > n; n++)
     if (e[n] === t) return n;
    return -1
   },
   B = "checked|selected|async|autofocus|autoplay|controls|defer|disabled|hidden|ismap|loop|multiple|open|readonly|required|scoped",
   j = "[\\x20\\t\\r\\n\\f]",
   F = "(?:\\\\.|[\\w-]|[^\\x00-\\xa0])+",
   I = F.replace("w", "w#"),
   q = "\\[" + j + "*(" + F + ")(?:" + j + "*([*^$|!~]?=)" + j + "*(?:'((?:\\\\.|[^\\\\'])*)'|\"((?:\\\\.|[^\\\\\"])*)\"|(" + I + "))|)" + j + "*\\]",
   R = ":(" + F + ")(?:\\((('((?:\\\\.|[^\\\\'])*)'|\"((?:\\\\.|[^\\\\\"])*)\")|((?:\\\\.|[^\\\\()[\\]]|" + q + ")*)|.*)\\)|)",
   U = new RegExp(j + "+", "g"),
   z = new RegExp("^" + j + "+|((?:^|[^\\\\])(?:\\\\.)*)" + j + "+$", "g"),
   W = new RegExp("^" + j + "*," + j + "*"),
   X = new RegExp("^" + j + "*([>+~]|" + j + ")" + j + "*"),
   V = new RegExp("=" + j + "*([^\\]'\"]*?)" + j + "*\\]", "g"),
   $ = new RegExp(R),
   J = new RegExp("^" + I + "$"),
   K = {
    ID: new RegExp("^#(" + F + ")"),
    CLASS: new RegExp("^\\.(" + F + ")"),
    TAG: new RegExp("^(" + F.replace("w", "w*") + ")"),
    ATTR: new RegExp("^" + q),
    PSEUDO: new RegExp("^" + R),
    CHILD: new RegExp("^:(only|first|last|nth|nth-last)-(child|of-type)(?:\\(" + j + "*(even|odd|(([+-]|)(\\d*)n|)" + j + "*(?:([+-]|)" + j + "*(\\d+)|))" + j + "*\\)|)", "i"),
    bool: new RegExp("^(?:" + B + ")$", "i"),
    needsContext: new RegExp("^" + j + "*[>+~]|:(even|odd|eq|gt|lt|nth|first|last)(?:\\(" + j + "*((?:-\\d)?\\d*)" + j + "*\\)|)(?=[^-]|$)", "i")
   },
   Q = /^(?:input|select|textarea|button)$/i,
   G = /^h\d$/i,
   Y = /^[^{]+\{\s*\[native \w/,
   Z = /^(?:#([\w-]+)|(\w+)|\.([\w-]+))$/,
   et = /[+~]/,
   tt = /'|\\/g,
   nt = new RegExp("\\\\([\\da-f]{1,6}" + j + "?|(" + j + ")|.)", "ig"),
   rt = function(e, t, n) {
    var r = "0x" + t - 65536;
    return r !== r || n ? t : 0 > r ? String.fromCharCode(r + 65536) : String.fromCharCode(r >> 10 | 55296, 1023 & r | 56320)
   },
   it = function() {
    h()
   };
  try {
   D.apply(O = P.call(E.childNodes), E.childNodes), O[E.childNodes.length].nodeType
  } catch (st) {
   D = {
    apply: O.length ? function(e, t) {
     _.apply(e, P.call(t))
    } : function(e, t) {
     var n = e.length,
      r = 0;
     while (e[n++] = t[r++]);
     e.length = n - 1
    }
   }
  }
  n = ot.support = {}, s = ot.isXML = function(e) {
   var t = e && (e.ownerDocument || e).documentElement;
   return t ? "HTML" !== t.nodeName : !1
  }, h = ot.setDocument = function(e) {
   var t, i, o = e ? e.ownerDocument || e : E;
   return o !== p && 9 === o.nodeType && o.documentElement ? (p = o, d = o.documentElement, i = o.defaultView, i && i !== i.top && (i.addEventListener ? i.addEventListener("unload", it, !1) : i.attachEvent && i.attachEvent("onunload", it)), v = !s(o), n.attributes = ft(function(e) {
    return e.className = "i", !e.getAttribute("className")
   }), n.getElementsByTagName = ft(function(e) {
    return e.appendChild(o.createComment("")), !e.getElementsByTagName("*").length
   }), n.getElementsByClassName = Y.test(o.getElementsByClassName), n.getById = ft(function(e) {
    return d.appendChild(e).id = w, !o.getElementsByName || !o.getElementsByName(w).length
   }), n.getById ? (r.find.ID = function(e, t) {
    if ("undefined" != typeof t.getElementById && v) {
     var n = t.getElementById(e);
     return n && n.parentNode ? [n] : []
    }
   }, r.filter.ID = function(e) {
    var t = e.replace(nt, rt);
    return function(e) {
     return e.getAttribute("id") === t
    }
   }) : (delete r.find.ID, r.filter.ID = function(e) {
    var t = e.replace(nt, rt);
    return function(e) {
     var n = "undefined" != typeof e.getAttributeNode && e.getAttributeNode("id");
     return n && n.value === t
    }
   }), r.find.TAG = n.getElementsByTagName ? function(e, t) {
    return "undefined" != typeof t.getElementsByTagName ? t.getElementsByTagName(e) : n.qsa ? t.querySelectorAll(e) : void 0
   } : function(e, t) {
    var n, r = [],
     i = 0,
     s = t.getElementsByTagName(e);
    if ("*" === e) {
     while (n = s[i++]) 1 === n.nodeType && r.push(n);
     return r
    }
    return s
   }, r.find.CLASS = n.getElementsByClassName && function(e, t) {
    return v ? t.getElementsByClassName(e) : void 0
   }, g = [], m = [], (n.qsa = Y.test(o.querySelectorAll)) && (ft(function(e) {
    d.appendChild(e).innerHTML = "<a id='" + w + "'></a><select id='" + w + "-\f]' msallowcapture=''><option selected=''></option></select>", e.querySelectorAll("[msallowcapture^='']").length && m.push("[*^$]=" + j + "*(?:''|\"\")"), e.querySelectorAll("[selected]").length || m.push("\\[" + j + "*(?:value|" + B + ")"), e.querySelectorAll("[id~=" + w + "-]").length || m.push("~="), e.querySelectorAll(":checked").length || m.push(":checked"), e.querySelectorAll("a#" + w + "+*").length || m.push(".#.+[+~]")
   }), ft(function(e) {
    var t = o.createElement("input");
    t.setAttribute("type", "hidden"), e.appendChild(t).setAttribute("name", "D"), e.querySelectorAll("[name=d]").length && m.push("name" + j + "*[*^$|!~]?="), e.querySelectorAll(":enabled").length || m.push(":enabled", ":disabled"), e.querySelectorAll("*,:x"), m.push(",.*:")
   })), (n.matchesSelector = Y.test(y = d.matches || d.webkitMatchesSelector || d.mozMatchesSelector || d.oMatchesSelector || d.msMatchesSelector)) && ft(function(e) {
    n.disconnectedMatch = y.call(e, "div"), y.call(e, "[s!='']:x"), g.push("!=", R)
   }), m = m.length && new RegExp(m.join("|")), g = g.length && new RegExp(g.join("|")), t = Y.test(d.compareDocumentPosition), b = t || Y.test(d.contains) ? function(e, t) {
    var n = 9 === e.nodeType ? e.documentElement : e,
     r = t && t.parentNode;
    return e === r || !!r && 1 === r.nodeType && !!(n.contains ? n.contains(r) : e.compareDocumentPosition && 16 & e.compareDocumentPosition(r))
   } : function(e, t) {
    if (t)
     while (t = t.parentNode)
      if (t === e) return !0;
    return !1
   }, k = t ? function(e, t) {
    if (e === t) return c = !0, 0;
    var r = !e.compareDocumentPosition - !t.compareDocumentPosition;
    return r ? r : (r = (e.ownerDocument || e) === (t.ownerDocument || t) ? e.compareDocumentPosition(t) : 1, 1 & r || !n.sortDetached && t.compareDocumentPosition(e) === r ? e === o || e.ownerDocument === E && b(E, e) ? -1 : t === o || t.ownerDocument === E && b(E, t) ? 1 : l ? H(l, e) - H(l, t) : 0 : 4 & r ? -1 : 1)
   } : function(e, t) {
    if (e === t) return c = !0, 0;
    var n, r = 0,
     i = e.parentNode,
     s = t.parentNode,
     u = [e],
     a = [t];
    if (!i || !s) return e === o ? -1 : t === o ? 1 : i ? -1 : s ? 1 : l ? H(l, e) - H(l, t) : 0;
    if (i === s) return ct(e, t);
    n = e;
    while (n = n.parentNode) u.unshift(n);
    n = t;
    while (n = n.parentNode) a.unshift(n);
    while (u[r] === a[r]) r++;
    return r ? ct(u[r], a[r]) : u[r] === E ? -1 : a[r] === E ? 1 : 0
   }, o) : p
  }, ot.matches = function(e, t) {
   return ot(e, null, null, t)
  }, ot.matchesSelector = function(e, t) {
   if ((e.ownerDocument || e) !== p && h(e), t = t.replace(V, "='$1']"), !(!n.matchesSelector || !v || g && g.test(t) || m && m.test(t))) try {
    var r = y.call(e, t);
    if (r || n.disconnectedMatch || e.document && 11 !== e.document.nodeType) return r
   } catch (i) {}
   return ot(t, p, null, [e]).length > 0
  }, ot.contains = function(e, t) {
   return (e.ownerDocument || e) !== p && h(e), b(e, t)
  }, ot.attr = function(e, t) {
   (e.ownerDocument || e) !== p && h(e);
   var i = r.attrHandle[t.toLowerCase()],
    s = i && A.call(r.attrHandle, t.toLowerCase()) ? i(e, t, !v) : void 0;
   return void 0 !== s ? s : n.attributes || !v ? e.getAttribute(t) : (s = e.getAttributeNode(t)) && s.specified ? s.value : null
  }, ot.error = function(e) {
   throw new Error("Syntax error, unrecognized expression: " + e)
  }, ot.uniqueSort = function(e) {
   var t, r = [],
    i = 0,
    s = 0;
   if (c = !n.detectDuplicates, l = !n.sortStable && e.slice(0), e.sort(k), c) {
    while (t = e[s++]) t === e[s] && (i = r.push(s));
    while (i--) e.splice(r[i], 1)
   }
   return l = null, e
  }, i = ot.getText = function(e) {
   var t, n = "",
    r = 0,
    s = e.nodeType;
   if (s) {
    if (1 === s || 9 === s || 11 === s) {
     if ("string" == typeof e.textContent) return e.textContent;
     for (e = e.firstChild; e; e = e.nextSibling) n += i(e)
    } else if (3 === s || 4 === s) return e.nodeValue
   } else
    while (t = e[r++]) n += i(t);
   return n
  }, r = ot.selectors = {
   cacheLength: 50,
   createPseudo: at,
   match: K,
   attrHandle: {},
   find: {},
   relative: {
    ">": {
     dir: "parentNode",
     first: !0
    },
    " ": {
     dir: "parentNode"
    },
    "+": {
     dir: "previousSibling",
     first: !0
    },
    "~": {
     dir: "previousSibling"
    }
   },
   preFilter: {
    ATTR: function(e) {
     return e[1] = e[1].replace(nt, rt), e[3] = (e[3] || e[4] || e[5] || "").replace(nt, rt), "~=" === e[2] && (e[3] = " " + e[3] + " "), e.slice(0, 4)
    },
    CHILD: function(e) {
     return e[1] = e[1].toLowerCase(), "nth" === e[1].slice(0, 3) ? (e[3] || ot.error(e[0]), e[4] = +(e[4] ? e[5] + (e[6] || 1) : 2 * ("even" === e[3] || "odd" === e[3])), e[5] = +(e[7] + e[8] || "odd" === e[3])) : e[3] && ot.error(e[0]), e
    },
    PSEUDO: function(e) {
     var t, n = !e[6] && e[2];
     return K.CHILD.test(e[0]) ? null : (e[3] ? e[2] = e[4] || e[5] || "" : n && $.test(n) && (t = o(n, !0)) && (t = n.indexOf(")", n.length - t) - n.length) && (e[0] = e[0].slice(0, t), e[2] = n.slice(0, t)), e.slice(0, 3))
    }
   },
   filter: {
    TAG: function(e) {
     var t = e.replace(nt, rt).toLowerCase();
     return "*" === e ? function() {
      return !0
     } : function(e) {
      return e.nodeName && e.nodeName.toLowerCase() === t
     }
    },
    CLASS: function(e) {
     var t = T[e + " "];
     return t || (t = new RegExp("(^|" + j + ")" + e + "(" + j + "|$)")) && T(e, function(e) {
      return t.test("string" == typeof e.className && e.className || "undefined" != typeof e.getAttribute && e.getAttribute("class") || "")
     })
    },
    ATTR: function(e, t, n) {
     return function(r) {
      var i = ot.attr(r, e);
      return null == i ? "!=" === t : t ? (i += "", "=" === t ? i === n : "!=" === t ? i !== n : "^=" === t ? n && 0 === i.indexOf(n) : "*=" === t ? n && i.indexOf(n) > -1 : "$=" === t ? n && i.slice(-n.length) === n : "~=" === t ? (" " + i.replace(U, " ") + " ").indexOf(n) > -1 : "|=" === t ? i === n || i.slice(0, n.length + 1) === n + "-" : !1) : !0
     }
    },
    CHILD: function(e, t, n, r, i) {
     var s = "nth" !== e.slice(0, 3),
      o = "last" !== e.slice(-4),
      u = "of-type" === t;
     return 1 === r && 0 === i ? function(e) {
      return !!e.parentNode
     } : function(t, n, a) {
      var f, l, c, h, p, d, v = s !== o ? "nextSibling" : "previousSibling",
       m = t.parentNode,
       g = u && t.nodeName.toLowerCase(),
       y = !a && !u;
      if (m) {
       if (s) {
        while (v) {
         c = t;
         while (c = c[v])
          if (u ? c.nodeName.toLowerCase() === g : 1 === c.nodeType) return !1;
         d = v = "only" === e && !d && "nextSibling"
        }
        return !0
       }
       if (d = [o ? m.firstChild : m.lastChild], o && y) {
        l = m[w] || (m[w] = {}), f = l[e] || [], p = f[0] === S && f[1], h = f[0] === S && f[2], c = p && m.childNodes[p];
        while (c = ++p && c && c[v] || (h = p = 0) || d.pop())
         if (1 === c.nodeType && ++h && c === t) {
          l[e] = [S, p, h];
          break
         }
       } else if (y && (f = (t[w] || (t[w] = {}))[e]) && f[0] === S) h = f[1];
       else
        while (c = ++p && c && c[v] || (h = p = 0) || d.pop())
         if ((u ? c.nodeName.toLowerCase() === g : 1 === c.nodeType) && ++h && (y && ((c[w] || (c[w] = {}))[e] = [S, h]), c === t)) break;
       return h -= i, h === r || h % r === 0 && h / r >= 0
      }
     }
    },
    PSEUDO: function(e, t) {
     var n, i = r.pseudos[e] || r.setFilters[e.toLowerCase()] || ot.error("unsupported pseudo: " + e);
     return i[w] ? i(t) : i.length > 1 ? (n = [e, e, "", t], r.setFilters.hasOwnProperty(e.toLowerCase()) ? at(function(e, n) {
      var r, s = i(e, t),
       o = s.length;
      while (o--) r = H(e, s[o]), e[r] = !(n[r] = s[o])
     }) : function(e) {
      return i(e, 0, n)
     }) : i
    }
   },
   pseudos: {
    not: at(function(e) {
     var t = [],
      n = [],
      r = u(e.replace(z, "$1"));
     return r[w] ? at(function(e, t, n, i) {
      var s, o = r(e, null, i, []),
       u = e.length;
      while (u--)(s = o[u]) && (e[u] = !(t[u] = s))
     }) : function(e, i, s) {
      return t[0] = e, r(t, null, s, n), t[0] = null, !n.pop()
     }
    }),
    has: at(function(e) {
     return function(t) {
      return ot(e, t).length > 0
     }
    }),
    contains: at(function(e) {
     return e = e.replace(nt, rt),
      function(t) {
       return (t.textContent || t.innerText || i(t)).indexOf(e) > -1
      }
    }),
    lang: at(function(e) {
     return J.test(e || "") || ot.error("unsupported lang: " + e), e = e.replace(nt, rt).toLowerCase(),
      function(t) {
       var n;
       do
        if (n = v ? t.lang : t.getAttribute("xml:lang") || t.getAttribute("lang")) return n = n.toLowerCase(), n === e || 0 === n.indexOf(e + "-"); while ((t = t.parentNode) && 1 === t.nodeType);
       return !1
      }
    }),
    target: function(t) {
     var n = e.location && e.location.hash;
     return n && n.slice(1) === t.id
    },
    root: function(e) {
     return e === d
    },
    focus: function(e) {
     return e === p.activeElement && (!p.hasFocus || p.hasFocus()) && !!(e.type || e.href || ~e.tabIndex)
    },
    enabled: function(e) {
     return e.disabled === !1
    },
    disabled: function(e) {
     return e.disabled === !0
    },
    checked: function(e) {
     var t = e.nodeName.toLowerCase();
     return "input" === t && !!e.checked || "option" === t && !!e.selected
    },
    selected: function(e) {
     return e.parentNode && e.parentNode.selectedIndex, e.selected === !0
    },
    empty: function(e) {
     for (e = e.firstChild; e; e = e.nextSibling)
      if (e.nodeType < 6) return !1;
     return !0
    },
    parent: function(e) {
     return !r.pseudos.empty(e)
    },
    header: function(e) {
     return G.test(e.nodeName)
    },
    input: function(e) {
     return Q.test(e.nodeName)
    },
    button: function(e) {
     var t = e.nodeName.toLowerCase();
     return "input" === t && "button" === e.type || "button" === t
    },
    text: function(e) {
     var t;
     return "input" === e.nodeName.toLowerCase() && "text" === e.type && (null == (t = e.getAttribute("type")) || "text" === t.toLowerCase())
    },
    first: dt(function() {
     return [0]
    }),
    last: dt(function(e, t) {
     return [t - 1]
    }),
    eq: dt(function(e, t, n) {
     return [0 > n ? n + t : n]
    }),
    even: dt(function(e, t) {
     for (var n = 0; t > n; n += 2) e.push(n);
     return e
    }),
    odd: dt(function(e, t) {
     for (var n = 1; t > n; n += 2) e.push(n);
     return e
    }),
    lt: dt(function(e, t, n) {
     for (var r = 0 > n ? n + t : n; --r >= 0;) e.push(r);
     return e
    }),
    gt: dt(function(e, t, n) {
     for (var r = 0 > n ? n + t : n; ++r < t;) e.push(r);
     return e
    })
   }
  }, r.pseudos.nth = r.pseudos.eq;
  for (t in {
    radio: !0,
    checkbox: !0,
    file: !0,
    password: !0,
    image: !0
   }) r.pseudos[t] = ht(t);
  for (t in {
    submit: !0,
    reset: !0
   }) r.pseudos[t] = pt(t);
  return mt.prototype = r.filters = r.pseudos, r.setFilters = new mt, o = ot.tokenize = function(e, t) {
   var n, i, s, o, u, a, f, l = N[e + " "];
   if (l) return t ? 0 : l.slice(0);
   u = e, a = [], f = r.preFilter;
   while (u) {
    (!n || (i = W.exec(u))) && (i && (u = u.slice(i[0].length) || u), a.push(s = [])), n = !1, (i = X.exec(u)) && (n = i.shift(), s.push({
     value: n,
     type: i[0].replace(z, " ")
    }), u = u.slice(n.length));
    for (o in r.filter) !(i = K[o].exec(u)) || f[o] && !(i = f[o](i)) || (n = i.shift(), s.push({
     value: n,
     type: o,
     matches: i
    }), u = u.slice(n.length));
    if (!n) break
   }
   return t ? u.length : u ? ot.error(e) : N(e, a).slice(0)
  }, u = ot.compile = function(e, t) {
   var n, r = [],
    i = [],
    s = C[e + " "];
   if (!s) {
    t || (t = o(e)), n = t.length;
    while (n--) s = xt(t[n]), s[w] ? r.push(s) : i.push(s);
    s = C(e, Tt(i, r)), s.selector = e
   }
   return s
  }, a = ot.select = function(e, t, i, s) {
   var a, f, l, c, h, p = "function" == typeof e && e,
    d = !s && o(e = p.selector || e);
   if (i = i || [], 1 === d.length) {
    if (f = d[0] = d[0].slice(0), f.length > 2 && "ID" === (l = f[0]).type && n.getById && 9 === t.nodeType && v && r.relative[f[1].type]) {
     if (t = (r.find.ID(l.matches[0].replace(nt, rt), t) || [])[0], !t) return i;
     p && (t = t.parentNode), e = e.slice(f.shift().value.length)
    }
    a = K.needsContext.test(e) ? 0 : f.length;
    while (a--) {
     if (l = f[a], r.relative[c = l.type]) break;
     if ((h = r.find[c]) && (s = h(l.matches[0].replace(nt, rt), et.test(f[0].type) && vt(t.parentNode) || t))) {
      if (f.splice(a, 1), e = s.length && gt(f), !e) return D.apply(i, s), i;
      break
     }
    }
   }
   return (p || u(e, d))(s, t, !v, i, et.test(e) && vt(t.parentNode) || t), i
  }, n.sortStable = w.split("").sort(k).join("") === w, n.detectDuplicates = !!c, h(), n.sortDetached = ft(function(e) {
   return 1 & e.compareDocumentPosition(p.createElement("div"))
  }), ft(function(e) {
   return e.innerHTML = "<a href='#'></a>", "#" === e.firstChild.getAttribute("href")
  }) || lt("type|href|height|width", function(e, t, n) {
   return n ? void 0 : e.getAttribute(t, "type" === t.toLowerCase() ? 1 : 2)
  }), n.attributes && ft(function(e) {
   return e.innerHTML = "<input/>", e.firstChild.setAttribute("value", ""), "" === e.firstChild.getAttribute("value")
  }) || lt("value", function(e, t, n) {
   return n || "input" !== e.nodeName.toLowerCase() ? void 0 : e.defaultValue
  }), ft(function(e) {
   return null == e.getAttribute("disabled")
  }) || lt(B, function(e, t, n) {
   var r;
   return n ? void 0 : e[t] === !0 ? t.toLowerCase() : (r = e.getAttributeNode(t)) && r.specified ? r.value : null
  }), ot
 }(a);
 n.find = t, n.expr = t.selectors, n.expr[":"] = n.expr.pseudos, n.unique = t.uniqueSort, n.text = t.getText, n.isXMLDoc = t.isXML, n.contains = t.contains;
 var u = n.expr.match.needsContext,
  v = /^<(\w+)\s*\/?>(?:<\/\1>|)$/,
  w = /^.[^:#\[\.,]*$/;
 n.filter = function(e, t, r) {
  var i = t[0];
  return r && (e = ":not(" + e + ")"), 1 === t.length && 1 === i.nodeType ? n.find.matchesSelector(i, e) ? [i] : [] : n.find.matches(e, n.grep(t, function(e) {
   return 1 === e.nodeType
  }))
 }, n.fn.extend({
  find: function(e) {
   var t, r = this.length,
    i = [],
    s = this;
   if ("string" != typeof e) return this.pushStack(n(e).filter(function() {
    for (t = 0; r > t; t++)
     if (n.contains(s[t], this)) return !0
   }));
   for (t = 0; r > t; t++) n.find(e, s[t], i);
   return i = this.pushStack(r > 1 ? n.unique(i) : i), i.selector = this.selector ? this.selector + " " + e : e, i
  },
  filter: function(e) {
   return this.pushStack(x(this, e || [], !1))
  },
  not: function(e) {
   return this.pushStack(x(this, e || [], !0))
  },
  is: function(e) {
   return !!x(this, "string" == typeof e && u.test(e) ? n(e) : e || [], !1).length
  }
 });
 var y, z = /^(?:\s*(<[\w\W]+>)[^>]*|#([\w-]*))$/,
  A = n.fn.init = function(e, t) {
   var r, i;
   if (!e) return this;
   if ("string" == typeof e) {
    if (r = "<" === e[0] && ">" === e[e.length - 1] && e.length >= 3 ? [null, e, null] : z.exec(e), !r || !r[1] && t) return !t || t.jquery ? (t || y).find(e) : this.constructor(t).find(e);
    if (r[1]) {
     if (t = t instanceof n ? t[0] : t, n.merge(this, n.parseHTML(r[1], t && t.nodeType ? t.ownerDocument || t : l, !0)), v.test(r[1]) && n.isPlainObject(t))
      for (r in t) n.isFunction(this[r]) ? this[r](t[r]) : this.attr(r, t[r]);
     return this
    }
    return i = l.getElementById(r[2]), i && i.parentNode && (this.length = 1, this[0] = i), this.context = l, this.selector = e, this
   }
   return e.nodeType ? (this.context = this[0] = e, this.length = 1, this) : n.isFunction(e) ? "undefined" != typeof y.ready ? y.ready(e) : e(n) : (void 0 !== e.selector && (this.selector = e.selector, this.context = e.context), n.makeArray(e, this))
  };
 A.prototype = n.fn, y = n(l);
 var B = /^(?:parents|prev(?:Until|All))/,
  C = {
   children: !0,
   contents: !0,
   next: !0,
   prev: !0
  };
 n.extend({
  dir: function(e, t, r) {
   var i = [],
    s = void 0 !== r;
   while ((e = e[t]) && 9 !== e.nodeType)
    if (1 === e.nodeType) {
     if (s && n(e).is(r)) break;
     i.push(e)
    } return i
  },
  sibling: function(e, t) {
   for (var n = []; e; e = e.nextSibling) 1 === e.nodeType && e !== t && n.push(e);
   return n
  }
 }), n.fn.extend({
  has: function(e) {
   var t = n(e, this),
    r = t.length;
   return this.filter(function() {
    for (var e = 0; r > e; e++)
     if (n.contains(this, t[e])) return !0
   })
  },
  closest: function(e, t) {
   for (var r, i = 0, s = this.length, o = [], a = u.test(e) || "string" != typeof e ? n(e, t || this.context) : 0; s > i; i++)
    for (r = this[i]; r && r !== t; r = r.parentNode)
     if (r.nodeType < 11 && (a ? a.index(r) > -1 : 1 === r.nodeType && n.find.matchesSelector(r, e))) {
      o.push(r);
      break
     } return this.pushStack(o.length > 1 ? n.unique(o) : o)
  },
  index: function(e) {
   return e ? "string" == typeof e ? g.call(n(e), this[0]) : g.call(this, e.jquery ? e[0] : e) : this[0] && this[0].parentNode ? this.first().prevAll().length : -1
  },
  add: function(e, t) {
   return this.pushStack(n.unique(n.merge(this.get(), n(e, t))))
  },
  addBack: function(e) {
   return this.add(null == e ? this.prevObject : this.prevObject.filter(e))
  }
 }), n.each({
  parent: function(e) {
   var t = e.parentNode;
   return t && 11 !== t.nodeType ? t : null
  },
  parents: function(e) {
   return n.dir(e, "parentNode")
  },
  parentsUntil: function(e, t, r) {
   return n.dir(e, "parentNode", r)
  },
  next: function(e) {
   return D(e, "nextSibling")
  },
  prev: function(e) {
   return D(e, "previousSibling")
  },
  nextAll: function(e) {
   return n.dir(e, "nextSibling")
  },
  prevAll: function(e) {
   return n.dir(e, "previousSibling")
  },
  nextUntil: function(e, t, r) {
   return n.dir(e, "nextSibling", r)
  },
  prevUntil: function(e, t, r) {
   return n.dir(e, "previousSibling", r)
  },
  siblings: function(e) {
   return n.sibling((e.parentNode || {}).firstChild, e)
  },
  children: function(e) {
   return n.sibling(e.firstChild)
  },
  contents: function(e) {
   return e.contentDocument || n.merge([], e.childNodes)
  }
 }, function(e, t) {
  n.fn[e] = function(r, i) {
   var s = n.map(this, t, r);
   return "Until" !== e.slice(-5) && (i = r), i && "string" == typeof i && (s = n.filter(i, s)), this.length > 1 && (C[e] || n.unique(s), B.test(e) && s.reverse()), this.pushStack(s)
  }
 });
 var E = /\S+/g,
  F = {};
 n.Callbacks = function(e) {
  e = "string" == typeof e ? F[e] || G(e) : n.extend({}, e);
  var t, r, i, s, o, u, a = [],
   f = !e.once && [],
   l = function(n) {
    for (t = e.memory && n, r = !0, u = s || 0, s = 0, o = a.length, i = !0; a && o > u; u++)
     if (a[u].apply(n[0], n[1]) === !1 && e.stopOnFalse) {
      t = !1;
      break
     } i = !1, a && (f ? f.length && l(f.shift()) : t ? a = [] : c.disable())
   },
   c = {
    add: function() {
     if (a) {
      var r = a.length;
      ! function u(t) {
       n.each(t, function(t, r) {
        var i = n.type(r);
        "function" === i ? e.unique && c.has(r) || a.push(r) : r && r.length && "string" !== i && u(r)
       })
      }(arguments), i ? o = a.length : t && (s = r, l(t))
     }
     return this
    },
    remove: function() {
     return a && n.each(arguments, function(e, t) {
      var r;
      while ((r = n.inArray(t, a, r)) > -1) a.splice(r, 1), i && (o >= r && o--, u >= r && u--)
     }), this
    },
    has: function(e) {
     return e ? n.inArray(e, a) > -1 : !!a && !!a.length
    },
    empty: function() {
     return a = [], o = 0, this
    },
    disable: function() {
     return a = f = t = void 0, this
    },
    disabled: function() {
     return !a
    },
    lock: function() {
     return f = void 0, t || c.disable(), this
    },
    locked: function() {
     return !f
    },
    fireWith: function(e, t) {
     return !a || r && !f || (t = t || [], t = [e, t.slice ? t.slice() : t], i ? f.push(t) : l(t)), this
    },
    fire: function() {
     return c.fireWith(this, arguments), this
    },
    fired: function() {
     return !!r
    }
   };
  return c
 }, n.extend({
  Deferred: function(e) {
   var t = [
     ["resolve", "done", n.Callbacks("once memory"), "resolved"],
     ["reject", "fail", n.Callbacks("once memory"), "rejected"],
     ["notify", "progress", n.Callbacks("memory")]
    ],
    r = "pending",
    i = {
     state: function() {
      return r
     },
     always: function() {
      return s.done(arguments).fail(arguments), this
     },
     then: function() {
      var e = arguments;
      return n.Deferred(function(r) {
       n.each(t, function(t, o) {
        var u = n.isFunction(e[t]) && e[t];
        s[o[1]](function() {
         var e = u && u.apply(this, arguments);
         e && n.isFunction(e.promise) ? e.promise().done(r.resolve).fail(r.reject).progress(r.notify) : r[o[0] + "With"](this === i ? r.promise() : this, u ? [e] : arguments)
        })
       }), e = null
      }).promise()
     },
     promise: function(e) {
      return null != e ? n.extend(e, i) : i
     }
    },
    s = {};
   return i.pipe = i.then, n.each(t, function(e, n) {
    var o = n[2],
     u = n[3];
    i[n[1]] = o.add, u && o.add(function() {
     r = u
    }, t[1 ^ e][2].disable, t[2][2].lock), s[n[0]] = function() {
     return s[n[0] + "With"](this === s ? i : this, arguments), this
    }, s[n[0] + "With"] = o.fireWith
   }), i.promise(s), e && e.call(s, s), s
  },
  when: function(e) {
   var t = 0,
    r = d.call(arguments),
    i = r.length,
    s = 1 !== i || e && n.isFunction(e.promise) ? i : 0,
    o = 1 === s ? e : n.Deferred(),
    u = function(e, t, n) {
     return function(r) {
      t[e] = this, n[e] = arguments.length > 1 ? d.call(arguments) : r, n === a ? o.notifyWith(t, n) : --s || o.resolveWith(t, n)
     }
    },
    a, f, l;
   if (i > 1)
    for (a = new Array(i), f = new Array(i), l = new Array(i); i > t; t++) r[t] && n.isFunction(r[t].promise) ? r[t].promise().done(u(t, l, r)).fail(o.reject).progress(u(t, f, a)) : --s;
   return s || o.resolveWith(l, r), o.promise()
  }
 });
 var H;
 n.fn.ready = function(e) {
  return n.ready.promise().done(e), this
 }, n.extend({
  isReady: !1,
  readyWait: 1,
  holdReady: function(e) {
   e ? n.readyWait++ : n.ready(!0)
  },
  ready: function(e) {
   (e === !0 ? --n.readyWait : n.isReady) || (n.isReady = !0, e !== !0 && --n.readyWait > 0 || (H.resolveWith(l, [n]), n.fn.triggerHandler && (n(l).triggerHandler("ready"), n(l).off("ready"))))
  }
 }), n.ready.promise = function(e) {
  return H || (H = n.Deferred(), "complete" === l.readyState ? setTimeout(n.ready) : (l.addEventListener("DOMContentLoaded", I, !1), a.addEventListener("load", I, !1))), H.promise(e)
 }, n.ready.promise();
 var J = n.access = function(e, t, r, i, s, o, u) {
  var a = 0,
   f = e.length,
   l = null == r;
  if ("object" === n.type(r)) {
   s = !0;
   for (a in r) n.access(e, t, a, r[a], !0, o, u)
  } else if (void 0 !== i && (s = !0, n.isFunction(i) || (u = !0), l && (u ? (t.call(e, i), t = null) : (l = t, t = function(e, t, r) {
    return l.call(n(e), r)
   })), t))
   for (; f > a; a++) t(e[a], r, u ? i : i.call(e[a], a, t(e[a], r)));
  return s ? e : l ? t.call(e) : f ? t(e[0], r) : o
 };
 n.acceptData = function(e) {
  return 1 === e.nodeType || 9 === e.nodeType || !+e.nodeType
 }, K.uid = 1, K.accepts = n.acceptData, K.prototype = {
  key: function(e) {
   if (!K.accepts(e)) return 0;
   var t = {},
    r = e[this.expando];
   if (!r) {
    r = K.uid++;
    try {
     t[this.expando] = {
      value: r
     }, Object.defineProperties(e, t)
    } catch (i) {
     t[this.expando] = r, n.extend(e, t)
    }
   }
   return this.cache[r] || (this.cache[r] = {}), r
  },
  set: function(e, t, r) {
   var i, s = this.key(e),
    o = this.cache[s];
   if ("string" == typeof t) o[t] = r;
   else if (n.isEmptyObject(o)) n.extend(this.cache[s], t);
   else
    for (i in t) o[i] = t[i];
   return o
  },
  get: function(e, t) {
   var n = this.cache[this.key(e)];
   return void 0 === t ? n : n[t]
  },
  access: function(e, t, r) {
   var i;
   return void 0 === t || t && "string" == typeof t && void 0 === r ? (i = this.get(e, t), void 0 !== i ? i : this.get(e, n.camelCase(t))) : (this.set(e, t, r), void 0 !== r ? r : t)
  },
  remove: function(e, t) {
   var r, i, s, o = this.key(e),
    u = this.cache[o];
   if (void 0 === t) this.cache[o] = {};
   else {
    n.isArray(t) ? i = t.concat(t.map(n.camelCase)) : (s = n.camelCase(t), t in u ? i = [t, s] : (i = s, i = i in u ? [i] : i.match(E) || [])), r = i.length;
    while (r--) delete u[i[r]]
   }
  },
  hasData: function(e) {
   return !n.isEmptyObject(this.cache[e[this.expando]] || {})
  },
  discard: function(e) {
   e[this.expando] && delete this.cache[e[this.expando]]
  }
 };
 var L = new K,
  M = new K,
  N = /^(?:\{[\w\W]*\}|\[[\w\W]*\])$/,
  O = /([A-Z])/g;
 n.extend({
  hasData: function(e) {
   return M.hasData(e) || L.hasData(e)
  },
  data: function(e, t, n) {
   return M.access(e, t, n)
  },
  removeData: function(e, t) {
   M.remove(e, t)
  },
  _data: function(e, t, n) {
   return L.access(e, t, n)
  },
  _removeData: function(e, t) {
   L.remove(e, t)
  }
 }), n.fn.extend({
  data: function(e, t) {
   var r, i, s, o = this[0],
    u = o && o.attributes;
   if (void 0 === e) {
    if (this.length && (s = M.get(o), 1 === o.nodeType && !L.get(o, "hasDataAttrs"))) {
     r = u.length;
     while (r--) u[r] && (i = u[r].name, 0 === i.indexOf("data-") && (i = n.camelCase(i.slice(5)), P(o, i, s[i])));
     L.set(o, "hasDataAttrs", !0)
    }
    return s
   }
   return "object" == typeof e ? this.each(function() {
    M.set(this, e)
   }) : J(this, function(t) {
    var r, i = n.camelCase(e);
    if (o && void 0 === t) {
     if (r = M.get(o, e), void 0 !== r) return r;
     if (r = M.get(o, i), void 0 !== r) return r;
     if (r = P(o, i, void 0), void 0 !== r) return r
    } else this.each(function() {
     var n = M.get(this, i);
     M.set(this, i, t), -1 !== e.indexOf("-") && void 0 !== n && M.set(this, e, t)
    })
   }, null, t, arguments.length > 1, null, !0)
  },
  removeData: function(e) {
   return this.each(function() {
    M.remove(this, e)
   })
  }
 }), n.extend({
  queue: function(e, t, r) {
   var i;
   return e ? (t = (t || "fx") + "queue", i = L.get(e, t), r && (!i || n.isArray(r) ? i = L.access(e, t, n.makeArray(r)) : i.push(r)), i || []) : void 0
  },
  dequeue: function(e, t) {
   t = t || "fx";
   var r = n.queue(e, t),
    i = r.length,
    s = r.shift(),
    o = n._queueHooks(e, t),
    u = function() {
     n.dequeue(e, t)
    };
   "inprogress" === s && (s = r.shift(), i--), s && ("fx" === t && r.unshift("inprogress"), delete o.stop, s.call(e, u, o)), !i && o && o.empty.fire()
  },
  _queueHooks: function(e, t) {
   var r = t + "queueHooks";
   return L.get(e, r) || L.access(e, r, {
    empty: n.Callbacks("once memory").add(function() {
     L.remove(e, [t + "queue", r])
    })
   })
  }
 }), n.fn.extend({
  queue: function(e, t) {
   var r = 2;
   return "string" != typeof e && (t = e, e = "fx", r--), arguments.length < r ? n.queue(this[0], e) : void 0 === t ? this : this.each(function() {
    var r = n.queue(this, e, t);
    n._queueHooks(this, e), "fx" === e && "inprogress" !== r[0] && n.dequeue(this, e)
   })
  },
  dequeue: function(e) {
   return this.each(function() {
    n.dequeue(this, e)
   })
  },
  clearQueue: function(e) {
   return this.queue(e || "fx", [])
  },
  promise: function(e, t) {
   var r, i = 1,
    s = n.Deferred(),
    o = this,
    u = this.length,
    a = function() {
     --i || s.resolveWith(o, [o])
    };
   "string" != typeof e && (t = e, e = void 0), e = e || "fx";
   while (u--) r = L.get(o[u], e + "queueHooks"), r && r.empty && (i++, r.empty.add(a));
   return a(), s.promise(t)
  }
 });
 var Q = /[+-]?(?:\d*\.|)\d+(?:[eE][+-]?\d+|)/.source,
  R = ["Top", "Right", "Bottom", "Left"],
  S = function(e, t) {
   return e = t || e, "none" === n.css(e, "display") || !n.contains(e.ownerDocument, e)
  },
  T = /^(?:checkbox|radio)$/i;
 ! function() {
  var e = l.createDocumentFragment(),
   t = e.appendChild(l.createElement("div")),
   n = l.createElement("input");
  n.setAttribute("type", "radio"), n.setAttribute("checked", "checked"), n.setAttribute("name", "t"), t.appendChild(n), k.checkClone = t.cloneNode(!0).cloneNode(!0).lastChild.checked, t.innerHTML = "<textarea>x</textarea>", k.noCloneChecked = !!t.cloneNode(!0).lastChild.defaultValue
 }();
 var U = "undefined";
 k.focusinBubbles = "onfocusin" in a;
 var V = /^key/,
  W = /^(?:mouse|pointer|contextmenu)|click/,
  X = /^(?:focusinfocus|focusoutblur)$/,
  Y = /^([^.]*)(?:\.(.+)|)$/;
 n.event = {
  global: {},
  add: function(e, t, r, i, s) {
   var o, u, a, f, l, c, h, p, d, v, m, g = L.get(e);
   if (g) {
    r.handler && (o = r, r = o.handler, s = o.selector), r.guid || (r.guid = n.guid++), (f = g.events) || (f = g.events = {}), (u = g.handle) || (u = g.handle = function(t) {
     return typeof n !== U && n.event.triggered !== t.type ? n.event.dispatch.apply(e, arguments) : void 0
    }), t = (t || "").match(E) || [""], l = t.length;
    while (l--) a = Y.exec(t[l]) || [], d = m = a[1], v = (a[2] || "").split(".").sort(), d && (h = n.event.special[d] || {}, d = (s ? h.delegateType : h.bindType) || d, h = n.event.special[d] || {}, c = n.extend({
     type: d,
     origType: m,
     data: i,
     handler: r,
     guid: r.guid,
     selector: s,
     needsContext: s && n.expr.match.needsContext.test(s),
     namespace: v.join(".")
    }, o), (p = f[d]) || (p = f[d] = [], p.delegateCount = 0, h.setup && h.setup.call(e, i, v, u) !== !1 || e.addEventListener && e.addEventListener(d, u, !1)), h.add && (h.add.call(e, c), c.handler.guid || (c.handler.guid = r.guid)), s ? p.splice(p.delegateCount++, 0, c) : p.push(c), n.event.global[d] = !0)
   }
  },
  remove: function(e, t, r, i, s) {
   var o, u, a, f, l, c, h, p, d, v, m, g = L.hasData(e) && L.get(e);
   if (g && (f = g.events)) {
    t = (t || "").match(E) || [""], l = t.length;
    while (l--)
     if (a = Y.exec(t[l]) || [], d = m = a[1], v = (a[2] || "").split(".").sort(), d) {
      h = n.event.special[d] || {}, d = (i ? h.delegateType : h.bindType) || d, p = f[d] || [], a = a[2] && new RegExp("(^|\\.)" + v.join("\\.(?:.*\\.|)") + "(\\.|$)"), u = o = p.length;
      while (o--) c = p[o], !s && m !== c.origType || r && r.guid !== c.guid || a && !a.test(c.namespace) || i && i !== c.selector && ("**" !== i || !c.selector) || (p.splice(o, 1), c.selector && p.delegateCount--, h.remove && h.remove.call(e, c));
      u && !p.length && (h.teardown && h.teardown.call(e, v, g.handle) !== !1 || n.removeEvent(e, d, g.handle), delete f[d])
     } else
      for (d in f) n.event.remove(e, d + t[l], r, i, !0);
    n.isEmptyObject(f) && (delete g.handle, L.remove(e, "events"))
   }
  },
  trigger: function(e, t, r, i) {
   var s, o, u, f, c, h, p, d = [r || l],
    v = j.call(e, "type") ? e.type : e,
    m = j.call(e, "namespace") ? e.namespace.split(".") : [];
   if (o = u = r = r || l, 3 !== r.nodeType && 8 !== r.nodeType && !X.test(v + n.event.triggered) && (v.indexOf(".") >= 0 && (m = v.split("."), v = m.shift(), m.sort()), c = v.indexOf(":") < 0 && "on" + v, e = e[n.expando] ? e : new n.Event(v, "object" == typeof e && e), e.isTrigger = i ? 2 : 3, e.namespace = m.join("."), e.namespace_re = e.namespace ? new RegExp("(^|\\.)" + m.join("\\.(?:.*\\.|)") + "(\\.|$)") : null, e.result = void 0, e.target || (e.target = r), t = null == t ? [e] : n.makeArray(t, [e]), p = n.event.special[v] || {}, i || !p.trigger || p.trigger.apply(r, t) !== !1)) {
    if (!i && !p.noBubble && !n.isWindow(r)) {
     for (f = p.delegateType || v, X.test(f + v) || (o = o.parentNode); o; o = o.parentNode) d.push(o), u = o;
     u === (r.ownerDocument || l) && d.push(u.defaultView || u.parentWindow || a)
    }
    s = 0;
    while ((o = d[s++]) && !e.isPropagationStopped()) e.type = s > 1 ? f : p.bindType || v, h = (L.get(o, "events") || {})[e.type] && L.get(o, "handle"), h && h.apply(o, t), h = c && o[c], h && h.apply && n.acceptData(o) && (e.result = h.apply(o, t), e.result === !1 && e.preventDefault());
    return e.type = v, i || e.isDefaultPrevented() || p._default && p._default.apply(d.pop(), t) !== !1 || !n.acceptData(r) || c && n.isFunction(r[v]) && !n.isWindow(r) && (u = r[c], u && (r[c] = null), n.event.triggered = v, r[v](), n.event.triggered = void 0, u && (r[c] = u)), e.result
   }
  },
  dispatch: function(e) {
   e = n.event.fix(e);
   var t, r, i, s, o, u = [],
    a = d.call(arguments),
    f = (L.get(this, "events") || {})[e.type] || [],
    l = n.event.special[e.type] || {};
   if (a[0] = e, e.delegateTarget = this, !l.preDispatch || l.preDispatch.call(this, e) !== !1) {
    u = n.event.handlers.call(this, e, f), t = 0;
    while ((s = u[t++]) && !e.isPropagationStopped()) {
     e.currentTarget = s.elem, r = 0;
     while ((o = s.handlers[r++]) && !e.isImmediatePropagationStopped())(!e.namespace_re || e.namespace_re.test(o.namespace)) && (e.handleObj = o, e.data = o.data, i = ((n.event.special[o.origType] || {}).handle || o.handler).apply(s.elem, a), void 0 !== i && (e.result = i) === !1 && (e.preventDefault(), e.stopPropagation()))
    }
    return l.postDispatch && l.postDispatch.call(this, e), e.result
   }
  },
  handlers: function(e, t) {
   var r, i, s, o, u = [],
    a = t.delegateCount,
    f = e.target;
   if (a && f.nodeType && (!e.button || "click" !== e.type))
    for (; f !== this; f = f.parentNode || this)
     if (f.disabled !== !0 || "click" !== e.type) {
      for (i = [], r = 0; a > r; r++) o = t[r], s = o.selector + " ", void 0 === i[s] && (i[s] = o.needsContext ? n(s, this).index(f) >= 0 : n.find(s, this, null, [f]).length), i[s] && i.push(o);
      i.length && u.push({
       elem: f,
       handlers: i
      })
     } return a < t.length && u.push({
    elem: this,
    handlers: t.slice(a)
   }), u
  },
  props: "altKey bubbles cancelable ctrlKey currentTarget eventPhase metaKey relatedTarget shiftKey target timeStamp view which".split(" "),
  fixHooks: {},
  keyHooks: {
   props: "char charCode key keyCode".split(" "),
   filter: function(e, t) {
    return null == e.which && (e.which = null != t.charCode ? t.charCode : t.keyCode), e
   }
  },
  mouseHooks: {
   props: "button buttons clientX clientY offsetX offsetY pageX pageY screenX screenY toElement".split(" "),
   filter: function(e, t) {
    var n, r, i, s = t.button;
    return null == e.pageX && null != t.clientX && (n = e.target.ownerDocument || l, r = n.documentElement, i = n.body, e.pageX = t.clientX + (r && r.scrollLeft || i && i.scrollLeft || 0) - (r && r.clientLeft || i && i.clientLeft || 0), e.pageY = t.clientY + (r && r.scrollTop || i && i.scrollTop || 0) - (r && r.clientTop || i && i.clientTop || 0)), e.which || void 0 === s || (e.which = 1 & s ? 1 : 2 & s ? 3 : 4 & s ? 2 : 0), e
   }
  },
  fix: function(e) {
   if (e[n.expando]) return e;
   var t, r, i, s = e.type,
    o = e,
    u = this.fixHooks[s];
   u || (this.fixHooks[s] = u = W.test(s) ? this.mouseHooks : V.test(s) ? this.keyHooks : {}), i = u.props ? this.props.concat(u.props) : this.props, e = new n.Event(o), t = i.length;
   while (t--) r = i[t], e[r] = o[r];
   return e.target || (e.target = l), 3 === e.target.nodeType && (e.target = e.target.parentNode), u.filter ? u.filter(e, o) : e
  },
  special: {
   load: {
    noBubble: !0
   },
   focus: {
    trigger: function() {
     return this !== _() && this.focus ? (this.focus(), !1) : void 0
    },
    delegateType: "focusin"
   },
   blur: {
    trigger: function() {
     return this === _() && this.blur ? (this.blur(), !1) : void 0
    },
    delegateType: "focusout"
   },
   click: {
    trigger: function() {
     return "checkbox" === this.type && this.click && n.nodeName(this, "input") ? (this.click(), !1) : void 0
    },
    _default: function(e) {
     return n.nodeName(e.target, "a")
    }
   },
   beforeunload: {
    postDispatch: function(e) {
     void 0 !== e.result && e.originalEvent && (e.originalEvent.returnValue = e.result)
    }
   }
  },
  simulate: function(e, t, r, i) {
   var s = n.extend(new n.Event, r, {
    type: e,
    isSimulated: !0,
    originalEvent: {}
   });
   i ? n.event.trigger(s, null, t) : n.event.dispatch.call(t, s), s.isDefaultPrevented() && r.preventDefault()
  }
 }, n.removeEvent = function(e, t, n) {
  e.removeEventListener && e.removeEventListener(t, n, !1)
 }, n.Event = function(e, t) {
  return this instanceof n.Event ? (e && e.type ? (this.originalEvent = e, this.type = e.type, this.isDefaultPrevented = e.defaultPrevented || void 0 === e.defaultPrevented && e.returnValue === !1 ? Z : $) : this.type = e, t && n.extend(this, t), this.timeStamp = e && e.timeStamp || n.now(), void(this[n.expando] = !0)) : new n.Event(e, t)
 }, n.Event.prototype = {
  isDefaultPrevented: $,
  isPropagationStopped: $,
  isImmediatePropagationStopped: $,
  preventDefault: function() {
   var e = this.originalEvent;
   this.isDefaultPrevented = Z, e && e.preventDefault && e.preventDefault()
  },
  stopPropagation: function() {
   var e = this.originalEvent;
   this.isPropagationStopped = Z, e && e.stopPropagation && e.stopPropagation()
  },
  stopImmediatePropagation: function() {
   var e = this.originalEvent;
   this.isImmediatePropagationStopped = Z, e && e.stopImmediatePropagation && e.stopImmediatePropagation(), this.stopPropagation()
  }
 }, n.each({
  mouseenter: "mouseover",
  mouseleave: "mouseout",
  pointerenter: "pointerover",
  pointerleave: "pointerout"
 }, function(e, t) {
  n.event.special[e] = {
   delegateType: t,
   bindType: t,
   handle: function(e) {
    var r, i = this,
     s = e.relatedTarget,
     o = e.handleObj;
    return (!s || s !== i && !n.contains(i, s)) && (e.type = o.origType, r = o.handler.apply(this, arguments), e.type = t), r
   }
  }
 }), k.focusinBubbles || n.each({
  focus: "focusin",
  blur: "focusout"
 }, function(e, t) {
  var r = function(e) {
   n.event.simulate(t, e.target, n.event.fix(e), !0)
  };
  n.event.special[t] = {
   setup: function() {
    var n = this.ownerDocument || this,
     i = L.access(n, t);
    i || n.addEventListener(e, r, !0), L.access(n, t, (i || 0) + 1)
   },
   teardown: function() {
    var n = this.ownerDocument || this,
     i = L.access(n, t) - 1;
    i ? L.access(n, t, i) : (n.removeEventListener(e, r, !0), L.remove(n, t))
   }
  }
 }), n.fn.extend({
  on: function(e, t, r, i, s) {
   var o, u;
   if ("object" == typeof e) {
    "string" != typeof t && (r = r || t, t = void 0);
    for (u in e) this.on(u, t, r, e[u], s);
    return this
   }
   if (null == r && null == i ? (i = t, r = t = void 0) : null == i && ("string" == typeof t ? (i = r, r = void 0) : (i = r, r = t, t = void 0)), i === !1) i = $;
   else if (!i) return this;
   return 1 === s && (o = i, i = function(e) {
    return n().off(e), o.apply(this, arguments)
   }, i.guid = o.guid || (o.guid = n.guid++)), this.each(function() {
    n.event.add(this, e, i, r, t)
   })
  },
  one: function(e, t, n, r) {
   return this.on(e, t, n, r, 1)
  },
  off: function(e, t, r) {
   var i, s;
   if (e && e.preventDefault && e.handleObj) return i = e.handleObj, n(e.delegateTarget).off(i.namespace ? i.origType + "." + i.namespace : i.origType, i.selector, i.handler), this;
   if ("object" == typeof e) {
    for (s in e) this.off(s, t, e[s]);
    return this
   }
   return (t === !1 || "function" == typeof t) && (r = t, t = void 0), r === !1 && (r = $), this.each(function() {
    n.event.remove(this, e, r, t)
   })
  },
  trigger: function(e, t) {
   return this.each(function() {
    n.event.trigger(e, t, this)
   })
  },
  triggerHandler: function(e, t) {
   var r = this[0];
   return r ? n.event.trigger(e, t, r, !0) : void 0
  }
 });
 var aa = /<(?!area|br|col|embed|hr|img|input|link|meta|param)(([\w:]+)[^>]*)\/>/gi,
  ba = /<([\w:]+)/,
  ca = /<|&#?\w+;/,
  da = /<(?:script|style|link)/i,
  ea = /checked\s*(?:[^=]|=\s*.checked.)/i,
  fa = /^$|\/(?:java|ecma)script/i,
  ga = /^true\/(.*)/,
  ha = /^\s*<!(?:\[CDATA\[|--)|(?:\]\]|--)>\s*$/g,
  ia = {
   option: [1, "<select multiple='multiple'>", "</select>"],
   thead: [1, "<table>", "</table>"],
   col: [2, "<table><colgroup>", "</colgroup></table>"],
   tr: [2, "<table><tbody>", "</tbody></table>"],
   td: [3, "<table><tbody><tr>", "</tr></tbody></table>"],
   _default: [0, "", ""]
  };
 ia.optgroup = ia.option, ia.tbody = ia.tfoot = ia.colgroup = ia.caption = ia.thead, ia.th = ia.td, n.extend({
  clone: function(e, t, r) {
   var i, s, o, u, a = e.cloneNode(!0),
    f = n.contains(e.ownerDocument, e);
   if (!(k.noCloneChecked || 1 !== e.nodeType && 11 !== e.nodeType || n.isXMLDoc(e)))
    for (u = oa(a), o = oa(e), i = 0, s = o.length; s > i; i++) pa(o[i], u[i]);
   if (t)
    if (r)
     for (o = o || oa(e), u = u || oa(a), i = 0, s = o.length; s > i; i++) na(o[i], u[i]);
    else na(e, a);
   return u = oa(a, "script"), u.length > 0 && ma(u, !f && oa(e, "script")), a
  },
  buildFragment: function(e, t, r, i) {
   for (var s, o, u, a, f, l, c = t.createDocumentFragment(), h = [], p = 0, d = e.length; d > p; p++)
    if (s = e[p], s || 0 === s)
     if ("object" === n.type(s)) n.merge(h, s.nodeType ? [s] : s);
     else if (ca.test(s)) {
    o = o || c.appendChild(t.createElement("div")), u = (ba.exec(s) || ["", ""])[1].toLowerCase(), a = ia[u] || ia._default, o.innerHTML = a[1] + s.replace(aa, "<$1></$2>") + a[2], l = a[0];
    while (l--) o = o.lastChild;
    n.merge(h, o.childNodes), o = c.firstChild, o.textContent = ""
   } else h.push(t.createTextNode(s));
   c.textContent = "", p = 0;
   while (s = h[p++])
    if ((!i || -1 === n.inArray(s, i)) && (f = n.contains(s.ownerDocument, s), o = oa(c.appendChild(s), "script"), f && ma(o), r)) {
     l = 0;
     while (s = o[l++]) fa.test(s.type || "") && r.push(s)
    } return c
  },
  cleanData: function(e) {
   for (var t, r, i, s, o = n.event.special, u = 0; void 0 !== (r = e[u]); u++) {
    if (n.acceptData(r) && (s = r[L.expando], s && (t = L.cache[s]))) {
     if (t.events)
      for (i in t.events) o[i] ? n.event.remove(r, i) : n.removeEvent(r, i, t.handle);
     L.cache[s] && delete L.cache[s]
    }
    delete M.cache[r[M.expando]]
   }
  }
 }), n.fn.extend({
  text: function(e) {
   return J(this, function(e) {
    return void 0 === e ? n.text(this) : this.empty().each(function() {
     (1 === this.nodeType || 11 === this.nodeType || 9 === this.nodeType) && (this.textContent = e)
    })
   }, null, e, arguments.length)
  },
  append: function() {
   return this.domManip(arguments, function(e) {
    if (1 === this.nodeType || 11 === this.nodeType || 9 === this.nodeType) {
     var t = ja(this, e);
     t.appendChild(e)
    }
   })
  },
  prepend: function() {
   return this.domManip(arguments, function(e) {
    if (1 === this.nodeType || 11 === this.nodeType || 9 === this.nodeType) {
     var t = ja(this, e);
     t.insertBefore(e, t.firstChild)
    }
   })
  },
  before: function() {
   return this.domManip(arguments, function(e) {
    this.parentNode && this.parentNode.insertBefore(e, this)
   })
  },
  after: function() {
   return this.domManip(arguments, function(e) {
    this.parentNode && this.parentNode.insertBefore(e, this.nextSibling)
   })
  },
  remove: function(e, t) {
   for (var r, i = e ? n.filter(e, this) : this, s = 0; null != (r = i[s]); s++) t || 1 !== r.nodeType || n.cleanData(oa(r)), r.parentNode && (t && n.contains(r.ownerDocument, r) && ma(oa(r, "script")), r.parentNode.removeChild(r));
   return this
  },
  empty: function() {
   for (var e, t = 0; null != (e = this[t]); t++) 1 === e.nodeType && (n.cleanData(oa(e, !1)), e.textContent = "");
   return this
  },
  clone: function(e, t) {
   return e = null == e ? !1 : e, t = null == t ? e : t, this.map(function() {
    return n.clone(this, e, t)
   })
  },
  html: function(e) {
   return J(this, function(e) {
    var t = this[0] || {},
     r = 0,
     i = this.length;
    if (void 0 === e && 1 === t.nodeType) return t.innerHTML;
    if ("string" == typeof e && !da.test(e) && !ia[(ba.exec(e) || ["", ""])[1].toLowerCase()]) {
     e = e.replace(aa, "<$1></$2>");
     try {
      for (; i > r; r++) t = this[r] || {}, 1 === t.nodeType && (n.cleanData(oa(t, !1)), t.innerHTML = e);
      t = 0
     } catch (s) {}
    }
    t && this.empty().append(e)
   }, null, e, arguments.length)
  },
  replaceWith: function() {
   var e = arguments[0];
   return this.domManip(arguments, function(t) {
    e = this.parentNode, n.cleanData(oa(this)), e && e.replaceChild(t, this)
   }), e && (e.length || e.nodeType) ? this : this.remove()
  },
  detach: function(e) {
   return this.remove(e, !0)
  },
  domManip: function(t, r) {
   t = e.apply([], t);
   var i, s, o, u, a, f, l = 0,
    c = this.length,
    h = this,
    p = c - 1,
    d = t[0],
    v = n.isFunction(d);
   if (v || c > 1 && "string" == typeof d && !k.checkClone && ea.test(d)) return this.each(function(e) {
    var n = h.eq(e);
    v && (t[0] = d.call(this, e, n.html())), n.domManip(t, r)
   });
   if (c && (i = n.buildFragment(t, this[0].ownerDocument, !1, this), s = i.firstChild, 1 === i.childNodes.length && (i = s), s)) {
    for (o = n.map(oa(i, "script"), ka), u = o.length; c > l; l++) a = i, l !== p && (a = n.clone(a, !0, !0), u && n.merge(o, oa(a, "script"))), r.call(this[l], a, l);
    if (u)
     for (f = o[o.length - 1].ownerDocument, n.map(o, la), l = 0; u > l; l++) a = o[l], fa.test(a.type || "") && !L.access(a, "globalEval") && n.contains(f, a) && (a.src ? n._evalUrl && n._evalUrl(a.src) : n.globalEval(a.textContent.replace(ha, "")))
   }
   return this
  }
 }), n.each({
  appendTo: "append",
  prependTo: "prepend",
  insertBefore: "before",
  insertAfter: "after",
  replaceAll: "replaceWith"
 }, function(e, t) {
  n.fn[e] = function(e) {
   for (var r, i = [], s = n(e), o = s.length - 1, u = 0; o >= u; u++) r = u === o ? this : this.clone(!0), n(s[u])[t](r), f.apply(i, r.get());
   return this.pushStack(i)
  }
 });
 var qa, ra = {},
  ua = /^margin/,
  va = new RegExp("^(" + Q + ")(?!px)[a-z%]+$", "i"),
  wa = function(e) {
   return e.ownerDocument.defaultView.opener ? e.ownerDocument.defaultView.getComputedStyle(e, null) : a.getComputedStyle(e, null)
  };
 ! function() {
  var e, t, r = l.documentElement,
   i = l.createElement("div"),
   s = l.createElement("div");
  if (s.style) {
   s.style.backgroundClip = "content-box", s.cloneNode(!0).style.backgroundClip = "", k.clearCloneStyle = "content-box" === s.style.backgroundClip, i.style.cssText = "border:0;width:0;height:0;top:0;left:-9999px;margin-top:1px;position:absolute", i.appendChild(s);

   function o() {
    s.style.cssText = "-webkit-box-sizing:border-box;-moz-box-sizing:border-box;box-sizing:border-box;display:block;margin-top:1%;top:1%;border:1px;padding:1px;width:4px;position:absolute", s.innerHTML = "", r.appendChild(i);
    var n = a.getComputedStyle(s, null);
    e = "1%" !== n.top, t = "4px" === n.width, r.removeChild(i)
   }
   a.getComputedStyle && n.extend(k, {
    pixelPosition: function() {
     return o(), e
    },
    boxSizingReliable: function() {
     return null == t && o(), t
    },
    reliableMarginRight: function() {
     var e, t = s.appendChild(l.createElement("div"));
     return t.style.cssText = s.style.cssText = "-webkit-box-sizing:content-box;-moz-box-sizing:content-box;box-sizing:content-box;display:block;margin:0;border:0;padding:0", t.style.marginRight = t.style.width = "0", s.style.width = "1px", r.appendChild(i), e = !parseFloat(a.getComputedStyle(t, null).marginRight), r.removeChild(i), s.removeChild(t), e
    }
   })
  }
 }(), n.swap = function(e, t, n, r) {
  var i, s, o = {};
  for (s in t) o[s] = e.style[s], e.style[s] = t[s];
  i = n.apply(e, r || []);
  for (s in t) e.style[s] = o[s];
  return i
 };
 var za = /^(none|table(?!-c[ea]).+)/,
  Aa = new RegExp("^(" + Q + ")(.*)$", "i"),
  Ba = new RegExp("^([+-])=(" + Q + ")", "i"),
  Ca = {
   position: "absolute",
   visibility: "hidden",
   display: "block"
  },
  Da = {
   letterSpacing: "0",
   fontWeight: "400"
  },
  Ea = ["Webkit", "O", "Moz", "ms"];
 n.extend({
  cssHooks: {
   opacity: {
    get: function(e, t) {
     if (t) {
      var n = xa(e, "opacity");
      return "" === n ? "1" : n
     }
    }
   }
  },
  cssNumber: {
   columnCount: !0,
   fillOpacity: !0,
   flexGrow: !0,
   flexShrink: !0,
   fontWeight: !0,
   lineHeight: !0,
   opacity: !0,
   order: !0,
   orphans: !0,
   widows: !0,
   zIndex: !0,
   zoom: !0
  },
  cssProps: {
   "float": "cssFloat"
  },
  style: function(e, t, r, i) {
   if (e && 3 !== e.nodeType && 8 !== e.nodeType && e.style) {
    var s, o, u, a = n.camelCase(t),
     f = e.style;
    return t = n.cssProps[a] || (n.cssProps[a] = Fa(f, a)), u = n.cssHooks[t] || n.cssHooks[a], void 0 === r ? u && "get" in u && void 0 !== (s = u.get(e, !1, i)) ? s : f[t] : (o = typeof r, "string" === o && (s = Ba.exec(r)) && (r = (s[1] + 1) * s[2] + parseFloat(n.css(e, t)), o = "number"), null != r && r === r && ("number" !== o || n.cssNumber[a] || (r += "px"), k.clearCloneStyle || "" !== r || 0 !== t.indexOf("background") || (f[t] = "inherit"), u && "set" in u && void 0 === (r = u.set(e, r, i)) || (f[t] = r)), void 0)
   }
  },
  css: function(e, t, r, i) {
   var s, o, u, a = n.camelCase(t);
   return t = n.cssProps[a] || (n.cssProps[a] = Fa(e.style, a)), u = n.cssHooks[t] || n.cssHooks[a], u && "get" in u && (s = u.get(e, !0, r)), void 0 === s && (s = xa(e, t, i)), "normal" === s && t in Da && (s = Da[t]), "" === r || r ? (o = parseFloat(s), r === !0 || n.isNumeric(o) ? o || 0 : s) : s
  }
 }), n.each(["height", "width"], function(e, t) {
  n.cssHooks[t] = {
   get: function(e, r, i) {
    return r ? za.test(n.css(e, "display")) && 0 === e.offsetWidth ? n.swap(e, Ca, function() {
     return Ia(e, t, i)
    }) : Ia(e, t, i) : void 0
   },
   set: function(e, r, i) {
    var s = i && wa(e);
    return Ga(e, r, i ? Ha(e, t, i, "border-box" === n.css(e, "boxSizing", !1, s), s) : 0)
   }
  }
 }), n.cssHooks.marginRight = ya(k.reliableMarginRight, function(e, t) {
  return t ? n.swap(e, {
   display: "inline-block"
  }, xa, [e, "marginRight"]) : void 0
 }), n.each({
  margin: "",
  padding: "",
  border: "Width"
 }, function(e, t) {
  n.cssHooks[e + t] = {
   expand: function(n) {
    for (var r = 0, i = {}, s = "string" == typeof n ? n.split(" ") : [n]; 4 > r; r++) i[e + R[r] + t] = s[r] || s[r - 2] || s[0];
    return i
   }
  }, ua.test(e) || (n.cssHooks[e + t].set = Ga)
 }), n.fn.extend({
  css: function(e, t) {
   return J(this, function(e, t, r) {
    var i, s, o = {},
     u = 0;
    if (n.isArray(t)) {
     for (i = wa(e), s = t.length; s > u; u++) o[t[u]] = n.css(e, t[u], !1, i);
     return o
    }
    return void 0 !== r ? n.style(e, t, r) : n.css(e, t)
   }, e, t, arguments.length > 1)
  },
  show: function() {
   return Ja(this, !0)
  },
  hide: function() {
   return Ja(this)
  },
  toggle: function(e) {
   return "boolean" == typeof e ? e ? this.show() : this.hide() : this.each(function() {
    S(this) ? n(this).show() : n(this).hide()
   })
  }
 }), n.Tween = Ka, Ka.prototype = {
  constructor: Ka,
  init: function(e, t, r, i, s, o) {
   this.elem = e, this.prop = r, this.easing = s || "swing", this.options = t, this.start = this.now = this.cur(), this.end = i, this.unit = o || (n.cssNumber[r] ? "" : "px")
  },
  cur: function() {
   var e = Ka.propHooks[this.prop];
   return e && e.get ? e.get(this) : Ka.propHooks._default.get(this)
  },
  run: function(e) {
   var t, r = Ka.propHooks[this.prop];
   return this.options.duration ? this.pos = t = n.easing[this.easing](e, this.options.duration * e, 0, 1, this.options.duration) : this.pos = t = e, this.now = (this.end - this.start) * t + this.start, this.options.step && this.options.step.call(this.elem, this.now, this), r && r.set ? r.set(this) : Ka.propHooks._default.set(this), this
  }
 }, Ka.prototype.init.prototype = Ka.prototype, Ka.propHooks = {
  _default: {
   get: function(e) {
    var t;
    return null == e.elem[e.prop] || e.elem.style && null != e.elem.style[e.prop] ? (t = n.css(e.elem, e.prop, ""), t && "auto" !== t ? t : 0) : e.elem[e.prop]
   },
   set: function(e) {
    n.fx.step[e.prop] ? n.fx.step[e.prop](e) : e.elem.style && (null != e.elem.style[n.cssProps[e.prop]] || n.cssHooks[e.prop]) ? n.style(e.elem, e.prop, e.now + e.unit) : e.elem[e.prop] = e.now
   }
  }
 }, Ka.propHooks.scrollTop = Ka.propHooks.scrollLeft = {
  set: function(e) {
   e.elem.nodeType && e.elem.parentNode && (e.elem[e.prop] = e.now)
  }
 }, n.easing = {
  linear: function(e) {
   return e
  },
  swing: function(e) {
   return .5 - Math.cos(e * Math.PI) / 2
  }
 }, n.fx = Ka.prototype.init, n.fx.step = {};
 var La, Ma, Na = /^(?:toggle|show|hide)$/,
  Oa = new RegExp("^(?:([+-])=|)(" + Q + ")([a-z%]*)$", "i"),
  Pa = /queueHooks$/,
  Qa = [Va],
  Ra = {
   "*": [function(e, t) {
    var r = this.createTween(e, t),
     i = r.cur(),
     s = Oa.exec(t),
     o = s && s[3] || (n.cssNumber[e] ? "" : "px"),
     u = (n.cssNumber[e] || "px" !== o && +i) && Oa.exec(n.css(r.elem, e)),
     a = 1,
     f = 20;
    if (u && u[3] !== o) {
     o = o || u[3], s = s || [], u = +i || 1;
     do a = a || ".5", u /= a, n.style(r.elem, e, u + o); while (a !== (a = r.cur() / i) && 1 !== a && --f)
    }
    return s && (u = r.start = +u || +i || 0, r.unit = o, r.end = s[1] ? u + (s[1] + 1) * s[2] : +s[2]), r
   }]
  };
 n.Animation = n.extend(Xa, {
   tweener: function(e, t) {
    n.isFunction(e) ? (t = e, e = ["*"]) : e = e.split(" ");
    for (var r, i = 0, s = e.length; s > i; i++) r = e[i], Ra[r] = Ra[r] || [], Ra[r].unshift(t)
   },
   prefilter: function(e, t) {
    t ? Qa.unshift(e) : Qa.push(e)
   }
  }), n.speed = function(e, t, r) {
   var i = e && "object" == typeof e ? n.extend({}, e) : {
    complete: r || !r && t || n.isFunction(e) && e,
    duration: e,
    easing: r && t || t && !n.isFunction(t) && t
   };
   return i.duration = n.fx.off ? 0 : "number" == typeof i.duration ? i.duration : i.duration in n.fx.speeds ? n.fx.speeds[i.duration] : n.fx.speeds._default, (null == i.queue || i.queue === !0) && (i.queue = "fx"), i.old = i.complete, i.complete = function() {
    n.isFunction(i.old) && i.old.call(this), i.queue && n.dequeue(this, i.queue)
   }, i
  }, n.fn.extend({
   fadeTo: function(e, t, n, r) {
    return this.filter(S).css("opacity", 0).show().end().animate({
     opacity: t
    }, e, n, r)
   },
   animate: function(e, t, r, i) {
    var s = n.isEmptyObject(e),
     o = n.speed(t, r, i),
     u = function() {
      var t = Xa(this, n.extend({}, e), o);
      (s || L.get(this, "finish")) && t.stop(!0)
     };
    return u.finish = u, s || o.queue === !1 ? this.each(u) : this.queue(o.queue, u)
   },
   stop: function(e, t, r) {
    var i = function(e) {
     var t = e.stop;
     delete e.stop, t(r)
    };
    return "string" != typeof e && (r = t, t = e, e = void 0), t && e !== !1 && this.queue(e || "fx", []), this.each(function() {
     var t = !0,
      s = null != e && e + "queueHooks",
      o = n.timers,
      u = L.get(this);
     if (s) u[s] && u[s].stop && i(u[s]);
     else
      for (s in u) u[s] && u[s].stop && Pa.test(s) && i(u[s]);
     for (s = o.length; s--;) o[s].elem !== this || null != e && o[s].queue !== e || (o[s].anim.stop(r), t = !1, o.splice(s, 1));
     (t || !r) && n.dequeue(this, e)
    })
   },
   finish: function(e) {
    return e !== !1 && (e = e || "fx"), this.each(function() {
     var t, r = L.get(this),
      i = r[e + "queue"],
      s = r[e + "queueHooks"],
      o = n.timers,
      u = i ? i.length : 0;
     for (r.finish = !0, n.queue(this, e, []), s && s.stop && s.stop.call(this, !0), t = o.length; t--;) o[t].elem === this && o[t].queue === e && (o[t].anim.stop(!0), o.splice(t, 1));
     for (t = 0; u > t; t++) i[t] && i[t].finish && i[t].finish.call(this);
     delete r.finish
    })
   }
  }), n.each(["toggle", "show", "hide"], function(e, t) {
   var r = n.fn[t];
   n.fn[t] = function(e, n, i) {
    return null == e || "boolean" == typeof e ? r.apply(this, arguments) : this.animate(Ta(t, !0), e, n, i)
   }
  }), n.each({
   slideDown: Ta("show"),
   slideUp: Ta("hide"),
   slideToggle: Ta("toggle"),
   fadeIn: {
    opacity: "show"
   },
   fadeOut: {
    opacity: "hide"
   },
   fadeToggle: {
    opacity: "toggle"
   }
  }, function(e, t) {
   n.fn[e] = function(e, n, r) {
    return this.animate(t, e, n, r)
   }
  }), n.timers = [], n.fx.tick = function() {
   var e, t = 0,
    r = n.timers;
   for (La = n.now(); t < r.length; t++) e = r[t], e() || r[t] !== e || r.splice(t--, 1);
   r.length || n.fx.stop(), La = void 0
  }, n.fx.timer = function(e) {
   n.timers.push(e), e() ? n.fx.start() : n.timers.pop()
  }, n.fx.interval = 13, n.fx.start = function() {
   Ma || (Ma = setInterval(n.fx.tick, n.fx.interval))
  }, n.fx.stop = function() {
   clearInterval(Ma), Ma = null
  }, n.fx.speeds = {
   slow: 600,
   fast: 200,
   _default: 400
  }, n.fn.delay = function(e, t) {
   return e = n.fx ? n.fx.speeds[e] || e : e, t = t || "fx", this.queue(t, function(t, n) {
    var r = setTimeout(t, e);
    n.stop = function() {
     clearTimeout(r)
    }
   })
  },
  function() {
   var e = l.createElement("input"),
    t = l.createElement("select"),
    n = t.appendChild(l.createElement("option"));
   e.type = "checkbox", k.checkOn = "" !== e.value, k.optSelected = n.selected, t.disabled = !0, k.optDisabled = !n.disabled, e = l.createElement("input"), e.value = "t", e.type = "radio", k.radioValue = "t" === e.value
  }();
 var Ya, Za, $a = n.expr.attrHandle;
 n.fn.extend({
  attr: function(e, t) {
   return J(this, n.attr, e, t, arguments.length > 1)
  },
  removeAttr: function(e) {
   return this.each(function() {
    n.removeAttr(this, e)
   })
  }
 }), n.extend({
  attr: function(e, t, r) {
   var i, s, o = e.nodeType;
   if (e && 3 !== o && 8 !== o && 2 !== o) return typeof e.getAttribute === U ? n.prop(e, t, r) : (1 === o && n.isXMLDoc(e) || (t = t.toLowerCase(), i = n.attrHooks[t] || (n.expr.match.bool.test(t) ? Za : Ya)), void 0 === r ? i && "get" in i && null !== (s = i.get(e, t)) ? s : (s = n.find.attr(e, t), null == s ? void 0 : s) : null !== r ? i && "set" in i && void 0 !== (s = i.set(e, r, t)) ? s : (e.setAttribute(t, r + ""), r) : void n.removeAttr(e, t))
  },
  removeAttr: function(e, t) {
   var r, i, s = 0,
    o = t && t.match(E);
   if (o && 1 === e.nodeType)
    while (r = o[s++]) i = n.propFix[r] || r, n.expr.match.bool.test(r) && (e[i] = !1), e.removeAttribute(r)
  },
  attrHooks: {
   type: {
    set: function(e, t) {
     if (!k.radioValue && "radio" === t && n.nodeName(e, "input")) {
      var r = e.value;
      return e.setAttribute("type", t), r && (e.value = r), t
     }
    }
   }
  }
 }), Za = {
  set: function(e, t, r) {
   return t === !1 ? n.removeAttr(e, r) : e.setAttribute(r, r), r
  }
 }, n.each(n.expr.match.bool.source.match(/\w+/g), function(e, t) {
  var r = $a[t] || n.find.attr;
  $a[t] = function(e, t, n) {
   var i, s;
   return n || (s = $a[t], $a[t] = i, i = null != r(e, t, n) ? t.toLowerCase() : null, $a[t] = s), i
  }
 });
 var _a = /^(?:input|select|textarea|button)$/i;
 n.fn.extend({
  prop: function(e, t) {
   return J(this, n.prop, e, t, arguments.length > 1)
  },
  removeProp: function(e) {
   return this.each(function() {
    delete this[n.propFix[e] || e]
   })
  }
 }), n.extend({
  propFix: {
   "for": "htmlFor",
   "class": "className"
  },
  prop: function(e, t, r) {
   var i, s, o, u = e.nodeType;
   if (e && 3 !== u && 8 !== u && 2 !== u) return o = 1 !== u || !n.isXMLDoc(e), o && (t = n.propFix[t] || t, s = n.propHooks[t]), void 0 !== r ? s && "set" in s && void 0 !== (i = s.set(e, r, t)) ? i : e[t] = r : s && "get" in s && null !== (i = s.get(e, t)) ? i : e[t]
  },
  propHooks: {
   tabIndex: {
    get: function(e) {
     return e.hasAttribute("tabindex") || _a.test(e.nodeName) || e.href ? e.tabIndex : -1
    }
   }
  }
 }), k.optSelected || (n.propHooks.selected = {
  get: function(e) {
   var t = e.parentNode;
   return t && t.parentNode && t.parentNode.selectedIndex, null
  }
 }), n.each(["tabIndex", "readOnly", "maxLength", "cellSpacing", "cellPadding", "rowSpan", "colSpan", "useMap", "frameBorder", "contentEditable"], function() {
  n.propFix[this.toLowerCase()] = this
 });
 var ab = /[\t\r\n\f]/g;
 n.fn.extend({
  addClass: function(e) {
   var t, r, i, s, o, u, a = "string" == typeof e && e,
    f = 0,
    l = this.length;
   if (n.isFunction(e)) return this.each(function(t) {
    n(this).addClass(e.call(this, t, this.className))
   });
   if (a)
    for (t = (e || "").match(E) || []; l > f; f++)
     if (r = this[f], i = 1 === r.nodeType && (r.className ? (" " + r.className + " ").replace(ab, " ") : " ")) {
      o = 0;
      while (s = t[o++]) i.indexOf(" " + s + " ") < 0 && (i += s + " ");
      u = n.trim(i), r.className !== u && (r.className = u)
     } return this
  },
  removeClass: function(e) {
   var t, r, i, s, o, u, a = 0 === arguments.length || "string" == typeof e && e,
    f = 0,
    l = this.length;
   if (n.isFunction(e)) return this.each(function(t) {
    n(this).removeClass(e.call(this, t, this.className))
   });
   if (a)
    for (t = (e || "").match(E) || []; l > f; f++)
     if (r = this[f], i = 1 === r.nodeType && (r.className ? (" " + r.className + " ").replace(ab, " ") : "")) {
      o = 0;
      while (s = t[o++])
       while (i.indexOf(" " + s + " ") >= 0) i = i.replace(" " + s + " ", " ");
      u = e ? n.trim(i) : "", r.className !== u && (r.className = u)
     } return this
  },
  toggleClass: function(e, t) {
   var r = typeof e;
   return "boolean" == typeof t && "string" === r ? t ? this.addClass(e) : this.removeClass(e) : this.each(n.isFunction(e) ? function(r) {
    n(this).toggleClass(e.call(this, r, this.className, t), t)
   } : function() {
    if ("string" === r) {
     var t, i = 0,
      s = n(this),
      o = e.match(E) || [];
     while (t = o[i++]) s.hasClass(t) ? s.removeClass(t) : s.addClass(t)
    } else(r === U || "boolean" === r) && (this.className && L.set(this, "__className__", this.className), this.className = this.className || e === !1 ? "" : L.get(this, "__className__") || "")
   })
  },
  hasClass: function(e) {
   for (var t = " " + e + " ", n = 0, r = this.length; r > n; n++)
    if (1 === this[n].nodeType && (" " + this[n].className + " ").replace(ab, " ").indexOf(t) >= 0) return !0;
   return !1
  }
 });
 var bb = /\r/g;
 n.fn.extend({
  val: function(e) {
   var t, r, i, s = this[0];
   if (arguments.length) return i = n.isFunction(e), this.each(function(r) {
    var s;
    1 === this.nodeType && (s = i ? e.call(this, r, n(this).val()) : e, null == s ? s = "" : "number" == typeof s ? s += "" : n.isArray(s) && (s = n.map(s, function(e) {
     return null == e ? "" : e + ""
    })), t = n.valHooks[this.type] || n.valHooks[this.nodeName.toLowerCase()], t && "set" in t && void 0 !== t.set(this, s, "value") || (this.value = s))
   });
   if (s) return t = n.valHooks[s.type] || n.valHooks[s.nodeName.toLowerCase()], t && "get" in t && void 0 !== (r = t.get(s, "value")) ? r : (r = s.value, "string" == typeof r ? r.replace(bb, "") : null == r ? "" : r)
  }
 }), n.extend({
  valHooks: {
   option: {
    get: function(e) {
     var t = n.find.attr(e, "value");
     return null != t ? t : n.trim(n.text(e))
    }
   },
   select: {
    get: function(e) {
     for (var t, r, i = e.options, s = e.selectedIndex, o = "select-one" === e.type || 0 > s, u = o ? null : [], a = o ? s + 1 : i.length, f = 0 > s ? a : o ? s : 0; a > f; f++)
      if (r = i[f], !(!r.selected && f !== s || (k.optDisabled ? r.disabled : null !== r.getAttribute("disabled")) || r.parentNode.disabled && n.nodeName(r.parentNode, "optgroup"))) {
       if (t = n(r).val(), o) return t;
       u.push(t)
      } return u
    },
    set: function(e, t) {
     var r, i, s = e.options,
      o = n.makeArray(t),
      u = s.length;
     while (u--) i = s[u], (i.selected = n.inArray(i.value, o) >= 0) && (r = !0);
     return r || (e.selectedIndex = -1), o
    }
   }
  }
 }), n.each(["radio", "checkbox"], function() {
  n.valHooks[this] = {
   set: function(e, t) {
    return n.isArray(t) ? e.checked = n.inArray(n(e).val(), t) >= 0 : void 0
   }
  }, k.checkOn || (n.valHooks[this].get = function(e) {
   return null === e.getAttribute("value") ? "on" : e.value
  })
 }), n.each("blur focus focusin focusout load resize scroll unload click dblclick mousedown mouseup mousemove mouseover mouseout mouseenter mouseleave change select submit keydown keypress keyup error contextmenu".split(" "), function(e, t) {
  n.fn[t] = function(e, n) {
   return arguments.length > 0 ? this.on(t, null, e, n) : this.trigger(t)
  }
 }), n.fn.extend({
  hover: function(e, t) {
   return this.mouseenter(e).mouseleave(t || e)
  },
  bind: function(e, t, n) {
   return this.on(e, null, t, n)
  },
  unbind: function(e, t) {
   return this.off(e, null, t)
  },
  delegate: function(e, t, n, r) {
   return this.on(t, e, n, r)
  },
  undelegate: function(e, t, n) {
   return 1 === arguments.length ? this.off(e, "**") : this.off(t, e || "**", n)
  }
 });
 var cb = n.now(),
  db = /\?/;
 n.parseJSON = function(e) {
  return JSON.parse(e + "")
 }, n.parseXML = function(e) {
  var t, r;
  if (!e || "string" != typeof e) return null;
  try {
   r = new DOMParser, t = r.parseFromString(e, "text/xml")
  } catch (i) {
   t = void 0
  }
  return (!t || t.getElementsByTagName("parsererror").length) && n.error("Invalid XML: " + e), t
 };
 var eb = /#.*$/,
  fb = /([?&])_=[^&]*/,
  gb = /^(.*?):[ \t]*([^\r\n]*)$/gm,
  hb = /^(?:about|app|app-storage|.+-extension|file|res|widget):$/,
  ib = /^(?:GET|HEAD)$/,
  jb = /^\/\//,
  kb = /^([\w.+-]+:)(?:\/\/(?:[^\/?#]*@|)([^\/?#:]*)(?::(\d+)|)|)/,
  lb = {},
  mb = {},
  nb = "*/".concat("*"),
  ob = a.location.href,
  pb = kb.exec(ob.toLowerCase()) || [];
 n.extend({
  active: 0,
  lastModified: {},
  etag: {},
  ajaxSettings: {
   url: ob,
   type: "GET",
   isLocal: hb.test(pb[1]),
   global: !0,
   processData: !0,
   async: !0,
   contentType: "application/x-www-form-urlencoded; charset=UTF-8",
   accepts: {
    "*": nb,
    text: "text/plain",
    html: "text/html",
    xml: "application/xml, text/xml",
    json: "application/json, text/javascript"
   },
   contents: {
    xml: /xml/,
    html: /html/,
    json: /json/
   },
   responseFields: {
    xml: "responseXML",
    text: "responseText",
    json: "responseJSON"
   },
   converters: {
    "* text": String,
    "text html": !0,
    "text json": n.parseJSON,
    "text xml": n.parseXML
   },
   flatOptions: {
    url: !0,
    context: !0
   }
  },
  ajaxSetup: function(e, t) {
   return t ? sb(sb(e, n.ajaxSettings), t) : sb(n.ajaxSettings, e)
  },
  ajaxPrefilter: qb(lb),
  ajaxTransport: qb(mb),
  ajax: function(e, t) {
   function T(e, t, o, a) {
    var l, g, y, w, E, x = t;
    2 !== b && (b = 2, u && clearTimeout(u), r = void 0, s = a || "", S.readyState = e > 0 ? 4 : 0, l = e >= 200 && 300 > e || 304 === e, o && (w = tb(c, S, o)), w = ub(c, w, S, l), l ? (c.ifModified && (E = S.getResponseHeader("Last-Modified"), E && (n.lastModified[i] = E), E = S.getResponseHeader("etag"), E && (n.etag[i] = E)), 204 === e || "HEAD" === c.type ? x = "nocontent" : 304 === e ? x = "notmodified" : (x = w.state, g = w.data, y = w.error, l = !y)) : (y = x, (e || !x) && (x = "error", 0 > e && (e = 0))), S.status = e, S.statusText = (t || x) + "", l ? d.resolveWith(h, [g, x, S]) : d.rejectWith(h, [S, x, y]), S.statusCode(m), m = void 0, f && p.trigger(l ? "ajaxSuccess" : "ajaxError", [S, c, l ? g : y]), v.fireWith(h, [S, x]), f && (p.trigger("ajaxComplete", [S, c]), --n.active || n.event.trigger("ajaxStop")))
   }
   "object" == typeof e && (t = e, e = void 0), t = t || {};
   var r, i, s, o, u, a, f, l, c = n.ajaxSetup({}, t),
    h = c.context || c,
    p = c.context && (h.nodeType || h.jquery) ? n(h) : n.event,
    d = n.Deferred(),
    v = n.Callbacks("once memory"),
    m = c.statusCode || {},
    g = {},
    y = {},
    b = 0,
    w = "canceled",
    S = {
     readyState: 0,
     getResponseHeader: function(e) {
      var t;
      if (2 === b) {
       if (!o) {
        o = {};
        while (t = gb.exec(s)) o[t[1].toLowerCase()] = t[2]
       }
       t = o[e.toLowerCase()]
      }
      return null == t ? null : t
     },
     getAllResponseHeaders: function() {
      return 2 === b ? s : null
     },
     setRequestHeader: function(e, t) {
      var n = e.toLowerCase();
      return b || (e = y[n] = y[n] || e, g[e] = t), this
     },
     overrideMimeType: function(e) {
      return b || (c.mimeType = e), this
     },
     statusCode: function(e) {
      var t;
      if (e)
       if (2 > b)
        for (t in e) m[t] = [m[t], e[t]];
       else S.always(e[S.status]);
      return this
     },
     abort: function(e) {
      var t = e || w;
      return r && r.abort(t), T(0, t), this
     }
    };
   if (d.promise(S).complete = v.add, S.success = S.done, S.error = S.fail, c.url = ((e || c.url || ob) + "").replace(eb, "").replace(jb, pb[1] + "//"), c.type = t.method || t.type || c.method || c.type, c.dataTypes = n.trim(c.dataType || "*").toLowerCase().match(E) || [""], null == c.crossDomain && (a = kb.exec(c.url.toLowerCase()), c.crossDomain = !(!a || a[1] === pb[1] && a[2] === pb[2] && (a[3] || ("http:" === a[1] ? "80" : "443")) === (pb[3] || ("http:" === pb[1] ? "80" : "443")))), c.data && c.processData && "string" != typeof c.data && (c.data = n.param(c.data, c.traditional)), rb(lb, c, t, S), 2 === b) return S;
   f = n.event && c.global, f && 0 === n.active++ && n.event.trigger("ajaxStart"), c.type = c.type.toUpperCase(), c.hasContent = !ib.test(c.type), i = c.url, c.hasContent || (c.data && (i = c.url += (db.test(i) ? "&" : "?") + c.data, delete c.data), c.cache === !1 && (c.url = fb.test(i) ? i.replace(fb, "$1_=" + cb++) : i + (db.test(i) ? "&" : "?") + "_=" + cb++)), c.ifModified && (n.lastModified[i] && S.setRequestHeader("If-Modified-Since", n.lastModified[i]), n.etag[i] && S.setRequestHeader("If-None-Match", n.etag[i])), (c.data && c.hasContent && c.contentType !== !1 || t.contentType) && S.setRequestHeader("Content-Type", c.contentType), S.setRequestHeader("Accept", c.dataTypes[0] && c.accepts[c.dataTypes[0]] ? c.accepts[c.dataTypes[0]] + ("*" !== c.dataTypes[0] ? ", " + nb + "; q=0.01" : "") : c.accepts["*"]);
   for (l in c.headers) S.setRequestHeader(l, c.headers[l]);
   if (!c.beforeSend || c.beforeSend.call(h, S, c) !== !1 && 2 !== b) {
    w = "abort";
    for (l in {
      success: 1,
      error: 1,
      complete: 1
     }) S[l](c[l]);
    if (r = rb(mb, c, t, S)) {
     S.readyState = 1, f && p.trigger("ajaxSend", [S, c]), c.async && c.timeout > 0 && (u = setTimeout(function() {
      S.abort("timeout")
     }, c.timeout));
     try {
      b = 1, r.send(g, T)
     } catch (x) {
      if (!(2 > b)) throw x;
      T(-1, x)
     }
    } else T(-1, "No Transport");
    return S
   }
   return S.abort()
  },
  getJSON: function(e, t, r) {
   return n.get(e, t, r, "json")
  },
  getScript: function(e, t) {
   return n.get(e, void 0, t, "script")
  }
 }), n.each(["get", "post"], function(e, t) {
  n[t] = function(e, r, i, s) {
   return n.isFunction(r) && (s = s || i, i = r, r = void 0), n.ajax({
    url: e,
    type: t,
    dataType: s,
    data: r,
    success: i
   })
  }
 }), n._evalUrl = function(e) {
  return n.ajax({
   url: e,
   type: "GET",
   dataType: "script",
   async: !1,
   global: !1,
   "throws": !0
  })
 }, n.fn.extend({
  wrapAll: function(e) {
   var t;
   return n.isFunction(e) ? this.each(function(t) {
    n(this).wrapAll(e.call(this, t))
   }) : (this[0] && (t = n(e, this[0].ownerDocument).eq(0).clone(!0), this[0].parentNode && t.insertBefore(this[0]), t.map(function() {
    var e = this;
    while (e.firstElementChild) e = e.firstElementChild;
    return e
   }).append(this)), this)
  },
  wrapInner: function(e) {
   return this.each(n.isFunction(e) ? function(t) {
    n(this).wrapInner(e.call(this, t))
   } : function() {
    var t = n(this),
     r = t.contents();
    r.length ? r.wrapAll(e) : t.append(e)
   })
  },
  wrap: function(e) {
   var t = n.isFunction(e);
   return this.each(function(r) {
    n(this).wrapAll(t ? e.call(this, r) : e)
   })
  },
  unwrap: function() {
   return this.parent().each(function() {
    n.nodeName(this, "body") || n(this).replaceWith(this.childNodes)
   }).end()
  }
 }), n.expr.filters.hidden = function(e) {
  return e.offsetWidth <= 0 && e.offsetHeight <= 0
 }, n.expr.filters.visible = function(e) {
  return !n.expr.filters.hidden(e)
 };
 var vb = /%20/g,
  wb = /\[\]$/,
  xb = /\r?\n/g,
  yb = /^(?:submit|button|image|reset|file)$/i,
  zb = /^(?:input|select|textarea|keygen)/i;
 n.param = function(e, t) {
  var r, i = [],
   s = function(e, t) {
    t = n.isFunction(t) ? t() : null == t ? "" : t, i[i.length] = encodeURIComponent(e) + "=" + encodeURIComponent(t)
   };
  if (void 0 === t && (t = n.ajaxSettings && n.ajaxSettings.traditional), n.isArray(e) || e.jquery && !n.isPlainObject(e)) n.each(e, function() {
   s(this.name, this.value)
  });
  else
   for (r in e) Ab(r, e[r], t, s);
  return i.join("&").replace(vb, "+")
 }, n.fn.extend({
  serialize: function() {
   return n.param(this.serializeArray())
  },
  serializeArray: function() {
   return this.map(function() {
    var e = n.prop(this, "elements");
    return e ? n.makeArray(e) : this
   }).filter(function() {
    var e = this.type;
    return this.name && !n(this).is(":disabled") && zb.test(this.nodeName) && !yb.test(e) && (this.checked || !T.test(e))
   }).map(function(e, t) {
    var r = n(this).val();
    return null == r ? null : n.isArray(r) ? n.map(r, function(e) {
     return {
      name: t.name,
      value: e.replace(xb, "\r\n")
     }
    }) : {
     name: t.name,
     value: r.replace(xb, "\r\n")
    }
   }).get()
  }
 }), n.ajaxSettings.xhr = function() {
  try {
   return new XMLHttpRequest
  } catch (e) {}
 };
 var Bb = 0,
  Cb = {},
  Db = {
   0: 200,
   1223: 204
  },
  Eb = n.ajaxSettings.xhr();
 a.attachEvent && a.attachEvent("onunload", function() {
  for (var e in Cb) Cb[e]()
 }), k.cors = !!Eb && "withCredentials" in Eb, k.ajax = Eb = !!Eb, n.ajaxTransport(function(e) {
  var t;
  return k.cors || Eb && !e.crossDomain ? {
   send: function(n, r) {
    var i, s = e.xhr(),
     o = ++Bb;
    if (s.open(e.type, e.url, e.async, e.username, e.password), e.xhrFields)
     for (i in e.xhrFields) s[i] = e.xhrFields[i];
    e.mimeType && s.overrideMimeType && s.overrideMimeType(e.mimeType), e.crossDomain || n["X-Requested-With"] || (n["X-Requested-With"] = "XMLHttpRequest");
    for (i in n) s.setRequestHeader(i, n[i]);
    t = function(e) {
     return function() {
      t && (delete Cb[o], t = s.onload = s.onerror = null, "abort" === e ? s.abort() : "error" === e ? r(s.status, s.statusText) : r(Db[s.status] || s.status, s.statusText, "string" == typeof s.responseText ? {
       text: s.responseText
      } : void 0, s.getAllResponseHeaders()))
     }
    }, s.onload = t(), s.onerror = t("error"), t = Cb[o] = t("abort");
    try {
     s.send(e.hasContent && e.data || null)
    } catch (u) {
     if (t) throw u
    }
   },
   abort: function() {
    t && t()
   }
  } : void 0
 }), n.ajaxSetup({
  accepts: {
   script: "text/javascript, application/javascript, application/ecmascript, application/x-ecmascript"
  },
  contents: {
   script: /(?:java|ecma)script/
  },
  converters: {
   "text script": function(e) {
    return n.globalEval(e), e
   }
  }
 }), n.ajaxPrefilter("script", function(e) {
  void 0 === e.cache && (e.cache = !1), e.crossDomain && (e.type = "GET")
 }), n.ajaxTransport("script", function(e) {
  if (e.crossDomain) {
   var t, r;
   return {
    send: function(i, s) {
     t = n("<script>").prop({
      async: !0,
      charset: e.scriptCharset,
      src: e.url
     }).on("load error", r = function(e) {
      t.remove(), r = null, e && s("error" === e.type ? 404 : 200, e.type)
     }), l.head.appendChild(t[0])
    },
    abort: function() {
     r && r()
    }
   }
  }
 });
 var Fb = [],
  Gb = /(=)\?(?=&|$)|\?\?/;
 n.ajaxSetup({
  jsonp: "callback",
  jsonpCallback: function() {
   var e = Fb.pop() || n.expando + "_" + cb++;
   return this[e] = !0, e
  }
 }), n.ajaxPrefilter("json jsonp", function(e, t, r) {
  var i, s, o, u = e.jsonp !== !1 && (Gb.test(e.url) ? "url" : "string" == typeof e.data && !(e.contentType || "").indexOf("application/x-www-form-urlencoded") && Gb.test(e.data) && "data");
  return u || "jsonp" === e.dataTypes[0] ? (i = e.jsonpCallback = n.isFunction(e.jsonpCallback) ? e.jsonpCallback() : e.jsonpCallback, u ? e[u] = e[u].replace(Gb, "$1" + i) : e.jsonp !== !1 && (e.url += (db.test(e.url) ? "&" : "?") + e.jsonp + "=" + i), e.converters["script json"] = function() {
   return o || n.error(i + " was not called"), o[0]
  }, e.dataTypes[0] = "json", s = a[i], a[i] = function() {
   o = arguments
  }, r.always(function() {
   a[i] = s, e[i] && (e.jsonpCallback = t.jsonpCallback, Fb.push(i)), o && n.isFunction(s) && s(o[0]), o = s = void 0
  }), "script") : void 0
 }), n.parseHTML = function(e, t, r) {
  if (!e || "string" != typeof e) return null;
  "boolean" == typeof t && (r = t, t = !1), t = t || l;
  var i = v.exec(e),
   s = !r && [];
  return i ? [t.createElement(i[1])] : (i = n.buildFragment([e], t, s), s && s.length && n(s).remove(), n.merge([], i.childNodes))
 };
 var Hb = n.fn.load;
 n.fn.load = function(e, t, r) {
  if ("string" != typeof e && Hb) return Hb.apply(this, arguments);
  var i, s, o, u = this,
   a = e.indexOf(" ");
  return a >= 0 && (i = n.trim(e.slice(a)), e = e.slice(0, a)), n.isFunction(t) ? (r = t, t = void 0) : t && "object" == typeof t && (s = "POST"), u.length > 0 && n.ajax({
   url: e,
   type: s,
   dataType: "html",
   data: t
  }).done(function(e) {
   o = arguments, u.html(i ? n("<div>").append(n.parseHTML(e)).find(i) : e)
  }).complete(r && function(e, t) {
   u.each(r, o || [e.responseText, t, e])
  }), this
 }, n.each(["ajaxStart", "ajaxStop", "ajaxComplete", "ajaxError", "ajaxSuccess", "ajaxSend"], function(e, t) {
  n.fn[t] = function(e) {
   return this.on(t, e)
  }
 }), n.expr.filters.animated = function(e) {
  return n.grep(n.timers, function(t) {
   return e === t.elem
  }).length
 };
 var Ib = a.document.documentElement;
 n.offset = {
  setOffset: function(e, t, r) {
   var i, s, o, u, a, f, l, c = n.css(e, "position"),
    h = n(e),
    p = {};
   "static" === c && (e.style.position = "relative"), a = h.offset(), o = n.css(e, "top"), f = n.css(e, "left"), l = ("absolute" === c || "fixed" === c) && (o + f).indexOf("auto") > -1, l ? (i = h.position(), u = i.top, s = i.left) : (u = parseFloat(o) || 0, s = parseFloat(f) || 0), n.isFunction(t) && (t = t.call(e, r, a)), null != t.top && (p.top = t.top - a.top + u), null != t.left && (p.left = t.left - a.left + s), "using" in t ? t.using.call(e, p) : h.css(p)
  }
 }, n.fn.extend({
  offset: function(e) {
   if (arguments.length) return void 0 === e ? this : this.each(function(t) {
    n.offset.setOffset(this, e, t)
   });
   var t, r, i = this[0],
    s = {
     top: 0,
     left: 0
    },
    o = i && i.ownerDocument;
   if (o) return t = o.documentElement, n.contains(t, i) ? (typeof i.getBoundingClientRect !== U && (s = i.getBoundingClientRect()), r = Jb(o), {
    top: s.top + r.pageYOffset - t.clientTop,
    left: s.left + r.pageXOffset - t.clientLeft
   }) : s
  },
  position: function() {
   if (this[0]) {
    var e, t, r = this[0],
     i = {
      top: 0,
      left: 0
     };
    return "fixed" === n.css(r, "position") ? t = r.getBoundingClientRect() : (e = this.offsetParent(), t = this.offset(), n.nodeName(e[0], "html") || (i = e.offset()), i.top += n.css(e[0], "borderTopWidth", !0), i.left += n.css(e[0], "borderLeftWidth", !0)), {
     top: t.top - i.top - n.css(r, "marginTop", !0),
     left: t.left - i.left - n.css(r, "marginLeft", !0)
    }
   }
  },
  offsetParent: function() {
   return this.map(function() {
    var e = this.offsetParent || Ib;
    while (e && !n.nodeName(e, "html") && "static" === n.css(e, "position")) e = e.offsetParent;
    return e || Ib
   })
  }
 }), n.each({
  scrollLeft: "pageXOffset",
  scrollTop: "pageYOffset"
 }, function(e, t) {
  var r = "pageYOffset" === t;
  n.fn[e] = function(n) {
   return J(this, function(e, n, i) {
    var s = Jb(e);
    return void 0 === i ? s ? s[t] : e[n] : void(s ? s.scrollTo(r ? a.pageXOffset : i, r ? i : a.pageYOffset) : e[n] = i)
   }, e, n, arguments.length, null)
  }
 }), n.each(["top", "left"], function(e, t) {
  n.cssHooks[t] = ya(k.pixelPosition, function(e, r) {
   return r ? (r = xa(e, t), va.test(r) ? n(e).position()[t] + "px" : r) : void 0
  })
 }), n.each({
  Height: "height",
  Width: "width"
 }, function(e, t) {
  n.each({
   padding: "inner" + e,
   content: t,
   "": "outer" + e
  }, function(r, i) {
   n.fn[i] = function(i, s) {
    var o = arguments.length && (r || "boolean" != typeof i),
     u = r || (i === !0 || s === !0 ? "margin" : "border");
    return J(this, function(t, r, i) {
     var s;
     return n.isWindow(t) ? t.document.documentElement["client" + e] : 9 === t.nodeType ? (s = t.documentElement, Math.max(t.body["scroll" + e], s["scroll" + e], t.body["offset" + e], s["offset" + e], s["client" + e])) : void 0 === i ? n.css(t, r, u) : n.style(t, r, i, u)
    }, t, o ? i : void 0, o, null)
   }
  })
 }), n.fn.size = function() {
  return this.length
 }, n.fn.andSelf = n.fn.addBack, "function" == typeof define && define.amd && define("jquery", [], function() {
  return n
 });
 var Kb = a.jQuery,
  Lb = a.$;
 return n.noConflict = function(e) {
  return a.$ === n && (a.$ = Lb), e && a.jQuery === n && (a.jQuery = Kb), n
 }, typeof b === U && (a.jQuery = a.$ = n), n
}),
function(e) {
 typeof define == "function" && define.amd ? define(["jquery"], e) : typeof exports == "object" ? e(require("jquery")) : e(jQuery)
}(function(e) {
 function n(e) {
  return u.raw ? e : encodeURIComponent(e)
 }

 function r(e) {
  return u.raw ? e : decodeURIComponent(e)
 }

 function i(e) {
  return n(u.json ? JSON.stringify(e) : String(e))
 }

 function s(e) {
  e.indexOf('"') === 0 && (e = e.slice(1, -1).replace(/\\"/g, '"').replace(/\\\\/g, "\\"));
  try {
   return e = decodeURIComponent(e.replace(t, " ")), u.json ? JSON.parse(e) : e
  } catch (n) {}
 }

 function o(t, n) {
  var r = u.raw ? t : s(t);
  return e.isFunction(n) ? n(r) : r
 }
 var t = /\+/g,
  u = e.cookie = function(t, s, a) {
   if (s !== undefined && !e.isFunction(s)) {
    a = e.extend({}, u.defaults, a);
    if (typeof a.expires == "number") {
     var f = a.expires,
      l = a.expires = new Date;
     l.setTime(+l + f * 864e5)
    }
    return document.cookie = [n(t), "=", i(s), a.expires ? "; expires=" + a.expires.toUTCString() : "", a.path ? "; path=" + a.path : "", a.domain ? "; domain=" + a.domain : "", a.secure ? "; secure" : ""].join("")
   }
   var c = t ? undefined : {},
    h = document.cookie ? document.cookie.split("; ") : [];
   for (var p = 0, d = h.length; p < d; p++) {
    var v = h[p].split("="),
     m = r(v.shift()),
     g = v.join("=");
    if (t && t === m) {
     c = o(g, s);
     break
    }!t && (g = o(g)) !== undefined && (c[m] = g)
   }
   return c
  };
 u.defaults = {}, e.removeCookie = function(t, n) {
  return e.cookie(t) === undefined ? !1 : (e.cookie(t, "", e.extend({}, n, {
   expires: -1
  })), !e.cookie(t))
 }
}),
function() {
 function e(e, t) {
  if (e !== t) {
   var n = null === e,
    r = e === w,
    i = e === e,
    s = null === t,
    o = t === w,
    u = t === t;
   if (e > t && !s || !i || n && !o && u || r && u) return 1;
   if (e < t && !n || !u || s && !r && i || o && i) return -1
  }
  return 0
 }

 function t(e, t, n) {
  for (var r = e.length, i = n ? r : -1; n ? i-- : ++i < r;)
   if (t(e[i], i, e)) return i;
  return -1
 }

 function n(e, t, n) {
  if (t !== t) return h(e, n);
  n -= 1;
  for (var r = e.length; ++n < r;)
   if (e[n] === t) return n;
  return -1
 }

 function r(e) {
  return typeof e == "function" || !1
 }

 function i(e) {
  return null == e ? "" : e + ""
 }

 function s(e, t) {
  for (var n = -1, r = e.length; ++n < r && -1 < t.indexOf(e.charAt(n)););
  return n
 }

 function o(e, t) {
  for (var n = e.length; n-- && -1 < t.indexOf(e.charAt(n)););
  return n
 }

 function u(t, n) {
  return e(t.a, n.a) || t.b - n.b
 }

 function a(e) {
  return Ht[e]
 }

 function f(e) {
  return Bt[e]
 }

 function l(e, t, n) {
  return t ? e = It[e] : n && (e = qt[e]), "\\" + e
 }

 function c(e) {
  return "\\" + qt[e]
 }

 function h(e, t, n) {
  var r = e.length;
  for (t += n ? 0 : -1; n ? t-- : ++t < r;) {
   var i = e[t];
   if (i !== i) return t
  }
  return -1
 }

 function p(e) {
  return !!e && typeof e == "object"
 }

 function d(e) {
  return 160 >= e && 9 <= e && 13 >= e || 32 == e || 160 == e || 5760 == e || 6158 == e || 8192 <= e && (8202 >= e || 8232 == e || 8233 == e || 8239 == e || 8287 == e || 12288 == e || 65279 == e)
 }

 function v(e, t) {
  for (var n = -1, r = e.length, i = -1, s = []; ++n < r;) e[n] === t && (e[n] = I, s[++i] = n);
  return s
 }

 function m(e) {
  for (var t = -1, n = e.length; ++t < n && d(e.charCodeAt(t)););
  return t
 }

 function g(e) {
  for (var t = e.length; t-- && d(e.charCodeAt(t)););
  return t
 }

 function y(e) {
  return jt[e]
 }

 function b(d) {
  function Ht(e) {
   if (p(e) && !(cu(e) || e instanceof Ft)) {
    if (e instanceof jt) return e;
    if (js.call(e, "__chain__") && js.call(e, "__wrapped__")) return Ni(e)
   }
   return new jt(e)
  }

  function Bt() {}

  function jt(e, t, n) {
   this.__wrapped__ = e, this.__actions__ = n || [], this.__chain__ = !!t
  }

  function Ft(e) {
   this.__wrapped__ = e, this.__actions__ = [], this.__dir__ = 1, this.__filtered__ = !1, this.__iteratees__ = [], this.__takeCount__ = lo, this.__views__ = []
  }

  function It() {
   this.__data__ = {}
  }

  function qt(e) {
   var t = e ? e.length : 0;
   for (this.data = {
     hash: Zs(null),
     set: new $s
    }; t--;) this.push(e[t])
  }

  function Rt(e, t) {
   var n = e.data;
   return (typeof t == "string" || Zi(t) ? n.set.has(t) : n.hash[t]) ? 0 : -1
  }

  function Ut(e, t) {
   var n = -1,
    r = e.length;
   for (t || (t = xs(r)); ++n < r;) t[n] = e[n];
   return t
  }

  function zt(e, t) {
   for (var n = -1, r = e.length; ++n < r && !1 !== t(e[n], n, e););
   return e
  }

  function Wt(e, t) {
   for (var n = -1, r = e.length; ++n < r;)
    if (!t(e[n], n, e)) return !1;
   return !0
  }

  function Xt(e, t) {
   for (var n = -1, r = e.length, i = -1, s = []; ++n < r;) {
    var o = e[n];
    t(o, n, e) && (s[++i] = o)
   }
   return s
  }

  function Jt(e, t) {
   for (var n = -1, r = e.length, i = xs(r); ++n < r;) i[n] = t(e[n], n, e);
   return i
  }

  function Kt(e, t) {
   for (var n = -1, r = t.length, i = e.length; ++n < r;) e[i + n] = t[n];
   return e
  }

  function Qt(e, t, n, r) {
   var i = -1,
    s = e.length;
   for (r && s && (n = e[++i]); ++i < s;) n = t(n, e[i], i, e);
   return n
  }

  function Gt(e, t) {
   for (var n = -1, r = e.length; ++n < r;)
    if (t(e[n], n, e)) return !0;
   return !1
  }

  function Yt(e, t, n, r) {
   return e !== w && js.call(r, n) ? e : t
  }

  function Zt(e, t, n) {
   for (var r = -1, i = Su(t), s = i.length; ++r < s;) {
    var o = i[r],
     u = e[o],
     a = n(u, t[o], o, e, t);
    (a === a ? a === u : u !== u) && (u !== w || o in e) || (e[o] = a)
   }
   return e
  }

  function Tn(e, t) {
   return null == t ? e : Ln(t, Su(t), e)
  }

  function Nn(e, t) {
   for (var n = -1, r = null == e, i = !r && hi(e), s = i ? e.length : 0, o = t.length, u = xs(o); ++n < o;) {
    var a = t[n];
    u[n] = i ? pi(a, s) ? e[a] : w : r ? w : e[a]
   }
   return u
  }

  function Ln(e, t, n) {
   n || (n = {});
   for (var r = -1, i = t.length; ++r < i;) {
    var s = t[r];
    n[s] = e[s]
   }
   return n
  }

  function Mn(e, t, n) {
   var r = typeof e;
   return "function" == r ? t === w ? e : xr(e, t, n) : null == e ? ys : "object" == r ? ir(e) : t === w ? Ss(e) : sr(e, t)
  }

  function Dn(e, t, n, r, i, s, o) {
   var u;
   if (n && (u = i ? n(e, r, i) : n(e)), u !== w) return u;
   if (!Zi(e)) return e;
   if (r = cu(e)) {
    if (u = ai(e), !t) return Ut(e, u)
   } else {
    var a = Is.call(e),
     f = a == X;
    if (a != $ && a != q && (!f || i)) return Pt[a] ? li(e, a, t) : i ? e : {};
    if (u = fi(f ? {} : e), !t) return Tn(u, e)
   }
   for (s || (s = []), o || (o = []), i = s.length; i--;)
    if (s[i] == e) return o[i];
   return s.push(e), o.push(u), (r ? zt : Kn)(e, function(r, i) {
    u[i] = Dn(r, t, n, i, e, s, o)
   }), u
  }

  function Pn(e, t, n) {
   if (typeof e != "function") throw new _s(F);
   return Js(function() {
    e.apply(w, n)
   }, t)
  }

  function Hn(e, t) {
   var r = e ? e.length : 0,
    i = [];
   if (!r) return i;
   var s = -1,
    o = si(),
    u = o === n,
    a = u && t.length >= H && Zs && $s ? new qt(t) : null,
    f = t.length;
   a && (o = Rt, u = !1, t = a);
   e: for (; ++s < r;)
    if (a = e[s], u && a === a) {
     for (var l = f; l--;)
      if (t[l] === a) continue e;
     i.push(a)
    } else 0 > o(t, a, 0) && i.push(a);
   return i
  }

  function Bn(e, t) {
   var n = !0;
   return yo(e, function(e, r, i) {
    return n = !!t(e, r, i)
   }), n
  }

  function qn(e, t, n, r) {
   var i = r,
    s = i;
   return yo(e, function(e, o, u) {
    o = +t(e, o, u), (n(o, i) || o === r && o === s) && (i = o, s = e)
   }), s
  }

  function zn(e, t) {
   var n = [];
   return yo(e, function(e, r, i) {
    t(e, r, i) && n.push(e)
   }), n
  }

  function Xn(e, t, n, r) {
   var i;
   return n(e, function(e, n, s) {
    return t(e, n, s) ? (i = r ? n : e, !1) : void 0
   }), i
  }

  function Vn(e, t, n, r) {
   r || (r = []);
   for (var i = -1, s = e.length; ++i < s;) {
    var o = e[i];
    p(o) && hi(o) && (n || cu(o) || Ki(o)) ? t ? Vn(o, t, n, r) : Kt(r, o) : n || (r[r.length] = o)
   }
   return r
  }

  function Jn(e, t) {
   wo(e, t, ls)
  }

  function Kn(e, t) {
   return wo(e, t, Su)
  }

  function Qn(e, t) {
   return Eo(e, t, Su)
  }

  function Gn(e, t) {
   for (var n = -1, r = t.length, i = -1, s = []; ++n < r;) {
    var o = t[n];
    Yi(e[o]) && (s[++i] = o)
   }
   return s
  }

  function er(e, t, n) {
   if (null != e) {
    n !== w && n in xi(e) && (t = [n]), n = 0;
    for (var r = t.length; null != e && n < r;) e = e[t[n++]];
    return n && n == r ? e : w
   }
  }

  function tr(e, t, n, r, i, s) {
   if (e === t) e = !0;
   else if (null == e || null == t || !Zi(e) && !p(t)) e = e !== e && t !== t;
   else e: {
    var o = tr,
     u = cu(e),
     a = cu(t),
     f = R,
     l = R;u || (f = Is.call(e), f == q ? f = $ : f != $ && (u = ss(e))),
    a || (l = Is.call(t), l == q ? l = $ : l != $ && ss(t));
    var c = f == $,
     a = l == $,
     l = f == l;
    if (!l || u || c) {
     if (!r && (f = c && js.call(e, "__wrapped__"), a = a && js.call(t, "__wrapped__"), f || a)) {
      e = o(f ? e.value() : e, a ? t.value() : t, n, r, i, s);
      break e
     }
     if (l) {
      for (i || (i = []), s || (s = []), f = i.length; f--;)
       if (i[f] == e) {
        e = s[f] == t;
        break e
       } i.push(e), s.push(t), e = (u ? ei : ni)(e, t, o, n, r, i, s), i.pop(), s.pop()
     } else e = !1
    } else e = ti(e, t, f)
   }
   return e
  }

  function nr(e, t, n) {
   var r = t.length,
    i = r,
    s = !n;
   if (null == e) return !i;
   for (e = xi(e); r--;) {
    var o = t[r];
    if (s && o[2] ? o[1] !== e[o[0]] : !(o[0] in e)) return !1
   }
   for (; ++r < i;) {
    var o = t[r],
     u = o[0],
     a = e[u],
     f = o[1];
    if (s && o[2]) {
     if (a === w && !(u in e)) return !1
    } else if (o = n ? n(a, f, u) : w, o === w ? !tr(f, a, n, !0) : !o) return !1
   }
   return !0
  }

  function rr(e, t) {
   var n = -1,
    r = hi(e) ? xs(e.length) : [];
   return yo(e, function(e, i, s) {
    r[++n] = t(e, i, s)
   }), r
  }

  function ir(e) {
   var t = oi(e);
   if (1 == t.length && t[0][2]) {
    var n = t[0][0],
     r = t[0][1];
    return function(e) {
     return null == e ? !1 : e[n] === r && (r !== w || n in xi(e))
    }
   }
   return function(e) {
    return nr(e, t)
   }
  }

  function sr(e, t) {
   var n = cu(e),
    r = vi(e) && t === t && !Zi(t),
    i = e + "";
   return e = Ti(e),
    function(s) {
     if (null == s) return !1;
     var o = i;
     if (s = xi(s), !(!n && r || o in s)) {
      if (s = 1 == e.length ? s : er(s, hr(e, 0, -1)), null == s) return !1;
      o = Oi(e), s = xi(s)
     }
     return s[o] === t ? t !== w || o in s : tr(t, s[o], w, !0)
    }
  }

  function or(e, t, n, r, i) {
   if (!Zi(e)) return e;
   var s = hi(t) && (cu(t) || ss(t)),
    o = s ? w : Su(t);
   return zt(o || t, function(u, a) {
    if (o && (a = u, u = t[a]), p(u)) {
     r || (r = []), i || (i = []);
     e: {
      for (var f = a, l = r, c = i, h = l.length, d = t[f]; h--;)
       if (l[h] == d) {
        e[f] = c[h];
        break e
       } var h = e[f],
       v = n ? n(h, d, f, e, t) : w,
       m = v === w;m && (v = d, hi(d) && (cu(d) || ss(d)) ? v = cu(h) ? h : hi(h) ? Ut(h) : [] : ns(d) || Ki(d) ? v = Ki(h) ? as(h) : ns(h) ? h : {} : m = !1),
      l.push(d),
      c.push(v),
      m ? e[f] = or(v, d, n, l, c) : (v === v ? v !== h : h === h) && (e[f] = v)
     }
    } else f = e[a], l = n ? n(f, u, a, e, t) : w, (c = l === w) && (l = u), l === w && (!s || a in e) || !c && (l === l ? l === f : f !== f) || (e[a] = l)
   }), e
  }

  function ur(e) {
   return function(t) {
    return null == t ? w : t[e]
   }
  }

  function ar(e) {
   var t = e + "";
   return e = Ti(e),
    function(n) {
     return er(n, e, t)
    }
  }

  function fr(e, t) {
   for (var n = e ? t.length : 0; n--;) {
    var r = t[n];
    if (r != i && pi(r)) {
     var i = r;
     Ks.call(e, r, 1)
    }
   }
  }

  function lr(e, t) {
   return e + eo(ao() * (t - e + 1))
  }

  function cr(e, t, n, r, i) {
   return i(e, function(e, i, s) {
    n = r ? (r = !1, e) : t(n, e, i, s)
   }), n
  }

  function hr(e, t, n) {
   var r = -1,
    i = e.length;
   for (t = null == t ? 0 : +t || 0, 0 > t && (t = -t > i ? 0 : i + t), n = n === w || n > i ? i : +n || 0, 0 > n && (n += i), i = t > n ? 0 : n - t >>> 0, t >>>= 0, n = xs(i); ++r < i;) n[r] = e[r + t];
   return n
  }

  function pr(e, t) {
   var n;
   return yo(e, function(e, r, i) {
    return n = t(e, r, i), !n
   }), !!n
  }

  function dr(e, t) {
   var n = e.length;
   for (e.sort(t); n--;) e[n] = e[n].c;
   return e
  }

  function vr(t, n, r) {
   var i = ri(),
    s = -1;
   return n = Jt(n, function(e) {
    return i(e)
   }), t = rr(t, function(e) {
    return {
     a: Jt(n, function(t) {
      return t(e)
     }),
     b: ++s,
     c: e
    }
   }), dr(t, function(t, n) {
    var i;
    e: {
     for (var s = -1, o = t.a, u = n.a, a = o.length, f = r.length; ++s < a;)
      if (i = e(o[s], u[s])) {
       if (s >= f) break e;
       s = r[s], i *= "asc" === s || !0 === s ? 1 : -1;
       break e
      } i = t.b - n.b
    }
    return i
   })
  }

  function mr(e, t) {
   var n = 0;
   return yo(e, function(e, r, i) {
    n += +t(e, r, i) || 0
   }), n
  }

  function gr(e, t) {
   var r = -1,
    i = si(),
    s = e.length,
    o = i === n,
    u = o && s >= H,
    a = u && Zs && $s ? new qt(void 0) : null,
    f = [];
   a ? (i = Rt, o = !1) : (u = !1, a = t ? [] : f);
   e: for (; ++r < s;) {
    var l = e[r],
     c = t ? t(l, r, e) : l;
    if (o && l === l) {
     for (var h = a.length; h--;)
      if (a[h] === c) continue e;
     t && a.push(c), f.push(l)
    } else 0 > i(a, c, 0) && ((t || u) && a.push(c), f.push(l))
   }
   return f
  }

  function yr(e, t) {
   for (var n = -1, r = t.length, i = xs(r); ++n < r;) i[n] = e[t[n]];
   return i
  }

  function br(e, t, n, r) {
   for (var i = e.length, s = r ? i : -1;
    (r ? s-- : ++s < i) && t(e[s], s, e););
   return n ? hr(e, r ? 0 : s, r ? s + 1 : i) : hr(e, r ? s + 1 : 0, r ? i : s)
  }

  function wr(e, t) {
   var n = e;
   n instanceof Ft && (n = n.value());
   for (var r = -1, i = t.length; ++r < i;) var s = t[r],
    n = s.func.apply(s.thisArg, Kt([n], s.args));
   return n
  }

  function Er(e, t, n) {
   var r = 0,
    i = e ? e.length : r;
   if (typeof t == "number" && t === t && i <= ho) {
    for (; r < i;) {
     var s = r + i >>> 1,
      o = e[s];
     (n ? o <= t : o < t) && null !== o ? r = s + 1 : i = s
    }
    return i
   }
   return Sr(e, t, ys, n)
  }

  function Sr(e, t, n, r) {
   t = n(t);
   for (var i = 0, s = e ? e.length : 0, o = t !== t, u = null === t, a = t === w; i < s;) {
    var f = eo((i + s) / 2),
     l = n(e[f]),
     c = l !== w,
     h = l === l;
    (o ? h || r : u ? h && c && (r || null != l) : a ? h && (r || c) : null == l ? 0 : r ? l <= t : l < t) ? i = f + 1: s = f
   }
   return so(s, co)
  }

  function xr(e, t, n) {
   if (typeof e != "function") return ys;
   if (t === w) return e;
   switch (n) {
    case 1:
     return function(n) {
      return e.call(t, n)
     };
    case 3:
     return function(n, r, i) {
      return e.call(t, n, r, i)
     };
    case 4:
     return function(n, r, i, s) {
      return e.call(t, n, r, i, s)
     };
    case 5:
     return function(n, r, i, s, o) {
      return e.call(t, n, r, i, s, o)
     }
   }
   return function() {
    return e.apply(t, arguments)
   }
  }

  function Tr(e) {
   var t = new Us(e.byteLength);
   return (new Qs(t)).set(new Qs(e)), t
  }

  function Nr(e, t, n) {
   for (var r = n.length, i = -1, s = io(e.length - r, 0), o = -1, u = t.length, a = xs(u + s); ++o < u;) a[o] = t[o];
   for (; ++i < r;) a[n[i]] = e[i];
   for (; s--;) a[o++] = e[i++];
   return a
  }

  function Cr(e, t, n) {
   for (var r = -1, i = n.length, s = -1, o = io(e.length - i, 0), u = -1, a = t.length, f = xs(o + a); ++s < o;) f[s] = e[s];
   for (o = s; ++u < a;) f[o + u] = t[u];
   for (; ++r < i;) f[o + n[r]] = e[s++];
   return f
  }

  function kr(e, t) {
   return function(n, r, i) {
    var s = t ? t() : {};
    if (r = ri(r, i, 3), cu(n)) {
     i = -1;
     for (var o = n.length; ++i < o;) {
      var u = n[i];
      e(s, u, r(u, i, n), n)
     }
    } else yo(n, function(t, n, i) {
     e(s, t, r(t, n, i), i)
    });
    return s
   }
  }

  function Lr(e) {
   return $i(function(t, n) {
    var r = -1,
     i = null == t ? 0 : n.length,
     s = 2 < i ? n[i - 2] : w,
     o = 2 < i ? n[2] : w,
     u = 1 < i ? n[i - 1] : w;
    for (typeof s == "function" ? (s = xr(s, u, 5), i -= 2) : (s = typeof u == "function" ? u : w, i -= s ? 1 : 0), o && di(n[0], n[1], o) && (s = 3 > i ? w : s, i = 1); ++r < i;)(o = n[r]) && e(t, o, s);
    return t
   })
  }

  function Ar(e, t) {
   return function(n, r) {
    var i = n ? To(n) : 0;
    if (!gi(i)) return e(n, r);
    for (var s = t ? i : -1, o = xi(n);
     (t ? s-- : ++s < i) && !1 !== r(o[s], s, o););
    return n
   }
  }

  function Or(e) {
   return function(t, n, r) {
    var i = xi(t);
    r = r(t);
    for (var s = r.length, o = e ? s : -1; e ? o-- : ++o < s;) {
     var u = r[o];
     if (!1 === n(i[u], u, i)) break
    }
    return t
   }
  }

  function Mr(e, t) {
   function n() {
    return (this && this !== Vt && this instanceof n ? r : e).apply(t, arguments)
   }
   var r = Dr(e);
   return n
  }

  function _r(e) {
   return function(t) {
    var n = -1;
    t = ms(ps(t));
    for (var r = t.length, i = ""; ++n < r;) i = e(i, t[n], n);
    return i
   }
  }

  function Dr(e) {
   return function() {
    var t = arguments;
    switch (t.length) {
     case 0:
      return new e;
     case 1:
      return new e(t[0]);
     case 2:
      return new e(t[0], t[1]);
     case 3:
      return new e(t[0], t[1], t[2]);
     case 4:
      return new e(t[0], t[1], t[2], t[3]);
     case 5:
      return new e(t[0], t[1], t[2], t[3], t[4]);
     case 6:
      return new e(t[0], t[1], t[2], t[3], t[4], t[5]);
     case 7:
      return new e(t[0], t[1], t[2], t[3], t[4], t[5], t[6])
    }
    var n = go(e.prototype),
     t = e.apply(n, t);
    return Zi(t) ? t : n
   }
  }

  function Pr(e) {
   function t(n, r, i) {
    return i && di(n, r, i) && (r = w), n = Zr(n, e, w, w, w, w, w, r), n.placeholder = t.placeholder, n
   }
   return t
  }

  function Hr(e, t) {
   return $i(function(n) {
    var r = n[0];
    return null == r ? r : (n.push(t), e.apply(w, n))
   })
  }

  function Br(e, t) {
   return function(n, r, i) {
    if (i && di(n, r, i) && (r = w), r = ri(r, i, 3), 1 == r.length) {
     i = n = cu(n) ? n : Si(n);
     for (var s = r, o = -1, u = i.length, a = t, f = a; ++o < u;) {
      var l = i[o],
       c = +s(l);
      e(c, a) && (a = c, f = l)
     }
     if (i = f, !n.length || i !== t) return i
    }
    return qn(n, r, e, t)
   }
  }

  function jr(e, n) {
   return function(r, i, s) {
    return i = ri(i, s, 3), cu(r) ? (i = t(r, i, n), -1 < i ? r[i] : w) : Xn(r, i, e)
   }
  }

  function Fr(e) {
   return function(n, r, i) {
    return n && n.length ? (r = ri(r, i, 3), t(n, r, e)) : -1
   }
  }

  function Ir(e) {
   return function(t, n, r) {
    return n = ri(n, r, 3), Xn(t, n, e, !0)
   }
  }

  function qr(e) {
   return function() {
    for (var t, n = arguments.length, r = e ? n : -1, i = 0, s = xs(n); e ? r-- : ++r < n;) {
     var o = s[i++] = arguments[r];
     if (typeof o != "function") throw new _s(F);
     !t && jt.prototype.thru && "wrapper" == ii(o) && (t = new jt([], !0))
    }
    for (r = t ? -1 : n; ++r < n;) {
     var o = s[r],
      i = ii(o),
      u = "wrapper" == i ? xo(o) : w;
     t = u && mi(u[0]) && u[1] == (A | N | k | O) && !u[4].length && 1 == u[9] ? t[ii(u[0])].apply(t, u[3]) : 1 == o.length && mi(o) ? t[i]() : t.thru(o)
    }
    return function() {
     var e = arguments,
      r = e[0];
     if (t && 1 == e.length && cu(r) && r.length >= H) return t.plant(r).value();
     for (var i = 0, e = n ? s[i].apply(this, e) : r; ++i < n;) e = s[i].call(this, e);
     return e
    }
   }
  }

  function Rr(e, t) {
   return function(n, r, i) {
    return typeof r == "function" && i === w && cu(n) ? e(n, r) : t(n, xr(r, i, 3))
   }
  }

  function Ur(e) {
   return function(t, n, r) {
    return (typeof n != "function" || r !== w) && (n = xr(n, r, 3)), e(t, n, ls)
   }
  }

  function zr(e) {
   return function(t, n, r) {
    return (typeof n != "function" || r !== w) && (n = xr(n, r, 3)), e(t, n)
   }
  }

  function Wr(e) {
   return function(t, n, r) {
    var i = {};
    return n = ri(n, r, 3), Kn(t, function(t, r, s) {
     s = n(t, r, s), r = e ? s : r, t = e ? t : s, i[r] = t
    }), i
   }
  }

  function Xr(e) {
   return function(t, n, r) {
    return t = i(t), (e ? t : "") + Kr(t, n, r) + (e ? "" : t)
   }
  }

  function Vr(e) {
   var t = $i(function(n, r) {
    var i = v(r, t.placeholder);
    return Zr(n, e, w, r, i)
   });
   return t
  }

  function $r(e, t) {
   return function(n, r, i, s) {
    var o = 3 > arguments.length;
    return typeof r == "function" && s === w && cu(n) ? e(n, r, i, o) : cr(n, ri(r, s, 4), i, o, t)
   }
  }

  function Jr(e, t, n, r, i, s, o, u, a, f) {
   function l() {
    for (var b = arguments.length, E = b, T = xs(b); E--;) T[E] = arguments[E];
    if (r && (T = Nr(T, r, i)), s && (T = Cr(T, s, o)), d || g) {
     var E = l.placeholder,
      N = v(T, E),
      b = b - N.length;
     if (b < f) {
      var C = u ? Ut(u) : w,
       b = io(f - b, 0),
       A = d ? N : w,
       N = d ? w : N,
       O = d ? T : w,
       T = d ? w : T;
      return t |= d ? k : L, t &= ~(d ? L : k), m || (t &= ~(S | x)), T = [e, t, n, O, A, T, N, C, a, b], C = Jr.apply(w, T), mi(e) && No(C, T), C.placeholder = E, C
     }
    }
    if (E = h ? n : this, C = p ? E[e] : e, u)
     for (b = T.length, A = so(u.length, b), N = Ut(T); A--;) O = u[A], T[A] = pi(O, b) ? N[O] : w;
    return c && a < T.length && (T.length = a), this && this !== Vt && this instanceof l && (C = y || Dr(e)), C.apply(E, T)
   }
   var c = t & A,
    h = t & S,
    p = t & x,
    d = t & N,
    m = t & T,
    g = t & C,
    y = p ? w : Dr(e);
   return l
  }

  function Kr(e, t, n) {
   return e = e.length, t = +t, e < t && no(t) ? (t -= e, n = null == n ? " " : n + "", ds(n, Ys(t / n.length)).slice(0, t)) : ""
  }

  function Qr(e, t, n, r) {
   function i() {
    for (var t = -1, u = arguments.length, a = -1, f = r.length, l = xs(f + u); ++a < f;) l[a] = r[a];
    for (; u--;) l[a++] = arguments[++t];
    return (this && this !== Vt && this instanceof i ? o : e).apply(s ? n : this, l)
   }
   var s = t & S,
    o = Dr(e);
   return i
  }

  function Gr(e) {
   var t = ks[e];
   return function(e, n) {
    return (n = n === w ? 0 : +n || 0) ? (n = Xs(10, n), t(e * n) / n) : t(e)
   }
  }

  function Yr(e) {
   return function(t, n, r, i) {
    var s = ri(r);
    return null == r && s === Mn ? Er(t, n, e) : Sr(t, n, s(r, i, 1), e)
   }
  }

  function Zr(e, t, n, r, i, s, o, u) {
   var a = t & x;
   if (!a && typeof e != "function") throw new _s(F);
   var f = r ? r.length : 0;
   if (f || (t &= ~(k | L), r = i = w), f -= i ? i.length : 0, t & L) {
    var l = r,
     c = i;
    r = i = w
   }
   var h = a ? w : xo(e);
   return n = [e, t, n, r, i, l, c, s, o, u], h && (r = n[1], t = h[1], u = r | t, i = t == A && r == N || t == A && r == O && n[7].length <= h[8] || t == (A | O) && r == N, (u < A || i) && (t & S && (n[2] = h[2], u |= r & S ? 0 : T), (r = h[3]) && (i = n[3], n[3] = i ? Nr(i, r, h[4]) : Ut(r), n[4] = i ? v(n[3], I) : Ut(h[4])), (r = h[5]) && (i = n[5], n[5] = i ? Cr(i, r, h[6]) : Ut(r), n[6] = i ? v(n[5], I) : Ut(h[6])), (r = h[7]) && (n[7] = Ut(r)), t & A && (n[8] = null == n[8] ? h[8] : so(n[8], h[8])), null == n[9] && (n[9] = h[9]), n[0] = h[0], n[1] = u), t = n[1], u = n[9]), n[9] = null == u ? a ? 0 : e.length : io(u - f, 0) || 0, (h ? So : No)(t == S ? Mr(n[0], n[2]) : t != k && t != (S | k) || n[4].length ? Jr.apply(w, n) : Qr.apply(w, n), n)
  }

  function ei(e, t, n, r, i, s, o) {
   var u = -1,
    a = e.length,
    f = t.length;
   if (a != f && (!i || f <= a)) return !1;
   for (; ++u < a;) {
    var l = e[u],
     f = t[u],
     c = r ? r(i ? f : l, i ? l : f, u) : w;
    if (c !== w) {
     if (c) continue;
     return !1
    }
    if (i) {
     if (!Gt(t, function(e) {
       return l === e || n(l, e, r, i, s, o)
      })) return !1
    } else if (l !== f && !n(l, f, r, i, s, o)) return !1
   }
   return !0
  }

  function ti(e, t, n) {
   switch (n) {
    case U:
    case z:
     return +e == +t;
    case W:
     return e.name == t.name && e.message == t.message;
    case V:
     return e != +e ? t != +t : e == +t;
    case J:
    case K:
     return e == t + ""
   }
   return !1
  }

  function ni(e, t, n, r, i, s, o) {
   var u = Su(e),
    a = u.length,
    f = Su(t).length;
   if (a != f && !i) return !1;
   for (f = a; f--;) {
    var l = u[f];
    if (!(i ? l in t : js.call(t, l))) return !1
   }
   for (var c = i; ++f < a;) {
    var l = u[f],
     h = e[l],
     p = t[l],
     d = r ? r(i ? p : h, i ? h : p, l) : w;
    if (d === w ? !n(h, p, r, i, s, o) : !d) return !1;
    c || (c = "constructor" == l)
   }
   return c || (n = e.constructor, r = t.constructor, !(n != r && "constructor" in e && "constructor" in t) || typeof n == "function" && n instanceof n && typeof r == "function" && r instanceof r) ? !0 : !1
  }

  function ri(e, t, n) {
   var r = Ht.callback || gs,
    r = r === gs ? Mn : r;
   return n ? r(e, t, n) : r
  }

  function ii(e) {
   for (var t = e.name + "", n = mo[t], r = n ? n.length : 0; r--;) {
    var i = n[r],
     s = i.func;
    if (null == s || s == e) return i.name
   }
   return t
  }

  function si(e, t, r) {
   var i = Ht.indexOf || Ai,
    i = i === Ai ? n : i;
   return e ? i(e, t, r) : i
  }

  function oi(e) {
   e = cs(e);
   for (var t = e.length; t--;) {
    var n = e[t][1];
    e[t][2] = n === n && !Zi(n)
   }
   return e
  }

  function ui(e, t) {
   var n = null == e ? w : e[t];
   return es(n) ? n : w
  }

  function ai(e) {
   var t = e.length,
    n = new e.constructor(t);
   return t && "string" == typeof e[0] && js.call(e, "index") && (n.index = e.index, n.input = e.input), n
  }

  function fi(e) {
   return e = e.constructor, typeof e == "function" && e instanceof e || (e = As), new e
  }

  function li(e, t, n) {
   var r = e.constructor;
   switch (t) {
    case Q:
     return Tr(e);
    case U:
    case z:
     return new r(+e);
    case G:
    case Y:
    case Z:
    case et:
    case tt:
    case nt:
    case rt:
    case it:
    case st:
     return t = e.buffer, new r(n ? Tr(t) : t, e.byteOffset, e.length);
    case V:
    case K:
     return new r(e);
    case J:
     var i = new r(e.source, Tt.exec(e));
     i.lastIndex = e.lastIndex
   }
   return i
  }

  function ci(e, t, n) {
   return null == e || vi(t, e) || (t = Ti(t), e = 1 == t.length ? e : er(e, hr(t, 0, -1)), t = Oi(t)), t = null == e ? e : e[t], null == t ? w : t.apply(e, n)
  }

  function hi(e) {
   return null != e && gi(To(e))
  }

  function pi(e, t) {
   return e = typeof e == "number" || kt.test(e) ? +e : -1, t = null == t ? po : t, -1 < e && 0 == e % 1 && e < t
  }

  function di(e, t, n) {
   if (!Zi(n)) return !1;
   var r = typeof t;
   return ("number" == r ? hi(n) && pi(t, n.length) : "string" == r && t in n) ? (t = n[t], e === e ? e === t : t !== t) : !1
  }

  function vi(e, t) {
   var n = typeof e;
   return "string" == n && gt.test(e) || "number" == n ? !0 : cu(e) ? !1 : !mt.test(e) || null != t && e in xi(t)
  }

  function mi(e) {
   var t = ii(e),
    n = Ht[t];
   return typeof n == "function" && t in Ft.prototype ? e === n ? !0 : (t = xo(n), !!t && e === t[0]) : !1
  }

  function gi(e) {
   return typeof e == "number" && -1 < e && 0 == e % 1 && e <= po
  }

  function yi(e, t) {
   return e === w ? t : hu(e, t, yi)
  }

  function bi(e, t) {
   e = xi(e);
   for (var n = -1, r = t.length, i = {}; ++n < r;) {
    var s = t[n];
    s in e && (i[s] = e[s])
   }
   return i
  }

  function wi(e, t) {
   var n = {};
   return Jn(e, function(e, r, i) {
    t(e, r, i) && (n[r] = e)
   }), n
  }

  function Ei(e) {
   for (var t = ls(e), n = t.length, r = n && e.length, i = !!r && gi(r) && (cu(e) || Ki(e)), s = -1, o = []; ++s < n;) {
    var u = t[s];
    (i && pi(u, r) || js.call(e, u)) && o.push(u)
   }
   return o
  }

  function Si(e) {
   return null == e ? [] : hi(e) ? Zi(e) ? e : As(e) : hs(e)
  }

  function xi(e) {
   return Zi(e) ? e : As(e)
  }

  function Ti(e) {
   if (cu(e)) return e;
   var t = [];
   return i(e).replace(yt, function(e, n, r, i) {
    t.push(r ? i.replace(St, "$1") : n || e)
   }), t
  }

  function Ni(e) {
   return e instanceof Ft ? e.clone() : new jt(e.__wrapped__, e.__chain__, Ut(e.__actions__))
  }

  function Ci(e, t, n) {
   return e && e.length ? ((n ? di(e, t, n) : null == t) && (t = 1), hr(e, 0 > t ? 0 : t)) : []
  }

  function ki(e, t, n) {
   var r = e ? e.length : 0;
   return r ? ((n ? di(e, t, n) : null == t) && (t = 1), t = r - (+t || 0), hr(e, 0, 0 > t ? 0 : t)) : []
  }

  function Li(e) {
   return e ? e[0] : w
  }

  function Ai(e, t, r) {
   var i = e ? e.length : 0;
   if (!i) return -1;
   if (typeof r == "number") r = 0 > r ? io(i + r, 0) : r;
   else if (r) return r = Er(e, t), r < i && (t === t ? t === e[r] : e[r] !== e[r]) ? r : -1;
   return n(e, t, r || 0)
  }

  function Oi(e) {
   var t = e ? e.length : 0;
   return t ? e[t - 1] : w
  }

  function Mi(e) {
   return Ci(e, 1)
  }

  function _i(e, t, r, i) {
   if (!e || !e.length) return [];
   null != t && typeof t != "boolean" && (i = r, r = di(e, t, i) ? w : t, t = !1);
   var s = ri();
   if ((null != r || s !== Mn) && (r = s(r, i, 3)), t && si() === n) {
    t = r;
    var o;
    r = -1, i = e.length;
    for (var s = -1, u = []; ++r < i;) {
     var a = e[r],
      f = t ? t(a, r, e) : a;
     r && o === f || (o = f, u[++s] = a)
    }
    e = u
   } else e = gr(e, r);
   return e
  }

  function Di(e) {
   if (!e || !e.length) return [];
   var t = -1,
    n = 0;
   e = Xt(e, function(e) {
    return hi(e) ? (n = io(e.length, n), !0) : void 0
   });
   for (var r = xs(n); ++t < n;) r[t] = Jt(e, ur(t));
   return r
  }

  function Pi(e, t, n) {
   return e && e.length ? (e = Di(e), null == t ? e : (t = xr(t, n, 4), Jt(e, function(e) {
    return Qt(e, t, w, !0)
   }))) : []
  }

  function Hi(e, t) {
   var n = -1,
    r = e ? e.length : 0,
    i = {};
   for (!r || t || cu(e[0]) || (t = []); ++n < r;) {
    var s = e[n];
    t ? i[s] = t[n] : s && (i[s[0]] = s[1])
   }
   return i
  }

  function Bi(e) {
   return e = Ht(e), e.__chain__ = !0, e
  }

  function ji(e, t, n) {
   return t.call(n, e)
  }

  function Fi(e, t, n) {
   var r = cu(e) ? Wt : Bn;
   return n && di(e, t, n) && (t = w), (typeof t != "function" || n !== w) && (t = ri(t, n, 3)), r(e, t)
  }

  function Ii(e, t, n) {
   var r = cu(e) ? Xt : zn;
   return t = ri(t, n, 3), r(e, t)
  }

  function qi(e, t, n, r) {
   var i = e ? To(e) : 0;
   return gi(i) || (e = hs(e), i = e.length), n = typeof n != "number" || r && di(t, n, r) ? 0 : 0 > n ? io(i + n, 0) : n || 0, typeof e == "string" || !cu(e) && is(e) ? n <= i && -1 < e.indexOf(t, n) : !!i && -1 < si(e, t, n)
  }

  function Ri(e, t, n) {
   var r = cu(e) ? Jt : rr;
   return t = ri(t, n, 3), r(e, t)
  }

  function Ui(e, t, n) {
   if (n ? di(e, t, n) : null == t) {
    e = Si(e);
    var r = e.length;
    return 0 < r ? e[lr(0, r - 1)] : w
   }
   n = -1, e = us(e);
   var r = e.length,
    i = r - 1;
   for (t = so(0 > t ? 0 : +t || 0, r); ++n < t;) {
    var r = lr(n, i),
     s = e[r];
    e[r] = e[n], e[n] = s
   }
   return e.length = t, e
  }

  function zi(e, t, n) {
   var r = cu(e) ? Gt : pr;
   return n && di(e, t, n) && (t = w), (typeof t != "function" || n !== w) && (t = ri(t, n, 3)), r(e, t)
  }

  function Wi(e, t) {
   var n;
   if (typeof t != "function") {
    if (typeof e != "function") throw new _s(F);
    var r = e;
    e = t, t = r
   }
   return function() {
    return 0 < --e && (n = t.apply(this, arguments)), 1 >= e && (t = w), n
   }
  }

  function Xi(e, t, n) {
   function r(t, n) {
    n && zs(n), a = h = p = w, t && (d = Go(), f = e.apply(c, u), h || a || (u = c = w))
   }

   function i() {
    var e = t - (Go() - l);
    0 >= e || e > t ? r(p, a) : h = Js(i, e)
   }

   function s() {
    r(m, h)
   }

   function o() {
    if (u = arguments, l = Go(), c = this, p = m && (h || !g), !1 === v) var n = g && !h;
    else {
     a || g || (d = l);
     var r = v - (l - d),
      o = 0 >= r || r > v;
     o ? (a && (a = zs(a)), d = l, f = e.apply(c, u)) : a || (a = Js(s, r))
    }
    return o && h ? h = zs(h) : h || t === v || (h = Js(i, t)), n && (o = !0, f = e.apply(c, u)), !o || h || a || (u = c = w), f
   }
   var u, a, f, l, c, h, p, d = 0,
    v = !1,
    m = !0;
   if (typeof e != "function") throw new _s(F);
   if (t = 0 > t ? 0 : +t || 0, !0 === n) var g = !0,
    m = !1;
   else Zi(n) && (g = !!n.leading, v = "maxWait" in n && io(+n.maxWait || 0, t), m = "trailing" in n ? !!n.trailing : m);
   return o.cancel = function() {
    h && zs(h), a && zs(a), d = 0, a = h = p = w
   }, o
  }

  function Vi(e, t) {
   function n() {
    var r = arguments,
     i = t ? t.apply(this, r) : r[0],
     s = n.cache;
    return s.has(i) ? s.get(i) : (r = e.apply(this, r), n.cache = s.set(i, r), r)
   }
   if (typeof e != "function" || t && typeof t != "function") throw new _s(F);
   return n.cache = new Vi.Cache, n
  }

  function $i(e, t) {
   if (typeof e != "function") throw new _s(F);
   return t = io(t === w ? e.length - 1 : +t || 0, 0),
    function() {
     for (var n = arguments, r = -1, i = io(n.length - t, 0), s = xs(i); ++r < i;) s[r] = n[t + r];
     switch (t) {
      case 0:
       return e.call(this, s);
      case 1:
       return e.call(this, n[0], s);
      case 2:
       return e.call(this, n[0], n[1], s)
     }
     for (i = xs(t + 1), r = -1; ++r < t;) i[r] = n[r];
     return i[t] = s, e.apply(this, i)
    }
  }

  function Ji(e, t) {
   return e > t
  }

  function Ki(e) {
   return p(e) && hi(e) && js.call(e, "callee") && !Vs.call(e, "callee")
  }

  function Qi(e, t, n, r) {
   return r = (n = typeof n == "function" ? xr(n, r, 3) : w) ? n(e, t) : w, r === w ? tr(e, t, n) : !!r
  }

  function Gi(e) {
   return p(e) && typeof e.message == "string" && Is.call(e) == W
  }

  function Yi(e) {
   return Zi(e) && Is.call(e) == X
  }

  function Zi(e) {
   var t = typeof e;
   return !!e && ("object" == t || "function" == t)
  }

  function es(e) {
   return null == e ? !1 : Yi(e) ? Rs.test(Bs.call(e)) : p(e) && Ct.test(e)
  }

  function ts(e) {
   return typeof e == "number" || p(e) && Is.call(e) == V
  }

  function ns(e) {
   var t;
   if (!p(e) || Is.call(e) != $ || Ki(e) || !(js.call(e, "constructor") || (t = e.constructor, typeof t != "function" || t instanceof t))) return !1;
   var n;
   return Jn(e, function(e, t) {
    n = t
   }), n === w || js.call(e, n)
  }

  function rs(e) {
   return Zi(e) && Is.call(e) == J
  }

  function is(e) {
   return typeof e == "string" || p(e) && Is.call(e) == K
  }

  function ss(e) {
   return p(e) && gi(e.length) && !!Dt[Is.call(e)]
  }

  function os(e, t) {
   return e < t
  }

  function us(e) {
   var t = e ? To(e) : 0;
   return gi(t) ? t ? Ut(e) : [] : hs(e)
  }

  function as(e) {
   return Ln(e, ls(e))
  }

  function fs(e) {
   return Gn(e, ls(e))
  }

  function ls(e) {
   if (null == e) return [];
   Zi(e) || (e = As(e));
   for (var t = e.length, t = t && gi(t) && (cu(e) || Ki(e)) && t || 0, n = e.constructor, r = -1, n = typeof n == "function" && n.prototype === e, i = xs(t), s = 0 < t; ++r < t;) i[r] = r + "";
   for (var o in e) s && pi(o, t) || "constructor" == o && (n || !js.call(e, o)) || i.push(o);
   return i
  }

  function cs(e) {
   e = xi(e);
   for (var t = -1, n = Su(e), r = n.length, i = xs(r); ++t < r;) {
    var s = n[t];
    i[t] = [s, e[s]]
   }
   return i
  }

  function hs(e) {
   return yr(e, Su(e))
  }

  function ps(e) {
   return (e = i(e)) && e.replace(Lt, a).replace(Et, "")
  }

  function ds(e, t) {
   var n = "";
   if (e = i(e), t = +t, 1 > t || !e || !no(t)) return n;
   do t % 2 && (n += e), t = eo(t / 2), e += e; while (t);
   return n
  }

  function vs(e, t, n) {
   var r = e;
   return (e = i(e)) ? (n ? di(r, t, n) : null == t) ? e.slice(m(e), g(e) + 1) : (t += "", e.slice(s(e, t), o(e, t) + 1)) : e
  }

  function ms(e, t, n) {
   return n && di(e, t, n) && (t = w), e = i(e), e.match(t || Mt) || []
  }

  function gs(e, t, n) {
   return n && di(e, t, n) && (t = w), p(e) ? bs(e) : Mn(e, t)
  }

  function ys(e) {
   return e
  }

  function bs(e) {
   return ir(Dn(e, !0))
  }

  function ws(e, t, n) {
   if (null == n) {
    var r = Zi(t),
     i = r ? Su(t) : w;
    ((i = i && i.length ? Gn(t, i) : w) ? i.length : r) || (i = !1, n = t, t = e, e = this)
   }
   i || (i = Gn(t, Su(t)));
   var s = !0,
    r = -1,
    o = Yi(e),
    u = i.length;
   !1 === n ? s = !1 : Zi(n) && "chain" in n && (s = n.chain);
   for (; ++r < u;) {
    n = i[r];
    var a = t[n];
    e[n] = a, o && (e.prototype[n] = function(t) {
     return function() {
      var n = this.__chain__;
      if (s || n) {
       var r = e(this.__wrapped__);
       return (r.__actions__ = Ut(this.__actions__)).push({
        func: t,
        args: arguments,
        thisArg: e
       }), r.__chain__ = n, r
      }
      return t.apply(e, Kt([this.value()], arguments))
     }
    }(a))
   }
   return e
  }

  function Es() {}

  function Ss(e) {
   return vi(e) ? ur(e) : ar(e)
  }
  d = d ? $t.defaults(Vt.Object(), d, $t.pick(Vt, _t)) : Vt;
  var xs = d.Array,
   Ts = d.Date,
   Ns = d.Error,
   Cs = d.Function,
   ks = d.Math,
   Ls = d.Number,
   As = d.Object,
   Os = d.RegExp,
   Ms = d.String,
   _s = d.TypeError,
   Ds = xs.prototype,
   Ps = As.prototype,
   Hs = Ms.prototype,
   Bs = Cs.prototype.toString,
   js = Ps.hasOwnProperty,
   Fs = 0,
   Is = Ps.toString,
   qs = Vt._,
   Rs = Os("^" + Bs.call(js).replace(/[\\^$.*+?()[\]{}|]/g, "\\$&").replace(/hasOwnProperty|(function).*?(?=\\\()| for .+?(?=\\\])/g, "$1.*?") + "$"),
   Us = d.ArrayBuffer,
   zs = d.clearTimeout,
   Ws = d.parseFloat,
   Xs = ks.pow,
   Vs = Ps.propertyIsEnumerable,
   $s = ui(d, "Set"),
   Js = d.setTimeout,
   Ks = Ds.splice,
   Qs = d.Uint8Array,
   Gs = ui(d, "WeakMap"),
   Ys = ks.ceil,
   Zs = ui(As, "create"),
   eo = ks.floor,
   to = ui(xs, "isArray"),
   no = d.isFinite,
   ro = ui(As, "keys"),
   io = ks.max,
   so = ks.min,
   oo = ui(Ts, "now"),
   uo = d.parseInt,
   ao = ks.random,
   fo = Ls.NEGATIVE_INFINITY,
   lo = Ls.POSITIVE_INFINITY,
   co = 4294967294,
   ho = 2147483647,
   po = 9007199254740991,
   vo = Gs && new Gs,
   mo = {};
  Ht.support = {}, Ht.templateSettings = {
   escape: pt,
   evaluate: dt,
   interpolate: vt,
   variable: "",
   imports: {
    _: Ht
   }
  };
  var go = function() {
    function e() {}
    return function(t) {
     if (Zi(t)) {
      e.prototype = t;
      var n = new e;
      e.prototype = w
     }
     return n || {}
    }
   }(),
   yo = Ar(Kn),
   bo = Ar(Qn, !0),
   wo = Or(),
   Eo = Or(!0),
   So = vo ? function(e, t) {
    return vo.set(e, t), e
   } : ys,
   xo = vo ? function(e) {
    return vo.get(e)
   } : Es,
   To = ur("length"),
   No = function() {
    var e = 0,
     t = 0;
    return function(n, r) {
     var i = Go(),
      s = P - (i - t);
     if (t = i, 0 < s) {
      if (++e >= D) return n
     } else e = 0;
     return So(n, r)
    }
   }(),
   Co = $i(function(e, t) {
    return p(e) && hi(e) ? Hn(e, Vn(t, !1, !0)) : []
   }),
   ko = Fr(),
   Lo = Fr(!0),
   Ao = $i(function(e) {
    for (var t = e.length, r = t, i = xs(l), s = si(), o = s === n, u = []; r--;) {
     var a = e[r] = hi(a = e[r]) ? a : [];
     i[r] = o && 120 <= a.length && Zs && $s ? new qt(r && a) : null
    }
    var o = e[0],
     f = -1,
     l = o ? o.length : 0,
     c = i[0];
    e: for (; ++f < l;)
     if (a = o[f], 0 > (c ? Rt(c, a) : s(u, a, 0))) {
      for (r = t; --r;) {
       var h = i[r];
       if (0 > (h ? Rt(h, a) : s(e[r], a, 0))) continue e
      }
      c && c.push(a), u.push(a)
     }
    return u
   }),
   Oo = $i(function(t, n) {
    n = Vn(n);
    var r = Nn(t, n);
    return fr(t, n.sort(e)), r
   }),
   Mo = Yr(),
   _o = Yr(!0),
   Do = $i(function(e) {
    return gr(Vn(e, !1, !0))
   }),
   Po = $i(function(e, t) {
    return hi(e) ? Hn(e, t) : []
   }),
   Ho = $i(Di),
   Bo = $i(function(e) {
    var t = e.length,
     n = 2 < t ? e[t - 2] : w,
     r = 1 < t ? e[t - 1] : w;
    return 2 < t && typeof n == "function" ? t -= 2 : (n = 1 < t && typeof r == "function" ? (--t, r) : w, r = w), e.length = t, Pi(e, n, r)
   }),
   jo = $i(function(e) {
    return e = Vn(e), this.thru(function(t) {
     t = cu(t) ? t : [xi(t)];
     for (var n = e, r = -1, i = t.length, s = -1, o = n.length, u = xs(i + o); ++r < i;) u[r] = t[r];
     for (; ++s < o;) u[r++] = n[s];
     return u
    })
   }),
   Fo = $i(function(e, t) {
    return Nn(e, Vn(t))
   }),
   Io = kr(function(e, t, n) {
    js.call(e, n) ? ++e[n] : e[n] = 1
   }),
   qo = jr(yo),
   Ro = jr(bo, !0),
   Uo = Rr(zt, yo),
   zo = Rr(function(e, t) {
    for (var n = e.length; n-- && !1 !== t(e[n], n, e););
    return e
   }, bo),
   Wo = kr(function(e, t, n) {
    js.call(e, n) ? e[n].push(t) : e[n] = [t]
   }),
   Xo = kr(function(e, t, n) {
    e[n] = t
   }),
   Vo = $i(function(e, t, n) {
    var r = -1,
     i = typeof t == "function",
     s = vi(t),
     o = hi(e) ? xs(e.length) : [];
    return yo(e, function(e) {
     var u = i ? t : s && null != e ? e[t] : w;
     o[++r] = u ? u.apply(e, n) : ci(e, t, n)
    }), o
   }),
   $o = kr(function(e, t, n) {
    e[n ? 0 : 1].push(t)
   }, function() {
    return [
     [],
     []
    ]
   }),
   Jo = $r(Qt, yo),
   Ko = $r(function(e, t, n, r) {
    var i = e.length;
    for (r && i && (n = e[--i]); i--;) n = t(n, e[i], i, e);
    return n
   }, bo),
   Qo = $i(function(e, t) {
    if (null == e) return [];
    var n = t[2];
    return n && di(t[0], t[1], n) && (t.length = 1), vr(e, Vn(t), [])
   }),
   Go = oo || function() {
    return (new Ts).getTime()
   },
   Yo = $i(function(e, t, n) {
    var r = S;
    if (n.length) var i = v(n, Yo.placeholder),
     r = r | k;
    return Zr(e, r, t, n, i)
   }),
   Zo = $i(function(e, t) {
    t = t.length ? Vn(t) : fs(e);
    for (var n = -1, r = t.length; ++n < r;) {
     var i = t[n];
     e[i] = Zr(e[i], S, e)
    }
    return e
   }),
   eu = $i(function(e, t, n) {
    var r = S | x;
    if (n.length) var i = v(n, eu.placeholder),
     r = r | k;
    return Zr(t, r, e, n, i)
   }),
   tu = Pr(N),
   nu = Pr(C),
   ru = $i(function(e, t) {
    return Pn(e, 1, t)
   }),
   iu = $i(function(e, t, n) {
    return Pn(e, t, n)
   }),
   su = qr(),
   ou = qr(!0),
   uu = $i(function(e, t) {
    if (t = Vn(t), typeof e != "function" || !Wt(t, r)) throw new _s(F);
    var n = t.length;
    return $i(function(r) {
     for (var i = so(r.length, n); i--;) r[i] = t[i](r[i]);
     return e.apply(this, r)
    })
   }),
   au = Vr(k),
   fu = Vr(L),
   lu = $i(function(e, t) {
    return Zr(e, O, w, w, w, Vn(t))
   }),
   cu = to || function(e) {
    return p(e) && gi(e.length) && Is.call(e) == R
   },
   hu = Lr(or),
   pu = Lr(function(e, t, n) {
    return n ? Zt(e, t, n) : Tn(e, t)
   }),
   du = Hr(pu, function(e, t) {
    return e === w ? t : e
   }),
   vu = Hr(hu, yi),
   mu = Ir(Kn),
   gu = Ir(Qn),
   yu = Ur(wo),
   bu = Ur(Eo),
   wu = zr(Kn),
   Eu = zr(Qn),
   Su = ro ? function(e) {
    var t = null == e ? w : e.constructor;
    return typeof t == "function" && t.prototype === e || typeof e != "function" && hi(e) ? Ei(e) : Zi(e) ? ro(e) : []
   } : Ei,
   xu = Wr(!0),
   Tu = Wr(),
   Nu = $i(function(e, t) {
    if (null == e) return {};
    if ("function" != typeof t[0]) return t = Jt(Vn(t), Ms), bi(e, Hn(ls(e), t));
    var n = xr(t[0], t[1], 3);
    return wi(e, function(e, t, r) {
     return !n(e, t, r)
    })
   }),
   Cu = $i(function(e, t) {
    return null == e ? {} : "function" == typeof t[0] ? wi(e, xr(t[0], t[1], 3)) : bi(e, Vn(t))
   }),
   ku = _r(function(e, t, n) {
    return t = t.toLowerCase(), e + (n ? t.charAt(0).toUpperCase() + t.slice(1) : t)
   }),
   Lu = _r(function(e, t, n) {
    return e + (n ? "-" : "") + t.toLowerCase()
   }),
   Au = Xr(),
   Ou = Xr(!0),
   Mu = _r(function(e, t, n) {
    return e + (n ? "_" : "") + t.toLowerCase()
   }),
   _u = _r(function(e, t, n) {
    return e + (n ? " " : "") + (t.charAt(0).toUpperCase() + t.slice(1))
   }),
   Du = $i(function(e, t) {
    try {
     return e.apply(w, t)
    } catch (n) {
     return Gi(n) ? n : new Ns(n)
    }
   }),
   Pu = $i(function(e, t) {
    return function(n) {
     return ci(n, e, t)
    }
   }),
   Hu = $i(function(e, t) {
    return function(n) {
     return ci(e, n, t)
    }
   }),
   Bu = Gr("ceil"),
   ju = Gr("floor"),
   Fu = Br(Ji, fo),
   Iu = Br(os, lo),
   qu = Gr("round");
  return Ht.prototype = Bt.prototype, jt.prototype = go(Bt.prototype), jt.prototype.constructor = jt, Ft.prototype = go(Bt.prototype), Ft.prototype.constructor = Ft, It.prototype["delete"] = function(e) {
   return this.has(e) && delete this.__data__[e]
  }, It.prototype.get = function(e) {
   return "__proto__" == e ? w : this.__data__[e]
  }, It.prototype.has = function(e) {
   return "__proto__" != e && js.call(this.__data__, e)
  }, It.prototype.set = function(e, t) {
   return "__proto__" != e && (this.__data__[e] = t), this
  }, qt.prototype.push = function(e) {
   var t = this.data;
   typeof e == "string" || Zi(e) ? t.set.add(e) : t.hash[e] = !0
  }, Vi.Cache = It, Ht.after = function(e, t) {
   if (typeof t != "function") {
    if (typeof e != "function") throw new _s(F);
    var n = e;
    e = t, t = n
   }
   return e = no(e = +e) ? e : 0,
    function() {
     return 1 > --e ? t.apply(this, arguments) : void 0
    }
  }, Ht.ary = function(e, t, n) {
   return n && di(e, t, n) && (t = w), t = e && null == t ? e.length : io(+t || 0, 0), Zr(e, A, w, w, w, w, t)
  }, Ht.assign = pu, Ht.at = Fo, Ht.before = Wi, Ht.bind = Yo, Ht.bindAll = Zo, Ht.bindKey = eu, Ht.callback = gs, Ht.chain = Bi, Ht.chunk = function(e, t, n) {
   t = (n ? di(e, t, n) : null == t) ? 1 : io(eo(t) || 1, 1), n = 0;
   for (var r = e ? e.length : 0, i = -1, s = xs(Ys(r / t)); n < r;) s[++i] = hr(e, n, n += t);
   return s
  }, Ht.compact = function(e) {
   for (var t = -1, n = e ? e.length : 0, r = -1, i = []; ++t < n;) {
    var s = e[t];
    s && (i[++r] = s)
   }
   return i
  }, Ht.constant = function(e) {
   return function() {
    return e
   }
  }, Ht.countBy = Io, Ht.create = function(e, t, n) {
   var r = go(e);
   return n && di(e, t, n) && (t = w), t ? Tn(r, t) : r
  }, Ht.curry = tu, Ht.curryRight = nu, Ht.debounce = Xi, Ht.defaults = du, Ht.defaultsDeep = vu, Ht.defer = ru, Ht.delay = iu, Ht.difference = Co, Ht.drop = Ci, Ht.dropRight = ki, Ht.dropRightWhile = function(e, t, n) {
   return e && e.length ? br(e, ri(t, n, 3), !0, !0) : []
  }, Ht.dropWhile = function(e, t, n) {
   return e && e.length ? br(e, ri(t, n, 3), !0) : []
  }, Ht.fill = function(e, t, n, r) {
   var i = e ? e.length : 0;
   if (!i) return [];
   for (n && typeof n != "number" && di(e, t, n) && (n = 0, r = i), i = e.length, n = null == n ? 0 : +n || 0, 0 > n && (n = -n > i ? 0 : i + n), r = r === w || r > i ? i : +r || 0, 0 > r && (r += i), i = n > r ? 0 : r >>> 0, n >>>= 0; n < i;) e[n++] = t;
   return e
  }, Ht.filter = Ii, Ht.flatten = function(e, t, n) {
   var r = e ? e.length : 0;
   return n && di(e, t, n) && (t = !1), r ? Vn(e, t) : []
  }, Ht.flattenDeep = function(e) {
   return e && e.length ? Vn(e, !0) : []
  }, Ht.flow = su, Ht.flowRight = ou, Ht.forEach = Uo, Ht.forEachRight = zo, Ht.forIn = yu, Ht.forInRight = bu, Ht.forOwn = wu, Ht.forOwnRight = Eu, Ht.functions = fs, Ht.groupBy = Wo, Ht.indexBy = Xo, Ht.initial = function(e) {
   return ki(e, 1)
  }, Ht.intersection = Ao, Ht.invert = function(e, t, n) {
   n && di(e, t, n) && (t = w), n = -1;
   for (var r = Su(e), i = r.length, s = {}; ++n < i;) {
    var o = r[n],
     u = e[o];
    t ? js.call(s, u) ? s[u].push(o) : s[u] = [o] : s[u] = o
   }
   return s
  }, Ht.invoke = Vo, Ht.keys = Su, Ht.keysIn = ls, Ht.map = Ri, Ht.mapKeys = xu, Ht.mapValues = Tu, Ht.matches = bs, Ht.matchesProperty = function(e, t) {
   return sr(e, Dn(t, !0))
  }, Ht.memoize = Vi, Ht.merge = hu, Ht.method = Pu, Ht.methodOf = Hu, Ht.mixin = ws, Ht.modArgs = uu, Ht.negate = function(e) {
   if (typeof e != "function") throw new _s(F);
   return function() {
    return !e.apply(this, arguments)
   }
  }, Ht.omit = Nu, Ht.once = function(e) {
   return Wi(2, e)
  }, Ht.pairs = cs, Ht.partial = au, Ht.partialRight = fu, Ht.partition = $o, Ht.pick = Cu, Ht.pluck = function(e, t) {
   return Ri(e, Ss(t))
  }, Ht.property = Ss, Ht.propertyOf = function(e) {
   return function(t) {
    return er(e, Ti(t), t + "")
   }
  }, Ht.pull = function() {
   var e = arguments,
    t = e[0];
   if (!t || !t.length) return t;
   for (var n = 0, r = si(), i = e.length; ++n < i;)
    for (var s = 0, o = e[n]; - 1 < (s = r(t, o, s));) Ks.call(t, s, 1);
   return t
  }, Ht.pullAt = Oo, Ht.range = function(e, t, n) {
   n && di(e, t, n) && (t = n = w), e = +e || 0, n = null == n ? 1 : +n || 0, null == t ? (t = e, e = 0) : t = +t || 0;
   var r = -1;
   t = io(Ys((t - e) / (n || 1)), 0);
   for (var i = xs(t); ++r < t;) i[r] = e, e += n;
   return i
  }, Ht.rearg = lu, Ht.reject = function(e, t, n) {
   var r = cu(e) ? Xt : zn;
   return t = ri(t, n, 3), r(e, function(e, n, r) {
    return !t(e, n, r)
   })
  }, Ht.remove = function(e, t, n) {
   var r = [];
   if (!e || !e.length) return r;
   var i = -1,
    s = [],
    o = e.length;
   for (t = ri(t, n, 3); ++i < o;) n = e[i], t(n, i, e) && (r.push(n), s.push(i));
   return fr(e, s), r
  }, Ht.rest = Mi, Ht.restParam = $i, Ht.set = function(e, t, n) {
   if (null == e) return e;
   var r = t + "";
   t = null != e[r] || vi(t, e) ? [r] : Ti(t);
   for (var r = -1, i = t.length, s = i - 1, o = e; null != o && ++r < i;) {
    var u = t[r];
    Zi(o) && (r == s ? o[u] = n : null == o[u] && (o[u] = pi(t[r + 1]) ? [] : {})), o = o[u]
   }
   return e
  }, Ht.shuffle = function(e) {
   return Ui(e, lo)
  }, Ht.slice = function(e, t, n) {
   var r = e ? e.length : 0;
   return r ? (n && typeof n != "number" && di(e, t, n) && (t = 0, n = r), hr(e, t, n)) : []
  }, Ht.sortBy = function(e, t, n) {
   if (null == e) return [];
   n && di(e, t, n) && (t = w);
   var r = -1;
   return t = ri(t, n, 3), e = rr(e, function(e, n, i) {
    return {
     a: t(e, n, i),
     b: ++r,
     c: e
    }
   }), dr(e, u)
  }, Ht.sortByAll = Qo, Ht.sortByOrder = function(e, t, n, r) {
   return null == e ? [] : (r && di(t, n, r) && (n = w), cu(t) || (t = null == t ? [] : [t]), cu(n) || (n = null == n ? [] : [n]), vr(e, t, n))
  }, Ht.spread = function(e) {
   if (typeof e != "function") throw new _s(F);
   return function(t) {
    return e.apply(this, t)
   }
  }, Ht.take = function(e, t, n) {
   return e && e.length ? ((n ? di(e, t, n) : null == t) && (t = 1), hr(e, 0, 0 > t ? 0 : t)) : []
  }, Ht.takeRight = function(e, t, n) {
   var r = e ? e.length : 0;
   return r ? ((n ? di(e, t, n) : null == t) && (t = 1), t = r - (+t || 0), hr(e, 0 > t ? 0 : t)) : []
  }, Ht.takeRightWhile = function(e, t, n) {
   return e && e.length ? br(e, ri(t, n, 3), !1, !0) : []
  }, Ht.takeWhile = function(e, t, n) {
   return e && e.length ? br(e, ri(t, n, 3)) : []
  }, Ht.tap = function(e, t, n) {
   return t.call(n, e), e
  }, Ht.throttle = function(e, t, n) {
   var r = !0,
    i = !0;
   if (typeof e != "function") throw new _s(F);
   return !1 === n ? r = !1 : Zi(n) && (r = "leading" in n ? !!n.leading : r, i = "trailing" in n ? !!n.trailing : i), Xi(e, t, {
    leading: r,
    maxWait: +t,
    trailing: i
   })
  }, Ht.thru = ji, Ht.times = function(e, t, n) {
   if (e = eo(e), 1 > e || !no(e)) return [];
   var r = -1,
    i = xs(so(e, 4294967295));
   for (t = xr(t, n, 1); ++r < e;) 4294967295 > r ? i[r] = t(r) : t(r);
   return i
  }, Ht.toArray = us, Ht.toPlainObject = as, Ht.transform = function(e, t, n, r) {
   var i = cu(e) || ss(e);
   return t = ri(t, r, 4), null == n && (i || Zi(e) ? (r = e.constructor, n = i ? cu(e) ? new r : [] : go(Yi(r) ? r.prototype : w)) : n = {}), (i ? zt : Kn)(e, function(e, r, i) {
    return t(n, e, r, i)
   }), n
  }, Ht.union = Do, Ht.uniq = _i, Ht.unzip = Di, Ht.unzipWith = Pi, Ht.values = hs, Ht.valuesIn = function(e) {
   return yr(e, ls(e))
  }, Ht.where = function(e, t) {
   return Ii(e, ir(t))
  }, Ht.without = Po, Ht.wrap = function(e, t) {
   return t = null == t ? ys : t, Zr(t, k, w, [e], [])
  }, Ht.xor = function() {
   for (var e = -1, t = arguments.length; ++e < t;) {
    var n = arguments[e];
    if (hi(n)) var r = r ? Kt(Hn(r, n), Hn(n, r)) : n
   }
   return r ? gr(r) : []
  }, Ht.zip = Ho, Ht.zipObject = Hi, Ht.zipWith = Bo, Ht.backflow = ou, Ht.collect = Ri, Ht.compose = ou, Ht.each = Uo, Ht.eachRight = zo, Ht.extend = pu, Ht.iteratee = gs, Ht.methods = fs, Ht.object = Hi, Ht.select = Ii, Ht.tail = Mi, Ht.unique = _i, ws(Ht, Ht), Ht.add = function(e, t) {
   return (+e || 0) + (+t || 0)
  }, Ht.attempt = Du, Ht.camelCase = ku, Ht.capitalize = function(e) {
   return (e = i(e)) && e.charAt(0).toUpperCase() + e.slice(1)
  }, Ht.ceil = Bu, Ht.clone = function(e, t, n, r) {
   return t && typeof t != "boolean" && di(e, t, n) ? t = !1 : typeof t == "function" && (r = n, n = t, t = !1), typeof n == "function" ? Dn(e, t, xr(n, r, 3)) : Dn(e, t)
  }, Ht.cloneDeep = function(e, t, n) {
   return typeof t == "function" ? Dn(e, !0, xr(t, n, 3)) : Dn(e, !0)
  }, Ht.deburr = ps, Ht.endsWith = function(e, t, n) {
   e = i(e), t += "";
   var r = e.length;
   return n = n === w ? r : so(0 > n ? 0 : +n || 0, r), n -= t.length, 0 <= n && e.indexOf(t, n) == n
  }, Ht.escape = function(e) {
   return (e = i(e)) && ht.test(e) ? e.replace(lt, f) : e
  }, Ht.escapeRegExp = function(e) {
   return (e = i(e)) && wt.test(e) ? e.replace(bt, l) : e || "(?:)"
  }, Ht.every = Fi, Ht.find = qo, Ht.findIndex = ko, Ht.findKey = mu, Ht.findLast = Ro, Ht.findLastIndex = Lo, Ht.findLastKey = gu, Ht.findWhere = function(e, t) {
   return qo(e, ir(t))
  }, Ht.first = Li, Ht.floor = ju, Ht.get = function(e, t, n) {
   return e = null == e ? w : er(e, Ti(t), t + ""), e === w ? n : e
  }, Ht.gt = Ji, Ht.gte = function(e, t) {
   return e >= t
  }, Ht.has = function(e, t) {
   if (null == e) return !1;
   var n = js.call(e, t);
   if (!n && !vi(t)) {
    if (t = Ti(t), e = 1 == t.length ? e : er(e, hr(t, 0, -1)), null == e) return !1;
    t = Oi(t), n = js.call(e, t)
   }
   return n || gi(e.length) && pi(t, e.length) && (cu(e) || Ki(e))
  }, Ht.identity = ys, Ht.includes = qi, Ht.indexOf = Ai, Ht.inRange = function(e, t, n) {
   return t = +t || 0, n === w ? (n = t, t = 0) : n = +n || 0, e >= so(t, n) && e < io(t, n)
  }, Ht.isArguments = Ki, Ht.isArray = cu, Ht.isBoolean = function(e) {
   return !0 === e || !1 === e || p(e) && Is.call(e) == U
  }, Ht.isDate = function(e) {
   return p(e) && Is.call(e) == z
  }, Ht.isElement = function(e) {
   return !!e && 1 === e.nodeType && p(e) && !ns(e)
  }, Ht.isEmpty = function(e) {
   return null == e ? !0 : hi(e) && (cu(e) || is(e) || Ki(e) || p(e) && Yi(e.splice)) ? !e.length : !Su(e).length
  }, Ht.isEqual = Qi, Ht.isError = Gi, Ht.isFinite = function(e) {
   return typeof e == "number" && no(e)
  }, Ht.isFunction = Yi, Ht.isMatch = function(e, t, n, r) {
   return n = typeof n == "function" ? xr(n, r, 3) : w, nr(e, oi(t), n)
  }, Ht.isNaN = function(e) {
   return ts(e) && e != +e
  }, Ht.isNative = es, Ht.isNull = function(e) {
   return null === e
  }, Ht.isNumber = ts, Ht.isObject = Zi, Ht.isPlainObject = ns, Ht.isRegExp = rs, Ht.isString = is, Ht.isTypedArray = ss, Ht.isUndefined = function(e) {
   return e === w
  }, Ht.kebabCase = Lu, Ht.last = Oi, Ht.lastIndexOf = function(e, t, n) {
   var r = e ? e.length : 0;
   if (!r) return -1;
   var i = r;
   if (typeof n == "number") i = (0 > n ? io(r + n, 0) : so(n || 0, r - 1)) + 1;
   else if (n) return i = Er(e, t, !0) - 1, e = e[i], (t === t ? t === e : e !== e) ? i : -1;
   if (t !== t) return h(e, i, !0);
   for (; i--;)
    if (e[i] === t) return i;
   return -1
  }, Ht.lt = os, Ht.lte = function(e, t) {
   return e <= t
  }, Ht.max = Fu, Ht.min = Iu, Ht.noConflict = function() {
   return Vt._ = qs, this
  }, Ht.noop = Es, Ht.now = Go, Ht.pad = function(e, t, n) {
   e = i(e), t = +t;
   var r = e.length;
   return r < t && no(t) ? (r = (t - r) / 2, t = eo(r), r = Ys(r), n = Kr("", r, n), n.slice(0, t) + e + n) : e
  }, Ht.padLeft = Au, Ht.padRight = Ou, Ht.parseInt = function(e, t, n) {
   return (n ? di(e, t, n) : null == t) ? t = 0 : t && (t = +t), e = vs(e), uo(e, t || (Nt.test(e) ? 16 : 10))
  }, Ht.random = function(e, t, n) {
   n && di(e, t, n) && (t = n = w);
   var r = null == e,
    i = null == t;
   return null == n && (i && typeof e == "boolean" ? (n = e, e = 1) : typeof t == "boolean" && (n = t, i = !0)), r && i && (t = 1, i = !1), e = +e || 0, i ? (t = e, e = 0) : t = +t || 0, n || e % 1 || t % 1 ? (n = ao(), so(e + n * (t - e + Ws("1e-" + ((n + "").length - 1))), t)) : lr(e, t)
  }, Ht.reduce = Jo, Ht.reduceRight = Ko, Ht.repeat = ds, Ht.result = function(e, t, n) {
   var r = null == e ? w : e[t];
   return r === w && (null == e || vi(t, e) || (t = Ti(t), e = 1 == t.length ? e : er(e, hr(t, 0, -1)), r = null == e ? w : e[Oi(t)]), r = r === w ? n : r), Yi(r) ? r.call(e) : r
  }, Ht.round = qu, Ht.runInContext = b, Ht.size = function(e) {
   var t = e ? To(e) : 0;
   return gi(t) ? t : Su(e).length
  }, Ht.snakeCase = Mu, Ht.some = zi, Ht.sortedIndex = Mo, Ht.sortedLastIndex = _o, Ht.startCase = _u, Ht.startsWith = function(e, t, n) {
   return e = i(e), n = null == n ? 0 : so(0 > n ? 0 : +n || 0, e.length), e.lastIndexOf(t, n) == n
  }, Ht.sum = function(e, t, n) {
   if (n && di(e, t, n) && (t = w), t = ri(t, n, 3), 1 == t.length) {
    e = cu(e) ? e : Si(e), n = e.length;
    for (var r = 0; n--;) r += +t(e[n]) || 0;
    e = r
   } else e = mr(e, t);
   return e
  }, Ht.template = function(e, t, n) {
   var r = Ht.templateSettings;
   n && di(e, t, n) && (t = n = w), e = i(e), t = Zt(Tn({}, n || t), r, Yt), n = Zt(Tn({}, t.imports), r.imports, Yt);
   var s, o, u = Su(n),
    a = yr(n, u),
    f = 0;
   n = t.interpolate || At;
   var l = "__p+='";
   n = Os((t.escape || At).source + "|" + n.source + "|" + (n === vt ? xt : At).source + "|" + (t.evaluate || At).source + "|$", "g");
   var h = "sourceURL" in t ? "//# sourceURL=" + t.sourceURL + "\n" : "";
   if (e.replace(n, function(t, n, r, i, u, a) {
     return r || (r = i), l += e.slice(f, a).replace(Ot, c), n && (s = !0, l += "'+__e(" + n + ")+'"), u && (o = !0, l += "';" + u + ";\n__p+='"), r && (l += "'+((__t=(" + r + "))==null?'':__t)+'"), f = a + t.length, t
    }), l += "';", (t = t.variable) || (l = "with(obj){" + l + "}"), l = (o ? l.replace(ot, "") : l).replace(ut, "$1").replace(at, "$1;"), l = "function(" + (t || "obj") + "){" + (t ? "" : "obj||(obj={});") + "var __t,__p=''" + (s ? ",__e=_.escape" : "") + (o ? ",__j=Array.prototype.join;function print(){__p+=__j.call(arguments,'')}" : ";") + l + "return __p}", t = Du(function() {
     return Cs(u, h + "return " + l).apply(w, a)
    }), t.source = l, Gi(t)) throw t;
   return t
  }, Ht.trim = vs, Ht.trimLeft = function(e, t, n) {
   var r = e;
   return (e = i(e)) ? e.slice((n ? di(r, t, n) : null == t) ? m(e) : s(e, t + "")) : e
  }, Ht.trimRight = function(e, t, n) {
   var r = e;
   return (e = i(e)) ? (n ? di(r, t, n) : null == t) ? e.slice(0, g(e) + 1) : e.slice(0, o(e, t + "") + 1) : e
  }, Ht.trunc = function(e, t, n) {
   n && di(e, t, n) && (t = w);
   var r = M;
   if (n = _, null != t)
    if (Zi(t)) {
     var s = "separator" in t ? t.separator : s,
      r = "length" in t ? +t.length || 0 : r;
     n = "omission" in t ? i(t.omission) : n
    } else r = +t || 0;
   if (e = i(e), r >= e.length) return e;
   if (r -= n.length, 1 > r) return n;
   if (t = e.slice(0, r), null == s) return t + n;
   if (rs(s)) {
    if (e.slice(r).search(s)) {
     var o, u = e.slice(0, r);
     for (s.global || (s = Os(s.source, (Tt.exec(s) || "") + "g")), s.lastIndex = 0; e = s.exec(u);) o = e.index;
     t = t.slice(0, null == o ? r : o)
    }
   } else e.indexOf(s, r) != r && (s = t.lastIndexOf(s), -1 < s && (t = t.slice(0, s)));
   return t + n
  }, Ht.unescape = function(e) {
   return (e = i(e)) && ct.test(e) ? e.replace(ft, y) : e
  }, Ht.uniqueId = function(e) {
   var t = ++Fs;
   return i(e) + t
  }, Ht.words = ms, Ht.all = Fi, Ht.any = zi, Ht.contains = qi, Ht.eq = Qi, Ht.detect = qo, Ht.foldl = Jo, Ht.foldr = Ko, Ht.head = Li, Ht.include = qi, Ht.inject = Jo, ws(Ht, function() {
   var e = {};
   return Kn(Ht, function(t, n) {
    Ht.prototype[n] || (e[n] = t)
   }), e
  }(), !1), Ht.sample = Ui, Ht.prototype.sample = function(e) {
   return this.__chain__ || null != e ? this.thru(function(t) {
    return Ui(t, e)
   }) : Ui(this.value())
  }, Ht.VERSION = E, zt("bind bindKey curry curryRight partial partialRight".split(" "), function(e) {
   Ht[e].placeholder = Ht
  }), zt(["drop", "take"], function(e, t) {
   Ft.prototype[e] = function(n) {
    var r = this.__filtered__;
    if (r && !t) return new Ft(this);
    n = null == n ? 1 : io(eo(n) || 0, 0);
    var i = this.clone();
    return r ? i.__takeCount__ = so(i.__takeCount__, n) : i.__views__.push({
     size: n,
     type: e + (0 > i.__dir__ ? "Right" : "")
    }), i
   }, Ft.prototype[e + "Right"] = function(t) {
    return this.reverse()[e](t).reverse()
   }
  }), zt(["filter", "map", "takeWhile"], function(e, t) {
   var n = t + 1,
    r = n != j;
   Ft.prototype[e] = function(e, t) {
    var i = this.clone();
    return i.__iteratees__.push({
     iteratee: ri(e, t, 1),
     type: n
    }), i.__filtered__ = i.__filtered__ || r, i
   }
  }), zt(["first", "last"], function(e, t) {
   var n = "take" + (t ? "Right" : "");
   Ft.prototype[e] = function() {
    return this[n](1).value()[0]
   }
  }), zt(["initial", "rest"], function(e, t) {
   var n = "drop" + (t ? "" : "Right");
   Ft.prototype[e] = function() {
    return this.__filtered__ ? new Ft(this) : this[n](1)
   }
  }), zt(["pluck", "where"], function(e, t) {
   var n = t ? "filter" : "map",
    r = t ? ir : Ss;
   Ft.prototype[e] = function(e) {
    return this[n](r(e))
   }
  }), Ft.prototype.compact = function() {
   return this.filter(ys)
  }, Ft.prototype.reject = function(e, t) {
   return e = ri(e, t, 1), this.filter(function(t) {
    return !e(t)
   })
  }, Ft.prototype.slice = function(e, t) {
   e = null == e ? 0 : +e || 0;
   var n = this;
   return n.__filtered__ && (0 < e || 0 > t) ? new Ft(n) : (0 > e ? n = n.takeRight(-e) : e && (n = n.drop(e)), t !== w && (t = +t || 0, n = 0 > t ? n.dropRight(-t) : n.take(t - e)), n)
  }, Ft.prototype.takeRightWhile = function(e, t) {
   return this.reverse().takeWhile(e, t).reverse()
  }, Ft.prototype.toArray = function() {
   return this.take(lo)
  }, Kn(Ft.prototype, function(e, t) {
   var n = /^(?:filter|map|reject)|While$/.test(t),
    r = /^(?:first|last)$/.test(t),
    i = Ht[r ? "take" + ("last" == t ? "Right" : "") : t];
   i && (Ht.prototype[t] = function() {
    function t(e) {
     return r && o ? i(e, 1)[0] : i.apply(w, Kt([e], s))
    }
    var s = r ? [1] : arguments,
     o = this.__chain__,
     u = this.__wrapped__,
     a = !!this.__actions__.length,
     f = u instanceof Ft,
     l = s[0],
     c = f || cu(u);
    return c && n && typeof l == "function" && 1 != l.length && (f = c = !1), l = {
     func: ji,
     args: [t],
     thisArg: w
    }, a = f && !a, r && !o ? a ? (u = u.clone(), u.__actions__.push(l), e.call(u)) : i.call(w, this.value())[0] : !r && c ? (u = a ? u : new Ft(this), u = e.apply(u, s), u.__actions__.push(l), new jt(u, o)) : this.thru(t)
   })
  }), zt("join pop push replace shift sort splice split unshift".split(" "), function(e) {
   var t = (/^(?:replace|split)$/.test(e) ? Hs : Ds)[e],
    n = /^(?:push|sort|unshift)$/.test(e) ? "tap" : "thru",
    r = /^(?:join|pop|replace|shift)$/.test(e);
   Ht.prototype[e] = function() {
    var e = arguments;
    return r && !this.__chain__ ? t.apply(this.value(), e) : this[n](function(n) {
     return t.apply(n, e)
    })
   }
  }), Kn(Ft.prototype, function(e, t) {
   var n = Ht[t];
   if (n) {
    var r = n.name + "";
    (mo[r] || (mo[r] = [])).push({
     name: t,
     func: n
    })
   }
  }), mo[Jr(w, x).name] = [{
   name: "wrapper",
   func: w
  }], Ft.prototype.clone = function() {
   var e = new Ft(this.__wrapped__);
   return e.__actions__ = Ut(this.__actions__), e.__dir__ = this.__dir__, e.__filtered__ = this.__filtered__, e.__iteratees__ = Ut(this.__iteratees__), e.__takeCount__ = this.__takeCount__, e.__views__ = Ut(this.__views__), e
  }, Ft.prototype.reverse = function() {
   if (this.__filtered__) {
    var e = new Ft(this);
    e.__dir__ = -1, e.__filtered__ = !0
   } else e = this.clone(), e.__dir__ *= -1;
   return e
  }, Ft.prototype.value = function() {
   var e, t = this.__wrapped__.value(),
    n = this.__dir__,
    r = cu(t),
    i = 0 > n,
    s = r ? t.length : 0;
   e = s;
   for (var o = this.__views__, u = 0, a = -1, f = o.length; ++a < f;) {
    var l = o[a],
     c = l.size;
    switch (l.type) {
     case "drop":
      u += c;
      break;
     case "dropRight":
      e -= c;
      break;
     case "take":
      e = so(e, u + c);
      break;
     case "takeRight":
      u = io(u, e - c)
    }
   }
   if (e = {
     start: u,
     end: e
    }, o = e.start, u = e.end, e = u - o, i = i ? u : o - 1, o = this.__iteratees__, u = o.length, a = 0, f = so(e, this.__takeCount__), !r || s < H || s == e && f == e) return wr(t, this.__actions__);
   r = [];
   e: for (; e-- && a < f;) {
    for (i += n, s = -1, l = t[i]; ++s < u;) {
     var h = o[s],
      c = h.type,
      h = h.iteratee(l);
     if (c == j) l = h;
     else if (!h) {
      if (c == B) continue e;
      break e
     }
    }
    r[a++] = l
   }
   return r
  }, Ht.prototype.chain = function() {
   return Bi(this)
  }, Ht.prototype.commit = function() {
   return new jt(this.value(), this.__chain__)
  }, Ht.prototype.concat = jo, Ht.prototype.plant = function(e) {
   for (var t, n = this; n instanceof Bt;) {
    var r = Ni(n);
    t ? i.__wrapped__ = r : t = r;
    var i = r,
     n = n.__wrapped__
   }
   return i.__wrapped__ = e, t
  }, Ht.prototype.reverse = function() {
   function e(e) {
    return e.reverse()
   }
   var t = this.__wrapped__;
   return t instanceof Ft ? (this.__actions__.length && (t = new Ft(this)), t = t.reverse(), t.__actions__.push({
    func: ji,
    args: [e],
    thisArg: w
   }), new jt(t, this.__chain__)) : this.thru(e)
  }, Ht.prototype.toString = function() {
   return this.value() + ""
  }, Ht.prototype.run = Ht.prototype.toJSON = Ht.prototype.valueOf = Ht.prototype.value = function() {
   return wr(this.__wrapped__, this.__actions__)
  }, Ht.prototype.collect = Ht.prototype.map, Ht.prototype.head = Ht.prototype.first, Ht.prototype.select = Ht.prototype.filter, Ht.prototype.tail = Ht.prototype.rest, Ht
 }
 var w, E = "3.10.1",
  S = 1,
  x = 2,
  T = 4,
  N = 8,
  C = 16,
  k = 32,
  L = 64,
  A = 128,
  O = 256,
  M = 30,
  _ = "...",
  D = 150,
  P = 16,
  H = 200,
  B = 1,
  j = 2,
  F = "Expected a function",
  I = "__lodash_placeholder__",
  q = "[object Arguments]",
  R = "[object Array]",
  U = "[object Boolean]",
  z = "[object Date]",
  W = "[object Error]",
  X = "[object Function]",
  V = "[object Number]",
  $ = "[object Object]",
  J = "[object RegExp]",
  K = "[object String]",
  Q = "[object ArrayBuffer]",
  G = "[object Float32Array]",
  Y = "[object Float64Array]",
  Z = "[object Int8Array]",
  et = "[object Int16Array]",
  tt = "[object Int32Array]",
  nt = "[object Uint8Array]",
  rt = "[object Uint8ClampedArray]",
  it = "[object Uint16Array]",
  st = "[object Uint32Array]",
  ot = /\b__p\+='';/g,
  ut = /\b(__p\+=)''\+/g,
  at = /(__e\(.*?\)|\b__t\))\+'';/g,
  ft = /&(?:amp|lt|gt|quot|#39|#96);/g,
  lt = /[&<>"'`]/g,
  ct = RegExp(ft.source),
  ht = RegExp(lt.source),
  pt = /<%-([\s\S]+?)%>/g,
  dt = /<%([\s\S]+?)%>/g,
  vt = /<%=([\s\S]+?)%>/g,
  mt = /\.|\[(?:[^[\]]*|(["'])(?:(?!\1)[^\n\\]|\\.)*?\1)\]/,
  gt = /^\w*$/,
  yt = /[^.[\]]+|\[(?:(-?\d+(?:\.\d+)?)|(["'])((?:(?!\2)[^\n\\]|\\.)*?)\2)\]/g,
  bt = /^[:!,]|[\\^$.*+?()[\]{}|\/]|(^[0-9a-fA-Fnrtuvx])|([\n\r\u2028\u2029])/g,
  wt = RegExp(bt.source),
  Et = /[\u0300-\u036f\ufe20-\ufe23]/g,
  St = /\\(\\)?/g,
  xt = /\$\{([^\\}]*(?:\\.[^\\}]*)*)\}/g,
  Tt = /\w*$/,
  Nt = /^0[xX]/,
  Ct = /^\[object .+?Constructor\]$/,
  kt = /^\d+$/,
  Lt = /[\xc0-\xd6\xd8-\xde\xdf-\xf6\xf8-\xff]/g,
  At = /($^)/,
  Ot = /['\n\r\u2028\u2029\\]/g,
  Mt = RegExp("[A-Z\\xc0-\\xd6\\xd8-\\xde]+(?=[A-Z\\xc0-\\xd6\\xd8-\\xde][a-z\\xdf-\\xf6\\xf8-\\xff]+)|[A-Z\\xc0-\\xd6\\xd8-\\xde]?[a-z\\xdf-\\xf6\\xf8-\\xff]+|[A-Z\\xc0-\\xd6\\xd8-\\xde]+|[0-9]+", "g"),
  _t = "Array ArrayBuffer Date Error Float32Array Float64Array Function Int8Array Int16Array Int32Array Math Number Object RegExp Set String _ clearTimeout isFinite parseFloat parseInt setTimeout TypeError Uint8Array Uint8ClampedArray Uint16Array Uint32Array WeakMap".split(" "),
  Dt = {};
 Dt[G] = Dt[Y] = Dt[Z] = Dt[et] = Dt[tt] = Dt[nt] = Dt[rt] = Dt[it] = Dt[st] = !0, Dt[q] = Dt[R] = Dt[Q] = Dt[U] = Dt[z] = Dt[W] = Dt[X] = Dt["[object Map]"] = Dt[V] = Dt[$] = Dt[J] = Dt["[object Set]"] = Dt[K] = Dt["[object WeakMap]"] = !1;
 var Pt = {};
 Pt[q] = Pt[R] = Pt[Q] = Pt[U] = Pt[z] = Pt[G] = Pt[Y] = Pt[Z] = Pt[et] = Pt[tt] = Pt[V] = Pt[$] = Pt[J] = Pt[K] = Pt[nt] = Pt[rt] = Pt[it] = Pt[st] = !0, Pt[W] = Pt[X] = Pt["[object Map]"] = Pt["[object Set]"] = Pt["[object WeakMap]"] = !1;
 var Ht = {
   "À": "A",
   "Á": "A",
   "Â": "A",
   "Ã": "A",
   "Ä": "A",
   "Å": "A",
   "à": "a",
   "á": "a",
   "â": "a",
   "ã": "a",
   "ä": "a",
   "å": "a",
   "Ç": "C",
   "ç": "c",
   "Ð": "D",
   "ð": "d",
   "È": "E",
   "É": "E",
   "Ê": "E",
   "Ë": "E",
   "è": "e",
   "é": "e",
   "ê": "e",
   "ë": "e",
   "Ì": "I",
   "Í": "I",
   "Î": "I",
   "Ï": "I",
   "ì": "i",
   "í": "i",
   "î": "i",
   "ï": "i",
   "Ñ": "N",
   "ñ": "n",
   "Ò": "O",
   "Ó": "O",
   "Ô": "O",
   "Õ": "O",
   "Ö": "O",
   "Ø": "O",
   "ò": "o",
   "ó": "o",
   "ô": "o",
   "õ": "o",
   "ö": "o",
   "ø": "o",
   "Ù": "U",
   "Ú": "U",
   "Û": "U",
   "Ü": "U",
   "ù": "u",
   "ú": "u",
   "û": "u",
   "ü": "u",
   "Ý": "Y",
   "ý": "y",
   "ÿ": "y",
   "Æ": "Ae",
   "æ": "ae",
   "Þ": "Th",
   "þ": "th",
   "ß": "ss"
  },
  Bt = {
   "&": "&amp;",
   "<": "&lt;",
   ">": "&gt;",
   '"': "&quot;",
   "'": "&#39;",
   "`": "&#96;"
  },
  jt = {
   "&amp;": "&",
   "&lt;": "<",
   "&gt;": ">",
   "&quot;": '"',
   "&#39;": "'",
   "&#96;": "`"
  },
  Ft = {
   "function": !0,
   object: !0
  },
  It = {
   0: "x30",
   1: "x31",
   2: "x32",
   3: "x33",
   4: "x34",
   5: "x35",
   6: "x36",
   7: "x37",
   8: "x38",
   9: "x39",
   A: "x41",
   B: "x42",
   C: "x43",
   D: "x44",
   E: "x45",
   F: "x46",
   a: "x61",
   b: "x62",
   c: "x63",
   d: "x64",
   e: "x65",
   f: "x66",
   n: "x6e",
   r: "x72",
   t: "x74",
   u: "x75",
   v: "x76",
   x: "x78"
  },
  qt = {
   "\\": "\\",
   "'": "'",
   "\n": "n",
   "\r": "r",
   "\u2028": "u2028",
   "\u2029": "u2029"
  },
  Rt = Ft[typeof exports] && exports && !exports.nodeType && exports,
  Ut = Ft[typeof module] && module && !module.nodeType && module,
  zt = Ft[typeof self] && self && self.Object && self,
  Wt = Ft[typeof window] && window && window.Object && window,
  Xt = Ut && Ut.exports === Rt && Rt,
  Vt = Rt && Ut && typeof global == "object" && global && global.Object && global || Wt !== (this && this.window) && Wt || zt || this,
  $t = b();
 typeof define == "function" && typeof define.amd == "object" && define.amd ? (Vt._ = $t, define(function() {
  return $t
 })) : Rt && Ut ? Xt ? (Ut.exports = $t)._ = $t : Rt._ = $t : Vt._ = $t
}.call(this),
 function(e) {
  e(document).ready(function() {
   e.urlQueryParam = function(e) {
    try {
     var t = (new RegExp("[?&#]" + e + "=([^&#]*)")).exec(window.location.href);
     return t == null ? null : (t[1] && (t[1] = t[1].replace(/<(?:.|\n)*?>/gm, "")), t[1] || 0)
    } catch (n) {}
    return 0
   }, e.addReplaceQueryHash = function(e, t, n, r) {
    var i = e.split("#"),
     s = i[0],
     o = i[1],
     u = [];
    if (o) {
     var a = o.split("&");
     for (var f = 0; f < a.length; f++) a[f].split("=")[0] != t && u.push(a[f])
    }
    return n !== "" && n !== null && typeof n != "undefined" && u.push(t + "=" + encodeURI(n)), u.length > 0 && (s = s + "#" + u.join("&")), r && (window.location.href = s), s
   }
  })
 }(jQuery);
var oao_market_tld, oao_market_language = "de_DE",
 oao_hostName = window.location.hostname.split(".");
oao_market_tld = oao_hostName[oao_hostName.length - 1], oao_hostName = undefined;
var oaoTranslationLib = {};
(function(e) {
 function o(e) {
  try {
   var r = t[oao_market_language];
   r || (r = t[n]);
   var i = r[e];
   return i || (t[n][e] ? i = t[n][e] : i = e, console && console.log(["Found no translation for key", e, "in language", oao_market_language].join(" "))), i
  } catch (s) {
   console && console.log("Error in translate()", s)
  }
 }

 function u() {
  try {
   e("[data-i18n]").each(function() {
    var t = e(this),
     n = t.attr("data-i18n") === "{YEAR}" ? (new Date).getFullYear() : o(t.attr("data-i18n")),
     r = t.attr("data-i18n-attr").split(",");
    for (var i = r.length - 1; i >= 0; i--) {
     var s = r[i];
     switch (s) {
      case "text":
       t.text(n);
       break;
      case "html":
       t.html(n);
       break;
      case "value":
       t.val(n);
       break;
      default:
       t.attr(s, n)
     }
    }
   });
   var t = oao_market_language.split("_")[0];
   e("html").attr("lang", t)
  } catch (n) {
   console && console.log("Error in translateAll()", n)
  }
 }
 var t = {
   
   en_GB: {
    "oao.lang": "en",
    "oao.login": "Login",
    "oao.login.ionos": "1&1 IONOS",
    "oao.login.ionos.legal": "1&1 IONOS Ltd.",
    "oao.login.ionos.link": "https://www.ionos.co.uk/",
    "oao.login.datasecurity": "Privacy Policy",
    "oao.login.datasecurity.link": "https://www.ionos.co.uk/terms-gtc/terms-privacy/",
    "oao.login.title": "1&1 IONOS E-Mail login",
    "oao.login.description": "Login to access your 1&1 IONOS e-mail account and read your e-mail online with 1&1 IONOS Webmail.",
    "oao.login.canonical": "https://mail.ionos.co.uk",
    "oao.login.app": "Webmail",
    "oao.login.heading": "Webmail Login",
    "oao.login.email": "E-Mail",
    "oao.login.feedback": "Feedback",
    "oao.login.hidrive": "HiDrive",
    "oao.login.hidrive.link": "https://hidrive.ionos.com/",
    "oao.login.controlcenter": "My IONOS",
    "oao.login.controlcenter.link": "https://my.ionos.co.uk/",
    "oao.login.imprint.link": "https://www.ionos.co.uk/about",
    "oao.login.field.email": "E-mail Address",
    "oao.login.field.password": "Password",
    "oao.login.forgotpw.heading": "Forgot your password?",
    "oao.login.forgotpw.link": "https://www.ionos.co.uk/help/index.php?id=2327&utm_term=2327&utm_campaign=forgotpw&utm_medium=help-and-learn&utm_source=login_frontend_hosting&utm_content=flyin",
    "oao.login.forgotpw.description": "The contract owner can reset the password for this mailbox in My IONOS. If you are not the contract owner, please contact him or her to get a new password.",
    "oao.login.error.heading": "An error has occurred.",
    "oao.login.error.try-again-later": "Please try againbb later.",
    "oao.login.error.INVALIDCREDENTIALS": "You have entered an invalid e-mail address.",
    "oao.login.error.AUTHFAILED": "This e-mail address could not be found or the password is incorrect.",
    "oao.login.error.INTERNALERROR": "An internal error has occurred.",
    "oao.login.error.LOCKED": "Your mailbox is currently locked.",
    "oao.login.error.LOCKED.license": "Your mailbox is currently locked due to missing licences.",
    "oao.login.error.NOTPOSSIBLE": "Incorrect password or the e-mail address does not exist. The next login will be available in a few seconds.",
    "oao.login.error.MIGRATED": 'Wichtig: Als 1&1 IONOS Kunde können sich ab sofort nur noch über den neuen <a href="https://hidrive.ionos.com/" tabindex="7">Login 1&1 IONOS Kunden</a> anmelden.',
    "oao.login.cookie.information": "This website uses cookies. By using our website, you agree to our use of cookies.",
    "oao.login.cookie.more-info": "More info",
    "oao.login.cookie.more-info.link": "https://www.ionos.co.uk/details-cookieinfo",
    "oao.login.stay-signed-in": "Remember me",
    "oao.login.stay-signed-in.link": "https://www.ionos.co.uk/help/index.php?id=4083&utm_term=4083&utm_campaign=staysignedin&utm_medium=help-and-learn&utm_source=login_frontend_hosting&utm_content=flyin",
    "oao.login.morelogins.heading": "Other 1&1 IONOS Logins",
    "oao.login.setup.headline": "Set up your mailbox on other devices",
    "oao.login.setup.mobile": "Mobile",
    "oao.login.setup.mobile.link": "",
    "oao.login.setup.mobile.ios": "iOS",
    "oao.login.setup.mobile.ios.link": "https://www.ionos.co.uk/help/index.php?id=2442&utm_term=2442&utm_campaign=mobile-ios&utm_medium=help-and-learn&utm_source=login_frontend_hosting&utm_content=article",
    "oao.login.setup.mobile.android": "Android",
    "oao.login.setup.mobile.android.link": "https://www.ionos.co.uk/help/index.php?id=2444&utm_term=2444&utm_campaign=mobile-android&utm_medium=help-and-learn&utm_source=login_frontend_hosting&utm_content=article",
    "oao.login.setup.desktop": "Desktop",
    "oao.login.setup.desktop.thunderbird": "Thunderbird",
    "oao.login.setup.desktop.thunderbird.link": "https://www.ionos.co.uk/help/index.php?id=2436&utm_term=2436&utm_campaign=desktop-thunderbird&utm_medium=help-and-learn&utm_source=login_frontend_hosting&utm_content=article",
    "oao.login.setup.desktop.outlook": "Outlook",
    "oao.login.setup.desktop.outlook.link": "https://www.ionos.co.uk/help/index.php?id=2462&utm_term=2462&utm_campaign=desktop-outlook&utm_medium=help-and-learn&utm_source=login_frontend_hosting&utm_content=article",
    "oao.login.setup.desktop.applemail": "Apple Mail",
    "oao.login.setup.desktop.applemail.link": "https://www.ionos.co.uk/help/index.php?id=2445&utm_term=2445&utm_campaign=desktop-applemail&utm_medium=help-and-learn&utm_source=login_frontend_hosting&utm_content=article",
    "oao.login.setup.other": "Other",
    "oao.login.setup.other.assistants": "email programs (POP/IMAP)",
    "oao.login.setup.other.assistants.link": "https://www.ionos.co.uk/help/index.php?id=2490&utm_term=2490&utm_campaign=other-assistants&utm_medium=help-and-learn&utm_source=login_frontend_hosting&utm_content=article"
   },
   en_US: {
    "oao.lang": "en",
    "oao.login": "Login",
    "oao.login.ionos": "1&1 IONOS",
    "oao.login.ionos.legal": "1&1 IONOS Inc.",
    "oao.login.ionos.link": "https://www.ionos.com/",
    "oao.login.datasecurity": "Privacy Policy",
    "oao.login.datasecurity.link": "https://www.ionos.com/terms-gtc/terms-privacy/",
    "oao.login.title": "1&1 IONOS E-Mail login",
    "oao.login.description": "Login to access your 1&1 IONOS e-mail account and read your e-mail online with 1&1 IONOS Webmail.",
    "oao.login.canonical": "https://mail.ionos.com",
    "oao.login.app": "Webmail",
    "oao.login.heading": "Webmail Login",
    "oao.login.email": "E-Mail",
    "oao.login.feedback": "Feedback",
    "oao.login.hidrive": "HiDrive",
    "oao.login.hidrive.link": "https://hidrive.ionos.com/",
    "oao.login.controlcenter": "My IONOS",
    "oao.login.controlcenter.link": "https://my.ionos.com/",
    "oao.login.imprint.link": "https://www.ionos.com/about",
    "oao.login.field.email": "E-mail Address",
    "oao.login.field.password": "Password",
    "oao.login.forgotpw.heading": "Forgot your password?",
    "oao.login.forgotpw.link": "https://www.ionos.com/help/index.php?id=2327&utm_term=2327&utm_campaign=forgotpw&utm_medium=help-and-learn&utm_source=login_frontend_hosting&utm_content=flyin",
    "oao.login.forgotpw.description": "The contract owner can reset the password for this mailbox in My IONOS. If you are not the contract owner, please contact him or her to get a new password.",
    "oao.login.error.heading": "An error has occurred.",
    "oao.login.error.try-again-later": "Please try againc later.",
    "oao.login.error.INVALIDCREDENTIALS": "You have entered an invalid e-mail address.",
    "oao.login.error.AUTHFAILED": "This e-mail address could not be found or the password is incorrect.",
    "oao.login.error.INTERNALERROR": "An internal error has occurred.",
    "oao.login.error.LOCKED": "Your mailbox is currently locked.",
    "oao.login.error.LOCKED.license": "Your mailbox is currently locked due to missing licenses.",
    "oao.login.error.NOTPOSSIBLE": "Incorrect password or the e-mail address does not exist. The next login will be available in a few seconds.",
    "oao.login.error.MIGRATED": 'Wichtig: Als 1&1 IONOS Kunde können sich ab sofort nur noch über den neuen <a href="https://hidrive.ionos.com/" tabindex="7">Login 1&1 IONOS Kunden</a> anmelden.',
    "oao.login.cookie.information": "This website uses cookies. By using our website, you agree to our use of cookies.",
    "oao.login.cookie.more-info": "More info",
    "oao.login.cookie.more-info.link": "#",
    "oao.login.stay-signed-in": "Remember me",
    "oao.login.stay-signed-in.link": "https://www.ionos.com/help/index.php?id=4083&utm_term=4083&utm_campaign=staysignedin&utm_medium=help-and-learn&utm_source=login_frontend_hosting&utm_content=flyin",
    "oao.login.morelogins.heading": "Other 1&1 IONOS Logins",
    "oao.login.setup.headline": "Set up your mailbox on other devices",
    "oao.login.setup.mobile": "Mobile",
    "oao.login.setup.mobile.link": "",
    "oao.login.setup.mobile.ios": "iOS",
    "oao.login.setup.mobile.ios.link": "https://www.ionos.com/help/index.php?id=2442&utm_term=2442&utm_campaign=mobile-ios&utm_medium=help-and-learn&utm_source=login_frontend_hosting&utm_content=article",
    "oao.login.setup.mobile.android": "Android",
    "oao.login.setup.mobile.android.link": "https://www.ionos.com/help/index.php?id=2444&utm_term=2444&utm_campaign=mobile-android&utm_medium=help-and-learn&utm_source=login_frontend_hosting&utm_content=article",
    "oao.login.setup.desktop": "Desktop",
    "oao.login.setup.desktop.thunderbird": "Thunderbird",
    "oao.login.setup.desktop.thunderbird.link": "https://www.ionos.com/help/index.php?id=2436&utm_term=2436&utm_campaign=desktop-thunderbird&utm_medium=help-and-learn&utm_source=login_frontend_hosting&utm_content=article",
    "oao.login.setup.desktop.outlook": "Outlook",
    "oao.login.setup.desktop.outlook.link": "https://www.ionos.com/help/index.php?id=2462&utm_term=2462&utm_campaign=desktop-outlook&utm_medium=help-and-learn&utm_source=login_frontend_hosting&utm_content=article",
    "oao.login.setup.desktop.applemail": "Apple Mail",
    "oao.login.setup.desktop.applemail.link": "https://www.ionos.com/help/index.php?id=2445&utm_term=2445&utm_campaign=desktop-applemail&utm_medium=help-and-learn&utm_source=login_frontend_hosting&utm_content=article",
    "oao.login.setup.other": "Other",
    "oao.login.setup.other.assistants": "email programs (POP/IMAP)",
    "oao.login.setup.other.assistants.link": "https://www.ionos.com/help/index.php?id=2490&utm_term=2490&utm_campaign=other-assistants&utm_medium=help-and-learn&utm_source=login_frontend_hosting&utm_content=article"
   },
   es_ES: {
    "oao.lang": "es",
    "oao.login": "Iniciar sesión",
    "oao.login.ionos": "IONOS",
    "oao.login.ionos.legal": "1&1 IONOS España S.L.U.",
    "oao.login.ionos.link": "https://www.ionos.es/",
    "oao.login.datasecurity": "Política de privacidad",
    "oao.login.datasecurity.link": "https://www.ionos.es/terms-gtc/terms-privacy/",
    "oao.login.title": "IONOS by 1&1 Correo – Acceso a Webmail",
    "oao.login.description": "Accesa a Webmail de IONOS: puedes leer, escribir y administrar tus correos electrónicos.",
    "oao.login.canonical": "https://mail.ionos.es",
    "oao.login.app": "Webmail",
    "oao.login.heading": "Webmail Iniciar sesión",
    "oao.login.email": "Correo electrónico",
    "oao.login.feedback": "Comentario",
    "oao.login.hidrive": "HiDrive",
    "oao.login.hidrive.link": "https://hidrive.ionos.com/",
    "oao.login.controlcenter": "My IONOS",
    "oao.login.controlcenter.link": "https://my.ionos.es/",
    "oao.login.imprint.link": "https://www.ionos.es/empresa",
    "oao.login.field.email": "Dirección de correo electrónico",
    "oao.login.field.password": "Contraseña",
    "oao.login.forgotpw.heading": "¿Ha olvidado su contraseña?",
    "oao.login.forgotpw.description": "En My IONOS, el titular del contrato puede restablecer la contraseña de este buzón de correo electrónico. Si usted no es el titular, póngase en contacto con este último para obtener una contraseña nueva.",
    "oao.login.error.heading": "Se ha producido un error.",
    "oao.login.forgotpw.link": "https://www.ionos.es/ayuda/index.php?id=2327&utm_term=2327&utm_campaign=forgotpw&utm_medium=help-and-learn&utm_source=login_frontend_hosting&utm_content=flyin",
    "oao.login.error.try-again-later": "Vuelva a intentarlo más tarde.",
    "oao.login.error.INVALIDCREDENTIALS": "La dirección de correo electrónico introducida no es correcta.",
    "oao.login.error.AUTHFAILED": "La contraseña introducida no es correcta o no existe la dirección de correo electrónico.",
    "oao.login.error.INTERNALERROR": "Se ha producido un error interno.",
    "oao.login.error.LOCKED": "Ahora mismo su buzón está bloqueado.",
    "oao.login.error.LOCKED.license": "Ahora mismo su buzón está bloqueado debido a que faltan licencias.",
    "oao.login.error.NOTPOSSIBLE": "La contraseña introducida no es correcta o la dirección de e-mail no existe. Puedes intentar aceder de nuevo en pocos segundos.",
    "oao.login.error.MIGRATED": 'Wichtig: Als IONOS Kunde können sich ab sofort nur noch über den neuen <a href="https://hidrive.ionos.com/" tabindex="7">Login IONOS Kunden</a> anmelden.',
    "oao.login.cookie.information": "Esta página web utiliza cookies. Si continúa navegando por esta página web confirma aceptar el uso de las mismas.",
    "oao.login.cookie.more-info": "Más información",
    "oao.login.cookie.more-info.link": "#",
    "oao.login.stay-signed-in": "Permanecer registrado",
    "oao.login.stay-signed-in.link": "https://www.ionos.es/ayuda/index.php?id=4083&utm_term=4083&utm_campaign=staysignedin&utm_medium=help-and-learn&utm_source=login_frontend_hosting&utm_content=flyin",
    "oao.login.morelogins.heading": "Más inicios de sesión en IONOS",
    "oao.login.setup.headline": "Configure su buzón de correo en más dispositivos",
    "oao.login.setup.mobile": "Móvil",
    "oao.login.setup.mobile.link": "",
    "oao.login.setup.mobile.ios": "iOS",
    "oao.login.setup.mobile.ios.link": "https://www.ionos.es/ayuda/index.php?id=2442&utm_term=2442&utm_campaign=mobile-ios&utm_medium=help-and-learn&utm_source=login_frontend_hosting&utm_content=article",
    "oao.login.setup.mobile.android": "Android",
    "oao.login.setup.mobile.android.link": "https://www.ionos.es/ayuda/index.php?id=2444&utm_term=2444&utm_campaign=mobile-android&utm_medium=help-and-learn&utm_source=login_frontend_hosting&utm_content=article",
    "oao.login.setup.desktop": "Escritorio",
    "oao.login.setup.desktop.thunderbird": "Thunderbird",
    "oao.login.setup.desktop.thunderbird.link": "https://www.ionos.es/ayuda/index.php?id=2436&utm_term=2436&utm_campaign=desktop-thunderbird&utm_medium=help-and-learn&utm_source=login_frontend_hosting&utm_content=article",
    "oao.login.setup.desktop.outlook": "Outlook",
    "oao.login.setup.desktop.outlook.link": "https://www.ionos.es/ayuda/index.php?id=2462&utm_term=2462&utm_campaign=desktop-outlook&utm_medium=help-and-learn&utm_source=login_frontend_hosting&utm_content=article",
    "oao.login.setup.desktop.applemail": "Apple Mail",
    "oao.login.setup.desktop.applemail.link": "https://www.ionos.es/ayuda/index.php?id=2445&utm_term=2445&utm_campaign=desktop-applemail&utm_medium=help-and-learn&utm_source=login_frontend_hosting&utm_content=article",
    "oao.login.setup.other": "Otros",
    "oao.login.setup.other.assistants": "programas de correo electrónico (POP/IMAP)",
    "oao.login.setup.other.assistants.link": "https://www.ionos.es/ayuda/index.php?id=2490&utm_term=2490&utm_campaign=other-assistants&utm_medium=help-and-learn&utm_source=login_frontend_hosting&utm_content=article"
   },
   es_MX: {
    "oao.lang": "es",
    "oao.login": "Iniciar sesión",
    "oao.login.ionos": "1&1 IONOS",
    "oao.login.ionos.legal": "1&1 IONOS Inc.",
    "oao.login.ionos.link": "https://www.ionos.mx/",
    "oao.login.datasecurity": "Política de privacidad",
    "oao.login.datasecurity.link": "https://www.ionos.mx/terms-gtc/terms-privacy/",
    "oao.login.title": "1&1 IONOS E-MAIL – Acceso a Webmail",
    "oao.login.description": "Accesa a Webmail de 1&1 IONOS: puedes leer, escribir y administrar tus e-mails.",
    "oao.login.canonical": "https://mail.ionos.mx",
    "oao.login.app": "Webmail",
    "oao.login.heading": "Webmail Iniciar sesión",
    "oao.login.email": "E-mail",
    "oao.login.feedback": "Comentario",
    "oao.login.hidrive": "HiDrive",
    "oao.login.hidrive.link": "https://hidrive.ionos.com/",
    "oao.login.controlcenter": "My IONOS",
    "oao.login.controlcenter.link": "https://my.ionos.mx/",
    "oao.login.imprint.link": "https://www.ionos.mx/empresa",
    "oao.login.field.email": "Dirección de e-mail",
    "oao.login.field.password": "Contraseña",
    "oao.login.forgotpw.heading": "¿Has olvidado tu contraseña?",
    "oao.login.forgotpw.link": "https://www.ionos.mx/ayuda/index.php?id=2327&utm_term=2327&utm_campaign=forgotpw&utm_medium=help-and-learn&utm_source=login_frontend_hosting&utm_content=flyin",
    "oao.login.forgotpw.description": "En MY IONOS, el titular del contrato puede restablecer la contraseña de este buzón de e-mail. Si no constas como el titular del contrato, ponte en contacto con éste para solicitarle una nueva contraseña.",
    "oao.login.error.heading": "Se ha producido un error.",
    "oao.login.error.try-again-later": "Vuelve a intentarlo más tarde.",
    "oao.login.error.INVALIDCREDENTIALS": "La dirección de e-mail introducida no es correcta.",
    "oao.login.error.AUTHFAILED": "La contraseña introducida no es correcta o no existe la dirección de e-mail.",
    "oao.login.error.INTERNALERROR": "Se ha producido un error interno.",
    "oao.login.error.LOCKED": "Ahora mismo tu buzón está bloqueado.",
    "oao.login.error.LOCKED.license": "Ahora mismo tu buzón está bloqueado debido a que faltan licencias.",
    "oao.login.error.NOTPOSSIBLE": "La contraseña introducida no es correcta o la dirección de e-mail no existe. Puedes intentar aceder de nuevo en pocos segundos.",
    "oao.login.error.MIGRATED": "",
    "oao.login.cookie.information": "Esta página web utiliza cookies. Si continúas navegando por esta página web confirmas aceptar el uso de las mismas.",
    "oao.login.cookie.more-info": "Más información",
    "oao.login.cookie.more-info.link": "#",
    "oao.login.stay-signed-in": "Permanecer registrado",
    "oao.login.stay-signed-in.link": "https://www.ionos.mx/ayuda/index.php?id=4083&utm_term=4083&utm_campaign=staysignedin&utm_medium=help-and-learn&utm_source=login_frontend_hosting&utm_content=flyin",
    "oao.login.morelogins.heading": "Más inicios de sesión en 1&1 IONOS",
    "oao.login.setup.headline": "Configura tu buzón de e-mail en más dispositivos",
    "oao.login.setup.mobile": "Móvil",
    "oao.login.setup.mobile.link": "",
    "oao.login.setup.mobile.ios": "iOS",
    "oao.login.setup.mobile.ios.link": "https://www.ionos.mx/ayuda/index.php?id=2442&utm_term=2442&utm_campaign=mobile-ios&utm_medium=help-and-learn&utm_source=login_frontend_hosting&utm_content=article",
    "oao.login.setup.mobile.android": "Android",
    "oao.login.setup.mobile.android.link": "https://www.ionos.mx/ayuda/index.php?id=2444&utm_term=2444&utm_campaign=mobile-android&utm_medium=help-and-learn&utm_source=login_frontend_hosting&utm_content=article",
    "oao.login.setup.desktop": "Escritorio",
    "oao.login.setup.desktop.thunderbird": "Thunderbird",
    "oao.login.setup.desktop.thunderbird.link": "https://www.ionos.mx/ayuda/index.php?id=2436&utm_term=2436&utm_campaign=desktop-thunderbird&utm_medium=help-and-learn&utm_source=login_frontend_hosting&utm_content=article",
    "oao.login.setup.desktop.outlook": "Outlook",
    "oao.login.setup.desktop.outlook.link": "https://www.ionos.mx/ayuda/index.php?id=2462&utm_term=2462&utm_campaign=desktop-outlook&utm_medium=help-and-learn&utm_source=login_frontend_hosting&utm_content=article",
    "oao.login.setup.desktop.applemail": "Apple Mail",
    "oao.login.setup.desktop.applemail.link": "https://www.ionos.mx/ayuda/index.php?id=2445&utm_term=2445&utm_campaign=desktop-applemail&utm_medium=help-and-learn&utm_source=login_frontend_hosting&utm_content=article",
    "oao.login.setup.other": "Otros",
    "oao.login.setup.other.assistants": "programas de e-mail (POP/IMAP)",
    "oao.login.setup.other.assistants.link": "https://www.ionos.mx/ayuda/index.php?id=2490&utm_term=2490&utm_campaign=other-assistants&utm_medium=help-and-learn&utm_source=login_frontend_hosting&utm_content=article"
   },
   fr_FR: {
    "oao.lang": "fr",
    "oao.login": "Connexion",
    "oao.login.ionos": "1&1 IONOS",
    "oao.login.ionos.legal": "1&1 IONOS S.A.R.L.",
    "oao.login.ionos.link": "https://www.ionos.fr/",
    "oao.login.datasecurity": "Politique de confidentialité",
    "oao.login.datasecurity.link": "https://www.ionos.fr/terms-gtc/terms-privacy/",
    "oao.login.title": "1&1 IONOS E-mail : connexion à 1&1 IONOS Webmail",
    "oao.login.description": "IONOS Webmail : accédez à vos emails où que vous soyez.",
    "oao.login.canonical": "https://mail.ionos.fr",
    "oao.login.app": "Webmail",
    "oao.login.heading": "Webmail Connexion",
    "oao.login.email": "E-mail",
    "oao.login.feedback": "Feedback",
    "oao.login.hidrive": "HiDrive",
    "oao.login.hidrive.link": "https://hidrive.ionos.com/",
    "oao.login.controlcenter": "My IONOS",
    "oao.login.controlcenter.link": "https://my.ionos.fr/",
    "oao.login.imprint.link": "https://www.ionos.fr/apropos",
    "oao.login.field.email": "Adresse e-mail",
    "oao.login.field.password": "Mot de passe",
    "oao.login.forgotpw.heading": "Mot de passe oublié ?",
    "oao.login.forgotpw.link": "https://www.ionos.fr/assistance/index.php?id=2327&utm_term=2327&utm_campaign=forgotpw&utm_medium=help-and-learn&utm_source=login_frontend_hosting&utm_content=flyin",
    "oao.login.forgotpw.description": "Depuis My IONOS, le titulaire du contrat peut définir un nouveau mot de passe pour cette boîte e-mail. Si vous n'êtes pas le titulaire du contrat, veuillez vous adresser à ce dernier pour obtenir un nouveau mot de passe.",
    "oao.login.error.heading": "Une erreur est survenue.",
    "oao.login.error.try-again-later": "Veuillez réessayer ultérieurement.",
    "oao.login.error.INVALIDCREDENTIALS": "L'adresse e-mail saisie est incorrecte.",
    "oao.login.error.AUTHFAILED": "Le mot de passe saisi est incorrect ou l'adresse e-mail n'existe pas.",
    "oao.login.error.INTERNALERROR": "Une erreur interne est survenue.",
    "oao.login.error.LOCKED": "Votre boîte e-mail est actuellement bloquée.",
    "oao.login.error.LOCKED.license": "Suite à des licences manquantes, votre boîte e-mail est actuellement bloquée.",
    "oao.login.error.NOTPOSSIBLE": "L'adresse email ou bien le mot de passe que vous avez rentré n'existe pas. Vous pourrez réessayer de vous connecter dans quelques secondes.",
    "oao.login.error.MIGRATED": 'Wichtig: Als 1&1 IONOS Hosting Kunde können sich ab sofort nur noch über den neuen <a href="https://hidrive.ionos.com/" tabindex="7">Login 1&1 IONOS Kunden</a> anmelden.',
    "oao.login.cookie.information": "Ce site Web utilise des cookies. En poursuivant votre navigation sur ce site Web, vous acceptez l'utilisation de cookies.",
    "oao.login.cookie.more-info": "Plus d'informations",
    "oao.login.cookie.more-info.link": "#",
    "oao.login.stay-signed-in": "Rester connecté",
    "oao.login.stay-signed-in.link": "https://www.ionos.fr/assistance/index.php?id=4083&utm_term=4083&utm_campaign=staysignedin&utm_medium=help-and-learn&utm_source=login_frontend_hosting&utm_content=flyin",
    "oao.login.morelogins.heading": "Plus d'identifiants 1&1 IONOS",
    "oao.login.setup.headline": "Configurez votre boîte de réception sur d'autres appareils",
    "oao.login.setup.mobile": "Mobil",
    "oao.login.setup.mobile.link": "",
    "oao.login.setup.mobile.ios": "iOS",
    "oao.login.setup.mobile.ios.link": "https://www.ionos.fr/assistance/index.php?id=2442&utm_term=2442&utm_campaign=mobile-ios&utm_medium=help-and-learn&utm_source=login_frontend_hosting&utm_content=article",
    "oao.login.setup.mobile.android": "Android",
    "oao.login.setup.mobile.android.link": "https://www.ionos.fr/assistance/index.php?id=2444&utm_term=2444&utm_campaign=mobile-android&utm_medium=help-and-learn&utm_source=login_frontend_hosting&utm_content=article",
    "oao.login.setup.desktop": "Ordinateur de bureau",
    "oao.login.setup.desktop.thunderbird": "Thunderbird",
    "oao.login.setup.desktop.thunderbird.link": "https://www.ionos.fr/assistance/index.php?id=2436&utm_term=2436&utm_campaign=desktop-thunderbird&utm_medium=help-and-learn&utm_source=login_frontend_hosting&utm_content=article",
    "oao.login.setup.desktop.outlook": "Outlook",
    "oao.login.setup.desktop.outlook.link": "https://www.ionos.fr/assistance/index.php?id=2462&utm_term=2462&utm_campaign=desktop-outlook&utm_medium=help-and-learn&utm_source=login_frontend_hosting&utm_content=article",
    "oao.login.setup.desktop.applemail": "Apple Mail",
    "oao.login.setup.desktop.applemail.link": "https://www.ionos.fr/assistance/index.php?id=2445&utm_term=2445&utm_campaign=desktop-applemail&utm_medium=help-and-learn&utm_source=login_frontend_hosting&utm_content=article",
    "oao.login.setup.other": "Autres",
    "oao.login.setup.other.assistants": "programmes de messagerie (POP/IMAP)",
    "oao.login.setup.other.assistants.link": "https://www.ionos.fr/assistance/index.php?id=2490&utm_term=2490&utm_campaign=other-assistants&utm_medium=help-and-learn&utm_source=login_frontend_hosting&utm_content=article"
   },
   it_IT: {
    "oao.lang": "it",
    "oao.login": "Accedi",
    "oao.login.ionos": "1&1 IONOS",
    "oao.login.ionos.legal": "1&1 IONOS SE",
    "oao.login.ionos.link": "https://www.ionos.it/",
    "oao.login.datasecurity": "Privacy Policy",
    "oao.login.datasecurity.link": "https://www.ionos.it/terms-gtc/terms-privacy/",
    "oao.login.title": "1&1 IONOS Mail – Webmail Login",
    "oao.login.description": "Accesso alla Webmail di 1&1 IONOS: leggi, scrivi e gestisci le tue e-mail.",
    "oao.login.canonical": "https://mail.ionos.it",
    "oao.login.app": "Webmail",
    "oao.login.heading": "Accedi a Webmail",
    "oao.login.email": "E-mail",
    "oao.login.feedback": "Feedback",
    "oao.login.hidrive": "HiDrive",
    "oao.login.hidrive.link": "https://hidrive.ionos.com/",
    "oao.login.controlcenter": "My IONOS",
    "oao.login.controlcenter.link": "https://my.ionos.it/",
    "oao.login.imprint.link": "https://www.ionos.it/azienda",
    "oao.login.field.email": "Indirizzo e-mail",
    "oao.login.field.password": "Password",
    "oao.login.forgotpw.heading": "Dimenticato la password?",
    "oao.login.forgotpw.link": "https://www.ionos.it/aiuto/index.php?id=2327&utm_term=2327&utm_campaign=forgotpw&utm_medium=help-and-learn&utm_source=login_frontend_hosting&utm_content=flyin",
    "oao.login.forgotpw.description": "Il titolare del contratto ha la possibilità di reimpostare la password relativa a questa casella di posta nell My IONOS. Nel caso non fossi tu il titolare del contratto, ti preghiamo di rivolgerti a quest'ultimo al fine di ottenere una nuova password.",
    "oao.login.error.heading": "Si è verificato un errore.",
    "oao.login.error.try-again-later": "Riprova più tardi.",
    "oao.login.error.INVALIDCREDENTIALS": "L'indirizzo e-mail inserito non è corretto.",
    "oao.login.error.AUTHFAILED": "La password inserita non è corretta o l'account non esiste.",
    "oao.login.error.INTERNALERROR": "Si è verificato un errore interno.",
    "oao.login.error.LOCKED": "La casella di posta è al momento disabilitata.",
    "oao.login.error.LOCKED.license": "La casella di posta è al momento, per problemi di licenze, disabilitata.",
    "oao.login.error.NOTPOSSIBLE": "La password inserita non è corretta o l'indirizzo e-mail è inesistente. Il prossimo tentativo di accesso sarà possibile tra pochi secondi.",
    "oao.login.error.MIGRATED": "",
    "oao.login.cookie.information": "Questo sito web utilizza dei cookie. Procedendo con questo sito web acconsenti all'utilizzo dei cookie.",
    "oao.login.cookie.more-info": "Ulteriori informazioni",
    "oao.login.cookie.more-info.link": "#",
    "oao.login.stay-signed-in": "Rimani collegato",
    "oao.login.stay-signed-in.link": "https://www.ionos.it/aiuto/index.php?id=4083&utm_term=4083&utm_campaign=staysignedin&utm_medium=help-and-learn&utm_source=login_frontend_hosting&utm_content=flyin",
    "oao.login.morelogins.heading": "Altri accessi 1&1 IONOS",
    "oao.login.setup.headline": "Configura una casella di posta elettronica su ulteriori dispositivi",
    "oao.login.setup.mobile": "Dispositivi mobili",
    "oao.login.setup.mobile.link": "",
    "oao.login.setup.mobile.ios": "iOS",
    "oao.login.setup.mobile.ios.link": "https://www.ionos.it/aiuto/index.php?id=2442&utm_term=2442&utm_campaign=mobile-ios&utm_medium=help-and-learn&utm_source=login_frontend_hosting&utm_content=article",
    "oao.login.setup.mobile.android": "Android",
    "oao.login.setup.mobile.android.link": "https://www.ionos.it/aiuto/index.php?id=2444&utm_term=2444&utm_campaign=mobile-android&utm_medium=help-and-learn&utm_source=login_frontend_hosting&utm_content=article",
    "oao.login.setup.desktop": "Desktop",
    "oao.login.setup.desktop.thunderbird": "Thunderbird",
    "oao.login.setup.desktop.thunderbird.link": "https://www.ionos.it/aiuto/index.php?id=2436&utm_term=2436&utm_campaign=desktop-thunderbird&utm_medium=help-and-learn&utm_source=login_frontend_hosting&utm_content=article",
    "oao.login.setup.desktop.outlook": "Outlook",
    "oao.login.setup.desktop.outlook.link": "https://www.ionos.it/aiuto/index.php?id=2462&utm_term=2462&utm_campaign=desktop-outlook&utm_medium=help-and-learn&utm_source=login_frontend_hosting&utm_content=article",
    "oao.login.setup.desktop.applemail": "Apple Mail",
    "oao.login.setup.desktop.applemail.link": "https://www.ionos.it/aiuto/index.php?id=2445&utm_term=2445&utm_campaign=desktop-applemail&utm_medium=help-and-learn&utm_source=login_frontend_hosting&utm_content=article",
    "oao.login.setup.other": "Altri",
    "oao.login.setup.other.assistants": "client e-mail (POP/IMAP)",
    "oao.login.setup.other.assistants.link": "https://www.ionos.it/aiuto/index.php?id=2490&utm_term=2490&utm_campaign=other-assistants&utm_medium=help-and-learn&utm_source=login_frontend_hosting&utm_content=article"
   },
   pl_PL: {
    "oao.lang": "pl",
    "oao.login": "Zaloguj",
    "oao.login.ionos": "1&1 IONOS",
    "oao.login.ionos.legal": "1&1 IONOS SE",
    "oao.login.ionos.link": "https://www.ionos.pl/",
    "oao.login.datasecurity": "Privacy Policy",
    "oao.login.datasecurity.link": "https://www.ionos.pl/terms-gtc/terms-privacy/",
    "oao.login.title": "1&1 IONOS Webmail",
    "oao.login.description": "Login to access your 1&1 IONOS e-mail account and read your e-mail online with 1&1 IONOS Webmail.",
    "oao.login.canonical": "https://mail.ionos.pl",
    "oao.login.app": "Webmail",
    "oao.login.heading": "Webmail Zaloguj",
    "oao.login.email": "E-mail",
    "oao.login.feedback": "Feedback",
    "oao.login.hidrive": "HiDrive",
    "oao.login.hidrive.link": "https://hidrive.ionos.com/",
    "oao.login.controlcenter": "My IONOS",
    "oao.login.controlcenter.link": "https://my.ionos.pl/",
    "oao.login.imprint.link": "https://www.ionos.pl/about",
    "oao.login.field.email": "Adres e-mail",
    "oao.login.field.password": "Hasło",
    "oao.login.forgotpw.heading": "Nie pamiętasz hasła?",
    "oao.login.forgotpw.link": "https://pomoc.1and1.pl/poczta-e-mail-c30",
    "oao.login.forgotpw.description": "W My IONOS właściciel umowy może utworzyć nowe hasło do tej skrzynki pocztowej. Jeżeli nie jesteś właścicielem umowy, skontaktuj się z nim, aby otrzymać nowe hasło.",
    "oao.login.error.heading": "Wystąpił błąd.",
    "oao.login.error.try-again-later": "Spróbuj ponownie później.",
    "oao.login.error.INVALIDCREDENTIALS": "Podany adres e-mail jest nieprawidłowy.",
    "oao.login.error.AUTHFAILED": "Wprowadzone hasło jest nieprawidłowe lub adres e-mail nie istnieje.",
    "oao.login.error.INTERNALERROR": "Wystąpił wewnętrzny błąd.",
    "oao.login.error.LOCKED": "Twoja skrzynka pocztowa jest obecnie zablokowana.",
    "oao.login.error.LOCKED.license": "Twoja skrzynka pocztowa jest obecnie zablokowana ze względu na brak licencji.",
    "oao.login.error.NOTPOSSIBLE": "Podano nieprawidłowe hasło lub adres e-mail. Odczekaj kilka sekund i spróbuj zalogować się ponownie.",
    "oao.login.error.MIGRATED": "",
    "oao.login.cookie.information": "Ta strona internetowa korzysta z plików cookie. Pozostając na niej, wyrażasz zgodę na korzystanie z plików cookie.",
    "oao.login.cookie.more-info": "Więcej informacji",
    "oao.login.cookie.more-info.link": "#",
    "oao.login.stay-signed-in": "Zapamiętaj mnie",
    "oao.login.morelogins.heading": "Więcej logów 1&1 IONOS",
    "oao.login.setup.headline": "",
    "oao.login.setup.mobile": "",
    "oao.login.setup.mobile.link": "",
    "oao.login.setup.mobile.ios": "",
    "oao.login.setup.mobile.ios.link": "",
    "oao.login.setup.mobile.android": "",
    "oao.login.setup.mobile.android.link": "",
    "oao.login.setup.desktop": "Desktop",
    "oao.login.setup.desktop.thunderbird": "",
    "oao.login.setup.desktop.thunderbird.link": "",
    "oao.login.setup.desktop.outlook": "",
    "oao.login.setup.desktop.outlook.link": "",
    "oao.login.setup.desktop.applemail": "",
    "oao.login.setup.desktop.applemail.link": "",
    "oao.login.setup.other": "",
    "oao.login.setup.other.assistants": "",
    "oao.login.setup.other.assistants.link": ""
   },
   dummy: {}
  },
  n = oao_market_language = "en_GB",
  r = "en";
 switch (oao_market_tld) {
  case "de":
  case "localhost":
   oao_market_language = "de_DE", r = "de";
   break;
  case "es":
   oao_market_language = "es_ES", r = "es";
   break;
  case "mx":
   oao_market_language = "es_MX", r = "es";
   break;
  case "fr":
   oao_market_language = "fr_FR", r = "fr";
   break;
  case "it":
   oao_market_language = "it_IT", r = "it";
   break;
  case "pl":
   oao_market_language = "pl_PL", r = "pl";
   break;
  case "com":
  case "us":
  case "net":
   oao_market_language = "en_US", r = "en";
   break;
  case "ca":
   oao_market_language = "en_CA", r = "en";
   break;
  case "uk":
  default:
   oao_market_language = "en_GB", r = "en"
 }
 e("html").attr("lang", r);
 var i = (new RegExp("[?&]setLng=([^&#]*)")).exec(window.location.search);
 if (i) {
  var s = i[1];
  t[s] ? oao_market_language = s : console && console.log("Query parameter setLng contains an unknown language " + s)
 }
 oao_market_language.match(/(es_MX|it_IT|pl_PL)/) && e('[data-tab="onlinestorage"]').hide(), oaoTranslationLib.translate = o, e(document).ready(u)
})(jQuery),
function(e) {
 e(document).ready(function() {
  var t = function(t) {
   var n = {
    wrapSelector: ".details",
    headingSelector: "dt",
    contentSelector: "dd",
    closeContent: '<span class="close">x</span>',
    closeContentSelector: ".close",
    openByDefault: !1,
    openByDocumentEvent: ""
   };
   e.extend(!0, n, t);
   var r = function() {
     e(n.wrapSelector).find(n.contentSelector).hide()
    },
    i = function() {
     e(n.wrapSelector).find(n.contentSelector).show()
    };
   n.openByDefault ? i() : r(), n.openByDocumentEvent && e(document).on(n.openByDocumentEvent, function() {
    i()
   }), e(n.wrapSelector).find(n.headingSelector).on("click", function(t) {
    var r = e(t.currentTarget),
     i = r.siblings(n.contentSelector),
     s = e(n.closeContent);
    s.on("click", function() {
     i.fadeOut()
    }), i.append(s), i.fadeToggle()
   }), e(n.wrapSelector).find(n.headingSelector).keypress(function(t) {
    t.which == 13 && e(t.currentTarget).click()
   })
  };
  t({
   wrapSelector: ".details.forgotpw",
   openByDocumentEvent: "oao:login:failure:userpassword"
  })
 })
}(jQuery),
function(e) {
 e(document).ready(function() {
  var t = function(t) {
   var n = {
     SUCCESS: "notification-success",
     INFO: "notification-info",
     WARNING: "notification-warning",
     DANGER: "notification-danger"
    },
    r = {
     boxSelector: "#login-error",
     template: '<dl class="notification %s$1" data-prio="%i$1"><dt class="notification-heading">%s$2</dt><dd class="notification-description">%s$3</dd></dl>',
     type: "DANGER",
     heading: "",
     description: "",
     prio: 0
    };
   e.extend(!0, r, t), e(document).on("oao:notify", function(t, i) {
    var s = e.extend({}, r, i);
    e(s.boxSelector).hide(), s.template = s.template.replace("%s$1", n[s.type] || "notification-info"), s.template = s.template.replace("%s$2", s.heading), s.template = s.template.replace("%s$3", s.description), s.template = s.template.replace("%i$1", s.prio);
    if (s.append) e(s.boxSelector).append(s.template);
    else {
     var o = e(s.boxSelector).find(".notification[data-prio]"),
      u = 0;
     o.length > 0 && (u = parseInt(o.last().attr("data-prio")) || 0), u <= s.prio && e(s.boxSelector).html(s.template)
    }
    e(s.boxSelector).fadeIn()
   })
  };
  t()
 })
}(jQuery),
function(e) {
 e(document).ready(function() {
  try {
   var t = "cookie-information-do-not-show",
    n;
   localStorage ? n = localStorage.getItem(t) : n = e.cookie(t);
   var r = e("#cookieinfo-container").find("a"),
    i = e(r).attr("href");
   (!i || i == "#") && e(r).hide(), n != "true" && (e("#cookieinfo-container").fadeIn(), e("#cookieinfo-close").click(function() {
    localStorage ? localStorage.setItem(t, "true") : e.cookie(t, "true", {
     secure: !0,
     expires: 9999
    }), e("#cookieinfo-container").fadeOut()
   }))
  } catch (s) {
   console && console.log("error: ", s)
  }
 })
}(jQuery);
var OAO = OAO || {};
OAO.q = OAO.q || {}, OAO.q.c = OAO.q.c || [], OAO.q.statuspage = OAO.q.statuspage || [], OAO.q.navigation = OAO.q.navigation || [], OAO.q.pageintegration = OAO.q.pageintegration || [], OAO.q.c.push(["setPageName", "login"]), oao_market_language && OAO.q.c.push(["setLanguage", oao_market_language]),
 function(e) {
  e(document).ready(function() {
   try {
    var e = document.createElement("script");
    e.id = "oaotag", e.type = "text/javascript", e.async = "async", e.defer = "defer", e.src = "https://frontend-services.ionos.com/t/tag/IONOS/webmail-login.js";
    var t = document.getElementsByTagName("script")[0];
    t.parentNode.insertBefore(e, t)
   } catch (n) {
    console && console.log("OAO lib", n)
   }
  })
 }(jQuery);
var stay_logged_in = {
 cookieKey: "oao_stay_logged_in",
 saveUser: function(e) {
  e = e.split("?")[0], e = e.replace("https://", "").replace("/appsuite/", ""), $.cookie(this.cookieKey, JSON.stringify({
   appsuiteUrl: e
  }), {
   secure: !0,
   expires: 90
  })
 },
 isUserLoggedIn: function() {
  try {
   var e = this,
    t = $.cookie(this.cookieKey);
   t && (t = JSON.parse(t)), t && t.appsuiteUrl && !!(t.appsuiteUrl.match(/^(oxvdev3|oxvtest2\-wm|oxvtest2\-mx|oxvtest1\-wm|oxvtest1\-mx)(\.schlund\.)(de)$/i) || t.appsuiteUrl.match(/^(wde|mde)(\.ionos\.)(de)$/i) || t.appsuiteUrl.match(/^(email|mailbusiness)(\.ionos\.)(de|ca|co\.uk|com|es|mx|fr|it)$/i)) && $.ajax({
    url: ["https://", t.appsuiteUrl, "/appsuite/api/login?action=autologin&client=open-xchange-appsuite"].join(""),
    dataType: "text/javascript",
    xhrFields: {
     withCredentials: !0
    }
   }).always(function(n) {
    e.redirectUserWithSession(n, ["https://", t.appsuiteUrl, "/appsuite/"].join(""))
   })
  } catch (n) {}
 },
 redirectUserWithSession: function(e, t) {
  if (e && e.status === 200) {
   var n = JSON.parse(e.responseText);
   n.session ? window.location.href = t : this.removeCookie()
  } else this.removeCookie()
 },
 removeCookie: function() {
  $.removeCookie(this.cookieKey)
 }
};
typeof define != "undefined" && define("stay_logged_in", [], function() {
 return stay_logged_in
}), typeof module != "undefined" && (module.exports = stay_logged_in);
var stay_logged_in = stay_logged_in || {},
 oao_moc_login = {
  _possibleUuidChars: "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789",
  _getRandomUUID: function() {
   var e = this,
    t = "";
   for (var n = 0; n < 32; n++) {
    var r = Math.floor(Math.random() * e._possibleUuidChars.length);
    t += e._possibleUuidChars.charAt(r)
   }
   return t
  },
  checkDeps: function() {
   try {
    $ = jQuery
   } catch (e) {
    throw console && console.log("error: ", e), "We're sorry, but this login-lib needs jQuery for Ajax-Calls and Events => http://jquery.com/download/ - and should be fetched via jQuery.ajax({url:loginLibUrl,dataType:'script',cache:true/false})"
   }
  },
  redirectUser: function(e, t) {
   t || (console && console.info("redirect to: " + e), window.location.href = e)
  },
  getHostname: function(e) {
   var t = typeof window != "undefined" ? window.location.hostname : e || "";
   return t = t && t.match(/^[a-zA-Z0-9\-\\.]+$/) ? t : "invalid.hostname", t
  },
  getHostnameTld: function(e) {
   e = e ? e : "de";
   var t = typeof window != "undefined" ? window.location.hostname.split(".") : e.split("."),
    n = t[t.length - 1];
   return n.match(/^localhost|^[0-9]{1,3}/) && (n = e), n.match(/^[a-zA-Z]{2,3}$/) ? n.toLowerCase() : "de"
  },
  mailLogin: function(e, t, n, r) {
   var i = this;
   $(document).trigger("oao:login:start");
   var s = this._getRandomUUID(),
    o = this._getRandomUUID();
   n = !!n;
   var u = (new Date).getTime(),
    a = i.getHostname(),
    f = i.getHostnameTld(),
    l = function(e) {
     if (e && e.status == "SUCCESS" && e.resultUri) {
      $(document).trigger("oao:login:success", e);
      var t = String(encodeURI(e.resultUri + "&clientToken=" + s));
      r && stay_logged_in.saveUser(t), i.redirectUser(t)
     } else c(e)
    },
    c = function(e) {
     e.resultHash = "tab=email";
     if (n && e && e.resultUri && e.status) {
      var t = [e.resultUri, "?status=", e.status].join("");
      e.reason && (t = [t, "&reason=", e.reason].join("")), e.resultHash && (t = [t, e.resultHash].join("#")), i.redirectUser(String(encodeURI(t)))
     }
     $(document).trigger("oao:login:failure", e)
    },
    h;
   return e && t ? h = $.ajax({
    url: ["/loginservice/", f, "?origin=", a, "&authId=", o].join(""),
    dataType: "json",
    headers: {
     "X-VERSION": "oao_hosting",
     "X-SLI": r ? "true" : ""
    },
    data: JSON.stringify({
     username: $.trim(e),
     password: t,
     clienttoken: s,
     timestamp: u
    }),
    contentType: "application/json;charset=utf-8",
    method: "POST"
   }) : h = (new $.Deferred).reject({
    status: "INVALIDCREDENTIALS"
   }), h.done(function(e) {
    l(e)
   }), h.fail(function(e) {
    e = e.responseJSON ? e.responseJSON : e || {}, c(e)
   }), h.promise()
  }
 };
oao_moc_login.checkDeps(), typeof define != "undefined" && define("oao_moc_login", [], function() {
  return oao_moc_login
 }), typeof module != "undefined" && (module.exports = oao_moc_login),
 function(e) {
  e(document).ready(function() {
   var t = function(e) {
     return e.match(/^[\w\-\\.]*@[\w\-\\.]*$/)
    },
    n = "#login-form",
    r = "#username",
    i = "#password",
    s = "#staysignedin-box",
    o = function() {
     var o = e.urlQueryParam("username") || e.urlQueryParam("Username");
     o && t(o) && e(r).val(o), stay_logged_in.isUserLoggedIn(), e(n).on("submit", function(t) {
      var n = e(r).val(),
       o = e(i).val(),
       u = !1,
       a = e(s).is(":checked");
      oao_moc_login.mailLogin(n, o, u, a)
     })
    };
   o();
   var u = "loading",
    a = function(t) {
     switch (t) {
      case "loading":
       e('button[type="submit"]').addClass(u);
       break;
      default:
       e('button[type="submit"]').removeClass(u)
     }
    };
   e(document).on("oao:login:start", function() {
    a("loading")
   }), e(document).on("oao:login:success", function() {
    a()
   }), e(document).on("oao:login:failure", function() {
    a()
   }), e(document).on("oao:login:failure", function(t, n) {
    var r = "DANGER",
     i = oaoTranslationLib.translate("oao.login.error.heading"),
     s = oaoTranslationLib.translate("oao.login.error.try-again-later");
    try {
     if (n && n.status) switch (n.status) {
      case "INVALIDCREDENTIALS":
       s = oaoTranslationLib.translate("oao.login.error.INVALIDCREDENTIALS");
       break;
      case "AUTHFAILED":
      case "UNPRIVILEDGED":
       s = oaoTranslationLib.translate("oao.login.error.AUTHFAILED"), e(document).trigger("oao:login:failure:userpassword");
       break;
      case "INTERNALERROR":
      case "CLIENTERROR":
       s = oaoTranslationLib.translate("oao.login.error.INTERNALERROR"), e(document).trigger("oao:login:failure:errorPartial");
       break;
      case "LOCKED":
       switch (n.reason) {
        case "license":
         s = oaoTranslationLib.translate("oao.login.error.LOCKED.license");
         break;
        default:
         s = oaoTranslationLib.translate("oao.login.error.LOCKED")
       }
       break;
      case "NOTPOSSIBLE":
       s = oaoTranslationLib.translate("oao.login.error.NOTPOSSIBLE");
       break;
      case "MIGRATED":
       s = oaoTranslationLib.translate("oao.login.error.MIGRATED");
       break;
      default:
       s = oaoTranslationLib.translate("oao.login.error.INTERNALERROR")
     }
    } catch (o) {
     console && console.log("error: ", o)
    }
    var u = {
     type: r,
     heading: i,
     description: s,
     prio: 50
    };
    e(document).trigger("oao:notify", u)
   });
   var f = {};
   f.status = e.urlQueryParam("status") || null, f.reason = e.urlQueryParam("reason") || null, f.status && !f.status.match(/^[\w\d\s\\.]*$/) && (f.status = null), f.reason && !f.reason.match(/^[\w\d\s\\.]*$/) && (f.reason = null), f.status && e(document).trigger("oao:login:failure", f)
  })
 }(jQuery),
 function(e, t, n) {
  e(document).ready(function() {
   e.ajax({
    cache: !0,
    dataType: "json",
    url: "maintenance/status.json",
    success: function(r) {
     var i = t.now(),
      s = t.get(r, "notification");
     if (s && t.get(s, "default") && t.get(s, n)) {
      var o = {};
      t.assign(o, t.get(s, "default"), t.get(s, n));
      if (i > o.active_from && i < o.active_to && o.date_from && o.date_to) {
       var u = (new Date(o.date_from)).toLocaleDateString(),
        a = (new Date(o.date_to)).toLocaleDateString();
       o.content = o.content.replace("%s", u), o.content = o.content.replace("%s", a), e(document).trigger("oao:notify", {
        type: "INFO",
        heading: o.header,
        description: o.content,
        prio: 0,
        append: !1
       }), console && console.log("maintenance > notification: active", o)
      }
     }
     var f = t.get(r, "errorPartial");
     if (f) {
      console && console.info("errorPartial");
      if (t.get(f, "default") && t.get(f, n)) {
       var l = {};
       t.assign(l, t.get(f, "default"), t.get(f, n)), e(document).on("oao:login:failure:errorPartial", function() {
        e(document).trigger("oao:notify", {
         type: "WARNING",
         heading: l.header,
         description: l.content,
         prio: 100,
         append: !1
        })
       }), console && console.log("maintenance > errorPartial: active", l)
      }
     }
     var c = t.get(r, "errorAll");
     if (c) {
      console && console.info("errorAll");
      if (t.get(c, "default") && t.get(c, n)) {
       var h = {};
       t.assign(h, t.get(c, "default"), t.get(c, n)), e(document).trigger("oao:notify", {
        type: "WARNING",
        heading: h.header,
        description: h.content,
        prio: 10,
        append: !1
       }), console && console.log("maintenance > errorAll: active", h)
      }
     }
    }
   })
  })
 }(jQuery, _, oao_market_language);
var $buoop = {
  vs: {
   i: 8,
   f: 32,
   o: 32,
   s: 9,
   n: 20,
   c: 47
  },
  reminder: 0,
  reminderClosed: 24,
  test: !1,
  newwindow: !0
 },
 $buo = function(e, t) {
  function n(e) {
   var t, n, r = e || navigator.userAgent,
    i = {
     i: "Internet Explorer",
     f: "Firefox",
     o: "Opera",
     s: "Apple Safari",
     n: "Netscape Navigator",
     c: "Chrome",
     x: "Other"
    };
   if (/bot|googlebot|facebook|slurp|wii|silk|blackberry|maxthon|maxton|mediapartners|dolfin|dolphin|adsbot|silk|android|phone|bingbot|google web preview|like firefox|chromeframe|seamonkey|opera mini|min|meego|netfront|moblin|maemo|arora|camino|flot|k-meleon|fennec|kazehakase|galeon|android|mobile|iphone|ipod|ipad|epiphany|konqueror|rekonq|symbian|webos|coolnovo|blackberry|bb10|RIM|PlayBook|PaleMoon|QupZilla|YaBrowser/i.test(r)) t = "x";
   else if (/Trident.*rv:(\d+\.\d+)/i.test(r)) t = "i";
   else if (/Trident.(\d+\.\d+)/i.test(r)) t = "io";
   else if (/MSIE.(\d+\.\d+)/i.test(r)) t = "i";
   else if (/OPR.(\d+\.\d+)/i.test(r)) t = "o";
   else if (/Chrome.(\d+\.\d+)/i.test(r)) t = "c";
   else if (/Firefox.(\d+\.\d+)/i.test(r)) t = "f";
   else if (/Version.(\d+.\d+).{0,10}Safari/i.test(r)) t = "s";
   else if (/Safari.(\d+)/i.test(r)) t = "so";
   else if (/Opera.*Version.(\d+\.\d+)/i.test(r)) t = "o";
   else if (/Opera.(\d+\.?\d+)/i.test(r)) t = "o";
   else {
    if (!/Netscape.(\d+)/i.test(r)) return {
     n: "x",
     v: 0,
     t: i[t]
    };
    t = "n"
   }
   n = parseFloat(RegExp.$1);
   var s = !1;
   return /windows.nt.5.0|windows.nt.4.0|windows.98|os x 10.4|os x 10.5|os x 10.3|os x 10.2/.test(r) && (s = "oldOS"), "f" != t || 24 != Math.round(n) && 31 != Math.round(n) || (s = "ESR"), /linux|x11|unix|bsd/.test(r) && "o" == t && n > 12 && (s = "Opera12Linux"), "x" == t ? {
    n: "x",
    v: n || 0,
    t: i[t],
    donotnotify: s
   } : ("so" == t && (n = 100 > n && 1 || 130 > n && 1.2 || 320 > n && 1.3 || 520 > n && 2 || 524 > n && 3 || 526 > n && 3.2 || 4, t = "s"), "i" == t && 7 == n && window.XDomainRequest && (n = 8), "io" == t && (t = "i", n = n > 6 ? 11 : n > 5 ? 10 : n > 4 ? 9 : n > 3.1 ? 8 : n > 3 ? 7 : 9), {
    n: t,
    v: n,
    t: i[t] + " " + n,
    donotnotify: s
   })
  }

  function r(e) {
   var t = new Date((new Date).getTime() + 36e5 * e);
   document.cookie = "browserupdateorg=pause; expires=" + t.toGMTString() + "; path=/"
  }

  function i() {
   for (var e = arguments, t = e[0], n = 1; n < e.length; ++n) t = t.replace(/%s/, e[n]);
   return t
  }
  var s, o = window.navigator;
  this.op = e || {}, this.op.l = e.l || (o.languages ? o.languages[0] : null) || o.language || o.browserLanguage || o.userLanguage || document.documentElement.getAttribute("lang") || "en";
  var u = this.op.l.substr(0, 2);
  this.op.vsakt = {
   i: 11,
   f: 44,
   o: 32,
   s: 9,
   n: 20,
   c: 47
  }, this.op.vsdefault = {
   i: 9,
   f: 34,
   o: 12.1,
   s: 6.2,
   n: 12,
   c: 29
  }, this.op.vsmin = {
   i: 8,
   f: 5,
   o: 12,
   s: 5.1,
   n: 12
  }, e.vs || {}, this.op.vs = e.vs || this.op.vsdefault;
  for (s in this.op.vsakt) this.op.vs[s] >= this.op.vsakt[s] && (this.op.vs[s] = this.op.vsakt[s] - .2), this.op.vs[s] || (this.op.vs[s] = this.op.vsdefault[s]), this.op.vs[s] < this.op.vsmin[s] && (this.op.vs[s] = this.op.vsmin[s]);
  if (e.reminder < .1 || 0 === e.reminder ? this.op.reminder = 0 : this.op.reminder = e.reminder || 24, this.op.reminderClosed = e.reminderClosed || 168, this.op.onshow = e.onshow || function(e) {}, this.op.onclick = e.onclick || function(e) {}, this.op.onclose = e.onclose || function(e) {}, this.op.url = e.url || "//whatbrowser.org", e.l && (this.op.url = e.url || "//whatbrowser.org"), this.op.pageurl = e.pageurl || window.location.hostname || "unknown", this.op.newwindow = e.newwindow !== !1, this.op.test = t || e.test || !1, "#test-bu" == window.location.hash && (this.op.test = !0), this.op.browser = n(), this.op.test || !(!this.op.browser || !this.op.browser.n || "x" == this.op.browser.n || this.op.browser.donotnotify !== !1 || document.cookie.indexOf("browserupdateorg=pause") > -1 && this.op.reminder > 0 || this.op.browser.v > this.op.vs[this.op.browser.n])) {
   this.op.reminder > 0 && r(this.op.reminder);
   var a = "xx,jp,sl,id,uk,rm,da,ca,sv,hu,fa,gl";
   a.indexOf(u) > 0 && (this.op.url = "//whatbrowser.org");
   var f = "";
   this.op.newwindow && (f = ' target="_blank"');
   var l = "This website would like to remind you: Your browser (%s) is <b>out of date</b>. <a%s>Update your browser</a> for more security, comfort and the best experience on this site.";
   "de" == u ? l = "Sie verwenden einen <b>veralteten Browser</b> (%s) mit <b>Sicherheitsschwachstellen</b> und <b>k&ouml;nnen nicht alle Funktionen dieser Webseite nutzen</b>. <a%s>Hier erfahren Sie, wie einfach Sie Ihren Browser aktualisieren k&ouml;nnen</a>." : "it" == u ? l = "Il tuo browser (%s) <b>non è aggiornato</b>. Ha delle <b>falle di sicurezza</b> e potrebbe <b>non visualizzare correttamente</b> le pagine di questo e altri siti. <a%s>Aggiorna il tuo browser</a>!" : "pl" == u ? l = "Przeglądarka (%s), której używasz, jest przestarzała. Posiada ona udokumentowane <b>luki bezpieczeństwa, inne wady</b> oraz <b>ograniczoną funkcjonalność</b>. Tracisz możliwość skorzystania z pełni możliwości oferowanych przez niektóre strony internetowe. <a%s>Dowiedz się jak zaktualizować swoją przeglądarkę</a>." : "es" == u ? l = "Su navegador (%s) <b>no está actualizado</b>. Tiene <b>fallos de seguridad</b> conocidos y podría <b>no mostrar todas las características</b> de este y otros sitios web. <a%s>Averigüe cómo actualizar su navegador.</a>" : "nl" == u ? l = "Uw browser (%s) is <b>oud</b>. Het heeft bekende <b>veiligheidsissues</b> en kan <b>niet alle mogelijkheden</b> weergeven van deze of andere websites. <a%s>Lees meer over hoe uw browser te upgraden</a>" : "pt" == u ? l = "Seu navegador (%s) está <b>desatualizado</b>. Ele possui <b>falhas de segurança</b> e pode <b>apresentar problemas</b> para exibir este e outros websites. <a%s>Veja como atualizar o seu navegador</a>" : "sl" == u ? l = "Vaš brskalnik (%s) je <b>zastarel</b>. Ima več <b>varnostnih pomankljivosti</b> in morda <b>ne bo pravilno prikazal</b> te ali drugih strani. <a%s>Poglejte kako lahko posodobite svoj brskalnik</a>" : "ru" == u ? l = "Ваш браузер (%s) <b>устарел</b>. Он имеет <b>уязвимости в безопасности</b> и может <b>не показывать все возможности</b> на этом и других сайтах. <a%s>Узнайте, как обновить Ваш браузер</a>" : "id" == u ? l = "Browser Anda (%s) sudah <b>kedaluarsa</b>. Browser yang Anda pakai memiliki <b>kelemahan keamanan</b> dan mungkin <b>tidak dapat menampilkan semua fitur</b> dari situs Web ini dan lainnya. <a%s> Pelajari cara memperbarui browser Anda</a>" : "uk" == u ? l = "Ваш браузер (%s) <b>застарів</b>. Він <b>уразливий</b> й може <b>не відображати всі можливості</b> на цьому й інших сайтах. <a%s>Дізнайтесь, як оновити Ваш браузер</a>" : "ko" == u ? l = "지금 사용하고 계신 브라우저(%s)는 <b>오래되었습니다.</b> 알려진 <b>보안 취약점</b>이 존재하며, 새로운 웹 사이트가 <b>깨져 보일 수도</b> 있습니다. <a%s>브라우저를 어떻게 업데이트하나요?</a>" : "rm" == u ? l = "Tes navigatur (%s) è <b>antiquà</b>. El cuntegna <b>problems da segirezza</b> enconuschents e mussa eventualmain <b>betg tut las funcziuns</b> da questa ed autras websites. <a%s>Emprenda sco actualisar tes navigatur</a>." : "ja" == u ? l = "お使いのブラウザ「%s」は、<b>時代遅れ</b>のバージョンです。既知の<b>脆弱性</b>が存在するばかりか、<b>機能不足</b>によって、サイトが正常に表示できない可能性があります。<a%s>ブラウザを更新する方法を確認する</a>" : "fr" == u ? l = "Votre navigateur (%s) est <b>périmé</b>. Il contient des <b>failles de sécurité</b> et pourrait <b>ne pas afficher certaines fonctionalités</b> des sites internet récents. <a%s>Découvrez comment mettre votre navigateur à jour</a>" : "da" == u ? l = "Din browser (%s) er <b>for&aelig;ldet</b>. Den har kendte <b>sikkerhedshuller</b> og kan m&aring;ske <b>ikke vise alle funktioner</b> p&aring; dette og andre websteder. <a%s>Se hvordan du opdaterer din browser</a>" : "sq" == u ? l = "Shfletuesi juaj (%s) është <b>ca i vjetër</b>. Ai ka <b>të meta sigurie</b> të njohura dhe mundet të <b>mos i shfaqë të gjitha karakteristikat</b> e kësaj dhe shumë faqeve web të tjera. <a%s>Mësoni se si të përditësoni shfletuesin tuaj</a>" : "ca" == u ? l = "El teu navegador (%s) està <b>desactualitzat</b>. Té <b>vulnerabilitats</b> conegudes i pot <b>no mostrar totes les característiques</b> d'aquest i altres llocs web. <a%s>Aprèn a actualitzar el navegador</a>" : "tr" == u ? l = "Tarayıcınız (%s) <b>güncel değildir.</b>. Eski versiyon olduğu için <b>güvenlik açıkları</b> vardır ve görmek istediğiniz bu web sitesinin ve diğer web sitelerinin <b>tüm özelliklerini hatasız bir şekilde</b> gösteremeyecektir. <a%s>Tarayıcınızı nasıl güncelleyeceğinizi öğrenin!</a>" : "fa" == u ? l = "مرورگر شما (%s) <b>از رده خارج شده</b> می باشد. این مرورگر دارای <b>مشکلات امنیتی شناخته شده</b> می باشد و <b>نمی تواند تمامی ویژگی های این</b> وب سایت و دیگر وب سایت ها را به خوبی نمایش دهد. <a%s>در خصوص گرفتن راهنمایی درخصوص نحوه ی به روز رسانی مرورگر خود اینجا کلیک کنید.</a>" : "sv" == u ? l = "Din webbläsare (%s) är <b>föråldrad</b>. Den har kända <b>säkerhetshål</b> och <b>kan inte visa alla funktioner korrekt</b> på denna och på andra webbsidor. <a%s>Uppdatera din webbläsare idag</a>" : "hu" == u ? l = "Az Ön böngészője (%s) <b>elavult</b>. Ismert <b>biztonsági hiányosságai</b> vannak és esetlegesen <b>nem tud minden funkciót megjeleníteni</b> ezen vagy más weboldalakon. <a%s>Itt talál bővebb információt a böngészőjének frissítésével kapcsolatban</a" : "gl" == u ? l = "O seu navegador (%s) está <b>desactualizado</b>. Ten coñecidos <b>fallos de seguranza</b> e podería <b>non mostrar tódalas características</b> deste e outros sitios web. <a%s>Aprenda como pode actualizar o seu navegador</a>" : "cs" == u ? l = "Váš prohlížeč (%s) je <b>zastaralý</b>. Jsou známy <b>bezpečnostní rizika</b> a možná <b>nedokáže zobrazit všechny prvky</b> této a dalších webových stránek. <a%s>Naučte se, jak aktualizovat svůj prohlížeč</a>" : "he" == u ? l = "הדפדפן שלך (%s) <b>אינו מעודכן</b>. יש לו <b>בעיות אבטחה ידועות</b> ועשוי <b>לא להציג את כל התכונות</b> של אתר זה ואתרים אחרים. <a%s>למד כיצד לעדכן את הדפדפן שלך</a>" : "nb" == u ? l = "Nettleseren din (%s) er <b>utdatert</b>. Den har kjente <b>sikkerhetshull</b> og <b>kan ikke vise alle funksjonene</b> på denne og andre websider. <a%s>Lær hvordan du kan oppdatere din nettleser</a>" : "zh" == u ? l = "您的浏览器(%s) 需要更新。该浏览器有诸多安全漏洞，无法显示本网站的所有功能。 <a%s>了解如何更新浏览器</a>" : "fi" == u ? l = "Selaimesi (%s) on <b>vanhentunut</b>. Siinä on tunnettuja tietoturvaongelmia eikä se välttämättä tue kaikkia ominaisuuksia tällä tai muilla sivustoilla. <a%s>Lue lisää siitä kuinka päivität selaimesi</a>." : "tr" == u ? l = "Tarayıcınız (%s) <b>güncel değil</b>. Eski versiyon olduğu için <b>güvenlik açıkları</b> vardır ve görmek istediğiniz bu web sitesinin ve diğer web sitelerinin <b>tüm özelliklerini hatasız bir şekilde</b> gösteremeyecektir. <a%s>Tarayıcınızı nasıl güncelleyebileceğinizi öğrenin</a>" : "ro" == u ? l = "Browser-ul (%s) tau este <b>invechit</b>. Detine <b>probleme de securitate</b> cunoscute si poate <b>sa nu afiseze corect</b> toate elementele acestui si altor site-uri. <a%s>Invata cum sa-ti actualizezi browserul.</a>" : "bg" == u ? l = "Вашият браузър (%s) <b>не е актуален</b>. Известно е, че има <b>пропуски в сигурността</b> и може <b>да не покаже правилно</b> този или други сайтове. <a%s>Научете как да актуализирате браузъра си</a>." : "el" == u && (l = "Αυτός ο ιστότοπος σας υπενθυμίζει: Ο φυλλομετρητής σας (%s) είναι <b>παρωχημένος</b>. <a%s>Ενημερώστε το πρόγραμμα περιήγησής σας</a> για μεγαλύτερη ασφάλεια και άνεση σε αυτήν την ιστοσελίδα."), e.text && (l = e.text), e["text_" + u] && (l = e["text_" + u]), this.op.text = i(l, this.op.browser.t, ' href="' + this.op.url + '"' + f);
   var c = document.createElement("div");
   this.op.div = c, c.id = "buorg", c.className = "buorg", c.innerHTML = "<div>" + this.op.text + '<div id="buorgclose">&times;</div></div>';
   var h = document.createElement("style"),
    p = ".buorg {position:absolute;position:fixed;z-index:111111;width:100%; top:0px; left:0px;border-bottom:1px solid #A29330;background:#FDF2AB no-repeat 13px center url(//browser-update.org/img/small/" + this.op.browser.n + ".gif);text-align:left; cursor:pointer;font-family: Arial,Helvetica,sans-serif; color:#000; font-size: 12px;}.buorg div { padding:5px 36px 5px 40px; } .buorg a,.buorg a:visited  {color:#E25600; text-decoration: underline;}#buorgclose { position: absolute; right: 6px; top:-2px; height: 20px; width: 12px; font-weight: bold;font-size:18px; padding:0; }";
   document.body.insertBefore(c, document.body.firstChild), document.getElementsByTagName("head")[0].appendChild(h);
   try {
    h.innerText = p, h.innerHTML = p
   } catch (d) {
    try {
     h.styleSheet.cssText = p
    } catch (v) {
     return
    }
   }
   var m = this;
   c.onclick = function() {
    return m.op.newwindow ? window.open(m.op.url, "_blank") : window.location.href = m.op.url, r(m.op.reminderClosed), m.op.onclick(m.op), !1
   };
   try {
    c.getElementsByTagName("a")[0].onclick = function(e) {
     return e = e || window.event, e.stopPropagation ? e.stopPropagation() : e.cancelBubble = !0, m.op.onclick(m.op), !0
    }
   } catch (d) {}
   var g = document.getElementsByTagName("html")[0] || document.body;
   this.op.bodymt = g.style.marginTop, g.style.marginTop = c.clientHeight + "px",
    function(e) {
     document.getElementById("buorgclose").onclick = function(t) {
      return t = t || window.event, t.stopPropagation ? t.stopPropagation() : t.cancelBubble = !0, e.op.div.style.display = "none", g.style.marginTop = e.op.bodymt, e.op.onclose(e.op), r(e.op.reminderClosed), !0
     }
    }(m), e.onshow(this.op)
  }
 },
 $buoop = $buoop || {};
$bu = $buo($buoop), ! function(e, t) {
 function n() {
  e.removeEventListener("load", n, !1), u = !0
 }

 function r(e) {
  return a = a || new r.Class(e)
 }

 function i(e, t) {
  for (var n in t) e[n] = t[n];
  return e
 }

 function s() {
  "#ath" == t.location.hash && history.replaceState("", e.document.title, t.location.href.split("#")[0]), f.test(t.location.href) && history.replaceState("", e.document.title, t.location.href.replace(f, "$1")), l.test(t.location.search) && history.replaceState("", e.document.title, t.location.href.replace(l, "$2"))
 }
 var o = "addEventListener" in e,
  u = !1;
 "complete" === t.readyState ? u = !0 : o && e.addEventListener("load", n, !1);
 var a, f = /\/ath(\/)?$/,
  l = /([\?&]ath=[^&]*$|&ath=[^&]*(&))/;
 r.intl = {
  de_de: {
   ios: "Um diese Web-App zum Home-Bildschirm hinzuzufügen, tippen Sie auf %icon und dann <strong>Zum Home-Bildschirm</strong>.",
   android: 'Um diese Web-App zum Home-Bildschirm hinzuzufügen, öffnen Sie das Menü und tippen dann auf <strong>Zum Startbildschirm hinzufügen</strong>. <small>Wenn Ihr Gerät eine Menütaste hat, lässt sich das Browsermenü über diese öffnen. Ansonsten tippen Sie auf <span class="ath-action-icon">icon</span>.</small>'
  },
  da_dk: {
   ios: "For at tilføje denne web app til hjemmeskærmen: Tryk %icon og derefter <strong>Føj til hjemmeskærm</strong>.",
   android: 'For at tilføje denne web app til hjemmeskærmen, åbn browser egenskaber menuen og tryk på <strong>Føj til hjemmeskærm</strong>. <small>Denne menu kan tilgås ved at trykke på menu knappen, hvis din enhed har en, eller ved at trykke på det øverste højre menu ikon <span class="ath-action-icon">icon</span>.</small>'
  },
  en_us: {
   ios: "To add this web app to the home screen: tap %icon and then <strong>Add to Home Screen</strong>.",
   android: 'To add this web app to the home screen open the browser option menu and tap on <strong>Add to homescreen</strong>. <small>The menu can be accessed by pressing the menu hardware button if your device has one, or by tapping the top right menu icon <span class="ath-action-icon">icon</span>.</small>'
  },
  es_es: {
   ios: "Para añadir esta aplicación web a la pantalla de inicio: pulsa %icon y selecciona <strong>Añadir a pantalla de inicio</strong>.",
   android: 'Para añadir esta aplicación web a la pantalla de inicio, abre las opciones y pulsa <strong>Añadir a pantalla inicio</strong>. <small>El menú se puede acceder pulsando el botón táctil en caso de tenerlo, o bien el icono de la parte superior derecha de la pantalla <span class="ath-action-icon">icon</span>.</small>'
  },
  fi_fi: {
   ios: "Liitä tämä sovellus kotivalikkoon: klikkaa %icon ja tämän jälkeen <strong>Lisää kotivalikkoon</strong>.",
   android: 'Lisätäksesi tämän sovelluksen aloitusnäytölle, avaa selaimen valikko ja klikkaa tähti -ikonia tai <strong>Lisää aloitusnäytölle tekstiä</strong>. <small>Valikkoon pääsee myös painamalla menuvalikkoa, jos laitteessasi on sellainen tai koskettamalla oikealla yläkulmassa menu ikonia <span class="ath-action-icon">icon</span>.</small>'
  },
  fr_fr: {
   ios: "Pour ajouter cette application web sur l'écran d'accueil : Appuyez %icon et sélectionnez <strong>Ajouter sur l'écran d'accueil</strong>.",
   android: 'Pour ajouter cette application web sur l\'écran d\'accueil : Appuyez sur le bouton "menu", puis sur <strong>Ajouter sur l\'écran d\'accueil</strong>. <small>Le menu peut-être accessible en appyant sur le bouton "menu" du téléphone s\'il en possède un <i class="fa fa-bars"></i>. Sinon, il se trouve probablement dans la coin supérieur droit du navigateur %icon.</small>'
  },
  he_il: {
   ios: '<span dir="rtl">להוספת האפליקציה למסך הבית: ללחוץ על %icon ואז <strong>הוסף למסך הבית</strong>.</span>',
   android: 'To add this web app to the home screen open the browser option menu and tap on <strong>Add to homescreen</strong>. <small>The menu can be accessed by pressing the menu hardware button if your device has one, or by tapping the top right menu icon <span class="ath-action-icon">icon</span>.</small>'
  },
  it_it: {
   ios: "Per aggiungere questa web app alla schermata iniziale: premi %icon e poi <strong>Aggiungi a Home</strong>.",
   android: 'Per aggiungere questa web app alla schermata iniziale, apri il menu opzioni del browser e premi su <strong>Aggiungi alla homescreen</strong>. <small>Puoi accedere al menu premendo il pulsante hardware delle opzioni se la tua device ne ha uno, oppure premendo l\'icona <span class="ath-action-icon">icon</span> in alto a destra.</small>'
  },
  ja_jp: {
   ios: "このウェプアプリをホーム画面に追加するために%iconを押して<strong>ホーム画面に追加</strong>。",
   android: 'To add this web app to the home screen open the browser option menu and tap on <strong>Add to homescreen</strong>. <small>The menu can be accessed by pressing the menu hardware button if your device has one, or by tapping the top right menu icon <span class="ath-action-icon">icon</span>.</small>'
  },
  ko_kr: {
   ios: "홈 화면에 바로가기 생성: %icon 을 클릭한 후 <strong>홈 화면에 추가</strong>.",
   android: '브라우저 옵션 메뉴의 <string>홈 화면에 추가</string>를 클릭하여 홈화면에 바로가기를 생성할 수 있습니다. <small>옵션 메뉴는 장치의 메뉴 버튼을 누르거나 오른쪽 상단의 메뉴 아이콘 <span class="ath-action-icon">icon</span>을 클릭하여 접근할 수 있습니다.</small>'
  },
  nb_no: {
   ios: "For å installere denne appen på hjem-skjermen: trykk på %icon og deretter <strong>Legg til på Hjem-skjerm</strong>.",
   android: 'For å legge til denne webappen på startsiden åpner en nettlesermenyen og velger <strong>Legg til på startsiden</strong>. <small>Menyen åpnes ved å trykke på den fysiske menyknappen hvis enheten har det, eller ved å trykke på menyikonet øverst til høyre <span class="ath-action-icon">icon</span>.</small>'
  },
  pt_br: {
   ios: "Para adicionar este app à tela de início: clique %icon e então <strong>Tela de início</strong>.",
   android: 'To add this web app to the home screen open the browser option menu and tap on <strong>Add to homescreen</strong>. <small>The menu can be accessed by pressing the menu hardware button if your device has one, or by tapping the top right menu icon <span class="ath-action-icon">icon</span>.</small>'
  },
  pt_pt: {
   ios: "Para adicionar esta app ao ecrã principal: clique %icon e depois <strong>Ecrã principal</strong>.",
   android: 'To add this web app to the home screen open the browser option menu and tap on <strong>Add to homescreen</strong>. <small>The menu can be accessed by pressing the menu hardware button if your device has one, or by tapping the top right menu icon <span class="ath-action-icon">icon</span>.</small>'
  },
  nl_nl: {
   ios: "Om deze webapp op je telefoon te installeren, klik op %icon en dan <strong>Zet in beginscherm</strong>.",
   android: 'To add this web app to the home screen open the browser option menu and tap on <strong>Add to homescreen</strong>. <small>The menu can be accessed by pressing the menu hardware button if your device has one, or by tapping the top right menu icon <span class="ath-action-icon">icon</span>.</small>'
  },
  ru_ru: {
   ios: 'Чтобы добавить этот сайт на свой домашний экран, нажмите на иконку %icon и затем <strong>На экран "Домой"</strong>.',
   android: 'Чтобы добавить сайт на свой домашний экран, откройте меню браузера и нажмите на <strong>Добавить на главный экран</strong>. <small>Меню можно вызвать, нажав на кнопку меню вашего телефона, если она есть. Или найдите иконку сверху справа <span class="ath-action-icon">иконка</span>.</small>'
  },
  sv_se: {
   ios: "För att lägga till denna webbapplikation på hemskärmen: tryck på %icon och därefter <strong>Lägg till på hemskärmen</strong>.",
   android: 'För att lägga till den här webbappen på hemskärmen öppnar du webbläsarens alternativ-meny och väljer <strong>Lägg till på startskärmen</strong>. <small>Man hittar menyn genom att trycka på hårdvaruknappen om din enhet har en sådan, eller genom att trycka på menyikonen högst upp till höger <span class="ath-action-icon">icon</span>.</small>'
  },
  zh_cn: {
   ios: "如要把应用程式加至主屏幕,请点击%icon, 然后<strong>加至主屏幕</strong>",
   android: 'To add this web app to the home screen open the browser option menu and tap on <strong>Add to homescreen</strong>. <small>The menu can be accessed by pressing the menu hardware button if your device has one, or by tapping the top right menu icon <span class="ath-action-icon">icon</span>.</small>'
  },
  zh_tw: {
   ios: "如要把應用程式加至主屏幕, 請點擊%icon, 然後<strong>加至主屏幕</strong>.",
   android: 'To add this web app to the home screen open the browser option menu and tap on <strong>Add to homescreen</strong>. <small>The menu can be accessed by pressing the menu hardware button if your device has one, or by tapping the top right menu icon <span class="ath-action-icon">icon</span>.</small>'
  }
 };
 for (var c in r.intl) r.intl[c.substr(0, 2)] = r.intl[c];
 r.defaults = {
  appID: "org.cubiq.addtohome",
  fontSize: 15,
  debug: !1,
  logging: !1,
  modal: !1,
  mandatory: !1,
  autostart: !0,
  skipFirstVisit: !1,
  startDelay: 1,
  lifespan: 15,
  displayPace: 1440,
  maxDisplayCount: 0,
  icon: !0,
  message: "",
  validLocation: [],
  onInit: null,
  onShow: null,
  onRemove: null,
  onAdd: null,
  onPrivate: null,
  privateModeOverride: !1,
  detectHomescreen: !1
 };
 var h = e.navigator.userAgent,
  p = e.navigator;
 i(r, {
  hasToken: "#ath" == t.location.hash || f.test(t.location.href) || l.test(t.location.search),
  isRetina: e.devicePixelRatio && e.devicePixelRatio > 1,
  isIDevice: /iphone|ipod|ipad/i.test(h),
  isMobileChrome: h.indexOf("Android") > -1 && /Chrome\/[.0-9]*/.test(h) && -1 == h.indexOf("Version"),
  isMobileIE: h.indexOf("Windows Phone") > -1,
  language: p.language && p.language.toLowerCase().replace("-", "_") || ""
 }), r.language = r.language && r.language in r.intl ? r.language : "en_us", r.isMobileSafari = r.isIDevice && h.indexOf("Safari") > -1 && h.indexOf("CriOS") < 0, r.OS = r.isIDevice ? "ios" : r.isMobileChrome ? "android" : r.isMobileIE ? "windows" : "unsupported", r.OSVersion = h.match(/(OS|Android) (\d+[_\.]\d+)/), r.OSVersion = r.OSVersion && r.OSVersion[2] ? +r.OSVersion[2].replace("_", ".") : 0, r.isStandalone = "standalone" in e.navigator && e.navigator.standalone, r.isTablet = r.isMobileSafari && h.indexOf("iPad") > -1 || r.isMobileChrome && h.indexOf("Mobile") < 0, r.isCompatible = r.isMobileSafari && r.OSVersion >= 6 || r.isMobileChrome;
 var d = {
  lastDisplayTime: 0,
  returningVisitor: !1,
  displayCount: 0,
  optedout: !1,
  added: !1
 };
 r.removeSession = function(e) {
  try {
   if (!localStorage) throw new Error("localStorage is not defined");
   localStorage.removeItem(e || r.defaults.appID)
  } catch (t) {}
 }, r.doLog = function(e) {
  this.options.logging && console.log(e)
 }, r.Class = function(n) {
  if (this.doLog = r.doLog, this.options = i({}, r.defaults), i(this.options, n), n.debug && "undefined" == typeof n.logging && (this.options.logging = !0), o) {
   if (this.options.mandatory = this.options.mandatory && ("standalone" in e.navigator || this.options.debug), this.options.modal = this.options.modal || this.options.mandatory, this.options.mandatory && (this.options.startDelay = -0.5), this.options.detectHomescreen = this.options.detectHomescreen === !0 ? "hash" : this.options.detectHomescreen, this.options.debug && (r.isCompatible = !0, r.OS = "string" == typeof this.options.debug ? this.options.debug : "unsupported" == r.OS ? "android" : r.OS, r.OSVersion = "ios" == r.OS ? "8" : "4"), this.container = t.documentElement, this.session = this.getItem(this.options.appID), this.session = this.session ? JSON.parse(this.session) : void 0, !r.hasToken || r.isCompatible && this.session || (r.hasToken = !1, s()), !r.isCompatible) return void this.doLog("Add to homescreen: not displaying callout because device not supported");
   this.session = this.session || d;
   try {
    if (!localStorage) throw new Error("localStorage is not defined");
    localStorage.setItem(this.options.appID, JSON.stringify(this.session)), r.hasLocalStorage = !0
   } catch (u) {
    r.hasLocalStorage = !1, this.options.onPrivate && this.options.onPrivate.call(this)
   }
   for (var a = !this.options.validLocation.length, f = this.options.validLocation.length; f--;)
    if (this.options.validLocation[f].test(t.location.href)) {
     a = !0;
     break
    } if (this.getItem("addToHome") && this.optOut(), this.session.optedout) return void this.doLog("Add to homescreen: not displaying callout because user opted out");
   if (this.session.added) return void this.doLog("Add to homescreen: not displaying callout because already added to the homescreen");
   if (!a) return void this.doLog("Add to homescreen: not displaying callout because not a valid location");
   if (r.isStandalone) return this.session.added || (this.session.added = !0, this.updateSession(), this.options.onAdd && r.hasLocalStorage && this.options.onAdd.call(this)), void this.doLog("Add to homescreen: not displaying callout because in standalone mode");
   if (this.options.detectHomescreen) {
    if (r.hasToken) return s(), this.session.added || (this.session.added = !0, this.updateSession(), this.options.onAdd && r.hasLocalStorage && this.options.onAdd.call(this)), void this.doLog("Add to homescreen: not displaying callout because URL has token, so we are likely coming from homescreen");
    "hash" == this.options.detectHomescreen ? history.replaceState("", e.document.title, t.location.href + "#ath") : "smartURL" == this.options.detectHomescreen ? history.replaceState("", e.document.title, t.location.href.replace(/(\/)?$/, "/ath$1")) : history.replaceState("", e.document.title, t.location.href + (t.location.search ? "&" : "?") + "ath=")
   }
   if (!this.session.returningVisitor && (this.session.returningVisitor = !0, this.updateSession(), this.options.skipFirstVisit)) return void this.doLog("Add to homescreen: not displaying callout because skipping first visit");
   if (!this.options.privateModeOverride && !r.hasLocalStorage) return void this.doLog("Add to homescreen: not displaying callout because browser is in private mode");
   this.ready = !0, this.options.onInit && this.options.onInit.call(this), this.options.autostart && (this.doLog("Add to homescreen: autostart displaying callout"), this.show())
  }
 }, r.Class.prototype = {
  events: {
   load: "_delayedShow",
   error: "_delayedShow",
   orientationchange: "resize",
   resize: "resize",
   scroll: "resize",
   click: "remove",
   touchmove: "_preventDefault",
   transitionend: "_removeElements",
   webkitTransitionEnd: "_removeElements",
   MSTransitionEnd: "_removeElements"
  },
  handleEvent: function(e) {
   var t = this.events[e.type];
   t && this[t](e)
  },
  show: function(n) {
   if (this.options.autostart && !u) return void setTimeout(this.show.bind(this), 50);
   if (this.shown) return void this.doLog("Add to homescreen: not displaying callout because already shown on screen");
   var i = Date.now(),
    s = this.session.lastDisplayTime;
   if (n !== !0) {
    if (!this.ready) return void this.doLog("Add to homescreen: not displaying callout because not ready");
    if (i - s < 6e4 * this.options.displayPace) return void this.doLog("Add to homescreen: not displaying callout because displayed recently");
    if (this.options.maxDisplayCount && this.session.displayCount >= this.options.maxDisplayCount) return void this.doLog("Add to homescreen: not displaying callout because displayed too many times already")
   }
   this.shown = !0, this.session.lastDisplayTime = i, this.session.displayCount++, this.updateSession(), this.applicationIcon || (this.applicationIcon = t.querySelector("ios" == r.OS ? 'head link[rel^=apple-touch-icon][sizes="152x152"],head link[rel^=apple-touch-icon][sizes="144x144"],head link[rel^=apple-touch-icon][sizes="120x120"],head link[rel^=apple-touch-icon][sizes="114x114"],head link[rel^=apple-touch-icon]' : 'head link[rel^="shortcut icon"][sizes="196x196"],head link[rel^=apple-touch-icon]'));
   var o = "";
   "object" == typeof this.options.message && r.language in this.options.message ? o = this.options.message[r.language][r.OS] : "object" == typeof this.options.message && r.OS in this.options.message ? o = this.options.message[r.OS] : this.options.message in r.intl ? o = r.intl[this.options.message][r.OS] : "" !== this.options.message ? o = this.options.message : r.OS in r.intl[r.language] && (o = r.intl[r.language][r.OS]), o = "<p>" + o.replace("%icon", '<span class="ath-action-icon">icon</span>') + "</p>", this.viewport = t.createElement("div"), this.viewport.className = "ath-viewport", this.options.modal && (this.viewport.className += " ath-modal"), this.options.mandatory && (this.viewport.className += " ath-mandatory"), this.viewport.style.position = "absolute", this.element = t.createElement("div"), this.element.className = "ath-container ath-" + r.OS + " ath-" + r.OS + (r.OSVersion + "").substr(0, 1) + " ath-" + (r.isTablet ? "tablet" : "phone"), this.element.style.cssText = "-webkit-transition-property:-webkit-transform,opacity;-webkit-transition-duration:0s;-webkit-transition-timing-function:ease-out;transition-property:transform,opacity;transition-duration:0s;transition-timing-function:ease-out;", this.element.style.webkitTransform = "translate3d(0,-" + e.innerHeight + "px,0)", this.element.style.transform = "translate3d(0,-" + e.innerHeight + "px,0)", this.options.icon && this.applicationIcon && (this.element.className += " ath-icon", this.img = t.createElement("img"), this.img.className = "ath-application-icon", this.img.addEventListener("load", this, !1), this.img.addEventListener("error", this, !1), this.img.src = this.applicationIcon.href, this.element.appendChild(this.img)), this.element.innerHTML += o, this.viewport.style.left = "-99999em", this.viewport.appendChild(this.element), this.container.appendChild(this.viewport), this.img ? this.doLog("Add to homescreen: not displaying callout because waiting for img to load") : this._delayedShow()
  },
  _delayedShow: function() {
   setTimeout(this._show.bind(this), 1e3 * this.options.startDelay + 500)
  },
  _show: function() {
   var n = this;
   this.updateViewport(), e.addEventListener("resize", this, !1), e.addEventListener("scroll", this, !1), e.addEventListener("orientationchange", this, !1), this.options.modal && t.addEventListener("touchmove", this, !0), this.options.mandatory || setTimeout(function() {
    n.element.addEventListener("click", n, !0)
   }, 1e3), setTimeout(function() {
    n.element.style.webkitTransitionDuration = "1.2s", n.element.style.transitionDuration = "1.2s", n.element.style.webkitTransform = "translate3d(0,0,0)", n.element.style.transform = "translate3d(0,0,0)"
   }, 0), this.options.lifespan && (this.removeTimer = setTimeout(this.remove.bind(this), 1e3 * this.options.lifespan)), this.options.onShow && this.options.onShow.call(this)
  },
  remove: function() {
   clearTimeout(this.removeTimer), this.img && (this.img.removeEventListener("load", this, !1), this.img.removeEventListener("error", this, !1)), e.removeEventListener("resize", this, !1), e.removeEventListener("scroll", this, !1), e.removeEventListener("orientationchange", this, !1), t.removeEventListener("touchmove", this, !0), this.element.removeEventListener("click", this, !0), this.element.addEventListener("transitionend", this, !1), this.element.addEventListener("webkitTransitionEnd", this, !1), this.element.addEventListener("MSTransitionEnd", this, !1), this.element.style.webkitTransitionDuration = "0.3s", this.element.style.opacity = "0"
  },
  _removeElements: function() {
   this.element.removeEventListener("transitionend", this, !1), this.element.removeEventListener("webkitTransitionEnd", this, !1), this.element.removeEventListener("MSTransitionEnd", this, !1), this.container.removeChild(this.viewport), this.shown = !1, this.options.onRemove && this.options.onRemove.call(this)
  },
  updateViewport: function() {
   if (this.shown) {
    this.viewport.style.width = e.innerWidth + "px", this.viewport.style.height = e.innerHeight + "px", this.viewport.style.left = e.scrollX + "px", this.viewport.style.top = e.scrollY + "px";
    var n = t.documentElement.clientWidth;
    this.orientation = n > t.documentElement.clientHeight ? "landscape" : "portrait";
    var i = "ios" == r.OS ? "portrait" == this.orientation ? screen.width : screen.height : screen.width;
    this.scale = screen.width > n ? 1 : i / e.innerWidth, this.element.style.fontSize = this.options.fontSize / this.scale + "px"
   }
  },
  resize: function() {
   clearTimeout(this.resizeTimer), this.resizeTimer = setTimeout(this.updateViewport.bind(this), 100)
  },
  updateSession: function() {
   r.hasLocalStorage !== !1 && localStorage && localStorage.setItem(this.options.appID, JSON.stringify(this.session))
  },
  clearSession: function() {
   this.session = d, this.updateSession()
  },
  getItem: function(e) {
   try {
    if (!localStorage) throw new Error("localStorage is not defined");
    return localStorage.getItem(e)
   } catch (t) {
    r.hasLocalStorage = !1
   }
  },
  optOut: function() {
   this.session.optedout = !0, this.updateSession()
  },
  optIn: function() {
   this.session.optedout = !1, this.updateSession()
  },
  clearDisplayCount: function() {
   this.session.displayCount = 0, this.updateSession()
  },
  _preventDefault: function(e) {
   e.preventDefault(), e.stopPropagation()
  }
 }, e.addToHomescreen = r
}(window, document), addToHomescreen({
 skipFirstVisit: !0,
 maxDisplayCount: 1
})