<?php
// KONTROL UNTUK MENDAPATKAN ZONA WAKTU (Makassar)
date_default_timezone_set('Asia/Jakarta');
$viewua = $_SERVER['HTTP_USER_AGENT'];
$author = 'RndyXD'; // RandKey
$time = date('d-m-Y h:i:s');

// FUNCTION GET IP
function rndytechip() {
    $ipaddress = '';
    if (isset($_SERVER['HTTP_CLIENT_IP']))
        $ipaddress = $_SERVER['HTTP_CLIENT_IP'];
    else if(isset($_SERVER['HTTP_X_FORWARDED_FOR']))
        $ipaddress = $_SERVER['HTTP_X_FORWARDED_FOR'];
    else if(isset($_SERVER['HTTP_X_FORWARDED']))
        $ipaddress = $_SERVER['HTTP_X_FORWARDED'];
    else if(isset($_SERVER['HTTP_FORWARDED_FOR']))
        $ipaddress = $_SERVER['HTTP_FORWARDED_FOR'];
    else if(isset($_SERVER['HTTP_FORWARDED']))
        $ipaddress = $_SERVER['HTTP_FORWARDED'];
    else if(isset($_SERVER['REMOTE_ADDR']))
        $ipaddress = $_SERVER['REMOTE_ADDR'];
    else
        $ipaddress = 'IP tidak dikenali';
    return $ipaddress;
}

$viewip = rndytechip();

// MENDAPATKAN INFO IP ADDRESS
$url = 'http://randiramli.my.id/api/location/?ip='.urlencode($viewip).'&RandKey='.$author.'';
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL,$url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
$json = curl_exec($ch);
curl_close($ch);
$infoip = json_decode($json, true);

/// MENDAPATKAN INFO USERAGENT
$url = 'http://randiramli.my.id/api/useragents/index.php/?ua='.urlencode($viewua).'&RandKey='.$author.'';
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL,$url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
$json = curl_exec($ch);
curl_close($ch);
$infoua = json_decode($json, true);;

// DECODE INFO
$negara = $infoip['Negara'];
$region = $infoip['Provinsi'];
$city = $infoip['Kota'];
$longitude = $infoip['Longitude'];
$latitude = $infoip['Latitude'];;
$flag = $infoip['flag'];
$callcode = $infoip['callcode'];
$rndytech = $infoip['rndytech'];
$device = $infoua['Device'];
$os = $infoua['Os'];
$browser = $infoua['Browser'];
?>