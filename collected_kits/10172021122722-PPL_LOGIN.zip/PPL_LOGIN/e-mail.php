<?php

	$zombiemail = "osker700@protonmail.com";

	$admin_pass = "khaled2323";