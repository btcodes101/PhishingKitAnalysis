<?php
$jean_email = "jonresul@yandex.com";
$chat_id = "1852653652";


?>