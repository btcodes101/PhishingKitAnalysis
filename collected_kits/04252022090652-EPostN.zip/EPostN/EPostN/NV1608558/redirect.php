<?php
header("Location: https://emiratespost.ae");

  ?>