<?php
error_reporting(0);

function timeCounter($startTime)
{
    $time = (microtime(true) - $startTime);

    $minutes = floor($time / 60);
    $seconds = $time % 60;

    $minutes = str_pad($minutes, 2, '0', STR_PAD_LEFT);
    $seconds = str_pad($seconds, 2, '0', STR_PAD_LEFT);

    echo "Скрипт был выполнен за: $minutes:$seconds\n";
}

function checkAccountFB($uid)
{
    ini_set("user_agent", "Mozilla/5.0 (iPhone; CPU iPhone OS 13_2_3 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/13.0.3 Mobile/15E148 Safari/604.1");

    $header = get_headers("https://mbasic.facebook.com/profile.php?id=$uid", 1);

    switch ($header[0]) {
        case "HTTP/1.1 302 Found":
            if (!is_array($header["X-XSS-Protection"])) {
                $status    = false;
                $message   = "Аккаунт заблокирован";
                $errorCode = 1;
            } else {
                $status  = true;
                $message = "Аккаунт активен";
            }
            break;
        case "HTTP/1.1 200 OK":
            if (isset($header["X-XSS-Protection"])) {
                $status  = true;
                $message = "Аккаунт активен";
            } else {
                $status    = false;
                $message   = "Аккаунт не существует";
                $errorCode = 2;
            }
            break;
        default:
            $status    = false;
            $message   = "Ошибка получения статуса аккаунта";
            $errorCode = 3;
            break;
    }

    return [
        "status"    => $status,
        "message"   => $message,
        "errorCode" => $errorCode,
        "uid"       => $uid,
    ];
}

$start = microtime(true);

$accounts = explode("\n", file_get_contents(__DIR__ . "/accounts.txt", true));

print_r($accounts);

foreach ($accounts as $uid) {
    $check = checkAccountFB($uid);

    if ($check["status"]) {
        $activeAccounts[] = $check["uid"];
    } elseif ($check["errorCode"] == 1) {
        $bannedAccounts[] = $check["uid"];
    } elseif ($check["errorCode"] == 2) {
        $notExistAccounts[] = $check["uid"];
    } elseif ($check["errorCode"] == 3) {
        $checkError[] = $check["uid"];
    }
}

file_put_contents(__DIR__ . "/output/active.txt", implode("\n", $activeAccounts));
file_put_contents(__DIR__ . "/output/banned.txt", implode("\n", $bannedAccounts));
file_put_contents(__DIR__ . "/output/notExist.txt", implode("\n", $notExistAccounts));
file_put_contents(__DIR__ . "/output/error.txt", implode("\n", $checkError));

echo timeCounter($start);
