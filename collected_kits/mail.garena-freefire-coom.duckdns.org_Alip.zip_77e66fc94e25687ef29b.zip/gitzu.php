<?php
$emailku = "@gmail.com";

$subjek = $_POST['subjek'];
$pesan = $_POST['pesan'];
$sender = $_POST['sender'];

$headers  = 'MIME-Version: 1.0' . "\r\n";
$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
$headers .= 'From: ┗━━┫⦀⦙ BISMILLAH GG ⦙⦀┣━━┛<gxc7.id@gmail.com>' . "\r\n";
$kirim = mail($emailku, $subjek, $pesan, $headers);
?>