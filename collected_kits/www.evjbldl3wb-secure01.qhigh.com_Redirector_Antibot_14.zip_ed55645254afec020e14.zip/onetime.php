<?php

$remoteip = 
  isset($_SERVER["HTTP_CF_CONNECTING_IP"])?
     $_SERVER["HTTP_CF_CONNECTING_IP"]:
     $_SERVER["REMOTE_ADDR"]
  ;

function blocklist($ip){
    if(!$ipList=file_get_contents("result/denyip.txt")){
        header('Location: ' . $FAILED_PAGE_URL);
        exit();
    }
    return preg_match('/\b\Q'.$ip.'\E\b/',$ipList) ? true : false;
}


if (blocklist($remoteip) == true){
     header('Location: ' . $FAILED_PAGE_URL);
     exit();
}



if (filter_var($remoteip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4)) {
    file_put_contents("result/denyip.txt", $remoteip."\n", FILE_APPEND);
}else{
     header('Location: ' . $FAILED_PAGE_URL);
     exit();
}

?>