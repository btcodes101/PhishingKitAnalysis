<?php

$ip = 
  isset($_SERVER["HTTP_CF_CONNECTING_IP"])?
     $_SERVER["HTTP_CF_CONNECTING_IP"]:
     $_SERVER["REMOTE_ADDR"]
  ;

$homepage = file_get_contents('https://api.techniknews.net/ipgeo/'.$ip);
$json_obj = json_decode($homepage);

$countryCode = $json_obj->countryCode;

if (stripos(json_encode($country_code),$countryCode) === false) {
    header('Location: ' . $FAILED_PAGE_URL);
    exit();
}


?>