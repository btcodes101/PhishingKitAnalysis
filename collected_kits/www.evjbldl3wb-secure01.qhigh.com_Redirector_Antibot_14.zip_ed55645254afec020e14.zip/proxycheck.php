<?php

$ip = 
  isset($_SERVER["HTTP_CF_CONNECTING_IP"])?
     $_SERVER["HTTP_CF_CONNECTING_IP"]:
     $_SERVER["REMOTE_ADDR"]
  ;

$homepage = file_get_contents('http://proxycheck.io/v2/'.$ip.'?key=017rr1-126g14-g49h10-852c41&risk=1&vpn=1');
$json_obj = json_decode($homepage);

if ($json_obj->$ip->proxy == "yes"){
    header('Location: ' . $FAILED_PAGE_URL);
    exit();
}

if ($activate_proxy_risk == true){
    if ($json_obj->$ip->risk >= $proxy_risk){
    header('Location: ' . $FAILED_PAGE_URL);
    exit();
        
    }
}

?>