<?php
$array = explode("\n", file_get_contents('fakelist.txt'));
$multiple_url = $array[array_rand($array)];
$errorpage = 'error.php';

?>