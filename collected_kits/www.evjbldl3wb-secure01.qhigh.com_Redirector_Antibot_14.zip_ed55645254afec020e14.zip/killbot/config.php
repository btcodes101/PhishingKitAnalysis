<?php

include('../config.php');

$CONFIG_KILLBOT = [
    'active'        => true, // If 'true' will set blocker protection active, and 'false' will deactive protection
    'apikey'        => $kill_bot_api, // Your API Key from https://killbot.org/developer
    'bot_redirect'  => 'suspend' // Bot will be redirect to this URL or you can change with 403, 404, suspend or cloudflare.
];