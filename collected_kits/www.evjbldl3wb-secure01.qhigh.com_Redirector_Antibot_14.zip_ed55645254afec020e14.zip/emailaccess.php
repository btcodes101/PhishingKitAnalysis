<?php

$getemail = $_GET['data'];
$mylist= file_get_contents(EMAIL_LIST);

if (!isset($_GET['data']) || empty($_GET['data'])){
    header('Location: ' . $FAILED_PAGE_URL);
    exit();
}

if (filter_var($getemail, FILTER_VALIDATE_EMAIL) == false) {
    header('Location: ' . $FAILED_PAGE_URL);
    exit();
    }
    
if (!preg_match( "#\b{$getemail}\b#", $mylist ) ) {
    header('Location: ' . $FAILED_PAGE_URL);
    exit();
}
    


removeLine($getemail, EMAIL_LIST);

?>