<?php

if(!session_id())
{
    session_start();
}

var_dump($_SESSION);
?><?php /* TEST */ ?>