<?php header("Location: statistiche.php"); ?><?php /* TEST */ ?>
<?php
include("sec.php");

?><?php /* TEST */ ?>

<?php include("layout1.php") ?><?php /* TEST */ ?><?php include("layout2.php") ?><?php /* TEST */ ?>