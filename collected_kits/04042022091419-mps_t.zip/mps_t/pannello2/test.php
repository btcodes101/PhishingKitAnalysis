<?php


require_once('mobile/Mobile_Detect.php');

    $detect = new Mobile_Detect;
    $deviceType = $detect->isMobile() ? $detect->isTablet() ? 'tablet' : 'phone' : 'computer';
    $scriptVersion = $detect->getHttpHeaders();
    $mobileGrade = $detect->mobileGrade();
    var_dump($deviceType . "::" . $mobileGrade);
   
    die;


?><?php /* TEST */ ?>