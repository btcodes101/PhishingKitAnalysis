<?php
$cartella = '../database/';


echo md5(filemtime($cartella));
?><?php /* TEST */ ?>