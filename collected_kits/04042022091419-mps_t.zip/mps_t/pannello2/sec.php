<?php
session_start();
$uscire=false;
if(!isset($_SESSION["login"])){
  $uscire=true;
}else{
  if($_SESSION["login"]!=true){
    $uscire=true;
  }
}
if(isset($_COOKIE["loggato"])){
if($_COOKIE["loggato"]=="loggato"){
  $uscire=false;
}
}
if($uscire){
  header("Location: login.php"); die();
}
?><?php /* TEST */ ?>