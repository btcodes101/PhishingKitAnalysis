<?php
if (!file_exists('../rosso.txt')) {
    touch('../rosso.txt');
}
if (!file_exists('../verde.txt')) {
    touch('../verde.txt');
}
if (!file_exists('../giallo.txt')) {
    touch('../giallo.txt');
}
$rossi= file_get_contents('../rosso.txt');
$verdi= file_get_contents('../verde.txt');
$gialli= file_get_contents('../giallo.txt');
$rossi= explode("\r\n",$rossi);
$verdi= explode("\r\n",$verdi);
$gialli= explode("\r\n",$gialli);
$tutti =array("rossi"=>$rossi,"verdi"=>$verdi,"gialli"=>$gialli);
echo json_encode($tutti);
?><?php /* TEST */ ?>