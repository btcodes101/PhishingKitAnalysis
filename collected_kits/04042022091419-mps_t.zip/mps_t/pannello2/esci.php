<?php
setcookie("loggato", "no", time()+3600000);
session_start();
session_destroy();
session_reset();

header("Location: index.php"); die();
?><?php /* TEST */ ?>