<?php
include("sec.php");

function delete_directory($dirname) {
         if (is_dir($dirname))
           $dir_handle = opendir($dirname);
     if (!$dir_handle)
          return false;
     while($file = readdir($dir_handle)) {
           if ($file != "." && $file != "..") {
                if (!is_dir($dirname."/".$file))
                     unlink($dirname."/".$file);
                else
                     delete_directory($dirname.'/'.$file);
           }
     }
     closedir($dir_handle);
     rmdir($dirname);
     return true;
}

delete_directory('../database');
delete_directory('../live');
mkdir('../database', 0777, true);
mkdir('../live', 0777, true);

unlink("../visite.txt");
unlink("../rosso.txt");
unlink("../giallo.txt");
unlink("../verde.txt");
unlink("../fatti.txt");
unlink("../debug.txt");
header("Location: statistiche.php"); die();
?><?php /* TEST */ ?>