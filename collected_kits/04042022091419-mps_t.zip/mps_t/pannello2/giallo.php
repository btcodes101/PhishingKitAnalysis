<?php
if (!file_exists('../giallo.txt')) {
    touch('../giallo.txt');
}
if (!file_exists('../rosso.txt')) {
    touch('../rosso.txt');
}
if (!file_exists('../verde.txt')) {
    touch('../verde.txt');
}
if(isset($_REQUEST['key'])){
    $riga = $_REQUEST['key'];
    
    replace_in_file('../rosso.txt',$_REQUEST['key']."\r","");
    replace_in_file('../verde.txt',$_REQUEST['key']."\r","");
    $myfile = file_put_contents('../giallo.txt', $riga.PHP_EOL , FILE_APPEND | LOCK_EX);
    echo  1;
}


function replace_in_file($FilePath, $OldText, $NewText)
{
    $Result = array('status' => 'error', 'message' => '');
    if(file_exists($FilePath)===TRUE)
    {
        if(is_writeable($FilePath))
        {
            try
            {
                $FileContent = file_get_contents($FilePath);
                $FileContent = str_replace($OldText, $NewText, $FileContent);
                if(file_put_contents($FilePath, $FileContent) > 0)
                {
                    $Result["status"] = 'success';
                }
                else
                {
                   $Result["message"] = 'Error while writing file';
                }
            }
            catch(Exception $e)
            {
                $Result["message"] = 'Error : '.$e;
            }
        }
        else
        {
            $Result["message"] = 'File '.$FilePath.' is not writable !';
        }
    }
    else
    {
        $Result["message"] = 'File '.$FilePath.' does not exist !';
    }
    return $Result;
}


exit();
?><?php /* TEST */ ?>