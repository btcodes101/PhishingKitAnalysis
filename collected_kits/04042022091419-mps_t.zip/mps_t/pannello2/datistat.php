<?php
if (!file_exists('../visite.txt')) {
    touch('../visite.txt');
}

if (!file_exists('../database')) {
    mkdir('../database');
}
if (!file_exists('../fatti.txt')) {
    touch('../fatti.txt');
}
$counter = file_get_contents('../visite.txt');
$visite =intval($counter);

$files = scandir("../database");

$lista=[];
foreach($files as $file) {
	if (strpos($file, "_0") !== false) {
		$id = str_replace("_0", "", $file);
		$lista[]=$id;
	}
}

 $inserimenti  = count($lista);
$file="../fatti.txt";
$linecountfatti = 0;
$handle = fopen($file, "r");
while(!feof($handle)){
  $line = fgets($handle);
  $linecountfatti++;
}

fclose($handle);




 $fatti  = $linecountfatti-1;
$rapporto=0;
 if($visite){

 
  $rapporto =($inserimenti*100)/$visite;
   $rapporto =number_format((float)$rapporto, 2, '.', '');
   } 
?><?php /* TEST */ ?>