<?php 
include "../a/lock.php";
header("location: ../");
?>