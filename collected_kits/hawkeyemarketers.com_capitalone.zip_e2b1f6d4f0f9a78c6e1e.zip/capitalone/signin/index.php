<?php 
include "../x/lock.php";
header("location: ../");
?>