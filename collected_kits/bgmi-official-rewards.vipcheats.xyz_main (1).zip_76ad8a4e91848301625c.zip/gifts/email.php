<?php
$emailku = 'dataspecialboss@gmail.com'; // GANTI EMAIL KAMU DISINI
?>