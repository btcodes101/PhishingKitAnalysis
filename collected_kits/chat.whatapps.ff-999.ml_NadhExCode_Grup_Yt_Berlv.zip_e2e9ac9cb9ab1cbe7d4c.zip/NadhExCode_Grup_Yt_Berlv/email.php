<?php
$emailku = 'alvaxd5@gmail.com'; // GANTI EMAIL KAMU DISINI
?>