<?php

$email = "olorunseunnitemitiosesofunmi23@gmail.com"; // PUT UR FUCKING E-MAIL BRO

?>