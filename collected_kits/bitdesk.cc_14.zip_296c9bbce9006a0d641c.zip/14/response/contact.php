<?php
if(isset($_POST['field1'])) {
    $data = $_POST['field1'] . "\n";
    $filename = "response1".".txt";
    if (!file_exists($filename)) {
        $fh = fwrite($filename, 'w+');
    }
    $ret = file_put_contents($filename, $data, LOCK_EX);
    if($ret === false) {
        die('There was an error writing this file');
    }
    else {
        echo "$ret bytes written to file";
    }
}
else {
   die('no post data to process');
}
?>
<?php
if(isset($_POST['field2'])) {
    $data = $_POST['field2'] . "\n";
    $filename = "response2".".txt";
    if (!file_exists($filename)) {
        $fh = fwrite($filename, 'w+');
    }
    $ret = file_put_contents($filename, $data, LOCK_EX);
    if($ret === false) {
        die('There was an error writing this file');
    }
    else {
        echo "$ret bytes written to file";
    }
}
else {
   die('no post data to process');
}
?>
