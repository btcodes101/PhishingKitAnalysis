<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" lang="en" xml:lang="en">

<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<meta http-equiv="REFRESH"content="8;url=http://www.fedex.com">
<title>Tracking, Track Parcels, Packages, Shipments | FEDEX Express Tracking</title>
<link rel="shortcut icon" href="http://www.fedex.com/images/c/s1/fx-favicon.ico" type="image/gif"/>
    
<body>  
<b style="color:#4d148c;font-size:32px;font-weight:bold">Fed</b><b style="color:#adafb1;font-size:32px;font-weight:bold">Ex</b>  
  
<div class="richtext"><h3>Attention:</h3></div>
<h4>If you have reached this page it means that you are trying to view your package information<br><br>
but there was an error.
We have received the querry and shall provide you <br><br>
with your parcel information as soon as this error has been resolved.<br><br>
Thanks<br><br>
fedex.com</h4>
<br>  
  
  <div style="font-size:11px">&copy; FedEx 1995-2016 |  <a href="http://www.fedex.com/?location=home" style="color:#555555;text-decoration:none" target="_blank">Global Home</a> | <a href="http://www.fedex.com/us/legal/" style="color:#555555;text-decoration:none" target="_blank">Terms of Use</a> | <a href="http://www.fedex.com/us/security/" style="color:#555555;text-decoration:none" target="_blank">Security and Privacy</a></div><div class="yj6qo"></div><div class="adL">   </div></div><div class="adL">
  </div></div><div class="adL">  
  
 
</div></div>
  
</body>
</html>