<?php
$emailku = 'ayventure@yandex.com';
?>