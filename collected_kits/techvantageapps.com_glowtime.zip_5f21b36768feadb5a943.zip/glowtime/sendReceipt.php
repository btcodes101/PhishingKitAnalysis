<?php

    header('Access-Control-Allow-Origin: *');
    
    $email = $_REQUEST['email'];
    $receipt = '<!DOCTYPE html><html lang="en"><head> <meta charset="UTF-8"> <meta name="viewport" content="width=device-width, initial-scale=1.0"> </head><body style="background: #eee; font-family: arial, sans-serif; -webkit-print-color-adjust: exact;">'.$_POST['receipt'].'</body></html>';
       
   $headers = 'From: "Glow Time" <no-reply@glowtime.mu>' . "\r\n" .
            'Content-type: text/html; charset=iso-8859-1'  . "\r\n" .
                'X-Mailer: PHP/' . phpversion();
                    
    // $headers = "MIME-Version: 1.0" . "\r\n";
    // $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";

    if(mail($email, "Glow Time Order Receipt", "$receipt", $headers)){
       echo 1;
    }else{
       echo 0;
    }

?>