<?php 
    
    header('Location: https://glowtime.mu');
        
?>