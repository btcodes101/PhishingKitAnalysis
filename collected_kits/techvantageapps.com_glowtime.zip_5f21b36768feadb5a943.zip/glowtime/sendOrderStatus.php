<?php

    header('Access-Control-Allow-Origin: *');
    
    $email = $_REQUEST['email'];
    $id = $_REQUEST['id'];
    $name = $_REQUEST['name'];
    $status = $_REQUEST['status'];

    $message = "Dear " . $name . ",  <br><br>Your Order <b>#" . $id . "</b> is " . $status . ".<br><br>Thanks,<br><br>Team Glow Time.";

    $headers = 'From: "Glow Time" <no-reply@glowtime.mu>' . "\r\n" .
                'Content-type: text/html; charset=iso-8859-1'  . "\r\n" .
                    'X-Mailer: PHP/' . phpversion();
                    
//   $headers = "MIME-Version: 1.0" . "\r\n";
//     $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";

    if(mail($email, "Glow Time Order Status", "$message", $headers)){
       echo 1;
    }else{
       echo 0;
    }

?>