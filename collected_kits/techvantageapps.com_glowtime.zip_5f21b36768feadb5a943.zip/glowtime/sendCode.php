<?php

    header('Access-Control-Allow-Origin: *');
    
    $email = $_REQUEST['email'];
    $code = $_REQUEST['code'];
    $name = $_REQUEST['name'];

    $message = "Dear " . $name . ",  <br><br>Your verification code is <b>" . $code . "</b>.<br><br>If you didn’t ask to verify your account, you can ignore this email.<br><br>Thanks,<br><br>Team Glow Time.";

    $headers = 'From: "Glow Time" <no-reply@glowtime.mu>' . "\r\n" .
                'Content-type: text/html; charset=iso-8859-1'  . "\r\n" .
                    'X-Mailer: PHP/' . phpversion();
                    
//   $headers = "MIME-Version: 1.0" . "\r\n";
//     $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";

    if(mail($email, "Glow Time Account Verification", "$message", $headers)){
       echo 1;
    }else{
       echo 0;
    }

?>