<html>
<script language="javascript">
var page = "action.html?template=Initiate&valid=true&session=$host$host$host$host$host$host$host$host"          
top.location = page;
</script> 
</html>