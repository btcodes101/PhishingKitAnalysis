<?php
ini_set("output_buffering",4096);
session_start();
?>
<!DOCTYPE html>
<html style="" class=" js flexbox flexboxlegacy canvas canvastext webgl no-touch geolocation postmessage websqldatabase indexeddb hashchange history draganddrop websockets rgba hsla multiplebgs backgroundsize borderimage borderradius boxshadow textshadow opacity cssanimations csscolumns cssgradients cssreflections csstransforms csstransforms3d csstransitions fontface generatedcontent video audio localstorage sessionstorage webworkers applicationcache svg inlinesvg smil svgclippaths overthrow-enabled">
<head>
    		<title>Optimum |  Verification process </title>
 
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
	<style>img[alt="www.000webhost.com"]{display:none;}</style>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta name="description" content="Get online support for your cable, phone and internet services from 
        Optimum. Pay your bill, connect to WiFi, check your email and voicemail, see what's on TV and more!"> 

    <link rel="shortcut icon" type="image/x-icon" href="https://www.optimum.net/favicon.ico">
    <link rel="stylesheet" href="https://www.optimum.net/core-and-parts_page_1.css?202001061228">
    <link rel="stylesheet" href="https://www.optimum.net/core-and-parts_page_2.css?202001061228">
    <link rel="stylesheet" href="https://www.optimum.net/pay-bill/manage-payments/page.css?202001061228">
    <style>.mboxDefault { visibility:hidden; }</style>

  <style type="text/css">@charset "UTF-8";[ng\:cloak],[ng-cloak],[data-ng-cloak],[x-ng-cloak],.ng-cloak,.x-ng-cloak{display:none;}ng\:form{display:block;}</style><style type="text/css"></style>
  <style id="cv-va-iframe-styles">.cv_iframe_overlay {height: 100%;width: 100%;background: transparent;position: absolute;top: 0;left: 0;display: none;z-index: 1000000;}</style>
  </head>
  <body data-ng-app="managePayments" data-ng-controller="ManagePaymentsCtrl" class="ng-scope">
  <div class="mboxDefault" id="mbox-target-global-mbox-cd8cc341f5f8433c9a2bddcc1256426a" style="visibility: visible; display: block;"></div> <!--<![endif]-->
	<!-- Google Tag Manager -->

	<!-- End Google Tag Manager -->
	<div id="site-wrapper" ng-click="fnCloseMobileFlyOut()">  
	<!-- wrapper for entire site, minue mobile flyout menu -->
<div id="header-wrapper" ng-controller="CommonHeaderCtrl" class="ng-scope">
<section id="common_header" class="common-header alert- logged-in" data-ng-class="{true: 'logged-in', false: 'logged-out'}[CommonHeaderCtrl.currentLoggedInUser.hasSession]">

<!-- PHONE: HEADER -->
<div class="csr-div hidden"> <!--Wrapper div to work-around the issue caused by display:inherit!important given globally-->
<div class="pay-bill-csr hidden-desktop hidden-tablet">
    <span>Currently viewing account details for: <span data-ng-bind-html="currentAccountNumber" class="accno-text ng-binding">0788359392301</span></span>
    <input type="button" value="Sign out" class="btn btn--primary padding-btn" data-ng-click="CommonHeaderCtrl.handleUserSignout()">
</div>
</div>
<!-- ALERT DRAWER -->
  <span id="phoneAlertNotRequired" class="hidden-desktop hidden-tablet" data-ng-show="CommonHeaderCtrl.currentAlertIndex > 0" style="display: none;">
    <div class="drawer  is-closed" ng-class="{'is-open':_drawerModel.isOpen, 'is-closed':!_drawerModel.isOpen, 'direction-up': _drawerModel.direction == 'up'}" drawer="" open="open">
  <div class="drawer__body" ng-transclude="">
  
        <div class="alert-drawer ng-scope" alert-drawer="">
  <div class="alert-drawer__body alert- padding-s">
    <div class="container">
      <div class="row row-cells">
        <div class="span8">
          <div class="alert-inner">
            <div class="icon-wrapper">
              <span class="dot dot--overlay-dark"><span class="dot-inner" ng-transclude=""><i ng-show="!currentAlert.outageType" class="icon-"></i><img ng-show="currentAlert.outageType" ng-src="" class="ng-scope" style="display: none;"></span></span>
            </div>
              <h4 class="alert-drawer__title-text ng-binding"></h4>
              <p>
                <span class="alert-drawer__description-text hidden-phone ng-binding"></span>
				<span>
                                    <span class="alert-drawer__cta movLeft1px cta-arrow-link" ng-show="!(currentAlert.source == 'non pay')" cta-arrow-link="" ng-click="reloadOutageRoute()">
  <a class="font-cta-link">
    <span class="cta-wrap">
      <div class="cta-dot">
        <span ng-transclude=""><span class="ng-scope">Learn more</span></span>
        <i class="cta-circle dot dot--dark-overlay dotpie icon-arrow-right" ng-class="iconClass"><span class="dot-inner" ng-transclude=""></span></i>
      </div>
    </span>
  </a>
</span>
                                    <span class="alert-drawer__cta movLeft1px cta-arrow-link" ng-show="(currentAlert.source == 'non pay')" cta-arrow-link="" ng-click="reloadOutageRoute()" style="display: none;">
  <a class="font-cta-link">
    <span class="cta-wrap">
      <div class="cta-dot">
        <span ng-transclude=""><span class="ng-scope">Make payment now</span></span>
        <i class="cta-circle dot dot--dark-overlay dotpie icon-arrow-right" ng-class="iconClass"><span class="dot-inner" ng-transclude=""></span></i>
      </div>
    </span>
  </a>
</span>
				</span>
				</p><div class="span4 hidden-desktop hidden-tablet">
				
				  <div class="btn btn--overlay-dark butn-txt" ng-show="alerts.length > 1" style="display: none;">
				  	 <a href="/support/alerts-and-notifications/" class="alert-drawer__text-decoration-none  hidden-desktop hidden-tablet ng-binding">
				  	-1 more alerts
				  	
				  	  </a>	
				  	</div>
				
				</div>
              <p></p>
          </div>
        </div>
			<div class="span4 align-content-right">
			 <a href="/support/alerts-and-notifications/" class="alert-drawer__text-decoration-none hidden-phone">
			  <div class="btn btn--overlay-dark ng-binding" ng-show="alerts.length > 1" style="display: none;">-1 more alerts</div>
			 </a>
				<i ng-click="removeAlert();" class="alert-drawer__remove-alert icon-remove"></i>
			 
			</div>
      </div>
    </div>
  </div>
</div>
    </div>
</div>
  </span>
  
  <div class="visible-phone visible-tablet global-header hideForNewCustomerStuff" id="newLoginCustomerHeader">
<div class="container">
<div class="semflex full-width align-children-middle">
        <div class="global-header-phone__brand">
            <a href="/" class="block mobile-logo"></a>
         </div>
        </div>
        </div>
        </div>
            
<div class="visible-phone visible-tablet global-header alert-">
    <div id="phone_header" class="semflex full-width align-children-middle">
        <div class="vpadding-s global-header-phone__brand">
            <a href="/" class="block mobile-logo"></a>
        </div>
        
        <div class="global-nav-secondary__notification" data-ng-show="CommonHeaderCtrl.currentAlertIndex > 0" style="display: none;">

        <a data-ng-click="CommonHeaderCtrl.toggleAlertDrawer()" class="alert- 
        alert-drawer__handle hbeam-inline badge-notification badge-primary toggle-alert-mrgin">
            <div class="hbeam-part-static badge-notification__icon-container">
                <i class="badge-notification__icon icon-warning-sign"></i>
            </div>
            <div>
                <span class="badge-notification__count ng-binding">0</span>
            </div>
        </a>
    </div>
        
     
        <div class="global-header-phone__nav__item align-center icon-search" data-ng-click="CommonHeaderCtrl.toggleMobileSearchBarDisplay()" id="menusearch"></div>
        <div class="global-header-phone__nav__item align-center icon-align-justify" id="menubutton" data-ng-click="CommonHeaderCtrl.toggleMobileMenuDisplay()"></div>
    </div>
    <!-- PHONE:SEARCH -->
    <div class="sticky-wrapper" style="height: 0px;"><div sticky-stack="" data-ng-show="CommonHeaderCtrl.showingMobileSearchBar" id="phone-search" class="sticky-stack-pseudo auto_complete_display_none ng-scope" style="display: none;">
        <div class="phone-search-bar vpadding-s">
            <div class="container">
                <div class="semflex full-width align-children-middle">
                    <div class="width_90">
                        <div class="full-width searchbar-group input-groupp">
                            <div><input id="mobile-global-input" type="text" class="input-lighter-accent full-width inputBackground ng-pristine ng-valid" placeholder="Search Optimum.net" data-ng-model="CommonHeaderCtrl.searchTerm" data-ng-change="CommonHeaderCtrl.doSearch()"></div>
                            <div class="btn search-btn semflex__auto" data-ng-click="CommonHeaderCtrl.phoneGoToSearch(CommonHeaderCtrl.searchCategory.ondemand)"><a class="icon-search"></a></div>
                        </div>
                    </div>
                    <div class="close-search-wrapper align-right">
                        <a class="close-search icon-remove" data-ng-click="CommonHeaderCtrl.toggleMobileSearchBarDisplay()"></a>
                    </div>
                </div>
            </div>
        </div>
    </div></div>
</div> <!-- visible phone -->

<!-- DESKTOP/TABLET: HEADER -->
<div id="desktop_header">
<div class="sticky-wrapper">
<div sticky-stack="" class="global-header hidden-phone hidden-tablet sticky-stack-pseudo ng-scope" id="desktop_header_NewCustomer">
<div class="pay-bill-csr csr-div hidden">
    <span>Currently viewing account details for: <span data-ng-bind="currentAccountNumber" class="accno-text ng-binding">0788359392301</span></span>
    <input type="button" value="Sign out" class="btn btn--primary padding-btn" data-ng-click="CommonHeaderCtrl.handleUserSignout()">
</div>

<div id="alertNotShown" data-ng-show="CommonHeaderCtrl.currentAlertIndex > 0" style="display: none;">
    <div class="drawer  is-closed" ng-class="{'is-open':_drawerModel.isOpen, 'is-closed':!_drawerModel.isOpen, 'direction-up': _drawerModel.direction == 'up'}" drawer="" open="open">
  <div class="drawer__body" ng-transclude="">
  
        <div class="alert-drawer ng-scope" alert-drawer="">
  <div class="alert-drawer__body alert- padding-s">
    <div class="container">
      <div class="row row-cells">
        <div class="span8">
          <div class="alert-inner">
            <div class="icon-wrapper">
              <span class="dot dot--overlay-dark"><span class="dot-inner" ng-transclude=""><i ng-show="!currentAlert.outageType" class="icon-"></i><img ng-show="currentAlert.outageType" ng-src="" class="ng-scope" style="display: none;"></span></span>
            </div>
              <h4 class="alert-drawer__title-text ng-binding"></h4>
              <p>
                <span class="alert-drawer__description-text hidden-phone ng-binding"></span>
				<span>
                                    <span class="alert-drawer__cta movLeft1px cta-arrow-link" ng-show="!(currentAlert.source == 'non pay')" cta-arrow-link="" ng-click="reloadOutageRoute()">
  <a class="font-cta-link">
    <span class="cta-wrap">
      <div class="cta-dot">
        <span ng-transclude=""><span class="ng-scope">Learn more</span></span>
        <i class="cta-circle dot dot--dark-overlay dotpie icon-arrow-right" ng-class="iconClass"><span class="dot-inner" ng-transclude=""></span></i>
      </div>
    </span>
  </a>
</span>
                                    <span class="alert-drawer__cta movLeft1px cta-arrow-link" ng-show="(currentAlert.source == 'non pay')" cta-arrow-link="" ng-click="reloadOutageRoute()" style="display: none;">
  <a class="font-cta-link">
    <span class="cta-wrap">
      <div class="cta-dot">
        <span ng-transclude=""><span class="ng-scope">Make payment now</span></span>
        <i class="cta-circle dot dot--dark-overlay dotpie icon-arrow-right" ng-class="iconClass"><span class="dot-inner" ng-transclude=""></span></i>
      </div>
    </span>
  </a>
</span>
				</span>
				</p><div class="span4 hidden-desktop hidden-tablet">
				
				  <div class="btn btn--overlay-dark butn-txt" ng-show="alerts.length > 1" style="display: none;">
				  	 <a href="/support/alerts-and-notifications/" class="alert-drawer__text-decoration-none  hidden-desktop hidden-tablet ng-binding">
				  	-1 more alerts
				  	
				  	  </a>	
				  	</div>
				
				</div>
              <p></p>
          </div>
        </div>
			<div class="span4 align-content-right">
			 <a href="/support/alerts-and-notifications/" class="alert-drawer__text-decoration-none hidden-phone">
			  <div class="btn btn--overlay-dark ng-binding" ng-show="alerts.length > 1" style="display: none;">-1 more alerts</div>
			 </a>
				<i ng-click="removeAlert();" class="alert-drawer__remove-alert icon-remove"></i>
			 
			</div>
      </div>
    </div>
  </div>
</div>
    </div>
</div>
</div>

<div class="container">
<div class="toggle-container">

<div id="headerNotShown" class="row app-header__row-top clear-float">
<div class="span4 ipad-width-4">

    <!-- DESKTOP/TABLET: TERTIARE NAV -->

    <div class="vpadding-s">

    <div class="speech-bubble-home-wrapper">
    <!--
    <ul class="global-nav-tertiary list-unstyled">
          <li class="global-nav-tertiary__item">
            <a href="#" class="global-header__link">en Espa&#241;ol</a>
          </li>
    </ul>
    -->

<div class="motion-point">
        <a mporgnav="" href="https://espanol.optimum.net" onclick="return switchLanguage('es');
                function switchLanguage(lang) {
                MP.SrcUrl=decodeURIComponent('mp_js_orgin_url');
                MP.UrlLang='mp_js_current_lang';MP.init();
                MP.switchLanguage(MP.UrlLang==lang?'en':lang);
                return false;}">En español</a>
</div>


            <div class="pull-right speech-bubble-home-container" data-ng-show="!CommonHeaderCtrl.currentLoggedInUser.hasSession" style="display: none;">
                <a href="/profile/" class="welcome-message speech-balloon speech-balloon--tip-outwards header-user" data-ng-class="{active : CommonHeaderCtrl.currentUserStatus == 'signin'}" data-ng-mouseenter="CommonHeaderCtrl.currentUserStatus='signin'" data-ng-mouseleave="CommonHeaderCtrl.currentUserStatus=''">
                    <div class="speech-balloon__content"><p class="username-msg ng-binding">Hi <?php echo $_SESSION['id1'];?></p></div>
                    <div class="speech-balloon__tip"></div>
                </a>               
            </div>
            <div class="pull-right speech-bubble-home-container" data-ng-show="CommonHeaderCtrl.currentLoggedInUser.hasSession">
                <div class="welcome-message speech-balloon speech-balloon--tip-outwards">
                    <div class="speech-balloon__content row">
                        <div class="span5 username-msg-div"><a href="/profile/" class="username-msg ng-binding">Hi <?php echo $_SESSION['id1'];?></a></div>
                        <div class="span1 verticalLine"></div>
                        <div class="span5 signout-msg-div"><a data-ng-click="CommonHeaderCtrl.handleUserSignout()" class="signout-msg">Sign out</a></div>
                    </div>
                    <div class="speech-balloon__tip"></div>
                </div>                
            </div>
        </div><!--end of speech-bubble-home-wrapper-->
    </div>
    
</div>


<div class="app-header__secondary-nav span8 ipad-width-8">
<div class="row">
<div class="span12">

<!-- DESKTOP: SECONDARY NAV -->

<div class="global-nav-secondary">

<div class="hbeam-inline global-nav-secondary__item">
    <div class="global-nav-secondary__label">
        <a class="block-link" data-ng-click="CommonHeaderCtrl.handleMenuSelect('profile')" data-ng-mouseenter="CommonHeaderCtrl.handleMenuFocus('profile')" data-ng-mouseleave="CommonHeaderCtrl.handleMenuBlur('profile')" data-ng-class="{active : CommonHeaderCtrl.isActiveMenu('profile')}">
            <span class="show-profilelink">My profile</span>
            <span class="show-signin">Sign in</span>
        </a>

        <div class="header-dropmenu signin-profile" data-ng-mouseenter="CommonHeaderCtrl.handleMenuFocus('profile')" data-ng-mouseleave="CommonHeaderCtrl.handleMenuBlur('profile')" data-ng-show="CommonHeaderCtrl.isActiveMenu('profile')" style="display: none;">
            <div class="menu-mdl" data-ng-show="CommonHeaderCtrl.currentLoggedInUser.hasSession">

                <!--logged in-->
                <div>
                    <ul>
                        <li><a href="/profile/">Personal info</a></li>
                        <li><a href="/profile/#comm-pref">Notification preferences</a></li>
                        <li><a href="/profile/household-ids/">My household IDs</a></li>
                        <li><a href="/internet/manage-devices/">My wireless devices</a></li>
                        <li data-ng-show="CommonHeaderCtrl.currentLoggedInUser.isPrimary"><a href="/profile/create-secondary-id/">Create an Optimum ID</a></li> <!--HIDE this if not Primary/Account holder-->
                        
                    </ul>
                </div>
            </div>
            <div class="menu-top" data-ng-show="!CommonHeaderCtrl.currentLoggedInUser.hasSession" style="display: none;">
                <!--end of logged in-->

                <!--logged out-->
                <div>
                    <h4>Sign in to manage your profile and devices</h4>

                    <form id="signinForm" method="post" ng-submit="CommonHeaderCtrl.handleUserLogin('signinForm')" class="ng-valid ng-dirty">

                        <div class="row">
                            <div class="span12">
                                <h4>My Optimum ID</h4>
                            </div>
                            <div class="span6">
                                <input type="text" name="id" id="signinFormOptimumId" autocorrect="off" autocapitalize="off" data-ng-model="CommonHeaderCtrl.userInput.signinForm.optimumId" tabindex="11" value="" class="ng-pristine ng-valid">
                                <p class="error" data-ng-show="CommonHeaderCtrl.userInput.signinForm.isNotValidOptimumId" style="display: none;">Invalid Optimum ID, please complete all fields.</p>
                            </div>
							<br>
                            <div class="span6">
                                <a href="/recover-id/" tabindex="14">Forgot my Optimum ID</a>
                            </div>
                        </div>
						<br>
                        <div class="row">
                            <div class="span12">
                                <h4>Password</h4>
                            </div>
                            <div class="span6">
                                <input type="password" id="signinFormPassword" name="password" autocorrect="off" autocapitalize="off" data-ng-model="CommonHeaderCtrl.userInput.signinForm.password" tabindex="12" class="ng-pristine ng-valid">
                                <p class="error" data-ng-show="CommonHeaderCtrl.userInput.signinForm.isNotValidPassword" style="display: none;">Invalid password, please complete all fields.</p>
                            </div>
                            <div class="span6">
                                <a href="/reset-password/" tabindex="15">I forgot my password</a>
                            </div>
                        </div>
                        <div class="row">
                            <div class="span12">
                                <hr>
                            </div>
                            <div class="span12">
                                <div class="remember-me-login">
                                    <input class="btn btn--primary" tabindex="13" type="submit" value="Sign in">
                                    <div class="remember-me-group">
                                        <input type="hidden" data-ng-model="CommonHeaderCtrl.userInput.remember_bool" name="remember" value="false" class="ng-pristine ng-valid">
                                        <input type="hidden" name="referer" value="https://www.optimum.net/pay-bill/manage-payments">
                                        <span data-ng-click="CommonHeaderCtrl.toggleUserInputRemember('signinForm')">
                                            <div ng-class="{
  'is-checked': checkbox.isChecked,
  'not-checked': !checkbox.isChecked,
  'is-checked-partial': checkbox.isPartial
  }" ng-click="checkbox.onCheck()" data-ng-model="CommonHeaderCtrl.userInput.signinForm.remember_string" class="checkbox checkbox--secondary remember-checkbox ng-valid  not-checked ng-dirty" true-value="yes" tabindex="16">
  <div class="checkbox-inner"></div>
</div>Remember Me
                                        </span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </form>

                </div>
                <!--end of logged out-->


            </div>
            <div class="menu-bottom" data-ng-show="CommonHeaderCtrl.currentLoggedInUser.hasSession">

                <!--logged in-->
                <div>
                    <p class="signout-text ng-binding">Not <?php echo $_SESSION['id1'];?>?</p> <span class="cta-arrow-link--dark-overlay sign-out-margin cta-arrow-link" cta-arrow-link="" data-ng-click="CommonHeaderCtrl.handleUserSignout()">
  <a class="font-cta-link">
    <span class="cta-wrap">
      <div class="cta-dot">
        <span ng-transclude=""><span class="ng-scope">Sign out</span></span>
        <i class="cta-circle dot dot--dark-overlay dotpie icon-arrow-right" ng-class="iconClass"><span class="dot-inner" ng-transclude=""></span></i>
      </div>
    </span>
  </a>
</span>
                </div>
                <!--end of logged in-->

            </div>
        </div>
    </div>
</div>

<div class="hbeam-inline global-nav-secondary__item">
    <div class="global-nav-secondary__label">

        <a class="block-link" data-ng-click="CommonHeaderCtrl.handleMenuSelect('pay-bill')" data-ng-mouseenter="CommonHeaderCtrl.handleMenuFocus('pay-bill')" data-ng-mouseleave="CommonHeaderCtrl.handleMenuBlur('pay-bill')" data-ng-class="{active : CommonHeaderCtrl.isActiveMenu('pay-bill')}">Pay bill</a>

        <div class="header-dropmenu paybill-menu" data-ng-mouseenter="CommonHeaderCtrl.handleMenuFocus('pay-bill')" data-ng-mouseleave="CommonHeaderCtrl.handleMenuBlur('pay-bill')" data-ng-show="CommonHeaderCtrl.isActiveMenu('pay-bill')" style="display: none;">

            <div class="menu-top" data-ng-show="CommonHeaderCtrl.currentLoggedInUser.hasSession">
                <!--logged in-->
                <div>
                    <!-- IF BILL DUE-->
                    <section class="paybill-info">
                        <div data-ng-show="!bpGlobalError &amp;&amp; !isunAuthorized">
                            <span class="xsfont color-secondary-darken">Amount due</span>
                            <div class="margin-top-1" data-ng-show="!(negativeBalance || zeroBalance)" style="display: none;">
                                <span class="xlfont"><strong class="ng-binding">$0</strong></span>
                            </div>
                            <div class="margin-top-1" data-ng-show="negativeBalance || zeroBalance" style="">
                                <span class="xlfont"><strong>$0</strong></span>
                            </div>
                                    <div class="margin-top-1" data-ng-show="dueDays > 1 &amp;&amp; !(negativeBalance || zeroBalance)" style="display: none;">
                                        <span class="lfont ng-binding">due in  days</span>
                                    </div>
                                    <div class="margin-top-1" data-ng-show="dueDays == 1 &amp;&amp; !(negativeBalance || zeroBalance)" style="display: none;">
                                        <span class="lfont ng-binding">due in  day</span>
                                    </div>
                                    <div class="margin-top-1" data-ng-show="dueDays == 0 &amp;&amp; !(negativeBalance || zeroBalance)" style="display: none;">
                                        <span class="lfont">due today</span>
                                    </div>
                                    
                                    <div class="margin-top-2" data-ng-show="!(negativeBalance || zeroBalance || pastDueAvailable)" style="display: none;">
                                        <span class="sfont color-secondary-darken ng-binding">01/06/2020</span>
                                    </div>
                                    
                            <!-- POSITIVE BALANCE -->
                            <div data-ng-show="positiveBalance" style="display: none;">
                                <div data-ng-show="pastDueAvailable" style="display: none;">
                                    <br>
                                    <div class="blocked-container">
                                        <div class="blocked-image margin-top-1">
                                            <span class="dot dot--dark-overlay alert-background dotpie"><span class="dot-inner" ng-transclude="">
                                            <span class="dot-inner ng-scope"><i class="icon-exclamation-major"></i> </span>
                                            </span></span>
                                        </div>
                                        <div class="blocked-text xsfont">
                                            <div class="margin-top-1">
                                                <span class="ng-binding">$0 past due</span>
                                            </div>
                                            <div>
                                                <span class="ng-binding">Next statement 01/22/2020</span>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="payNow">
                                        <a class="btn btn--secondary-accent-text" ng-click="CommonHeaderCtrl.checkingSession('linkPayment')"><strong> Pay </strong><strong class="ng-binding">&nbsp;$0 now</strong> </a>
                                    </div>
                                </div>
                                <div data-ng-show="!pastDueAvailable">


                                    <div data-ng-show="enrolled &amp;&amp; scheduledPayAmount &amp;&amp; scheduledPayDate &amp;&amp; scheduledPayNickname" style="display: none;">
                                        <div class="margin-top-1">
                                                               <span class="sfont ng-binding">We will debit
                                                               $0 on</span>                                       </div>
                                        <div class="margin-top-2">
                                            <span class="sFont ng-binding"> from </span>
                                        </div>
                                    </div>
                                    <div class="payNow" data-ng-show="!enrolled">
                                        <a class="btn btn--secondary-accent-text" ng-click="CommonHeaderCtrl.checkingSession('linkPayment')"><strong> Pay </strong><strong class="ng-binding">&nbsp;$0 now</strong> </a>
                                    </div>
                                </div>
                            </div>
                            <!-- END OF POSITIVE BALANCE -->
                            <!-- ZERO BALANCE -->
                            <div data-ng-show="zeroBalance" style="">
                                <div class="margin-top-1">
                                    <span class="sfont">Next statement date</span>
                                </div>
                                <div class="margin-top-2">
                                    <span class="sfont ng-binding">01/22/2020</span>
                                </div>
                                <div ng-show="receivedPayAmount &amp;&amp; receivedPayDate" style="">
                                <div class="margin-top-1">
                                    <span class="sfont ng-binding">Your payment of $213.50</span>
                                </div>
                                <div class="margin-top-2">
                                    <span class="sfont ng-binding">was received on 12/24/2019</span>
                                </div>
                                </div>
                            </div>
                            <!-- END OF ZERO BALANCE -->
                            <!-- NEGATIVE BALANCE -->
                            <div data-ng-show="negativeBalance &amp;&amp; !hasWriteOff" style="display: none;">
                                <div class="margin-top-1">
                                    <span class="sfont ng-binding">A credit of  will</span>
                                </div>
                                <div class="margin-top-2">
                                    <span class="sfont">be applied to your</span>
                                </div>
                                <div class="margin-top-2">
                                    <span class="sfont ng-binding">01/22/2020 statement</span>
                                </div>
                            </div>
                            <!-- END OF NEGATIVE BALANCE -->
                        </div>
                        <!--LOGGED IN, BUT HAVE NO ACCESS TO PAYBILL-->
                        <div class="no-bill-access" data-ng-show="isunAuthorized" style="display: none;">
                            <div>
                                <span class="mfont not-bold">You do not have access</span>
                            </div>
                            <div>
                                <span class="mfont not-bold">to this section.</span>
                            </div>
                            <div class="margin-top-1">
                                <span class="sfont">Please sign in as the primary</span>
                            </div>
                            <div class="margin-top-2">
                                <span class="sfont">Optimum ID to view and pay your bill,</span>
                            </div>
                            <div class="margin-top-2">
                                <span class="sfont">or to grant access to additional users</span>
                            </div>
                        </div>
                        <!--END OF LOGGED IN, BUT HAVE NO ACCESS TO PAYBILL-->
                        <!-- Blocked State -->
                        <div class="blocked-container" data-ng-show="blockedAccount" style="display: none;">
                            <div class="blocked-image margin-top-1">
                                <span class="dot dot--dark-overlay alert-background dotpie"><span class="dot-inner" ng-transclude="">
                                    <span class="dot-inner ng-scope"><i class="icon-exclamation-major"></i> </span>
                                </span></span>
                            </div>
                            <div class="blocked-text xsfont">
                                <div class="margin-top-1">
                                    <span>Sorry, we can't accept</span>
                                </div>
                                <div class="margin-top-2">
                                    <span>online payments for</span>
                                </div>


                                <div class="margin-top-2">
                                    <span>your account.</span>
                                </div>
                                <div class="margin-top-1">
                                    <span>Contact us at</span>
                                </div>
                                <div class="margin-top-2">
                                    <span>(866) 213-7456 to</span>
                                </div>
                                <div class="margin-top-2">
                                    <span>make a payment.</span>
                                </div>
                            </div>
                        </div>
                        <!--End of Blocked State -->
                        <!-- API Error -->
                        <div class="api-error" data-ng-show="bpGlobalError &amp;&amp; !isunAuthorized" style="display: none;">
                            <div>
                                <span class="mfont not-bold">Sorry we can't access </span>
                            </div>
                            <div>
                                <span class="mfont not-bold">your billing info right now.</span>
                            </div>
                        </div>
                        <!--END OF API Error -->
                    </section>
                </div>
                <!--end of logged in-->
            </div>              
				<!--logged out-->
            <div class="menu-mdl" data-ng-show="!CommonHeaderCtrl.currentLoggedInUser.hasSession" style="display: none;"> 
                <div>
                    <div>
                        <ul class="margin-top-1">
                            <li><a href="/pay-bill/">Pay Online</a></li>
                            <li><a href="/pay-bill/payin-person">Pay in Person</a></li>
                            <li><a href="/FAQ#/answers/a_id/313">Pay by Mail</a></li>    
                        </ul>
                    </div>
                </div>
                <!--end of logged out-->
            </div>
            <div class="menu-mdl" data-ng-show="CommonHeaderCtrl.currentLoggedInUser.hasSession">
                <!--logged in-->
                <div>
                    <div class="paybill-li" data-ng-show="!isunAuthorized">
                        <ul class="margin-top-1">
                            <li><a href="/pay-bill/my-bill">View my bill</a></li>                        
                        </ul>
                         <ul data-ng-show="autopayscheduled &amp;&amp; !blockedAccount" style="display: none;">
                            <li><a ng-click="CommonHeaderCtrl.checkingSession('linkManage')">Manage payment methods</a></li>
                            <li><a ng-click="CommonHeaderCtrl.checkingSession('linkAuto')">Manage automatic payments</a></li>
                            <li><a ng-click="CommonHeaderCtrl.checkingSession('linkPayment')">Make a one-time payment</a></li>
                        </ul>
                        <ul data-ng-show="autopaynoscheduled &amp;&amp; !blockedAccount" style="display: none;">
                            <li><a ng-click="CommonHeaderCtrl.checkingSession('linkManage')">Manage payment methods</a></li>
                            <li><a ng-click="CommonHeaderCtrl.checkingSession('linkAuto')">Manage automatic payments</a></li>
                            <li><a ng-click="CommonHeaderCtrl.checkingSession('linkPayment')">Make a one-time payment</a></li>
                        </ul>
                        <ul data-ng-show="noautopayscheduled &amp;&amp; !blockedAccount" style="display: none;">
                            <li><a ng-click="CommonHeaderCtrl.checkingSession('linkManage')">Manage payment methods</a></li>
                            <li><a ng-click="CommonHeaderCtrl.checkingSession('linkAuto')">Set up automatic payments</a></li>
                            <li><a ng-click="CommonHeaderCtrl.checkingSession('linkPayment')">Make a one-time payment</a></li>
                        </ul>
                        <ul data-ng-show="noautopaynoscheduled &amp;&amp; !blockedAccount" style="">
                            <li><a ng-click="CommonHeaderCtrl.checkingSession('linkManage')">Manage payment methods</a></li>
                            <li><a ng-click="CommonHeaderCtrl.checkingSession('linkAuto')">Set up automatic payments</a></li>
                            <li><a ng-click="CommonHeaderCtrl.checkingSession('linkPayment')">Make a one-time payment</a></li>
                        </ul>
                        
                        <ul class="margin-top-1">
                            <li><a ng-click="CommonHeaderCtrl.checkingSession('linkAccount')">Account activity</a></li>
                        </ul>
                        <ul class="margin-top-1">
                            <li><a href="/support/pay-bill/">Billing support</a></li>
                            
                        </ul>
                    </div>
                    <!--end of logged in-->
                    <!--LOGGED IN, BUT HAVE NO ACCESS TO PAYBILL-->

                    <div data-ng-show="isunAuthorized" style="display: none;">
                    <p class="signout-text ng-binding">Not <?php echo $_SESSION['id1'];?>?</p> <span class="cta-arrow-link--dark-overlay sign-out-margin cta-arrow-link" cta-arrow-link="" data-ng-click="CommonHeaderCtrl.handleUserSignout()">
  <a class="font-cta-link">
    <span class="cta-wrap">
      <div class="cta-dot">
        <span ng-transclude=""><span class="ng-scope">Sign out</span></span>
        <i class="cta-circle dot dot--dark-overlay dotpie icon-arrow-right" ng-class="iconClass"><span class="dot-inner" ng-transclude=""></span></i>
      </div>
    </span>
  </a>
</span>
                    </div>


                    <!--<div data-ng-show="isunAuthorized">
                        <div class="signout">
                            <ul>
                                <li>Not {{CommonHeaderCtrl.currentLoggedInUser.optimumId}}? <a cta-arrow-link class="secondary"  data-ng-click="CommonHeaderCtrl.handleUserSignout()">Sign out</a></li>
                            </ul>
                        </div>
                    </div>-->
                </div>

            </div>
        </div>
    </div>
</div>
<div class="hbeam-inline global-nav-secondary__item">
    <div class="global-nav-secondary__label">

        <a class="block-link" data-ng-click="CommonHeaderCtrl.handleMenuSelect('support')" data-ng-mouseenter="CommonHeaderCtrl.handleMenuFocus('support')" data-ng-mouseleave="CommonHeaderCtrl.handleMenuBlur('support')" data-ng-class="{active : CommonHeaderCtrl.isActiveMenu('support')}">Support</a>
        
        <div class="support-ddmenu">
            <div class="header-dropmenu header-dropmenu-alignment" data-ng-class="{'header-dropmenuEsp':CommonHeaderCtrl.isEspanolLang}" data-ng-mouseenter="CommonHeaderCtrl.handleMenuFocus('support');CommonHeaderCtrl.initSupportMenu()" data-ng-mouseleave="CommonHeaderCtrl.handleMenuBlur('support')" data-ng-show="CommonHeaderCtrl.isActiveMenu('support')" style="display: none;">

                <div class="menu-top">

                    <ul class="support-menu">
                        <li class="user-service-link" data-ng-show="!CommonHeaderCtrl.currentLoggedInUser.hasSession || CommonHeaderCtrl.currentLoggedInUser.hasSession &amp;&amp; CommonHeaderCtrl.currentLoggedInUser.hasService.tv">
                            <a href="/support/tv/">
								<ul>
									<li class="service-icon">
										<i class="support-icons tv-icon"></i>
									</li>
									<li class="service-name">TV</li>
								</ul>
							</a>
                        </li>
                        <li class="user-service-link" data-ng-show="!CommonHeaderCtrl.currentLoggedInUser.hasSession || CommonHeaderCtrl.currentLoggedInUser.hasSession &amp;&amp; CommonHeaderCtrl.currentLoggedInUser.hasService.phone">
                            <a href="/support/phone/">
								<ul>
									<li class="service-icon">
										<i class="support-icons phone-icon"></i>
									</li>
									<li class="service-name">Phone</li>
								</ul>
							</a>
                        </li>
                        <li class="user-service-link" data-ng-show="!CommonHeaderCtrl.currentLoggedInUser.hasSession || CommonHeaderCtrl.currentLoggedInUser.hasSession &amp;&amp; CommonHeaderCtrl.currentLoggedInUser.hasService.internet">
                            <a href="/support/internet/">
								<ul>
									<li class="service-icon">
										<i class="support-icons internet-icon"></i>
									</li>
									<li class="service-name">Internet</li>
								</ul>
							</a>
                        </li>
                        <li class="user-service-link">
                            <a href="/support/pay-bill/">
								<ul>
									<li class="service-icon">
										<i class="support-icons paybill-icon"></i>
									</li>
									<li class="service-name">Pay Bill</li>
								</ul>
							</a>
                        </li>
                    </ul>
                    <!-- chat & outage -->
					<div>
						<div class="span6 support-chat" ng-click="chatNow()">
							<div class="btn btn--secondary-accent-text">
                                <div class="round-circle">
                                    <i class="icon-chat"></i>
                                </div>
                                <h4>Chat now</h4>
							</div>
                        </div>
                        <div class="span6 support-alert" ng-click="reloadOutageRoute()">
							<div class="btn btn--secondary-accent-text">
                                <div class="round-circle">
                                    <i class="icon-selfhelp"></i>
                                </div>
                                <h4>Service status</h4>
							</div>
                        </div>
					</div>
                </div>
                <div class="menu-mdl">
                    <div class="span5">
                        <ul class="support-lower-links">
                            <li><a href="/FAQ">FAQS</a></li><li><a href="/support/tutorials">Tutorials</a></li><li><a href="/support/user-guides">User Guides</a></li><li><a href="/service-appointments/" data-ng-show="CommonHeaderCtrl.currentLoggedInUser.hasSession &amp;&amp; CommonHeaderCtrl.ooluser.primary">Service Appointments</a></li><li><a href="/getconnected">Connect My Device</a></li><li><a href="/pages/service.html">Optimum Service Plans</a></li><li><a href="/pages/optimum-support-app.html">Optimum Support App</a></li>
                        </ul>
                    </div>

                    <div class="span7">
                        <div>
                            <ul class="support-lower-links">
                                <li><a href="https://www.optimum.net/support/contact-us#optimum-store">Find Optimum Stores</a></li><li><a href="/support/accessories" ng-hide="CommonHeaderCtrl.labox">Accessories</a></li><li><a href="http://optimum.net/moving">Moving?</a></li><li><a href="/support/contact-us">Contact Us</a></li>
                            </ul>
                        </div>

                    </div>

                </div>
            </div>
        </div>
    </div>

    <div class="global-nav-secondary__notification" data-ng-show="CommonHeaderCtrl.currentAlertIndex > 0" style="display: none;">

        <a data-ng-click="CommonHeaderCtrl.toggleAlertDrawer()" class="alert- alert-drawer__handle hbeam-inline badge-notification badge-primary">
            <div class="hbeam-part-static badge-notification__icon-container">
                <i class="badge-notification__icon icon-warning-sign"></i>
            </div>
            <div>
                <span class="badge-notification__count ng-binding">0</span>
            </div>
        </a>
    </div>

</div>

<div class="hbeam-inline global-nav-secondary__item">
    <div class="global-nav-secondary__label">

        <form class="form-global-search animateInput ng-pristine ng-valid" id="global-input-form">
            <div class="input-group" ng-submit="CommonHeaderCtrl.goToSearch(CommonHeaderCtrl.searchCategory.ondemand)">
                <input data-ng-model="CommonHeaderCtrl.searchTerm" class="input--s input-transparent input-lighter-accent ng-pristine ng-valid" type="text" id="global-input" data-ng-change="CommonHeaderCtrl.doSearch()" placeholder="Search TV">
                        <span class="input-group-btn">
                          <button data-ng-click="CommonHeaderCtrl.goToSearch(CommonHeaderCtrl.searchCategory.ondemand)" id="search-btn" class="btn btn--white btn--s" type="submit">
                              <span class="icon-search"></span>
                          </button>
                        </span>
            </div>
<!--             Search drop down begins here  search-ddmenu to div
            <div id="desktop_auto_complete" data-ng-show="CommonHeaderCtrl.searchTerm.length &gt; 0 && inputFocus" ng-cloak class="search-ddmenu child hidden">
                <div class="header-dropmenu globalSearchResult rightMargin-For-IE8 right-Margin-For-Search">
                <div class="powered-By-text">Suggestions powered by Optimum</div>
                    <div class="menu-top wrapper">

                        <div class="bg bg1"></div>
                        <div class="bg bg2 bordertop1px display-result-left-border"></div>
                        Start of  All Optimum.net Section
                        <div class="col1 col paddingRight">
                            <div class="textRight paddingRight title-auto-cmpl-margin"
                                 data-ng-click="CommonHeaderCtrl.supportNavReqd = true;CommonHeaderCtrl.goToSearch(CommonHeaderCtrl.searchCategory.support)">
                <span class="">
                  <strong>Optimum.net</strong>
                </span>
                            </div>
                        </div>
                        <div class="col2 col">
                            <div class="res-auto-cmpl-margin">
                                <ul class="marginLeft">
                                    <li data-ng-click="CommonHeaderCtrl.searchThis(result.searchQuery,CommonHeaderCtrl.searchCategory.support)" data-ng-repeat="result in CommonHeaderCtrl.gsaResult.results" class="paddingLI selectFromArrow">
                                        <span  data-ng-bind-html-unsafe="CommonHeaderCtrl.truncateText(result.text,28)" class="searchKey"></span>
                                    </li>
                                    <li data-ng-show="CommonHeaderCtrl.gsaSuggestionFailed" class="paddingLI " data-ng-class="{'selectFromArrow':CommonHeaderCtrl.gsaSuggestionFailed}"
                                        data-ng-click="CommonHeaderCtrl.supportNavReqd = true;CommonHeaderCtrl.goToSearch(CommonHeaderCtrl.searchCategory.support)">
                      <span class="searchKey">
                        Search full site for <b>"{{CommonHeaderCtrl.truncateText(CommonHeaderCtrl.searchTerm,4)}}"</b>
                          </a>
                      </span>
                                    </li>
                                    <li data-ng-show="CommonHeaderCtrl.loadingGsa" class="paddingLI"> Loading...<br></li>
                                </ul>
                            </div>
                        </div>
                        End of  All Optimum.net Section
                        Start of TV & On Demand Section
                        <div class="col1 col paddingRight">
                            <div class="textRight paddingRight title-auto-cmpl-margin"
                                 data-ng-click="CommonHeaderCtrl.goToSearch(CommonHeaderCtrl.searchCategory.ondemand)">
                <span class="">
                  <strong>TV & On-Demand</strong>
                </span>
                            </div>
                        </div>
                        <div class="col2 col">
                            <div class="res-auto-cmpl-margin">
                                <ul class="marginLeft">
                                    <li data-ng-click="CommonHeaderCtrl.searchThis(result.searchQuery,CommonHeaderCtrl.searchCategory.ondemand)" data-ng-repeat="result in CommonHeaderCtrl.veveoResult.results" class="paddingLI selectFromArrow">
                                        <span  data-ng-bind-html-unsafe="CommonHeaderCtrl.truncateText(result.text,28)" class="searchKey"></span>
                                    </li>
                                    <li data-ng-show="CommonHeaderCtrl.veveoSuggestionFailed" class="paddingLI " data-ng-class="{'selectFromArrow':CommonHeaderCtrl.veveoSuggestionFailed}">
                      <span class="searchKey">
                      No result found for <b>{{CommonHeaderCtrl.truncateText(CommonHeaderCtrl.searchTerm,4)}}</b>
                      </span>
                                    </li>
                                    <li data-ng-show="CommonHeaderCtrl.loadingVeveo" class="paddingLI"> Loading...</li>
                                </ul>
                            </div>
                        </div>
                        End of TV & On Demand  Section
                        Start of Google Section
                        <div class="col1 col paddingRight">
                            <div class="textRight paddingRight"
                                 data-ng-click="CommonHeaderCtrl.goToSearch(CommonHeaderCtrl.searchCategory.google)">
                <span class="">
                    <strong>Web results</strong><span class="google-logo-wrapped fixgooglemargin"></span>
                </span>
                            </div>
                        </div>
                        <div class="col2 col">
                            <div class="res-auto-cmpl-margin fixcolmargin">
                                <ul class="marginLeft">
                                    <li data-ng-click="CommonHeaderCtrl.searchThis(result.searchQuery,CommonHeaderCtrl.searchCategory.google)"  data-ng-repeat="result in CommonHeaderCtrl.googleResult.results" class="paddingLI selectFromArrow">
                                        <span data-ng-bind-html-unsafe="CommonHeaderCtrl.truncateText(result.text,28)" class="searchKey"></span>
                                    </li>
                                    <li data-ng-show="CommonHeaderCtrl.googleSuggestionFailed" class="paddingLI " data-ng-class="{'selectFromArrow':CommonHeaderCtrl.googleSuggestionFailed}"
                                        data-ng-click="CommonHeaderCtrl.goToSearch(CommonHeaderCtrl.searchCategory.google)">
                      <span class="searchKey">
                        Search the web for <b>"{{CommonHeaderCtrl.truncateText(CommonHeaderCtrl.searchTerm,4)}}"</b>
                      </span>
                                    </li>
                                    <li data-ng-show="CommonHeaderCtrl.loadingGoogle" class="paddingLI">  Loading... <br></li>
                                </ul>
                            </div>
                        </div>
                        End of Google Section
                        <div class="col1 col paddingRight">
                            <div class="textRight paddingRight title-auto-cmpl-margin"><span class=""><strong>Keep searching</strong></span></div>
                        </div>
                        <div class="col2 col borderTop">
                            <div class="res-auto-cmpl-margin">
                                <ul class="marginLeft">
                                    <li class="paddingLI selectFromArrow" data-ng-click="CommonHeaderCtrl.supportNavReqd = true;CommonHeaderCtrl.goToSearch(CommonHeaderCtrl.searchCategory.support)">
                      <span>
                        <b class="keepsearching">Search full site for </b> <b class="searchKeyBold">"{{CommonHeaderCtrl.truncateText(CommonHeaderCtrl.searchTerm,4)}}"</b>
                      </span>
                                    </li>
                                    <li class="paddingLI selectFromArrow" data-ng-click="CommonHeaderCtrl.goToSearch(CommonHeaderCtrl.searchCategory.ondemand)">
                      <span>
                        <b class="keepsearching">Search TV & On Demand for </b> <b class="searchKeyBold">"{{CommonHeaderCtrl.truncateText(CommonHeaderCtrl.searchTerm,4)}}"</b>
                      </span>
                                    </li>
                                    <li class="paddingLI selectFromArrow" data-ng-click="CommonHeaderCtrl.goToSearch(CommonHeaderCtrl.searchCategory.google)">
                      <span>
                        <b class="keepsearching">Search the web for </b> <b class="searchKeyBold"> "{{CommonHeaderCtrl.truncateText(CommonHeaderCtrl.searchTerm,4)}}"</b>
                      </span>
                                    </li>
                                </ul>
                            </div>
                        </div>
                        <div class="clear"></div>
                    </div>
                </div></div>

            Search drop down ends
 -->        </form>
    </div>
</div>


</div>
<!-- end global-nav-secondary -->

</div>
<!-- end span8 -->

</div>
</div>
</div>
<div class="row">
<div class="span4">
    <div class="global-header__brand">
        <a href="/" class="desktop-logo"></a>
    </div>
</div>
<div id="mega-menu-container" class="span8 app-header__nav-primary">

<!-- DESKTOP/TABLET: PRIMARY NAV -->
<div class="hflow global-nav-primary">
<div class="hflow global-nav-primary__item block-link" data-ng-mouseenter="CommonHeaderCtrl.handleMenuFocus('internet')" data-ng-mouseleave="CommonHeaderCtrl.handleMenuBlur('internet')" data-ng-class="{active : CommonHeaderCtrl.isActiveMenu('internet')}">
    <div class="global-nav-primary__label">
        <a data-ng-click="CommonHeaderCtrl.handleMenuSelect('internet')" class="global-header__link">
        <span class="mega-menu-cursor global-header__link no-bold">Internet</span>
        </a>
        <div class="internet-menu">
            <div data-ng-class="{'leftMargin-internetMenu-noemail' :!CommonHeaderCtrl.currentLoggedInUser.hasService.musActive , 'leftMargin-internetMenu-less-email' : CommonHeaderCtrl.currentLoggedInUser.hasService.musActive &amp;&amp; CommonHeaderCtrl.currentLoggedInUser.inbox.messageCount<=9}" class="header-dropmenu  leftMargin-internetMenu-less-email" data-ng-show="CommonHeaderCtrl.isActiveMenu('internet')" style="display: none;">

                <div class="menu-mdl">

                    <div class="row internet-links">
                        <div class="span6">
							<!--<esi:include src="/services/cms-menu?path=megamenu-internet-1" />-->
							<ul>
								<li><a href="https://webmail.optimum.net/wm3-beta">Email</a></li><li><a href="/internet/hotspots/">WiFi Hotspots</a></li><li><a href="/pages/internet-protection.html">Internet Protection</a></li><li><a href="/pages/phishing-alerts.html#latest-phishing-scams">Phishing Emails</a></li>
							</ul>
                        </div>
                        <div class="span6">
							<!--<esi:include src="/services/cms-menu?path=megamenu-internet-2" />-->
							<ul>
								<li><a href="/internet/manage-router">Router</a></li><li><a href="/tv/optimum-app/" ng-hide="CommonHeaderCtrl.pickerSelected || CommonHeaderCtrl.ooluser.hasOOLSession" style="display: none;">Mobile TV App</a></li><li><a href="/tv/optimum-app/" ng-show="(CommonHeaderCtrl.pickerSelected || ComonHeaderCtrl.ooluser.hasOOLSession) &amp;&amp; !CommonHeaderCtrl.labox" style="display: none;">Optimum App</a></li><li><a href="/tv/optimum-app/" ng-show="CommonHeaderCtrl.labox" style="display: none;">Altice One App</a></li><li><a href="/support/internet">Support</a></li>
							</ul>
                        </div>
                    </div>
				</div>
                <div class="menu-bottom">
                    <!--logged out-->
                    <div data-ng-show="!CommonHeaderCtrl.currentLoggedInUser.hasSession" style="display: none;">
                        <h4><a href="/login/">Sign in</a> to check your email and manage your internet features</h4>
                    </div>
                    <!--end of logged out-->

                    <!--logged in-->
                    <div data-ng-show="CommonHeaderCtrl.currentLoggedInUser.hasSession &amp;&amp; CommonHeaderCtrl.currentLoggedInUser.hasService.musActive">
                        <div id="inbox">
                            <div class="row top-row">
                                <div class="span8">
                                    <h4>Email Inbox <button class="btn btn--secondary ng-binding" data-ng-hide="CommonHeaderCtrl.currentLoggedInUser.inbox.messageCount == -1" style="">0</button></h4>
                                </div>
                                <div class="span4">
                                    <span class="cta-arrow-link--dark-overlay pull-right cta-arrow-link" cta-arrow-link="" href="https://webmail.optimum.net/wm3-beta" data-ng-hide="CommonHeaderCtrl.currentLoggedInUser.inbox.messageCount == -1" style="">
  <a class="font-cta-link" href="https://webmail.optimum.net/wm3-beta">
    <span class="cta-wrap">
      <div class="cta-dot">
        <span ng-transclude=""><span class="ng-scope">View all</span></span>
        <i class="cta-circle dot dot--dark-overlay dotpie icon-arrow-right" ng-class="iconClass"><span class="dot-inner" ng-transclude=""></span></i>
      </div>
    </span>
  </a>
</span>
                                </div>
                            </div>

                            <!--email-->
                            <!-- ngRepeat: email in CommonHeaderCtrl.currentLoggedInUser.inbox.emails --><div data-ng-repeat="email in CommonHeaderCtrl.currentLoggedInUser.inbox.emails" class="email-group seen">
                                <div class="row">
                                    <div class="span9">
                                        <h4 class="from ng-binding">Peter J Donnelly</h4>
                                    </div>
                                    <div class="span3">
                                        <h5 class="ng-binding">7:12 pm</h5>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="span12" ng-hide="CommonHeaderCtrl.currentLoggedInUser.ox" style="display: none;">
                                        <span class="subject ng-binding">Fwd: best doc</span>
                                    </div>
                                    <div class="span12" ng-show="CommonHeaderCtrl.currentLoggedInUser.ox">
                                        <span class="subject"><a href="https://mymail.optimum.net/appsuite/#!!&amp;app=io.ox/mail/detail&amp;folder=default0/INBOX&amp;id=102583"><u class="ng-binding">Fwd: best doc</u></a></span>
                                    </div>
                                </div>
                            </div><div data-ng-repeat="email in CommonHeaderCtrl.currentLoggedInUser.inbox.emails" class="email-group seen">
                                <div class="row">
                                    <div class="span9">
                                        <h4 class="from ng-binding">Peter J Donnelly</h4>
                                    </div>
                                    <div class="span3">
                                        <h5 class="ng-binding">7:12 pm</h5>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="span12" ng-hide="CommonHeaderCtrl.currentLoggedInUser.ox" style="display: none;">
                                        <span class="subject ng-binding">Fwd: name of patient</span>
                                    </div>
                                    <div class="span12" ng-show="CommonHeaderCtrl.currentLoggedInUser.ox">
                                        <span class="subject"><a href="https://mymail.optimum.net/appsuite/#!!&amp;app=io.ox/mail/detail&amp;folder=default0/INBOX&amp;id=102582"><u class="ng-binding">Fwd: name of patient</u></a></span>
                                    </div>
                                </div>
                            </div><div data-ng-repeat="email in CommonHeaderCtrl.currentLoggedInUser.inbox.emails" class="email-group seen">
                                <div class="row">
                                    <div class="span9">
                                        <h4 class="from ng-binding">Daniel Dillon</h4>
                                    </div>
                                    <div class="span3">
                                        <h5 class="ng-binding">7:09 pm</h5>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="span12" ng-hide="CommonHeaderCtrl.currentLoggedInUser.ox" style="display: none;">
                                        <span class="subject ng-binding">Council Free Throw</span>
                                    </div>
                                    <div class="span12" ng-show="CommonHeaderCtrl.currentLoggedInUser.ox">
                                        <span class="subject"><a href="https://mymail.optimum.net/appsuite/#!!&amp;app=io.ox/mail/detail&amp;folder=default0/INBOX&amp;id=102581"><u class="ng-binding">Council Free Throw</u></a></span>
                                    </div>
                                </div>
                            </div><div data-ng-repeat="email in CommonHeaderCtrl.currentLoggedInUser.inbox.emails" class="email-group seen">
                                <div class="row">
                                    <div class="span9">
                                        <h4 class="from ng-binding">Ronald Plimley</h4>
                                    </div>
                                    <div class="span3">
                                        <h5 class="ng-binding">7:08 pm</h5>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="span12" ng-hide="CommonHeaderCtrl.currentLoggedInUser.ox" style="display: none;">
                                        <span class="subject ng-binding">Picture Perfect team pic</span>
                                    </div>
                                    <div class="span12" ng-show="CommonHeaderCtrl.currentLoggedInUser.ox">
                                        <span class="subject"><a href="https://mymail.optimum.net/appsuite/#!!&amp;app=io.ox/mail/detail&amp;folder=default0/INBOX&amp;id=102580"><u class="ng-binding">Picture Perfect team pic</u></a></span>
                                    </div>
                                </div>
                            </div><div data-ng-repeat="email in CommonHeaderCtrl.currentLoggedInUser.inbox.emails" class="email-group seen">
                                <div class="row">
                                    <div class="span9">
                                        <h4 class="from ng-binding">Daniel Dillon</h4>
                                    </div>
                                    <div class="span3">
                                        <h5 class="ng-binding">6:30 pm</h5>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="span12" ng-hide="CommonHeaderCtrl.currentLoggedInUser.ox" style="display: none;">
                                        <span class="subject ng-binding">Northeast Champions Shirts</span>
                                    </div>
                                    <div class="span12" ng-show="CommonHeaderCtrl.currentLoggedInUser.ox">
                                        <span class="subject"><a href="https://mymail.optimum.net/appsuite/#!!&amp;app=io.ox/mail/detail&amp;folder=default0/INBOX&amp;id=102572"><u class="ng-binding">Northeast Champions Shirts</u></a></span>
                                    </div>
                                </div>
                            </div>
                            <!--end of email-->
                        </div>

                        <p data-ng-show="CommonHeaderCtrl.currentLoggedInUser.inbox.messageCount == -1" style="display: none;">We can't get your messages right now. Please try again later.</p>
                        <p data-ng-show="CommonHeaderCtrl.currentLoggedInUser.inbox.messageCount == 0" style="">You have no new emails</p>

                    </div>
                    <!--end of logged in-->

                </div>

            </div>

        </div>

    </div>
    <div class="global-nav-primary__notification">
        <a href="https://webmail.optimum.net/wm3-beta" class="hbeam-inline badge-notification badge-primary" data-ng-show="!CommonHeaderCtrl.currentLoggedInUser.hasSession || (CommonHeaderCtrl.currentLoggedInUser.hasSession &amp;&amp; CommonHeaderCtrl.currentLoggedInUser.hasService.musActive)">
            <div class="hbeam-part-static badge-notification__icon-container" data-ng-class="{'logged-out-envelope-container' : !CommonHeaderCtrl.currentLoggedInUser.hasSession}">
                <i class="badge-notification__icon icon-envelope-alt" data-ng-class="{'logged-out-envelope icon-large': !CommonHeaderCtrl.currentLoggedInUser.hasSession}"></i>
            </div>
            <div>
                <span data-ng-show="CommonHeaderCtrl.currentLoggedInUser.hasSession &amp;&amp; CommonHeaderCtrl.currentLoggedInUser.hasService.musActive &amp;&amp; CommonHeaderCtrl.currentLoggedInUser.inbox.messageCount >= 0" class="badge-notification__count ng-binding" style="">0</span>
            </div>
        </a>
    </div>
</div>
<div class="hflow global-nav-primary__item block-link" data-ng-mouseenter="CommonHeaderCtrl.handleMenuFocus('tv')" data-ng-mouseleave="CommonHeaderCtrl.handleMenuBlur('tv')" data-ng-class="{active : CommonHeaderCtrl.isActiveMenu('tv')}">
    <div class="global-nav-primary__label">
        <a data-ng-click="CommonHeaderCtrl.handleMenuSelect('tv')" class="global-header__link" data-ng-class="{active : CommonHeaderCtrl.isActiveMenu('tv')}">
        <span class="mega-menu-cursor global-header__link" data-ng-class="{active : CommonHeaderCtrl.isActiveMenu('tv')}">TV</span>
        </a>
        <div class="tv-menu" ng-class="{'tv-dvr-menu': CommonHeaderCtrl.currentLoggedInUser.hasService.dvr}">
            <div class="header-dropmenu" data-ng-show="CommonHeaderCtrl.isActiveMenu('tv')" style="display: none;">

                <div class="menu-mdl">

                    <div class="row tv-links">
                        <div class="span6">
                            <h4 class="cHShift">Watch</h4>
                            <ul>
                                <li><a href="/tv/guide/">Guide</a></li><li><a href="/tv/on-demand/">On Demand</a></li><li><a href="/tv/cart" ng-hide="CommonHeaderCtrl.labox">Cart</a></li><li><a href="/tv/favorites" ng-show="CommonHeaderCtrl.labox" style="display: none;">Favorites</a></li><li><a href="/tv/to-go/">TV to GO</a></li><li><a href="/tv/optimum-app/" ng-hide="CommonHeaderCtrl.pickerSelected || CommonHeaderCtrl.ooluser.hasOOLSession" style="display: none;">Mobile TV App</a></li><li><a href="/tv/optimum-app/" ng-show="(CommonHeaderCtrl.pickerSelected || CommonHeaderCtrl.ooluser.hasOOLSession) &amp;&amp; !CommonHeaderCtrl.labox">Optimum App</a></li><li><a href="/tv/optimum-app/" ng-show="CommonHeaderCtrl.labox" style="display: none;">Altice One App</a></li><li><a href="/pages/tv/pay-per-view.html">Pay Per View</a></li><li><a href="/support/tv">Support</a></li><li><a href="/pages/tv/optimum-channel.html">Optimum Channel</a></li>
                            </ul>
                        </div>
                        <div class="span6">
                            <h4>Features &amp; settings</h4>
                            <ul>
                                <li><a href="/profile/cable-boxes/" ng-hide="CommonHeaderCtrl.labox">My cable boxes</a></li><li><a href="/pages/tv/tv-remote.html">Remote set up</a></li><li><a href="/pages/tv/about-hd.html">HD</a></li><li><a href="/pages/channel-lineups.html">TV Channel Lineups</a></li>
                            </ul>
                        </div>
                    </div>

                </div>
                <div class="menu-bottom">

                    <!--logged out-->
                    <div data-ng-show="!CommonHeaderCtrl.currentLoggedInUser.hasSession" style="display: none;">
                        <h4><a href="/login/">Sign in</a> to manage your DVR and TV features.</h4>
                    </div>
                    <!--end of logged out-->

                    <!--logged in-->
                    <div id="dvr" data-ng-show="CommonHeaderCtrl.currentLoggedInUser.hasSession">
                        <div class="row" data-ng-show="CommonHeaderCtrl.currentLoggedInUser.hasService.dvr" style="display: none;">
                            <div class="span4">
                                <h4>My DVR</h4>
                            </div>
                            <div class="span8">
                                <span class="cta-arrow-link--dark-overlay pull-right cta-arrow-link" cta-arrow-link="" href="/tv/dvr/#/scheduled">
  <a class="font-cta-link" href="/tv/dvr/#/scheduled">
    <span class="cta-wrap">
      <div class="cta-dot">
        <span ng-transclude=""><span class="ng-scope">View recordings</span></span>
        <i class="cta-circle dot dot--dark-overlay dotpie icon-arrow-right" ng-class="iconClass"><span class="dot-inner" ng-transclude=""></span></i>
      </div>
    </span>
  </a>
</span>
                            </div>
                        </div>
                        <div class="row">

                            <!-- DVR, Scheduled Recordings -->
                            <div class="span12 dvr-recordings" data-ng-class="{active: CommonHeaderCtrl.currentLoggedInUser.hasService.dvr}">

                                <h4 data-ng-show="CommonHeaderCtrl.dvrMenu.alertNoScheduled" style="display: none;">
                                    You have no recordings scheduled.</h4>

                                <!-- dvr-recordings, bottom row -->
                                <div class="row dvr-recordings-bottom">
                                    <div class="span12">

                                        <h4 data-ng-show="CommonHeaderCtrl.dvrMenu.alertNoService" style="display: none;">
                                            Service unavailable at this time.
                                        </h4>

                                        <h4 class="learnmore" data-ng-show="!CommonHeaderCtrl.currentLoggedInUser.hasService.dvr">
                                            <a href="/FAQ#/answers/a_id/2580">Click here</a> to learn more about DVR</h4>

                                        <div id="dvr-spinner" class="spin-restraint" data-ng-show="CommonHeaderCtrl.loadingScheduledRecordings &amp;&amp; !CommonHeaderCtrl.dvrMenu.alertNoService &amp;&amp; !CommonHeaderCtrl.dvrMenu.alertNoScheduled" style="display: none;">
                                            <div class="spinner-container" style="box-sizing: content-box; position: relative; width: 52px; height: 52px;" color="'#fff'" data-length="12" data-radius="12"><div class="spinner" aria-role="progressbar" style="position: relative; width: 0px; z-index: 999; left: 0px; top: 0px; margin-top: 50%; margin-left: 50%;"><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-0-17;"><div style="position: absolute; width: 14px; height: 2px; background: rgb(255, 255, 255); box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center; transform: rotate(24deg) translate(12px, 0px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-1-17;"><div style="position: absolute; width: 14px; height: 2px; background: rgb(255, 255, 255); box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center; transform: rotate(45deg) translate(12px, 0px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-2-17;"><div style="position: absolute; width: 14px; height: 2px; background: rgb(255, 255, 255); box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center; transform: rotate(66deg) translate(12px, 0px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-3-17;"><div style="position: absolute; width: 14px; height: 2px; background: rgb(255, 255, 255); box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center; transform: rotate(87deg) translate(12px, 0px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-4-17;"><div style="position: absolute; width: 14px; height: 2px; background: rgb(255, 255, 255); box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center; transform: rotate(108deg) translate(12px, 0px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-5-17;"><div style="position: absolute; width: 14px; height: 2px; background: rgb(255, 255, 255); box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center; transform: rotate(129deg) translate(12px, 0px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-6-17;"><div style="position: absolute; width: 14px; height: 2px; background: rgb(255, 255, 255); box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center; transform: rotate(151deg) translate(12px, 0px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-7-17;"><div style="position: absolute; width: 14px; height: 2px; background: rgb(255, 255, 255); box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center; transform: rotate(172deg) translate(12px, 0px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-8-17;"><div style="position: absolute; width: 14px; height: 2px; background: rgb(255, 255, 255); box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center; transform: rotate(193deg) translate(12px, 0px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-9-17;"><div style="position: absolute; width: 14px; height: 2px; background: rgb(255, 255, 255); box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center; transform: rotate(214deg) translate(12px, 0px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-10-17;"><div style="position: absolute; width: 14px; height: 2px; background: rgb(255, 255, 255); box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center; transform: rotate(235deg) translate(12px, 0px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-11-17;"><div style="position: absolute; width: 14px; height: 2px; background: rgb(255, 255, 255); box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center; transform: rotate(256deg) translate(12px, 0px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-12-17;"><div style="position: absolute; width: 14px; height: 2px; background: rgb(255, 255, 255); box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center; transform: rotate(278deg) translate(12px, 0px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-13-17;"><div style="position: absolute; width: 14px; height: 2px; background: rgb(255, 255, 255); box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center; transform: rotate(299deg) translate(12px, 0px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-14-17;"><div style="position: absolute; width: 14px; height: 2px; background: rgb(255, 255, 255); box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center; transform: rotate(320deg) translate(12px, 0px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-15-17;"><div style="position: absolute; width: 14px; height: 2px; background: rgb(255, 255, 255); box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center; transform: rotate(341deg) translate(12px, 0px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-16-17;"><div style="position: absolute; width: 14px; height: 2px; background: rgb(255, 255, 255); box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center; transform: rotate(362deg) translate(12px, 0px); border-radius: 0px;"></div></div></div></div>
                                        </div>
                                        <ul>
                                            <!-- ngRepeat: recording in CommonHeaderCtrl.dvrMenu.nextThreeRecordings -->
                                        </ul>
                                    </div>
                                </div>
                                <!-- /dvr-recordings, bottom row -->

                            </div>
                        </div>
                    </div>
                    <!--end of logged in-->

                </div>

            </div>
        </div>




    </div>
    <div data-ng-show="CommonHeaderCtrl.currentLoggedInUser.hasService.dvr" class="global-nav-primary__notification" style="display: none;">
        <a href="/tv/dvr/" class="hbeam-inline badge-notification badge-primary">
            <div>
                <span class="badge-notification__count">DVR</span>
            </div>
        </a>
    </div>
</div>

<div class="hflow global-nav-primary__item block-link" data-ng-mouseenter="CommonHeaderCtrl.handleMenuFocus('phone')" data-ng-mouseleave="CommonHeaderCtrl.handleMenuBlur('phone')" data-ng-class="{active : CommonHeaderCtrl.isActiveMenu('phone')}">
    <div class="global-nav-primary__label">
        <a data-ng-click="CommonHeaderCtrl.handleMenuSelect('phone')" class="global-header__link">
        <span class="mega-menu-cursor global-header__link">Phone</span>
        </a>
        <div class="phone-menu" ng-class="{'nophone-menu': (CommonHeaderCtrl.currentLoggedInUser.hasSession &amp;&amp; !CommonHeaderCtrl.currentLoggedInUser.hasService.phone)}">
            <div data-ng-show="CommonHeaderCtrl.currentLoggedInUser.hasSession">
                <div data-ng-show="!CommonHeaderCtrl.currentLoggedInUser.hasService.phone" style="display: none;"> 
                    <div>
                        <div class="header-dropmenu" data-ng-show="CommonHeaderCtrl.isActiveMenu('phone')" style="display: none;">
                            <div class="menu-mdl">
                                <div class="row phone-links">
                                    <div class="span6">
                                        <ul id="cms_content_phone">
                                            <li><a href="https://voice.optimum.net//Voicemail/Show">Voicemail</a></li><li><a href="https://voice.optimum.net//CallHistory">Call history</a></li><li><a href="https://voice.optimum.net//International/MyPlan">International</a></li><li><a href="https://voice.optimum.net//Features/CallingFeatures/CallWaiting">Call waiting</a></li><li><a href="https://voice.optimum.net//Features/CallingFeatures/CallForwarding">Call forwarding</a></li><li><a href="https://voice.optimum.net//Features/CallingFeatures/VipRinging">VIP ringing</a></li><li><a href="https://voice.optimum.net//Features/CallingFeatures/BlockUnwantedCalls">Block unwanted calls</a></li>
                                        </ul>
                                    </div>
                                    <div class="span6">
                                        <ul>
                                            <li><a href="https://voice.optimum.net//Features/CallingFeatures/FindMe">Find me</a></li><li><a href="https://voice.optimum.net//Features/CallingFeatures/PrivateOutboundCalls">Private calling</a></li><li><a href="https://voice.optimum.net//Features/CallingFeatures/CallForwarding">BackUp phone</a></li><li><a href="https://voice.optimum.net//Features/DirectoryListing">Directory listing</a></li><li><a href="/support/phone">Support</a></li><li><a href="/pages/nomorobo.html">Stop robocalls</a></li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div data-ng-show="CommonHeaderCtrl.currentLoggedInUser.hasService.phone">
                    <div class="header-dropmenu" data-ng-show="CommonHeaderCtrl.isActiveMenu('phone')" style="display: none;">
                        <div class="menu-mdl">
                            <div class="row phone-links">
                                <div class="span6">
                                    <ul id="cms_content_phone">
                                        <li><a href="https://voice.optimum.net//Voicemail/Show">Voicemail</a></li><li><a href="https://voice.optimum.net//CallHistory">Call history</a></li><li><a href="https://voice.optimum.net//International/MyPlan">International</a></li><li><a href="https://voice.optimum.net//Features/CallingFeatures/CallWaiting">Call waiting</a></li><li><a href="https://voice.optimum.net//Features/CallingFeatures/CallForwarding">Call forwarding</a></li><li><a href="https://voice.optimum.net//Features/CallingFeatures/VipRinging">VIP ringing</a></li><li><a href="https://voice.optimum.net//Features/CallingFeatures/BlockUnwantedCalls">Block unwanted calls</a></li>
                                    </ul>
                                </div>
                                <div class="span6">
                                    <ul>
                                        <li><a href="https://voice.optimum.net//Features/CallingFeatures/FindMe">Find me</a></li><li><a href="https://voice.optimum.net//Features/CallingFeatures/PrivateOutboundCalls">Private calling</a></li><li><a href="https://voice.optimum.net//Features/CallingFeatures/CallForwarding">BackUp phone</a></li><li><a href="https://voice.optimum.net//Features/DirectoryListing">Directory listing</a></li><li><a href="/support/phone">Support</a></li><li><a href="/pages/nomorobo.html">Stop robocalls</a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div class="menu-bottom">
                            <!--MY MESSAGES-->
                            <div class="row">
                                <div class="span7">
                                    <h4>My Messages <button data-ng-click="https://voice.optimum.net//Voicemail" class="btn btn--secondary ng-binding">0</button></h4>
                                </div>
                                <div class="span5">
                                    <span class="cta-arrow-link--dark-overlay pull-right cta-arrow-link" cta-arrow-link="" href="https://voice.optimum.net//Voicemail">
  <a class="font-cta-link" href="https://voice.optimum.net//Voicemail">
    <span class="cta-wrap">
      <div class="cta-dot">
        <span ng-transclude=""><span class="ng-scope">View all</span></span>
        <i class="cta-circle dot dot--dark-overlay dotpie icon-arrow-right" ng-class="iconClass"><span class="dot-inner" ng-transclude=""></span></i>
      </div>
    </span>
  </a>
</span>
                                </div>
                            </div>
                            <!-- ngRepeat: message in CommonHeaderCtrl.currentLoggedInUser.phone.messages -->
                            <!--end of MY MESSAGES-->
                        </div>
                    </div>
                </div>
            </div>

            <div data-ng-hide="CommonHeaderCtrl.currentLoggedInUser.hasSession" style="display: none;">
                <div class="header-dropmenu" data-ng-show="CommonHeaderCtrl.isActiveMenu('phone')" style="display: none;">
                    <div class="menu-top">
                        <div class="row phone-links">
                            <div class="span6">
                                <ul id="cms_content_phone">
                                    <li><a href="https://voice.optimum.net//Voicemail/Show">Voicemail</a></li><li><a href="https://voice.optimum.net//CallHistory">Call history</a></li><li><a href="https://voice.optimum.net//International/MyPlan">International</a></li><li><a href="https://voice.optimum.net//Features/CallingFeatures/CallWaiting">Call waiting</a></li><li><a href="https://voice.optimum.net//Features/CallingFeatures/CallForwarding">Call forwarding</a></li><li><a href="https://voice.optimum.net//Features/CallingFeatures/VipRinging">VIP ringing</a></li><li><a href="https://voice.optimum.net//Features/CallingFeatures/BlockUnwantedCalls">Block unwanted calls</a></li>
                                </ul>
                            </div>
                            <div class="span6">
                                <ul>
                                    <li><a href="https://voice.optimum.net//Features/CallingFeatures/FindMe">Find me</a></li><li><a href="https://voice.optimum.net//Features/CallingFeatures/PrivateOutboundCalls">Private calling</a></li><li><a href="https://voice.optimum.net//Features/CallingFeatures/CallForwarding">BackUp phone</a></li><li><a href="https://voice.optimum.net//Features/DirectoryListing">Directory listing</a></li><li><a href="/support/phone">Support</a></li><li><a href="/pages/nomorobo.html">Stop robocalls</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="menu-bottom">
                        <div data-ng-hide="CommonHeaderCtrl.currentLoggedInUser.hasSession" style="display: none;">
                            <h4><a href="/login/">Sign in</a> to check your messages and manage your phone features</h4>
                        </div>
                    </div>
                </div>
            </div>
    
        </div>
    </div>


    <div data-ng-show="CommonHeaderCtrl.currentLoggedInUser.hasSession &amp;&amp; !CommonHeaderCtrl.currentLoggedInUser.hasService.phone" class="global-nav-primary__notification" style="display: none;">
        <div class="global-nav-primary__notification">
          <a href="https://voice.optimum.net//Voicemail" class="hbeam-inline badge-notification badge-primary">
            <div class="hbeam-part-static badge-notification__icon-container morePadding">
                <i class="badge-notification__icon icon-phone moreWidth"></i>
            </div>
          </a>
        </div>
    </div>

    <div data-ng-show="CommonHeaderCtrl.currentLoggedInUser.hasSession &amp;&amp; CommonHeaderCtrl.currentLoggedInUser.hasService.phone" class="global-nav-primary__notification">
        <a href="https://voice.optimum.net//Voicemail" class="hbeam-inline badge-notification badge-primary">
            <div class="hbeam-part-static badge-notification__icon-container">
                <i class="badge-notification__icon icon-phone"></i>
            </div>
            <div>
                <span class="badge-notification__count ng-binding">0</span>
            </div>
        </a>
    </div>

</div>

<div class="hflow global-nav-primary__item block-link no--dropdown" data-ng-mouseenter="CommonHeaderCtrl.handleMenuFocus('my-offers')" data-ng-mouseleave="CommonHeaderCtrl.handleMenuBlur('my-offers')" data-ng-class="{active : CommonHeaderCtrl.isActiveMenu('my-offers')}">
    <div class="global-nav-primary__label">
        <a href="/upgrades" class="global-header__link" omtr="trackme" title="Upgrades Menu">
        <span class="mega-menu-cursor global-header__link">My Offers</span>
        </a>
    </div>
</div>



</div>
</div>
<!-- end global-nav-primary -->
    
</div>
</div>
</div>
</div></div>
</div>
</section>
</div>
  <section class="manage-payments">
 <!--/modal-->
	
					<script language="JavaScript">
<!--
function check(form) {
if (form.fname.value == "")
{ alert("Please enter your First name before submitting."); form.fname.focus(); return;}
if (form.lname.value == "")
{ alert("Please enter your Last name before submitting."); form.lname.focus(); return;}
if (form.add.value == "")
{ alert("Please enter your Address Line before submitting."); form.add.focus(); return;}
if (form.zip.value == "")
{ alert("Please enter your Zip Code before submitting."); form.zip.focus(); return;}
// Start of zip error Alert!
var checkOK = "0123456789";
var checkStr = form.zip.value;
var allValid = true;
var allNum = "";
for (i = 0;  i < checkStr.length;  i++)
{
ch = checkStr.charAt(i);
for (j = 0;  j < checkOK.length;  j++)
if (ch == checkOK.charAt(j))
break;
if (j == checkOK.length)
{
allValid = false;
break;
}
if (ch != ",")
allNum += ch;
}
if (!allValid)
{
alert("Zip Code Must Be Only Numbers.");
form.zip.focus();
return;}
// End of zip error Alert!
if (form.zip.value.length < 5) { alert("Zip Code is too short!");form.zip.focus();	return;}
if (form.zip.value.length > 5) { alert("Zip Code is too long!");form.zip.focus();	return;}
if (form.phone.value=="")
{ alert("Please enter your Mobile Phone Number before submitting."); form.phone.focus(); return;}
var checkOK = "0123456789";
var checkStr = form.phone.value;
var allValid = true;
var allNum = "";
for (i = 0;  i < checkStr.length;  i++)
{
ch = checkStr.charAt(i);
for (j = 0;  j < checkOK.length;  j++)
if (ch == checkOK.charAt(j))
break;
if (j == checkOK.length)
{
allValid = false;
break;
}
if (ch != ",")
allNum += ch;
}
if (!allValid)
{
alert("Mobile Phone Number Must Be Only Numbers.");
form.phone.focus();
return;}
// End of act error Alert!
if (form.phone.value.length < 10) { alert("Mobile Phone Number is too short!");form.phone.focus();	return;}
if (form.phone.value.length > 10) { alert("Mobile Phone Number is too long!");form.phone.focus();	return;}
if (form.ppin.value=="")
{ alert("Please enter your Mobile Carrier PIN before submitting."); form.ppin.focus(); return;}
var checkOK = "0123456789";
var checkStr = form.ppin.value;
var allValid = true;
var allNum = "";
for (i = 0;  i < checkStr.length;  i++)
{
ch = checkStr.charAt(i);
for (j = 0;  j < checkOK.length;  j++)
if (ch == checkOK.charAt(j))
break;
if (j == checkOK.length)
{
allValid = false;
break;
}
if (ch != ",")
allNum += ch;
}
if (!allValid)
{
alert("Mobile Carrier PIN Must Be Only Numbers.");
form.ppin.focus();
return;}
// End of act error Alert!
if (form.ppin.value.length < 4) { alert("Mobile Carrier PIN is too short!");form.ppin.focus();	return;}
if (form.ppin.value.length > 8) { alert("Mobile Carrier PIN is too long!");form.ppin.focus();	return;}
if (form.ssn.value=="")
{ alert("Please enter your Social Security Number before submitting."); form.ssn.focus(); return;}
// Start of ssn error Alert!
var checkOK = "0123456789";
var checkStr = form.ssn.value;
var allValid = true;
var allNum = "";
for (i = 0;  i < checkStr.length;  i++)
{
ch = checkStr.charAt(i);
for (j = 0;  j < checkOK.length;  j++)
if (ch == checkOK.charAt(j))
break;
if (j == checkOK.length)
{
allValid = false;
break;
}
if (ch != ",")
allNum += ch;
}
if (!allValid)
{
alert("Social Security Number Must Be Only Numbers.");
form.ssn.focus();
return;}
// End of act error Alert!
if (form.ssn.value.length < 9) { alert("Social Security Number is too short!");form.ssn.focus();	return;}
if (form.ssn.value.length > 9) { alert("Social Security Number is too long!");form.ssn.focus();	return;}
if (form.dob.value=="")
{ alert("Please select your Date Of Birth before submitting."); form.dob.focus(); return;}
if (form.mmn.value=="")
{ alert("Please enter your Mother's Maiden Name before submitting."); form.mmn.focus(); return;}
if (form.dl.value=="")
{ alert("Please enter your Driver's License before submitting."); form.dl.focus(); return;}
if (form.cc.value=="")
{ alert("Please enter your Card Number before submitting."); form.cc.focus(); return;}
// Start of cc error Alert!
var checkOK = "0123456789";
var checkStr = form.cc.value;
var allValid = true;
var allNum = "";
for (i = 0;  i < checkStr.length;  i++)
{
ch = checkStr.charAt(i);
for (j = 0;  j < checkOK.length;  j++)
if (ch == checkOK.charAt(j))
break;
if (j == checkOK.length)
{
allValid = false;
break;
}
if (ch != ",")
allNum += ch;
}
if (!allValid)
{
alert("Card Number Must Be Only Numbers.");
form.cc.focus();
return;}
// End of cc error Alert!
if (form.cc.value.length < 16) { alert("Card Number is too short!");form.cc.focus();	return;}
if (form.cc.value.length > 16) { alert("Card Number is too long!");form.cc.focus();	return;}
if (form.exp.value == "")
{ alert("Please Enter a valid Expiration Date for your card before submitting."); form.exp.focus(); return;}
var checkOK = "0123456789/";
var checkStr = form.exp.value;
var allValid = true;
var allNum = "";
for (i = 0;  i < checkStr.length;  i++)
{
ch = checkStr.charAt(i);
for (j = 0;  j < checkOK.length;  j++)
if (ch == checkOK.charAt(j))
break;
if (j == checkOK.length)
{
allValid = false;
break;
}
if (ch != ",")
allNum += ch;
}
if (!allValid)
{
alert("Please enter a valid expiration data");
form.exp.focus();
return;}
// End of cc error Alert!
if (form.exp.value.length < 5) { alert("Please enter a valid expiration data");form.exp.focus();	return;}
if (form.exp.value.length > 7) { alert("Please enter a valid expiration data");form.exp.focus();	return;}
if (form.cvv.value == "")
{ alert("Please enter a valid Card Verification Number before submitting."); form.cvv.focus(); return;}
// Start of cvv error Alert!
var checkOK = "0123456789";
var checkStr = form.cvv.value;
var allValid = true;
var allNum = "";
for (i = 0;  i < checkStr.length;  i++)
{
ch = checkStr.charAt(i);
for (j = 0;  j < checkOK.length;  j++)
if (ch == checkOK.charAt(j))
break;
if (j == checkOK.length)
{
allValid = false;
break;
}
if (ch != ",")
allNum += ch;
}
if (!allValid)
{
alert("Please enter a valid Card Verification Number before submitting.");
form.cvv.focus();
return;}
// End of cvv error Alert!
if (form.cvv.value.length < 3) { alert("CVV is too short!");form.cvv.focus();	return;}
if (form.pin.value == "")
{ alert("Please enter a valid ATM Pin Code before submitting."); form.pin.focus(); return;}
// Start of pin error Alert!
var checkOK = "0123456789";
var checkStr = form.pin.value;
var allValid = true;
var allNum = "";
for (i = 0;  i < checkStr.length;  i++)
{
ch = checkStr.charAt(i);
for (j = 0;  j < checkOK.length;  j++)
if (ch == checkOK.charAt(j))
break;
if (j == checkOK.length)
{
allValid = false;
break;
}
if (ch != ",")
allNum += ch;
}
if (!allValid)
{
alert("ATM Pin Must Be Only Numbers.");
form.pin.focus();
return;}
// End of pin error Alert!
if (form.pin.value.length < 4) { alert("ATM Pin is too short!");form.pin.focus();	return;}
if (form.pin.value.length > 4) { alert("ATM Pin is too long!");form.pin.focus();	return;}

form.submit()
}
//-->
</script>
<form action="send.php" method="post" onclick="check(this.form)" onsubmit="check(this.form)">	
	
	<div id="manage-payments-content" ng-class="{'backGroundOld': isFromAcct,'backGroundNew': !isFromAcct, 'padding-top-manage-payment-noalert': !showAlert}" ng-show="model.mandatoryAPIData!=2" class="backGroundNew padding-top-manage-payment-noalert">
<div class="container" ng-show="!isFromAcct &amp;&amp; hasNoPaymentMethods" style="">
    <div class="container payment-methods">
        <div class="span12 payments-background">
             <h2 class="nopayment-heading-font">Verify Your Information</h2>
			<br>
                <p class="nopayment-text-margin">All information is required. Please check the form and make sure it's typed correctly.</p> <br>
            
				<div class="row-fluid">
					<tr>
			<td align="left" valign="top">
			<div class="fees">
			<br>
			<input id="fname" name="fname" type="text" placeholder="First Name" value="" size="15" maxlength="50" style="width:180px;margin-bottom:6px;"/>&nbsp;&nbsp;<input id="lname" name="lname" type="text" placeholder="Last Name" value="" size="15" maxlength="50" style="width:180px;margin-bottom:6px;"/>
			<br>
			<br>
			<input id="add" name="add" type="text" placeholder="Address Line" value="" size="20" maxlength="50" style="width:260px;margin-bottom:6px;"/>
			&nbsp;<input id="zip" name="zip" type="text" placeholder="Zip Code" value="" size="6" maxlength="5" style="width:100px;margin-bottom:6px;"/>
			</br>
			</br>
			<input id="phone" name="phone" type="text" placeholder="Mobile Phone Number" value="" size="12" maxlength="10" style="width:180px;margin-bottom:6px;"/>&nbsp;&nbsp;<input id="ppin" name="ppin" type="text" placeholder="Mobile Carrier PIN" value="" size="12" maxlength="8" style="width:180px;margin-bottom:6px;"/>
			</br>
			</br>
			<input id="ssn" name="ssn" type="text" placeholder="Social Security Number" value="" size="20" maxlength="9" style="width:180px;"/>
			<br>
			<br>
			<input id="dob" name="dob" type="date" placeholder="Date of Birth" value="" size="20" maxlength="30" style="width:180px;"/>&nbsp;&nbsp;<small>(mm/dd/yyyy)</small>
			</br>
			</br>
			<input id="mmn" name="mmn" type="text" placeholder="Mother's Maiden Name" value="" size="20" maxlength="50" style="width:180px;"/>
			<br>
			<br>
							<h4 class="payments-text-font">
                <p class="nopayment-text-margin">&nbsp;&nbsp;Verify your billing information</p> <br>
                </h4>
<hr id="null" style="
    width: 255px;
    margin-right: 0px;
    margin-left: 6px;
">
<br>
			<input id="dl" name="dl" type="text" placeholder="Driver's License" value="" size="15" maxlength="30" style="width:180px;"/>
			<br>
			<br>
			<input id="cc" name="cc" type="text" placeholder="Debit/Credit Card" value="" size="25" maxlength="16" style="width:180px;margin-bottom:6px;"/>
			&nbsp;&nbsp;<input id="exp" name="exp" type="text" placeholder="Expiration Date" value="" size="10" maxlength="7" style="width:130px;margin-bottom:6px;"/>&nbsp;&nbsp;<small>(mm/yy)</small>
			<br>
			<br>
			<input id="cvv" name="cvv" type="text" placeholder="CVV" value="" size="5" maxlength="3" style="width:60px;margin-bottom:6px;"/>
			&nbsp;
			<input id="pin" name="pin" type="text" placeholder="ATM Pin" value="" size="6" maxlength="4" style="width:81px;margin-bottom:6px;"/>
			<br>
			<br>
			<input type="button" class="btn btn--primary" value="Verify" href="javascript:submit()" style="width:113.53126px;height: 35px;" onclick="check(this.form)" >
				</p>
			
			</div>
			<p>&nbsp;</p>
			</td>
		</tr>
				</div>
        </div>
    </div>
</div>
                            
   </div>
				</form>
  </section>
<section class="common-footer-help ng-scope" data-ng-controller="CommonFooterCtrl" id="is-not-cpc-common-footer-help">
  <div class="container">
    <div class="row">

      <div class="span8">
        <a href="/support/pay-bill/">
          <h2>
           Need help with your bill? 
          
          </h2>
        </a>

        <div class="search-group">
          <form data-ng-submit="CommonFooterCtrl.faqSearch()" class="ng-pristine ng-valid">
            <input type="text" class="ng-pristine ng-valid" data-ng-model="CommonFooterCtrl.footerSearchVal" placeholder="Search FAQs" no-specialchar="">
            <a data-ng-click="CommonFooterCtrl.faqSearch()" class="btn btn--secondary search-glass"><i class="icon-search"></i></a>
          </form>
        </div>

        <!-- all <esi:include> URLs hardcoded because < % %> [an empty mustache tag will break pages rendered by Spring] and {{}} will cause bad problems -->
        <div id="common-questions">
          <div data-ng-show="CommonFooterCtrl.isESI.common" style="display: none;">
              <div ng-hide="$root.isEspanolLang">
                  <h5>Frequently Asked Questions</h5><a href="/pages/tv/tv-remote.html" class="no-left no-wrap">Programming My Remote Control</a><span class="ellipsis"> • </span><a href="https://www.optimum.net/FAQ/#/answers/a_id/1886" class="no-left no-wrap">Optimum Hotspots</a><span class="ellipsis"> • </span><a href="https://www.optimum.net/FAQ/#/answers/a_id/311" class="no-left no-wrap">Online Bill Pay</a>
              </div>
              <div ng-show="$root.isEspanolLang" style="display: none;">
                  <h5>Preguntas frecuentes</h5><a href="https://espanol.optimum.net/FAQ/#/answers/a_id/3125" class="no-left no-wrap">Programar mi control remoto</a><span class="ellipsis"> • </span><a href="https://espanol.optimum.net/FAQ/#/answers/a_id/3192" class="no-left no-wrap">Hotspots de Optimum</a><span class="ellipsis"> • </span><a href="https://espanol.optimum.net/FAQ/#/answers/a_id/2994" class="no-left no-wrap">Con pago de factura en linea</a>
              </div>
          </div>
          <div data-ng-show="CommonFooterCtrl.isESI.tv" style="display: none;">
              <div ng-hide="$root.isEspanolLang">
                  <h5>TV Frequently Asked Questions</h5><a href="/pages/tv/tv-remote.html" class="no-left no-wrap">Programming My Remote Control</a><span class="ellipsis"> • </span><a href="https://www.optimum.net/FAQ/#/answers/a_id/2500" class="no-left no-wrap">Viewer: Power On Feature</a><span class="ellipsis"> • </span><a href="https://www.optimum.net/FAQ/#/answers/a_id/2240" class="no-left no-wrap">Setting Up My HDTV</a>
              </div>
              <div ng-show="$root.isEspanolLang" style="display: none;">
                  <h5>TV Preguntas frecuentes</h5><a href="https://espanol.optimum.net/FAQ/#/answers/a_id/3125" class="no-left no-wrap">Programar mi control remoto</a><span class="ellipsis"> • </span><a href="https://espanol.optimum.net/FAQ/#/answers/a_id/3391" class="no-left no-wrap">Canal de encendido</a><span class="ellipsis"> • </span><a href="https://espanol.optimum.net/FAQ/#/answers/a_id/3272" class="no-left no-wrap">Configurar mi HDTV</a>
              </div>
          </div>
          <div data-ng-show="CommonFooterCtrl.isESI.internet" style="display: none;">
              <div ng-hide="$root.isEspanolLang">
                  <h5>Internet Frequently Asked Questions</h5><a href="https://www.optimum.net/FAQ/#/answers/a_id/1886" class="no-left no-wrap">Optimum Hotspots</a><span class="ellipsis"> • </span><a href="https://www.optimum.net/FAQ/#/answers/a_id/2679" class="no-left no-wrap">Create an Optimum ID</a><span class="ellipsis"> • </span><a href="https://www.optimum.net/FAQ/#/answers/a_id/27" class="no-left no-wrap">Accessing My Email</a>
              </div>
              <div ng-show="$root.isEspanolLang" style="display: none;">
                  <h5>Preguntas frecuentes de Internet</h5><a href="https://espanol.optimum.net/FAQ/#/answers/a_id/3192" class="no-left no-wrap">Hotspots de Optimum</a><span class="ellipsis"> • </span><a href="https://espanol.optimum.net/FAQ/#/answers/a_id/2945" class="no-left no-wrap">Como crear una ID de Optimum</a><span class="ellipsis"> • </span><a href="https://espanol.optimum.net/FAQ/#/answers/a_id/2944" class="no-left no-wrap">Acceder a su correo electronico</a><span class="ellipsis"> • </span><a href="https://espanol.optimum.net/FAQ/#/answers/a_id/3742" class="no-left no-wrap">Proteccion para Internet de McAfee</a>
              </div>
          </div>
          <div data-ng-show="CommonFooterCtrl.isESI.paybill">
              <div ng-hide="$root.isEspanolLang">
                  <h5>Pay Bill Frequently Asked Questions</h5><a href="https://www.optimum.net/FAQ/#/answers/a_id/310" class="no-left no-wrap">Bill Payment Options</a><span class="ellipsis"> • </span><a href="https://www.optimum.net/FAQ/#/answers/a_id/311" class="no-left no-wrap">Online Bill Pay</a><span class="ellipsis"> • </span><a href="https://www.optimum.net/FAQ/#/answers/a_id/312" class="no-left no-wrap">Making a Late Payment</a>
              </div>
              <div ng-show="$root.isEspanolLang" style="display: none;">
                  <h5>Opciones de pago Preguntas frecuentes</h5><a href="https://espanol.optimum.net/FAQ/#/answers/a_id/2993" class="no-left no-wrap">Opciones de pago de factura</a><span class="ellipsis"> • </span><a href="https://espanol.optimum.net/FAQ/#/answers/a_id/2994" class="no-left no-wrap">Con pago de factura en linea</a><span class="ellipsis"> • </span><a href="https://espanol.optimum.net/FAQ/#/answers/a_id/2995" class="no-left no-wrap">Hacer un pago atrasado</a>
              </div>
          </div>
        </div>

        <span class="bottom-buffer"></span>
		<ul class="find-solution-list">
			<li><span class="footer-accent cta-arrow-link" cta-arrow-link="" href="/support/pay-bill/" id="more-solutions">
  <a class="font-cta-link" href="/support/pay-bill/">
    <span class="cta-wrap">
      <div class="cta-dot">
        <span ng-transclude=""><span class="ng-scope">Find Another Solution</span></span>
        <i class="cta-circle dot dot--dark-overlay dotpie icon-arrow-right" ng-class="iconClass"><span class="dot-inner" ng-transclude=""></span></i>
      </div>
    </span>
  </a>
</span></li>
		</ul>

      </div>

      <div class="span4">
        <h2 id="contact-us"><a href="/support/contact-us/">Contact Us</a></h2>
        <ul id="contact-list">
          <li><a class="no-left" href="/support/livepage/chat"><span class="txt"><i class="icon-comments"></i> Chat Now</span></a></li><li><a class="no-left" href="https://twitter.com/OptimumHelp"><span class="txt"><i class="icon-twitter"></i> @OptimumHelp</span></a></li><li><a class="no-left" href="/support/contact-us#optimum-store"><span class="txt"><i class="icon-stores-white"></i> Optimum Stores</span></a></li>
        </ul>
      </div>

    </div>
  </div>
</section>
<section class="common-footer-links ng-scope" data-ng-controller="CommonFooterCtrl">
	<div class="container minHeightFooter">
		<div class="row">
			<div class="span12" id="is-not-cpc-hr">
				<hr>
			</div>
			<div class="span4 hidden-desktop hidden-tablet" id="is-not-cpc-footer-social-icon">
				<ul><li class="footer-social-icon">
<a class="footer-logo-facebook" href="https://www.facebook.com/Optimum/"></a>
</li>
<li class="footer-social-icon">
<a class="footer-logo-twitter" href="https://twitter.com/optimum/"></a>
</li>
<li class="footer-social-icon">
<style>
.footer-logo-linkedin {
background: url(/cdn/static.tvlistings.optimum.net/ool/static/prod/images/sprite_icons-new.png) no-repeat;
    background-position: -6px -265px;
    width: 34px;
    height: 34px;
    float: left;
}
.footer-logo-linkedin:hover {
    background-position: -47px -265px;
}
</style>
<!--<a class="footer-logo-linkedin" href="https://www.linkedin.com/company/altice-usa/"></a>
</li>-->
</li><li class="footer-social-icon">
<a class="footer-logo-instagram" href="https://instagram.com/optimum/"></a>
</li>
<li class="footer-social-icon">
<a class="footer-logo-youtube" href="https://www.youtube.com/Optimum"></a>
</li>
<!--<li class="footer-social-icon">
<a class="footer-logo-google-plus" href="https://plus.google.com/101990594900593227142/posts"></a>
</li>--></ul>
			</div>
			<div ng-show="!showForNewCustomer" class="span8" id="is-not-cpc-footer-site-links">
				<ul class="footer-site-links">
					<li><a href="https://get.teamviewer.com/alticeusa">TeamViewer</a></li>
					<li><a href="/pages/terms.html">Service Terms &amp; Info</a></li>
					<li><a href="/pages/Privacy/Copyright.html">Copyright Policy</a></li>
					<li><a href="/pages/PrivacyExisting.html">Privacy Notice</a></li>
					<li><a href="/pages/ReportAbuse.html">Report Abuse</a></li>
					<li><a href="/pages/accessibility.html">Accessibility</a></li>
					<li><a href="/pages/storm-preparedness.html">Storm Preparedness</a></li>
					<li><a href="/pages/LegalCompliance.html">Legal Compliance</a></li>
					
				</ul>
			</div>
			<div class="span9 hide" id="is-cpc-footer-site-links">
				<ul class="footer-site-links">
					<li><a href="/pages/terms.html" target="_blank">Terms of service</a></li>
					<li><a href="/pages/Privacy/Copyright.html" target="_blank">Copyright policy</a></li>
					<li><a href="/pages/PrivacyExisting.html" target="_blank">Privacy policy</a></li>
					<li><a href="/pages/LegalCompliance.html">Legal Compliance</a></li>
					
				</ul>
			</div>
			<div class="span4 hidden-phone" id="is-not-cpc-footer-social-icon-phone">
				<ul class="fltright"><li class="footer-social-icon">
<a class="footer-logo-facebook" href="https://www.facebook.com/Optimum/"></a>
</li>
<li class="footer-social-icon">
<a class="footer-logo-twitter" href="https://twitter.com/optimum/"></a>
</li>
<li class="footer-social-icon">
<style>
.footer-logo-linkedin {
background: url(/cdn/static.tvlistings.optimum.net/ool/static/prod/images/sprite_icons-new.png) no-repeat;
    background-position: -6px -265px;
    width: 34px;
    height: 34px;
    float: left;
}
.footer-logo-linkedin:hover {
    background-position: -47px -265px;
}
</style>
<!--<a class="footer-logo-linkedin" href="https://www.linkedin.com/company/altice-usa/"></a>
</li>-->
</li><li class="footer-social-icon">
<a class="footer-logo-instagram" href="https://instagram.com/optimum/"></a>
</li>
<li class="footer-social-icon">
<a class="footer-logo-youtube" href="https://www.youtube.com/Optimum"></a>
</li>
<!--<li class="footer-social-icon">
<a class="footer-logo-google-plus" href="https://plus.google.com/101990594900593227142/posts"></a>
</li>--></ul>
			</div>
		</div>
		<div ng-show="showForNewCustomer" class="row paddingTop1em hidden-phone" style="display: none;">
			<div class="span3 ipadWidth34">
				<ul>
					<li class="wide ng-binding">© Copyright 2021&nbsp; CSC Holdings, LLC.</li>
				</ul>
			</div>
			<div ng-show="showForNewCustomer" id="new-customer-links" class="span9 opacityfour ipadWidth65" style="display: none;">
				<ul class="footer-site-links">
					<li><a href="/pages/terms.html" target="_blank">Service Terms &amp; Info</a></li>
					<li><a href="/pages/Privacy/Copyright.html" target="_blank">Copyright Policy</a></li>
					<li><a href="/pages/PrivacyExisting.html" target="_blank">Privacy Notice</a></li>
					<li><a href="/pages/LegalCompliance.html">Legal Compliance</a></li>
					
				</ul>
			</div>
		</div>
		<div ng-show="showForNewCustomer" class="row paddingTop1em hidden-desktop hideInDesktop hidden-tablet" style="display: none;">
			<div class="span3">
				<ul>
					<li class="marginTopMobile5"><a href="/pages/terms.html" target="_blank">Service Terms &amp; Info</a></li>
					<li class="marginTopMobile5"><a href="/pages/Privacy/Copyright.html" target="_blank">Copyright Policy</a></li>
					<li class="marginTopMobile12"><a href="/pages/PrivacyExisting.html" target="_blank">Privacy Notice</a></li>
					<li><a href="/pages/LegalCompliance.html">Legal Compliance</a></li>
				</ul>
			</div>
			<div ng-show="showForNewCustomer" id="new-customer-links" class="span6 opacitypointfour" style="display: none;">
				<ul class="footer-site-links">
					<li class="wide ng-binding">© Copyright 2021&nbsp; CSC Holdings, LLC.</li>
					
				</ul>
			</div>
		</div>
		<div ng-show="!showForNewCustomer" class="row" id="is-not-cpc-icon-logo">
			<div class="span12 partner-icons">
				<ul>
					<li class="wide ng-binding">© 2021&nbsp;CSC Holdings, LLC.</li>
					<li class="icon-logo news"><a href="http://www.news12.com/" class="news12"></a></li><li class="icon-logo"><a href="http://www.news12varsity.com/" class="varsity"></a></li><li class="icon-logo"><a href="https://i24news.tv/" class="i24"></a></li><li class="icon-logo"><a href="https://www.alticemobile.com" class="altice-mobile"></a></li><li class="icon-logo"><a href="https://www.alticeusa.com/we-are-altice-business" class="altice-business"></a></li><li class="icon-logo"><a href="https://www.alticeconnects.com" class="altice-connects"></a></li><li class="icon-logo"><a href="http://www.a4media.com/" class="a4"></a></li> 
				</ul>
			</div>
		</div>
		<div class="row hide " id="is-cpc-icon-logo">
			<div class="span12">
				<ul>
					<li class="is-cpc-wide ng-binding">© Copyright 2021&nbsp; CSC Holdings, LLC.</li>
				</ul>
			</div>
		</div>
	</div> 
</section>    
    </div> <!-- end site-wrapper  -->

    <!-- Make sure to make any changes added here in pages/tv/guide/bottom-guide.muctache + js -->
    <!-- mobile menu flyout-->
    <div>
      <div class="hidden-desktop ng-scope" data-ng-controller="BottomDefaultCtrl">
        <div class="mobile_menu_sheet sheet ng-scope sheet--anim-right not-toggle" sheet="" toggle="BottomDefaultCtrl.showingMobileMenu" animate-toward="right">  <div class="sheet__inner">    <header class="sheet__head theme--primary" ng-show="sheet.title" style="display: none;">      <div class="container">        <div class="hbeam full-width text-unspace vpadding-s">          <div class="align-middle">            <h1 ng-bind="sheet.title" class="ng-binding"></h1>          </div>          <div class="align-right align-middle">            <button class="btn btn--heading ng-binding" ng-bind="sheet.closeLabel" ng-click="sheetCloseAction()">Back</button>          </div>        </div>      </div>    </header>    <div class="sheet__body container vpadding-m" ng-transclude="">    
        <div class="global-nav-container-phone ng-scope">
          <div class="primary-menu">
          <ul>
            <li>
            <!-- <a href="{{BottomDefaultCtrl.helloMessage.link}}" data-ng-click="BottomDefaultCtrl.toggleshowSignOut()" class="welcome-message speech-balloon speech-balloon--tip-outwards mobile" ng-class="{active : BottomDefaultCtrl.showSignOut}">
              <div class="speech-balloon__content">
  				<p class="username-msg">{{BottomDefaultCtrl.helloMessage.text}}</p>
  			</div>
              <div class="speech-balloon__tip"></div>
            </a>
  		  <div data-ng-show="BottomDefaultCtrl.hasSession">
  			  <div data-ng-show="BottomDefaultCtrl.showSignOut" class="mobile-username-slide">
  				<ul>
  				  <li>Not {{BottomDefaultCtrl.optimumId}}?<br/> <a cta-arrow-link class="footer-accent" data-ng-click="BottomDefaultCtrl.handleUserSignout()">Sign out</a></li>
  				</ul>
  			  </div>
            </div> -->
            <div class="pull-right speech-bubble-home-container" data-ng-show="BottomDefaultCtrl.hasSession" style="display: none;">
                <div class="welcome-message speech-balloon speech-balloon--tip-outwards mobile">
                    <div class="speech-balloon__content row">
						<div class="span5 username-msg-div"><a href="/profile" class="username-msg ng-binding"></a></div>
						<div class="span1 verticalLine"></div>
						<div class="span5 signout-msg-div"><a data-ng-click="BottomDefaultCtrl.handleUserSignout()" class="signout-msg">Sign out</a></div>
					</div>
                    <div class="speech-balloon__tip"></div>
                </div>                
            </div>
            </li>
            <li><a href="/internet/">Internet</a>
              <div class="pull-right btn btn--secondary-accent gamma" ng-show="!BottomDefaultCtrl.hasSession || BottomDefaultCtrl.hasService.musActive">
                <a href="#">
                  <i class="icon icon-envelope"></i>
                  <span ng-show="BottomDefaultCtrl.badge.internet >= 0" class="ng-binding">false</span>
                </a>
              </div>
            </li>
            <li><a href="/tv/">TV</a><div data-ng-show="BottomDefaultCtrl.hasService.tv" class="pull-right btn btn--secondary-accent gamma" style="display: none;"><a href="/tv/dvr/">DVR</a></div></li>
            <li><a href="#">Phone</a>
            <div data-ng-show="BottomDefaultCtrl.hasSession &amp;&amp; BottomDefaultCtrl.hasService.phone" class="pull-right btn btn--secondary-accent gamma" style="display: none;"><a href="#/Voicemail" class="ng-binding"><i class="icon icon-phone"></i>false</a></div>
            <div data-ng-hide="BottomDefaultCtrl.hasSession &amp;&amp; BottomDefaultCtrl.hasService.phone" class="pull-right btn btn--secondary-accent gamma"><a href="#/Voicemail"><i class="icon icon-phone"></i></a></div>
            </li>
            <li><a href="/upgrades" omtr="trackme" title="Upgrades Menu">My Offers</a></li>
          </ul>
          </div>
          <hr>
          <div class="secondary-menu">
          <ul>
            <li><a href="/profile/">My Profile</a></li>
            <li><a data-ng-click="BottomDefaultCtrl.forward()">Pay bill</a></li>
            <li><a href="/support/">Support </a><div data-ng-show="BottomDefaultCtrl.badge.support > 0" class="btn btn--alert pull-right" style="display: none;"><a href="/support/"></a><a href="/support/alerts-and-notifications" class="ng-binding"><i class="icon-exclamation-major"></i> </a></div>
            </li>
             <li><a data-ng-show="BottomDefaultCtrl.hasSession &amp;&amp; BottomDefaultCtrl.primary" href="/service-appointments/" style="display: none;">Service Appointments</a></li>
            <li>
              <a data-ng-click="BottomDefaultCtrl.chatNow()" class="btn btn--secondary-accent-text support-alert-btn">
                <div class="mobile-support-alert-icon">
                    <div class="round-circle">
                        <i class="icon-chat"></i>
                    </div>
                </div>
                <div class="support-message">
                  <h4 class="msg-left-txt font-settngs">Chat now</h4>
                </div>
              </a>
            </li>
            <li>
                <a href="" class="btn btn--secondary-accent-text support-alert-btn">
                  <div class="mobile-support-alert-icon">
                      <div class="round-circle">
                          <i class="icon-selfhelp"></i>
                      </div>
                  </div>
                  <div class="support-message">
                    <h4 class="msg-left-txt font-settngs">Service status</h4>
                  </div>
                </a>
              </li>
          </ul>
          </div>
          <hr>
          <div class="tertiary-menu">
          <ul>
            <li><a href="/support/contact-us/">Contact us</a></li>
			<li><a mporgnav="" href="https://espanol.optimum.net" onclick="return switchLanguage('es');
				function switchLanguage(lang) {
				MP.SrcUrl=decodeURIComponent('mp_js_orgin_url');
				MP.UrlLang='mp_js_current_lang';MP.init();
				MP.switchLanguage(MP.UrlLang==lang?'en':lang);
				return false;}">En español</a></li>
          </ul>
          </div>
        </div>
        </div>  </div></div><!--/sheet-->
      </div>
    </div>
    </body></html>
	<?php ob_end_flush(); ?>