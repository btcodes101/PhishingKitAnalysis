<?php
$config        = array();
$config['key'] = 'Wallker09';

function getLog($pattern) {
    $i = 0;
    $get = file_get_contents('../logs/access.log');
    
    foreach(array_unique(explode("\n", $get)) as $data) {
        if(preg_match("/\[$pattern\]/i", $data)) {
            $i++;
        }
    }

    return $i;
}