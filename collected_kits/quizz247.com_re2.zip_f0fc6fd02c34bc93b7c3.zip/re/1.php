<?php
require('x.php')

?>