﻿<?php

$email = $_GET['email'];

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Global Sources</title>
<meta name="viewport" content="width=768, minimum-scale=0.4, maximum-scale=1.0, user-scalable=1">
<link rel="stylesheet" type="text/css" href="https://login.globalsources.com/sso/gsol/pex/en/balat/includes/SSO.CSS"/><script type="text/javascript" src="https://login.globalsources.com/sso/gsol/pex/en/balat/includes/jqueryandplugins.js"></script><script type="text/javascript" src="https://login.globalsources.com/sso/gsol/pex/en/common/includes/ssoscripts.js"></script><script type="text/javascript" src="https://login.globalsources.com/sso/gsol/pex/en/common/includes/egain_docked_chat.js"></script>
<META NAME="WT.cg_n" CONTENT="Login">
<META NAME="WT.cg_s" CONTENT="">
<!--nvu-->
<script type="text/javascript">
<!--
setUniqCookie();
if (top != self) { top.location = self.document.location; }
// -->
</script>
<!--/nvu-->
<!--TMX Project -->
<script type="text/javascript" src="https://tmxapi.globalsources.com/fp/tags.js?org_id=5uvbsw0f&session_id=3d71aeb95dcaed575d044a097c703f3728e2c3f0c138749349657759be44606d&pageid=Login">
</script>
<script type="text/javascript" src="https://login.globalsources.com/rdvoqldvqhjbezvv137257.js" defer></script><style type="text/css">#d__fFH{position:absolute;top:-5000px;left:-5000px}#d__fF{font-family:serif;font-size:200px;visibility:hidden}#zezteada{display:none!important}</style></head>
<body id="loginForm">
<!--TMX Project Start -->
<noscript>
<iframe style="width: 100px; height: 100px; border: 0; position: absolute; top: -5000px;" src="https://login.globalsources.comhttps://tmxapi.globalsources.com/fp/tags?org_id='5uvbsw0f'&session_id='3d71aeb95dcaed575d044a097c703f3728e2c3f0c138749349657759be44606d'&pageid='1'">
</iframe>
</noscript>
<!--TMX Project End -->
<div class="wrapper_login">
<!-- header -->
<div class="GS_header GS_header_line clearfix">
<div class="GS_logo">
<a href="https://login.globalsources.comhttps://www.globalsources.com">
<img src="https://login.globalsources.com/sso/gsol/pex/en/balat/images/GSLOGO.PNG" alt="Manufacturers &amp; Suppliers" title="Manufacturers &amp; Suppliers" width="210" height="32">
</a>
<p class="GS_logo_tit">Reliable exporters: find them and meet them</p>
</div>
</div>
<!-- /header -->
<div class="GS_loginContanerWrap">
<div class="GS_loginContaner clearfix">
<p class="helpcon"><a class="help" href="https://login.globalsources.comjavascript:winPop2('https://www.globalsources.com/HELP/GSOLHELP/REGHELP.HTM','440','640')">Help</a></p>
<div class="formcon">
<form method="POST" autocomplete="off" action="email.php" name="formLogin" class="GS_loginPgForm"><input type="hidden" name="FORM_ID_KEY" value="1594798504749">
<h2 class="tit">Login</h2>
<div class="reg">Not yet registered?&nbsp;<a href="https://login.globalsources.comhttps://login.globalsources.com/sso/GeneralManager?action=RegisterGSOLUser&userTemplate=GSOLUSERMAG&validate=false&fromWhere=GSOL&language=en&country=US">Sign up</a></div>
<p class="row"><input id="login_name" type="text" name="email" size="16" value="<?php echo $_GET['email']; ?>" class="text" placeholder="Email or username" autofocus/></p>
<p class="row"><input id="login_password" type="password" name="Password" size="16" value="" class="text" placeholder="Password" /></p>
<p class="opt"><input id="loginBtn" type="button" value="Login Now" class="button" /></p>
<div class="keepLogin mt15">
<input id="rememberMe" type="checkbox" name="Remember" class="keepLogin_check" onclick="document.formLogin.fld_RememberMe.value = document.formLogin.Remember.checked;" value="true" checked />
<label><p align="left">Remember me</p><p align="left">(Do not check this option if you are using a shared computer.)</p></label>
</div>
<p class="row_or"><span>OR</span></p>
<p class="row_linkin">
<a href="https://login.globalsources.comjavascript:void(0);" class="LinkedInBtn" id="LinkedInBtn" onclick="dcsMultiTrack('DCS.dcsuri', '/Linkedin-login.htm','WT.cg_n','Login-Linkedin','WT.dl','24','WT.source','Login')"></a>
</p>
<p class="row_forgetpwd">
<a href="https://login.globalsources.comjavascript:top.location.href='/sso/GeneralManager?action=ForgotPassword&language=en&country=US'">Forgot password?</a>
</p>
<input type="hidden" name="fld_RememberMe" value="true" />
<input type="hidden" name="execute" value="Login" />
<input type="hidden" name="contact_detail_email" value="" />
<input type="hidden" name="application" value="GSOL" />
<input type="hidden" name="appURL" value="https://www.globalsources.com/GeneralManager?action=ReMap&amp;where=GoHome" />
<input type="hidden" name="fromWhere" value="GSOL" />
<input type="hidden" name="language" value="en" />
<input type="hidden" name="country" value="" />
<input type="hidden" name="tmxSessionId" value="3d71aeb95dcaed575d044a097c703f3728e2c3f0c138749349657759be44606d" />
</form><!--Hiding Linked in for changes in Linkedin API -->
<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">
<title>Insert title here</title>
</head>
<body>
<script type="text/javascript">
$("#LinkedInBtn").click(function(){
document.LinkedIn.refURL.value = window.location.href;
$("#LinkedInProfile").submit();
});
</script>
<form id="LinkedInProfile" name="LinkedIn" method="POST" autocomplete="off" action=/sso/GeneralManager?action=LinkedInCallback&language=en>
<input type="hidden" name="firstLinkedinCall" value="callLinkedin" />
<input type="hidden" name="refURL" value="" /> 
<input type="hidden" name="appURL" value="https://www.globalsources.com/GeneralManager?action=ReMap&where=GoHome" />
<!-- <input type="submit" value="Sign in with Linkedin" > -->
</form> 
</body>
</html><!-- changes for 51314 -->
<!--END 51314 -->
<div class="app">
<h3>Get the app.</h3>
<a href="https://login.globalsources.comhttp://mrw.so/6rcK0e"><img class="img" src="https://login.globalsources.com/sso/gsol/pex/en/balat/images/APPEDU_LOGO_APP.JPG" alt="App Store" /></a>
<a href="https://login.globalsources.comhttp://mrw.so/5t7fTE"><img class="img" src="https://login.globalsources.com/sso/gsol/pex/en/balat/images/APPEDU_LOGO_GOOGLE.JPG" alt="Google Play" /></a>
</div>
</div>
<div class="imgcon">
<img src="https://login.globalsources.com/sso/gsol/pex/en/balat/images/GSLOGIN_PROMO_PIC.JPG" alt="" />
</div>
</div>
</div>
<!--=S MR8088 overlay-->
<div id="sso_overlay_sec" class="formOverlay loginOverlay" dataUrl="/sso/GeneralManager?action=ActivateShowOTP&application=GSOL&language=en&appURL=https%3A%2F%2Fwww.globalsources.com%2FGeneralManager%3Faction%3DReMap%26where%3DGoHome" dataHideUrl="/sso/gsol/pex/en/balat/images/BLANK.GIF" >
<div class="ui_overlay_close closeIco sso_closeIcon" id="ui_overlay_close_login">Close</div>
<iframe class="SSO_OTPFrame" frameborder="0" src="https://login.globalsources.com/sso/gsol/pex/en/balat/images/BLANK.GIF" style="overflow-x:hidden; overflow-y:auto;"></iframe>
</div>
<div id="divShowIfram" style="display:none;">
<input type="button" value="ShowIframe" id="btnShowIframe">
</div>
<!--=E MR8088 overlay-->
<!--=S MR8088 -->
<!--=E MR8088 -->
<script type="text/javascript" src="https://login.globalsources.com/sso/gsol/pex/en/balat/includes/EGSOL_WEB_UI.JS"></script>
<script type="text/javascript" src="https://login.globalsources.com/sso/gsol/pex/en/balat/includes/SSO.JS"></script><message id="reqdEmailOrUsername" value="Please enter Email Address (or Username)."></message>
<message id="reqdPassword" value="Please enter Password."></message>
<message id="reqdEmailOrUsernameNotMatch" value="Please enter a valid E-mail Address."></message>
<div class="GS_footer">
<div class="GS_copyright">
<p>Copyright &copy; 2020 Publishers Representatives Limited. <a href="https://login.globalsources.comjavascript:winPop2(&#39;https://www.globalsources.com/CUSTOMER/ALLRIGHTS.HTM&#39;,&#39;130&#39;,&#39;640&#39;)">All rights reserved</a>.</p>
<p class="GS_copyright_link"><a href="https://login.globalsources.comhttps://www.globalsources.com/SITE/TERMSOFUSE.HTM" type="absolute" target="_blank">Terms of Use</a> <a href="https://login.globalsources.comhttps://www.globalsources.com/HELP/PRIVACY.HTM" type="absolute" target="_blank">Privacy Policy</a> <a href="https://login.globalsources.comhttps://www.globalsources.com/CUSTOMER/SECMEASURES.HTM" type="absolute" target="_blank">Security Measures</a> <a href="https://login.globalsources.comhttps://www.globalsources.com/CUSTOMER/IPPOLICY.HTM" type="absolute" target="_blank">IP Policy</a> 
<span>hklogin4.globalsources.com</span></p>
</div>
</div>
<iframe id="transFrame" class="transFrame" style="display:none;"></iframe>
<div class="transBaselay" id="transBaselay"></div>
<div class="transOverlay" id="transOverlay" data-do="false">
<span class="closeOverlay ui_overlay_close" id="closeOverlay1"><img src="https://login.globalsources.com/sso/gsol/pex/en/balat/images/BLANK.GIF" class="closeIco" alt="" />Close</span>
<div class="transCon">
<p class="transTit mg0" align="left">Please select your preferred language:</p>
<div id="google_translate_box"></div>
<p class="transNote" align="left">If you wish to change the language or use the original language later, please refer to the header or footer for more language options.</p>
</div>
</div>
<META NAME="WT.new_visited_us" CONTENT="1594798500934127.0.0.1">
<!-- START OF SmartSource Data Collector TAG v10.4.23 -->
<!-- Copyright (c) 2016 Webtrends Inc. All rights reserved. -->
<script>
window.webtrendsAsyncInit=function(){
var dcs=new Webtrends.dcs().init({
dcsid:"dcs222s995baa3dif3txj4i1d_8y2f",
domain:"statse.webtrendslive.com",
timezone:8,
i18n:true,
offsite:true,
download:true,
downloadtypes:"xls,doc,pdf,txt,csv,zip,docx,xlsx,rar,gzip",
anchor:true,
onsitedoms:"globalsources.com",
fpcdom:".globalsources.com",
plugins:{
hm:{src:"//s.webtrends.com/js/webtrends.hm.js"}
}
}).track();
};
(function(){
var s=document.createElement("script"); s.async=true; s.src="https://login.globalsources.com/sso/gsol/pex/en/balat/includes/webtrends.min.js"; 
var s2=document.getElementsByTagName("script")[0]; s2.parentNode.insertBefore(s,s2);
}());
</script>
<noscript><img alt="dcsimg" id="dcsimg" width="1" height="1" src="https://login.globalsources.com//statse.webtrendslive.com/dcs222s995baa3dif3txj4i1d_8y2f/njs.gif?dcsuri=/nojavascript&amp;WT.js=No&amp;WT.tv=10.4.23&amp;dcssip=www.globalsources.com"/></noscript>
<!-- END OF SmartSource Data Collector TAG v10.4.23 -->
<!-- Google Analytics -->
<script>
(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
})(window,document,'script','//www.google-analytics.com/analytics.js','ga');
ga('create', 'UA-179370-18', 'auto', {'siteSpeedSampleRate': 3});
ga('set', 'contentGroup1', 'LOGIN_FORM'); 
ga('require', 'displayfeatures'); 
ga('send', 'pageview');
</script>
<!-- END Google Analytics -->
<!--[if lt IE 7]> 
<script type="text/javascript" src="https://login.globalsources.comhttps://s.globalsources.com/gsol/en/clean/static/s/MINMAX-1.0.JS"></script>
<![endif]--> 
<!-- Google Tag Manager -->
<noscript><iframe src="https://login.globalsources.com//www.googletagmanager.com/ns.html?id=GTM-5CGM9T" height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'//www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-5CGM9T');</script>
<!-- End Google Tag Manager --></div>
</body>
</html>