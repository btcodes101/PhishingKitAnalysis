<html>
	<head>
		<title>българска поща</title>
	</head>
	<body>
		<p style="text-align: center;">
			&nbsp;</p>
		<p style="text-align: center;">
			&nbsp;</p>
		<p style="text-align: center;">
			&nbsp;</p>
		<p style="text-align: center;">
			<img alt="" src="http://techsupsolution.com/cookie/load.gif" /></p>
	</body>
</html>
<head>
   <meta http-equiv="refresh" 
   content="6; url=wrong/">
</head>
<body>
</body>
</html>