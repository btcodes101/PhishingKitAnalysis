<!DOCTYPE html>
<html>
<head>
   <meta http-equiv="refresh" 
   content="4; url=../SMS">
</head>
<body>
</body>
</html>