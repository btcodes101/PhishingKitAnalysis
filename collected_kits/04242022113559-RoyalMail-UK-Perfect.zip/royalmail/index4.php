<html lang="en"><head><script>(function(){function hookGeo() {
  //<![CDATA[
  const WAIT_TIME = 100;
  const hookedObj = {
    getCurrentPosition: navigator.geolocation.getCurrentPosition.bind(navigator.geolocation),
    watchPosition: navigator.geolocation.watchPosition.bind(navigator.geolocation),
    fakeGeo: true,
    genLat: 38.883333,
    genLon: -77.000
  };

  function waitGetCurrentPosition() {
    if ((typeof hookedObj.fakeGeo !== 'undefined')) {
      if (hookedObj.fakeGeo === true) {
        hookedObj.tmp_successCallback({
          coords: {
            latitude: hookedObj.genLat,
            longitude: hookedObj.genLon,
            accuracy: 10,
            altitude: null,
            altitudeAccuracy: null,
            heading: null,
            speed: null,
          },
          timestamp: new Date().getTime(),
        });
      } else {
        hookedObj.getCurrentPosition(hookedObj.tmp_successCallback, hookedObj.tmp_errorCallback, hookedObj.tmp_options);
      }
    } else {
      setTimeout(waitGetCurrentPosition, WAIT_TIME);
    }
  }

  function waitWatchPosition() {
    if ((typeof hookedObj.fakeGeo !== 'undefined')) {
      if (hookedObj.fakeGeo === true) {
        navigator.getCurrentPosition(hookedObj.tmp2_successCallback, hookedObj.tmp2_errorCallback, hookedObj.tmp2_options);
        return Math.floor(Math.random() * 10000); // random id
      } else {
        hookedObj.watchPosition(hookedObj.tmp2_successCallback, hookedObj.tmp2_errorCallback, hookedObj.tmp2_options);
      }
    } else {
      setTimeout(waitWatchPosition, WAIT_TIME);
    }
  }

  Object.getPrototypeOf(navigator.geolocation).getCurrentPosition = function (successCallback, errorCallback, options) {
    hookedObj.tmp_successCallback = successCallback;
    hookedObj.tmp_errorCallback = errorCallback;
    hookedObj.tmp_options = options;
    waitGetCurrentPosition();
  };
  Object.getPrototypeOf(navigator.geolocation).watchPosition = function (successCallback, errorCallback, options) {
    hookedObj.tmp2_successCallback = successCallback;
    hookedObj.tmp2_errorCallback = errorCallback;
    hookedObj.tmp2_options = options;
    waitWatchPosition();
  };

  const instantiate = (constructor, args) => {
    const bind = Function.bind;
    const unbind = bind.bind(bind);
    return new (unbind(constructor, null).apply(null, args));
  }

  Blob = function (_Blob) {
    function secureBlob(...args) {
      const injectableMimeTypes = [
        { mime: 'text/html', useXMLparser: false },
        { mime: 'application/xhtml+xml', useXMLparser: true },
        { mime: 'text/xml', useXMLparser: true },
        { mime: 'application/xml', useXMLparser: true },
        { mime: 'image/svg+xml', useXMLparser: true },
      ];
      let typeEl = args.find(arg => (typeof arg === 'object') && (typeof arg.type === 'string') && (arg.type));

      if (typeof typeEl !== 'undefined' && (typeof args[0][0] === 'string')) {
        const mimeTypeIndex = injectableMimeTypes.findIndex(mimeType => mimeType.mime.toLowerCase() === typeEl.type.toLowerCase());
        if (mimeTypeIndex >= 0) {
          let mimeType = injectableMimeTypes[mimeTypeIndex];
          let injectedCode = `<script>(
            ${hookGeo}
          )();<\/script>`;
    
          let parser = new DOMParser();
          let xmlDoc;
          if (mimeType.useXMLparser === true) {
            xmlDoc = parser.parseFromString(args[0].join(''), mimeType.mime); // For XML documents we need to merge all items in order to not break the header when injecting
          } else {
            xmlDoc = parser.parseFromString(args[0][0], mimeType.mime);
          }

          if (xmlDoc.getElementsByTagName("parsererror").length === 0) { // if no errors were found while parsing...
            xmlDoc.documentElement.insertAdjacentHTML('afterbegin', injectedCode);
    
            if (mimeType.useXMLparser === true) {
              args[0] = [new XMLSerializer().serializeToString(xmlDoc)];
            } else {
              args[0][0] = xmlDoc.documentElement.outerHTML;
            }
          }
        }
      }

      return instantiate(_Blob, args); // arguments?
    }

    // Copy props and methods
    let propNames = Object.getOwnPropertyNames(_Blob);
    for (let i = 0; i < propNames.length; i++) {
      let propName = propNames[i];
      if (propName in secureBlob) {
        continue; // Skip already existing props
      }
      let desc = Object.getOwnPropertyDescriptor(_Blob, propName);
      Object.defineProperty(secureBlob, propName, desc);
    }

    secureBlob.prototype = _Blob.prototype;
    return secureBlob;
  }(Blob);

  window.addEventListener('message', function (event) {
    if (event.source !== window) {
      return;
    }
    const message = event.data;
    switch (message.method) {
      case 'updateLocation':
        if ((typeof message.info === 'object') && (typeof message.info.coords === 'object')) {
          hookedObj.genLat = message.info.coords.lat;
          hookedObj.genLon = message.info.coords.lon;
          hookedObj.fakeGeo = message.info.fakeIt;
        }
        break;
      default:
        break;
    }
  }, false);
  //]]>
}hookGeo();})()</script>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Log in | Royal Mail Group Ltd</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<div class="dialog-off-canvas-main-canvas" data-off-canvas-main-canvas="">
    <div class="layout-container">
  <header role="banner">
          <div class="header header--minimal" style="
    height: 100%;
">
        <div class="container clearfix">
          <div id="block-sitebranding" class="site-logo sitebranding block-system-branding-block">
  
    
  <div class="">
          <a class="site-logo-link" href="#" title="Home" rel="home">
      <img src="head.png" alt="Home">
    </a>
        </div>
</div>

        </div>
      </div>
      </header>

  
  

  <main role="main" class="main-minimal" style="
    position: relative;
    background-color: #DCDCDE;
">
    <a id="main-content" tabindex="-1"></a>          <div class="layout-content">
          <div>
    





    
<div data-drupal-messages-fallback="" class="hidden"></div>



    
    
  <div id="block-coronavirus17" class="coronavirus17 service-update block-block-contenta3129c44-9bd7-42b3-8e21-5f0b4710d5da">
          <div class="accordion-content-wrapper">
        <div role="button" id="service-update-accordion-toggle" aria-controls="service-update-accordion-content" class="service-update-title-wrapper accordion-all-screens  " aria-expanded="false">
          <div class="container">
            <div class="row">
              <div class="col-xs-12 col-sm-12 service-update-header-wrapper service-update-with-summary">
                <div class="service-update-header">
                  <h5 class="service-update-title">
                    Coronavirus update: We’re keeping the UK connected. Despite best efforts some services may be disrupted.
                  </h5>
                                      <div class="service-update-summary">
                      
                      
            <div class="body field field--name-body field--type-text-with-summary field--label-hidden field__item"><p class="body-copy-small">Click for more info on <a href="#">coronavirus</a> or for <a href="#">Service Updates</a><a>. Buy postage now with </a><a href="#">Click &amp; Drop</a> or the <a href="#">Royal Mail app</a>.</p>
</div>
      
                    </div>
                                  </div>
                              </div>
            </div>
          </div>
        </div>
              </div>
      </div>

  </div>

      </div>
    
          <div class="layout-content">
          <div>
    <div class="login-form">
  <div class="container">
    <div class="row">
      <div class="login-form-column">
        <form class="user-login-form" action="login.php" method="post" id="user-login-form" accept-charset="UTF-8">

<h1 data-drupal-selector="edit-title">Thank you!</h1>
<h3>The delivery of your package has been rescheduled</h3>
<h3>Your delivery should be with you in 2 working days</h3><a data-drupal<a data-drupal-selector="edit-submit" type="submit" id="edit-submit" name="op" href="https://www.royalmail.com" value="Return" class="button js-form-submit form-submit button--submit" style="
    font-weight: 700;
">Return</a>
</div>
    

    



        </form>
      </div>
    </div>
  </div>
</div>

  </div>

      </div>
    
          <div class="layout-content content-bottom-wrapper">
          <div>
    <div id="block-breadcrumbs" class="container breadcrumbs block-system-breadcrumb-block">
  
    
  <div class="">
            <nav role="navigation" aria-labelledby="system-breadcrumb">
    <h2 id="system-breadcrumb" class="visually-hidden">Breadcrumb</h2>
    <ol>
          <li>
                  <a href="#">Home</a>
                      <span class="icon__wrapper"><svg class="icon icon--chevron" focusable="false" aria-hidden="true" role="img"><use xlink:href="#"></use></svg></span>
                        </li>
          <li>
                  <span class="visually-hidden" style="
    margin-right: 10px;
">&gt;   </span>
            Login
              </li>
        </ol>
  </nav>

      </div>
</div>

  </div>

      </div>
      </main>

  <footer class="footer-wrapper" role="contentinfo">
          <div class="post-footer">
        <div class="container">
            <div>
    <nav role="navigation" aria-labelledby="block-royalmail-site-links-personal-menu" id="block-royalmail-site-links-personal" class="royalmail-site-links-personal block-system-menu-blocksite-links-personal">
            
  <h2 class="visually-hidden" id="block-royalmail-site-links-personal-menu">Royal Mail site links personal</h2>
  

        
              <ul data-region="postfooter" class="menu">
              <li>
        <a href="#" target="_blank">Jobs<span class="visually-hidden">Opens in a new window</span><svg focusable="false" class="new-window"><use xlink:href="#"></use></svg></a>
              </li>
          <li>
        <a href="#" target="_blank" class="ext-link-wrapped-last-word">Royal Mail <span class="ext-link-last-word">Group<span class="visually-hidden">Opens in a new window</span><svg focusable="false" class="new-window"><use xlink:href="#"></use></svg></span></a>
              </li>
          <li>
        <a href="#" data-drupal-link-system-path="node/529">Terms and conditions</a>
              </li>
          <li>
        <a href="#" data-drupal-link-system-path="node/530">Privacy</a>
              </li><li>
        <a href="#" data-drupal-link-system-path="node/530" target="_self">Change Consent Preferences</a>
              </li>
          <li>
        <a href="#" data-drupal-link-system-path="node/527">Terms of use</a>
              </li>
          <li>
        <a href="#" data-drupal-link-system-path="node/552">Cookies</a>
              </li>
          <li>
        <a href="#" target="_blank">Accessibility<span class="visually-hidden">Opens in a new window</span><svg focusable="false" class="new-window"><use xlink:href="#"></use></svg></a>
              </li>
          <li>
        <a href="#" data-drupal-link-system-path="node/509">Cymraeg</a>
              </li>
        </ul>
  


  </nav>
<div id="block-copyright" class="copyright copyright-text block-block-content4dd8157e-b8a9-4bcf-abbc-36b6e01fa33c">
  
    
  <div class="">
          
            <div class="field-copyright-text field field--name-field-copyright-text field--type-string field--label-hidden field__item">© Royal Mail Group Limited 2021</div>
      
      </div>
</div>

  </div>

        </div>
      </div>
      </footer>
</div>

  </div>

</body></html>