<?php 
include './config.php';

$_SESSION['logged'] = false;
$_SESSION['login'] = '';
unset($_SESSION);

header("Location: index.php");
exit;
?>