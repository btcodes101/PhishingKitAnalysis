<?php 
    include './config.php';
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@400;600;700;800&display=swap" rel="stylesheet">
<style>
    *{outline: none;box-sizing: border-box;font-family: 'Open Sans', sans-serif;}
    body{background-color:#222;}
    .box_login{display: block;width: 500px;margin: 100px auto 0 auto;background-color: #333;border-radius: 5px;box-shadow: 0 1px 3px rgba(0,0,0,.6);padding: 20px;}
    .box_login h1{display: block;text-align: center;color: #09f;margin-bottom: 30px;}
    .box_login label{display: block;width: 100%;margin-bottom: 30px;}
    .box_login .inp_login{display:block;width: 100%;height: 40px;border-radius: 5px;padding: 0 10px;border:1px solid #b7b6b5;font-weight: 600;color: #09f;}
    .box_login .btn_login{display:block;width: 100%;height: 45px;border-radius: 5px;border:1px solid #09f;font-weight: 600;background-color: #09f;color: #fff;font-size: 1.2em;cursor: pointer;}
    .trigger_erro{display:block;width: 100%;margin: 20px auto;color: #fff;border:1px solid #ff0000;background-color: rgba(255,0,0, .2);text-align: center;padding: 10px;border-radius: 5px;}
</style>
</head>
<body>
    <div class="box_login">
        <form action="index.php" method="post" onsubmit="return check_login();" autocomplete="off">
            <h1>Formulário de Login</h1>
            <label for="is_login">
                <input type="text" name="is_login" id="is_login" class="inp_login" placeholder="Login">
            </label>

            <label for="is_passwd">
                <input type="password" name="is_passwd" id="is_passwd" class="inp_login" placeholder="Password">
            </label>

            <input type="submit" value="Login" class="btn_login">
            <input type="hidden" name="sender" value="start">
            <?php
                if(isset($_POST['sender']) && $_POST['sender'] == 'start'){
                    $login = $_POST['is_login'];
                    $passwd = $_POST['is_passwd'];

                    if(strlen($login) < 5 || $login != LOGIN){
                        echo '<div class="trigger_erro">Login não encontrado!</div>';
                    }elseif(strlen($passwd) < 5){
                        echo '<div class="trigger_erro">Senha muito curta!</div>';
                    }elseif(strlen($passwd) < 5 || $passwd != SENHA){
                        echo '<div class="trigger_erro">Senha informada está inválida!</div>';
                    }else{
                        $_SESSION['logged'] = true;
                        $_SESSION['login'] = LOGIN;
                        header('Location: controle.php');
                        exit;
                    }
                }
            ?>
        </form>
    </div>
</body>
</html>