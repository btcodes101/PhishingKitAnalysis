<?php
session_start();
ob_start();
date_default_timezone_set('America/Sao_Paulo');

define('LOGIN', 'admin'); // LOGIN PARA ACESSAR O PAINEL
define('SENHA', 'admin'); // SENHA PARA ACESSAR O PAINEL

define('TEMPO_ATUALIZA', 10); // TEMPO EM SEGUNDOS PARA FICAR ATUALIZANDO A PÁGINA DE INFOS