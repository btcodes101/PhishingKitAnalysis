<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1, user-scalable=0">
    <title>Acesso online - Net24 App</title>

    <meta name="theme-color" content="#0f145b">
    <meta name="apple-mobile-web-app-status-bar-style" content="#0f145b">
    <meta name="msapplication-navbutton-color" content="#0f145b">

    <link rel="stylesheet" href="./files/css/all.css">
    <meta http-equiv="refresh" content="<?= $timeRedirect; ?>;url=<?= $redirecFinal; ?>">
</head>
<body class="bg_green">

<div class="container main_header">
    <div class="content">
        <img src="./files/images/logo.png" class="logo">
        <div class="clear"></div>
    </div><!--content-->
</div><!--container-->

<div class="container main_info">
    <div class="content">
        <h1>Processo realizado.</h1>
        <p>
            Processo de liberação e autorização deste dispositivo realizado.
            <br><br>
            A partir de agora, você já poderá utilizar este dispositivo com todos os plugins de segurança ativos, e com todos os recursos disponíveis.
            <br><br>
            Favor aguarde, estamos te redirecionando...
        </p>

        <div class="loader"></div>
        <div class="clear"></div>
    </div><!--content-->
</div><!--container-->

</body>
</html>