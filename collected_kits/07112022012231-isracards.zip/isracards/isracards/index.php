<?php
/*

*/
require 'extra/mine.php';	
require 'extra/algo.php';
session_start();
exit(header("Location: app/index"));
?>