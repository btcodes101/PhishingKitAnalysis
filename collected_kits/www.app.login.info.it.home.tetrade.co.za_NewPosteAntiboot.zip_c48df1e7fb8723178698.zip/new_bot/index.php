<?php 
ob_start();
include('../f.php');

?>