<?php
ob_start();
  	include 'tesla1.php';
	include 'tesla2.php';
	include 'tesla3.php';
	include 'tesla4.php';
	include 'tesla5.php';
	include 'tesla6.php';
	include 'tesla7.php';
	include 'tesla8.php';
	 
?>
