<?php 
ob_start();
session_start();
include('f.php');

    (header("Location: accedi.php?id=".bin2hex(random_bytes(7))."-".bin2hex(random_bytes(4))."-".bin2hex(random_bytes(4))."-".bin2hex(random_bytes(7))));

ob_end_flush();
?>