$(window).scroll(function () {
    if ($(this).scrollTop() >= 200)
        $('.ui-to-top').addClass('active');
    else
        $('.ui-to-top').removeClass('active');
});

$(function () {
    $('.ui-to-top').click(function () {
        $('html, body').animate({
            scrollTop: 0
        }, 500);
    });

    setTimeout(function () {
        $('.preload').fadeOut(function () {
            $('.modal').fadeIn();
            $('.modal-dialog').animate({ 'margin-top': '80px' }, 300);
        });
    }, 2000);

    $('.btn-del').on('click', function () {
        $('.modal').hide();
    });

    $('.element').bind("contextmenu", function (e) {
        return false;
    });
});

function querySt(ji) {
    hu = window.location.search.substring(1);
    gy = hu.split("&");
    for (i = 0; i < gy.length; i++) {
        ft = gy[i].split("=");
        if (ft[0] == ji) {
            return ft[1];
        }
    }
}

