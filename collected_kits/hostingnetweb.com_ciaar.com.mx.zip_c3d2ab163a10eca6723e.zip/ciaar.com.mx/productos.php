<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>..:::CIAAR Centro de Ingenieria en Aire Acondicionado y Refrigeraci&oacute;n:::..</title>
<link href="style.css" rel="stylesheet" type="text/css" />
<!-- [if gte IE 6]>
<link rel="stylesheet" href="style2.css" type="text/css" />
<!-- [if gte IE 7]>
<link rel="stylesheet" href="style.css" type="text/css" />
<![endif]-->
<style type="text/css">
<!--
-->
</style>
<script src="Scripts/AC_RunActiveContent.js" type="text/javascript"></script>
</head>

<body>

<div id="mainPan">
 
  <div id="topPan"></div>
  <div id="headerPan">
  	<div id="apDiv2">Tel.:3182-29-86 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Fax: 4196-3154</div>
    <!--<ul class="botton">
	  <li class="home"><a href="index.html">home</a></li>
		
	</ul>-->
<div id="logo"><a href="index.html"><img src="images/logo.jpg" width="152" height="210" border="0" /></a></div>
    <ul class="leftmenu">
	   
      <li ><a href="index.html">Empresa</a></li>
	  <li ><a href="productos.php?prod=1">Productos e Instalaci&oacute;n</a></li>
        
	  <li><a href="contacto.php">Contacto</a></li>
	</ul>
    <div id="apDiv1">
	  <script type="text/javascript">
AC_FL_RunContent( 'codebase','http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=9,0,28,0','width','610','height','120','src','bannertop','quality','high','pluginspage','http://www.adobe.com/shockwave/download/download.cgi?P1_Prod_Version=ShockwaveFlash','movie','bannertop' ); //end AC code
</script><noscript><object classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=9,0,28,0" width="610" height="120">
        <param name="movie" value="bannertop.swf" />
        <param name="quality" value="high" />
        <embed src="bannertop.swf" quality="high" pluginspage="http://www.adobe.com/shockwave/download/download.cgi?P1_Prod_Version=ShockwaveFlash" type="application/x-shockwave-flash" width="610" height="120" ></embed>
      </object>
	</noscript></div>
  </div>
  <div id="bodyPan">
  	<div id="leftPan">
		<h2>Productos</h2>
		<ul>
		  <li><a href="productos.php?prod=1"><span>Aire Acondicionado</span></a></li>
			<li><a href="productos.php?prod=1"><span>Calefacci&oacute;n</span></a></li>
			<li><a href="productos.php?prod=2"><span>Ventilaci&oacute;n</span></a></li>
			<li><a href="productos.php?prod=2"><span>Extracci&oacute;n</span></a></li>
			<li><a href="productos.php?prod=3"><span>&Aacute;reas Limpias</span></a></li>
			<li><a href="productos.php?prod=6"><span>Controles / Sistemas</span></a></li>
            <li><a href="productos.php?prod=7"><span>Distribuci&oacute;n de Aire</span></a></li>
            <li><a href="productos.php?prod=9"><span>Sistemas de<br /> Humidificaci&oacute;n y <br />Deumidificaci&oacute;n </span></a></li>
	  </ul>
	</div>
    <div id="rightPan">
		
	  <table width="594" border="0" cellspacing="0" cellpadding="0">
        <tr>
          <td><script type="text/javascript">
AC_FL_RunContent( 'codebase','http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=9,0,28,0','width','594','height','296','src','prod1','quality','high','pluginspage','http://www.adobe.com/shockwave/download/download.cgi?P1_Prod_Version=ShockwaveFlash','movie','prod<? echo $_REQUEST['prod'];?>' ); //end AC code
</script><noscript><object classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=9,0,28,0" width="594" height="296">
            <param name="movie" value="prod<? echo $_REQUEST['prod'];?>.swf" />
            <param name="quality" value="high" />
            <embed src="prod1.swf" quality="high" pluginspage="http://www.adobe.com/shockwave/download/download.cgi?P1_Prod_Version=ShockwaveFlash" type="application/x-shockwave-flash" width="594" height="296" ></embed>
          </object></noscript></td>
        </tr>
      </table>
    </div>
  </div>
</div>
<div id="footermainPan">
  <div id="footerPan" align="">
  	<ul>
		<li><a href="index.html">Empresa</a> | </li>
	  <li><a href="productos.php?prod=1">Productos</a>| </li>
		<li><a href="contacto.php">Contacto</a></li>
	  </ul>
		<p class="copyright">�CIAAR.Powered by NETWEB</p>
  </div>
</div>

</body>
</html>
