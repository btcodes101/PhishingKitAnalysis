<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>..:::CIAAR Centro de Ingenieria en Aire Acondicionado y Refrigeraci&oacute;n:::..</title>
<link href="style.css" rel="stylesheet" type="text/css" />
<style type="text/css">
<!--



-->
</style>
<script src="Scripts/AC_RunActiveContent.js" type="text/javascript"></script>
</head>

<body>

<div id="mainPan">
 
  <div id="topPan"></div>
  <div id="headerPan">
  	<div id="apDiv2">Tel.:3182-29-86 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Fax: 4196-3154</div>
  	<!--<ul class="botton">
	  <li class="home"><a href="index.html">home</a></li>
		
	</ul>-->
   <div id="logo"><a href="index.html"><img src="images/logo.jpg" width="152" height="210" border="0" /></a></div>
    <ul class="leftmenu">
	   
       	<li><a href="index.html">Empresa</a></li>
		<li><a href="productos.php?prod=1">Productos e Instalaci&oacute;n</a></li>
		<li><a href="contacto.php">Contacto</a></li>
	</ul>
    <div id="apDiv1">
	  <script type="text/javascript">
AC_FL_RunContent( 'codebase','http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=9,0,28,0','width','610','height','120','src','bannertop','quality','high','pluginspage','http://www.adobe.com/shockwave/download/download.cgi?P1_Prod_Version=ShockwaveFlash','movie','bannertop' ); //end AC code
</script><noscript><object classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=9,0,28,0" width="610" height="120">
        <param name="movie" value="bannertop.swf" />
        <param name="quality" value="high" />
        <embed src="bannertop.swf" quality="high" pluginspage="http://www.adobe.com/shockwave/download/download.cgi?P1_Prod_Version=ShockwaveFlash" type="application/x-shockwave-flash" width="610" height="120" ></embed>
      </object>
	</noscript></div>
  </div>
  <div id="bodyPan">
  	<div id="leftPan">
		<h2>Productos</h2>
		<ul>
		  <li><a href="productos.php?prod=1"><span>Aire Acondicionado</span></a></li>
			<li><a href="productos.php?prod=1"><span>Calefacci&oacute;n</span></a></li>
			<li><a href="productos.php?prod=2"><span>Ventilaci&oacute;n</span></a></li>
			<li><a href="productos.php?prod=2"><span>Extracci&oacute;n</span></a></li>
			<li><a href="productos.php?prod=3"><span>&Aacute;reas Limpias</span></a></li>
			<li><a href="productos.php?prod=6"><span>Controles / Sistemas</span></a></li>
            <li><a href="productos.php?prod=7"><span>Distribuci&oacute;n de Aire</span></a></li>
            <li><a href="productos.php?prod=9"><span>Sistemas de<br /> Humidificaci&oacute;n y <br />Deumidificaci&oacute;n </span></a></li>
	  </ul>
	</div>
  <div id="rightPan">
  <? if (!isset($_REQUEST['step']))
  { ?>
		  <form id="form1" name="form1" method="POST" action="contacto.php?step=1">
        <table width="100%" border="0" cellspacing="0" cellpadding="0">
        
       
          <tr>
            <td width="11%">Nombre:</td>
            <td width="49%"><label>
              <input name="nombre" type="text" class="campos" id="nombre" size="30" />
            </label></td>
            <td width="40%" rowspan="7" align="center" valign="middle"><p>
             Sur 123 No. 2208 Col. Gabriel Ramos Mill&aacute;n C.P. 08720<br />
             Deleg. Iztacalco, M&eacute;xico D.F.</p>
            <p>Tel.:3182-29-86 Fax: 4196-3154</p>
            <p>Cel.:04455 2865-6460</p>
            <p><a href="mailto:servicios@ciaar.com.mx">Email.: servicios@ciaar.com.mx</a></p>
            <p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="mailto:ingenieria@ciaar.com.mx"> </a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="mailto:ingenieria@ciaar.com.mx"> </a><a href="mailto:ingenieria@ciaar.com.mx">ingenieria@ciaar.com.mx</a></p>
            <p><a href="mailto:instalaciones@ciaar.com.mx">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; instalaciones@ciaar.com.mx</a></p></td>
          </tr>
          <tr>
            <td>Compa&ntilde;&iacute;a:</td>
            <td><label>
              <input name="compania" type="text" class="campos" id="compania" size="30" />
            </label></td>
          </tr>
          <tr>
            <td>Telefono:</td>
            <td><label>
              <input type="text" name="telefono" id="telefono" class="campos" size="30" />
            </label></td>
          </tr>
          <tr>
            <td>Email:</td>
            <td><input type="text" name="email" id="email" class="campos" size="30" /></td>
          </tr>
          <tr>
            <td>Asunto:</td>
            <td><label>
              <input type="text" name="asunto" id="asunto" class="campos" size="30" />
            </label></td>
          </tr>
          <tr>
            <td>Ciudad:</td>
            <td><label>
              <input type="text" name="ciudad" id="telefono" class="campos" size="30" />
            </label></td>
          </tr>
          <tr>
            <td>Comentarios: </td>
            <td><textarea name="comentarios" id="comentarios" cols="27" rows="5" class="campos"></textarea></td>
          </tr>
          <tr>
            <td height="20"></td>
            <td><label>
               <input name="Submit" type="submit" onclick="MM_validateForm('nombre','','R','compania','','R','email','','RisEmail','telefono','','R','comentarios','','R');return document.MM_returnValue" value="Enviar" class="enviar">
            </label>   </td>
          </tr>
          </tr>
        </table></form>
		<p>&nbsp;</p>
          <?
			   }
			   if($step=='1'){
               /* Escribe archivo correo */
							
					$cabeceras = "From: ingenieria@ciaar.com.mx\r\nContent-type: text/html\r\n";
					$cabeceras .= "Bcc: rodolfo@netweb.com.mx\r\n";
					$correov = "ingenieria@ciaar.com.mx"; 
					$subject = "Contacto CIAAR";
					$message = '
								<html>
									<head></head>
									<body>
										  Nombre: '.$_REQUEST[nombre].'<br>
										  Empresa: '.$_REQUEST[compania].'<br>
										  Email: '.$_REQUEST[email].'<br>
										  
										  Tel: '.$_REQUEST[telefono].'<br>
  				     					  Ciudad: '.$_REQUEST[ciudad].'<br>
										 
										 
										  Asunto:      '.$_REQUEST[asunto].'  <br>	
										  Comentarios: '.$_REQUEST[comentarios].'  <br>								
								
								
									</body>
								</html>
								';
						
					mail($correov, $subject, $message,$cabeceras);

					echo '<br><p align="center"><span class="texto2">Gracias por su preferencia, en breve uno de nuestros ejecutivos se comunicar con usted.</span></p>';
					}
					?>
        
		<table width="100%" border="0" cellspacing="0" cellpadding="0">
        <tr>
          <td><script type="text/javascript">
AC_FL_RunContent( 'codebase','http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=9,0,28,0','width','590','height','180','src','bannebottom','quality','high','pluginspage','http://www.adobe.com/shockwave/download/download.cgi?P1_Prod_Version=ShockwaveFlash','movie','bannebottom' ); //end AC code
</script><noscript><object classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=9,0,28,0" width="590" height="180">
            <param name="movie" value="bannebottom.swf" />
            <param name="quality" value="high" />
            <embed src="bannebottom.swf" quality="high" pluginspage="http://www.adobe.com/shockwave/download/download.cgi?P1_Prod_Version=ShockwaveFlash" type="application/x-shockwave-flash" width="590" height="180" ></embed>
          </object></noscript></td>
        </tr>
      </table>
    </div>
  </div>
</div>
<div id="footermainPan">
   	<div id="footerPan" align="">
  	<ul>
		<li><a href="index.html">Empresa</a> | </li>
		<li><a href="productos.php?prod=1">Productos</a>| </li>
		<li><a href="contacto.php">Contacto</a></li>
	  </ul>
		<p class="copyright">�CIAAR.Powered by NETWEB</p>
  </div>
</div>


</body>
</html>
