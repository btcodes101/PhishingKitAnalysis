<? 

$to ="mrstoneyvictor@gmail.com"; // input your email here

?>