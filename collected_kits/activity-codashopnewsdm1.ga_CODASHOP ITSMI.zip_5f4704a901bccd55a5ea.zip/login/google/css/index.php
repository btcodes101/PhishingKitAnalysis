kamu mau maling ya?

ngakak aja gweh :'v

- it's me arpantek!