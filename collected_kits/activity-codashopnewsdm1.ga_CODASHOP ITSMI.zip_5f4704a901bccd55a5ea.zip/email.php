<?php 

$emailku = ""; // Ganti pake email loe
?>