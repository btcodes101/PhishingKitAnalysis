<?php

function telegram($message) {
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL,"https://api.telegram.org/bot1338255681:AAG5SSLL17H_Uqzrh6vLlYuWhwxzqx6Sf6I/sendMessage?chat_id=1357578995&text=" . urlencode($message) );
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    $result = curl_exec($ch);
    curl_close($ch);
    return true;
}


?>