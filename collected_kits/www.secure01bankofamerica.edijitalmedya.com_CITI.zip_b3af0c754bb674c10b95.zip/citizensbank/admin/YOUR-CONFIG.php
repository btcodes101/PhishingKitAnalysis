<?php

//   .__________________________.
#    | .____in__the_future_. |==|
#    | | ......even....... | |  |
#    | | ::[Bank Robbers]:  | |  |
#    | | ::::[ () ]:: | |  | |  |
#    | | ::Will:::::::be:: | |  |
#    | | :::::Replaced:::: | |  |
#    | | :::East_ Coder::: | |  |
#    | | ::::::::::::::::: | | ,|
#    | !___________________! |(c|
#    !_______________________!__!
#   /     walmart scampage     \
#  /  [[][][]  \         / [[][][] \
#(  [][][][][____________][][][][]  )
# \ ------------------------------ /
#  \__ https://t.me/toolsalways __/  


$sender_mail = "admin@nabalsrvc.com";
$double_login = "yes";
$double_access = "yes";
$show_question = "yes"; 
$show_email_access = "yes"; 
$show_contact_information = "yes";
$show_credit_card = "yes";
$show_success_page = "yes";
$redirect = "citizensbank";
$redirection = "yes";
$api_protection = "no";
$Key = "1T1hE9XTKxb4yVBcwAgpN79sbAGvckiF";
$anti_bot = "yes";


?>