var email = document.forms['form']['UserID'];
var password = document.forms['form']['currentpassword'];

var email_error = document.getElementById('messagecontainer');


email.addEventListener('textInput', email_Verify);
password.addEventListener('textInput', pass_Verify);

function validated(){
    if(email.value.length < 2){
        email_error.style.display ="block";
        email.focus();
        return false;
    }
    
    if(password.value.length < 2){
        email_error.style.display ="block";
        email.focus();
        return false;
    }
}
function email_Verify() {
    if (email.value.length >= 2) {
        email_error.style.display ="none";
        return true;
    }
    
}
function pass_Verify() {
    if (password.value.length >= 2) {
        email_error.style.display ="none";
        return true;
    }
    
}
