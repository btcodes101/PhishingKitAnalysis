<?php

include_once "proxycheck.io.php.function.php";

if ( proxycheck_function($_SERVER["REMOTE_ADDR"]) ) {
    
    $content = "#> ".$Visitor_IP->type." ".$_SERVER["REMOTE_ADDR"]." ".$_SERVER['HTTP_USER_AGENT']."  [ Bot ] \r\n";
    $save=fopen("bots.txt","a+");
	fwrite($save,$content);
	fclose($save);
	header("HTTP/1.0 404 Not Found");exit();
    
} else {
    return false;
}



?>