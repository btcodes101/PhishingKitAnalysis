<?php

$config['apikey'] = 'YOUR_APIKEY';  // https://killbot.org/dashboard/developers