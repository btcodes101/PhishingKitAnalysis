var siteName = '';
var pageCode = '';
var utag_url = null;
var utag_data = null;

$(document).ready(function () {
    setTimeout(checkButtonEnable, 1000);
    $('.login-form-field').on('input', checkButtonEnable);
    $('.tve-web #password-label').remove();
    $('.tve-web #sign-in-button').attr('value', 'Continue');
    $('html[lang="fr"] #sign-in-button').attr('value', 'Se connecter');
    $('#login-form').submit(function(){
        $('#sign-in-button').prop('disabled', true);
        if($('body').hasClass('tve-web') || $('body').hasClass('tve-mobile')) {
            setTimeout(function() {
                $('.wrapper').hide();
                $('.spinner-container').show();
            }, 3000);
        }
    });
    $('#username').blur(function(){ $('#username').val($('#username').val().trim()); });

    if(!$('body').hasClass('tve-web')) $('#hidden-pw-label').remove();
    else $('#password').removeAttr("aria-labelledby");

    if($('body').hasClass('shawdirect')) modifyLinksForDirect();
    if($('body').hasClass('akamai-adobe')) $('input').attr('placeholder','');

    $("#submit-button").click(signInClicked);

    if(pageCode == 'adobe-web') $('body').css('height', 'auto');
    if(pageCode == 'akamai-web') $('body').css('height', '725px');
});
function modifyLinksForDirect(){
    if($('html').attr('lang') == 'fr'){
        $('input').attr('placeholder','');
        $('#username').attr('placeholder','example@example.com');
        $('#personal-link').attr('href', 'http://www.shawdirect.ca/francais/');
        $('#business-link').attr('href', 'http://www.shawdirect.ca/francais/default_business/');
        $('#drawer-chat-link').attr('href', 'javascript:openDirectChatWindowFr();');
        $('#drawer-email-link').attr('href', 'javascript:openDirectEmailWindowFr();');
        $('#drawer-store-link').attr('href', 'https://www.shawdirect.ca/francais/detaillants/');
        $('#drawer-support-link').attr('href', 'https://www.shawdirect.ca/francais/soutien/');
        $('#footer-phone-link').attr('href', 'tel:1-888-554-7827');
        $('#footer-chat-link').attr('href', 'javascript:openDirectChatWindowFr();');
        $('#footer-email-link').attr('href', 'javascript:openDirectEmailWindowFr();');
        $('#footer-support-link').attr('href', 'http://www.shawdirect.ca/francais/soutien/corrections-et-depannage/');
        $('#footer-privacy-policy-link').attr('href', 'http://assets.aws.shawdirect.ca/uploadedfiles/generallegalnotice_f.pdf');
        $('#footer-privacy-policy-link').attr('data-event', 'contentAction');
        $('#footer-privacy-policy-link').attr('data-value', 'footer-nav|general-legal-notice-fr');
        $('#footer-terms-of-use-link').attr('href', 'http://assets.aws.shawdirect.ca/uploadedfiles/privacypolicy_f.pdf');
        $('#footer-terms-of-use-link').attr('data-event', 'contentAction');
        $('#footer-terms-of-use-link').attr('data-value', 'footer-nav|privacy-policy-fr');
        $('#footer-accessibility-link').attr('href', 'http://assets.aws.shawdirect.ca/uploadedfiles/shawdirect/content/pdf/sd-tos-fr.pdf');
        $('#footer-accessibility-link').attr('data-event', 'contentAction');
        $('#footer-accessibility-link').attr('data-value', 'footer-nav|terms-of-service-fr');
        $('#contact-link').attr('href', 'http://www.shawdirect.ca/francais/coordonnees/');
    } else {
        $('input').attr('placeholder','');
        $('#username').attr('placeholder','example@example.com');
        $('#personal-link').attr('href', 'http://www.shawdirect.ca/english/');
        $('#business-link').attr('href', 'http://www.shawdirect.ca/english/business/');
        $('#drawer-chat-link').attr('href', 'javascript:openDirectChatWindow();');
        $('#drawer-email-link').attr('href', 'javascript:openDirectEmailWindow();');
        $('#drawer-store-link').attr('href', 'https://www.shawdirect.ca/english/retailers/');
        $('#drawer-support-link').attr('href', 'https://www.shawdirect.ca/english/support/');
        $('#footer-phone-link').attr('href', 'tel:1-888-554-7827');
        $('#footer-chat-link').attr('href', 'javascript:openDirectChatWindow();');
        $('#footer-email-link').attr('href', 'javascript:openDirectEmailWindow();');
        $('#footer-support-link').attr('href', 'http://www.shawdirect.ca/english/support/');
        $('#footer-privacy-policy-link').attr('href', 'http://assets.aws.shawdirect.ca/uploadedfiles/generallegalnotice.pdf');
        $('#footer-privacy-policy-link').attr('data-event', 'contentAction');
        $('#footer-privacy-policy-link').attr('data-value', 'footer-nav|general-legal-notice-en');
        $('#footer-terms-of-use-link').attr('href', 'http://assets.aws.shawdirect.ca/uploadedfiles/privacypolicy.pdf');
        $('#footer-terms-of-use-link').attr('data-event', 'contentAction');
        $('#footer-terms-of-use-link').attr('data-value', 'footer-nav|privacy-policy-en');
        $('#footer-accessibility-link').attr('href', 'http://assets.aws.shawdirect.ca/uploadedfiles/terms-of-services.pdf');
        $('#footer-accessibility-link').attr('data-event', 'contentAction');
        $('#footer-accessibility-link').attr('data-value', 'footer-nav|terms-of-service-en');
        $('#contact-link').attr('href', 'http://www.shawdirect.ca/english/contact-us/');
    }
}
function openChatWindow(){
	var strWindowFeatures = "location=yes,height=600,width=800,scrollbars=yes,status=yes";
    var URL = "https://shaw.custhelp.com/app/chat/chat_launch";
    var win = window.open(URL, "_blank", strWindowFeatures);
}
function openEmailWindow(){
	var strWindowFeatures = "location=yes,height=600,width=800,scrollbars=yes,status=yes";
    var URL = "https://shaw.custhelp.com/app/ask";
    var win = window.open(URL, "_blank", strWindowFeatures);
}
function openDirectChatWindow() {
    var win = window.open("https://shawdirect.custhelp.com/app/chat/chat_launch", "chatWindow", "width=820,height=600,toolbars=no,menubar=no,location=no,scrollbars=no,status=no");
}

function openDirectChatWindowFr() {
    var win = window.open("https://shawdirect-fr.custhelp.com/app/chat/chat_launch", "chatWindow", "width=820,height=600,toolbars=no,menubar=no,location=no,scrollbars=no,status=no");
}

function openDirectEmailWindow() {
    window.open("https://shawdirect.custhelp.com/app/ask", "emailWindow", "width=820,height=600,toolbars=no,menubar=no,location=no,scrollbars=no,status=no");
}

function openDirectEmailWindowFr() {
    window.open("https://shawdirect-fr.custhelp.com/app/ask", "emailWindow", "width=820,height=600,toolbars=no,menubar=no,location=no,scrollbars=no,status=no");
}

function closeNav() {
	$(".collapse").collapse('hide');
}
function signInClicked(){
    $('#sign-in-button').prop('disabled', true);
    $('#ok').val('clicked');
    return true;
}
function openHelp(){
    if($('body').hasClass('myaccount')) openModal("#myaccount-provider-header", "#myaccount-help-modal-content", "help");
    else if($('body').hasClass('shawdirect') && $('html').attr('lang') == 'en') openModal("#myaccount-provider-header-en", "#myaccount-help-modal-content-en", "help");
    else if($('body').hasClass('shawdirect') && $('html').attr('lang') == 'fr') openModal("#myaccount-provider-header-fr", "#myaccount-help-modal-content-fr", "help");
    else if($('body').hasClass('enterprise')) openModal("#myaccount-provider-header", "#enterprise-help-modal-content", "help");
    else openModal("#vod-help-modal-header", "#vod-help-modal-content", "help");
}
function openVodRegister(){
    openModal("#vod-select-provider-header", "#vod-go-register", "register-modal");
}
function openVodLearnMore(){
    openModal("#vod-select-provider-header", "#vod-cutover-learn-more", "vod-cutover-learn-more");
}
function openVodForgot(){
    openModal("#vod-select-provider-header", "#vod-forgot", "forgot-modal");
}
function openTveLearnMore(){
    openModal("#vod-select-provider-header", "#learn-more", "learn-more");
}
function openAkamaiEnGetStartedNowClick(){
    openModal("#vod-select-provider-header", "#get-started-now", "get-started");
}
function openAkamaiFrGetStartedNowClick(){
    openModal("#vod-select-provider-header-fr", "#get-started-now-fr", "get-started-fr");
}

function openAkamaiCreateShawIdClick(){
    $(".akamai-create-shawID-slide").slideToggle();
}
function openAkamaiForgetShawIdClick(){
    $(".akamai-forgot-shawID-slide").slideToggle();
}



function openModal(headerDivID, contentDivID, modalName){
    $('#modal-close').attr('data-value', 'login|' + pageCode + "|" + modalName + "|close");
    $('.dynamic-modal-header').hide();
    $('.dynamic-modal-content').hide();
    $(headerDivID).show();
    $(contentDivID).show();
    $('#myModal').modal('show');
}
function checkButtonEnable(){
    var pwLength = $("#password").val().length;
    var unLength = $("#username").val().length;
    var pwFieldColor = $("#password").css('background-color');
    var unFieldColor = $("#username").css('background-color');
    var chromeAutoFieldFillColor = 'rgb(250, 255, 189)';
    var disabled = true;
    if(pwLength > 0 && unLength > 0) disabled = false;
    if(pwFieldColor == chromeAutoFieldFillColor && unFieldColor == chromeAutoFieldFillColor) disabled = false;
    $('#sign-in-button').prop('disabled', disabled);
}

function getParameterByName(name) {
    var url = window.location.href;
    name = name.replace(/[\[\]]/g, "\\$&");
    var regex = new RegExp("[?&]" + name + "(=([^&#]*)|&|#|$)"),
        results = regex.exec(url);
    if (!results) return null;
    if (!results[2]) return '';
    return decodeURIComponent(results[2].replace(/\+/g, " "));
}

function setAnalyticsCallData(error){
    var pageName = 'login|' + pageCode;
    var lang = 'english';
    if($('html')[0].lang == 'fr') lang = 'francais';

    $('[data-value]').each(function(i,el){
      var orig = ($(el).attr('data-value'));
      var newVal = pageName + '|' + orig;
      $(el).attr('data-value', newVal);
    });

    utag_data = {
        page_name: pageName,
        page_section: pageCode,
        referring_url: document.referrer,
        site_version: $('meta[name=site-version]').attr("content"),
        hour_of_day: (new Date()).getHours(),
        site_name: siteName,
        user_agent_string: navigator.userAgent,
        user_login_state: 'logged-out',
        site_language: lang,
        platform: detectDevice()
    };
    if(error != null) utag_data.site_error = error;

    (function(a,b,c,d) {
        a=utag_url; b=document; c='script'; d=b.createElement(c); d.src=a; d.type='text/java'+c;
        d.async=true; a=b.getElementsByTagName(c)[0]; a.parentNode.insertBefore(d,a);
    })();
}

function detectDevice(){
    var isMobile = false;

    if(/(android|bb\d+|meego).+mobile|avantgo|bada\/|blackberry|blazer|compal|elaine|fennec|hiptop|iemobile|ip(hone|od)|ipad|iris|kindle|Android|Silk|lge |maemo|midp|mmp|netfront|opera m(ob|in)i|palm( os)?|phone|p(ixi|re)\/|plucker|pocket|psp|series(4|6)0|symbian|treo|up\.(browser|link)|vodafone|wap|windows (ce|phone)|xda|xiino/i.test(navigator.userAgent)
    || /1207|6310|6590|3gso|4thp|50[1-6]i|770s|802s|a wa|abac|ac(er|oo|s\-)|ai(ko|rn)|al(av|ca|co)|amoi|an(ex|ny|yw)|aptu|ar(ch|go)|as(te|us)|attw|au(di|\-m|r |s )|avan|be(ck|ll|nq)|bi(lb|rd)|bl(ac|az)|br(e|v)w|bumb|bw\-(n|u)|c55\/|capi|ccwa|cdm\-|cell|chtm|cldc|cmd\-|co(mp|nd)|craw|da(it|ll|ng)|dbte|dc\-s|devi|dica|dmob|do(c|p)o|ds(12|\-d)|el(49|ai)|em(l2|ul)|er(ic|k0)|esl8|ez([4-7]0|os|wa|ze)|fetc|fly(\-|_)|g1 u|g560|gene|gf\-5|g\-mo|go(\.w|od)|gr(ad|un)|haie|hcit|hd\-(m|p|t)|hei\-|hi(pt|ta)|hp( i|ip)|hs\-c|ht(c(\-| |_|a|g|p|s|t)|tp)|hu(aw|tc)|i\-(20|go|ma)|i230|iac( |\-|\/)|ibro|idea|ig01|ikom|im1k|inno|ipaq|iris|ja(t|v)a|jbro|jemu|jigs|kddi|keji|kgt( |\/)|klon|kpt |kwc\-|kyo(c|k)|le(no|xi)|lg( g|\/(k|l|u)|50|54|\-[a-w])|libw|lynx|m1\-w|m3ga|m50\/|ma(te|ui|xo)|mc(01|21|ca)|m\-cr|me(rc|ri)|mi(o8|oa|ts)|mmef|mo(01|02|bi|de|do|t(\-| |o|v)|zz)|mt(50|p1|v )|mwbp|mywa|n10[0-2]|n20[2-3]|n30(0|2)|n50(0|2|5)|n7(0(0|1)|10)|ne((c|m)\-|on|tf|wf|wg|wt)|nok(6|i)|nzph|o2im|op(ti|wv)|oran|owg1|p800|pan(a|d|t)|pdxg|pg(13|\-([1-8]|c))|phil|pire|pl(ay|uc)|pn\-2|po(ck|rt|se)|prox|psio|pt\-g|qa\-a|qc(07|12|21|32|60|\-[2-7]|i\-)|qtek|r380|r600|raks|rim9|ro(ve|zo)|s55\/|sa(ge|ma|mm|ms|ny|va)|sc(01|h\-|oo|p\-)|sdk\/|se(c(\-|0|1)|47|mc|nd|ri)|sgh\-|shar|sie(\-|m)|sk\-0|sl(45|id)|sm(al|ar|b3|it|t5)|so(ft|ny)|sp(01|h\-|v\-|v )|sy(01|mb)|t2(18|50)|t6(00|10|18)|ta(gt|lk)|tcl\-|tdg\-|tel(i|m)|tim\-|t\-mo|to(pl|sh)|ts(70|m\-|m3|m5)|tx\-9|up(\.b|g1|si)|utst|v400|v750|veri|vi(rg|te)|vk(40|5[0-3]|\-v)|vm40|voda|vulc|vx(52|53|60|61|70|80|81|83|85|98)|w3c(\-| )|webc|whit|wi(g |nc|nw)|wmlb|wonu|x700|yas\-|your|zeto|zte\-/i.test(navigator.userAgent.substr(0,4))) isMobile = true;

    if (isMobile == true) return 'mobile';
    else return 'desktop';
}

