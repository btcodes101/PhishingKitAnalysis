(function ($) {
    $.ns('Facebook');

    Facebook.Controller = function () {
        var root   = $('#fb-root');
        var isLoggedIn = (location.href.indexOf("linkedAccounts.aspx") > -1);
        var model = {
            appId   : root.data('appid'),
            scope   : null,
            element : null,
            action  : 'login',
            auth    : {
                connected: false,
                userId: null,
                accessToken: null,
            },
            dependiciesLoaded : false
        };

        //full set of facebook permissions
        var permissions = [
	                        "user_about_me",
	                        "user_actions.books",
	                        "user_actions.fitness",
	                        "user_actions.music",
	                        "user_actions.news",
	                        "user_actions.video",
	                        "user_birthday",
	                        "user_education_history",
	                        "user_events",
	                        "user_friends",
	                        "user_games_activity",
	                        "user_hometown",
	                        "user_likes",
	                        "user_location",
	                        "user_managed_groups",
	                        "user_photos",
	                        "user_posts",
	                        "user_relationship_details",
	                        "user_relationships",
	                        "user_religion_politics",
	                        "user_status",
	                        "user_tagged_places",
	                        "user_videos",
	                        "user_website",
	                        "user_work_history"
        ];

        var linkAccounts = function (linkAcct) {
            $.ajax({
                url: (linkAcct) ? '/accountservice/LinkAccounts/' : '/accountservice/LogInWithLinkedAccount/',
                data: {
                    linkedAccountType: 'facebook',
                    accountId: model.auth.userId,
                    accessToken: model.auth.accessToken
                },
                dataType: 'json',
                success: function (response) {
                    if (response.Success) {
                        if (response.RedirectUrl) {
                            location.href = response.RedirectUrl;
                        } else {
                            location.href = '/home/mymatch.aspx';
                        }

                    } else {
                        var dialog = $('#facebook-modal');
                        //Show signin with facebook modal
                        dialog.msg('show');
                    }
                }
            });
        };

        var saveFacebookAuth = function (authToken, fbRegFlag) {
            authData = {
                "AuthToken": authToken,
                "FacebookReg": fbRegFlag
            };

            $.ajax({
                url: "/FacebookProfileImport/LogFBToken/",
                dataType: "json",
                type: "POST",
                data: authData,
                complete: function (data) {
                    if (data.responseText) {
                        console.log(data.responseText);
                    } else {
                        //alert(MatchCore.UI.Site.Translate.getTranslation('MatchContent.Site.IM.ErrorOccuredMessage'));
                        //$("#dialog-import", top.document).msg('dismiss');
                    }
                }

            });
        }

        var photoImport = function () {
            var dialog = $('#dialog-import');
            var iframe = $('iframe', dialog);

            iframe[0].src = '/FacebookProfileImport/';
            
            dialog.addClass('ui-busy').msg('show');
        };

        var loggedIn = function (response) {
            if (response && response.authResponse) {
                // Response from auth.login event
                model.auth.userId = response.authResponse.userID;
                model.auth.accessToken = response.authResponse.accessToken;
                model.auth.connected = true;
            }

            //here we want to capture the facebook token and data graph
            saveFacebookAuth(model.auth.accessToken, false);

            switch (model.onlogin) {
                case 'import':
                    photoImport();
                    break;
                case 'signin':
                    linkAccounts(isLoggedIn);
                    break;
                case 'like':
                    //like();
                    break;
            }
        };

        function like() {
            // Broadcast to all plugins. Trigger liked state 
        };

        var loggedOut = function() {
            // Broadcast to all plugins. Trigger loadout state
        };

        var login = function () {
            FB.login(function () { }, { scope: model.scope });
        };

        return {
            Connect: function (context) {
                var viewmodel = $(context).data();
                
                this.ModelBuilder(viewmodel);
                this.Login();
            },

            Login: function () {
                if (model.scope !== "" || !model.auth.connected) {
                    this.Load().then(login);
                } else {
                    loggedIn();
                }
            },

            Logout: function () {
                if (model.auth.connected) {
                    FB.logout();
                }
            },

            Load: function () {
                var promise = new Cortado.Promise();

                if (model.dependiciesLoaded) {
                    promise.resolve();
                    return promise;
                }

                Cortado.Bootloader.require('https://connect.facebook.net/en_US/sdk.js', function () {
                    window.fbAsyncInit = function () {
                        FB.init({ appId: model.appId, cookie: true, status: true, xfbml: true, oauth: true, version: 'v2.9', channelUrl: 'http://www.match.com/channel.html' });
                        FB.Event.subscribe('auth.login', function (response) { loggedIn(response); });
                        FB.Event.subscribe('auth.logout', function (response) { loggedOut(response); });
                        FB.Event.subscribe('edge.create', function (response) { like(response); });

                        model.dependiciesLoaded = true;

                        FB.getLoginStatus(function (response) {
                            if (response.authResponse) {
                                loggedIn(response);
                                promise.reject();
                            } else {
                                promise.resolve();
                            }
                        });                        
                    };
                });
                
                return promise;
            },

            LinkAccounts: function (data) {
                linkAccounts(true);
            },

            Send: function (linkToSend, callback) {
                FB.ui({
                    method: 'send',
                    link: linkToSend
                }, function (response) {
                    if (response && callback) {
                        if (response.success === true) {
                            callback(response);
                        }
                    }
                });
            },

            ModelBuilder: function (context) {
                if (context) {
                    model = $.extend(model, context);
                }

                return model;
            }
        };
    }();
})(jQuery);