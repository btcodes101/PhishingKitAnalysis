(function() {
    this.MooTools = {
        version: '1.5.1',
        build: '0542c135fdeb7feed7d9917e01447a408f22c876'
    };
    var typeOf = this.typeOf = function(item) {
        if (item == null) return 'null';
        if (item.$family != null) return item.$family();
        if (item.nodeName) {
            if (item.nodeType == 1) return 'element';
            if (item.nodeType == 3) return (/\S/).test(item.nodeValue) ? 'textnode' : 'whitespace';
        } else if (typeof item.length == 'number') {
            if ('callee' in item) return 'arguments';
            if ('item' in item) return 'collection';
        }
        return typeof item;
    };
    var instanceOf = this.instanceOf = function(item, object) {
        if (item == null) return false;
        var constructor = item.$constructor || item.constructor;
        while (constructor) {
            if (constructor === object) return true;
            constructor = constructor.parent;
        }
        if (!item.hasOwnProperty) return false;
        return item instanceof object;
    };
    var Function = this.Function;
    var enumerables = true;
    for (var i in {
            toString: 1
        }) enumerables = null;
    if (enumerables) enumerables = ['hasOwnProperty', 'valueOf', 'isPrototypeOf', 'propertyIsEnumerable', 'toLocaleString', 'toString', 'constructor'];
    Function.prototype.overloadSetter = function(usePlural) {
        var self = this;
        return function(a, b) {
            if (a == null) return this;
            if (usePlural || typeof a != 'string') {
                for (var k in a) self.call(this, k, a[k]);
                if (enumerables)
                    for (var i = enumerables.length; i--;) {
                        k = enumerables[i];
                        if (a.hasOwnProperty(k)) self.call(this, k, a[k]);
                    }
            } else {
                self.call(this, a, b);
            }
            return this;
        };
    };
    Function.prototype.overloadGetter = function(usePlural) {
        var self = this;
        return function(a) {
            var args, result;
            if (typeof a != 'string') args = a;
            else if (arguments.length > 1) args = arguments;
            else if (usePlural) args = [a];
            if (args) {
                result = {};
                for (var i = 0; i < args.length; i++) result[args[i]] = self.call(this, args[i]);
            } else {
                result = self.call(this, a);
            }
            return result;
        };
    };
    Function.prototype.extend = function(key, value) {
        this[key] = value;
    }.overloadSetter();
    Function.prototype.implement = function(key, value) {
        this.prototype[key] = value;
    }.overloadSetter();
    var slice = Array.prototype.slice;
    Function.from = function(item) {
        return (typeOf(item) == 'function') ? item : function() {
            return item;
        };
    };
    Array.from = function(item) {
        if (item == null) return [];
        return (Type.isEnumerable(item) && typeof item != 'string') ? (typeOf(item) == 'array') ? item : slice.call(item) : [item];
    };
    Number.from = function(item) {
        var number = parseFloat(item);
        return isFinite(number) ? number : null;
    };
    String.from = function(item) {
        return item + '';
    };
    Function.implement({
        hide: function() {
            this.$hidden = true;
            return this;
        },
        protect: function() {
            this.$protected = true;
            return this;
        }
    });
    var Type = this.Type = function(name, object) {
        if (name) {
            var lower = name.toLowerCase();
            var typeCheck = function(item) {
                return (typeOf(item) == lower);
            };
            Type['is' + name] = typeCheck;
            if (object != null) {
                object.prototype.$family = (function() {
                    return lower;
                }).hide();
                object.type = typeCheck;
            }
        }
        if (object == null) return null;
        object.extend(this);
        object.$constructor = Type;
        object.prototype.$constructor = object;
        return object;
    };
    var toString = Object.prototype.toString;
    Type.isEnumerable = function(item) {
        return (item != null && typeof item.length == 'number' && toString.call(item) != '[object Function]');
    };
    var hooks = {};
    var hooksOf = function(object) {
        var type = typeOf(object.prototype);
        return hooks[type] || (hooks[type] = []);
    };
    var implement = function(name, method) {
        if (method && method.$hidden) return;
        var hooks = hooksOf(this);
        for (var i = 0; i < hooks.length; i++) {
            var hook = hooks[i];
            if (typeOf(hook) == 'type') implement.call(hook, name, method);
            else hook.call(this, name, method);
        }
        var previous = this.prototype[name];
        if (previous == null || !previous.$protected) this.prototype[name] = method;
        if (this[name] == null && typeOf(method) == 'function') extend.call(this, name, function(item) {
            return method.apply(item, slice.call(arguments, 1));
        });
    };
    var extend = function(name, method) {
        if (method && method.$hidden) return;
        var previous = this[name];
        if (previous == null || !previous.$protected) this[name] = method;
    };
    Type.implement({
        implement: implement.overloadSetter(),
        extend: extend.overloadSetter(),
        alias: function(name, existing) {
            implement.call(this, name, this.prototype[existing]);
        }.overloadSetter(),
        mirror: function(hook) {
            hooksOf(this).push(hook);
            return this;
        }
    });
    new Type('Type', Type);
    var force = function(name, object, methods) {
        var isType = (object != Object),
            prototype = object.prototype;
        if (isType) object = new Type(name, object);
        for (var i = 0, l = methods.length; i < l; i++) {
            var key = methods[i],
                generic = object[key],
                proto = prototype[key];
            if (generic) generic.protect();
            if (isType && proto) object.implement(key, proto.protect());
        }
        if (isType) {
            var methodsEnumerable = prototype.propertyIsEnumerable(methods[0]);
            object.forEachMethod = function(fn) {
                if (!methodsEnumerable)
                    for (var i = 0, l = methods.length; i < l; i++) {
                        fn.call(prototype, prototype[methods[i]], methods[i]);
                    }
                for (var key in prototype) fn.call(prototype, prototype[key], key);
            };
        }
        return force;
    };
    force('String', String, ['charAt', 'charCodeAt', 'concat', 'contains', 'indexOf', 'lastIndexOf', 'match', 'quote', 'replace', 'search', 'slice', 'split', 'substr', 'substring', 'trim', 'toLowerCase', 'toUpperCase'])('Array', Array, ['pop', 'push', 'reverse', 'shift', 'sort', 'splice', 'unshift', 'concat', 'join', 'slice', 'indexOf', 'lastIndexOf', 'filter', 'forEach', 'every', 'map', 'some', 'reduce', 'reduceRight'])('Number', Number, ['toExponential', 'toFixed', 'toLocaleString', 'toPrecision'])('Function', Function, ['apply', 'call', 'bind'])('RegExp', RegExp, ['exec', 'test'])('Object', Object, ['create', 'defineProperty', 'defineProperties', 'keys', 'getPrototypeOf', 'getOwnPropertyDescriptor', 'getOwnPropertyNames', 'preventExtensions', 'isExtensible', 'seal', 'isSealed', 'freeze', 'isFrozen'])('Date', Date, ['now']);
    Object.extend = extend.overloadSetter();
    Date.extend('now', function() {
        return +(new Date);
    });
    new Type('Boolean', Boolean);
    Number.prototype.$family = function() {
        return isFinite(this) ? 'number' : 'null';
    }.hide();
    Number.extend('random', function(min, max) {
        return Math.floor(Math.random() * (max - min + 1) + min);
    });
    var hasOwnProperty = Object.prototype.hasOwnProperty;
    Object.extend('forEach', function(object, fn, bind) {
        for (var key in object) {
            if (hasOwnProperty.call(object, key)) fn.call(bind, object[key], key, object);
        }
    });
    Object.each = Object.forEach;
    Array.implement({
        forEach: function(fn, bind) {
            for (var i = 0, l = this.length; i < l; i++) {
                if (i in this) fn.call(bind, this[i], i, this);
            }
        },
        each: function(fn, bind) {
            Array.forEach(this, fn, bind);
            return this;
        }
    });
    var cloneOf = function(item) {
        switch (typeOf(item)) {
            case 'array':
                return item.clone();
            case 'object':
                return Object.clone(item);
            default:
                return item;
        }
    };
    Array.implement('clone', function() {
        var i = this.length,
            clone = new Array(i);
        while (i--) clone[i] = cloneOf(this[i]);
        return clone;
    });
    var mergeOne = function(source, key, current) {
        switch (typeOf(current)) {
            case 'object':
                if (typeOf(source[key]) == 'object') Object.merge(source[key], current);
                else source[key] = Object.clone(current);
                break;
            case 'array':
                source[key] = current.clone();
                break;
            default:
                source[key] = current;
        }
        return source;
    };
    Object.extend({
        merge: function(source, k, v) {
            if (typeOf(k) == 'string') return mergeOne(source, k, v);
            for (var i = 1, l = arguments.length; i < l; i++) {
                var object = arguments[i];
                for (var key in object) mergeOne(source, key, object[key]);
            }
            return source;
        },
        clone: function(object) {
            var clone = {};
            for (var key in object) clone[key] = cloneOf(object[key]);
            return clone;
        },
        append: function(original) {
            for (var i = 1, l = arguments.length; i < l; i++) {
                var extended = arguments[i] || {};
                for (var key in extended) original[key] = extended[key];
            }
            return original;
        }
    });
    ['Object', 'WhiteSpace', 'TextNode', 'Collection', 'Arguments'].each(function(name) {
        new Type(name);
    });
    var UID = Date.now();
    String.extend('uniqueID', function() {
        return (UID++).toString(36);
    });
    var Hash = this.Hash = new Type('Hash', function(object) {
        if (typeOf(object) == 'hash') object = Object.clone(object.getClean());
        for (var key in object) this[key] = object[key];
        return this;
    });
    Hash.implement({
        forEach: function(fn, bind) {
            Object.forEach(this, fn, bind);
        },
        getClean: function() {
            var clean = {};
            for (var key in this) {
                if (this.hasOwnProperty(key)) clean[key] = this[key];
            }
            return clean;
        },
        getLength: function() {
            var length = 0;
            for (var key in this) {
                if (this.hasOwnProperty(key)) length++;
            }
            return length;
        }
    });
    Hash.alias('each', 'forEach');
    Object.type = Type.isObject;
    var Native = this.Native = function(properties) {
        return new Type(properties.name, properties.initialize);
    };
    Native.type = Type.type;
    Native.implement = function(objects, methods) {
        for (var i = 0; i < objects.length; i++) objects[i].implement(methods);
        return Native;
    };
    var arrayType = Array.type;
    Array.type = function(item) {
        return instanceOf(item, Array) || arrayType(item);
    };
    this.$A = function(item) {
        return Array.from(item).slice();
    };
    this.$arguments = function(i) {
        return function() {
            return arguments[i];
        };
    };
    this.$chk = function(obj) {
        return !!(obj || obj === 0);
    };
    this.$clear = function(timer) {
        clearTimeout(timer);
        clearInterval(timer);
        return null;
    };
    this.$defined = function(obj) {
        return (obj != null);
    };
    this.$each = function(iterable, fn, bind) {
        var type = typeOf(iterable);
        ((type == 'arguments' || type == 'collection' || type == 'array' || type == 'elements') ? Array : Object).each(iterable, fn, bind);
    };
    this.$empty = function() {};
    this.$extend = function(original, extended) {
        return Object.append(original, extended);
    };
    this.$H = function(object) {
        return new Hash(object);
    };
    this.$merge = function() {
        var args = Array.slice(arguments);
        args.unshift({});
        return Object.merge.apply(null, args);
    };
    this.$lambda = Function.from;
    this.$mixin = Object.merge;
    this.$random = Number.random;
    this.$splat = Array.from;
    this.$time = Date.now;
    this.$type = function(object) {
        var type = typeOf(object);
        if (type == 'elements') return 'array';
        return (type == 'null') ? false : type;
    };
    this.$unlink = function(object) {
        switch (typeOf(object)) {
            case 'object':
                return Object.clone(object);
            case 'array':
                return Array.clone(object);
            case 'hash':
                return new Hash(object);
            default:
                return object;
        }
    };
})();
Array.implement({
    every: function(fn, bind) {
        for (var i = 0, l = this.length >>> 0; i < l; i++) {
            if ((i in this) && !fn.call(bind, this[i], i, this)) return false;
        }
        return true;
    },
    filter: function(fn, bind) {
        var results = [];
        for (var value, i = 0, l = this.length >>> 0; i < l; i++)
            if (i in this) {
                value = this[i];
                if (fn.call(bind, value, i, this)) results.push(value);
            }
        return results;
    },
    indexOf: function(item, from) {
        var length = this.length >>> 0;
        for (var i = (from < 0) ? Math.max(0, length + from) : from || 0; i < length; i++) {
            if (this[i] === item) return i;
        }
        return -1;
    },
    map: function(fn, bind) {
        var length = this.length >>> 0,
            results = Array(length);
        for (var i = 0; i < length; i++) {
            if (i in this) results[i] = fn.call(bind, this[i], i, this);
        }
        return results;
    },
    some: function(fn, bind) {
        for (var i = 0, l = this.length >>> 0; i < l; i++) {
            if ((i in this) && fn.call(bind, this[i], i, this)) return true;
        }
        return false;
    },
    clean: function() {
        return this.filter(function(item) {
            return item != null;
        });
    },
    invoke: function(methodName) {
        var args = Array.slice(arguments, 1);
        return this.map(function(item) {
            return item[methodName].apply(item, args);
        });
    },
    associate: function(keys) {
        var obj = {},
            length = Math.min(this.length, keys.length);
        for (var i = 0; i < length; i++) obj[keys[i]] = this[i];
        return obj;
    },
    link: function(object) {
        var result = {};
        for (var i = 0, l = this.length; i < l; i++) {
            for (var key in object) {
                if (object[key](this[i])) {
                    result[key] = this[i];
                    delete object[key];
                    break;
                }
            }
        }
        return result;
    },
    contains: function(item, from) {
        return this.indexOf(item, from) != -1;
    },
    append: function(array) {
        this.push.apply(this, array);
        return this;
    },
    getLast: function() {
        return (this.length) ? this[this.length - 1] : null;
    },
    getRandom: function() {
        return (this.length) ? this[Number.random(0, this.length - 1)] : null;
    },
    include: function(item) {
        if (!this.contains(item)) this.push(item);
        return this;
    },
    combine: function(array) {
        for (var i = 0, l = array.length; i < l; i++) this.include(array[i]);
        return this;
    },
    erase: function(item) {
        for (var i = this.length; i--;) {
            if (this[i] === item) this.splice(i, 1);
        }
        return this;
    },
    empty: function() {
        this.length = 0;
        return this;
    },
    flatten: function() {
        var array = [];
        for (var i = 0, l = this.length; i < l; i++) {
            var type = typeOf(this[i]);
            if (type == 'null') continue;
            array = array.concat((type == 'array' || type == 'collection' || type == 'arguments' || instanceOf(this[i], Array)) ? Array.flatten(this[i]) : this[i]);
        }
        return array;
    },
    pick: function() {
        for (var i = 0, l = this.length; i < l; i++) {
            if (this[i] != null) return this[i];
        }
        return null;
    },
    hexToRgb: function(array) {
        if (this.length != 3) return null;
        var rgb = this.map(function(value) {
            if (value.length == 1) value += value;
            return parseInt(value, 16);
        });
        return (array) ? rgb : 'rgb(' + rgb + ')';
    },
    rgbToHex: function(array) {
        if (this.length < 3) return null;
        if (this.length == 4 && this[3] == 0 && !array) return 'transparent';
        var hex = [];
        for (var i = 0; i < 3; i++) {
            var bit = (this[i] - 0).toString(16);
            hex.push((bit.length == 1) ? '0' + bit : bit);
        }
        return (array) ? hex : '#' + hex.join('');
    }
});
Array.alias('extend', 'append');
var $pick = function() {
    return Array.from(arguments).pick();
};
String.implement({
    contains: function(string, index) {
        return (index ? String(this).slice(index) : String(this)).indexOf(string) > -1;
    },
    test: function(regex, params) {
        return ((typeOf(regex) == 'regexp') ? regex : new RegExp('' + regex, params)).test(this);
    },
    trim: function() {
        return String(this).replace(/^\s+|\s+$/g, '');
    },
    clean: function() {
        return String(this).replace(/\s+/g, ' ').trim();
    },
    camelCase: function() {
        return String(this).replace(/-\D/g, function(match) {
            return match.charAt(1).toUpperCase();
        });
    },
    hyphenate: function() {
        return String(this).replace(/[A-Z]/g, function(match) {
            return ('-' + match.charAt(0).toLowerCase());
        });
    },
    capitalize: function() {
        return String(this).replace(/\b[a-z]/g, function(match) {
            return match.toUpperCase();
        });
    },
    escapeRegExp: function() {
        return String(this).replace(/([-.*+?^${}()|[\]\/\\])/g, '\\$1');
    },
    toInt: function(base) {
        return parseInt(this, base || 10);
    },
    toFloat: function() {
        return parseFloat(this);
    },
    hexToRgb: function(array) {
        var hex = String(this).match(/^#?(\w{1,2})(\w{1,2})(\w{1,2})$/);
        return (hex) ? hex.slice(1).hexToRgb(array) : null;
    },
    rgbToHex: function(array) {
        var rgb = String(this).match(/\d{1,3}/g);
        return (rgb) ? rgb.rgbToHex(array) : null;
    },
    substitute: function(object, regexp) {
        return String(this).replace(regexp || (/\\?\{([^{}]+)\}/g), function(match, name) {
            if (match.charAt(0) == '\\') return match.slice(1);
            return (object[name] != null) ? object[name] : '';
        });
    }
});
String.prototype.contains = function(string, separator) {
    return (separator) ? (separator + this + separator).indexOf(separator + string + separator) > -1 : String(this).indexOf(string) > -1;
};
Number.implement({
    limit: function(min, max) {
        return Math.min(max, Math.max(min, this));
    },
    round: function(precision) {
        precision = Math.pow(10, precision || 0).toFixed(precision < 0 ? -precision : 0);
        return Math.round(this * precision) / precision;
    },
    times: function(fn, bind) {
        for (var i = 0; i < this; i++) fn.call(bind, i, this);
    },
    toFloat: function() {
        return parseFloat(this);
    },
    toInt: function(base) {
        return parseInt(this, base || 10);
    }
});
Number.alias('each', 'times');
(function(math) {
    var methods = {};
    math.each(function(name) {
        if (!Number[name]) methods[name] = function() {
            return Math[name].apply(null, [this].concat(Array.from(arguments)));
        };
    });
    Number.implement(methods);
})(['abs', 'acos', 'asin', 'atan', 'atan2', 'ceil', 'cos', 'exp', 'floor', 'log', 'max', 'min', 'pow', 'sin', 'sqrt', 'tan']);
Function.extend({
    attempt: function() {
        for (var i = 0, l = arguments.length; i < l; i++) {
            try {
                return arguments[i]();
            } catch (e) {}
        }
        return null;
    }
});
Function.implement({
    attempt: function(args, bind) {
        try {
            return this.apply(bind, Array.from(args));
        } catch (e) {}
        return null;
    },
    bind: function(that) {
        var self = this,
            args = arguments.length > 1 ? Array.slice(arguments, 1) : null,
            F = function() {};
        var bound = function() {
            var context = that,
                length = arguments.length;
            if (this instanceof bound) {
                F.prototype = self.prototype;
                context = new F;
            }
            var result = (!args && !length) ? self.call(context) : self.apply(context, args && length ? args.concat(Array.slice(arguments)) : args || arguments);
            return context == that ? result : context;
        };
        return bound;
    },
    pass: function(args, bind) {
        var self = this;
        if (args != null) args = Array.from(args);
        return function() {
            return self.apply(bind, args || arguments);
        };
    },
    delay: function(delay, bind, args) {
        return setTimeout(this.pass((args == null ? [] : args), bind), delay);
    },
    periodical: function(periodical, bind, args) {
        return setInterval(this.pass((args == null ? [] : args), bind), periodical);
    }
});
delete Function.prototype.bind;
Function.implement({
    create: function(options) {
        var self = this;
        options = options || {};
        return function(event) {
            var args = options.arguments;
            args = (args != null) ? Array.from(args) : Array.slice(arguments, (options.event) ? 1 : 0);
            if (options.event) args = [event || window.event].extend(args);
            var returns = function() {
                return self.apply(options.bind || null, args);
            };
            if (options.delay) return setTimeout(returns, options.delay);
            if (options.periodical) return setInterval(returns, options.periodical);
            if (options.attempt) return Function.attempt(returns);
            return returns();
        };
    },
    bind: function(bind, args) {
        var self = this;
        if (args != null) args = Array.from(args);
        return function() {
            return self.apply(bind, args || arguments);
        };
    },
    bindWithEvent: function(bind, args) {
        var self = this;
        if (args != null) args = Array.from(args);
        return function(event) {
            return self.apply(bind, (args == null) ? arguments : [event].concat(args));
        };
    },
    run: function(args, bind) {
        return this.apply(bind, Array.from(args));
    }
});
if (Object.create == Function.prototype.create) Object.create = null;
var $try = Function.attempt;
(function() {
    var hasOwnProperty = Object.prototype.hasOwnProperty;
    Object.extend({
        subset: function(object, keys) {
            var results = {};
            for (var i = 0, l = keys.length; i < l; i++) {
                var k = keys[i];
                if (k in object) results[k] = object[k];
            }
            return results;
        },
        map: function(object, fn, bind) {
            var results = {};
            for (var key in object) {
                if (hasOwnProperty.call(object, key)) results[key] = fn.call(bind, object[key], key, object);
            }
            return results;
        },
        filter: function(object, fn, bind) {
            var results = {};
            for (var key in object) {
                var value = object[key];
                if (hasOwnProperty.call(object, key) && fn.call(bind, value, key, object)) results[key] = value;
            }
            return results;
        },
        every: function(object, fn, bind) {
            for (var key in object) {
                if (hasOwnProperty.call(object, key) && !fn.call(bind, object[key], key)) return false;
            }
            return true;
        },
        some: function(object, fn, bind) {
            for (var key in object) {
                if (hasOwnProperty.call(object, key) && fn.call(bind, object[key], key)) return true;
            }
            return false;
        },
        keys: function(object) {
            var keys = [];
            for (var key in object) {
                if (hasOwnProperty.call(object, key)) keys.push(key);
            }
            return keys;
        },
        values: function(object) {
            var values = [];
            for (var key in object) {
                if (hasOwnProperty.call(object, key)) values.push(object[key]);
            }
            return values;
        },
        getLength: function(object) {
            return Object.keys(object).length;
        },
        keyOf: function(object, value) {
            for (var key in object) {
                if (hasOwnProperty.call(object, key) && object[key] === value) return key;
            }
            return null;
        },
        contains: function(object, value) {
            return Object.keyOf(object, value) != null;
        },
        toQueryString: function(object, base) {
            var queryString = [];
            Object.each(object, function(value, key) {
                if (base) key = base + '[' + key + ']';
                var result;
                switch (typeOf(value)) {
                    case 'object':
                        result = Object.toQueryString(value, key);
                        break;
                    case 'array':
                        var qs = {};
                        value.each(function(val, i) {
                            qs[i] = val;
                        });
                        result = Object.toQueryString(qs, key);
                        break;
                    default:
                        result = key + '=' + encodeURIComponent(value);
                }
                if (value != null) queryString.push(result);
            });
            return queryString.join('&');
        }
    });
})();
Hash.implement({
    has: Object.prototype.hasOwnProperty,
    keyOf: function(value) {
        return Object.keyOf(this, value);
    },
    hasValue: function(value) {
        return Object.contains(this, value);
    },
    extend: function(properties) {
        Hash.each(properties || {}, function(value, key) {
            Hash.set(this, key, value);
        }, this);
        return this;
    },
    combine: function(properties) {
        Hash.each(properties || {}, function(value, key) {
            Hash.include(this, key, value);
        }, this);
        return this;
    },
    erase: function(key) {
        if (this.hasOwnProperty(key)) delete this[key];
        return this;
    },
    get: function(key) {
        return (this.hasOwnProperty(key)) ? this[key] : null;
    },
    set: function(key, value) {
        if (!this[key] || this.hasOwnProperty(key)) this[key] = value;
        return this;
    },
    empty: function() {
        Hash.each(this, function(value, key) {
            delete this[key];
        }, this);
        return this;
    },
    include: function(key, value) {
        if (this[key] == null) this[key] = value;
        return this;
    },
    map: function(fn, bind) {
        return new Hash(Object.map(this, fn, bind));
    },
    filter: function(fn, bind) {
        return new Hash(Object.filter(this, fn, bind));
    },
    every: function(fn, bind) {
        return Object.every(this, fn, bind);
    },
    some: function(fn, bind) {
        return Object.some(this, fn, bind);
    },
    getKeys: function() {
        return Object.keys(this);
    },
    getValues: function() {
        return Object.values(this);
    },
    toQueryString: function(base) {
        return Object.toQueryString(this, base);
    }
});
Hash.extend = Object.append;
Hash.alias({
    indexOf: 'keyOf',
    contains: 'hasValue'
});
(function() {
    var document = this.document;
    var window = document.window = this;
    var parse = function(ua, platform) {
        ua = ua.toLowerCase();
        platform = (platform ? platform.toLowerCase() : '');
        var UA = ua.match(/(opera|ie|firefox|chrome|trident|crios|version)[\s\/:]([\w\d\.]+)?.*?(safari|(?:rv[\s\/:]|version[\s\/:])([\w\d\.]+)|$)/) || [null, 'unknown', 0];
        if (UA[1] == 'trident') {
            UA[1] = 'ie';
            if (UA[4]) UA[2] = UA[4];
        } else if (UA[1] == 'crios') {
            UA[1] = 'chrome';
        }
        platform = ua.match(/ip(?:ad|od|hone)/) ? 'ios' : (ua.match(/(?:webos|android)/) || platform.match(/mac|win|linux/) || ['other'])[0];
        if (platform == 'win') platform = 'windows';
        return {
            extend: Function.prototype.extend,
            name: (UA[1] == 'version') ? UA[3] : UA[1],
            version: parseFloat((UA[1] == 'opera' && UA[4]) ? UA[4] : UA[2]),
            platform: platform
        };
    };
    var Browser = this.Browser = parse(navigator.userAgent, navigator.platform);
    if (Browser.name == 'ie') {
        Browser.version = document.documentMode;
    }
    Browser.extend({
        Features: {
            xpath: !!(document.evaluate),
            air: !!(window.runtime),
            query: !!(document.querySelector),
            json: !!(window.JSON)
        },
        parseUA: parse
    });
    Browser[Browser.name] = true;
    Browser[Browser.name + parseInt(Browser.version, 10)] = true;
    if (Browser.name == 'ie' && Browser.version >= '11') {
        delete Browser.ie;
    }
    var platform = Browser.platform;
    if (platform == 'windows') {
        platform = 'win';
    }
    Browser.Platform = {
        name: platform
    };
    Browser.Platform[platform] = true;
    Browser.Request = (function() {
        var XMLHTTP = function() {
            return new XMLHttpRequest();
        };
        var MSXML2 = function() {
            return new ActiveXObject('MSXML2.XMLHTTP');
        };
        var MSXML = function() {
            return new ActiveXObject('Microsoft.XMLHTTP');
        };
        return Function.attempt(function() {
            XMLHTTP();
            return XMLHTTP;
        }, function() {
            MSXML2();
            return MSXML2;
        }, function() {
            MSXML();
            return MSXML;
        });
    })();
    Browser.Features.xhr = !!(Browser.Request);
    var version = (Function.attempt(function() {
        return navigator.plugins['Shockwave Flash'].description;
    }, function() {
        return new ActiveXObject('ShockwaveFlash.ShockwaveFlash').GetVariable('$version');
    }) || '0 r0').match(/\d+/g);
    Browser.Plugins = {
        Flash: {
            version: Number(version[0] || '0.' + version[1]) || 0,
            build: Number(version[2]) || 0
        }
    };
    Browser.exec = function(text) {
        if (!text) return text;
        if (window.execScript) {
            window.execScript(text);
        } else {
            var script = document.createElement('script');
            script.setAttribute('type', 'text/javascript');
            script.text = text;
            document.head.appendChild(script);
            document.head.removeChild(script);
        }
        return text;
    };
    String.implement('stripScripts', function(exec) {
        var scripts = '';
        var text = this.replace(/<script[^>]*>([\s\S]*?)<\/script>/gi, function(all, code) {
            scripts += code + '\n';
            return '';
        });
        if (exec === true) Browser.exec(scripts);
        else if (typeOf(exec) == 'function') exec(scripts, text);
        return text;
    });
    Browser.extend({
        Document: this.Document,
        Window: this.Window,
        Element: this.Element,
        Event: this.Event
    });
    this.Window = this.$constructor = new Type('Window', function() {});
    this.$family = Function.from('window').hide();
    Window.mirror(function(name, method) {
        window[name] = method;
    });
    this.Document = document.$constructor = new Type('Document', function() {});
    document.$family = Function.from('document').hide();
    Document.mirror(function(name, method) {
        document[name] = method;
    });
    document.html = document.documentElement;
    if (!document.head) document.head = document.getElementsByTagName('head')[0];
    if (document.execCommand) try {
        document.execCommand("BackgroundImageCache", false, true);
    } catch (e) {}
    if (this.attachEvent && !this.addEventListener) {
        var unloadEvent = function() {
            this.detachEvent('onunload', unloadEvent);
            document.head = document.html = document.window = null;
            window = this.Window = document = null;
        };
        this.attachEvent('onunload', unloadEvent);
    }
    var arrayFrom = Array.from;
    try {
        arrayFrom(document.html.childNodes);
    } catch (e) {
        Array.from = function(item) {
            if (typeof item != 'string' && Type.isEnumerable(item) && typeOf(item) != 'array') {
                var i = item.length,
                    array = new Array(i);
                while (i--) array[i] = item[i];
                return array;
            }
            return arrayFrom(item);
        };
        var prototype = Array.prototype,
            slice = prototype.slice;
        ['pop', 'push', 'reverse', 'shift', 'sort', 'splice', 'unshift', 'concat', 'join', 'slice'].each(function(name) {
            var method = prototype[name];
            Array[name] = function(item) {
                return method.apply(Array.from(item), slice.call(arguments, 1));
            };
        });
    }
    if (Browser.Platform.ios) Browser.Platform.ipod = true;
    Browser.Engine = {};
    var setEngine = function(name, version) {
        Browser.Engine.name = name;
        Browser.Engine[name + version] = true;
        Browser.Engine.version = version;
    };
    if (Browser.ie) {
        Browser.Engine.trident = true;
        switch (Browser.version) {
            case 6:
                setEngine('trident', 4);
                break;
            case 7:
                setEngine('trident', 5);
                break;
            case 8:
                setEngine('trident', 6);
        }
    }
    if (Browser.firefox) {
        Browser.Engine.gecko = true;
        if (Browser.version >= 3) setEngine('gecko', 19);
        else setEngine('gecko', 18);
    }
    if (Browser.safari || Browser.chrome) {
        Browser.Engine.webkit = true;
        switch (Browser.version) {
            case 2:
                setEngine('webkit', 419);
                break;
            case 3:
                setEngine('webkit', 420);
                break;
            case 4:
                setEngine('webkit', 525);
        }
    }
    if (Browser.opera) {
        Browser.Engine.presto = true;
        if (Browser.version >= 9.6) setEngine('presto', 960);
        else if (Browser.version >= 9.5) setEngine('presto', 950);
        else setEngine('presto', 925);
    }
    if (Browser.name == 'unknown') {
        switch ((navigator.userAgent.toLowerCase().match(/(?:webkit|khtml|gecko)/) || [])[0]) {
            case 'webkit':
            case 'khtml':
                Browser.Engine.webkit = true;
                break;
            case 'gecko':
                Browser.Engine.gecko = true;
        }
    }
    this.$exec = Browser.exec;
})();
(function() {
    var _keys = {};
    var normalizeWheelSpeed = function(event) {
        var normalized;
        if (event.wheelDelta) {
            normalized = event.wheelDelta % 120 == 0 ? event.wheelDelta / 120 : event.wheelDelta / 12;
        } else {
            var rawAmount = event.deltaY || event.detail || 0;
            normalized = -(rawAmount % 3 == 0 ? rawAmount / 3 : rawAmount * 10);
        }
        return normalized;
    }
    var DOMEvent = this.DOMEvent = new Type('DOMEvent', function(event, win) {
        if (!win) win = window;
        event = event || win.event;
        if (event.$extended) return event;
        this.event = event;
        this.$extended = true;
        this.shift = event.shiftKey;
        this.control = event.ctrlKey;
        this.alt = event.altKey;
        this.meta = event.metaKey;
        var type = this.type = event.type;
        var target = event.target || event.srcElement;
        while (target && target.nodeType == 3) target = target.parentNode;
        this.target = document.id(target);
        if (type.indexOf('key') == 0) {
            var code = this.code = (event.which || event.keyCode);
            this.key = _keys[code] || Object.keyOf(Event.Keys, code);
            if (type == 'keydown' || type == 'keyup') {
                if (code > 111 && code < 124) this.key = 'f' + (code - 111);
                else if (code > 95 && code < 106) this.key = code - 96;
            }
            if (this.key == null) this.key = String.fromCharCode(code).toLowerCase();
        } else if (type == 'click' || type == 'dblclick' || type == 'contextmenu' || type == 'wheel' || type == 'DOMMouseScroll' || type.indexOf('mouse') == 0) {
            var doc = win.document;
            doc = (!doc.compatMode || doc.compatMode == 'CSS1Compat') ? doc.html : doc.body;
            this.page = {
                x: (event.pageX != null) ? event.pageX : event.clientX + doc.scrollLeft,
                y: (event.pageY != null) ? event.pageY : event.clientY + doc.scrollTop
            };
            this.client = {
                x: (event.pageX != null) ? event.pageX - win.pageXOffset : event.clientX,
                y: (event.pageY != null) ? event.pageY - win.pageYOffset : event.clientY
            };
            if (type == 'DOMMouseScroll' || type == 'wheel' || type == 'mousewheel') this.wheel = normalizeWheelSpeed(event);
            this.rightClick = (event.which == 3 || event.button == 2);
            if (type == 'mouseover' || type == 'mouseout') {
                var related = event.relatedTarget || event[(type == 'mouseover' ? 'from' : 'to') + 'Element'];
                while (related && related.nodeType == 3) related = related.parentNode;
                this.relatedTarget = document.id(related);
            }
        } else if (type.indexOf('touch') == 0 || type.indexOf('gesture') == 0) {
            this.rotation = event.rotation;
            this.scale = event.scale;
            this.targetTouches = event.targetTouches;
            this.changedTouches = event.changedTouches;
            var touches = this.touches = event.touches;
            if (touches && touches[0]) {
                var touch = touches[0];
                this.page = {
                    x: touch.pageX,
                    y: touch.pageY
                };
                this.client = {
                    x: touch.clientX,
                    y: touch.clientY
                };
            }
        }
        if (!this.client) this.client = {};
        if (!this.page) this.page = {};
    });
    DOMEvent.implement({
        stop: function() {
            return this.preventDefault().stopPropagation();
        },
        stopPropagation: function() {
            if (this.event.stopPropagation) this.event.stopPropagation();
            else this.event.cancelBubble = true;
            return this;
        },
        preventDefault: function() {
            if (this.event.preventDefault) this.event.preventDefault();
            else this.event.returnValue = false;
            return this;
        }
    });
    DOMEvent.defineKey = function(code, key) {
        _keys[code] = key;
        return this;
    };
    DOMEvent.defineKeys = DOMEvent.defineKey.overloadSetter(true);
    DOMEvent.defineKeys({
        '38': 'up',
        '40': 'down',
        '37': 'left',
        '39': 'right',
        '27': 'esc',
        '32': 'space',
        '8': 'backspace',
        '9': 'tab',
        '46': 'delete',
        '13': 'enter'
    });
})();
var Event = DOMEvent;
Event.Keys = {};
Event.Keys = new Hash(Event.Keys);
(function() {
    var Class = this.Class = new Type('Class', function(params) {
        if (instanceOf(params, Function)) params = {
            initialize: params
        };
        var newClass = function() {
            reset(this);
            if (newClass.$prototyping) return this;
            this.$caller = null;
            var value = (this.initialize) ? this.initialize.apply(this, arguments) : this;
            this.$caller = this.caller = null;
            return value;
        }.extend(this).implement(params);
        newClass.$constructor = Class;
        newClass.prototype.$constructor = newClass;
        newClass.prototype.parent = parent;
        return newClass;
    });
    var parent = function() {
        if (!this.$caller) throw new Error('The method "parent" cannot be called.');
        var name = this.$caller.$name,
            parent = this.$caller.$owner.parent,
            previous = (parent) ? parent.prototype[name] : null;
        if (!previous) throw new Error('The method "' + name + '" has no parent.');
        return previous.apply(this, arguments);
    };
    var reset = function(object) {
        for (var key in object) {
            var value = object[key];
            switch (typeOf(value)) {
                case 'object':
                    var F = function() {};
                    F.prototype = value;
                    object[key] = reset(new F);
                    break;
                case 'array':
                    object[key] = value.clone();
                    break;
            }
        }
        return object;
    };
    var wrap = function(self, key, method) {
        if (method.$origin) method = method.$origin;
        var wrapper = function() {
            if (method.$protected && this.$caller == null) throw new Error('The method "' + key + '" cannot be called.');
            var caller = this.caller,
                current = this.$caller;
            this.caller = current;
            this.$caller = wrapper;
            var result = method.apply(this, arguments);
            this.$caller = current;
            this.caller = caller;
            return result;
        }.extend({
            $owner: self,
            $origin: method,
            $name: key
        });
        return wrapper;
    };
    var implement = function(key, value, retain) {
        if (Class.Mutators.hasOwnProperty(key)) {
            value = Class.Mutators[key].call(this, value);
            if (value == null) return this;
        }
        if (typeOf(value) == 'function') {
            if (value.$hidden) return this;
            this.prototype[key] = (retain) ? value : wrap(this, key, value);
        } else {
            Object.merge(this.prototype, key, value);
        }
        return this;
    };
    var getInstance = function(klass) {
        klass.$prototyping = true;
        var proto = new klass;
        delete klass.$prototyping;
        return proto;
    };
    Class.implement('implement', implement.overloadSetter());
    Class.Mutators = {
        Extends: function(parent) {
            this.parent = parent;
            this.prototype = getInstance(parent);
        },
        Implements: function(items) {
            Array.from(items).each(function(item) {
                var instance = new item;
                for (var key in instance) implement.call(this, key, instance[key], true);
            }, this);
        }
    };
})();
(function() {
    this.Chain = new Class({
        $chain: [],
        chain: function() {
            this.$chain.append(Array.flatten(arguments));
            return this;
        },
        callChain: function() {
            return (this.$chain.length) ? this.$chain.shift().apply(this, arguments) : false;
        },
        clearChain: function() {
            this.$chain.empty();
            return this;
        }
    });
    var removeOn = function(string) {
        return string.replace(/^on([A-Z])/, function(full, first) {
            return first.toLowerCase();
        });
    };
    this.Events = new Class({
        $events: {},
        addEvent: function(type, fn, internal) {
            type = removeOn(type);
            if (fn == $empty) return this;
            this.$events[type] = (this.$events[type] || []).include(fn);
            if (internal) fn.internal = true;
            return this;
        },
        addEvents: function(events) {
            for (var type in events) this.addEvent(type, events[type]);
            return this;
        },
        fireEvent: function(type, args, delay) {
            type = removeOn(type);
            var events = this.$events[type];
            if (!events) return this;
            args = Array.from(args);
            events.each(function(fn) {
                if (delay) fn.delay(delay, this, args);
                else fn.apply(this, args);
            }, this);
            return this;
        },
        removeEvent: function(type, fn) {
            type = removeOn(type);
            var events = this.$events[type];
            if (events && !fn.internal) {
                var index = events.indexOf(fn);
                if (index != -1) delete events[index];
            }
            return this;
        },
        removeEvents: function(events) {
            var type;
            if (typeOf(events) == 'object') {
                for (type in events) this.removeEvent(type, events[type]);
                return this;
            }
            if (events) events = removeOn(events);
            for (type in this.$events) {
                if (events && events != type) continue;
                var fns = this.$events[type];
                for (var i = fns.length; i--;)
                    if (i in fns) {
                        this.removeEvent(type, fns[i]);
                    }
            }
            return this;
        }
    });
    this.Options = new Class({
        setOptions: function() {
            var options = this.options = Object.merge.apply(null, [{}, this.options].append(arguments));
            if (this.addEvent)
                for (var option in options) {
                    if (typeOf(options[option]) != 'function' || !(/^on[A-Z]/).test(option)) continue;
                    this.addEvent(option, options[option]);
                    delete options[option];
                }
            return this;
        }
    });
})();;
(function() {
    var parsed, separatorIndex, combinatorIndex, reversed, cache = {},
        reverseCache = {},
        reUnescape = /\\/g;
    var parse = function(expression, isReversed) {
        if (expression == null) return null;
        if (expression.Slick === true) return expression;
        expression = ('' + expression).replace(/^\s+|\s+$/g, '');
        reversed = !!isReversed;
        var currentCache = (reversed) ? reverseCache : cache;
        if (currentCache[expression]) return currentCache[expression];
        parsed = {
            Slick: true,
            expressions: [],
            raw: expression,
            reverse: function() {
                return parse(this.raw, true);
            }
        };
        separatorIndex = -1;
        while (expression != (expression = expression.replace(regexp, parser)));
        parsed.length = parsed.expressions.length;
        return currentCache[parsed.raw] = (reversed) ? reverse(parsed) : parsed;
    };
    var reverseCombinator = function(combinator) {
        if (combinator === '!') return ' ';
        else if (combinator === ' ') return '!';
        else if ((/^!/).test(combinator)) return combinator.replace(/^!/, '');
        else return '!' + combinator;
    };
    var reverse = function(expression) {
        var expressions = expression.expressions;
        for (var i = 0; i < expressions.length; i++) {
            var exp = expressions[i];
            var last = {
                parts: [],
                tag: '*',
                combinator: reverseCombinator(exp[0].combinator)
            };
            for (var j = 0; j < exp.length; j++) {
                var cexp = exp[j];
                if (!cexp.reverseCombinator) cexp.reverseCombinator = ' ';
                cexp.combinator = cexp.reverseCombinator;
                delete cexp.reverseCombinator;
            }
            exp.reverse().push(last);
        }
        return expression;
    };
    var escapeRegExp = function(string) {
        return string.replace(/[-[\]{}()*+?.\\^$|,#\s]/g, function(match) {
            return '\\' + match;
        });
    };
    var regexp = new RegExp("^(?:\\s*(,)\\s*|\\s*(<combinator>+)\\s*|(\\s+)|(<unicode>+|\\*)|\\#(<unicode>+)|\\.(<unicode>+)|\\[\\s*(<unicode1>+)(?:\\s*([*^$!~|]?=)(?:\\s*(?:([\"']?)(.*?)\\9)))?\\s*\\](?!\\])|(:+)(<unicode>+)(?:\\((?:(?:([\"'])([^\\13]*)\\13)|((?:\\([^)]+\\)|[^()]*)+))\\))?)".replace(/<combinator>/, '[' + escapeRegExp(">+~`!@$%^&={}\\;</") + ']').replace(/<unicode>/g, '(?:[\\w\\u00a1-\\uFFFF-]|\\\\[^\\s0-9a-f])').replace(/<unicode1>/g, '(?:[:\\w\\u00a1-\\uFFFF-]|\\\\[^\\s0-9a-f])'));

    function parser(rawMatch, separator, combinator, combinatorChildren, tagName, id, className, attributeKey, attributeOperator, attributeQuote, attributeValue, pseudoMarker, pseudoClass, pseudoQuote, pseudoClassQuotedValue, pseudoClassValue) {
        if (separator || separatorIndex === -1) {
            parsed.expressions[++separatorIndex] = [];
            combinatorIndex = -1;
            if (separator) return '';
        }
        if (combinator || combinatorChildren || combinatorIndex === -1) {
            combinator = combinator || ' ';
            var currentSeparator = parsed.expressions[separatorIndex];
            if (reversed && currentSeparator[combinatorIndex])
                currentSeparator[combinatorIndex].reverseCombinator = reverseCombinator(combinator);
            currentSeparator[++combinatorIndex] = {
                combinator: combinator,
                tag: '*'
            };
        }
        var currentParsed = parsed.expressions[separatorIndex][combinatorIndex];
        if (tagName) {
            currentParsed.tag = tagName.replace(reUnescape, '');
        } else if (id) {
            currentParsed.id = id.replace(reUnescape, '');
        } else if (className) {
            className = className.replace(reUnescape, '');
            if (!currentParsed.classList) currentParsed.classList = [];
            if (!currentParsed.classes) currentParsed.classes = [];
            currentParsed.classList.push(className);
            currentParsed.classes.push({
                value: className,
                regexp: new RegExp('(^|\\s)' + escapeRegExp(className) + '(\\s|$)')
            });
        } else if (pseudoClass) {
            pseudoClassValue = pseudoClassValue || pseudoClassQuotedValue;
            pseudoClassValue = pseudoClassValue ? pseudoClassValue.replace(reUnescape, '') : null;
            if (!currentParsed.pseudos) currentParsed.pseudos = [];
            currentParsed.pseudos.push({
                key: pseudoClass.replace(reUnescape, ''),
                value: pseudoClassValue,
                type: pseudoMarker.length == 1 ? 'class' : 'element'
            });
        } else if (attributeKey) {
            attributeKey = attributeKey.replace(reUnescape, '');
            attributeValue = (attributeValue || '').replace(reUnescape, '');
            var test, regexp;
            switch (attributeOperator) {
                case '^=':
                    regexp = new RegExp('^' + escapeRegExp(attributeValue));
                    break;
                case '$=':
                    regexp = new RegExp(escapeRegExp(attributeValue) + '$');
                    break;
                case '~=':
                    regexp = new RegExp('(^|\\s)' + escapeRegExp(attributeValue) + '(\\s|$)');
                    break;
                case '|=':
                    regexp = new RegExp('^' + escapeRegExp(attributeValue) + '(-|$)');
                    break;
                case '=':
                    test = function(value) {
                        return attributeValue == value;
                    };
                    break;
                case '*=':
                    test = function(value) {
                        return value && value.indexOf(attributeValue) > -1;
                    };
                    break;
                case '!=':
                    test = function(value) {
                        return attributeValue != value;
                    };
                    break;
                default:
                    test = function(value) {
                        return !!value;
                    };
            }
            if (attributeValue == '' && (/^[*$^]=$/).test(attributeOperator)) test = function() {
                return false;
            };
            if (!test) test = function(value) {
                return value && regexp.test(value);
            };
            if (!currentParsed.attributes) currentParsed.attributes = [];
            currentParsed.attributes.push({
                key: attributeKey,
                operator: attributeOperator,
                value: attributeValue,
                test: test
            });
        }
        return '';
    };
    var Slick = (this.Slick || {});
    Slick.parse = function(expression) {
        return parse(expression);
    };
    Slick.escapeRegExp = escapeRegExp;
    if (!this.Slick) this.Slick = Slick;
}).apply((typeof exports != 'undefined') ? exports : this);;
(function() {
    var local = {},
        featuresCache = {},
        toString = Object.prototype.toString;
    local.isNativeCode = function(fn) {
        return (/\{\s*\[native code\]\s*\}/).test('' + fn);
    };
    local.isXML = function(document) {
        return (!!document.xmlVersion) || (!!document.xml) || (toString.call(document) == '[object XMLDocument]') || (document.nodeType == 9 && document.documentElement.nodeName != 'HTML');
    };
    local.setDocument = function(document) {
        var nodeType = document.nodeType;
        if (nodeType == 9);
        else if (nodeType) document = document.ownerDocument;
        else if (document.navigator) document = document.document;
        else return;
        if (this.document === document) return;
        this.document = document;
        var root = document.documentElement,
            rootUid = this.getUIDXML(root),
            features = featuresCache[rootUid],
            feature;
        if (features) {
            for (feature in features) {
                this[feature] = features[feature];
            }
            return;
        }
        features = featuresCache[rootUid] = {};
        features.root = root;
        features.isXMLDocument = this.isXML(document);
        features.brokenStarGEBTN = features.starSelectsClosedQSA = features.idGetsName = features.brokenMixedCaseQSA = features.brokenGEBCN = features.brokenCheckedQSA = features.brokenEmptyAttributeQSA = features.isHTMLDocument = features.nativeMatchesSelector = false;
        var starSelectsClosed, starSelectsComments, brokenSecondClassNameGEBCN, cachedGetElementsByClassName, brokenFormAttributeGetter;
        var selected, id = 'slick_uniqueid';
        var testNode = document.createElement('div');
        var testRoot = document.body || document.getElementsByTagName('body')[0] || root;
        testRoot.appendChild(testNode);
        try {
            testNode.innerHTML = '<a id="' + id + '"></a>';
            features.isHTMLDocument = !!document.getElementById(id);
        } catch (e) {};
        if (features.isHTMLDocument) {
            testNode.style.display = 'none';
            testNode.appendChild(document.createComment(''));
            starSelectsComments = (testNode.getElementsByTagName('*').length > 1);
            try {
                testNode.innerHTML = 'foo</foo>';
                selected = testNode.getElementsByTagName('*');
                starSelectsClosed = (selected && !!selected.length && selected[0].nodeName.charAt(0) == '/');
            } catch (e) {};
            features.brokenStarGEBTN = starSelectsComments || starSelectsClosed;
            try {
                testNode.innerHTML = '<a name="' + id + '"></a><b id="' + id + '"></b>';
                features.idGetsName = document.getElementById(id) === testNode.firstChild;
            } catch (e) {};
            if (testNode.getElementsByClassName) {
                try {
                    testNode.innerHTML = '<a class="f"></a><a class="b"></a>';
                    testNode.getElementsByClassName('b').length;
                    testNode.firstChild.className = 'b';
                    cachedGetElementsByClassName = (testNode.getElementsByClassName('b').length != 2);
                } catch (e) {};
                try {
                    testNode.innerHTML = '<a class="a"></a><a class="f b a"></a>';
                    brokenSecondClassNameGEBCN = (testNode.getElementsByClassName('a').length != 2);
                } catch (e) {};
                features.brokenGEBCN = cachedGetElementsByClassName || brokenSecondClassNameGEBCN;
            }
            if (testNode.querySelectorAll) {
                try {
                    testNode.innerHTML = 'foo</foo>';
                    selected = testNode.querySelectorAll('*');
                    features.starSelectsClosedQSA = (selected && !!selected.length && selected[0].nodeName.charAt(0) == '/');
                } catch (e) {};
                try {
                    testNode.innerHTML = '<a class="MiX"></a>';
                    features.brokenMixedCaseQSA = !testNode.querySelectorAll('.MiX').length;
                } catch (e) {};
                try {
                    testNode.innerHTML = '<select><option selected="selected">a</option></select>';
                    features.brokenCheckedQSA = (testNode.querySelectorAll(':checked').length == 0);
                } catch (e) {};
                try {
                    testNode.innerHTML = '<a class=""></a>';
                    features.brokenEmptyAttributeQSA = (testNode.querySelectorAll('[class*=""]').length != 0);
                } catch (e) {};
            }
            try {
                testNode.innerHTML = '<form action="s"><input id="action"/></form>';
                brokenFormAttributeGetter = (testNode.firstChild.getAttribute('action') != 's');
            } catch (e) {};
            features.nativeMatchesSelector = root.matches || root.mozMatchesSelector || root.webkitMatchesSelector;
            if (features.nativeMatchesSelector) try {
                features.nativeMatchesSelector.call(root, ':slick');
                features.nativeMatchesSelector = null;
            } catch (e) {};
        }
        try {
            root.slick_expando = 1;
            delete root.slick_expando;
            features.getUID = this.getUIDHTML;
        } catch (e) {
            features.getUID = this.getUIDXML;
        }
        testRoot.removeChild(testNode);
        testNode = selected = testRoot = null;
        features.getAttribute = (features.isHTMLDocument && brokenFormAttributeGetter) ? function(node, name) {
            var method = this.attributeGetters[name];
            if (method) return method.call(node);
            var attributeNode = node.getAttributeNode(name);
            return (attributeNode) ? attributeNode.nodeValue : null;
        } : function(node, name) {
            var method = this.attributeGetters[name];
            return (method) ? method.call(node) : node.getAttribute(name);
        };
        features.hasAttribute = (root && this.isNativeCode(root.hasAttribute)) ? function(node, attribute) {
            return node.hasAttribute(attribute);
        } : function(node, attribute) {
            node = node.getAttributeNode(attribute);
            return !!(node && (node.specified || node.nodeValue));
        };
        var nativeRootContains = root && this.isNativeCode(root.contains),
            nativeDocumentContains = document && this.isNativeCode(document.contains);
        features.contains = (nativeRootContains && nativeDocumentContains) ? function(context, node) {
            return context.contains(node);
        } : (nativeRootContains && !nativeDocumentContains) ? function(context, node) {
            return context === node || ((context === document) ? document.documentElement : context).contains(node);
        } : (root && root.compareDocumentPosition) ? function(context, node) {
            return context === node || !!(context.compareDocumentPosition(node) & 16);
        } : function(context, node) {
            if (node)
                do {
                    if (node === context) return true;
                } while ((node = node.parentNode));
            return false;
        };
        features.documentSorter = (root.compareDocumentPosition) ? function(a, b) {
            if (!a.compareDocumentPosition || !b.compareDocumentPosition) return 0;
            return a.compareDocumentPosition(b) & 4 ? -1 : a === b ? 0 : 1;
        } : ('sourceIndex' in root) ? function(a, b) {
            if (!a.sourceIndex || !b.sourceIndex) return 0;
            return a.sourceIndex - b.sourceIndex;
        } : (document.createRange) ? function(a, b) {
            if (!a.ownerDocument || !b.ownerDocument) return 0;
            var aRange = a.ownerDocument.createRange(),
                bRange = b.ownerDocument.createRange();
            aRange.setStart(a, 0);
            aRange.setEnd(a, 0);
            bRange.setStart(b, 0);
            bRange.setEnd(b, 0);
            return aRange.compareBoundaryPoints(Range.START_TO_END, bRange);
        } : null;
        root = null;
        for (feature in features) {
            this[feature] = features[feature];
        }
    };
    var reSimpleSelector = /^([#.]?)((?:[\w-]+|\*))$/,
        reEmptyAttribute = /\[.+[*$^]=(?:""|'')?\]/,
        qsaFailExpCache = {};
    local.search = function(context, expression, append, first) {
        var found = this.found = (first) ? null : (append || []);
        if (!context) return found;
        else if (context.navigator) context = context.document;
        else if (!context.nodeType) return found;
        var parsed, i, uniques = this.uniques = {},
            hasOthers = !!(append && append.length),
            contextIsDocument = (context.nodeType == 9);
        if (this.document !== (contextIsDocument ? context : context.ownerDocument)) this.setDocument(context);
        if (hasOthers)
            for (i = found.length; i--;) uniques[this.getUID(found[i])] = true;
        if (typeof expression == 'string') {
            var simpleSelector = expression.match(reSimpleSelector);
            simpleSelectors: if (simpleSelector) {
                    var symbol = simpleSelector[1],
                        name = simpleSelector[2],
                        node, nodes;
                    if (!symbol) {
                        if (name == '*' && this.brokenStarGEBTN) break simpleSelectors;
                        nodes = context.getElementsByTagName(name);
                        if (first) return nodes[0] || null;
                        for (i = 0; node = nodes[i++];) {
                            if (!(hasOthers && uniques[this.getUID(node)])) found.push(node);
                        }
                    } else if (symbol == '#') {
                        if (!this.isHTMLDocument || !contextIsDocument) break simpleSelectors;
                        node = context.getElementById(name);
                        if (!node) return found;
                        if (this.idGetsName && node.getAttributeNode('id').nodeValue != name) break simpleSelectors;
                        if (first) return node || null;
                        if (!(hasOthers && uniques[this.getUID(node)])) found.push(node);
                    } else if (symbol == '.') {
                        if (!this.isHTMLDocument || ((!context.getElementsByClassName || this.brokenGEBCN) && context.querySelectorAll)) break simpleSelectors;
                        if (context.getElementsByClassName && !this.brokenGEBCN) {
                            nodes = context.getElementsByClassName(name);
                            if (first) return nodes[0] || null;
                            for (i = 0; node = nodes[i++];) {
                                if (!(hasOthers && uniques[this.getUID(node)])) found.push(node);
                            }
                        } else {
                            var matchClass = new RegExp('(^|\\s)' + Slick.escapeRegExp(name) + '(\\s|$)');
                            nodes = context.getElementsByTagName('*');
                            for (i = 0; node = nodes[i++];) {
                                className = node.className;
                                if (!(className && matchClass.test(className))) continue;
                                if (first) return node;
                                if (!(hasOthers && uniques[this.getUID(node)])) found.push(node);
                            }
                        }
                    }
                    if (hasOthers) this.sort(found);
                    return (first) ? null : found;
                }
            querySelector: if (context.querySelectorAll) {
                    if (!this.isHTMLDocument || qsaFailExpCache[expression] || this.brokenMixedCaseQSA || (this.brokenCheckedQSA && expression.indexOf(':checked') > -1) || (this.brokenEmptyAttributeQSA && reEmptyAttribute.test(expression)) || (!contextIsDocument && expression.indexOf(',') > -1) || Slick.disableQSA) break querySelector;
                    var _expression = expression,
                        _context = context;
                    if (!contextIsDocument) {
                        var currentId = _context.getAttribute('id'),
                            slickid = 'slickid__';
                        _context.setAttribute('id', slickid);
                        _expression = '#' + slickid + ' ' + _expression;
                        context = _context.parentNode;
                    }
                    try {
                        if (first) return context.querySelector(_expression) || null;
                        else nodes = context.querySelectorAll(_expression);
                    } catch (e) {
                        qsaFailExpCache[expression] = 1;
                        break querySelector;
                    } finally {
                        if (!contextIsDocument) {
                            if (currentId) _context.setAttribute('id', currentId);
                            else _context.removeAttribute('id');
                            context = _context;
                        }
                    }
                    if (this.starSelectsClosedQSA)
                        for (i = 0; node = nodes[i++];) {
                            if (node.nodeName > '@' && !(hasOthers && uniques[this.getUID(node)])) found.push(node);
                        } else
                            for (i = 0; node = nodes[i++];) {
                                if (!(hasOthers && uniques[this.getUID(node)])) found.push(node);
                            }
                    if (hasOthers) this.sort(found);
                    return found;
                }
            parsed = this.Slick.parse(expression);
            if (!parsed.length) return found;
        } else if (expression == null) {
            return found;
        } else if (expression.Slick) {
            parsed = expression;
        } else if (this.contains(context.documentElement || context, expression)) {
            (found) ? found.push(expression): found = expression;
            return found;
        } else {
            return found;
        }
        this.posNTH = {};
        this.posNTHLast = {};
        this.posNTHType = {};
        this.posNTHTypeLast = {};
        this.push = (!hasOthers && (first || (parsed.length == 1 && parsed.expressions[0].length == 1))) ? this.pushArray : this.pushUID;
        if (found == null) found = [];
        var j, m, n;
        var combinator, tag, id, classList, classes, attributes, pseudos;
        var currentItems, currentExpression, currentBit, lastBit, expressions = parsed.expressions;
        search: for (i = 0;
            (currentExpression = expressions[i]); i++)
            for (j = 0;
                (currentBit = currentExpression[j]); j++) {
                combinator = 'combinator:' + currentBit.combinator;
                if (!this[combinator]) continue search;
                tag = (this.isXMLDocument) ? currentBit.tag : currentBit.tag.toUpperCase();
                id = currentBit.id;
                classList = currentBit.classList;
                classes = currentBit.classes;
                attributes = currentBit.attributes;
                pseudos = currentBit.pseudos;
                lastBit = (j === (currentExpression.length - 1));
                this.bitUniques = {};
                if (lastBit) {
                    this.uniques = uniques;
                    this.found = found;
                } else {
                    this.uniques = {};
                    this.found = [];
                }
                if (j === 0) {
                    this[combinator](context, tag, id, classes, attributes, pseudos, classList);
                    if (first && lastBit && found.length) break search;
                } else {
                    if (first && lastBit)
                        for (m = 0, n = currentItems.length; m < n; m++) {
                            this[combinator](currentItems[m], tag, id, classes, attributes, pseudos, classList);
                            if (found.length) break search;
                        } else
                            for (m = 0, n = currentItems.length; m < n; m++) this[combinator](currentItems[m], tag, id, classes, attributes, pseudos, classList);
                }
                currentItems = this.found;
            }
        if (hasOthers || (parsed.expressions.length > 1)) this.sort(found);
        return (first) ? (found[0] || null) : found;
    };
    local.uidx = 1;
    local.uidk = 'slick-uniqueid';
    local.getUIDXML = function(node) {
        var uid = node.getAttribute(this.uidk);
        if (!uid) {
            uid = this.uidx++;
            node.setAttribute(this.uidk, uid);
        }
        return uid;
    };
    local.getUIDHTML = function(node) {
        return node.uniqueNumber || (node.uniqueNumber = this.uidx++);
    };
    local.sort = function(results) {
        if (!this.documentSorter) return results;
        results.sort(this.documentSorter);
        return results;
    };
    local.cacheNTH = {};
    local.matchNTH = /^([+-]?\d*)?([a-z]+)?([+-]\d+)?$/;
    local.parseNTHArgument = function(argument) {
        var parsed = argument.match(this.matchNTH);
        if (!parsed) return false;
        var special = parsed[2] || false;
        var a = parsed[1] || 1;
        if (a == '-') a = -1;
        var b = +parsed[3] || 0;
        parsed = (special == 'n') ? {
            a: a,
            b: b
        } : (special == 'odd') ? {
            a: 2,
            b: 1
        } : (special == 'even') ? {
            a: 2,
            b: 0
        } : {
            a: 0,
            b: a
        };
        return (this.cacheNTH[argument] = parsed);
    };
    local.createNTHPseudo = function(child, sibling, positions, ofType) {
        return function(node, argument) {
            var uid = this.getUID(node);
            if (!this[positions][uid]) {
                var parent = node.parentNode;
                if (!parent) return false;
                var el = parent[child],
                    count = 1;
                if (ofType) {
                    var nodeName = node.nodeName;
                    do {
                        if (el.nodeName != nodeName) continue;
                        this[positions][this.getUID(el)] = count++;
                    } while ((el = el[sibling]));
                } else {
                    do {
                        if (el.nodeType != 1) continue;
                        this[positions][this.getUID(el)] = count++;
                    } while ((el = el[sibling]));
                }
            }
            argument = argument || 'n';
            var parsed = this.cacheNTH[argument] || this.parseNTHArgument(argument);
            if (!parsed) return false;
            var a = parsed.a,
                b = parsed.b,
                pos = this[positions][uid];
            if (a == 0) return b == pos;
            if (a > 0) {
                if (pos < b) return false;
            } else {
                if (b < pos) return false;
            }
            return ((pos - b) % a) == 0;
        };
    };
    local.pushArray = function(node, tag, id, classes, attributes, pseudos) {
        if (this.matchSelector(node, tag, id, classes, attributes, pseudos)) this.found.push(node);
    };
    local.pushUID = function(node, tag, id, classes, attributes, pseudos) {
        var uid = this.getUID(node);
        if (!this.uniques[uid] && this.matchSelector(node, tag, id, classes, attributes, pseudos)) {
            this.uniques[uid] = true;
            this.found.push(node);
        }
    };
    local.matchNode = function(node, selector) {
        if (this.isHTMLDocument && this.nativeMatchesSelector) {
            try {
                return this.nativeMatchesSelector.call(node, selector.replace(/\[([^=]+)=\s*([^'"\]]+?)\s*\]/g, '[$1="$2"]'));
            } catch (matchError) {}
        }
        var parsed = this.Slick.parse(selector);
        if (!parsed) return true;
        var expressions = parsed.expressions,
            simpleExpCounter = 0,
            i, currentExpression;
        for (i = 0;
            (currentExpression = expressions[i]); i++) {
            if (currentExpression.length == 1) {
                var exp = currentExpression[0];
                if (this.matchSelector(node, (this.isXMLDocument) ? exp.tag : exp.tag.toUpperCase(), exp.id, exp.classes, exp.attributes, exp.pseudos)) return true;
                simpleExpCounter++;
            }
        }
        if (simpleExpCounter == parsed.length) return false;
        var nodes = this.search(this.document, parsed),
            item;
        for (i = 0; item = nodes[i++];) {
            if (item === node) return true;
        }
        return false;
    };
    local.matchPseudo = function(node, name, argument) {
        var pseudoName = 'pseudo:' + name;
        if (this[pseudoName]) return this[pseudoName](node, argument);
        var attribute = this.getAttribute(node, name);
        return (argument) ? argument == attribute : !!attribute;
    };
    local.matchSelector = function(node, tag, id, classes, attributes, pseudos) {
        if (tag) {
            var nodeName = (this.isXMLDocument) ? node.nodeName : node.nodeName.toUpperCase();
            if (tag == '*') {
                if (nodeName < '@') return false;
            } else {
                if (nodeName != tag) return false;
            }
        }
        if (id && node.getAttribute('id') != id) return false;
        var i, part, cls;
        if (classes)
            for (i = classes.length; i--;) {
                cls = this.getAttribute(node, 'class');
                if (!(cls && classes[i].regexp.test(cls))) return false;
            }
        if (attributes)
            for (i = attributes.length; i--;) {
                part = attributes[i];
                if (part.operator ? !part.test(this.getAttribute(node, part.key)) : !this.hasAttribute(node, part.key)) return false;
            }
        if (pseudos)
            for (i = pseudos.length; i--;) {
                part = pseudos[i];
                if (!this.matchPseudo(node, part.key, part.value)) return false;
            }
        return true;
    };
    var combinators = {
        ' ': function(node, tag, id, classes, attributes, pseudos, classList) {
            var i, item, children;
            if (this.isHTMLDocument) {
                getById: if (id) {
                        item = this.document.getElementById(id);
                        if ((!item && node.all) || (this.idGetsName && item && item.getAttributeNode('id').nodeValue != id)) {
                            children = node.all[id];
                            if (!children) return;
                            if (!children[0]) children = [children];
                            for (i = 0; item = children[i++];) {
                                var idNode = item.getAttributeNode('id');
                                if (idNode && idNode.nodeValue == id) {
                                    this.push(item, tag, null, classes, attributes, pseudos);
                                    break;
                                }
                            }
                            return;
                        }
                        if (!item) {
                            if (this.contains(this.root, node)) return;
                            else break getById;
                        } else if (this.document !== node && !this.contains(node, item)) return;
                        this.push(item, tag, null, classes, attributes, pseudos);
                        return;
                    }
                getByClass: if (classes && node.getElementsByClassName && !this.brokenGEBCN) {
                    children = node.getElementsByClassName(classList.join(' '));
                    if (!(children && children.length)) break getByClass;
                    for (i = 0; item = children[i++];) this.push(item, tag, id, null, attributes, pseudos);
                    return;
                }
            }
            getByTag: {
                children = node.getElementsByTagName(tag);
                if (!(children && children.length)) break getByTag;
                if (!this.brokenStarGEBTN) tag = null;
                for (i = 0; item = children[i++];) this.push(item, tag, id, classes, attributes, pseudos);
            }
        },
        '>': function(node, tag, id, classes, attributes, pseudos) {
            if ((node = node.firstChild))
                do {
                    if (node.nodeType == 1) this.push(node, tag, id, classes, attributes, pseudos);
                } while ((node = node.nextSibling));
        },
        '+': function(node, tag, id, classes, attributes, pseudos) {
            while ((node = node.nextSibling))
                if (node.nodeType == 1) {
                    this.push(node, tag, id, classes, attributes, pseudos);
                    break;
                }
        },
        '^': function(node, tag, id, classes, attributes, pseudos) {
            node = node.firstChild;
            if (node) {
                if (node.nodeType == 1) this.push(node, tag, id, classes, attributes, pseudos);
                else this['combinator:+'](node, tag, id, classes, attributes, pseudos);
            }
        },
        '~': function(node, tag, id, classes, attributes, pseudos) {
            while ((node = node.nextSibling)) {
                if (node.nodeType != 1) continue;
                var uid = this.getUID(node);
                if (this.bitUniques[uid]) break;
                this.bitUniques[uid] = true;
                this.push(node, tag, id, classes, attributes, pseudos);
            }
        },
        '++': function(node, tag, id, classes, attributes, pseudos) {
            this['combinator:+'](node, tag, id, classes, attributes, pseudos);
            this['combinator:!+'](node, tag, id, classes, attributes, pseudos);
        },
        '~~': function(node, tag, id, classes, attributes, pseudos) {
            this['combinator:~'](node, tag, id, classes, attributes, pseudos);
            this['combinator:!~'](node, tag, id, classes, attributes, pseudos);
        },
        '!': function(node, tag, id, classes, attributes, pseudos) {
            while ((node = node.parentNode))
                if (node !== this.document) this.push(node, tag, id, classes, attributes, pseudos);
        },
        '!>': function(node, tag, id, classes, attributes, pseudos) {
            node = node.parentNode;
            if (node !== this.document) this.push(node, tag, id, classes, attributes, pseudos);
        },
        '!+': function(node, tag, id, classes, attributes, pseudos) {
            while ((node = node.previousSibling))
                if (node.nodeType == 1) {
                    this.push(node, tag, id, classes, attributes, pseudos);
                    break;
                }
        },
        '!^': function(node, tag, id, classes, attributes, pseudos) {
            node = node.lastChild;
            if (node) {
                if (node.nodeType == 1) this.push(node, tag, id, classes, attributes, pseudos);
                else this['combinator:!+'](node, tag, id, classes, attributes, pseudos);
            }
        },
        '!~': function(node, tag, id, classes, attributes, pseudos) {
            while ((node = node.previousSibling)) {
                if (node.nodeType != 1) continue;
                var uid = this.getUID(node);
                if (this.bitUniques[uid]) break;
                this.bitUniques[uid] = true;
                this.push(node, tag, id, classes, attributes, pseudos);
            }
        }
    };
    for (var c in combinators) local['combinator:' + c] = combinators[c];
    var pseudos = {
        'empty': function(node) {
            var child = node.firstChild;
            return !(child && child.nodeType == 1) && !(node.innerText || node.textContent || '').length;
        },
        'not': function(node, expression) {
            return !this.matchNode(node, expression);
        },
        'contains': function(node, text) {
            return (node.innerText || node.textContent || '').indexOf(text) > -1;
        },
        'first-child': function(node) {
            while ((node = node.previousSibling))
                if (node.nodeType == 1) return false;
            return true;
        },
        'last-child': function(node) {
            while ((node = node.nextSibling))
                if (node.nodeType == 1) return false;
            return true;
        },
        'only-child': function(node) {
            var prev = node;
            while ((prev = prev.previousSibling))
                if (prev.nodeType == 1) return false;
            var next = node;
            while ((next = next.nextSibling))
                if (next.nodeType == 1) return false;
            return true;
        },
        'nth-child': local.createNTHPseudo('firstChild', 'nextSibling', 'posNTH'),
        'nth-last-child': local.createNTHPseudo('lastChild', 'previousSibling', 'posNTHLast'),
        'nth-of-type': local.createNTHPseudo('firstChild', 'nextSibling', 'posNTHType', true),
        'nth-last-of-type': local.createNTHPseudo('lastChild', 'previousSibling', 'posNTHTypeLast', true),
        'index': function(node, index) {
            return this['pseudo:nth-child'](node, '' + (index + 1));
        },
        'even': function(node) {
            return this['pseudo:nth-child'](node, '2n');
        },
        'odd': function(node) {
            return this['pseudo:nth-child'](node, '2n+1');
        },
        'first-of-type': function(node) {
            var nodeName = node.nodeName;
            while ((node = node.previousSibling))
                if (node.nodeName == nodeName) return false;
            return true;
        },
        'last-of-type': function(node) {
            var nodeName = node.nodeName;
            while ((node = node.nextSibling))
                if (node.nodeName == nodeName) return false;
            return true;
        },
        'only-of-type': function(node) {
            var prev = node,
                nodeName = node.nodeName;
            while ((prev = prev.previousSibling))
                if (prev.nodeName == nodeName) return false;
            var next = node;
            while ((next = next.nextSibling))
                if (next.nodeName == nodeName) return false;
            return true;
        },
        'enabled': function(node) {
            return !node.disabled;
        },
        'disabled': function(node) {
            return node.disabled;
        },
        'checked': function(node) {
            return node.checked || node.selected;
        },
        'focus': function(node) {
            return this.isHTMLDocument && this.document.activeElement === node && (node.href || node.type || this.hasAttribute(node, 'tabindex'));
        },
        'root': function(node) {
            return (node === this.root);
        },
        'selected': function(node) {
            return node.selected;
        }
    };
    for (var p in pseudos) local['pseudo:' + p] = pseudos[p];
    var attributeGetters = local.attributeGetters = {
        'for': function() {
            return ('htmlFor' in this) ? this.htmlFor : this.getAttribute('for');
        },
        'href': function() {
            return ('href' in this) ? this.getAttribute('href', 2) : this.getAttribute('href');
        },
        'style': function() {
            return (this.style) ? this.style.cssText : this.getAttribute('style');
        },
        'tabindex': function() {
            var attributeNode = this.getAttributeNode('tabindex');
            return (attributeNode && attributeNode.specified) ? attributeNode.nodeValue : null;
        },
        'type': function() {
            return this.getAttribute('type');
        },
        'maxlength': function() {
            var attributeNode = this.getAttributeNode('maxLength');
            return (attributeNode && attributeNode.specified) ? attributeNode.nodeValue : null;
        }
    };
    attributeGetters.MAXLENGTH = attributeGetters.maxLength = attributeGetters.maxlength;
    var Slick = local.Slick = (this.Slick || {});
    Slick.version = '1.1.7';
    Slick.search = function(context, expression, append) {
        return local.search(context, expression, append);
    };
    Slick.find = function(context, expression) {
        return local.search(context, expression, null, true);
    };
    Slick.contains = function(container, node) {
        local.setDocument(container);
        return local.contains(container, node);
    };
    Slick.getAttribute = function(node, name) {
        local.setDocument(node);
        return local.getAttribute(node, name);
    };
    Slick.hasAttribute = function(node, name) {
        local.setDocument(node);
        return local.hasAttribute(node, name);
    };
    Slick.match = function(node, selector) {
        if (!(node && selector)) return false;
        if (!selector || selector === node) return true;
        local.setDocument(node);
        return local.matchNode(node, selector);
    };
    Slick.defineAttributeGetter = function(name, fn) {
        local.attributeGetters[name] = fn;
        return this;
    };
    Slick.lookupAttributeGetter = function(name) {
        return local.attributeGetters[name];
    };
    Slick.definePseudo = function(name, fn) {
        local['pseudo:' + name] = function(node, argument) {
            return fn.call(node, argument);
        };
        return this;
    };
    Slick.lookupPseudo = function(name) {
        var pseudo = local['pseudo:' + name];
        if (pseudo) return function(argument) {
            return pseudo.call(this, argument);
        };
        return null;
    };
    Slick.override = function(regexp, fn) {
        local.override(regexp, fn);
        return this;
    };
    Slick.isXML = local.isXML;
    Slick.uidOf = function(node) {
        return local.getUIDHTML(node);
    };
    if (!this.Slick) this.Slick = Slick;
}).apply((typeof exports != 'undefined') ? exports : this);
var Element = this.Element = function(tag, props) {
    var konstructor = Element.Constructors[tag];
    if (konstructor) return konstructor(props);
    if (typeof tag != 'string') return document.id(tag).set(props);
    if (!props) props = {};
    if (!(/^[\w-]+$/).test(tag)) {
        var parsed = Slick.parse(tag).expressions[0][0];
        tag = (parsed.tag == '*') ? 'div' : parsed.tag;
        if (parsed.id && props.id == null) props.id = parsed.id;
        var attributes = parsed.attributes;
        if (attributes)
            for (var attr, i = 0, l = attributes.length; i < l; i++) {
                attr = attributes[i];
                if (props[attr.key] != null) continue;
                if (attr.value != null && attr.operator == '=') props[attr.key] = attr.value;
                else if (!attr.value && !attr.operator) props[attr.key] = true;
            }
        if (parsed.classList && props['class'] == null) props['class'] = parsed.classList.join(' ');
    }
    return document.newElement(tag, props);
};
if (Browser.Element) {
    Element.prototype = Browser.Element.prototype;
    Element.prototype._fireEvent = (function(fireEvent) {
        return function(type, event) {
            return fireEvent.call(this, type, event);
        };
    })(Element.prototype.fireEvent);
}
new Type('Element', Element).mirror(function(name) {
    if (Array.prototype[name]) return;
    var obj = {};
    obj[name] = function() {
        var results = [],
            args = arguments,
            elements = true;
        for (var i = 0, l = this.length; i < l; i++) {
            var element = this[i],
                result = results[i] = element[name].apply(element, args);
            elements = (elements && typeOf(result) == 'element');
        }
        return (elements) ? new Elements(results) : results;
    };
    Elements.implement(obj);
});
if (!Browser.Element) {
    Element.parent = Object;
    Element.Prototype = {
        '$constructor': Element,
        '$family': Function.from('element').hide()
    };
    Element.mirror(function(name, method) {
        Element.Prototype[name] = method;
    });
}
Element.Constructors = {};
Element.Constructors = new Hash;
var IFrame = new Type('IFrame', function() {
    var params = Array.link(arguments, {
        properties: Type.isObject,
        iframe: function(obj) {
            return (obj != null);
        }
    });
    var props = params.properties || {},
        iframe;
    if (params.iframe) iframe = document.id(params.iframe);
    var onload = props.onload || function() {};
    delete props.onload;
    props.id = props.name = [props.id, props.name, iframe ? (iframe.id || iframe.name) : 'IFrame_' + String.uniqueID()].pick();
    iframe = new Element(iframe || 'iframe', props);
    var onLoad = function() {
        onload.call(iframe.contentWindow);
    };
    if (window.frames[props.id]) onLoad();
    else iframe.addListener('load', onLoad);
    return iframe;
});
var Elements = this.Elements = function(nodes) {
    if (nodes && nodes.length) {
        var uniques = {},
            node;
        for (var i = 0; node = nodes[i++];) {
            var uid = Slick.uidOf(node);
            if (!uniques[uid]) {
                uniques[uid] = true;
                this.push(node);
            }
        }
    }
};
Elements.prototype = {
    length: 0
};
Elements.parent = Array;
new Type('Elements', Elements).implement({
    filter: function(filter, bind) {
        if (!filter) return this;
        return new Elements(Array.filter(this, (typeOf(filter) == 'string') ? function(item) {
            return item.match(filter);
        } : filter, bind));
    }.protect(),
    push: function() {
        var length = this.length;
        for (var i = 0, l = arguments.length; i < l; i++) {
            var item = document.id(arguments[i]);
            if (item) this[length++] = item;
        }
        return (this.length = length);
    }.protect(),
    unshift: function() {
        var items = [];
        for (var i = 0, l = arguments.length; i < l; i++) {
            var item = document.id(arguments[i]);
            if (item) items.push(item);
        }
        return Array.prototype.unshift.apply(this, items);
    }.protect(),
    concat: function() {
        var newElements = new Elements(this);
        for (var i = 0, l = arguments.length; i < l; i++) {
            var item = arguments[i];
            if (Type.isEnumerable(item)) newElements.append(item);
            else newElements.push(item);
        }
        return newElements;
    }.protect(),
    append: function(collection) {
        for (var i = 0, l = collection.length; i < l; i++) this.push(collection[i]);
        return this;
    }.protect(),
    empty: function() {
        while (this.length) delete this[--this.length];
        return this;
    }.protect()
});
Elements.alias('extend', 'append');
(function() {
    var splice = Array.prototype.splice,
        object = {
            '0': 0,
            '1': 1,
            length: 2
        };
    splice.call(object, 1, 1);
    if (object[1] == 1) Elements.implement('splice', function() {
        var length = this.length;
        var result = splice.apply(this, arguments);
        while (length >= this.length) delete this[length--];
        return result;
    }.protect());
    Array.forEachMethod(function(method, name) {
        Elements.implement(name, method);
    });
    Array.mirror(Elements);
    var createElementAcceptsHTML;
    try {
        createElementAcceptsHTML = (document.createElement('<input name=x>').name == 'x');
    } catch (e) {}
    var escapeQuotes = function(html) {
        return ('' + html).replace(/&/g, '&amp;').replace(/"/g, '&quot;');
    };
    var canChangeStyleHTML = (function() {
        var div = document.createElement('style'),
            flag = false;
        try {
            div.innerHTML = '#justTesing{margin: 0px;}';
            flag = !!div.innerHTML;
        } catch (e) {}
        return flag;
    })();
    Document.implement({
        newElement: function(tag, props) {
            if (props) {
                if (props.checked != null) props.defaultChecked = props.checked;
                if ((props.type == 'checkbox' || props.type == 'radio') && props.value == null) props.value = 'on';
                if (!canChangeStyleHTML && tag == 'style') {
                    var styleElement = document.createElement('style');
                    styleElement.setAttribute('type', 'text/css');
                    if (props.type) delete props.type;
                    return this.id(styleElement).set(props);
                }
                if (createElementAcceptsHTML) {
                    tag = '<' + tag;
                    if (props.name) tag += ' name="' + escapeQuotes(props.name) + '"';
                    if (props.type) tag += ' type="' + escapeQuotes(props.type) + '"';
                    tag += '>';
                    delete props.name;
                    delete props.type;
                }
            }
            return this.id(this.createElement(tag)).set(props);
        }
    });
})();
(function() {
    Slick.uidOf(window);
    Slick.uidOf(document);
    Document.implement({
        newTextNode: function(text) {
            return this.createTextNode(text);
        },
        getDocument: function() {
            return this;
        },
        getWindow: function() {
            return this.window;
        },
        id: (function() {
            var types = {
                string: function(id, nocash, doc) {
                    id = Slick.find(doc, '#' + id.replace(/(\W)/g, '\\$1'));
                    return (id) ? types.element(id, nocash) : null;
                },
                element: function(el, nocash) {
                    Slick.uidOf(el);
                    if (!nocash && !el.$family && !(/^(?:object|embed)$/i).test(el.tagName)) {
                        var fireEvent = el.fireEvent;
                        el._fireEvent = function(type, event) {
                            return fireEvent(type, event);
                        };
                        Object.append(el, Element.Prototype);
                    }
                    return el;
                },
                object: function(obj, nocash, doc) {
                    if (obj.toElement) return types.element(obj.toElement(doc), nocash);
                    return null;
                }
            };
            types.textnode = types.whitespace = types.window = types.document = function(zero) {
                return zero;
            };
            return function(el, nocash, doc) {
                if (el && el.$family && el.uniqueNumber) return el;
                var type = typeOf(el);
                return (types[type]) ? types[type](el, nocash, doc || document) : null;
            };
        })()
    });
    if (window.$ == null) Window.implement('$', function(el, nc) {
        return document.id(el, nc, this.document);
    });
    Window.implement({
        getDocument: function() {
            return this.document;
        },
        getWindow: function() {
            return this;
        }
    });
    [Document, Element].invoke('implement', {
        getElements: function(expression) {
            return Slick.search(this, expression, new Elements);
        },
        getElement: function(expression) {
            return document.id(Slick.find(this, expression));
        }
    });
    var contains = {
        contains: function(element) {
            return Slick.contains(this, element);
        }
    };
    if (!document.contains) Document.implement(contains);
    if (!document.createElement('div').contains) Element.implement(contains);
    Element.implement('hasChild', function(element) {
        return this !== element && this.contains(element);
    });
    (function(search, find, match) {
        this.Selectors = {};
        var pseudos = this.Selectors.Pseudo = new Hash();
        var addSlickPseudos = function() {
            for (var name in pseudos)
                if (pseudos.hasOwnProperty(name)) {
                    Slick.definePseudo(name, pseudos[name]);
                    delete pseudos[name];
                }
        };
        Slick.search = function(context, expression, append) {
            addSlickPseudos();
            return search.call(this, context, expression, append);
        };
        Slick.find = function(context, expression) {
            addSlickPseudos();
            return find.call(this, context, expression);
        };
        Slick.match = function(node, selector) {
            addSlickPseudos();
            return match.call(this, node, selector);
        };
    })(Slick.search, Slick.find, Slick.match);
    var injectCombinator = function(expression, combinator) {
        if (!expression) return combinator;
        expression = Object.clone(Slick.parse(expression));
        var expressions = expression.expressions;
        for (var i = expressions.length; i--;)
            expressions[i][0].combinator = combinator;
        return expression;
    };
    Object.forEach({
        getNext: '~',
        getPrevious: '!~',
        getParent: '!'
    }, function(combinator, method) {
        Element.implement(method, function(expression) {
            return this.getElement(injectCombinator(expression, combinator));
        });
    });
    Object.forEach({
        getAllNext: '~',
        getAllPrevious: '!~',
        getSiblings: '~~',
        getChildren: '>',
        getParents: '!'
    }, function(combinator, method) {
        Element.implement(method, function(expression) {
            return this.getElements(injectCombinator(expression, combinator));
        });
    });
    Element.implement({
        getFirst: function(expression) {
            return document.id(Slick.search(this, injectCombinator(expression, '>'))[0]);
        },
        getLast: function(expression) {
            return document.id(Slick.search(this, injectCombinator(expression, '>')).getLast());
        },
        getWindow: function() {
            return this.ownerDocument.window;
        },
        getDocument: function() {
            return this.ownerDocument;
        },
        getElementById: function(id) {
            return document.id(Slick.find(this, '#' + ('' + id).replace(/(\W)/g, '\\$1')));
        },
        match: function(expression) {
            return !expression || Slick.match(this, expression);
        }
    });
    if (window.$$ == null) Window.implement('$$', function(selector) {
        var elements = new Elements;
        if (arguments.length == 1 && typeof selector == 'string') return Slick.search(this.document, selector, elements);
        var args = Array.flatten(arguments);
        for (var i = 0, l = args.length; i < l; i++) {
            var item = args[i];
            switch (typeOf(item)) {
                case 'element':
                    elements.push(item);
                    break;
                case 'string':
                    Slick.search(this.document, item, elements);
            }
        }
        return elements;
    });
    if (window.$$ == null) Window.implement('$$', function(selector) {
        if (arguments.length == 1) {
            if (typeof selector == 'string') return Slick.search(this.document, selector, new Elements);
            else if (Type.isEnumerable(selector)) return new Elements(selector);
        }
        return new Elements(arguments);
    });
    var inserters = {
        before: function(context, element) {
            var parent = element.parentNode;
            if (parent) parent.insertBefore(context, element);
        },
        after: function(context, element) {
            var parent = element.parentNode;
            if (parent) parent.insertBefore(context, element.nextSibling);
        },
        bottom: function(context, element) {
            element.appendChild(context);
        },
        top: function(context, element) {
            element.insertBefore(context, element.firstChild);
        }
    };
    inserters.inside = inserters.bottom;
    Object.each(inserters, function(inserter, where) {
        where = where.capitalize();
        var methods = {};
        methods['inject' + where] = function(el) {
            inserter(this, document.id(el, true));
            return this;
        };
        methods['grab' + where] = function(el) {
            inserter(document.id(el, true), this);
            return this;
        };
        Element.implement(methods);
    });
    var propertyGetters = {},
        propertySetters = {};
    var properties = {};
    Array.forEach(['type', 'value', 'defaultValue', 'accessKey', 'cellPadding', 'cellSpacing', 'colSpan', 'frameBorder', 'rowSpan', 'tabIndex', 'useMap'], function(property) {
        properties[property.toLowerCase()] = property;
    });
    properties.html = 'innerHTML';
    properties.text = (document.createElement('div').textContent == null) ? 'innerText' : 'textContent';
    Object.forEach(properties, function(real, key) {
        propertySetters[key] = function(node, value) {
            node[real] = value;
        };
        propertyGetters[key] = function(node) {
            return node[real];
        };
    });
    propertySetters.text = (function(setter) {
        return function(node, value) {
            if (node.get('tag') == 'style') node.set('html', value);
            else node[properties.text] = value;
        };
    })(propertySetters.text);
    propertyGetters.text = (function(getter) {
        return function(node) {
            return (node.get('tag') == 'style') ? node.innerHTML : getter(node);
        };
    })(propertyGetters.text);
    var bools = ['compact', 'nowrap', 'ismap', 'declare', 'noshade', 'checked', 'disabled', 'readOnly', 'multiple', 'selected', 'noresize', 'defer', 'defaultChecked', 'autofocus', 'controls', 'autoplay', 'loop'];
    var booleans = {};
    Array.forEach(bools, function(bool) {
        var lower = bool.toLowerCase();
        booleans[lower] = bool;
        propertySetters[lower] = function(node, value) {
            node[bool] = !!value;
        };
        propertyGetters[lower] = function(node) {
            return !!node[bool];
        };
    });
    Object.append(propertySetters, {
        'class': function(node, value) {
            ('className' in node) ? node.className = (value || ''): node.setAttribute('class', value);
        },
        'for': function(node, value) {
            ('htmlFor' in node) ? node.htmlFor = value: node.setAttribute('for', value);
        },
        'style': function(node, value) {
            (node.style) ? node.style.cssText = value: node.setAttribute('style', value);
        },
        'value': function(node, value) {
            node.value = (value != null) ? value : '';
        }
    });
    propertyGetters['class'] = function(node) {
        return ('className' in node) ? node.className || null : node.getAttribute('class');
    };
    var el = document.createElement('button');
    try {
        el.type = 'button';
    } catch (e) {}
    if (el.type != 'button') propertySetters.type = function(node, value) {
        node.setAttribute('type', value);
    };
    el = null;
    var canChangeStyleHTML = (function() {
        var div = document.createElement('style'),
            flag = false;
        try {
            div.innerHTML = '#justTesing{margin: 0px;}';
            flag = !!div.innerHTML;
        } catch (e) {}
        return flag;
    })();
    var input = document.createElement('input'),
        volatileInputValue, html5InputSupport;
    input.value = 't';
    input.type = 'submit';
    volatileInputValue = input.value != 't';
    try {
        input.type = 'email';
        html5InputSupport = input.type == 'email';
    } catch (e) {}
    input = null;
    if (volatileInputValue || !html5InputSupport) propertySetters.type = function(node, type) {
        try {
            var value = node.value;
            node.type = type;
            node.value = value;
        } catch (e) {}
    };
    var pollutesGetAttribute = (function(div) {
        div.random = 'attribute';
        return (div.getAttribute('random') == 'attribute');
    })(document.createElement('div'));
    var hasCloneBug = (function(test) {
        test.innerHTML = '<object><param name="should_fix" value="the unknown" /></object>';
        return test.cloneNode(true).firstChild.childNodes.length != 1;
    })(document.createElement('div'));
    var hasClassList = !!document.createElement('div').classList;
    var classes = function(className) {
        var classNames = (className || '').clean().split(" "),
            uniques = {};
        return classNames.filter(function(className) {
            if (className !== "" && !uniques[className]) return uniques[className] = className;
        });
    };
    var addToClassList = function(name) {
        this.classList.add(name);
    };
    var removeFromClassList = function(name) {
        this.classList.remove(name);
    };
    Element.implement({
        setProperty: function(name, value) {
            var setter = propertySetters[name.toLowerCase()];
            if (setter) {
                setter(this, value);
            } else {
                var attributeWhiteList;
                if (pollutesGetAttribute) attributeWhiteList = this.retrieve('$attributeWhiteList', {});
                if (value == null) {
                    this.removeAttribute(name);
                    if (pollutesGetAttribute) delete attributeWhiteList[name];
                } else {
                    this.setAttribute(name, '' + value);
                    if (pollutesGetAttribute) attributeWhiteList[name] = true;
                }
            }
            return this;
        },
        setProperties: function(attributes) {
            for (var attribute in attributes) this.setProperty(attribute, attributes[attribute]);
            return this;
        },
        getProperty: function(name) {
            var getter = propertyGetters[name.toLowerCase()];
            if (getter) return getter(this);
            if (pollutesGetAttribute) {
                var attr = this.getAttributeNode(name),
                    attributeWhiteList = this.retrieve('$attributeWhiteList', {});
                if (!attr) return null;
                if (attr.expando && !attributeWhiteList[name]) {
                    var outer = this.outerHTML;
                    if (outer.substr(0, outer.search(/\/?['"]?>(?![^<]*<['"])/)).indexOf(name) < 0) return null;
                    attributeWhiteList[name] = true;
                }
            }
            var result = Slick.getAttribute(this, name);
            return (!result && !Slick.hasAttribute(this, name)) ? null : result;
        },
        getProperties: function() {
            var args = Array.from(arguments);
            return args.map(this.getProperty, this).associate(args);
        },
        removeProperty: function(name) {
            return this.setProperty(name, null);
        },
        removeProperties: function() {
            Array.each(arguments, this.removeProperty, this);
            return this;
        },
        set: function(prop, value) {
            var property = Element.Properties[prop];
            (property && property.set) ? property.set.call(this, value): this.setProperty(prop, value);
        }.overloadSetter(),
        get: function(prop) {
            var property = Element.Properties[prop];
            return (property && property.get) ? property.get.apply(this) : this.getProperty(prop);
        }.overloadGetter(),
        erase: function(prop) {
            var property = Element.Properties[prop];
            (property && property.erase) ? property.erase.apply(this): this.removeProperty(prop);
            return this;
        },
        hasClass: hasClassList ? function(className) {
            return this.classList.contains(className);
        } : function(className) {
            return classes(this.className).contains(className);
        },
        addClass: hasClassList ? function(className) {
            classes(className).forEach(addToClassList, this);
            return this;
        } : function(className) {
            this.className = classes(className + ' ' + this.className).join(' ');
            return this;
        },
        removeClass: hasClassList ? function(className) {
            classes(className).forEach(removeFromClassList, this);
            return this;
        } : function(className) {
            var classNames = classes(this.className);
            classes(className).forEach(classNames.erase, classNames);
            this.className = classNames.join(' ');
            return this;
        },
        toggleClass: function(className, force) {
            if (force == null) force = !this.hasClass(className);
            return (force) ? this.addClass(className) : this.removeClass(className);
        },
        adopt: function() {
            var parent = this,
                fragment, elements = Array.flatten(arguments),
                length = elements.length;
            if (length > 1) parent = fragment = document.createDocumentFragment();
            for (var i = 0; i < length; i++) {
                var element = document.id(elements[i], true);
                if (element) parent.appendChild(element);
            }
            if (fragment) this.appendChild(fragment);
            return this;
        },
        appendText: function(text, where) {
            return this.grab(this.getDocument().newTextNode(text), where);
        },
        grab: function(el, where) {
            inserters[where || 'bottom'](document.id(el, true), this);
            return this;
        },
        inject: function(el, where) {
            inserters[where || 'bottom'](this, document.id(el, true));
            return this;
        },
        replaces: function(el) {
            el = document.id(el, true);
            el.parentNode.replaceChild(this, el);
            return this;
        },
        wraps: function(el, where) {
            el = document.id(el, true);
            return this.replaces(el).grab(el, where);
        },
        getSelected: function() {
            this.selectedIndex;
            return new Elements(Array.from(this.options).filter(function(option) {
                return option.selected;
            }));
        },
        toQueryString: function() {
            var queryString = [];
            this.getElements('input, select, textarea').each(function(el) {
                var type = el.type;
                if (!el.name || el.disabled || type == 'submit' || type == 'reset' || type == 'file' || type == 'image') return;
                var value = (el.get('tag') == 'select') ? el.getSelected().map(function(opt) {
                    return document.id(opt).get('value');
                }) : ((type == 'radio' || type == 'checkbox') && !el.checked) ? null : el.get('value');
                Array.from(value).each(function(val) {
                    if (typeof val != 'undefined') queryString.push(encodeURIComponent(el.name) + '=' + encodeURIComponent(val));
                });
            });
            return queryString.join('&');
        }
    });
    var appendInserters = {
        before: 'beforeBegin',
        after: 'afterEnd',
        bottom: 'beforeEnd',
        top: 'afterBegin',
        inside: 'beforeEnd'
    };
    Element.implement('appendHTML', ('insertAdjacentHTML' in document.createElement('div')) ? function(html, where) {
        this.insertAdjacentHTML(appendInserters[where || 'bottom'], html);
        return this;
    } : function(html, where) {
        var temp = new Element('div', {
                html: html
            }),
            children = temp.childNodes,
            fragment = temp.firstChild;
        if (!fragment) return this;
        if (children.length > 1) {
            fragment = document.createDocumentFragment();
            for (var i = 0, l = children.length; i < l; i++) {
                fragment.appendChild(children[i]);
            }
        }
        inserters[where || 'bottom'](fragment, this);
        return this;
    });
    var collected = {},
        storage = {};
    var get = function(uid) {
        return (storage[uid] || (storage[uid] = {}));
    };
    var clean = function(item) {
        var uid = item.uniqueNumber;
        if (item.removeEvents) item.removeEvents();
        if (item.clearAttributes) item.clearAttributes();
        if (uid != null) {
            delete collected[uid];
            delete storage[uid];
        }
        return item;
    };
    var formProps = {
        input: 'checked',
        option: 'selected',
        textarea: 'value'
    };
    Element.implement({
        destroy: function() {
            var children = clean(this).getElementsByTagName('*');
            Array.each(children, clean);
            Element.dispose(this);
            return null;
        },
        empty: function() {
            Array.from(this.childNodes).each(Element.dispose);
            return this;
        },
        dispose: function() {
            return (this.parentNode) ? this.parentNode.removeChild(this) : this;
        },
        clone: function(contents, keepid) {
            contents = contents !== false;
            var clone = this.cloneNode(contents),
                ce = [clone],
                te = [this],
                i;
            if (contents) {
                ce.append(Array.from(clone.getElementsByTagName('*')));
                te.append(Array.from(this.getElementsByTagName('*')));
            }
            for (i = ce.length; i--;) {
                var node = ce[i],
                    element = te[i];
                if (!keepid) node.removeAttribute('id');
                if (node.clearAttributes) {
                    node.clearAttributes();
                    node.mergeAttributes(element);
                    node.removeAttribute('uniqueNumber');
                    if (node.options) {
                        var no = node.options,
                            eo = element.options;
                        for (var j = no.length; j--;) no[j].selected = eo[j].selected;
                    }
                }
                var prop = formProps[element.tagName.toLowerCase()];
                if (prop && element[prop]) node[prop] = element[prop];
            }
            if (hasCloneBug) {
                var co = clone.getElementsByTagName('object'),
                    to = this.getElementsByTagName('object');
                for (i = co.length; i--;) co[i].outerHTML = to[i].outerHTML;
            }
            return document.id(clone);
        }
    });
    [Element, Window, Document].invoke('implement', {
        addListener: function(type, fn) {
            if (window.attachEvent && !window.addEventListener) {
                collected[Slick.uidOf(this)] = this;
            }
            if (this.addEventListener) this.addEventListener(type, fn, !!arguments[2]);
            else this.attachEvent('on' + type, fn);
            return this;
        },
        removeListener: function(type, fn) {
            if (this.removeEventListener) this.removeEventListener(type, fn, !!arguments[2]);
            else this.detachEvent('on' + type, fn);
            return this;
        },
        retrieve: function(property, dflt) {
            var storage = get(Slick.uidOf(this)),
                prop = storage[property];
            if (dflt != null && prop == null) prop = storage[property] = dflt;
            return prop != null ? prop : null;
        },
        store: function(property, value) {
            var storage = get(Slick.uidOf(this));
            storage[property] = value;
            return this;
        },
        eliminate: function(property) {
            var storage = get(Slick.uidOf(this));
            delete storage[property];
            return this;
        }
    });
    if (window.attachEvent && !window.addEventListener) {
        var gc = function() {
            Object.each(collected, clean);
            if (window.CollectGarbage) CollectGarbage();
            window.removeListener('unload', gc);
        }
        window.addListener('unload', gc);
    }
    Element.Properties = {};
    Element.Properties = new Hash;
    Element.Properties.style = {
        set: function(style) {
            this.style.cssText = style;
        },
        get: function() {
            return this.style.cssText;
        },
        erase: function() {
            this.style.cssText = '';
        }
    };
    Element.Properties.tag = {
        get: function() {
            return this.tagName.toLowerCase();
        }
    };
    Element.Properties.html = {
        set: function(html) {
            if (html == null) html = '';
            else if (typeOf(html) == 'array') html = html.join('');
            if (this.styleSheet && !canChangeStyleHTML) this.styleSheet.cssText = html;
            else this.innerHTML = html;
        },
        erase: function() {
            this.set('html', '');
        }
    };
    var supportsHTML5Elements = true,
        supportsTableInnerHTML = true,
        supportsTRInnerHTML = true;
    var div = document.createElement('div');
    div.innerHTML = '<nav></nav>';
    supportsHTML5Elements = (div.childNodes.length == 1);
    if (!supportsHTML5Elements) {
        var tags = 'abbr article aside audio canvas datalist details figcaption figure footer header hgroup mark meter nav output progress section summary time video'.split(' '),
            fragment = document.createDocumentFragment(),
            l = tags.length;
        while (l--) fragment.createElement(tags[l]);
    }
    div = null;
    supportsTableInnerHTML = Function.attempt(function() {
        var table = document.createElement('table');
        table.innerHTML = '<tr><td></td></tr>';
        return true;
    });
    var tr = document.createElement('tr'),
        html = '<td></td>';
    tr.innerHTML = html;
    supportsTRInnerHTML = (tr.innerHTML == html);
    tr = null;
    if (!supportsTableInnerHTML || !supportsTRInnerHTML || !supportsHTML5Elements) {
        Element.Properties.html.set = (function(set) {
            var translations = {
                table: [1, '<table>', '</table>'],
                select: [1, '<select>', '</select>'],
                tbody: [2, '<table><tbody>', '</tbody></table>'],
                tr: [3, '<table><tbody><tr>', '</tr></tbody></table>']
            };
            translations.thead = translations.tfoot = translations.tbody;
            return function(html) {
                if (this.styleSheet) return set.call(this, html);
                var wrap = translations[this.get('tag')];
                if (!wrap && !supportsHTML5Elements) wrap = [0, '', ''];
                if (!wrap) return set.call(this, html);
                var level = wrap[0],
                    wrapper = document.createElement('div'),
                    target = wrapper;
                if (!supportsHTML5Elements) fragment.appendChild(wrapper);
                wrapper.innerHTML = [wrap[1], html, wrap[2]].flatten().join('');
                while (level--) target = target.firstChild;
                this.empty().adopt(target.childNodes);
                if (!supportsHTML5Elements) fragment.removeChild(wrapper);
                wrapper = null;
            };
        })(Element.Properties.html.set);
    }
    var testForm = document.createElement('form');
    testForm.innerHTML = '<select><option>s</option></select>';
    if (testForm.firstChild.value != 's') Element.Properties.value = {
        set: function(value) {
            var tag = this.get('tag');
            if (tag != 'select') return this.setProperty('value', value);
            var options = this.getElements('option');
            value = String(value);
            for (var i = 0; i < options.length; i++) {
                var option = options[i],
                    attr = option.getAttributeNode('value'),
                    optionValue = (attr && attr.specified) ? option.value : option.get('text');
                if (optionValue === value) return option.selected = true;
            }
        },
        get: function() {
            var option = this,
                tag = option.get('tag');
            if (tag != 'select' && tag != 'option') return this.getProperty('value');
            if (tag == 'select' && !(option = option.getSelected()[0])) return '';
            var attr = option.getAttributeNode('value');
            return (attr && attr.specified) ? option.value : option.get('text');
        }
    };
    testForm = null;
    if (document.createElement('div').getAttributeNode('id')) Element.Properties.id = {
        set: function(id) {
            this.id = this.getAttributeNode('id').value = id;
        },
        get: function() {
            return this.id || null;
        },
        erase: function() {
            this.id = this.getAttributeNode('id').value = '';
        }
    };
})();
(function() {
    var html = document.html,
        el;
    el = document.createElement('div');
    el.style.color = 'red';
    el.style.color = null;
    var doesNotRemoveStyles = el.style.color == 'red';
    var border = '1px solid #123abc';
    el.style.border = border;
    var returnsBordersInWrongOrder = el.style.border != border;
    el = null;
    var hasGetComputedStyle = !!window.getComputedStyle,
        supportBorderRadius = document.createElement('div').style.borderRadius != null;
    Element.Properties.styles = {
        set: function(styles) {
            this.setStyles(styles);
        }
    };
    var hasOpacity = (html.style.opacity != null),
        hasFilter = (html.style.filter != null),
        reAlpha = /alpha\(opacity=([\d.]+)\)/i;
    var setVisibility = function(element, opacity) {
        element.store('$opacity', opacity);
        element.style.visibility = opacity > 0 || opacity == null ? 'visible' : 'hidden';
    };
    var setFilter = function(element, regexp, value) {
        var style = element.style,
            filter = style.filter || element.getComputedStyle('filter') || '';
        style.filter = (regexp.test(filter) ? filter.replace(regexp, value) : filter + ' ' + value).trim();
        if (!style.filter) style.removeAttribute('filter');
    };
    var setOpacity = (hasOpacity ? function(element, opacity) {
        element.style.opacity = opacity;
    } : (hasFilter ? function(element, opacity) {
        if (!element.currentStyle || !element.currentStyle.hasLayout) element.style.zoom = 1;
        if (opacity == null || opacity == 1) {
            setFilter(element, reAlpha, '');
            if (opacity == 1 && getOpacity(element) != 1) setFilter(element, reAlpha, 'alpha(opacity=100)');
        } else {
            setFilter(element, reAlpha, 'alpha(opacity=' + (opacity * 100).limit(0, 100).round() + ')');
        }
    } : setVisibility));
    var getOpacity = (hasOpacity ? function(element) {
        var opacity = element.style.opacity || element.getComputedStyle('opacity');
        return (opacity == '') ? 1 : opacity.toFloat();
    } : (hasFilter ? function(element) {
        var filter = (element.style.filter || element.getComputedStyle('filter')),
            opacity;
        if (filter) opacity = filter.match(reAlpha);
        return (opacity == null || filter == null) ? 1 : (opacity[1] / 100);
    } : function(element) {
        var opacity = element.retrieve('$opacity');
        if (opacity == null) opacity = (element.style.visibility == 'hidden' ? 0 : 1);
        return opacity;
    }));
    var floatName = (html.style.cssFloat == null) ? 'styleFloat' : 'cssFloat',
        namedPositions = {
            left: '0%',
            top: '0%',
            center: '50%',
            right: '100%',
            bottom: '100%'
        },
        hasBackgroundPositionXY = (html.style.backgroundPositionX != null);
    var removeStyle = function(style, property) {
        if (property == 'backgroundPosition') {
            style.removeAttribute(property + 'X');
            property += 'Y';
        }
        style.removeAttribute(property);
    };
    Element.implement({
        getComputedStyle: function(property) {
            if (!hasGetComputedStyle && this.currentStyle) return this.currentStyle[property.camelCase()];
            var defaultView = Element.getDocument(this).defaultView,
                computed = defaultView ? defaultView.getComputedStyle(this, null) : null;
            return (computed) ? computed.getPropertyValue((property == floatName) ? 'float' : property.hyphenate()) : '';
        },
        setStyle: function(property, value) {
            if (property == 'opacity') {
                if (value != null) value = parseFloat(value);
                setOpacity(this, value);
                return this;
            }
            property = (property == 'float' ? floatName : property).camelCase();
            if (typeOf(value) != 'string') {
                var map = (Element.Styles[property] || '@').split(' ');
                value = Array.from(value).map(function(val, i) {
                    if (!map[i]) return '';
                    return (typeOf(val) == 'number') ? map[i].replace('@', Math.round(val)) : val;
                }).join(' ');
            } else if (value == String(Number(value))) {
                value = Math.round(value);
            }
            this.style[property] = value;
            if ((value == '' || value == null) && doesNotRemoveStyles && this.style.removeAttribute) {
                removeStyle(this.style, property);
            }
            return this;
        },
        getStyle: function(property) {
            if (property == 'opacity') return getOpacity(this);
            property = (property == 'float' ? floatName : property).camelCase();
            if (supportBorderRadius && property.indexOf('borderRadius') != -1) {
                return ['borderTopLeftRadius', 'borderTopRightRadius', 'borderBottomRightRadius', 'borderBottomLeftRadius'].map(function(corner) {
                    return this.style[corner] || '0px';
                }, this).join(' ');
            }
            var result = this.style[property];
            if (!result || property == 'zIndex') {
                if (Element.ShortStyles.hasOwnProperty(property)) {
                    result = [];
                    for (var s in Element.ShortStyles[property]) result.push(this.getStyle(s));
                    return result.join(' ');
                }
                result = this.getComputedStyle(property);
            }
            if (hasBackgroundPositionXY && /^backgroundPosition[XY]?$/.test(property)) {
                return result.replace(/(top|right|bottom|left)/g, function(position) {
                    return namedPositions[position];
                }) || '0px';
            }
            if (!result && property == 'backgroundPosition') return '0px 0px';
            if (result) {
                result = String(result);
                var color = result.match(/rgba?\([\d\s,]+\)/);
                if (color) result = result.replace(color[0], color[0].rgbToHex());
            }
            if (!hasGetComputedStyle && !this.style[property]) {
                if ((/^(height|width)$/).test(property) && !(/px$/.test(result))) {
                    var values = (property == 'width') ? ['left', 'right'] : ['top', 'bottom'],
                        size = 0;
                    values.each(function(value) {
                        size += this.getStyle('border-' + value + '-width').toInt() + this.getStyle('padding-' + value).toInt();
                    }, this);
                    return this['offset' + property.capitalize()] - size + 'px';
                }
                if ((/^border(.+)Width|margin|padding/).test(property) && isNaN(parseFloat(result))) {
                    return '0px';
                }
            }
            if (returnsBordersInWrongOrder && /^border(Top|Right|Bottom|Left)?$/.test(property) && /^#/.test(result)) {
                return result.replace(/^(.+)\s(.+)\s(.+)$/, '$2 $3 $1');
            }
            return result;
        },
        setStyles: function(styles) {
            for (var style in styles) this.setStyle(style, styles[style]);
            return this;
        },
        getStyles: function() {
            var result = {};
            Array.flatten(arguments).each(function(key) {
                result[key] = this.getStyle(key);
            }, this);
            return result;
        }
    });
    Element.Styles = {
        left: '@px',
        top: '@px',
        bottom: '@px',
        right: '@px',
        width: '@px',
        height: '@px',
        maxWidth: '@px',
        maxHeight: '@px',
        minWidth: '@px',
        minHeight: '@px',
        backgroundColor: 'rgb(@, @, @)',
        backgroundSize: '@px',
        backgroundPosition: '@px @px',
        color: 'rgb(@, @, @)',
        fontSize: '@px',
        letterSpacing: '@px',
        lineHeight: '@px',
        clip: 'rect(@px @px @px @px)',
        margin: '@px @px @px @px',
        padding: '@px @px @px @px',
        border: '@px @ rgb(@, @, @) @px @ rgb(@, @, @) @px @ rgb(@, @, @)',
        borderWidth: '@px @px @px @px',
        borderStyle: '@ @ @ @',
        borderColor: 'rgb(@, @, @) rgb(@, @, @) rgb(@, @, @) rgb(@, @, @)',
        zIndex: '@',
        'zoom': '@',
        fontWeight: '@',
        textIndent: '@px',
        opacity: '@',
        borderRadius: '@px @px @px @px'
    };
    Element.implement({
        setOpacity: function(value) {
            setOpacity(this, value);
            return this;
        },
        getOpacity: function() {
            return getOpacity(this);
        }
    });
    Element.Properties.opacity = {
        set: function(opacity) {
            setOpacity(this, opacity);
            setVisibility(this, opacity);
        },
        get: function() {
            return getOpacity(this);
        }
    };
    Element.Styles = new Hash(Element.Styles);
    Element.ShortStyles = {
        margin: {},
        padding: {},
        border: {},
        borderWidth: {},
        borderStyle: {},
        borderColor: {}
    };
    ['Top', 'Right', 'Bottom', 'Left'].each(function(direction) {
        var Short = Element.ShortStyles;
        var All = Element.Styles;
        ['margin', 'padding'].each(function(style) {
            var sd = style + direction;
            Short[style][sd] = All[sd] = '@px';
        });
        var bd = 'border' + direction;
        Short.border[bd] = All[bd] = '@px @ rgb(@, @, @)';
        var bdw = bd + 'Width',
            bds = bd + 'Style',
            bdc = bd + 'Color';
        Short[bd] = {};
        Short.borderWidth[bdw] = Short[bd][bdw] = All[bdw] = '@px';
        Short.borderStyle[bds] = Short[bd][bds] = All[bds] = '@';
        Short.borderColor[bdc] = Short[bd][bdc] = All[bdc] = 'rgb(@, @, @)';
    });
    if (hasBackgroundPositionXY) Element.ShortStyles.backgroundPosition = {
        backgroundPositionX: '@',
        backgroundPositionY: '@'
    };
})();
(function() {
    Element.Properties.events = {
        set: function(events) {
            this.addEvents(events);
        }
    };
    [Element, Window, Document].invoke('implement', {
        addEvent: function(type, fn) {
            var events = this.retrieve('events', {});
            if (!events[type]) events[type] = {
                keys: [],
                values: []
            };
            if (events[type].keys.contains(fn)) return this;
            events[type].keys.push(fn);
            var realType = type,
                custom = Element.Events[type],
                condition = fn,
                self = this;
            if (custom) {
                if (custom.onAdd) custom.onAdd.call(this, fn, type);
                if (custom.condition) {
                    condition = function(event) {
                        if (custom.condition.call(this, event, type)) return fn.call(this, event);
                        return true;
                    };
                }
                if (custom.base) realType = Function.from(custom.base).call(this, type);
            }
            var defn = function() {
                return fn.call(self);
            };
            var nativeEvent = Element.NativeEvents[realType];
            if (nativeEvent) {
                if (nativeEvent == 2) {
                    defn = function(event) {
                        event = new DOMEvent(event, self.getWindow());
                        if (condition.call(self, event) === false) event.stop();
                    };
                }
                this.addListener(realType, defn, arguments[2]);
            }
            events[type].values.push(defn);
            return this;
        },
        removeEvent: function(type, fn) {
            var events = this.retrieve('events');
            if (!events || !events[type]) return this;
            var list = events[type];
            var index = list.keys.indexOf(fn);
            if (index == -1) return this;
            var value = list.values[index];
            delete list.keys[index];
            delete list.values[index];
            var custom = Element.Events[type];
            if (custom) {
                if (custom.onRemove) custom.onRemove.call(this, fn, type);
                if (custom.base) type = Function.from(custom.base).call(this, type);
            }
            return (Element.NativeEvents[type]) ? this.removeListener(type, value, arguments[2]) : this;
        },
        addEvents: function(events) {
            for (var event in events) this.addEvent(event, events[event]);
            return this;
        },
        removeEvents: function(events) {
            var type;
            if (typeOf(events) == 'object') {
                for (type in events) this.removeEvent(type, events[type]);
                return this;
            }
            var attached = this.retrieve('events');
            if (!attached) return this;
            if (!events) {
                for (type in attached) this.removeEvents(type);
                this.eliminate('events');
            } else if (attached[events]) {
                attached[events].keys.each(function(fn) {
                    this.removeEvent(events, fn);
                }, this);
                delete attached[events];
            }
            return this;
        },
        fireEvent: function(type, args, delay) {
            var events = this.retrieve('events');
            if (!events || !events[type]) return this;
            args = Array.from(args);
            events[type].keys.each(function(fn) {
                if (delay) fn.delay(delay, this, args);
                else fn.apply(this, args);
            }, this);
            return this;
        },
        cloneEvents: function(from, type) {
            from = document.id(from);
            var events = from.retrieve('events');
            if (!events) return this;
            if (!type) {
                for (var eventType in events) this.cloneEvents(from, eventType);
            } else if (events[type]) {
                events[type].keys.each(function(fn) {
                    this.addEvent(type, fn);
                }, this);
            }
            return this;
        }
    });
    Element.NativeEvents = {
        click: 2,
        dblclick: 2,
        mouseup: 2,
        mousedown: 2,
        contextmenu: 2,
        wheel: 2,
        mousewheel: 2,
        DOMMouseScroll: 2,
        mouseover: 2,
        mouseout: 2,
        mousemove: 2,
        selectstart: 2,
        selectend: 2,
        keydown: 2,
        keypress: 2,
        keyup: 2,
        orientationchange: 2,
        touchstart: 2,
        touchmove: 2,
        touchend: 2,
        touchcancel: 2,
        gesturestart: 2,
        gesturechange: 2,
        gestureend: 2,
        focus: 2,
        blur: 2,
        change: 2,
        reset: 2,
        select: 2,
        submit: 2,
        paste: 2,
        input: 2,
        load: 2,
        unload: 1,
        beforeunload: 2,
        resize: 1,
        move: 1,
        DOMContentLoaded: 1,
        readystatechange: 1,
        hashchange: 1,
        popstate: 2,
        error: 1,
        abort: 1,
        scroll: 1,
        message: 2
    };
    Element.Events = {
        mousewheel: {
            base: 'onwheel' in document ? 'wheel' : 'onmousewheel' in document ? 'mousewheel' : 'DOMMouseScroll'
        }
    };
    var check = function(event) {
        var related = event.relatedTarget;
        if (related == null) return true;
        if (!related) return false;
        return (related != this && related.prefix != 'xul' && typeOf(this) != 'document' && !this.contains(related));
    };
    if ('onmouseenter' in document.documentElement) {
        Element.NativeEvents.mouseenter = Element.NativeEvents.mouseleave = 2;
        Element.MouseenterCheck = check;
    } else {
        Element.Events.mouseenter = {
            base: 'mouseover',
            condition: check
        };
        Element.Events.mouseleave = {
            base: 'mouseout',
            condition: check
        };
    }
    if (!window.addEventListener) {
        Element.NativeEvents.propertychange = 2;
        Element.Events.change = {
            base: function() {
                var type = this.type;
                return (this.get('tag') == 'input' && (type == 'radio' || type == 'checkbox')) ? 'propertychange' : 'change';
            },
            condition: function(event) {
                return event.type != 'propertychange' || event.event.propertyName == 'checked';
            }
        };
    }
    Element.Events = new Hash(Element.Events);
})();
(function() {
    var eventListenerSupport = !!window.addEventListener;
    Element.NativeEvents.focusin = Element.NativeEvents.focusout = 2;
    var bubbleUp = function(self, match, fn, event, target) {
        while (target && target != self) {
            if (match(target, event)) return fn.call(target, event, target);
            target = document.id(target.parentNode);
        }
    };
    var map = {
        mouseenter: {
            base: 'mouseover',
            condition: Element.MouseenterCheck
        },
        mouseleave: {
            base: 'mouseout',
            condition: Element.MouseenterCheck
        },
        focus: {
            base: 'focus' + (eventListenerSupport ? '' : 'in'),
            capture: true
        },
        blur: {
            base: eventListenerSupport ? 'blur' : 'focusout',
            capture: true
        }
    };
    var _key = '$delegation:';
    var formObserver = function(type) {
        return {
            base: 'focusin',
            remove: function(self, uid) {
                var list = self.retrieve(_key + type + 'listeners', {})[uid];
                if (list && list.forms)
                    for (var i = list.forms.length; i--;) {
                        if (list.forms[i].removeEvent) list.forms[i].removeEvent(type, list.fns[i]);
                    }
            },
            listen: function(self, match, fn, event, target, uid) {
                var form = (target.get('tag') == 'form') ? target : event.target.getParent('form');
                if (!form) return;
                var listeners = self.retrieve(_key + type + 'listeners', {}),
                    listener = listeners[uid] || {
                        forms: [],
                        fns: []
                    },
                    forms = listener.forms,
                    fns = listener.fns;
                if (forms.indexOf(form) != -1) return;
                forms.push(form);
                var _fn = function(event) {
                    bubbleUp(self, match, fn, event, target);
                };
                form.addEvent(type, _fn);
                fns.push(_fn);
                listeners[uid] = listener;
                self.store(_key + type + 'listeners', listeners);
            }
        };
    };
    var inputObserver = function(type) {
        return {
            base: 'focusin',
            listen: function(self, match, fn, event, target) {
                var events = {
                    blur: function() {
                        this.removeEvents(events);
                    }
                };
                events[type] = function(event) {
                    bubbleUp(self, match, fn, event, target);
                };
                event.target.addEvents(events);
            }
        };
    };
    if (!eventListenerSupport) Object.append(map, {
        submit: formObserver('submit'),
        reset: formObserver('reset'),
        change: inputObserver('change'),
        select: inputObserver('select')
    });
    var proto = Element.prototype,
        addEvent = proto.addEvent,
        removeEvent = proto.removeEvent;
    var relay = function(old, method) {
        return function(type, fn, useCapture) {
            if (type.indexOf(':relay') == -1) return old.call(this, type, fn, useCapture);
            var parsed = Slick.parse(type).expressions[0][0];
            if (parsed.pseudos[0].key != 'relay') return old.call(this, type, fn, useCapture);
            var newType = parsed.tag;
            parsed.pseudos.slice(1).each(function(pseudo) {
                newType += ':' + pseudo.key + (pseudo.value ? '(' + pseudo.value + ')' : '');
            });
            old.call(this, type, fn);
            return method.call(this, newType, parsed.pseudos[0].value, fn);
        };
    };
    var delegation = {
        addEvent: function(type, match, fn) {
            var storage = this.retrieve('$delegates', {}),
                stored = storage[type];
            if (stored)
                for (var _uid in stored) {
                    if (stored[_uid].fn == fn && stored[_uid].match == match) return this;
                }
            var _type = type,
                _match = match,
                _fn = fn,
                _map = map[type] || {};
            type = _map.base || _type;
            match = function(target) {
                return Slick.match(target, _match);
            };
            var elementEvent = Element.Events[_type];
            if (_map.condition || elementEvent && elementEvent.condition) {
                var __match = match,
                    condition = _map.condition || elementEvent.condition;
                match = function(target, event) {
                    return __match(target, event) && condition.call(target, event, type);
                };
            }
            var self = this,
                uid = String.uniqueID();
            var delegator = _map.listen ? function(event, target) {
                if (!target && event && event.target) target = event.target;
                if (target) _map.listen(self, match, fn, event, target, uid);
            } : function(event, target) {
                if (!target && event && event.target) target = event.target;
                if (target) bubbleUp(self, match, fn, event, target);
            };
            if (!stored) stored = {};
            stored[uid] = {
                match: _match,
                fn: _fn,
                delegator: delegator
            };
            storage[_type] = stored;
            return addEvent.call(this, type, delegator, _map.capture);
        },
        removeEvent: function(type, match, fn, _uid) {
            var storage = this.retrieve('$delegates', {}),
                stored = storage[type];
            if (!stored) return this;
            if (_uid) {
                var _type = type,
                    delegator = stored[_uid].delegator,
                    _map = map[type] || {};
                type = _map.base || _type;
                if (_map.remove) _map.remove(this, _uid);
                delete stored[_uid];
                storage[_type] = stored;
                return removeEvent.call(this, type, delegator, _map.capture);
            }
            var __uid, s;
            if (fn)
                for (__uid in stored) {
                    s = stored[__uid];
                    if (s.match == match && s.fn == fn) return delegation.removeEvent.call(this, type, match, fn, __uid);
                } else
                    for (__uid in stored) {
                        s = stored[__uid];
                        if (s.match == match) delegation.removeEvent.call(this, type, match, s.fn, __uid);
                    }
            return this;
        }
    };
    [Element, Window, Document].invoke('implement', {
        addEvent: relay(addEvent, delegation.addEvent),
        removeEvent: relay(removeEvent, delegation.removeEvent)
    });
})();
(function() {
    var element = document.createElement('div'),
        child = document.createElement('div');
    element.style.height = '0';
    element.appendChild(child);
    var brokenOffsetParent = (child.offsetParent === element);
    element = child = null;
    var heightComponents = ['height', 'paddingTop', 'paddingBottom', 'borderTopWidth', 'borderBottomWidth'],
        widthComponents = ['width', 'paddingLeft', 'paddingRight', 'borderLeftWidth', 'borderRightWidth'];
    var svgCalculateSize = function(el) {
        var gCS = window.getComputedStyle(el),
            bounds = {
                x: 0,
                y: 0
            };
        heightComponents.each(function(css) {
            bounds.y += parseFloat(gCS[css]);
        });
        widthComponents.each(function(css) {
            bounds.x += parseFloat(gCS[css]);
        });
        return bounds;
    };
    var isOffset = function(el) {
        return styleString(el, 'position') != 'static' || isBody(el);
    };
    var isOffsetStatic = function(el) {
        return isOffset(el) || (/^(?:table|td|th)$/i).test(el.tagName);
    };
    Element.implement({
        scrollTo: function(x, y) {
            if (isBody(this)) {
                this.getWindow().scrollTo(x, y);
            } else {
                this.scrollLeft = x;
                this.scrollTop = y;
            }
            return this;
        },
        getSize: function() {
            if (isBody(this)) return this.getWindow().getSize();
            if (!window.getComputedStyle) return {
                x: this.offsetWidth,
                y: this.offsetHeight
            };
            if (this.get('tag') == 'svg') return svgCalculateSize(this);
            var bounds = this.getBoundingClientRect();
            return {
                x: bounds.width,
                y: bounds.height
            };
        },
        getScrollSize: function() {
            if (isBody(this)) return this.getWindow().getScrollSize();
            return {
                x: this.scrollWidth,
                y: this.scrollHeight
            };
        },
        getScroll: function() {
            if (isBody(this)) return this.getWindow().getScroll();
            return {
                x: this.scrollLeft,
                y: this.scrollTop
            };
        },
        getScrolls: function() {
            var element = this.parentNode,
                position = {
                    x: 0,
                    y: 0
                };
            while (element && !isBody(element)) {
                position.x += element.scrollLeft;
                position.y += element.scrollTop;
                element = element.parentNode;
            }
            return position;
        },
        getOffsetParent: brokenOffsetParent ? function() {
            var element = this;
            if (isBody(element) || styleString(element, 'position') == 'fixed') return null;
            var isOffsetCheck = (styleString(element, 'position') == 'static') ? isOffsetStatic : isOffset;
            while ((element = element.parentNode)) {
                if (isOffsetCheck(element)) return element;
            }
            return null;
        } : function() {
            var element = this;
            if (isBody(element) || styleString(element, 'position') == 'fixed') return null;
            try {
                return element.offsetParent;
            } catch (e) {}
            return null;
        },
        getOffsets: function() {
            var hasGetBoundingClientRect = this.getBoundingClientRect;
            hasGetBoundingClientRect = hasGetBoundingClientRect && !Browser.Platform.ios
            if (hasGetBoundingClientRect) {
                var bound = this.getBoundingClientRect(),
                    html = document.id(this.getDocument().documentElement),
                    htmlScroll = html.getScroll(),
                    elemScrolls = this.getScrolls(),
                    isFixed = (styleString(this, 'position') == 'fixed');
                return {
                    x: bound.left.toInt() + elemScrolls.x + ((isFixed) ? 0 : htmlScroll.x) - html.clientLeft,
                    y: bound.top.toInt() + elemScrolls.y + ((isFixed) ? 0 : htmlScroll.y) - html.clientTop
                };
            }
            var element = this,
                position = {
                    x: 0,
                    y: 0
                };
            if (isBody(this)) return position;
            while (element && !isBody(element)) {
                position.x += element.offsetLeft;
                position.y += element.offsetTop;
                if (Browser.firefox) {
                    if (!borderBox(element)) {
                        position.x += leftBorder(element);
                        position.y += topBorder(element);
                    }
                    var parent = element.parentNode;
                    if (parent && styleString(parent, 'overflow') != 'visible') {
                        position.x += leftBorder(parent);
                        position.y += topBorder(parent);
                    }
                } else if (element != this && Browser.safari) {
                    position.x += leftBorder(element);
                    position.y += topBorder(element);
                }
                element = element.offsetParent;
            }
            if (Browser.firefox && !borderBox(this)) {
                position.x -= leftBorder(this);
                position.y -= topBorder(this);
            }
            return position;
        },
        getPosition: function(relative) {
            var offset = this.getOffsets(),
                scroll = this.getScrolls();
            var position = {
                x: offset.x - scroll.x,
                y: offset.y - scroll.y
            };
            if (relative && (relative = document.id(relative))) {
                var relativePosition = relative.getPosition();
                return {
                    x: position.x - relativePosition.x - leftBorder(relative),
                    y: position.y - relativePosition.y - topBorder(relative)
                };
            }
            return position;
        },
        getCoordinates: function(element) {
            if (isBody(this)) return this.getWindow().getCoordinates();
            var position = this.getPosition(element),
                size = this.getSize();
            var obj = {
                left: position.x,
                top: position.y,
                width: size.x,
                height: size.y
            };
            obj.right = obj.left + obj.width;
            obj.bottom = obj.top + obj.height;
            return obj;
        },
        computePosition: function(obj) {
            return {
                left: obj.x - styleNumber(this, 'margin-left'),
                top: obj.y - styleNumber(this, 'margin-top')
            };
        },
        setPosition: function(obj) {
            return this.setStyles(this.computePosition(obj));
        }
    });
    [Document, Window].invoke('implement', {
        getSize: function() {
            var doc = getCompatElement(this);
            return {
                x: doc.clientWidth,
                y: doc.clientHeight
            };
        },
        getScroll: function() {
            var win = this.getWindow(),
                doc = getCompatElement(this);
            return {
                x: win.pageXOffset || doc.scrollLeft,
                y: win.pageYOffset || doc.scrollTop
            };
        },
        getScrollSize: function() {
            var doc = getCompatElement(this),
                min = this.getSize(),
                body = this.getDocument().body;
            return {
                x: Math.max(doc.scrollWidth, body.scrollWidth, min.x),
                y: Math.max(doc.scrollHeight, body.scrollHeight, min.y)
            };
        },
        getPosition: function() {
            return {
                x: 0,
                y: 0
            };
        },
        getCoordinates: function() {
            var size = this.getSize();
            return {
                top: 0,
                left: 0,
                bottom: size.y,
                right: size.x,
                height: size.y,
                width: size.x
            };
        }
    });
    var styleString = Element.getComputedStyle;

    function styleNumber(element, style) {
        return styleString(element, style).toInt() || 0;
    }

    function borderBox(element) {
        return styleString(element, '-moz-box-sizing') == 'border-box';
    }

    function topBorder(element) {
        return styleNumber(element, 'border-top-width');
    }

    function leftBorder(element) {
        return styleNumber(element, 'border-left-width');
    }

    function isBody(element) {
        return (/^(?:body|html)$/i).test(element.tagName);
    }

    function getCompatElement(element) {
        var doc = element.getDocument();
        return (!doc.compatMode || doc.compatMode == 'CSS1Compat') ? doc.html : doc.body;
    }
})();
Element.alias({
    position: 'setPosition'
});
[Window, Document, Element].invoke('implement', {
    getHeight: function() {
        return this.getSize().y;
    },
    getWidth: function() {
        return this.getSize().x;
    },
    getScrollTop: function() {
        return this.getScroll().y;
    },
    getScrollLeft: function() {
        return this.getScroll().x;
    },
    getScrollHeight: function() {
        return this.getScrollSize().y;
    },
    getScrollWidth: function() {
        return this.getScrollSize().x;
    },
    getTop: function() {
        return this.getPosition().y;
    },
    getLeft: function() {
        return this.getPosition().x;
    }
});
(function() {
    var Fx = this.Fx = new Class({
        Implements: [Chain, Events, Options],
        options: {
            fps: 60,
            unit: false,
            duration: 500,
            frames: null,
            frameSkip: true,
            link: 'ignore'
        },
        initialize: function(options) {
            this.subject = this.subject || this;
            this.setOptions(options);
        },
        getTransition: function() {
            return function(p) {
                return -(Math.cos(Math.PI * p) - 1) / 2;
            };
        },
        step: function(now) {
            if (this.options.frameSkip) {
                var diff = (this.time != null) ? (now - this.time) : 0,
                    frames = diff / this.frameInterval;
                this.time = now;
                this.frame += frames;
            } else {
                this.frame++;
            }
            if (this.frame < this.frames) {
                var delta = this.transition(this.frame / this.frames);
                this.set(this.compute(this.from, this.to, delta));
            } else {
                this.frame = this.frames;
                this.set(this.compute(this.from, this.to, 1));
                this.stop();
            }
        },
        set: function(now) {
            return now;
        },
        compute: function(from, to, delta) {
            return Fx.compute(from, to, delta);
        },
        check: function() {
            if (!this.isRunning()) return true;
            switch (this.options.link) {
                case 'cancel':
                    this.cancel();
                    return true;
                case 'chain':
                    this.chain(this.caller.pass(arguments, this));
                    return false;
            }
            return false;
        },
        start: function(from, to) {
            if (!this.check(from, to)) return this;
            this.from = from;
            this.to = to;
            this.frame = (this.options.frameSkip) ? 0 : -1;
            this.time = null;
            this.transition = this.getTransition();
            var frames = this.options.frames,
                fps = this.options.fps,
                duration = this.options.duration;
            this.duration = Fx.Durations[duration] || duration.toInt();
            this.frameInterval = 1000 / fps;
            this.frames = frames || Math.round(this.duration / this.frameInterval);
            this.fireEvent('start', this.subject);
            pushInstance.call(this, fps);
            return this;
        },
        stop: function() {
            if (this.isRunning()) {
                this.time = null;
                pullInstance.call(this, this.options.fps);
                if (this.frames == this.frame) {
                    this.fireEvent('complete', this.subject);
                    if (!this.callChain()) this.fireEvent('chainComplete', this.subject);
                } else {
                    this.fireEvent('stop', this.subject);
                }
            }
            return this;
        },
        cancel: function() {
            if (this.isRunning()) {
                this.time = null;
                pullInstance.call(this, this.options.fps);
                this.frame = this.frames;
                this.fireEvent('cancel', this.subject).clearChain();
            }
            return this;
        },
        pause: function() {
            if (this.isRunning()) {
                this.time = null;
                pullInstance.call(this, this.options.fps);
            }
            return this;
        },
        resume: function() {
            if (this.isPaused()) pushInstance.call(this, this.options.fps);
            return this;
        },
        isRunning: function() {
            var list = instances[this.options.fps];
            return list && list.contains(this);
        },
        isPaused: function() {
            return (this.frame < this.frames) && !this.isRunning();
        }
    });
    Fx.compute = function(from, to, delta) {
        return (to - from) * delta + from;
    };
    Fx.Durations = {
        'short': 250,
        'normal': 500,
        'long': 1000
    };
    var instances = {},
        timers = {};
    var loop = function() {
        var now = Date.now();
        for (var i = this.length; i--;) {
            var instance = this[i];
            if (instance) instance.step(now);
        }
    };
    var pushInstance = function(fps) {
        var list = instances[fps] || (instances[fps] = []);
        list.push(this);
        if (!timers[fps]) timers[fps] = loop.periodical(Math.round(1000 / fps), list);
    };
    var pullInstance = function(fps) {
        var list = instances[fps];
        if (list) {
            list.erase(this);
            if (!list.length && timers[fps]) {
                delete instances[fps];
                timers[fps] = clearInterval(timers[fps]);
            }
        }
    };
})();
Fx.CSS = new Class({
    Extends: Fx,
    prepare: function(element, property, values) {
        values = Array.from(values);
        var from = values[0],
            to = values[1];
        if (to == null) {
            to = from;
            from = element.getStyle(property);
            var unit = this.options.unit;
            if (unit && from && typeof from == 'string' && from.slice(-unit.length) != unit && parseFloat(from) != 0) {
                element.setStyle(property, to + unit);
                var value = element.getComputedStyle(property);
                if (!(/px$/.test(value))) {
                    value = element.style[('pixel-' + property).camelCase()];
                    if (value == null) {
                        var left = element.style.left;
                        element.style.left = to + unit;
                        value = element.style.pixelLeft;
                        element.style.left = left;
                    }
                }
                from = (to || 1) / (parseFloat(value) || 1) * (parseFloat(from) || 0);
                element.setStyle(property, from + unit);
            }
        }
        return {
            from: this.parse(from),
            to: this.parse(to)
        };
    },
    parse: function(value) {
        value = Function.from(value)();
        value = (typeof value == 'string') ? value.split(' ') : Array.from(value);
        return value.map(function(val) {
            val = String(val);
            var found = false;
            Object.each(Fx.CSS.Parsers, function(parser, key) {
                if (found) return;
                var parsed = parser.parse(val);
                if (parsed || parsed === 0) found = {
                    value: parsed,
                    parser: parser
                };
            });
            found = found || {
                value: val,
                parser: Fx.CSS.Parsers.String
            };
            return found;
        });
    },
    compute: function(from, to, delta) {
        var computed = [];
        (Math.min(from.length, to.length)).times(function(i) {
            computed.push({
                value: from[i].parser.compute(from[i].value, to[i].value, delta),
                parser: from[i].parser
            });
        });
        computed.$family = Function.from('fx:css:value');
        return computed;
    },
    serve: function(value, unit) {
        if (typeOf(value) != 'fx:css:value') value = this.parse(value);
        var returned = [];
        value.each(function(bit) {
            returned = returned.concat(bit.parser.serve(bit.value, unit));
        });
        return returned;
    },
    render: function(element, property, value, unit) {
        element.setStyle(property, this.serve(value, unit));
    },
    search: function(selector) {
        if (Fx.CSS.Cache[selector]) return Fx.CSS.Cache[selector];
        var to = {},
            selectorTest = new RegExp('^' + selector.escapeRegExp() + '$');
        var searchStyles = function(rules) {
            Array.each(rules, function(rule, i) {
                if (rule.media) {
                    searchStyles(rule.rules || rule.cssRules);
                    return;
                }
                if (!rule.style) return;
                var selectorText = (rule.selectorText) ? rule.selectorText.replace(/^\w+/, function(m) {
                    return m.toLowerCase();
                }) : null;
                if (!selectorText || !selectorTest.test(selectorText)) return;
                Object.each(Element.Styles, function(value, style) {
                    if (!rule.style[style] || Element.ShortStyles[style]) return;
                    value = String(rule.style[style]);
                    to[style] = ((/^rgb/).test(value)) ? value.rgbToHex() : value;
                });
            });
        };
        Array.each(document.styleSheets, function(sheet, j) {
            var href = sheet.href;
            if (href && href.indexOf('://') > -1 && href.indexOf(document.domain) == -1) return;
            var rules = sheet.rules || sheet.cssRules;
            searchStyles(rules);
        });
        return Fx.CSS.Cache[selector] = to;
    }
});
Fx.CSS.Cache = {};
Fx.CSS.Parsers = {
    Color: {
        parse: function(value) {
            if (value.match(/^#[0-9a-f]{3,6}$/i)) return value.hexToRgb(true);
            return ((value = value.match(/(\d+),\s*(\d+),\s*(\d+)/))) ? [value[1], value[2], value[3]] : false;
        },
        compute: function(from, to, delta) {
            return from.map(function(value, i) {
                return Math.round(Fx.compute(from[i], to[i], delta));
            });
        },
        serve: function(value) {
            return value.map(Number);
        }
    },
    Number: {
        parse: parseFloat,
        compute: Fx.compute,
        serve: function(value, unit) {
            return (unit) ? value + unit : value;
        }
    },
    String: {
        parse: Function.from(false),
        compute: function(zero, one) {
            return one;
        },
        serve: function(zero) {
            return zero;
        }
    }
};
Fx.CSS.Parsers = new Hash(Fx.CSS.Parsers);
Fx.Tween = new Class({
    Extends: Fx.CSS,
    initialize: function(element, options) {
        this.element = this.subject = document.id(element);
        this.parent(options);
    },
    set: function(property, now) {
        if (arguments.length == 1) {
            now = property;
            property = this.property || this.options.property;
        }
        this.render(this.element, property, now, this.options.unit);
        return this;
    },
    start: function(property, from, to) {
        if (!this.check(property, from, to)) return this;
        var args = Array.flatten(arguments);
        this.property = this.options.property || args.shift();
        var parsed = this.prepare(this.element, this.property, args);
        return this.parent(parsed.from, parsed.to);
    }
});
Element.Properties.tween = {
    set: function(options) {
        this.get('tween').cancel().setOptions(options);
        return this;
    },
    get: function() {
        var tween = this.retrieve('tween');
        if (!tween) {
            tween = new Fx.Tween(this, {
                link: 'cancel'
            });
            this.store('tween', tween);
        }
        return tween;
    }
};
Element.implement({
    tween: function(property, from, to) {
        this.get('tween').start(property, from, to);
        return this;
    },
    fade: function(how) {
        var fade = this.get('tween'),
            method, args = ['opacity'].append(arguments),
            toggle;
        if (args[1] == null) args[1] = 'toggle';
        switch (args[1]) {
            case 'in':
                method = 'start';
                args[1] = 1;
                break;
            case 'out':
                method = 'start';
                args[1] = 0;
                break;
            case 'show':
                method = 'set';
                args[1] = 1;
                break;
            case 'hide':
                method = 'set';
                args[1] = 0;
                break;
            case 'toggle':
                var flag = this.retrieve('fade:flag', this.getStyle('opacity') == 1);
                method = 'start';
                args[1] = flag ? 0 : 1;
                this.store('fade:flag', !flag);
                toggle = true;
                break;
            default:
                method = 'start';
        }
        if (!toggle) this.eliminate('fade:flag');
        fade[method].apply(fade, args);
        var to = args[args.length - 1];
        if (method == 'set' || to != 0) this.setStyle('visibility', to == 0 ? 'hidden' : 'visible');
        else fade.chain(function() {
            this.element.setStyle('visibility', 'hidden');
            this.callChain();
        });
        return this;
    },
    highlight: function(start, end) {
        if (!end) {
            end = this.retrieve('highlight:original', this.getStyle('background-color'));
            end = (end == 'transparent') ? '#fff' : end;
        }
        var tween = this.get('tween');
        tween.start('background-color', start || '#ffff88', end).chain(function() {
            this.setStyle('background-color', this.retrieve('highlight:original'));
            tween.callChain();
        }.bind(this));
        return this;
    }
});
Fx.Morph = new Class({
    Extends: Fx.CSS,
    initialize: function(element, options) {
        this.element = this.subject = document.id(element);
        this.parent(options);
    },
    set: function(now) {
        if (typeof now == 'string') now = this.search(now);
        for (var p in now) this.render(this.element, p, now[p], this.options.unit);
        return this;
    },
    compute: function(from, to, delta) {
        var now = {};
        for (var p in from) now[p] = this.parent(from[p], to[p], delta);
        return now;
    },
    start: function(properties) {
        if (!this.check(properties)) return this;
        if (typeof properties == 'string') properties = this.search(properties);
        var from = {},
            to = {};
        for (var p in properties) {
            var parsed = this.prepare(this.element, p, properties[p]);
            from[p] = parsed.from;
            to[p] = parsed.to;
        }
        return this.parent(from, to);
    }
});
Element.Properties.morph = {
    set: function(options) {
        this.get('morph').cancel().setOptions(options);
        return this;
    },
    get: function() {
        var morph = this.retrieve('morph');
        if (!morph) {
            morph = new Fx.Morph(this, {
                link: 'cancel'
            });
            this.store('morph', morph);
        }
        return morph;
    }
};
Element.implement({
    morph: function(props) {
        this.get('morph').start(props);
        return this;
    }
});
Fx.implement({
    getTransition: function() {
        var trans = this.options.transition || Fx.Transitions.Sine.easeInOut;
        if (typeof trans == 'string') {
            var data = trans.split(':');
            trans = Fx.Transitions;
            trans = trans[data[0]] || trans[data[0].capitalize()];
            if (data[1]) trans = trans['ease' + data[1].capitalize() + (data[2] ? data[2].capitalize() : '')];
        }
        return trans;
    }
});
Fx.Transition = function(transition, params) {
    params = Array.from(params);
    var easeIn = function(pos) {
        return transition(pos, params);
    };
    return Object.append(easeIn, {
        easeIn: easeIn,
        easeOut: function(pos) {
            return 1 - transition(1 - pos, params);
        },
        easeInOut: function(pos) {
            return (pos <= 0.5 ? transition(2 * pos, params) : (2 - transition(2 * (1 - pos), params))) / 2;
        }
    });
};
Fx.Transitions = {
    linear: function(zero) {
        return zero;
    }
};
Fx.Transitions = new Hash(Fx.Transitions);
Fx.Transitions.extend = function(transitions) {
    for (var transition in transitions) Fx.Transitions[transition] = new Fx.Transition(transitions[transition]);
};
Fx.Transitions.extend({
    Pow: function(p, x) {
        return Math.pow(p, x && x[0] || 6);
    },
    Expo: function(p) {
        return Math.pow(2, 8 * (p - 1));
    },
    Circ: function(p) {
        return 1 - Math.sin(Math.acos(p));
    },
    Sine: function(p) {
        return 1 - Math.cos(p * Math.PI / 2);
    },
    Back: function(p, x) {
        x = x && x[0] || 1.618;
        return Math.pow(p, 2) * ((x + 1) * p - x);
    },
    Bounce: function(p) {
        var value;
        for (var a = 0, b = 1; 1; a += b, b /= 2) {
            if (p >= (7 - 4 * a) / 11) {
                value = b * b - Math.pow((11 - 6 * a - 11 * p) / 4, 2);
                break;
            }
        }
        return value;
    },
    Elastic: function(p, x) {
        return Math.pow(2, 10 * --p) * Math.cos(20 * p * Math.PI * (x && x[0] || 1) / 3);
    }
});
['Quad', 'Cubic', 'Quart', 'Quint'].each(function(transition, i) {
    Fx.Transitions[transition] = new Fx.Transition(function(p) {
        return Math.pow(p, i + 2);
    });
});
(function() {
    var empty = function() {},
        progressSupport = ('onprogress' in new Browser.Request);
    var Request = this.Request = new Class({
        Implements: [Chain, Events, Options],
        options: {
            url: '',
            data: '',
            headers: {
                'X-Requested-With': 'XMLHttpRequest',
                'Accept': 'text/javascript, text/html, application/xml, text/xml, */*'
            },
            async: true,
            format: false,
            method: 'post',
            link: 'ignore',
            isSuccess: null,
            emulation: true,
            urlEncoded: true,
            encoding: 'utf-8',
            evalScripts: false,
            evalResponse: false,
            timeout: 0,
            noCache: false
        },
        initialize: function(options) {
            this.xhr = new Browser.Request();
            this.setOptions(options);
            this.headers = this.options.headers;
        },
        onStateChange: function() {
            var xhr = this.xhr;
            if (xhr.readyState != 4 || !this.running) return;
            this.running = false;
            this.status = 0;
            Function.attempt(function() {
                var status = xhr.status;
                this.status = (status == 1223) ? 204 : status;
            }.bind(this));
            xhr.onreadystatechange = empty;
            if (progressSupport) xhr.onprogress = xhr.onloadstart = empty;
            if (this.timer) {
                clearTimeout(this.timer);
                delete this.timer;
            }
            this.response = {
                text: this.xhr.responseText || '',
                xml: this.xhr.responseXML
            };
            if (this.options.isSuccess.call(this, this.status))
                this.success(this.response.text, this.response.xml);
            else
                this.failure();
        },
        isSuccess: function() {
            var status = this.status;
            return (status >= 200 && status < 300);
        },
        isRunning: function() {
            return !!this.running;
        },
        processScripts: function(text) {
            if (this.options.evalResponse || (/(ecma|java)script/).test(this.getHeader('Content-type'))) return Browser.exec(text);
            return text.stripScripts(this.options.evalScripts);
        },
        success: function(text, xml) {
            this.onSuccess(this.processScripts(text), xml);
        },
        onSuccess: function() {
            this.fireEvent('complete', arguments).fireEvent('success', arguments).callChain();
        },
        failure: function() {
            this.onFailure();
        },
        onFailure: function() {
            this.fireEvent('complete').fireEvent('failure', this.xhr);
        },
        loadstart: function(event) {
            this.fireEvent('loadstart', [event, this.xhr]);
        },
        progress: function(event) {
            this.fireEvent('progress', [event, this.xhr]);
        },
        timeout: function() {
            this.fireEvent('timeout', this.xhr);
        },
        setHeader: function(name, value) {
            this.headers[name] = value;
            return this;
        },
        getHeader: function(name) {
            return Function.attempt(function() {
                return this.xhr.getResponseHeader(name);
            }.bind(this));
        },
        check: function() {
            if (!this.running) return true;
            switch (this.options.link) {
                case 'cancel':
                    this.cancel();
                    return true;
                case 'chain':
                    this.chain(this.caller.pass(arguments, this));
                    return false;
            }
            return false;
        },
        send: function(options) {
            if (!this.check(options)) return this;
            this.options.isSuccess = this.options.isSuccess || this.isSuccess;
            this.running = true;
            var type = typeOf(options);
            if (type == 'string' || type == 'element') options = {
                data: options
            };
            var old = this.options;
            options = Object.append({
                data: old.data,
                url: old.url,
                method: old.method
            }, options);
            var data = options.data,
                url = String(options.url),
                method = options.method.toLowerCase();
            switch (typeOf(data)) {
                case 'element':
                    data = document.id(data).toQueryString();
                    break;
                case 'object':
                case 'hash':
                    data = Object.toQueryString(data);
            }
            if (this.options.format) {
                var format = 'format=' + this.options.format;
                data = (data) ? format + '&' + data : format;
            }
            if (this.options.emulation && !['get', 'post'].contains(method)) {
                var _method = '_method=' + method;
                data = (data) ? _method + '&' + data : _method;
                method = 'post';
            }
            if (this.options.urlEncoded && ['post', 'put'].contains(method)) {
                var encoding = (this.options.encoding) ? '; charset=' + this.options.encoding : '';
                this.headers['Content-type'] = 'application/x-www-form-urlencoded' + encoding;
            }
            if (!url) url = document.location.pathname;
            var trimPosition = url.lastIndexOf('/');
            if (trimPosition > -1 && (trimPosition = url.indexOf('#')) > -1) url = url.substr(0, trimPosition);
            if (this.options.noCache)
                url += (url.indexOf('?') > -1 ? '&' : '?') + String.uniqueID();
            if (data && (method == 'get' || method == 'delete')) {
                url += (url.indexOf('?') > -1 ? '&' : '?') + data;
                data = null;
            }
            var xhr = this.xhr;
            if (progressSupport) {
                xhr.onloadstart = this.loadstart.bind(this);
                xhr.onprogress = this.progress.bind(this);
            }
            xhr.open(method.toUpperCase(), url, this.options.async, this.options.user, this.options.password);
            if ((this.options.user || this.options.withCredentials) && 'withCredentials' in xhr) xhr.withCredentials = true;
            xhr.onreadystatechange = this.onStateChange.bind(this);
            Object.each(this.headers, function(value, key) {
                try {
                    xhr.setRequestHeader(key, value);
                } catch (e) {
                    this.fireEvent('exception', [key, value]);
                }
            }, this);
            this.fireEvent('request');
            xhr.send(data);
            if (!this.options.async) this.onStateChange();
            else if (this.options.timeout) this.timer = this.timeout.delay(this.options.timeout, this);
            return this;
        },
        cancel: function() {
            if (!this.running) return this;
            this.running = false;
            var xhr = this.xhr;
            xhr.abort();
            if (this.timer) {
                clearTimeout(this.timer);
                delete this.timer;
            }
            xhr.onreadystatechange = empty;
            if (progressSupport) xhr.onprogress = xhr.onloadstart = empty;
            this.xhr = new Browser.Request();
            this.fireEvent('cancel');
            return this;
        }
    });
    var methods = {};
    ['get', 'post', 'put', 'delete', 'patch', 'head', 'GET', 'POST', 'PUT', 'DELETE', 'PATCH', 'HEAD'].each(function(method) {
        methods[method] = function(data) {
            var object = {
                method: method
            };
            if (data != null) object.data = data;
            return this.send(object);
        };
    });
    Request.implement(methods);
    Element.Properties.send = {
        set: function(options) {
            var send = this.get('send').cancel();
            send.setOptions(options);
            return this;
        },
        get: function() {
            var send = this.retrieve('send');
            if (!send) {
                send = new Request({
                    data: this,
                    link: 'cancel',
                    method: this.get('method') || 'post',
                    url: this.get('action')
                });
                this.store('send', send);
            }
            return send;
        }
    };
    Element.implement({
        send: function(url) {
            var sender = this.get('send');
            sender.send({
                data: this,
                url: url || sender.options.url
            });
            return this;
        }
    });
})();
Request.HTML = new Class({
    Extends: Request,
    options: {
        update: false,
        append: false,
        evalScripts: true,
        filter: false,
        headers: {
            Accept: 'text/html, application/xml, text/xml, */*'
        }
    },
    success: function(text) {
        var options = this.options,
            response = this.response;
        response.html = text.stripScripts(function(script) {
            response.javascript = script;
        });
        var match = response.html.match(/<body[^>]*>([\s\S]*?)<\/body>/i);
        if (match) response.html = match[1];
        var temp = new Element('div').set('html', response.html);
        response.tree = temp.childNodes;
        response.elements = temp.getElements(options.filter || '*');
        if (options.filter) response.tree = response.elements;
        if (options.update) {
            var update = document.id(options.update).empty();
            if (options.filter) update.adopt(response.elements);
            else update.set('html', response.html);
        } else if (options.append) {
            var append = document.id(options.append);
            if (options.filter) response.elements.reverse().inject(append);
            else append.adopt(temp.getChildren());
        }
        if (options.evalScripts) Browser.exec(response.javascript);
        this.onSuccess(response.tree, response.elements, response.html, response.javascript);
    }
});
Element.Properties.load = {
    set: function(options) {
        var load = this.get('load').cancel();
        load.setOptions(options);
        return this;
    },
    get: function() {
        var load = this.retrieve('load');
        if (!load) {
            load = new Request.HTML({
                data: this,
                link: 'cancel',
                update: this,
                method: 'get'
            });
            this.store('load', load);
        }
        return load;
    }
};
Element.implement({
    load: function() {
        this.get('load').send(Array.link(arguments, {
            data: Type.isObject,
            url: Type.isString
        }));
        return this;
    }
});
if (typeof JSON == 'undefined') this.JSON = {};
JSON = new Hash({
    stringify: JSON.stringify,
    parse: JSON.parse
});
(function() {
    var special = {
        '\b': '\\b',
        '\t': '\\t',
        '\n': '\\n',
        '\f': '\\f',
        '\r': '\\r',
        '"': '\\"',
        '\\': '\\\\'
    };
    var escape = function(chr) {
        return special[chr] || '\\u' + ('0000' + chr.charCodeAt(0).toString(16)).slice(-4);
    };
    JSON.validate = function(string) {
        string = string.replace(/\\(?:["\\\/bfnrt]|u[0-9a-fA-F]{4})/g, '@').replace(/"[^"\\\n\r]*"|true|false|null|-?\d+(?:\.\d*)?(?:[eE][+\-]?\d+)?/g, ']').replace(/(?:^|:|,)(?:\s*\[)+/g, '');
        return (/^[\],:{}\s]*$/).test(string);
    };
    JSON.encode = JSON.stringify ? function(obj) {
        return JSON.stringify(obj);
    } : function(obj) {
        if (obj && obj.toJSON) obj = obj.toJSON();
        switch (typeOf(obj)) {
            case 'string':
                return '"' + obj.replace(/[\x00-\x1f\\"]/g, escape) + '"';
            case 'array':
                return '[' + obj.map(JSON.encode).clean() + ']';
            case 'object':
            case 'hash':
                var string = [];
                Object.each(obj, function(value, key) {
                    var json = JSON.encode(value);
                    if (json) string.push(JSON.encode(key) + ':' + json);
                });
                return '{' + string + '}';
            case 'number':
            case 'boolean':
                return '' + obj;
            case 'null':
                return 'null';
        }
        return null;
    };
    JSON.secure = true;
    JSON.secure = false;
    JSON.decode = function(string, secure) {
        if (!string || typeOf(string) != 'string') return null;
        if (secure == null) secure = JSON.secure;
        if (secure) {
            if (JSON.parse) return JSON.parse(string);
            if (!JSON.validate(string)) throw new Error('JSON could not decode the input; security is enabled and the value is not secure.');
        }
        return eval('(' + string + ')');
    };
})();
Request.JSON = new Class({
    Extends: Request,
    options: {
        secure: true
    },
    initialize: function(options) {
        this.parent(options);
        Object.append(this.headers, {
            'Accept': 'application/json',
            'X-Request': 'JSON'
        });
    },
    success: function(text) {
        var json;
        try {
            json = this.response.json = JSON.decode(text, this.options.secure);
        } catch (error) {
            this.fireEvent('error', [text, error]);
            return;
        }
        if (json == null) this.onFailure();
        else this.onSuccess(json, text);
    }
});
(function(window, document) {
    var ready, loaded, checks = [],
        shouldPoll, timer, testElement = document.createElement('div');
    var domready = function() {
        clearTimeout(timer);
        if (!ready) {
            Browser.loaded = ready = true;
            document.removeListener('DOMContentLoaded', domready).removeListener('readystatechange', check);
            document.fireEvent('domready');
            window.fireEvent('domready');
        }
        document = window = testElement = null;
    };
    var check = function() {
        for (var i = checks.length; i--;)
            if (checks[i]()) {
                domready();
                return true;
            }
        return false;
    };
    var poll = function() {
        clearTimeout(timer);
        if (!check()) timer = setTimeout(poll, 10);
    };
    document.addListener('DOMContentLoaded', domready);
    var doScrollWorks = function() {
        try {
            testElement.doScroll();
            return true;
        } catch (e) {}
        return false;
    };
    if (testElement.doScroll && !doScrollWorks()) {
        checks.push(doScrollWorks);
        shouldPoll = true;
    }
    if (document.readyState) checks.push(function() {
        var state = document.readyState;
        return (state == 'loaded' || state == 'complete');
    });
    if ('onreadystatechange' in document) document.addListener('readystatechange', check);
    else shouldPoll = true;
    if (shouldPoll) poll();
    Element.Events.domready = {
        onAdd: function(fn) {
            if (ready) fn.call(this);
        }
    };
    Element.Events.load = {
        base: 'load',
        onAdd: function(fn) {
            if (loaded && this == window) fn.call(this);
        },
        condition: function() {
            if (this == window) {
                domready();
                delete Element.Events.load;
            }
            return true;
        }
    };
    window.addEvent('load', function() {
        loaded = true;
    });
})(window, document);
MooTools.More = {
    version: '1.5.1',
    build: '2dd695ba957196ae4b0275a690765d6636a61ccd'
};
Class.Mutators.Binds = function(binds) {
    if (!this.prototype.initialize) this.implement('initialize', function() {});
    return Array.from(binds).concat(this.prototype.Binds || []);
};
Class.Mutators.initialize = function(initialize) {
    return function() {
        Array.from(this.Binds).each(function(name) {
            var original = this[name];
            if (original) this[name] = original.bind(this);
        }, this);
        return initialize.apply(this, arguments);
    };
};
(function() {
    Events.Pseudos = function(pseudos, addEvent, removeEvent) {
        var storeKey = '_monitorEvents:';
        var storageOf = function(object) {
            return {
                store: object.store ? function(key, value) {
                    object.store(storeKey + key, value);
                } : function(key, value) {
                    (object._monitorEvents || (object._monitorEvents = {}))[key] = value;
                },
                retrieve: object.retrieve ? function(key, dflt) {
                    return object.retrieve(storeKey + key, dflt);
                } : function(key, dflt) {
                    if (!object._monitorEvents) return dflt;
                    return object._monitorEvents[key] || dflt;
                }
            };
        };
        var splitType = function(type) {
            if (type.indexOf(':') == -1 || !pseudos) return null;
            var parsed = Slick.parse(type).expressions[0][0],
                parsedPseudos = parsed.pseudos,
                l = parsedPseudos.length,
                splits = [];
            while (l--) {
                var pseudo = parsedPseudos[l].key,
                    listener = pseudos[pseudo];
                if (listener != null) splits.push({
                    event: parsed.tag,
                    value: parsedPseudos[l].value,
                    pseudo: pseudo,
                    original: type,
                    listener: listener
                });
            }
            return splits.length ? splits : null;
        };
        return {
            addEvent: function(type, fn, internal) {
                var split = splitType(type);
                if (!split) return addEvent.call(this, type, fn, internal);
                var storage = storageOf(this),
                    events = storage.retrieve(type, []),
                    eventType = split[0].event,
                    args = Array.slice(arguments, 2),
                    stack = fn,
                    self = this;
                split.each(function(item) {
                    var listener = item.listener,
                        stackFn = stack;
                    if (listener == false) eventType += ':' + item.pseudo + '(' + item.value + ')';
                    else stack = function() {
                        listener.call(self, item, stackFn, arguments, stack);
                    };
                });
                events.include({
                    type: eventType,
                    event: fn,
                    monitor: stack
                });
                storage.store(type, events);
                if (type != eventType) addEvent.apply(this, [type, fn].concat(args));
                return addEvent.apply(this, [eventType, stack].concat(args));
            },
            removeEvent: function(type, fn) {
                var split = splitType(type);
                if (!split) return removeEvent.call(this, type, fn);
                var storage = storageOf(this),
                    events = storage.retrieve(type);
                if (!events) return this;
                var args = Array.slice(arguments, 2);
                removeEvent.apply(this, [type, fn].concat(args));
                events.each(function(monitor, i) {
                    if (!fn || monitor.event == fn) removeEvent.apply(this, [monitor.type, monitor.monitor].concat(args));
                    delete events[i];
                }, this);
                storage.store(type, events);
                return this;
            }
        };
    };
    var pseudos = {
        once: function(split, fn, args, monitor) {
            fn.apply(this, args);
            this.removeEvent(split.event, monitor).removeEvent(split.original, fn);
        },
        throttle: function(split, fn, args) {
            if (!fn._throttled) {
                fn.apply(this, args);
                fn._throttled = setTimeout(function() {
                    fn._throttled = false;
                }, split.value || 250);
            }
        },
        pause: function(split, fn, args) {
            clearTimeout(fn._pause);
            fn._pause = fn.delay(split.value || 250, this, args);
        }
    };
    Events.definePseudo = function(key, listener) {
        pseudos[key] = listener;
        return this;
    };
    Events.lookupPseudo = function(key) {
        return pseudos[key];
    };
    var proto = Events.prototype;
    Events.implement(Events.Pseudos(pseudos, proto.addEvent, proto.removeEvent));
    ['Request', 'Fx'].each(function(klass) {
        if (this[klass]) this[klass].implement(Events.prototype);
    });
})();
var Drag = new Class({
    Implements: [Events, Options],
    options: {
        snap: 6,
        unit: 'px',
        grid: false,
        style: true,
        limit: false,
        handle: false,
        invert: false,
        preventDefault: false,
        stopPropagation: false,
        compensateScroll: false,
        modifiers: {
            x: 'left',
            y: 'top'
        }
    },
    initialize: function() {
        var params = Array.link(arguments, {
            'options': Type.isObject,
            'element': function(obj) {
                return obj != null;
            }
        });
        this.element = document.id(params.element);
        this.document = this.element.getDocument();
        this.setOptions(params.options || {});
        var htype = typeOf(this.options.handle);
        this.handles = ((htype == 'array' || htype == 'collection') ? $$(this.options.handle) : document.id(this.options.handle)) || this.element;
        this.mouse = {
            'now': {},
            'pos': {}
        };
        this.value = {
            'start': {},
            'now': {}
        };
        this.offsetParent = (function(el) {
            var offsetParent = el.getOffsetParent();
            var isBody = !offsetParent || (/^(?:body|html)$/i).test(offsetParent.tagName);
            return isBody ? window : document.id(offsetParent);
        })(this.element);
        this.selection = 'selectstart' in document ? 'selectstart' : 'mousedown';
        this.compensateScroll = {
            start: {},
            diff: {},
            last: {}
        };
        if ('ondragstart' in document && !('FileReader' in window) && !Drag.ondragstartFixed) {
            document.ondragstart = Function.from(false);
            Drag.ondragstartFixed = true;
        }
        this.bound = {
            start: this.start.bind(this),
            check: this.check.bind(this),
            drag: this.drag.bind(this),
            stop: this.stop.bind(this),
            cancel: this.cancel.bind(this),
            eventStop: Function.from(false),
            scrollListener: this.scrollListener.bind(this)
        };
        this.attach();
    },
    attach: function() {
        this.handles.addEvent('mousedown', this.bound.start);
        if (this.options.compensateScroll) this.offsetParent.addEvent('scroll', this.bound.scrollListener);
        return this;
    },
    detach: function() {
        this.handles.removeEvent('mousedown', this.bound.start);
        if (this.options.compensateScroll) this.offsetParent.removeEvent('scroll', this.bound.scrollListener);
        return this;
    },
    scrollListener: function() {
        if (!this.mouse.start) return;
        var newScrollValue = this.offsetParent.getScroll();
        if (this.element.getStyle('position') == 'absolute') {
            var scrollDiff = this.sumValues(newScrollValue, this.compensateScroll.last, -1);
            this.mouse.now = this.sumValues(this.mouse.now, scrollDiff, 1);
        } else {
            this.compensateScroll.diff = this.sumValues(newScrollValue, this.compensateScroll.start, -1);
        }
        if (this.offsetParent != window) this.compensateScroll.diff = this.sumValues(this.compensateScroll.start, newScrollValue, -1);
        this.compensateScroll.last = newScrollValue;
        this.render(this.options);
    },
    sumValues: function(alpha, beta, op) {
        var sum = {},
            options = this.options;
        for (z in options.modifiers) {
            if (!options.modifiers[z]) continue;
            sum[z] = alpha[z] + beta[z] * op;
        }
        return sum;
    },
    start: function(event) {
        var options = this.options;
        if (event.rightClick) return;
        if (options.preventDefault) event.preventDefault();
        if (options.stopPropagation) event.stopPropagation();
        this.compensateScroll.start = this.compensateScroll.last = this.offsetParent.getScroll();
        this.compensateScroll.diff = {
            x: 0,
            y: 0
        };
        this.mouse.start = event.page;
        this.fireEvent('beforeStart', this.element);
        var limit = options.limit;
        this.limit = {
            x: [],
            y: []
        };
        var z, coordinates, offsetParent = this.offsetParent == window ? null : this.offsetParent;
        for (z in options.modifiers) {
            if (!options.modifiers[z]) continue;
            var style = this.element.getStyle(options.modifiers[z]);
            if (style && !style.match(/px$/)) {
                if (!coordinates) coordinates = this.element.getCoordinates(offsetParent);
                style = coordinates[options.modifiers[z]];
            }
            if (options.style) this.value.now[z] = (style || 0).toInt();
            else this.value.now[z] = this.element[options.modifiers[z]];
            if (options.invert) this.value.now[z] *= -1;
            this.mouse.pos[z] = event.page[z] - this.value.now[z];
            if (limit && limit[z]) {
                var i = 2;
                while (i--) {
                    var limitZI = limit[z][i];
                    if (limitZI || limitZI === 0) this.limit[z][i] = (typeof limitZI == 'function') ? limitZI() : limitZI;
                }
            }
        }
        if (typeOf(this.options.grid) == 'number') this.options.grid = {
            x: this.options.grid,
            y: this.options.grid
        };
        var events = {
            mousemove: this.bound.check,
            mouseup: this.bound.cancel
        };
        events[this.selection] = this.bound.eventStop;
        this.document.addEvents(events);
    },
    check: function(event) {
        if (this.options.preventDefault) event.preventDefault();
        var distance = Math.round(Math.sqrt(Math.pow(event.page.x - this.mouse.start.x, 2) + Math.pow(event.page.y - this.mouse.start.y, 2)));
        if (distance > this.options.snap) {
            this.cancel();
            this.document.addEvents({
                mousemove: this.bound.drag,
                mouseup: this.bound.stop
            });
            this.fireEvent('start', [this.element, event]).fireEvent('snap', this.element);
        }
    },
    drag: function(event) {
        var options = this.options;
        if (options.preventDefault) event.preventDefault();
        this.mouse.now = this.sumValues(event.page, this.compensateScroll.diff, -1);
        this.render(options);
        this.fireEvent('drag', [this.element, event]);
    },
    render: function(options) {
        for (var z in options.modifiers) {
            if (!options.modifiers[z]) continue;
            this.value.now[z] = this.mouse.now[z] - this.mouse.pos[z];
            if (options.invert) this.value.now[z] *= -1;
            if (options.limit && this.limit[z]) {
                if ((this.limit[z][1] || this.limit[z][1] === 0) && (this.value.now[z] > this.limit[z][1])) {
                    this.value.now[z] = this.limit[z][1];
                } else if ((this.limit[z][0] || this.limit[z][0] === 0) && (this.value.now[z] < this.limit[z][0])) {
                    this.value.now[z] = this.limit[z][0];
                }
            }
            if (options.grid[z]) this.value.now[z] -= ((this.value.now[z] - (this.limit[z][0] || 0)) % options.grid[z]);
            if (options.style) this.element.setStyle(options.modifiers[z], this.value.now[z] + options.unit);
            else this.element[options.modifiers[z]] = this.value.now[z];
        }
    },
    cancel: function(event) {
        this.document.removeEvents({
            mousemove: this.bound.check,
            mouseup: this.bound.cancel
        });
        if (event) {
            this.document.removeEvent(this.selection, this.bound.eventStop);
            this.fireEvent('cancel', this.element);
        }
    },
    stop: function(event) {
        var events = {
            mousemove: this.bound.drag,
            mouseup: this.bound.stop
        };
        events[this.selection] = this.bound.eventStop;
        this.document.removeEvents(events);
        this.mouse.start = null;
        if (event) this.fireEvent('complete', [this.element, event]);
    }
});
Element.implement({
    makeResizable: function(options) {
        var drag = new Drag(this, Object.merge({
            modifiers: {
                x: 'width',
                y: 'height'
            }
        }, options));
        this.store('resizer', drag);
        return drag.addEvent('drag', function() {
            this.fireEvent('resize', drag);
        }.bind(this));
    }
});
(function() {
    var getStylesList = function(styles, planes) {
        var list = [];
        Object.each(planes, function(directions) {
            Object.each(directions, function(edge) {
                styles.each(function(style) {
                    list.push(style + '-' + edge + (style == 'border' ? '-width' : ''));
                });
            });
        });
        return list;
    };
    var calculateEdgeSize = function(edge, styles) {
        var total = 0;
        Object.each(styles, function(value, style) {
            if (style.test(edge)) total = total + value.toInt();
        });
        return total;
    };
    var isVisible = function(el) {
        return !!(!el || el.offsetHeight || el.offsetWidth);
    };
    Element.implement({
        measure: function(fn) {
            if (isVisible(this)) return fn.call(this);
            var parent = this.getParent(),
                toMeasure = [];
            while (!isVisible(parent) && parent != document.body) {
                toMeasure.push(parent.expose());
                parent = parent.getParent();
            }
            var restore = this.expose(),
                result = fn.call(this);
            restore();
            toMeasure.each(function(restore) {
                restore();
            });
            return result;
        },
        expose: function() {
            if (this.getStyle('display') != 'none') return function() {};
            var before = this.style.cssText;
            this.setStyles({
                display: 'block',
                position: 'absolute',
                visibility: 'hidden'
            });
            return function() {
                this.style.cssText = before;
            }.bind(this);
        },
        getDimensions: function(options) {
            options = Object.merge({
                computeSize: false
            }, options);
            var dim = {
                x: 0,
                y: 0
            };
            var getSize = function(el, options) {
                return (options.computeSize) ? el.getComputedSize(options) : el.getSize();
            };
            var parent = this.getParent('body');
            if (parent && this.getStyle('display') == 'none') {
                dim = this.measure(function() {
                    return getSize(this, options);
                });
            } else if (parent) {
                try {
                    dim = getSize(this, options);
                } catch (e) {}
            }
            return Object.append(dim, (dim.x || dim.x === 0) ? {
                width: dim.x,
                height: dim.y
            } : {
                x: dim.width,
                y: dim.height
            });
        },
        getComputedSize: function(options) {
            if (options && options.plains) options.planes = options.plains;
            options = Object.merge({
                styles: ['padding', 'border'],
                planes: {
                    height: ['top', 'bottom'],
                    width: ['left', 'right']
                },
                mode: 'both'
            }, options);
            var styles = {},
                size = {
                    width: 0,
                    height: 0
                },
                dimensions;
            if (options.mode == 'vertical') {
                delete size.width;
                delete options.planes.width;
            } else if (options.mode == 'horizontal') {
                delete size.height;
                delete options.planes.height;
            }
            getStylesList(options.styles, options.planes).each(function(style) {
                styles[style] = this.getStyle(style).toInt();
            }, this);
            Object.each(options.planes, function(edges, plane) {
                var capitalized = plane.capitalize(),
                    style = this.getStyle(plane);
                if (style == 'auto' && !dimensions) dimensions = this.getDimensions();
                style = styles[plane] = (style == 'auto') ? dimensions[plane] : style.toInt();
                size['total' + capitalized] = style;
                edges.each(function(edge) {
                    var edgesize = calculateEdgeSize(edge, styles);
                    size['computed' + edge.capitalize()] = edgesize;
                    size['total' + capitalized] += edgesize;
                });
            }, this);
            return Object.append(size, styles);
        }
    });
})();
(function() {
    var pseudos = {
            relay: false
        },
        copyFromEvents = ['once', 'throttle', 'pause'],
        count = copyFromEvents.length;
    while (count--) pseudos[copyFromEvents[count]] = Events.lookupPseudo(copyFromEvents[count]);
    DOMEvent.definePseudo = function(key, listener) {
        pseudos[key] = listener;
        return this;
    };
    var proto = Element.prototype;
    [Element, Window, Document].invoke('implement', Events.Pseudos(pseudos, proto.addEvent, proto.removeEvent));
})();
(function() {
    var keysStoreKey = '$moo:keys-pressed',
        keysKeyupStoreKey = '$moo:keys-keyup';
    DOMEvent.definePseudo('keys', function(split, fn, args) {
        var event = args[0],
            keys = [],
            pressed = this.retrieve(keysStoreKey, []),
            value = split.value;
        if (value != '+') keys.append(value.replace('++', function() {
            keys.push('+');
            return '';
        }).split('+'));
        else keys = ['+'];
        pressed.include(event.key);
        if (keys.every(function(key) {
                return pressed.contains(key);
            })) fn.apply(this, args);
        this.store(keysStoreKey, pressed);
        if (!this.retrieve(keysKeyupStoreKey)) {
            var keyup = function(event) {
                (function() {
                    pressed = this.retrieve(keysStoreKey, []).erase(event.key);
                    this.store(keysStoreKey, pressed);
                }).delay(0, this);
            };
            this.store(keysKeyupStoreKey, keyup).addEvent('keyup', keyup);
        }
    });
    DOMEvent.defineKeys({
        '16': 'shift',
        '17': 'control',
        '18': 'alt',
        '20': 'capslock',
        '33': 'pageup',
        '34': 'pagedown',
        '35': 'end',
        '36': 'home',
        '144': 'numlock',
        '145': 'scrolllock',
        '186': ';',
        '187': '=',
        '188': ',',
        '190': '.',
        '191': '/',
        '192': '`',
        '219': '[',
        '220': '\\',
        '221': ']',
        '222': "'",
        '107': '+',
        '109': '-',
        '189': '-'
    })
})();
(function() {
    var special = {
            'a': /[� áâãäåăą]/g,
            'A': /[ÀÁÂÃÄÅĂĄ]/g,
            'c': /[ćčç]/g,
            'C': /[ĆČÇ]/g,
            'd': /[ďđ]/g,
            'D': /[ĎÐ]/g,
            'e': /[èéêëěę]/g,
            'E': /[ÈÉÊËĚĘ]/g,
            'g': /[ğ]/g,
            'G': /[Ğ]/g,
            'i': /[ìíîï]/g,
            'I': /[ÌÍÎÏ]/g,
            'l': /[ĺľł]/g,
            'L': /[ĹĽŁ]/g,
            'n': /[ñňń]/g,
            'N': /[ÑŇŃ]/g,
            'o': /[òóôõöøő]/g,
            'O': /[ÒÓÔÕÖØ]/g,
            'r': /[řŕ]/g,
            'R': /[ŘŔ]/g,
            's': /[ššş]/g,
            'S': /[� ŞŚ]/g,
            't': /[ťţ]/g,
            'T': /[ŤŢ]/g,
            'u': /[ùúûůüµ]/g,
            'U': /[ÙÚÛŮÜ]/g,
            'y': /[ÿý]/g,
            'Y': /[ŸÝ]/g,
            'z': /[žźż]/g,
            'Z': /[ŽŹŻ]/g,
            'th': /[þ]/g,
            'TH': /[Þ]/g,
            'dh': /[ð]/g,
            'DH': /[Ð]/g,
            'ss': /[ß]/g,
            'oe': /[œ]/g,
            'OE': /[Œ]/g,
            'ae': /[æ]/g,
            'AE': /[Æ]/g
        },
        tidy = {
            ' ': /[\xa0\u2002\u2003\u2009]/g,
            '*': /[\xb7]/g,
            '\'': /[\u2018\u2019]/g,
            '"': /[\u201c\u201d]/g,
            '...': /[\u2026]/g,
            '-': /[\u2013]/g,
            '&raquo;': /[\uFFFD]/g
        },
        conversions = {
            ms: 1,
            s: 1000,
            m: 6e4,
            h: 36e5
        },
        findUnits = /(\d*.?\d+)([msh]+)/;
    var walk = function(string, replacements) {
        var result = string,
            key;
        for (key in replacements) result = result.replace(replacements[key], key);
        return result;
    };
    var getRegexForTag = function(tag, contents) {
        tag = tag || '';
        var regstr = contents ? "<" + tag + "(?!\\w)[^>]*>([\\s\\S]*?)<\/" + tag + "(?!\\w)>" : "<\/?" + tag + "([^>]+)?>",
            reg = new RegExp(regstr, "gi");
        return reg;
    };
    String.implement({
        standardize: function() {
            return walk(this, special);
        },
        repeat: function(times) {
            return new Array(times + 1).join(this);
        },
        pad: function(length, str, direction) {
            if (this.length >= length) return this;
            var pad = (str == null ? ' ' : '' + str).repeat(length - this.length).substr(0, length - this.length);
            if (!direction || direction == 'right') return this + pad;
            if (direction == 'left') return pad + this;
            return pad.substr(0, (pad.length / 2).floor()) + this + pad.substr(0, (pad.length / 2).ceil());
        },
        getTags: function(tag, contents) {
            return this.match(getRegexForTag(tag, contents)) || [];
        },
        stripTags: function(tag, contents) {
            return this.replace(getRegexForTag(tag, contents), '');
        },
        tidy: function() {
            return walk(this, tidy);
        },
        truncate: function(max, trail, atChar) {
            var string = this;
            if (trail == null && arguments.length == 1) trail = '…';
            if (string.length > max) {
                string = string.substring(0, max);
                if (atChar) {
                    var index = string.lastIndexOf(atChar);
                    if (index != -1) string = string.substr(0, index);
                }
                if (trail) string += trail;
            }
            return string;
        },
        ms: function() {
            var units = findUnits.exec(this);
            if (units == null) return Number(this);
            return Number(units[1]) * conversions[units[2]];
        }
    });
})();
Element.implement({
    tidy: function() {
        this.set('value', this.get('value').tidy());
    },
    getTextInRange: function(start, end) {
        return this.get('value').substring(start, end);
    },
    getSelectedText: function() {
        if (this.setSelectionRange) return this.getTextInRange(this.getSelectionStart(), this.getSelectionEnd());
        return document.selection.createRange().text;
    },
    getSelectedRange: function() {
        if (this.selectionStart != null) {
            return {
                start: this.selectionStart,
                end: this.selectionEnd
            };
        }
        var pos = {
            start: 0,
            end: 0
        };
        var range = this.getDocument().selection.createRange();
        if (!range || range.parentElement() != this) return pos;
        var duplicate = range.duplicate();
        if (this.type == 'text') {
            pos.start = 0 - duplicate.moveStart('character', -100000);
            pos.end = pos.start + range.text.length;
        } else {
            var value = this.get('value');
            var offset = value.length;
            duplicate.moveToElementText(this);
            duplicate.setEndPoint('StartToEnd', range);
            if (duplicate.text.length) offset -= value.match(/[\n\r]*$/)[0].length;
            pos.end = offset - duplicate.text.length;
            duplicate.setEndPoint('StartToStart', range);
            pos.start = offset - duplicate.text.length;
        }
        return pos;
    },
    getSelectionStart: function() {
        return this.getSelectedRange().start;
    },
    getSelectionEnd: function() {
        return this.getSelectedRange().end;
    },
    setCaretPosition: function(pos) {
        if (pos == 'end') pos = this.get('value').length;
        this.selectRange(pos, pos);
        return this;
    },
    getCaretPosition: function() {
        return this.getSelectedRange().start;
    },
    selectRange: function(start, end) {
        if (this.setSelectionRange) {
            this.focus();
            this.setSelectionRange(start, end);
        } else {
            var value = this.get('value');
            var diff = value.substr(start, end - start).replace(/\r/g, '').length;
            start = value.substr(0, start).replace(/\r/g, '').length;
            var range = this.createTextRange();
            range.collapse(true);
            range.moveEnd('character', start + diff);
            range.moveStart('character', start);
            range.select();
        }
        return this;
    },
    insertAtCursor: function(value, select) {
        var pos = this.getSelectedRange();
        var text = this.get('value');
        this.set('value', text.substring(0, pos.start) + value + text.substring(pos.end, text.length));
        if (select !== false) this.selectRange(pos.start, pos.start + value.length);
        else this.setCaretPosition(pos.start + value.length);
        return this;
    },
    insertAroundCursor: function(options, select) {
        options = Object.append({
            before: '',
            defaultMiddle: '',
            after: ''
        }, options);
        var value = this.getSelectedText() || options.defaultMiddle;
        var pos = this.getSelectedRange();
        var text = this.get('value');
        if (pos.start == pos.end) {
            this.set('value', text.substring(0, pos.start) + options.before + value + options.after + text.substring(pos.end, text.length));
            this.selectRange(pos.start + options.before.length, pos.end + options.before.length + value.length);
        } else {
            var current = text.substring(pos.start, pos.end);
            this.set('value', text.substring(0, pos.start) + options.before + current + options.after + text.substring(pos.end, text.length));
            var selStart = pos.start + options.before.length;
            if (select !== false) this.selectRange(selStart, selStart + current.length);
            else this.setCaretPosition(selStart + text.length);
        }
        return this;
    }
});
(function() {
    var supportsPositionFixed = false,
        supportTested = false;
    var testPositionFixed = function() {
        var test = new Element('div').setStyles({
            position: 'fixed',
            top: 0,
            right: 0
        }).inject(document.body);
        supportsPositionFixed = (test.offsetTop === 0);
        test.dispose();
        supportTested = true;
    };
    Element.implement({
        pin: function(enable, forceScroll) {
            if (!supportTested) testPositionFixed();
            if (this.getStyle('display') == 'none') return this;
            var pinnedPosition, scroll = window.getScroll(),
                parent, scrollFixer;
            if (enable !== false) {
                pinnedPosition = this.getPosition();
                if (!this.retrieve('pin:_pinned')) {
                    var currentPosition = {
                        top: pinnedPosition.y - scroll.y,
                        left: pinnedPosition.x - scroll.x,
                        margin: '0px',
                        padding: '0px'
                    };
                    if (supportsPositionFixed && !forceScroll) {
                        this.setStyle('position', 'fixed').setStyles(currentPosition);
                    } else {
                        parent = this.getOffsetParent();
                        var position = this.getPosition(parent),
                            styles = this.getStyles('left', 'top');
                        if (parent && styles.left == 'auto' || styles.top == 'auto') this.setPosition(position);
                        if (this.getStyle('position') == 'static') this.setStyle('position', 'absolute');
                        position = {
                            x: styles.left.toInt() - scroll.x,
                            y: styles.top.toInt() - scroll.y
                        };
                        scrollFixer = function() {
                            if (!this.retrieve('pin:_pinned')) return;
                            var scroll = window.getScroll();
                            this.setStyles({
                                left: position.x + scroll.x,
                                top: position.y + scroll.y
                            });
                        }.bind(this);
                        this.store('pin:_scrollFixer', scrollFixer);
                        window.addEvent('scroll', scrollFixer);
                    }
                    this.store('pin:_pinned', true);
                }
            } else {
                if (!this.retrieve('pin:_pinned')) return this;
                parent = this.getParent();
                var offsetParent = (parent.getComputedStyle('position') != 'static' ? parent : parent.getOffsetParent());
                pinnedPosition = this.getPosition();
                this.store('pin:_pinned', false);
                scrollFixer = this.retrieve('pin:_scrollFixer');
                if (!scrollFixer) {
                    this.setStyles({
                        position: 'absolute',
                        top: pinnedPosition.y + scroll.y,
                        left: pinnedPosition.x + scroll.x
                    });
                } else {
                    this.store('pin:_scrollFixer', null);
                    window.removeEvent('scroll', scrollFixer);
                }
                this.removeClass('isPinned');
            }
            return this;
        },
        unpin: function() {
            return this.pin(false);
        },
        togglePin: function() {
            return this.pin(!this.retrieve('pin:_pinned'));
        }
    });
    Element.alias('togglepin', 'togglePin');
})();
(function(original) {
    var local = Element.Position = {
        options: {
            relativeTo: document.body,
            position: {
                x: 'center',
                y: 'center'
            },
            offset: {
                x: 0,
                y: 0
            }
        },
        getOptions: function(element, options) {
            options = Object.merge({}, local.options, options);
            local.setPositionOption(options);
            local.setEdgeOption(options);
            local.setOffsetOption(element, options);
            local.setDimensionsOption(element, options);
            return options;
        },
        setPositionOption: function(options) {
            options.position = local.getCoordinateFromValue(options.position);
        },
        setEdgeOption: function(options) {
            var edgeOption = local.getCoordinateFromValue(options.edge);
            options.edge = edgeOption ? edgeOption : (options.position.x == 'center' && options.position.y == 'center') ? {
                x: 'center',
                y: 'center'
            } : {
                x: 'left',
                y: 'top'
            };
        },
        setOffsetOption: function(element, options) {
            var parentOffset = {
                x: 0,
                y: 0
            };
            var parentScroll = {
                x: 0,
                y: 0
            };
            var offsetParent = element.measure(function() {
                return document.id(this.getOffsetParent());
            });
            if (!offsetParent || offsetParent == element.getDocument().body) return;
            parentScroll = offsetParent.getScroll();
            parentOffset = offsetParent.measure(function() {
                var position = this.getPosition();
                if (this.getStyle('position') == 'fixed') {
                    var scroll = window.getScroll();
                    position.x += scroll.x;
                    position.y += scroll.y;
                }
                return position;
            });
            options.offset = {
                parentPositioned: offsetParent != document.id(options.relativeTo),
                x: options.offset.x - parentOffset.x + parentScroll.x,
                y: options.offset.y - parentOffset.y + parentScroll.y
            };
        },
        setDimensionsOption: function(element, options) {
            options.dimensions = element.getDimensions({
                computeSize: true,
                styles: ['padding', 'border', 'margin']
            });
        },
        getPosition: function(element, options) {
            var position = {};
            options = local.getOptions(element, options);
            var relativeTo = document.id(options.relativeTo) || document.body;
            local.setPositionCoordinates(options, position, relativeTo);
            if (options.edge) local.toEdge(position, options);
            var offset = options.offset;
            position.left = ((position.x >= 0 || offset.parentPositioned || options.allowNegative) ? position.x : 0).toInt();
            position.top = ((position.y >= 0 || offset.parentPositioned || options.allowNegative) ? position.y : 0).toInt();
            local.toMinMax(position, options);
            if (options.relFixedPosition || relativeTo.getStyle('position') == 'fixed') local.toRelFixedPosition(relativeTo, position);
            if (options.ignoreScroll) local.toIgnoreScroll(relativeTo, position);
            if (options.ignoreMargins) local.toIgnoreMargins(position, options);
            position.left = Math.ceil(position.left);
            position.top = Math.ceil(position.top);
            delete position.x;
            delete position.y;
            return position;
        },
        setPositionCoordinates: function(options, position, relativeTo) {
            var offsetY = options.offset.y,
                offsetX = options.offset.x,
                calc = (relativeTo == document.body) ? window.getScroll() : relativeTo.getPosition(),
                top = calc.y,
                left = calc.x,
                winSize = window.getSize();
            switch (options.position.x) {
                case 'left':
                    position.x = left + offsetX;
                    break;
                case 'right':
                    position.x = left + offsetX + relativeTo.offsetWidth;
                    break;
                default:
                    position.x = left + ((relativeTo == document.body ? winSize.x : relativeTo.offsetWidth) / 2) + offsetX;
                    break;
            }
            switch (options.position.y) {
                case 'top':
                    position.y = top + offsetY;
                    break;
                case 'bottom':
                    position.y = top + offsetY + relativeTo.offsetHeight;
                    break;
                default:
                    position.y = top + ((relativeTo == document.body ? winSize.y : relativeTo.offsetHeight) / 2) + offsetY;
                    break;
            }
        },
        toMinMax: function(position, options) {
            var xy = {
                    left: 'x',
                    top: 'y'
                },
                value;
            ['minimum', 'maximum'].each(function(minmax) {
                ['left', 'top'].each(function(lr) {
                    value = options[minmax] ? options[minmax][xy[lr]] : null;
                    if (value != null && ((minmax == 'minimum') ? position[lr] < value : position[lr] > value)) position[lr] = value;
                });
            });
        },
        toRelFixedPosition: function(relativeTo, position) {
            var winScroll = window.getScroll();
            position.top += winScroll.y;
            position.left += winScroll.x;
        },
        toIgnoreScroll: function(relativeTo, position) {
            var relScroll = relativeTo.getScroll();
            position.top -= relScroll.y;
            position.left -= relScroll.x;
        },
        toIgnoreMargins: function(position, options) {
            position.left += options.edge.x == 'right' ? options.dimensions['margin-right'] : (options.edge.x != 'center' ? -options.dimensions['margin-left'] : -options.dimensions['margin-left'] + ((options.dimensions['margin-right'] + options.dimensions['margin-left']) / 2));
            position.top += options.edge.y == 'bottom' ? options.dimensions['margin-bottom'] : (options.edge.y != 'center' ? -options.dimensions['margin-top'] : -options.dimensions['margin-top'] + ((options.dimensions['margin-bottom'] + options.dimensions['margin-top']) / 2));
        },
        toEdge: function(position, options) {
            var edgeOffset = {},
                dimensions = options.dimensions,
                edge = options.edge;
            switch (edge.x) {
                case 'left':
                    edgeOffset.x = 0;
                    break;
                case 'right':
                    edgeOffset.x = -dimensions.x - dimensions.computedRight - dimensions.computedLeft;
                    break;
                default:
                    edgeOffset.x = -(Math.round(dimensions.totalWidth / 2));
                    break;
            }
            switch (edge.y) {
                case 'top':
                    edgeOffset.y = 0;
                    break;
                case 'bottom':
                    edgeOffset.y = -dimensions.y - dimensions.computedTop - dimensions.computedBottom;
                    break;
                default:
                    edgeOffset.y = -(Math.round(dimensions.totalHeight / 2));
                    break;
            }
            position.x += edgeOffset.x;
            position.y += edgeOffset.y;
        },
        getCoordinateFromValue: function(option) {
            if (typeOf(option) != 'string') return option;
            option = option.toLowerCase();
            return {
                x: option.test('left') ? 'left' : (option.test('right') ? 'right' : 'center'),
                y: option.test(/upper|top/) ? 'top' : (option.test('bottom') ? 'bottom' : 'center')
            };
        }
    };
    Element.implement({
        position: function(options) {
            if (options && (options.x != null || options.y != null)) {
                return (original ? original.apply(this, arguments) : this);
            }
            var position = this.setStyle('position', 'absolute').calculatePosition(options);
            return (options && options.returnPos) ? position : this.setStyles(position);
        },
        calculatePosition: function(options) {
            return local.getPosition(this, options);
        }
    });
})(Element.prototype.position);
Element.implement({
    isDisplayed: function() {
        return this.getStyle('display') != 'none';
    },
    isVisible: function() {
        var w = this.offsetWidth,
            h = this.offsetHeight;
        return (w == 0 && h == 0) ? false : (w > 0 && h > 0) ? true : this.style.display != 'none';
    },
    toggle: function() {
        return this[this.isDisplayed() ? 'hide' : 'show']();
    },
    hide: function() {
        var d;
        try {
            d = this.getStyle('display');
        } catch (e) {}
        if (d == 'none') return this;
        return this.store('element:_originalDisplay', d || '').setStyle('display', 'none');
    },
    show: function(display) {
        if (!display && this.isDisplayed()) return this;
        display = display || this.retrieve('element:_originalDisplay') || 'block';
        return this.setStyle('display', (display == 'none') ? 'block' : display);
    },
    swapClass: function(remove, add) {
        return this.removeClass(remove).addClass(add);
    }
});
Document.implement({
    clearSelection: function() {
        if (window.getSelection) {
            var selection = window.getSelection();
            if (selection && selection.removeAllRanges) selection.removeAllRanges();
        } else if (document.selection && document.selection.empty) {
            try {
                document.selection.empty();
            } catch (e) {}
        }
    }
});
Elements.from = function(text, excludeScripts) {
    if (excludeScripts || excludeScripts == null) text = text.stripScripts();
    var container, match = text.match(/^\s*(?:<!--.*?-->\s*)*<(t[dhr]|tbody|tfoot|thead)/i);
    if (match) {
        container = new Element('table');
        var tag = match[1].toLowerCase();
        if (['td', 'th', 'tr'].contains(tag)) {
            container = new Element('tbody').inject(container);
            if (tag != 'tr') container = new Element('tr').inject(container);
        }
    }
    return (container || new Element('div')).set('html', text).getChildren();
};
(function() {
    var defined = function(value) {
        return value != null;
    };
    var hasOwnProperty = Object.prototype.hasOwnProperty;
    Object.extend({
        getFromPath: function(source, parts) {
            if (typeof parts == 'string') parts = parts.split('.');
            for (var i = 0, l = parts.length; i < l; i++) {
                if (hasOwnProperty.call(source, parts[i])) source = source[parts[i]];
                else return null;
            }
            return source;
        },
        cleanValues: function(object, method) {
            method = method || defined;
            for (var key in object)
                if (!method(object[key])) {
                    delete object[key];
                }
            return object;
        },
        erase: function(object, key) {
            if (hasOwnProperty.call(object, key)) delete object[key];
            return object;
        },
        run: function(object) {
            var args = Array.slice(arguments, 1);
            for (var key in object)
                if (object[key].apply) {
                    object[key].apply(object, args);
                }
            return object;
        }
    });
})();
(function() {
    var current = null,
        locales = {},
        inherits = {};
    var getSet = function(set) {
        if (instanceOf(set, Locale.Set)) return set;
        else return locales[set];
    };
    var Locale = this.Locale = {
        define: function(locale, set, key, value) {
            var name;
            if (instanceOf(locale, Locale.Set)) {
                name = locale.name;
                if (name) locales[name] = locale;
            } else {
                name = locale;
                if (!locales[name]) locales[name] = new Locale.Set(name);
                locale = locales[name];
            }
            if (set) locale.define(set, key, value);
            if (set == 'cascade') return Locale.inherit(name, key);
            if (!current) current = locale;
            return locale;
        },
        use: function(locale) {
            locale = getSet(locale);
            if (locale) {
                current = locale;
                this.fireEvent('change', locale);
                this.fireEvent('langChange', locale.name);
            }
            return this;
        },
        getCurrent: function() {
            return current;
        },
        get: function(key, args) {
            return (current) ? current.get(key, args) : '';
        },
        inherit: function(locale, inherits, set) {
            locale = getSet(locale);
            if (locale) locale.inherit(inherits, set);
            return this;
        },
        list: function() {
            return Object.keys(locales);
        }
    };
    Object.append(Locale, new Events);
    Locale.Set = new Class({
        sets: {},
        inherits: {
            locales: [],
            sets: {}
        },
        initialize: function(name) {
            this.name = name || '';
        },
        define: function(set, key, value) {
            var defineData = this.sets[set];
            if (!defineData) defineData = {};
            if (key) {
                if (typeOf(key) == 'object') defineData = Object.merge(defineData, key);
                else defineData[key] = value;
            }
            this.sets[set] = defineData;
            return this;
        },
        get: function(key, args, _base) {
            var value = Object.getFromPath(this.sets, key);
            if (value != null) {
                var type = typeOf(value);
                if (type == 'function') value = value.apply(null, Array.from(args));
                else if (type == 'object') value = Object.clone(value);
                return value;
            }
            var index = key.indexOf('.'),
                set = index < 0 ? key : key.substr(0, index),
                names = (this.inherits.sets[set] || []).combine(this.inherits.locales).include('en-US');
            if (!_base) _base = [];
            for (var i = 0, l = names.length; i < l; i++) {
                if (_base.contains(names[i])) continue;
                _base.include(names[i]);
                var locale = locales[names[i]];
                if (!locale) continue;
                value = locale.get(key, args, _base);
                if (value != null) return value;
            }
            return '';
        },
        inherit: function(names, set) {
            names = Array.from(names);
            if (set && !this.inherits.sets[set]) this.inherits.sets[set] = [];
            var l = names.length;
            while (l--)(set ? this.inherits.sets[set] : this.inherits.locales).unshift(names[l]);
            return this;
        }
    });
    var lang = MooTools.lang = {};
    Object.append(lang, Locale, {
        setLanguage: Locale.use,
        getCurrentLanguage: function() {
            var current = Locale.getCurrent();
            return (current) ? current.name : null;
        },
        set: function() {
            Locale.define.apply(this, arguments);
            return this;
        },
        get: function(set, key, args) {
            if (key) set += '.' + key;
            return Locale.get(set, args);
        }
    });
})();
Locale.define('en-US', 'Date', {
    months: ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'],
    months_abbr: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
    days: ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'],
    days_abbr: ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'],
    dateOrder: ['month', 'date', 'year'],
    shortDate: '%m/%d/%Y',
    shortTime: '%I:%M%p',
    AM: 'AM',
    PM: 'PM',
    firstDayOfWeek: 0,
    ordinal: function(dayOfMonth) {
        return (dayOfMonth > 3 && dayOfMonth < 21) ? 'th' : ['th', 'st', 'nd', 'rd', 'th'][Math.min(dayOfMonth % 10, 4)];
    },
    lessThanMinuteAgo: 'less than a minute ago',
    minuteAgo: 'about a minute ago',
    minutesAgo: '{delta} minutes ago',
    hourAgo: 'about an hour ago',
    hoursAgo: 'about {delta} hours ago',
    dayAgo: '1 day ago',
    daysAgo: '{delta} days ago',
    weekAgo: '1 week ago',
    weeksAgo: '{delta} weeks ago',
    monthAgo: '1 month ago',
    monthsAgo: '{delta} months ago',
    yearAgo: '1 year ago',
    yearsAgo: '{delta} years ago',
    lessThanMinuteUntil: 'less than a minute from now',
    minuteUntil: 'about a minute from now',
    minutesUntil: '{delta} minutes from now',
    hourUntil: 'about an hour from now',
    hoursUntil: 'about {delta} hours from now',
    dayUntil: '1 day from now',
    daysUntil: '{delta} days from now',
    weekUntil: '1 week from now',
    weeksUntil: '{delta} weeks from now',
    monthUntil: '1 month from now',
    monthsUntil: '{delta} months from now',
    yearUntil: '1 year from now',
    yearsUntil: '{delta} years from now'
});
(function() {
    var Date = this.Date;
    var DateMethods = Date.Methods = {
        ms: 'Milliseconds',
        year: 'FullYear',
        min: 'Minutes',
        mo: 'Month',
        sec: 'Seconds',
        hr: 'Hours'
    };
    ['Date', 'Day', 'FullYear', 'Hours', 'Milliseconds', 'Minutes', 'Month', 'Seconds', 'Time', 'TimezoneOffset', 'Week', 'Timezone', 'GMTOffset', 'DayOfYear', 'LastMonth', 'LastDayOfMonth', 'UTCDate', 'UTCDay', 'UTCFullYear', 'AMPM', 'Ordinal', 'UTCHours', 'UTCMilliseconds', 'UTCMinutes', 'UTCMonth', 'UTCSeconds', 'UTCMilliseconds'].each(function(method) {
        Date.Methods[method.toLowerCase()] = method;
    });
    var pad = function(n, digits, string) {
        if (digits == 1) return n;
        return n < Math.pow(10, digits - 1) ? (string || '0') + pad(n, digits - 1, string) : n;
    };
    Date.implement({
        set: function(prop, value) {
            prop = prop.toLowerCase();
            var method = DateMethods[prop] && 'set' + DateMethods[prop];
            if (method && this[method]) this[method](value);
            return this;
        }.overloadSetter(),
        get: function(prop) {
            prop = prop.toLowerCase();
            var method = DateMethods[prop] && 'get' + DateMethods[prop];
            if (method && this[method]) return this[method]();
            return null;
        }.overloadGetter(),
        clone: function() {
            return new Date(this.get('time'));
        },
        increment: function(interval, times) {
            interval = interval || 'day';
            times = times != null ? times : 1;
            switch (interval) {
                case 'year':
                    return this.increment('month', times * 12);
                case 'month':
                    var d = this.get('date');
                    this.set('date', 1).set('mo', this.get('mo') + times);
                    return this.set('date', d.min(this.get('lastdayofmonth')));
                case 'week':
                    return this.increment('day', times * 7);
                case 'day':
                    return this.set('date', this.get('date') + times);
            }
            if (!Date.units[interval]) throw new Error(interval + ' is not a supported interval');
            return this.set('time', this.get('time') + times * Date.units[interval]());
        },
        decrement: function(interval, times) {
            return this.increment(interval, -1 * (times != null ? times : 1));
        },
        isLeapYear: function() {
            return Date.isLeapYear(this.get('year'));
        },
        clearTime: function() {
            return this.set({
                hr: 0,
                min: 0,
                sec: 0,
                ms: 0
            });
        },
        diff: function(date, resolution) {
            if (typeOf(date) == 'string') date = Date.parse(date);
            return ((date - this) / Date.units[resolution || 'day'](3, 3)).round();
        },
        getLastDayOfMonth: function() {
            return Date.daysInMonth(this.get('mo'), this.get('year'));
        },
        getDayOfYear: function() {
            return (Date.UTC(this.get('year'), this.get('mo'), this.get('date') + 1) -
                Date.UTC(this.get('year'), 0, 1)) / Date.units.day();
        },
        setDay: function(day, firstDayOfWeek) {
            if (firstDayOfWeek == null) {
                firstDayOfWeek = Date.getMsg('firstDayOfWeek');
                if (firstDayOfWeek === '') firstDayOfWeek = 1;
            }
            day = (7 + Date.parseDay(day, true) - firstDayOfWeek) % 7;
            var currentDay = (7 + this.get('day') - firstDayOfWeek) % 7;
            return this.increment('day', day - currentDay);
        },
        getWeek: function(firstDayOfWeek) {
            if (firstDayOfWeek == null) {
                firstDayOfWeek = Date.getMsg('firstDayOfWeek');
                if (firstDayOfWeek === '') firstDayOfWeek = 1;
            }
            var date = this,
                dayOfWeek = (7 + date.get('day') - firstDayOfWeek) % 7,
                dividend = 0,
                firstDayOfYear;
            if (firstDayOfWeek == 1) {
                var month = date.get('month'),
                    startOfWeek = date.get('date') - dayOfWeek;
                if (month == 11 && startOfWeek > 28) return 1;
                if (month == 0 && startOfWeek < -2) {
                    date = new Date(date).decrement('day', dayOfWeek);
                    dayOfWeek = 0;
                }
                firstDayOfYear = new Date(date.get('year'), 0, 1).get('day') || 7;
                if (firstDayOfYear > 4) dividend = -7;
            } else {
                firstDayOfYear = new Date(date.get('year'), 0, 1).get('day');
            }
            dividend += date.get('dayofyear');
            dividend += 6 - dayOfWeek;
            dividend += (7 + firstDayOfYear - firstDayOfWeek) % 7;
            return (dividend / 7);
        },
        getOrdinal: function(day) {
            return Date.getMsg('ordinal', day || this.get('date'));
        },
        getTimezone: function() {
            return this.toString().replace(/^.*? ([A-Z]{3}).[0-9]{4}.*$/, '$1').replace(/^.*?\(([A-Z])[a-z]+ ([A-Z])[a-z]+ ([A-Z])[a-z]+\)$/, '$1$2$3');
        },
        getGMTOffset: function() {
            var off = this.get('timezoneOffset');
            return ((off > 0) ? '-' : '+') + pad((off.abs() / 60).floor(), 2) + pad(off % 60, 2);
        },
        setAMPM: function(ampm) {
            ampm = ampm.toUpperCase();
            var hr = this.get('hr');
            if (hr > 11 && ampm == 'AM') return this.decrement('hour', 12);
            else if (hr < 12 && ampm == 'PM') return this.increment('hour', 12);
            return this;
        },
        getAMPM: function() {
            return (this.get('hr') < 12) ? 'AM' : 'PM';
        },
        parse: function(str) {
            this.set('time', Date.parse(str));
            return this;
        },
        isValid: function(date) {
            if (!date) date = this;
            return typeOf(date) == 'date' && !isNaN(date.valueOf());
        },
        format: function(format) {
            if (!this.isValid()) return 'invalid date';
            if (!format) format = '%x %X';
            if (typeof format == 'string') format = formats[format.toLowerCase()] || format;
            if (typeof format == 'function') return format(this);
            var d = this;
            return format.replace(/%([a-z%])/gi, function($0, $1) {
                switch ($1) {
                    case 'a':
                        return Date.getMsg('days_abbr')[d.get('day')];
                    case 'A':
                        return Date.getMsg('days')[d.get('day')];
                    case 'b':
                        return Date.getMsg('months_abbr')[d.get('month')];
                    case 'B':
                        return Date.getMsg('months')[d.get('month')];
                    case 'c':
                        return d.format('%a %b %d %H:%M:%S %Y');
                    case 'd':
                        return pad(d.get('date'), 2);
                    case 'e':
                        return pad(d.get('date'), 2, ' ');
                    case 'H':
                        return pad(d.get('hr'), 2);
                    case 'I':
                        return pad((d.get('hr') % 12) || 12, 2);
                    case 'j':
                        return pad(d.get('dayofyear'), 3);
                    case 'k':
                        return pad(d.get('hr'), 2, ' ');
                    case 'l':
                        return pad((d.get('hr') % 12) || 12, 2, ' ');
                    case 'L':
                        return pad(d.get('ms'), 3);
                    case 'm':
                        return pad((d.get('mo') + 1), 2);
                    case 'M':
                        return pad(d.get('min'), 2);
                    case 'o':
                        return d.get('ordinal');
                    case 'p':
                        return Date.getMsg(d.get('ampm'));
                    case 's':
                        return Math.round(d / 1000);
                    case 'S':
                        return pad(d.get('seconds'), 2);
                    case 'T':
                        return d.format('%H:%M:%S');
                    case 'U':
                        return pad(d.get('week'), 2);
                    case 'w':
                        return d.get('day');
                    case 'x':
                        return d.format(Date.getMsg('shortDate'));
                    case 'X':
                        return d.format(Date.getMsg('shortTime'));
                    case 'y':
                        return d.get('year').toString().substr(2);
                    case 'Y':
                        return d.get('year');
                    case 'z':
                        return d.get('GMTOffset');
                    case 'Z':
                        return d.get('Timezone');
                }
                return $1;
            });
        },
        toISOString: function() {
            return this.format('iso8601');
        }
    }).alias({
        toJSON: 'toISOString',
        compare: 'diff',
        strftime: 'format'
    });
    var rfcDayAbbr = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'],
        rfcMonthAbbr = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
    var formats = {
        db: '%Y-%m-%d %H:%M:%S',
        compact: '%Y%m%dT%H%M%S',
        'short': '%d %b %H:%M',
        'long': '%B %d, %Y %H:%M',
        rfc822: function(date) {
            return rfcDayAbbr[date.get('day')] + date.format(', %d ') + rfcMonthAbbr[date.get('month')] + date.format(' %Y %H:%M:%S %Z');
        },
        rfc2822: function(date) {
            return rfcDayAbbr[date.get('day')] + date.format(', %d ') + rfcMonthAbbr[date.get('month')] + date.format(' %Y %H:%M:%S %z');
        },
        iso8601: function(date) {
            return (date.getUTCFullYear() + '-' +
                pad(date.getUTCMonth() + 1, 2) + '-' +
                pad(date.getUTCDate(), 2) + 'T' +
                pad(date.getUTCHours(), 2) + ':' +
                pad(date.getUTCMinutes(), 2) + ':' +
                pad(date.getUTCSeconds(), 2) + '.' +
                pad(date.getUTCMilliseconds(), 3) + 'Z');
        }
    };
    var parsePatterns = [],
        nativeParse = Date.parse;
    var parseWord = function(type, word, num) {
        var ret = -1,
            translated = Date.getMsg(type + 's');
        switch (typeOf(word)) {
            case 'object':
                ret = translated[word.get(type)];
                break;
            case 'number':
                ret = translated[word];
                if (!ret) throw new Error('Invalid ' + type + ' index: ' + word);
                break;
            case 'string':
                var match = translated.filter(function(name) {
                    return this.test(name);
                }, new RegExp('^' + word, 'i'));
                if (!match.length) throw new Error('Invalid ' + type + ' string');
                if (match.length > 1) throw new Error('Ambiguous ' + type);
                ret = match[0];
        }
        return (num) ? translated.indexOf(ret) : ret;
    };
    var startCentury = 1900,
        startYear = 70;
    Date.extend({
        getMsg: function(key, args) {
            return Locale.get('Date.' + key, args);
        },
        units: {
            ms: Function.from(1),
            second: Function.from(1000),
            minute: Function.from(60000),
            hour: Function.from(3600000),
            day: Function.from(86400000),
            week: Function.from(608400000),
            month: function(month, year) {
                var d = new Date;
                return Date.daysInMonth(month != null ? month : d.get('mo'), year != null ? year : d.get('year')) * 86400000;
            },
            year: function(year) {
                year = year || new Date().get('year');
                return Date.isLeapYear(year) ? 31622400000 : 31536000000;
            }
        },
        daysInMonth: function(month, year) {
            return [31, Date.isLeapYear(year) ? 29 : 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31][month];
        },
        isLeapYear: function(year) {
            return ((year % 4 === 0) && (year % 100 !== 0)) || (year % 400 === 0);
        },
        parse: function(from) {
            var t = typeOf(from);
            if (t == 'number') return new Date(from);
            if (t != 'string') return from;
            from = from.clean();
            if (!from.length) return null;
            var parsed;
            parsePatterns.some(function(pattern) {
                var bits = pattern.re.exec(from);
                return (bits) ? (parsed = pattern.handler(bits)) : false;
            });
            if (!(parsed && parsed.isValid())) {
                parsed = new Date(nativeParse(from));
                if (!(parsed && parsed.isValid())) parsed = new Date(from.toInt());
            }
            return parsed;
        },
        parseDay: function(day, num) {
            return parseWord('day', day, num);
        },
        parseMonth: function(month, num) {
            return parseWord('month', month, num);
        },
        parseUTC: function(value) {
            var localDate = new Date(value);
            var utcSeconds = Date.UTC(localDate.get('year'), localDate.get('mo'), localDate.get('date'), localDate.get('hr'), localDate.get('min'), localDate.get('sec'), localDate.get('ms'));
            return new Date(utcSeconds);
        },
        orderIndex: function(unit) {
            return Date.getMsg('dateOrder').indexOf(unit) + 1;
        },
        defineFormat: function(name, format) {
            formats[name] = format;
            return this;
        },
        parsePatterns: parsePatterns,
        defineParser: function(pattern) {
            parsePatterns.push((pattern.re && pattern.handler) ? pattern : build(pattern));
            return this;
        },
        defineParsers: function() {
            Array.flatten(arguments).each(Date.defineParser);
            return this;
        },
        define2DigitYearStart: function(year) {
            startYear = year % 100;
            startCentury = year - startYear;
            return this;
        }
    }).extend({
        defineFormats: Date.defineFormat.overloadSetter()
    });
    var regexOf = function(type) {
        return new RegExp('(?:' + Date.getMsg(type).map(function(name) {
            return name.substr(0, 3);
        }).join('|') + ')[a-z]*');
    };
    var replacers = function(key) {
        switch (key) {
            case 'T':
                return '%H:%M:%S';
            case 'x':
                return ((Date.orderIndex('month') == 1) ? '%m[-./]%d' : '%d[-./]%m') + '([-./]%y)?';
            case 'X':
                return '%H([.:]%M)?([.:]%S([.:]%s)?)? ?%p? ?%z?';
        }
        return null;
    };
    var keys = {
        d: /[0-2]?[0-9]|3[01]/,
        H: /[01]?[0-9]|2[0-3]/,
        I: /0?[1-9]|1[0-2]/,
        M: /[0-5]?\d/,
        s: /\d+/,
        o: /[a-z]*/,
        p: /[ap]\.?m\.?/,
        y: /\d{2}|\d{4}/,
        Y: /\d{4}/,
        z: /Z|[+-]\d{2}(?::?\d{2})?/
    };
    keys.m = keys.I;
    keys.S = keys.M;
    var currentLanguage;
    var recompile = function(language) {
        currentLanguage = language;
        keys.a = keys.A = regexOf('days');
        keys.b = keys.B = regexOf('months');
        parsePatterns.each(function(pattern, i) {
            if (pattern.format) parsePatterns[i] = build(pattern.format);
        });
    };
    var build = function(format) {
        if (!currentLanguage) return {
            format: format
        };
        var parsed = [];
        var re = (format.source || format).replace(/%([a-z])/gi, function($0, $1) {
            return replacers($1) || $0;
        }).replace(/\((?!\?)/g, '(?:').replace(/ (?!\?|\*)/g, ',? ').replace(/%([a-z%])/gi, function($0, $1) {
            var p = keys[$1];
            if (!p) return $1;
            parsed.push($1);
            return '(' + p.source + ')';
        }).replace(/\[a-z\]/gi, '[a-z\\u00c0-\\uffff;\&]');
        return {
            format: format,
            re: new RegExp('^' + re + '$', 'i'),
            handler: function(bits) {
                bits = bits.slice(1).associate(parsed);
                var date = new Date().clearTime(),
                    year = bits.y || bits.Y;
                if (year != null) handle.call(date, 'y', year);
                if ('d' in bits) handle.call(date, 'd', 1);
                if ('m' in bits || bits.b || bits.B) handle.call(date, 'm', 1);
                for (var key in bits) handle.call(date, key, bits[key]);
                return date;
            }
        };
    };
    var handle = function(key, value) {
        if (!value) return this;
        switch (key) {
            case 'a':
            case 'A':
                return this.set('day', Date.parseDay(value, true));
            case 'b':
            case 'B':
                return this.set('mo', Date.parseMonth(value, true));
            case 'd':
                return this.set('date', value);
            case 'H':
            case 'I':
                return this.set('hr', value);
            case 'm':
                return this.set('mo', value - 1);
            case 'M':
                return this.set('min', value);
            case 'p':
                return this.set('ampm', value.replace(/\./g, ''));
            case 'S':
                return this.set('sec', value);
            case 's':
                return this.set('ms', ('0.' + value) * 1000);
            case 'w':
                return this.set('day', value);
            case 'Y':
                return this.set('year', value);
            case 'y':
                value = +value;
                if (value < 100) value += startCentury + (value < startYear ? 100 : 0);
                return this.set('year', value);
            case 'z':
                if (value == 'Z') value = '+00';
                var offset = value.match(/([+-])(\d{2}):?(\d{2})?/);
                offset = (offset[1] + '1') * (offset[2] * 60 + (+offset[3] || 0)) + this.getTimezoneOffset();
                return this.set('time', this - offset * 60000);
        }
        return this;
    };
    Date.defineParsers('%Y([-./]%m([-./]%d((T| )%X)?)?)?', '%Y%m%d(T%H(%M%S?)?)?', '%x( %X)?', '%d%o( %b( %Y)?)?( %X)?', '%b( %d%o)?( %Y)?( %X)?', '%Y %b( %d%o( %X)?)?', '%o %b %d %X %z %Y', '%T', '%H:%M( ?%p)?');
    Locale.addEvent('change', function(language) {
        if (Locale.get('Date')) recompile(language);
    }).fireEvent('change', Locale.getCurrent());
})();
(function() {
    var Keyboard = this.Keyboard = new Class({
        Extends: Events,
        Implements: [Options],
        options: {
            defaultEventType: 'keydown',
            active: false,
            manager: null,
            events: {},
            nonParsedEvents: ['activate', 'deactivate', 'onactivate', 'ondeactivate', 'changed', 'onchanged']
        },
        initialize: function(options) {
            if (options && options.manager) {
                this._manager = options.manager;
                delete options.manager;
            }
            this.setOptions(options);
            this._setup();
        },
        addEvent: function(type, fn, internal) {
            return this.parent(Keyboard.parse(type, this.options.defaultEventType, this.options.nonParsedEvents), fn, internal);
        },
        removeEvent: function(type, fn) {
            return this.parent(Keyboard.parse(type, this.options.defaultEventType, this.options.nonParsedEvents), fn);
        },
        toggleActive: function() {
            return this[this.isActive() ? 'deactivate' : 'activate']();
        },
        activate: function(instance) {
            if (instance) {
                if (instance.isActive()) return this;
                if (this._activeKB && instance != this._activeKB) {
                    this.previous = this._activeKB;
                    this.previous.fireEvent('deactivate');
                }
                this._activeKB = instance.fireEvent('activate');
                Keyboard.manager.fireEvent('changed');
            } else if (this._manager) {
                this._manager.activate(this);
            }
            return this;
        },
        isActive: function() {
            return this._manager ? (this._manager._activeKB == this) : (Keyboard.manager == this);
        },
        deactivate: function(instance) {
            if (instance) {
                if (instance === this._activeKB) {
                    this._activeKB = null;
                    instance.fireEvent('deactivate');
                    Keyboard.manager.fireEvent('changed');
                }
            } else if (this._manager) {
                this._manager.deactivate(this);
            }
            return this;
        },
        relinquish: function() {
            if (this.isActive() && this._manager && this._manager.previous) this._manager.activate(this._manager.previous);
            else this.deactivate();
            return this;
        },
        manage: function(instance) {
            if (instance._manager) instance._manager.drop(instance);
            this._instances.push(instance);
            instance._manager = this;
            if (!this._activeKB) this.activate(instance);
            return this;
        },
        drop: function(instance) {
            instance.relinquish();
            this._instances.erase(instance);
            if (this._activeKB == instance) {
                if (this.previous && this._instances.contains(this.previous)) this.activate(this.previous);
                else this._activeKB = this._instances[0];
            }
            return this;
        },
        trace: function() {
            Keyboard.trace(this);
        },
        each: function(fn) {
            Keyboard.each(this, fn);
        },
        _instances: [],
        _disable: function(instance) {
            if (this._activeKB == instance) this._activeKB = null;
        },
        _setup: function() {
            this.addEvents(this.options.events);
            if (Keyboard.manager && !this._manager) Keyboard.manager.manage(this);
            if (this.options.active) this.activate();
            else this.relinquish();
        },
        _handle: function(event, type) {
            if (event.preventKeyboardPropagation) return;
            var bubbles = !!this._manager;
            if (bubbles && this._activeKB) {
                this._activeKB._handle(event, type);
                if (event.preventKeyboardPropagation) return;
            }
            this.fireEvent(type, event);
            if (!bubbles && this._activeKB) this._activeKB._handle(event, type);
        }
    });
    var parsed = {};
    var modifiers = ['shift', 'control', 'alt', 'meta'];
    var regex = /^(?:shift|control|ctrl|alt|meta)$/;
    Keyboard.parse = function(type, eventType, ignore) {
        if (ignore && ignore.contains(type.toLowerCase())) return type;
        type = type.toLowerCase().replace(/^(keyup|keydown):/, function($0, $1) {
            eventType = $1;
            return '';
        });
        if (!parsed[type]) {
            if (type != '+') {
                var key, mods = {};
                type.split('+').each(function(part) {
                    if (regex.test(part)) mods[part] = true;
                    else key = part;
                });
                mods.control = mods.control || mods.ctrl;
                var keys = [];
                modifiers.each(function(mod) {
                    if (mods[mod]) keys.push(mod);
                });
                if (key) keys.push(key);
                parsed[type] = keys.join('+');
            } else {
                parsed[type] = type;
            }
        }
        return eventType + ':keys(' + parsed[type] + ')';
    };
    Keyboard.each = function(keyboard, fn) {
        var current = keyboard || Keyboard.manager;
        while (current) {
            fn(current);
            current = current._activeKB;
        }
    };
    Keyboard.stop = function(event) {
        event.preventKeyboardPropagation = true;
    };
    Keyboard.manager = new Keyboard({
        active: true
    });
    Keyboard.trace = function(keyboard) {
        keyboard = keyboard || Keyboard.manager;
        var hasConsole = window.console && console.log;
        if (hasConsole) console.log('the following items have focus: ');
        Keyboard.each(keyboard, function(current) {
            if (hasConsole) console.log(document.id(current.widget) || current.wiget || current);
        });
    };
    var handler = function(event) {
        var keys = [];
        modifiers.each(function(mod) {
            if (event[mod]) keys.push(mod);
        });
        if (!regex.test(event.key)) keys.push(event.key);
        Keyboard.manager._handle(event, event.type + ':keys(' + keys.join('+') + ')');
    };
    document.addEvents({
        'keyup': handler,
        'keydown': handler
    });
})();
Locale.define('fr-FR', 'Date', {
    months: ['Janvier', 'Février', 'Mars', 'Avril', 'Mai', 'Juin', 'Juillet', 'Août', 'Septembre', 'Octobre', 'Novembre', 'Décembre'],
    months_abbr: ['janv.', 'févr.', 'mars', 'avr.', 'mai', 'juin', 'juil.', 'août', 'sept.', 'oct.', 'nov.', 'déc.'],
    days: ['Dimanche', 'Lundi', 'Mardi', 'Mercredi', 'Jeudi', 'Vendredi', 'Samedi'],
    days_abbr: ['dim.', 'lun.', 'mar.', 'mer.', 'jeu.', 'ven.', 'sam.'],
    dateOrder: ['date', 'month', 'year'],
    shortDate: '%d/%m/%Y',
    shortTime: '%H:%M',
    AM: 'AM',
    PM: 'PM',
    firstDayOfWeek: 1,
    ordinal: function(dayOfMonth) {
        return (dayOfMonth > 1) ? '' : 'er';
    },
    lessThanMinuteAgo: "il y a moins d'une minute",
    minuteAgo: 'il y a une minute',
    minutesAgo: 'il y a {delta} minutes',
    hourAgo: 'il y a une heure',
    hoursAgo: 'il y a {delta} heures',
    dayAgo: 'il y a un jour',
    daysAgo: 'il y a {delta} jours',
    weekAgo: 'il y a une semaine',
    weeksAgo: 'il y a {delta} semaines',
    monthAgo: 'il y a 1 mois',
    monthsAgo: 'il y a {delta} mois',
    yearthAgo: 'il y a 1 an',
    yearsAgo: 'il y a {delta} ans',
    lessThanMinuteUntil: "dans moins d'une minute",
    minuteUntil: 'dans une minute',
    minutesUntil: 'dans {delta} minutes',
    hourUntil: 'dans une heure',
    hoursUntil: 'dans {delta} heures',
    dayUntil: 'dans un jour',
    daysUntil: 'dans {delta} jours',
    weekUntil: 'dans 1 semaine',
    weeksUntil: 'dans {delta} semaines',
    monthUntil: 'dans 1 mois',
    monthsUntil: 'dans {delta} mois',
    yearUntil: 'dans 1 an',
    yearsUntil: 'dans {delta} ans'
});
Locale.define('en-US', 'Number', {
    decimal: '.',
    group: ',',
    currency: {
        prefix: '$ '
    }
});
Number.implement({
    format: function(options) {
        var value = this;
        options = options ? Object.clone(options) : {};
        var getOption = function(key) {
            if (options[key] != null) return options[key];
            return Locale.get('Number.' + key);
        };
        var negative = value < 0,
            decimal = getOption('decimal'),
            precision = getOption('precision'),
            group = getOption('group'),
            decimals = getOption('decimals');
        if (negative) {
            var negativeLocale = getOption('negative') || {};
            if (negativeLocale.prefix == null && negativeLocale.suffix == null) negativeLocale.prefix = '-';
            ['prefix', 'suffix'].each(function(key) {
                if (negativeLocale[key]) options[key] = getOption(key) + negativeLocale[key];
            });
            value = -value;
        }
        var prefix = getOption('prefix'),
            suffix = getOption('suffix');
        if (decimals !== '' && decimals >= 0 && decimals <= 20) value = value.toFixed(decimals);
        if (precision >= 1 && precision <= 21) value = (+value).toPrecision(precision);
        value += '';
        var index;
        if (getOption('scientific') === false && value.indexOf('e') > -1) {
            var match = value.split('e'),
                zeros = +match[1];
            value = match[0].replace('.', '');
            if (zeros < 0) {
                zeros = -zeros - 1;
                index = match[0].indexOf('.');
                if (index > -1) zeros -= index - 1;
                while (zeros--) value = '0' + value;
                value = '0.' + value;
            } else {
                index = match[0].lastIndexOf('.');
                if (index > -1) zeros -= match[0].length - index - 1;
                while (zeros--) value += '0';
            }
        }
        if (decimal != '.') value = value.replace('.', decimal);
        if (group) {
            index = value.lastIndexOf(decimal);
            index = (index > -1) ? index : value.length;
            var newOutput = value.substring(index),
                i = index;
            while (i--) {
                if ((index - i - 1) % 3 == 0 && i != (index - 1)) newOutput = group + newOutput;
                newOutput = value.charAt(i) + newOutput;
            }
            value = newOutput;
        }
        if (prefix) value = prefix + value;
        if (suffix) value += suffix;
        return value;
    },
    formatCurrency: function(decimals) {
        var locale = Locale.get('Number.currency') || {};
        if (locale.scientific == null) locale.scientific = false;
        locale.decimals = decimals != null ? decimals : (locale.decimals == null ? 2 : locale.decimals);
        return this.format(locale);
    },
    formatPercentage: function(decimals) {
        var locale = Locale.get('Number.percentage') || {};
        if (locale.suffix == null) locale.suffix = '%';
        locale.decimals = decimals != null ? decimals : (locale.decimals == null ? 2 : locale.decimals);
        return this.format(locale);
    }
});
var ZoomTag = new function() {
    this.tailleinit = 62.5;
    this.palierinit = 1;
    this.nbzoom = 5;
    this.pourcentzoom = 12.5;
    this.nomCookiePalier = "cookiePalier";
    this.uniteZoom = "%";
    this.creerCookie = function(palier) {
        document.cookie = this.nomCookiePalier + "=" + palier;
    };
    this.lireCookie = function() {
        var cookie = document.cookie;
        var deb = cookie.indexOf(this.nomCookiePalier + "=");
        if (deb >= 0) {
            var str = cookie.substring(deb, cookie.length);
            var fin = str.indexOf(";");
            if (fin < 0) {
                fin = str.length;
            }
            str = str.substring(0, fin).split("=");
            return unescape(str[1]);
        } else {
            return null;
        }
    };
    this.toggleAriaPressed = function(cssClass) {
        $$(cssClass).each(function(bouton) {
            if (bouton.getProperty('aria-pressed') === 'false') {
                bouton.setProperty('aria-pressed', 'true');
            } else {
                bouton.setProperty('aria-pressed', 'false');
            }
        });
    };
    this.initSpan = function() {
        var zoomElements = $$('.cnamts-zoomtexte');
        zoomElements.each(function(zoomspan) {
            var zoomAgrandir = new Element('span', {
                title: 'Agrandir le texte',
                tabindex: '0',
                role: 'button'
            });
            zoomAgrandir.addClass('zoom-agrandir');
            zoomAgrandir.inject(zoomspan);
            var zoomReduire = new Element('span', {
                title: 'R\u00e9duire le texte',
                tabindex: '0',
                role: 'button'
            });
            zoomReduire.addClass('zoom-reduire');
            zoomReduire.inject(zoomspan);
            zoomAgrandir.addEvents({
                'click': function() {
                    ZoomTag.zoom();
                },
                'keydown': function(event) {
                    if (event.key === 'enter') {
                        ZoomTag.zoom();
                    }
                }
            });
            zoomReduire.addEvents({
                'click': function() {
                    ZoomTag.dezoom();
                },
                'keydown': function(event) {
                    if (event.key === 'enter') {
                        ZoomTag.dezoom();
                    }
                }
            });
        });
        this.toggleAriaPressed('.zoom-agrandir');
        this.toggleAriaPressed('.zoom-reduire');
    };
    this.initZoom = function() {
        this.initSpan();
        var body = document.getElementsByTagName("body")[0];
        var palierActu = this.lireCookie();
        if (palierActu === null || palierActu === '' || (palierActu < this.palierinit)) {
            body.style.fontSize = this.tailleinit + this.uniteZoom;
            this.creerCookie(this.palierinit);
        } else {
            if (palierActu > this.palierinit + this.nbzoom) {
                body.style.fontSize = (this.tailleinit + (this.nbzoom * this.pourcentzoom)) + this.uniteZoom;
                this.creerCookie(this.palierinit + this.nbzoom);
            } else {
                body.style.fontSize = (((parseInt(palierActu) - 1) * this.pourcentzoom) + this.tailleinit) + this.uniteZoom;
            }
        }
    };
    this.zoom = function() {
        this.toggleAriaPressed('.zoom-agrandir');
        var body = document.getElementsByTagName("body")[0];
        var palierActu = this.lireCookie();
        if (palierActu <= this.nbzoom) {
            var nouvellevaleur = (((parseInt(palierActu)) * this.pourcentzoom) + this.tailleinit);
            body.style.fontSize = nouvellevaleur + this.uniteZoom;
            this.creerCookie(parseInt(palierActu) + 1);
        }
        this.toggleAriaPressed('.zoom-agrandir');
    };
    this.dezoom = function() {
        this.toggleAriaPressed('.zoom-reduire');
        var body = document.getElementsByTagName("body")[0];
        var palierActu = this.lireCookie();
        if (palierActu > this.palierinit) {
            var nouvellevaleur = (((parseInt(palierActu) - 2) * this.pourcentzoom) + this.tailleinit);
            body.style.fontSize = nouvellevaleur + this.uniteZoom;
            this.creerCookie(parseInt(palierActu) - 1);
        }
        this.toggleAriaPressed('.zoom-reduire');
    };
};
var MenuTag = new Class({
    Implements: [Options],
    options: {
        menuover: false
    },
    element: null,
    initialize: function(element, options) {
        this.setOptions(options);
        this.element = element;
        this.initEvents();
        this.hierarchyHighlight();
        this.updateTabindex();
        if (this.options.menuover && !('ontouchstart' in window)) {
            this.menuOverEvents();
        }
    },
    initEvents: function() {
        var self = this;
        this.element.getElements('a').each(function(lien) {
            if (lien.hasClass(MenuTag.classPlier) || lien.hasClass(MenuTag.classDeplier)) {
                lien.addEvent('click', function(event) {
                    event.preventDefault();
                    self.toggle(this.id);
                });
            }
        });
        this.element.addEvent('keydown', function(event) {
            var lien = $(event.target);
            var role = lien.getParent('ul[role]').get('role');
            var subMenu = lien.getNext('ul');
            var items = (subMenu === null ? null : subMenu.getChildren('li > a'));
            switch (event.key) {
                case MenuTag.navigKeys[role].open:
                case 'space':
                    event.preventDefault();
                    lien.fireEvent('click', event);
                    if (subMenu !== null) {
                        lien.set('tabindex', -1);
                        items[0].set('tabindex', 0);
                        items[0].focus();
                    }
                    break;
                case MenuTag.navigKeys[role].previous:
                    event.preventDefault();
                    if (lien.hasClass(MenuTag.classDeplier)) {
                        lien.set('tabindex', -1);
                        items[items.length - 1].set('tabindex', 0);
                        items[items.length - 1].focus();
                    } else {
                        MenuTag.previousKey(lien);
                    }
                    break;
                case MenuTag.navigKeys[role].next:
                    event.preventDefault();
                    if (lien.hasClass(MenuTag.classDeplier)) {
                        lien.set('tabindex', -1);
                        items[0].set('tabindex', 0);
                        items[0].focus();
                    } else {
                        MenuTag.nextKey(lien);
                    }
                    break;
                case MenuTag.navigKeys[role].close:
                case 'esc':
                    var menuGroup = lien.getParent('ul');
                    if (menuGroup.hasClass("niveau2") || menuGroup.hasClass("niveau3")) {
                        var linkMenuGroup = menuGroup.getPrevious('a');
                        linkMenuGroup.fireEvent('click', event);
                        lien.set('tabindex', -1);
                        linkMenuGroup.set('tabindex', 0);
                        linkMenuGroup.focus();
                    }
                    break;
                default:
                    break;
            }
        });
    },
    menuOverEvents: function() {
        var self = this;
        this.element.getElements('li[role=menuitem]').each(function(li) {
            li.addEvent('mouseenter', function(event) {
                event.stop();
                if (this.getFirst('a').hasClass(MenuTag.classPlier)) {
                    self.toggle(this.getFirst('a').id);
                    self.updateTabindex();
                }
            });
        });
    },
    hierarchyHighlight: function() {
        var courant = this.element.getElement('.courant');
        if (courant) {
            var parents = courant.getParents('li[role=menuitem]').reverse();
            var parentsText = parents.map(function(menuParent) {
                return menuParent.getFirst('a').get('text');
            });
            parents.each(function(menuParent) {
                menuParent.addClass('mev');
                if (MenuTag.titlePrefix !== null) {
                    menuParent.getFirst('a').set('title', MenuTag.titlePrefix + parentsText.join(' / '));
                }
            });
        }
    },
    updateTabindex: function() {
        this.element.getElements('a').each(function(lien) {
            lien.set('tabindex', -1);
        });
        if (this.element.getElement('.courant') === null || !this.element.getElement('.courant').isVisible()) {
            this.element.getElement('a').set('tabindex', 0);
        } else {
            this.element.getElement('.courant').set('tabindex', 0);
        }
    },
    toggle: function(menuId) {
        if (MenuTag.getSousMenu(menuId)) {
            if ($(menuId).hasClass(MenuTag.classDeplier)) {
                MenuTag.replier(menuId);
            } else {
                this.element.getElements('a').each(function(lien) {
                    if (lien.hasClass(MenuTag.classDeplier)) {
                        MenuTag.replier(lien.id);
                    }
                });
                MenuTag.deplier(menuId);
            }
        }
    }
});
MenuTag.Vertical = new Class({
    Extends: MenuTag,
    initialize: function(element, options) {
        this.parent(element, options);
    },
    toggle: function(menuId) {
        if (MenuTag.getSousMenu(menuId)) {
            if ($(menuId).hasClass(MenuTag.classDeplier)) {
                MenuTag.replier(menuId);
            } else {
                MenuTag.deplier(menuId);
            }
        }
    }
});
MenuTag.Mixte = new Class({
    Extends: MenuTag,
    initialize: function(element, options) {
        this.parent(element, options);
        this.element.getElements('a').each(function(lien) {
            if (lien.hasClass(MenuTag.classDeplier)) {
                MenuTag.replier(lien.id);
            }
        });
        this.menuCloseEvents();
    },
    menuOverEvents: function() {
        var self = this;
        this.element.getElements('li[role=menuitem]').each(function(li) {
            li.addEvent('mouseenter', function(event) {
                event.stop();
                self.toggle(this.getFirst('a').id);
            });
        });
        this.element.addEvent('mouseleave', function(event) {
            event.stop();
            self.element.getElements('a').each(function(lien) {
                if (lien.hasClass(MenuTag.classDeplier)) {
                    MenuTag.replier(lien.id);
                }
            });
        });
    },
    menuCloseEvents: function() {
        $(document).addEvent('click', function(event) {
            if (this.element.getElement(event.target) === null) {
                this.close();
            }
        }.bind(this));
        $(document).addEvent('keyup', function(event) {
            if (event.key === 'tab' && document.activeElement && this.element.getElement(document.activeElement) === null) {
                this.close();
            }
        }.bind(this));
    },
    updateTabindex: function() {
        this.element.getElements('a').each(function(lien) {
            lien.set('tabindex', -1);
        });
        var menuFocusable = this.element.getElement('.niveau1 > .mev > a');
        if (menuFocusable === null) {
            this.element.getElement('a').set('tabindex', 0);
        } else {
            menuFocusable.set('tabindex', 0);
        }
    },
    toggle: function(menuId) {
        if ($(menuId).hasClass(MenuTag.classDeplier)) {
            MenuTag.replier(menuId);
        } else {
            this.closeOthers(menuId);
            if ($(menuId).hasClass(MenuTag.classPlier)) {
                MenuTag.deplier(menuId);
                this.position(menuId);
            }
        }
    },
    closeOthers: function(menuId) {
        this.element.getElements('a.' + MenuTag.classDeplier).each(function(lien) {
            if (lien.getParent('li').getElement('#' + menuId) === null) {
                MenuTag.replier(lien.id);
            }
        });
    },
    close: function() {
        this.element.getElements('a.' + MenuTag.classDeplier).each(function(lien) {
            MenuTag.replier(lien.id);
        });
        this.updateTabindex();
    },
    position: function(menuId) {
        var sousMenu = MenuTag.getSousMenu(menuId);
        if (sousMenu.hasClass('niveau2')) {
            sousMenu.setPosition({
                x: $(menuId).getPosition(this.element).x,
                y: $(menuId).getComputedSize().height
            });
        }
        if (sousMenu.hasClass('niveau3')) {
            var ulNiveau2 = sousMenu.getParent('li').getParent('ul');
            var posLiNiveau2 = sousMenu.getParent('li').getPosition(ulNiveau2);
            var posX = ulNiveau2.getComputedSize().width;
            var sousMenuWidth = sousMenu.measure(function() {
                return this.getComputedSize();
            }).totalWidth;
            if ((posX + ulNiveau2.getPosition().x + sousMenuWidth) > window.getSize().x) {
                posX = -1 * sousMenuWidth;
            }
            sousMenu.setPosition({
                x: posX,
                y: posLiNiveau2.y
            });
        }
    }
});
MenuTag.extend({
    components: {},
    classPlier: "plier",
    classDeplier: "deplier",
    classInvisible: "cacher",
    classVisible: "visible",
    prefixeSousMenu: "ssMen_",
    classHorizontal: "nav-horizontal",
    classMixte: "nav-mixte",
    titlePrefix: 'Vous \u00eates sur ',
    navigKeys: {
        menu: {
            next: "down",
            previous: "up",
            open: "right",
            close: "left"
        },
        menubar: {
            next: "right",
            previous: "left",
            open: "down",
            close: "up"
        }
    },
    init: function(element, options) {
        if (element.hasClass(MenuTag.classHorizontal)) {
            this.components[element.id] = new MenuTag(element, options);
        } else if (element.hasClass(MenuTag.classMixte)) {
            this.components[element.id] = new MenuTag.Mixte(element, options);
        } else {
            this.components[element.id] = new MenuTag.Vertical(element, options);
        }
    },
    replier: function(menuId) {
        $(menuId).swapClass(MenuTag.classDeplier, MenuTag.classPlier);
        MenuTag.getSousMenu(menuId).swapClass(MenuTag.classVisible, MenuTag.classInvisible);
    },
    deplier: function(menuId) {
        $(menuId).swapClass(MenuTag.classPlier, MenuTag.classDeplier);
        MenuTag.getSousMenu(menuId).swapClass(MenuTag.classInvisible, MenuTag.classVisible);
    },
    getSousMenu: function(menuId) {
        return $(MenuTag.prefixeSousMenu + menuId);
    },
    previousKey: function(lien) {
        var menuGroup = lien.getParent('ul');
        var items = menuGroup.getChildren('li > a');
        var previousLink = items[items.length - 1];
        for (var i = items.length - 1; i > 0; i--) {
            if (items[i] === lien) {
                previousLink = items[i - 1];
                break;
            }
        }
        lien.set('tabindex', -1);
        previousLink.set('tabindex', 0);
        previousLink.focus();
    },
    nextKey: function(lien) {
        var menuGroup = lien.getParent('ul');
        var items = menuGroup.getChildren('li > a');
        var nextLink = items[0];
        for (var i = 0; i < items.length - 1; i++) {
            if (items[i] === lien) {
                nextLink = items[i + 1];
                break;
            }
        }
        lien.set('tabindex', -1);
        nextLink.set('tabindex', 0);
        nextLink.focus();
    }
});

function syncSelToTextSimple(champSel, champTextName) {
    var champText = document.getElementById(champTextName);
    if (champText !== null) {
        if (champSel.selectedIndex > 0) {
            if (champText.defaultValue === null) {
                champText.defaultValue = champText.value;
            }
            champText.value = champSel.options[champSel.selectedIndex].text;
        } else {
            if (champText.defaultValue !== null) {
                champText.value = champText.defaultValue;
            }
        }
    }
}

function syncTextToSelSimple(champText, champSelName) {
    var champSel = document.getElementById(champSelName);
    var code;
    var i;
    if (champSel !== null) {
        code = champText.value;
        champText.defaultValue = code;
        lst = champSel.options;
        lst[0].selected = true;
        for (i = 1; i < lst.length; i++) {
            lst[i].selected = (code === lst[i].text);
        }
    }
}

function syncSelToTextDouble(champSel, champCodePostalName, champLocaliteName) {
    var champCodePostal = document.getElementById(champCodePostalName);
    var champLocalite = document.getElementById(champLocaliteName);
    if (champCodePostal !== null && champLocalite !== null) {
        if (champSel.selectedIndex > 0) {
            if (champCodePostal.defaultValue === null) {
                champCodePostal.defaultValue = champCodePostal.value;
            }
            if (champLocalite.defaultValue === null) {
                champLocalite.defaultValue = champLocalite.value;
            }
            champCodePostal.value = champSel.options[champSel.selectedIndex].getAttribute("value").split('|')[0];
            champLocalite.value = champSel.options[champSel.selectedIndex].getAttribute("value").split('|')[1];
        } else {
            if (champCodePostal.defaultValue !== null) {
                champCodePostal.value = champCodePostal.defaultValue;
            }
            if (champLocalite.defaultValue !== null) {
                champLocalite.value = champLocalite.defaultValue;
            }
        }
    }
}

function syncTextToSelDouble(champCodePostalName, champLocaliteName, champSelName) {
    var champCodePostal = document.getElementById(champCodePostalName);
    var champLocalite = document.getElementById(champLocaliteName);
    var champSel = document.getElementById(champSelName);
    var codePostal;
    var localite;
    var i;
    if (champCodePostal !== null && champLocalite !== null && champSel !== null) {
        codePostal = champCodePostal.value;
        localite = champLocalite.value;
        champCodePostal.defaultValue = codePostal;
        champLocalite.defaultValue = localite;
        lst = champSel.options;
        lst[0].selected = true;
        for (i = 1; i < lst.length; i++) {
            lst[i].selected = (codePostal === lst[i].getAttribute("value").split('|')[0]) && (localite === lst[i].getAttribute("value").split('|')[1]);
        }
    }
}

function doTrim(string) {
    return String(string).replace(/^\s+|\s+$/g, "").replace(/\s+/g, " ");
}

function controlRequiredFields(fieldsForm) {
    if (fieldsForm === null || document.forms[fieldsForm] === null) {
        return true;
    }
    var el = document.forms[fieldsForm].elements;
    if (el === null) {
        return true;
    }
    var i = 0;
    var notFound = true;
    var element;
    while (notFound && (i < el.length)) {
        element = el[i];
        if (element.getAttribute("obligatoire") !== null && element.getAttribute("obligatoire") === "true") {
            notFound = notFound && (doTrim(element.value).length > 0);
        }
        i++;
    }
    if (!notFound) {
        alert('Champ obligatoire');
        element.focus();
    }
    return notFound;
};
var ListNavig = {
    previousKey: function(link) {
        var group = link.getParent('ul');
        var items = group.getChildren(group.navigChildsSelector);
        var previousLink = items[items.length - 1];
        for (var i = items.length - 1; i > 0; i--) {
            if (items[i] === link) {
                previousLink = items[i - 1];
                break;
            }
        }
        previousLink.focus();
    },
    nextKey: function(link) {
        var group = link.getParent('ul');
        var items = group.getChildren(group.navigChildsSelector);
        var nextLink = items[0];
        for (var i = 0; i < items.length - 1; i++) {
            if (items[i] === link) {
                nextLink = items[i + 1];
                break;
            }
        }
        nextLink.focus();
    },
    initEvents: function(navigContainer) {
        navigContainer.getElements('a').each(function(link) {
            link.addEvent('keydown', function(event) {
                switch (event.key) {
                    case 'up':
                    case 'left':
                        event.preventDefault();
                        ListNavig.previousKey(this);
                        break;
                    case 'down':
                    case 'right':
                        event.preventDefault();
                        ListNavig.nextKey(this);
                        break;
                    default:
                        break;
                }
            });
        });
        var section = navigContainer.getNext();
        if (section !== null && section.hasClass('section')) {
            section.addEvent('keydown', function(event) {
                if (event.control && event.key === "up") {
                    navigContainer.getElement('a[tabindex=0]').focus();
                }
            });
        }
    }
};
var MessageFormat = {
    format: function(str, col) {
        col = typeof col === 'object' ? col : Array.prototype.slice.call(arguments, 1);
        return str.replace(/\{\{|\}\}|\{(\w+)\}/g, function(m, n) {
            if (m == "{{") {
                return "{";
            }
            if (m == "}}") {
                return "}";
            }
            return col[n];
        });
    },
    pluralFormat: function(pattern01, patterns, test, col) {
        var args = Array.prototype.slice.call(arguments, 2);
        if (test <= 1) {
            return MessageFormat.format(pattern01, args);
        } else {
            return MessageFormat.format(patterns, args);
        }
    }
};
Fx.TweenBiblicnam = new Class({
    Extends: Fx.Tween,
    start: function(from, to) {
        var delta = Math.abs(from - to);
        if (this.options.threshold && delta < this.options.threshold) {
            this.calcNewDuration(delta);
        }
        return this.parent(from, to);
    },
    calcNewDuration: function(delta) {
        var duration = (delta / this.options.threshold) * this.options.duration;
        var minDuration = this.options.duration / 10;
        if (duration < minDuration) {
            duration = minDuration;
        }
        this.options.duration = duration;
    }
});
var ArboTag = new Class({
    Implements: [Options],
    options: {
        nodeAction: null,
        contentContainer: null,
        branchAction: null
    },
    element: null,
    defaultAction: null,
    initialize: function(element, defaultAction, options) {
        this.setOptions(options);
        this.element = element;
        this.defaultAction = defaultAction;
        this.initEvents();
        return this;
    },
    initEvents: function() {
        var self = this;
        if (self.options.nodeAction !== null && self.options.contentContainer !== null) {
            self.initAjaxNodeEvents(this.element);
        }
        if (Browser.ie) {
            self.element.getElements('li:last-child').each(function(item) {
                item.addClass('dernier');
            });
        }
        this.element.getElements('.dossier').each(function(item) {
            if (item.hasClass("ferme")) {
                var childContainer = item.getParent('li').getChildren('ul');
                if (childContainer !== null) {
                    childContainer.addClass('ferme');
                }
            }
            item.addEvent('click', function(event) {
                event.stop();
                self.toggleFolder(this);
            });
        });
        var toolbar = this.element.getElement('.actions');
        if (toolbar !== null) {
            var openAllBtn = new Element('a', {
                href: '#' + this.element.id,
                'class': "tout-ouvrir",
                title: "Tout ouvrir",
                role: "button"
            });
            var closeAllBtn = new Element('a', {
                href: '#' + this.element.id,
                'class': "tout-fermer",
                title: "Tout fermer",
                role: "button"
            });
            openAllBtn.addEvent('click', function(event) {
                event.stop();
                self.openAll();
            });
            closeAllBtn.addEvent('click', function(event) {
                event.stop();
                self.closeAll();
            });
            openAllBtn.inject(toolbar);
            closeAllBtn.inject(toolbar);
        }
        if ($('btn_openall') !== null) {
            $('btn_openall').addEvent('click', function(event) {
                event.stop();
                self.openAll();
            });
            $('btn_closeall').addEvent('click', function(event) {
                event.stop();
                self.closeAll();
            });
        }
        self.initTabIndex();
        DOMEvent.defineKeys({
            '58': '2points',
            '106': 'multiply',
            '111': 'divide',
            '170': 'mu'
        });
        self.element.addEvent('keydown', self.arboKeydownEvent.bind(self));
    },
    arboKeydownEvent: function(event) {
        if (ArboTag.isBranchLabel(event.target)) {
            switch (event.key) {
                case 'multiply':
                case 'mu':
                    this.openAll();
                    break;
                case 'divide':
                    event.preventDefault();
                    this.closeAll();
                    break;
                case '2points':
                    if (event.shift) {
                        event.preventDefault();
                        this.closeAll();
                    }
                    break;
                case 'space':
                    event.preventDefault();
                    $(event.target).fireEvent('click', event);
                    break;
                case 'home':
                    event.preventDefault();
                    var firstNode = this.element.getElement('ul a');
                    if (firstNode !== null) {
                        ArboTag.switchFocus($(event.target), firstNode);
                    }
                    break;
                case 'end':
                    event.preventDefault();
                    var lastNode = this.element.getLast('ul:not(.ferme) > li > a');
                    if (lastNode !== null) {
                        ArboTag.switchFocus($(event.target), lastNode);
                    }
                    break;
                case 'left':
                    event.preventDefault();
                    if ($(event.target).hasClass('ouvert')) {
                        $(event.target).fireEvent('click', event);
                    } else {
                        var branch = $(event.target).getParent('li').getParent('li');
                        if (branch !== null) {
                            ArboTag.switchFocus($(event.target), branch.getElement('a'));
                        }
                    }
                    break;
                case 'right':
                    event.preventDefault();
                    if ($(event.target).hasClass('ferme')) {
                        $(event.target).fireEvent('click', event);
                    } else {
                        var firstNode = $(event.target).getParent('li').getElement('ul a');
                        if (firstNode !== null) {
                            ArboTag.switchFocus($(event.target), firstNode);
                        }
                    }
                    break;
                case 'up':
                    event.preventDefault();
                    var visibleNodes = this.getVisibleNodes();
                    if (visibleNodes.length > 0) {
                        var posCurrentNode = visibleNodes.indexOf($(event.target));
                        var posPreviousNode = ((posCurrentNode - 1) < 0 ? visibleNodes.length - 1 : posCurrentNode - 1);
                        ArboTag.switchFocus($(event.target), visibleNodes[posPreviousNode]);
                    }
                    break;
                case 'down':
                    event.preventDefault();
                    var visibleNodes = this.getVisibleNodes();
                    if (visibleNodes.length > 0) {
                        var posCurrentNode = visibleNodes.indexOf($(event.target));
                        var posNextNode = ((posCurrentNode + 1) >= visibleNodes.length ? 0 : posCurrentNode + 1);
                        ArboTag.switchFocus($(event.target), visibleNodes[posNextNode]);
                    }
                    break;
                default:
                    break;
            }
        } else {
            switch (event.key) {
                case 'left':
                    event.preventDefault();
                    var label = $(event.target).getParent('li[role=treeitem]').getElement('a');
                    if (label) {
                        label.focus();
                    }
                default:
                    break;
            }
        }
    },
    getVisibleNodes: function() {
        if (Browser.ie7 || Browser.ie8) {
            return this.element.getElements('ul > li > a').filter(function(item, index) {
                return item.getParent('ul.ferme') === null;
            });
        } else {
            return this.element.getElements('ul:not(.ferme) > li > a');
        }
    },
    selectNode: function(node) {
        this.element.getElements('a.selected, a[tabindex=0]').each(function(link) {
            link.removeClass('selected');
            link.set('tabindex', -1);
            link.erase('aria-selected');
        });
        node.addClass('selected');
        node.set('tabindex', 0);
        node.set('aria-selected', 'true');
    },
    initTabIndex: function() {
        var found = false;
        this.element.getElements('ul a').each(function(link) {
            if (link.hasClass('selected')) {
                link.set('tabindex', 0);
                found = true;
            } else {
                link.set('tabindex', -1);
            }
        });
        if (!found) {
            var firstNode = this.element.getElement('ul a');
            if (firstNode !== null) {
                firstNode.set('tabindex', 0);
            }
        }
    },
    initAjaxNodeEvents: function(nodeContainer) {
        var self = this;
        nodeContainer.getElements('ul a:not(.dossier)').each(function(node) {
            if (node.href.indexOf(self.defaultAction) > -1) {
                node.addEvent('click', function(e) {
                    e.stop();
                    $(self.options.contentContainer).set('html', ArboTag.nodeWaitMessage);
                    $(self.options.contentContainer).set('load', {
                        method: 'post',
                        async: true
                    });
                    $(self.options.contentContainer).load(self.options.nodeAction + '?node=' + this.id);
                    self.selectNode(this);
                });
                node.set('aria-controls', self.options.contentContainer);
            }
        });
    },
    openAll: function() {
        var self = this;
        this.element.getElements('a.ferme + ul').each(function(element) {
            self.toggleFolder(element.getParent('li').getElement('a'));
        });
    },
    closeAll: function() {
        var self = this;
        this.element.getElements('a.ouvert + ul').each(function(element) {
            self.toggleFolder(element.getParent('li').getElement('a'));
        });
    },
    getChildRequest: function(target) {
        var self = this;
        return new Request.JSON({
            url: self.options.branchAction,
            async: true,
            timeout: ArboTag.timeout,
            onRequest: function() {
                ArboTag.addMessageChild(ArboTag.branchWaitMessage, target);
                target.setProperty('aria-busy', 'true');
            },
            onSuccess: function(data) {
                target.getChildren('ul').destroy();
                self.parseJsonChildrens(data).inject(target);
                if (Browser.ie) {
                    target.getElements('li:last-child').each(function(item) {
                        item.addClass('dernier');
                    });
                }
                target.getElements('ul .dossier').each(function(item) {
                    item.addEvent('click', function(event) {
                        event.stop();
                        self.toggleFolder(this);
                    });
                });
                var childContainer = target.getChildren('ul');
                if (childContainer.length > 0) {
                    childContainer.removeClass('ferme');
                }
                self.initTabIndex();
                target.setProperty('aria-busy', 'false');
            },
            onTimeout: function() {
                ArboTag.addMessageChild("Délai d'attente dépassé", target);
                target.setProperty('aria-busy', 'false');
                this.cancel();
            },
            onError: function() {
                ArboTag.addMessageChild("Erreur lors de la récupération", target);
            },
            onFailure: function() {
                ArboTag.addMessageChild("Erreur lors du chargement", target);
            }
        });
    },
    parseJsonChildrens: function(data) {
        var self = this;
        var ul = new Element('ul');
        ul.addClass('ferme');
        for (var i = 0; i < data.length; i++) {
            var bean = data[i];
            var li = new Element('li', {
                'role': 'treeitem'
            });
            var elementTitle = null;
            if (bean.link) {
                elementTitle = new Element('a', {
                    id: bean.key,
                    text: bean.label
                });
                elementTitle.href = bean.link;
            } else if (this.defaultAction.length > 0 || bean.elements !== undefined || bean.branch) {
                elementTitle = new Element('a', {
                    id: bean.key,
                    text: bean.label
                });
                elementTitle.href = this.defaultAction + '?node=' + bean.key;
                if (self.options.nodeAction !== null && self.options.contentContainer !== null) {
                    if (bean.elements === undefined && bean.branch === undefined) {
                        elementTitle.addEvent('click', function(e) {
                            e.stop();
                            $(self.options.contentContainer).innerHTML = ArboTag.nodeWaitMessage;
                            $(self.options.contentContainer).set('load', {
                                method: 'post',
                                async: true
                            });
                            $(self.options.contentContainer).load(self.options.nodeAction + '?node=' + this.id);
                            self.selectNode(this);
                        });
                    }
                }
            } else {
                elementTitle = new Element('span', {
                    id: bean.key,
                    text: bean.label
                });
            }
            if (bean.pictogram) {
                elementTitle.addClass(bean.pictogram);
            }
            if (bean.elements !== undefined || bean.branch) {
                li.addClass('branche');
                li.setProperty('aria-expanded', 'false');
                li.setProperty('role', 'treeitem');
                elementTitle.addClass('dossier ferme');
                elementTitle.inject(li);
                if (bean.extraHtml) {
                    var extraHtmlElement = Elements.from(bean.extraHtml);
                    extraHtmlElement.inject(li);
                }
                if (bean.branch) {
                    self.initAjaxNodeEvents(li);
                } else {
                    self.parseJsonChildrens(bean.elements).inject(li);
                }
            } else {
                elementTitle.inject(li);
                if (bean.extraHtml) {
                    var extraHtmlElement = Elements.from(bean.extraHtml);
                    extraHtmlElement.inject(li);
                }
            }
            li.inject(ul);
        }
        return ul;
    },
    toggleFolder: function(folder) {
        var childContainer = folder.getParent('li').getChildren('ul');
        if (folder.hasClass('ouvert')) {
            folder.removeClass('ouvert');
            folder.addClass('ferme');
            folder.getParent('li').setProperty('aria-expanded', 'false');
            if (childContainer.length > 0) {
                childContainer.addClass('ferme');
            }
        } else {
            folder.removeClass('ferme');
            folder.addClass('ouvert');
            folder.getParent('li').setProperty('aria-expanded', 'true');
            if (childContainer.length > 0) {
                childContainer.removeClass('ferme');
            } else {
                if (this.options.branchAction !== null) {
                    var request = this.getChildRequest(folder.getParent('li'));
                    request.send("branch=" + folder.id);
                }
            }
        }
    }
});
ArboTag.extend({
    components: {},
    nodeWaitMessage: '<div class="section"><p>Chargement en cours\u2026</p></div>',
    branchWaitMessage: 'Chargement en cours\u2026',
    timeout: 5000,
    init: function(element, defaultAction, options) {
        this.components[element.id] = new ArboTag(element, defaultAction, options);
    },
    isBranchLabel: function(element) {
        var branch = element.getParent('li[role=treeitem]');
        if (branch !== null) {
            return branch.getFirst() === element;
        }
        return false;
    },
    addMessageChild: function(message, target) {
        target.getChildren('ul').destroy();
        var ul = new Element('ul');
        var li = new Element('li', {
            text: message
        });
        li.inject(ul);
        ul.inject(target);
    },
    switchFocus: function(node, nextNode) {
        node.set('tabindex', -1);
        nextNode.set('tabindex', 0);
        nextNode.focus();
    }
});
(function(global, $) {
    var browser = Browser;
    Object.append(Element.NativeEvents, {
        'paste': 2,
        'input': 2
    });
    Element.Events.paste = {
        base: (browser.opera || (browser.firefox && (browser.version < 3))) ? 'input' : 'paste',
        condition: function(e) {
            this.fireEvent('paste', e, 1);
            return false;
        }
    };
    Element.Events.keyrepeat = {
        base: (browser.firefox || browser.opera) ? 'keypress' : 'keydown',
        condition: Function.from(true)
    };
    var Meio = {};
    var globalCache;
    var keysThatDontChangeValueOnKeyUp = {
        9: 1,
        16: 1,
        17: 1,
        18: 1,
        224: 1,
        91: 1,
        37: 1,
        38: 1,
        39: 1,
        40: 1
    };
    var encode = function(str) {
        return str.replace(/"/g, '&quot;').replace(/'/g, '&#39;');
    };
    Meio.Widget = new Class({
        initialize: function() {
            this.elements = {};
        },
        addElement: function(name, obj) {
            this.elements[name] = obj;
        },
        addEventToElement: function(name, eventName, event) {
            this.elements[name].addEvent(eventName, event.bindWithEvent(this));
        },
        addEventsToElement: function(name, events) {
            for (var eventName in events) {
                this.addEventToElement(name, eventName, events[eventName]);
            }
        },
        attach: function() {
            for (var element in this.elements) {
                this.elements[element].attach();
            }
        },
        detach: function() {
            for (var element in this.elements) {
                this.elements[element].detach();
            }
        },
        destroy: function() {
            for (var element in this.elements) {
                this.elements[element] && this.elements[element].destroy();
            }
        }
    });
    Meio.Autocomplete = new Class({
        Extends: Meio.Widget,
        Implements: [Options, Events],
        options: {
            delay: 200,
            minChars: 0,
            cacheLength: 20,
            selectOnTab: true,
            maxVisibleItems: 10,
            cacheType: 'shared',
            filter: {},
            fieldOptions: {},
            listOptions: {},
            requestOptions: {},
            urlOptions: {}
        },
        initialize: function(input, data, options, listInstance) {
            this.input = input;
            this.parent();
            this.setOptions(options);
            this.active = 0;
            $(input).setProperty('role', 'combobox');
            $(input).setProperty('aria-autocomplete', 'none');
            $(input).setProperty('aria-owns', this.input + '-list');
            $(input).setProperty('aria-expanded', 'false');
            this.filters = Meio.Autocomplete.Filter.get(this.options.filter);
            this.addElement('list', listInstance || new Meio.Element.List(this.input, this.options.listOptions));
            this.addListEvents();
            this.addElement('field', new Meio.Element.Field(input, this.options.fieldOptions));
            this.addFieldEvents();
            this.addSelectEvents();
            this.attach();
            this.initCache();
            this.initData(data);
        },
        addFieldEvents: function() {
            this.addEventsToElement('field', {
                'beforeKeyrepeat': function(e) {
                    this.active = 1;
                    var e_key = e.key,
                        list = this.elements.list;
                    if ((e_key === 'up') || (e_key === 'down') || ((e_key === 'enter') && list.showing)) {
                        e.preventDefault();
                    }
                },
                'delayedKeyrepeat': function(e) {
                    var e_key = e.key,
                        field = this.elements.field;
                    field.keyPressControl[e_key] = true;
                    switch (e_key) {
                        case 'up':
                        case 'down':
                            this.focusItem(e_key);
                            break;
                        case 'enter':
                        case 'right':
                            this.setInputValue();
                            break;
                        case 'tab':
                            if (this.options.selectOnTab) {
                                this.setInputValue();
                            }
                            field.keyPressControl[e_key] = false;
                            break;
                        case 'esc':
                            this.elements.list.hide();
                            break;
                        default:
                            this.setupList();
                    }
                },
                'keyup': function(e) {
                    var field = this.elements.field;
                    if (!keysThatDontChangeValueOnKeyUp[e.code]) {
                        if (!field.keyPressControl[e.key]) {
                            this.setupList();
                        }
                        field.keyPressControl[e.key] = false;
                    }
                },
                'focus': function() {
                    this.active = 1;
                    var list = this.elements.list;
                    list.focusedItem = null;
                    list.positionNextTo(this.elements.field.node);
                },
                'click': function() {
                    if ((this.active++ > 1) && !this.elements.list.showing) {
                        this.forceSetupList();
                    }
                },
                'blur': function(e) {
                    var list = this.elements.list;
                    if (!list.focusedItem) {
                        this.active = 0;
                        list.hide();
                    }
                },
                'paste': function() {
                    return this.setupList();
                }
            });
        },
        addListEvents: function() {
            this.addEventsToElement('list', {
                'mousedown': function(e) {
                    if (this.active && !e.dontHide) {
                        this.setInputValue();
                        this.elements.list.focusedItem = null;
                        this.inputedText = this.elements.field.node.get('value');
                    }
                },
                'keydown': function(e) {
                    switch (e.key) {
                        case 'up':
                        case 'down':
                            e.preventDefault();
                            this.elements.list.enableBlurEvent = false;
                            this.focusItem(e.key);
                            break;
                        case 'enter':
                        case 'tab':
                            e.preventDefault();
                            this.setInputValue();
                            this.elements.list.focusedItem = null;
                            this.inputedText = this.elements.field.node.get('value');
                            this.elements.field.node.focus();
                            break;
                        case 'esc':
                            this.elements.list.hide();
                            this.elements.list.focusedItem = null;
                            this.elements.field.node.focus();
                            break;
                        default:
                            this.elements.field.node.focus();
                            break;
                    }
                }
            });
        },
        update: function() {
            var oldDomaine = null;
            var idligne = null;
            var data = this.data,
                list = this.elements.list;
            var html;
            data = data.get();
            var itemsHtml = [],
                itemsData = [],
                classes = list.options.classes,
                text = this.inputedText;
            var filter = this.filters.filter,
                formatMatch = this.filters.formatMatch,
                formatItem = this.filters.formatItem;
            for (var row, i = 0, n = 0; row = data[i++];) {
                var txt = 'text'.split('.');
                var dom = 'domaine'.split('.');
                if (row.text === "" && row.domaine === "") {
                    oldDomaine = null;
                    continue;
                }
                if (filter.call(this, text, row, txt) || filter.call(this, text, row, dom)) {
                    idligne = this.input + row.value + row.text + row.domaine;
                    var newCat = '';
                    if (oldDomaine !== row.domaine) {
                        if (null === row.text || "" === row.text) {
                            itemsHtml.push('<li id="', idligne, '" tabindex="0" role="option" title="', encode(row.domaine) + ' - ' + encode(row.domaine), '" data-index="', n, '" class="', classes.newcategorie, '">', encode(row.domaine), '</li>');
                        } else {
                            newCat = '" class="' + classes.newcategorie;
                        }
                        oldDomaine = row.domaine;
                    }
                    if (null === row.domaine || "" === row.domaine) {
                        itemsHtml.push('<li id="', idligne, '" tabindex="0" role="option" title="', encode(row.text), '" data-index="', n, newCat, '">', formatItem.call(this, text, row, n), '</li>');
                    } else if (null !== row.text && "" !== row.text) {
                        itemsHtml.push('<li id="', idligne, '" tabindex="0" role="option" title="', encode(row.domaine) + ' - ' + encode(formatMatch.call(this, row.text, row)), '" data-index="', n, newCat, '">', '<span class="', classes.categorie, '">', encode(row.domaine), '</span> - ', formatItem.call(this, text, row, n), '</li>');
                    }
                    itemsData.push(row);
                    n++;
                }
            }
            html = itemsHtml.join('');
            this.itemsData = itemsData;
            list.list.set('html', html);
            list.list.getElements('li').each(function(item) {
                item.addEvent('blur', function(event) {
                    if (list.enableBlurEvent === undefined || list.enableBlurEvent === true) {
                        list.hide();
                        list.focusedItem = null;
                    } else {
                        list.enableBlurEvent = true;
                    }
                });
            });
            if (this.options.maxVisibleItems) {
                list.applyMaxHeight(this.options.maxVisibleItems);
            }
        },
        setupList: function() {
            this.inputedText = this.elements.field.node.get('value');
            this.forceSetupList(this.inputedText);
            return true;
        },
        forceSetupList: function(inputedText) {
            inputedText = inputedText || this.elements.field.node.get('value');
            if (inputedText.length >= this.options.minChars) {
                clearInterval(this.prepareTimer);
                this.prepareTimer = this.data.prepare.delay(this.options.delay, this.data, this.inputedText);
            } else {
                list = this.elements.list;
                list.list.set('html', "");
                list.hide();
            }
        },
        dataReady: function() {
            this.update();
            var list = this.elements.list;
            if (list.focusedItem) {
                list.focusedItem = $(list.focusedItem.id);
                if (list.focusedItem) {
                    list.focusedItem.addClass(list.options.classes.hover);
                }
            }
            if (this.onUpdate) {
                this.onUpdate();
                this.onUpdate = null;
            }
            list = this.elements.list;
            if (list.list.get('html') && (this.inputedText.length !== null) && (this.inputedText.length !== 0)) {
                if (this.active) {
                    list.show();
                }
            } else {
                this.fireEvent('noItemToList', [this.elements]);
                list.hide();
            }
        },
        setInputValue: function() {
            var list = this.elements.list;
            if (list.focusedItem) {
                var item = list.focusedItem.clone();
                var text = list.focusedItem.get('title');
                if (item.getElement('span')) {
                    item.getElement('span').destroy();
                    text = item.get('text').substring(3);
                }
                this.elements.field.node.set('value', text);
                var index = list.focusedItem.get('data-index');
                this.fireEvent('select', [this.elements, this.itemsData[index], text, index]);
            }
            list.hide();
        },
        focusItem: function(direction) {
            var list = this.elements.list;
            if (list.showing) {
                list.focusItem(direction);
            } else {
                this.forceSetupList();
                this.onUpdate = function() {
                    list.focusItem(direction);
                };
            }
        },
        addSelectEvents: function() {
            this.addEvents({
                select: function(elements) {
                    elements.field.addClass('selected');
                },
                deselect: function(elements) {
                    elements.field.removeClass('selected');
                }
            });
        },
        initData: function(data) {
            this.data = (typeOf(data) === 'string') ? new Meio.Autocomplete.Data.Request(data, this.cache, this.elements.field, this.options.requestOptions, this.options.urlOptions) : new Meio.Autocomplete.Data(data, this.cache);
            this.data.addEvent('ready', this.dataReady.bind(this));
        },
        initCache: function() {
            var cacheLength = this.options.cacheLength;
            if (this.options.cacheType === 'shared') {
                this.cache = globalCache;
                this.cache.setMaxLength(cacheLength);
            } else {
                this.cache = new Meio.Autocomplete.Cache(cacheLength);
            }
        },
        refreshCache: function(cacheLength) {
            this.cache.refresh();
            this.cache.setMaxLength(cacheLength || this.options.cacheLength);
        },
        refreshAll: function(cacheLength, urlOptions) {
            this.refreshCache(cacheLength);
            this.data.refreshKey(urlOptions);
        }
    });
    Meio.Autocomplete.Select = new Class({
        Extends: Meio.Autocomplete,
        options: {
            syncName: 'id',
            valueField: null,
            valueFilter: function(data) {
                return data.id;
            }
        },
        initialize: function(input, data, options, listInstance) {
            this.parent(input, data, options, listInstance);
            this.valueField = $(this.options.valueField);
            if (!this.valueField) {
                return;
            }
            if (this.options.syncName) {
                this.syncWithValueField(data);
            }
        },
        addValueFieldEvents: function() {
            this.addEvents({
                'select': function(elements, data) {
                    this.valueField.set('value', this.options.valueFilter.call(this, data));
                },
                'deselect': function(elements) {
                    this.valueField.set('value', '');
                }
            });
        },
        syncWithValueField: function(data) {
            var value = this.getValueFromValueField();
            if (value) {
                this.addParameter(data);
                this.addDataReadyEvent(value);
                this.data.prepare(this.elements.field.node.get('value'));
            } else {
                this.addValueFieldEvents();
            }
        },
        addParameter: function(data) {
            this.parameter = {
                name: this.options.syncName,
                value: function() {
                    return this.valueField.value;
                }.bind(this)
            };
            if (this.data.url) {
                this.data.url.addParameter(this.parameter);
            }
        },
        addDataReadyEvent: function(value) {
            var self = this;
            var runOnce = function() {
                var values = this.get();
                for (var i = values.length; i--;) {
                    if (self.options.valueFilter.call(self, values[i]) === value) {
                        self.elements.field.node.set('value', self.filters.formatMatch.call(self, '', values[i], 0));
                    }
                }
                if (this.url) {
                    this.url.removeParameter(self.parameter);
                }
                self.addValueFieldEvents();
                this.removeEvent('ready', runOnce);
            };
            this.data.addEvent('ready', runOnce);
        },
        getValueFromValueField: function() {
            return this.valueField.get('value');
        }
    });
    Meio.Autocomplete.Select.One = new Class({
        Extends: Meio.Autocomplete.Select,
        options: {
            filter: {
                path: 'text'
            }
        },
        initialize: function(select, options, listInstance) {
            this.select = $(select);
            this.replaceSelect();
            this.parent(this.field, this.createDataArray(), Object.merge(options || {}, {
                valueField: this.select,
                valueFilter: function(data) {
                    return data.value;
                }
            }), listInstance);
        },
        replaceSelect: function() {
            var selectedOption = this.select.getSelected()[0];
            this.field = new Element('input', {
                type: 'text'
            });
            var optionValue = selectedOption.get('value');
            if (optionValue || optionValue === 0) {
                this.field.set('value', selectedOption.get('html'));
            }
            this.select.setStyle('display', 'none');
            this.field.inject(this.select, 'after');
        },
        createDataArray: function() {
            var selectOptions = this.select.options,
                data = [];
            for (var i = 0, selectOption, optionValue; selectOption = selectOptions[i++];) {
                optionValue = selectOption.value;
                if (optionValue || optionValue === 0) {
                    data.push({
                        value: optionValue,
                        text: selectOption.innerHTML
                    });
                }
            }
            return data;
        },
        addValueFieldEvents: function() {
            this.addEvents({
                'select': function(elements, data, text, index) {
                    var option = this.valueField.getElement('option[value="' +
                        this.options.valueFilter.call(this, data) + '"]');
                    if (option) {
                        option.selected = true;
                    }
                },
                'deselect': function(elements) {
                    var option = this.valueField.getSelected()[0];
                    if (option) {
                        option.selected = false;
                    }
                }
            });
        },
        getValueFromValueField: function() {
            return this.valueField.getSelected()[0].get('value');
        }
    });
    Meio.Element = new Class({
        Implements: [Events],
        initialize: function(node) {
            this.setNode(node);
            this.createBoundEvents();
            this.attach();
        },
        setNode: function(node) {
            this.node = node ? $(node) || $$(node)[0] : this.render();
        },
        createBoundEvents: function() {
            this.bound = {};
            this.boundEvents.each(function(evt) {
                this.bound[evt] = function(e) {
                    this.fireEvent('before' + evt.capitalize(), e);
                    this[evt] && this[evt](e);
                    this.fireEvent(evt, e);
                    return true;
                }.bind(this);
            }, this);
        },
        attach: function() {
            for (var e in this.bound) {
                if (this.node) {
                    this.node.addEvent(e, this.bound[e]);
                }
            }
        },
        detach: function() {
            for (var e in this.bound) {
                if (this.node) {
                    this.node.removeEvent(e, this.bound[e]);
                }
            }
        },
        addClass: function(type) {
            if (this.node) {
                this.node.addClass(this.options.classes[type]);
            }
        },
        removeClass: function(type) {
            if (this.node) {
                this.node.removeClass(this.options.classes[type]);
            }
        },
        toElement: function() {
            this.node;
        },
        render: function() {}
    });
    Meio.Element.Field = new Class({
        Extends: Meio.Element,
        Implements: [Options],
        options: {
            classes: {
                loading: 'ma-loading',
                selected: 'ma-selected'
            }
        },
        initialize: function(field, options) {
            this.keyPressControl = {};
            this.boundEvents = ['paste', 'focus', 'blur', 'click', 'keyup', 'keyrepeat'];
            this.setOptions(options);
            this.parent(field);
            $(global).addEvent('unload', function() {
                if (this.node) {
                    this.node.set('autocomplete', 'on');
                }
            }.bind(this));
        },
        setNode: function(element) {
            this.parent(element);
            if (this.node) {
                this.node.set('autocomplete', 'off');
            }
        },
        keyrepeat: function(e) {
            clearInterval(this.keyrepeatTimer);
            this.keyrepeatTimer = this._keyrepeat.delay(1, this, e);
        },
        _keyrepeat: function(e) {
            this.fireEvent('delayedKeyrepeat', e);
        },
        destroy: function() {
            this.detach();
            this.node.removeAttribute('autocomplete');
        }
    });
    Meio.Element.List = new Class({
        Extends: Meio.Element,
        Implements: [Options],
        options: {
            width: 'field',
            classes: {
                container: 'zone_autocompletion',
                hover: 'li-hover',
                odd: '',
                even: '',
                newcategorie: 'new-categorie',
                focus: 'li-hover',
                categorie: 'categorie',
                newcategorie2: 'new-categorie2'
            }
        },
        initialize: function(input, options) {
            this.boundEvents = ['mousedown', 'mouseover', 'keydown'];
            this.setOptions(options);
            this.parent();
            this.focusedItem = null;
            this.input = input;
            this.list.set('id', input + '-list');
        },
        applyMaxHeight: function(maxVisibleItems) {
            var listChildren = this.list.childNodes;
            var node = listChildren[maxVisibleItems - 1] || (listChildren.length ? listChildren[listChildren.length - 1] : null);
            if (!node) {
                return;
            }
            node = $(node);
            var maxWidth = 0;
            for (var k = 0; k < listChildren.length; k++) {
                var newElementVar = new Element('span', {
                    'id': 'id_name',
                    'class': 'new-categorie',
                    'text': listChildren[k].title,
                    styles: {
                        visibility: 'hidden'
                    }
                });
                document.body.appendChild(newElementVar);
                if (newElementVar.offsetWidth > maxWidth) {
                    maxWidth = newElementVar.offsetWidth;
                }
                document.body.removeChild(newElementVar);
            }
            var height = node.getCoordinates(this.list).bottom;
            var width = maxWidth + 30;
            this.node.setStyle('height', height);
            this.node.setStyle('width', width);
            var child = this.node.getChildren()[0];
            if (child !== null) {
                child.setStyle('height', height);
                child.setStyle('width', width);
            }
        },
        mouseover: function(e) {
            var item = this.getItemFromEvent(e),
                hoverClass = this.options.classes.focus;
            if (!item) {
                return true;
            }
            if (this.focusedkeyItem) {
                this.focusedkeyItem.removeClass(hoverClass);
            }
            item.addClass(hoverClass);
            this.focusedkeyItem = item;
        },
        mousedown: function(e) {
            e.preventDefault();
            this.shouldNotBlur = true;
            if (!(this.focusedItem = this.getItemFromEvent(e))) {
                e.dontHide = true;
                return true;
            }
            this.focusedItem.removeClass(this.options.classes.hover);
        },
        focusItem: function(direction) {
            var hoverClass = this.options.classes.hover,
                newFocusedItem;
            if (this.focusedItem) {
                if ((newFocusedItem = this.focusedItem[direction === 'up' ? 'getPrevious' : 'getNext']())) {
                    this.focusedItem.removeClass(hoverClass);
                    newFocusedItem.addClass(hoverClass);
                    this.focusedItem = newFocusedItem;
                    this.scrollFocusedItem(direction);
                    newFocusedItem.focus();
                }
            } else {
                if ((newFocusedItem = this.list.getFirst())) {
                    newFocusedItem.addClass(hoverClass);
                    this.focusedItem = newFocusedItem;
                    newFocusedItem.focus();
                }
            }
        },
        scrollFocusedItem: function(direction) {
            var focusedItemCoordinates = this.focusedItem.getCoordinates(this.list);
            scrollTop = this.node.scrollTop;
            if (direction === 'down') {
                var delta = focusedItemCoordinates.bottom - this.node.getStyle('height').toInt();
                if ((delta - scrollTop) > 0) {
                    this.node.scrollTop = delta;
                }
            } else {
                var top = focusedItemCoordinates.top;
                if (scrollTop && (scrollTop > top)) {
                    this.node.scrollTop = top;
                }
            }
        },
        getItemFromEvent: function(e) {
            var target = e.target;
            while (target && (target.tagName.toLowerCase() !== 'li')) {
                if (target === this.node) {
                    return null;
                }
                target = target.parentNode;
            }
            return $(target);
        },
        render: function() {
            var node = new Element('span', {
                'class': this.options.classes.container
            });
            this.list = new Element('ul', {
                'role': 'listbox',
                'aria-hidden': 'true'
            }).inject(node);
            $(document.body).grab(node);
            return node;
        },
        positionNextTo: function(fieldNode) {
            var width = this.options.width,
                listNode = this.node;
            var elPosition = fieldNode.getCoordinates();
            listNode.setStyle('width', width === 'field' ? fieldNode.getWidth().toInt() -
                listNode.getStyle('border-left-width').toInt() -
                listNode.getStyle('border-right-width').toInt() : width);
            listNode.setPosition({
                x: elPosition.left,
                y: elPosition.bottom
            });
        },
        show: function() {
            $(this.input).set('aria-expanded', 'true');
            this.node.scrollTop = 0;
            this.node.setStyle('visibility', 'visible');
            var child = this.node.getChildren()[0];
            if (child !== null) {
                child.scrollTop = 0;
                child.set('aria-hidden', 'false');
                child.setStyle('visibility', 'visible');
            }
            this.showing = true;
        },
        hide: function() {
            $(this.input).set('aria-expanded', 'false');
            this.showing = false;
            this.node.setStyle('visibility', 'hidden');
            var child = this.node.getChildren()[0];
            if (child !== null) {
                child.set('aria-hidden', 'true');
                child.setStyle('visibility', 'hidden');
            }
        }
    });
    Meio.Autocomplete.Filter = {
        filters: {},
        get: function(options) {
            var type = options.type,
                keys = (options.path || '').split('.');
            var filters = (type && this.filters[type]) ? this.filters[type](this, keys) : options;
            return Object.merge(this.defaults(keys), filters);
        },
        define: function(name, options) {
            this.filters[name] = options;
        },
        defaults: function(keys) {
            var self = this;
            return {
                filter: function(text, data) {
                    if (!text) {
                        return true;
                    }
                    var bool = self._getValueFromKeys(data, keys).test(new RegExp(text.escapeRegExp(), 'i'));
                    return bool;
                },
                filter: function(text, data, key) {
                    if (!text) {
                        return true;
                    }
                    return self._getValueFromKeys(data, key).test(new RegExp(text.escapeRegExp(), 'i'));
                },
                formatMatch: function(text, data) {
                    return self._getValueFromKeys(data, keys);
                },
                formatItem: function(text, data, i) {
                    return text ? self._getValueFromKeys(data, keys).replace(new RegExp('(' + text.escapeRegExp() + ')', 'gi'), '<strong>$1</strong>') : self._getValueFromKeys(data, keys);
                }
            };
        },
        _getValueFromKeys: function(obj, keys) {
            var key, value = obj;
            for (var i = 0; key = keys[i++];) {
                value = value[key];
            }
            return value;
        }
    };
    Meio.Autocomplete.Filter.define('contains', function(self, keys) {
        return {};
    });
    Meio.Autocomplete.Filter.define('startswith', function(self, keys) {
        return {
            filter: function(text, data) {
                return text ? self._getValueFromKeys(data, keys).test(new RegExp('^' + text.escapeRegExp(), 'i')) : true;
            }
        };
    });
    Meio.Autocomplete.Data = new Class({
        Implements: [Options, Events],
        initialize: function(data, cache) {
            this._cache = cache;
            this.data = data;
            this.dataString = JSON.encode(this.data);
        },
        get: function() {
            return this.data;
        },
        getKey: function() {
            return this.cachedKey;
        },
        prepare: function(text) {
            this.cachedKey = this.dataString + (text || '');
            this.fireEvent('ready');
        },
        cache: function(key, data) {
            this._cache.set(key, data);
        },
        refreshKey: function() {}
    });
    Meio.Autocomplete.Data.Request = new Class({
        Extends: Meio.Autocomplete.Data,
        options: {
            noCache: true,
            formatResponse: function(jsonResponse) {
                return jsonResponse;
            }
        },
        initialize: function(url, cache, element, options, urlOptions) {
            this.setOptions(options);
            this.rawUrl = url;
            this._cache = cache;
            this.element = element;
            this.urlOptions = urlOptions;
            this.refreshKey();
            this.createRequest();
        },
        prepare: function(text) {
            this.cachedKey = this.url.evaluate(text);
            if (this._cache.has(this.cachedKey)) {
                this.fireEvent('ready');
            } else {
                this.request.send({
                    url: this.cachedKey
                });
            }
        },
        createRequest: function() {
            var self = this;
            this.request = new Request.JSON(this.options);
            this.request.addEvents({
                request: function() {
                    self.element.addClass('loading');
                },
                complete: function() {
                    self.element.removeClass('loading');
                },
                success: function(jsonResponse) {
                    self.data = self.options.formatResponse(jsonResponse);
                    self.fireEvent('ready');
                }
            });
        },
        refreshKey: function(urlOptions) {
            urlOptions = Object.merge(this.urlOptions, {
                url: this.rawUrl
            }, urlOptions || {});
            this.url = new Meio.Autocomplete.Data.Request.URL(urlOptions.url, urlOptions);
        }
    });
    Meio.Autocomplete.Data.Request.URL = new Class({
        Implements: [Options],
        options: {
            queryVarName: 'q',
            extraParams: null,
            max: 20
        },
        initialize: function(url, options) {
            this.setOptions(options);
            this.rawUrl = url;
            this.url = url;
            this.url += this.url.contains('?') ? '&' : '?';
            this.dynamicExtraParams = [];
            var params = Array.from(this.options.extraParams);
            for (var i = params.length; i--;) {
                this.addParameter(params[i]);
            }
            if (this.options.max) {
                this.addParameter('limit=' + this.options.max);
            }
        },
        evaluate: function(text) {
            text = text || '';
            var params = this.dynamicExtraParams,
                url = [];
            url.push(this.options.queryVarName + '=' + encodeURIComponent(text));
            for (var i = params.length; i--;) {
                url.push(encodeURIComponent(params[i].name) + '=' + encodeURIComponent($lambda(params[i].value)()));
            }
            return this.url + url.join('&');
        },
        addParameter: function(param) {
            if (isFinite(param.nodeType) || (typeOf(param.value) === 'function')) {
                this.dynamicExtraParams.push(param);
            } else {
                this.url += ((typeOf(param) === 'string') ? param : encodeURIComponent(param.name) + '=' +
                    encodeURIComponent(param.value)) + '&';
            }
        },
        removeParameter: function(param) {
            this.dynamicExtraParams.erase(param);
        }
    });
    Meio.Autocomplete.Cache = new Class({
        initialize: function(maxLength) {
            this.refresh();
            this.setMaxLength(maxLength);
        },
        set: function(key, value) {
            if (!this.cache[key]) {
                if (this.getLength() >= this.maxLength) {
                    var keyToRemove = this.pos.shift();
                    this.cache[keyToRemove] = null;
                    delete this.cache[keyToRemove];
                }
                this.cache[key] = value;
                this.pos.push(key);
            }
            return this;
        },
        get: function(key) {
            return this.cache[key || ''] || null;
        },
        has: function(key) {
            return !!this.get(key);
        },
        getLength: function() {
            return this.pos.length;
        },
        refresh: function() {
            this.cache = {};
            this.pos = [];
        },
        setMaxLength: function(maxLength) {
            this.maxLength = Math.max(maxLength, 1);
        }
    });
    globalCache = new Meio.Autocomplete.Cache();
    if (global.Meio != undefined && global.Meio != null) {
        Object.append(global.Meio, Meio);
    } else {
        global.Meio = Meio;
    }
})(this, document.id || $);
var BlocPliableTag = {
    accordeon: '.accordeon',
    bloc: '.bpliable',
    header: '.bpliable-header',
    content: '.bpliable-body',
    duration: 500,
    waitMessage: '<p>Chargement en cours\u2026</p>',
    errorMessage: 'Erreur lors du chargement des données',
    openTransition: function(bpBody) {
        return new Fx.Tween(bpBody, {
            duration: this.duration,
            transition: Fx.Transitions.Quad.easeInOut,
            property: 'height',
            onComplete: function() {
                bpBody.setStyle('height', 'auto');
                bpBody.setStyle('overflow', 'visible');
            }
        });
    },
    closeTransition: function(bpBody) {
        return new Fx.Tween(bpBody, {
            duration: this.duration,
            transition: Fx.Transitions.Quad.easeInOut,
            property: 'height',
            onComplete: function() {
                bpBody.set('aria-hidden', 'true');
                bpBody.setStyle('height', 'auto');
                bpBody.setStyle('overflow', 'visible');
            }
        });
    },
    accordeonne: function(accordeonElement) {
        var accordeon = accordeonElement.getParent(this.accordeon);
        accordeon.getElements(this.bloc).each(function(item) {
            if (item.getElement(BlocPliableTag.header).get('aria-expanded') === 'true') {
                BlocPliableTag.close(item);
            }
        });
    },
    isAccordeonElement: function(object) {
        return object.getParent(this.accordeon) === null ? false : true;
    },
    open: function(blocPliable) {
        var bpHeader = blocPliable.getElement(BlocPliableTag.header);
        var bpBody = blocPliable.getElement(this.content);
        bpHeader.set('aria-expanded', 'true');
        bpBody.setStyle('overflow', 'hidden');
        this.openTransition(bpBody).start("0", bpBody.getDimensions().y);
        (function() {
            this.set('aria-hidden', 'false');
        }).delay(50, bpBody);
    },
    close: function(blocPliable) {
        var bpHeader = blocPliable.getElement(BlocPliableTag.header);
        var bpBody = blocPliable.getElement(this.content);
        bpHeader.set('aria-expanded', 'false');
        bpBody.setStyle('overflow', 'hidden');
        this.closeTransition(bpBody).start(bpBody.getSize().y, "0");
    },
    toggle: function(blocPliable) {
        var bpHeader = blocPliable.getElement(BlocPliableTag.header);
        if (bpHeader.get('aria-expanded') === 'false') {
            if (this.isAccordeonElement(blocPliable)) {
                this.accordeonne(blocPliable);
            }
            this.open(blocPliable);
        } else {
            this.close(blocPliable);
        }
    },
    findNext: function(blocPliable) {
        var blocs = blocPliable.getParent(this.accordeon).getElements(this.bloc);
        for (var i = 1; i < blocs.length; i++) {
            if (blocs[i - 1] === blocPliable) {
                return blocs[i].getElement(BlocPliableTag.header);
            }
        }
        if (blocs.length > 0) {
            return blocs[0].getElement(BlocPliableTag.header);
        }
    },
    findPrevious: function(blocPliable) {
        var blocs = blocPliable.getParent(this.accordeon).getElements(this.bloc);
        for (var i = 0; i < blocs.length - 1; i++) {
            if (blocs[i + 1] === blocPliable) {
                return blocs[i].getElement(BlocPliableTag.header);
            }
        }
        if (blocs.length > 0) {
            return blocs[blocs.length - 1].getElement(BlocPliableTag.header);
        }
    },
    loadContent: function(blocPliable, url) {
        var contentContainer = blocPliable.getElement(this.content);
        contentContainer.set('aria-busy', true);
        contentContainer.set('html', BlocPliableTag.waitMessage);
        contentContainer.set('load', {
            method: 'get',
            async: true,
            onFailure: function() {
                contentContainer.set('text', BlocPliableTag.errorMessage);
            },
            onError: function() {
                contentContainer.set('text', BlocPliableTag.errorMessage);
            },
            onSuccess: function() {
                blocPliable.set('data-loaded', true);
            }
        });
        contentContainer.load(url);
        contentContainer.set('aria-busy', false);
    },
    initEvents: function(blocPliableId) {
        $(blocPliableId).getElement(BlocPliableTag.header).addEvents({
            keydown: function(event) {
                switch (event.key) {
                    case 'space':
                    case 'enter':
                        BlocPliableTag.toggle($(blocPliableId));
                        break;
                    case 'left':
                    case 'up':
                        if (BlocPliableTag.isAccordeonElement($(blocPliableId))) {
                            event.preventDefault();
                            BlocPliableTag.findPrevious($(blocPliableId)).focus();
                        }
                        break;
                    case 'right':
                    case 'down':
                        if (BlocPliableTag.isAccordeonElement($(blocPliableId))) {
                            event.preventDefault();
                            BlocPliableTag.findNext($(blocPliableId)).focus();
                        }
                        break;
                    default:
                        break;
                }
            }
        });
        $(blocPliableId).getElement(this.content).addEvent('keydown', function(event) {
            if (event.control && event.key === "up") {
                $(blocPliableId).getElement(BlocPliableTag.header).focus();
            }
        });
    },
    handleClick: function(event) {
        event.stop();
        BlocPliableTag.toggle($(blocPliableId));
    },
    initLocal: function(blocPliableId) {
        BlocPliableTag.initEvents(blocPliableId);
        $(blocPliableId).getElement(BlocPliableTag.header).addEvents({
            click: function(event) {
                event.stop();
                BlocPliableTag.toggle($(blocPliableId));
            }
        });
    },
    initAjax: function(blocPliableId, urlToLoad, cacheForAjax) {
        var blocPliable = $(blocPliableId);
        BlocPliableTag.duration = 0;
        BlocPliableTag.initEvents(blocPliableId);
        blocPliable.getElement(BlocPliableTag.header).addEvents({
            click: function(event) {
                event.stop();
                var bpHeader = blocPliable.getElement(BlocPliableTag.header);
                if (bpHeader.get('aria-expanded') === 'false') {
                    if (BlocPliableTag.isAccordeonElement(blocPliable)) {
                        BlocPliableTag.accordeonne(blocPliable);
                    }
                    if (!blocPliable.get('data-loaded') || cacheForAjax === false) {
                        BlocPliableTag.loadContent(blocPliable, urlToLoad);
                    }
                    BlocPliableTag.open(blocPliable);
                } else {
                    BlocPliableTag.close(blocPliable);
                }
            }
        });
    }
};
﻿
var DatePicker = new Class({
    Implements: [Options, Events],
    today: '',
    choice: {},
    minDate: null,
    maxDate: null,
    dateSelection: null,
    dateFocus: null,
    targetSelection: null,
    options: {
        pickerClass: 'datepicker',
        dayShort: 3,
        monthShort: 3,
        startDay: 1,
        yearPicker: true,
        allowEmpty: true,
        linkTitle: '',
        animationDuration: 400,
        useFadeInOut: !Browser.ie,
        positionOffset: {
            x: 0,
            y: 0
        },
        timeWheelStep: 1
    },
    initialize: function(attachTo, options) {
        Locale.use('fr-FR');
        this.setOptions({
            days: Locale.get('Date.days'),
            months: Locale.get('Date.months'),
            format: Locale.get('Date.shortDate')
        });
        var defaultFormat = this.options.format;
        this.setOptions(options);
        this.inputId = attachTo;
        var ico = new Element('a', {
            'id': attachTo + '_calendrier',
            'class': 'calendrier',
            'tabindex': '-1',
            'title': this.options.linkTitle
        });
        if ($(this.inputId).get('disabled')) {
            ico.addClass('cal-inactif');
        }
        ico.inject($(this.inputId), 'after');
        this.attach(attachTo, this.options.toggle);
        document.addEvent('mousedown', function(event) {
            if (!(this.elems && this.elems.contains(event.target)) && this.picker && (event.target !== this.picker) && !(this.picker.contains(event.target) && (event.target !== this.picker))) {
                this.close.call(this);
            }
        }.bind(this));
    },
    attach: function(attachTo, toggle) {
        if (!attachTo) {
            return this;
        }
        if (toggle) {
            var togglers = typeOf(toggle) === 'array' ? toggle : [document.id(toggle)];
        }
        var elemsType = typeOf(attachTo);
        this.elems = (elemsType === 'array' || elemsType === 'elements') ? attachTo : [document.id(attachTo)];
        var elems = this.elems;
        elems.each(function(item, index) {
            if (item.retrieve('datepicker')) {
                return;
            }
            item.store('datepicker', true);
            var events;
            if (toggle && togglers) {
                var self = this;
                events = {
                    click: function(e) {
                        if (e) {
                            e.stop();
                        }
                        if (!$(self.inputId).get('disabled')) {
                            self.destroy();
                            self.show(item, togglers[index]);
                        }
                    },
                    keydown: function(e) {
                        if (e.key === 'down') {
                            self.destroy();
                            self.show(item, togglers[index]);
                        }
                    }
                };
                var toggler = togglers[index].addEvents(events);
                item.store('datepicker:toggler', toggler).store('datepicker:events', events);
                var eventsInput = {
                    click: function(e) {
                        if (e) {
                            e.stop();
                        }
                        if (!$(self.inputId).get('disabled')) {
                            self.destroy();
                            self.show(item, togglers[index], true);
                        }
                    },
                    keydown: function(e) {
                        switch (e.key) {
                            case 'down':
                                e.stop();
                                self.destroy();
                                self.show(item, togglers[index]);
                                break;
                            case 'tab':
                                self.destroy();
                                break;
                            case 'esc':
                                if (self.picker) {
                                    e.stop();
                                }
                                self.destroy();
                                break;
                            default:
                                break;
                        }
                    }
                };
                item.addEvents(eventsInput);
            } else {
                events = {
                    keydown: function(e) {
                        if (this.options.allowEmpty && (e.key === 'delete' || e.key === 'backspace')) {
                            item.set('value', '');
                            this.close();
                        } else if (e.key === 'tab') {
                            this.close();
                        } else {
                            e.stop();
                        }
                    }.bind(this),
                    focus: this.show.pass(item, this),
                    click: this.show.pass(item, this)
                };
                item.addEvents(events).store('datepicker:events', events);
            }
        }.bind(this));
        return this;
    },
    detach: function(detach) {
        var elems = typeOf(detach) === 'array' ? detach : [document.id(detach)];
        elems.each(function(item) {
            if (!item.retrieve('datepicker')) {
                return;
            }
            var toggler = item.retrieve('datepicker:toggler');
            var events = item.retrieve('datepicker:events');
            (toggler || item).removeEvents(events);
        });
        return this;
    },
    isDateExists: function(dateEnTableau) {
        var isDateExists = false;
        var jour = parseFloat(dateEnTableau[0]);
        var mois = parseFloat(dateEnTableau[1]);
        var annee = parseFloat(dateEnTableau[2]);
        unedate = new Date(eval(annee), eval(mois) - 1, eval(jour));
        if ((unedate.getDate() === eval(jour)) && (unedate.getMonth() === eval(mois) - 1) && (annee === eval(annee))) {
            isDateExists = true;
        }
        return isDateExists;
    },
    controleFormat: function(date) {
        var dateTableau = date.split('/');
        if (dateTableau.length === 3) {
            if ((!isNaN(dateTableau[0])) && (!isNaN(dateTableau[1])) && (!isNaN(dateTableau[2]))) {
                return this.isDateExists(dateTableau);
            }
        }
        return false;
    },
    show: function(input, toggler, withoutFocus) {
        input = document.id(input);
        if (!input.retrieve('datepicker')) {
            return;
        }
        this.d = input.get('value');
        if (!this.d) {
            this.d = new Date().clearTime();
        } else if (!(this.d instanceof Date)) {
            if (this.controleFormat(this.d)) {
                this.d = Date.parse(this.d);
            } else {
                this.d = new Date().clearTime();
            }
        }
        if (!this.d.isValid()) {
            this.d = new Date().clearTime();
        }
        this.input = input;
        this.minDate = this.getDateFromInputAttr('data-mindate');
        this.maxDate = this.getDateFromInputAttr('data-maxdate');
        if ((this.minDate && this.maxDate) && (this.minDate > this.maxDate)) {
            this.minDate = null;
            this.maxDate = null;
        }
        if (this.isDateOutOfRange(this.d)) {
            if (this.minDate !== null && this.d < this.minDate) {
                this.d = this.minDate.clone();
            } else if (this.maxDate !== null && this.d > this.maxDate) {
                this.d = this.maxDate.clone();
            }
        }
        var inputCoords = (document.id(toggler) || input).getCoordinates();
        var position = {
            left: inputCoords.left + this.options.positionOffset.x,
            top: inputCoords.top + inputCoords.height + this.options.positionOffset.y
        };
        this.fireEvent('show');
        this.today = new Date().clearTime();
        this.choice = this.d.toObject();
        this.render();
        this.position({
            x: position.left,
            y: position.top
        });
        if (this.dateSelection && !withoutFocus) {
            this.selectCurrentElement(this.dateSelection);
        }
        if (Browser.ie) {
            this.shim();
        }
        return this;
    },
    close: function(e, force) {
        $(this.inputId).focus();
        if (!document.id(this.picker)) {
            return;
        }
        if (this.options.useFadeInOut) {
            this.picker.set('tween', {
                duration: this.options.animationDuration / 2,
                onComplete: this.destroy.bind(this)
            }).tween('opacity', 1, 0);
        } else {
            this.destroy();
        }
        return this;
    },
    shim: function() {
        var coords = this.picker.setStyle('zIndex', 1000).getCoordinates();
        this.frame = new Element('iframe', {
            src: 'javascript:false;document.write("");',
            styles: {
                position: 'absolute',
                zIndex: 999,
                height: coords.height,
                width: coords.width,
                left: coords.left,
                top: coords.top
            }
        }).inject(document.body);
        var frame = this.frame;
        if (this.frame.style !== null) {
            this.frame.style.filter = 'progid:DXImageTransform.Microsoft.Alpha(style=0,opacity=0)';
        }
        frame.destroy();
        if (this.dragger) {
            this.dragger.addEvent('drag', function() {
                var coords = this.picker.getCoordinates();
                frame.setStyles({
                    left: coords.left,
                    top: coords.top
                });
            }.bind(this));
        }
    },
    position: function(position) {
        var size = window.getSize(),
            scroll = window.getScroll(),
            pickerSize = this.picker.getSize(),
            max_y = (size.y + scroll.y) - pickerSize.y,
            max_x = (size.x + scroll.x) - pickerSize.x,
            inputCoords = this.input.getCoordinates();
        if (position.x > max_x) {
            position.x = inputCoords.right - this.options.positionOffset.x - pickerSize.x;
        }
        if (position.y > max_y) {
            position.y = inputCoords.top - this.options.positionOffset.y - pickerSize.y;
        }
        this.picker.setStyles({
            left: position.x,
            top: position.y
        });
    },
    render: function(fx) {
        var firstTime = true;
        if (!this.picker) {
            this.constructPicker();
        } else {
            var old = this.oldContents;
            this.oldContents = this.newContents;
            this.newContents = old;
            this.newContents.empty();
            firstTime = false;
        }
        var startDate = new Date(this.d.getTime());
        this.renderMonth();
        this.d = startDate;
        if (this.picker.getStyle('opacity') === 0) {
            this.picker.tween('opacity', 0, 1);
        }
        if (fx) {
            this.fx(fx);
        }
        if (!firstTime && this.dateSelection) {
            this.selectCurrentElement.delay(this.options.animationDuration, this, this.dateSelection);
        }
        this.initKeyEvents();
    },
    initKeyEvents: function() {
        this.picker.removeEvent('keydown', this.keyEvt);
        this.picker.addEvent('keydown', this.keyEvt = function(evt) {
            switch (evt.key) {
                case 'tab':
                    evt.stop();
                    this.initFocusableElements();
                    if (evt.shift) {
                        this.findPreviousTab(document.activeElement).focus();
                    } else {
                        this.findNextTab(document.activeElement).focus();
                    }
                    break;
                case 'right':
                    evt.stop();
                    this.goToNextDay();
                    break;
                case 'left':
                    evt.stop();
                    this.goToPreviousDay();
                    break;
                case 'up':
                    evt.stop();
                    this.goToPreviousWeek();
                    break;
                case 'down':
                    evt.stop();
                    this.goToNextWeek();
                    break;
                case 'esc':
                    evt.stop();
                    this.close();
                    break;
                case 'space':
                    if (this.getCurrentElement() === document.activeElement) {
                        this.getCurrentElement().fireEvent('click');
                    }
                    break;
                case 'enter':
                    evt.preventDefault();
                    document.activeElement.fireEvent('click');
                    break;
                case 'pageup':
                    evt.stop();
                    if (evt.control) {
                        this.goToPreviousYear();
                    } else {
                        this.goToPreviousMonth();
                    }
                    break;
                case 'pagedown':
                    evt.stop();
                    if (evt.control) {
                        this.goToNextYear();
                    } else {
                        this.goToNextMonth();
                    }
                    break;
                default:
                    break;
            }
        }.bind(this));
        this.days = this.newContents.getElements('.week td.day:not(.semaine, .unavailable)');
    },
    initFocusableElements: function() {
        this.picker.focusableElements = this.picker.getElements('a:not([aria-disabled=true]), td[tabindex]:not([tabindex^="-"])');
    },
    goToNextDay: function() {
        var currentElement = this.getCurrentElement();
        if (currentElement) {
            var posCurrentElement = this.days.indexOf(currentElement);
            if (posCurrentElement < this.days.length - 1) {
                this.deselectCurrentElement();
                this.selectCurrentElement(this.days[posCurrentElement + 1]);
            } else {
                if (!this.isDateOutOfRange(this.firstDateOfNextMonth())) {
                    this.deselectCurrentElement();
                    this.targetSelection = this.firstDateOfNextMonth();
                    this.next();
                }
            }
        } else {
            this.selectCurrentElement(this.days[0]);
        }
    },
    goToPreviousDay: function() {
        var currentElement = this.getCurrentElement();
        if (currentElement) {
            var posCurrentElement = this.days.indexOf(currentElement);
            if (posCurrentElement > 0) {
                this.deselectCurrentElement();
                this.selectCurrentElement(this.days[posCurrentElement - 1]);
            } else {
                if (!this.isDateOutOfRange(this.lastDateOfPreviousMonth())) {
                    this.deselectCurrentElement();
                    this.targetSelection = this.lastDateOfPreviousMonth();
                    this.previous();
                }
            }
        } else {
            this.selectCurrentElement(this.days[this.days.length - 1]);
        }
    },
    goToPreviousWeek: function() {
        var currentElement = this.getCurrentElement();
        if (currentElement) {
            var posCurrentElement = this.days.indexOf(currentElement);
            if (posCurrentElement - 7 >= 0) {
                this.deselectCurrentElement();
                this.selectCurrentElement(this.days[posCurrentElement - 7]);
            } else {
                if (!this.isDateOutOfRange(this.lastDateOfPreviousMonth())) {
                    this.deselectCurrentElement();
                    if (this.isDateOutOfRange(this.dateFocus.decrement('day', 7))) {
                        this.dateFocus = this.minDate.clone();
                    }
                    this.targetSelection = this.dateFocus;
                    this.previous();
                }
            }
        } else {
            this.selectCurrentElement(this.days[this.days.length - 1]);
        }
    },
    goToNextWeek: function() {
        var currentElement = this.getCurrentElement();
        if (currentElement) {
            var posCurrentElement = this.days.indexOf(currentElement);
            if (posCurrentElement + 7 < this.days.length) {
                this.deselectCurrentElement();
                this.selectCurrentElement(this.days[posCurrentElement + 7]);
            } else {
                if (!this.isDateOutOfRange(this.firstDateOfNextMonth())) {
                    this.deselectCurrentElement();
                    if (this.isDateOutOfRange(this.dateFocus.increment('day', 7))) {
                        this.dateFocus = this.maxDate.clone();
                    }
                    this.targetSelection = this.dateFocus;
                    this.next();
                }
            }
        } else {
            this.selectCurrentElement(this.days[0]);
        }
    },
    goToPreviousMonth: function() {
        if (!this.isDateOutOfRange(this.lastDateOfPreviousMonth())) {
            var currentElement = this.getCurrentElement();
            if (currentElement && this.dateFocus !== null) {
                if (this.isDateOutOfRange(this.dateFocus.decrement('month', 1))) {
                    this.dateFocus = this.minDate.clone();
                }
                this.targetSelection = this.dateFocus;
                this.previous();
            } else {
                this.previous();
            }
        }
    },
    goToNextMonth: function() {
        if (!this.isDateOutOfRange(this.firstDateOfNextMonth())) {
            var currentElement = this.getCurrentElement();
            if (currentElement && this.dateFocus !== null) {
                if (this.isDateOutOfRange(this.dateFocus.increment('month', 1))) {
                    this.dateFocus = this.maxDate.clone();
                }
                this.targetSelection = this.dateFocus;
                this.next();
            } else {
                this.next();
            }
        }
    },
    goToPreviousYear: function() {
        if (!this.isDateOutOfRange(this.previousYearDate())) {
            var currentElement = this.getCurrentElement();
            if (currentElement && this.dateFocus !== null) {
                this.targetSelection = this.dateFocus.decrement('year', 1);
                this.previousYear();
            } else {
                this.previousYear();
            }
        }
    },
    goToNextYear: function() {
        if (!this.isDateOutOfRange(this.nextYearDate())) {
            var currentElement = this.getCurrentElement();
            if (currentElement && this.dateFocus !== null) {
                this.targetSelection = this.dateFocus.increment('year', 1);
                this.nextYear();
            } else {
                this.nextYear();
            }
        }
    },
    getCurrentElement: function() {
        var currentElement = this.newContents.getElement('.current');
        if (!currentElement) {
            currentElement = this.dateSelection;
        }
        if (!currentElement) {
            if (document.activeElement && document.activeElement.hasClass('selected')) {
                currentElement = document.activeElement;
            }
        }
        return currentElement;
    },
    deselectCurrentElement: function() {
        var currentElement = this.newContents.getElement('.current');
        if (currentElement) {
            currentElement.removeClass('current');
            currentElement.set('aria-selected', 'false');
            currentElement.set('tabindex', -1);
        }
        this.dateSelection = null;
    },
    selectCurrentElement: function(element) {
        element.addClass('current');
        element.set('tabindex', 0);
        element.set('aria-selected', 'true');
        element.focus();
        this.dateFocus = Date.fromObject({
            day: element.get('text'),
            month: this.d.getMonth(),
            year: this.d.getFullYear()
        });
    },
    findNextTab: function(element) {
        for (var i = 0; i < this.picker.focusableElements.length - 1; i++) {
            if (this.picker.focusableElements[i] === element) {
                return this.picker.focusableElements[i + 1];
            }
        }
        return this.picker.focusableElements[0];
    },
    findPreviousTab: function(element) {
        for (var i = 1; i < this.picker.focusableElements.length; i++) {
            if (this.picker.focusableElements[i] === element) {
                return this.picker.focusableElements[i - 1];
            }
        }
        return this.picker.focusableElements[this.picker.focusableElements.length - 1];
    },
    fx: function(fx) {
        this.slider.set('tween', {
            unit: 'em'
        });
        if (fx === 'right') {
            this.oldContents.setStyles({
                left: '0em',
                opacity: 1
            });
            this.newContents.setStyles({
                left: '22.6em',
                opacity: 1
            });
            this.slider.setStyle('left', '0em').tween('left', 0, '-22.6em');
        } else if (fx === 'left') {
            this.oldContents.setStyles({
                left: '22.6em',
                opacity: 1
            });
            this.newContents.setStyles({
                left: '0em',
                opacity: 1
            });
            this.slider.setStyle('left', '-22.6em').tween('left', '-22.6em', 0);
        } else if (fx === 'fade') {
            this.slider.setStyle('left', '0em');
            this.oldContents.setStyle('left', '0em').set('tween', {
                duration: this.options.animationDuration / 2
            }).tween('opacity', 1, 0);
            this.newContents.setStyles({
                opacity: 0,
                left: '0em'
            }).set('tween', {
                duration: this.options.animationDuration
            }).tween('opacity', 0, 1);
        }
    },
    constructPicker: function() {
        this.picker = new Element('div', {
            'class': this.options.pickerClass
        }).inject(document.body);
        if (this.options.useFadeInOut) {
            this.picker.setStyle('opacity', 0).set('tween', {
                duration: this.options.animationDuration
            });
        }
        var h = new Element('div').inject(this.picker);
        new Element('a', {
            'class': 'titre_aujourdhui',
            'href': '#'
        }).addEvent('click', this.aujourdhui.bind(this)).inject(h);
        var titreNavigation = new Element('div', {
            'class': 'titre_navigation'
        }).inject(h);
        var navigationMois = new Element('div', {
            'style': 'float: left'
        }).inject(titreNavigation);
        new Element('a', {
            'href': '#myself',
            'class': 'titre_navigation_mois_prec'
        }).addEvent('click', this.goToPreviousMonth.bind(this)).inject(navigationMois);
        new Element('div', {
            'class': 'titre_navigation_mois'
        }).inject(navigationMois);
        new Element('a', {
            'href': '#myself',
            'class': 'titre_navigation_mois_suiv'
        }).addEvent('click', this.goToNextMonth.bind(this)).inject(navigationMois);
        new Element('div', {
            'class': 'clear'
        }).inject(navigationMois);
        var navigationAnnee = new Element('div', {
            'style': 'float: right'
        }).inject(titreNavigation);
        new Element('a', {
            'href': '#myself',
            'class': 'titre_navigation_annee_prec'
        }).addEvent('click', this.goToPreviousYear.bind(this)).inject(navigationAnnee);
        new Element('div', {
            'class': 'titre_navigation_annee'
        }).inject(navigationAnnee);
        new Element('a', {
            'href': '#myself',
            'class': 'titre_navigation_annee_suiv'
        }).addEvent('click', this.goToNextYear.bind(this)).inject(navigationAnnee);
        new Element('div', {
            'class': 'clear'
        }).inject(navigationAnnee);
        var b = new Element('div', {
            'class': 'body'
        }).inject(this.picker);
        this.slider = new Element('div', {
            styles: {
                position: 'absolute',
                top: 0,
                left: 0,
                width: '45.2em',
                height: '15.7em'
            }
        }).set('tween', {
            duration: this.options.animationDuration,
            transition: Fx.Transitions.Quad.easeInOut
        }).inject(b);
        this.oldContents = new Element('div', {
            styles: {
                position: 'absolute',
                top: '0em',
                left: '22.6em',
                width: '22.6em',
                height: '15.7em'
            }
        }).inject(this.slider);
        this.newContents = new Element('div', {
            styles: {
                position: 'absolute',
                top: '0em',
                left: '0em',
                width: '22.6em',
                height: '15.7em'
            }
        }).inject(this.slider);
    },
    getDateFromInputAttr: function(attr) {
        if (this.input.get(attr)) {
            if (this.input.get(attr) === 'today') {
                return new Date().clearTime();
            } else if (this.controleFormat(this.input.get(attr))) {
                return Date.parse(this.input.get(attr));
            }
        }
        return null;
    },
    isDateOutOfRange: function(date) {
        return (this.minDate !== null && date < this.minDate) || (this.maxDate !== null && date > this.maxDate);
    },
    fillCalendarHeader: function() {
        var month = this.d.getMonth();
        var dateDuJour = new Date().toLocaleString();
        if (this.picker.hasClass('dpmetier')) {
            this.picker.getElement('.titre_aujourdhui').set({
                text: 'Aujourd\'hui : ' + dateDuJour.substr(0, dateDuJour.length - 8),
                'aria-disabled': this.isDateOutOfRange(this.today)
            });
        } else {
            this.picker.getElement('.titre_aujourdhui').set({
                title: dateDuJour.substr(0, dateDuJour.length - 8),
                text: 'Aujourd\'hui',
                'aria-disabled': this.isDateOutOfRange(this.today)
            });
        }
        this.picker.getElement('.titre_navigation_mois').set('html', this.options.months[month]);
        this.picker.getElement('.titre_navigation_mois_prec').set({
            title: this.options.months[(month + 11) % 12],
            'aria-disabled': this.isDateOutOfRange(this.lastDateOfPreviousMonth())
        });
        this.picker.getElement('.titre_navigation_mois_suiv').set({
            title: this.options.months[(month + 1) % 12],
            'aria-disabled': this.isDateOutOfRange(this.firstDateOfNextMonth())
        });
        this.picker.getElement('.titre_navigation_annee').set('text', this.d.getFullYear());
        this.picker.getElement('.titre_navigation_annee_prec').set({
            title: this.d.getFullYear() - 1,
            'aria-disabled': this.isDateOutOfRange(this.previousYearDate())
        });
        this.picker.getElement('.titre_navigation_annee_suiv').set({
            title: this.d.getFullYear() + 1,
            'aria-disabled': this.isDateOutOfRange(this.nextYearDate())
        });
    },
    renderMonth: function() {
        var month = this.d.getMonth();
        var year = this.d.getFullYear();
        this.fillCalendarHeader();
        this.d.setDate(1);
        while (this.d.getDay() !== this.options.startDay) {
            this.d.setDate(this.d.getDate() - 1);
        }
        var container = new Element('table', {
            'class': 'days',
            'role': 'grid'
        }).inject(this.newContents);
        var caption = new Element('caption', {
            'class': 'invisible'
        });
        caption.set('html', 'Calendrier ' + this.options.months[month] + ' ' + year);
        caption.inject(container);
        var thead = new Element('thead').inject(container);
        var tbody = new Element('tbody').inject(container);
        var titles = new Element('tr', {
            'class': 'titles'
        }).inject(thead);
        var d, i, classes, e, weekcontainer;
        if (this.picker.hasClass('dpmetier')) {
            new Element('th', {
                'class': 'title day week',
                'title': 'num\u00E9ro de semaine',
                'scope': 'col'
            }).set('text', "Num.").inject(titles);
        }
        for (d = this.options.startDay; d < (this.options.startDay + 7); d++) {
            new Element('th', {
                'class': 'title day day' + (d % 7),
                'scope': 'col'
            }).set('text', this.options.days[(d % 7)].substring(0, 1).toUpperCase() +
                this.options.days[(d % 7)].substring(1, this.options.dayShort).toLowerCase() + ".").inject(titles);
        }
        var t = this.today.toDateString();
        var currentChoice = Date.fromObject(this.choice).toDateString();
        for (i = 0; i < 42; i++) {
            var isCurrent = false;
            classes = [];
            classes.push('day');
            classes.push('day' + this.d.getDay());
            if (this.d.toDateString() == t) {
                classes.push('today');
            }
            if ((this.d.getDay() == 6) || (this.d.getDay() == 0)) {
                classes.push('nonouvrable');
            }
            if (this.d.toDateString() == currentChoice) {
                classes.push('selected');
            }
            if (this.targetSelection && this.d.getTime() === this.targetSelection.getTime()) {
                classes.push('current');
                isCurrent = true;
            }
            var available = true;
            if (this.d.getMonth() !== month || this.isDateOutOfRange(this.d)) {
                classes.push('unavailable');
                available = false;
            }
            if (i % 7 === 0) {
                weekcontainer = new Element('tr', {
                    'class': 'week week' + (Math.floor(i / 7))
                }).inject(tbody);
                var dateSemaine = new Date(this.d.getFullYear(), this.d.getMonth(), this.d.getDate(), 0, 0, 0);
                var DoW = dateSemaine.getDay();
                dateSemaine.setDate(dateSemaine.getDate() - (DoW + 6) % 7 + 3);
                var ms = dateSemaine.valueOf();
                dateSemaine.setMonth(0);
                dateSemaine.setDate(4);
                if (this.picker.hasClass('dpmetier')) {
                    var numSemaine = Math.round((ms - dateSemaine.valueOf()) / (7 * 864e5)) + 1;
                    new Element('th', {
                        'class': 'day semaine',
                        'scope': 'row'
                    }).set('text', numSemaine).inject(weekcontainer);
                }
            }
            var dateDebutAnnee = new Date();
            dateDebutAnnee.setDate(1);
            dateDebutAnnee.setMonth(0);
            dateDebutAnnee.setFullYear(this.d.getFullYear());
            var title = this.d.format(this.options.format);
            if (this.picker.hasClass('dpmetier')) {
                var quantieme = (((this.d.getTime()) - (dateDebutAnnee.getTime())) / (24 * 3600 * 1000)).ceil() + 1;
                e = new Element('td', {
                    'class': classes.join(' '),
                    'role': 'gridcell',
                    'aria-selected': 'false'
                }).set('text', this.d.getDate()).inject(weekcontainer);
                title += ' Quanti\u00E8me ' + quantieme;
            } else {
                e = new Element('td', {
                    'class': classes.join(' '),
                    'role': 'gridcell',
                    'aria-selected': 'false'
                }).set('text', this.d.getDate()).inject(weekcontainer);
            }
            if (this.d.toDateString() === currentChoice) {
                title += ' courant';
                if (!this.dateSelection) {
                    this.dateSelection = e;
                }
            }
            e.set('title', title);
            if (isCurrent) {
                this.dateSelection = e;
            }
            if (available) {
                e.addEvent('click', function(e, d) {
                    this.select(d);
                    return false;
                }.bindWithEvent(this, {
                    day: this.d.getDate(),
                    month: this.d.getMonth(),
                    year: this.d.getFullYear()
                }));
                e.addEvent('mouseover', function(cell) {
                    this.deselectCurrentElement();
                    this.selectCurrentElement(cell);
                }.bind(this, e));
            }
            this.d.setDate(this.d.getDate() + 1);
        }
    },
    lastDateOfPreviousMonth: function() {
        var date = this.d.clone();
        date.setDate(1);
        date.decrement('day', 1);
        return date;
    },
    firstDateOfNextMonth: function() {
        var date = this.d.clone();
        date.setDate(1);
        date.increment('month', 1);
        return date;
    },
    previousYearDate: function() {
        var date = this.d.clone();
        date.setDate(1);
        date.decrement('year', 1);
        date.setDate(date.get('lastdayofmonth'));
        return date;
    },
    nextYearDate: function() {
        var date = this.d.clone();
        date.setDate(1);
        date.increment('year', 1);
        return date;
    },
    previous: function() {
        this.deselectCurrentElement();
        this.d.setDate(1);
        this.d.setMonth(this.d.getMonth() - 1);
        this.render('left');
        this.fireEvent('previous');
        return false;
    },
    next: function() {
        this.deselectCurrentElement();
        this.d.setDate(1);
        this.d.setMonth(this.d.getMonth() + 1);
        this.render('right');
        this.fireEvent('next');
        return false;
    },
    previousYear: function() {
        this.deselectCurrentElement();
        this.d.setFullYear(this.d.getFullYear() - 1);
        this.render('left');
        this.fireEvent('previous');
        return false;
    },
    nextYear: function() {
        this.deselectCurrentElement();
        this.d.setFullYear(this.d.getFullYear() + 1);
        this.render('right');
        this.fireEvent('next');
        return false;
    },
    aujourdhui: function() {
        var today = new Date().clearTime();
        if (!this.isDateOutOfRange(today)) {
            this.choice = today.toObject();
            this.select('select', today.toObject());
        }
        return false;
    },
    destroy: function() {
        if (this.picker) {
            this.picker.destroy();
            this.picker = null;
            this.dateSelection = null;
            this.targetSelection = null;
            this.dateFocus = null;
            this.fireEvent('close');
        }
    },
    select: function(values) {
        this.choice = Object.merge(this.choice, values);
        var d = Date.fromObject(this.choice);
        if (typeof Placeholders !== 'undefined') {
            Placeholders.hide(this.input);
        }
        this.input.set('value', d.format(this.options.format)).store('datepicker:value', d);
        this.fireEvent('select', d);
        this.close(null, true);
    },
    leadZero: function(v) {
        return v < 10 ? '0' + v : v;
    }
});
Date.implement({
    toObject: function() {
        return {
            year: this.getFullYear(),
            month: this.getMonth(),
            day: this.getDate()
        };
    },
    isValid: function() {
        return !isNaN(this);
    }
});
Date.extend({
    fromObject: function(values) {
        values = values || {};
        var d = new Date();
        d.setDate(1);
        ['year', 'month', 'day'].each(function(type) {
            var v = values[type];
            if (!v && v !== 0) {
                return;
            }
            switch (type) {
                case 'day':
                    d.setDate(v);
                    break;
                case 'month':
                    d.setMonth(v);
                    break;
                case 'year':
                    d.setFullYear(v);
                    break;
                default:
                    break;
            }
        });
        return d.clearTime();
    }
});
var ChampSaisieTag = {
    tagErreur: "b.erreur_champ",
    classErreur: "erreur_champ",
    prefixIdZoneMessageErreur: "_messageErreur",
    classSpan: "zone_champ_saisie",
    separateurTelephone: ".",
    messagesErreur: [],
    lblErreurDate: "La date n'a pas un format correct (jj/mm/aaaa).",
    lblErreurHeure: "L'heure n'a pas un format correct (hh:mm:ss).",
    lblErreurTel: "Le t\u00E9l\u00E9phone n'a pas un format correct (01.23.45.67.89).",
    erreurChamp: function(champ, messageErreur) {
        if (messageErreur.length !== 0) {
            var span = $(champ.id).getParent('span');
            var bTagErreur = $(champ.id).getParent(ChampSaisieTag.tagErreur);
            if (!bTagErreur) {
                bTagErreur = new Element('b');
                bTagErreur.addClass(ChampSaisieTag.classErreur);
                $(champ.id).inject(bTagErreur);
                bTagErreur.inject(span, 'top');
            }
            $(champ.id).setProperty('aria-invalid', 'true');
            var icoCalendar = span.getElement('.calendrier');
            if (icoCalendar) {
                icoCalendar.inject(bTagErreur);
            }
            if ($(champ.id + ChampSaisieTag.prefixIdZoneMessageErreur) !== null) {
                $(champ.id + ChampSaisieTag.prefixIdZoneMessageErreur).removeClass('message_erreur_invisible');
                $(champ.id + ChampSaisieTag.prefixIdZoneMessageErreur).innerHTML = messageErreur;
            }
        }
    },
    isEmpty: function(champ) {
        return champ.value.length === 0;
    },
    champOK: function(champ) {
        var span = $(champ.id).getParent('span');
        var bTagErreur = $(champ.id).getParent(ChampSaisieTag.tagErreur);
        if (bTagErreur) {
            var elements = bTagErreur.getChildren();
            for (i = elements.length - 1; i >= 0; i--) {
                (elements[i]).inject(span, 'top');
            }
            bTagErreur.destroy();
        }
        $(champ.id).removeProperty('aria-invalid');
        if ($(champ.id + ChampSaisieTag.prefixIdZoneMessageErreur) !== null) {
            $(champ.id + ChampSaisieTag.prefixIdZoneMessageErreur).addClass('message_erreur_invisible');
            $(champ.id + ChampSaisieTag.prefixIdZoneMessageErreur).innerHTML = "";
        }
    },
    controleHeure: function(champ) {
        var erreur = false;
        var heureSaisie = champ.value;
        var heureSaisieSize = heureSaisie.length;
        if (!ChampSaisieTag.isEmpty(champ) && (heureSaisieSize === 4 || heureSaisieSize === 5 || heureSaisieSize === 6 || heureSaisieSize === 8)) {
            if (heureSaisieSize === 8) {
                heureSaisie = heureSaisie.replace(":", "");
                heureSaisie = heureSaisie.replace(":", "");
            }
            var Lheure = (heureSaisie).split("");
            var regExpFormatHH_MM = new RegExp("^[0-9]{4}$", "g");
            var regExpFormatHHDeuxPointsMM = new RegExp("^[0-9]{2}[:]{1}[0-9]{2}$", "g");
            var regExpFormatHH_MM_SS = new RegExp("^[0-9]{6}$", "g");
            if (regExpFormatHH_MM.test(heureSaisie)) {
                heureSaisie = Lheure[0] + Lheure[1] + ":" + Lheure[2] + Lheure[3] + ":00";
            } else {
                if (regExpFormatHHDeuxPointsMM.test(heureSaisie)) {
                    heureSaisie += ":00";
                } else {
                    if (regExpFormatHH_MM_SS.test(heureSaisie)) {
                        heureSaisie = Lheure[0] + Lheure[1] + ":" + Lheure[2] + Lheure[3] + ":" + Lheure[4] + Lheure[5];
                    } else {
                        erreur = true;
                    }
                }
            }
        } else {
            erreur = true;
        }
        champ.value = heureSaisie;
        if (erreur && !ChampSaisieTag.isEmpty(champ)) {
            ChampSaisieTag.erreurChamp(champ, ChampSaisieTag.lblErreurHeure);
            return false;
        } else {
            ChampSaisieTag.champOK(champ);
        }
        return true;
    },
    completeAnnee: function(annee, pPivot) {
        if (pPivot === undefined) {
            return "20" + annee;
        }
        if (annee < pPivot) {
            return "20" + annee;
        } else {
            return "19" + annee;
        }
    },
    normaliseDateAvecSlash: function(dateSaisie, pPivot) {
        var dateSplitee = dateSaisie.split('/');
        if (dateSplitee[0].length < 2) {
            dateSaisie = '0' + dateSplitee[0] + '/';
        } else {
            dateSaisie = dateSplitee[0] + '/';
        }
        if (dateSplitee[1].length < 2) {
            dateSaisie += '0' + dateSplitee[1] + '/';
        } else {
            dateSaisie += dateSplitee[1] + '/';
        }
        if (dateSplitee[2].length === 2) {
            dateSaisie += ChampSaisieTag.completeAnnee(dateSplitee[2], pPivot);
        } else {
            dateSaisie += dateSplitee[2];
        }
        return dateSaisie;
    },
    controleDate: function(champ, pPivot) {
        var erreur = false;
        var dateSaisie = champ.value;
        var dateTableau = dateSaisie.split("");
        var regSixCaracEtQueDesNombres = new RegExp("^[0-9]{6}$", "g");
        var regHuitCaracEtQueDesNombres = new RegExp("^[0-9]{8}$", "g");
        var regFormatDate = new RegExp("^[0-9]{1,2}\/[0-9]{1,2}\/([0-9]{2}|[0-9]{4})$", "g");
        if (regSixCaracEtQueDesNombres.test(dateSaisie)) {
            dateSaisie = dateTableau[0] + dateTableau[1] + "/" + dateTableau[2] + dateTableau[3] + "/" +
                ChampSaisieTag.completeAnnee(dateTableau[4] + dateTableau[5], pPivot);
        } else {
            if (regHuitCaracEtQueDesNombres.test(dateSaisie)) {
                dateSaisie = dateTableau[0] + dateTableau[1] + "/" + dateTableau[2] + dateTableau[3] + "/" +
                    dateTableau[4] + dateTableau[5] + dateTableau[6] + dateTableau[7];
            } else {
                if (regFormatDate.test(dateSaisie)) {
                    dateSaisie = ChampSaisieTag.normaliseDateAvecSlash(dateSaisie, pPivot);
                } else {
                    erreur = true;
                }
            }
        }
        champ.value = dateSaisie;
        if (erreur && !ChampSaisieTag.isEmpty(champ)) {
            ChampSaisieTag.erreurChamp(champ, ChampSaisieTag.lblErreurDate);
            return false;
        } else {
            ChampSaisieTag.champOK(champ);
        }
        return true;
    },
    controleTel: function(champ) {
        var telSaisie = champ.value;
        var regExpFormatTel = new RegExp("^0[1-9]([-. ]?[0-9]{2}){4}$", "g");
        if (regExpFormatTel.test(telSaisie)) {
            telSaisie = telSaisie.replace(/[-. ]/g, '');
            var telComplet = telSaisie.substr(0, 2) + ChampSaisieTag.separateurTelephone;
            telComplet += telSaisie.substr(2, 2) + ChampSaisieTag.separateurTelephone;
            telComplet += telSaisie.substr(4, 2) + ChampSaisieTag.separateurTelephone;
            telComplet += telSaisie.substr(6, 2) + ChampSaisieTag.separateurTelephone;
            telComplet += telSaisie.substr(8, 2);
            ChampSaisieTag.champOK(champ);
            champ.value = telComplet;
        } else {
            if (ChampSaisieTag.isEmpty(champ)) {
                ChampSaisieTag.champOK(champ);
            } else {
                ChampSaisieTag.erreurChamp(champ, ChampSaisieTag.lblErreurTel);
                return false;
            }
        }
        return true;
    },
    ajoutMessageErreur: function(message) {
        ChampSaisieTag.messagesErreur[0] = message;
    },
    recupMessagesErreur: function() {
        return ChampSaisieTag.messagesErreur[0];
    },
    controleTaille: function(champ, tailleMin, tailleMax, message) {
        var taille = champ.value.length;
        if (taille < tailleMin || taille > tailleMax) {
            ChampSaisieTag.ajoutMessageErreur(message);
            return false;
        }
        return true;
    },
    controlePattern: function(champ, regex, message) {
        var regexp = new RegExp(regex);
        if (!regexp.test(champ.value)) {
            ChampSaisieTag.ajoutMessageErreur(message);
            return false;
        }
        return true;
    },
    controleMin: function(champ, valeurMin, message) {
        var valeur = champ.value.replace(',', '.');
        if (ChampSaisieTag.isEmpty(champ) || isNaN(valeur) || valeur < valeurMin) {
            ChampSaisieTag.ajoutMessageErreur(message);
            return false;
        }
        return true;
    },
    controleMax: function(champ, valeurMax, message) {
        var valeur = champ.value.replace(',', '.');
        if (ChampSaisieTag.isEmpty(champ) || isNaN(valeur) || valeur > valeurMax) {
            ChampSaisieTag.ajoutMessageErreur(message);
            return false;
        }
        return true;
    },
    controleFuture: function(champ, message) {
        Date.defineParser('%d/%m/%Y');
        var valeur = new Date().parse(champ.value);
        if (ChampSaisieTag.isEmpty(champ) || !valeur.isValid() || valeur < (new Date())) {
            ChampSaisieTag.ajoutMessageErreur(message);
            return false;
        }
        return true;
    },
    controlePast: function(champ, message) {
        Date.defineParser('%d/%m/%Y');
        var valeur = new Date().parse(champ.value);
        if (ChampSaisieTag.isEmpty(champ) || !valeur.isValid() || valeur > (new Date())) {
            ChampSaisieTag.ajoutMessageErreur(message);
            return false;
        }
        return true;
    },
    effacerFormulaire: function(formid) {
        ChampTag.getForm(formid).getElements('span').each(function(span) {
            var champ;
            if (span.hasClass(ChampSaisieTag.classSpan)) {
                champ = span.getElement('input');
                ChampSaisieTag.champOK(champ);
                $(champ.id).setProperty('value', '');
            }
        });
        return true;
    }
};
var ChampTag = {
    suffixIdErr: "_messageErreur",
    erreurChamp: function(champ, messageErreur) {
        if (messageErreur.length !== 0) {
            if (champ.get('tag') === 'input' && champ.get('type') === 'text') {
                ChampSaisieTag.erreurChamp(champ, messageErreur);
            } else if (champ.get('tag') === 'textarea') {
                TexteTag.erreurChamp(champ, messageErreur);
            } else if (champ.getParent('.zone_choix') !== null) {
                ChoixTag.erreurChamp(champ, messageErreur);
            } else if (champ.getParent('.zone_combo') !== null) {
                ComboTag.erreurChamp(champ, messageErreur);
            }
        }
    },
    champOK: function(champ) {
        if (champ.get('tag') === 'input' && champ.get('type') === 'text') {
            ChampSaisieTag.champOK(champ);
        } else if (champ.get('tag') === 'textarea') {
            TexteTag.champOK(champ);
        } else if (champ.getParent('.zone_choix') !== null) {
            ChoixTag.champOK(champ);
        } else if (champ.getParent('.zone_combo') !== null) {
            ComboTag.champOK(champ);
        }
    },
    getForm: function(elm) {
        var formElement = null;
        if (document.id(elm) && document.id(elm).tagName === "FORM") {
            formElement = document.id(elm);
        } else if ($(elm) && $(elm).tagName === "FORM") {
            formElement = $(elm);
        } else if (document.getElementsByName(elm).length > 0 && document.getElementsByName(elm)[0].tagName === "FORM") {
            formElement = document.getElementsByName(elm)[0];
        } else if ($(elm)) {
            formElement = $(elm).getParent('form');
        }
        return formElement;
    },
    retablirFormulaire: function(formid) {
        ChampTag.getForm(formid).getElements('.zone_champ_saisie input, .zone_choix .choix-nav-v, .zone_choix .choix-nav-h, .zone_texte textarea, .zone_combo select').each(function(elem) {
            ChampTag.champOK(elem);
        });
        return true;
    },
    effacerFormulaire: function(formid) {
        ChampSaisieTag.effacerFormulaire(formid);
        ChoixTag.effacerFormulaire(formid);
        TexteTag.effacerFormulaire(formid);
        ComboTag.effacerFormulaire(formid);
        return true;
    }
};
var ChoixTag = {
    erreurChamp: function(champ, messageErreur) {
        var container = $(champ.id).getParent('.zone_choix');
        var tagErreur = $(champ.id).getParent('.erreur_choix');
        if (!tagErreur) {
            tagErreur = new Element('div');
            tagErreur.addClass('erreur_choix');
            $(champ.id).inject(tagErreur);
            container.addClass('erreur_champ');
            tagErreur.inject(container, 'top');
        }
        if ($(champ.id + ChampTag.suffixIdErr) !== null) {
            $(champ.id + ChampTag.suffixIdErr).innerHTML = messageErreur;
            $(champ.id + ChampTag.suffixIdErr).style.display = "inline-block";
        }
    },
    champOK: function(champ) {
        var container = $(champ.id).getParent('.zone_choix');
        var tagErreur = $(champ.id).getParent('.erreur_choix');
        if (tagErreur) {
            $(champ.id).inject(container, 'top');
            tagErreur.destroy();
        }
        container.removeClass('erreur_champ');
        if ($(champ.id + ChampTag.suffixIdErr) !== null) {
            $(champ.id + ChampTag.suffixIdErr).style.display = "none";
            $(champ.id + ChampTag.suffixIdErr).innerHTML = "";
        }
    },
    effacerFormulaire: function(formid) {
        ChampTag.getForm(formid).getElements('.zone_choix .choix-nav-v, .zone_choix .choix-nav-h').each(function(champ) {
            ChoixTag.champOK(champ);
            champ.getElements('input').each(function(choix) {
                choix.erase('checked');
            });
        });
        return true;
    }
};
Elements.implement({
    chosen: function(options) {
        return this.each(function(el) {
            if (!el.hasClass("chzn-done")) {
                return new Chosen(el, options);
            }
        });
    }
});
var Chosen = new Class({
    Implements: Options,
    Binds: ['test_active_click', 'container_mousedown', 'container_mouseup', 'mouse_enter', 'mouse_leave', 'search_results_mouseup', 'search_results_mouseover', 'search_results_mouseout', 'input_blur', 'keyup_checker', 'keydown_checker', 'choices_click', 'input_focus', 'activate_field', 'results_update_field'],
    options: {
        allow_single_deselect: false,
        disable_search_threshold: 0,
        placeholder: null,
        width: null
    },
    active_field: false,
    mouse_on_container: false,
    results_showing: false,
    result_highlighted: null,
    result_single_selected: null,
    choices: 0,
    initialize: function(elmn, options) {
        this.setOptions(options);
        this.form_field = elmn;
        this.is_multiple = this.form_field.multiple;
        this.is_rtl = this.form_field.hasClass('chzn-rtl');
        this.set_up_html();
        this.register_observers();
        this.update_label();
        this.form_field.addClass('chzn-done');
    },
    set_up_html: function() {
        if (!this.form_field.get('id')) {
            this.form_field.set('id', String.uniqueID());
        }
        this.container_id = this.form_field.id.replace(/(:|\.)/g, '_') + "_chzn";
        this.f_width = this.form_field.measure(function() {
            return (this.options.width ? this.getSize().x : this.getSize().x + 25);
        });
        this.default_text = this.options.placeholder ? this.options.placeholder : Locale.get('Chosen.placeholder', this.form_field.multiple);
        this.container = new Element('div', {
            'id': this.container_id,
            'class': 'chzn-container' + (this.is_rtl ? ' chzn-rtl' : '') + " chzn-container-" + (this.is_multiple ? "multi" : "single"),
            'styles': {
                'width': this.f_width
            }
        });
        if (this.is_multiple) {
            this.container.set('html', '<ul class="chzn-choices"><li class="search-field"><input type="text" value="' + this.default_text + '" class="default" autocomplete="off" style="width:25px;" /></li></ul><div class="chzn-drop" style="left:-9000px;"><ul class="chzn-results"></ul></div>');
        } else {
            this.container.set('html', '<a href="javascript:void(0)" tabindex="-1" class="chzn-single" aria-expanded="false" id="' + this.container_id + '_text" aria-owns="' + this.container_id + '_drop"><span>' + this.default_text + '</span><span class="btn-down"><b></b></span></a><div class="chzn-drop" style="left:-9000px;"><div class="chzn-search"><input id="input_' + this.form_field.get('id') + '" type="text" autocomplete="off" /></div><ul class="chzn-results"></ul></div>');
        }
        this.form_field.setStyle('display', 'none').grab(this.container, 'after');
        this.dropdown = this.container.getElement('div.chzn-drop');
        this.dropdown.set('id', this.container_id + '_drop');
        var dd_width = this.f_width - this.dropdown.get_side_border_padding();
        this.dropdown_pos();
        this.search_field = this.container.getElement('input');
        this.search_field.setProperty('aria-controls', this.container_id + '_listbox');
        this.search_results = this.container.getElement('ul.chzn-results');
        this.search_results.setProperty('role', 'listbox');
        this.search_results.set('id', this.container_id + '_listbox');
        this.search_results.tabIndex = -1;
        this.search_field_scale();
        this.search_no_results = this.container.getElement('li.no-results');
        if (this.is_multiple) {
            this.search_choices = this.container.getElement('ul.chzn-choices');
            this.search_container = this.container.getElement('li.search-field');
        } else {
            this.search_container = this.container.getElement('div.chzn-search');
            this.selected_item = this.container.getElement('.chzn-single');
            var sf_width = dd_width - this.search_container.get_side_border_padding() - this.search_field.get_side_border_padding();
            this.search_field.setStyle('width', sf_width);
        }
        this.results_build();
        this.form_field.fireEvent('liszt:ready', this);
    },
    register_observers: function() {
        this.container.addEvents({
            mousedown: this.container_mousedown,
            mouseup: this.container_mouseup,
            mouseenter: this.mouse_enter,
            mouseleave: this.mouse_leave
        });
        this.search_results.addEvents({
            mouseup: this.search_results_mouseup,
            mouseover: this.search_results_mouseover,
            mouseout: this.search_results_mouseout
        });
        this.form_field.addEvent("liszt:updated", this.results_update_field);
        this.search_field.addEvents({
            keyup: this.keyup_checker,
            keydown: this.keydown_checker
        });
        this.search_results.addEvents({
            blur: this.input_blur,
            keyup: this.keyup_checker,
            keydown: this.keydown_checker
        });
        if (this.is_multiple) {
            this.search_choices.addEvent("click", this.choices_click);
            this.search_field.addEvent("focus", this.input_focus);
        } else {
            this.selected_item.addEvent("focus", this.activate_field);
            this.search_field.addEvent("focus", this.activate_field);
        }
    },
    unregister_observers: function() {
        this.container.removeEvents({
            mousedown: this.container_mousedown,
            mouseup: this.container_mouseup,
            mouseenter: this.mouse_enter,
            mouseleave: this.mouse_leave
        });
        this.search_results.removeEvents({
            mouseup: this.search_results_mouseup,
            mouseover: this.search_results_mouseover,
            mouseout: this.search_results_mouseout
        });
        this.form_field.removeEvent("liszt:updated", this.results_update_field);
        this.search_field.removeEvents({
            blur: this.input_blur,
            keyup: this.keyup_checker,
            keydown: this.keydown_checker
        });
        this.search_results.removeEvents({
            blur: this.input_blur,
            keyup: this.keyup_checker,
            keydown: this.keydown_checker
        });
        if (this.is_multiple) {
            this.search_choices.removeEvent("click", this.choices_click);
            this.search_field.removeEvent("focus", this.input_focus);
        } else {
            this.selected_item.removeEvent("focus", this.activate_field);
        }
        document.removeEvent('click', this.test_active_click);
    },
    update_label: function() {
        var lbl = $$('label[for=' + this.form_field.get('id') + ']');
        if (lbl != null) {
            lbl.setProperty("for", 'input_' + this.form_field.get('id'));
        }
    },
    search_field_disabled: function() {
        this.is_disabled = this.form_field.get('disabled');
        if (this.is_disabled) {
            this.container.addClass('chzn-disabled');
            this.search_field.set('disabled', true);
            if (!this.is_multiple) {
                this.selected_item.removeEvent("focus", this.activate_field);
            }
            this.close_field();
        } else {
            this.container.removeClass('chzn-disabled');
            this.search_field.set('disabled', false);
            if (!this.is_multiple) {
                this.selected_item.addEvent("focus", this.activate_field);
            }
        }
    },
    container_mousedown: function(evt) {
        if (!this.is_disabled) {
            var target_closelink = evt != null ? evt.target.hasClass("search-choice-close") : false;
            if (!this.pending_destroy_click && !target_closelink) {
                if (!this.active_field) {
                    if (this.is_multiple) {
                        this.search_field.set('value', '');
                    }
                    document.addEvent('click', this.test_active_click);
                    this.results_show();
                } else if (!this.is_multiple && evt && (evt.target === this.selected_item || evt.target.getParents('a.chzn-single').length)) {
                    evt.preventDefault();
                    this.results_toggle();
                }
                this.activate_field();
            } else {
                this.pending_destroy_click = false;
            }
        }
    },
    container_mouseup: function(evt) {
        if (evt.target.get('tag').toUpperCase() === "ABBR") {
            return this.results_reset(evt);
        }
    },
    mouse_enter: function() {
        this.mouse_on_container = true;
    },
    mouse_leave: function() {
        this.mouse_on_container = false;
    },
    input_focus: function(evt) {
        if (!this.active_field) {
            setTimeout(this.container_mousedown, 50);
        }
    },
    input_blur: function(evt) {
        if (!this.mouse_on_container) {
            this.active_field = false;
            setTimeout(this.blur_test.bind(this), 100);
        }
    },
    blur_test: function(evt) {
        if (!this.active_field && this.container.hasClass('chzn-container-active')) {
            this.close_field();
        }
    },
    close_field: function() {
        document.removeEvent('click', this.test_active_click);
        this.active_field = false;
        this.results_hide();
        this.container.removeClass("chzn-container-active");
        this.selected_item.removeClass('chzn-container-focus');
        this.winnow_results_clear();
        this.clear_backstroke();
        this.show_search_field_default();
        this.search_field_scale();
    },
    activate_field: function() {
        if (!this.container.hasClass('chzn-disabled')) {
            this.container.addClass('chzn-container-active');
            this.active_field = true;
            this.search_field.set('value', this.search_field.get('value'));
            this.selected_item.addClass('chzn-container-focus');
            this.search_field.removeEvents('blur');
            this.search_field.addEvent('blur', this.input_blur);
            this.search_field.focus();
        }
    },
    test_active_click: function(evt) {
        if (evt.target.getParents('#' + this.container_id).length) {
            this.active_field = true;
        } else {
            this.close_field();
        }
    },
    results_build: function() {
        this.parsing = true;
        this.results_data = this.form_field.select_to_array();
        if (this.is_multiple && (this.choices > 0)) {
            this.search_choices.getElements("li.search-choice").destroy();
            this.choices = 0;
        } else if (!this.is_multiple) {
            this.selected_item.getElements("span:not(.btn-down)").set('text', this.default_text);
            if (this.form_field.options.length <= this.options.disable_search_threshold) {
                this.container.addClass("chzn-container-single-nosearch");
            } else {
                this.container.removeClass("chzn-container-single-nosearch");
            }
        }
        var content = '';
        this.results_data.each(function(data) {
            if (data.group) {
                content += this.result_add_group(data);
            } else if (!data.empty) {
                content += this.result_add_option(data);
                if (data.selected && this.is_multiple) {
                    this.choice_build(data);
                } else if (data.selected && !this.is_multiple) {
                    this.selected_item.getElements("span:not(.btn-down)").set('text', data.text);
                    if (this.options.allow_single_deselect) {
                        this.single_deselect_control_build();
                    }
                }
            }
        }, this);
        this.search_field_disabled();
        this.show_search_field_default();
        this.search_field_scale();
        this.search_results.set('html', content);
        this.parsing = false;
    },
    result_add_group: function(group) {
        if (!group.disabled) {
            group.dom_id = this.container_id + "_g_" + group.array_index;
            return '<li id="' + group.dom_id + '" class="group-result"><div>' + group.label + '</div></li>';
        } else {
            return '';
        }
    },
    result_add_option: function(option) {
        if (!option.disabled) {
            option.dom_id = this.container_id + "_o_" + option.array_index;
            var classes = option.selected && this.is_multiple ? [] : ["active-result"];
            if (option.selected) {
                classes.push('result-selected');
            }
            if (option.group_array_index != null) {
                classes.push("group-option");
            }
            if (option.classes !== "") {
                classes.push(option.classes);
            }
            var style = option.style.cssText !== '' ? ' style="' + option.style + '"' : '';
            return '<li id="' + option.dom_id + '" tabindex="-1" role="option" aria-controls="' + this.container_id + '_text" ' + (option.selected ? 'aria-selected="true"' : '') + ' class="' + classes.join(' ') + '"' + style + '>' + option.html + '</li>';
        } else {
            return '';
        }
    },
    results_update_field: function() {
        this.result_clear_highlight();
        this.result_single_selected = null;
        this.results_build();
        this.form_field.setStyle('display', 'block');
        this.form_field.setStyle('display', 'none');
    },
    result_do_highlight: function(el) {
        if (el) {
            this.result_clear_highlight();
            this.result_highlight = el;
            this.result_highlight.addClass("highlighted");
        }
    },
    result_clear_highlight: function() {
        if (this.result_highlight) {
            this.result_highlight.removeClass("highlighted");
        }
        this.result_highlight = null;
    },
    results_toggle: function() {
        if (this.results_showing) {
            this.results_hide();
        } else {
            this.results_show();
        }
    },
    dropdown_pos: function() {
        var outOfScreen = (this.container.getCoordinates().top + this.container.getCoordinates().height - window.getScroll().y + this.dropdown.getComputedSize().totalHeight) > window.getSize().y;
        var dd_width = this.f_width - this.dropdown.get_side_border_padding();
        if ((outOfScreen || this.container.getParent(".force-drop-up")) && !this.container.getParent(".force-drop-down")) {
            this.dropdown.swapClass("chzn-drop-down", "chzn-drop-up");
            this.dropdown.setStyles({
                'width': dd_width,
                "top": "auto",
                bottom: this.container.getCoordinates().height
            });
        } else {
            this.dropdown.swapClass("chzn-drop-up", "chzn-drop-down");
            this.dropdown.setStyles({
                'width': dd_width,
                "top": this.container.getCoordinates().height,
                "bottom": "auto"
            });
        }
    },
    results_show: function() {
        if (!this.is_multiple) {
            this.selected_item.addClass("chzn-single-with-drop");
            this.selected_item.setProperty('aria-expanded', 'true');
            this.search_results.setProperty('aria-hidden', 'false');
            if (this.result_single_selected) {
                this.result_do_highlight(this.result_single_selected);
            }
        }
        this.dropdown_pos();
        this.dropdown.setStyle('left', 0);
        this.results_showing = true;
        this.selected_item.removeClass('chzn-container-focus');
        this.search_field.focus();
        this.search_field.set('value', this.search_field.get('value'));
        this.winnow_results();
    },
    results_hide: function() {
        if (!this.is_multiple) {
            this.selected_item.removeClass("chzn-single-with-drop");
            this.selected_item.setProperty('aria-expanded', 'false');
            this.search_results.setProperty('aria-hidden', 'true');
        }
        this.result_clear_highlight();
        this.dropdown.setStyle('left', -9000);
        this.results_showing = false;
    },
    show_search_field_default: function() {
        if (this.is_multiple && (this.choices < 1) && !this.active_field) {
            this.search_field.set('value', this.default_text);
            this.search_field.addClass("default");
        } else {
            this.search_field.set('value', "");
            this.search_field.removeClass("default");
        }
    },
    search_results_mouseup: function(evt) {
        var target = evt.target.hasClass("active-result") ? evt.target : evt.target.getParent(".active-result");
        if (target) {
            this.result_highlight = target;
            this.result_select(evt);
        }
    },
    search_results_mouseover: function(evt) {
        var target = evt.target.hasClass("active-result") ? evt.target : evt.target.getParent(".active-result");
        if (target) {
            this.result_do_highlight(target);
        }
    },
    search_results_mouseout: function(evt) {},
    choices_click: function(evt) {
        evt.preventDefault();
        if (this.active_field && !(evt.target.hasClass("search-choice") || evt.target.getParent('.search-choice')) && !this.results_showing) {
            this.results_show();
        }
    },
    choice_build: function(item) {
        var choice_id = this.container_id + "_c_" + item.array_index;
        this.choices += 1;
        var el = new Element('li', {
            'id': choice_id
        }).addClass('search-choice').set('html', '<span>' + item.html + '</span><a href="#" class="search-choice-close" rel="' + item.array_index + '"></a>');
        this.search_container.grab(el, 'before');
        el.getElement("a").addEvent('click', this.choice_destroy_link_click.bind(this));
    },
    choice_destroy_link_click: function(evt) {
        evt.preventDefault();
        if (!this.is_disabled) {
            this.pending_destroy_click = true;
            this.choice_destroy(evt.target);
        } else {
            evt.stop();
        }
    },
    choice_destroy: function(link) {
        this.choices -= 1;
        this.show_search_field_default();
        if (this.is_multiple && (this.choices > 0) && (this.search_field.value.length < 1)) {
            this.results_hide();
        }
        this.result_deselect(link.get("rel"));
        link.getParent('li').destroy();
    },
    results_reset: function(evt) {
        this.form_field.options[0].selected = true;
        this.selected_item.getElement("span:not(.btn-down)").set('text', this.default_text);
        this.show_search_field_default();
        evt.target.destroy();
        this.form_field.fireEvent("change");
        if (this.active_field) {
            this.results_hide();
        }
    },
    result_select: function(evt) {
        if (this.result_highlight) {
            var high = this.result_highlight,
                high_id = high.id;
            this.result_clear_highlight();
            if (this.is_multiple) {
                this.result_deactivate(high);
            } else {
                var selected = this.search_results.getElement(".result-selected");
                if (selected) {
                    selected.removeClass("result-selected");
                    selected.removeProperty("aria-selected");
                }
                this.result_single_selected = high;
            }
            high.addClass("result-selected");
            high.setProperty("aria-selected", "true");
            var position = high_id.substr(high_id.lastIndexOf("_") + 1),
                item = this.results_data[position];
            item.selected = true;
            this.form_field.selectedIndex = item.options_index;
            if (this.is_multiple) {
                this.choice_build(item);
            } else {
                this.selected_item.getElement("span:not(.btn-down)").set('text', item.text);
                if (this.options.allow_single_deselect) {
                    this.single_deselect_control_build();
                }
            }
            if (!this.is_multiple || !evt.control) {
                this.results_hide();
            }
            this.search_field.set('value', "");
            this.form_field.fireEvent("change");
            this.search_field_scale();
        }
    },
    result_activate: function(el) {
        el.addClass("active-result");
    },
    result_deactivate: function(el) {
        el.removeClass("active-result");
    },
    result_deselect: function(pos) {
        var result_data = this.results_data[pos];
        result_data.selected = false;
        this.form_field.options[result_data.options_index].selected = false;
        var result = document.id(this.container_id + "_o_" + pos);
        result.removeClass("result-selected").addClass("active-result").setStyle('display', 'block');
        result.removeProperty('aria-selected');
        this.result_clear_highlight();
        this.winnow_results();
        this.form_field.fireEvent("change");
        this.search_field_scale();
    },
    single_deselect_control_build: function() {
        if (this.options.allow_single_deselect && (this.selected_item.getElements("abbr").length < 1)) {
            return this.selected_item.getElement("span").grab(new Element('abbr', {
                'class': 'search-choice-close'
            }), 'before');
        }
    },
    results_search: function(evt) {
        if (this.results_showing) {
            this.winnow_results();
        } else {
            this.results_show();
        }
    },
    winnow_results: function() {
        this.no_results_clear();
        var results = 0,
            searchText = this.search_field.get('value') === this.default_text ? "" : new Element('div', {
                text: this.search_field.get('value').trim()
            }).get('html'),
            regex = new RegExp('^' + searchText.replace(/[-[\]{}()*+?.,\\^$|#\s]/g, "\\$&"), 'i'),
            zregex = new RegExp(searchText.replace(/[-[\]{}()*+?.,\\^$|#\s]/g, "\\$&"), 'i');
        if (this.container.hasClass("chzn-container-single-nosearch")) {
            searchText = "";
        }
        this.results_data.each(function(option) {
            if (!option.disabled && !option.empty) {
                if (option.group) {
                    document.id(option.dom_id).setStyle('display', 'none');
                } else if (!(this.is_multiple && option.selected)) {
                    var found = false,
                        result_id = option.dom_id,
                        result = $(result_id);
                    if (regex.test(option.html) || this.container.hasClass("chzn-container-single-nosearch")) {
                        found = true;
                        results += 1;
                    } else if ((option.html.indexOf(" ") >= 0) || option.html.indexOf("[") === 0) {
                        var parts = [option.html.replace(/\[|\]/g, "")];
                        if (parts.length) {
                            parts.each(function(part) {
                                if (regex.test(part)) {
                                    found = true;
                                    results += 1;
                                }
                            });
                        }
                    }
                    if (found) {
                        var text;
                        if (searchText.length) {
                            var startpos = option.html.search(zregex);
                            text = option.html.substr(0, startpos + searchText.length) + '</em>' + option.html.substr(startpos + searchText.length);
                            text = text.substr(0, startpos) + '<em>' + text.substr(startpos);
                        } else {
                            text = option.html;
                        }
                        result.set('html', text);
                        this.result_activate(result);
                        if (option.group_array_index != null) {
                            document.id(this.results_data[option.group_array_index].dom_id).setStyle('display', 'list-item');
                        }
                    } else {
                        if (this.result_highlight && result_id === this.result_highlight.id) {
                            this.result_clear_highlight();
                        }
                        this.result_deactivate(result);
                    }
                }
            }
        }, this);
        if ((results < 1) && searchText.length) {
            this.no_results(searchText);
        } else {
            this.winnow_results_set_highlight();
        }
    },
    winnow_results_clear: function() {
        this.search_field.set('value', '');
        this.search_results.getElements("li").each(function(li) {
            if (li.hasClass("group-result")) {
                li.setStyle('display', 'block');
            } else {
                if (this.is_multiple && !li.hasClass("result-selected")) {
                    this.result_activate(li);
                }
            }
        }, this);
    },
    winnow_results_set_highlight: function() {
        if (!this.result_highlight) {
            var selected_results = !this.is_multiple ? this.search_results.getElements(".active-result.result-selected") : [];
            var do_high = selected_results.length ? selected_results[0] : null;
            if (do_high != null) {
                this.result_do_highlight(do_high);
            }
        }
    },
    no_results: function(terms) {
        var no_results_html = new Element('li', {
            'class': 'no-results'
        }).set('html', Locale.get('Chosen.noResults') + ' "<span></span>"');
        no_results_html.getElement("span").set('html', terms);
        this.search_results.grab(no_results_html);
    },
    no_results_clear: function() {
        this.search_results.getElements(".no-results").destroy();
    },
    keydown_arrow: function() {
        this.search_field.removeEvents('blur');
        if (!this.result_highlight) {
            var first_active = this.search_results.getElement("li.active-result");
            if (first_active) {
                first_active.focus();
                this.result_do_highlight(first_active);
            }
        } else if (this.results_showing) {
            var next_sib = this.result_highlight.getNext("li.active-result");
            if (next_sib) {
                next_sib.focus();
                this.result_do_highlight(next_sib);
            }
        }
        if (!this.results_showing) {
            this.results_show();
        }
    },
    keyup_arrow: function() {
        if (!this.results_showing && !this.is_multiple) {
            this.results_show();
        } else if (this.result_highlight) {
            var prev_sib = this.result_highlight.getPrevious('li.active-result');
            if (prev_sib) {
                this.search_field.removeEvents('blur');
                prev_sib.focus();
                this.result_do_highlight(prev_sib);
            }
        }
    },
    keydown_backstroke: function() {
        if (this.pending_backstroke) {
            this.choice_destroy(this.pending_backstroke.getElement("a"));
            this.clear_backstroke();
        } else {
            this.pending_backstroke = this.search_choices.getLast("li.search-choice");
            this.pending_backstroke.addClass("search-choice-focus");
        }
    },
    clear_backstroke: function() {
        if (this.pending_backstroke) {
            this.pending_backstroke.removeClass("search-choice-focus");
        }
        this.pending_backstroke = null;
    },
    keyup_checker: function(evt) {
        this.search_field_scale();
        switch (evt.key) {
            case 'backspace':
                if (this.is_multiple && (this.backstroke_length < 1) && (this.choices > 0)) {
                    this.keydown_backstroke();
                } else if (!this.pending_backstroke) {
                    this.result_clear_highlight();
                    this.results_search();
                }
                break;
            case 'enter':
                evt.preventDefault();
                if (this.results_showing) {
                    this.result_select(evt);
                    this.activate_field();
                }
                break;
            case 'esc':
                if (this.results_showing) {
                    this.results_hide();
                }
                break;
            case 'tab':
            case 'up':
            case 'down':
            case 'shift':
            case 'ctrl':
                break;
            default:
                if (!this.container.hasClass("chzn-container-single-nosearch")) {
                    this.results_search();
                }
        }
    },
    keydown_checker: function(evt) {
        var eventOnSearchField = (evt.target.get('tag') === 'input');
        this.search_field_scale();
        if (evt.key !== 'backspace' && this.pending_backstroke) {
            this.clear_backstroke();
        }
        switch (evt.key) {
            case 'backspace':
                if (eventOnSearchField) {
                    this.backstroke_length = this.search_field.value.length;
                } else {
                    this.search_field.focus();
                    this.search_field.fireEvent('keydown', evt);
                    evt.preventDefault();
                }
                break;
            case 'tab':
                if (this.results_showing && !this.is_multiple) {
                    this.result_select(evt);
                }
                this.mouse_on_container = false;
                break;
            case 'enter':
                evt.preventDefault();
                break;
            case 'up':
                evt.preventDefault();
                this.keyup_arrow();
                break;
            case 'down':
                evt.preventDefault();
                this.keydown_arrow();
                break;
            default:
                this.search_field.focus();
                break;
        }
    },
    search_field_scale: function() {
        if (this.is_multiple) {
            var h = 0,
                w = 0,
                style_block = {
                    position: 'absolute',
                    left: '-1000px',
                    top: '-1000px',
                    display: 'none'
                },
                styles = this.search_field.getStyles('font-size', 'font-style', 'font-weight', 'font-family', 'line-height', 'text-transform', 'letter-spacing');
            Object.merge(style_block, styles);
            var div = new Element('div', {
                'styles': style_block
            });
            div.set('text', this.search_field.get('value'));
            $(document.body).grab(div);
            w = div.getDimensions().width + 25;
            div.destroy();
            if (w > this.f_width - 10) {
                w = this.f_width - 10;
            }
            this.search_field.setStyle('width', w);
            var dd_top = this.container.getCoordinates().height;
            this.dropdown.setStyle('top', dd_top);
        }
    }
});
Element.implement({
    get_side_border_padding: function() {
        var styles = this.getStyles('padding-left', 'padding-right', 'border-left-width', 'border-right-width'),
            notNull = Object.filter(styles, function(value) {
                return (typeof(value) == 'string');
            }),
            mapped = Object.map(notNull, function(s) {
                return s.toInt();
            }),
            array = Object.values(mapped),
            result = 0,
            l = array.length;
        if (l) {
            while (l--) {
                result += array[l];
            }
        }
        return result;
    },
    select_to_array: function() {
        var parser = new SelectParser();
        this.getChildren().each(function(child) {
            parser.add_node(child);
        });
        return parser.parsed;
    }
});
var SelectParser = new Class({
    options_index: 0,
    parsed: [],
    add_node: function(child) {
        if (child.nodeName.toUpperCase() === "OPTGROUP") {
            this.add_group(child);
        } else {
            this.add_option(child);
        }
    },
    add_group: function(group) {
        var group_position = this.parsed.length;
        this.parsed.push({
            array_index: group_position,
            group: true,
            label: group.label,
            children: 0,
            disabled: group.disabled
        });
        group.getChildren().each(function(option) {
            this.add_option(option, group_position, group.disabled);
        }, this);
    },
    add_option: function(option, group_position, group_disabled) {
        if (option.nodeName.toUpperCase() === "OPTION") {
            if (option.text !== "") {
                if (group_position != null) {
                    this.parsed[group_position].children += 1;
                }
                this.parsed.push({
                    array_index: this.parsed.length,
                    options_index: this.options_index,
                    value: option.get("value"),
                    text: option.get("text").trim(),
                    html: option.get("html"),
                    selected: option.selected,
                    disabled: group_disabled === true ? group_disabled : option.disabled,
                    group_array_index: group_position,
                    classes: option.className,
                    style: option.style.cssText
                });
            } else {
                this.parsed.push({
                    array_index: this.parsed.length,
                    options_index: this.options_index,
                    empty: true
                });
            }
            this.options_index += 1;
        }
    }
});
var ComboTag = {
    erreurChamp: function(champ, messageErreur) {
        var container = $(champ.id).getParent('.zone_combo');
        container.addClass('erreur_combo');
        if ($(champ.id + ChampTag.suffixIdErr) !== null) {
            $(champ.id + ChampTag.suffixIdErr).innerHTML = messageErreur;
            $(champ.id + ChampTag.suffixIdErr).style.display = "inline-block";
        }
    },
    champOK: function(champ) {
        var container = $(champ.id).getParent('.zone_combo');
        container.removeClass('erreur_combo');
        if ($(champ.id + ChampTag.suffixIdErr) !== null) {
            $(champ.id + ChampTag.suffixIdErr).style.display = "none";
            $(champ.id + ChampTag.suffixIdErr).innerHTML = "";
        }
    },
    effacerFormulaire: function(formid) {
        ChampTag.getForm(formid).getElements('.zone_combo select').each(function(champ) {
            ComboTag.champOK(champ);
            champ.selectedIndex = 0;
            champ.fireEvent("liszt:updated");
        });
        return true;
    }
};
var combosTag = {};
combosTag.clearCombo = function(combo) {
    var options = combo.getElements('option');
    for (i = 1; i < options.length; i++) {
        options[i].destroy();
    }
};
combosTag.addItems = function(comboTarget, data) {
    if (data) {
        for (i = 0; i < data.length; i++) {
            var elem = data[i];
            if (elem.label) {
                var group = new Element('optgroup', {
                    label: elem.label
                });
                for (j = 0; j < elem.items.length; j++) {
                    new Element('option', {
                        value: elem.items[j].value,
                        text: elem.items[j].text
                    }).inject(group);
                }
                group.inject(comboTarget);
            } else {
                new Element('option', {
                    value: elem.value,
                    text: elem.text
                }).inject(comboTarget);
            }
        }
    }
};
combosTag.getComboRequest = function(comboTarget, url) {
    return new Request.JSON({
        url: url,
        onSuccess: function(data_combo) {
            combosTag.clearCombo(comboTarget);
            combosTag.addItems(comboTarget, data_combo);
            comboTarget.removeProperty('disabled');
            comboTarget.fireEvent("liszt:updated");
        }
    });
};
combosTag.getNextComboId = function(comboIdList, currentComboId) {
    for (i = 0; i < comboIdList.length; i++) {
        if (comboIdList[i] == currentComboId) {
            return comboIdList[i + 1];
        }
    }
    return null;
};
combosTag.clearAllFollowingCombos = function(comboIdList, comboId) {
    var clearFlag = false;
    for (j = 0; j < comboIdList.length; j++) {
        if (clearFlag) {
            combosTag.clearCombo($(comboIdList[j]));
            $(comboIdList[j]).set("disabled", "disabled");
            $(comboIdList[j]).fireEvent("liszt:updated");
        }
        if (comboIdList[j] == comboId) {
            clearFlag = true;
        }
    }
};
combosTag.initAjax = function(comboIdList, url, params) {
    for (i = 0; i < (comboIdList.length - 1); i++) {
        $(comboIdList[i]).addEvent('change', function(event) {
            var nextComboId = combosTag.getNextComboId(comboIdList, this.id);
            var request = combosTag.getComboRequest($(nextComboId), url);
            var data = this.name + "=" + this.value;
            if (params !== "") {
                data += "&" + params;
            }
            request.send(data);
            combosTag.clearAllFollowingCombos(comboIdList, nextComboId);
        });
    }
};
combosTag.getItems = function(data, comboIdList, valueSelected, level) {
    var data_combo = [];
    if (level < 1) {
        data_combo = data;
    } else {
        data_combo = combosTag.getItems(data, comboIdList, $(comboIdList[level - 1]).value, level - 1);
    }
    for (i = 0; i < data_combo.length; i++) {
        var elem = data_combo[i];
        if (elem.label) {
            for (j = 0; j < elem.items.length; j++) {
                if (elem.items[j].value == valueSelected) {
                    return elem.items[j].items;
                }
            }
        } else {
            if (elem.value == valueSelected) {
                return elem.items;
            }
        }
    }
};
combosTag.updateCombo = function(comboTarget, data, comboIdList, valueSelected, level) {
    combosTag.clearCombo(comboTarget);
    var data_combo = combosTag.getItems(data, comboIdList, valueSelected, level);
    combosTag.addItems(comboTarget, data_combo);
    comboTarget.removeProperty('disabled');
    comboTarget.fireEvent("liszt:updated");
};
combosTag.initLocal = function(comboIdList, data) {
    for (i = 0; i < (comboIdList.length - 1); i++) {
        $(comboIdList[i]).addEvent('change', function(event) {
            var nextComboId = combosTag.getNextComboId(comboIdList, this.id);
            combosTag.updateCombo($(nextComboId), data, comboIdList, this.value, i);
            combosTag.clearAllFollowingCombos(comboIdList, nextComboId);
        });
    }
};
var EtapeTag = new Class({
    element: null,
    initialize: function(element) {
        this.element = element;
        this.initEvents();
    },
    initEvents: function() {
        this.element.getElement('ul').navigChildsSelector = 'li > a:not([aria-disabled=true])';
        ListNavig.initEvents(this.element);
    }
});
EtapeTag.extend({
    components: {},
    init: function(element) {
        this.components[element.id] = new EtapeTag(element);
    }
});
var Fenetre = new Class({
    Implements: [Options],
    options: {
        overlays: true,
        url: null,
        draggable: false,
        onload: false,
        position: document.body,
        cssclass: null
    },
    element: null,
    triggerElement: null,
    level: null,
    drag: null,
    keyboardHandlerId: null,
    focusableElements: [],
    overlay: null,
    initialize: function(elementId, options) {
        if (Fenetre.components[elementId] !== undefined) {
            Fenetre.components[elementId].destroy();
        }
        Fenetre.components[elementId] = this;
        this.setOptions(options);
        this.element = $(elementId);
        if (this.element === null) {
            this.construct(elementId);
        } else {
            $(document.body).adopt(this.element);
        }
        var closeButton = this.getCloseElement();
        if (closeButton !== null) {
            closeButton.set('tabindex', 0);
            closeButton.addEvent('click', this.close.bind(this));
            closeButton.addEvent('keydown', function(evt) {
                switch (evt.key) {
                    case 'enter':
                        this.close();
                        evt.stop();
                        break;
                    default:
                        break;
                }
            }.bind(this));
        }
        if (this.options.draggable) {
            this.enableDrag();
        }
        if (this.options.onload) {
            this.open();
        }
    },
    construct: function(elementId) {
        this.element = new Element('div', {
            id: elementId,
            'class': 'invisible fenetre',
            'tabindex': 0,
            role: this.getRole()
        });
        if (this.options.cssclass) {
            this.element.addClass(this.options.cssclass);
        }
        var header = this.constructHeader();
        this.element.set('aria-labelledby', header.getElement('.fenetre-title').id);
        header.inject(this.element);
        var elementContent = new Element('div', {
            'class': 'fenetre-content'
        });
        elementContent.inject(this.element);
        this.element.inject($(document.body));
    },
    constructHeader: function() {
        var elementHeader = new Element('div', {
            'class': 'fenetre-header'
        });
        var elementTitle = new Element('span', {
            id: this.element.id + '_title',
            'class': 'fenetre-title'
        });
        if (this.options.title) {
            elementTitle.set('html', this.options.title);
        }
        var elementClose = new Element('span', {
            id: this.element.id + '_close',
            'class': 'fenetre-button',
            role: 'button',
            title: 'Fermer'
        });
        var elementLabelClose = new Element('span', {
            'class': 'label-close',
            'html': 'Fermer'
        });
        elementTitle.inject(elementHeader);
        elementLabelClose.inject(elementClose);
        elementClose.inject(elementHeader);
        return elementHeader;
    },
    getRole: function() {
        return '';
    },
    getCloseElement: function() {
        return this.element.getElement('.fenetre-button');
    },
    enableDrag: function() {
        var header = this.element.getElement('.fenetre-header');
        header.set('tabindex', 0);
        this.element.addClass('draggable');
        this.drag = new Drag(this.element.id, {
            snap: 0,
            limit: {
                x: [0, false],
                y: [0, false]
            },
            handle: header,
            onSnap: function(el) {
                el.addClass('dragging');
            },
            onComplete: function(el) {
                el.removeClass('dragging');
            }
        });
        header.addEvent('keydown', function(evt) {
            var currentPosition = this.element.getPosition();
            switch (evt.key) {
                case 'up':
                    if (currentPosition.y > 0) {
                        this.element.setPosition({
                            x: currentPosition.x,
                            y: currentPosition.y - Fenetre.dragStep
                        });
                    }
                    evt.stop();
                    break;
                case 'down':
                    this.element.setPosition({
                        x: currentPosition.x,
                        y: currentPosition.y + Fenetre.dragStep
                    });
                    evt.stop();
                    break;
                case 'left':
                    if (currentPosition.x > 0) {
                        this.element.setPosition({
                            x: currentPosition.x - Fenetre.dragStep,
                            y: currentPosition.y
                        });
                    }
                    evt.stop();
                    break;
                case 'right':
                    this.element.setPosition({
                        x: currentPosition.x + Fenetre.dragStep,
                        y: currentPosition.y
                    });
                    evt.stop();
                    break;
                default:
                    break;
            }
        }.bind(this));
    },
    open: function() {
        this.triggerElement = document.activeElement;
        this.element.removeClass('invisible');
        Fenetre.visibleStack.push(this);
        this.level = Fenetre.visibleStack.length;
        if (this.options.overlays) {
            this.drawOverlay();
        }
        this.element.setStyle('z-index', Fenetre.zIndexMin + (this.level * 2) + 1);
        this.position();
        if (this.options.url === null) {
            this.element.focus();
        } else {
            this.loadContent();
        }
        $(document).addEvent('keydown', this.keyboardHandlerId = this.keyboardHandler.bind(this));
    },
    position: function() {
        this.element.position({
            relativeTo: this.options.position
        });
    },
    drawOverlay: function() {
        var idOverlay = this.element.id + Fenetre.suffixOverlay;
        if (this.overlay) {
            this.removeOverlay();
        }
        this.overlay = new Element('div', {
            id: idOverlay
        });
        this.overlay.addClass(Fenetre.classOverlay);
        this.overlay.inject($(document.body), 'top');
        this.overlay.setStyle('z-index', Fenetre.zIndexMin + (this.level * 2));
    },
    loadContent: function() {
        var contentContainer = this.element.getElement('.fenetre-content');
        var self = this;
        contentContainer.set('aria-busy', true);
        contentContainer.set('html', Fenetre.waitMessageHtml);
        contentContainer.set('load', {
            method: 'post',
            async: true,
            onFailure: function() {
                contentContainer.set('html', Fenetre.errorMessageHtml);
            },
            onError: function() {
                contentContainer.set('html', Fenetre.errorMessageHtml);
            },
            onComplete: function() {
                self.position();
                self.element.focus();
            }
        });
        contentContainer.load(this.options.url);
        contentContainer.set('aria-busy', false);
    },
    removeOverlay: function() {
        if (this.overlay) {
            this.overlay.destroy();
            this.overlay = null;
        }
    },
    close: function() {
        this.element.addClass('invisible');
        Fenetre.visibleStack.pop();
        if (this.options.overlays) {
            this.removeOverlay();
        }
        $(document).removeEvent('keydown', this.keyboardHandlerId);
        if (this.triggerElement !== null) {
            this.triggerElement.focus();
        }
        this.element.fireEvent('close');
    },
    destroy: function() {
        this.removeOverlay();
        this.element.destroy();
    },
    keyboardHandler: function(event) {
        if (Fenetre.getVisibleFenetre() === this) {
            if (event.key === 'esc') {
                this.close();
                event.stop();
            } else if (event.key === 'tab') {
                event.stop();
                this.initFocusableElements();
                var focusableElement;
                if (event.shift) {
                    focusableElement = this.getPreviousFocusableElement();
                } else {
                    focusableElement = this.getNextFocusableElement();
                }
                if (focusableElement !== null) {
                    focusableElement.focus();
                }
            }
        }
    },
    setContent: function(htmlContent) {
        this.element.getElement('.fenetre-content').set('html', htmlContent);
    },
    initFocusableElements: function() {
        var focusableElementsSelector = '[tabindex]:not([tabindex^="-"]),a[href]:not([tabindex]),' +
            'input:not([tabindex]):not([disabled="disabled"]),' +
            'button:not([tabindex]):not([disabled="disabled"]),' +
            'select:not([tabindex]):not([disabled="disabled"]),' +
            'textarea:not([tabindex]):not([disabled="disabled"])';
        var visibleFocusableElements = this.element.getElements(focusableElementsSelector).filter(function(item, index) {
            return item.isDisplayed();
        });
        this.focusableElements = $$(this.element).concat(visibleFocusableElements);
    },
    getNextFocusableElement: function() {
        for (var i = 1; i < this.focusableElements.length; i++) {
            if (this.focusableElements[i - 1] === document.activeElement) {
                return this.focusableElements[i];
            }
        }
        return this.focusableElements[0];
    },
    getPreviousFocusableElement: function() {
        for (var i = this.focusableElements.length - 2; i >= 0; i--) {
            if (this.focusableElements[i + 1] === document.activeElement) {
                return this.focusableElements[i];
            }
        }
        return this.focusableElements[this.focusableElements.length - 1];
    }
});
Fenetre.extend({
    components: {},
    visibleStack: [],
    suffixOverlay: '_overlay',
    classOverlay: 'popbg',
    zIndexMin: 98,
    dragStep: 4,
    waitMessageHtml: '<p class="zone-attente">Chargement en cours, veuillez patienter</p>',
    errorMessageHtml: '<p class="zone-alerte">Le serveur est temporairement indisponible, veuillez fermer la fen&ecirc;tre</p>',
    initDialogue: function(elementId, options) {
        return new Fenetre.Dialogue(elementId, options);
    },
    initModale: function(elementId, options) {
        return new Fenetre.Modale(elementId, options);
    },
    initBulle: function(elementId, options) {
        return new Fenetre.Bulle(elementId, options);
    },
    getVisibleFenetre: function() {
        if (this.visibleStack.length > 0) {
            return this.visibleStack[this.visibleStack.length - 1];
        }
        return null;
    }
});
Fenetre.Dialogue = new Class({
    Extends: Fenetre,
    initialize: function(elementId, options) {
        this.parent(elementId, options);
        this.element.addClass('dialogue');
        this.position();
    },
    getRole: function() {
        return 'dialog';
    }
});
Fenetre.Modale = new Class({
    Extends: Fenetre,
    initialize: function(elementId, options) {
        options.draggable = false;
        options.position = document.body;
        this.parent(elementId, options);
        this.element.addClass('modale');
        this.position();
    },
    getRole: function() {
        return 'alert';
    },
    getCloseElement: function() {
        return this.element.getElement('.fenetre-header');
    }
});
Fenetre.Bulle = new Class({
    Extends: Fenetre,
    initialize: function(elementId, options) {
        options.overlays = false;
        this.parent(elementId, options);
        this.element.addClass('bulle');
        document.addEvent('mousedown', function(event) {
            if (Fenetre.visibleStack.contains(this) && !this.element.contains(event.target)) {
                this.close();
            }
        }.bind(this));
    },
    getRole: function() {
        return 'alert';
    },
    position: function() {
        if (this.options.position === null || $(this.options.position) === $(document.body)) {
            this.element.position({
                relativeTo: this.options.position
            });
        } else {
            var x = $(this.options.position).getPosition().x + $(this.options.position).getComputedSize().totalWidth;
            if (this.element.getComputedSize().totalWidth + x < $(document.body).getSize().x) {
                this.element.position({
                    relativeTo: this.options.position,
                    position: 'upperRight',
                    edge: 'upperLeft'
                });
            } else {
                this.element.position({
                    relativeTo: this.options.position,
                    position: 'bottomRight',
                    edge: 'upperRight'
                });
            }
        }
    }
});
FenetreModaleTag = {
    ouvrirFenetre: function(idFenetre) {
        Fenetre.components[idFenetre].open();
        return false;
    },
    fermerFenetre: function(idFenetre) {
        Fenetre.components[idFenetre].close();
        return false;
    }
};
var Grille = new Class({
    Implements: [Options],
    options: {
        minrows: 0,
        animationDuration: 2000,
        threshold: 300,
        collapse: true,
        button: true,
        expandTitle: 'D\u00E9plier la liste',
        collapseTitle: 'Plier la liste'
    },
    grid: null,
    container: null,
    button: null,
    isCollapse: false,
    activeElements: null,
    activeElementsSelector: 'li[role=option]:not([aria-disabled=true]) .item-nl',
    items: null,
    initialize: function(elementId, options) {
        Grille.components[elementId] = this;
        this.setOptions(options);
        this.container = $(elementId);
        this.grid = this.container.getElement('ul[role=listbox]');
        this.activeElements = this.grid.getElements(this.activeElementsSelector);
        this.items = this.grid.getElements('li[role=option]');
        if (this.items.length === 0) {
            return false;
        }
        if (this.options.collapse) {
            this.grid.setStyle('height', this.getRowHeight() * this.options.minrows);
            this.isCollapse = true;
        } else {
            this.isCollapse = false;
        }
        this.updateItems();
        if (this.options.button) {
            this.button = this.container.getElement('.btngrille');
            this.button.addEvent('click', this.toggle.bind(this));
            this.button.addEvent('keydown', this.buttonKeydownEvent.bind(this));
            this.updateButton();
            var gridWidth = this.grid.getDimensions().width;
            var elemsPerRow = Math.floor(gridWidth / this.getItemWidth());
            var rows = Math.ceil(this.items.length / elemsPerRow);
            if (this.options.minrows >= rows) {
                this.button.setStyle('visibility', 'hidden');
            }
        }
        this.addItemEvents();
        this.grid.addEvent('keydown', this.grilleKeydownEvent.bind(this));
    },
    getRowHeight: function() {
        return this.grid.getElement('li').getDimensions().height;
    },
    getItemWidth: function() {
        return this.grid.getElement('li').getDimensions().width - 1;
    },
    toggle: function() {
        if (this.grid.get('aria-busy') === null || this.grid.get('aria-busy') === 'false') {
            this.grid.set('aria-busy', 'true');
            if (this.isCollapse) {
                this.expandGrid();
            } else {
                this.collapseGrid();
            }
        }
    },
    updateButton: function() {
        if (this.isCollapse) {
            this.button.set('title', this.options.expandTitle);
            this.button.removeClass('deplier');
            this.button.addClass('plier');
        } else {
            this.button.set('title', this.options.collapseTitle);
            this.button.removeClass('plier');
            this.button.addClass('deplier');
        }
    },
    animate: function(height) {
        var myFx = new Fx.TweenBiblicnam(this.grid, {
            duration: this.options.animationDuration,
            threshold: this.options.threshold,
            transition: Fx.Transitions.Quad.easeInOut,
            property: 'height',
            onComplete: this.animateComplete.bind(this)
        });
        myFx.start(this.grid.getDimensions().height, height);
    },
    animateComplete: function() {
        this.isCollapse = !this.isCollapse;
        this.updateButton();
        this.updateItems();
        this.grid.set('aria-busy', 'false');
    },
    collapseGrid: function() {
        this.animate(this.getRowHeight() * this.options.minrows);
    },
    expandGrid: function() {
        var gridWidth = this.grid.getDimensions().width;
        var elemsPerRow = Math.floor(gridWidth / this.getItemWidth());
        var items = this.grid.getElements('li');
        var maxHeight = this.getRowHeight() * Math.ceil(items.length / elemsPerRow);
        this.grid.getElements('li[role=option][aria-hidden=true]').set('aria-hidden', false);
        this.animate(maxHeight);
    },
    evalDataEvent: function(event) {
        event.preventDefault();
        eval(this.get('data-event'));
    },
    isItemHidden: function(item) {
        return item.get('aria-hidden') === 'true';
    },
    isItemDisabled: function(item) {
        return item.get('aria-disabled') === 'true';
    },
    addItemEvents: function() {
        for (var i = 0; i < this.items.length; i++) {
            var item = this.items[i];
            var link = this.getLinkNavigable(item);
            if (link) {
                var itemEventStr = link.get('data-event');
                if (itemEventStr !== null) {
                    link.addEvent('click', this.evalDataEvent);
                }
            }
        }
    },
    updateItems: function() {
        var items = this.grid.getElements('li[role=option]');
        for (var i = 0; i < items.length; i++) {
            var item = items[i];
            var link = this.getLinkNavigable(item);
            var relPosY = item.getPosition(this.grid).y;
            if (relPosY < this.grid.getDimensions().height) {
                item.set('aria-hidden', false);
            } else {
                item.set('aria-hidden', true);
            }
            if (link) {
                link.set('tabindex', -1);
            }
        }
        var firstVisible = this.grid.getFirst('li[aria-hidden=false]:not([aria-disabled=true]) .item-nl');
        if (firstVisible !== null) {
            firstVisible.set('tabindex', 0);
        }
    },
    buttonKeydownEvent: function(event) {
        switch (event.key) {
            case 'space':
            case 'enter':
                this.toggle();
                break;
            default:
                break;
        }
    },
    isLinkNavigable: function(element) {
        var parent = element.getParent('li[role=option]');
        if (parent) {
            return this.getLinkNavigable(parent) === element;
        }
        return false;
    },
    getLinkNavigable: function(item) {
        return item.getElement('.item-nl');
    },
    grilleKeydownEvent: function(event) {
        var gridWidth = this.grid.getDimensions().width;
        var elemsPerRow = Math.floor(gridWidth / this.getItemWidth());
        var currentLink = event.target;
        var currentItem = currentLink.getParent('li[role=option]');
        if (this.isLinkNavigable(currentLink)) {
            switch (event.key) {
                case 'space':
                    event.preventDefault();
                    $(currentLink).click();
                    break;
                case 'home':
                    event.preventDefault();
                    this.switchFocus(this.grid.getFirst(this.activeElementsSelector));
                    break;
                case 'end':
                    event.preventDefault();
                    var lastItem = this.grid.getLast(this.activeElementsSelector);
                    this.switchFocus(lastItem);
                    break;
                case 'left':
                    event.preventDefault();
                    var currentIndex = this.activeElements.indexOf(currentLink);
                    var targetIndex = currentIndex - 1;
                    if (targetIndex >= 0) {
                        this.switchFocus(this.activeElements[targetIndex]);
                    }
                    break;
                case 'right':
                    event.preventDefault();
                    var currentIndex = this.activeElements.indexOf(currentLink);
                    var targetIndex = currentIndex + 1;
                    if (targetIndex < this.activeElements.length) {
                        this.switchFocus(this.activeElements[targetIndex]);
                    }
                    break;
                case 'up':
                    event.preventDefault();
                    var currentIndex = this.items.indexOf(currentItem);
                    var targetIndex = currentIndex - elemsPerRow;
                    if (targetIndex >= 0) {
                        var targetItem = this.items[targetIndex];
                        var targetLink = this.getLinkNavigable(targetItem);
                        if (this.isItemDisabled(targetItem)) {
                            targetLink = targetItem.getNext(this.activeElementsSelector);
                            if (targetLink === currentLink) {
                                targetLink = targetItem.getPrevious(this.activeElementsSelector);
                            }
                        }
                        this.switchFocus(targetLink);
                    }
                    break;
                case 'down':
                    event.preventDefault();
                    var currentIndex = this.items.indexOf(currentItem);
                    var targetIndex = currentIndex + elemsPerRow;
                    if (targetIndex < this.items.length) {
                        var targetItem = this.items[targetIndex];
                        var targetLink = this.getLinkNavigable(targetItem);
                        if (this.isItemDisabled(targetItem)) {
                            targetLink = targetItem.getPrevious(this.activeElementsSelector);
                            if (targetLink === currentLink) {
                                targetLink = targetItem.getNext(this.activeElementsSelector);
                            }
                        }
                        this.switchFocus(targetLink);
                    }
                    break;
                default:
                    break;
            }
        } else {
            if (event.key === 'left') {
                event.preventDefault();
                var link = this.getLinkNavigable(currentItem);
                if (link) {
                    link.focus();
                }
            }
        }
    },
    switchFocus: function(targetLink) {
        if (targetLink !== null) {
            document.activeElement.set('tabindex', -1);
            targetLink.set('tabindex', 0);
            if (this.isItemHidden(targetLink.getParent('li[role=option]'))) {
                this.toggle();
                (function() {
                    this.focus();
                }).delay(this.options.animationDuration, targetLink);
            } else {
                targetLink.focus();
            }
        }
    }
});
Grille.Banner = new Class({
    Extends: Grille,
    options: {
        previousBtnHtml: null,
        nextBtnHtml: null
    },
    previousBtn: null,
    nextBtn: null,
    isNavigable: false,
    containerWidth: null,
    liveUpdateInterval: 500,
    intervalId: null,
    initialize: function(elementId, options) {
        Grille.components[elementId] = this;
        this.setOptions(options);
        this.container = $(elementId);
        this.containerWidth = this.container.getDimensions().width;
        this.grid = this.container.getElement('ul[role=listbox]');
        this.activeElements = this.grid.getElements(this.activeElementsSelector);
        this.items = this.grid.getElements('li[role=option]');
        this.container.addClass('grille-banner');
        if (this.items.length === 0) {
            return false;
        }
        var ulWidth = this.getItemWidth() * this.items.length;
        this.grid.setStyle('height', this.getRowHeight());
        this.grid.setStyle('width', ulWidth);
        if (this.container.getDimensions().width < ulWidth) {
            this.addNavig();
            this.grid.setStyle('left', this.previousBtn.getDimensions().width);
            this.updateNavig();
        }
        this.addItemEvents();
        if (this.liveUpdateInterval > 0) {
            this.intervalId = this.checkNavig.periodical(this.liveUpdateInterval, this);
        }
    },
    checkNavig: function(event) {
        if (this.liveUpdateInterval > 0 && this.container.getDimensions().width !== this.containerWidth) {
            this.containerWidth = this.container.getDimensions().width;
            if (this.isNavigable) {
                if (this.grid.getDimensions().width <= this.containerWidth) {
                    this.removeNavig();
                    this.grid.setStyle('left', 0);
                } else {
                    this.updateNavig();
                }
            } else {
                if (this.grid.getDimensions().width > this.containerWidth) {
                    this.addNavig();
                    this.updateNavig();
                }
            }
        }
    },
    removeNavig: function() {
        this.previousBtn.destroy();
        this.nextBtn.destroy();
        this.grid.getElements('li[aria-hidden])').set('aria-hidden', false);
        this.isNavigable = false;
    },
    destroy: function() {
        if (this.intervalId) {
            clearInterval(this.intervalId);
        }
        this.container.removeClass('grille-banner');
        this.grid.removeAttribute('style');
        this.grid.getElements("li a.item-nl").each(function(item) {
            item.removeAttribute('tabindex');
        });
        this.removeNavig();
    },
    addNavig: function() {
        var self = this;
        if (this.isNavigable === false) {
            this.previousBtn = new Element('div', {
                'class': 'item-prec',
                'role': 'button',
                'tabindex': 0,
                html: this.options.previousBtnHtml
            });
            this.previousBtn.addEvent('click', function() {
                if (this.get('aria-disabled') === 'false') {
                    var previousPosition = self.computePreviousPosition();
                    self.slideTo(previousPosition);
                }
            });
            this.previousBtn.addEvent('keydown', function(event) {
                if (event.key === 'enter') {
                    this.fireEvent('click');
                }
            });
            this.previousBtn.inject(this.container, 'top');
            this.nextBtn = new Element('div', {
                'class': 'item-suiv',
                'role': 'button',
                'tabindex': 0,
                html: this.options.nextBtnHtml
            });
            this.nextBtn.addEvent('click', function() {
                if (this.get('aria-disabled') === 'false') {
                    var nextPosition = self.computeNextPosition();
                    self.slideTo(nextPosition);
                }
            });
            this.nextBtn.addEvent('keydown', function(event) {
                if (event.key === 'enter') {
                    this.fireEvent('click');
                }
            });
            this.nextBtn.inject(this.container);
            this.isNavigable = true;
        }
        this.grid.setStyle('left', this.computeListPositionFor(this.grid.getElement('li')));
        this.updateNavig();
    },
    computeListPositionFor: function(item) {
        var posRightLimit = this.container.getDimensions().width - this.nextBtn.getDimensions().width;
        var items = this.grid.getElements('li');
        var lastItem = items[items.length - 1];
        if (this.isItemVisible(item)) {
            return this.getListPosition();
        }
        var newPosition = this.previousBtn.getDimensions().width + 1 - item.getPosition(this.grid).x;
        var newPositionLastItem = lastItem.getPosition(this.grid).x + newPosition;
        if (newPositionLastItem + lastItem.getDimensions().width < posRightLimit) {
            newPosition = -(this.grid.getDimensions().width) + Math.floor(this.container.getDimensions().width) -
                this.nextBtn.getDimensions().width - 1;
        }
        return newPosition;
    },
    isItemVisible: function(item) {
        if (item === null) {
            return true;
        }
        var posLeftLimit = this.container.getPosition().x + this.previousBtn.getDimensions().width;
        var posRightLimit = this.container.getPosition().x + this.container.getDimensions().width -
            this.nextBtn.getDimensions().width;
        return (item.getPosition().x >= posLeftLimit && item.getPosition().x +
            item.getDimensions().width <= posRightLimit);
    },
    computeNextPosition: function() {
        var lastVisible = this.grid.getLast('li[aria-hidden=false]');
        var nextHidden = lastVisible.getNext('li');
        return this.computeListPositionFor(nextHidden);
    },
    computePreviousPosition: function() {
        var item = this.grid.getFirst('li[aria-hidden=false]');
        if (item === null) {
            return this.computeListPositionFor(this.grid.getLast('li'));
        } else {
            var viewportWidth = this.container.getDimensions().width - this.previousBtn.getDimensions().width -
                this.nextBtn.getDimensions().width;
            var newPosition = this.getListPosition() + viewportWidth - (item.getPosition(this.container).x -
                this.previousBtn.getDimensions().width);
            return (newPosition > this.previousBtn.getDimensions().width ? this.previousBtn.getDimensions().width : newPosition);
        }
    },
    getItemWidth: function() {
        return this.grid.getElement('li').getDimensions().width;
    },
    updateNavig: function() {
        var items = this.grid.getElements('li');
        var nbPrev = 0;
        var nbNext = 0;
        var token = false;
        for (var i = 0; i < items.length; i++) {
            if (this.isItemVisible(items[i])) {
                items[i].set('aria-hidden', false);
                token = true;
            } else {
                items[i].set('aria-hidden', true);
                if (token) {
                    nbNext++;
                } else {
                    nbPrev++;
                }
            }
        }
        this.updateIndicator(this.previousBtn, nbPrev);
        this.updateIndicator(this.nextBtn, nbNext);
        if (nbPrev === 0) {
            this.previousBtn.set('title', '');
            this.previousBtn.set('aria-disabled', true);
        } else {
            this.previousBtn.set('title', Grille.getPreviousBtnTitle(nbPrev));
            this.previousBtn.set('aria-disabled', false);
        }
        if (nbNext === 0) {
            this.nextBtn.set('title', '');
            this.nextBtn.set('aria-disabled', true);
        } else {
            this.nextBtn.set('title', Grille.getNextBtnTitle(nbNext));
            this.nextBtn.set('aria-disabled', false);
        }
        this.updateItems();
        this.container.set('aria-busy', false);
    },
    updateItems: function() {
        var items = this.grid.getElements('li[role=option]');
        for (var i = 0; i < items.length; i++) {
            var item = items[i];
            var link = this.getLinkNavigable(item);
            if (this.isItemVisible(item)) {
                item.set('aria-hidden', false);
                if (link) {
                    link.set('tabindex', 0);
                }
            } else {
                item.set('aria-hidden', true);
                if (link) {
                    link.set('tabindex', -1);
                }
            }
        }
        var firstVisible = this.grid.getFirst('li[aria-hidden=false]:not([aria-disabled=true]) .item-nl');
        if (firstVisible !== null) {
            firstVisible.set('tabindex', 0);
        }
    },
    updateIndicator: function(button, num) {
        if (button.getElement('sub') !== null) {
            button.getElement('sub').set('text', num);
        }
    },
    getListPosition: function() {
        return this.grid.getPosition(this.container).x;
    },
    slideTo: function(position) {
        if (this.container.get('aria-busy') === 'false') {
            this.container.set('aria-busy', true);
            var myFx = new Fx.TweenBiblicnam(this.grid, {
                duration: this.options.animationDuration,
                threshold: this.options.threshold,
                transition: Fx.Transitions.Quad.easeInOut,
                property: 'left',
                onComplete: this.updateNavig.bind(this)
            });
            myFx.start(this.getListPosition(), position);
        }
    }
});
Grille.extend({
    components: {},
    init: function(elementId, options) {
        return new Grille(elementId, options);
    },
    initBanner: function(elementId, options) {
        return new Grille.Banner(elementId, options);
    },
    getPreviousBtnTitle: function(num) {
        return num + ' item(s) pr\u00e9c\u00e9dents(s)';
    },
    getNextBtnTitle: function(num) {
        return num + ' item(s) suivant(s)';
    }
});
var InterpageTag = {};
InterpageTag.initFocusableElements = function(conteneurInterpage) {
    return conteneurInterpage.getElements('a[href],a[tabindex]');
};
InterpageTag.findNextFocusableElement = function(anchor) {
    var conteneur = anchor.getParent('.navigation-interpage');
    var focusableElements = InterpageTag.initFocusableElements(conteneur);
    for (var i = 1; i < focusableElements.length; i++) {
        if (focusableElements[i - 1] === anchor) {
            return focusableElements[i];
        }
    }
    if (focusableElements.length > 0) {
        return focusableElements[0];
    }
};
InterpageTag.findPreviousFocusableElement = function(anchor) {
    var conteneur = anchor.getParent('.navigation-interpage');
    var focusableElements = InterpageTag.initFocusableElements(conteneur);
    for (var i = 0; i < focusableElements.length - 1; i++) {
        if (focusableElements[i + 1] === anchor) {
            return focusableElements[i];
        }
    }
    if (focusableElements.length > 0) {
        return focusableElements[focusableElements.length - 1];
    }
};
InterpageTag.initKeyboardEvents = function(idConteneur) {
    $(idConteneur).getElements('.navigation-interpage').each(function(interpage) {
        var focusableElements = InterpageTag.initFocusableElements(interpage);
        for (var i = 0; i < focusableElements.length; i++) {
            focusableElements[i].addEvent('keydown', function(event) {
                switch (event.key) {
                    case 'right':
                        InterpageTag.findNextFocusableElement(this).focus();
                        break;
                    case 'left':
                        InterpageTag.findPreviousFocusableElement(this).focus();
                        break;
                    case 'space':
                        window.location.href = this.href;
                        break;
                    default:
                        break;
                }
            });
            if (!(focusableElements[i].hasClass('suivant') || focusableElements[i].hasClass('precedent') || focusableElements[i].hasClass('courant'))) {
                focusableElements[i].set('tabindex', -1);
            }
        }
    });
};
var Interfiche = new Class({
    element: null,
    pagesize: null,
    current: null,
    items: null,
    interpage: null,
    position: null,
    showMonoPage: true,
    addEvents: function() {
        this.interpage.addEvent('click:relay(a)', this.mouseHandler.bind(this));
        this.interpage.addEvent('keydown', this.keyboardHandler.bind(this));
    },
    getPageSize: function() {
        return this.pagesize;
    },
    destroy: function() {
        var ol = this.interpage.getElement('.navigation-interpage');
        if (ol) {
            ol.destroy();
        }
    },
    construct: function() {
        this.destroy();
        if (this.getLastPageNumber() > 1 || this.showMonoPage) {
            var pagename = new Element('li', {
                id: this.element.id + '_pagename',
                'class': 'pagename',
                text: 'Page'
            });
            ol = new Element('ol', {
                'class': 'navigation-interpage',
                'aria-labelledby': pagename.id
            });
            ol.grab(this.navItem(this.previousButton()));
            ol.grab(pagename);
            this.navList(ol);
            ol.grab(this.navItem(this.nextButton()));
            ol.inject(this.interpage);
            this.interpage.inject(this.element, this.position);
        }
    },
    mouseHandler: function(event, clicked) {
        event.preventDefault();
        if (clicked.hasClass('precedent')) {
            this.previous();
        } else if (clicked.hasClass('suivant')) {
            this.next();
        } else {
            this.page(parseInt(clicked.get('text')));
        }
    },
    keyboardHandler: function(event) {
        switch (event.key) {
            case 'space':
                event.stop();
                this.mouseHandler(event, event.target).bind(this);
                break;
            case 'right':
                event.stop();
                InterpageTag.findNextFocusableElement(event.target).focus();
                break;
            case 'left':
                event.stop();
                InterpageTag.findPreviousFocusableElement(event.target).focus();
                break;
            default:
                break;
        }
    },
    navItem: function(element) {
        var li = new Element('li');
        return li.grab(element);
    },
    navPos: function(position) {
        var pos = new Element('a', {
            'class': 'page'
        });
        if (this.current === position) {
            pos.addClass('courant');
            pos.set('title', position + ': page courante');
            pos.set('tabindex', 0);
        } else {
            pos.set('href', '#');
            pos.set('tabindex', -1);
        }
        pos.set('text', position);
        return this.navItem(pos);
    },
    navList: function(ol) {
        var lastpage = this.getLastPageNumber();
        for (var i = 1; i <= lastpage; i++) {
            if (this.isPosDisplayed(i, lastpage)) {
                ol.grab(this.navPos(i));
                switchEllipsis = true;
            } else if (i < lastpage) {
                if (this.isPosDisplayed(i - 1, lastpage)) {
                    var ellipsis = new Element('span', {
                        html: '&hellip;'
                    });
                    if (this.isBigEllipsis()) {
                        ellipsis.addClass('dbl');
                    }
                    ol.grab(this.navItem(ellipsis));
                }
            }
        }
    },
    isBigEllipsis: function() {
        var lastpage = this.getLastPageNumber();
        return ((lastpage > 5 && this.current > 3) && (lastpage - this.current < 3)) || ((lastpage - this.current > 2) && (this.current < 4));
    },
    isPosDisplayed: function(pPosition, pPositionFin) {
        if (pPosition == 1 || pPosition == pPositionFin) {
            return true;
        }
        if (this.current <= 2 && pPosition < 5) {
            return true;
        } else if (this.current >= pPositionFin - 2) {
            if (pPosition < pPositionFin - 3) {
                return false;
            }
        } else {
            if (pPosition < this.current - 1 || pPosition > this.current + 1) {
                return false;
            }
        }
        return true;
    },
    previousButton: function() {
        if (this.current === 1) {
            return new Element('span', {
                'class': 'precedentinactif'
            });
        } else {
            return new Element('a', {
                'class': 'precedent',
                title: (this.current - 1) + ': page precedente',
                href: '#'
            });
        }
    },
    nextButton: function() {
        if (this.current === this.getLastPageNumber()) {
            return new Element('span', {
                'class': 'suivantinactif'
            });
        } else {
            return new Element('a', {
                'class': 'suivant',
                title: (this.current + 1) + ': page suivante',
                href: '#'
            });
        }
    },
    next: function() {
        this.current++;
        this.construct();
        this.updateList();
    },
    previous: function() {
        this.current--;
        this.construct();
        this.updateList();
    },
    first: function() {
        this.current = 1;
        this.construct();
        this.updateList();
    },
    page: function(page) {
        this.current = page;
        this.construct();
        this.updateList();
    },
    last: function() {
        this.current = this.getLastPageNumber();
        this.construct();
        this.updateList();
    },
    getLastPageNumber: function() {
        var last = Math.ceil(this.items.length / this.getPageSize());
        if ((this.items.length % this.getPageSize()) === 0) {
            last++;
        }
        return last;
    },
    updateList: function() {
        var max = this.current * this.getPageSize();
        var min = max - this.getPageSize();
        for (var i = 0; i < this.items.length; i++) {
            if (i >= min && i < max) {
                this.items[i].removeClass('invisible');
            } else {
                this.items[i].addClass('invisible');
            }
        }
    }
});
Historique = new Class({
    Extends: Interfiche,
    position: 'top',
    initialize: function(element, pagesize) {
        this.element = element;
        this.pagesize = pagesize;
        this.items = this.element.getElements('.histo-list > li');
        this.interpage = new Element('div', {
            'class': 'histo-interfiche',
            role: 'navigation'
        });
        this.addEvents();
        this.first();
    },
    getLastPageNumber: function() {
        var last = Math.ceil(this.items.length / this.pagesize);
        if ((this.items.length % this.pagesize) === 0) {
            last++;
        }
        return last;
    },
    updateList: function() {
        var max = this.current * this.pagesize;
        var min = max - this.pagesize;
        for (var i = 0; i < this.items.length; i++) {
            if (i >= min && i < max) {
                this.items[i].removeClass('invisible');
            } else {
                this.items[i].addClass('invisible');
            }
        }
    }
});
(function() {
    var nTips = 0;
    this.lastTip = {
        set: function(tip, element) {
            this.tip = tip;
            this.element = element;
        },
        getTip: function() {
            return this.tip;
        },
        getElement: function() {
            return this.element;
        }
    };
    this.Tips = new Class({
        Implements: [Events, Options],
        options: {
            id: 'tip',
            onShow: function() {
                this.tip.setStyle('visibility', 'visible');
            },
            onHide: function() {
                this.tip.setStyle('visibility', 'hidden');
            },
            title: 'title',
            text: function(element) {
                return element.get('rel') || element.get('href');
            },
            showDelay: 100,
            hideDelay: 100,
            className: 'tip-wrap',
            offset: {
                x: 16,
                y: 16
            },
            windowPadding: {
                x: 0,
                y: 0
            },
            fixed: false,
            waiAria: true
        },
        handlerEsc: function(event) {
            if (event.type === 'keydown' && event.key === 'esc') {
                var tip = lastTip.getTip(),
                    elem = lastTip.getElement();
                if (tip && elem) {
                    tip.hide(elem);
                }
            }
        },
        initialize: function() {
            var params = Array.link(arguments, {
                options: Type.isObject,
                elements: function(obj) {
                    return obj !== null;
                }
            });
            this.setOptions(params.options);
            nTips = nTips + 1;
            this.container = new Element('div.tip');
            if (this.options.id) {
                this.options.id = this.options.id + nTips;
                this.container.set('id', this.options.id);
            }
            if (params.elements) {
                this.attach(params.elements);
            }
            document.addEvent('keydown', this.handlerEsc);
        },
        toElement: function() {
            if (!this.tip) {
                this.tip = new Element('div', {
                    'class': this.options.className,
                    styles: {
                        position: 'absolute',
                        top: 0,
                        left: 0
                    }
                }).adopt(new Element('div', {
                    'class': 'tip-top'
                }), this.container, new Element('div', {
                    'class': 'tip-bottom'
                }));
            }
            return this.tip;
        },
        attachWaiAria: function() {
            var id = this.options.id,
                tip = this.container;
            tip.set('role', 'tooltip');
            if (!this.waiAria) {
                this.waiAria = {
                    show: function(element) {
                        tip.set('aria-hidden', 'false');
                    },
                    hide: function(element) {
                        tip.set('aria-hidden', 'true');
                    }
                };
            }
        },
        detachWaiAria: function(element) {
            if (this.waiAria) {
                this.container.erase('role');
                this.container.erase('aria-hidden');
                element.erase('aria-describedby');
            }
        },
        read: function(option, element) {
            if (option) {
                if (typeOf(option) === 'function') {
                    return (option(element));
                }
                return element.get(option);
            }
            return '';
        },
        elementSearch: function(elements) {
            if (typeOf(elements) === 'element') {
                return [elements];
            }
            if (typeOf(elements) === 'elements') {
                return elements;
            }
            return $$(elements);
        },
        attach: function(elements) {
            this.elementSearch(elements).each(function(element) {
                var title = this.read(this.options.title, element),
                    text = this.read(this.options.text, element);
                if (!element.retrieve('tip:native') && element.title) {
                    element.store('tip:native', element.title);
                    element.erase('title');
                }
                if (!element.retrieve('tip:text')) {
                    if (text && text !== "") {
                        element.store('tip:text', text);
                    }
                }
                if (!element.retrieve('tip:title')) {
                    if (title && title !== "") {
                        if (!element.retrieve('tip:text')) {
                            element.store('tip:text', title);
                        } else {
                            element.store('tip:title', title);
                        }
                    }
                }
                this.fireEvent('attach', element);
                if (this.options.waiAria) {
                    if (this.options.id) {
                        element.set('aria-describedby', this.options.id);
                    }
                    this.attachWaiAria(element);
                }
                var events = ['enter', 'leave'];
                if (!this.options.fixed) {
                    events.push('move');
                }
                events.each(function(value) {
                    var handler = element.retrieve('tip:' + value);
                    if (!handler) {
                        handler = function(event) {
                            this['element' + value.capitalize()].apply(this, [event, element]);
                        }.bind(this);
                    }
                    element.store('tip:' + value, handler);
                    element.addEvent('mouse' + value, handler);
                    if (value === 'enter') {
                        element.addEvent('focus', handler);
                    }
                    if (value === 'leave') {
                        element.addEvent('blur', handler);
                    }
                }, this);
            }, this);
            return this;
        },
        detach: function(elements) {
            this.elementSearch(elements).each(function(element) {
                ['enter', 'leave', 'move'].each(function(value) {
                    var handler = element.retrieve('tip:' + value);
                    element.removeEvent('mouse' + value, handler);
                    if (value === 'enter') {
                        element.removeEvent('focus', handler);
                    }
                    if (value === 'leave') {
                        element.removeEvent('blur', handler);
                    }
                    element.eliminate('tip:' + value);
                });
                if (lastTip.getElement() === element) {
                    lastTip.set(null, null);
                }
                this.fireEvent('detach', [element]);
                if (this.waiAria) {
                    element.erase('aria-describedby');
                    this.detachWaiAria(element);
                }
                var original = element.retrieve('tip:native');
                if (original && original !== '') {
                    element.set('title', original);
                }
                element.eliminate('tip:native');
                element.eliminate('tip:text');
                element.eliminate('tip:title');
            }, this);
            return this;
        },
        elementEnter: function(event, element) {
            this.container.empty();
            ['title', 'text'].each(function(value) {
                var content = element.retrieve('tip:' + value),
                    div;
                if (content) {
                    div = new Element('div', {
                        'class': 'tip-' + value
                    }).inject(this.container);
                    this.fill(div, content);
                }
            }, this);
            this.position((this.options.fixed || event.type === 'focus') ? {
                page: element.getPosition()
            } : event);
            clearTimeout(this.timerEnter);
            this.timerEnter = (function() {
                this.show(element);
            }).delay(this.options.showDelay, this);
            var lastElem = lastTip.getElement();
            if (lastElem && lastElem !== element) {
                lastTip.getTip().hide(lastElem);
            }
            lastTip.set(this, element);
        },
        elementLeave: function(event, element) {
            clearTimeout(this.timerLeave);
            this.timerLeave = (function() {
                this.hide(element);
            }).delay(this.options.hideDelay, this);
            this.fireForParent(event, element);
        },
        setTitle: function(element, title) {
            if (title && title !== "") {
                element.store('tip:title', title);
            } else {
                element.eliminate('tip:title');
            }
            return this;
        },
        setText: function(element, text) {
            if (text && text !== "") {
                element.store('tip:text', text);
            } else {
                element.eliminate('tip:text');
            }
            return this;
        },
        fireForParent: function(event, element) {
            if (event.type === 'mouseleave') {
                element = element.getParent();
                if (!element || element === document.body) {
                    return;
                }
                if (element.retrieve('tip:enter')) {
                    element.fireEvent('mouseenter', event);
                } else {
                    this.fireForParent(event, element);
                }
            }
        },
        elementMove: function(event, element) {
            this.position(event);
        },
        position: function(event) {
            if (!this.tip) {
                document.id(this);
            }
            var size = window.getSize(),
                scroll = window.getScroll(),
                tip = {
                    x: this.tip.offsetWidth,
                    y: this.tip.offsetHeight
                },
                props = {
                    x: 'left',
                    y: 'top'
                },
                bounds = {
                    y: false,
                    x2: false,
                    y2: false,
                    x: false
                },
                obj = {},
                z;
            for (z in props) {
                obj[props[z]] = event.page[z] + this.options.offset[z];
                bounds[z] = (obj[props[z]] < 0);
                if ((obj[props[z]] + tip[z] - scroll[z]) > size[z] - this.options.windowPadding[z]) {
                    obj[props[z]] = event.page[z] - this.options.offset[z] - tip[z];
                    bounds[z + '2'] = true;
                }
            }
            this.fireEvent('bound', bounds);
            this.tip.setStyles(obj);
        },
        fill: function(element, contents) {
            if (typeof contents === 'string') {
                element.set('html', contents);
            } else {
                element.adopt(contents);
            }
        },
        show: function(element) {
            if (!this.tip) {
                document.id(this);
            }
            if (!this.tip.getParent()) {
                this.tip.inject(document.body);
            }
            this.fireEvent('show', [this.tip, element]);
            if (this.waiAria) {
                this.waiAria.show(element);
            }
        },
        hide: function(element) {
            if (!this.tip) {
                document.id(this);
            }
            this.fireEvent('hide', [this.tip, element]);
            if (this.waiAria) {
                this.waiAria.hide(element);
            }
        }
    });
})();
var Infobulle = {
    create: function(element, separator) {
        var title = element.get('title'),
            titre = "",
            texte = "",
            tabTitle = [];
        if (typeOf(title) !== 'null') {
            texte = title;
            if (typeOf(separator) !== 'null') {
                tabTitle = title.split(separator);
                if (tabTitle.length > 1) {
                    titre = tabTitle[0];
                    texte = title.substring(tabTitle[0].length + separator.length);
                }
            }
            this.tip.attach(element);
            this.tip.setTitle(element, titre);
            this.tip.setText(element, texte);
        }
    },
    createHtml: function(element, elementHtml) {
        var titre = "";
        var texte = "";
        elementHtml.getElements('.info-titre').each(function(el) {
            titre += el.get('html');
        });
        elementHtml.getElements('.info-contenu').each(function(el) {
            texte += el.get('html');
        });
        this.tip.attach(element);
        this.tip.setTitle(element, titre);
        this.tip.setText(element, texte);
    },
    init: function(elements, elementOrSeparator) {
        this.tip = this.tip || new Tips();
        if (typeOf(elementOrSeparator) === 'string' || typeOf(elementOrSeparator) === 'null') {
            if (typeOf(elements) === 'element') {
                this.create(elements, elementOrSeparator);
            } else {
                $$(elements).each(function(element) {
                    this.create(element, elementOrSeparator);
                }, this);
            }
        } else if (typeOf(elementOrSeparator) === 'element') {
            if (typeOf(elements) === 'element') {
                this.createHtml(elements, elementOrSeparator);
            } else {
                $$(elements).each(function(element) {
                    this.createHtml(element, elementOrSeparator);
                }, this);
            }
        }
    }
};
var InterApplicationTag = {};
InterApplicationTag.conteneur = "liens-interapplication";
InterApplicationTag.zlPlaceholder = "Changer d'application\u2026";
InterApplicationTag.zlCssClass = "ia-list";
InterApplicationTag.lienMaxWidth = 0;
InterApplicationTag.listMaxHeight = 190;
InterApplicationTag.mouseOnContainer = false;
InterApplicationTag.bandeauWidth = 270;
InterApplicationTag.afficheListe = function() {
    $(InterApplicationTag.conteneur).getElement('ul').setStyle('display', 'block');
    $(InterApplicationTag.conteneur).getElement('.ia-select-btn').setStyle('visibility', 'hidden');
};
InterApplicationTag.masqueListe = function() {
    $(InterApplicationTag.conteneur).getElement('ul').setStyle('display', 'none');
    $(InterApplicationTag.conteneur).getElement('.ia-select-btn').setStyle('visibility', 'visible');
};
InterApplicationTag.toggleListe = function() {
    if ($(InterApplicationTag.conteneur).getElement('ul').getStyle('display') === 'none') {
        InterApplicationTag.afficheListe();
    } else {
        InterApplicationTag.masqueListe();
    }
};
InterApplicationTag.setListeMaxHeight = function(height) {
    if ($(InterApplicationTag.conteneur).getElement('ul').getSize().y > height) {
        $(InterApplicationTag.conteneur).getElement('ul').setStyle('height', height);
    }
};
InterApplicationTag.initLienMaxWidth = function() {
    var liens = $(InterApplicationTag.conteneur).getElements('ul li a');
    InterApplicationTag.lienMaxWidth = 0;
    for (i = 0; i < liens.length; i++) {
        if (liens[i].getSize().x > InterApplicationTag.lienMaxWidth) {
            InterApplicationTag.lienMaxWidth = liens[i].getSize().x;
        }
    }
};
InterApplicationTag.listeClearHightLight = function() {
    var conteneur = $(InterApplicationTag.conteneur);
    if (conteneur.getElement('.hightlight')) {
        conteneur.getElement('.hightlight').removeClass('hightlight');
    }
};
InterApplicationTag.listeHightLightItem = function(item) {
    item.addClass('hightlight');
};
InterApplicationTag.listePreviousKey = function() {
    var conteneur = $(InterApplicationTag.conteneur);
    var items = conteneur.getElements('.ia-select-dropdown a');
    var previousLink = items[items.length - 1];
    for (i = items.length - 1; i > 0; i--) {
        if (items[i].hasClass('hightlight')) {
            previousLink = items[i - 1];
            break;
        }
    }
    InterApplicationTag.listeClearHightLight();
    InterApplicationTag.listeHightLightItem(previousLink);
    var posCourant = previousLink.getPosition(conteneur.getElement('.ia-select-dropdown')).y;
    var heightCourant = previousLink.getCoordinates().height;
    if (posCourant < 0) {
        conteneur.getElement('.ia-select-dropdown ul').scrollTo(0, conteneur.getElement('.ia-select-dropdown ul').getScroll().y - heightCourant - 2);
    } else if (posCourant + heightCourant > conteneur.getElement('.ia-select-dropdown').getCoordinates().height) {
        conteneur.getElement('.ia-select-dropdown ul').scrollTo(0, posCourant + 2);
    }
};
InterApplicationTag.listeNextKey = function() {
    var conteneur = $(InterApplicationTag.conteneur);
    var items = conteneur.getElements('.ia-select-dropdown a');
    var nextLink = items[0];
    for (i = 0; i < items.length - 1; i++) {
        if (items[i].hasClass('hightlight')) {
            nextLink = items[i + 1];
            break;
        }
    }
    InterApplicationTag.listeClearHightLight();
    InterApplicationTag.listeHightLightItem(nextLink);
    var posCourant = nextLink.getPosition(conteneur.getElement('.ia-select-dropdown')).y;
    var heightCourant = nextLink.getCoordinates().height;
    if (posCourant + heightCourant > conteneur.getElement('.ia-select-dropdown').getCoordinates().height) {
        conteneur.getElement('.ia-select-dropdown ul').scrollTo(0, conteneur.getElement('.ia-select-dropdown ul').getScroll().y + heightCourant + 2);
    } else if (posCourant < 0) {
        conteneur.getElement('.ia-select-dropdown ul').scrollTo(0, posCourant);
    }
};
InterApplicationTag.test_active_click = function(evt) {
    if (evt.target.getParents('#' + InterApplicationTag.conteneur).length) {} else {
        InterApplicationTag.masqueListe();
        InterApplicationTag.listeClearHightLight();
    }
};
InterApplicationTag.listeDeroulanteEvents = function() {
    var zoneListeConteneur = $(InterApplicationTag.conteneur).getElement('.ia-select');
    var liensDropdown = $(InterApplicationTag.conteneur).getElement('.ia-select-dropdown');
    zoneListeConteneur.addEvent('click', function(event) {
        event.preventDefault();
        InterApplicationTag.toggleListe();
        InterApplicationTag.listeNextKey();
        if (Browser.ie6 || Browser.ie7) {
            InterApplicationTag.setListeMaxHeight(InterApplicationTag.listMaxHeight);
        }
        this.focus();
    });
    zoneListeConteneur.addEvent('blur', function() {
        if (!InterApplicationTag.mouseOnContainer) {
            InterApplicationTag.masqueListe();
            InterApplicationTag.listeClearHightLight();
        }
    });
    liensDropdown.addEvent('mouseenter', function(event) {
        InterApplicationTag.mouseOnContainer = true;
    });
    liensDropdown.addEvent('mouseleave', function(event) {
        InterApplicationTag.mouseOnContainer = false;
    });
    zoneListeConteneur.addEvent('keydown', function(event) {
        switch (event.key) {
            case 'down':
                event.preventDefault();
                InterApplicationTag.afficheListe();
                InterApplicationTag.listeNextKey();
                break;
            case 'up':
                event.preventDefault();
                InterApplicationTag.listePreviousKey();
                break;
            default:
                break;
        }
    });
    var liens = liensDropdown.getElements('ul a');
    for (i = 0; i < liens.length; i++) {
        liens[i].addEvent('mouseover', function(event) {
            InterApplicationTag.listeClearHightLight();
            InterApplicationTag.listeHightLightItem(this);
        });
    }
    document.addEvent('click', InterApplicationTag.test_active_click);
};
InterApplicationTag.listeDeroulante = function() {
    InterApplicationTag.initLienMaxWidth();
    $(InterApplicationTag.conteneur).erase('class');
    $(InterApplicationTag.conteneur).set('class', InterApplicationTag.zlCssClass);
    var zoneListe = new Element('span');
    var btn = new Element('span');
    var btnContent = new Element('b');
    var zoneListeConteneur = new Element('a');
    zoneListe.set('text', InterApplicationTag.zlPlaceholder);
    btn.set('class', 'ia-select-btn');
    btnContent.inject(btn);
    zoneListeConteneur.set('class', 'ia-select');
    zoneListeConteneur.set('href', '#');
    zoneListe.inject(zoneListeConteneur);
    btn.inject(zoneListeConteneur);
    zoneListeConteneur.inject($(InterApplicationTag.conteneur));
    var liensDropdown = new Element('div');
    liensDropdown.set('class', 'ia-select-dropdown');
    $(InterApplicationTag.conteneur).getElement('ul').inject(liensDropdown);
    liensDropdown.inject($(InterApplicationTag.conteneur));
    var zlWidth = 0;
    var placeholderWidth = $(InterApplicationTag.conteneur).getElement('.ia-select span').getSize().x - 2;
    if (InterApplicationTag.lienMaxWidth + 12 > placeholderWidth) {
        zlWidth = InterApplicationTag.lienMaxWidth + 12;
    } else {
        zlWidth = placeholderWidth;
    }
    if ((zlWidth > 300) || (zlWidth <= 0)) {
        zlWidth = 300;
    }
    liensDropdown.setStyle('width', zlWidth + 24);
    $(InterApplicationTag.conteneur).getElement('.ia-select').setStyle('width', zlWidth);
    InterApplicationTag.masqueListe();
    $(InterApplicationTag.conteneur).setStyle('visibility', 'visible');
    InterApplicationTag.listeDeroulanteEvents();
};
InterApplicationTag.initBandeauTabIndex = function() {
    var liensImage = $(InterApplicationTag.conteneur).getElements('ul a');
    for (i = 0; i < liensImage.length; i++) {
        if (i < 6) {
            liensImage[i].set('tabindex', '0');
        } else {
            liensImage[i].set('tabindex', '-1');
        }
    }
};
InterApplicationTag.bandeauPreviousKey = function(lien) {
    var conteneur = $(InterApplicationTag.conteneur);
    var items = conteneur.getElements('a[tabindex=0]');
    var previousLink = items[items.length - 1];
    for (i = items.length - 1; i > 0; i--) {
        if (items[i] === lien) {
            previousLink = items[i - 1];
            break;
        }
    }
    previousLink.focus();
};
InterApplicationTag.bandeauNextKey = function(lien) {
    var conteneur = $(InterApplicationTag.conteneur);
    var items = conteneur.getElements('a[tabindex=0]');
    var nextLink = items[0];
    for (i = 0; i < items.length - 1; i++) {
        if (items[i] === lien) {
            nextLink = items[i + 1];
            break;
        }
    }
    nextLink.focus();
};
InterApplicationTag.bandeauKeyEvents = function(event) {
    switch (event.key) {
        case 'space':
            event.preventDefault();
            this.fireEvent('click');
            break;
        case 'right':
            InterApplicationTag.bandeauNextKey(this);
            break;
        case 'left':
            InterApplicationTag.bandeauPreviousKey(this);
            break;
        default:
            break;
    }
};
InterApplicationTag.bandeau = function() {
    var imgList = $(InterApplicationTag.conteneur).getElements('ul li');
    var imgListSize = imgList.length;
    if (imgListSize > 5) {
        $(InterApplicationTag.conteneur).setStyle('width', InterApplicationTag.bandeauWidth);
        $(InterApplicationTag.conteneur).getElement('ul').setStyle('width', InterApplicationTag.bandeauWidth * 2);
    }
    InterApplicationTag.initBandeauTabIndex();
    if (imgListSize > 6) {
        var btnSuivant = new Element('img');
        btnSuivant.set('src', 'biblicnam/images/entete/picto_bandeau_r_bleu.gif');
        var lienBtnSuivant = new Element('a');
        lienBtnSuivant.setAttribute('href', '#');
        lienBtnSuivant.set('id', 'bandeau-suivant');
        lienBtnSuivant.set('tabindex', '0');
        btnSuivant.inject(lienBtnSuivant);
        lienBtnSuivant.inject($(InterApplicationTag.conteneur));
        lienBtnSuivant.addEvent("click", function(event) {
            event.preventDefault();
            var imgList = $(InterApplicationTag.conteneur).getElements('ul li');
            var imgListSize = imgList.length;
            if ((imgListSize > 6) && (imgListSize < 12)) {
                for (i = 0; i < imgListSize; i++) {
                    var liCopie = imgList[i].clone();
                    var lienCopie = liCopie.getElement('a');
                    lienCopie.set('id', 'ia-autogenerated' + i);
                    lienCopie.cloneEvents(imgList[i].getElement('a'));
                    liCopie.inject($(InterApplicationTag.conteneur).getElement('ul'), 'bottom');
                }
            }
            var myFx = new Fx.Tween($(InterApplicationTag.conteneur).getElement('ul'), {
                duration: 2000,
                transition: Fx.Transitions.Quad.easeInOut,
                property: 'left',
                onComplete: function() {
                    for (i = 0; i < 6; i++) {
                        $(InterApplicationTag.conteneur).getElement('ul li').inject($(InterApplicationTag.conteneur).getElement('ul'), 'bottom');
                    }
                    $(InterApplicationTag.conteneur).getElement('ul').setStyle('left', 0);
                    InterApplicationTag.initBandeauTabIndex();
                }
            });
            myFx.start(0, -270);
        });
    }
    var liens = $(InterApplicationTag.conteneur).getElements('a');
    for (i = 0; i < liens.length; i++) {
        liens[i].addEvent('keydown', InterApplicationTag.bandeauKeyEvents.bind(liens[i]));
    }
    $(InterApplicationTag.conteneur).setStyle('visibility', 'visible');
};
OngletTag = new Class({
    element: null,
    initialize: function(element) {
        this.element = element;
        this.element.navigChildsSelector = 'li > a:not([aria-disabled=true])';
        ListNavig.initEvents(this.element);
    }
});
OngletTag.extend({
    components: {},
    waitMessage: '<p>Chargement en cours\u2026</p>',
    errorMessage: 'Erreur lors du chargement des données',
    init: function(element) {
        this.components[element.id] = new OngletTag(element);
    },
    loadContent: function(onglet, contentContainer, params) {
        contentContainer.set('aria-busy', true);
        this.select(onglet);
        contentContainer.set('aria-labelledby', onglet.id);
        contentContainer.set('html', OngletTag.waitMessage);
        contentContainer.set('load', {
            method: 'post',
            async: true,
            data: params,
            onFailure: function() {
                contentContainer.set('text', OngletTag.errorMessage);
            },
            onError: function() {
                contentContainer.set('text', OngletTag.errorMessage);
            }
        });
        contentContainer.load(onglet.get('data-href'));
        contentContainer.set('aria-busy', false);
    },
    select: function(onglet) {
        var onglets = onglet.getParent('.onglets');
        var previousCurrent = onglets.getElement('a[aria-selected=true]');
        if (previousCurrent) {
            previousCurrent.set('aria-selected', false);
            previousCurrent.set('tabindex', -1);
            if (previousCurrent.get('data-href')) {
                previousCurrent.href = previousCurrent.get('data-href');
                previousCurrent.erase('data-href');
            }
            onglet.set('aria-selected', true);
            onglet.set('tabindex', 0);
            onglet.set('data-href', onglet.href);
            onglet.erase('href');
        }
    }
});
DossierTag = new Class({
    Implements: [Options],
    element: null,
    initialize: function(element) {
        this.element = element;
        this.element.navigChildsSelector = 'li > a:not([aria-disabled=true])';
        ListNavig.initEvents(this.element);
        this.addDeleteEvents();
    },
    addDeleteEvents: function() {
        var self = this;
        this.element.getElements('.deletable').each(function(lien) {
            var supprButton = new Element('div', {
                'class': 'delete-btn',
                'role': 'button',
                'tabindex': -1
            });
            supprButton.inject(lien, 'after');
            lien.addEvent('delete', lien.remove = DossierTag.remove.bind(lien), 200);
            supprButton.addEvent('click', function(event) {
                this.fireEvent('delete', event);
            }.bind(lien));
            lien.addEvent('keydown', function(event) {
                if (event.key === 'delete') {
                    this.fireEvent('delete', event);
                }
            }.bind(lien));
        });
    },
    removeContainer: function() {
        this.element.destroy();
    }
});
DossierTag.Navigable = new Class({
    Extends: DossierTag,
    animationDuration: 2000,
    threshold: 300,
    container: null,
    previousBtn: null,
    nextBtn: null,
    listDossier: null,
    containerWidth: null,
    isNavigable: false,
    liveUpdateInterval: 500,
    options: {
        previousBtnHtml: null,
        nextBtnHtml: null
    },
    initialize: function(element, options) {
        this.element = element;
        this.setOptions(options);
        this.container = this.element.getParent('.dossiers-navig');
        this.containerWidth = this.container.getDimensions().width;
        this.listDossier = this.container.getElement('ul');
        this.updateListWidth();
        if (this.element.getDimensions().width > this.container.getDimensions().width) {
            this.addNavig();
            this.element.setStyle('left', this.previousBtn.getDimensions().width);
            this.element.setStyle('left', this.computeListPositionFor(this.getCurrent()));
            this.updateNavig();
            this.element.navigChildsSelector = 'li > a[aria-hidden=false]:not([aria-disabled=true])';
        } else {
            this.element.setStyle('left', 0);
            this.element.navigChildsSelector = 'li > a:not([aria-disabled=true])';
        }
        if (this.liveUpdateInterval > 0) {
            this.checkNavig.periodical(this.liveUpdateInterval, this);
        }
        this.addDeleteEvents();
        this.container.setStyle('visibility', 'visible');
    },
    checkNavig: function(event) {
        if (this.liveUpdateInterval > 0) {
            if (this.container.getDimensions().width !== this.containerWidth || event === 'delete') {
                this.containerWidth = this.container.getDimensions().width;
                if (this.isNavigable) {
                    if (this.element.getDimensions().width <= this.containerWidth) {
                        this.removeNavig();
                        this.element.setStyle('left', 0);
                    } else {
                        var elem = this.container.getElement('a[aria-selected=true]');
                        if (elem !== null) {
                            var current = elem.getParent('li');
                            this.element.setStyle('left', this.computeListPositionFor(current));
                        }
                        this.updateNavig();
                    }
                } else {
                    if (this.element.getDimensions().width > this.containerWidth) {
                        this.addNavig();
                        this.element.setStyle('left', this.computeListPositionFor(this.getCurrent()));
                        this.updateNavig();
                    }
                }
            } else {
                var focusedElement = this.container.getElement(document.activeElement);
                if (focusedElement === null && this.isNavigable) {
                    var elem = this.container.getElement('a[aria-selected=true]');
                    if (elem !== null) {
                        var current = elem.getParent('li');
                        if (!this.isDossierVisible(current)) {
                            this.element.setStyle('left', this.computeListPositionFor(current));
                            this.updateNavig();
                        }
                    }
                }
            }
        }
    },
    removeNavig: function() {
        this.previousBtn.destroy();
        this.nextBtn.destroy();
        this.element.getElements('li a[aria-hidden])').set('aria-hidden', false);
        this.manageTabindex();
        this.isNavigable = false;
    },
    removeContainer: function() {
        this.element.destroy();
        this.container.destroy();
    },
    addNavig: function() {
        var self = this;
        if (this.isNavigable === false) {
            this.previousBtn = new Element('div', {
                'class': 'dossier-prec',
                'role': 'button',
                'tabindex': 0,
                html: this.options.previousBtnHtml
            });
            this.previousBtn.addEvent('click', function() {
                if (this.get('aria-disabled') === 'false') {
                    var previousPosition = self.computePreviousPosition();
                    self.slideTo(previousPosition);
                }
            });
            this.previousBtn.addEvent('keydown', function(event) {
                if (event.key === 'enter') {
                    this.fireEvent('click');
                }
            });
            this.previousBtn.inject(this.container, 'top');
            this.nextBtn = new Element('div', {
                'class': 'dossier-suiv',
                'role': 'button',
                'tabindex': 0,
                html: this.options.nextBtnHtml
            });
            this.nextBtn.addEvent('click', function() {
                if (this.get('aria-disabled') === 'false') {
                    var nextPosition = self.computeNextPosition();
                    self.slideTo(nextPosition);
                }
            });
            this.nextBtn.addEvent('keydown', function(event) {
                if (event.key === 'enter') {
                    this.fireEvent('click');
                }
            });
            this.nextBtn.inject(this.container);
            this.isNavigable = true;
        }
        this.element.setStyle('left', this.computeListPositionFor(this.getCurrent()));
        this.updateNavig();
    },
    updateListWidth: function() {
        var dossiers = this.element.getElements('li');
        var width = 0;
        for (var i = 0; i < dossiers.length; i++) {
            width += dossiers[i].getComputedSize({
                styles: ['padding', 'border', 'margin']
            }).totalWidth;
        }
        this.element.setStyle('width', width);
    },
    isDossierVisible: function(dossier) {
        if (dossier == null) {
            return true;
        }
        var posLeftLimit = this.container.getPosition().x + this.previousBtn.getDimensions().width;
        var posRightLimit = this.container.getPosition().x + this.container.getDimensions().width -
            this.nextBtn.getDimensions().width;
        return (dossier.getPosition().x >= posLeftLimit && dossier.getPosition().x +
            dossier.getDimensions().width < posRightLimit);
    },
    updateNavig: function() {
        var dossiers = this.element.getElements('li');
        var nbPrev = 0;
        var nbNext = 0;
        var token = false;
        for (var i = 0; i < dossiers.length; i++) {
            if (this.isDossierVisible(dossiers[i])) {
                dossiers[i].getElement('a').set('aria-hidden', false);
                token = true;
            } else {
                dossiers[i].getElement('a').set('aria-hidden', true);
                if (token) {
                    nbNext++;
                } else {
                    nbPrev++;
                }
            }
        }
        this.updateIndicator(this.previousBtn, nbPrev);
        this.updateIndicator(this.nextBtn, nbNext);
        if (nbPrev === 0) {
            this.previousBtn.set('title', '');
            this.previousBtn.set('aria-disabled', true);
        } else {
            this.previousBtn.set('title', nbPrev + ' dossier(s) pr\u00e9c\u00e9dents(s)');
            this.previousBtn.set('aria-disabled', false);
        }
        if (nbNext === 0) {
            this.nextBtn.set('title', '');
            this.nextBtn.set('aria-disabled', true);
        } else {
            this.nextBtn.set('title', nbNext + ' dossier(s) suivant(s)');
            this.nextBtn.set('aria-disabled', false);
        }
        this.manageTabindex();
        this.container.set('aria-busy', false);
    },
    manageTabindex: function() {
        this.element.getElements('li a[aria-hidden])').each(function(lien) {
            if (lien.get('aria-hidden') === 'true' || lien.get('aria-disabled') === 'true') {
                lien.set('tabindex', -1);
            } else {
                lien.set('tabindex', 0);
            }
        });
    },
    updateIndicator: function(button, num) {
        if (button.getElement('sub') !== null) {
            button.getElement('sub').set('text', num);
        }
    },
    getListPosition: function() {
        return this.element.getPosition(this.container).x;
    },
    getCurrent: function() {
        var elem = this.element.getElement('li a[aria-selected=true]');
        return (elem) ? elem.getParent('li') : null;
    },
    computeListPositionFor: function(dossier) {
        var posRightLimit = this.container.getDimensions().width - this.nextBtn.getDimensions().width;
        var dossiers = this.element.getElements('li');
        var lastDossier = dossiers[dossiers.length - 1];
        if (this.isDossierVisible(dossier)) {
            return this.getListPosition();
        }
        var newPosition = this.previousBtn.getDimensions().width - dossier.getPosition(this.element).x;
        var newPositionLastDossier = lastDossier.getPosition(this.element).x + newPosition;
        if (newPositionLastDossier + lastDossier.getDimensions().width < posRightLimit) {
            newPosition = -(this.element.getDimensions().width) + this.container.getDimensions().width -
                this.nextBtn.getDimensions().width;
        }
        return newPosition;
    },
    computeNextPosition: function() {
        var lastVisible = this.element.getLast('li a[aria-hidden=false]').getParent('li');
        var nextHidden = lastVisible.getNext('li');
        return this.computeListPositionFor(nextHidden);
    },
    computePreviousPosition: function() {
        var item = this.element.getFirst('li a[aria-hidden=false]');
        if (item === null) {
            return this.computeListPositionFor(this.element.getLast('li a').getParent('li'));
        } else {
            var firstVisible = item.getParent('li');
            var viewportWidth = this.container.getDimensions().width - this.previousBtn.getDimensions().width -
                this.nextBtn.getDimensions().width;
            var newPosition = this.getListPosition() + viewportWidth - (firstVisible.getPosition(this.container).x -
                this.previousBtn.getDimensions().width);
            return (newPosition > this.previousBtn.getDimensions().width ? this.previousBtn.getDimensions().width : newPosition);
        }
    },
    slideTo: function(position) {
        if (this.container.get('aria-busy') === 'false') {
            this.container.set('aria-busy', true);
            var myFx = new Fx.TweenBiblicnam(this.element, {
                duration: this.animationDuration,
                threshold: this.threshold,
                transition: Fx.Transitions.Quad.easeInOut,
                property: 'left',
                onComplete: this.updateNavig.bind(this)
            });
            myFx.start(this.getListPosition(), position);
        }
    }
});
DossierTag.extend({
    components: {},
    waitMessage: '<p>Chargement en cours\u2026</p>',
    errorMessage: 'Erreur lors du chargement des données',
    init: function(element, options) {
        if (element.getParent('.dossiers-navig') === null) {
            this.components[element.id] = new DossierTag(element);
        } else {
            this.components[element.id] = new DossierTag.Navigable(element, options);
        }
    },
    loadContent: function(dossier, contentContainer) {
        contentContainer.set('aria-busy', true);
        this.select(dossier);
        contentContainer.set('aria-labelledby', dossier.id);
        contentContainer.set('html', DossierTag.waitMessage);
        contentContainer.set('load', {
            method: 'post',
            async: true,
            data: 'dossierChoisi=' + dossier.id,
            onFailure: function() {
                contentContainer.set('text', DossierTag.errorMessage);
            },
            onError: function() {
                contentContainer.set('text', DossierTag.errorMessage);
            }
        });
        contentContainer.load(dossier.get('data-href'));
        contentContainer.set('aria-busy', false);
    },
    select: function(dossier) {
        var dossiers = dossier.getParent('.dossiers');
        var previousCurrent = dossiers.getElement('a[aria-selected=true]');
        if (previousCurrent) {
            previousCurrent.set('aria-selected', false);
            previousCurrent.set('tabindex', -1);
            if (previousCurrent.get('data-href')) {
                previousCurrent.href = previousCurrent.get('data-href');
                previousCurrent.erase('data-href');
            }
        }
        dossier.set('aria-selected', true);
        dossier.set('tabindex', 0);
        dossier.set('data-href', dossier.href);
        dossier.erase('href');
    },
    remove: function() {
        var component = DossierTag.components[this.getParent('ul').id];
        this.getParent('li').destroy();
        if (instanceOf(component, DossierTag.Navigable)) {
            component.updateListWidth();
            component.checkNavig('delete');
        }
        if (component.element.getElements('li').length === 0) {
            component.removeContainer();
        }
    }
});
var Progression = new Class({
    Implements: [Options],
    options: {
        timeout: 2000,
        delay: 2000,
        errorMessage: null,
        callback: null
    },
    element: null,
    url: null,
    isError: false,
    isGlobalError: false,
    isComplete: false,
    isRunning: false,
    isRequestRunning: false,
    periodicalFunctionId: null,
    initialize: function(element, url, options) {
        this.setOptions(options);
        this.element = element;
        this.url = url;
        this.start();
    },
    start: function() {
        this.element.removeClass('invisible');
        this.isRunning = true;
        this.checkFunction();
        this.periodicalFunctionId = this.checkFunction.periodical(this.options.delay, this);
    },
    stop: function() {
        clearInterval(this.periodicalFunctionId);
        this.isRunning = false;
        if (this.options.callback !== null) {
            window[this.options.callback].bind(this)();
        }
    },
    checkFunction: function() {
        if (!this.isRequestRunning) {
            var request = new Request.JSON({
                url: this.url,
                async: true,
                timeout: this.options.timeout,
                onSuccess: function(data) {
                    this.isRequestRunning = false;
                    if (!this.isGlobalError) {
                        this.element.set('html', '');
                        this.formatData(data).inject(this.element);
                        if (this.isComplete) {
                            this.stop();
                        }
                    }
                }.bind(this),
                onTimeout: function() {
                    this.isGlobalError = true;
                    this.showGlobalError();
                    this.stop();
                }.bind(this),
                onError: function() {
                    this.isGlobalError = true;
                    this.showGlobalError();
                    this.stop();
                }.bind(this),
                onFailure: function() {
                    this.isGlobalError = true;
                    this.showGlobalError();
                    this.stop();
                }.bind(this)
            });
            this.isRequestRunning = true;
            request.send();
        }
    },
    showGlobalError: function() {
        var error = new Element('p', {
            'class': 'zone-alerte'
        });
        error.set('text', this.options.errorMessage || Progression.errorMessage);
        error.inject(this.element);
        var items = this.element.getElement('ul');
        if (items != null) {
            items.addClass('global-error');
        }
    },
    formatData: function(data) {
        var ul = new Element('ul');
        this.isComplete = true;
        for (var i = 0; i < data.length; i++) {
            this.formatItem(data[i]).inject(ul);
        }
        return ul;
    },
    formatItem: function(bean) {
        var li = new Element('li', {
            'class': 'incomplete'
        });
        if (bean.value >= 100) {
            li.className = 'complete';
        }
        var label = new Element('span', {
            text: bean.text
        });
        if (bean.value < 100 && bean.error === undefined) {
            this.isComplete = false;
        }
        label.inject(li);
        if (bean.error !== undefined) {
            li.className = 'error';
            this.isError = true;
            var errorMessage = new Element('span', {
                'class': 'errormessage',
                text: bean.error
            });
            errorMessage.inject(li);
        }
        return li;
    }
});
Progression.Barre = new Class({
    Extends: Progression,
    initialize: function(element, url, options) {
        this.parent(element, url, options);
    },
    progressNativeSupport: function() {
        if ('position' in document.createElement('progress')) {
            return true;
        }
        return false;
    },
    formatItem: function(bean) {
        var li = new Element('li');
        var progress;
        if (this.progressNativeSupport()) {
            progress = new Element('progress', {
                max: 100
            });
            progress.set('value', bean.value);
            li.set('title', bean.value + '%');
        } else {
            progress = new Element('div', {
                'class': 'progress'
            });
            var pbar = new Element('div', {
                'class': 'pbar'
            });
            pbar.setStyle('width', bean.value + '%');
            pbar.inject(progress);
        }
        li.set('title', bean.value + '%');
        var label = new Element('span', {
            text: bean.text
        });
        if (bean.value < 100 && bean.error === undefined) {
            this.isComplete = false;
        }
        progress.inject(li);
        label.inject(li);
        if (bean.error !== undefined) {
            this.isError = true;
            var errorMessage = new Element('span', {
                'class': 'errormessage',
                text: bean.error
            });
            errorMessage.inject(li);
        }
        return li;
    }
});
Progression.extend({
    components: {},
    errorMessage: 'Une erreur est survenue lors de communication avec le serveur',
    init: function(element, url, options) {
        if (element.hasClass('barre')) {
            this.components[element.id] = new Progression.Barre(element, url, options);
        } else {
            this.components[element.id] = new Progression(element, url, options);
        }
    }
});
var TexteTag = {
    erreurChamp: function(champ, messageErreur) {
        var container = $(champ.id).getParent('.zone_texte');
        var bTagErreur = $(champ.id).getParent('b');
        if (!bTagErreur) {
            bTagErreur = new Element('b');
            $(champ.id).inject(bTagErreur);
            container.addClass('erreur_champ');
            bTagErreur.inject(container, 'top');
        }
        $(champ.id).setProperty('aria-invalid', 'true');
        if ($(champ.id + ChampTag.suffixIdErr) !== null) {
            $(champ.id + ChampTag.suffixIdErr).innerHTML = messageErreur;
            $(champ.id + ChampTag.suffixIdErr).style.display = "inline-block";
        }
    },
    champOK: function(champ) {
        var container = $(champ.id).getParent('.zone_texte');
        var bTagErreur = $(champ.id).getParent('b');
        if (bTagErreur) {
            $(champ.id).inject(container, 'top');
            bTagErreur.destroy();
        }
        $(champ.id).removeProperty('aria-invalid');
        container.removeClass('erreur_champ');
        if ($(champ.id + ChampTag.suffixIdErr) !== null) {
            $(champ.id + ChampTag.suffixIdErr).style.display = "none";
            $(champ.id + ChampTag.suffixIdErr).innerHTML = "";
        }
    },
    effacerFormulaire: function(formid) {
        ChampTag.getForm(formid).getElements('.zone_texte textarea').each(function(champ) {
            TexteTag.champOK(champ);
            champ.value = '';
        });
        TexteTag.majCompteurs(formid);
        return true;
    },
    majCompteurs: function(formid) {
        ChampTag.getForm(formid).getElements('.zone_texte textarea').each(function(champ) {
            if ($(champ).textChars) {
                $(champ).textChars.updateText();
            }
            if ($(champ).textRows) {
                $(champ).textRows.updateText();
            }
        });
        return true;
    }
};
var TextUtil = new Class({
    isOnInputSupported: function(elem) {
        return 'oninput' in document.createElement(elem.type);
    },
    isOnPropertyChangeSupported: function(elem) {
        return 'onpropertychange' in document.createElement(elem.type);
    },
    isOnPasteSupported: function(elem) {
        return 'onpaste' in document.createElement(elem.type);
    },
    isOnDropSupported: function(elem) {
        return 'ondrop' in document.createElement(elem.type);
    },
    getSelection: function(elem) {
        var s = {
            start: 0,
            end: 0
        };
        if (document.activeElement !== elem) {
            elem.focus();
        }
        if (typeof elem.selectionStart === "number" && typeof elem.selectionEnd === "number") {
            s.start = elem.selectionStart;
            s.end = elem.selectionEnd;
        } else if (document.selection) {
            var bookmark = document.selection.createRange().getBookmark();
            var sel = elem.createTextRange();
            var bfr = sel.duplicate();
            sel.moveToBookmark(bookmark);
            bfr.setEndPoint("EndToStart", sel);
            s.start = bfr.text.length;
            s.end = s.start + sel.text.length;
        }
        return s;
    },
    offsetToRangeCharacterMove: function(el, offset) {
        return offset - (el.value.slice(0, offset).split("\r\n").length - 1);
    },
    setSelection: function(elem, start, end) {
        var range = elem.createTextRange();
        var startCharMove = this.offsetToRangeCharacterMove(elem, start);
        range.collapse(true);
        if (start === end) {
            range.move("character", startCharMove);
        } else {
            range.moveEnd("character", this.offsetToRangeCharacterMove(elem, end));
            range.moveStart("character", startCharMove);
        }
        range.select();
    },
    inputEvent: function(elem, fnEvent) {
        if (this.isOnInputSupported(elem)) {
            elem.addEvent('input', fnEvent);
        } else if (this.isOnPropertyChangeSupported(elem)) {
            elem.addEvent('propertychange', fnEvent);
        }
    }
});
var TextMaxlength = new Class({
    Extends: TextUtil,
    initialize: function(element) {
        this.element = element;
        var max = parseInt(element.getProperty("maxlength"));
        this.maxlength = (isNaN(max)) ? 0 : max;
        this.lastValue = element.value;
        this.data = {
            value: "",
            type: ""
        };
        if (this.maxlength > 0 && !this.isMaxlengthSupported(element)) {
            this.element.maxlength = this.maxlength;
            element.addEvent('keypress', this.maxlengthKeypress.bind(this));
            if (this.isOnPasteSupported(element)) {
                element.addEvent('paste', this.maxlengthPaste.bind(this));
            }
            if (this.isOnDropSupported(element)) {
                if (element.attachEvent && !element.addEventListener) {
                    element.addEvent('focus', this.maxlengthEvent.bind(this));
                } else {
                    element.addEventListener("drop", this.maxlengthEvent.bind(this), false);
                }
            }
            this.inputEvent(element, this.maxlengthEvent.bind(this));
        }
    },
    isMaxlengthSupported: function(elem) {
        if (elem.type === 'textarea') {
            return ('maxLength' in document.createElement(elem.type)) && (Browser.name !== 'ie' || Browser.version > 9);
        } else {
            return 'maxLength' in document.createElement(elem.type);
        }
    },
    setData: function(value, type) {
        this.data.value = value;
        this.data.type = type;
    },
    maxlengthKeypress: function(event) {
        var elem = event.target;
        if (document.activeElement === elem && !this.isMaxlengthSupported(elem)) {
            if (elem.value.length >= this.maxlength) {
                event.stop();
            }
            this.lastValue = elem.value;
        }
    },
    maxlengthPaste: function(event) {
        var clp = (event.clipboardData || window.clipboardData);
        if (typeOf(clp) !== 'null') {
            this.setData(clp.getData("text") || "", event.type);
            var elem = event.target;
            event.preventDefault();
            if (this.data.value.length > 0) {
                var posit = this.getSelection(elem);
                var textLeft = elem.value.substr(0, posit.start);
                var textRight = elem.value.substr(posit.end, elem.value.length);
                var calcLength = this.maxlength - textLeft.length - textRight.length;
                if (calcLength > 0) {
                    var text = this.data.value.substr(0, calcLength);
                    this.lastValue = textLeft + text + textRight;
                    elem.value = textLeft + text + textRight;
                } else {
                    elem.value = this.lastValue;
                }
                this.setData("", "");
                this.setSelection.delay(20, this, [elem, posit.start, posit.end]);
            }
        }
    },
    maxlengthDrop: function(event) {
        var data = event.dataTransfer;
        if (typeOf(data) === 'null') {
            this.setData("", event.type);
        } else {
            this.setData(data.getData("text"), event.type);
        }
    },
    maxlengthEvent: function(event) {
        var elem = event.target;
        if (this.lastValue !== elem.value) {
            if (elem.value.length <= this.maxlength || this.lastValue.length >= elem.value.length) {
                this.lastValue = elem.value;
                this.setData("", "");
            } else if (this.data.value.length > 0) {
                var posit = this.getSelection(elem);
                if (posit.start === posit.end) {
                    posit.start = posit.end - this.data.value.length;
                }
                var textLeft = elem.value.substr(0, posit.start);
                var textRight = elem.value.substr(posit.end, elem.value.length);
                var calcLength = this.maxlength - textLeft.length - textRight.length;
                if (calcLength > 0) {
                    var text = this.data.value.substr(0, calcLength);
                    this.lastValue = textLeft + text + textRight;
                    elem.value = textLeft + text + textRight;
                    posit.start = textLeft.length;
                    posit.end = textLeft.length + text.length;
                    if (this.data.type === 'drop') {
                        posit.start = textLeft.length;
                        posit.end = textLeft.length + text.length;
                    } else {
                        posit.start = posit.end = textLeft.length + text.length;
                    }
                } else {
                    elem.value = this.lastValue;
                    posit.end = posit.start;
                }
                this.setData("", "");
                this.setSelection.delay(20, this, [elem, posit.start, posit.end]);
            } else {
                if (elem.value.charAt(this.maxlength) === '\n') {
                    this.lastValue = elem.value.substr(0, this.maxlength + 1);
                } else {
                    this.lastValue = elem.value.substr(0, this.maxlength);
                }
                this.setData("", "");
                elem.value = this.lastValue;
            }
        }
    },
});
var TextTrim = new Class({
    Extends: TextUtil,
    Implements: [Options],
    options: {
        trim: 'none'
    },
    initialize: function(element, options) {
        this.element = element;
        this.setOptions(options);
        this.lastValue = element.value;
        if (this.options.trim === 'left' || this.options.trim === 'right' || this.options.trim === 'both') {
            element.addEvent('keypress', this.trimKeypress.bind(this));
            this.inputEvent(element, this.trimInput.bind(this));
            element.addEvent('focus', this.trimFocusBlur.bind(this));
            element.addEvent('blur', this.trimFocusBlur.bind(this));
        }
    },
    trimLeft: function(text) {
        var i;
        for (i = 0; i < text.length && text.charCodeAt(i) <= 32; i++) {}
        return (i > 0) ? text.substr(i) : text;
    },
    trimRight: function(text) {
        var j;
        for (j = text.length - 1; j >= 0 && text.charCodeAt(j) <= 32; j--) {}
        return (j < 0) ? "" : text.substr(0, j + 1);
    },
    trimBoth: function(text) {
        return this.trimLeft(this.trimRight(text));
    },
    trimKeypress: function(event) {
        var elem = event.target;
        if (document.activeElement === elem) {
            var s = this.getSelection(elem);
            if ((this.options.trim === 'left' || this.options.trim === 'both') && (s.start === 0 && event.code <= 32 && event.key !== 'backspace' && event.key !== 'tab')) {
                event.stop();
            }
            this.lastValue = elem.value;
        }
    },
    trimInput: function(event) {
        var elem = event.target;
        if (this.lastValue !== elem.value && (this.options.trim === 'left' || this.options.trim === 'both')) {
            this.lastValue = this.trimLeft(elem.value);
            if (this.lastValue !== elem.value) {
                elem.value = this.lastValue;
            }
        }
    },
    trimFocusBlur: function(event) {
        var elem = event.target;
        if (this.options.trim === 'left') {
            this.lastValue = this.trimLeft(elem.value);
        } else if (this.options.trim === 'right') {
            this.lastValue = this.trimRight(elem.value);
        } else if (this.options.trim === 'both') {
            this.lastValue = this.trimBoth(elem.value);
        }
        if (this.lastValue !== elem.value) {
            elem.value = this.lastValue;
        }
    }
});
var TextCounter = new Class({
    Extends: TextUtil,
    Implements: [Options],
    options: {
        max: 0,
        rowLength: 0,
        infoText: null,
        tabChars: 8,
        rowCut: 'char'
    },
    textarea: null,
    spanLabel: null,
    classLabel: null,
    classCount: null,
    infoText: "",
    maxText: "",
    initialize: function(element, options) {
        var container;
        this.setOptions(options);
        if (this.options.max > 0) {
            if (this.options.infoText !== null) {
                this.maxText = this.options.infoText;
            }
        } else {
            if (this.options.infoText !== null) {
                this.infoText = this.options.infoText;
            }
        }
        this.htmlInfo = '<span class="' + this.classCount + '">{1}</span>';
        this.element = element;
        container = element.getParent('.zone_texte');
        if (container.getElement('.' + this.classLabel)) {
            this.spanLabel = container.getElement('.' + this.classLabel);
        } else {
            this.spanLabel = new Element('span', {
                'class': this.classLabel
            });
            this.spanLabel.inject(container);
        }
        element.addEvent('keypress', this.updateText.bind(this));
        this.inputEvent(element, this.updateText.bind(this));
        element.addEvent('focus', this.updateText.bind(this));
        element.addEvent('blur', this.updateText.bind(this));
        if (Browser.name === 'ie' && Browser.version === 9) {
            element.addEvent('focus', this.onFocusChange.bind(this));
            element.addEvent('blur', this.onFocusChange.bind(this));
        }
        this.updateText();
    },
    calcNewCount: function(text) {
        return 0;
    },
    onFocusChange: function(event) {
        if (event.type === "focus") {
            document.addEventListener("selectionchange", this.updateText.bind(this), false);
        } else {
            document.removeEventListener("selectionchange", this.updateText.bind(this), false);
        }
    },
    updateText: function(event) {
        var newText;
        var formatCount;
        var infoCpl;
        var text = this.element.value;
        if (event && event.type === "keypress" && (event.key === "space" || event.key === "enter" || event.key === "tab" || event.key.length === 1) && text.length < this.element.maxlength) {
            text = text + String.fromCharCode(event.code);
        }
        var count = this.calcNewCount(text);
        if (this.options.max > 0) {
            newText = this.htmlInfo + '/{2} ';
            if (count > this.options.max) {
                formatCount = '<b>' + count + '</b>';
            } else {
                formatCount = count;
            }
            infoCpl = this.maxText.split("|");
            if (infoCpl.length === 1) {
                infoCpl.push(infoCpl[0]);
            }
            newText = MessageFormat.pluralFormat(newText + infoCpl[0], newText + infoCpl[1], count, formatCount, this.options.max);
        } else {
            infoCpl = this.infoText.split("|");
            if (infoCpl.length === 1) {
                infoCpl.push(infoCpl[0]);
            }
            newText = this.htmlInfo + ' ';
            newText = MessageFormat.pluralFormat(newText + infoCpl[0], newText + infoCpl[1], count, count);
        }
        this.spanLabel.set('html', newText);
        return count;
    }
});
var TextChars = new Class({
    Extends: TextCounter,
    classCount: 'nbcars',
    classLabel: 'maxcars',
    infoText: 'caractère saisi|caractères saisis',
    maxText: 'caractères max.|caractères. max.',
    initialize: function(element, options) {
        this.parent(element, options);
    },
    calcNewCount: function(text) {
        return text.length;
    }
});
var TextRows = new Class({
    Extends: TextCounter,
    classCount: 'nblignes',
    classLabel: 'maxlignes',
    infoText: 'ligne saisie|lignes saisies',
    maxText: 'lignes max.|lignes max.',
    initialize: function(element, options) {
        this.parent(element, options);
    },
    isCutChar: function(car) {
        return car === ' ' || car === '\t' || car === '\n';
    },
    calcNewCount: function(text) {
        if (this.options.rowLength > 0) {
            return this.calcNbRowsFixedCols(text);
        } else {
            return this.calcNbRowsLegacy(text);
        }
    },
    calcNbRowsLegacy: function(text) {
        var nbligne = 0;
        var nbcars = 0;
        var textLength = text.length;
        for (var i = 0; i < text.length; i++) {
            if (text.charAt(i) === '\r' || text.charAt(i) === '\n') {
                if (nbcars === 0) {
                    nbligne++;
                }
                if (i < textLength - 1 && text.charAt(i) === '\r' && text.charAt(i + 1) === '\n') {
                    i++;
                }
                nbcars = 0;
            } else {
                if (nbcars === 0) {
                    nbligne++;
                }
                nbcars++;
            }
        }
        return nbligne;
    },
    calcNbRowsFixedCols: function(text) {
        var nbligne = 0;
        var nbcars = 0;
        var textLength = text.length;
        for (var i = 0; i < textLength; i++) {
            if (text.charAt(i) === '\r' || text.charAt(i) === '\n') {
                if (nbcars === 0) {
                    nbligne++;
                }
                if (i < textLength - 1 && text.charAt(i) === '\r' && text.charAt(i + 1) === '\n') {
                    i++;
                }
                nbcars = 0;
            } else {
                if (nbcars === 0) {
                    nbligne++;
                }
                if (text.charAt(i) === '\t') {
                    nbcars = nbcars + this.options.tabChars;
                } else {
                    nbcars++;
                }
                if (nbcars > this.options.rowLength) {
                    nbligne++;
                    if (this.options.rowCut === 'char') {
                        if (text.charAt(i) === '\t') {
                            nbcars = this.options.tabChars;
                        } else {
                            nbcars = 1;
                        }
                    } else {
                        if (this.isCutChar(text.charAt(i))) {
                            if (text.charAt(i) === '\t') {
                                nbcars = this.options.tabChars;
                            } else {
                                nbcars = 1;
                            }
                        } else {
                            var j;
                            for (j = i - 1; j >= 0 && !this.isCutChar(text.charAt(j)); j--) {}
                            nbcars = i - j;
                        }
                    }
                }
            }
        }
        return nbligne;
    }
});
var ZoneMessage = {
    afficherMessage: function(zone, message) {
        document.getElementById(zone).className = "zone-message";
        document.getElementById(zone).innerHTML = message;
    },
    afficherErreur: function(zone, message) {
        document.getElementById(zone).className = "zone-alerte";
        document.getElementById(zone).innerHTML = message;
    },
    afficherAttente: function(zone, type, message) {
        document.getElementById(zone).className = "zone-attente";
        if (type === "roue") {
            document.getElementById(zone).innerHTML = "<img alt='Traitement en cours, veuillez patienter ...' " + "title='Traitement en cours, veuillez patienter ...' " + "src='biblicnam/images/zoneMessage/roue-tempo.gif' />";
        } else {
            document.getElementById(zone).innerHTML = "<img alt='Traitement en cours, veuillez patienter ...' " + "title='Traitement en cours, veuillez patienter ...' " + "src='biblicnam/images/zoneMessage/barre-progress-rapide.gif' />";
        }
        if (message !== null && message !== "") {
            document.getElementById(zone).innerHTML += message;
        }
    },
    effacerMessage: function(zone) {
        document.getElementById(zone).innerHTML = "";
        document.getElementById(zone).className = "invisible";
    }
};
var MODE_PAIEMENTS = [];
var NOM_PREFIX_DIV_CHOIX = "dbc_section_types_choix_";
var NOM_PREFIX_DIV_COORD = "dbc_section_coord_";
var MODE_PAIEMENT_SEPARATEUR;

function MODE_PAIEMENT(codeModePaiement, typesCoordonneeBancaire) {
    this.codeModePaiement = codeModePaiement;
    this.typesCoordonneeBancaire = typesCoordonneeBancaire;
}

function changerVisibilite(idElement, visible) {
    var eltDiv = document.getElementById(idElement);
    if (eltDiv !== null) {
        if (visible !== true) {
            eltDiv.style.display = 'none';
        } else {
            if (idElement.indexOf("idTypeCoordonneeBancaire") > -1) {
                eltDiv.style.display = 'inline-block';
            } else {
                eltDiv.style.display = 'block';
            }
        }
    }
}

function afficherElement(idElement) {
    changerVisibilite(idElement, true);
}

function cacherElement(idElement) {
    changerVisibilite(idElement, false);
}

function idTypesCoordonneeBancaire(valCodeModePaiement) {
    var result = 'idTypeCoordonneeBancaire' + valCodeModePaiement;
    return result;
}

function nomDivSectionChoix(valCodeModePaiement) {
    var result = NOM_PREFIX_DIV_CHOIX + valCodeModePaiement;
    return result;
}

function nomDivSectionCoord(valCodeTypeCoordonneeBancaire) {
    var result = NOM_PREFIX_DIV_COORD + valCodeTypeCoordonneeBancaire;
    return result;
}

function recupererModePaiementsForm() {
    var forms = document.forms;
    var result = null;
    var testPresent = false;
    for (i = 0; i < forms.length; i++) {
        try {
            testPresent = (forms[i].codeModePaiement !== undefined);
        } catch (e) {
            testPresent = false;
        }
        if (testPresent) {
            result = forms[i];
            break;
        }
    }
    return result;
}

function recupererCodeModePaiement(form) {
    var eltCodeMP = form.codeModePaiement;
    var eltMPOptions = eltCodeMP.options;
    var testTypeSelect = false;
    var codeMPSelected = "";
    try {
        var eltCodeMPOptions = eltCodeMP.options;
        testTypeSelect = ((eltCodeMPOptions !== null) && (eltCodeMPOptions !== undefined));
    } catch (e) {
        testTypeSelect = false;
    }
    if (testTypeSelect) {
        for (i = 0; i < eltMPOptions.length; i++) {
            if (eltMPOptions[i].selected === true) {
                codeMPSelected = eltMPOptions[i].value;
                break;
            }
        }
    } else {
        codeMPSelected = eltCodeMP.value;
    }
    return codeMPSelected;
}

function changerAffichage() {
    var form = recupererModePaiementsForm();
    if (form !== null) {
        var codeMPSelected = recupererCodeModePaiement(form);
        var nomFieldset;
        for (i = 0; i < MODE_PAIEMENTS.length; i++) {
            var valCodeMP = MODE_PAIEMENTS[i].codeModePaiement;
            cacherElement(nomDivSectionChoix(valCodeMP));
            cacherElement('idTypeCoordonneeBancaire' + valCodeMP);
            cacherElement('idTypeCoordonneeBancaire' + valCodeMP + '_label');
            for (j = 0; j < MODE_PAIEMENTS[i].typesCoordonneeBancaire.length; j++) {
                nomFieldset = nomDivSectionCoord(MODE_PAIEMENTS[i].typesCoordonneeBancaire[j]).replace("+", "");
                cacherElement("formulaire" + nomFieldset);
                cacherElement("consultation" + nomFieldset);
                $("formulaire" + nomFieldset).setProperty('aria-expanded', 'false');
            }
        }
        if ($('idTypeCoordonneeBancaire' + codeMPSelected) === null) {
            return;
        }
        if ($('idTypeCoordonneeBancaire' + codeMPSelected).getElements('option').length !== 0) {
            afficherElement('idTypeCoordonneeBancaire' + codeMPSelected + '_label');
            afficherElement('idTypeCoordonneeBancaire' + codeMPSelected);
        }
        var eltTC = document.getElementById(idTypesCoordonneeBancaire(codeMPSelected));
        var eltTCOptions = eltTC.options;
        var codeTCSelected = "";
        for (i = 0; i < eltTCOptions.length; i++) {
            if (eltTCOptions[i].selected === true) {
                codeTCSelected = eltTCOptions[i].value;
                break;
            }
        }
        if ((eltTCOptions !== null) && (eltTCOptions.length > 1)) {
            afficherElement(nomDivSectionChoix(codeMPSelected));
        }
        if (codeTCSelected === "") {
            eltTCOptions.seletedIndex = 0;
            codeTCSelected = eltTCOptions[0].value;
        }
        nomFieldset = nomDivSectionCoord(codeTCSelected.replace("+", ""));
        afficherElement("formulaire" + nomFieldset);
        afficherElement("consultation" + nomFieldset);
        $("formulaire" + nomFieldset).setProperty('aria-expanded', 'true');
        form.codeTypeCoordonneeBancaire.value = codeTCSelected.replace("+", "");
    }
}
var keyDownField;

function autoJump_keyDown() {
    if (this !== keyDownField) {
        this.beforeLength = this.value.length;
        keyDownField = this;
    }
}

function autoJump_keyUp() {
    if ((this === keyDownField) && (this.value.length > this.beforeLength) && (this.value.length >= this.maxLength)) {
        this.nextField.focus();
        this.nextField.select();
    }
    keyDownField = null;
}
var Domiciliation = {};
Domiciliation.autoUpperCase = function() {
    this.value = this.value.toUpperCase();
};
Domiciliation.addEventAutoUpperCase = function(champList) {
    for (i = 0; i < champList.length - 1; i++) {
        var champId = champList[i];
        if ($(champId)) {
            $(champId).addEvent('blur', Domiciliation.autoUpperCase);
        }
    }
};
Domiciliation.addEventAutoJump = function autoJump(fieldId, nextFieldId) {
    if ($(fieldId)) {
        $(fieldId).nextField = $(nextFieldId);
        if ($(fieldId).maxLength !== null) {
            $(fieldId).addEvent('keydown', autoJump_keyDown);
            $(fieldId).addEvent('keyup', autoJump_keyUp);
        }
    }
};

function postAction(action, formObject) {
    if (action !== null) {
        formObject.action = action;
        if (typeof Placeholders !== 'undefined') {
            Placeholders.disable(formObject);
        }
        formObject.submit();
    }
}

function setAction(url, form) {
    var formObject = document.forms[0];
    if (form !== null && form !== '') {
        formObject = ChampTag.getForm(form);
    }
    if (formObject !== null) {
        postAction(url, formObject);
    } else {
        window.location = url;
    }
}

function checkALL(form, name, nameParent) {
    var formObject = document.forms[0];
    if (form !== null && form !== '' && (document.forms[form] !== null)) {
        formObject = document.forms[form];
    }
    var state = formObject.elements[nameParent].checked;
    for (i = formObject.elements.length - 1; i >= 0; i--) {
        var elm = formObject.elements[i];
        if ((elm.type === 'checkbox') && (elm.name === name)) {
            elm.checked = state;
        }
    }
}

function setReset(form) {
    var formObject = document.forms[0];
    if ((form !== null) && (form !== '') && (document.forms[form] !== null)) {
        formObject = document.forms[form];
    }
    for (i = formObject.elements.length - 1; i >= 0; i--) {
        var elm = formObject.elements[i];
        if ((elm.type === 'text') && (elm.name !== '') && (elm.name.match("-f$") === "-f")) {
            formObject.elements[i].value = '';
        }
        if ((elm.type === 'select-one') && (elm.name.match("-f$") === "-f")) {
            elm.options[elm.length - 1].selected = true;
        }
    }
}

function changeAllSelect(nomSelect, selectElm) {
    var elements = document.getElementsByName(nomSelect);
    for (i = elements.length - 1; i >= 0; i--) {
        elements[i].selectedIndex = selectElm;
    }
}

function openPopUpSimple(titre, url, height, width) {
    if (height !== undefined) {
        config = "height=" + height;
    } else {
        config = "height=550";
        height = 550;
    }
    if (width !== undefined) {
        config += ", width=" + width;
    } else {
        config += ", width=700";
        width = 700;
    }
    var H = (screen.height - height) / 2;
    var W = (screen.width - width) / 2;
    popup = window.open(url, titre, config + ',scrollbars=1,resizable=0,locationbar=no,left=' + W + ',top=' + H);
}
var TableTag = {
    checkAllSelector: 'input[name$="-ct"]',
    checkboxesSelector: 'input[name$="-c"]',
    formFieldsSuffix: ["-f", "-f1", "-f2", "-z", "c", "r", "-ct", "-restore", "-filter"]
};
TableTag.cleanParameters = function(href) {
    var cleanHref = href;
    if (href !== null) {
        var url = href.split("?");
        if (url.length <= 1) {
            return href;
        }
        cleanHref = href.split("?")[0];
        var parameters = href.split("?")[1].split("&");
        cleanHref += "?";
        for (var i = 0; i < parameters.length; i++) {
            var parametre = parameters[i];
            if (parametre !== null) {
                var isFormField = false;
                for (var j = 0;
                    (j < TableTag.formFieldsSuffix.length) && !isFormField; j++) {
                    if (parameters[i].indexOf(TableTag.formFieldsSuffix[j] + "=") !== -1) {
                        isFormField = true;
                    }
                }
                if (!isFormField) {
                    cleanHref += parameters[i] + "&";
                }
            }
        }
        cleanHref = cleanHref.substr(0, cleanHref.length - 1);
    }
    return cleanHref;
};
TableTag.updateHref = function(href, formId) {
    if (href === null) {
        return "";
    } else {
        return "javascript:setAction('" + TableTag.cleanParameters(href) + "','" + formId + "');";
    }
};
TableTag.updateLinks = function(formId, tabUid) {
    var form = ChampTag.getForm(formId);
    if (form) {
        var table = form.getElement("#" + tabUid);
        var interpage = table.getParent('.tab-body').getPrevious('.tab-interpage');
        var interpagebas = table.getParent('.tab-body').getNext('.tab-interpagebas');
        var interpages = [interpage, interpagebas];
        for (var i = 0; i < interpages.length; i++) {
            if (interpages[i]) {
                interpages[i].getElements('a').each(function(anchor) {
                    if (!anchor.hasClass('precedentinactif') && !anchor.hasClass('suivantinactif') && !anchor.hasClass('courant')) {
                        var oldhref = anchor.getProperty('href');
                        anchor.setProperty('href', TableTag.updateHref(oldhref, formId));
                    }
                });
            }
        }
        var thead = table.getElement('thead');
        if (thead) {
            thead.getElements('.triable a').each(function(anchor) {
                var oldhref = anchor.getProperty('href');
                anchor.setProperty('href', TableTag.updateHref(oldhref, formId));
            });
        }
    }
};
TableTag.updatePaging = function(formId, tabUid, baseHref) {
    var form = ChampTag.getForm(formId);
    if (form) {
        var table = form.getElement("#" + tabUid);
        var divPaginationHaut = table.getParent('.tab-body').getPrevious('.tab-interpage');
        var divPaginationBas = table.getParent('.tab-body').getNext('.tab-interpagebas');
        if (divPaginationHaut && divPaginationHaut.getElement('.pagination')) {
            divPaginationHaut.getElement('button').destroy();
            divPaginationHaut.getElement('select').addEvent('change', function() {
                if (divPaginationBas) {
                    divPaginationBas.getElement('select').selectedIndex = this.selectedIndex;
                }
                eval(TableTag.updateHref(baseHref, formId));
            });
        }
        if (divPaginationBas && divPaginationBas.getElement('.pagination')) {
            divPaginationBas.getElement('button').destroy();
            divPaginationBas.getElement('select').addEvent('change', function() {
                if (divPaginationHaut) {
                    divPaginationHaut.getElement('select').selectedIndex = this.selectedIndex;
                }
                eval(TableTag.updateHref(baseHref, formId));
            });
        }
    }
};
TableTag.updateRowHref = function(tabUid) {
    var table = $(tabUid);
    if (table) {
        table.getElements('tr.trClickable').each(function(row) {
            var onclickValue = row.getProperty('data-onclick');
            if (onclickValue !== null) {
                row.removeProperty('data-onclick');
                row.getElements('td').each(function(cell) {
                    var isLoupeSansHref = cell.hasClass('pictogramme') && cell.getElement('a.vue-detail') !== null && cell.getElement('a.vue-detail').getProperty('href') === null;
                    if ((!cell.hasClass('pictogramme') && cell.getElement('a') === null) || isLoupeSansHref) {
                        cell.addEvent('click', function() {
                            if (onclickValue.indexOf('(') === -1) {
                                window.location = onclickValue;
                            } else {
                                eval(onclickValue);
                            }
                        });
                    }
                });
            }
        });
    }
};
TableTag.updateCheckAll = function(checkAll, checkboxes) {
    var checked = true;
    if (checkboxes.length > 0) {
        checkboxes.each(function(checkbox) {
            if (!checkbox.checked) {
                checked = false;
            }
        });
        checkAll.set('checked', checked);
    }
};
TableTag.addCheckEvents = function(checkAll, checkboxes) {
    checkAll.addEvent("click", function(event) {
        checkboxes.set('checked', this.checked);
    });
    checkboxes.addEvent("click", function(event) {
        TableTag.updateCheckAll(checkAll, checkboxes);
    });
};
TableTag.init = function(formName, tabUid, baseHref) {
    var table = $(tabUid);
    TableTag.updatePaging(formName, tabUid, baseHref);
    TableTag.updateLinks(formName, tabUid);
    TableTag.updateRowHref(tabUid);
    if (table) {
        var checkAll = table.getElement(TableTag.checkAllSelector);
        var checkboxes = table.getElements(TableTag.checkboxesSelector);
        if (checkAll) {
            TableTag.addCheckEvents(checkAll, checkboxes);
            TableTag.updateCheckAll(checkAll, checkboxes);
        }
    }
};

function getLinkFrom(bouton) {
    var lienBouton = new Element('a');
    lienBouton.set('id', bouton.get('id'));
    lienBouton.set('class', bouton.get('class'));
    lienBouton.store('oldButton', bouton.clone());
    bouton.getChildren().inject(lienBouton);
    lienBouton.addEvent('click', function() {
        var oldButton = this.retrieve('oldButton');
        oldButton.setStyle('display', 'none');
        oldButton.inject(this);
        this.getParent('form').submit();
    });
    return lienBouton;
}
window.addEvent('domready', function() {
    if (Browser.ie6 || Browser.ie7) {
        var tableaux = $(document.body).getElements('.tab-box table');
        for (j = 0; j < tableaux.length; j++) {
            var boutons = tableaux[j].getElements('.filtre button:not([disabled])');
            for (i = 0; i < boutons.length; i++) {
                if (String.from(boutons[i].get('name')).contains("-restore")) {
                    var conteneur = boutons[i].getParent();
                    var lienBouton = getLinkFrom(boutons[i]);
                    lienBouton.inject(conteneur, 'top');
                    boutons[i].destroy();
                    break;
                }
            }
        }
    }
});
TableJs = new Class({
    Implements: [Options],
    rowMin: 0,
    rowMax: 0,
    columns: [],
    isArrayDataSource: false,
    interfiches: [],
    resultats: [],
    paginationSelects: [],
    hasFilters: false,
    options: {
        pagination: {
            value: 10,
            options: [5, 10, 50],
            position: "top",
            partialList: false
        },
        sortable: true,
        paginationOptions: [5, 10, 50],
        noValueMatchFilter: false
    },
    initialize: function(element, data, options) {
        Locale.use('fr-FR');
        var opts = Object.merge({}, data, options);
        opts.data = undefined;
        this.setOptions(opts);
        this.id = this.options.id || 't' + Math.floor((Math.random() * 1000) + 1);
        this.container = $(element);
        this.source = data;
        this.check();
        this.rows = Array.from(this.source.data);
        if (this.rows[0]) {
            this.isArrayDataSource = (this.rows[0] instanceof Array);
        }
        var j = 0;
        this.options.columns.each(function(column, index) {
            var values = [];
            var nameOrIndex;
            if (this.isArrayDataSource) {
                nameOrIndex = j;
            } else {
                nameOrIndex = column.name;
            }
            this.rows.each(function(row) {
                if (row[nameOrIndex]) {
                    values.push(row[nameOrIndex]);
                }
            });
            var col = new TableJs.Column(column, index, values, this);
            this.hasFilters = this.hasFilters || col.isFilterable;
            this.columns.push(col);
            if (!col.skipData) {
                j++;
            }
        }.bind(this));
        this.pagination = this.options.pagination.value;
        this.rowMax = this.pagination;
        if (!isNaN(this.pagination)) {
            this.options.pagination.options.include(this.pagination).sort(function(a, b) {
                return a - b;
            });
        }
        if (this.options.sort !== undefined) {
            this.sortColumn = this.getColIndexFor(this.options.sort);
            this.sortReverse = (this.options.order === 'desc');
            this.sort();
        }
        var hasFilterValue = (this.options.columns.filter(function(col) {
            return col.filterValue !== undefined;
        }).length > 0);
        if (hasFilterValue) {
            this.filter();
        }
        this.construct();
        this.attachEvents();
        this.table.fireEvent('tbody:ready');
        this.table.fireEvent('table:ready');
        this.table.tableJs = this;
    },
    check: function() {
        if (this.source.data === undefined) {
            throw new SyntaxError("No data");
        }
        if (this.options.caption === undefined) {
            throw new SyntaxError("Caption is required for a table (accessibility)");
        }
        this.options.columns.each(function(column) {
            if (column.decorator) {
                if (TableJs.Decorators[column.decorator] === undefined) {
                    throw new SyntaxError("Decorator not found for column " + JSON.stringify(column));
                }
                if (column.decorator === 'radio' || column.decorator === 'checkbox') {
                    if (column.name === undefined) {
                        throw new SyntaxError("Property name is required for column " + JSON.stringify(column));
                    }
                    if (column.value === undefined) {
                        throw new SyntaxError("Property value is required for column " + JSON.stringify(column));
                    }
                }
            }
            if (column.filter) {
                if (TableJs.Filters[column.filter] === undefined) {
                    throw new SyntaxError("Filter not found for column " + JSON.stringify(column));
                }
                if (column.filter === 'DateBetween' && column.filterValue && typeof column.filterValue !== 'object') {
                    throw new SyntaxError("Wrong value for filter DateBetween, column: " + JSON.stringify(column));
                }
            }
        });
    },
    construct: function() {
        this.tabbox = this.container;
        this.tabbox.addClass('tab-box');
        var tabbody = new Element('div', {
            'class': 'tab-body'
        });
        this.writer = new TableJs.TableWriter(this);
        if (this.hasBanner('top')) {
            this.tabbox.adopt(this.buildInterpage('h'));
        }
        tabbody.inject(this.tabbox);
        this.table = this.writer.writeTable(tabbody);
        if (this.hasBanner('bottom')) {
            this.tabbox.adopt(this.buildInterpage('b'));
        }
        this.updateResultatHtml();
        this.writer.updateHeaders();
        this.writer.updatePaginationSelect();
    },
    hasBanner: function(position) {
        if (position) {
            return this.options.pagination && (this.options.pagination.position === 'both' || this.options.pagination.position === position);
        } else {
            return this.options.pagination.position !== 'none';
        }
    },
    buildInterpage: function(suffix) {
        var tabinterpage = new Element('div', {
            'id': this.id + 'interpage' + suffix,
            'class': 'tab-interpage'
        });
        this.interfiches.push(new TableJs.Interfiche(this, tabinterpage));
        var resultat = new Element('div', {
            'class': 'resultat'
        });
        this.resultats.push(resultat);
        resultat.inject(tabinterpage, 'top');
        var pagination = new Element('div', {
            'class': 'pagination'
        });
        var idselp = this.id + 'pagesel' + suffix;
        var labelp = new Element('label', {
            'class': 'lignePage',
            'for': idselp,
            'text': 'nb. de lignes par page'
        });
        var paginationSelect = new Element('select', {
            'id': idselp
        });
        this.paginationSelects.push(paginationSelect);
        pagination.adopt(labelp, paginationSelect);
        pagination.inject(tabinterpage, 'bottom');
        return tabinterpage;
    },
    updateResultatHtml: function() {
        var message;
        if (this.rows.length < this.source.data.length) {
            message = MessageFormat.pluralFormat('<b>{0}</b> ligne filtrée sur {1}', '<b>{0}</b> lignes filtrées sur {1}', this.rows.length, this.source.data.length);
        } else {
            message = MessageFormat.pluralFormat('<b>{0}</b> ligne', '<b>{0}</b> lignes', this.rows.length);
        }
        this.resultats.each(function(div) {
            div.set('html', message);
        });
    },
    attachEvents: function() {
        var self = this;
        this.table.addEvent('filter:updated', function(event) {
            this.filter();
            this.rowMin = 0;
            this.writer.updateInterpage();
            this.writer.updateBody();
            this.writer.updatePaginationSelect();
            this.updateResultatHtml();
        }.bind(this));
        this.table.addEvent('interfiche:updated', function(trigger) {
            this.writer.updateBody();
            this.interfiches.each(function(interfiche) {
                if (trigger !== interfiche) {
                    interfiche.current = trigger.current;
                    interfiche.construct();
                }
            }.bind(this));
        }.bind(this));
        this.paginationSelects.each(function(select) {
            select.addEvent('change', function(event) {
                self.pagination = this.value;
                self.writer.updatePaginationSelect();
                self.table.fireEvent('pagination:select');
            });
        });
        this.table.addEvent('pagination:select', function(event) {
            this.writer.updateInterpage();
            this.writer.updateBody();
        }.bind(this));
        this.table.addEvent('click:relay(th.triable a)', this.sortEventHandler.bind(this));
        this.table.addEvent('keydown:keys(enter):relay(th.triable a)', this.sortEventHandler.bind(this));
        this.table.addEvent('sort:updated', function(event) {
            this.sort();
            this.writer.updateHeaders();
            this.writer.updateBody();
            this.writer.updateInterpage();
        }.bind(this));
        this.table.addEvent('filter:restore', function(event) {
            this.writer.restoreFilters();
            this.filter();
            this.writer.updateBody();
            this.writer.updateInterpage();
        }.bind(this));
        this.table.addEvent('table:ready', function(event) {
            var checkAll = self.table.getElement('thead input[type=checkbox]');
            if (checkAll) {
                checkAll.addEvent("click", function(event) {
                    var checkboxes = self.table.getElements('tbody input[type=checkbox]');
                    checkboxes.set('checked', this.checked);
                });
            }
        });
        this.table.addEvent('tbody:ready', function(event) {
            var checkAll = self.table.getElement('thead .cb-decorator input[type=checkbox]');
            if (checkAll) {
                var checkboxes = self.table.getElements('tbody .cb-decorator input[type=checkbox]');
                checkboxes.addEvent("click", function(event) {
                    TableTag.updateCheckAll(checkAll, checkboxes);
                });
                TableTag.updateCheckAll(checkAll, checkboxes);
            }
        });
        if (this.options.rows) {
            this.table.addEvent('click:relay(td:not(.no-row-link))', function(event) {
                var tr = event.target.getParent('tr');
                var visibleTR = this.table.getElements('tbody tr');
                var rowNum = this.rowMin + visibleTR.indexOf(tr);
                if (this.options.rows.js) {
                    var eventClickFunction = new Function('event', this.options.rows.js);
                    eventClickFunction.call({
                        row: this.rows[rowNum]
                    }, event);
                }
                if (this.options.rows.href !== undefined) {
                    window.location = TableJs.buildHref(this.options.rows.href, this.options.rows.params, this.rows[rowNum]);
                }
            }.bind(this));
        }
    },
    sortEventHandler: function(event) {
        var th = event.target.getParent('th');
        this.sortColumn = this.table.getElements('thead th').indexOf(th);
        if (th.hasClass('tri-desc')) {
            this.sortReverse = false;
        } else if (th.hasClass('tri-asc')) {
            this.sortReverse = true;
        } else {
            this.sortReverse = (TableJs.sortFirstOrder !== "ascending");
        }
        this.table.fireEvent('sort:updated');
    },
    filter: function() {
        this.rows = [];
        if (typeof Placeholders !== 'undefined') {
            Placeholders.disable(this.table);
        }
        this.source.data.each(function(row) {
            var match = true;
            for (var i = 0, j = 0; i < this.columns.length; i++) {
                var column = this.columns[i];
                if (!column.skipData) {
                    var val = row[(this.isArrayDataSource ? j : column.name)];
                    if (column.isFilterable) {
                        if (val) {
                            if (!column.filter.match(val)) {
                                match = false;
                                break;
                            }
                        } else {
                            if (!this.options.noValueMatchFilter && !column.filter.match('')) {
                                match = false;
                                break;
                            }
                        }
                    }
                    j++;
                }
            }
            if (match) {
                this.rows.push(row);
            }
        }.bind(this));
        if (typeof Placeholders !== 'undefined') {
            Placeholders.enable(this.table);
        }
    },
    sort: function() {
        var nameOrIndex;
        if (this.isArrayDataSource) {
            nameOrIndex = this.getColIndexFor(this.sortColumn);
        } else {
            nameOrIndex = this.columns[this.sortColumn].name;
        }
        this.rows.sort(function(a, b) {
            return this.columns[this.sortColumn].compare(a[nameOrIndex], b[nameOrIndex]);
        }.bind(this));
        if (this.sortReverse) {
            this.rows.reverse();
        }
    },
    getColIndexFor: function(name) {
        for (var i = 0, j = 0; i < this.columns.length; i++) {
            if (name === this.columns[i].name) {
                return j;
            }
            if (!this.columns[i].skipData) {
                j++;
            }
        }
    }
});
TableJs.Column = new Class({
    values: [],
    initialize: function(column, index, values, tableJs) {
        this.rawdata = column;
        this.index = index;
        this.name = column.name || index;
        this.values = values;
        this.decorator = TableJs.Decorators[column.decorator || 'default'];
        this.compare = this.decorator.sortFunction || TableJs.Decorators['default'].sortFunction;
        if (typeof(column) === "string") {
            this.label = column;
        } else {
            this.label = column.label || '';
            this.format = column.format || this.decorator.format;
        }
        if (column.filterable || column.filter) {
            this.isFilterable = true;
            this.filter = new TableJs.Filters[column.filter || this.decorator.filter || 'Default'](this, tableJs);
        } else {
            this.isFilterable = false;
        }
        this.isSortable = column.sortable;
        this.css = column.css || this.decorator.css;
        this.skipData = column.skipData || false;
    },
    formatValue: function(value, row, opts) {
        if (typeof this.format === 'function') {
            return this.format.apply(this, [value, row, opts]);
        }
        return value;
    }
});
TableJs.Interfiche = new Class({
    Extends: Interfiche,
    position: 'bottom',
    showMonoPage: false,
    initialize: function(tableJs, container) {
        this.tableJs = tableJs;
        this.element = container;
        this.items = tableJs.rows;
        this.interpage = new Element('div', {
            'class': 'tabinterfiche',
            role: 'navigation'
        });
        this.addEvents();
        this.first();
    },
    getPageSize: function() {
        return this.tableJs.pagination;
    },
    getLastPageNumber: function() {
        return Math.ceil(this.items.length / this.getPageSize());
    },
    updateList: function() {
        this.tableJs.rowMax = this.current * this.getPageSize();
        this.tableJs.rowMin = this.tableJs.rowMax - this.getPageSize();
        if (this.tableJs.table) {
            this.tableJs.table.fireEvent('interfiche:updated', this);
        }
    }
});
TableJs.TableWriter = new Class({
    oddClass: 'pair',
    evenClass: 'impair',
    columns: [],
    visibleRows: [],
    initialize: function(tableJs) {
        this.tableJs = tableJs;
        this.columns = this.tableJs.columns;
        this.hasFilters = this.tableJs.hasFilters;
    },
    getTable: function() {
        var table = new Element('table', {
            id: this.tableJs.id
        });
        if (this.tableJs.options.cssclass) {
            table.addClass(this.tableJs.options.cssclass);
        }
        table.adopt(new Element('caption', {
            text: this.tableJs.options.caption
        }));
        table.adopt(this.getColgroup());
        table.adopt(this.getThead());
        table.adopt(this.getTbody());
        return table;
    },
    writeTable: function(container) {
        var table = this.getTable();
        container.adopt(table);
        this.tableJs.table = table;
        this.tableJs.table.fireEvent('table:ready');
        this.columns.each(function(column) {
            if (column.isFilterable && column.filter.js) {
                column.filter.js();
            }
        }.bind(this));
        return table;
    },
    getColgroup: function() {
        var colgroup = new Element('colgroup');
        var cols = [];
        this.columns.each(function(column) {
            var col = new Element('col');
            if (column.rawdata.width) {
                col.setStyle('width', column.rawdata.width);
            }
            cols.push(col);
        });
        colgroup.adopt(cols);
        return colgroup;
    },
    getThead: function() {
        var thead = new Element('thead');
        if (this.hasFilters) {
            thead.adopt(this.getFilters());
            thead.adopt(this.getFiltersInfo());
        }
        thead.adopt(this.getHeaders());
        return thead;
    },
    getHeaders: function() {
        var tr = new Element('tr');
        this.columns.each(function(column) {
            var th = new Element('th', {
                scope: 'col'
            });
            if (column.css) {
                th.set('class', column.css);
            }
            if (column.rawdata.decorator === 'checkbox') {
                var checkall = new Element('input', {
                    type: 'checkbox'
                });
                th.adopt(checkall);
            } else if (column.isSortable) {
                var anchor = new Element('a', {
                    role: 'button',
                    tabIndex: 0,
                    text: column.label
                });
                anchor.addEvent('click', function(e) {
                    e.preventDefault();
                });
                th.addClass('tri triable');
                anchor.inject(th);
            } else {
                th.set('text', column.label);
            }
            th.inject(tr);
        }.bind(this));
        return tr;
    },
    getFilters: function() {
        var tr = new Element('tr', {
            'class': 'filtre top'
        });
        this.columns.each(function(column) {
            var td = new Element('td');
            if (column.isFilterable) {
                td.adopt(column.filter.elements);
            }
            td.inject(tr);
        }.bind(this));
        return tr;
    },
    restoreFilters: function() {
        this.columns.each(function(column) {
            if (column.isFilterable) {
                column.filter.reset();
            }
        });
    },
    getFiltersInfo: function() {
        var tr = new Element('tr', {
            'class': 'filtre ligne2'
        });
        var td = new Element('td', {
            colspan: this.tableJs.columns.length,
            'class': 'droite'
        });
        var restoreBtn = new Element('button', {
            type: 'button',
            'class': 'bouton intermediaire',
            'html': '<span class="btn_action"><span><span>Rétablir</span></span></span>'
        });
        restoreBtn.addEvent('click', function(event) {
            this.tableJs.table.fireEvent('filter:restore');
        }.bind(this));
        td.adopt(restoreBtn);
        td.adopt(new Element('a', TableJs.filterHelp));
        td.inject(tr);
        return tr;
    },
    getTbody: function() {
        var tbody = new Element('tbody');
        if (this.tableJs.options.rows !== undefined) {
            tbody.addClass('has-row-link');
        }
        var start = this.tableJs.rowMin;
        var end = this.tableJs.rows.length;
        if (this.tableJs.hasBanner() && (this.tableJs.pagination !== '*' || this.tableJs.rows.length <= this.tableJs.pagination)) {
            end = Math.min(this.tableJs.rows.length, this.tableJs.rowMax);
        }
        this.visibleRows = [];
        for (var i = start; i < end; i++) {
            this.visibleRows.push(this.tableJs.rows[i]);
            var tr = this.getRow(this.tableJs.rows[i]);
            tr.inject(tbody);
        }
        return tbody;
    },
    getRow: function(row) {
        var tr = new Element('tr', {
            'class': (this.visibleRows.indexOf(row) % 2 === 1 ? this.oddClass : this.evenClass)
        });
        for (var i = 0, j = 0; i < this.columns.length; i++) {
            var td = new Element('td');
            if (i < this.columns.length) {
                var opts = {
                    rowIndex: this.visibleRows.indexOf(row),
                    column: this.columns[i].rawdata
                };
                var val = (this.tableJs.isArrayDataSource ? row[j] : row[this.columns[i].name]);
                if (val === undefined) {
                    val = '';
                }
                var formatedVal = this.columns[i].formatValue(val, row, opts);
                if (typeof formatedVal === "string") {
                    td.set('html', formatedVal);
                } else {
                    td.adopt(formatedVal);
                }
                if (!(this.columns[i].skipData || j >= row.length)) {
                    j++;
                }
            }
            if (this.columns[i].css) {
                td.set('class', this.columns[i].css);
            }
            td.inject(tr);
        }
        return tr;
    },
    updateHeaders: function() {
        var headers = this.tableJs.table.getElements('thead th');
        headers.removeClass('tri-asc');
        headers.removeClass('tri-desc');
        headers.removeProperty('aria-sort');
        if (this.tableJs.sortColumn !== null && this.tableJs.sortColumn !== undefined) {
            var th = headers[this.tableJs.sortColumn];
            if (this.tableJs.sortReverse) {
                th.addClass('tri-desc');
                th.set('aria-sort', 'descending');
            } else {
                th.addClass('tri-asc');
                th.set('aria-sort', 'ascending');
            }
        }
    },
    updateBody: function() {
        var tbody = this.tableJs.tabbox.getElement('tbody');
        if (tbody) {
            tbody.destroy();
            this.tableJs.table.adopt(this.getTbody());
            this.tableJs.table.fireEvent('tbody:ready');
        }
    },
    updatePaginationSelect: function() {
        this.tableJs.paginationSelects.each(function(select) {
            var opts = [];
            var optionSelected = false;
            var options = this.tableJs.options.pagination.options;
            options.each(function(val) {
                if (val < this.rows.length) {
                    var opt = new Element('option', {
                        value: val,
                        text: val
                    });
                    if (val == this.pagination) {
                        opt.set('selected', 'selected');
                        optionSelected = true;
                    }
                    opts.push(opt);
                }
            }.bind(this.tableJs));
            var optall = new Element('option', {
                value: '*',
                text: 'Toutes'
            });
            if ('*' === this.tableJs.pagination || !optionSelected) {
                optall.set('selected', 'selected');
            }
            opts.push(optall);
            select.empty();
            select.adopt(opts);
        }.bind(this));
    },
    updateInterpage: function() {
        this.tableJs.interfiches.each(function(interfiche) {
            interfiche.items = this.tableJs.rows;
            if (this.tableJs.pagination === '*' || this.tableJs.rows.length <= this.tableJs.pagination) {
                this.tableJs.hasPagination = false;
                interfiche.destroy();
            } else {
                this.tableJs.hasPagination = true;
                interfiche.construct();
                interfiche.first();
            }
        }.bind(this));
    }
});
TableJs.FilterUtils = {
    getOperator: function(filterValue) {
        var ret = {
            name: 'NONE',
            length: 0
        };
        if (filterValue.indexOf('<>') === 0 || filterValue.indexOf('!=') === 0) {
            ret = {
                name: 'DIFF',
                length: 2
            };
        } else if (filterValue.indexOf('>=') === 0) {
            ret = {
                name: 'SUPEQ',
                length: 2
            };
        } else if (filterValue.indexOf('>') === 0) {
            ret = {
                name: 'SUP',
                length: 1
            };
        } else if (filterValue.indexOf('<=') === 0) {
            ret = {
                name: 'INFEQ',
                length: 2
            };
        } else if (filterValue.indexOf('<') === 0) {
            ret = {
                name: 'INF',
                length: 1
            };
        } else if (filterValue.indexOf('=') === 0) {
            ret = {
                name: 'EQ',
                length: 1
            };
        }
        return ret;
    },
    strToRegex: function(str) {
        var resultat = '';
        var character;
        for (var i = 0; i < str.length; ++i) {
            character = str.charAt(i);
            if ("*".indexOf(character) != -1) {
                resultat += '.';
                resultat += character;
            } else if ("?".indexOf(character) != -1) {
                resultat += '.';
            } else if (".^$|?*+[]{}\"()".indexOf(character) != -1) {
                resultat += '\\';
                resultat += character;
            } else {
                resultat += character;
            }
        }
        return '^' + resultat + '$';
    },
    hasJokers: function(filterValue) {
        var regex = RegExp('((".*")|\\?|\\*)');
        return filterValue.length > 0 && regex.test(filterValue);
    },
    isCaseSensitive: function(filterValue) {
        return filterValue.indexOf('"') === 0 && filterValue.lastIndexOf('"') === (filterValue.length - 1);
    }
};
TableJs.Filters = {
    delay: 200
};
TableJs.Filters.Abstract = new Class({
    op: {
        name: 'NONE'
    },
    initialize: function(column, tableJs) {
        this.column = column;
        this.tableJs = tableJs;
        this.elements = this.build();
        if (this.column.rawdata.filterValue !== undefined) {
            this.updateComputedProp();
        }
    },
    match: function(cellValue) {
        var ret;
        if (this.input.value.length === 0) {
            ret = true;
        } else {
            var cellVal = this.getComparableObject(cellValue);
            switch (this.op.name) {
                case 'DIFF':
                    ret = this.column.compare(cellVal, this.filterVal) !== 0;
                    break;
                case 'SUPEQ':
                    ret = this.column.compare(cellVal, this.filterVal) >= 0;
                    break;
                case 'SUP':
                    ret = this.column.compare(cellVal, this.filterVal) > 0;
                    break;
                case 'INFEQ':
                    ret = this.column.compare(cellVal, this.filterVal) <= 0;
                    break;
                case 'INF':
                    ret = this.column.compare(cellVal, this.filterVal) < 0;
                    break;
                case 'EQ':
                    ret = this.column.compare(cellVal, this.filterVal) === 0;
                    break;
                case 'NONE':
                    ret = cellVal.indexOf(this.filterVal) > -1;
                    break;
                default:
                    ret = false;
                    break;
            }
        }
        return ret;
    },
    delayedNotifyUpdate: function() {
        clearTimeout(this.timer);
        this.timer = this.notifyUpdate.delay(TableJs.Filters.delay, this);
    },
    updateComputedProp: function() {},
    reset: function() {},
    notifyUpdate: function() {
        this.updateComputedProp();
        this.tableJs.table.fireEvent('filter:updated');
    }
});
TableJs.Filters.Default = new Class({
    Extends: TableJs.Filters.Abstract,
    build: function() {
        this.input = new Element('input', {
            type: 'text',
            'class': 'champ_filtre',
            title: 'Filtre sur la colonne ' + this.column.label
        });
        if (this.column.rawdata.filterValue !== undefined) {
            this.input.set('value', this.column.rawdata.filterValue);
        }
        this.input.addEvent('keyup', this.firterUpdated.bind(this));
        return this.input;
    },
    reset: function() {
        if (this.column.rawdata.filterValue !== undefined) {
            this.input.set('value', this.column.rawdata.filterValue);
        } else {
            this.input.set('value', '');
        }
        this.notifyUpdate();
    },
    updateComputedProp: function() {
        this.op = TableJs.FilterUtils.getOperator(this.input.value);
        this.filterVal = this.getComparableObject(this.input.value.substring(this.op.length));
        this.hasJokers = TableJs.FilterUtils.hasJokers(this.input.value);
        var valueWithoutOp = this.input.value.substring(this.op.length);
        var realFilterValue = valueWithoutOp;
        this.caseSensitive = false;
        if (TableJs.FilterUtils.isCaseSensitive(valueWithoutOp)) {
            realFilterValue = valueWithoutOp.substring(1, valueWithoutOp.length - 1);
            this.caseSensitive = true;
        }
        this.regex = RegExp(TableJs.FilterUtils.strToRegex(this.getComparableObject(realFilterValue, this.caseSensitive)));
    },
    firterUpdated: function(event) {
        var forbiddenKeys = [9, 16, 17, 37, 38, 39, 40];
        if (!forbiddenKeys.contains(event.code)) {
            this.delayedNotifyUpdate();
        }
    },
    getComparableObject: function(value, caseSensitive) {
        if (typeof value === 'number') {
            return "" + value;
        }
        return (caseSensitive ? value : value.standardize().toUpperCase());
    },
    match: function(cellValue) {
        var ret;
        if (this.hasJokers) {
            switch (this.op.name) {
                case 'NONE':
                case 'EQ':
                    ret = this.regex.test(this.getComparableObject(cellValue, this.caseSensitive));
                    break;
                case 'DIFF':
                    ret = !this.regex.test(this.getComparableObject(cellValue, this.caseSensitive));
                    break;
                default:
                    ret = this.parent(cellValue);
                    break;
            }
        } else {
            ret = this.parent(cellValue);
        }
        return ret;
    }
});
TableJs.Filters.Numeric = new Class({
    Extends: TableJs.Filters.Default,
    hasJokers: false,
    match: function(cellValue) {
        var ret;
        if (this.input.value.length === 0) {
            ret = true;
        } else {
            var cellVal = this.getComparableObject(cellValue);
            if (this.op.name === 'NONE') {
                ret = this.column.compare(cellVal, this.filterVal) === 0;
            } else {
                ret = this.parent(cellValue);
            }
        }
        return ret;
    },
    updateComputedProp: function() {
        this.op = TableJs.FilterUtils.getOperator(this.input.value);
        this.filterVal = this.getComparableObject(this.input.value.substring(this.op.length));
    },
    getComparableObject: function(value) {
        var num = value;
        if (typeof value === 'string') {
            num = value.replace(',', '.');
        }
        if (!isNaN(num)) {
            return Number.from(num);
        }
        return 0;
    }
});
TableJs.Filters.DateBetween = new Class({
    Extends: TableJs.Filters.Abstract,
    input: {},
    build: function() {
        this.container = new Element('div', {
            'class': 'filter-between'
        });
        this.container.adopt(this.buildDateField(1, 'from', 'du'), this.buildDateField(2, 'to', 'au'));
        return this.container;
    },
    buildDateField: function(num, name, lbl) {
        var id = this.tableJs.id + 'dbw' + num + '-' + this.column.name;
        var div = new Element('div', {
            'class': 'between-' + num
        });
        var label = new Element('label', {
            'for': id,
            text: lbl
        });
        var input = new Element('input', {
            id: id,
            type: 'text',
            maxLength: 10,
            size: 10,
            'autocomplete': 'off',
            'placeholder': 'jj/mm/aaaa'
        });
        input.addEvent('keyup', this.firterUpdated.bind(this));
        if (typeof this.column.rawdata.filterValue === 'object') {
            input.set('value', this.column.rawdata.filterValue[name] || '');
        }
        this.input[name] = input;
        div.adopt(label, input);
        return div;
    },
    js: function() {
        for (var name in this.input) {
            var picker = new DatePicker(this.input[name].id, {
                toggle: this.input[name].id + '_calendrier',
                pickerClass: 'datepicker dpstandard',
                linkTitle: 'Aide �  la saisie de date'
            });
            picker.addEvent('select', this.firterUpdated.bind(this));
        }
    },
    firterUpdated: function(event) {
        var forbiddenKeys = [9, 16, 17, 37, 38, 39, 40];
        if (!forbiddenKeys.contains(event.code)) {
            this.delayedNotifyUpdate();
        }
    },
    isFilterValid: function() {
        var minValid = this.input.from.value.length === 0 || this.input.from.value.length === 10;
        var maxValid = this.input.to.value.length === 0 || this.input.to.value.length === 10;
        return (minValid && maxValid);
    },
    match: function(cellValue) {
        if (!this.isFilterValid()) {
            return false;
        } else if (this.input.from.value === '' && this.input.to.value === '') {
            return true;
        } else if (!cellValue) {
            return false;
        }
        var cellDate = Date.parse(cellValue);
        if (this.input.to.value === '') {
            return cellDate >= this.minDate;
        }
        if (this.input.from.value === '') {
            return cellDate <= this.maxDate;
        }
        return (cellDate >= this.minDate && cellDate <= this.maxDate);
    },
    reset: function() {
        if (typeof this.column.rawdata.filterValue === 'object') {
            this.input.from.value = this.column.rawdata.filterValue.from || '';
            this.input.to.value = this.column.rawdata.filterValue.to || '';
        } else {
            this.input.from.value = '';
            this.input.to.value = '';
        }
        this.notifyUpdate();
    },
    updateComputedProp: function() {
        this.minDate = Date.parse(this.input.from.value);
        this.maxDate = Date.parse(this.input.to.value);
    }
});
TableJs.Filters.Combo = new Class({
    Extends: TableJs.Filters.Abstract,
    build: function() {
        this.select = new Element('select', {
            title: 'Filtre sur la colonne ' + this.column.label
        });
        var distinctValues = this.column.values.filter(function(value, index, self) {
            return self.indexOf(value) === index;
        });
        var opts = [];
        opts.push(new Element('option'));
        distinctValues.each(function(val) {
            var opt = new Element('option', {
                value: val,
                text: val
            });
            if (this.column.rawdata.filterValue !== undefined && this.column.rawdata.filterValue === val) {
                opt.selected = 'selected';
            }
            opts.push(opt);
        }.bind(this));
        this.select.adopt(opts);
        this.select.addEvent('change', this.notifyUpdate.bind(this));
        return this.select;
    },
    match: function(cellValue) {
        if (this.select.value === '') {
            return true;
        }
        return cellValue === this.select.value;
    },
    reset: function() {
        var opts = this.select.getElements('option');
        this.select.selectedIndex = 0;
        opts.each(function(opt) {
            if (this.column.rawdata.filterValue !== undefined && this.column.rawdata.filterValue === opt.value) {
                opt.selected = 'selected';
            } else {
                opt.removeProperty('selected');
            }
        }.bind(this));
        this.notifyUpdate();
    }
});
TableJs.Decorators = {
    'default': {
        format: function(value) {
            return '' + value;
        },
        sortFunction: function(a, b) {
            if (a === undefined) {
                return -1;
            }
            if (b === undefined) {
                return 1;
            }
            if (a > b) {
                return 1;
            } else if (a < b) {
                return -1;
            }
            return 0;
        },
        filter: 'Default'
    },
    shortdate: {
        css: 'center',
        format: function(value) {
            if (value) {
                return Date.parse(value).format(Locale.get('Date.shortDate'));
            } else {
                return '';
            }
        },
        sortFunction: function(a, b) {
            if (a === undefined) {
                return -1;
            }
            if (b === undefined) {
                return 1;
            }
            if (a > b) {
                return 1;
            } else if (a < b) {
                return -1;
            }
            return 0;
        },
        filter: 'DateBetween'
    },
    boolean: {
        css: 'center',
        format: function(value) {
            if (value) {
                return 'O';
            } else if (value === false || value === "false") {
                return 'N';
            } else {
                return '';
            }
        },
        sortFunction: function(a, b) {
            if (a === undefined) {
                return -1;
            }
            if (b === undefined) {
                return 1;
            }
            if (a > b) {
                return 1;
            } else if (a < b) {
                return -1;
            }
            return 0;
        },
        filter: 'Combo'
    },
    numeric: {
        css: 'colnum',
        format: function(value) {
            if (value) {
                var num = new Number(value);
                return (num).format({
                    group: ' ',
                    decimal: ','
                });
            } else {
                return '';
            }
        },
        sortFunction: function(a, b) {
            if (isNaN(a)) return -1;
            if (isNaN(b)) return 1;
            a = parseFloat(a);
            b = parseFloat(b);
            if (a > b) {
                return 1;
            } else if (a < b) {
                return -1;
            }
            return 0;
        },
        filter: 'Numeric'
    },
    checkbox: {
        css: 'pictogramme cb-decorator no-row-link',
        format: function(value, row, opts) {
            return '<input type="checkbox" title="Choix de la ligne ' + (opts.rowIndex + 1) + '" value="' + row[opts.column.value] + '" name="' + opts.column.name + '">';
        }
    },
    radio: {
        css: 'pictogramme no-row-link',
        format: function(value, row, opts) {
            return '<input type="radio" title="Sélection de la ligne ' + (opts.rowIndex + 1) + '" value="' + row[opts.column.value] + '" name="' + opts.column.name + '">';
        }
    },
    loupe: {
        css: 'pictogramme',
        format: function(value, row, opts) {
            var alt = 'Détail ligne ' + (opts.rowIndex + 1);
            var anchor = new Element('a', {
                "class": "vue-detail",
                title: alt
            });
            if (opts.column.js) {
                var eventClickFunction = new Function('event', opts.column.js);
                anchor.addEvent('click', eventClickFunction.bind({
                    row: row
                }));
            }
            if (opts.column.href !== undefined) {
                anchor.set('href', TableJs.buildHref(opts.column.href, opts.column.params, row));
            }
            var img = new Element('img', TableJs.loupeImg);
            img.set('alt', alt);
            anchor.adopt(img);
            return anchor;
        }
    },
    autolink: {
        css: 'no-row-link',
        format: function(value, row, opts) {
            if (/.+@.+/.test(value)) {
                return '<a href="mailto:' + value + '">' + value + '</a>';
            } else {
                return '<a href="' + value + '">' + value + '</a>';
            }
        }
    },
    longtext: {
        css: 'cell',
        format: function(value) {
            var div = new Element('div');
            div.set('text', value);
            return div;
        }
    }
};
TableJs.Adapter = new Class({
    initialize: function(element) {
        this.table = $(element);
    },
    getData: function() {
        var dataArray = [];
        this.table.getElements('tbody tr').each(function(row) {
            var rowArr = [];
            row.getElements('td').each(function(cell) {
                rowArr.push(cell.get('text'));
            });
            dataArray.push(rowArr);
        });
        return {
            data: dataArray
        };
    }
});
TableJs.extend({
    components: {},
    errorMessage: "Erreur lors du chargement des données du tableau",
    waitingMessage: "Chargement des données du tableau en cours...",
    loupeImg: {
        width: 30,
        height: 30,
        src: "biblicnam/images/table/btn_vuedetail.gif"
    },
    filterHelp: {
        'class': 'aide',
        title: 'Aide filtrage tableau (nouvelle fenêtre)',
        onclick: "javascript:openPopUpSimple('Aide','biblicnam/html/infoTableau.html');return false",
        href: "biblicnam/html/infoTableau.html"
    },
    sortFirstOrder: 'descending',
    initFromObject: function(container, data, options) {
        return new TableJs(container, data, options);
    },
    initFromAJAX: function(container, url, options) {
        container.empty();
        container.set('text', TableJs.waitingMessage);
        var request = new Request.JSON({
            url: url,
            method: 'get',
            async: true,
            onFailure: function() {
                container.set('text', TableJs.errorMessage);
            },
            onError: function() {
                container.set('text', TableJs.errorMessage);
            },
            onSuccess: function(data) {
                container.empty();
                new TableJs(container, data, options);
            }
        });
        request.send();
    },
    initFromHTML: function(element, options) {
        var container = element.getParent('.tab-box');
        var adapter = new TableJs.Adapter(element);
        var data = adapter.getData();
        container.empty();
        return new TableJs(container, data, options);
    },
    buildHref: function(hrefSource, params, row) {
        var href = hrefSource;
        if (params) {
            href += (href.indexOf('?') > -1 ? '&' : '?');
            params.each(function(param) {
                var obj = {};
                if (typeof param === "string") {
                    obj[param] = row[param];
                } else {
                    obj[param.name] = row[param.value];
                }
                href += Object.toQueryString(obj);
                href += '&';
            });
            href = href.substr(0, href.length - 1);
        }
        return href;
    }
});
var Carrousel = new Class({
    Implements: [Options],
    options: {
        interval: 5000,
        animationDuration: 1500,
        autoplay: true,
        navigate: 'dot'
    },
    animation: null,
    currentIndex: 0,
    isRunning: false,
    initialize: function(element, options) {
        this.setOptions(options);
        this.element = element;
        this.wrapper = element.getElement('.c-wrapper');
        this.list = this.wrapper.getElement('.c-content');
        this.diapos = this.list.getElements('li');
        if (this.diapos.length <= 1) {
            return;
        }
        this.dimensions = this.list.getDimensions();
        this.getCurrentDiapo().setStyles({
            left: 0
        });
        this.getHiddenDiapos().setStyles({
            left: this.dimensions.width
        });
        this.buildRunBtn();
        this.options.navigate.split(' ').each(function(type) {
            switch (type) {
                case 'dot':
                    this.buildNavigDot();
                    break;
                case 'video':
                    this.buildNavigVideo();
                    break;
                default:
                    break;
            }
        }.bind(this));
        if (this.options.autoplay) {
            this.autoplay = this.options.autoplay;
            this.start();
        }
        this.updateDiapoAria();
        this.addEvents();
    },
    addEvents: function() {
        this.element.addEvent('focusin', function(event) {
            if (event.target === this.btnRun) {
                this.resume = false;
            } else {
                this.resume = this.isRunning;
                this.stop();
            }
        }.bind(this));
        this.element.addEvent('focusout', function() {
            if (this.resume && this.autoplay) {
                this.start();
            }
        }.bind(this));
    },
    buildRunBtn: function() {
        this.btnRun = this.wrapper.getElement('.btn-run');
        if (!this.btnRun) {
            this.btnRun = new Element('button', {
                'class': 'btn-run',
                'aria-label': 'Lancer l\'animation'
            });
            this.btnRun.addEvent('click', function(event) {
                if (this.isRunning) {
                    this.stop();
                    this.autoplay = false;
                } else {
                    this.start();
                    this.autoplay = true;
                }
            }.bind(this));
            this.wrapper.adopt(this.btnRun);
        }
    },
    start: function() {
        this.isRunning = true;
        this.timer = this.next.periodical(this.options.interval, this);
        if (this.btnRun) {
            this.btnRun.addClass('pause');
            this.btnRun.set('aria-label', 'Arrêter l\'animation');
        }
    },
    stop: function() {
        clearInterval(this.timer);
        this.timer = null;
        this.isRunning = false;
        if (this.btnRun) {
            this.btnRun.removeClass('pause');
            this.btnRun.set('aria-label', 'Lancer l\'animation');
        }
    },
    setCurrent: function(index) {
        this.element.fireEvent('change', [this.currentIndex, index]);
        this.currentIndex = index;
    },
    buildNavigDot: function() {
        var navig = this.wrapper.getElement('.c-navig-dot');
        var items = [];
        if (!navig) {
            navig = new Element('ol', {
                'class': 'c-navig-dot'
            });
        }
        for (var i = 0; i < this.diapos.length; i++) {
            var li = new Element('li');
            var diapoId = this.element.id + '_i' + i;
            this.diapos[i].set('id', diapoId);
            var button = new Element('button', {
                'aria-label': 'Diapo ' + (i + 1),
                'aria-controls': diapoId
            });
            if (i === 0) {
                li.addClass('current');
                button.set('title', 'Diapo ' + (i + 1) + ' (courante)');
            }
            li.adopt(button);
            button.addEvent('click', function(event) {
                var liParent = event.target.getParent('li');
                var targetIndex = navig.getElements('li').indexOf(liParent);
                this.goTo(targetIndex);
            }.bind(this));
            items.push(li);
        }
        this.element.addEvent('change', function(previous, next) {
            var dots = this.wrapper.getElements('.c-navig-dot li');
            for (var i = 0; i < dots.length; i++) {
                var button = dots[i].getElement('button');
                if (i === next) {
                    dots[i].addClass('current');
                    button.set('title', 'Diapo ' + (i + 1) + ' (courante)');
                } else {
                    dots[i].removeClass('current');
                    button.removeProperty('title');
                }
            }
        }.bind(this));
        navig.adopt(items);
        this.wrapper.adopt(navig);
    },
    buildNavigVideo: function() {
        var btnNext = this.wrapper.getElement('.btn-next');
        var btnPrevious = this.wrapper.getElement('.btn-previous');
        if (!btnPrevious) {
            btnPrevious = new Element('button', {
                'class': 'btn-previous',
                'aria-label': 'Précédent'
            });
            btnPrevious.addEvent('click', function(event) {
                this.stop();
                this.previous();
            }.bind(this));
            this.wrapper.adopt(btnPrevious);
        }
        if (!btnNext) {
            btnNext = new Element('button', {
                'class': 'btn-next',
                'aria-label': 'Suivant'
            });
            btnNext.addEvent('click', function(event) {
                this.stop();
                this.next();
            }.bind(this));
            this.wrapper.adopt(btnNext);
        }
    },
    getCurrentDiapo: function() {
        return this.diapos[this.currentIndex];
    },
    getHiddenDiapos: function() {
        return this.diapos.filter(function(diapo, index) {
            return this.currentIndex !== index;
        }, this);
    },
    next: function() {
        if (this.animation === null || !this.animation.isRunning()) {
            var nextIndex = (this.currentIndex + 1) % this.diapos.length;
            this.getHiddenDiapos().setStyles({
                left: this.dimensions.width
            });
            this.animate(this.getCurrentDiapo(), 0, -this.dimensions.width);
            this.animate(this.diapos[nextIndex], this.dimensions.width, 0);
            this.setCurrent(nextIndex);
        }
    },
    previous: function() {
        if (this.animation === null || !this.animation.isRunning()) {
            var previousIndex = (this.currentIndex - 1 + this.diapos.length) % this.diapos.length;
            this.getHiddenDiapos().setStyles({
                left: -this.dimensions.width
            });
            this.animate(this.getCurrentDiapo(), 0, this.dimensions.width);
            this.animate(this.diapos[previousIndex], -this.dimensions.width, 0);
            this.setCurrent(previousIndex);
        }
    },
    goTo: function(index) {
        if (index >= 0) {
            this.stop();
            this.setCurrent(index);
            for (var i = 0; i < this.diapos.length; i++) {
                if (i !== this.currentIndex) {
                    this.diapos[i].setStyles({
                        left: this.dimensions.width
                    });
                } else {
                    this.diapos[i].setStyles({
                        left: 0
                    });
                }
            }
            this.updateDiapoAria();
        }
    },
    animate: function(diapo, origin, destination) {
        this.animation = new Fx.Tween(diapo, {
            duration: this.options.animationDuration,
            property: 'left',
            onComplete: this.updateDiapoAria.bind(this)
        });
        this.getHiddenDiapos().removeClass('hidden');
        this.animation.start(origin, destination);
    },
    updateDiapoAria: function() {
        this.getHiddenDiapos().set('aria-hidden', true);
        this.getHiddenDiapos().addClass('hidden');
        this.getCurrentDiapo().set('aria-hidden', false);
        this.getCurrentDiapo().removeClass('hidden');
    }
});
Carrousel.extend({
    components: {},
    init: function(element, options) {
        this.components[element.id] = new Carrousel(element, options);
    }
});
var Vote = new Class({
    Implements: [Options],
    options: {
        max: 5,
        average: 0,
        readonly: false
    },
    presentation: {
        build: function(elm, width) {
            this.stars = new Element('div', {
                'class': 'stars'
            });
            this.average = new Element('div', {
                'class': 'average'
            });
            this.current = new Element('div', {
                'class': 'current'
            });
            this.over = new Element('div', {
                'class': 'over'
            });
            this.stars.adopt(this.average, this.current, this.over);
            this.stars.setStyle('width', width);
            this.stars.inject(elm, 'before');
        }
    },
    current: 0,
    average: 0,
    initialize: function(element, options) {
        this.setOptions(options);
        this.element = element;
        this.blockRadios = element.getElement('.radios');
        this.itemList = this.blockRadios.getElements('li');
        this.radios = element.getElements('.radios input');
        this.description = element.getElement('.description');
        this.radiogroup = element.getElement('fieldset');
        this.readonly = this.options.readonly;
        this.presentation.build(this.blockRadios, Vote.levelWidth * this.options.max);
        this.sync();
        this.setAverage(this.options.average);
        this.setReadOnly(this.options.readonly);
        this.element.vote = this;
    },
    sync: function() {
        var currentElm = this.radios.filter(function(input) {
            return input.checked === true;
        })[0];
        if (currentElm) {
            this.setCurrent(this.radios.indexOf(currentElm) + 1);
        } else {
            this.setCurrent(0);
        }
    },
    setCurrent: function(note) {
        this.current = note;
        for (var i = 0; i < this.radios.length; i++) {
            var li = this.radios[i].getParent('li');
            if (i === (note - 1)) {
                this.radios[i].checked = true;
                li.addClass('checked');
            } else {
                this.radios[i].checked = false;
                li.removeClass('outline').removeClass('checked');
            }
        }
        this.presentation.current.setStyle('width', Vote.levelWidth * this.current);
    },
    outlineCurrent: function() {
        if (this.current > 0) {
            this.radios[this.current - 1].getParent('li').addClass('outline');
        }
    },
    setAverage: function(note) {
        this.average = note;
        this.presentation.average.setStyle('width', Vote.levelWidth * this.average);
    },
    setDescription: function(htmlDescription) {
        this.description.set('html', htmlDescription);
    },
    addEvents: function() {
        this.radios.addEvent('focus', function(event) {
            var liParent = event.target.getParent('li');
            this.setCurrent(this.itemList.indexOf(liParent) + 1);
            this.outlineCurrent();
        }.bind(this));
        this.radios.addEvent('blur', function(event) {
            event.target.getParent('li').removeClass('outline');
        });
        this.blockRadios.addEvent('click:relay(label)', this.eventClickId = this.buttonsClickListener.bind(this));
        this.radiogroup.addEvent('keydown', this.eventKeyId = this.buttonsKeydownListener.bind(this));
        this.blockRadios.addEvent('mouseover', this.eventMouseOverId = this.mouseOverListener.bind(this));
        this.blockRadios.addEvent('mouseleave', this.eventMouseOutId = this.mouseOutListener.bind(this));
    },
    removeEvents: function() {
        this.radios.removeEvents('focus');
        this.radios.removeEvents('blur');
        this.blockRadios.removeEvent('click:relay(label)', this.eventClickId);
        this.radiogroup.removeEvent('keydown', this.eventKeyId);
        this.blockRadios.removeEvent('mouseover', this.eventMouseOverId);
        this.blockRadios.removeEvent('mouseleave', this.eventMouseOutId);
    },
    setReadOnly: function(readonly) {
        if (readonly) {
            this.element.addClass('readonly');
            this.radios.set('disabled', true);
            this.itemList.removeClass('outline');
            this.removeEvents();
        } else {
            this.element.removeClass('readonly');
            this.radios.removeProperty('disabled');
            this.addEvents();
        }
        this.readonly = readonly;
    },
    buttonsClickListener: function(event) {
        var targetIndex = this.itemList.indexOf(event.target.getParent('li'));
        this.setCurrent(targetIndex + 1);
        this.outlineCurrent();
        this.element.fireEvent('vote', targetIndex + 1);
    },
    buttonsKeydownListener: function(event) {
        if (event.key === 'enter') {
            this.element.fireEvent('vote', this.current);
        }
    },
    mouseOverListener: function(event) {
        if (event.target.get('tag') === 'label') {
            var targetIndex = this.itemList.indexOf(event.target.getParent('li'));
            this.presentation.over.setStyle('width', Vote.levelWidth * (targetIndex + 1));
        }
    },
    mouseOutListener: function(event) {
        this.presentation.over.setStyle('width', 0);
    }
});
Vote.extend({
    components: {},
    levelWidth: 30,
    init: function(element, options) {
        this.components[element.id] = new Vote(element, options);
    }
});
! function() {
    var w = window,
        d = w.document;
    if (w.onfocusin === undefined && Browser.name !== 'ie') {
        d.addEventListener('focus', addPolyfill, true);
        d.addEventListener('blur', addPolyfill, true);
        d.addEventListener('focusin', removePolyfill, true);
        d.addEventListener('focusout', removePolyfill, true);
    }

    function addPolyfill(e) {
        var type = e.type === 'focus' ? 'focusin' : 'focusout';
        var event = new CustomEvent(type, {
            bubbles: true,
            cancelable: false
        });
        event.c1Generated = true;
        e.target.dispatchEvent(event);
    }

    function removePolyfill(e) {
        if (!e.c1Generated) {
            d.removeEventListener('focus', addPolyfill, true);
            d.removeEventListener('blur', addPolyfill, true);
            d.removeEventListener('focusin', removePolyfill, true);
            d.removeEventListener('focusout', removePolyfill, true);
        }
        setTimeout(function() {
            d.removeEventListener('focusin', removePolyfill, true);
            d.removeEventListener('focusout', removePolyfill, true);
        });
    }
}();