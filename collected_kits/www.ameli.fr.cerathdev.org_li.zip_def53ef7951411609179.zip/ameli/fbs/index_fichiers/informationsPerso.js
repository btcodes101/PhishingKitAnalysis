function addClassBgdWhite(element){
	var cssClass = element.className;

	if(cssClass.indexOf("fondGris")>-1){
    	element.removeClass("fondGris");
	}
		
	var newCssClass =element.className;
    newCssClass = newCssClass + " fondBlanc";
	element.className=newCssClass;
}

function addClassBgdGris(element){

	var cssClass = element.className;

	if(cssClass.indexOf("fondGris")>-1){
		element.removeClass("fondBlanc");
	}
	
	var newCssClass = element.className;
    newCssClass = newCssClass + " fondGris";
	element.className = newCssClass;
}


function  showDiv(id , listeDiv){
 	var tabDivs = listeDiv.toString().split(',');
	if(id==('pageAssure')){
 		var pageAssure =  document.getElementById('pageAssure');
        pageAssure.removeClass("invisible");
        pageAssure.setProperty('aria-hidden', 'false');
        window.location.hash = '#' + pageAssure.id;
		for ( i =0 ; i < tabDivs.length ; i++ ) {

			var idDivCovert = Number(tabDivs[i]) ;
			var divToHide = document.getElementById(idDivCovert);
			divToHide.className="invisible";
			divToHide.setProperty('aria-hidden', 'true');
 			var liAssurePageBack = document.getElementById("idAssure");
 				//LI ASSUREE A METTRE EN VERT 
 			var classeCssAss =  liAssurePageBack.className;
 			classeCssAss = classeCssAss.replace('VERT', 'BLEU'); 
 			liAssurePageBack.className=classeCssAss;
			addClassBgdWhite(liAssurePageBack);
  			var liTochangeBackGround = document.getElementById(idDivCovert+ '-li');
 			//autre que asssure 
 			var classeCssOther =  liTochangeBackGround.className;
 			classeCssOther = classeCssOther.replace('BLEU', 'VERT'); 
 			liTochangeBackGround.className=classeCssOther;
 			addClassBgdGris(liTochangeBackGround);
 		}
 	} else {
      	//titulaire de compte 
	 	var liAssurePageBack = document.getElementById("idAssure");
	 	var classeCss =  liAssurePageBack.className;
 		classeCss = classeCss.replace('BLEU', 'VERT'); 
	 	liAssurePageBack.className=classeCss;
    	addClassBgdGris(liAssurePageBack);
		var toShowDiv ;
	
		for ( i =0 ; i < tabDivs.length ; i++ ) {
			var idDivCovert = Number(tabDivs[i]) ;
			if(idDivCovert === id) {
	             var liTochangeBackGround = document.getElementById(id+ '-li');
	             //Beneficiare selectione
				 var classeCssSelect =  liTochangeBackGround.className;
				 classeCssSelect = classeCssSelect.replace('VERT', 'BLEU'); 
				 liTochangeBackGround.className=classeCssSelect;
				 addClassBgdWhite(liTochangeBackGround);
				 var divToShow = document.getElementById(id);
				 var pageAssure =  document.getElementById('pageAssure');
				 var liAssurePageBack = document.getElementById("idAssure");
				 divToShow.removeClass("invisible");
				 divToShow.setProperty('aria-hidden', 'false');
				 window.location.hash = '#' + divToShow.id;
				 pageAssure.className="invisible";
				 pageAssure.setProperty('aria-hidden', 'true');
			} else {
				var liTochangeBackGroundHidden = document.getElementById(idDivCovert+ '-li');
				var divToHide = document.getElementById(idDivCovert);
				divToHide.className="invisible";
				divToHide.setProperty('aria-hidden', 'true');
				addClassBgdGris(liTochangeBackGroundHidden);
				//Autre beneficiare 
				var classeCssOther =  liTochangeBackGroundHidden.className;
				classeCssOther = classeCssOther.replace('BLEU', 'VERT'); 
				liTochangeBackGroundHidden.className=classeCssOther;
			}
		}
	}
}

function openNewWindow(url){
	window.open(url);
}


function linkToCeam(target, url) {
	var element = $(target);
	
	// Redirection si on ne clique pas sur l'image de la ceam (ou ses composants)
	if (!element.hasClass('ceamwrapper') && !element.getParent('.ceamwrapper')) {
		location.href=url;
	}
}
