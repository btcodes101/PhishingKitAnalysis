
/*** Fonctions javascript pour la fonctionalit� demande de code provisoire **/
/*** Les fonctions de controle utilisent la compilation des champ:saisie de la biblicnam **/
/*** Ce qui permet de savoir que le champ d'erreur est d�finit par id = champ.id + '_messageErreur' **/
 
/* controle de format de l'adresse email */
/* @argument - champ : le champ a controller */
/* @argument - validErr : le msg si une erreur de validation client est remont�e */
function controlEmail(champ, validErr) {
	
	var mailSaisie = champ.value;
	var erreurAdresse = false;

	// regex de validation d'une adresse email
	var regExpFormatEmail = new RegExp("^[a-zA-Z0-9]([\\.\\-_]?[a-zA-Z0-9])+@[a-zA-Z0-9]([\\.\\-_]?[a-zA-Z0-9])+[\\.][a-zA-Z]{2,4}$", "g");

	if (regExpFormatEmail.test(mailSaisie)) {
		ChampSaisieTag.champOK(champ);
		erreurAdresse = false;
	} else {
		if (mailSaisie.length === 0) {
			ChampSaisieTag.champOK(champ);
			erreurAdresse = true;
		} else {
			ChampSaisieTag.erreurChamp(champ, validErr.pattern);
			erreurAdresse = true;
		}
	}
	return erreurAdresse; 
};


function controlDateNaissance(champ, validErr) {

	var erreurDate = false;
	var regFormatDate = new RegExp("^[0-9]{2}\/[0-9]{2}\/([0-9]{4})$", "g");
	
	if (champ.value.length === 0) {
		ChampSaisieTag.champOK(champ);
		erreurDate = true;
	}
	// Control du format;
	else if (!regFormatDate.test(champ.value)) {
		ChampSaisieTag.erreurChamp(champ, validErr.pattern);
		erreurDate = true;
	} 
	// Control de la borne inferieure 
	else {
		var dateSaisie = champ.value.split('/');
		var ddj = new Date();
		var ddn = new Date(dateSaisie[2], dateSaisie[1]-1, dateSaisie[0]);
		
		if (ddn >= ddj) {
			ChampSaisieTag.erreurChamp(champ, validErr.anterieur);
			erreurDate = true;
		} else {
			ChampSaisieTag.champOK(champ);
			erreurDate = false;
		}
	}
	return erreurDate;
};



/* controle de format de num�ro de securit� */
/* @argument - champ : le champ a controller */
/* @argument - validErr : le msg si une erreur de validation client est remont�e */
function controlNir(champ, validErr) {

	var nirSaisie = champ.value;
	var erreurNir = false;

	if (nirSaisie.length !== 13 && nirSaisie.length > 0) {
		erreurNir = true;
		ChampSaisieTag.erreurChamp(champ, validErr.length);
		champ.focus();
	} else {
		// regex de validation d'un nir
		var regExpFormatNir = new RegExp("^[0-9]{6}[0-9ABab][0-9]{6}$", "g");	
	                                                                  
		if (regExpFormatNir.test(nirSaisie)) {
			ChampSaisieTag.champOK(champ);
			erreurNir = false;
		} else {
			if (nirSaisie.length === 0) {
				ChampSaisieTag.champOK(champ);
				erreurNir = true;
			} else {
				ChampSaisieTag.erreurChamp(champ, validErr.pattern);
				erreurNir = true;
			}
		}
	}
	return erreurNir;
}

/* controle du code postal */
/* @argument - champ : le champ a controller */
/* @argument - validErr : le msg si une erreur de validation client est remont�e */
function controlCodePostal(champ, validErr) {

	var codePosatlSaisie = champ.value;
	var erreurCP = false;
	var erreur = $(champ.id + '_messageErreur');

	// regex de validation d'un code postal
	var regExpFormatCodePostal = new RegExp("^[0-9]{5}$", "g");
	if (regExpFormatCodePostal.test(codePosatlSaisie)) {
		ChampSaisieTag.champOK(champ);
		erreurCP=false;
	} else {
		if (codePosatlSaisie.length === 0) {
			ChampSaisieTag.champOK(champ);
			erreurCP=true;
		} else {
			ChampSaisieTag.erreurChamp(champ, validErr.pattern);
			erreurCP=true;
		}
	}
	
	return erreurCP;
}

/* controlle du nom */
/* @argument - champ : le champ a controller */
/* @argument - validErr : le msg si une erreur de validation client est remont�e */
function controlNom(champ, validErr) {

	var erreurNom = false;
	
	if (champ.value.length > 0) {
		ChampSaisieTag.champOK(champ);
		erreurNom = false;
	} else {
		erreurNom = true;
		ChampSaisieTag.erreurChamp(champ, validErr.length);
	}
	
	return erreurNom;
}



// l'activation de bouton Continuer (pour la demande de code)
// @args - pC : portletContext
function enableBoutonDDC(pC){
	var disabled = false;
	// Si les 2 premiers champs sont OK
	if (controlNir($(pC + 'idNir'), errors[pC + 'idNir'])) 
		disabled = true;
	else if (controlDateNaissance($(pC + 'idDna'), errors[pC + 'idDna']))
		disabled = true;
	else if ($(pC + 'idBoxChoixEmail').checked && 
			  controlEmail($(pC + 'email'), errors[pC + 'email']))
		disabled = true;
	else if ($(pC + 'idBoxChoixCourrier').checked &&
	   		  (controlCodePostal($(pC + 'idCp'), errors[pC + 'idCp']) ||
	   		   controlNom($(pC + 'idNom'), errors[pC + 'idNom'])))
	   	disabled = true;
	else if (!$(pC + 'idBoxChoixCourrier').checked && !$(pC + 'idBoxChoixEmail').checked)
		disabled = true;
	else 
		disabled = false;
		
	$(pC + 'id_r_cnx_btn_submit').disabled = disabled;
}

// l'activation de bouton Continuer (pour la creation immediate de compte)
// @args - pC : portletContext
function enableBoutonCIC(pC){
	var disabled = false;
	// Si les 2 premiers champs sont OK
	if(controlNir($(pC + 'idNir'), errors[pC + 'idNir']))
		disabled = true;
	if (controlDateNaissance($(pC + 'idDna'), errors[pC + 'idDna']))
		disabled = true;
	if (controlCodePostal($(pC + 'idCp'), errors[pC + 'idCp']))
		disabled = true;
	if (controlNom($(pC + 'idNom'), errors[pC + 'idNom']))
		disabled = true;
	
	$(pC + 'id_r_cnx_btn_submit').disabled = disabled;
}
