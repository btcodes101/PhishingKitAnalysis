/**M�thode pour la gestion du bouton "Valider"*/
function gestionActivationValider(portletCtx){

	if(document.getElementById(portletCtx+'idConsentement')){
		//alert("existe "+document.getElementById(portletCtx+'idConsentement').checked);
		if(document.getElementById(portletCtx+'idConsentement').checked == true) {
			document.getElementById(portletCtx+'idBtValider').disabled = false;
		}else{
			document.getElementById(portletCtx+'idBtValider').disabled = true;
		}
	}else{
		document.getElementById(portletCtx+'idBtValider').disabled = false;
	}
}

/**M�thode AJAX appel� par "Valider"*/
function ajaxCallRemoteValiderConsentement(portletCtx){
	var consentement = document.getElementById(portletCtx+'idConsentement').checked;
	
	var functionActionUrl = '/PortailAS/recueilConsentement.do?actionEvt=envoyerConsentement&idNoCache=' + new Date().getTime() 
					+ '&consentement=' + consentement;
					//
		if (window.XMLHttpRequest)
		{	// Non-IE browsers
			req = new XMLHttpRequest();
			req.onreadystatechange = afficherConfirmation;
			req.open('GET', functionActionUrl, true);
			req.send(null);
		}
		else if (window.ActiveXObject)
		{	// IE
			req = new ActiveXObject('Microsoft.XMLHTTP');
			req.onreadystatechange = afficherConfirmation;
			req.open('GET', functionActionUrl, true);
			req.send();
		}
		else {
			return; // Navigateur non compatible
		}
}

// Methode private qui traite le retour de l'appel de ajaxCallRemoteValiderConsentement
function afficherConfirmation() {
	if (req.readyState == 4)
	{ 	// Complete
		if (req.status == 200)
		{ 	// OK response
			afficherMessage(req);
		 }
	}
}

function afficherMessage(req){
	//alert(req.responseText);
	var charSeparator = ":-:";
	
	var reponse = req.responseText;
	var retour = reponse.split(charSeparator);
	var reponseType = retour[0];
	var reponseValue = retour[1];
	
	
		//if (reponseValue==true){	
			document.getElementById('divFormulaire').style.display="none";
			document.getElementById('divRetour').style.display="block";
			document.getElementById('divConfirmation').style.display="block";
			document.getElementById('divMessageErreur').style.display="none";
		//}
		
		//if(reponseValue==false){
		//	document.getElementById('divFormulaire').style.display="none";
		//	document.getElementById('divRetour').style.display="block";		
		//	document.getElementById('divConfirmation').style.display="none";
		//	document.getElementById('divMessageErreur').style.display="block";	
		//}
	
}

