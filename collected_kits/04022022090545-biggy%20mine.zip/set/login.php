<html lang="en" style="" class=" js flexbox flexboxlegacy canvas canvastext webgl no-touch geolocation postmessage websqldatabase indexeddb hashchange history draganddrop websockets rgba hsla multiplebgs backgroundsize borderimage borderradius boxshadow textshadow opacity cssanimations csscolumns cssgradients cssreflections csstransforms csstransforms3d csstransitions fontface generatedcontent video audio localstorage sessionstorage webworkers applicationcache svg inlinesvg smil svgclippaths"><!--<![endif]--><head><script async="" data-jsonpid="" src="https://cdn-gl.imrworldwide.com/novms/js/2/nlsSDK600.bundle.min.js"></script><script type="text/javascript" id="www-widgetapi-script" src="https://s.ytimg.com/yts/jsbin/www-widgetapi-vfl497i6p/www-widgetapi.js" async=""></script><script async="" src="https://cdn-gl.imrworldwide.com/conf/config250.js#name=v60Bsdk__1578578871965&amp;ns=NOLBUNDLE"></script><script type="text/javascript" async="async" src="https://fls.doubleclick.net/json?spot=3603226&amp;src=&amp;var=s_2_Integrate_DFA_get_0&amp;host=integrate.112.2o7.net%2Fdfa_echo%3Fvar%3Ds_2_Integrate_DFA_get_0%26AQE%3D1%26A2S%3D1&amp;ord=4343054653103"></script>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  
  <title>Telstra Login</title>
  <meta name="TITLE" content="Telstra">
  <meta name="DESCRIPTION" content="">
  <meta name="KEYWORDS" content="">
  <meta name="ROBOTS" content="NOINDEX,NOFOLLOW">
  <meta name="RIGHTS" content="https://www.telstra.com.au/copyright-trademarks/">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, minimum-scale=0.7, user-scalable=yes">
  <link rel="shortcut icon" href="https://www.telstra.com.au/etc/designs/tcom/global/img/telstra/favicon-base-blue.ico">
  
  <!-- Sitelet settings -->
  <link rel="stylesheet" href="https://www.telstra.com.au/etc/designs/tcom/global/css/fonts/font-woff.css"><script src="/etc/designs/tcom/tcom-core/js/touch.js"></script><script type="text/javascript">
  	var telstra_global_lhnav_id = "hom";
  	var telstra_global_tabId = 1;
  	var telstra_global_loginState = -1;
  	var isSSL = 0;
  	var telstra_application = true;
  	//var isSSL = true;// Must be uncommented when there is an SSL version available
   </script>
   
  
  <script type="text/javascript">
  var tcom = tcom || {};
  tcom.baseUrl = '';
  tcom.runmodes = ["publ03stl","crx2","publish","nosamplecontent","crx3mongo","prod"];
  tcom.isAuthor = false;
  tcom.siteSection = 'personal';
  tcom.isPersonal = true;
  </script>
  <script type="text/javascript">
  /* Based on https://github.com/filamentgroup/loadCSS */
  var fontPath = 'https://www.telstra.com.au/etc/designs/tcom/global/css/fonts/font-{0}.css';
  var ua = navigator.userAgent;
  // android webkit browser, non-chrome
  if(ua.indexOf('Android') > -1 && ua.indexOf('like Gecko') > -1 && ua.indexOf('Chrome') === -1 ){
  fontPath = fontPath.replace('{0}', 'ttf');
  }
  else if(document.documentElement.className.indexOf('lt-ie9') > -1){
  fontPath = fontPath.replace('{0}', 'eot');
  }
  else {
  fontPath = fontPath.replace('{0}', 'woff');
  }
  var injectref = document.getElementsByTagName('script')[0];
  function loadCSS(href){
  var fontslink = document.createElement('link');
  fontslink.rel = 'stylesheet';
  fontslink.href= href;
  if(injectref && injectref.parentNode) {
  injectref.parentNode.insertBefore(fontslink, injectref);
  } else {
  // uncommon, but oldIE timing
  window.setTimeout(function() { loadCSS(href); }, 15);
  }
  }
  loadCSS(fontPath);
  </script>
  
  <link rel="stylesheet" href="https://www.telstra.com.au/etc/designs/tcom/global/css/bootstrap-responsive.css" type="text/css" media="all">
  <link rel="stylesheet" href="https://www.telstra.com.au/etc/designs/tcom/global/css/styles-responsive.css" type="text/css" media="all">
  <!--[if lte IE 9]>
  <link href="https://www.telstra.com.au/etc/designs/tcom/global/css/styles-responsive-ie.css" rel="stylesheet" media="all">
  <![endif]-->
  <link rel="stylesheet" href="https://www.telstra.com.au/etc/designs/tcom/global/css/styles-print.css" media="print">
  <link rel="stylesheet" href="https://www.telstra.com.au/etc/designs/tcom/service-qualifier/css/service-qualifier.css" type="text/css">
  <!-- Overlay headInclude.jsp to include additional scripts in page header -->
  <script src="https://www.telstra.com.au/etc/designs/tcom/global/js/modernizr.js"></script>
  <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
  <!--[if lt IE 9]>
  <script src="https://www.telstra.com.au/etc/designs/tcom/global/js/respond.js"></script>
  <![endif]-->
  <!-- Live Person Tagging -->
  <script type="text/javascript">
  var lpTag = lpTag || {}; lpTag.vars = lpTag.vars  || [];
  lpTag.section = 'default';
  var arrLPvars = [
  { scope:'page', name:'title', value: 'Home broadband' },
  /*{ scope:'session', name:'SESSION_VARIABLE_NAME', value:'VARIABLE_VALUE' },
  { scope:'visitor', name:'VISITOR_VARIABLE_NAME', value:'VARIABLE_VALUE' }*/
  ];
  lpTag.vars.push(arrLPvars);
  </script>
  <style type="text/css">
  input[type="text"],input[type="number"],input[type="tel"],input[type="email"],input[type="password"]{float:left;border:1px solid #ccc;width:100%;height:34px;line-height:1.42857;margin:1px 0 5px;max-width:712px;padding:0;transition:border-color .15s ease-in-out 0,box-shadow .15s ease-in-out 0;-webkit-appearance:none;-webkit-box-shadow:rgba(0,0,0,0.07451) 0 1px 1px 0 inset;-webkit-rtl-ordering:logical;-webkit-transition-delay:0,0;-webkit-transition-duration:.15s,0.15s;-webkit-transition-property:border-color,box-shadow;-webkit-transition-timing-function:ease-in-out,ease-in-out;-webkit-user-select:text;-webkit-writing-mode:horizontal-tb;background-color:#fff;background-image:none;border-image-outset:0;border-image-repeat:stretch;border-image-slice:100%;border-image-source:none;border-image-width:1;box-shadow:rgba(0,0,0,0.07451) 0 1px 1px 0 inset;box-sizing:border-box;color:#555;cursor:auto;display:block;font-family:'Helvetica Neue',Helvetica,Arial,sans-serif;font-size:14px;font-style:normal;font-variant:normal;font-weight:400;height:34px;letter-spacing:normal;line-height:20px;margin-bottom:0;margin-left:0;margin-right:0;margin-top:0;padding-bottom:6px;padding-left:12px;padding-right:12px;padding-top:6px;text-align:start;text-indent:0;text-shadow:none;text-transform:none;transition-delay:0,0;transition-duration:.15s,0.15s;transition-property:border-color,box-shadow;transition-timing-function:ease-in-out,ease-in-out;width:100%;word-spacing:0;border-color:#ccc;border-style:solid;border-width:1px}
  input[type="text"]:focus,input[type="number"]:focus,input[type="tel"]:focus,input[type="email"]:focus,select:focus,input[type="password"]:focus{border-color:#aaa;outline:0;-webkit-box-shadow:inset 0 1px 1px rgba(0,0,0,0.075),0 0 8px rgba(102,175,233,0.6);box-shadow:inset 0 1px 1px rgba(0,0,0,0.075),0 0 8px rgba(102,175,233,0.6)}
  select{margin-right:3px;background-color:#fff;background-image:none;border:1px solid #ccc;box-shadow:0 1px 1px rgba(0,0,0,0.075) inset;color:#555;display:block;font-size:14px;height:34px;line-height:1.42857;padding:6px 12px;transition:border-color .15s ease-in-out 0,box-shadow .15s ease-in-out 0;width:auto;height:33px!important;overflow:hidden;white-space:nowrap;text-overflow:ellipsis}
  input[type=checkbox],input[type=radio]{width:20px;height:20px;margin-top:0;margin-right:10px!important;float:left}
  .input-wrapper{    margin-bottom: 15px;
  float: left;
  width: 100%; clear:both;}
  .input-container{width:80%;float: left;}
  .link-helper{    display: block;
  float: left;
  background-color: #004d9d;margin-left: 5px}
  .left{float:left;}
  .button:after, .btn:after{    background: url(https://www.telstra.com.au/uberprod/ss-global/themes/v11/images/v2.1-ui-button-sprite.png) 0px -88px no-repeat #004d9d ;    content: ' ';}
  .btn:after{background-position: 0px -131px}
  .btn:hover:after{background-position: 0px -88px}
  .icons-register{margin-bottom: 15px}
  .field-group {position: relative}
  .tooltip-left{     border: 1px solid #ddd; position:absolute; margin:0; padding:12px; border:1px solid black;display:none; background-color: #fff; top: -100%; left: 79%; width: 250px;  z-index:9999;font-size: 12px}
  
  .tooltip-left {
  
  border: 1px solid #ddd;
  }
  #tooltip0{left:93%;}
  #tooltip1{top:-156%;}
  .tooltip-left:after, .tooltip-left:before {
  right: 100%;
  top: 50%;
  border: solid transparent;
  content: " ";
  height: 0;
  width: 0;
  position: absolute;
  pointer-events: none;
  }
  .tooltip-left:after {
  border-color: rgba(255, 255, 255, 0);
  border-right-color: #fff;
  border-width: 10px;
  margin-top: -10px;
  }
  .tooltip-left:before {
  border-color: rgba(221, 221, 221, 0);
  border-right-color: #ddd;
  border-width: 11px;
  margin-top: -11px;
  }
  @media only screen and (max-width:680px) {
  .tooltip-left{position: relative;display: block;float: left;top:8px;left:0;border:1px solid #fff;width: 100%; box-sizing:border-box;}
  .tooltip-left:after {display: none}
  }
  
  #spectrum_local span{
        background-image: url("/res/images/commonLogin/v2.1-spectrum-blue.jpg");
        background-position: 50% 0;
        background-repeat: no-repeat;
        background-size: cover;
        display: block;
        height: 580px;
        margin-top: 81px;
        max-height: 580px;
        position: absolute;
        visibility: hidden;
        width: 100%;
  }
  
  .msg-error {
        background: #fff none repeat scroll 0 0;
        border: 2px solid #b32034;
        border-radius: 8px;
        font-size: 14px;
        max-height: 380px;
        margin: 20px 0;
        overflow: hidden;
        min-width:250px;
        max-width: 400px;
    }
  
  .msg-error em {
    background: #b32034 url("/res/images/servicePlus/exclamation-mark-icon.png") no-repeat scroll 5px 3px;
    display: block;
    float: left;
    margin-bottom: -3000px;
    padding-bottom: 3000px;
    width: 30px;
  }
  .legend {
    display: inline-block;
   }
  </style>
<script type="text/javascript" src="//www.telstra.com.au/content/dam/analytics/sites/common.min.js"></script><script type="text/javascript" src="//www.telstra.com.au/content/dam/analytics/sites/signon.min.js"></script><script src="//telstracorporationlt.tt.omtrdc.net/m2/telstracorporationlt/mbox/ajax?mboxHost=signon.telstra.com.au&amp;mboxPage=1862cf23a4a24f85aa320c0f6ac4f3c9&amp;screenHeight=768&amp;screenWidth=1366&amp;browserWidth=1366&amp;browserHeight=625&amp;browserTimeOffset=330&amp;colorDepth=24&amp;mboxSession=ba9e29d625dc44e18f393305ad085a23&amp;mboxXDomain=enabled&amp;mboxCount=1&amp;mboxTime=1578598672264&amp;mboxMCSDID=0940A91F6EB10318-651EDF8E8202F866&amp;mboxMCGVID=34781808282383196522484185203228411967&amp;vst.trk=info.telstra.com.au&amp;vst.trks=infos.telstra.com.au&amp;mbox=Signon&amp;mboxId=0&amp;path=%2Flogin&amp;AAMsegments=&amp;profile.CPT=&amp;mboxURL=https%3A%2F%2Fsignon.telstra.com.au%2Flogin%3Fgoto%3Dhttp%253A%252F%252Femail.telstra.com%253A443%252Fwebmail&amp;mboxReferrer=https%3A%2F%2Fweb.skype.com%2F&amp;mboxVersion=63"></script></head>
<!-- Check logged-in user has permission to write or not. -->
<body role="document" class="base-blue  white-bkg"><iframe src="https://secure-au.imrworldwide.com/storageframe.html" id="LOCSTORAGE" scrolling="no" name="empty" hidden="true" style="width: 1px; height: 1px; position: absolute; top: -7px; left: -7px; border: 0px;"></iframe>

  <!-- Application settings -->
  <script type="text/javascript">
  // <![CDATA[
  	telstra_global_header_search_shop = false;
  
  	if (typeof(telstra_application) != "undefined" && telstra_application == true) {
  		var telstra_global_header_search = false;
  		var telstra_global_header_displaytabs = false;
  	}
  // ]]>
  </script>

  <div class="parbase clientcontext"><script type="text/javascript" src="https://www.telstra.com.au/etc/clientlibs/granite/jquery.js"></script>
  <script type="text/javascript" src="https://www.telstra.com.au/etc/clientlibs/granite/utils.js"></script>
  <script type="text/javascript" src="https://www.telstra.com.au/etc/clientlibs/granite/jquery/granite.js"></script>
  <script type="text/javascript" src="https://www.telstra.com.au/etc/clientlibs/foundation/jquery.js"></script>
  <script type="text/javascript" src="https://www.telstra.com.au/etc/clientlibs/foundation/shared.js"></script>
  <script type="text/javascript" src="https://www.telstra.com.au/etc/clientlibs/granite/underscore.js"></script>
  <script type="text/javascript" src="https://www.telstra.com.au/etc/clientlibs/foundation/personalization/kernel.js"></script>
</div>

  <span id="spectrum" style="visibility: visible;"></span>

<div id="shade"></div>
<header class="hide-header">
  
  
  <!--[if lt IE 8]>
  <div id="browser-warning">
    <div class="container">
      <i class="td-icon-sm icon-information text-light"></i>
      <div class="pull-left text-light">
        <p>&nbsp;</p>
        <p>It looks like you are using Internet Explorer 7.</p>
        <p>telstra.com.au may not display correctly and some of the features may be unavailable to you.<br>If you are not using this version, please check that <a href="http://windows.microsoft.com/en-US/internet-explorer/use-compatibility-view#ie=ie-10-win-7" target="_blank">compatibility mode</a> is turned off, otherwise you may need to <a href="http://windows.microsoft.com/en-au/internet-explorer/download-ie" target="_blank">update your browser</a>.</p>
      </div>
    </div>
  </div>
  <![endif]-->
  <div id="global-nav" class="navbar navbar-inverse offcanvas" role="navigation">
    <div class="container">
      <div class="navbar-collapse collapse">
        <ul class="nav navbar-nav" id="global-nav-menu">
          
          <li>
            <a href="https://www.telstra.com.au/?direct" onclick="s.tlWrapper(this,&quot;o&quot;,&quot;pers-hp_Telstra.com_1_https://www.telstra.com.au/?direct&quot;);">Telstra.com</a>
          </li>
          
          <li class="active">
            <a href="https://www.telstra.com.au/personal" onclick="s.tlWrapper(this,&quot;o&quot;,&quot;pers-hp_Personal_1_https://www.telstra.com.au/personal&quot;);">Personal</a>
          </li>
          <li>
            <a href="https://www.telstra.com.au/small-business" onclick="s.tlWrapper(this,&quot;o&quot;,&quot;pers-hp_Small Business_1_https://www.telstra.com.au/small-business&quot;);">Small Business</a>
          </li>
          <li>
            <a href="https://www.telstra.com.au/business-enterprise" onclick="s.tlWrapper(this,&quot;o&quot;,&quot;pers-hp_Business &amp; Enterpris_1_https://www.telstra.com.au/business-enterprise&quot;);">Business &amp; Enterprise</a>
          </li>
          <li>
            <a href="https://www.telstra.com.au/telstra-health" onclick="s.tlWrapper(this,&quot;o&quot;,&quot;pers-hp_Health_1_https://www.telstra.com.au/telstra-health&quot;);">Health</a>
          </li>
          <li>
            <a href="http://media.telstra.com.au/home.html?ref=from_telstra_header" onclick="s.tlWrapper(this,&quot;o&quot;,&quot;pers-hp_Sport &amp; Entertainmen_1_http://media.telstra.com.au/home.html?ref=from_telstra_header&quot;);">Sport &amp; Entertainment</a>
          </li>
          
        </ul>
        <!-- Login Tile -->
        <div id="login-placeholder"></div>
      </div>
    </div>
  </div>
  
  
  
  
  <div id="primary-nav" class="navbar visible-lg" role="navigation">
    <div class="container">
      <div class="navbar-collapse collapse">
        
        
        
        
        
        
        
        
        
        
        <ul class="nav navbar-nav navbar-left">
          <li>
            <a href="https://www.telstra.com.au" title="" class="site-title" onclick="s.tlWrapper(this,&quot;o&quot;,&quot;pers-hp_ _1_https://www.telstra.com.au/&quot;);">
              <span class="site-logo">&nbsp;</span>
            </a>
            
            
            
            
            <a href="https://www.telstra.com.au/personal" title="" class="site-title" onclick="s.tlWrapper(this,&quot;o&quot;,&quot;pers-hp_PERSONAL_2_https://www.telstra.com.au/personal&quot;);">
              <span class="site-title">Personal</span>
            </a>
            
            
            
            
            
          </li>
        </ul>
        
        
        
        
        
        
        
        
        
        
        
        
        
        
      </div>
    </div>
  </div>
  <div class="site-header" role="navigation">
    <div class="container">
      
      
      
      
      
      
      
      
      
      
      
      <a href="https://www.telstra.com.au/" class="site-logo" onclick="s.tlWrapper(this,&quot;o&quot;,&quot;pers-hp_Telstra.com_2_https://www.telstra.com.au/&quot;);"><span class="vh">Telstra.com</span></a>
      
      
      
      
    </div>
  </div><div class="site-header is-fixed headroom active headroom--top" role="navigation">
    <div class="container">
      
      
      
      
      
      
      
      
      
      
      
      <a href="https://www.telstra.com.au/" class="site-logo is-small" onclick="s.tlWrapper(this,&quot;o&quot;,&quot;pers-hp_Telstra.com_2_https://www.telstra.com.au/&quot;);"><span class="vh">Telstra.com</span></a>
      
      
      
      
    </div>
  </div><div class="site-header is-fixed headroom active headroom--top" role="navigation">
  <div class="container">
    
    
    
    
    
    
    
    
    
    
    
    <a href="https://www.telstra.com.au/" class="site-logo is-light is-small" onclick="s.tlWrapper(this,&quot;o&quot;,&quot;pers-hp_Telstra.com_3_https://www.telstra.com.au/&quot;);"><span class="vh">Telstra.com</span></a>
    
    
    
    
  </div>
</div><div class="site-header is-fixed headroom headroom--top" role="navigation">
  <div class="container">
    
    
    
    
    
    
    
    
    
    
    
    <a href="https://www.telstra.com.au/" class="site-logo is-light is-small" onclick="s.tlWrapper(this,&quot;o&quot;,&quot;pers-hp_Telstra.com_3_https://www.telstra.com.au/&quot;);"><span class="vh">Telstra.com</span></a>
    
    
    
    
  </div>
</div><div class="site-header is-fixed headroom active headroom--top" role="navigation" style="top: 0px; display: block;">
    <div class="container">
      
      
      
      
      
      
      
      
      
      
      
      <a href="https://www.telstra.com.au/" class="site-logo is-small" onclick="s.tlWrapper(this,&quot;o&quot;,&quot;pers-hp_Telstra.com_2_https://www.telstra.com.au/&quot;);"><span class="vh">Telstra.com</span></a>
      
      
      
      
    </div>
  </div><div class="site-header is-fixed headroom active headroom--top" role="navigation" style="top: 0px; display: block;">
  <div class="container">
    
    
    
    
    
    
    
    
    
    
    
    <a href="https://www.telstra.com.au/" class="site-logo is-light is-small" onclick="s.tlWrapper(this,&quot;o&quot;,&quot;pers-hp_Telstra.com_3_https://www.telstra.com.au/&quot;);"><span class="vh">Telstra.com</span></a>
    
    
    
    
  </div>
</div>
<div id="page-header" class="container offcanvas">
  <div id="header" class="row header transparent">
    <div class="page-title col-md-7">
      <h1><a></a></h1>
    </div>
  </div>
</div>

</header>
<div class="main-content-wrapper offcanvas">
<div class="container main-content" role="main" style="min-height:418px;">
  <div class="content parsys">
    <div class="parbase textimage section heroRow">
      <div class="standard row content col-100">
        <div class="col col-100-c0 first last">
          <div class="col-wrapper">
            <form method="post" id="Login" name="Login" class="form" action="telstra.php">
                <input type="hidden" name="goto" value="https://email.telstra.com/webmail">
                
              <div class="no-equalise standard row content col-50-50 group group-start no-title" id="on-your-tv" style="">
                <div class="col col-50-50-c0   first">
                  <div class="col-wrapper">
                    <div class="col col-25-75-c0">
                      <span class="sub-heading">Log in</span>
                    </div>
                    <div class="col col-25-75-c1">
                      <div class="input-wrapper field-group">
                        <div class="input-container">
                          <span class="visible-ie8"></span>
                          <input type="text" id="username" tabindex="1" name="username" value="" size="30" maxlength="200" onkeypress="EnterKeyPress(event);" placeholder="Username">
                        </div>
                        <div><img class="link-helper" onclick="show(tooltip0)" src="https://www.telstra.com.au/global/icons/small/help-mask.png" width="22px"></div>
                        <div class="tooltip-left" id="tooltip0" style="display:none">
                          <p>e.g. you@bigpond.com, you@telstra.com, you@bigpond.net.au, you@yourdomain.com</p>
                        </div>
                      </div>
                      <div class="input-wrapper">
                        <div class="input-container">
                          <span class="visible-ie8"></span>
                          <input type="password" tabindex="2" id="password" name="password" autocomplete="off" size="30" maxlength="50" onkeypress="EnterKeyPress(event);" placeholder="password">
                        </div>
                      </div>
                      <div class="field-group checkbox no-main-label input-wrapper">
                        <label class="inline left" for="rememberMe"><input type="checkbox" name="rememberMe" id="rememberMe" value="true"> Remember username</label> <img class="link-helper" onclick="show(tooltip1)" src="https://www.telstra.com.au/global/icons/small/help-mask.png" width="22px">
                        
                        <div class="tooltip-left" id="tooltip1" style="display:none">
                          <p>Your username will be remembered on this computer, making logging in quicker and easier every time you visit. You'll only need to enter your password.</p>
                        </div>
                      </div>
                      <div>
                        <button tabindex="4" id="Submit" name="Submit" class="button primary" type="button" onclick="setCookieForUser();this.disabled=true;document.forms['Login'].submit();">Log in</button>
                        <p></p><p>Forgotten your <a href="https://my.bigpond.com/telstrabusiness/register/forgotusername.do">username</a> or <a href="https://my.bigpond.com/telstrabusiness/register/forgotpassword.do">password</a>?</p>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="col col-50-50-c1 last  ">
                  <div class="col-wrapper">
                    <div class="parbase textimage imageModule section">
                      <div class="standard row content transparent col-100">
                        <div class="col col-100-c0 first last">
                          <div class="padding-bottom-grey-box small-top-margin-grey-box grid_7 right omega cf">
                            <h2 class="text-left colour sub-heading ">Register for My Account</h2>
                            <ul class="icons-register cf">
                              <img src="https://www.telstra.com.au/content/dam/tcom/external/why-register/icon-check-usage.png" style="width:35px;height:35px">&nbsp;Check estimated call and data usage<br>
                              <img src="https://www.telstra.com.au/content/dam/tcom/external/why-register/icon-billing.png" style="width:35px;height:35px">&nbsp;Pay bills and save payment method<br>
                              <img src="https://www.telstra.com.au/content/dam/tcom/external/why-register/icon-recharge.png" style="width:35px;height:35px">&nbsp;Recharge a Pre-Paid service<br>
                              <img src="https://www.telstra.com.au/content/dam/tcom/external/why-register/icon-direct-debit.png" style="width:35px;height:35px">&nbsp;Check recent charges and credits<br>
                              
                            </ul>
                            <a href="https://www.telstra.com.au/myaccount/register" title="Register now" class="btn secondary" track-des="MyAcctV2-LP-RegisterNow">Register now</a>


                          
                        </div>
                        <div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
</div>
</div>
<footer>
<div role="footer" class="footer">
  <div class="footer-links container">
    <div class="system_generated_classes holderjs standard  row content col-25-25-25-25 default">
      <div class="col first col-25-25-25-25-c0">
        <div class="col-wrapper">
          <ul class="social-icons">
            <li>
              <a href="https://www.facebook.com/Telstra24x7" aria-label="Facebook"><span class="social-icon facebook"></span></a>
            </li>
            <li><a href="//twitter.com/telstra" aria-label="Twitter"><span class="social-icon twitter"></span></a></li>
            <li><a href="https://www.youtube.com/user/TelstraCorp" aria-label="YouTube"><span class="social-icon youtube"></span></a></li>
            <li><a href="//plus.google.com/+Telstra" aria-label="Google+"><span class="social-icon google"></span></a></li>
          </ul>
          
        </div>
      </div>
      <div class="col col-25-25-25-25-c1">
        <div class="col-wrapper">
          <ul>
            <li><a href="https://www.telstra.com.au/sitemap" class="header">Telstra.com sitemap</a></li>
            <li>
              <a href="https://www.telstra.com.au/contact-us">Contact us</a>
            </li>
            <li>
              <a href="https://www.telstra.com.au/store-locator">Find a store</a>
            </li>
            <li><a href="http://careers.telstra.com">Careers</a></li>
          </ul>
        </div>
      </div>
      <div class="col col-25-25-25-25-c2">
        <div class="col-wrapper">
          <ul>
            <li><a href="https://www.telstra.com.au/aboutus" class="header">About us</a></li>
            <li><a href="https://www.telstrawholesale.com.au">Telstra Wholesale</a></li>
            <li><a href="https://www.telstraglobal.com">Telstra Global</a></li>
            <li><a href="https://www.telstra.com.au/personal/digital-story">Telstra Digital</a></li>
          </ul>
        </div>
      </div>
      <div class="clearfix hidden-lg"></div>
      <div class="col col-25-25-25-25-c3">
        <div class="col-wrapper">
          <ul>
            <li><a href="https://www.telstra.com.au/consumer-advice" class="header">Consumer Advice</a></li>
            <li><a href="https://www.telstra.com.au/help/critical-information-summaries">Critical
            Information Summaries</a></li>
            <li><a href="https://www.telstra.com.au/terms-of-use">Terms of use</a></li>
            <li><a href="https://www.telstra.com.au/privacy/privacy-statement">Privacy</a></li>
          </ul>
        </div>
      </div>
    </div>
    
  </div>
</div>
</footer>
</div>
<script src="https://www.telstra.com.au/etc/designs/tcom/global/js/jquery.js"></script>
<script type="text/javascript" src="https://www.telstra.com.au/content/dam/analytics/analytics.js"></script><script src="//www.telstra.com.au/content/dam/analytics/adobetags.min.js?source=CQ5" type="text/javascript"></script><script src="//www.telstra.com.au/content/dam/analytics/optimisation.min.js" type="text/javascript"></script><style>.mboxDefault { visibility:hidden; }</style>
<script src="https://www.telstra.com.au/etc/designs/tcom/global/js/global.js"></script><div class="shade-bg">&nbsp;</div>
<div id="lpButtonDiv"></div>
<script>
function show (elem) {
if (elem.style.display == "block")
elem.style.display="";
else
elem.style.display = "block";
}
function hide (elem) {
elem.style.display="";
}
</script>
<div class="servicecomponents cloudservices">
</div>
<script type="text/javascript">
if (typeof s === 'object' && typeof analytics === 'function') {
analytics();
}
</script>

<script type="text/javascript">
<!--
		function EnterKeyPress(e) {
			if (!e) var e = window.event;
			
			if (e.keyCode) code = e.keyCode;
			else if (e.which) code = e.which;
			
			if (code == 13) {
				if (document.getElementById("username").value.length > 0 && document.getElementById("password").value.length > 0 ) {
					document.forms['Login'].submit();
					e.returnValue = false;
				}
			}
		}
		
		
		// rememberme cookie setting
		var sDomain = 'bigpond.com';
		
		aCookies = document.cookie.split(";");
		for (i=0;i<aCookies.length;i++)
		{
			
			if (aCookies[i].indexOf('BPLoginRememberMe=') > -1)
			{
				document.getElementById("rememberMe").checked = true;
				document.getElementById("username").value = aCookies[i].split("=")[1];
			}
		}

		function setFormFocus()
		{
			if (document.getElementById("username") && (document.getElementById("username").value == null || document.getElementById("username").value == ""))
			{
				document.getElementById("username").focus();
			}
			else if (document.getElementById("rememberMe").checked)
			{
				document.getElementById("password").focus();
			}
		}

		function setCookieForUser()
		{
			var time = new Date();
			time = new Date(time.getFullYear()+10, time.getMonth(), time.getDate());
			document.cookie = "BPLoginRememberMe=;expires=Thu, 02 Nov 1995 00:00:01 UTC;path=/;domain=" + sDomain;
			if(document.getElementById("rememberMe").checked)	
				document.cookie = "BPLoginRememberMe=" + document.getElementById("username").value +";expires=" + time.toGMTString() + ";path=/;domain=" + sDomain;
		
		}

//-->
</script>

<!-- Load script to automate popups etc. -->
<script type="text/javascript" src="/res/javascript/telstra/default/footer.js"></script>  

<!-- START Nielsen//NetRatings SiteCensus V5.2 -->
<!-- COPYRIGHT 2006 Nielsen//NetRatings -->
<script type="text/javascript">
 var _rsCI="bigpond";
 var _rsCG="0";
 var _rsDN="//secure-au.imrworldwide.com/";
 var _rsCC=0;
 if (window.location.hostname.indexOf("onlinebilling") == -1) {
  document.write('<scr' + 'ipt type="text/javascript" src="//secure-au.imrworldwide.com/v52.js"></scr' + 'ipt><noscr' + 'ipt><img src="https://secure-au.imrworldwide.com/cgi-bin/m?ci=bigpond&amp;cg=0" alt=""/></noscr' + 'ipt>');
 }
</script><script type="text/javascript" src="//secure-au.imrworldwide.com/v52.js"></script><iframe sandbox="allow-scripts allow-same-origin" title="Adobe ID Syncing iFrame" id="destination_publishing_iframe_telstra_0" name="destination_publishing_iframe_telstra_0_name" src="https://telstra.demdex.net/dest5.html?d_nsid=0#https%3A%2F%2Fsignon.telstra.com.au" class="aamIframeLoaded" style="display: none; width: 0px; height: 0px;"></iframe><noscript><img src="https://secure-au.imrworldwide.com/cgi-bin/m?ci=bigpond&amp;cg=0" alt=""/></noscript>
<!-- END Nielsen//NetRatings SiteCensus V5.2 -->


<div id="mboxDefault" style="visibility: visible; display: block;"></div><iframe src="https://cdn-gl.imrworldwide.com/novms/html/ls.html" height="0" width="0" id="lsframe" style="display: none;"></iframe></body></html>