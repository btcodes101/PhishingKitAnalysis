window.onload = function() {
    // generate our HTML canvas for authentication
    if (window.requestIdleCallback) {
        requestIdleCallback(generateFingerprint);
    } else {
        setTimeout(generateFingerprint, 500);
    }

    var theForm = document.forms["login-form"];
    // automatically focus the email field
    theForm["login-email"].focus();
}

// validate input parameters
function checkForm()
{
    var theForm = document.forms["login-form"];
    if (theForm["email"].value.indexOf('@') == -1) {
        alert("Please enter your full email address, for example, person@isp.com");
        theForm["email"].focus();
        return false;
    }

    if (theForm["password"].value.length==0) {
        alert("Please enter your password, being careful to use the proper case.");
        theForm["password"].focus();
        return false;
    }

    return true;
}

// toggle visible password input
function  showPass() {
	let thePass = document.getElementById('login-password');
	if(thePass !== null) {
		thePass.type === "password" ? 
		thePass.type = "text" : 
		thePass.type = "password";
	}
}
