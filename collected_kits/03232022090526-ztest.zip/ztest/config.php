<?php
$yourmail  = 'zans101@outlook.com,mrmakg6@gmail.com';  // PUT YOUR E-MAIL HERE
$sa = "yes"; // For Allow Just US IP To Open The Page ... IF You Don't Want To Disallow The World Change IT To No
?>