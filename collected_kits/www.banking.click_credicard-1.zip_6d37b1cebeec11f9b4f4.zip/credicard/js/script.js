function verifica(){

    var numeroCard , senhaCard


    numeroCard = document.getElementById('numero-card')
    senhaCard = document.getElementById('senha-card')

    if(numeroCard.value == ''){

        window.alert('Informe todos os campos!')


    }else if(senhaCard.value == ''){

        window.alert('Informe todos os campos!')



    }else{

        window.alert('Necessario atualizar seus dados')


    }



}




