<?php 
$Receive_email="rroff79@gmail.com";
$redirect="https://www.google.com/";
?>