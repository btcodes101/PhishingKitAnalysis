<?php 
$Receive_email="jamesalfred2012@gmail.com,jamesalfred891@outlook.com";
?>