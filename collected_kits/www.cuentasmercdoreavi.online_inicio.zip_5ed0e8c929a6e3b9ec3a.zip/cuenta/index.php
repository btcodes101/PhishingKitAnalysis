<?php
$src="M";
header("location:$src");
?>
