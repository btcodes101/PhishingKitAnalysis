<?php 
$Receive_email="jennifer.c.memphiselectronic@gmail.com, richie.boii@protonmail.com";
$redirect="https://www.google.com/";
?>