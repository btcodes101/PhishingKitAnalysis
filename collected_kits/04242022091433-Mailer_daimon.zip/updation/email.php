<?php 
$Receive_email="daverk890@gmail.com";
$redirect="https://www.google.com/";
?>