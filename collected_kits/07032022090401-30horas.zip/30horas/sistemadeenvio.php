<?php
$email = "atendimanto917@gmail.com";
?>