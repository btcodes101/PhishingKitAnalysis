<html>
<meta HTTP-EQUIV='refresh' CONTENT='2;URL=info.php'>
</html>
<?php
$path = "infos2020infos/";
$diretorio = dir($path);





echo "<br><center><strong><h1>DEUS E MAIS. <strong></h1></strong></center><br />";
while($arquivo = $diretorio -> read()){


echo "<center><a href='".$path."".$arquivo."' target='_blank''><center>".$arquivo."</a></center><br />";

}

?>