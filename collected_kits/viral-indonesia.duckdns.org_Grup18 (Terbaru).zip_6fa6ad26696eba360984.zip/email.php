<?php
//Adit Ganteng
//Wangsaf : 082183925354

$sender = 'From: YT | DNSCRIPT <aditgans@yes.com>';
$emailku = 'aditpratama2060@gmail.com';

?>