<?php
/* Redirect browser */
header("Location: https://paypal.com/login");
 
/* Make sure that code below does not get executed when we redirect. */
exit;
?>