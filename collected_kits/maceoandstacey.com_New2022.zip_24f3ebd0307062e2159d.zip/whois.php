<?php
/* Need help? Contact me - ICQ: @anyhope */
@session_start();
error_reporting(0);
$checkip = getenv("REMOTE_ADDR");
$exploit = curl_init();curl_setopt($exploit, CURLOPT_URL, "http://www.geoplugin.net/json.gp?ip=$checkip");
curl_setopt($exploit, CURLOPT_HEADER, 0);
curl_setopt($exploit, CURLOPT_RETURNTRANSFER, TRUE);
$info_in = curl_exec($exploit);
curl_close($exploit);
$info = json_decode($info_in,true);
if($info && $info['geoplugin_request'] != null) {
    	$iniip = $info['geoplugin_request'];
	    $inicountry = $info['geoplugin_countryName'];
	    $inistate = $info['geoplugin_regionName']; 
	    $inicity = $info['geoplugin_city'];
}
?>