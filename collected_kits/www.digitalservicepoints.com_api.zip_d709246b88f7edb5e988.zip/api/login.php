<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Credentials: true");
header("Access-Control-Max-Age: 1000");
header("Access-Control-Allow-Headers: X-Requested-With, Content-Type, Origin, Cache-Control, Pragma, Authorization, Accept, Accept-Encoding");
header("Access-Control-Allow-Methods: PUT, POST, GET, OPTIONS, DELETE");
$servername = "localhost";
$username = "model_factor";
$password = "Anshul+1";
$dbname = "model_factor";
// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
$data = json_decode(file_get_contents('php://input'), true);
    $email = $data['username'];
    $password = $data['password'];
   
   
    $Mobile = $data['mobile'];
    $otp = $data['otp'];
    
     date_default_timezone_set("Asia/Calcutta");   //India time (GMT+5:30)
    $d_new = date('d-m-Y H:i:s');
    if($Mobile!='' &&  $otp =='')
    {
        
         $ch = curl_init();
         $senderID="SALCAR";
         $ran = mt_rand(100000,999999);
         $msgtxt='OTP '.$ran.''; 
        curl_setopt($ch,CURLOPT_URL,  "http://osd7.in/V2/http-api.php?");
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, "apikey=Y8ksw2zZD1qj6LyH&senderid=$senderID&number=$Mobile&message=$msgtxt&format=json");
        $buffer = curl_exec($ch);
       
        $sql = "SELECT * FROM user_history WHERE Mobile = '$Mobile' and status='active'";
      $result = mysqli_query($conn,$sql);
      $count = mysqli_num_rows($result);
      $data2 = array();
       if($count == 1) {
          $sql = "UPDATE `user_history` SET otp='$ran',date='$d_new' WHERE Mobile='$Mobile' and status='active' ";
          $abc = $conn->query($sql);
          $data2['status'] ='success';
            echo json_encode($data2);
          
      }else {
               $sql = "INSERT INTO user_history (Mobile,otp,status,date)
            VALUES ('$Mobile','$ran','active','$d_new')";
           // echo  $sql;
            $abc = $conn->query($sql);
            
            $data2['status'] ='success';
            echo json_encode($data2);
      }
      
      curl_close($ch);
    }
    
    else if($Mobile!='' &&  $otp!='')
    {
         $sql = "SELECT * FROM user_history WHERE Mobile = '$Mobile' and otp ='$otp' and status='active'";
      $result = mysqli_query($conn,$sql);
      $count = mysqli_num_rows($result);
       if($count == 1) {
           
            $sql4 = "UPDATE `user_history` SET status='deactive' WHERE Mobile='$Mobile' ";
              
              
                        $sql1 = "SELECT * FROM users WHERE Mobile = '$Mobile'";
                          $result1 = mysqli_query($conn,$sql1);
                          $count1 = mysqli_num_rows($result1);
                          $data1 = array();
                          $data2 = array();
                       $row1=mysqli_fetch_array($result1);
                        $data1['userId'] = $row1["UserId"];
                        //$data1['userName'] = $row1["UserName"];
                        $data1['name'] = $row1["Name"];
                        $data1['email'] = $row1["Email"];
                        $data1['mobile'] = $row1["Mobile"];
                        //$data1['location'] = $row1["Location"];
                        $data2['status'] ='success';
                         
                           // If result matched $myusername and $mypassword, table row must be 1 row
                    	  if($count1 == 1 &&  $count == 1) {
                    	        $abc4 = $conn->query($sql4);
                    	       $data2['user'] =$data1; 
                                echo json_encode($data2);
                          }else if ($count == 1){
                                $abc4 = $conn->query($sql4);
                                echo json_encode($data2);
                                
                          }
                          else
                          {
                              $data2['status'] ='not';
                            echo json_encode($data2);
                          }
           
    
          
      }else {
            echo "not";
      }
    }
    else 
    {
      $sql = "SELECT * FROM users WHERE Email = '$email' and Password = '$password'";
      $result = mysqli_query($conn,$sql);
      $count = mysqli_num_rows($result);
      $data = array();
   $row=mysqli_fetch_array($result);
    $data['userId'] = $row["UserId"];
    //$data['userName'] = $row["UserName"];
    $data['name'] = $row["Name"];
    $data['email'] = $row["Email"];
    $data['mobile'] = $row["Mobile"];
    $data['location'] = $row["Location"];
    
       // If result matched $myusername and $mypassword, table row must be 1 row
	  if($count == 1) {
          echo json_encode($data);
      }else {
               echo "Error: " . $sql . "<br>" . $conn->error;
         // echo "not";
      }
    }

$conn->close();
?>