<?php

defined('dtsheader') or die('Page not Found');



include_once 'function/config.ini.php';

require_once 'controller/login-controller.php';



$Login = new Loginvle($conn);





$LoginDbKey = $_SESSION['LoginDbKey'];



$stmt = $conn->prepare("SELECT * FROM vle_master WHERE id=?");



if ($stmt->execute([$LoginDbKey])) {



        $LoginDetails = $stmt->fetchAll(PDO::FETCH_ASSOC);

        $_SESSION['LoginDetails'] = $LoginDetails;

        

        



}



?>

<!DOCTYPE html>

<html lang="en">

    <head>

        <meta charset="utf-8">

        <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=0" />

        <title>Digital Service Point || Vle Panel</title>

        <link href="assets/css/sweetalert2.min.css" rel="stylesheet" type="text/css" />

        <link href="bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css" />

        <link href="assets/css/bootstrap-select.min.css" rel="stylesheet" type="text/css" />

        <link href="assets/css/fileinput.min.css" rel="stylesheet" type="text/css" />

        <link href="assets/css/bootstrap-datepicker.css" rel="stylesheet" type="text/css" />

        <!--[if lt IE 9]><link rel="stylesheet" type="text/css" href="plugins/jquery-ui/jquery.ui.1.10.2.ie.css"/><![endif]-->

        <link href="assets/css/main.css" rel="stylesheet" type="text/css" />

        <link href="assets/css/plugins.css" rel="stylesheet" type="text/css" />

        <link href="assets/css/responsive.css" rel="stylesheet" type="text/css" />

        <link href="assets/css/icons.css" rel="stylesheet" type="text/css" />

        <link rel="stylesheet" href="assets/css/fontawesome/font-awesome.min.css">

        <!--[if IE 7]><link rel="stylesheet" href="assets/css/fontawesome/font-awesome-ie7.min.css"><![endif]-->

        <!--[if IE 8]><link href="assets/css/ie8.css" rel="stylesheet" type="text/css"/><![endif]-->

        <link href='http://fonts.googleapis.com/css?family=Open+Sans:400,600,700' rel='stylesheet' type='text/css'>

    </head>



    <body>

        <header class="header navbar navbar-fixed-top" role="banner">

            <div class="container">

                <ul class="nav navbar-nav">

                    <li class="nav-toggle"><a href="javascript:void(0);" title=""><i class="icon-reorder"></i></a></li>

                </ul>

                <a class="navbar-brand" href="index"><strong>Vle </strong>Panel </a>

                <a href="#" class="toggle-sidebar bs-tooltip" data-placement="bottom" data-original-title="Toggle navigation"> <i class="icon-reorder"></i> </a>

                <ul class="nav navbar-nav navbar-left hidden-xs hidden-sm">

                    <li> <a href="index"> Dashboard </a> </li>

                </ul>

                <ul class="nav navbar-nav navbar-right">

<!--                    <li class="dropdown">

                        <a href="#" class="dropdown-toggle" data-toggle="dropdown"> <i class="icon-bell "></i> <span class="badge">5</span> </a>

                        <ul class="dropdown-menu extended notification">

                            <li class="title">

                                <p>You have 5 new notifications</p>

                            </li>

                            <li>

                                <a href="javascript:void(0);"> <span class="label label-success"><i class="icon-plus"></i></span> <span class="message">New user registration.</span> <span class="time">1 mins</span> </a>

                            </li>

                            <li>

                                <a href="javascript:void(0);"> <span class="label label-danger"><i class="icon-warning-sign"></i></span> <span class="message">High CPU load on cluster #2.</span> <span class="time">5 mins</span> </a>

                            </li>

                            <li>

                                <a href="javascript:void(0);"> <span class="label label-success"><i class="icon-plus"></i></span> <span class="message">New user registration.</span> <span class="time">10 mins</span> </a>

                            </li>

                            <li>

                                <a href="javascript:void(0);"> <span class="label label-info"><i class="icon-bullhorn"></i></span> <span class="message">New items are in queue.</span> <span class="time">25 mins</span> </a>

                            </li>

                            <li>

                                <a href="javascript:void(0);"> <span class="label label-warning"><i class="icon-bolt"></i></span> <span class="message">Disk space to 85% full.</span> <span class="time">55 mins</span> </a>

                            </li>

                            <li class="footer"> <a href="javascript:void(0);">View all notifications</a> </li>

                        </ul>

                    </li>

                    <li>

                        <a href="#" class="dropdown-toggle row-bg-toggle"> <i class="icon-resize-vertical"></i> </a>

                    </li>-->

                    <li class="dropdown user">

                        <a href="#" class="dropdown-toggle" data-toggle="dropdown"> <i class="icon-male"></i> <span class="username"><?php echo $_SESSION['LoginDetails'][0]['name']; ?></span> <i class="icon-caret-down small"></i> </a>

                        <ul class="dropdown-menu profileddl">

                            <li class="walletbalance">

                                <span>

                                    Wallet Balance<br><i class="icon-credit-card"></i> <?php echo $_SESSION['LoginDetails'][0]['my_wallet']; ?>/-

                                </span>

                            </li>

                            <li class="divider"></li>

                            <li><a href="profile"><i class="icon-user"></i> Profile</a></li>

                            <li><a href="model/logout-model?Operation=64364dfbdkvb"><i class="icon-signout"></i> Logout</a></li>

                        </ul>

                    </li>
                    
                     <li class="dropdown user">

                        <a href="#" class="dropdown-toggle" data-toggle="dropdown"> <i class="icon-male"></i> <span class="username"><?php echo $_SESSION['LoginDetails'][0]['name']; ?></span> <i class="icon-caret-down small"></i> </a>

                        <ul class="dropdown-menu profileddl">

                            <li class="walletbalance">

                                <span>

                                    Wallet Balance1<br><i class="icon-credit-card"></i> <?php echo $_SESSION['LoginDetails'][0]['my_wallet']; ?>/-

                                </span>

                            </li>

                            <li class="divider"></li>

                            <li><a href="profile"><i class="icon-user"></i> Profile</a></li>

                            <li><a href="model/logout-model?Operation=64364dfbdkvb"><i class="icon-signout"></i> Logout</a></li>

                        </ul>

                    </li>

                </ul>

            </div>

        </header>

        <div id="container">

            <div id="sidebar" class="sidebar-fixed">

                <div id="sidebar-content">

                    <div class="sidebar-search-results"> <i class="icon-remove close"></i>

                        <div class="title"> Documents </div>

                        <ul class="notifications">

                            <li>

                                <a href="javascript:void(0);">

                                    <div class="col-left"> <span class="label label-info"><i class="icon-file-text"></i></span> </div>

                                    <div class="col-right with-margin"> <span class="message"><strong>John Doe</strong> received $1.527,32</span> <span class="time">finances.xls</span> </div>

                                </a>

                            </li>

                            <li>

                                <a href="javascript:void(0);">

                                    <div class="col-left"> <span class="label label-success"><i class="icon-file-text"></i></span> </div>

                                    <div class="col-right with-margin"> <span class="message">My name is <strong>John Doe</strong> ...</span> <span class="time">briefing.docx</span> </div>

                                </a>

                            </li>

                        </ul>

                        <div class="title"> Persons </div>

                        <ul class="notifications">

                            <li>

                                <a href="javascript:void(0);">

                                    <div class="col-left"> <span class="label label-danger"><i class="icon-female"></i></span> </div>

                                    <div class="col-right with-margin"> <span class="message">Jane <strong>Doe</strong></span> <span class="time">21 years old</span> </div>

                                </a>

                            </li>

                        </ul>

                    </div>

                    <ul id="nav">

                        <li class="<?php if($page == 'dashboard'){ echo 'current'; } ?>">

                            <a href="index"> <i class="icon-dashboard"></i> Dashboard </a>

                        </li>

                        

                        <li class="<?php if($page == 'wallet-request'){ echo 'current'; } ?>">

                            <a href="wallet-request"> <i class="icon-tags"></i> Wallet Request </a>

                        </li>
                         <li class="<?php if($page == 'Financial Service'){ echo 'current'; } ?>">

                            <a href="https://retailer.novopay.in/login"> <i class="icon-tags"></i> Financial Service </a>

                        </li>

                        

                        <li class="<?php if($page == 'bill-pay'){ echo 'current'; } ?>">

                            <a href="bill-pay"> <i class="icon-inr"></i> Bill Pay </a>

                        </li>

                        

                        <li class="<?php if($page == 'send-gic' || $page == 'view-gic'){ echo 'current open'; } ?>">

                            <a href="javascript:void(0);"> <i class="icon-reorder"></i> General Insurance </a>

                            <ul class="sub-menu">

                                <li class="<?php if($page == 'send-gic'){ echo 'current'; } ?>">

                                    <a href="send-gic"> <i class="icon-angle-right"></i> Send Inquiry GIC </a>

                                </li>

                                <li class="<?php if($page == 'view-gic'){ echo 'current'; } ?>">

                                    <a href="view-gic"> <i class="icon-angle-right"></i> View GIC </a>

                                </li>

                            </ul>

                        </li>

                        

                        <li class="<?php if($page == 'passbook'){ echo 'current'; } ?>">

                            <a href="passbook"> <i class="icon-inr"></i> Passbook </a>

                        </li>

                        

                        <li class="<?php if($page == 'complaints'){ echo 'current'; } ?>">

                            <a href="complaints"> <i class="icon-comment"></i> View Complaints </a>

                        </li>

                        

                        

                        

                    </ul>

                    <div class="sidebar-title"> <span>Notifications</span> </div>

                    <ul class="notifications demo-slide-in">

                        <li style="display: none;">

                            <div class="col-left"> <span class="label label-danger"><i class="icon-envelope"></i></span> </div>

                            <div class="col-right with-margin"> <span class="message">Last prepaid recharge</span> <span class="time">1 day ago</span> </div>

                        </li>

                        <li style="display: none;">

                            <div class="col-left"> <span class="label label-info"><i class="icon-envelope"></i></span> </div>

                            <div class="col-right with-margin"> <span class="message">Last DTH recharge</span> <span class="time">3 hours ago</span> </div>

                        </li>

                        <li>

                            <div class="col-left"> <span class="label label-success"><i class="icon-envelope"></i></span> </div>

                            <div class="col-right with-margin"> <span class="message"><i class="icon-inr"></i> 500/- add to your wallet</span> <span class="time">3 hours ago</span> </div>

                        </li>

                    </ul>

                </div>

                <div id="divider" class="resizeable"></div>

            </div>