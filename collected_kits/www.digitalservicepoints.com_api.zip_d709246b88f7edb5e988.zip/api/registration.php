<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Credentials: true");
header("Access-Control-Max-Age: 1000");
header("Access-Control-Allow-Headers: X-Requested-With, Content-Type, Origin, Cache-Control, Pragma, Authorization, Accept, Accept-Encoding");
header("Access-Control-Allow-Methods: PUT, POST, GET, OPTIONS, DELETE");

$servername = "localhost";
$username = "model_factor";
$password = "Anshul+1";
$dbname = "model_factor";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

    $data = json_decode(file_get_contents('php://input'), true);
    $userName = $data['username'];
    $name = $data['name'];
    $email = $data['email'];
    $password = $data['password'];
    $mobile = $data['mobile'];
    $dob = $data['dob'];
    $cin_no = $data['cin_no'];
    
    $category = $data['category'];
     
    
  
    $location = $data['location'];
    $language = $data['language'];
    $work_location = $data['workLocation'];
    
    $ac_image = $data['imageUrl'];
    $age_restriction = $data['is18Plus'];
    if($age_restriction ==true)
    {
        $age_restriction = 1;
    }
    else
    {
        $age_restriction = 0;
    }
    $Organization_role = $data['companyType'];
    $Hire_for_role = $data['lookingFor'];
    $company_name = $data['companyName'];
    
    $status = $data['status'];
    
    
    date_default_timezone_set("Asia/Calcutta");   //India time (GMT+5:30)
    $d_new = date('d-m-Y H:i:s');
    
    
            $sql = "INSERT INTO users (CompanyType,LookingFor,CompanyName,Name,Email,Type,Password,Mobile,DOB,ImageUrl,Is18Plus,status,date)
            VALUES ('$Organization_role','$Hire_for_role','$company_name','$name','$email','$oppcode','$password', '$mobile','$dob','$ac_image','$age_restriction','$status','$d_new')";
            if ($conn->query($sql) === TRUE) {
                                                    $last_id = $conn->insert_id;
                                              foreach ($category as $key => $value) {
                                                                $new1= $value['value'];
                                                                  $sql1 = "INSERT INTO user_category (User_Id,Name)  VALUES ('$last_id','$new1')";
                                                                    $n = $conn->query($sql1);
                                                     }
                                                
                                                     foreach ($location as $key => $value ) {
                                                         
                                                                 $loc = $value['value'];
                                                                    $sql2 = "INSERT INTO user_location (User_Id,Name)  VALUES ('$last_id','$loc')";
                                                                    $n2 = $conn->query($sql2);
                                                     }
                                                     foreach ($language as $value) {
                                                           $lan = $value['value'];
                                                                    $sql3 = "INSERT INTO user_langauge (User_Id,Name)  VALUES ('$last_id','$lan')";
                                                                    $n3 = $conn->query($sql3);
                                                     }
                                                     foreach ($work_location as $value) {
                                                           $wok = $value['value'];
                                                                    $sql4 = "INSERT INTO user_worklocation (User_Id,Name)  VALUES ('$last_id','$wok')";
                                                                    $n4 = $conn->query($sql4);
                                                     }
                                                    echo "success";
                                            
                
            } else {
                                                echo "Error: " . $sql . "<br>" . $conn->error;
                                                //echo "not";
                                            }
$conn->close();
?>