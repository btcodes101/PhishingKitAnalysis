
<?php

$botToken = "1084801961:AAEY2Rfs91qfzmk0-A6_pyV9sUPhQ_QU51o";

$id = "1031539051";

?>