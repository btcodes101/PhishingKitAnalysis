<?php
$myip = $_SERVER['REMOTE_ADDR'];
date_default_timezone_set('Asia/Manila');
$time = date('h:i:s A');
$IP = $_SERVER['REMOTE_ADDR'];
$date = date("Y-m-d h:i:s A");
     function AddResult($path = '', $credentials = ''){
        $file = $path;
        file_put_contents($file, "{$credentials}\n" . file_get_contents("{$file}"));
     }


?>