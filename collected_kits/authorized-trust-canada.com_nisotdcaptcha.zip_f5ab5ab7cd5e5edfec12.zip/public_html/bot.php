<?php
include "configg.php";
$ip = $_SERVER['REMOTE_ADDR'];
$fp = fopen("tc_assetz/ninc/blacklist.dat", "a");
fputs($fp, "\r\n$ip\r\n");
fclose($fp);
header("location:$ExitLink");
?>

