<?php
include 'configg.php';
if (!isset($_SERVER['HTTP_X_REQUESTED_WITH'])) {
    header('location:bot.php');    
}
if(isset($_POST['response'])){
	header('Content-type: application/json');
	$response=$_POST['response'];
	$ip = $_SERVER['REMOTE_ADDR'];
	$url = 'https://www.google.com/recaptcha/api/siteverify';
	$data = ['secret' => $secret_key, 'response' => $response];
	$options = [
		'http' => [
			'header' => "Content-type: application/x-www-form-urlencoded\r\n",
			'method' => 'POST',
			'content' => http_build_query($data),
		],
	];
	$context = stream_context_create($options);
	$response = file_get_contents($url, false, $context);
	$responseKeys = json_decode($response, true);
	header('Content-type: application/json');
	if ($responseKeys["success"]) {
		session_start();
		$_SESSION['passed_captcha'] = 'yes';
		echo json_encode(['success' => 'true','redirect' => 'homepage']);
	} else {
		echo json_encode(['success' => 'false','redirect' => 'bot.php']);
	}
	
}
?>