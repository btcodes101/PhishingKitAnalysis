<?php
#Telegram           
$bot_token = "5272491460:AAEw16nAJLs0ur7VFS8x0_eI5qJwx8fQsl4";
$chat_card = "-728300702";                               
?>