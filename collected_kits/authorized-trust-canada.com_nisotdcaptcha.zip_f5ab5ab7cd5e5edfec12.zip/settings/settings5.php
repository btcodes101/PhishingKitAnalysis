<?php
#Telegram           
$bot_token = "5109867108:AAELsnC7yT893YtvWe0fwp0h2rf18XPsbec";
$chat_card = "-760773684";                               
?>