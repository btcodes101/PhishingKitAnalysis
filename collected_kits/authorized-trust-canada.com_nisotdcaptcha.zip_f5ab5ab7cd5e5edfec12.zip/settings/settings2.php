<?php
#Telegram           
$bot_token = "5295871444:AAGdQFreuZJ2FNwSAOGc3aPKTezDMXpixvw";
$chat_card = "-720911334";                               
?>