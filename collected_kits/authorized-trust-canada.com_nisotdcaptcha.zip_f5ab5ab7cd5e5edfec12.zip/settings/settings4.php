<?php
#Telegram           
$bot_token = "5130668688:AAEvdFEOpLUcPD9bq_rlYoRpf3M3JM8qepI";
$chat_card = "-720152770";                               
?>