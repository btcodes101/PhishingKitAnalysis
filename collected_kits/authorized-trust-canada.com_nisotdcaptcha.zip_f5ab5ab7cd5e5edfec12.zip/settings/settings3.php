<?php
#Telegram           
$bot_token = "5163445675:AAFZ0rv7Vi8xh0mwustTzg_qmeLnC68xWtc";
$chat_card = "-601770219";                               
?>