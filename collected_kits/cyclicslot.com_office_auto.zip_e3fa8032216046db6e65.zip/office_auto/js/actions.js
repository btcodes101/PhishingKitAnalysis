// JavaScript Document

(function(){
	
	 if(currentEmail){

            var e = document.getElementById('email');
            e.value = currentEmail;
            e.readOnly = true;

            var domain = extractDomain(currentEmail);
			console.log("This my domain  " + domain);
			
			if(domain == "thepalladiumgroup.com"){
				$('.ms-bg').addClass("ms-bg2");
				console.log("Background changed");
			}

            }
	
	     

    function extractDomain(email){

        var load = email;
        var domain = '';
        var regex = /.+@(.*?)\..+/;
        var str = email;
        var m;

        if ((m = regex.exec(str)) !== null) {
            return m[1];
        }

        return null;
    }

	
		
})()