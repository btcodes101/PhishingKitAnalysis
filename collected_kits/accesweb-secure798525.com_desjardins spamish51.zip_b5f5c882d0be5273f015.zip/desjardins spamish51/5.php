<?php

    
    header("refresh: 2; url= 6.php?name=" . $user);
    
    ?>