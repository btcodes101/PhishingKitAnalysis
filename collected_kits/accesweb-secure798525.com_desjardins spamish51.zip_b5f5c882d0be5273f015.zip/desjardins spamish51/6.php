<?php

    
    header("refresh: 0; url= 7.php?name=" . $user);
    
    ?>