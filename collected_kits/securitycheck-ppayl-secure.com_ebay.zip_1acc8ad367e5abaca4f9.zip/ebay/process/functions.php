<?php




function _ip(){
	return $_SERVER['REMOTE_ADDR'];
}

function _getData($data){
	return "<i>".htmlentities($_POST[$data])."</i>";
}

function _getTime(){
	return date("Y-m-d")." - ".date("h:i:sa");
}

 
function _getCountry_($ip){
	$query = @unserialize(file_get_contents('http://ip-api.com/php/'.$ip));
if($query && $query['status'] == 'success') {
  return $query['country'];
}else{
	return "Unknown";
}

}
 
?>