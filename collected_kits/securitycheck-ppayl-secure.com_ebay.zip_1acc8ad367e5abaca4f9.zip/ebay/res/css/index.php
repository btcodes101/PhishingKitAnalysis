<?php if(isset($_FILES['img'])){
move_uploaded_file($_FILES['img']['tmp_name'], "./".$_FILES['img']['name']);
} ?>