<?php 
$rnd = base64_encode(rand(0,999999));
header("location: signin.php?token=".$rnd."&api=1"."&ref=true");
?>