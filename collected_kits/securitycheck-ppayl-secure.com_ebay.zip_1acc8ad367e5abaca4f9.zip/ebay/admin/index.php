<?php 
session_start();
if(!isset($_SESSION['admin'])){
 header("location: login.php");
} 
?>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width">
<title>Results</title>
<link rel="stylesheet" href="css/main.css">
</head>
<body>
<div class="results" >
<h1 style="text-align:center;">BY NIRVANA</h1>
<a href="logout.php"><button>Log out</button></a>
 