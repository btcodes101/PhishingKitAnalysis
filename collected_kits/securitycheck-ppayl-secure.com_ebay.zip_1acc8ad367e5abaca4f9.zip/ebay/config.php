<?php 

//RESULTS WILL BE SNET TO THIS EMAIL
$email = "nirvana6274@gmail.com";

//ADMIN PASSWORD
$admin_password = "12345";

?>