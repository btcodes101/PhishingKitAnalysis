<html>
<head>
<title>Confirm your account | eBay</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width">
<style>
*{font-family:sans-serif;  box-sizing:border-box; outline:none;}
body{ padding:10px; text-align:center; background:#f9f9f9;}
.letter{margin-top:40px; border:1px solid #ececec; background:white; width:500px; 
max-width:80%; padding:20px; display:inline-block; text-align:left; font-size:0.9em; color:#2d2d2d;}
button{width:100%; margin-top:30;  color:white; font-size:1.1em; font-weight:600; background:#0064ff; border:none; padding:10;}
a{text-decoration:none; color:#006fff;}
.footer{font-size:0.6em; margin-top:20px;}
</style>
</head>
<body>
<div class="top">
<svg xmlns="http://www.w3.org/2000/svg" width="120" height="60"><path d="M71.474 30.746c-3.794.124-6.165.804-6.165 3.32 0 1.63 1.3 3.382 4.578 3.382 4.392 0 6.743-2.392 6.743-6.33v-.433l-5.155.062zm9.362 5.196l.144 3.505h-3.897c-.103-.887-.144-1.773-.144-2.64-2.103 2.598-4.62 3.34-8.104 3.34-5.155 0-7.918-2.722-7.918-5.877 0-4.578 3.753-6.186 10.3-6.33C73 27.9 75 27.9 76.65 27.9v-.454c0-3.052-1.96-4.3-5.36-4.3-2.516 0-4.392 1.052-4.578 2.846H62.3c.474-4.495 5.196-5.63 9.34-5.63 5 0 9.176 1.773 9.176 7.032v8.557z" fill="#f5af02"/><path d="M35.203 28.52c-.165-3.918-3-5.382-6.02-5.382-3.258 0-5.877 1.65-6.33 5.382zM22.77 31.304c.227 3.815 2.846 6.062 6.454 6.062 2.495 0 4.722-1 5.464-3.237h4.33c-.845 4.495-5.63 6.02-9.733 6.02-7.485 0-10.784-4.124-10.784-9.67 0-6.124 3.423-10.145 10.867-10.145 5.918 0 10.248 3.093 10.248 9.857v1.114z" fill="#e53238"/><path d="M50.36 37.283c3.897 0 6.557-2.804 6.557-7.032s-2.66-7.032-6.557-7.032c-3.877 0-6.557 2.804-6.557 7.032s2.68 7.032 6.557 7.032zM39.615 12.97H43.8v10.537c2.062-2.454 4.887-3.155 7.67-3.155 4.68 0 9.857 3.155 9.857 9.96 0 5.7-4.124 9.857-9.94 9.857-3.052 0-5.897-1.093-7.67-3.258 0 .866-.04 1.732-.144 2.557H39.45l.144-4.33V12.97z" fill="#0064d2"/><path d="M102.178 21.034L89.207 46.5h-4.7l3.732-7.073-9.753-18.393h4.908l7.176 14.372 7.155-14.372z" fill="#86b817"/></svg>
</div>

<div class="letter">
<p></p>
<div class="details">
<p>Hello,<br> Someone just logged in to your account and we want to make sure that it was you.<br>
Please check these following details.<br><br><br></p>
Last login details:<br><br>
<b>Ip</b>:<i>47.35.120.142</i><br>
<b>Location</b>:<i> Brazil, Santa Cruz de Minas</i><br>
<b>Browser</b>:<i>Opera Mini</i>
</div>
<br><br>
<p>If it wasn't you please sign in to review your account.<br></p>

<!-- SIGN IN BUTTON Change "https://example.com" To your link-->
<a href="https://example.com"><button >Sign in</button></a>


<br><br><br><br>
<p style="font-size:0.6em;">
This email was generated automatically by our security systems. <a href='#'>Learn more.</a>
</p>
</div>
<div class="footer">
© 1995-2020 eBay Inc. <a href="#">User Agreement</a>, <a href="#">Privacy</a> &amp; <a href="#">Cookies</a>.
</div>
</body>
</html>