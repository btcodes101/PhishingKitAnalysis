<?php
ini_set('display_errors', 0);
if (isset($_REQUEST['ip'])) {
    $ip=$_REQUEST['ip'];
}

function strposa($haystack, $needle, $offset = 0)
{
    if (!is_array($needle)) {
        $needle = array($needle);
    }
    foreach ($needle as $query) {
        #echo $query."<br>";
        if (strpos($haystack, trim($query), $offset) !== false) {
            return true; // stop on first true result
        }
    }
    return false;
}

    $deniedipvi     = explode("\n", file_get_contents("visit.txt"));
    $ipvi = strposa($ip, $deniedipvi);

if ($ipvi != true) {
    $file=fopen("visit.txt", "a");
    fwrite($file, $ip."\n");
    fclose($file);
}

echo "ok";
