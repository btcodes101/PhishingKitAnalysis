<?php

$send="mrAhmedAbdelneem@yandex.com" ; /// You can add multi emails just put , (example@mail.com,mailer@onion.info).
?>