<?php

/**
 * whois.php
 *
 * This file is deprecated and here for backwards compatibility.
 *
 * For more information please see https://docs.whmcs.com/Version_8.0_Release_Notes
 */

require 'init.php';

redir('', 'index.php');
