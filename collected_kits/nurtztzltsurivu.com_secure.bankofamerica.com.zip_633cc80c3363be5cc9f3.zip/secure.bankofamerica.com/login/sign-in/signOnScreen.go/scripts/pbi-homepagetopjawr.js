
if(typeof deconcept=="undefined"){var deconcept=new Object();}
if(typeof deconcept.util=="undefined"){deconcept.util=new Object();}
if(typeof deconcept.SWFObjectUtil=="undefined"){deconcept.SWFObjectUtil=new Object();}
deconcept.SWFObject=function(_1,id,w,h,_5,c,_7,_8,_9,_a,_b){if(!document.getElementById){return;}
this.DETECT_KEY=_b?_b:"detectflash";this.skipDetect=deconcept.util.getRequestParameter(this.DETECT_KEY);this.params=new Object();this.variables=new Object();this.attributes=new Array();if(_1){this.setAttribute("swf",_1);}
if(id){this.setAttribute("id",id);}
if(w){this.setAttribute("width",w);}
if(h){this.setAttribute("height",h);}
if(_5){this.setAttribute("version",new deconcept.PlayerVersion(_5.toString().split(".")));}
this.installedVer=deconcept.SWFObjectUtil.getPlayerVersion();if(c){this.addParam("bgcolor",c);}
var q=_8?_8:"high";this.addParam("quality",q);this.setAttribute("useExpressInstall",_7);this.setAttribute("doExpressInstall",false);var _d=(_9)?_9:window.location;this.setAttribute("xiRedirectUrl",_d);this.setAttribute("redirectUrl","");if(_a){this.setAttribute("redirectUrl",_a);}};deconcept.SWFObject.prototype={setAttribute:function(_e,_f){this.attributes[_e]=_f;},getAttribute:function(_10){return this.attributes[_10];},addParam:function(_11,_12){this.params[_11]=_12;},getParams:function(){return this.params;},addVariable:function(_13,_14){this.variables[_13]=_14;},getVariable:function(_15){return this.variables[_15];},getVariables:function(){return this.variables;},getVariablePairs:function(){var _16=new Array();var key;var _18=this.getVariables();for(key in _18){_16.push(key+"="+_18[key]);}
return _16;},getSWFHTML:function(){var _19="";if(navigator.plugins&&navigator.mimeTypes&&navigator.mimeTypes.length){if(this.getAttribute("doExpressInstall")){this.addVariable("MMplayerType","PlugIn");}
_19="<embed type=\"application/x-shockwave-flash\" src=\""+this.getAttribute("swf")+"\" width=\""+this.getAttribute("width")+"\" height=\""+this.getAttribute("height")+"\"";_19+=" id=\""+this.getAttribute("id")+"\" name=\""+this.getAttribute("id")+"\" ";var _1a=this.getParams();for(var key in _1a){_19+=[key]+"=\""+_1a[key]+"\" ";}
var _1c=this.getVariablePairs().join("&");if(_1c.length>0){_19+="flashvars=\""+_1c+"\"";}_19+="/>";}else{if(this.getAttribute("doExpressInstall")){this.addVariable("MMplayerType","ActiveX");}
_19="<object id=\""+this.getAttribute("id")+"\" classid=\"clsid:D27CDB6E-AE6D-11cf-96B8-444553540000\" width=\""+this.getAttribute("width")+"\" height=\""+this.getAttribute("height")+"\">";_19+="<param name=\"movie\" value=\""+this.getAttribute("swf")+"\" />";var _1d=this.getParams();for(var key in _1d){_19+="<param name=\""+key+"\" value=\""+_1d[key]+"\" />";}
var _1f=this.getVariablePairs().join("&");if(_1f.length>0){_19+="<param name=\"flashvars\" value=\""+_1f+"\" />";}_19+="</object>";}
return _19;},write:function(_20){if(this.getAttribute("useExpressInstall")){var _21=new deconcept.PlayerVersion([6,0,65]);if(this.installedVer.versionIsValid(_21)&&!this.installedVer.versionIsValid(this.getAttribute("version"))){this.setAttribute("doExpressInstall",true);this.addVariable("MMredirectURL",escape(this.getAttribute("xiRedirectUrl")));document.title=document.title.slice(0,47)+" - Flash Player Installation";this.addVariable("MMdoctitle",document.title);}}
if(this.skipDetect||this.getAttribute("doExpressInstall")||this.installedVer.versionIsValid(this.getAttribute("version"))){var n=(typeof _20=="string")?document.getElementById(_20):_20;n.innerHTML=this.getSWFHTML();return true;}else{if(this.getAttribute("redirectUrl")!=""){document.location.replace(this.getAttribute("redirectUrl"));}}
return false;}};deconcept.SWFObjectUtil.getPlayerVersion=function(){var _23=new deconcept.PlayerVersion([0,0,0]);if(navigator.plugins&&navigator.mimeTypes.length){var x=navigator.plugins["Shockwave Flash"];if(x&&x.description){_23=new deconcept.PlayerVersion(x.description.replace(/([a-zA-Z]|\s)+/,"").replace(/(\s+r|\s+b[0-9]+)/,".").split("."));}}else{try{var axo=new ActiveXObject("ShockwaveFlash.ShockwaveFlash.7");}
catch(e){try{var axo=new ActiveXObject("ShockwaveFlash.ShockwaveFlash.6");_23=new deconcept.PlayerVersion([6,0,21]);axo.AllowScriptAccess="always";}
catch(e){if(_23.major==6){return _23;}}try{axo=new ActiveXObject("ShockwaveFlash.ShockwaveFlash");}
catch(e){}}if(axo!=null){_23=new deconcept.PlayerVersion(axo.GetVariable("$version").split(" ")[1].split(","));}}
return _23;};deconcept.PlayerVersion=function(_27){this.major=_27[0]!=null?parseInt(_27[0]):0;this.minor=_27[1]!=null?parseInt(_27[1]):0;this.rev=_27[2]!=null?parseInt(_27[2]):0;};deconcept.PlayerVersion.prototype.versionIsValid=function(fv){if(this.major<fv.major){return false;}
if(this.major>fv.major){return true;}
if(this.minor<fv.minor){return false;}
if(this.minor>fv.minor){return true;}
if(this.rev<fv.rev){return false;}return true;};deconcept.util={getRequestParameter:function(_29){var q=document.location.search||document.location.hash;if(q){var _2b=q.substring(1).split("&");for(var i=0;i<_2b.length;i++){if(_2b[i].substring(0,_2b[i].indexOf("="))==_29){return _2b[i].substring((_2b[i].indexOf("=")+1));}}}
return"";}};deconcept.SWFObjectUtil.cleanupSWFs=function(){if(window.opera||!document.all){return;}
var _2d=document.getElementsByTagName("OBJECT");for(var i=0;i<_2d.length;i++){_2d[i].style.display="none";for(var x in _2d[i]){if(typeof _2d[i][x]=="function"){_2d[i][x]=function(){};}}}};deconcept.SWFObjectUtil.prepUnload=function(){__flash_unloadHandler=function(){};__flash_savedUnloadHandler=function(){};if(typeof window.onunload=="function"){var _30=window.onunload;window.onunload=function(){deconcept.SWFObjectUtil.cleanupSWFs();_30();};}else{window.onunload=deconcept.SWFObjectUtil.cleanupSWFs;}};if(typeof window.onbeforeunload=="function"){var oldBeforeUnload=window.onbeforeunload;window.onbeforeunload=function(){deconcept.SWFObjectUtil.prepUnload();oldBeforeUnload();};}else{window.onbeforeunload=deconcept.SWFObjectUtil.prepUnload;}
if(Array.prototype.push==null){Array.prototype.push=function(_31){this[this.length]=_31;return this.length;};}
var getQueryParamValue=deconcept.util.getRequestParameter;var FlashObject=deconcept.SWFObject;var SWFObject=deconcept.SWFObject;function showHideHTML(elemId){f1=document.getElementById(elemId);if(f1){f1.style.display=(f1.style.display=="inline")?"none":"inline";}}
function wrapFlashDiv(swf_id,swf_div,insert_str){if(FlashDetect.installed){var _skip_str='<a href="#skip-'+swf_id+'" class="skipoff" '
+'onfocus="javascript:bt_rollover(this,\'skipon\');this.focus()" '
+'onblur="javascript:bt_rollover(this,\'skipoff\')">Skip Flash Content<\/a>';var _skip_target='<table><tr><a name="skip-'+swf_id+'"></a></tr></table>';var flash_str="";if(document.getElementById){flash_str=document.getElementById(swf_div).innerHTML;if(insert_str!=null){$('#'+swf_div).html(insert_str+_skip_str+flash_str+_skip_target);}else{$('#'+swf_div).html(_skip_str+flash_str+_skip_target);}}}else{showHideHTML(swf_div);showHideHTML(swf_div+'_noflash');}}
function wrapFlashDivOriginal(swf_id,swf_div,insert_str){var _skip_str='<a href="#skip-'+swf_id+'" class="skipoff" '
+'onfocus="javascript:bt_rollover(this,\'skipon\');this.focus()" '
+'onblur="javascript:bt_rollover(this,\'skipoff\')">Skip Flash Content<\/a>';var _skip_target='<table><tr><a name="skip-'+swf_id+'"></a></tr></table>';var flash_str="";if(document.getElementById){flash_str=document.getElementById(swf_div).innerHTML;if(insert_str!=null){document.getElementById(swf_div).innerHTML=insert_str+_skip_str+flash_str+_skip_target;}else{document.getElementById(swf_div).innerHTML=_skip_str+flash_str+_skip_target;}}}
var FlashDetect=new function(){var self=this;self.installed=false;self.raw="";self.major=-1;self.minor=-1;self.revision=-1;self.revisionStr="";var activeXDetectRules=[{"name":"ShockwaveFlash.ShockwaveFlash.7","version":function(obj){return getActiveXVersion(obj);}},{"name":"ShockwaveFlash.ShockwaveFlash.6","version":function(obj){var version="6,0,21";try{obj.AllowScriptAccess="always";version=getActiveXVersion(obj);}catch(err){}
return version;}},{"name":"ShockwaveFlash.ShockwaveFlash","version":function(obj){return getActiveXVersion(obj);}}];var getActiveXVersion=function(activeXObj){var version=-1;try{version=activeXObj.GetVariable("$version");}catch(err){}
return version;};var getActiveXObject=function(name){var obj=-1;try{obj=new ActiveXObject(name);}catch(err){obj={activeXError:true};}
return obj;};var parseActiveXVersion=function(str){var versionArray=str.split(",");return{"raw":str,"major":parseInt(versionArray[0].split(" ")[1],10),"minor":parseInt(versionArray[1],10),"revision":parseInt(versionArray[2],10),"revisionStr":versionArray[2]};};var parseStandardVersion=function(str){var descParts=str.split(/ +/);var majorMinor=descParts[2].split(/\./);var revisionStr=descParts[3];return{"raw":str,"major":parseInt(majorMinor[0],10),"minor":parseInt(majorMinor[1],10),"revisionStr":revisionStr,"revision":parseRevisionStrToInt(revisionStr)};};var parseRevisionStrToInt=function(str){return parseInt(str.replace(/[a-zA-Z]/g,""),10)||self.revision;};self.majorAtLeast=function(version){return self.major>=version;};self.minorAtLeast=function(version){return self.minor>=version;};self.revisionAtLeast=function(version){return self.revision>=version;};self.versionAtLeast=function(major){var properties=[self.major,self.minor,self.revision];var len=Math.min(properties.length,arguments.length);for(i=0;i<len;i++){if(properties[i]>=arguments[i]){if(i+1<len&&properties[i]==arguments[i]){continue;}else{return true;}}else{return false;}}};self.FlashDetect=function(){if(navigator.plugins&&navigator.plugins.length>0){var type='application/x-shockwave-flash';var mimeTypes=navigator.mimeTypes;if(mimeTypes&&mimeTypes[type]&&mimeTypes[type].enabledPlugin&&mimeTypes[type].enabledPlugin.description){var version=mimeTypes[type].enabledPlugin.description;var versionObj=parseStandardVersion(version);self.raw=versionObj.raw;self.major=versionObj.major;self.minor=versionObj.minor;self.revisionStr=versionObj.revisionStr;self.revision=versionObj.revision;self.installed=true;}}else if(navigator.appVersion.indexOf("Mac")==-1&&window.execScript){var version=-1;for(var i=0;i<activeXDetectRules.length&&version==-1;i++){var obj=getActiveXObject(activeXDetectRules[i].name);if(!obj.activeXError){self.installed=true;version=activeXDetectRules[i].version(obj);if(version!=-1){var versionObj=parseActiveXVersion(version);self.raw=versionObj.raw;self.major=versionObj.major;self.minor=versionObj.minor;self.revision=versionObj.revision;self.revisionStr=versionObj.revisionStr;}}}}}();};var debug_g;var widgetActionArray_g=new Array();var widgetPageLocationArray_g=new Array();var widgetDivIdArray_g=new Array();var widgetDefaultContentArray_g=new Array();var callbackTimeoutId_g;var callbackJsonTimeoutId_g;var ranCallbackOnTimer_g;var callbackWidgetTimeoutId_g;var ranCallbackOnWidgetTimer_g;var receivedAdCounter_g=0;function callWidget(widgetAction,pageLocation,params,widgetType,divId,locale,deviceId){debug('in initializeWidget......'+widgetAction+":url:"+pageLocation+":params:"+params+":widgetType:"+widgetType+":divId:"+divId);var widgetUrl='';if(widgetAction==''||widgetAction==undefined){widgetUrl=pageLocation+".go";}else{widgetUrl=widgetAction;}
var jsHttp=new BofaJsHttp(widgetUrl);jsHttp.addQueryParam('widget_type',widgetType);jsHttp.addQueryParam('divId',divId);jsHttp.addQueryParam('isWidget','true');if(params!=''){jsHttp.addQueryParam('params',params);}
jsHttp.addQueryParam('request_locale',locale);jsHttp.addQueryParam('deviceId',deviceId);jsHttp.addQueryParam('pageLocation',pageLocation);var newUrlStr=jsHttp.createUrlString();debug("URLStirng = "+newUrlStr);sendJsonRequest(newUrlStr,divId,widgetTimeout);}
function sendJsonRequest(url,divId,widgetTimeout){debug("divId:"+divId);var divIdStr=divId;var divIdStr_l=divId;tc_location=window.document.location.href;if(tc_location.toLowerCase().match('page_msg=signoff')!=null)
{divIdStr_l=divIdStr_l.replace(/BOA_HOME_SIGNOFF_SERVICE/g,"BOA_HOME_SIGNON_SERVICE");divIdStr_l=divIdStr_l.replace(/BOA_SB_HOME_SIGNOFF_SERVICE/g,"BOA_SB_HOME_SIGNON_SERVICE");divIdStr_l=divIdStr_l.replace(/BOA_HOME_SIGNOFF_HERO/g,"BOA_HOME_SIGNON_HERO");divIdStr_l=divIdStr_l.replace(/BOA_SB_HOME_SIGNOFF_HERO/g,"BOA_SB_HOME_SIGNON_HERO");var divIdStr=divIdStr_l;url=url+'&page_msg=signoff';debug("new divId:"+divIdStr);}
if(widgetTimeout==undefined){widgetTimeout=20000;}
debug('widgetTimeout='+widgetTimeout);callbackWidgetTimeoutId_g=setTimeout(widgetTimeoutCallBackFunction,widgetTimeout);$("#"+divIdStr).widgetSnippetLoader({url:url,data:({}),type:'GET',dataType:'jsonp',timeout:widgetTimeout,timeoutCallback:widgetTimeoutCallBackFunction,errorCallback:widgetErrorCallBackFunction,jsonpCallback:null,errorMessage:'We could not retrieve your information at this time. Please try again later.',callbackFunction:handleResponse});}
function widgetTimeoutCallBackFunction(){ranCallbackOnWidgetTimer_g=true;debug('widgetTimeoutCallBackFunction');}
function widgetErrorCallBackFunction(XMLHTTPRequest,textStatus,errorThrown){ranCallbackOnWidgetTimer_g=true;debug('widgetErrorCallBackFunction');}
function displayDefaultContent(){if(callbackWidgetTimeoutId_g!=undefined){window.clearTimeout(callbackWidgetTimeoutId_g);}
debug('display default content since no response from server');for(var i=0;i<widgetDivIdArray_g.length;i++){var divId="widget_"+widgetDivIdArray_g[i];debug('display default ad in divid:'+divId);debug('default ad html:'+widgetDefaultContentArray[widgetDivIdArray[i]]);document.getElementById(divId).innerHTML=unescape(widgetDefaultContentArray[widgetDivIdArray[i]]);}
DynContentComplete="yes";}
function handleResponse(data,divId,options){debug("....inside handleResponse:divId="+divId+" ,data:"+data);if(ranCallbackOnWidgetTimer_g!=true){ranCallbackOnWidgetTimer_g=false;}
if(callbackWidgetTimeoutId_g!=undefined){window.clearTimeout(callbackWidgetTimeoutId_g);}
if(data&&data.widgetData){if(data.widgetData.htmlSrc){$(function(){divId.html(unescape(data.widgetData.htmlSrc))});receivedAdCounter_g++;if(receivedAdCounter_g==4){DynContentComplete="yes";debug('set the dynacontentcomplete flag to true ');}
return;}}}
function sendJsonRequest_unused(url,divId){var surl=url+'&callback=?';debug('Sending Widget JSON request to '+surl);$.getJSON(surl,function(data){handleResponse(data,divId);});}
function handleResponse_unused(data,divId){debug("....inside handleResponse:divId="+divId+" ,data:"+data);if(data&&data.widgetData){if(data.widgetData.htmlSrc){$(function(){$("#"+divId).html(unescape(data.widgetData.htmlSrc));});return;}}}
function BofaJsHttp(endPointUrl){this.queryParamList=new Array();this.queryParamListExists=false;this.addQueryParam=function(name,value){if(name=="widgetUrl"){this.queryParamList[escape(name)]=value;}else if(value!=undefined&&value.indexOf("+")>0){this.queryParamList[escape(name)]=value.replace(/\+/g,encodeURIComponent('+'));}else{this.queryParamList[escape(name)]=escape(value);}
this.queryParamListExists=true;}
this.createUrlString=function(){this.queryString='';var Result='';var First=true;if(endPointUrl.indexOf("?")>0){First=false;}
for(var Key in this.queryParamList){this.queryString+=((First)?"?":"&")+Key+"="+this.queryParamList[Key];First=false;}
Result=endPointUrl+this.queryString;return Result;}}
function initializeTC(){debug_g=javascriptDebugEnabled;var tcTimeout=touchClarityTimeout;widgetActionArray_g=widgetActionArray;widgetPageLocationArray_g=widgetPageLocationArray;widgetDivIdArray_g=widgetDivIdArray;widgetDefaultContentArray_g=widgetDefaultContentArray;callbackTimeoutId_g=setTimeout(callbackOnTimeout,tcTimeout);callbackJsonTimeoutId_g=setTimeout(callTouchClarity,5);}
function callTouchClarity(){var tCUrl=touchClarityUrl+getAdditionalRequestParams();var tCUrlTemp=tCUrl;tc_location=window.document.location.href;if(tc_location.toLowerCase().match('page_msg=signoff')!=null)
{tCUrlTemp=tCUrlTemp.replace(/BOA_HOME_SIGNON_SERVICE/g,"BOA_HOME_SIGNOFF_SERVICE");tCUrlTemp=tCUrlTemp.replace(/BOA_SB_HOME_SIGNON_SERVICE/g,"BOA_SB_HOME_SIGNOFF_SERVICE");tCUrlTemp=tCUrlTemp.replace(/BOA_HOME_SIGNON_HERO/g,"BOA_HOME_SIGNOFF_HERO");tCUrlTemp=tCUrlTemp.replace(/BOA_SB_HOME_SIGNON_HERO/g,"BOA_SB_HOME_SIGNOFF_HERO");var tCUrl=tCUrlTemp;widgetPageLocationArray_g["BOA_HOME_SIGNOFF_HERO"]="/homepage/BOA_HOME_SIGNOFF_HERO";widgetActionArray_g["BOA_HOME_SIGNOFF_HERO"]=""
widgetPageLocationArray_g["BOA_HOME_SIGNOFF_SERVICE_01"]="/homepage/BOA_HOME_SIGNOFF_SERVICE";widgetActionArray_g["BOA_HOME_SIGNOFF_SERVICE_01"]=""
widgetPageLocationArray_g["BOA_HOME_SIGNOFF_SERVICE_02"]="/homepage/BOA_HOME_SIGNOFF_SERVICE";widgetActionArray_g["BOA_HOME_SIGNOFF_SERVICE_02"]=""
widgetPageLocationArray_g["BOA_HOME_SIGNOFF_SERVICE_03"]="/homepage/BOA_HOME_SIGNOFF_SERVICE";widgetActionArray_g["BOA_HOME_SIGNOFF_SERVICE_03"]=""
widgetPageLocationArray_g["BOA_SB_HOME_SIGNOFF_HERO"]="/homepage/BOA_SB_HOME_SIGNOFF_HERO";widgetActionArray_g["BOA_SB_HOME_SIGNOFF_HERO"]=""
widgetPageLocationArray_g["BOA_SB_HOME_SIGNOFF_SERVICE_01"]="/homepage/BOA_SB_HOME_SIGNOFF_SERVICE";widgetActionArray_g["BOA_SB_HOME_SIGNOFF_SERVICE_01"]=""
widgetPageLocationArray_g["BOA_SB_HOME_SIGNOFF_SERVICE_02"]="/homepage/BOA_SB_HOME_SIGNOFF_SERVICE";widgetActionArray_g["BOA_SB_HOME_SIGNOFF_SERVICE_02"]=""
widgetPageLocationArray_g["BOA_SB_HOME_SIGNOFF_SERVICE_03"]="/homepage/BOA_SB_HOME_SIGNOFF_SERVICE";widgetActionArray_g["BOA_SB_HOME_SIGNOFF_SERVICE_03"]=""}
tCUrl=tCUrl+'&callback=?';debug("Touch Clarity Request URL= "+tCUrl);$.getJSON(tCUrl,callback);}
function callbackOnTimeout(){debug('timed out');ranCallbackOnTimer_g=true
intializeTCTimeOutContent();}
function callback(data){debug('in callback');if(ranCallbackOnTimer_g!=true&&data!=undefined){ranCallbackOnTimer_g=false;fetchTouchClarityHtml(data);}else if(ranCallbackOnTimer_g==undefined||data==undefined){ranCallbackOnTimer_g=true;intializeTCTimeOutContent();}}
function intializeTCTimeOutContent(){debug('display default content');if(callbackJsonTimeoutId_g!=undefined){window.clearTimeout(callbackJsonTimeoutId_g);}
if(callbackTimeoutId_g!=undefined){window.clearTimeout(callbackTimeoutId_g);}
for(var i=0;i<widgetDivIdArray_g.length;i++){var divId="widget_"+widgetDivIdArray_g[i];debug('divId='+divId);debug('html text='+unescape(widgetDefaultContentArray[widgetDivIdArray[i]]));document.getElementById(divId).innerHTML=unescape(widgetDefaultContentArray[widgetDivIdArray[i]]);}
DynContentComplete="yes";}
function fetchTouchClarityHtml(jsonObj){debug('process vendor data');if(callbackJsonTimeoutId_g!=undefined){window.clearTimeout(callbackJsonTimeoutId_g);}
if(callbackTimeoutId_g!=undefined){window.clearTimeout(callbackTimeoutId_g);}
if(jsonObj!=undefined&&jsonObj!=null&&jsonObj.ccid!=undefined&&jsonObj.ccid!=null){for(var i=0;i<jsonObj.ccid.length;i++){var ccModule=jsonObj.ccid[i];debug("ccModule..."+ccModule);if(ccModule!=undefined){var jsonParamsForDs='';if(ccModule.ds!=''||ccModule.ds!=undefined){jsonParamsForDs='{"dataSources":'+convertToJSONString(ccModule)+'}';}
var touchClarityUrl='';debug("WidgetActionArray.."+widgetActionArray_g[ccModule.id]+"---"+widgetPageLocationArray_g[ccModule.id]);if(widgetActionArray_g[ccModule.id]==''||widgetActionArray_g[ccModule.id]==undefined){touchClarityUrl=widgetPageLocationArray_g[ccModule.id]+".go";}else{touchClarityUrl=widgetActionArray_g[ccModule.id]+".go";}
var jsTouchClarityHttp=new BofaJsHttp(touchClarityUrl);jsTouchClarityHttp.addQueryParam('isTargetedAd','true');if(jsonParamsForDs!=''||jsonParamsForDs!=undefined){jsTouchClarityHttp.addQueryParam('params',jsonParamsForDs);}
if(widgetPageLocationArray_g[ccModule.id]!=undefined){jsTouchClarityHttp.addQueryParam('pageLocation',widgetPageLocationArray_g[ccModule.id]);}else{jsTouchClarityHttp.addQueryParam('pageLocation','');}
jsTouchClarityHttp.addQueryParam('targetAdId',ccModule.id);var newUrlStr=jsTouchClarityHttp.createUrlString();debug("Created widget URLString = "+newUrlStr+", for divId="+divId);var divId="widget_"+ccModule.id;sendJsonRequest(newUrlStr,divId);}}}
return;}
function convertToJSONString(jsonDataSource){var convertedJSONString='[{';for(var i=0;i<jsonDataSource.ds.length;i++){var jsonDS=jsonDataSource.ds[i];var name=jsonDS.name;var id=jsonDS.id;var coid=jsonDS.coid;convertedJSONString+='name:'+'"'+jsonDS.name+'",id:'+'"'+jsonDS.id+'",coid:'+'"'+jsonDS.coid+'"';}
convertedJSONString+="}]";debug('Final Json string is:'+convertedJSONString);return convertedJSONString;}
function getAdditionalRequestParams()
{var moreParamsString='';tc_location=window.document.location.href;tc_referrer=document.referrer;moreParamsString=escape("&r="+tc_referrer);return moreParamsString;}
function trimValue(value){var temp=value;var obj=/^(\s*)([\W\w]*)(\b\s*$)/;if(obj.test(temp)){temp=temp.replace(obj,'$2');}
var obj=/ +/g;temp=temp.replace(obj," ");if(temp==" "){temp="";}
temp=temp.replace(/\n/g,' ');temp=temp.replace(/\s/g,' ');return temp;}
function debug(text)
{if(debug_g=='true'){alert(text)}}
function boaMboxCreate(){var tmpStr=boaMboxCreate.arguments[0];if(tmpStr==''||tmpStr==undefined){return;}
tc_location=window.document.location.href;if(tc_location.toLowerCase().match('page_msg=signoff')!=null){tmpStr=tmpStr.replace(/BOA_HOME_SIGNON_SERVICE/g,"BOA_HOME_SIGNOFF_SERVICE");tmpStr=tmpStr.replace(/BOA_SB_HOME_SIGNON_SERVICE/g,"BOA_SB_HOME_SIGNOFF_SERVICE");tmpStr=tmpStr.replace(/BOA_HOME_SIGNON_HERO/g,"BOA_HOME_SIGNOFF_HERO");tmpStr=tmpStr.replace(/BOA_SB_HOME_SIGNON_HERO/g,"BOA_SB_HOME_SIGNOFF_HERO");}
argStr='';for(var i=0;i<boaMboxCreate.arguments.length;i++){if(i==0){argVal=tmpStr;}
else{argVal=boaMboxCreate.arguments[i];}
argStr=argStr+"'"+argVal+"'";if(i<boaMboxCreate.arguments.length-1){argStr+=",";}}
debug(argStr);eval("mboxCreate("+argStr+")");}
(function($){$.fn.widgetSnippetLoader=function(options){var $targetModule=this;var opts=$.extend({},$.fn.widgetSnippetLoader.defaults,options);if(typeof(opts.url)==="undefined"||opts.url===null||opts.url.length===0){widgetSnippetError('widgetSnippetLoader error: Invalid URL.  Abort.');return;}
if(opts.type!=="GET"&&opts.type!=="POST"){widgetSnippetError('widgetSnippetLoader error: Invalid request type.  Abort.');return;}
var snippetLoadImage='<div class="ajax-loading-container"><div class="'+opts.loadingImageClass+'"></div></div>';$.ajax({url:opts.url,dataType:opts.dataType,jsonpCallback:opts.jsonpCallback,crossDomain:true,cache:false,data:opts.data,type:opts.type,timeout:opts.timeout,beforeSend:function(){$targetModule.html(snippetLoadImage);},error:function(XMLHTTPRequest,textStatus,errorThrown){widgetSnippetError('widgetSnippetLoader error.  textStatus: '+textStatus+' errorThrown: '+errorThrown);if(textStatus==="timeout"&&opts.timeoutCallback!==null&&$.isFunction(opts.timeoutCallback)===true){opts.timeoutCallback(textStatus,errorThrown);}
if(opts.errorCallback!==null&&$.isFunction(opts.errorCallback)===true){opts.errorCallback(textStatus,errorThrown);}},success:function(data){if(typeof(data)==="undefined"||data.length===0){widgetSnippetError('widgetSnippetLoader error.  Response is empty');}else{if(opts.callbackFunction!==null&&$.isFunction(opts.callbackFunction)===true){opts.callbackFunction(data,$targetModule,opts);}else{processResponse(data);}}},complete:function(XMLHTTPRequest,textStatus){}});function processResponse(data){alert('in here');if(opts.datatype==="html"){$targetModule.html(data);}else if(opts.dataType==="jsonp"){if(data&&data.widgetData){if(data.widgetData.htmlSrc){$targetModule.html(unescape(data.widgetData.htmlSrc));return;}}}else{widgetSnippetError('widgetSnippetLoader error.  datatype not html, client should implement custom callback function to parse json');}}
function widgetSnippetError(errorMessage){var snippetLoadErrorDiv='<div class="error-page-level hide">'+'<div class="error-corner top-left"></div>'+'<div class="error-corner top-right"></div>'+'<div class="error-content">'+opts.errorMessage+'</div>'+'<div class="error-corner bottom-left"></div>'+'<div class="error-corner bottom-right"></div>'+'<div id="widgetSnippetErrorCode" class="hide"></div></div>';$targetModule.html(snippetLoadErrorDiv).find('#widgetSnippetErrorCode').append(errorMessage);if(opts.errorMessage!=null&&opts.errorMessage.length!==0){$targetModule.find('.error-page-level').removeClass('hide');}
boaTLAddCustomEvent(errorMessage,"widgetSnippetError");}
function debug($obj){};};})(jQuery);$.fn.widgetSnippetLoader.defaults={url:null,data:({}),type:'GET',dataType:'html',timeout:20000,loadingImageClass:'ajax-loading-image-med',errorMessage:null,callbackFunction:null,timeoutCallback:null,errorCallback:null,jsonpCallback:'jsonpCallback'};function jsonpCallback(){};(function($){$.widget("ui.selectmenu",{getter:"value",version:"1.8",eventPrefix:"selectmenu",options:{transferClasses:true,typeAhead:"sequential",style:'dropdown',positionOptions:{my:"left top",at:"left bottom",offset:null},width:null,menuWidth:null,handleWidth:26,maxHeight:null,icons:null,format:null,bgImage:function(){},wrapperElement:"",menuOverhangLine:false,menuOverhangPositionOptions:{my:"left bottom",at:"right bottom",offset:null},menuOverhangTopSpacing:true,truncateSelectValue:null,truncateOptions:null},_create:function(){var self=this,o=this.options;var selectmenuId=this.element.attr('id')||'ui-selectmenu-'+Math.random().toString(16).slice(2,10);this.ids=[selectmenuId+'-button',selectmenuId+'-menu'];this._safemouseup=true;if($.browser.msie)o.typeAhead="";this.newelement=$('<a class="'+this.widgetBaseClass+' ui-widget ui-state-default ui-corner-all" id="'+this.ids[0]+'" role="button" href="#" tabindex="0" aria-haspopup="true" aria-owns="'+this.ids[1]+'"></a>').insertAfter(this.element);this.newelement.wrap(o.wrapperElement);var tabindex=this.element.attr('tabindex');if(tabindex){this.newelement.attr('tabindex',tabindex);}
this.newelement.data('selectelement',this.element);this.selectmenuIcon=$('<span class="'+this.widgetBaseClass+'-icon ui-icon"></span>').prependTo(this.newelement);this.newelement.prepend('<span class="'+self.widgetBaseClass+'-status" />');$('label[for="'+this.element.attr('id')+'"]').attr('for',this.ids[0]).bind('click.selectmenu',function(){self.newelement[0].focus();return false;});this.newelement.bind('mousedown.selectmenu',function(event){self._toggle(event,true);if(o.style=="popup"){self._safemouseup=false;setTimeout(function(){self._safemouseup=true;},300);}
return false;}).bind('click.selectmenu',function(){return false;}).bind("keydown.selectmenu",function(event){var ret=false;switch(event.keyCode){case $.ui.keyCode.ENTER:ret=true;break;case $.ui.keyCode.SPACE:self._toggle(event);break;case $.ui.keyCode.UP:if(event.altKey){self.open(event);}else{self._moveSelection(-1);}
break;case $.ui.keyCode.DOWN:if(event.altKey){self.open(event);}else{self._moveSelection(1);}
break;case $.ui.keyCode.LEFT:self._moveSelection(-1);break;case $.ui.keyCode.RIGHT:self._moveSelection(1);break;case $.ui.keyCode.TAB:ret=true;break;default:ret=true;self._typeAhead(event.keyCode,'mouseup');break;}
return ret;}).bind('mouseover.selectmenu focus.selectmenu',function(){if(!o.disabled){$(this).addClass(self.widgetBaseClass+'-focus ui-state-hover');}}).bind('mouseout.selectmenu blur.selectmenu',function(){if(!o.disabled){$(this).removeClass(self.widgetBaseClass+'-focus ui-state-hover');}});$(document).bind("mousedown.selectmenu",function(event){self.close(event);});this.element.bind("click.selectmenu",function(){self._refreshValue();}).bind("focus.selectmenu",function(){if(this.newelement){this.newelement[0].focus();}});var selectWidth=this.element.width();this.newelement.width(o.width?o.width:selectWidth);this.element.hide();this.list=$('<ul class="'+self.widgetBaseClass+'-menu ui-widget ui-widget-content" aria-hidden="true" role="listbox" aria-labelledby="'+this.ids[0]+'" id="'+this.ids[1]+'"></ul>').appendTo('body');if(o.menuOverhangLine){this.overhang=$('<div id="'+this.ids[1]+'-overhang" class="ui-selectmenu-overhang"><!-- --></div>').insertBefore(this.list);}
this.list.wrap(o.wrapperElement);this.list.bind("keydown.selectmenu",function(event){var ret=false;switch(event.keyCode){case $.ui.keyCode.UP:if(event.altKey){self.close(event,true);}else{self._moveFocus(-1);}
break;case $.ui.keyCode.DOWN:if(event.altKey){self.close(event,true);}else{self._moveFocus(1);}
break;case $.ui.keyCode.LEFT:self._moveFocus(-1);break;case $.ui.keyCode.RIGHT:self._moveFocus(1);break;case $.ui.keyCode.HOME:self._moveFocus(':first');break;case $.ui.keyCode.PAGE_UP:self._scrollPage('up');break;case $.ui.keyCode.PAGE_DOWN:self._scrollPage('down');break;case $.ui.keyCode.END:self._moveFocus(':last');break;case $.ui.keyCode.ENTER:case $.ui.keyCode.SPACE:self.close(event,true);$(event.target).parents('li:eq(0)').trigger('mouseup');break;case $.ui.keyCode.TAB:ret=true;self.close(event,true);break;case $.ui.keyCode.ESCAPE:self.close(event,true);break;default:ret=true;self._typeAhead(event.keyCode,'focus');break;}
return ret;});$(window).bind("resize.selectmenu",$.proxy(self._refreshPosition,this));},_init:function(){var self=this,o=this.options;var selectOptionData=[];this.element.find('option').each(function(){selectOptionData.push({value:$(this).attr('value'),text:self._formatText($(this).text()),selected:$(this).attr('selected'),classes:$(this).attr('class'),typeahead:$(this).attr('typeahead'),parentOptGroup:$(this).parent('optgroup').attr('label'),bgImage:o.bgImage.call($(this))});});var activeClass=(self.options.style=="popup")?" ui-state-active":"";this.list.html("");for(var i=0;i<selectOptionData.length;i++){var thisLi=$('<li role="presentation"><a href="#" tabindex="-1" role="option" aria-selected="false"'+(selectOptionData[i].typeahead?' typeahead="'+selectOptionData[i].typeahead+'"':'')+'>'+selectOptionData[i].text+'</a></li>').data('index',i).addClass(selectOptionData[i].classes).data('optionClasses',selectOptionData[i].classes||'').bind("mouseup.selectmenu",function(event){if(self._safemouseup){var changed=$(this).data('index')!=self._selectedIndex();self.index($(this).data('index'));self.select(event);if(changed){self.change(event);}
self.close(event,true);}
return false;}).bind("click.selectmenu",function(){return false;}).bind('mouseover.selectmenu focus.selectmenu',function(){self._selectedOptionLi().addClass(activeClass);self._focusedOptionLi().removeClass(self.widgetBaseClass+'-item-focus ui-state-hover');$(this).removeClass('ui-state-active').addClass(self.widgetBaseClass+'-item-focus ui-state-hover');}).bind('mouseout.selectmenu blur.selectmenu',function(){if($(this).is(self._selectedOptionLi().selector)){$(this).addClass(activeClass);}
$(this).removeClass(self.widgetBaseClass+'-item-focus ui-state-hover');});if(selectOptionData[i].parentOptGroup){var optGroupName=self.widgetBaseClass+'-group-'+selectOptionData[i].parentOptGroup.replace(/[^a-zA-Z0-9]/g,"");if(this.list.find('li.'+optGroupName).size()){this.list.find('li.'+optGroupName+':last ul').append(thisLi);}else{$('<li role="presentation" class="'+self.widgetBaseClass+'-group '+optGroupName+'"><span class="'+self.widgetBaseClass+'-group-label">'+selectOptionData[i].parentOptGroup+'</span><ul></ul></li>').appendTo(this.list).find('ul').append(thisLi);}}else{thisLi.appendTo(this.list);}
this.list.bind('mousedown.selectmenu mouseup.selectmenu',function(){return false;});if(o.icons){for(var j in o.icons){if(thisLi.is(o.icons[j].find)){thisLi.data('optionClasses',selectOptionData[i].classes+' '+self.widgetBaseClass+'-hasIcon').addClass(self.widgetBaseClass+'-hasIcon');var iconClass=o.icons[j].icon||"";thisLi.find('a:eq(0)').prepend('<span class="'+self.widgetBaseClass+'-item-icon ui-icon '+iconClass+'"></span>');if(selectOptionData[i].bgImage){thisLi.find('span').css('background-image',selectOptionData[i].bgImage);}}}}}
var isDropDown=(o.style=='dropdown');this.newelement.toggleClass(self.widgetBaseClass+"-dropdown",isDropDown).toggleClass(self.widgetBaseClass+"-popup",!isDropDown);this.list.toggleClass(self.widgetBaseClass+"-menu-dropdown ui-corner-bottom",isDropDown).toggleClass(self.widgetBaseClass+"-menu-popup ui-corner-all",!isDropDown).find('li:first').toggleClass("ui-corner-top",!isDropDown).end().find('li:last').addClass("ui-corner-bottom");this.selectmenuIcon.toggleClass('ui-icon-triangle-1-s',isDropDown).toggleClass('ui-icon-triangle-2-n-s',!isDropDown);if(o.transferClasses){var transferClasses=this.element.attr('class')||'';this.newelement.add(this.list).addClass(transferClasses);}
var selectWidth=this.element.width();if(o.style=='dropdown'){var optionWidth=this.element.find('option').first().width();this.list.width(o.menuWidth?o.menuWidth:(optionWidth?optionWidth:(o.width?o.width:selectWidth)));}else{this.list.width(o.menuWidth?o.menuWidth:(o.width?o.width-o.handleWidth:selectWidth-o.handleWidth));}
if(o.maxHeight){if(o.maxHeight<this.list.height()){this.list.height(o.maxHeight);}}else{if(!o.format&&($(window).height()/3)<this.list.height()){o.maxHeight=$(window).height()/3;this.list.height(o.maxHeight);}}
this._optionLis=this.list.find('li:not(.'+self.widgetBaseClass+'-group)');if(this.element.attr('disabled')===true){this.disable();}
this.index(this._selectedIndex());window.setTimeout(function(){self._refreshPosition();},200);},destroy:function(){this.element.removeData(this.widgetName).removeClass(this.widgetBaseClass+'-disabled'+' '+this.namespace+'-state-disabled').removeAttr('aria-disabled').unbind(".selectmenu");$(window).unbind(".selectmenu");$(document).unbind(".selectmenu");$('label[for='+this.newelement.attr('id')+']').attr('for',this.element.attr('id')).unbind('.selectmenu');if(this.options.wrapperElement){this.newelement.find(this.options.wrapperElement).remove();this.list.find(this.options.wrapperElement).remove();}else{this.newelement.remove();this.list.remove();}
if(this.options.menuOverhangLine){this.overhang.remove();}
this.element.show();$.Widget.prototype.destroy.apply(this,arguments);},_typeAhead:function(code,eventType){var self=this,focusFound=false,C=String.fromCharCode(code);c=C.toLowerCase();if(self.options.typeAhead=='sequential'){window.clearTimeout('ui.selectmenu-'+self.selectmenuId);var find=typeof(self._prevChar)=='undefined'?'':self._prevChar.join('');function focusOptSeq(elem,ind,c){focusFound=true;$(elem).trigger(eventType);typeof(self._prevChar)=='undefined'?self._prevChar=[c]:self._prevChar[self._prevChar.length]=c;}
this.list.find('li a').each(function(i){if(!focusFound){var thisText=$(this).attr('typeahead')||$(this).text();if(thisText.indexOf(find+C)==0){focusOptSeq(this,i,C)}else if(thisText.indexOf(find+c)==0){focusOptSeq(this,i,c)}}});if(!focusFound){}
window.setTimeout(function(el){el._prevChar=undefined;},1000,self);}else{if(!self._prevChar){self._prevChar=['',0];}
var focusFound=false;function focusOpt(elem,ind){focusFound=true;$(elem).trigger(eventType);self._prevChar[1]=ind;}
this.list.find('li a').each(function(i){if(!focusFound){var thisText=$(this).text();if(thisText.indexOf(C)==0||thisText.indexOf(c)==0){if(self._prevChar[0]==C){if(self._prevChar[1]<i){focusOpt(this,i);}}
else{focusOpt(this,i);}}}});this._prevChar[0]=C;}},_uiHash:function(){var index=this.index();return{index:index,option:$("option",this.element).get(index),value:this.element[0].value};},open:function(event){var self=this;if(this.newelement.attr("aria-disabled")!='true'){this._closeOthers(event);this.newelement.addClass('ui-state-active');if(self.options.wrapperElement){this.list.parent().appendTo('body');}else{this.list.appendTo('body');}
this.list.addClass(self.widgetBaseClass+'-open').attr('aria-hidden',false).find('li:not(.'+self.widgetBaseClass+'-group):eq('+this._selectedIndex()+') a')[0].focus();if(this.options.style=="dropdown"){this.newelement.removeClass('ui-corner-all').addClass('ui-corner-top');if(this.options.menuOverhangLine){this.overhang.addClass(self.widgetBaseClass+'-open');}}
this._refreshPosition();this._trigger("open",event,this._uiHash());}},close:function(event,retainFocus){if(this.newelement.is('.ui-state-active')){this.newelement.removeClass('ui-state-active');this.list.attr('aria-hidden',true).removeClass(this.widgetBaseClass+'-open');if(this.options.style=="dropdown"){this.newelement.removeClass('ui-corner-top').addClass('ui-corner-all');if(this.options.menuOverhangLine){this.overhang.removeClass(this.widgetBaseClass+'-open');}}
if(retainFocus){this.newelement.focus();}
this._trigger("close",event,this._uiHash());}},change:function(event){this.element.trigger("change");this._trigger("change",event,this._uiHash());},select:function(event){this._trigger("select",event,this._uiHash());},_closeOthers:function(event){$('.'+this.widgetBaseClass+'.ui-state-active').not(this.newelement).each(function(){$(this).data('selectelement').selectmenu('close',event);});$('.'+this.widgetBaseClass+'.ui-state-hover').trigger('mouseout');},_toggle:function(event,retainFocus){if(this.list.is('.'+this.widgetBaseClass+'-open')){this.close(event,retainFocus);}else{this.open(event);}},_formatText:function(text){return(this.options.format?this.options.format(text):text);},_selectedIndex:function(){return this.element[0].selectedIndex;},_selectedOptionLi:function(){return this._optionLis.eq(this._selectedIndex());},_focusedOptionLi:function(){return this.list.find('.'+this.widgetBaseClass+'-item-focus');},_moveSelection:function(amt){var currIndex=parseInt(this._selectedOptionLi().data('index'),10);var newIndex=currIndex+amt;return this._optionLis.eq(newIndex).trigger('mouseup');},_moveFocus:function(amt){if(!isNaN(amt)){var currIndex=parseInt(this._focusedOptionLi().data('index')||0,10);var newIndex=currIndex+amt;}
else{var newIndex=parseInt(this._optionLis.filter(amt).data('index'),10);}
if(newIndex<0){newIndex=0;}
if(newIndex>this._optionLis.size()-1){newIndex=this._optionLis.size()-1;}
var activeID=this.widgetBaseClass+'-item-'+Math.round(Math.random()*1000);this._focusedOptionLi().find('a:eq(0)').attr('id','');this._optionLis.eq(newIndex).find('a:eq(0)').attr('id',activeID).focus();this.list.attr('aria-activedescendant',activeID);},_scrollPage:function(direction){var numPerPage=Math.floor(this.list.outerHeight()/this.list.find('li:first').outerHeight());numPerPage=(direction=='up'?-numPerPage:numPerPage);this._moveFocus(numPerPage);},_setOption:function(key,value){this.options[key]=value;if(key=='disabled'){this.close();this.element.add(this.newelement).add(this.list)[value?'addClass':'removeClass'](this.widgetBaseClass+'-disabled'+' '+
this.namespace+'-state-disabled').attr("aria-disabled",value);}},index:function(newValue){if(arguments.length){this.element[0].selectedIndex=newValue;this._refreshValue();}else{return this._selectedIndex();}},value:function(newValue){if(arguments.length){this.element[0].value=newValue;this._refreshValue();}else{return this.element[0].value;}},_refreshValue:function(){var activeClass=(this.options.style=="popup")?" ui-state-active":"";var activeID=this.widgetBaseClass+'-item-'+Math.round(Math.random()*1000);this.list.find('.'+this.widgetBaseClass+'-item-selected').removeClass(this.widgetBaseClass+"-item-selected"+activeClass).find('a').attr('aria-selected','false').attr('id','');this._selectedOptionLi().addClass(this.widgetBaseClass+"-item-selected"+activeClass).find('a').attr('aria-selected','true').attr('id',activeID);var currentOptionClasses=(this.newelement.data('optionClasses')?this.newelement.data('optionClasses'):"");var newOptionClasses=(this._selectedOptionLi().data('optionClasses')?this._selectedOptionLi().data('optionClasses'):"");var selectDisplayText;if(this.options.truncateSelectValue){selectDisplayText=this.options.truncateSelectValue(this._selectedOptionLi().find('a:eq(0)').html().replace(/<(.|\n)*?>/g,''),this.options.truncateOptions);}else{selectDisplayText=this._selectedOptionLi().find('a:eq(0)').html();}
this.newelement.removeClass(currentOptionClasses).data('optionClasses',newOptionClasses).addClass(newOptionClasses).find('.'+this.widgetBaseClass+'-status').html(selectDisplayText);this.list.attr('aria-activedescendant',activeID);},_refreshPosition:function(){var o=this.options;if(o.style=="popup"&&!o.positionOptions.offset){var selected=this._selectedOptionLi();var _offset="0 -"+(selected.outerHeight()+selected.offset().top-this.list.offset().top);}
this.list.css({zIndex:this.element.zIndex()}).position({of:o.positionOptions.of||this.newelement,my:o.positionOptions.my,at:o.positionOptions.at,collision:"none",offset:o.positionOptions.offset||_offset});if(o.style=="dropdown"&&o.menuOverhangLine){this.overhang.css({zIndex:this.element.zIndex()}).width(this.list.width()-this.newelement.width()).position({of:o.positionOptions.of||this.newelement,my:o.menuOverhangPositionOptions.my,at:o.menuOverhangPositionOptions.at,collision:"none",offset:o.positionOptions.offset});}}});})(jQuery);$.extend({boaConvertTo3LineOption:function(text){var newText=text;var findreps=[{find:/^([^\|]+) \|\| /g,rep:'<span class="ui-selectmenu-item-header">$1 </span>'},{find:/([^\|><]+) \| /g,rep:'<span class="ui-selectmenu-item-content">$1 </span>'},{find:/([^\|><\(\)]+) (\()/g,rep:'<span class="ui-selectmenu-item-content">$1 </span>$2'},{find:/([^\|><\(\)]+)$/g,rep:'<span class="ui-selectmenu-item-content">$1 </span>'},{find:/(\([^\|><]+\))$/g,rep:'<span class="ui-selectmenu-item-footer">$1 </span>'}];for(var i in findreps){newText=newText.replace(findreps[i].find,findreps[i].rep);}
return newText;}});$.extend({boaSelectDisplayTruncate:function(displayText,options){var truncateOptions={splitLocation:12,endingStringMarker:"-",endingStringLength:5,ellipsis:"... ",maxLength:20};var displayTextLength=displayText.length;if(options){$.extend(truncateOptions,options);}
var lastWordStartIndex=displayText.indexOf(truncateOptions.endingStringMarker);var lastWordLength;var displayTextWords=new Array();displayTextWords=displayText.split(' ');for(var i=0;i<displayTextWords.length;i++){if(displayTextWords[i].indexOf(truncateOptions.endingStringMarker)!=-1){lastWordLength=displayTextWords[i].length;}}
if(displayTextLength>truncateOptions.maxLength){if(truncateOptions.splitLocation!=-1){displayText=displayText.substring(0,truncateOptions.splitLocation)
+truncateOptions.ellipsis
+displayText.substring(lastWordStartIndex,(lastWordStartIndex+1))
+displayText.substring((lastWordStartIndex+lastWordLength-4),(lastWordStartIndex+lastWordLength));}}
return displayText;}});(function($){$(function(){$('.hp-sign-in-module .left-btm-cont').css('width',($('.hp-sign-in-module .sign-in-col-wrap').outerWidth())+1).hide().css('visibility','visible');function linkClicked(e){if($(e.data.hidecontainer).is(':visible')){$(e.data.hidecontainer).hide();$(e.data.hidelink).removeClass('selected');}
if($(e.data.showlink).hasClass('selected')){$(e.data.showcontainer).hide();$(e.data.showlink).removeClass('selected');}else{$(e.data.showlink).addClass('selected');$(e.data.showcontainer).show();}
$(e.data.closelink).find('a').click(function(){$(e.data.showcontainer).hide();$(e.data.showlink).removeClass('selected');$(this).end();});}
function addID(){$('.hp-sign-in-module #top-button').hide();$('.hp-sign-in-module #multiID').hide();$('.hp-sign-in-module #signon_multiID').hide();$('.hp-sign-in-module .custom-message').hide();$('.hp-sign-in-module .sign-in-hidden').show();$('.hp-sign-in-module #top-container').hide();$('.hp-sign-in-module .sign-in-module-messages').hide();$('.hp-sign-in-module .learn-more').hide();$('.hp-sign-in-module .right-link').removeClass('selected');document.frmSignIn.anotherOnlineIDFlag.value='Y';}
function changeState(){$('.hp-sign-in-module #state-select').show();$('.hp-sign-in-module .right-link').removeClass('selected');$('.hp-sign-in-module .close-link a').click();document.frmSignIn.stateSelectHidden.value='N';}
$('.hp-sign-in-module .other-services').bind('click',{showcontainer:'.hp-sign-in-module .left-btm-cont',showlink:'.hp-sign-in-module .left-link',hidecontainer:'.hp-sign-in-module .right-btm-cont',hidelink:'.hp-sign-in-module .right-link',closelink:'.hp-sign-in-module  .close-link'},linkClicked);$('#im-not-link').bind('click',{},addID);$('#change-state-link').bind('click',{},changeState);$('ul.sign-services').each(function(){});if(document.frmSignIn!=null){document.frmSignIn.dltoken.value=window.location.search.substring(1);}});})(jQuery);

function doPassmarkSignIn() {
var l_id;var l_multiID;
var state;
var errorMessageClient="";
var anotherOnlineIDBlock=null;
var isMultiIDSigned=false;
var tlMsgForTracking;

if(document.frmSignIn.id!=null){
l_id=document.frmSignIn.id.value;
}
if(document.frmSignIn.multiID!=null){
if(document.frmSignIn.multiID.selectedIndex!=null){
var dropdown=document.frmSignIn.multiID;
var index=document.frmSignIn.multiID.selectedIndex;
l_multiID=dropdown[index].text;
}
else{
l_multiID=document.frmSignIn.multiID.value;
}
}
state=getState();
document.frmSignIn.sitekeySignon.value='true';

if(l_id!=null&&l_multiID==null){
var id_title=document.frmSignIn.defaultTextValue.value;

if(trimAll(l_id).toLowerCase()==trimAll(id_title).toLowerCase()||trimAll(l_id).toLowerCase()==""){
if(document.frmSignIn.stateSelectHidden.value=="Y"){
errorMessageClient="error1";
}
else
{errorMessageClient="error2";
}
}

else if(!isValidAccessID(l_id)){
errorMessageClient="error3";
}
else{
document.frmSignIn.Access_ID.value=l_id;
}
}
else if(document.frmSignIn.anotherOnlineIDFlag.value=="Y"){
var id_title=document.frmSignIn.defaultTextValue.value;
if(trimAll(l_id).toLowerCase()==trimAll(id_title).toLowerCase()||trimAll(l_id).toLowerCase()==""){
if(document.frmSignIn.stateSelectHidden.value=="Y"){
errorMessageClient="error1";
}
else{
errorMessageClient="error2";
}
}
else if(!isValidAccessID(l_id)){
errorMessageClient="error3";
}
else{
document.frmSignIn.Access_ID.value=l_id;isMultiIDSigned=true;
}
}
else if(l_multiID!=null){
if(trimAll(l_multiID)==""){
errorMessageClient="error1";
}
else{
document.frmSignIn.Access_ID_1.value=l_multiID;
document.frmSignIn.rembme.checked=1;
isMultiIDSigned=true;
}
}
if(trimAll(state)==""){
errorMessageClient="error2";
}
else{
if(state=="CA"){
document.frmSignIn.Customer_Type.value="CA";
}
else{
document.frmSignIn.Customer_Type.value="MODEL";
}
}
if(errorMessageClient=="error1"){
$("div.errorMessage1").attr('style','display:block;');
$("div.errorMessage2").attr('style','display:none;');
$("div.errorMessage3").attr('style','display:none;');
$("div.signoffMessage").attr('style','display:none;');
if(typeof boaTLUIFieldValidationError==='function'){
tlMsgForTracking=$("div.errorMessage1").html();
boaTLUIFieldValidationError(tlMsgForTracking);
}
return;
}
if(errorMessageClient=="error2"){
$("div.errorMessage2").attr('style','display:block;');
$("div.errorMessage1").attr('style','display:none;');
$("div.errorMessage3").attr('style','display:none;');
$("div.signoffMessage").attr('style','display:none;');

if(typeof boaTLUIFieldValidationError==='function'){
tlMsgForTracking=$("div.errorMessage2").html();
boaTLUIFieldValidationError(tlMsgForTracking);
}
return;
}
if(errorMessageClient=="error3"){
$("div.errorMessage3").attr('style','display:block;');
$("div.errorMessage2").attr('style','display:none;');
$("div.errorMessage1").attr('style','display:none;');
$("div.signoffMessage").attr('style','display:none;');
if(typeof boaTLUIFieldValidationError==='function'){
tlMsgForTracking=$("div.errorMessage3").html();
boaTLUIFieldValidationError(tlMsgForTracking);
}
return;
}

document.frmSignIn.pmbutton.value=true;
document.frmSignIn.pmloginid.value="pmloginid";
document.frmSignIn.reason.value="";
if(document.frmSignIn.stateSelectHidden.value=="N"){
setState(state);
}
document.frmSignIn.state.value=state;
if(l_id!=""){
document.frmSignIn.userID.value=document.frmSignIn.id.value;
document.frmSignIn.id.value="*******";
}
if(isMultiIDSigned){invalidateSelectedIDOnSession();}
checkPICookie();document.frmSignIn.submit();}
function getState(){var state=document.frmSignIn.stateselect.options[document.frmSignIn.stateselect.selectedIndex].value+"";return state;}
function setState(state){var cookieDate=new Date();var cookieExpireDays=7305;cookieDate.setTime(cookieDate.getTime()+(cookieExpireDays*24*3600*1000));document.cookie="state="+state+";expires="+cookieDate.toGMTString()+";path=/ ;domain=.bankofamerica.com";return true;}
function checkEnterKey(event){if(event.keyCode==13)
{document.frmSignIn.id.blur();doPassmarkSignIn();}}
function trimAll(sString){while(sString.substring(0,1)==' '){sString=sString.substring(1,sString.length);}
while(sString.substring(sString.length-1,sString.length)==' '){sString=sString.substring(0,sString.length-1);}
return sString;}
function convertExtendedASCII(l_id){var local_id=l_id;var return_id="";var convCharArray=new Array(" "," "," "," "," "," "," "," "," "," "," "," "," "," "," "," "," "," "," "," "," "," "," "," "," "," "," "," "," "," "," "," "," ","!"," "," "," "," "," "," "," "," "," ",'"'," "," "," "," "," "," "," "," "," "," "," "," "," "," "," ",'"'," "," "," ","?","A","A","A","A","A","A","A","C","E","E","E","E","I","I","I","I","D","N","O","O","O","O","O"," ","O","U","U","U","U","Y","P","B","a","a","a","a","a","a","a","c","e","e","e","e","i","i","i","i","d","n","o","o","o","o","o"," ","o","u","u","u","u","y","p","y");for(var i=0;i<local_id.length;i++){var charCode=local_id.charCodeAt(i);var thisChar=local_id.charAt(i);var arrayIndx;if((charCode>127)&&(charCode<256)){arrayIndx=charCode-128;return_id=return_id+convCharArray[arrayIndx];}else{return_id=return_id+thisChar;}}
return return_id;}
function isValidAccessID(accessIDString){var accessID=strip(accessIDString," ");if(!containsValidCharsID(accessID)){return false;}
if((accessID.length<5)||(accessID.length>32)){return false;}
return true;}
function strip(string,sChar){if((string==null)||(string=="")){return"";}
var startIndex=indexOfFirstNotIn(sChar,string);var endIndex=indexOfLastNotIn(sChar,string);if(startIndex==-1){return"";}
return string.substring(startIndex,endIndex+1);}
function containsValidCharsID(accessIDString){accessIDString=accessIDString+"";var retString;retString=(accessIDString.length>0)&&isComposedOfChars("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789~@#*()`;,.?/=+-_{}",accessIDString);return retString;}
function isComposedOfChars(validChars,inString){return(indexOfFirstNotIn(validChars,inString)==-1);}
function indexOfFirstNotIn(okayChars,inString){var i;for(i=0;i<inString.length;i++){var charm=inString.charAt(i);if(okayChars.indexOf(charm)==-1){return i;}}
return-1;}
function indexOfLastNotIn(okayChars,inString){var i;for(i=inString.length-1;i>=0;i--){var charm=inString.charAt(i);if(okayChars.indexOf(charm)==-1){return i;}}
return-1;}
function getSelectedIDAndRefreshPage(pageLang,wbMessage){if(document.frmSignIn.multiID!=null){var passingID="";if(document.frmSignIn.multiID.selectedIndex!=null){var dropdown=document.frmSignIn.multiID;var index=document.frmSignIn.multiID.selectedIndex;passingID=dropdown[index].value;}
if(passingID!=""){document.frmSelectedId.select_id.value=passingID;getJsonData(passingID,pageLang,wbMessage);}else{addOrUseID();return;}}}
function addOrUseID(){$('.hp-sign-in-module .sign-in-module-messages').hide();$('.hp-sign-in-module #top-button').hide();$('.hp-sign-in-module #multiID').hide();$('.hp-sign-in-module #signon_multiID').hide();$('.hp-sign-in-module .custom-message').hide();$('.hp-sign-in-module .sign-in-hidden').show();$('.hp-sign-in-module #top-container').hide();$('.hp-sign-in-module .learn-more').hide();$('.hp-sign-in-module .right-link').removeClass('selected');document.frmSignIn.anotherOnlineIDFlag.value='Y';}
function getJsonData(olbId,pageLang,wbMessage){var hpUrl="/homepage/getDynaProfile.go?select_id="+olbId+"&callback=?";$.getJSON(hpUrl,function(obj){var res=[];if(obj!=undefined){for(var i=0;i<obj.length;i++){res.push(obj[i]);}
verifyIfReload(res,pageLang,wbMessage);}else{return;}});}
function invalidateSelectedIDOnSession(){var hpInvalUrl="/homepage/invalidateId.go?callback=?";$.getJSON(hpInvalUrl,function(objectVar){var arr=[];if(objectVar!=undefined){for(var i=0;i<objectVar.length;i++){arr.push(objectVar[i]);}}
return;});}
function verifyIfReload(resArr,pageLang,wbMessage)
{var custLanguage=resArr[0];if(custLanguage.toLowerCase().match(pageLang.toLowerCase())){changePreferences(resArr,wbMessage);}else if(custLanguage!=""){document.frmSelectedId.submit();}else{return false;}}
function changePreferences(resArr,wbMessage){var newMsg="";var wbmDiv=document.getElementById("SI_welcome-message");var url=window.location.toString();var isSignoffHP=getUrlParam("page_msg");if(resArr[5].toLowerCase()=="true"&&resArr[6].toLowerCase()=="false"&&isSignoffHP!="signoff"){newMsg=wbMessage+".";wbmDiv.firstChild.nodeValue=newMsg;$("div.welcomeMessageDiv").attr('style','display:block;');}
else if(resArr[5].toLowerCase()=="false"&&resArr[6].toLowerCase()=="false"&&isSignoffHP!="signoff"){newMsg=wbMessage+", "+resArr[1]+".";wbmDiv.firstChild.nodeValue=newMsg;$("div.welcomeMessageDiv").attr('style','display:block;');}
else if(resArr[6].toLowerCase()=="true"||isSignoffHP=="signoff"){newMsg=wbMessage+".";wbmDiv.firstChild.nodeValue=newMsg;$("div.welcomeMessageDiv").attr('style','display:none;');}
if(resArr[6].toLowerCase()=="false"){document.frmLocator.postalCode.value=resArr[2]+", "+resArr[3];document.frmLocator.dynaAtmText.value=document.frmLocator.postalCode.value;}else{document.frmLocator.postalCode.value=document.frmLocator.defaultAtmLocatorText.value;document.frmLocator.dynaAtmText.value="";}
document.frmLocator.zipCode.value=resArr[4];}
function getUrlParam(name){name=name.replace(/[\[]/,"\\\[").replace(/[\]]/,"\\\]");var regexS="[\\?&]"+name+"=([^&#]*)";var regex=new RegExp(regexS);var results=regex.exec(window.location.href);if(results==null)
return"";else
return results[1];}
function clearCookies(){document.frmSignIn.action="removeGreetings.go";document.frmSignIn.submit();}
$(document).ready(function(){$('.overhang-custom-select:visible').selectmenu({format:$.boaConvertTo3LineOption,width:166,menuWidth:260,menuOverhangLine:true,truncateSelectValue:$.boaSelectDisplayTruncate,truncateOptions:{splitLocation:12,endingStringLength:5}});});var dyn_prop_ind="false";var vipaa_aix_url="";var vipaa_pod_url="";function setDPI(value){dyn_prop_ind=value;}
function getDPI(){return dyn_prop_ind;}
function setVipaaAixUrl(url){vipaa_aix_url=url;}
function getVipaaAixUrl(){return vipaa_aix_url;}
function setVipaaPodUrl(url){vipaa_pod_url=url;}
function getVipaaPodUrl(){return vipaa_pod_url;}
function setPICookie(){var cookieDate=new Date();var cookieExpireDays=7305;cookieDate.setTime(cookieDate.getTime()+(cookieExpireDays*24*3600*1000));document.cookie="PI=A;expires="+cookieDate.toGMTString()+";";}
function getCookie(name){var boaCookies=document.cookie.split(';');var cname,cval;for(i=0;i<boaCookies.length;i++){cname=boaCookies[i].substr(0,boaCookies.indexOf("="));cval=boaCookies[i].substr(boaCookies.indexOf("=")+1);cname=cname.replace(/^\s+|\s+$/g,"");if(name==cname){return cval;}}}
function checkPICookie(){if(dyn_prop_ind=="true"){setFormActionUrl("pod");}else{var co_val=getCookie("PI");if(co_val!=null&&co_val.toLowerCase()=="p"){setFormActionUrl("pod");}else{setFormActionUrl("aix");}}}
function setFormActionUrl(sysName){if(sysName=="aix"){var url=getVipaaAixUrl();if(url.replace(/^\s+|\s+$/g,"").length>0){document.frmSignIn.action=url;}}else if(sysName=="pod"){var url=getVipaaPodUrl();if(url.replace(/^\s+|\s+$/g,"").length>0){document.frmSignIn.action=url;}}}