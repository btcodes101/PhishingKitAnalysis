<!DOCTYPE html>
<html class="no-js desktop legacy-jquery digital-id">
 <head> 
  <script src="//assets.adobedtm.com/5618484f119aa283a43872ba464534d4a912352a/satelliteLib-0f7d9589551ed7071db2509e1b92aadeff17ecd3.js"></script> 
  <meta name="HandheldFriendly" content="true" /> 
  <meta name="viewport" content="user-scalable=0, width=device-width, initial-scale=1.0,  minimum-scale=1.0, maximum-scale=1.0, shrink-to-fit=no" /> 
  <meta name="format-detection" content="telephone=no" /> 
  <script type="text/javascript">
    
  var o2 = o2 || {};
  o2.assetBaseUrl = 'https://accounts.o2.co.uk/v83p/_assets/';
  o2.assetBaseUrlShared = 'https://accounts.o2.co.uk/_assets_shared/';
</script> 
  <script type="text/javascript" src="https://accounts.o2.co.uk/_assets_shared/js/lib/modernizr.min.js"></script> 
  <meta name="robots" content="noodp,noydir" /> 
  <meta name="distribution" content="global" /> 
  <meta name="content-language" content="en" /> 
  <meta name="msvalidate.01" content="CC31ED886711FD7071695E1B2DA17022" /> 
  <link rel="Shortcut Icon" href="https://accounts.o2.co.uk/_assets_shared/img/o2.ico" /> 
  <script type="text/javascript" src="https://accounts.o2.co.uk/_assets_shared/js/jquery-1.7.min.js"></script> 
  <script type="text/javascript" src="https://accounts.o2.co.uk/_assets_shared/js/base.js?ts=080220131523"></script> 
  <link rel="stylesheet" href="https://accounts.o2.co.uk/_assets_shared/css/base.css?ts=080220131525" type="text/css" media="all" /> 
  <!--[if (gt IE 6)&(lt IE 9)]>
<link rel="stylesheet" href="https://accounts.o2.co.uk/_assets_shared/css/ielt9base.css?ts=20120920" type="text/css" media="all" charset="utf-8" />
<script type="text/javascript" src="https://accounts.o2.co.uk/_assets_shared/js/ielt9base.js?ts=20120920"></script>
<![endif]--> 
  <!--[if IE 6]>
<link rel="stylesheet" href="https://accounts.o2.co.uk/_assets_shared/css/ie6base.css" type="text/css" media="all" charset="utf-8" />
<script type="text/javascript" src="https://accounts.o2.co.uk/_assets_shared/js/ie6base.js"></script>
<![endif]--> 
  <link rel="stylesheet" href="https://accounts.o2.co.uk/_assets_shared/css/fonts.css?v=v83" type="text/css" /> 
  <!--[if gt IE 8]><!--> 
  <link rel="stylesheet" href="https://accounts.o2.co.uk/_assets_shared/css/global.css?v=v83" type="text/css" /> 
  <link rel="stylesheet" href="https://accounts.o2.co.uk/_assets_shared/css/_all-modules.css?v=v83" type="text/css" /> 
  <link rel="stylesheet" href="https://accounts.o2.co.uk/v83p/_assets/css/_all-modules.css" type="text/css" /> 
  <link rel="stylesheet" href="https://accounts.o2.co.uk/v83p/_assets/css/modal.css" type="text/css" /> 
  <link rel="stylesheet" href="https://accounts.o2.co.uk/v83p/_assets/css/consent.css" type="text/css" /> 
  <!--<![endif]--> 
  <link rel="stylesheet" href="//static-www.o2.co.uk/core/modules/system/css/components/hidden.module.css?v=2.4" type="text/css" /> 
  <link rel="stylesheet" href="//static-www.o2.co.uk/themes/o2_theme/css/global-nav.min.css?v=4.26" type="text/css" /> 
  <link rel="stylesheet" href="//static-www.o2.co.uk/themes/o2_theme/css/slick.css?v=4.4" type="text/css" /> 
  <link rel="stylesheet" href="//static-www.o2.co.uk/sites/default/files/fonticon/o2-icon-font/style.css?769" type="text/css" /> 
  <!--[if lt IE 9]>
    <link rel="stylesheet" href="https://accounts.o2.co.uk/_assets_shared/css/ie-global.css?v=v83" type="text/css"/>
    <link rel="stylesheet" href="https://accounts.o2.co.uk/_assets_shared/css/_all-modules-ie.css?v=v83" type="text/css"/>
    <link rel="stylesheet" href="https://accounts.o2.co.uk/v83p/_assets/css/_all-modules-ie.css" type="text/css"/>
    <link rel="stylesheet" href="https://accounts.o2.co.uk/v83p/_assets/css/modal.css" type="text/css"/>
    <link rel="stylesheet" href="https://accounts.o2.co.uk/v83p/_assets/css/consent-ie.css" type="text/css"/>
    <![endif]--> 
  <link rel="stylesheet" href="https://accounts.o2.co.uk/_assets_shared/css/legacy-app-overrides-to-support-new-header-footer.css?v=v83" type="text/css" /> 
  <!--[if (lt IE 8) & (!IEMobile)]>
    <link rel="stylesheet" href="https://accounts.o2.co.uk/_assets_shared/css/ie7.css?v=v83" type="text/css"/>
    <![endif]--> 
  <title>O2 | Accounts | Sign in | View bills , balances and emails in your My O2 account</title> 
  <link rel="Shortcut Icon" href="https://accounts.o2.co.uk/_assets_shared/img/o2.ico?v=v83" /> 
  <link media="all" type="text/css" href="https://accounts.o2.co.uk/v83p/_assets/css/html5boilerplate.css" rel="stylesheet" /> 
  <link media="all" type="text/css" href="https://accounts.o2.co.uk/v83p/_assets/css/desktop-new.css" rel="stylesheet" /> 
  <script type="text/javascript" src="//static-www.o2.co.uk/themes/o2_theme/js/search.js?v=0.1"></script> 
  <script type="text/javascript" src="//static-www.o2.co.uk/themes/o2_theme/js/global-nav-webpack.js?v=13.2"></script> 
  <script type="text/javascript" src="//static-www.o2.co.uk/themes/o2_theme/js/lazyload.js"></script> 
  <script src="https://accounts.o2.co.uk/v83p/_assets/js/jquery.tools.min.js"></script> 
  <script src="https://accounts.o2.co.uk/v83p/_assets/js/application.js"></script> 
  <script src="https://accounts.o2.co.uk/v83p/_assets/js/jquery.application.js"></script> 
  <script src="https://accounts.o2.co.uk/v83p/_assets/js/webchat/jquery.json-2.3.min.js"></script> 
  <script src="https://accounts.o2.co.uk/v83p/_assets/js/jquery-modal.js" type="text/javascript"></script> 
  <script src="https://accounts.o2.co.uk/v83p/_assets/js/lib/analytics-page-map.js"></script> 
  <script src="https://accounts.o2.co.uk/v83p/_assets/js/lib/analytics-page-header.js"></script> 
  <script type="text/javascript">
        var validationmessagepattern = "multiple";
    </script>    
 </head> 
 <body class=" serviceMsg desktop digital-id "> 
  <div class="wrapper" id="o2-page-wrapper"> 
   <!-- Logout Message Twig --> 
   <div class="header-logout-msg hide-my-o2 hide"> 
    <p class="header-logout-msg-txt"> <img src="//static-www.o2.co.uk/themes/o2_theme/img/global/icons.png" alt="O2" class="tickImg" /> You have been successfully logged out</p> 
   </div> 
   <div class="emptydiv hide-my-o2 hide"></div> 
   <!-- Logout Message Twig --> 
   <div component-name="globalNav" class="globalNavConsumerWrapper"> 
    <header class="newConsumer"> 
     <div class="topBar"> 
      <div class="navContainer"> 
       <div class="basketLink basketMobile">
        <a class="basketUrl" href="https://www.o2.co.uk/shop/basket"></a>
       </div> 
       <!-- Top Strip (Personal/Business) menu --> 
       <ul class="categoryList"> 
        <li class="current"> Personal </li> 
        <li class="pipe">|</li> 
        <li class=""> <a href="https://www.o2.co.uk/business" manual_cm_re="header-_-Business-_-na">Business</a> </li> 
       </ul> 
       <!-- Top Strip (Personal/Business) menu --> 
       <ul class="signUpLinks"> 
        <li id="header-tool-signin"> 
         <div class="hideWhenSignedOut welcome hide">
           Hi 
          <!-- SessionCam:Hide --> 
          <span class="username"></span> 
          <!-- /SessionCam:Hide --> 
         </div> 
         <div class="hideWhenSignedIn hide"> 
          <a class="signInLink" href="https://accounts.o2.co.uk/signin" title="Sign In" manual_cm_re="header-_-Sign In-_-na">Sign in</a> 
         </div> 
         <div class="hideWhenSignedOut hide"> 
          <span>|</span> 
          <a class="signOutLink" href="https://identity.o2.co.uk/logout" title="Sign out of your account" manual_cm_re="header-_-Sign out-_-na">Sign out</a>&nbsp; 
         </div> 
         <div class="hideWhenSignedIn hide">
           or 
          <a class="registerLink" href="https://accounts.o2.co.uk/register" title="register" manual_cm_re="header-_-Register-_-na">Register</a> 
         </div> </li> 
       </ul> 
      </div> 
     </div> 
     <nav class="globalNav" role="navigation"> 
      <div class="tier1"> 
       <div class="navContainer"> 
        <div class="brandLogo"> 
         <a href="https://www.o2.co.uk" manual_cm_re="header-_-Telefonica-_-na"> 
          <!--[if gte IE 9]><!-->
          <!--?xml version="1.0" encoding="UTF-8" standalone="no"?--> 
          <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="34px" height="35px" viewbox="0 0 34 35" version="1.1"> 
           <!-- Generator: Sketch 49.3 (51167) - http://www.bohemiancoding.com/sketch --> 
           <title>O2 Logo</title> 
           <desc>
            Created with Sketch.
           </desc> 
           <defs> 
            <polygon id="path-1" points="0 28.5963489 0 0.0563479784 26.7030678 0.0563479784 26.7030678 28.5963489 3.5407696e-15 28.5963489" /> 
           </defs> 
           <g id="Page-1" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd"> 
            <g id="Artboard"> 
             <g id="o2-logo"> 
              <g id="Group-3" transform="translate(0.000000, 0.100063)"> 
               <mask id="mask-2" fill="white"> 
                <use xlink:href="#path-1" /> 
               </mask> 
               <g id="Clip-2" /> 
               <path d="M5.145108,14.3262702 C5.145108,9.14206862 8.18067295,4.11812414 13.3773169,4.11812414 C18.5223346,4.11812414 21.5578996,9.14206862 21.5578996,14.3262702 C21.5578996,19.1898012 19.0369417,24.5344163 13.3773169,24.5344163 C7.66621634,24.5344163 5.145108,19.1898012 5.145108,14.3262702 M-6.02055707e-05,14.3262702 C-6.02055707e-05,22.1294646 5.45381207,28.5963489 13.3773169,28.5963489 C21.249346,28.5963489 26.7030678,22.1294646 26.7030678,14.3262702 C26.7030678,6.04230441 21.352147,0.0563479784 13.3773169,0.0563479784 C5.35086054,0.0563479784 -6.02055707e-05,6.04230441 -6.02055707e-05,14.3262702" id="Fill-1" fill="#FFFFFF" mask="url(#mask-2)" /> 
              </g> 
              <path d="M33.9007041,34.809417 L33.9007041,32.9072819 L29.1563545,32.9072819 C31.0540342,30.9705938 33.5343532,28.6188005 33.5343532,26.0596892 C33.5343532,23.6906976 32.1028152,22.5321557 29.8889058,22.5321557 C28.7067694,22.5321557 27.4916705,22.8432891 26.4428894,23.3966062 L26.6260648,25.4025567 C27.3917292,24.8837926 28.3240125,24.4342908 29.3062664,24.4342908 C30.2549557,24.4342908 31.203946,24.9528986 31.203946,26.0596892 C31.203946,28.2729577 27.2585244,31.6968323 26.1766302,32.7862682 L26.1766302,34.809417 L33.9007041,34.809417 Z" id="Fill-4" fill="#FFFFFF" /> 
             </g> 
            </g> 
           </g> 
          </svg> 
          <!--<![endif]-->
          <!--[if lte IE 8]><img src="//static-www.o2.co.uk/themes/o2_theme/img/global/o2-logo@2x.png" alt="O2 Logo"/><![endif]--> </a> 
         <span class="accordionToggle"> <img src="//static-www.o2.co.uk/themes/o2_theme/img/global/arrowbig.png" alt="O2" /> </span> 
        </div> 
        <div class="globalNavlinksWrapper"> 
         <ul class="linksDesktop"> 
          <li name="Shop"> <a manual_cm_re="meganav_Shop-_-na-_-na" data-parent="tier1-shop" data-parent-url="/shop" target="_self" href="https://www.o2.co.uk/shop">Shop</a> </li> 
          <li class="hideMobile" name="Why-O2"> <a manual_cm_re="meganav_Why O2-_-na-_-na" data-parent="tier1-why-o2" data-parent-url="/why-o2" target="_self" href="https://www.o2.co.uk/why-o2">Why O2</a> </li> 
          <li name="Help"> <a manual_cm_re="meganav_Help-_-na-_-na" data-parent="tier1-help" data-parent-url="/help" target="_self" href="https://www.o2.co.uk/help">Help</a> </li> 
         </ul> 
         <ul class=" otherLinks"> 
          <li class="myO2Link"> <a manual_cm_re="meganav_My O2-_-na-_-na" href="http://www.o2.co.uk/myo2" id="myO2Linkclick"> <span class="colorSpan">My O2</span> 
            <!--  <span class="myO2Linkclick">^</span> --> </a> </li> 
          <li class="searchLink open-overlay" tabindex="0"> <span class="ico o2-ico-search global-nav-white"></span> <span class="hideMobile search-text">Search</span> </li> 
          <li class="basketLink hideMobile"> <a class="basketUrl" href="https://www.o2.co.uk/shop/basket"> <span class="svgHide">
             <!--[if gte IE 9]><!-->
             <!--?xml version="1.0" encoding="UTF-8" standalone="no"?--> 
             <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewbox="0 0 24 20" version="1.1"> 
              <!-- Generator: Sketch 49.3 (51167) - http://www.bohemiancoding.com/sketch --> 
              <title>Your Basket</title> 
              <desc>
               Created with Sketch.
              </desc> 
              <defs /> 
              <g id="Symbols" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd" stroke-linecap="round" stroke-linejoin="round"> 
               <g id="desktop-tier-1-v1" transform="translate(-967.000000, -48.000000)" stroke="#FFFFFF" stroke-width="1.2"> 
                <g id="Group-2" transform="translate(882.000000, 49.000000)"> 
                 <g id="icons"> 
                  <path d="M100.94933,7.29932475 L98.3505135,0.646655413 C98.1987114,0.278223254 97.8542023,0 97.4487906,0 L96.2125576,0 C95.783512,0.000949567419 95.4117331,0.276324119 95.2572039,0.666596328 L92.5583981,7.29932475 L106.617822,7.29932475 C107.201397,7.29932475 107.674074,7.79309981 107.674074,8.40177253 C107.674074,8.58503904 107.631351,8.75691074 107.556814,8.90884153 L104.440779,16.577548 C103.970829,17.4283604 103.090922,18 102.082847,18 L91.5848646,18 C90.5904242,18 89.7177891,17.4407048 89.2423848,16.606035 L86.1190783,8.9126398 C86.0427228,8.75975944 86,8.58693817 86,8.40177253 C86,7.79309981 86.4717683,7.29932475 87.0544341,7.29932475 L90.1741045,7.29932475" id="basket" /> 
                 </g> 
                </g> 
               </g> 
              </g> 
             </svg> 
             <!--<![endif]-->
             <!--[if lte IE 8]><img src="//static-www.o2.co.uk/themes/o2_theme/img/global/basket@3x.png" alt="Your basket"/><![endif]--></span> </a> </li> 
         </ul> 
        </div> 
       </div> 
      </div> 
      <div class="tier2"> 
       <div class="navContainer"> 
        <div class="linksMobile"> 
         <ul class="accordionMobile"> 
          <li> <a class="mobileAccodLinks" href="javascript:void(0);" manual_cm_re="meganav_Shop-_-na-_-na">Shop</a> 
           <ul class="inner"> 
            <li><a href="https://www.o2.co.uk/shop" manual_cm_re="meganav_Browse Shop-_-na-_-na">Browse Shop</a></li> 
            <!-- Tier 2 Mobile Navigation elements --> 
            <li class="indented"> Phones </li> 
            <!-- Tier 3 Navigation --> 
            <li> <a href="https://www.o2.co.uk/shop/phones" manual_cm_re="meganav_Shop-_-Phones-_-Phones" target="_self">Phones</a> </li> 
            <!-- Tier 3 Navigation --> 
            <li> <a href="https://www.o2.co.uk/upgrade/upgradeOptions" manual_cm_re="meganav_Shop-_-Phones-_-Upgrades" target="_self">Upgrades</a> </li> 
            <!-- Tier 3 Navigation --> 
            <li> <a href="https://www.o2.co.uk/iphone" manual_cm_re="meganav_Shop-_-Phones-_-Apple iPhone" target="_self">Apple iPhone</a> </li> 
            <!-- Tier 3 Navigation --> 
            <li> <a href="https://www.o2.co.uk/android" manual_cm_re="meganav_Shop-_-Phones-_-Android phones" target="_self">Android phones</a> </li> 
            <!-- Tier 3 Navigation --> 
            <li> <a href="https://www.o2.co.uk/shop/like-new" manual_cm_re="meganav_Shop-_-Phones-_-Refurbished phones" target="_self">Refurbished phones</a> </li> 
            <!-- Tier 2 Mobile Navigation elements --> 
            <li class="indented"> Tablets and dongles </li> 
            <!-- Tier 3 Navigation --> 
            <li> <a href="https://www.o2.co.uk/shop/tablets" manual_cm_re="meganav_Shop-_-Tablets and dongles-_-Pay Monthly tablets" target="_self">Pay Monthly tablets</a> </li> 
            <!-- Tier 3 Navigation --> 
            <li> <a href="https://www.o2.co.uk/ipad" manual_cm_re="meganav_Shop-_-Tablets and dongles-_-Apple iPad" target="_self">Apple iPad</a> </li> 
            <!-- Tier 3 Navigation --> 
            <li> <a href="https://www.o2.co.uk/android-tablets" manual_cm_re="meganav_Shop-_-Tablets and dongles-_-Android tablets" target="_self">Android tablets</a> </li> 
            <!-- Tier 3 Navigation --> 
            <li> <a href="https://www.o2.co.uk/tablet-computers" manual_cm_re="meganav_Shop-_-Tablets and dongles-_-Tablet computers" target="_self">Tablet computers</a> </li> 
            <!-- Tier 3 Navigation --> 
            <li> <a href="https://www.o2.co.uk/shop/mobile-broadband" manual_cm_re="meganav_Shop-_-Tablets and dongles-_-Dongles and mobile wifi" target="_self">Dongles and mobile wifi</a> </li> 
            <!-- Tier 2 Mobile Navigation elements --> 
            <li class="indented"> Sims and Tariffs </li> 
            <!-- Tier 3 Navigation --> 
            <li> <a href="https://www.o2.co.uk/shop/sim-cards/sim-only-deals#deviceType=phone&amp;contractLength=P12M" manual_cm_re="meganav_Shop-_-Sims and Tariffs-_-Pay Monthly sims" target="_self">Pay Monthly sims</a> </li> 
            <!-- Tier 3 Navigation --> 
            <li> <a href="https://www.o2.co.uk/shop/sim-cards/pay-as-you-go#simtype=bigbundles" manual_cm_re="meganav_Shop-_-Sims and Tariffs-_-Pay As You Go sims" target="_self">Pay As You Go sims</a> </li> 
            <!-- Tier 3 Navigation --> 
            <li> <a href="https://www.o2.co.uk/shop/all-tariffs" manual_cm_re="meganav_Shop-_-Sims and Tariffs-_-Tariffs" target="_self">Tariffs</a> </li> 
            <!-- Tier 3 Navigation --> 
            <li> <a href="https://www.o2.co.uk/shop/international" manual_cm_re="meganav_Shop-_-Sims and Tariffs-_-International" target="_self">International</a> </li> 
            <!-- Tier 3 Navigation --> 
            <li> <a href="https://www.o2.co.uk/topup" manual_cm_re="meganav_Shop-_-Sims and Tariffs-_-Top-up" target="_self">Top-up</a> </li> 
            <!-- Tier 2 Mobile Navigation elements --> 
            <li class="indented"> Accessories and more </li> 
            <!-- Tier 3 Navigation --> 
            <li> <a href="https://www.o2.co.uk/shop/accessories" manual_cm_re="meganav_Shop-_-Accessories and more-_-Accessories" target="_self">Accessories</a> </li> 
            <!-- Tier 3 Navigation --> 
            <li> <a href="https://www.o2.co.uk/shop/smartwatches#sort=content.sorting.featured&amp;page=1" manual_cm_re="meganav_Shop-_-Accessories and more-_-Apple Watch/smartwatches" target="_self">Apple Watch/smartwatches</a> </li> 
            <!-- Tier 3 Navigation --> 
            <li> <a href="https://www.o2.co.uk/shop/wireless-accessories" manual_cm_re="meganav_Shop-_-Accessories and more-_-AirPods/wireless accessories" target="">AirPods/wireless accessories</a> </li> 
            <!-- Tier 3 Navigation --> 
            <li> <a href="https://www.o2.co.uk/shop/great-deals" manual_cm_re="meganav_Shop-_-Accessories and more-_-Great deals" target="_self">Great deals</a> </li> 
            <!-- Tier 3 Navigation --> 
            <li> <a href="https://www.o2.co.uk/shop/clearance" manual_cm_re="meganav_Shop-_-Accessories and more-_-Clearance" target="_self">Clearance</a> </li> 
           </ul> </li> 
          <li> <a class="mobileAccodLinks" href="javascript:void(0);" manual_cm_re="meganav_Why O2-_-na-_-na">Why O2</a> 
           <ul class="inner"> 
            <li><a href="https://www.o2.co.uk/why-o2" manual_cm_re="meganav_Browse Why O2-_-na-_-na">Browse Why O2</a></li> 
            <!-- Tier 2 Mobile Navigation elements --> 
            <li class="indented"> Flexibility </li> 
            <!-- Tier 3 Navigation --> 
            <li> <a href="https://www.o2.co.uk/custom-plans" manual_cm_re="meganav_Why O2-_-Flexibility-_-O2 custom plans" target="_self">O2 custom plans</a> </li> 
            <!-- Tier 3 Navigation --> 
            <li> <a href="https://www.o2recycle.co.uk/" manual_cm_re="meganav_Why O2-_-Flexibility-_-O2 Recycle" target="_self">O2 Recycle</a> </li> 
            <!-- Tier 3 Navigation --> 
            <li> <a href="https://www.o2.co.uk/help/phones-sims-and-devices/collection-and-delivery" manual_cm_re="meganav_Why O2-_-Flexibility-_-Click and collect" target="_self">Click and collect</a> </li> 
            <!-- Tier 2 Mobile Navigation elements --> 
            <li class="indented"> Perks </li> 
            <!-- Tier 3 Navigation --> 
            <li> <a href="https://www.o2.co.uk/extras" manual_cm_re="meganav_Why O2-_-Perks-_-O2 Extras" target="">O2 Extras</a> </li> 
            <!-- Tier 3 Navigation --> 
            <li> <a href="https://priority.o2.co.uk/offers?category=offers" manual_cm_re="meganav_Why O2-_-Perks-_-Priority offers" target="_self">Priority offers</a> </li> 
            <!-- Tier 3 Navigation --> 
            <li> <a href="https://priority.o2.co.uk/tickets" manual_cm_re="meganav_Why O2-_-Perks-_-Priority Tickets" target="_self">Priority Tickets</a> </li> 
            <!-- Tier 3 Navigation --> 
            <li> <a href="https://www.o2.co.uk/perks/perks-at-o2-venues" manual_cm_re="meganav_Why O2-_-Perks-_-Perks at O2 venues" target="_self">Perks at O2 venues</a> </li> 
            <!-- Tier 3 Navigation --> 
            <li> <a href="https://payandgorewards.o2.co.uk/web/o2" manual_cm_re="meganav_Why O2-_-Perks-_-Pay &amp;  Go Rewards" target="_self">Pay &amp; Go Rewards</a> </li> 
            <!-- Tier 2 Mobile Navigation elements --> 
            <li class="indented"> Services </li> 
            <!-- Tier 3 Navigation --> 
            <li> <a href="https://www.o2.co.uk/myo2" manual_cm_re="meganav_Why O2-_-Services-_-Manage your account" target="_self">Manage your account</a> </li> 
            <!-- Tier 3 Navigation --> 
            <li> <a href="https://www.o2.co.uk/help/guru" manual_cm_re="meganav_Why O2-_-Services-_-O2 Gurus - tips and advice" target="_self">O2 Gurus - tips and advice</a> </li> 
            <!-- Tier 3 Navigation --> 
            <li> <a href="https://www.o2.co.uk/help/nspcc" manual_cm_re="meganav_Why O2-_-Services-_-Keeping kids safe online" target="_self">Keeping kids safe online</a> </li> 
            <!-- Tier 3 Navigation --> 
            <li> <a href="https://www.o2.co.uk/inspiration" manual_cm_re="meganav_Why O2-_-Services-_-Ideas and Inspiration" target="_self">Ideas and Inspiration</a> </li> 
            <!-- Tier 3 Navigation --> 
            <li> <a href="https://www.o2.co.uk/shop/services/drive" manual_cm_re="meganav_Why O2-_-Services-_-O2 Drive - car insurance" target="_self">O2 Drive - car insurance</a> </li> 
            <!-- Tier 2 Mobile Navigation elements --> 
            <li class="indented"> Connected </li> 
            <!-- Tier 3 Navigation --> 
            <li> <a href="https://www.o2.co.uk/coveragechecker" manual_cm_re="meganav_Why O2-_-Connected-_-Coverage checker" target="_self">Coverage checker</a> </li> 
            <!-- Tier 3 Navigation --> 
            <li> <a href="https://www.o2.co.uk/connectivity/network-coverage" manual_cm_re="meganav_Why O2-_-Connected-_-Best Network Coverage" target="">Best Network Coverage</a> </li> 
            <!-- Tier 3 Navigation --> 
            <li> <a href="https://www.o2.co.uk/5G" manual_cm_re="meganav_Why O2-_-Connected-_-5G network" target="_self">5G network</a> </li> 
            <!-- Tier 3 Navigation --> 
            <li> <a href="https://www.o2.co.uk/connectivity/free-wifi" manual_cm_re="meganav_Why O2-_-Connected-_-O2 Wifi" target="_self">O2 Wifi</a> </li> 
            <!-- Tier 3 Navigation --> 
            <li> <a href="https://www.o2.co.uk/shop/international/using-phone-abroad" manual_cm_re="meganav_Why O2-_-Connected-_-O2 Travel - roaming abroad" target="_self">O2 Travel - roaming abroad</a> </li> 
           </ul> </li> 
          <li> <a class="mobileAccodLinks" href="javascript:void(0);" manual_cm_re="meganav_Help-_-na-_-na">Help</a> 
           <ul class="inner"> 
            <li><a href="https://www.o2.co.uk/help" manual_cm_re="meganav_Browse Help-_-na-_-na">Browse Help</a></li> 
            <!-- Tier 2 Mobile Navigation elements --> 
            <li class="indented"> Top queries </li> 
            <!-- Tier 3 Navigation --> 
            <li> <a href="https://www.o2.co.uk/help/pay-monthly/how-to-track-your-order" manual_cm_re="meganav_Help-_-Top queries-_-Track my order" target="_self">Track my order</a> </li> 
            <!-- Tier 3 Navigation --> 
            <li> <a href="https://www.o2.co.uk/help/phones-sims-and-devices/activating-your-sim" manual_cm_re="meganav_Help-_-Top queries-_-Sim card" target="_self">Sim card</a> </li> 
            <!-- Tier 3 Navigation --> 
            <li> <a href="https://www.o2.co.uk/help/pay-as-you-go/topping-up" manual_cm_re="meganav_Help-_-Top queries-_-Top-up" target="_self">Top-up</a> </li> 
            <!-- Tier 3 Navigation --> 
            <li> <a href="https://www.o2.co.uk/help/digital-services/personal-hotspot" manual_cm_re="meganav_Help-_-Top queries-_-Personal Hotspot" target="_self">Personal Hotspot</a> </li> 
            <!-- Tier 3 Navigation --> 
            <li> <a href="https://www.o2.co.uk/help/phones-sims-and-devices/collection-and-delivery" manual_cm_re="meganav_Help-_-Top queries-_-Collection and delivery" target="_self">Collection and delivery</a> </li> 
            <!-- Tier 2 Mobile Navigation elements --> 
            <li class="indented"> Device help </li> 
            <!-- Tier 3 Navigation --> 
            <li> <a href="https://www.o2.co.uk/help/phones-sims-and-devices" manual_cm_re="meganav_Help-_-Device help-_-How to use your device" target="_self">How to use your device</a> </li> 
            <!-- Tier 3 Navigation --> 
            <li> <a href="https://diagnostics.o2.co.uk/fix-my-device" manual_cm_re="meganav_Help-_-Device help-_-Faulty device" target="_self">Faulty device</a> </li> 
            <!-- Tier 3 Navigation --> 
            <li> <a href="https://www.o2.co.uk/help/digital-services/phone-health-check" manual_cm_re="meganav_Help-_-Device help-_-Device health check" target="_self">Device health check</a> </li> 
            <!-- Tier 3 Navigation --> 
            <li> <a href="https://www.o2.co.uk/help/phones-sims-and-devices/lost-or-stolen-device" manual_cm_re="meganav_Help-_-Device help-_-Lost or stolen" target="_self">Lost or stolen</a> </li> 
            <!-- Tier 3 Navigation --> 
            <li> <a href="https://community.o2.co.uk/" manual_cm_re="meganav_Help-_-Device help-_-Check O2 Community" target="_self">Check O2 Community</a> </li> 
            <!-- Tier 2 Mobile Navigation elements --> 
            <li class="indented"> Managing your account </li> 
            <!-- Tier 3 Navigation --> 
            <li> <a href="https://accounts.o2.co.uk" manual_cm_re="meganav_Help-_-Managing your account-_-My O2" target="_self">My O2</a> </li> 
            <!-- Tier 3 Navigation --> 
            <li> <a href="https://www.o2.co.uk/help/account-and-billing/understanding-your-bill" manual_cm_re="meganav_Help-_-Managing your account-_-Your bill" target="_self">Your bill</a> </li> 
            <!-- Tier 3 Navigation --> 
            <li> <a href="https://www.o2.co.uk/help/account-and-billing/how-to-pay" manual_cm_re="meganav_Help-_-Managing your account-_-Payments" target="_self">Payments</a> </li> 
            <!-- Tier 3 Navigation --> 
            <li> <a href="https://www.o2.co.uk/help/account-and-billing/premium-service-checker" manual_cm_re="meganav_Help-_-Managing your account-_-Premium charges" target="_self">Premium charges</a> </li> 
            <!-- Tier 3 Navigation --> 
            <li> <a href="https://www.o2.co.uk/abouto2/your-data-hub" manual_cm_re="meganav_Help-_-Managing your account-_-Your Data Hub" target="_self">Your Data Hub</a> </li> 
            <!-- Tier 2 Mobile Navigation elements --> 
            <li class="indented"> Other ways to get help </li> 
            <!-- Tier 3 Navigation --> 
            <li> <a href="https://www.o2.co.uk/help" manual_cm_re="meganav_Help-_-Other ways to get help-_-Help articles" target="_self">Help articles</a> </li> 
            <!-- Tier 3 Navigation --> 
            <li> <a href="https://www.o2.co.uk/apps/aura" manual_cm_re="meganav_Help-_-Other ways to get help-_-Aura" target="">Aura</a> </li> 
            <!-- Tier 3 Navigation --> 
            <li> <a href="https://www.o2.co.uk/storelocator" manual_cm_re="meganav_Help-_-Other ways to get help-_-Store locator" target="_self">Store locator</a> </li> 
            <!-- Tier 3 Navigation --> 
            <li> <a href="https://status.o2.co.uk/" manual_cm_re="meganav_Help-_-Other ways to get help-_-Network status" target="_self">Network status</a> </li> 
            <!-- Tier 3 Navigation --> 
            <li> <a href="https://www.o2.co.uk/contactus" manual_cm_re="meganav_Help-_-Other ways to get help-_-Contact us" target="_self">Contact us</a> </li> 
           </ul> </li> 
         </ul> 
         <!-- Display mobile bottom link --> 
         <div class="bottomLinks"> 
          <ul> 
           <li> <a manual_cm_re="meganav_Find a store-_-na-_-na" href="https://www.o2.co.uk/storelocator">Find a store</a> </li> 
           <li> <a manual_cm_re="meganav_Business-_-na-_-na" href="https://www.o2.co.uk/business">Business</a> </li> 
          </ul> 
         </div> 
         <!-- Dsiaply mobile bottom link --> 
        </div> 
        <div class="linksModuleWrapper linksWrapperConsumer"> 
         <div class="linksWrapper linksWrapperConsumerWidth"> 
          <ul name="Shop"> 
           <!-- Tier 2 navigation elements --> 
           <li class="tier-menu-wrapper"> <span> Phones </span> 
            <ul> 
             <!-- Tier 3 Navigation --> 
             <li> <a manual_cm_re="meganav_Shop-_-Phones-_-Phones" data-parent="Shop" data-parent-link="/shop" data-href="/shop/phones" href="https://www.o2.co.uk/shop/phones" target="_self">Phones</a> </li> 
             <!-- Tier 3 Navigation --> 
             <li> <a manual_cm_re="meganav_Shop-_-Phones-_-Upgrades" data-parent="Shop" data-parent-link="/shop" data-href="https://www.o2.co.uk/upgrade/upgradeOptions" href="https://www.o2.co.uk/upgrade/upgradeOptions" target="_self">Upgrades</a> </li> 
             <!-- Tier 3 Navigation --> 
             <li> <a manual_cm_re="meganav_Shop-_-Phones-_-Apple iPhone" data-parent="Shop" data-parent-link="/shop" data-href="/iphone" href="https://www.o2.co.uk/iphone" target="_self">Apple iPhone</a> </li> 
             <!-- Tier 3 Navigation --> 
             <li> <a manual_cm_re="meganav_Shop-_-Phones-_-Android phones" data-parent="Shop" data-parent-link="/shop" data-href="/android" href="https://www.o2.co.uk/android" target="_self">Android phones</a> </li> 
             <!-- Tier 3 Navigation --> 
             <li> <a manual_cm_re="meganav_Shop-_-Phones-_-Refurbished phones" data-parent="Shop" data-parent-link="/shop" data-href="/shop/like-new" href="https://www.o2.co.uk/shop/like-new" target="_self">Refurbished phones</a> </li> 
            </ul> </li> 
           <!-- Tier 2 navigation elements --> 
           <li class="tier-menu-wrapper"> <span> Tablets and dongles </span> 
            <ul> 
             <!-- Tier 3 Navigation --> 
             <li> <a manual_cm_re="meganav_Shop-_-Tablets and dongles-_-Pay Monthly tablets" data-parent="Shop" data-parent-link="/shop" data-href="/shop/tablets" href="https://www.o2.co.uk/shop/tablets" target="_self">Pay Monthly tablets</a> </li> 
             <!-- Tier 3 Navigation --> 
             <li> <a manual_cm_re="meganav_Shop-_-Tablets and dongles-_-Apple iPad" data-parent="Shop" data-parent-link="/shop" data-href="/ipad" href="https://www.o2.co.uk/ipad" target="_self">Apple iPad</a> </li> 
             <!-- Tier 3 Navigation --> 
             <li> <a manual_cm_re="meganav_Shop-_-Tablets and dongles-_-Android tablets" data-parent="Shop" data-parent-link="/shop" data-href="/android-tablets" href="https://www.o2.co.uk/android-tablets" target="_self">Android tablets</a> </li> 
             <!-- Tier 3 Navigation --> 
             <li> <a manual_cm_re="meganav_Shop-_-Tablets and dongles-_-Tablet computers" data-parent="Shop" data-parent-link="/shop" data-href="/tablet-computers" href="https://www.o2.co.uk/tablet-computers" target="_self">Tablet computers</a> </li> 
             <!-- Tier 3 Navigation --> 
             <li> <a manual_cm_re="meganav_Shop-_-Tablets and dongles-_-Dongles and mobile wifi" data-parent="Shop" data-parent-link="/shop" data-href="/shop/mobile-broadband" href="https://www.o2.co.uk/shop/mobile-broadband" target="_self">Dongles and mobile wifi</a> </li> 
            </ul> </li> 
           <!-- Tier 2 navigation elements --> 
           <li class="tier-menu-wrapper"> <span> Sims and Tariffs </span> 
            <ul> 
             <!-- Tier 3 Navigation --> 
             <li> <a manual_cm_re="meganav_Shop-_-Sims and Tariffs-_-Pay Monthly sims" data-parent="Shop" data-parent-link="/shop" data-href="/shop/sim-cards/sim-only-deals#deviceType=phone&amp;contractLength=P12M" href="https://www.o2.co.uk/shop/sim-cards/sim-only-deals#deviceType=phone&amp;contractLength=P12M" target="_self">Pay Monthly sims</a> </li> 
             <!-- Tier 3 Navigation --> 
             <li> <a manual_cm_re="meganav_Shop-_-Sims and Tariffs-_-Pay As You Go sims" data-parent="Shop" data-parent-link="/shop" data-href="/shop/sim-cards/pay-as-you-go#simtype=bigbundles" href="https://www.o2.co.uk/shop/sim-cards/pay-as-you-go#simtype=bigbundles" target="_self">Pay As You Go sims</a> </li> 
             <!-- Tier 3 Navigation --> 
             <li> <a manual_cm_re="meganav_Shop-_-Sims and Tariffs-_-Tariffs" data-parent="Shop" data-parent-link="/shop" data-href="/shop/all-tariffs" href="https://www.o2.co.uk/shop/all-tariffs" target="_self">Tariffs</a> </li> 
             <!-- Tier 3 Navigation --> 
             <li> <a manual_cm_re="meganav_Shop-_-Sims and Tariffs-_-International" data-parent="Shop" data-parent-link="/shop" data-href="/shop/international" href="https://www.o2.co.uk/shop/international" target="_self">International</a> </li> 
             <!-- Tier 3 Navigation --> 
             <li> <a manual_cm_re="meganav_Shop-_-Sims and Tariffs-_-Top-up" data-parent="Shop" data-parent-link="/shop" data-href="/topup" href="https://www.o2.co.uk/topup" target="_self">Top-up</a> </li> 
            </ul> </li> 
           <!-- Tier 2 navigation elements --> 
           <li class="tier-menu-wrapper"> <span> Accessories and more </span> 
            <ul> 
             <!-- Tier 3 Navigation --> 
             <li> <a manual_cm_re="meganav_Shop-_-Accessories and more-_-Accessories" data-parent="Shop" data-parent-link="/shop" data-href="https://www.o2.co.uk/shop/accessories" href="https://www.o2.co.uk/shop/accessories" target="_self">Accessories</a> </li> 
             <!-- Tier 3 Navigation --> 
             <li> <a manual_cm_re="meganav_Shop-_-Accessories and more-_-Apple Watch/smartwatches" data-parent="Shop" data-parent-link="/shop" data-href="https://www.o2.co.uk/shop/smartwatches#sort=content.sorting.featured&amp;page=1" href="https://www.o2.co.uk/shop/smartwatches#sort=content.sorting.featured&amp;page=1" target="_self">Apple Watch/smartwatches</a> </li> 
             <!-- Tier 3 Navigation --> 
             <li> <a manual_cm_re="meganav_Shop-_-Accessories and more-_-AirPods/wireless accessories" data-parent="Shop" data-parent-link="/shop" data-href="https://www.o2.co.uk/shop/wireless-accessories" href="https://www.o2.co.uk/shop/wireless-accessories" target="">AirPods/wireless accessories</a> </li> 
             <!-- Tier 3 Navigation --> 
             <li> <a manual_cm_re="meganav_Shop-_-Accessories and more-_-Great deals" data-parent="Shop" data-parent-link="/shop" data-href="/shop/great-deals" href="https://www.o2.co.uk/shop/great-deals" target="_self">Great deals</a> </li> 
             <!-- Tier 3 Navigation --> 
             <li> <a manual_cm_re="meganav_Shop-_-Accessories and more-_-Clearance" data-parent="Shop" data-parent-link="/shop" data-href="/shop/clearance" href="https://www.o2.co.uk/shop/clearance" target="_self">Clearance</a> </li> 
            </ul> </li> 
          </ul> 
          <ul name="Why-O2"> 
           <!-- Tier 2 navigation elements --> 
           <li class="tier-menu-wrapper"> <span> Flexibility </span> 
            <ul> 
             <!-- Tier 3 Navigation --> 
             <li> <a manual_cm_re="meganav_Why O2-_-Flexibility-_-O2 custom plans" data-parent="Why O2" data-parent-link="/why-o2" data-href="/custom-plans" href="https://www.o2.co.uk/custom-plans" target="_self">O2 custom plans</a> </li> 
             <!-- Tier 3 Navigation --> 
             <li> <a manual_cm_re="meganav_Why O2-_-Flexibility-_-O2 Recycle" data-parent="Why O2" data-parent-link="/why-o2" data-href="https://www.o2recycle.co.uk/" href="https://www.o2recycle.co.uk/" target="_self">O2 Recycle</a> </li> 
             <!-- Tier 3 Navigation --> 
             <li> <a manual_cm_re="meganav_Why O2-_-Flexibility-_-Click and collect" data-parent="Why O2" data-parent-link="/why-o2" data-href="/help/phones-sims-and-devices/collection-and-delivery" href="https://www.o2.co.uk/help/phones-sims-and-devices/collection-and-delivery" target="_self">Click and collect</a> </li> 
            </ul> </li> 
           <!-- Tier 2 navigation elements --> 
           <li class="tier-menu-wrapper"> <span> Perks </span> 
            <ul> 
             <!-- Tier 3 Navigation --> 
             <li> <a manual_cm_re="meganav_Why O2-_-Perks-_-O2 Extras" data-parent="Why O2" data-parent-link="/why-o2" data-href="/extras" href="https://www.o2.co.uk/extras" target="">O2 Extras</a> </li> 
             <!-- Tier 3 Navigation --> 
             <li> <a manual_cm_re="meganav_Why O2-_-Perks-_-Priority offers" data-parent="Why O2" data-parent-link="/why-o2" data-href="https://priority.o2.co.uk/offers?category=offers" href="https://priority.o2.co.uk/offers?category=offers" target="_self">Priority offers</a> </li> 
             <!-- Tier 3 Navigation --> 
             <li> <a manual_cm_re="meganav_Why O2-_-Perks-_-Priority Tickets" data-parent="Why O2" data-parent-link="/why-o2" data-href="https://priority.o2.co.uk/tickets" href="https://priority.o2.co.uk/tickets" target="_self">Priority Tickets</a> </li> 
             <!-- Tier 3 Navigation --> 
             <li> <a manual_cm_re="meganav_Why O2-_-Perks-_-Perks at O2 venues" data-parent="Why O2" data-parent-link="/why-o2" data-href="/perks/perks-at-o2-venues" href="https://www.o2.co.uk/perks/perks-at-o2-venues" target="_self">Perks at O2 venues</a> </li> 
             <!-- Tier 3 Navigation --> 
             <li> <a manual_cm_re="meganav_Why O2-_-Perks-_-Pay &amp;  Go Rewards" data-parent="Why O2" data-parent-link="/why-o2" data-href="https://payandgorewards.o2.co.uk/web/o2" href="https://payandgorewards.o2.co.uk/web/o2" target="_self">Pay &amp; Go Rewards</a> </li> 
            </ul> </li> 
           <!-- Tier 2 navigation elements --> 
           <li class="tier-menu-wrapper"> <span> Services </span> 
            <ul> 
             <!-- Tier 3 Navigation --> 
             <li> <a manual_cm_re="meganav_Why O2-_-Services-_-Manage your account" data-parent="Why O2" data-parent-link="/why-o2" data-href="/myo2" href="https://www.o2.co.uk/myo2" target="_self">Manage your account</a> </li> 
             <!-- Tier 3 Navigation --> 
             <li> <a manual_cm_re="meganav_Why O2-_-Services-_-O2 Gurus - tips and advice" data-parent="Why O2" data-parent-link="/why-o2" data-href="/help/guru" href="https://www.o2.co.uk/help/guru" target="_self">O2 Gurus - tips and advice</a> </li> 
             <!-- Tier 3 Navigation --> 
             <li> <a manual_cm_re="meganav_Why O2-_-Services-_-Keeping kids safe online" data-parent="Why O2" data-parent-link="/why-o2" data-href="/help/nspcc" href="https://www.o2.co.uk/help/nspcc" target="_self">Keeping kids safe online</a> </li> 
             <!-- Tier 3 Navigation --> 
             <li> <a manual_cm_re="meganav_Why O2-_-Services-_-Ideas and Inspiration" data-parent="Why O2" data-parent-link="/why-o2" data-href="/inspiration" href="https://www.o2.co.uk/inspiration" target="_self">Ideas and Inspiration</a> </li> 
             <!-- Tier 3 Navigation --> 
             <li> <a manual_cm_re="meganav_Why O2-_-Services-_-O2 Drive - car insurance" data-parent="Why O2" data-parent-link="/why-o2" data-href="/shop/services/drive" href="https://www.o2.co.uk/shop/services/drive" target="_self">O2 Drive - car insurance</a> </li> 
            </ul> </li> 
           <!-- Tier 2 navigation elements --> 
           <li class="tier-menu-wrapper"> <span> Connected </span> 
            <ul> 
             <!-- Tier 3 Navigation --> 
             <li> <a manual_cm_re="meganav_Why O2-_-Connected-_-Coverage checker" data-parent="Why O2" data-parent-link="/why-o2" data-href="/coveragechecker" href="https://www.o2.co.uk/coveragechecker" target="_self">Coverage checker</a> </li> 
             <!-- Tier 3 Navigation --> 
             <li> <a manual_cm_re="meganav_Why O2-_-Connected-_-Best Network Coverage" data-parent="Why O2" data-parent-link="/why-o2" data-href="/connectivity/network-coverage" href="https://www.o2.co.uk/connectivity/network-coverage" target="">Best Network Coverage</a> </li> 
             <!-- Tier 3 Navigation --> 
             <li> <a manual_cm_re="meganav_Why O2-_-Connected-_-5G network" data-parent="Why O2" data-parent-link="/why-o2" data-href="/5G" href="https://www.o2.co.uk/5G" target="_self">5G network</a> </li> 
             <!-- Tier 3 Navigation --> 
             <li> <a manual_cm_re="meganav_Why O2-_-Connected-_-O2 Wifi" data-parent="Why O2" data-parent-link="/why-o2" data-href="/connectivity/free-wifi" href="https://www.o2.co.uk/connectivity/free-wifi" target="_self">O2 Wifi</a> </li> 
             <!-- Tier 3 Navigation --> 
             <li> <a manual_cm_re="meganav_Why O2-_-Connected-_-O2 Travel - roaming abroad" data-parent="Why O2" data-parent-link="/why-o2" data-href="/shop/international/using-phone-abroad" href="https://www.o2.co.uk/shop/international/using-phone-abroad" target="_self">O2 Travel - roaming abroad</a> </li> 
            </ul> </li> 
          </ul> 
          <ul name="Help"> 
           <!-- Tier 2 navigation elements --> 
           <li class="tier-menu-wrapper"> <span> Top queries </span> 
            <ul> 
             <!-- Tier 3 Navigation --> 
             <li> <a manual_cm_re="meganav_Help-_-Top queries-_-Track my order" data-parent="Help" data-parent-link="/help" data-href="/help/pay-monthly/how-to-track-your-order" href="https://www.o2.co.uk/help/pay-monthly/how-to-track-your-order" target="_self">Track my order</a> </li> 
             <!-- Tier 3 Navigation --> 
             <li> <a manual_cm_re="meganav_Help-_-Top queries-_-Sim card" data-parent="Help" data-parent-link="/help" data-href="/help/phones-sims-and-devices/activating-your-sim" href="https://www.o2.co.uk/help/phones-sims-and-devices/activating-your-sim" target="_self">Sim card</a> </li> 
             <!-- Tier 3 Navigation --> 
             <li> <a manual_cm_re="meganav_Help-_-Top queries-_-Top-up" data-parent="Help" data-parent-link="/help" data-href="/help/pay-as-you-go/topping-up" href="https://www.o2.co.uk/help/pay-as-you-go/topping-up" target="_self">Top-up</a> </li> 
             <!-- Tier 3 Navigation --> 
             <li> <a manual_cm_re="meganav_Help-_-Top queries-_-Personal Hotspot" data-parent="Help" data-parent-link="/help" data-href="/help/digital-services/personal-hotspot" href="https://www.o2.co.uk/help/digital-services/personal-hotspot" target="_self">Personal Hotspot</a> </li> 
             <!-- Tier 3 Navigation --> 
             <li> <a manual_cm_re="meganav_Help-_-Top queries-_-Collection and delivery" data-parent="Help" data-parent-link="/help" data-href="/help/phones-sims-and-devices/collection-and-delivery" href="https://www.o2.co.uk/help/phones-sims-and-devices/collection-and-delivery" target="_self">Collection and delivery</a> </li> 
            </ul> </li> 
           <!-- Tier 2 navigation elements --> 
           <li class="tier-menu-wrapper"> <span> Device help </span> 
            <ul> 
             <!-- Tier 3 Navigation --> 
             <li> <a manual_cm_re="meganav_Help-_-Device help-_-How to use your device" data-parent="Help" data-parent-link="/help" data-href="/help/phones-sims-and-devices" href="https://www.o2.co.uk/help/phones-sims-and-devices" target="_self">How to use your device</a> </li> 
             <!-- Tier 3 Navigation --> 
             <li> <a manual_cm_re="meganav_Help-_-Device help-_-Faulty device" data-parent="Help" data-parent-link="/help" data-href="https://diagnostics.o2.co.uk/fix-my-device" href="https://diagnostics.o2.co.uk/fix-my-device" target="_self">Faulty device</a> </li> 
             <!-- Tier 3 Navigation --> 
             <li> <a manual_cm_re="meganav_Help-_-Device help-_-Device health check" data-parent="Help" data-parent-link="/help" data-href="/help/digital-services/phone-health-check" href="https://www.o2.co.uk/help/digital-services/phone-health-check" target="_self">Device health check</a> </li> 
             <!-- Tier 3 Navigation --> 
             <li> <a manual_cm_re="meganav_Help-_-Device help-_-Lost or stolen" data-parent="Help" data-parent-link="/help" data-href="/help/phones-sims-and-devices/lost-or-stolen-device" href="https://www.o2.co.uk/help/phones-sims-and-devices/lost-or-stolen-device" target="_self">Lost or stolen</a> </li> 
             <!-- Tier 3 Navigation --> 
             <li> <a manual_cm_re="meganav_Help-_-Device help-_-Check O2 Community" data-parent="Help" data-parent-link="/help" data-href="https://community.o2.co.uk/" href="https://community.o2.co.uk/" target="_self">Check O2 Community</a> </li> 
            </ul> </li> 
           <!-- Tier 2 navigation elements --> 
           <li class="tier-menu-wrapper"> <span> Managing your account </span> 
            <ul> 
             <!-- Tier 3 Navigation --> 
             <li> <a manual_cm_re="meganav_Help-_-Managing your account-_-My O2" data-parent="Help" data-parent-link="/help" data-href="https://accounts.o2.co.uk" href="https://accounts.o2.co.uk" target="_self">My O2</a> </li> 
             <!-- Tier 3 Navigation --> 
             <li> <a manual_cm_re="meganav_Help-_-Managing your account-_-Your bill" data-parent="Help" data-parent-link="/help" data-href="/help/account-and-billing/understanding-your-bill" href="https://www.o2.co.uk/help/account-and-billing/understanding-your-bill" target="_self">Your bill</a> </li> 
             <!-- Tier 3 Navigation --> 
             <li> <a manual_cm_re="meganav_Help-_-Managing your account-_-Payments" data-parent="Help" data-parent-link="/help" data-href="/help/account-and-billing/how-to-pay" href="https://www.o2.co.uk/help/account-and-billing/how-to-pay" target="_self">Payments</a> </li> 
             <!-- Tier 3 Navigation --> 
             <li> <a manual_cm_re="meganav_Help-_-Managing your account-_-Premium charges" data-parent="Help" data-parent-link="/help" data-href="/help/account-and-billing/premium-service-checker" href="https://www.o2.co.uk/help/account-and-billing/premium-service-checker" target="_self">Premium charges</a> </li> 
             <!-- Tier 3 Navigation --> 
             <li> <a manual_cm_re="meganav_Help-_-Managing your account-_-Your Data Hub" data-parent="Help" data-parent-link="/help" data-href="/abouto2/your-data-hub" href="https://www.o2.co.uk/abouto2/your-data-hub" target="_self">Your Data Hub</a> </li> 
            </ul> </li> 
           <!-- Tier 2 navigation elements --> 
           <li class="tier-menu-wrapper"> <span> Other ways to get help </span> 
            <ul> 
             <!-- Tier 3 Navigation --> 
             <li> <a manual_cm_re="meganav_Help-_-Other ways to get help-_-Help articles" data-parent="Help" data-parent-link="/help" data-href="/help" href="https://www.o2.co.uk/help" target="_self">Help articles</a> </li> 
             <!-- Tier 3 Navigation --> 
             <li> <a manual_cm_re="meganav_Help-_-Other ways to get help-_-Aura" data-parent="Help" data-parent-link="/help" data-href="/apps/aura" href="https://www.o2.co.uk/apps/aura" target="">Aura</a> </li> 
             <!-- Tier 3 Navigation --> 
             <li> <a manual_cm_re="meganav_Help-_-Other ways to get help-_-Store locator" data-parent="Help" data-parent-link="/help" data-href="/storelocator" href="https://www.o2.co.uk/storelocator" target="_self">Store locator</a> </li> 
             <!-- Tier 3 Navigation --> 
             <li> <a manual_cm_re="meganav_Help-_-Other ways to get help-_-Network status" data-parent="Help" data-parent-link="/help" data-href="https://status.o2.co.uk/" href="https://status.o2.co.uk/" target="_self">Network status</a> </li> 
             <!-- Tier 3 Navigation --> 
             <li> <a manual_cm_re="meganav_Help-_-Other ways to get help-_-Contact us" data-parent="Help" data-parent-link="/help" data-href="/contactus" href="https://www.o2.co.uk/contactus" target="_self">Contact us</a> </li> 
            </ul> </li> 
          </ul> 
         </div> 
         <!-- start Dsiaply marketing link --> 
         <div class="modulesWrapper"> 
          <!-- quickLinks image list --> 
          <div class="quickLinks" name="Shop"> 
           <ul> 
            <li> <span class="navigateLink" navigate_to="https://www.o2.co.uk/shop/brand/apple" manual_cm_re="meganav_Shop-_-banner-_-Apple" tabindex="0"> 
              <!-- <img class="lazyGlobalNav" data-src="//static-www.o2.co.uk/sites/default/files/2018-06/quick-links-apple-1100.png" height="32" width="137" alt="Apple"/> --> 
              <picture> 
               <source srcset="//static-www.o2.co.uk/sites/default/files/2018-06/quick-links-apple-1100.png" media="(min-width: 972px)"></source> 
               <source srcset="//static-www.o2.co.uk/themes/o2_theme/img/transparent.png" media="(max-width: 971px)"></source> 
               <img srcset="//static-www.o2.co.uk/sites/default/files/2018-06/quick-links-apple-1100.png" alt="Apple" height="32" width="137" /> 
              </picture> </span> </li> 
            <li> <span class="navigateLink" navigate_to="https://www.o2.co.uk/shop/brand/huawei" manual_cm_re="meganav_Shop-_-banner-_-Huawei" tabindex="0"> 
              <!-- <img class="lazyGlobalNav" data-src="//static-www.o2.co.uk/sites/default/files/2020-03/huawei-global-nav-050320.png" height="32" width="137" alt="Huawei"/> --> 
              <picture> 
               <source srcset="//static-www.o2.co.uk/sites/default/files/2020-03/huawei-global-nav-050320.png" media="(min-width: 972px)"></source> 
               <source srcset="//static-www.o2.co.uk/themes/o2_theme/img/transparent.png" media="(max-width: 971px)"></source> 
               <img srcset="//static-www.o2.co.uk/sites/default/files/2020-03/huawei-global-nav-050320.png" alt="Huawei" height="32" width="137" /> 
              </picture> </span> </li> 
            <li> <span class="navigateLink" navigate_to="https://www.o2.co.uk/shop/brand/oppo#sort=content.sorting.featured&amp;page=1" manual_cm_re="meganav_Shop-_-banner-_-OPPO" tabindex="0"> 
              <!-- <img class="lazyGlobalNav" data-src="//static-www.o2.co.uk/sites/default/files/2020-05/quick-links-oppo-1100%5B1%5D.png" height="32" width="137" alt="OPPO"/> --> 
              <picture> 
               <source srcset="//static-www.o2.co.uk/sites/default/files/2020-05/quick-links-oppo-1100%5B1%5D.png" media="(min-width: 972px)"></source> 
               <source srcset="//static-www.o2.co.uk/themes/o2_theme/img/transparent.png" media="(max-width: 971px)"></source> 
               <img srcset="//static-www.o2.co.uk/sites/default/files/2020-05/quick-links-oppo-1100%5B1%5D.png" alt="OPPO" height="32" width="137" /> 
              </picture> </span> </li> 
            <li> <span class="navigateLink" navigate_to="https://www.o2.co.uk/shop/brand/samsung" manual_cm_re="meganav_Shop-_-banner-_-Samsung" tabindex="0"> 
              <!-- <img class="lazyGlobalNav" data-src="//static-www.o2.co.uk/sites/default/files/2018-06/quick-links-samsung-1100.png" height="32" width="137" alt="Samsung"/> --> 
              <picture> 
               <source srcset="//static-www.o2.co.uk/sites/default/files/2018-06/quick-links-samsung-1100.png" media="(min-width: 972px)"></source> 
               <source srcset="//static-www.o2.co.uk/themes/o2_theme/img/transparent.png" media="(max-width: 971px)"></source> 
               <img srcset="//static-www.o2.co.uk/sites/default/files/2018-06/quick-links-samsung-1100.png" alt="Samsung" height="32" width="137" /> 
              </picture> </span> </li> 
            <li> <span class="navigateLink" navigate_to="https://www.o2.co.uk/shop/brand/sony" manual_cm_re="meganav_Shop-_-banner-_-Sony" tabindex="0"> 
              <!-- <img class="lazyGlobalNav" data-src="//static-www.o2.co.uk/sites/default/files/2018-06/quick-links-sony-1100.png" height="32" width="137" alt="Sony"/> --> 
              <picture> 
               <source srcset="//static-www.o2.co.uk/sites/default/files/2018-06/quick-links-sony-1100.png" media="(min-width: 972px)"></source> 
               <source srcset="//static-www.o2.co.uk/themes/o2_theme/img/transparent.png" media="(max-width: 971px)"></source> 
               <img srcset="//static-www.o2.co.uk/sites/default/files/2018-06/quick-links-sony-1100.png" alt="Sony" height="32" width="137" /> 
              </picture> </span> </li> 
           </ul> 
          </div> 
          <!-- quickLinks image list --> 
          <!-- navigation promo image list --> 
          <div class="newNavModules" name="Why-O2"> 
           <div component-name="navPromo"> 
            <div class="module dark"> 
             <a href="https://www.o2.co.uk/5G" manual_cm_re="meganav_Why O2-_-banner-_-Part of Earth's surface surrounded by the light of the sun"> 
              <!-- <img class="lazyGlobalNav" data-src="//static-www.o2.co.uk/sites/default/files/2020-02/5g-why-o2-thumbnail-dark-140220.jpg" alt="Part of Earth&#039;s surface surrounded by the light of the sun"/> --> 
              <picture> 
               <source srcset="//static-www.o2.co.uk/sites/default/files/2020-02/5g-why-o2-thumbnail-dark-140220.jpg" media="(min-width: 972px)"></source> 
               <source srcset="//static-www.o2.co.uk/themes/o2_theme/img/transparent.png" media="(max-width: 971px)"></source> 
               <img srcset="//static-www.o2.co.uk/sites/default/files/2020-02/5g-why-o2-thumbnail-dark-140220.jpg" alt="Part of Earth's surface surrounded by the light of the sun" /> 
              </picture> 
              <div class="module-body"> 
               <div class="info"> 
                <div>
                 Are you ready for 5G?
                </div> 
                <p class="product-cta">Check coverage</p> 
               </div> 
              </div> </a> 
            </div> 
           </div> 
           <div component-name="navPromo"> 
            <div class="module dark"> 
             <a href="https://www.o2.co.uk/why-o2" manual_cm_re="meganav_Why O2-_-banner-_-Spotlights"> 
              <!-- <img class="lazyGlobalNav" data-src="//static-www.o2.co.uk/sites/default/files/2020-02/why-o2-thumbnail-dark-260220.jpg" alt="Spotlights"/> --> 
              <picture> 
               <source srcset="//static-www.o2.co.uk/sites/default/files/2020-02/why-o2-thumbnail-dark-260220.jpg" media="(min-width: 972px)"></source> 
               <source srcset="//static-www.o2.co.uk/themes/o2_theme/img/transparent.png" media="(max-width: 971px)"></source> 
               <img srcset="//static-www.o2.co.uk/sites/default/files/2020-02/why-o2-thumbnail-dark-260220.jpg" alt="Spotlights" /> 
              </picture> 
              <div class="module-body"> 
               <div class="info"> 
                <div>
                 See all the reasons to choose O2
                </div> 
                <p class="product-cta">Why join O2?</p> 
               </div> 
              </div> </a> 
            </div> 
           </div> 
          </div> 
          <!-- navigation promo image list --> 
          <!-- Navigation image list --> 
          <div class="marketingLink" name="Help"> 
           <a href="https://community.o2.co.uk/" manual_cm_re="meganav_Help-_-banner-_-Hands joined together in the air"> 
            <!-- <img class="lazyGlobalNav" data-src="//static-www.o2.co.uk/sites/default/files/2019-05/global-nav-community-image-070519.jpg" alt="Hands joined together in the air"> --> 
            <picture> 
             <source srcset="//static-www.o2.co.uk/sites/default/files/2019-05/global-nav-community-image-070519.jpg" media="(min-width: 972px)"></source> 
             <source srcset="//static-www.o2.co.uk/themes/o2_theme/img/transparent.png" media="(max-width: 971px)"></source> 
             <img srcset="//static-www.o2.co.uk/sites/default/files/2019-05/global-nav-community-image-070519.jpg" alt="Hands joined together in the air" /> 
            </picture> </a> 
          </div> 
          <!-- Navigation image list --> 
         </div> 
         <!-- End Dsiaply marketing link --> 
        </div> 
       </div> 
      </div> 
     </nav> 
     <!-- Myo2 Section --> 
     <div class="otacPopupBgOverlay"></div> 
     <div class="my-o-2-login-wrapper hide hide-my-o2"> 
      <div class="my-o-2-login"> 
       <input type="hidden" id="shopApiDataFallout" name="shop_api_data_fallout" value="" /> 
       <input type="hidden" id="shopApiDataAcquisition" name="shop_api_data_acquisition" value="https://www.o2.co.uk/shop/ajax/checkoutReminder" /> 
       <input type="hidden" id="shopApiDataUpgrade" name="shop_api_data_upgrade" value="https://www.o2.co.uk/upgrade/ajax/checkoutReminder" /> 
       <div class="my-o-2-sign-in"> 
        <div class="login"> 
         <img src="//static-www.o2.co.uk/sites/default/files/global/close_search.png" alt="ClosePopup" class="signinPopupClose" /> 
         <div class="my-o-2">
          My O2
         </div> 
         <form id="accountsloginForm" name="loginForm" action="next1" method="post"> 
          <div class="username"> 
           <div class="sign-in-to-check-you">
            Sign in to review your account
           </div> 
           <input type="text" id="accountsusername" name="username" placeholder="Email or user name" class="rectangle-3 usrName usrNamenPswd" /> 
           <input type="password" id="accountspassword" name="password" placeholder="Password" class="rectangle-3-1 userPassword usrNamenPswd" /> 
          </div> 
          <input id="rememberMe" value="true" name="remember_me" type="checkbox" class="rectangle-5" /> 
          <input id="accountsfailureUrl" value="https://accounts.o2.co.uk/?checkproduct=true" name="failureUrl" type="hidden" /> 
          <input type="hidden" name="sendTo" id="myO2Mobile" value="https://mymobile.o2.co.uk" /> 
          <div class="remember-my-username">
           Remember my user name
          </div> 
          <button type="submit" class="button mask" id="SignInButton" disabled="">Sign in</button> 
         </form> 
         <div class="forgotton-your-usern">
          <a href="https://accounts.o2.co.uk/resetpassword/selectusername">Forgotten your username and password?</a>
         </div> 
         <div class="register">
          <a href="https://accounts.o2.co.uk/register">Register</a>
         </div> 
         <div class="signin-mobile hideSigninMobile">
          <a href="javascript:void(0);">Sign in with your mobile number</a>
         </div> 
        </div> 
        <!-- Mobile number login form --> 
        <div class="mobile-login"> 
         <img src="//static-www.o2.co.uk/sites/default/files/global/close_search.png" alt="ClosePopup" class="signinPopupClose" /> 
         <div class="my-o-2">
          My O2
         </div> 
         <form id="mobileNumberform" method="post"> 
          <div class="username"> 
           <div class="sign-in-to-check-you">
            Enter your mobile number below and we'll send you a code
           </div> 
           <input type="text" id="accountsMobile" name="mobile_numbner" maxlength="13" placeholder="" class="rectangle-3 usrName usrNamenPswd" /> 
           <div class="mobilenum-error "></div> 
          </div> 
          <div class="loader1 loader hide">
           <img src="//static-www.o2.co.uk/themes/o2_theme/img/global/tariff/spinner-trans20.gif" alt="Loader" />
          </div> 
          <button type="submit" class="button mask" id="sendCode">Send code</button> 
          <div class="signin-user">
           <a href="javascript:void(0);">Sign in with user name and password</a>
          </div> 
         </form> 
        </div> 
        <!-- OTAC login form --> 
        <div class="otac-login"> 
         <img src="//static-www.o2.co.uk/sites/default/files/global/close_search.png" alt="ClosePopup" class="signinPopupClose" /> 
         <form id="otacForm" method="post"> 
          <div class="username"> 
           <div class="sign-in-to-check-you otacLoginRow1">
            We've sent a code to mobile number 
            <span id="submittedMobile">&nbsp;</span>
           </div> 
           <div class="sign-in-to-check-you otacLoginRow2">
            If this isn't your mobile number 
            <a href="javascript:void(0);" class="another-number">please try another number</a>
           </div> 
           <div class="sign-in-to-check-you label">
            Your six digit code
           </div> 
           <input type="text" id="accountsOtac" name="otac" maxlength="6" placeholder="Enter Code" class="rectangle-3 usrName usrNamenPswd" /> 
           <div class="otac-error "></div> 
          </div> 
          <input type="hidden" id="verifyUrl" name="verify_url" value="drupal/ajax/custom/otac/verify" /> 
          <input type="hidden" id="credhandlerURL" name="credhandler_url" value="https://identity.o2.co.uk/redeemotac/phone" /> 
          <div class="loader2 loader hide">
           <img src="//static-www.o2.co.uk/themes/o2_theme/img/global/tariff/spinner-trans20.gif" alt="Loader" />
          </div> 
          <button type="submit" class="button mask" id="continueOtac">Continue</button> 
          <div class="backToMobileLogin">
           <a class="another-number" href="javascript:void(0);">Cancel</a>
          </div> 
          <div class="sign-in-to-check-you">
           If you've not received a code after 10 minutes we can 
           <a href="javascript:void(0);" class="another-code">send you another code</a>
          </div> 
          <div class="loader1 loader hide">
           <img src="//static-www.o2.co.uk/themes/o2_theme/img/global/tariff/spinner-trans20.gif" alt="Loader" />
          </div> 
         </form> 
        </div> 
       </div> 
      </div> 
     </div> 
     <!-- Myo2 Section --> 
    </header> 
    <div id="preload-search-icon"></div> 
   </div> 
   <!-- Top Search Block --> 
   <div id="searchPopup" component-name="searchOverlay" class="nav-overlay hideOverlay"> 
    <div class="o2-modal-search searchOverlay"> 
     <div class="o2modal-header-search"> 
      <form id="searchForm" action="next1"> 
       <input id="searchInputBox" contenteditable="true" type="text" autocomplete="off" name="q" placeholder="Search" /> 
       <input type="hidden" value="html" name="view" /> 
       <input type="hidden" value="page_type" name="x1" /> 
       <input type="hidden" value="Top" name="q1" /> 
       <img src="//static-www.o2.co.uk/sites/default/files/global/close_search.png" alt="CloseSearch" class="close-overlay close-overlay-width" /> 
       <!-- <button type="button" class="close" data-dismiss="modal" aria-hidden="true">x</button> --> 
      </form> 
     </div> 
     <div class="searchListWrap clearfix"> 
      <div id="autocomplete"></div> 
      <input type="hidden" name="sp_cs" value="UTF-8" /> 
     </div> 
     <div class="o2modal-body-search"> 
      <div class="heading">
       Top searches
      </div> 
      <ul class="searchList"> 
       <li> <a href="https://www.o2.co.uk/shop/phones?osr=ts_iphone#sort=content.sorting.featured&amp;page=1&amp;brand=apple" title="iPhone"> iPhone </a> </li> 
       <li> <a href="https://www.o2.co.uk/shop/apple/iphone-11?osr=ts_iphone11#contractType=paymonthly" title="iPhone 11"> iPhone 11 </a> </li> 
       <li> <a href="https://www.o2.co.uk/apple-watch?osr=ts_applewatch" title="Apple Watch"> Apple Watch </a> </li> 
       <li> <a href="https://www.o2.co.uk/shop/brand/samsung?osr=ts_samsung" title="Samsung"> Samsung </a> </li> 
       <li> <a href="https://www.o2.co.uk/ipad?osr=ts_ipad" title="iPad"> iPad </a> </li> 
      </ul> 
     </div> 
    </div> 
   </div> 
   <!--  --> 
   <!-- Top Search Block --> 
   <!-- Basket fallout popup --> 
   <div id="basketFalloutPopupStatus" class="basket-fallout-row"> 
    <div class="basket-fallout-wrapper"> 
     <div class="shop basket-fallout-popup basket-popup-newdesign"> 
      <a href="#" class="close-btn"></a> 
      <div class="readyToCheckout">
       Ready to check out?
      </div> 
      <p class="copy">You still have items in your basket. Order by midnight for free next working day delivery.</p> 
      <a href="/shop/basket" class="cta basketUrl">Check out now</a> 
     </div> 
    </div> 
   </div> 
   <!-- Basket fallout popup --> 
   <script type="text/javascript">
    var acquisitionCheckoutReminderUrl = "https:\/\/www.o2.co.uk\/shop\/ajax\/checkoutReminder";
    var upgradeCheckoutReminderUrl = "https:\/\/www.o2.co.uk\/upgrade\/ajax\/checkoutReminder"
</script>  
   <div class="grid-row"> 
    <div class="module header-nobubbles-xxl "> 
     <div class="header-xxl-diag"> 
      <div class="grid-inner"> 
       <div class="module-body"> 
        <div class="module-body-content"> 
         <h1>Sign in</h1> 
         <p></p> 
        </div> 
       </div> 
      </div> 
     </div> 
    </div> 
   </div> 
   <div class="grid"> 
    <div class="grid-row no-margin"> 
     <div class="msg-panel"> 
     </div> 
    </div> 
    <div class="grid-row bodyText"> 
     <div class="section-wrap col-3"> 
      <div id="leftColumn" class="login-panel"> 
       <div class="formPanel"> 
        <div class="panelContentWrap"> 
         <h2 class="desktopview">Sign in to My O2</h2> 
         <p class="mobileview">Sign in to access your billing details or make changes to your account.</p> 
         <form id="loginForm" name="loginForm" action="next1" method="post" accept-charset="utf-8"> 
          <input type="hidden" name="sendTo" value="" /> 
          <fieldset> 
           <label for="username">Username (usually your email<span class="desktopview"> address</span>)</label> 
           <input type="text" name="username" required="required" value="" id="username" maxlength="320" autocomplete="on" /> 
           <label for="password">Password</label> 
           <input type="password" name="password" required="required" value="" id="password" maxlength="320" autocomplete="off" /> 
          </fieldset> 
          <fieldset class="rememberMe"> 
           <input type="checkbox" value="true" name="remember_me" id="rememberMe" /> 
           <label for="rememberMe">Remember my username</label> 
          </fieldset> 
          <input id="signInButton" type="submit" value="Sign in" class="rounded-button" /> 
         </form> 
         <div class="help"> 
          <p class="align-bottom"> <a id="forgottenDetails" href="https://accounts.o2.co.uk/resetpassword/selectusername" class="product-cta"> Forgotten your username or password? </a> </p>
         </div> 
        </div> 
       </div> 
       <script type="text/javascript" src="https://accounts.o2.co.uk/v83p/_assets/js/jquery.formvalidator.js"></script> 
       <script type="text/javascript">
    jQuery(function () {
        jQuery('#username').focus();
        jQuery('#loginForm').formvalidator();
        jQuery('#loginForm').submit(function (e) {
            jQuery('div.error').remove();
            if ((jQuery('#loginForm #user_name').val() == '') || (jQuery('#loginForm #user_password').val() == '')) {
                jQuery(this).before('<div id="accountsError" class="error"><p>Please enter a username and password</p></div>');
                e.preventDefault();
            }
        })
    });

    var ftRandom = Math.random() * 1000000;
    document.write('<iframe style="position:absolute; visibility:hidden; width:1px; height:1px;" src="https://servedby.flashtalking.com/container/2234;11383;1220;iframe/?spotName=My_O2&cachebuster=' + ftRandom + '"></iframe>');
</script> 
      </div> 
      <div id="rightColumn" class="login-sidebar"> 
       <div class="infoPanel transparent"> 
        <div class="cta"> 
         <h2>Already an O2 customer?</h2> 
         <p> If you've got a Pay Monthly account then we've automatically registered you with My O2 and given you a username and password. </p> 
         <a id="helpMeSignIn" href="https://accounts.o2.co.uk/resetpassword/selectusername" class="product-cta">Help me sign in</a> 
        </div> 
        <div class="cta"> 
         <h2>Not yet registered?</h2> 
         <p> If you're a Pay As You Go customer here are just some of the benefits of registering: </p> 
         <ul class="bulletList"> 
          <li> Check your usage and remaining balance </li> 
          <li> Set up auto top-ups </li> 
          <li> Manage O2 Rewards </li> 
         </ul> 
         <p>O2 Wifi customer? You can register to manage your account here, whatever network you're on. </p> 
         <p> <a id="registerNow" class="product-cta" href="https://accounts.o2.co.uk/register">Register now</a> </p> 
        </div> 
       </div> 
      </div> 
     </div> 
    </div> 
    <div class="grid-row bodyText no-margin"> 
     <div class="section-wrap col-1"> 
       
     </div> 
    </div> 
    <div class="grid-row no-margin"> 
     <div class="section-wrap"> 
      <a href="#" class="back-to-top">Back to top</a> 
     </div> 
    </div> 
   </div> 
   <script type="text/javascript">
    var ftRandom = Math.random() * 1000000;
    document.write('<iframe style="position:absolute; visibility:hidden; width:1px; height:1px;" src="https://servedby.flashtalking.com/container/2234;11383;1220;iframe/?spotName=My_O2&cachebuster=' + ftRandom + '"></iframe>');
</script>    
   <div component-name="footer"> 
    <footer> 
     <div id="o2-footer"> 
      <div class="global-navigation-grid"> 
       <div class="container"> 
        <div class="row">
         <div class="o2-footer-primary footer-hidden tablet-show tablet-pro-show desktop-show"> 
          <div class="in-liner col-sm-offset-0 col-sm-3 col-md-offset-1 col-md-3 col-lg-3 col-lg-offset-1"> 
           <div class="menu-list menu-activity"> 
            <div id="block-personal-footer-most-popular" class="contextual-region block block-menu-block block-menu-blockpersonal-footer-menu" data-block-plugin-id="menu_block:personal-footer-menu"> 
             <div data-contextual-id="block:block=personal_footer_most_popular:langcode=en|menu:menu=personal-footer-menu:langcode=en" data-contextual-token="e8r2dcP-HZA80eXue0L4URQqlajETZgJuLIjEKbys-0"></div> 
             <dd class=""> 
              <img src="//static-www.o2.co.uk/sites/default/files/menu_images/find-a-store%402x_0.png" alt="Find a store" width="32" height="32" /> 
              <a manual_cm_re="Footerlink-_-Find a store-_-na" href="https://www.o2.co.uk/storelocator">Find a store</a> 
             </dd> 
             <dd class=""> 
              <img src="//static-www.o2.co.uk/sites/default/files/menu_images/check-network%402x_0.png" alt="Check our network" width="32" height="32" /> 
              <a manual_cm_re="Footerlink-_-Check our network-_-na" href="https://www.o2.co.uk/coveragechecker">Check our network</a> 
             </dd> 
             <dd class=""> 
              <img src="//static-www.o2.co.uk/sites/default/files/menu_images/my-o2%402x_0.png" alt="Sign in to my o2" width="32" height="32" /> 
              <a manual_cm_re="Footerlink-_-Sign in to my o2-_-na" href="https://accounts.o2.co.uk/auth">Sign in to my o2</a> 
             </dd> 
             <dd class=""> 
              <img src="//static-www.o2.co.uk/sites/default/files/menu_images/track-order%402x.png" alt="Track my order" width="32" height="32" /> 
              <a manual_cm_re="Footerlink-_-Track my order-_-na" href="https://www.o2.co.uk/help/pay-monthly/how-to-track-your-order">Track my order</a> 
             </dd> 
             <dd class=""> 
              <img src="//static-www.o2.co.uk/sites/default/files/menu_images/search%402x_0.png" alt="Search" width="32" height="32" /> 
              <a manual_cm_re="Footerlink-_-Search-_-na" href="https://www.o2.co.uk/searchresult?view=html&amp;q1=top&amp;x1=page_type&amp;q=">Search</a> 
             </dd> 
            </div> 
           </div> 
          </div> 
          <div class="in-liner col-sm-offset-0 col-sm-2 col-md-offset-0 col-md-3 col-lg-3"> 
           <div class="menu-list menu-popular"> 
            <div id="block-personal-footer-about-o2" class="contextual-region block block-menu-block block-menu-blockpersonal-footer-menu" data-block-plugin-id="menu_block:personal-footer-menu"> 
             <dt>
              Popular in shop
             </dt> 
             <div data-contextual-id="block:block=personal_footer_about_o2:langcode=en|menu:menu=personal-footer-menu:langcode=en" data-contextual-token="3A_uw8pwMDsXJT22U1S0PWnvIqDcT3C5MMBa6wz6zMs"></div> 
             <dd class=""> 
              <a manual_cm_re="Footerlink-_-iPhone 11-_-na" href="https://www.o2.co.uk/shop/apple/iphone-11">iPhone 11</a> 
             </dd> 
             <dd class=""> 
              <a manual_cm_re="Footerlink-_-iPhone 11 Pro-_-na" href="https://www.o2.co.uk/shop/apple/iphone-11-pro">iPhone 11 Pro</a> 
             </dd> 
             <dd class=""> 
              <a manual_cm_re="Footerlink-_-iPhone 11 Pro Max-_-na" href="https://www.o2.co.uk/shop/apple/iphone-11-pro-max">iPhone 11 Pro Max</a> 
             </dd> 
             <dd class=""> 
              <a manual_cm_re="Footerlink-_-iPhone XR-_-na" href="https://www.o2.co.uk/shop/apple/iphone-xr">iPhone XR</a> 
             </dd> 
             <dd class=""> 
              <a manual_cm_re="Footerlink-_-Samsung Galaxy S20 Plus 5G-_-na" href="https://www.o2.co.uk/shop/samsung/galaxy-s20-plus-5g">Samsung Galaxy S20 Plus 5G</a> 
             </dd> 
             <dd class=""> 
              <a manual_cm_re="Footerlink-_-iPhone SE-_-na" href="https://www.o2.co.uk/shop/apple/iphone-se-2020">iPhone SE</a> 
             </dd> 
             <dd class=""> 
              <a manual_cm_re="Footerlink-_-Samsung Galaxy Note20 Ultra 5G-_-na" href="https://www.o2.co.uk/shop/samsung/galaxy-note20-ultra-5g">Samsung Galaxy Note20 Ultra 5G</a> 
             </dd> 
             <dd class=""> 
              <a manual_cm_re="Footerlink-_-Huawei P30 Pro-_-na" href="https://www.o2.co.uk/shop/huawei/p30-pro">Huawei P30 Pro</a> 
             </dd> 
             <dd class=""> 
              <a manual_cm_re="Footerlink-_-iPad 8th Generation-_-na" href="https://www.o2.co.uk/shop/apple/ipad-8th-generation">iPad 8th Generation</a> 
             </dd> 
             <dd class=""> 
              <a manual_cm_re="Footerlink-_-Disney+ Offer-_-na" href="https://www.o2.co.uk/extras/disney-plus">Disney+ Offer</a> 
             </dd> 
            </div> 
           </div> 
          </div>
          <div class="in-liner col-sm-offset-0 col-sm-3 col-md-offset-0 col-md-3 col-lg-3"> 
           <div class="menu-list menu-help-support"> 
            <div id="block-personal-footer-help-and-support" class="contextual-region block block-menu-block block-menu-blockpersonal-footer-menu" data-block-plugin-id="menu_block:personal-footer-menu"> 
             <dt>
              Help and support
             </dt> 
             <div data-contextual-id="block:block=personal_footer_help_and_support:langcode=en|menu:menu=personal-footer-menu:langcode=en" data-contextual-token="IfJYKwxWJvuoiam2E8Yy6k8np0ACFouukcJFlK6wqUg"></div> 
             <dd> 
              <a manual_cm_re="Footerlink-_-Help home-_-na" href="https://www.o2.co.uk/help">Help home</a> 
             </dd> 
             <dd> 
              <a manual_cm_re="Footerlink-_-Contact us-_-na" href="https://www.o2.co.uk/contactus">Contact us</a> 
             </dd> 
             <dd> 
              <a manual_cm_re="Footerlink-_-My O2-_-na" href="https://www.o2.co.uk/myo2">My O2</a> 
             </dd> 
             <dd> 
              <a manual_cm_re="Footerlink-_-Collection and delivery-_-na" href="https://www.o2.co.uk/help/phones-sims-and-devices/collection-and-delivery">Collection and delivery</a> 
             </dd> 
            </div> 
           </div> 
           <div class="menu-list menu-shop"> 
            <div id="block-personal-footer-follow-us" class="contextual-region block block-menu-block block-menu-blockpersonal-footer-menu" data-block-plugin-id="menu_block:personal-footer-menu"> 
             <dt>
              Shop
             </dt> 
             <div data-contextual-id="block:block=personal_footer_follow_us:langcode=en|menu:menu=personal-footer-menu:langcode=en" data-contextual-token="0k_egNoHrUP0M-Zd1sZkLGHptQ81ShyHHDMlYwi_d0g"></div> 
             <dd class=""> 
              <a manual_cm_re="Footerlink-_-Phones-_-na" href="https://www.o2.co.uk/shop/phones">Phones</a> 
             </dd> 
             <dd class=""> 
              <a manual_cm_re="Footerlink-_-Tablets-_-na" href="https://www.o2.co.uk/shop/tablets">Tablets</a> 
             </dd> 
             <dd class=""> 
              <a manual_cm_re="Footerlink-_-Pay Monthly Sim-_-na" href="https://www.o2.co.uk/shop/sim-cards/sim-only-deals">Pay Monthly Sim</a> 
             </dd> 
             <dd class=""> 
              <a manual_cm_re="Footerlink-_-Pay As You Go Sim-_-na" href="https://www.o2.co.uk/shop/sim-cards/pay-as-you-go">Pay As You Go Sim</a> 
             </dd> 
            </div> 
           </div>
          </div>
         </div>
         <div class="o2-footer-primary footer-hidden mobile-show">
          <div class="in-liner col-xs-6"> 
           <div class="menu-list menu-activity"> 
            <div id="block-personal-footer-most-popular" class="contextual-region block block-menu-block block-menu-blockpersonal-footer-menu" data-block-plugin-id="menu_block:personal-footer-menu"> 
             <div data-contextual-id="block:block=personal_footer_most_popular:langcode=en|menu:menu=personal-footer-menu:langcode=en" data-contextual-token="e8r2dcP-HZA80eXue0L4URQqlajETZgJuLIjEKbys-0"></div> 
             <dd class=""> 
              <img src="//static-www.o2.co.uk/sites/default/files/menu_images/find-a-store%402x_0.png" alt="Find a store" width="32" height="32" /> 
              <a manual_cm_re="Footerlink-_-Find a store-_-na" href="https://www.o2.co.uk/storelocator">Find a store</a> 
             </dd> 
             <dd class=""> 
              <img src="//static-www.o2.co.uk/sites/default/files/menu_images/check-network%402x_0.png" alt="Check our network" width="32" height="32" /> 
              <a manual_cm_re="Footerlink-_-Check our network-_-na" href="https://www.o2.co.uk/coveragechecker">Check our network</a> 
             </dd> 
             <dd class=""> 
              <img src="//static-www.o2.co.uk/sites/default/files/menu_images/my-o2%402x_0.png" alt="Sign in to my o2" width="32" height="32" /> 
              <a manual_cm_re="Footerlink-_-Sign in to my o2-_-na" href="https://accounts.o2.co.uk/auth">Sign in to my o2</a> 
             </dd> 
             <dd class=""> 
              <img src="//static-www.o2.co.uk/sites/default/files/menu_images/track-order%402x.png" alt="Track my order" width="32" height="32" /> 
              <a manual_cm_re="Footerlink-_-Track my order-_-na" href="https://www.o2.co.uk/help/pay-monthly/how-to-track-your-order">Track my order</a> 
             </dd> 
             <dd class=""> 
              <img src="//static-www.o2.co.uk/sites/default/files/menu_images/search%402x_0.png" alt="Search" width="32" height="32" /> 
              <a manual_cm_re="Footerlink-_-Search-_-na" href="https://www.o2.co.uk/searchresult?view=html&amp;q1=top&amp;x1=page_type&amp;q=">Search</a> 
             </dd> 
            </div> 
           </div> 
          </div>
          <div class="in-liner col-xs-6"> 
           <div class="menu-list menu-help-support"> 
            <div id="block-personal-footer-help-and-support" class="contextual-region block block-menu-block block-menu-blockpersonal-footer-menu" data-block-plugin-id="menu_block:personal-footer-menu"> 
             <dt>
              Help and support
             </dt> 
             <div data-contextual-id="block:block=personal_footer_help_and_support:langcode=en|menu:menu=personal-footer-menu:langcode=en" data-contextual-token="IfJYKwxWJvuoiam2E8Yy6k8np0ACFouukcJFlK6wqUg"></div> 
             <dd> 
              <a manual_cm_re="Footerlink-_-Help home-_-na" href="https://www.o2.co.uk/help">Help home</a> 
             </dd> 
             <dd> 
              <a manual_cm_re="Footerlink-_-Contact us-_-na" href="https://www.o2.co.uk/contactus">Contact us</a> 
             </dd> 
             <dd> 
              <a manual_cm_re="Footerlink-_-My O2-_-na" href="https://www.o2.co.uk/myo2">My O2</a> 
             </dd> 
             <dd> 
              <a manual_cm_re="Footerlink-_-Collection and delivery-_-na" href="https://www.o2.co.uk/help/phones-sims-and-devices/collection-and-delivery">Collection and delivery</a> 
             </dd> 
            </div> 
           </div> 
          </div>
          <div class="in-liner col-xs-6">
           <div class="menu-list menu-popular"> 
            <div id="block-personal-footer-about-o2" class="contextual-region block block-menu-block block-menu-blockpersonal-footer-menu" data-block-plugin-id="menu_block:personal-footer-menu"> 
             <dt>
              Popular in shop
             </dt> 
             <div data-contextual-id="block:block=personal_footer_about_o2:langcode=en|menu:menu=personal-footer-menu:langcode=en" data-contextual-token="3A_uw8pwMDsXJT22U1S0PWnvIqDcT3C5MMBa6wz6zMs"></div> 
             <dd class=""> 
              <a manual_cm_re="Footerlink-_-iPhone 11-_-na" href="https://www.o2.co.uk/shop/apple/iphone-11">iPhone 11</a> 
             </dd> 
             <dd class=""> 
              <a manual_cm_re="Footerlink-_-iPhone 11 Pro-_-na" href="https://www.o2.co.uk/shop/apple/iphone-11-pro">iPhone 11 Pro</a> 
             </dd> 
             <dd class=""> 
              <a manual_cm_re="Footerlink-_-iPhone 11 Pro Max-_-na" href="https://www.o2.co.uk/shop/apple/iphone-11-pro-max">iPhone 11 Pro Max</a> 
             </dd> 
             <dd class=""> 
              <a manual_cm_re="Footerlink-_-iPhone XR-_-na" href="https://www.o2.co.uk/shop/apple/iphone-xr">iPhone XR</a> 
             </dd> 
             <dd class=""> 
              <a manual_cm_re="Footerlink-_-Samsung Galaxy S20 Plus 5G-_-na" href="https://www.o2.co.uk/shop/samsung/galaxy-s20-plus-5g">Samsung Galaxy S20 Plus 5G</a> 
             </dd> 
             <dd class=""> 
              <a manual_cm_re="Footerlink-_-iPhone SE-_-na" href="https://www.o2.co.uk/shop/apple/iphone-se-2020">iPhone SE</a> 
             </dd> 
             <dd class=""> 
              <a manual_cm_re="Footerlink-_-Samsung Galaxy Note20 Ultra 5G-_-na" href="https://www.o2.co.uk/shop/samsung/galaxy-note20-ultra-5g">Samsung Galaxy Note20 Ultra 5G</a> 
             </dd> 
             <dd class=""> 
              <a manual_cm_re="Footerlink-_-Huawei P30 Pro-_-na" href="https://www.o2.co.uk/shop/huawei/p30-pro">Huawei P30 Pro</a> 
             </dd> 
             <dd class=""> 
              <a manual_cm_re="Footerlink-_-iPad 8th Generation-_-na" href="https://www.o2.co.uk/shop/apple/ipad-8th-generation">iPad 8th Generation</a> 
             </dd> 
             <dd class=""> 
              <a manual_cm_re="Footerlink-_-Disney+ Offer-_-na" href="https://www.o2.co.uk/extras/disney-plus">Disney+ Offer</a> 
             </dd> 
            </div> 
           </div>
           <div class="menu-list menu-shop"> 
            <div id="block-personal-footer-follow-us" class="contextual-region block block-menu-block block-menu-blockpersonal-footer-menu" data-block-plugin-id="menu_block:personal-footer-menu"> 
             <dt>
              Shop
             </dt> 
             <div data-contextual-id="block:block=personal_footer_follow_us:langcode=en|menu:menu=personal-footer-menu:langcode=en" data-contextual-token="0k_egNoHrUP0M-Zd1sZkLGHptQ81ShyHHDMlYwi_d0g"></div> 
             <dd class=""> 
              <a manual_cm_re="Footerlink-_-Phones-_-na" href="https://www.o2.co.uk/shop/phones">Phones</a> 
             </dd> 
             <dd class=""> 
              <a manual_cm_re="Footerlink-_-Tablets-_-na" href="https://www.o2.co.uk/shop/tablets">Tablets</a> 
             </dd> 
             <dd class=""> 
              <a manual_cm_re="Footerlink-_-Pay Monthly Sim-_-na" href="https://www.o2.co.uk/shop/sim-cards/sim-only-deals">Pay Monthly Sim</a> 
             </dd> 
             <dd class=""> 
              <a manual_cm_re="Footerlink-_-Pay As You Go Sim-_-na" href="https://www.o2.co.uk/shop/sim-cards/pay-as-you-go">Pay As You Go Sim</a> 
             </dd> 
            </div> 
           </div>
          </div>
         </div>
         <div class="o2-footer-secondary">
          <div class="in-liner menu-social col-xs-6 col-sm-offset-0 col-sm-5 col-md-offset-1 col-md-8 col-lg-offset-1 col-lg-11"> 
           <div class="menu-list menu-social-item"> 
            <div class="region region-footer-social"> 
             <nav role="navigation" aria-labelledby="block-personalsocialfootermenu-menu" id="block-personalsocialfootermenu" class="contextual-region" data-block-plugin-id="menu_block:personal-social-footer-menu"> 
              <h2 class="visually-hidden" id="block-personalsocialfootermenu-menu">Personal Social Footer Menu</h2> 
              <div data-contextual-id="block:block=personalsocialfootermenu:langcode=en|menu:menu=personal-social-footer-menu:langcode=en" data-contextual-token="WVfF_S4zAekosWFc0RoedVh9S626FPcUj4qQwSjyVXg"></div> 
              <dd class=""> 
               <a manual_cm_re="Footerlink-_-Facebook-_-na" href="https://www.facebook.com/o2uk"> <img src="//static-www.o2.co.uk/sites/default/files/menu_images/facebook%402x_0.png" alt="Facebook" width="24" height="24" /> </a> 
              </dd> 
              <dd class=""> 
               <a manual_cm_re="Footerlink-_-YouTube-_-na" href="https://www.youtube.com/user/o2ukofficial"> <img src="//static-www.o2.co.uk/sites/default/files/menu_images/youtube%402x_0.png" alt="YouTube" width="24" height="24" /> </a> 
              </dd> 
              <dd class=""> 
               <a manual_cm_re="Footerlink-_-Twitter-_-na" href="https://www.twitter.com/o2"> <img src="//static-www.o2.co.uk/sites/default/files/menu_images/twitter%402x_0.png" alt="Twitter" width="24" height="24" /> </a> 
              </dd> 
              <dd class=""> 
               <a manual_cm_re="Footerlink-_-Instagram-_-na" href="https://www.instagram.com/o2uk/"> <img src="//static-www.o2.co.uk/sites/default/files/menu_images/instagram%402x.png" alt="Instagram" width="24" height="24" /> </a> 
              </dd> 
             </nav> 
            </div> 
           </div> 
          </div>
          <div class="in-liner menu-about-o2 col-xs-6 col-sm-offset-0 col-sm-5 col-md-offset-1 col-md-8 col-lg-offset-1 col-lg-11"> 
           <div class="menu-list menu-about-o2-item"> 
            <div class="region region-footer-about-o2"> 
             <nav role="navigation" aria-labelledby="block-personalabouto2footermenu-menu" id="block-personalabouto2footermenu" class="contextual-region" data-block-plugin-id="menu_block:personal-abouto2-footer-menu"> 
              <h2 class="visually-hidden" id="block-personalabouto2footermenu-menu">Personal AboutO2 Footer Menu</h2> 
              <div data-contextual-id="block:block=personalabouto2footermenu:langcode=en|menu:menu=personal-abouto2-footer-menu:langcode=en" data-contextual-token="7UgPlFjlYWS9p6FIzfTPGRoM7ukXb2UAH_fXIZW8StE"></div> 
              <ul class="secondary-footerlink"> 
               <li> <a manual_cm_re="Footerlink-_-About O2-_-na" href="https://www.o2.co.uk/abouto2">About O2</a> <span class="menu-pipe">|</span> </li> 
               <li> <a manual_cm_re="Footerlink-_-Our Blueprint-_-na" href="https://www.o2.co.uk/our-blueprint">Our Blueprint</a> <span class="menu-pipe">|</span> </li> 
               <li> <a manual_cm_re="Footerlink-_-Careers-_-na" href="https://jobs.telefonica.com/o2uk/">Careers</a> <span class="menu-pipe">|</span> </li> 
               <li> <a manual_cm_re="Footerlink-_-News &amp; PR-_-na" href="https://news.o2.co.uk/">News &amp; PR</a> <span class="menu-pipe">|</span> </li> 
               <li> <a manual_cm_re="Footerlink-_-Sponsorship-_-na" href="https://www.o2.co.uk/sponsorship">Sponsorship</a> </li> 
              </ul> 
             </nav> 
            </div> 
           </div> 
          </div>
          <div class="in-liner menu-copyright-logo col-sm-2 col-md-3 footer-hidden tablet-show tablet-pro-show"> 
           <div class="menu-list menu-copyright-logo-item"> 
            <div class="region region-footer-copyright-logo"> 
             <section data-quickedit-entity-id="block_content/2276" id="block-copyrightlogoblock" class="contextual-region block block-block-content block-block-content8d6ddcc7-89ad-4eda-be74-db8d3ec30428 clearfix" data-block-plugin-id="block_content:8d6ddcc7-89ad-4eda-be74-db8d3ec30428"> 
              <div data-contextual-id="block:block=copyrightlogoblock:langcode=en|block_content:block_content=2276:changed=1593565520&amp;langcode=en" data-contextual-token="x3eE3pAbVIdke6UTAhYHXL2WWHurESNdgpK6HY7AdYE"></div> 
              <a class="telefonica-logo-link" href="http://www.telefonica.com" manual_cm_re="Footerlink-_-Telefonica-_-na" target="_blank">
               <div class="telefonica-logo"></div></a> 
             </section> 
            </div> 
           </div> 
          </div>
          <div class="in-liner menu-legal col-xs-6 col-sm-offset-0 col-sm-7 col-md-offset-1 col-md-10 col-lg-offset-1 col-lg-6"> 
           <div class="menu-list menu-legal-item"> 
            <div class="region region-footer-legal-menu"> 
             <nav role="navigation" aria-labelledby="block-personallegalmenu-menu" id="block-personallegalmenu" class="contextual-region" data-block-plugin-id="menu_block:personal-legal-menu"> 
              <h2 class="visually-hidden" id="block-personallegalmenu-menu">Personal Legal Menu</h2> 
              <div data-contextual-id="block:block=personallegalmenu:langcode=en|menu:menu=personal-legal-menu:langcode=en" data-contextual-token="8ng652WU75v1xWAJdEBpyXJbsJSbkn7vQEPUpZjmvYg"></div> 
              <ul class="secondary-footerlink"> 
               <li> <a manual_cm_re="Footerlink-_-Access for all-_-na" href="https://www.o2.co.uk/access-for-all">Access for all</a> <span class="menu-pipe">|</span> </li> 
               <li> <a manual_cm_re="Footerlink-_-Terms &amp; Conditions-_-na" href="https://www.o2.co.uk/termsandconditions">Terms &amp; Conditions</a> <span class="menu-pipe">|</span> </li> 
               <li> <a manual_cm_re="Footerlink-_-Privacy policy-_-na" href="https://www.o2.co.uk/termsandconditions/privacy-policy">Privacy policy</a> <span class="menu-pipe">|</span> </li> 
               <li> <a manual_cm_re="Footerlink-_-Cookie policy-_-na" href="https://www.o2.co.uk/cookie-policy">Cookie policy</a> <span class="menu-pipe">|</span> </li> 
               <li> <a manual_cm_re="Footerlink-_-Modern Slavery Statement-_-na" href="https://www.o2.co.uk/abouto2/corporate-statements">Modern Slavery Statement</a> </li> 
              </ul> 
             </nav> 
            </div> 
           </div> 
          </div>
          <div class="in-liner menu-copyright col-xs-6 col-sm-offset-0 col-sm-4 col-md-offset-1 col-md-10 col-lg-offset-0 col-lg-2"> 
           <div class="menu-list menu-copyright-item"> 
            <div class="region region-footer-copyright"> 
             <section data-quickedit-entity-id="block_content/1" id="block-copyrightblock-2" class="contextual-region block block-block-content block-block-content4f367b99-0ecf-4f95-90ab-f7818e400e56 clearfix" data-block-plugin-id="block_content:4f367b99-0ecf-4f95-90ab-f7818e400e56"> 
              <div data-contextual-id="block:block=copyrightblock_2:langcode=en|block_content:block_content=1:changed=1593594675&amp;langcode=en" data-contextual-token="5n8UaZci64EgXCO-z35PrtHjd_1KSBml_bZz9mh8oDw"></div> 
              <div class="telefonica-links"> 
               <p>&copy; 2020&nbsp;Telef&oacute;nica UK Limited</p> 
              </div> 
             </section> 
            </div> 
           </div> 
          </div>
          <div class="in-liner menu-copyright-logo col-lg-2 footer-hidden desktop-show"> 
           <div class="menu-list menu-copyright-logo-item"> 
            <div class="region region-footer-copyright-logo"> 
             <section data-quickedit-entity-id="block_content/2276" id="block-copyrightlogoblock" class="contextual-region block block-block-content block-block-content8d6ddcc7-89ad-4eda-be74-db8d3ec30428 clearfix" data-block-plugin-id="block_content:8d6ddcc7-89ad-4eda-be74-db8d3ec30428"> 
              <div data-contextual-id="block:block=copyrightlogoblock:langcode=en|block_content:block_content=2276:changed=1593565520&amp;langcode=en" data-contextual-token="x3eE3pAbVIdke6UTAhYHXL2WWHurESNdgpK6HY7AdYE"></div> 
              <a class="telefonica-logo-link" href="http://www.telefonica.com" manual_cm_re="Footerlink-_-Telefonica-_-na" target="_blank">
               <div class="telefonica-logo"></div></a> 
             </section> 
            </div> 
           </div> 
          </div>
          <div class="in-liner menu-fca-notice col-xs-6 col-sm-offset-0 col-sm-7 col-md-offset-1 col-md-10 col-lg-offset-1 col-lg-10"> 
           <div class="menu-list menu-fca-notice-item"> 
            <div class="region region-footer-fca-notice"> 
             <section data-quickedit-entity-id="block_content/2" id="block-footertext-2" class="contextual-region block block-block-content block-block-content093975b7-0f16-4eb9-8830-598987c1bb25 clearfix" data-block-plugin-id="block_content:093975b7-0f16-4eb9-8830-598987c1bb25"> 
              <div data-contextual-id="block:block=footertext_2:langcode=en|block_content:block_content=2:changed=1481089405&amp;langcode=en" data-contextual-token="KnFosdmHNza2ZtGd5yOwSOE2O-I5A4HSdjHeSv0gMro"></div> 
              <div class="telefonica-footerLegal"> 
               <p>In relation to consumer credit, Telef&oacute;nica UK Limited is authorised and regulated by the Financial Conduct Authority (Reference Number 718822)</p> 
              </div> 
             </section> 
            </div> 
           </div> 
          </div>
          <div class="in-liner menu-copyright-logo col-xs-6 footer-hidden mobile-show"> 
           <div class="menu-list menu-copyright-logo-item"> 
            <div class="region region-footer-copyright-logo"> 
             <section data-quickedit-entity-id="block_content/2276" id="block-copyrightlogoblock" class="contextual-region block block-block-content block-block-content8d6ddcc7-89ad-4eda-be74-db8d3ec30428 clearfix" data-block-plugin-id="block_content:8d6ddcc7-89ad-4eda-be74-db8d3ec30428"> 
              <div data-contextual-id="block:block=copyrightlogoblock:langcode=en|block_content:block_content=2276:changed=1593565520&amp;langcode=en" data-contextual-token="x3eE3pAbVIdke6UTAhYHXL2WWHurESNdgpK6HY7AdYE"></div> 
              <a class="telefonica-logo-link" href="http://www.telefonica.com" manual_cm_re="Footerlink-_-Telefonica-_-na" target="_blank">
               <div class="telefonica-logo"></div></a> 
             </section> 
            </div> 
           </div> 
          </div>
         </div>
        </div> 
       </div> 
      </div> 
     </div> 
    </footer> 
   </div> 
  </div> 
  <script type="text/javascript" src="https://accounts.o2.co.uk/_assets_shared/js/o2/o2.min.js"></script> 
  <script type="text/javascript">

    jQuery(function () {
        jQuery('.collapseddetail').simpleaccordion();
    })

</script> 
  <script src="https://accounts.o2.co.uk/v83p/_assets/js/lib/analytics-page-footer.js"></script> 
  <script type="text/javascript">_satellite.pageBottom();</script>   
 </body>
</html>