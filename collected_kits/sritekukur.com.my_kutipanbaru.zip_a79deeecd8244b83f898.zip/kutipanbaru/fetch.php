<?php

//fetch.php

include('database_connection.php');

$column = array('order_customer_name', 'order_value', 'keranabayaran', 'order_date', 'WT', 'KB', 'TJ');

$query = "SELECT * FROM tbl_kutipan ";

if(isset($_POST['search']['value']))
{
 $query .= '
 WHERE order_customer_name LIKE "%'.$_POST['search']['value'].'%" 
 OR order_value LIKE "%'.$_POST['search']['value'].'%" 
 OR order_date LIKE "%'.$_POST['search']['value'].'%" 
 OR keranabayaran LIKE "%'.$_POST['search']['value'].'%" 
 OR WT LIKE "%'.$_POST['search']['value'].'%" 

 ';
}

if(isset($_POST['order']))
{
 $query .= 'ORDER BY '.$column[$_POST['order']['0']['column']].' '.$_POST['order']['0']['dir'].' ';
}
else
{
 $query .= 'ORDER BY orde_id DESC ';
}

$query1 = '';

if($_POST['length'] != -1)
{
 $query1 = 'LIMIT ' . $_POST['start'] . ', ' . $_POST['length'];
}

$statement = $connect->prepare($query);

$statement->execute();

$number_filter_row = $statement->rowCount();

$statement = $connect->prepare($query . $query1);

$statement->execute();

$result = $statement->fetchAll();

$data = array();

foreach($result as $row)
{
 $sub_array = array();
 $sub_array[] = $row['order_id'];
 $sub_array[] = $row['order_date'];
 $sub_array[] = $row['order_customer_name'];
 $sub_array[] = $row['order_value'];
 $sub_array[] = $row['keranabayaran'];

 $data[] = $sub_array;
}

function count_all_data($connect)
{
 $query = "SELECT * FROM tbl_kutipan";
 $statement = $connect->prepare($query);
 $statement->execute();
 return $statement->rowCount();
}

$output = array(
 'draw'    => intval($_POST['draw']),
 'recordsTotal'  => count_all_data($connect),
 'recordsFiltered' => $number_filter_row,
 'data'    => $data
);

echo json_encode($output);

?>
