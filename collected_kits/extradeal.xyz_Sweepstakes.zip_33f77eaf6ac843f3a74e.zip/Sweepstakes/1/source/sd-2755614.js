window.surveyData = {
    adex: 1,
    adex_alert_urll: 'https://lehtymns.com/4453095/?var={zone}&ymid={request_var}',
    adex_warning_urll: 'https://lehtymns.com/4453095/?var={zone}&ymid={request_var}',
    ipp_zonex: 4599387,
    ipp_zone_teenagex: 4599749,
    ipp_zone_reverse: 4453914,
    comment: 'Sweep survey 6 VI',
    autoexitx: 4254940,
    push_zonex: 4843177,
    reverse_zonex: 4254937,
    popunder_urll: 'https://lehtymns.com/4254936/?var={zone}&ymid={request_var}',
    lead: {
        not_unique: {
            redirect_urll: 'https://lehtymns.com/4254934/?var={zone}&ymid={request_var}',
        },
    },
    title: 'Kính gửi người dùng',
    subtitle: [
        'Chúng tôi cung cấp cho bạn cơ hội nhận được phần thưởng từ các nhà tài trợ của chúng tôi!',
        'Để nhận phần thưởng của bạn, chỉ cần hoàn thành khảo sát ngắn và ẩn danh của chúng tôi.',
        'Bạn chỉ có <b>{min} Phút và  {sec} Giây</b>, để tham gia.',
    ],
    logo_text: 'Xin chúc mừng! <br> <br> Cuộc thi quảng cáo trên <b>{date:today}</b>',
    alert: {
        welcome: `<h1>Xin chúc mừng!</h1>
        <p>Hômnay <b>{date:today}</b>  bạn đã được chọn ngẫu nhiên để tham gia vào bài kiểm tra này. Bạn sẽ chỉ mất một phút và bạn sẽ có cơ hội nhận được một giải thưởng.</p>
        <img src='/img/sweep/tokens10k.png'>
        <p>Mỗituần chúng tôi ngẫu nhiên chọn 10 người dùng. Chỉ có 10 người dùng may mắn sống ở <b>{countryName}</b> có cơ hội nhận phần thưởng!</p>
        <p>Bạnchỉ có <span><b>{min} phút và {sec} giây</b></span>, để tham gia.
        <br>
        Nhanhlên! Có một số giải thưởng hạn chế!</p>`,
        welcomebtn: 'Tiếp tục',
        empty: 'Xin lỗi, hộp quà tặng này trống rỗng! Bạn vẫn còn một vài lần thử. Chúc may mắn!',
        final: '',
    },
    main: {
        type: 'question',
        text: 'Giới tính của bạn là gì?',
        options: [
            {
                type: 'button',
                text: 'Người đàn ông',
                audience_id: [61427, 60623],
                action: {
                    goto: 'step2',
                },
            },
            {
                type: 'button',
                text: 'Người phụ nữ',
                audience_id: [61428, 60624],
                action: {
                    goto: 'step2',
                },
            },
        ],
    },
    step2: {
        type: 'question',
        text: 'Bạn bao nhiêu tuổi?',
        options: [
            {
                type: 'button',
                text: 'ít hơn 18 năm',
                audience_id: [61421, 62387, 60625],
                action: {
                    redirect_ipp: 'teenage',
                    redirect_url: SmartURL,
                    popunder_url: SmartURL,
                },
            },
            {
                type: 'button',
                text: '18-29 năm',
                audience_id: [62180, 62377, 68427, 78100, 62377, 62382, 68423, 78096],
                action: {
                    goto: 'step3',
                },
            },
            {
                type: 'button',
                text: '30-49 năm',
                audience_id: [62181, 62380, 68425, 78097, 62383, 78101],
                action: {
                    goto: 'step3',
                },
            },
            {
                type: 'button',
                text: '50-80 năm',
                audience_id: [62182, 62381, 68426, 78098, 62384, 78102],
                action: {
                    goto: 'step3',
                },
            },
        ],
    },
    step3: {
        type: 'question',
        text: 'Bạn có thường xuyên mua sắm trực tuyến?',
        options: [
            {
                type: 'button',
                text: 'Mỗi ngày',
                audience_id: 0,
                action: {
                    goto: 'step4',
                },
            },
            {
                type: 'button',
                text: 'Thường xuyên',
                audience_id: 0,
                action: {
                    goto: 'step4',
                },
            },
            {
                type: 'button',
                text: 'Hiếm khi',
                audience_id: 0,
                action: {
                    goto: 'step4',
                },
            },
            {
                type: 'button',
                text: 'Không bao giờ',
                audience_id: 0,
                action: {
                    goto: 'step4',
                },
            },
        ],
    },
    step4: {
        type: 'question',
        text: 'Bạn đã bao giờ sử dụng thẻ quà tặng/phiếu mua hàng cho mua hàng của mình chưa?',
        options: [
            {
                type: 'button',
                text: 'Có',
                audience_id: 0,
                action: {
                    goto: 'step5',
                },
            },
            {
                type: 'button',
                text: 'Không',
                audience_id: 0,
                action: {
                    goto: 'step5',
                },
            },
        ],
    },
    step5: {
        type: 'question',
        text: 'Bạn có quan tâm đến việc nhận được giảm giá và quà tặng lớn nhất?',
        options: [
            {
                type: 'button',
                text: 'Có',
                audience_id: 0,
                action: {
                    goto: 'step6',
                },
            },
            {
                type: 'button',
                text: 'Không',
                audience_id: 0,
                action: {
                    goto: 'step6',
                },
            },
        ],
    },
    step6: {
        type: 'question',
        text: 'Bạn thích điều gì hơn?',
        options: [
            {
                type: 'button',
                text: 'Một thẻ quà tặng',
                audience_id: 0,
                action: {
                    goto: 'final',
                },
            },
            {
                type: 'button',
                text: 'Giảm giá một lần',
                audience_id: 0,
                action: {
                    goto: 'final',
                },
            },
            {
                type: 'button',
                text: 'Một thẻ giảm giá',
                audience_id: 0,
                action: {
                    goto: 'final',
                },
            },
        ],
    },
    final: {
        type: 'thank_you',
        boxes: 1,
        timeout: 40,
        timeout_url: SmartURL,
        timeout_conversion: 1,
        content: `<div class="final">
                    <div class="final__step1">
                        <p>Cảmơn bạn đã tham gia bài kiểm tra của chúng tôi.</p>
                        <p>Bâygiờ bạn có cơ hội nhận được phần thưởng.</p>
                        <p>Tấtcả những gì bạn phải làm là chọn hộp quà phù hợp.</p>
                    </div>
                    <div class="final__step2">
                        <p>Rấttiếc!</p>
                        <p>Các hộp trống.</p>
                        <p>Bạnvẫn có cơ hội nhận được phần thưởng từ các đối tác của chúng tôi.</p>
                        <p>Ưuđãi này chỉ có sẵn trong 7 phút tiếp theo!</p>
                    </div>
                    <div class="instructions">
                        <h2 class="instructions__header">Tìm phần thưởng!</h2>
                        <div class="instructions__text">
                            <span class=bounce>&darr;</span>
                            <h3 class="instructions__text-1">tất cả những gì bạn phải làm là chọn <b>hộp quà chính xác</b>.</h3>
                            <h3 class="instructions__text-2">Nhấp vào nút TIẾP TỤC và hoàn thành các bước cuối cùng để có cơ hội nhận phần thưởng!</h3>
                            <span class=bounce>&darr;</span>
                        </div>
                    </div>
                </div>`,
        progress_title: 'Ước tính kết quả...',
        progress_texts: ['Chờ... Kiểm tra câu trả lời', 'Chờ... Đếm điểm của bạn'],
        progress_content: '',
        options: [
            {
                type: 'button',
                text: 'TIẾP TỤC',
                audience_id: 61426,
                action: {
                    conversion: 1,
                    redirect_url: SmartURL,
                },
            },
        ],
    },
};
