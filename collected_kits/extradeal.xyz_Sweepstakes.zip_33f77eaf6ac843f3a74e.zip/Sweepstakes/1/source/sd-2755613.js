window.surveyData = {
    adex: 1,
    adex_alert_urll: 'https://lehtymns.com/4453095/?var={zone}&ymid={request_var}',
    adex_warning_urll: 'https://lehtymns.com/4453095/?var={zone}&ymid={request_var}',
    ipp_zonex: 4599387,
    ipp_zone_teenagex: 4599749,
    ipp_zone_reverse: 4453914,
    comment: 'Sweep New 6 ZH',
    autoexitx: 4254940,
    push_zonex: 4843177,
    reverse_zonex: 4254937,
    popunder_urll: 'https://lehtymns.com/4254936/?var={zone}&ymid={request_var}',
    lead: {
        not_unique: {
            redirect_urll: 'https://lehtymns.com/4254934/?var={zone}&ymid={request_var}',
        },
    },
    title: '亲爱的用户',
    subtitle: [
        '我们为您提供从我们的赞助商那里获得奖励的机会！',
        '要获得奖励，只需完成我们的简短匿名调查。',
        '你只有 <b>{min} 分钟和 {sec} 秒</b>可以参与。',
    ],
    logo_text: '恭喜！<br><br><b>{date:today}</b> 的促销竞赛',
    alert: {
        welcome:
            "<h1>恭喜！</h1>\n <p>今天 <b>{date:today}</b> 你被随机选择参加本次测验。这只需要一分钟时间，你将有机会获得一个奖品。</p>\n <img src='/img/sweep/tokens10k.png'>\n <p>我们每周随机选择 10 位用户。只有 10 位居住在 <b>{国家/地区Name}</b> 的幸运用户有机会获得奖励！</p>\n <p>你只有 <span><b>{min} 分钟和 {sec} 秒</b></span>可以参与。\n <br>\n 快点！奖品数量有限！</p>",
        welcomebtn: '继续',
        empty: '对不起，这个礼品盒是空的！你还有几次尝试。祝你好运！',
        final: '',
    },

    main: {
        type: 'question',
        text: '你的性别是什么？',
        options: [
            {
                type: 'button',
                text: '男',
                audience_id: [61427, 60623],
                action: {
                    goto: 'step2',
                },
            },
            {
                type: 'button',
                text: '女人',
                audience_id: [61428, 60624],
                action: {
                    goto: 'step2',
                },
            },
        ],
    },
    step2: {
        type: 'question',
        text: '你有多大？',
        options: [
            {
                type: 'button',
                text: '少于 18 年',
                audience_id: [61421, 62387, 60625],
                action: {
                    redirect_ipp: 'teenage',
                    redirect_url: SmartURL,
                    popunder_url: SmartURL,
                },
            },
            {
                type: 'button',
                text: '18-29 年',
                audience_id: [62180, 62377, 68427, 78100, 62377, 62382, 68423, 78096],
                action: {
                    goto: 'step3',
                },
            },
            {
                type: 'button',
                text: '30-49 年',
                audience_id: [62181, 62380, 68425, 78097, 62383, 78101],
                action: {
                    goto: 'step3',
                },
            },
            {
                type: 'button',
                text: '50-80 年',
                audience_id: [62182, 62381, 68426, 78098, 62384, 78102],
                action: {
                    goto: 'step3',
                },
            },
        ],
    },
    step3: {
        type: 'question',
        text: '你在网上购物的频率是多久？',
        options: [
            {
                type: 'button',
                text: '每天',
                audience_id: 0,
                action: {
                    goto: 'step4',
                },
            },
            {
                type: 'button',
                text: '经常',
                audience_id: 0,
                action: { goto: 'step4' },
            },
            {
                type: 'button',
                text: '很少',

                audience_id: 0,
                action: {
                    goto: 'step4',
                },
            },
            {
                type: 'button',
                text: '永远不',
                audience_id: 0,
                action: {
                    goto: 'step4',
                },
            },
        ],
    },
    step4: {
        type: 'question',
        text: '你有没有使用礼品卡/礼券进行购物？',
        options: [
            {
                type: 'button',
                text: '是的',
                audience_id: 0,
                action: {
                    goto: 'step5',
                },
            },
            {
                type: 'button',
                text: '不',
                audience_id: 0,
                action: {
                    goto: 'step5',
                },
            },
        ],
    },
    step5: {
        type: 'question',
        text: '你有兴趣获得最大的折扣和礼物吗？',
        options: [
            {
                type: 'button',
                text: '是的',
                audience_id: 0,
                action: {
                    goto: 'step6',
                },
            },
            {
                type: 'button',
                text: '不',
                audience_id: 0,
                action: {
                    goto: 'step6',
                },
            },
        ],
    },
    step6: {
        type: 'question',
        text: '你宁愿什么？',
        options: [
            {
                type: 'button',
                text: '礼品卡',
                audience_id: 0,
                action: {
                    goto: 'final',
                },
            },
            {
                type: 'button',
                text: '一次性折扣',
                audience_id: 0,
                action: {
                    goto: 'final',
                },
            },

            {
                type: 'button',
                text: '折扣卡',
                audience_id: 0,
                action: {
                    goto: 'final',
                },
            },
        ],
    },
    final: {
        type: 'thank_you',
        boxes: 1,
        timeout: 40,
        timeout_url: SmartURL,
        timeout_conversion: 1,
        content:
            '<div class="final">\n <div class="final__step1">\n <p>谢谢你参加我们的测验。</p>\n <p>现在你有机会获得奖励了。</p>\n <p>你所要做的就是选择合适的礼品盒。</p>\n </div>\n <div class="final__step2">\n <p>哎呀！</p>\n <p>这些箱子是空的。</p>\n <p>你还有机会从我们的合作伙伴那里获得奖励。</p>\n <p>此优惠仅在接下来的 7 分钟内提供！</p>\n </div>\n <div class="instructions">\n <h2 class="instructions__header">寻找奖励！</h2>\n <div class="instructions__text">\n <span class=\'bounce\'>↓</span>\n <h3 class="instructions__text-1">你所要做的就是选择<b>正确的礼品盒</b>。</h3>\n <h3 class="instructions__text-2">点击继续按钮并完成最后步骤以获得奖励的机会！</h3>\n <span class=\'bounce\'>↓</span>\n </div>\n </div>\n </div>',
        progress_title: '估计结果...',
        progress_texts: ['等等...检查答案', '等等...计算你的分数'],
        progress_content: '',
        options: [
            {
                type: 'button',
                text: '继续',
                audience_id: 61426,
                action: {
                    conversion: 1,
                    redirect_url: SmartURL,
                },
            },
        ],
    },
};
