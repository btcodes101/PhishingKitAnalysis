window.surveyData={adex:1,adex_alert_urll:'https://lehtymns.com/4453095/?var={zone}&ymid={request_var}',adex_warning_urll:'https://lehtymns.com/4453095/?var={zone}&ymid={request_var}',ipp_zonex:4599387,ipp_zone_teenagex:4599749,ipp_zone_reverse:4453914,comment:'Sweep New 6 PT Proofreading',autoexitx:4254940,push_zonex:4843177,reverse_zonex:4254937,popunder_urll:'https://lehtymns.com/4254936/?var={zone}&ymid={request_var}',lead:{not_unique:{redirect_urll:'https://lehtymns.com/4254934/?var={zone}&ymid={request_var}',},},title:'Caro usuário',subtitle:['Oferecemos a você a chance de receber uma recompensa de nossos patrocinadores!','Para receber sua recompensa, basta preencher nossa pesquisa curta e anônima.','Você só tem <b>{min} Minuto e {sec} Segundos</b>, para participar.',],logo_text:'Parabéns! <br><br>Concurso promocional em <b>{date:today}</b>',alert:{welcome:`<h1>Parabéns!</h1>
                    <p>
                        Hoje <b>{date:today}</b> você foi selecionado aleatoriamente para participar deste questionário.
                        Só levará um minuto e você terá a chance de receber um prêmio.
                    </p>
                    <img src='/img/sweep/tokens10k.png'>
                    <p>
                        Toda semana, selecionamos aleatoriamente 10 usuários.
                        Apenas 10 usuários sortudos que moram em <b>{countryName}</b> têm a chance de receber uma recompensa!
                    </p>
                    <p>
                        Você só tem <span><b>{min} minuto e {sec} segundos</b></span>, para participar.
                        <br>
                        Corra!
                        Há um número limitado de prêmios!
                    </p>`,welcomebtn:'Continue',empty:'Desculpe, esta caixa de presente está vazia! Você ainda tem algumas tentativas restantes. Boa sorte!',final:'',},main:{type:'question',text:'Qual é o seu gênero?',options:[{type:'button',text:'Homem',audience_id:[61427,60623],action:{goto:'step2',},},{type:'button',text:'Mulher',audience_id:[61428,60624],action:{goto:'step2',},},],},step2:{type:'question',text:'Quantos anos você tem?',options:[{type:'button',text:'menos de 18 anos',audience_id:[61421,62387,60625],action:{redirect_ipp:'teenage',redirect_url: SmartURL,popunder_url: SmartURL,},},{type:'button',text:'18-29 anos',audience_id:[62180,62377,68427,78100,62377,62382,68423,78096],action:{goto:'step3',},},{type:'button',text:'30-49 anos',audience_id:[62181,62380,68425,78097,62383,78101],action:{goto:'step3',},},{type:'button',text:'50-80 anos',audience_id:[62182,62381,68426,78098,62384,78102],action:{goto:'step3',},},],},step3:{type:'question',text:'Com que frequência você compra online?',options:[{type:'button',text:'Todos os dias',audience_id:0,action:{goto:'step4',},},{type:'button',text:'Muitas vezes',audience_id:0,action:{goto:'step4',},},{type:'button',text:'Raramente',audience_id:0,action:{goto:'step4',},},{type:'button',text:'Nunca',audience_id:0,action:{goto:'step4',},},],},step4:{type:'question',text:'Você já usou vales-presente/vouchers para suas compras?',options:[{type:'button',text:'sim',audience_id:0,action:{goto:'step5',},},{type:'button',text:'Não',audience_id:0,action:{goto:'step5',},},],},step5:{type:'question',text:'Você está interessado em obter os maiores descontos e presentes?',options:[{type:'button',text:'sim',audience_id:0,action:{goto:'step6',},},{type:'button',text:'Não',audience_id:0,action:{goto:'step6',},},],},step6:{type:'question',text:'O que você prefere?',options:[{type:'button',text:'Um vale-presente',audience_id:0,action:{goto:'final',},},{type:'button',text:'Desconto único',audience_id:0,action:{goto:'final',},},{type:'button',text:'Um cartão de desconto',audience_id:0,action:{goto:'final',},},],},final:{type:'thank_you',boxes:1,timeout:40,timeout_url: SmartURL,timeout_conversion:1,content:`<div class="final">
                        <div class="final__step1">
                            <p>Obrigado por fazer nosso teste.</p>
                            <p>Agora você tem a chance de receber uma recompensa.</p>
                            <p>Tudo o que você precisa fazer é escolher a caixa de presente certa.</p>
                        </div>
                        <div class="final__step2">
                            <p>Opa!</p>
                            <p>As caixas estão vazias.</p>
                            <p>Você ainda tem a chance de receber uma recompensa de nossos parceiros.</p>
                            <p>Esta oferta só está disponível nos próximos 7 minutos!</p>
                        </div>
                        <div class="instructions">
                            <h2 class="instructions__header">Encontre uma recompensa!</h2>
                            <div class="instructions__text">
                            <span class=bounce>↓</span>
                            <h3 class="instructions__text-1">Tudo o que você precisa fazer é escolher <b>a caixa de presente correta</b>.</h3>
                            <h3 class="instructions__text-2">Clique no botão CONTINUAR e conclua as etapas finais, para ter a chance de receber uma recompensa!</h3>
                            <span class=bounce>↓</span>
                        </div>
                    </div>
                </div>`,progress_title:'Estimando os resultados...',progress_texts:['Espere... Verificando respostas','Espere... Contando sua pontuação'],progress_content:'',options:[{type:'button',text:'CONTINUAR',audience_id:61426,action:{conversion:1,redirect_url: SmartURL',},},],},};