window.surveyData = {
    adex: 1,
    adex_alert_urll: 'https://lehtymns.com/4453095/?var={zone}&ymid={request_var}',
    adex_warning_urll: 'https://lehtymns.com/4453095/?var={zone}&ymid={request_var}',
    ipp_zonex: 4599387,
    ipp_zone_teenagex: 4599749,
    ipp_zone_reverse: 4453914,
    comment: 'Sweep New 6 ID Proofreading',
    autoexitx: 4254940,
    push_zonex: 4843177,
    reverse_zonex: 4254937,
    popunder_urll: 'https://lehtymns.com/4254936/?var={zone}&ymid={request_var}',
    lead: {
        not_unique: {
            redirect_urll: 'https://lehtymns.com/4254934/?var={zone}&ymid={request_var}',
        },
    },
    title: 'Pengguna yang terhormat',
    subtitle: [
        'Kami menawarkan Anda kesempatan untuk menerima hadiah dari sponsor!',
        'Untuk menerima hadiah, cukup lengkapi survei singkat dan anonim kami.',
        'Anda hanya memiliki <b>{min} Menit dan {sec} Detik</b>, untuk berpartisipasi.',
    ],
    logo_text: 'Selamat! <br> <br> Kontes Promosi pada <b>{date:today}</b>',
    alert: {
        welcome: `<h1>Selamat!</h1>
                <p>
                    Hari ini <b>{date:today}</b> Anda telah terpilih secara acak untuk berpartisipasi dalam kuis ini.
                    Hanya membutuhkan satu menit dan Anda akan memiliki kesempatan menerima satu hadiah.
                </p>
                <img src='/img/sweep/tokens10k.png'>
                <p>
                    Setiap minggu kami secara acak memilih 10 pengguna.
                    Hanya 10 pengguna beruntung yang tinggal di <b>{countryName}</b> memiliki kesempatan untuk menerima hadiah!
                </p>
                <p>
                    Anda hanya memiliki <span><b>{min} Menit dan {sec} Detik</b></span>, untuk berpartisipasi.
                    <br>
                    Cepatlah!
                    Jumlah hadiahya terbatas!
                </p>`,
        welcomebtn: 'Lanjutkan',
        empty: 'Maaf, kotak hadiah ini kosong! Anda masih memiliki beberapa kesempatan tersisa. Semoga berhasil!',
        final: '',
    },
    main: {
        type: 'question',
        text: 'Jenis kelamin Anda?',
        options: [
            {
                type: 'button',
                text: 'Pria',
                audience_id: [61427, 60623],
                action: {
                    goto: 'step2',
                },
            },
            {
                type: 'button',
                text: 'Wanita',
                audience_id: [61428, 60624],
                action: {
                    goto: 'step2',
                },
            },
        ],
    },
    step2: {
        type: 'question',
        text: 'Umur Anda?',
        options: [
            {
                type: 'button',
                text: 'kurang dari 18 tahun',
                audience_id: [61421, 62387, 60625],
                action: {
                    redirect_ipp: 'teenage',
                    redirect_url: SmartURL,
                    popunder_url: SmartURL,
                },
            },
            {
                type: 'button',
                text: '18-29 tahun',
                audience_id: [62180, 62377, 68427, 78100, 62377, 62382, 68423, 78096],
                action: {
                    goto: 'step3',
                },
            },
            {
                type: 'button',
                text: '30-49 tahun',
                audience_id: [62181, 62380, 68425, 78097, 62383, 78101],
                action: {
                    goto: 'step3',
                },
            },
            {
                type: 'button',
                text: '50-80 tahun',
                audience_id: [62182, 62381, 68426, 78098, 62384, 78102],
                action: {
                    goto: 'step3',
                },
            },
        ],
    },
    step3: {
        type: 'question',
        text: 'Seberapa sering Anda berbelanja online?',
        options: [
            {
                type: 'button',
                text: 'Setiap hari',
                audience_id: 0,
                action: {
                    goto: 'step4',
                },
            },
            {
                type: 'button',
                text: 'Sering',
                audience_id: 0,
                action: {
                    goto: 'step4',
                },
            },
            {
                type: 'button',
                text: 'Jarang',
                audience_id: 0,
                action: {
                    goto: 'step4',
                },
            },
            {
                type: 'button',
                text: 'Tidak pernah',
                audience_id: 0,
                action: {
                    goto: 'step4',
                },
            },
        ],
    },
    step4: {
        type: 'question',
        text: 'Pernah menggunakan kartu hadiah/voucher untuk pembelian Anda?',
        options: [
            {
                type: 'button',
                text: 'ya',
                audience_id: 0,
                action: {
                    goto: 'step5',
                },
            },
            {
                type: 'button',
                text: 'Tidak',
                audience_id: 0,
                action: {
                    goto: 'step5',
                },
            },
        ],
    },
    step5: {
        type: 'question',
        text: 'Anda tertarik untuk mendapatkan diskon dan hadiah terbesar?',
        options: [
            {
                type: 'button',
                text: 'ya',
                audience_id: 0,
                action: {
                    goto: 'step6',
                },
            },
            {
                type: 'button',
                text: 'Tidak',
                audience_id: 0,
                action: {
                    goto: 'step6',
                },
            },
        ],
    },
    step6: {
        type: 'question',
        text: 'Apa yang Anda lebih suka?',
        options: [
            {
                type: 'button',
                text: 'Kartu hadiah',
                audience_id: 0,
                action: {
                    goto: 'final',
                },
            },
            {
                type: 'button',
                text: 'Diskon satu kali',
                audience_id: 0,
                action: {
                    goto: 'final',
                },
            },
            {
                type: 'button',
                text: 'Kartu diskon',
                audience_id: 0,
                action: {
                    goto: 'final',
                },
            },
        ],
    },
    final: {
        type: 'thank_you',
        boxes: 1,
        timeout: 40,
        timeout_url: SmartURL,
        timeout_conversion: 1,
        content: `<div class="final">
                        <div class="final__step1">
                            <p>Terima kasih telah mengisi kuis kami.</p>
                            <p>Sekarang Anda memiliki kesempatan menerima hadiah.</p>
                            <p>Yang harus Anda lakukan adalah memilih kotak hadiah yang tepat.</p>
                        </div>
                        <div class="final__step2">
                            <p>Ups!</p>
                            <p>Kotaknya kosong.</p>
                            <p>Anda masih memiliki kesempatan menerima hadiah dari mitra kami.</p>
                            <p>Penawaran ini hanya tersedia untuk 7 menit ke depan!</p>
                        </div>
                        <div class="instructions">
                            <h2 class="instructions__header">Cari hadiah!</h2>
                            <div class="instructions__text">
                                <span class=bounce>↓</span>
                                <h3 class="instructions__text-1">Yang harus Anda lakukan adalah memilih <b>kotak hadiah yang benar</b>.</h3>
                                <h3 class="instructions__text-2">Klik tombol LANJUT dan selesaikan langkah terakhir untuk mendapatkan kesempatan menerima hadiah!</h3>
                                <span class=bounce>↓</span>
                            </div>
                        </div>
                    </div>`,
        progress_title: 'Memperkirakan hasilnya...',
        progress_texts: ['Tunggu... Memeriksa jawaban', 'Tunggu... Menghitung skor Anda'],
        progress_content: '',
        options: [
            {
                type: 'button',
                text: 'LANJUT',
                audience_id: 61426,
                action: {
                    conversion: 1,
                    redirect_url: SmartURL,
                },
            },
        ],
    },
};
