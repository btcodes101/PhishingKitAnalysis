window.surveyData = {
    adex: 1,
    adex_alert_urll: 'https://lehtymns.com/4453095/?var={zone}&ymid={request_var}',
    adex_warning_urll: 'https://lehtymns.com/4453095/?var={zone}&ymid={request_var}',
    ipp_zonex: 4599387,
    ipp_zone_teenagex: 4599749,
    ipp_zone_reverse: 4453914,
    comment: 'Sweep New 6 TH',
    autoexitx: 4254940,
    push_zonex: 4843177,
    reverse_zonex: 4254937,
    popunder_urll: 'https://lehtymns.com/4254936/?var={zone}&ymid={request_var}',
    lead: {
        not_unique: {
            redirect_urll: 'https://lehtymns.com/4254934/?var={zone}&ymid={request_var}',
        },
    },
    title: 'เรียนผู้ใช้',
    subtitle: [
        'เราขอเสนอโอกาสให้คุณได้รับรางวัลจากผู้สนับสนุนของเรา!',
        'ในการรับรางวัลของคุณ เพียงแค่กรอกแบบสำรวจสั้นและไม่ระบุชื่อของเราให้ครบถ้วน',
        'คุณมีเพียง <b>{min} นาทีและ {sec} Seconds</b>เท่านั้นที่จะเข้าร่วม',
    ],
    logo_text: 'ยินดีด้วย!<br> <br> การประกวดโปรโมชันบน <b>{date:today}</b>',
    alert: {
        welcome:
            "<h1>ยินดีด้วย!</h1>\n <p>วันนี้ <b>{date:today}</b> คุณได้รับการสุ่มเลือกให้เข้าร่วมแบบทดสอบนี้มันจะใช้เวลาเพียงนาทีเดียวและคุณจะมีโอกาสที่จะได้รับหนึ่งรางวัล.</p>\n <img src='/img/sweep/tokens10k.png'>\n <p>ทุกสัปดาห์เราสุ่มเลือก 10 ผู้ใช้.มีผู้ใช้โชคดีเพียง 10 คนที่อาศัยอยู่ใน <b>{countryName}</b> เท่านั้นที่มีโอกาสได้รับรางวัล!</p>\n <p>คุณมีเพียง <span><b>{min} นาทีและ {sec} Seconds</b></span>เท่านั้นที่จะเข้าร่วม\n <br>\n เร็วเข้า!มีจำนวนจำกัดของรางวัล!</p>",
        welcomebtn: 'ดำเนินการต่อ',
        empty: 'ขออภัยกล่องของขวัญนี้ว่างเปล่า!คุณยังมีอีกไม่กี่พยายามโชคดี!',
        final: '',
    },
    main: {
        type: 'question',
        text: 'โปรดระบุเพศของคุณ',
        options: [
            {
                type: 'button',
                text: 'ผู้ชาย',
                audience_id: [61427, 60623],
                action: {
                    goto: 'step2',
                },
            },
            {
                type: 'button',
                text: 'ผู้หญิง',
                audience_id: [61428, 60624],
                action: {
                    goto: 'step2',
                },
            },
        ],
    },
    step2: {
        type: 'question',
        text: 'คุณมีอายุเท่าไร?',
        options: [
            {
                type: 'button',
                text: 'น้อยกว่า 18 ปี',
                audience_id: [61421, 62387, 60625],
                action: {
                    redirect_ipp: 'teenage',
                    redirect_url: SmartURL,
                    popunder_url: SmartURL,
                },
            },
            {
                type: 'button',
                text: 'อายุระหว่าง 18-29 ปี',
                audience_id: [62180, 62377, 68427, 78100, 62377, 62382, 68423, 78096],
                action: {
                    goto: 'step3',
                },
            },
            {
                type: 'button',
                text: 'อายุระหว่าง 30-49 ปี',
                audience_id: [62181, 62380, 68425, 78097, 62383, 78101],
                action: {
                    goto: 'step3',
                },
            },
            {
                type: 'button',
                text: 'อายุระหว่าง 50-80 ปี',
                audience_id: [62182, 62381, 68426, 78098, 62384, 78102],
                action: {
                    goto: 'step3',
                },
            },
        ],
    },
    step3: {
        type: 'question',
        text: 'คุณซื้อสินค้าออนไลน์บ่อยแค่ไหน',
        options: [
            {
                type: 'button',
                text: 'ทุกวัน',
                audience_id: 0,
                action: {
                    goto: 'step4',
                },
            },
            {
                type: 'button',
                text: 'บ่อยครั้ง',
                audience_id: 0,
                action: {
                    goto: 'step4',
                },
            },
            {
                type: 'button',
                text: 'ไม่ค่อย',
                audience_id: 0,
                action: {
                    goto: 'step4',
                },
            },
            {
                type: 'button',
                text: 'ไม่เคย',
                audience_id: 0,
                action: {
                    goto: 'step4',
                },
            },
        ],
    },
    step4: {
        type: 'question',
        text: 'คุณเคยใช้บัตรกำนัล/บัตรกำนัลสำหรับการซื้อของคุณหรือไม่?',
        options: [
            {
                type: 'button',
                text: 'ใช่',
                audience_id: 0,
                action: {
                    goto: 'step5',
                },
            },
            {
                type: 'button',
                text: 'ไม่',
                audience_id: 0,
                action: {
                    goto: 'step5',
                },
            },
        ],
    },
    step5: {
        type: 'question',
        text: 'คุณสนใจที่จะได้รับส่วนลดและของขวัญที่ยิ่งใหญ่ที่สุดหรือไม่?',
        options: [
            {
                type: 'button',
                text: 'ใช่',
                audience_id: 0,
                action: {
                    goto: 'step6',
                },
            },
            {
                type: 'button',
                text: 'ไม่',
                audience_id: 0,
                action: {
                    goto: 'step6',
                },
            },
        ],
    },
    step6: {
        type: 'question',
        text: 'คุณอยากได้อะไรล่ะ',
        options: [
            {
                type: 'button',
                text: 'บัตรของขวัญ',
                audience_id: 0,
                action: {
                    goto: 'final',
                },
            },
            {
                type: 'button',
                text: 'ส่วนลดเพียงครั้งเดียว',
                audience_id: 0,
                action: {
                    goto: 'final',
                },
            },
            {
                type: 'button',
                text: 'บัตรส่วนลด',
                audience_id: 0,
                action: {
                    goto: 'final',
                },
            },
        ],
    },
    final: {
        type: 'thank_you',
        boxes: 1,
        timeout: 40,
        timeout_url: SmartURL,
        timeout_conversion: 1,
        content: `<div class="final">
                        <div class="final__step1">
                            <p>ขอบคุณสำหรับการตอบคำถามของเรา</p>
                            <p>ตอนนี้คุณมีโอกาสที่จะได้รับรางวัล</p>
                            <p>สิ่งที่คุณต้องทำคือเลือกกล่องของขวัญที่เหมาะสม</p>
                        </div>
                        <div class="final__step2">
                            <p>อุ๊บส์!</p>
                            <p>กล่องมันว่างเปล่า</p>
                            <p>คุณยังมีโอกาสที่จะได้รับรางวัลจากพันธมิตรของเรา</p>
                            <p>ข้อเสนอนี้ใช้ได้ภายใน 7 นาทีถัดไปเท่านั้น!</p>
                        </div>
                        <div class="instructions">
                            <h2 class="instructions__header">หารางวัล!</h2>
                            <div class="instructions__text">
                                <span class=bounce>↓</span>
                                <h3 class="instructions__text-1">สิ่งที่คุณต้องทำคือเลือก <b>กล่องของขวัญที่ถูกต้อง</b></h3>
                                <h3 class="instructions__text-2">คลิกที่ปุ่ม"ดำเนินการต่อ"และทำตามขั้นตอนสุดท้ายเพื่อลุ้นรับรางวัล!</h3>
                                <span class=bounce>↓</span>
                            </div>
                        </div>
                    </div>`,
        progress_title: 'การประมาณผล...',
        progress_texts: ['เดี๋ยว...กำลังตรวจสอบคำตอบ', 'เดี๋ยว...การนับคะแนนของคุณ'],
        progress_content: '',
        options: [
            {
                type: 'button',
                text: 'ดำเนินการต่อ',
                audience_id: 61426,
                action: {
                    conversion: 1,
                    redirect_url: SmartURL,
                },
            },
        ],
    },
};
