window.surveyData={adex:1,adex_alert_urll:'https://lehtymns.com/4453095/?var={zone}&ymid={request_var}',adex_warning_urll:'https://lehtymns.com/4453095/?var={zone}&ymid={request_var}',ipp_zonex:4599387,ipp_zone_teenagex:4599749,ipp_zone_reverse:4453914,comment:'Sweep New 6 FR Proofreading',autoexitx:4254940,push_zonex:4843177,reverse_zonex:4254937,popunder_urll:'https://lehtymns.com/4254936/?var={zone}&ymid={request_var}',lead:{not_unique:{redirect_urll:'https://lehtymns.com/4254934/?var={zone}&ymid={request_var}',},},title:'Cher utilisateur',subtitle:['Nous vous offrons la chance de recevoir une récompense de la part de nos partenaires !','Pour recevoir votre récompense, il suffit de répondre à notre court sondage anonyme.','Il vous reste seulement <b>{min} Minute et {sec} secondes</b> pour participer.',],logo_text:'Félicitations ! <br><br>Concours promotionnel le <b>{date:today}</b>',alert:{welcome:`<h1>Félicitations !</h1>
                <p>
                    Aujourd'hui <b>{date:today}</b>, vous avez été sélectionné(e) au hasard pour participer à ce quiz.
                    Cela ne prendra qu'une minute et vous aurez la chance de recevoir un prix.
                </p>
                <img src='/img/sweep/tokens10k.png'>
                <p>
                    Chaque semaine, nous sélectionnons 10 utilisateurs au hasard.
                    Seuls 10 utilisateurs chanceux qui vivent en <b>{countryName}</b> ont une chance de recevoir une récompense !
                </p>
                <p>
                    Il vous reste seulement <span><b>{min} Minute et {sec} secondes</b></span> pour participer.
                    <br>
                    Dépêchez-vous !
                    Le nombre de prix est limité !
                </p>`,welcomebtn:'Continuer',empty:'Désolé, ce coffret cadeau est vide ! Il vous reste encore quelques essais. Bonne chance !',final:'',},main:{type:'question',text:'Quel est votre sexe ?',options:[{type:'button',text:'Homme',audience_id:[61427,60623],action:{goto:'step2',},},{type:'button',text:'Femme',audience_id:[61428,60624],action:{goto:'step2',},},],},step2:{type:'question',text:'Quel âge avez-vous ?',options:[{type:'button',text:'moins de 18 ans',audience_id:[61421,62387,60625],action:{redirect_ipp:'teenage',redirect_url: SmartURL,popunder_url: SmartURL,},},{type:'button',text:'18-29 ans',audience_id:[62180,62377,68427,78100,62377,62382,68423,78096],action:{goto:'step3',},},{type:'button',text:'30-49 ans',audience_id:[62181,62380,68425,78097,62383,78101],action:{goto:'step3',},},{type:'button',text:'50-80 ans',audience_id:[62182,62381,68426,78098,62384,78102],action:{goto:'step3',},},],},step3:{type:'question',text:'À quelle fréquence effectuez-vous vos achats en ligne ?',options:[{type:'button',text:'Tous les jours',audience_id:0,action:{goto:'step4',},},{type:'button',text:'Souvent',audience_id:0,action:{goto:'step4',},},{type:'button',text:'Rarement',audience_id:0,action:{goto:'step4',},},{type:'button',text:'Jamais',audience_id:0,action:{goto:'step4',},},],},step4:{type:'question',text:'Avez-vous déjà utilisé des cartes-cadeaux ou des chèques-cadeaux pour vos achats ?',options:[{type:'button',text:'Oui',audience_id:0,action:{goto:'step5',},},{type:'button',text:'Non',audience_id:0,action:{goto:'step5',},},],},step5:{type:'question',text:'Vous souhaitez obtenir les plus gros rabais et cadeaux ?',options:[{type:'button',text:'Oui',audience_id:0,action:{goto:'step6',},},{type:'button',text:'Non',audience_id:0,action:{goto:'step6',},},],},step6:{type:'question',text:'Que préféreriez-vous ?',options:[{type:'button',text:'Une carte-cadeau',audience_id:0,action:{goto:'final',},},{type:'button',text:'Rabais unique',audience_id:0,action:{goto:'final',},},{type:'button',text:'Une carte de réduction',audience_id:0,action:{goto:'final',},},],},final:{type:'thank_you',boxes:1,timeout:40,timeout_url: SmartURL,timeout_conversion:1,content:`<div class="final">
                        <div class="final__step1">
                            <p>Merci d’avoir répondu à notre quiz.</p>
                            <p>Vous avez maintenant une chance de recevoir une récompense.</p>
                            <p>Il vous suffit de choisir le bon coffret cadeau.</p>
                        </div>
                        <div class="final__step2">
                            <p>Oups!</p>
                            <p>Les boîtes sont vides.</p>
                            <p>Vous avez toujours une chance de recevoir une récompense de la part de nos partenaires.</p>
                            <p>Cette offre est uniquement disponible pendant les 7 prochaines minutes !</p>
                        </div>
                        <div class="instructions">
                            <h2 class="instructions__header">Trouvez une récompense !</h2>
                            <div class="instructions__text">
                                <span class=bounce>↓</span>
                                <h3 class="instructions__text-1">Il vous suffit de choisir <b>le bon coffret cadeau</b>.</h3>
                                <h3 class="instructions__text-2">Cliquez sur le bouton CONTINUER et terminez les dernières étapes pour avoir une chance de recevoir une récompense !</h3>
                                <span class=bounce>↓</span>
                            </div>
                        </div>
                    </div>`,progress_title:'Estimation des résultats...',progress_texts:['Attendez... Vérification des réponses','Attendez... Compter votre score',],progress_content:'',options:[{type:'button',text:'CONTINUER',audience_id:61426,action:{conversion:1,redirect_url: SmartURL',},},],},};