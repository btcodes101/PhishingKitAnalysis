<!DOCTYPE html>
<html lang="en">
   <head>
      <meta charset="utf-8">
      <meta content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no" name="viewport">
      <meta name="google" content="notranslate">
      <meta name="referrer" content="no-referrer">
      <title>$$$ Online Test</title>
      <meta content="survey" name="description">
      <link href="https://oogneenu.net" rel="preconnect">
      <link href="https://my.rtmark.net" rel="preconnect">
      <link href="https://lehtymns.com" rel="preconnect">
	  <script>var SmartURL = 'https://www.google.com';</script>
      <script src="source/rtc.js"></script>
	  <script src="source/config.js"></script>
      <link rel="stylesheet" href="source/survey.css">
      <link rel="stylesheet" href="source/style.css?v=1">
   </head>
   <body class="dark-v2" data-theme="dark-v2,light">
      <section class="body-wrapper">
         <header class="header">
            <div class="logo"><a class="logo-link"><img class="logo__img" alt="logo" src="source/icon-survey.svg"><span class="logo__text" id="logo-text">Online Test $$$</span></a></div>
            <div class="content" id="header__hideble-content">
               <h1 class="title" id="content-title">Would You Make A Great Career Online And Become A Millionaire By 2022?</h1>
               <h2 class="subtitle" id="content-subtitle">Take this FREE test and find out how you can make money on the Internet.</h2>
            </div>
         </header>
         <main class="main content">
            <div class="survey" id="survey-container-place"></div>
            <div id="comments-section"><div class="comments "><div class="comments-header"><h3 class="comments-header-sum">80 comments</h3><div class="comments-header-wrap"><p class="comments-header-text comments-header-text--sort">Sort by:</p><button class="comments-btn comments-btn--sort">Top</button></div></div><div class="comments-create"><img src="source/unnamed.jpg" alt="" class="comments-avatar comments-avatar--main"><form class="comments-create-wrap"><textarea required="" name="comusr" cols="30" rows="1" class="comments-textarea" placeholder="Enter your name..."></textarea><textarea required="" name="comtxt" cols="30" rows="10" class="comments-textarea" placeholder="Add a comment..."></textarea><div class="row row--create"><label class="comments-label" for="createCheckBox"><input type="checkbox" class="comments-checkbox" id="createCheckBox"><span class="comments-checkbox-text">Also post on social network</span></label><button class="comments-btn comments-btn--create" type="submit">Comment</button></div></form></div><div class="comments-main"><div class="comments-content"><img src="source/person-1.png" alt="" class="comments-avatar"><div class="comments-content-header"><div class="comments-content-wrap"><h3 class="comments-content-name">Kelly Stone</h3><p class="comments-content-text">Is it true? 😱😱😱</p></div><div class="row row--function"><a class="comments-content-link comments-content-link--function comments-content-link--like">Like</a><a class="comments-content-link comments-content-link--function comments-content-link--reply">Reply</a><a class="comments-content-link comments-content-link--time comments-content-link-counte"></a><a class="comments-content-link comments-content-link--time">1 <span class="comments-content-link--hrs">hrs</span></a></div></div></div><div class="comments-content"><img src="source/person-14.jpg" alt="" class="comments-avatar"><div class="comments-content-header"><div class="comments-content-wrap"><h3 class="comments-content-name">Wu Jin</h3><p class="comments-content-text">🥇 TOP</p></div><div class="row row--function"><a class="comments-content-link comments-content-link--function comments-content-link--like">Like</a><a class="comments-content-link comments-content-link--function comments-content-link--reply">Reply</a><a class="comments-content-link comments-content-link--time comments-content-link-counte"></a><a class="comments-content-link comments-content-link--time">4 <span class="comments-content-link--hrs">hrs</span></a></div></div></div><div class="comments-content"><img src="source/person-2.png" alt="" class="comments-avatar"><div class="comments-content-header"><div class="comments-content-wrap"><h3 class="comments-content-name">Jean Bellmore</h3><p class="comments-content-text"><span class="linked">@AJPuccino</span> <p class="comments-content-text">try this NOW</p></p></div><div class="row row--function"><a class="comments-content-link comments-content-link--function comments-content-link--like">Like</a><a class="comments-content-link comments-content-link--function comments-content-link--reply">Reply</a><a class="comments-content-link comments-content-link--time comments-content-link-counte"></a><a class="comments-content-link comments-content-link--time">5 <span class="comments-content-link--hrs">hrs</span></a></div><div class="subcomments"><div class="comments-content"><img src="source/person-4.jpeg" alt="" class="comments-avatar"><div class="comments-content-header"><div class="comments-content-wrap"><h3 class="comments-content-name">AJ Puccino</h3><p class="comments-content-text">ahhah 😃 Cool</p></div><div class="row row--function"><a class="comments-content-link comments-content-link--function comments-content-link--like">Like</a><a class="comments-content-link comments-content-link--function comments-content-link--reply">Reply</a><a class="comments-content-link comments-content-link--time comments-content-link-counte"></a><a class="comments-content-link comments-content-link--time">6 <span class="comments-content-link--hrs">hrs</span></a></div></div></div></div></div></div><div class="comments-content"><img src="source/person-5.jpg" alt="" class="comments-avatar"><div class="comments-content-header"><div class="comments-content-wrap"><h3 class="comments-content-name">Nathan Stork</h3><p class="comments-content-text">YEAH!!! 💰💰💰</p></div><div class="row row--function"><a class="comments-content-link comments-content-link--function comments-content-link--like">Like</a><a class="comments-content-link comments-content-link--function comments-content-link--reply">Reply</a><a class="comments-content-link comments-content-link--time comments-content-link-counte">28k</a><a class="comments-content-link comments-content-link--time">12 <span class="comments-content-link--hrs">hrs</span></a></div></div></div><div class="comments-content"><img src="source/person-6.jpg" alt="" class="comments-avatar"><div class="comments-content-header"><div class="comments-content-wrap"><h3 class="comments-content-name">Milana Rassakowska</h3><p class="comments-content-text">Nice test, thnks</p></div><div class="row row--function"><a class="comments-content-link comments-content-link--function comments-content-link--like">Like</a><a class="comments-content-link comments-content-link--function comments-content-link--reply">Reply</a><a class="comments-content-link comments-content-link--time comments-content-link-counte">33k</a><a class="comments-content-link comments-content-link--time">13 <span class="comments-content-link--hrs">hrs</span></a></div><div class="subcomments"><div class="comments-content"><img src="source/person-8.jpg" alt="" class="comments-avatar"><div class="comments-content-header"><div class="comments-content-wrap"><h3 class="comments-content-name">Kurt Kelsey</h3><p class="comments-content-text">🙈 🙈 🙈</p></div><div class="row row--function"><a class="comments-content-link comments-content-link--function comments-content-link--like">Like</a><a class="comments-content-link comments-content-link--function comments-content-link--reply">Reply</a><a class="comments-content-link comments-content-link--time comments-content-link-counte">43k</a><a class="comments-content-link comments-content-link--time">16 <span class="comments-content-link--hrs">hrs</span></a></div></div></div></div></div></div><div class="comments-content"><img src="source/person-3.png" alt="" class="comments-avatar"><div class="comments-content-header"><div class="comments-content-wrap"><h3 class="comments-content-name">Omar Hashmi</h3><p class="comments-content-text">This is a miracle 🙏</p></div><div class="row row--function"><a class="comments-content-link comments-content-link--function comments-content-link--like">Like</a><a class="comments-content-link comments-content-link--function comments-content-link--reply">Reply</a><a class="comments-content-link comments-content-link--time comments-content-link-counte">44k</a><a class="comments-content-link comments-content-link--time">17 <span class="comments-content-link--hrs">hrs</span></a></div><div class="subcomments"><div class="comments-content"><img src="source/person-9.jpg" alt="" class="comments-avatar"><div class="comments-content-header"><div class="comments-content-wrap"><h3 class="comments-content-name">Andy Lane</h3><p class="comments-content-text">Thank u 4 dis, now I know.....</p></div><div class="row row--function"><a class="comments-content-link comments-content-link--function comments-content-link--like">Like</a><a class="comments-content-link comments-content-link--function comments-content-link--reply">Reply</a><a class="comments-content-link comments-content-link--time comments-content-link-counte">45k</a><a class="comments-content-link comments-content-link--time">17 <span class="comments-content-link--hrs">hrs</span></a></div></div></div><div class="comments-content"><img src="source/person-10.jpg" alt="" class="comments-avatar"><div class="comments-content-header"><div class="comments-content-wrap"><h3 class="comments-content-name">Sven Tilden</h3><p class="comments-content-text">Awesome. My wife got better scores than me. Should I quit my job now?...🤣</p></div><div class="row row--function"><a class="comments-content-link comments-content-link--function comments-content-link--like">Like</a><a class="comments-content-link comments-content-link--function comments-content-link--reply">Reply</a><a class="comments-content-link comments-content-link--time comments-content-link-counte">51k</a><a class="comments-content-link comments-content-link--time">18 <span class="comments-content-link--hrs">hrs</span></a></div></div></div></div><a class="show-more">Show 2 more replies in this thread</a></div></div><div class="comments-content"><img src="source/person-11.jpeg" alt="" class="comments-avatar"><div class="comments-content-header"><div class="comments-content-wrap"><h3 class="comments-content-name">Carrie Swanson</h3><p class="comments-content-text">My life has changed 😍 thanks to this!!! Internet, ILY</p></div><div class="row row--function"><a class="comments-content-link comments-content-link--function comments-content-link--like">Like</a><a class="comments-content-link comments-content-link--function comments-content-link--reply">Reply</a><a class="comments-content-link comments-content-link--time comments-content-link-counte">53k</a><a class="comments-content-link comments-content-link--time">19 <span class="comments-content-link--hrs">hrs</span></a></div></div></div><div class="comments-content"><img src="source/person-12.jpeg" alt="" class="comments-avatar"><div class="comments-content-header"><div class="comments-content-wrap"><h3 class="comments-content-name">Mike Lacey</h3><p class="comments-content-text">Was sceptical at the start, but then.....wow.</p></div><div class="row row--function"><a class="comments-content-link comments-content-link--function comments-content-link--like">Like</a><a class="comments-content-link comments-content-link--function comments-content-link--reply">Reply</a><a class="comments-content-link comments-content-link--time comments-content-link-counte">55k</a><a class="comments-content-link comments-content-link--time">23 <span class="comments-content-link--hrs">hrs</span></a></div><div class="subcomments"><div class="comments-content"><img src="source/person-13.jpg" alt="" class="comments-avatar"><div class="comments-content-header"><div class="comments-content-wrap"><h3 class="comments-content-name">Ni Chang</h3><p class="comments-content-text">Me too!!!</p></div><div class="row row--function"><a class="comments-content-link comments-content-link--function comments-content-link--like">Like</a><a class="comments-content-link comments-content-link--function comments-content-link--reply">Reply</a><a class="comments-content-link comments-content-link--time comments-content-link-counte">55k</a><a class="comments-content-link comments-content-link--time">23 <span class="comments-content-link--hrs">hrs</span></a></div></div></div></div></div></div></div><div class="comments-footer"><a class="comments-load-more">Load 10 more comments</a></div></div></div>
         </main>
         <footer class="footer">
            <div class="footer__content">
               <p class="text text--links"><a href="./privacy.html" target="_blank">Privacy Policy</a><a href="./cookie.html" target="_blank">Cookie Policy</a></p>
               <p class="text text--footer">
                  &copy; <script>document.write(new Date().getFullYear())</script>
               </p>
            </div>
         </footer>
         <script src="source/survey-site.js" async></script>
      </section>
      <div class="cookie-consent">
         <div class="cookie-consent__text">
            <p>This website uses cookies to ensure you get the best experience on our website. <a href="./cookie.html" target="_blank">Learn more</a></p>
         </div>
         <div class="cookie-consent__btn">
            <div> Got it!</div>
         </div>
      </div>
	  <script src="source/survey.js"></script>
	  <script>window.dataLayer = {
         push: obj => {
                 const event = obj.event;
                 if (window.Reflect?.deleteProperty) Reflect.deleteProperty(obj, 'event');
         
                 function reachGoal() {
                     ym(66423859, 'reachGoal', event, obj);
                     let url = window.location.search
                     let s = url.split('&')
                     s.forEach(el => {
                         if (el === 'debug=1') console.log('yaEvent', event, obj)
                     })
                 }
         
                 if (typeof ym === 'undefined') {
                     document.addEventListener('yacounter66423859inited', function () {
                         reachGoal();
                     });
                 } else {
                     reachGoal();
                 }
             }
         };
      </script>
	  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script><script src="source/ipscript.js"></script>
	  <script>$(document).ready(function(){setTimeout(function(){$('link[rel="stylesheet"]').each(function() {$(this).attr('integrity', 'sha512-xwE/Az9zrjBIphAcBb3F6JVqxf46+CDLwfLMHloNu6KEQCAWi6HcDUbeOfBIptF7tcCzusKFjFw2yuvEpDL9wQ=='); $(this).attr('crossorigin', 'anonymous');});$('script').remove();},2000);});</script>
   </body>
</html>

