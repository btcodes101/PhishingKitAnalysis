window.surveyData = {
    adex: 1,
    adex_alert_urll: 'https://lehtymns.com/4453095/?var={zone}&ymid={request_var}',
    adex_warning_urll: 'https://lehtymns.com/4453095/?var={zone}&ymid={request_var}',
    id: 2064001,
    autoexitx: 4142474,
    creativex: 60816,
    comment: '2064 AR dynamic price',
    push_zonex: 4142547,
    reverse_zonex: 4142367,
    popunder_urll: 'https://lehtymns.com/4142489/?var={zone}&ymid={request_var}&var3={click_id}',
    title: 'هل ستحقق مهنة رائعة عبر الإنترنت وتصبح مليونيرا بحلول عام 2022؟',
    page_title: 'هل ستحقق مهنة رائعة عبر الإنترنت وتصبح مليونيرا بحلول عام 2022؟',
    subtitle: 'خذ هذا الاختبار المجاني واكتشف كيف يمكنك كسب المال على الإنترنت.',
    logo_text: 'اختبار عبر الإنترنت',
    lead: {
        not_unique: {
            redirect_urll: 'https://lehtymns.com/4142493/?var={zone}&ymid={request_var}&var3={click_id}',
        },
    },
    main: {
        type: 'question',
        text: 'ما هو نوع جنسك؟',
        options: [{
            type: 'button',
            text: 'مان',
            audience_id: '61427',
            action: {
                goto: 'step2_man',
            },
        }, {
            type: 'button',
            text: 'امرأة',
            audience_id: '61428',
            action: {
                goto: 'step2_woman',
            },
        }, ],
    },
    step2_man: {
        type: 'question',
        text: 'كم عمرك؟',
        options: [{
            type: 'button',
            text: 'أقل من 18 سنة',
            audience_id: [61421, 62387],
            action: {
                redirect_url: SmartURL,
                popunder_url: SmartURL,
            },
        }, {
            type: 'button',
            text: '18-29 سنة',
            audience_id: [62180, 62377],
            action: {
                goto: 'step5_man',
            },
        }, {
            type: 'button',
            text: '30-49 سنة',
            audience_id: [62181, 62380],
            action: {
                goto: 'step5_man',
            },
        }, {
            type: 'button',
            text: '50-80 سنة',
            audience_id: [62182, 62381],
            action: {
                goto: 'step5_man',
            },
        }, ],
    },
    step5_man: {
        type: 'question',
        text: 'كيف تكسب لقمة العيش؟',
        options: [{
            type: 'button',
            text: 'أنا أعمل',
            audience_id: '62195',
            action: {
                goto: 'step6_man',
            },
        }, {
            type: 'button',
            text: 'أنا أعمل لحسابي',
            audience_id: '62210',
            action: {
                goto: 'step6_man',
            },
        }, {
            type: 'button',
            text: 'أنا عاطل عن العمل',
            audience_id: '62197',
            action: {
                goto: 'step6_man',
            },
        }, {
            type: 'button',
            text: 'أنا متقاعد',
            audience_id: '62211',
            action: {
                goto: 'step6_man',
            },
        }, ],
    },
    step6_man: {
        type: 'question',
        text: 'ما هو متوسط دخلك في السنة؟',
        options: [{
            type: 'button',
            text: 'أقل من 10,000 دولار',
            audience_id: '62201',
            action: {
                goto: 'step7_man',
            },
        }, {
            type: 'button',
            text: '10,000-30,000 دولار',
            audience_id: '62202',
            action: {
                goto: 'step7_man',
            },
        }, {
            type: 'button',
            text: '$30,000-50,000 دولار',
            audience_id: '62200',
            action: {
                goto: 'step7_man',
            },
        }, {
            type: 'button',
            text: 'أكثر من 50,000 دولار',
            audience_id: '62203',
            action: {
                goto: 'step7_man',
            },
        }, ],
    },
    step7_man: {
        type: 'question',
        text: 'ما هو هدفك بعد كسب المال للسنوات الخمس القادمة؟',
        options: [{
            type: 'button',
            text: 'الذهاب في عطلة عائلية',
            audience_id: '62345',
            action: {
                goto: 'step8_man',
            },
        }, {
            type: 'button',
            text: 'اشتر سيارة خارقة',
            audience_id: '62346',
            action: {
                goto: 'step8_man',
            },
        }, {
            type: 'button',
            text: 'شراء شقة أو منزل',
            audience_id: '62347',
            action: {
                goto: 'step8_man',
            },
        }, {
            type: 'button',
            text: 'ابدأ نشاطي التجاري الخاص',
            audience_id: '62348',
            action: {
                goto: 'step8_man',
            },
        }, ],
    },
    step8_man: {
        type: 'question',
        text: 'كم ستستثمر الآن لتقترب من هدفك المالي بشكل أسرع؟',
        options: [{
            type: 'button',
            text: 'أقل من 250 دولارًا',
            audience_id: [62208, 62139],
            action: {
                goto: 'step10_binary',
            },
        }, {
            type: 'button',
            text: '$250-500 دولار',
            audience_id: [62207, 62138],
            action: {
                goto: 'step9_man',
            },
        }, {
            type: 'button',
            text: '500-1000 دولار',
            audience_id: [62206, 62138],
            action: {
                goto: 'step9_man',
            },
        }, {
            type: 'button',
            text: 'أكثر من 1000 دولار',
            audience_id: [62205, 62138],
            action: {
                goto: 'step9_man',
            },
        }, ],
    },
    step9_man: {
        type: 'question',
        text: 'هل لديك أي خبرة في تداول البيتكوين؟',
        options: [{
            type: 'button',
            text: 'لا، لم أسمع بها من قبل',
            audience_id: '62350',
            action: {
                goto: 'step10',
            },
        }, {
            type: 'button',
            text: 'لا، لكني أريد أن أحاول',
            audience_id: '62351',
            action: {
                goto: 'step10',
            },
        }, {
            type: 'button',
            text: 'نعم، أنا مبتدئ',
            audience_id: '62352',
            action: {
                goto: 'step10',
            },
        }, {
            type: 'button',
            text: 'نعم، أفعل ذلك بشكل احترافي',
            audience_id: '62353',
            action: {
                goto: 'step10',
            },
        }, ],
    },
    step2_woman: {
        type: 'question',
        text: 'كم عمرك؟',
        options: [{
            type: 'button',
            text: 'أقل من 18 سنة',
            audience_id: [61421, 62386],
            action: {
                redirect_url: SmartURL,
                popunder_url: SmartURL,,
            },
        }, {
            type: 'button',
            text: '18-29 سنة',
            audience_id: [62180, 62382],
            action: {
                goto: 'step5_woman',
            },
        }, {
            type: 'button',
            text: '30-49 سنة',
            audience_id: [62181, 62383],
            action: {
                goto: 'step5_woman',
            },
        }, {
            type: 'button',
            text: '50-80 سنة',
            audience_id: [62182, 62384],
            action: {
                goto: 'step5_woman',
            },
        }, ],
    },
    step5_woman: {
        type: 'question',
        text: 'كيف تكسب لقمة العيش؟',
        options: [{
            type: 'button',
            text: 'أنا أعمل',
            audience_id: '62195',
            action: {
                goto: 'step6_woman',
            },
        }, {
            type: 'button',
            text: 'أنا أعمل لحسابي',
            audience_id: '62210',
            action: {
                goto: 'step6_woman',
            },
        }, {
            type: 'button',
            text: 'أنا عاطل عن العمل',
            audience_id: '62197',
            action: {
                goto: 'step6_woman',
            },
        }, {
            type: 'button',
            text: 'أنا متقاعد',
            audience_id: '62211',
            action: {
                goto: 'step6_woman',
            },
        }, ],
    },
    step6_woman: {
        type: 'question',
        text: 'ما هو متوسط دخلك في السنة؟',
        options: [{
            type: 'button',
            text: 'أقل من 10,000 دولار',
            audience_id: '62201',
            action: {
                goto: 'step7_woman',
            },
        }, {
            type: 'button',
            text: '10,000-30,000 دولار',
            audience_id: '62202',
            action: {
                goto: 'step7_woman',
            },
        }, {
            type: 'button',
            text: '$30,000-50,000 دولار',
            audience_id: '62200',
            action: {
                goto: 'step7_woman',
            },
        }, {
            type: 'button',
            text: 'أكثر من 50,000 دولار',
            audience_id: '62203',
            action: {
                goto: 'step7_woman',
            },
        }, ],
    },
    step7_woman: {
        type: 'question',
        text: 'ما هو هدفك بعد كسب المال للسنوات الخمس القادمة؟',
        options: [{
            type: 'button',
            text: 'الذهاب في عطلة عائلية',
            audience_id: '62345',
            action: {
                goto: 'step8_woman',
            },
        }, {
            type: 'button',
            text: 'اشتر سيارة خارقة',
            audience_id: '62346',
            action: {
                goto: 'step8_woman',
            },
        }, {
            type: 'button',
            text: 'شراء شقة أو منزل',
            audience_id: '62347',
            action: {
                goto: 'step8_woman',
            },
        }, {
            type: 'button',
            text: 'ابدأ نشاطي التجاري الخاص',
            audience_id: '62348',
            action: {
                goto: 'step8_woman',
            },
        }, ],
    },
    step8_woman: {
        type: 'question',
        text: 'كم ستستثمر الآن لتقترب من هدفك المالي بشكل أسرع؟',
        options: [{
            type: 'button',
            text: 'أقل من 250 دولارًا',
            audience_id: [62208, 62141],
            action: {
                goto: 'step10_binary',
            },
        }, {
            type: 'button',
            text: '$250-500 دولار',
            audience_id: [62207, 62140],
            action: {
                goto: 'step9_woman',
            },
        }, {
            type: 'button',
            text: '500-1000 دولار',
            audience_id: [62206, 62140],
            action: {
                goto: 'step9_woman',
            },
        }, {
            type: 'button',
            text: 'أكثر من 1000 دولار',
            audience_id: [62205, 62140],
            action: {
                goto: 'step9_woman',
            },
        }, ],
    },
    step9_woman: {
        type: 'question',
        text: 'هل لديك أي خبرة في تداول البيتكوين؟',
        options: [{
            type: 'button',
            text: 'لا، لم أسمع بها من قبل',
            audience_id: '62350',
            action: {
                goto: 'step10',
            },
        }, {
            type: 'button',
            text: 'لا، لكني أريد أن أحاول',
            audience_id: '62351',
            action: {
                goto: 'step10',
            },
        }, {
            type: 'button',
            text: 'نعم، أنا مبتدئ',
            audience_id: '62352',
            action: {
                goto: 'step10',
            },
        }, {
            type: 'button',
            text: 'نعم، أفعل ذلك بشكل احترافي',
            audience_id: '62353',
            action: {
                goto: 'step10',
            },
        }, ],
    },
    step10: {
        type: 'thank_you',
        text: 'شكرًا لك!',
        content: '<div style="text-align: center; font-size:2rem"><p style="text-align: center; font-size:2rem; margin-bottom:2rem">نتيجة الاختبار الخاصة بك: <span class="text--danger" style="font-weight:bold"><strong>ممتاز</strong></span> (35 من 35)</p> <p style="font-size:2rem;">أنت شخص مثالي لكسب المال عبر الإنترنت، <br>يمكنك كسب أكثر من <span class="text--danger" style="font-weight:bold"><strong>5000 دولار</strong></span> يوميًا! <br>لقد اخترنا لك <span class="text--danger"><strong>4 عروض</strong></span> للحصول على أموال سريعة عبر الإنترنت. <br>اتبع التعليمات أدناه واحصل على عرضك الشخصي. <br>في غضون 40 ثانية ستتم إعادة توجيهك إلى أفضل عرض (<span class="text--danger">الأكثر ربحية بالنسبة لك</span>). <br>انقر على زر GET OFFER للانتقال إلى أفضل عرض على الفور! </p></div>',
        timeout: 40,
        timeout_url: SmartURL,
        progress_title: 'هل ستحقق أكثر من 5000 دولار يوميًا؟',
        progress_texts: ['انتظر... التحقق من الإجابات', 'انتظر... عد درجاتك'],
        progress_content: '',
        options: [{
            type: 'button',
            text: 'احصل على عرض',
            audience_id: '61426',
            action: {
                redirect_url: SmartURL,
            },
        }, ],
    },
    step10_binary: {
        type: 'thank_you',
        text: 'شكرًا لك!',
        content: '<div style="text-align: center; font-size:2rem;"><p style="text-align: center; font-size:2rem; margin-bottom:2rem">نتيجة الاختبار الخاصة بك: <span class="text--danger" style="font-weight:bold"><strong>عظيم</strong></span> (22 من أصل 35)</p> <p style="font-size:2rem;">أنت شخص شجاع، والحظ في صفك! <span class="text--danger blink"><b>لا تفوت فرصتك</b></span> للحصول على ثراء وإحاطة نفسك بالفخامة! <br>في غضون 40 ثانية ستتم إعادة توجيهك إلى أفضل عرض (<span class="text--danger">الأكثر ربحية بالنسبة لك</span>). <br>انقر على زر GET OFFER للانتقال إلى أفضل عرض على الفور! </p></div>',
        timeout: 40,
        timeout_url: SmartURL,
        progress_title: 'هل ستحقق أكثر من 5000 دولار يوميًا؟',
        progress_texts: ['انتظر... التحقق من الإجابات', 'انتظر... عد درجاتك'],
        progress_content: '',
        options: [{
            type: 'button',
            text: 'احصل على عرض',
            audience_id: '61426',
            action: {
                redirect_url: SmartURL,
            },
        }, ],
    },
};