window.surveyData = {
    adex: 1,
    adex_alert_urll: 'https://lehtymns.com/4453095/?var={zone}&ymid={request_var}',
    adex_warning_urll: 'https://lehtymns.com/4453095/?var={zone}&ymid={request_var}',
    id: 2064001,
    autoexitx: 4142474,
    creativex: 60816,
    comment: '2064 DE dynamic price',
    push_zonex: 4142547,
    reverse_zonex: 4142367,
    popunder_urll: 'https://lehtymns.com/4142489/?var={zone}&ymid={request_var}&var3={click_id}',
    title: 'Würden Sie online richtig Karriere machen und bis 2022 Millionär werden?',
    page_title: 'Würden Sie online richtig Karriere machen und bis 2022 Millionär werden?',
    subtitle:
        'Machen Sie diesen KOSTENLOSEN Test und erfahren Sie, wie Sie im Internet Geld verdienen können.',
    logo_text: 'Online-Test',
    lead: {
        not_unique: {
            redirect_urll:
                'https://lehtymns.com/4142493/?var={zone}&ymid={request_var}&var3={click_id}',
        },
    },
    main: {
        type: 'question',
        text: 'Was ist dein Geschlecht?',
        options: [
            {
                type: 'button',
                text: 'Mann',
                audience_id: '61427',
                action: {
                    goto: 'step2_man',
                },
            },
            {
                type: 'button',
                text: 'Frau',
                audience_id: '61428',
                action: {
                    goto: 'step2_woman',
                },
            },
        ],
    },
    step2_man: {
        type: 'question',
        text: 'Wie alt sind Sie?',
        options: [
            {
                type: 'button',
                text: 'unter 18 Jahre',
                audience_id: [61421, 62387],
                action: {
                    redirect_url: SmartURL,
                    popunder_url: SmartURL,
                },
            },
            {
                type: 'button',
                text: '18-29 Jahre',
                audience_id: [62180, 62377],
                action: {
                    goto: 'step5_man',
                },
            },
            {
                type: 'button',
                text: '30-49 Jahre',
                audience_id: [62181, 62380],
                action: {
                    goto: 'step5_man',
                },
            },
            {
                type: 'button',
                text: '50-80 Jahre',
                audience_id: [62182, 62381],
                action: {
                    goto: 'step5_man',
                },
            },
        ],
    },
    step5_man: {
        type: 'question',
        text: 'Wie verdient man ihren Lebensunterhalt?',
        options: [
            {
                type: 'button',
                text: 'Ich arbeite',
                audience_id: '62195',
                action: {
                    goto: 'step6_man',
                },
            },
            {
                type: 'button',
                text: 'Ich bin selbstständig',
                audience_id: '62210',
                action: {
                    goto: 'step6_man',
                },
            },
            {
                type: 'button',
                text: 'Ich bin arbeitslos',
                audience_id: '62197',
                action: {
                    goto: 'step6_man',
                },
            },
            {
                type: 'button',
                text: 'Ich bin Rentner',
                audience_id: '62211',
                action: {
                    goto: 'step6_man',
                },
            },
        ],
    },
    step6_man: {
        type: 'question',
        text: 'Wie hoch ist Ihr Durchschnittseinkommen pro Jahr?',
        options: [
            {
                type: 'button',
                text: 'unter 10.000$',
                audience_id: '62201',
                action: {
                    goto: 'step7_man',
                },
            },
            {
                type: 'button',
                text: '10.000-30.000$',
                audience_id: '62202',
                action: {
                    goto: 'step7_man',
                },
            },
            {
                type: 'button',
                text: '30.000-50.000$',
                audience_id: '62200',
                action: {
                    goto: 'step7_man',
                },
            },
            {
                type: 'button',
                text: 'mehr als 50.000 Dollar',
                audience_id: '62203',
                action: {
                    goto: 'step7_man',
                },
            },
        ],
    },
    step7_man: {
        type: 'question',
        text: 'Was ist Ihr finanzielles Ziel für die nächsten 5 Jahre?',
        options: [
            {
                type: 'button',
                text: 'Einen Familienurlaub machen',
                audience_id: '62345',
                action: {
                    goto: 'step8_man',
                },
            },
            {
                type: 'button',
                text: 'Einen Sportwagen kaufen',
                audience_id: '62346',
                action: {
                    goto: 'step8_man',
                },
            },
            {
                type: 'button',
                text: 'Kaufen Sie eine Wohnung oder ein Haus',
                audience_id: '62347',
                action: {
                    goto: 'step8_man',
                },
            },
            {
                type: 'button',
                text: 'Ein eigenes Unternehmen gründen',
                audience_id: '62348',
                action: {
                    goto: 'step8_man',
                },
            },
        ],
    },
    step8_man: {
        type: 'question',
        text:
            'Wie viel würden Sie jetzt investieren, um Ihrem finanziellen Ziel viel schneller näher zu kommen?',
        options: [
            {
                type: 'button',
                text: 'weniger als 250 USD',
                audience_id: [62208, 62139],
                action: {
                    goto: 'step10_binary',
                },
            },
            {
                type: 'button',
                text: '250 bis 500$',
                audience_id: [62207, 62138],
                action: {
                    goto: 'step9_man',
                },
            },
            {
                type: 'button',
                text: '500-1000$',
                audience_id: [62206, 62138],
                action: {
                    goto: 'step9_man',
                },
            },
            {
                type: 'button',
                text: 'mehr als 1000 USD',
                audience_id: [62205, 62138],
                action: {
                    goto: 'step9_man',
                },
            },
        ],
    },
    step9_man: {
        type: 'question',
        text: 'Haben Sie Erfahrung im Bitcoin-Handel?',
        options: [
            {
                type: 'button',
                text: 'Nein, ich habe noch nie davon gehört',
                audience_id: '62350',
                action: {
                    goto: 'step10',
                },
            },
            {
                type: 'button',
                text: 'Nein, aber ich möchte es versuchen',
                audience_id: '62351',
                action: {
                    goto: 'step10',
                },
            },
            {
                type: 'button',
                text: 'Ja, ich bin Anfänger',
                audience_id: '62352',
                action: {
                    goto: 'step10',
                },
            },
            {
                type: 'button',
                text: 'Ja, ich handle professionell',
                audience_id: '62353',
                action: {
                    goto: 'step10',
                },
            },
        ],
    },
    step2_woman: {
        type: 'question',
        text: 'Wie alt sind Sie?',
        options: [
            {
                type: 'button',
                text: 'unter 18 Jahre',
                audience_id: [61421, 62386],
                action: {
                    redirect_url: SmartURL,
                    popunder_url: SmartURL,
                },
            },
            {
                type: 'button',
                text: '18-29 Jahre',
                audience_id: [62180, 62382],
                action: {
                    goto: 'step5_woman',
                },
            },
            {
                type: 'button',
                text: '30-49 Jahre',
                audience_id: [62181, 62383],
                action: {
                    goto: 'step5_woman',
                },
            },
            {
                type: 'button',
                text: '50-80 Jahre',
                audience_id: [62182, 62384],
                action: {
                    goto: 'step5_woman',
                },
            },
        ],
    },
    step5_woman: {
        type: 'question',
        text: 'Wie verdient man ihren Lebensunterhalt?',
        options: [
            {
                type: 'button',
                text: 'Ich arbeite',
                audience_id: '62195',
                action: {
                    goto: 'step6_woman',
                },
            },
            {
                type: 'button',
                text: 'Ich bin selbstständig',
                audience_id: '62210',
                action: {
                    goto: 'step6_woman',
                },
            },
            {
                type: 'button',
                text: 'Ich bin arbeitslos',
                audience_id: '62197',
                action: {
                    goto: 'step6_woman',
                },
            },
            {
                type: 'button',
                text: 'Ich bin Rentner',
                audience_id: '62211',
                action: {
                    goto: 'step6_woman',
                },
            },
        ],
    },
    step6_woman: {
        type: 'question',
        text: 'Wie hoch ist Ihr Durchschnittseinkommen pro Jahr?',
        options: [
            {
                type: 'button',
                text: 'unter 10.000$',
                audience_id: '62201',
                action: {
                    goto: 'step7_woman',
                },
            },
            {
                type: 'button',
                text: '10.000-30.000$',
                audience_id: '62202',
                action: {
                    goto: 'step7_woman',
                },
            },
            {
                type: 'button',
                text: '30.000-50.000$',
                audience_id: '62200',
                action: {
                    goto: 'step7_woman',
                },
            },
            {
                type: 'button',
                text: 'mehr als 50.000 Dollar',
                audience_id: '62203',
                action: {
                    goto: 'step7_woman',
                },
            },
        ],
    },
    step7_woman: {
        type: 'question',
        text: 'Was ist Ihr finanzielles Ziel für die nächsten 5 Jahre?',
        options: [
            {
                type: 'button',
                text: 'Einen Familienurlaub machen',
                audience_id: '62345',
                action: {
                    goto: 'step8_woman',
                },
            },
            {
                type: 'button',
                text: 'Einen Sportwagen kaufen',
                audience_id: '62346',
                action: {
                    goto: 'step8_woman',
                },
            },
            {
                type: 'button',
                text: 'Kaufen Sie eine Wohnung oder ein Haus',
                audience_id: '62347',
                action: {
                    goto: 'step8_woman',
                },
            },
            {
                type: 'button',
                text: 'Ein eigenes Unternehmen gründen',
                audience_id: '62348',
                action: {
                    goto: 'step8_woman',
                },
            },
        ],
    },
    step8_woman: {
        type: 'question',
        text:
            'Wie viel würden Sie jetzt investieren, um Ihrem finanziellen Ziel viel schneller näher zu kommen?',
        options: [
            {
                type: 'button',
                text: 'weniger als 250 USD',
                audience_id: [62208, 62141],
                action: {
                    goto: 'step10_binary',
                },
            },
            {
                type: 'button',
                text: '250 bis 500$',
                audience_id: [62207, 62140],
                action: {
                    goto: 'step9_woman',
                },
            },
            {
                type: 'button',
                text: '500-1000$',
                audience_id: [62206, 62140],
                action: {
                    goto: 'step9_woman',
                },
            },
            {
                type: 'button',
                text: 'mehr als 1000 USD',
                audience_id: [62205, 62140],
                action: {
                    goto: 'step9_woman',
                },
            },
        ],
    },
    step9_woman: {
        type: 'question',
        text: 'Haben Sie Erfahrung im Bitcoin-Handel?',
        options: [
            {
                type: 'button',
                text: 'Nein, ich habe noch nie davon gehört',
                audience_id: '62350',
                action: {
                    goto: 'step10',
                },
            },
            {
                type: 'button',
                text: 'Nein, aber ich möchte es versuchen',
                audience_id: '62351',
                action: {
                    goto: 'step10',
                },
            },
            {
                type: 'button',
                text: 'Ja, ich bin Anfänger',
                audience_id: '62352',
                action: {
                    goto: 'step10',
                },
            },
            {
                type: 'button',
                text: 'Ja, ich handle professionell',
                audience_id: '62353',
                action: {
                    goto: 'step10',
                },
            },
        ],
    },
    step10: {
        type: 'thank_you',
        text: 'DANKE!',
        content:
            '<div style="text-align: center; font-size:2rem"><p style="text-align: center; font-size:2rem; margin-bottom:2rem">Ihr Testergebnis: <span class="text--danger" style="font-weight:bold"><strong>EXCELLENT</strong></span> (35 von 35)</p> <p style="font-size:2rem;">Sie sind die ideale Person, um online Geld zu verdienen, <br>Sie können viel mehr als <span class="text--danger" style="font-weight:bold"><strong>5.000 USD</strong></span> täglich verdienen! <br>Wir haben für Sie <span class="text--danger"><strong>4 Angebote</strong></span> für schnelles Online-Geldverdienen ausgewählt. <br>Befolgen Sie die nachstehenden Anweisungen und holen Sie sich Ihr persönliches Angebot. <br>In 40 Sekunden werden Sie zum besten (<span class="text--danger">profitabelsten für Sie</span>) Angebot weitergeleitet. <br>Klicken Sie auf den Button ANGEBOT ERHALTEN, um sofort zum besten Angebot zu gelangen! </p></div>',
        timeout: 40,
        timeout_url: SmartURL,
        progress_title: 'Werden Sie täglich 5.000$ verdienen?',
        progress_texts: ['Warte... Antworten prüfen', 'Warte... Zählen Sie Ihre Punktzahl'],
        progress_content: '',
        options: [
            {
                type: 'button',
                text: 'ANGEBOT ABRUFEN',
                audience_id: '61426',
                action: {
                    redirect_url: SmartURL,
                },
            },
        ],
    },
    step10_binary: {
        type: 'thank_you',
        text: 'DANKE!',
        content:
            '<div style="text-align: center; font-size:2rem;"><p style="text-align: center; font-size:2rem; margin-bottom:2rem">Dein Testergebnis: <span class="text--danger" style="font-weight:bold"><strong>GROSSARTIG</strong></span> (22 von 35)</p> <p style="font-size:2rem;">Du bist eine mutige Person, das Glück ist auf deiner Seite! <span class="text--danger blink"><b>Verpassen Sie nicht Ihre Chance</b></span>, wohlhabender zu werden und sich mit Luxus zu umgeben! <br>In 40 Sekunden werden Sie zum besten (<span class="text--danger">profitabelsten für Sie</span>) Angebot weitergeleitet. <br>Klicken Sie auf den Button ANGEBOT ERHALTEN, um sofort zum besten Angebot zu gelangen! </p></div>',
        timeout: 40,
        timeout_url: SmartURL,
        progress_title: 'Werden Sie täglich 5.000$ verdienen?',
        progress_texts: ['Warte... Antworten prüfen', 'Warte... Zählen Sie Ihre Punktzahl'],
        progress_content: '',
        options: [
            {
                type: 'button',
                text: 'ANGEBOT ABRUFEN',
                audience_id: '61426',
                action: {
                    redirect_url: SmartURL,
                },
            },
        ],
    },
};
