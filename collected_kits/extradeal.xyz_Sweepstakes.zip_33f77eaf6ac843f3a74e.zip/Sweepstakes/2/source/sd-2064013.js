window.surveyData = {
    adex: 1,
    adex_alert_urll: 'https://lehtymns.com/4453095/?var={zone}&ymid={request_var}',
    adex_warning_urll: 'https://lehtymns.com/4453095/?var={zone}&ymid={request_var}',
    id: 2064001,
    autoexitx: 4142474,
    creativex: 60816,
    comment: '2064 VN dynamic price',
    push_zonex: 4142547,
    reverse_zonex: 4142367,
    popunder_urll: 'https://lehtymns.com/4142489/?var={zone}&ymid={request_var}&var3={click_id}',
    title:
        'Bạn sẽ tạo ra một sự nghiệp tuyệt vời trực tuyến và trở thành một triệu phú vào năm 2022?',
    page_title:
        'Bạn sẽ tạo ra một sự nghiệp tuyệt vời trực tuyến và trở thành một triệu phú vào năm 2022?',
    subtitle:
        'Tham gia bài kiểm tra miễn phí này và tìm hiểu làm thế nào bạn có thể kiếm tiền trên Internet.',
    logo_text: 'Online Test',
    lead: {
        not_unique: {
            redirect_urll:
                'https://lehtymns.com/4142493/?var={zone}&ymid={request_var}&var3={click_id}',
        },
    },
    main: {
        type: 'question',
        text: 'Giới tính của bạn là gì?',
        options: [
            {
                type: 'button',
                text: 'Người đàn ông',
                audience_id: '61427',
                action: {
                    goto: 'step2_man',
                },
            },
            {
                type: 'button',
                text: 'Người phụ nữ',
                audience_id: '61428',
                action: {
                    goto: 'step2_woman',
                },
            },
        ],
    },
    step2_man: {
        type: 'question',
        text: 'Anh bao nhiêu tuổi rồi?',
        options: [
            {
                type: 'button',
                text: 'ít hơn 18 năm',
                audience_id: [61421, 62387],
                action: {
                    redirect_url: SmartURL,
                    popunder_url: SmartURL,
                },
            },
            {
                type: 'button',
                text: '18-29 các năm',
                audience_id: [62180, 62377],
                action: {
                    goto: 'step5_man',
                },
            },
            {
                type: 'button',
                text: '30-49 các năm',
                audience_id: [62181, 62380],
                action: {
                    goto: 'step5_man',
                },
            },
            {
                type: 'button',
                text: '50-80 các năm',
                audience_id: [62182, 62381],
                action: {
                    goto: 'step5_man',
                },
            },
        ],
    },
    step5_man: {
        type: 'question',
        text: 'Làm thế nào để bạn kiếm sống?',
        options: [
            {
                type: 'button',
                text: 'Tôi làm việc',
                audience_id: '62195',
                action: {
                    goto: 'step6_man',
                },
            },
            {
                type: 'button',
                text: 'Tôi là người tự làm chủ',
                audience_id: '62210',
                action: {
                    goto: 'step6_man',
                },
            },
            {
                type: 'button',
                text: 'Tôi đang thất nghiệp',
                audience_id: '62197',
                action: {
                    goto: 'step6_man',
                },
            },
            {
                type: 'button',
                text: 'Tôi là một người hưu trí',
                audience_id: '62211',
                action: {
                    goto: 'step6_man',
                },
            },
        ],
    },
    step6_man: {
        type: 'question',
        text: 'Thu nhập trung bình mỗi năm của bạn là bao nhiêu?',
        options: [
            {
                type: 'button',
                text: 'ít hơn 10.000 đô la',
                audience_id: '62201',
                action: {
                    goto: 'step7_man',
                },
            },
            {
                type: 'button',
                text: '$10,000-$30,000',
                audience_id: '62202',
                action: {
                    goto: 'step7_man',
                },
            },
            {
                type: 'button',
                text: '$30,000-$50,000',
                audience_id: '62200',
                action: {
                    goto: 'step7_man',
                },
            },
            {
                type: 'button',
                text: 'hơn 50.000 đô la',
                audience_id: '62203',
                action: {
                    goto: 'step7_man',
                },
            },
        ],
    },
    step7_man: {
        type: 'question',
        text: 'Mục tiêu tài chính của bạn trong 5 năm tới là gì?',
        options: [
            {
                type: 'button',
                text: 'Đi vào một kỳ nghỉ gia đình',
                audience_id: '62345',
                action: {
                    goto: 'step8_man',
                },
            },
            {
                type: 'button',
                text: 'Mua một siêu xe',
                audience_id: '62346',
                action: {
                    goto: 'step8_man',
                },
            },
            {
                type: 'button',
                text: 'Mua một căn hộ hoặc một ngôi nhà',
                audience_id: '62347',
                action: {
                    goto: 'step8_man',
                },
            },
            {
                type: 'button',
                text: 'Bắt đầu kinh doanh của riêng tôi',
                audience_id: '62348',
                action: {
                    goto: 'step8_man',
                },
            },
        ],
    },
    step8_man: {
        type: 'question',
        text:
            'Bạn sẽ đầu tư bao nhiêu ngay bây giờ để có được gần hơn với mục tiêu tài chính của bạn nhanh hơn nhiều?',
        options: [
            {
                type: 'button',
                text: 'ít hơn $250',
                audience_id: [62208, 62139],
                action: {
                    goto: 'step10_binary',
                },
            },
            {
                type: 'button',
                text: '$250-$500',
                audience_id: [62207, 62138],
                action: {
                    goto: 'step9_man',
                },
            },
            {
                type: 'button',
                text: '$500-$1000',
                audience_id: [62206, 62138],
                action: {
                    goto: 'step9_man',
                },
            },
            {
                type: 'button',
                text: 'hơn $1000',
                audience_id: [62205, 62138],
                action: {
                    goto: 'step9_man',
                },
            },
        ],
    },
    step9_man: {
        type: 'question',
        text: 'Bạn có kinh nghiệm kinh nghiệm trong giao dịch Bitcoin không?',
        options: [
            {
                type: 'button',
                text: 'Không, tôi chưa bao giờ nghe nói về nó',
                audience_id: '62350',
                action: {
                    goto: 'step10',
                },
            },
            {
                type: 'button',
                text: 'Không, nhưng tôi muốn thử',
                audience_id: '62351',
                action: {
                    goto: 'step10',
                },
            },
            {
                type: 'button',
                text: 'Vâng, tôi là người mới bắt đầu',
                audience_id: '62352',
                action: {
                    goto: 'step10',
                },
            },
            {
                type: 'button',
                text: 'Vâng, tôi làm điều đó một cách chuyên nghiệp',
                audience_id: '62353',
                action: {
                    goto: 'step10',
                },
            },
        ],
    },
    step2_woman: {
        type: 'question',
        text: 'Anh bao nhiêu tuổi rồi?',
        options: [
            {
                type: 'button',
                text: 'ít hơn 18 năm',
                audience_id: [61421, 62386],
                action: {
                    redirect_url: SmartURL,
                    popunder_url: SmartURL,
                },
            },
            {
                type: 'button',
                text: '18-29 các năm',
                audience_id: [62180, 62382],
                action: {
                    goto: 'step5_woman',
                },
            },
            {
                type: 'button',
                text: '30-49 các năm',
                audience_id: [62181, 62383],
                action: {
                    goto: 'step5_woman',
                },
            },
            {
                type: 'button',
                text: '50-80 các năm',
                audience_id: [62182, 62384],
                action: {
                    goto: 'step5_woman',
                },
            },
        ],
    },
    step5_woman: {
        type: 'question',
        text: 'Làm thế nào để bạn kiếm sống?',
        options: [
            {
                type: 'button',
                text: 'Tôi làm việc',
                audience_id: '62195',
                action: {
                    goto: 'step6_woman',
                },
            },
            {
                type: 'button',
                text: 'Tôi là người tự làm chủ',
                audience_id: '62210',
                action: {
                    goto: 'step6_woman',
                },
            },
            {
                type: 'button',
                text: 'Tôi đang thất nghiệp',
                audience_id: '62197',
                action: {
                    goto: 'step6_woman',
                },
            },
            {
                type: 'button',
                text: 'Tôi là một người hưu trí',
                audience_id: '62211',
                action: {
                    goto: 'step6_woman',
                },
            },
        ],
    },
    step6_woman: {
        type: 'question',
        text: 'Thu nhập trung bình mỗi năm của bạn là bao nhiêu?',
        options: [
            {
                type: 'button',
                text: 'ít hơn 10.000 đô la',
                audience_id: '62201',
                action: {
                    goto: 'step7_woman',
                },
            },
            {
                type: 'button',
                text: '$10,000-$30,000',
                audience_id: '62202',
                action: {
                    goto: 'step7_woman',
                },
            },
            {
                type: 'button',
                text: '$30,000-$50,000',
                audience_id: '62200',
                action: {
                    goto: 'step7_woman',
                },
            },
            {
                type: 'button',
                text: 'hơn 50.000 đô la',
                audience_id: '62203',
                action: {
                    goto: 'step7_woman',
                },
            },
        ],
    },
    step7_woman: {
        type: 'question',
        text: 'Mục tiêu tài chính của bạn trong 5 năm tới là gì?',
        options: [
            {
                type: 'button',
                text: 'Đi vào một kỳ nghỉ gia đình',
                audience_id: '62345',
                action: {
                    goto: 'step8_woman',
                },
            },
            {
                type: 'button',
                text: 'Mua một siêu xe',
                audience_id: '62346',
                action: {
                    goto: 'step8_woman',
                },
            },
            {
                type: 'button',
                text: 'Mua một căn hộ hoặc một ngôi nhà',
                audience_id: '62347',
                action: {
                    goto: 'step8_woman',
                },
            },
            {
                type: 'button',
                text: 'Bắt đầu kinh doanh của riêng tôi',
                audience_id: '62348',
                action: {
                    goto: 'step8_woman',
                },
            },
        ],
    },
    step8_woman: {
        type: 'question',
        text:
            'Bạn sẽ đầu tư bao nhiêu ngay bây giờ để có được gần hơn với mục tiêu tài chính của bạn nhanh hơn nhiều?',
        options: [
            {
                type: 'button',
                text: 'ít hơn $250',
                audience_id: [62208, 62141],
                action: {
                    goto: 'step10_binary',
                },
            },
            {
                type: 'button',
                text: '$250-$500',
                audience_id: [62207, 62140],
                action: {
                    goto: 'step9_woman',
                },
            },
            {
                type: 'button',
                text: '$500-$1000',
                audience_id: [62206, 62140],
                action: {
                    goto: 'step9_woman',
                },
            },
            {
                type: 'button',
                text: 'hơn $1000',
                audience_id: [62205, 62140],
                action: {
                    goto: 'step9_woman',
                },
            },
        ],
    },
    step9_woman: {
        type: 'question',
        text: 'Bạn có kinh nghiệm kinh nghiệm trong giao dịch Bitcoin không?',
        options: [
            {
                type: 'button',
                text: 'Không, tôi chưa bao giờ nghe nói về nó',
                audience_id: '62350',
                action: {
                    goto: 'step10',
                },
            },
            {
                type: 'button',
                text: 'Không, nhưng tôi muốn thử',
                audience_id: '62351',
                action: {
                    goto: 'step10',
                },
            },
            {
                type: 'button',
                text: 'Vâng, tôi là người mới bắt đầu',
                audience_id: '62352',
                action: {
                    goto: 'step10',
                },
            },
            {
                type: 'button',
                text: 'Vâng, tôi làm điều đó một cách chuyên nghiệp',
                audience_id: '62353',
                action: {
                    goto: 'step10',
                },
            },
        ],
    },
    step10: {
        type: 'thank_you',
        text: 'CẢM ƠN BẠN!',
        content:
            '<div style="text-align: center; font-size:2rem"> <p style="text-align: center; font-size:2rem; margin-bottom:2rem">Kết quả kiểm tra của bạn: <span class="text--danger" style="font-weight:bold"> <strong> Tuyệt vời </strong> </span> (35 trên 35) </p> <p style="font-size:2rem;"> Bạn là một người lý tưởng để kiếm tiền trực tuyến, <br>bạn có thể kiếm được nhiều hơn <span class="text--danger" style="font-weight:bold"> <strong> $5,000 </strong> </span> mỗi ngày! <br>Chúng tôi đã chọn cho bạn <span class="text--danger"> <strong> 4 cung cấp </strong> </span> cho kiếm tiền trực tuyến nhanh. <br>Làm theo hướng dẫn dưới đây và nhận đề nghị cá nhân của bạn. <br>Trong 40 giây, bạn sẽ được chuyển hướng đến cung cấp tốt <span class="text--danger"> nhất (có lợi nhất cho bạn </span>). <br>Nhấp vào nút GET OFFER để đi đến ưu đãi tốt nhất ngay lập tức! </p> </div>',
        timeout: 40,
        timeout_url: SmartURL,
        progress_title: 'Bạn sẽ kiếm được $5,000+ mỗi ngày?',
        progress_texts: ['Đợi đã... Kiểm tra câu trả lời', 'Đợi đã... Đếm điểm của bạn'],
        progress_content: '',
        options: [
            {
                type: 'button',
                text: 'NHẬN ĐỀ NGHỊ',
                audience_id: '61426',
                action: {
                    redirect_url: SmartURL,
                },
            },
        ],
    },
    step10_binary: {
        type: 'thank_you',
        text: 'CẢM ƠN BẠN!',
        content:
            '<div style="text-align: center; font-size:2rem;"> <p style="text-align: center; font-size:2rem; margin-bottom:2rem">Kết quả kiểm tra của bạn: <span class="text--danger" style="font-weight:bold"> <strong> Great </strong> </span> (22 trên 35) </p> <p style="font-size:2rem;"> Bạn là một người can đảm, may mắn là về phía bạn! <span class="text--danger blink"> <b>Đừng bỏ lỡ cơ hội </b> </span> để trở nên giàu có hơn và bao quanh mình với sự sang trọng! <br>Trong 40 giây, bạn sẽ được chuyển hướng đến cung cấp tốt <span class="text--danger"> nhất (có lợi nhất cho bạn </span>). <br>Nhấp vào nút GET OFFER để đi đến ưu đãi tốt nhất ngay lập tức! </p> </div>',
        timeout: 40,
        timeout_url: SmartURL,
        progress_title: 'Bạn sẽ kiếm được $5,000+ mỗi ngày?',
        progress_texts: ['Đợi đã... Kiểm tra câu trả lời', 'Đợi đã... Đếm điểm của bạn'],
        progress_content: '',
        options: [
            {
                type: 'button',
                text: 'NHẬN ĐỀ NGHỊ',
                audience_id: '61426',
                action: {
                    redirect_url: SmartURL,
                },
            },
        ],
    },
};
