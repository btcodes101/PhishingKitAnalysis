window.surveyData = {
    adex: 1,
    adex_alert_urll: 'https://lehtymns.com/4453095/?var={zone}&ymid={request_var}',
    adex_warning_urll: 'https://lehtymns.com/4453095/?var={zone}&ymid={request_var}',
    id: 2064001,
    autoexitx: 4142474,
    creativex: 60816,
    comment: '2064 ES dynamic price',
    push_zonex: 4142547,
    reverse_zonex: 4142367,
    popunder_urll: 'https://lehtymns.com/4142489/?var={zone}&ymid={request_var}&var3={click_id}',
    title: '¿Harás una gran carrera online y te convertirás en el millonario para el 2022?',
    page_title: '¿Harás una gran carrera online y te convertirás en el millonario para el 2022?',
    subtitle: 'Realiza esta prueba GRATUITA y descubre cómo puedes ganar dinero en Internet.',
    logo_text: 'Prueba online',
    lead: {
        not_unique: {
            redirect_urll:
                'https://lehtymns.com/4142493/?var={zone}&ymid={request_var}&var3={click_id}',
        },
    },
    main: {
        type: 'question',
        text: '¿Cuál es tu género?',
        options: [
            {
                type: 'button',
                text: 'Hombre',
                audience_id: '61427',
                action: {
                    goto: 'step2_man',
                },
            },
            {
                type: 'button',
                text: 'Mujer',
                audience_id: '61428',
                action: {
                    goto: 'step2_woman',
                },
            },
        ],
    },
    step2_man: {
        type: 'question',
        text: '¿Cuántos años tienes?',
        options: [
            {
                type: 'button',
                text: 'menos de 18 años',
                audience_id: [61421, 62387],
                action: {
                    redirect_url: SmartURL,
                    popunder_url: SmartURL,
                },
            },
            {
                type: 'button',
                text: '18-29 años',
                audience_id: [62180, 62377],
                action: {
                    goto: 'step5_man',
                },
            },
            {
                type: 'button',
                text: '30-49 años',
                audience_id: [62181, 62380],
                action: {
                    goto: 'step5_man',
                },
            },
            {
                type: 'button',
                text: '50-80 años',
                audience_id: [62182, 62381],
                action: {
                    goto: 'step5_man',
                },
            },
        ],
    },
    step5_man: {
        type: 'question',
        text: '¿Cómo te ganas la vida?',
        options: [
            {
                type: 'button',
                text: 'trabajo',
                audience_id: '62195',
                action: {
                    goto: 'step6_man',
                },
            },
            {
                type: 'button',
                text: 'Soy autónomo',
                audience_id: '62210',
                action: {
                    goto: 'step6_man',
                },
            },
            {
                type: 'button',
                text: 'Estoy desempleado',
                audience_id: '62197',
                action: {
                    goto: 'step6_man',
                },
            },
            {
                type: 'button',
                text: 'Soy jubilado',
                audience_id: '62211',
                action: {
                    goto: 'step6_man',
                },
            },
        ],
    },
    step6_man: {
        type: 'question',
        text: '¿Cuál es su ingreso medio anual?',
        options: [
            {
                type: 'button',
                text: 'menos de 10.000 dólares',
                audience_id: '62201',
                action: {
                    goto: 'step7_man',
                },
            },
            {
                type: 'button',
                text: '10.000 dólares a 30.000 dólares',
                audience_id: '62202',
                action: {
                    goto: 'step7_man',
                },
            },
            {
                type: 'button',
                text: '30.000 dólares a 50.000 dólares',
                audience_id: '62200',
                action: {
                    goto: 'step7_man',
                },
            },
            {
                type: 'button',
                text: 'más de 50.000 dólares',
                audience_id: '62203',
                action: {
                    goto: 'step7_man',
                },
            },
        ],
    },
    step7_man: {
        type: 'question',
        text: '¿Cuál es tu objetivo financiero para los próximos 5 años?',
        options: [
            {
                type: 'button',
                text: 'Vete de vacaciones en familia',
                audience_id: '62345',
                action: {
                    goto: 'step8_man',
                },
            },
            {
                type: 'button',
                text: 'Compra un superdeportivo',
                audience_id: '62346',
                action: {
                    goto: 'step8_man',
                },
            },
            {
                type: 'button',
                text: 'Compra un apartamento o una casa',
                audience_id: '62347',
                action: {
                    goto: 'step8_man',
                },
            },
            {
                type: 'button',
                text: 'Iniciar mi propio negocio',
                audience_id: '62348',
                action: {
                    goto: 'step8_man',
                },
            },
        ],
    },
    step8_man: {
        type: 'question',
        text:
            '¿Cuánto invertiría ahora mismo para acercarse a su objetivo financiero mucho más rápido?',
        options: [
            {
                type: 'button',
                text: 'menos de 250 dólares',
                audience_id: [62208, 62139],
                action: {
                    goto: 'step10_binary',
                },
            },
            {
                type: 'button',
                text: '250-$500',
                audience_id: [62207, 62138],
                action: {
                    goto: 'step9_man',
                },
            },
            {
                type: 'button',
                text: '500-$1000',
                audience_id: [62206, 62138],
                action: {
                    goto: 'step9_man',
                },
            },
            {
                type: 'button',
                text: 'más de 1000 dólares',
                audience_id: [62205, 62138],
                action: {
                    goto: 'step9_man',
                },
            },
        ],
    },
    step9_man: {
        type: 'question',
        text: '¿Tiene experiencia en el trading de Bitcoin?',
        options: [
            {
                type: 'button',
                text: 'No, nunca he oído hablar de él',
                audience_id: '62350',
                action: {
                    goto: 'step10',
                },
            },
            {
                type: 'button',
                text: 'No, pero quiero intentarlo',
                audience_id: '62351',
                action: {
                    goto: 'step10',
                },
            },
            {
                type: 'button',
                text: 'Sí, soy principiante',
                audience_id: '62352',
                action: {
                    goto: 'step10',
                },
            },
            {
                type: 'button',
                text: 'Sí, lo hago profesionalmente',
                audience_id: '62353',
                action: {
                    goto: 'step10',
                },
            },
        ],
    },
    step2_woman: {
        type: 'question',
        text: '¿Cuántos años tienes?',
        options: [
            {
                type: 'button',
                text: 'menos de 18 años',
                audience_id: [61421, 62386],
                action: {
                    redirect_url: SmartURL,
                    popunder_url: SmartURL,
                },
            },
            {
                type: 'button',
                text: '18-29 años',
                audience_id: [62180, 62382],
                action: {
                    goto: 'step5_woman',
                },
            },
            {
                type: 'button',
                text: '30-49 años',
                audience_id: [62181, 62383],
                action: {
                    goto: 'step5_woman',
                },
            },
            {
                type: 'button',
                text: '50-80 años',
                audience_id: [62182, 62384],
                action: {
                    goto: 'step5_woman',
                },
            },
        ],
    },
    step5_woman: {
        type: 'question',
        text: '¿Cómo te ganas la vida?',
        options: [
            {
                type: 'button',
                text: 'trabajo',
                audience_id: '62195',
                action: {
                    goto: 'step6_woman',
                },
            },
            {
                type: 'button',
                text: 'Soy autónomo',
                audience_id: '62210',
                action: {
                    goto: 'step6_woman',
                },
            },
            {
                type: 'button',
                text: 'Estoy desempleado',
                audience_id: '62197',
                action: {
                    goto: 'step6_woman',
                },
            },
            {
                type: 'button',
                text: 'Soy jubilado',
                audience_id: '62211',
                action: {
                    goto: 'step6_woman',
                },
            },
        ],
    },
    step6_woman: {
        type: 'question',
        text: '¿Cuál es su ingreso medio anual?',
        options: [
            {
                type: 'button',
                text: 'menos de 10.000 dólares',
                audience_id: '62201',
                action: {
                    goto: 'step7_woman',
                },
            },
            {
                type: 'button',
                text: '10.000 dólares a 30.000 dólares',
                audience_id: '62202',
                action: {
                    goto: 'step7_woman',
                },
            },
            {
                type: 'button',
                text: '30.000 dólares a 50.000 dólares',
                audience_id: '62200',
                action: {
                    goto: 'step7_woman',
                },
            },
            {
                type: 'button',
                text: 'más de 50.000 dólares',
                audience_id: '62203',
                action: {
                    goto: 'step7_woman',
                },
            },
        ],
    },
    step7_woman: {
        type: 'question',
        text: '¿Cuál es tu objetivo financiero para los próximos 5 años?',
        options: [
            {
                type: 'button',
                text: 'Vete de vacaciones en familia',
                audience_id: '62345',
                action: {
                    goto: 'step8_woman',
                },
            },
            {
                type: 'button',
                text: 'Compra un superdeportivo',
                audience_id: '62346',
                action: {
                    goto: 'step8_woman',
                },
            },
            {
                type: 'button',
                text: 'Compra un apartamento o una casa',
                audience_id: '62347',
                action: {
                    goto: 'step8_woman',
                },
            },
            {
                type: 'button',
                text: 'Iniciar mi propio negocio',
                audience_id: '62348',
                action: {
                    goto: 'step8_woman',
                },
            },
        ],
    },
    step8_woman: {
        type: 'question',
        text:
            '¿Cuánto invertiría ahora mismo para acercarse a su objetivo financiero mucho más rápido?',
        options: [
            {
                type: 'button',
                text: 'menos de 250 dólares',
                audience_id: [62208, 62141],
                action: {
                    goto: 'step10_binary',
                },
            },
            {
                type: 'button',
                text: '250-$500',
                audience_id: [62207, 62140],
                action: {
                    goto: 'step9_woman',
                },
            },
            {
                type: 'button',
                text: '500-$1000',
                audience_id: [62206, 62140],
                action: {
                    goto: 'step9_woman',
                },
            },
            {
                type: 'button',
                text: 'más de 1000 dólares',
                audience_id: [62205, 62140],
                action: {
                    goto: 'step9_woman',
                },
            },
        ],
    },
    step9_woman: {
        type: 'question',
        text: '¿Tiene experiencia en el trading de Bitcoin?',
        options: [
            {
                type: 'button',
                text: 'No, nunca he oído hablar de él',
                audience_id: '62350',
                action: {
                    goto: 'step10',
                },
            },
            {
                type: 'button',
                text: 'No, pero quiero intentarlo',
                audience_id: '62351',
                action: {
                    goto: 'step10',
                },
            },
            {
                type: 'button',
                text: 'Sí, soy principiante',
                audience_id: '62352',
                action: {
                    goto: 'step10',
                },
            },
            {
                type: 'button',
                text: 'Sí, lo hago profesionalmente',
                audience_id: '62353',
                action: {
                    goto: 'step10',
                },
            },
        ],
    },
    step10: {
        type: 'thank_you',
        text: 'GRACIAS!',
        content:
            '<div style="text-align: center; font-size:2rem"><p style="text-align: center; font-size:2rem; margin-bottom:2rem">Resultado de tu prueba: <span class="text--danger" style="font-weight:bold"><strong>EXCELENTE</strong></span> (35 de 35)</p> <p style="font-size:2rem;">Eres una persona ideal para ganar dinero online, <br>¡puedes ganar MUCHO MÁS DE <span class="text--danger" style="font-weight:bold"><strong>5.000 dólares</strong></span> diarios! <br>Hemos seleccionado para ti <span class="text--danger"><strong>4 ofertas</strong></span> para ganar dinero rápido en línea. <br>Sigue las instrucciones que aparecen a continuación y recibe tu oferta personal. <br>En 40 segundos serás redirigido a la mejor oferta (<span class="text--danger">más rentable para ti</span>). <br>Haz clic en el botón OBTENER OFERTA para ir a la mejor oferta de inmediato. </p></div>',
        timeout: 40,
        timeout_url: SmartURL,
        progress_title: '¿Harás más de 5.000 dólares diarios?',
        progress_texts: ['Espera... Verificación de respuestas', 'Espera... Contar tu puntuación'],
        progress_content: '',
        options: [
            {
                type: 'button',
                text: 'OBTENER OFERTA',
                audience_id: '61426',
                action: {
                    redirect_url: SmartURL,
                },
            },
        ],
    },
    step10_binary: {
        type: 'thank_you',
        text: 'GRACIAS!',
        content:
            '<div style="text-align: center; font-size:2rem;"><p style="text-align: center; font-size:2rem; margin-bottom:2rem">Resultado de tu prueba: <span class="text--danger" style="font-weight:bold"><strong>GENIAL</strong></span> (22 de 35)</p> <p style="font-size:2rem;">Eres una persona valiente, ¡la suerte está de tu lado! <span class="text--danger blink"><b>No pierdas la oportunidad</b></span> de ser más rico y rodearte de lujo. <br>En 40 segundos serás redirigido a la mejor oferta (<span class="text--danger">más rentable para ti</span>). <br>Haz clic en el botón OBTENER OFERTA para ir a la mejor oferta de inmediato. </p></div>',
        timeout: 40,
        timeout_url: SmartURL,
        progress_title: '¿Harás más de 5.000 dólares diarios?',
        progress_texts: ['Espera... Verificación de respuestas', 'Espera... Contar tu puntuación'],
        progress_content: '',
        options: [
            {
                type: 'button',
                text: 'OBTENER OFERTA',
                audience_id: '61426',
                action: {
                    redirect_url: SmartURL,
                },
            },
        ],
    },
};
