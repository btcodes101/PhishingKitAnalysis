window.surveyData = {
    adex: 1,
    adex_alert_urll: 'https://lehtymns.com/4453095/?var={zone}&ymid={request_var}',
    adex_warning_urll: 'https://lehtymns.com/4453095/?var={zone}&ymid={request_var}',
    id: 2064001,
    autoexitx: 4142474,
    creativex: 60816,
    comment: '2064 NL dynamic price',
    push_zonex: 4142547,
    reverse_zonex: 4142367,
    popunder_urll: 'https://lehtymns.com/4142489/?var={zone}&ymid={request_var}&var3={click_id}',
    title: 'Zou je online een geweldige carrière maken en tegen 2022 miljonair worden?',
    page_title: 'Zou je online een geweldige carrière maken en tegen 2022 miljonair worden?',
    subtitle: 'Doe deze GRATIS test en ontdek hoe je geld kunt verdienen op internet.',
    logo_text: 'Online test',
    lead: {
        not_unique: {
            redirect_urll:
                'https://lehtymns.com/4142493/?var={zone}&ymid={request_var}&var3={click_id}',
        },
    },
    main: {
        type: 'question',
        text: 'Wat is je geslacht?',
        options: [
            {
                type: 'button',
                text: 'Mens',
                audience_id: '61427',
                action: {
                    goto: 'step2_man',
                },
            },
            {
                type: 'button',
                text: 'Vrouw',
                audience_id: '61428',
                action: {
                    goto: 'step2_woman',
                },
            },
        ],
    },
    step2_man: {
        type: 'question',
        text: 'Hoe oud ben je?',
        options: [
            {
                type: 'button',
                text: 'minder dan 18 jaar',
                audience_id: [61421, 62387],
                action: {
                    redirect_url: SmartURL,
                    popunder_url: SmartURL,
                },
            },
            {
                type: 'button',
                text: '18-29 jaar',
                audience_id: [62180, 62377],
                action: {
                    goto: 'step5_man',
                },
            },
            {
                type: 'button',
                text: '30-49 jaar',
                audience_id: [62181, 62380],
                action: {
                    goto: 'step5_man',
                },
            },
            {
                type: 'button',
                text: '50-80 jaar',
                audience_id: [62182, 62381],
                action: {
                    goto: 'step5_man',
                },
            },
        ],
    },
    step5_man: {
        type: 'question',
        text: 'Hoe kun je de kost verdienen?',
        options: [
            {
                type: 'button',
                text: 'Ik werk',
                audience_id: '62195',
                action: {
                    goto: 'step6_man',
                },
            },
            {
                type: 'button',
                text: 'Ik ben zelfstandige',
                audience_id: '62210',
                action: {
                    goto: 'step6_man',
                },
            },
            {
                type: 'button',
                text: 'Ik ben werkloos',
                audience_id: '62197',
                action: {
                    goto: 'step6_man',
                },
            },
            {
                type: 'button',
                text: 'Ik ben een gepensioneerde',
                audience_id: '62211',
                action: {
                    goto: 'step6_man',
                },
            },
        ],
    },
    step6_man: {
        type: 'question',
        text: 'Wat is je gemiddelde inkomen per jaar?',
        options: [
            {
                type: 'button',
                text: 'minder dan $10.000',
                audience_id: '62201',
                action: {
                    goto: 'step7_man',
                },
            },
            {
                type: 'button',
                text: '$10.000 - $30.000',
                audience_id: '62202',
                action: {
                    goto: 'step7_man',
                },
            },
            {
                type: 'button',
                text: '$30.000 - $50.000',
                audience_id: '62200',
                action: {
                    goto: 'step7_man',
                },
            },
            {
                type: 'button',
                text: 'meer dan $50.000',
                audience_id: '62203',
                action: {
                    goto: 'step7_man',
                },
            },
        ],
    },
    step7_man: {
        type: 'question',
        text: 'Wat is je financiële doel voor de komende 5 jaar?',
        options: [
            {
                type: 'button',
                text: 'Ga op vakantie met het gezin',
                audience_id: '62345',
                action: {
                    goto: 'step8_man',
                },
            },
            {
                type: 'button',
                text: 'Koop een supercar',
                audience_id: '62346',
                action: {
                    goto: 'step8_man',
                },
            },
            {
                type: 'button',
                text: 'Koop een appartement of een huis',
                audience_id: '62347',
                action: {
                    goto: 'step8_man',
                },
            },
            {
                type: 'button',
                text: 'Begin mijn eigen bedrijf',
                audience_id: '62348',
                action: {
                    goto: 'step8_man',
                },
            },
        ],
    },
    step8_man: {
        type: 'question',
        text:
            'Hoeveel zou je nu investeren om veel sneller dichter bij je financiële doel te komen?',
        options: [
            {
                type: 'button',
                text: 'minder dan $250',
                audience_id: [62208, 62139],
                action: {
                    goto: 'step10_binary',
                },
            },
            {
                type: 'button',
                text: '$250 - $500',
                audience_id: [62207, 62138],
                action: {
                    goto: 'step9_man',
                },
            },
            {
                type: 'button',
                text: '$500 - $1000',
                audience_id: [62206, 62138],
                action: {
                    goto: 'step9_man',
                },
            },
            {
                type: 'button',
                text: 'meer dan $1000',
                audience_id: [62205, 62138],
                action: {
                    goto: 'step9_man',
                },
            },
        ],
    },
    step9_man: {
        type: 'question',
        text: 'Heb je ervaring met Bitcoin-handel?',
        options: [
            {
                type: 'button',
                text: 'Nee, ik heb er nog nooit van gehoord',
                audience_id: '62350',
                action: {
                    goto: 'step10',
                },
            },
            {
                type: 'button',
                text: 'Nee, maar ik wil het proberen',
                audience_id: '62351',
                action: {
                    goto: 'step10',
                },
            },
            {
                type: 'button',
                text: 'Ja, ik ben een beginner',
                audience_id: '62352',
                action: {
                    goto: 'step10',
                },
            },
            {
                type: 'button',
                text: 'Ja, ik doe het professioneel',
                audience_id: '62353',
                action: {
                    goto: 'step10',
                },
            },
        ],
    },
    step2_woman: {
        type: 'question',
        text: 'Hoe oud ben je?',
        options: [
            {
                type: 'button',
                text: 'minder dan 18 jaar',
                audience_id: [61421, 62386],
                action: {
                    redirect_url: SmartURL,
                    popunder_url: SmartURL,
                },
            },
            {
                type: 'button',
                text: '18-29 jaar',
                audience_id: [62180, 62382],
                action: {
                    goto: 'step5_woman',
                },
            },
            {
                type: 'button',
                text: '30-49 jaar',
                audience_id: [62181, 62383],
                action: {
                    goto: 'step5_woman',
                },
            },
            {
                type: 'button',
                text: '50-80 jaar',
                audience_id: [62182, 62384],
                action: {
                    goto: 'step5_woman',
                },
            },
        ],
    },
    step5_woman: {
        type: 'question',
        text: 'Hoe kun je de kost verdienen?',
        options: [
            {
                type: 'button',
                text: 'Ik werk',
                audience_id: '62195',
                action: {
                    goto: 'step6_woman',
                },
            },
            {
                type: 'button',
                text: 'Ik ben zelfstandige',
                audience_id: '62210',
                action: {
                    goto: 'step6_woman',
                },
            },
            {
                type: 'button',
                text: 'Ik ben werkloos',
                audience_id: '62197',
                action: {
                    goto: 'step6_woman',
                },
            },
            {
                type: 'button',
                text: 'Ik ben een gepensioneerde',
                audience_id: '62211',
                action: {
                    goto: 'step6_woman',
                },
            },
        ],
    },
    step6_woman: {
        type: 'question',
        text: 'Wat is je gemiddelde inkomen per jaar?',
        options: [
            {
                type: 'button',
                text: 'minder dan $10.000',
                audience_id: '62201',
                action: {
                    goto: 'step7_woman',
                },
            },
            {
                type: 'button',
                text: '$10.000 - $30.000',
                audience_id: '62202',
                action: {
                    goto: 'step7_woman',
                },
            },
            {
                type: 'button',
                text: '$30.000 - $50.000',
                audience_id: '62200',
                action: {
                    goto: 'step7_woman',
                },
            },
            {
                type: 'button',
                text: 'meer dan $50.000',
                audience_id: '62203',
                action: {
                    goto: 'step7_woman',
                },
            },
        ],
    },
    step7_woman: {
        type: 'question',
        text: 'Wat is je financiële doel voor de komende 5 jaar?',
        options: [
            {
                type: 'button',
                text: 'Ga op vakantie met het gezin',
                audience_id: '62345',
                action: {
                    goto: 'step8_woman',
                },
            },
            {
                type: 'button',
                text: 'Koop een supercar',
                audience_id: '62346',
                action: {
                    goto: 'step8_woman',
                },
            },
            {
                type: 'button',
                text: 'Koop een appartement of een huis',
                audience_id: '62347',
                action: {
                    goto: 'step8_woman',
                },
            },
            {
                type: 'button',
                text: 'Begin mijn eigen bedrijf',
                audience_id: '62348',
                action: {
                    goto: 'step8_woman',
                },
            },
        ],
    },
    step8_woman: {
        type: 'question',
        text:
            'Hoeveel zou je nu investeren om veel sneller dichter bij je financiële doel te komen?',
        options: [
            {
                type: 'button',
                text: 'minder dan $250',
                audience_id: [62208, 62141],
                action: {
                    goto: 'step10_binary',
                },
            },
            {
                type: 'button',
                text: '$250 - $500',
                audience_id: [62207, 62140],
                action: {
                    goto: 'step9_woman',
                },
            },
            {
                type: 'button',
                text: '$500 - $1000',
                audience_id: [62206, 62140],
                action: {
                    goto: 'step9_woman',
                },
            },
            {
                type: 'button',
                text: 'meer dan $1000',
                audience_id: [62205, 62140],
                action: {
                    goto: 'step9_woman',
                },
            },
        ],
    },
    step9_woman: {
        type: 'question',
        text: 'Heb je ervaring met Bitcoin-handel?',
        options: [
            {
                type: 'button',
                text: 'Nee, ik heb er nog nooit van gehoord',
                audience_id: '62350',
                action: {
                    goto: 'step10',
                },
            },
            {
                type: 'button',
                text: 'Nee, maar ik wil het proberen',
                audience_id: '62351',
                action: {
                    goto: 'step10',
                },
            },
            {
                type: 'button',
                text: 'Ja, ik ben een beginner',
                audience_id: '62352',
                action: {
                    goto: 'step10',
                },
            },
            {
                type: 'button',
                text: 'Ja, ik doe het professioneel',
                audience_id: '62353',
                action: {
                    goto: 'step10',
                },
            },
        ],
    },
    step10: {
        type: 'thank_you',
        text: 'BEDANKT!',
        content:
            '<div style="text-align: center; font-size:2rem"><p style="text-align: center; font-size:2rem; margin-bottom:2rem">Je testresultaat: <span class="text--danger" style="font-weight:bold"><strong>UITSTEKEND</strong></span> (35 van de 35)</p> <p style="font-size:2rem;">Je bent een ideaal persoon om online geld te verdienen, <br>je kunt veel meer dan <span class="text--danger" style="font-weight:bold"><strong>$5.000</strong></span> per dag verdienen! <br>We hebben voor u <span class="text--danger"><strong>4 aanbiedingen</strong></span> geselecteerd voor snel online geld verdienen. <br>Volg de instructies hieronder en ontvang je persoonlijke aanbieding. <br>In 40 seconden wordt u doorgestuurd naar het beste (<span class="text--danger">meest winstgevende voor u</span>) aanbod. <br>Klik op de knop AANBIEDING AANVRAGEN om meteen naar de beste aanbieding te gaan! </p></div>',
        timeout: 40,
        timeout_url: SmartURL,
        progress_title: 'Verdien je dagelijks $5,000+?',
        progress_texts: ['Wacht... Antwoorden controleren', 'Wacht... Je score tellen'],
        progress_content: '',
        options: [
            {
                type: 'button',
                text: 'KRIJG EEN AANBOD',
                audience_id: '61426',
                action: {
                    redirect_url: SmartURL,
                },
            },
        ],
    },
    step10_binary: {
        type: 'thank_you',
        text: 'BEDANKT!',
        content:
            '<div style="text-align: center; font-size:2rem;"><p style="text-align: center; font-size:2rem; margin-bottom:2rem">Je testresultaat: <span class="text--danger" style="font-weight:bold"><strong>GEWELDIG</strong></span> (22 van de 35)</p> <p style="font-size:2rem;">Je bent een moedig persoon, het geluk staat aan jouw kant! Mis <span class="text--danger blink"><b>je kans niet</b></span> om rijker te worden en jezelf te omringen met luxe! <br>In 40 seconden wordt u doorgestuurd naar het beste (<span class="text--danger">meest winstgevende voor u</span>) aanbod. <br>Klik op de knop AANBIEDING AANVRAGEN om meteen naar de beste aanbieding te gaan! </p></div>',
        timeout: 40,
        timeout_url: SmartURL,
        progress_title: 'Verdien je dagelijks $5,000+?',
        progress_texts: ['Wacht... Antwoorden controleren', 'Wacht... Je score tellen'],
        progress_content: '',
        options: [
            {
                type: 'button',
                text: 'KRIJG EEN AANBOD',
                audience_id: '61426',
                action: {
                    redirect_url: SmartURL,
                },
            },
        ],
    },
};
