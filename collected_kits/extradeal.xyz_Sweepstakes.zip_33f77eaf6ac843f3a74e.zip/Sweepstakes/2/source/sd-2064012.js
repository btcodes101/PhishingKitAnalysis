window.surveyData = {
    adex: 1,
    adex_alert_urll: 'https://lehtymns.com/4453095/?var={zone}&ymid={request_var}',
    adex_warning_urll: 'https://lehtymns.com/4453095/?var={zone}&ymid={request_var}',
    id: 2064001,
    autoexitx: 4142474,
    creativex: 60816,
    comment: '2064 TH dynamic price',
    push_zonex: 4142547,
    reverse_zonex: 4142367,
    popunder_urll: 'https://lehtymns.com/4142489/?var={zone}&ymid={request_var}&var3={click_id}',
    title: 'คุณจะสร้างอาชีพออนไลน์อันยิ่งใหญ่และกลายเป็นเศรษฐีภายในปี 2022 หรือไม่?',
    page_title: 'คุณจะสร้างอาชีพออนไลน์อันยิ่งใหญ่และกลายเป็นเศรษฐีภายในปี 2022 หรือไม่?',
    subtitle: 'ทำการทดสอบฟรีนี้และพบคำตอบว่าคุณจะสามารถทำเงินบนอินเทอร์เน็ตได้อย่างไร',
    logo_text: 'การทดสอบออนไลน์',
    lead: {
        not_unique: {
            redirect_urll:
                'https://lehtymns.com/4142493/?var={zone}&ymid={request_var}&var3={click_id}',
        },
    },
    main: {
        type: 'question',
        text: 'โปรดระบุเพศของคุณ',
        options: [
            {
                type: 'button',
                text: 'ผู้ชาย',
                audience_id: '61427',
                action: {
                    goto: 'step2_man',
                },
            },
            {
                type: 'button',
                text: 'ผู้หญิง',
                audience_id: '61428',
                action: {
                    goto: 'step2_woman',
                },
            },
        ],
    },
    step2_man: {
        type: 'question',
        text: 'คุณมีอายุเท่าไร?',
        options: [
            {
                type: 'button',
                text: 'น้อยกว่า 18 ปี',
                audience_id: [61421, 62387],
                action: {
                    redirect_url: SmartURL,
                    popunder_url: SmartURL,
                },
            },
            {
                type: 'button',
                text: 'อายุระหว่าง 18-29 ปี',
                audience_id: [62180, 62377],
                action: {
                    goto: 'step5_man',
                },
            },
            {
                type: 'button',
                text: 'อายุระหว่าง 30-49 ปี',
                audience_id: [62181, 62380],
                action: {
                    goto: 'step5_man',
                },
            },
            {
                type: 'button',
                text: 'อายุระหว่าง 50-80 ปี',
                audience_id: [62182, 62381],
                action: {
                    goto: 'step5_man',
                },
            },
        ],
    },
    step5_man: {
        type: 'question',
        text: 'คุณจะหาเงินเลี้ยงชีพได้อย่างไร?',
        options: [
            {
                type: 'button',
                text: 'ฉันทำงาน',
                audience_id: '62195',
                action: {
                    goto: 'step6_man',
                },
            },
            {
                type: 'button',
                text: 'ฉันทำงานอิสระ',
                audience_id: '62210',
                action: {
                    goto: 'step6_man',
                },
            },
            {
                type: 'button',
                text: 'ฉันว่างงาน',
                audience_id: '62197',
                action: {
                    goto: 'step6_man',
                },
            },
            {
                type: 'button',
                text: 'ฉันเป็นผู้รับบำนาญ',
                audience_id: '62211',
                action: {
                    goto: 'step6_man',
                },
            },
        ],
    },
    step6_man: {
        type: 'question',
        text: 'คุณมีรายได้เฉลี่ยต่อปีเท่าไร?',
        options: [
            {
                type: 'button',
                text: 'น้อยกว่า $10,000',
                audience_id: '62201',
                action: {
                    goto: 'step7_man',
                },
            },
            {
                type: 'button',
                text: '$10,000-$30,000',
                audience_id: '62202',
                action: {
                    goto: 'step7_man',
                },
            },
            {
                type: 'button',
                text: '$30,000-$50,000',
                audience_id: '62200',
                action: {
                    goto: 'step7_man',
                },
            },
            {
                type: 'button',
                text: 'มากกว่า $50,000',
                audience_id: '62203',
                action: {
                    goto: 'step7_man',
                },
            },
        ],
    },
    step7_man: {
        type: 'question',
        text: 'เป้าหมายทางการเงินของคุณใน 5 ปีข้างหน้าคืออะไร?',
        options: [
            {
                type: 'button',
                text: 'ไปเที่ยววันหยุดกับครอบครัว',
                audience_id: '62345',
                action: {
                    goto: 'step8_man',
                },
            },
            {
                type: 'button',
                text: 'ซื้อรถซูเปอร์คาร์',
                audience_id: '62346',
                action: {
                    goto: 'step8_man',
                },
            },
            {
                type: 'button',
                text: 'ซื้ออะพาร์ตเมนต์ หรือบ้าน',
                audience_id: '62347',
                action: {
                    goto: 'step8_man',
                },
            },
            {
                type: 'button',
                text: 'เริ่มทำธุรกิจของฉันเอง',
                audience_id: '62348',
                action: {
                    goto: 'step8_man',
                },
            },
        ],
    },
    step8_man: {
        type: 'question',
        text: 'ตอนนี้คุณจะลงทุนเป็นเงินจำนวนเท่าไรเพื่อให้เข้าใกล้เป้าหมายทางการเงินของคุณได้เร็วขึ้น?',
        options: [
            {
                type: 'button',
                text: 'น้อยกว่า $250',
                audience_id: [62208, 62139],
                action: {
                    goto: 'step10_binary',
                },
            },
            {
                type: 'button',
                text: '$250-$500',
                audience_id: [62207, 62138],
                action: {
                    goto: 'step9_man',
                },
            },
            {
                type: 'button',
                text: '$500-$1000',
                audience_id: [62206, 62138],
                action: {
                    goto: 'step9_man',
                },
            },
            {
                type: 'button',
                text: 'มากกว่า $1000',
                audience_id: [62205, 62138],
                action: {
                    goto: 'step9_man',
                },
            },
        ],
    },
    step9_man: {
        type: 'question',
        text: 'คุณมีประสบการณ์ในการซื้อขายบิทคอยน์หรือไม่?',
        options: [
            {
                type: 'button',
                text: 'ไม่ ฉันไม่เคยได้ยินเกี่ยวกับมัน',
                audience_id: '62350',
                action: {
                    goto: 'step10',
                },
            },
            {
                type: 'button',
                text: 'ไม่ แต่ฉันต้องการลอง',
                audience_id: '62351',
                action: {
                    goto: 'step10',
                },
            },
            {
                type: 'button',
                text: 'ใช่ ฉันเป็นมือใหม่',
                audience_id: '62352',
                action: {
                    goto: 'step10',
                },
            },
            {
                type: 'button',
                text: 'ใช่ ฉันทำมันอย่างมืออาชีพ',
                audience_id: '62353',
                action: {
                    goto: 'step10',
                },
            },
        ],
    },
    step2_woman: {
        type: 'question',
        text: 'คุณมีอายุเท่าไร?',
        options: [
            {
                type: 'button',
                text: 'น้อยกว่า 18 ปี',
                audience_id: [61421, 62386],
                action: {
                    redirect_url: SmartURL,
                    popunder_url: SmartURL,
                },
            },
            {
                type: 'button',
                text: 'อายุระหว่าง 18-29 ปี',
                audience_id: [62180, 62382],
                action: {
                    goto: 'step5_woman',
                },
            },
            {
                type: 'button',
                text: 'อายุระหว่าง 30-49 ปี',
                audience_id: [62181, 62383],
                action: {
                    goto: 'step5_woman',
                },
            },
            {
                type: 'button',
                text: 'อายุระหว่าง 50-80 ปี',
                audience_id: [62182, 62384],
                action: {
                    goto: 'step5_woman',
                },
            },
        ],
    },
    step5_woman: {
        type: 'question',
        text: 'คุณจะหาเงินเลี้ยงชีพได้อย่างไร?',
        options: [
            {
                type: 'button',
                text: 'ฉันทำงาน',
                audience_id: '62195',
                action: {
                    goto: 'step6_woman',
                },
            },
            {
                type: 'button',
                text: 'ฉันทำงานอิสระ',
                audience_id: '62210',
                action: {
                    goto: 'step6_woman',
                },
            },
            {
                type: 'button',
                text: 'ฉันว่างงาน',
                audience_id: '62197',
                action: {
                    goto: 'step6_woman',
                },
            },
            {
                type: 'button',
                text: 'ฉันเป็นผู้รับบำนาญ',
                audience_id: '62211',
                action: {
                    goto: 'step6_woman',
                },
            },
        ],
    },
    step6_woman: {
        type: 'question',
        text: 'คุณมีรายได้เฉลี่ยต่อปีเท่าไร?',
        options: [
            {
                type: 'button',
                text: 'น้อยกว่า $10,000',
                audience_id: '62201',
                action: {
                    goto: 'step7_woman',
                },
            },
            {
                type: 'button',
                text: '$10,000-$30,000',
                audience_id: '62202',
                action: {
                    goto: 'step7_woman',
                },
            },
            {
                type: 'button',
                text: '$30,000-$50,000',
                audience_id: '62200',
                action: {
                    goto: 'step7_woman',
                },
            },
            {
                type: 'button',
                text: 'มากกว่า $50,000',
                audience_id: '62203',
                action: {
                    goto: 'step7_woman',
                },
            },
        ],
    },
    step7_woman: {
        type: 'question',
        text: 'เป้าหมายทางการเงินของคุณใน 5 ปีข้างหน้าคืออะไร?',
        options: [
            {
                type: 'button',
                text: 'ไปเที่ยววันหยุดกับครอบครัว',
                audience_id: '62345',
                action: {
                    goto: 'step8_woman',
                },
            },
            {
                type: 'button',
                text: 'ซื้อรถซูเปอร์คาร์',
                audience_id: '62346',
                action: {
                    goto: 'step8_woman',
                },
            },
            {
                type: 'button',
                text: 'ซื้ออะพาร์ตเมนต์ หรือบ้าน',
                audience_id: '62347',
                action: {
                    goto: 'step8_woman',
                },
            },
            {
                type: 'button',
                text: 'เริ่มทำธุรกิจของฉันเอง',
                audience_id: '62348',
                action: {
                    goto: 'step8_woman',
                },
            },
        ],
    },
    step8_woman: {
        type: 'question',
        text: 'ตอนนี้คุณจะลงทุนเป็นเงินจำนวนเท่าไรเพื่อให้เข้าใกล้เป้าหมายทางการเงินของคุณได้เร็วขึ้น?',
        options: [
            {
                type: 'button',
                text: 'น้อยกว่า $250',
                audience_id: [62208, 62141],
                action: {
                    goto: 'step10_binary',
                },
            },
            {
                type: 'button',
                text: '$250-$500',
                audience_id: [62207, 62140],
                action: {
                    goto: 'step9_woman',
                },
            },
            {
                type: 'button',
                text: '$500-$1000',
                audience_id: [62206, 62140],
                action: {
                    goto: 'step9_woman',
                },
            },
            {
                type: 'button',
                text: 'มากกว่า $1000',
                audience_id: [62205, 62140],
                action: {
                    goto: 'step9_woman',
                },
            },
        ],
    },
    step9_woman: {
        type: 'question',
        text: 'คุณมีประสบการณ์ในการซื้อขายบิทคอยน์หรือไม่?',
        options: [
            {
                type: 'button',
                text: 'ไม่ ฉันไม่เคยได้ยินเกี่ยวกับมัน',
                audience_id: '62350',
                action: {
                    goto: 'step10',
                },
            },
            {
                type: 'button',
                text: 'ไม่ แต่ฉันต้องการลอง',
                audience_id: '62351',
                action: {
                    goto: 'step10',
                },
            },
            {
                type: 'button',
                text: 'ใช่ ฉันเป็นมือใหม่',
                audience_id: '62352',
                action: {
                    goto: 'step10',
                },
            },
            {
                type: 'button',
                text: 'ใช่ ฉันทำมันอย่างมืออาชีพ',
                audience_id: '62353',
                action: {
                    goto: 'step10',
                },
            },
        ],
    },
    step10: {
        type: 'thank_you',
        text: 'ขอบคุณ!',
        content:
            '<div style="text-align: center; font-size:2rem"><p style="text-align: center; font-size:2rem; margin-bottom:2rem">ผลการทดสอบของคุณ: <span class="text--danger" style="font-weight:bold"><strong>ดีเยี่ยม</strong></span> (ได้ 35 จากทั้งหมด 35)</p><p style="font-size:2rem;">คุณเป็นคนที่เหมาะสำหรับการทำเงินออนไลน์<br>คุณสามารถสร้างรายได้มากกว่า <span class="text--danger" style="font-weight:bold"><strong>$5,000</strong></span> ต่อวัน!<br> เราได้เลือกสำหรับคุณ <span class="text--danger"><strong>4 ข้อเสนอ</strong></span> สำหรับการทำเงินออนไลน์ได้อย่างรวดเร็ว.<br> ทำตามคำแนะนำด้านล่าง และรับข้อเสนอส่วนตัวของคุณ<br> ใน 40 วินาทีคุณจะถูกเปลี่ยนเส้นทางไปยังข้อเสนอที่ดีที่สุด (มี<span class="text--danger">กำไรมากที่สุดสำหรับคุณ</span>)<br> คลิกปุ่ม รับข้อเสนอ เพื่อไปยังข้อเสนอที่ดีที่สุดในทันที!</p></div>',
        timeout: 40,
        timeout_url: SmartURL,
        progress_title: 'คุณจะทำเงินได้มากกว่า $5,000 ต่อวัน?',
        progress_texts: ['เดี๋ยว...กำลังตรวจสอบคำตอบ', 'เดี๋ยว...การนับคะแนนของคุณ'],
        progress_content: '',
        options: [
            {
                type: 'button',
                text: 'รับข้อเสนอ',
                audience_id: '61426',
                action: {
                    redirect_url: SmartURL,
                },
            },
        ],
    },
    step10_binary: {
        type: 'thank_you',
        text: 'ขอบคุณ!',
        content:
            '<div style="text-align: center; font-size:2rem;"><p style="text-align: center; font-size:2rem; margin-bottom:2rem">ผลการทดสอบของคุณ: <span class="text--danger" style="font-weight:bold"><strong>G</strong></span> EAT (22 จาก 35)</p><p style="font-size:2rem;">คุณเป็นคนที่กล้าหาญโชคอยู่ข้างคุณ!<span class="text--danger blink"><b>อย่าพลาดโอกาสที่คุณ</b></span> จะได้รับความร่ำรวยและล้อมรอบตัวคุณด้วยความหรูหรา!<br> ใน 40 วินาทีคุณจะถูกเปลี่ยนเส้นทางไปยังข้อเสนอที่ดีที่สุด (มี<span class="text--danger">กำไรมากที่สุดสำหรับคุณ</span>)<br> คลิกปุ่ม รับข้อเสนอ เพื่อไปยังข้อเสนอที่ดีที่สุดในทันที!</p></div>',
        timeout: 40,
        timeout_url: SmartURL,
        progress_title: 'คุณจะทำเงินได้มากกว่า $5,000 ต่อวัน?',
        progress_texts: ['เดี๋ยว...กำลังตรวจสอบคำตอบ', 'เดี๋ยว...การนับคะแนนของคุณ'],
        progress_content: '',
        options: [
            {
                type: 'button',
                text: 'รับข้อเสนอ',
                audience_id: '61426',
                action: {
                    redirect_url: SmartURL,
                },
            },
        ],
    },
};
