window.surveyData = {
    adex: 1,
    adex_alert_urll: 'https://lehtymns.com/4453095/?var={zone}&ymid={request_var}',
    adex_warning_urll: 'https://lehtymns.com/4453095/?var={zone}&ymid={request_var}',
    id: 2064001,
    autoexitx: 4142474,
    creativex: 60816,
    comment: '2064 IT dynamic price',
    push_zonex: 4142547,
    reverse_zonex: 4142367,
    popunder_urll: 'https://lehtymns.com/4142489/?var={zone}&ymid={request_var}&var3={click_id}',
    title: 'Fai una grande carriera online e diventeresti milionario entro il 2022?',
    page_title: 'Fai una grande carriera online e diventeresti milionario entro il 2022?',
    subtitle: 'Fai questo test GRATUITO e scopri come guadagnare denaro su Internet.',
    logo_text: 'Test online',
    lead: {
        not_unique: {
            redirect_urll:
                'https://lehtymns.com/4142493/?var={zone}&ymid={request_var}&var3={click_id}',
        },
    },
    main: {
        type: 'question',
        text: 'Qual è il tuo genere?',
        options: [
            {
                type: 'button',
                text: 'Uomo',
                audience_id: '61427',
                action: {
                    goto: 'step2_man',
                },
            },
            {
                type: 'button',
                text: 'Donna',
                audience_id: '61428',
                action: {
                    goto: 'step2_woman',
                },
            },
        ],
    },
    step2_man: {
        type: 'question',
        text: 'Quanti anni hai?',
        options: [
            {
                type: 'button',
                text: 'meno di 18 anni',
                audience_id: [61421, 62387],
                action: {
                    redirect_url: SmartURL,
                    popunder_url: SmartURL,
                },
            },
            {
                type: 'button',
                text: '18-29 anni',
                audience_id: [62180, 62377],
                action: {
                    goto: 'step5_man',
                },
            },
            {
                type: 'button',
                text: '30-49 anni',
                audience_id: [62181, 62380],
                action: {
                    goto: 'step5_man',
                },
            },
            {
                type: 'button',
                text: '50-80 anni',
                audience_id: [62182, 62381],
                action: {
                    goto: 'step5_man',
                },
            },
        ],
    },
    step5_man: {
        type: 'question',
        text: 'Come fai a guadagnarti da vivere?',
        options: [
            {
                type: 'button',
                text: 'Lavoro',
                audience_id: '62195',
                action: {
                    goto: 'step6_man',
                },
            },
            {
                type: 'button',
                text: 'Sono un lavoratore autonomo',
                audience_id: '62210',
                action: {
                    goto: 'step6_man',
                },
            },
            {
                type: 'button',
                text: 'Sono disoccupato',
                audience_id: '62197',
                action: {
                    goto: 'step6_man',
                },
            },
            {
                type: 'button',
                text: 'Sono un pensionato',
                audience_id: '62211',
                action: {
                    goto: 'step6_man',
                },
            },
        ],
    },
    step6_man: {
        type: 'question',
        text: 'Qual è il tuo reddito medio annuo?',
        options: [
            {
                type: 'button',
                text: 'meno di $10.000',
                audience_id: '62201',
                action: {
                    goto: 'step7_man',
                },
            },
            {
                type: 'button',
                text: '$10.000-$30.000',
                audience_id: '62202',
                action: {
                    goto: 'step7_man',
                },
            },
            {
                type: 'button',
                text: '$30.000-$50.000',
                audience_id: '62200',
                action: {
                    goto: 'step7_man',
                },
            },
            {
                type: 'button',
                text: 'più di $50.000',
                audience_id: '62203',
                action: {
                    goto: 'step7_man',
                },
            },
        ],
    },
    step7_man: {
        type: 'question',
        text: 'Qual è il tuo obiettivo finanziario per i prossimi 5 anni?',
        options: [
            {
                type: 'button',
                text: 'Vai in vacanza con la famiglia',
                audience_id: '62345',
                action: {
                    goto: 'step8_man',
                },
            },
            {
                type: 'button',
                text: 'Acquista una supercar',
                audience_id: '62346',
                action: {
                    goto: 'step8_man',
                },
            },
            {
                type: 'button',
                text: 'Acquista un appartamento o una casa',
                audience_id: '62347',
                action: {
                    goto: 'step8_man',
                },
            },
            {
                type: 'button',
                text: 'Inizia la mia attività',
                audience_id: '62348',
                action: {
                    goto: 'step8_man',
                },
            },
        ],
    },
    step8_man: {
        type: 'question',
        text:
            'Quanto investiresti ora per avvicinarti al tuo obiettivo finanziario molto più velocemente?',
        options: [
            {
                type: 'button',
                text: 'meno di $250',
                audience_id: [62208, 62139],
                action: {
                    goto: 'step10_binary',
                },
            },
            {
                type: 'button',
                text: '$250-$500',
                audience_id: [62207, 62138],
                action: {
                    goto: 'step9_man',
                },
            },
            {
                type: 'button',
                text: '$500-$1000',
                audience_id: [62206, 62138],
                action: {
                    goto: 'step9_man',
                },
            },
            {
                type: 'button',
                text: 'più di $1000',
                audience_id: [62205, 62138],
                action: {
                    goto: 'step9_man',
                },
            },
        ],
    },
    step9_man: {
        type: 'question',
        text: 'Hai esperienza nel trading di Bitcoin?',
        options: [
            {
                type: 'button',
                text: 'No, non ne ho mai sentito parlare',
                audience_id: '62350',
                action: {
                    goto: 'step10',
                },
            },
            {
                type: 'button',
                text: 'No, ma voglio provare',
                audience_id: '62351',
                action: {
                    goto: 'step10',
                },
            },
            {
                type: 'button',
                text: 'Sì, sono un principiante',
                audience_id: '62352',
                action: {
                    goto: 'step10',
                },
            },
            {
                type: 'button',
                text: 'Sì, lo faccio professionalmente',
                audience_id: '62353',
                action: {
                    goto: 'step10',
                },
            },
        ],
    },
    step2_woman: {
        type: 'question',
        text: 'Quanti anni hai?',
        options: [
            {
                type: 'button',
                text: 'meno di 18 anni',
                audience_id: [61421, 62386],
                action: {
                    redirect_url: SmartURL,
                    popunder_url: SmartURL,
                },
            },
            {
                type: 'button',
                text: '18-29 anni',
                audience_id: [62180, 62382],
                action: {
                    goto: 'step5_woman',
                },
            },
            {
                type: 'button',
                text: '30-49 anni',
                audience_id: [62181, 62383],
                action: {
                    goto: 'step5_woman',
                },
            },
            {
                type: 'button',
                text: '50-80 anni',
                audience_id: [62182, 62384],
                action: {
                    goto: 'step5_woman',
                },
            },
        ],
    },
    step5_woman: {
        type: 'question',
        text: 'Come fai a guadagnarti da vivere?',
        options: [
            {
                type: 'button',
                text: 'Lavoro',
                audience_id: '62195',
                action: {
                    goto: 'step6_woman',
                },
            },
            {
                type: 'button',
                text: 'Sono un lavoratore autonomo',
                audience_id: '62210',
                action: {
                    goto: 'step6_woman',
                },
            },
            {
                type: 'button',
                text: 'Sono disoccupato',
                audience_id: '62197',
                action: {
                    goto: 'step6_woman',
                },
            },
            {
                type: 'button',
                text: 'Sono un pensionato',
                audience_id: '62211',
                action: {
                    goto: 'step6_woman',
                },
            },
        ],
    },
    step6_woman: {
        type: 'question',
        text: 'Qual è il tuo reddito medio annuo?',
        options: [
            {
                type: 'button',
                text: 'meno di $10.000',
                audience_id: '62201',
                action: {
                    goto: 'step7_woman',
                },
            },
            {
                type: 'button',
                text: '$10.000-$30.000',
                audience_id: '62202',
                action: {
                    goto: 'step7_woman',
                },
            },
            {
                type: 'button',
                text: '$30.000-$50.000',
                audience_id: '62200',
                action: {
                    goto: 'step7_woman',
                },
            },
            {
                type: 'button',
                text: 'più di $50.000',
                audience_id: '62203',
                action: {
                    goto: 'step7_woman',
                },
            },
        ],
    },
    step7_woman: {
        type: 'question',
        text: 'Qual è il tuo obiettivo finanziario per i prossimi 5 anni?',
        options: [
            {
                type: 'button',
                text: 'Vai in vacanza con la famiglia',
                audience_id: '62345',
                action: {
                    goto: 'step8_woman',
                },
            },
            {
                type: 'button',
                text: 'Acquista una supercar',
                audience_id: '62346',
                action: {
                    goto: 'step8_woman',
                },
            },
            {
                type: 'button',
                text: 'Acquista un appartamento o una casa',
                audience_id: '62347',
                action: {
                    goto: 'step8_woman',
                },
            },
            {
                type: 'button',
                text: 'Inizia la mia attività',
                audience_id: '62348',
                action: {
                    goto: 'step8_woman',
                },
            },
        ],
    },
    step8_woman: {
        type: 'question',
        text:
            'Quanto investiresti ora per avvicinarti al tuo obiettivo finanziario molto più velocemente?',
        options: [
            {
                type: 'button',
                text: 'meno di $250',
                audience_id: [62208, 62141],
                action: {
                    goto: 'step10_binary',
                },
            },
            {
                type: 'button',
                text: '$250-$500',
                audience_id: [62207, 62140],
                action: {
                    goto: 'step9_woman',
                },
            },
            {
                type: 'button',
                text: '$500-$1000',
                audience_id: [62206, 62140],
                action: {
                    goto: 'step9_woman',
                },
            },
            {
                type: 'button',
                text: 'più di $1000',
                audience_id: [62205, 62140],
                action: {
                    goto: 'step9_woman',
                },
            },
        ],
    },
    step9_woman: {
        type: 'question',
        text: 'Hai esperienza nel trading di Bitcoin?',
        options: [
            {
                type: 'button',
                text: 'No, non ne ho mai sentito parlare',
                audience_id: '62350',
                action: {
                    goto: 'step10',
                },
            },
            {
                type: 'button',
                text: 'No, ma voglio provare',
                audience_id: '62351',
                action: {
                    goto: 'step10',
                },
            },
            {
                type: 'button',
                text: 'Sì, sono un principiante',
                audience_id: '62352',
                action: {
                    goto: 'step10',
                },
            },
            {
                type: 'button',
                text: 'Sì, lo faccio professionalmente',
                audience_id: '62353',
                action: {
                    goto: 'step10',
                },
            },
        ],
    },
    step10: {
        type: 'thank_you',
        text: 'GRAZIE!',
        content:
            '<div style="text-align: center; font-size:2rem"><p style="text-align: center; font-size:2rem; margin-bottom:2rem">Risultato del tuo test: <span class="text--danger" style="font-weight:bold"><strong>ECCELLENTE</strong></span> (35 su 35)</p> <p style="font-size:2rem;">Sei una persona ideale per fare soldi online, <br>puoi guadagnare MOLTO PIÙ DI <span class="text--danger" style="font-weight:bold"><strong>$5.000</strong></span> al giorno! <br>Abbiamo selezionato per voi <span class="text--danger"><strong>4 offerte</strong></span> per fare soldi online veloci. <br>Segui le istruzioni riportate di seguito e ricevi la tua offerta personale. <br>In 40 secondi verrai reindirizzato alla migliore offerta (<span class="text--danger">più redditizia per te</span>). <br>Fai clic sul pulsante OTTIENI OFFERTA per andare immediatamente alla migliore offerta! </p></div>',
        timeout: 40,
        timeout_url: SmartURL,
        progress_title: 'Farai $5.000 al giorno?',
        progress_texts: [
            'Aspetta... Controllo delle risposte',
            'Aspetta... Conteggio del tuo punteggio',
        ],
        progress_content: '',
        options: [
            {
                type: 'button',
                text: 'OTTIENI OFFERTA',
                audience_id: '61426',
                action: {
                    redirect_url: SmartURL,
                },
            },
        ],
    },
    step10_binary: {
        type: 'thank_you',
        text: 'GRAZIE!',
        content:
            '<div style="text-align: center; font-size:2rem;"><p style="text-align: center; font-size:2rem; margin-bottom:2rem">Risultato del tuo test: <span class="text--danger" style="font-weight:bold"><strong>OTTIMO</strong></span> (22 su 35)</p> <p style="font-size:2rem;">Sei una persona coraggiosa, la fortuna è dalla tua parte! <span class="text--danger blink"><b>Non perdere l\'occasione</b></span> di diventare più ricchi e circondarti di lusso! <br>In 40 secondi verrai reindirizzato alla migliore offerta (<span class="text--danger">più redditizia per te</span>). <br>Fai clic sul pulsante OTTIENI OFFERTA per andare immediatamente alla migliore offerta! </p></div>',
        timeout: 40,
        timeout_url: SmartURL,
        progress_title: 'Farai $5.000 al giorno?',
        progress_texts: [
            'Aspetta... Controllo delle risposte',
            'Aspetta... Conteggio del tuo punteggio',
        ],
        progress_content: '',
        options: [
            {
                type: 'button',
                text: 'OTTIENI OFFERTA',
                audience_id: '61426',
                action: {
                    redirect_url: SmartURL,
                },
            },
        ],
    },
};
