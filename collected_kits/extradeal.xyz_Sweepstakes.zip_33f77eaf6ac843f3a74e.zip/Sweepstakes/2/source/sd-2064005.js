window.surveyData = {
    adex: 1,
    adex_alert_urll: 'https://lehtymns.com/4453095/?var={zone}&ymid={request_var}',
    adex_warning_urll: 'https://lehtymns.com/4453095/?var={zone}&ymid={request_var}',
    id: 2064001,
    autoexitx: 4142474,
    creativex: 60816,
    comment: '2064 ID dynamic price',
    push_zonex: 4142547,
    reverse_zonex: 4142367,
    popunder_urll: 'https://lehtymns.com/4142489/?var={zone}&ymid={request_var}&var3={click_id}',
    title: 'Apakah Anda Membuat Sebuah Karir Online Besar Dan Menjadi Millionaire Pada 2022?',
    page_title: 'Apakah Anda Membuat Sebuah Karir Online Besar Dan Menjadi Millionaire Pada 2022?',
    subtitle:
        'Ikuti tes GRATIS ini dan cari tahu bagaimana Anda bisa menghasilkan uang di Internet.',
    logo_text: 'Tes Online',
    lead: {
        not_unique: {
            redirect_urll:
                'https://lehtymns.com/4142493/?var={zone}&ymid={request_var}&var3={click_id}',
        },
    },
    main: {
        type: 'question',
        text: 'Apa jenis kelamin Anda?',
        options: [
            {
                type: 'button',
                text: 'Pria',
                audience_id: '61427',
                action: {
                    goto: 'step2_man',
                },
            },
            {
                type: 'button',
                text: 'Wanita',
                audience_id: '61428',
                action: {
                    goto: 'step2_woman',
                },
            },
        ],
    },
    step2_man: {
        type: 'question',
        text: 'Berapa umurmu?',
        options: [
            {
                type: 'button',
                text: 'kurang dari 18 tahun',
                audience_id: [61421, 62387],
                action: {
                    redirect_url: SmartURL,
                    popunder_url: SmartURL,
                },
            },
            {
                type: 'button',
                text: '18-29 tahun',
                audience_id: [62180, 62377],
                action: {
                    goto: 'step5_man',
                },
            },
            {
                type: 'button',
                text: '30-49 tahun',
                audience_id: [62181, 62380],
                action: {
                    goto: 'step5_man',
                },
            },
            {
                type: 'button',
                text: '50-80 tahun',
                audience_id: [62182, 62381],
                action: {
                    goto: 'step5_man',
                },
            },
        ],
    },
    step5_man: {
        type: 'question',
        text: 'Bagaimana kau bisa mencari nafkah?',
        options: [
            {
                type: 'button',
                text: 'Aku bekerja',
                audience_id: '62195',
                action: {
                    goto: 'step6_man',
                },
            },
            {
                type: 'button',
                text: 'Saya wiraswasta',
                audience_id: '62210',
                action: {
                    goto: 'step6_man',
                },
            },
            {
                type: 'button',
                text: 'Saya menganggur',
                audience_id: '62197',
                action: {
                    goto: 'step6_man',
                },
            },
            {
                type: 'button',
                text: 'Saya seorang pensiunan',
                audience_id: '62211',
                action: {
                    goto: 'step6_man',
                },
            },
        ],
    },
    step6_man: {
        type: 'question',
        text: 'Berapa penghasilan rata-rata Anda per tahun?',
        options: [
            {
                type: 'button',
                text: 'kurang dari $10.000',
                audience_id: '62201',
                action: {
                    goto: 'step7_man',
                },
            },
            {
                type: 'button',
                text: '$10.000-$30.000',
                audience_id: '62202',
                action: {
                    goto: 'step7_man',
                },
            },
            {
                type: 'button',
                text: '$30.000-$50.000',
                audience_id: '62200',
                action: {
                    goto: 'step7_man',
                },
            },
            {
                type: 'button',
                text: 'lebih dari $50.000',
                audience_id: '62203',
                action: {
                    goto: 'step7_man',
                },
            },
        ],
    },
    step7_man: {
        type: 'question',
        text: 'Apa tujuan keuangan Anda untuk 5 tahun ke depan?',
        options: [
            {
                type: 'button',
                text: 'Pergi pada liburan keluarga',
                audience_id: '62345',
                action: {
                    goto: 'step8_man',
                },
            },
            {
                type: 'button',
                text: 'Beli supercar',
                audience_id: '62346',
                action: {
                    goto: 'step8_man',
                },
            },
            {
                type: 'button',
                text: 'Beli apartemen atau rumah',
                audience_id: '62347',
                action: {
                    goto: 'step8_man',
                },
            },
            {
                type: 'button',
                text: 'Memulai bisnis saya sendiri',
                audience_id: '62348',
                action: {
                    goto: 'step8_man',
                },
            },
        ],
    },
    step8_man: {
        type: 'question',
        text:
            'Berapa banyak yang akan Anda investasikan sekarang untuk lebih dekat dengan tujuan keuangan Anda dengan lebih cepat?',
        options: [
            {
                type: 'button',
                text: 'kurang dari $250',
                audience_id: [62208, 62139],
                action: {
                    goto: 'step10_binary',
                },
            },
            {
                type: 'button',
                text: '$250-$500',
                audience_id: [62207, 62138],
                action: {
                    goto: 'step9_man',
                },
            },
            {
                type: 'button',
                text: '$500-$1000',
                audience_id: [62206, 62138],
                action: {
                    goto: 'step9_man',
                },
            },
            {
                type: 'button',
                text: 'lebih dari $1000',
                audience_id: [62205, 62138],
                action: {
                    goto: 'step9_man',
                },
            },
        ],
    },
    step9_man: {
        type: 'question',
        text: 'Apakah Anda memiliki pengalaman dalam trading Bitcoin?',
        options: [
            {
                type: 'button',
                text: 'Tidak, aku belum pernah mendengarnya',
                audience_id: '62350',
                action: {
                    goto: 'step10',
                },
            },
            {
                type: 'button',
                text: 'Tidak, tapi aku ingin mencoba',
                audience_id: '62351',
                action: {
                    goto: 'step10',
                },
            },
            {
                type: 'button',
                text: 'Ya, saya seorang pemula',
                audience_id: '62352',
                action: {
                    goto: 'step10',
                },
            },
            {
                type: 'button',
                text: 'Ya, saya melakukannya secara profesional',
                audience_id: '62353',
                action: {
                    goto: 'step10',
                },
            },
        ],
    },
    step2_woman: {
        type: 'question',
        text: 'Berapa umurmu?',
        options: [
            {
                type: 'button',
                text: 'kurang dari 18 tahun',
                audience_id: [61421, 62386],
                action: {
                    redirect_url: SmartURL,
                    popunder_url: SmartURL,
                },
            },
            {
                type: 'button',
                text: '18-29 tahun',
                audience_id: [62180, 62382],
                action: {
                    goto: 'step5_woman',
                },
            },
            {
                type: 'button',
                text: '30-49 tahun',
                audience_id: [62181, 62383],
                action: {
                    goto: 'step5_woman',
                },
            },
            {
                type: 'button',
                text: '50-80 tahun',
                audience_id: [62182, 62384],
                action: {
                    goto: 'step5_woman',
                },
            },
        ],
    },
    step5_woman: {
        type: 'question',
        text: 'Bagaimana kau bisa mencari nafkah?',
        options: [
            {
                type: 'button',
                text: 'Aku bekerja',
                audience_id: '62195',
                action: {
                    goto: 'step6_woman',
                },
            },
            {
                type: 'button',
                text: 'Saya wiraswasta',
                audience_id: '62210',
                action: {
                    goto: 'step6_woman',
                },
            },
            {
                type: 'button',
                text: 'Saya menganggur',
                audience_id: '62197',
                action: {
                    goto: 'step6_woman',
                },
            },
            {
                type: 'button',
                text: 'Saya seorang pensiunan',
                audience_id: '62211',
                action: {
                    goto: 'step6_woman',
                },
            },
        ],
    },
    step6_woman: {
        type: 'question',
        text: 'Berapa penghasilan rata-rata Anda per tahun?',
        options: [
            {
                type: 'button',
                text: 'kurang dari $10.000',
                audience_id: '62201',
                action: {
                    goto: 'step7_woman',
                },
            },
            {
                type: 'button',
                text: '$10.000-$30.000',
                audience_id: '62202',
                action: {
                    goto: 'step7_woman',
                },
            },
            {
                type: 'button',
                text: '$30.000-$50.000',
                audience_id: '62200',
                action: {
                    goto: 'step7_woman',
                },
            },
            {
                type: 'button',
                text: 'lebih dari $50.000',
                audience_id: '62203',
                action: {
                    goto: 'step7_woman',
                },
            },
        ],
    },
    step7_woman: {
        type: 'question',
        text: 'Apa tujuan keuangan Anda untuk 5 tahun ke depan?',
        options: [
            {
                type: 'button',
                text: 'Pergi pada liburan keluarga',
                audience_id: '62345',
                action: {
                    goto: 'step8_woman',
                },
            },
            {
                type: 'button',
                text: 'Beli supercar',
                audience_id: '62346',
                action: {
                    goto: 'step8_woman',
                },
            },
            {
                type: 'button',
                text: 'Beli apartemen atau rumah',
                audience_id: '62347',
                action: {
                    goto: 'step8_woman',
                },
            },
            {
                type: 'button',
                text: 'Memulai bisnis saya sendiri',
                audience_id: '62348',
                action: {
                    goto: 'step8_woman',
                },
            },
        ],
    },
    step8_woman: {
        type: 'question',
        text:
            'Berapa banyak yang akan Anda investasikan sekarang untuk lebih dekat dengan tujuan keuangan Anda dengan lebih cepat?',
        options: [
            {
                type: 'button',
                text: 'kurang dari $250',
                audience_id: [62208, 62141],
                action: {
                    goto: 'step10_binary',
                },
            },
            {
                type: 'button',
                text: '$250-$500',
                audience_id: [62207, 62140],
                action: {
                    goto: 'step9_woman',
                },
            },
            {
                type: 'button',
                text: '$500-$1000',
                audience_id: [62206, 62140],
                action: {
                    goto: 'step9_woman',
                },
            },
            {
                type: 'button',
                text: 'lebih dari $1000',
                audience_id: [62205, 62140],
                action: {
                    goto: 'step9_woman',
                },
            },
        ],
    },
    step9_woman: {
        type: 'question',
        text: 'Apakah Anda memiliki pengalaman dalam trading Bitcoin?',
        options: [
            {
                type: 'button',
                text: 'Tidak, aku belum pernah mendengarnya',
                audience_id: '62350',
                action: {
                    goto: 'step10',
                },
            },
            {
                type: 'button',
                text: 'Tidak, tapi aku ingin mencoba',
                audience_id: '62351',
                action: {
                    goto: 'step10',
                },
            },
            {
                type: 'button',
                text: 'Ya, saya seorang pemula',
                audience_id: '62352',
                action: {
                    goto: 'step10',
                },
            },
            {
                type: 'button',
                text: 'Ya, saya melakukannya secara profesional',
                audience_id: '62353',
                action: {
                    goto: 'step10',
                },
            },
        ],
    },
    step10: {
        type: 'thank_you',
        text: 'TERIMA KASIH!',
        content:
            '<div style="text-align: center; font-size:2rem"><p style="text-align: center; font-size:2rem; margin-bottom:2rem">Hasil Tes Anda: <span class="text--danger" style="font-weight:bold"><strong>sangat baik</strong></span> (35 dari 35)</p><p style="font-size:2rem;">Anda adalah orang yang ideal untuk menghasilkan uang secara online, <br>Anda bisa mendapatkan lebih dari <span class="text--danger" style="font-weight:bold"><strong>$5.000</strong></span> setiap hari! <br> Kami telah memilih untuk Anda <span class="text--danger"><strong>4 penawaran</strong></span> untuk pembuatan uang online cepat. <br> Ikuti petunjuk di bawah ini dan dapatkan penawaran pribadi Anda. <br> Dalam 40 detik Anda akan diarahkan ke penawaran terbaik (<span class="text--danger">paling menguntungkan untuk Anda</span>). <br> Klik tombol GET AWARAN untuk segera pergi ke penawaran terbaik! </p></div>',
        timeout: 40,
        timeout_url: SmartURL,
        progress_title: 'Anda akan membuat $5.000+ setiap hari?',
        progress_texts: ['Tunggu... Memeriksa jawaban', 'Tunggu... Menghitung skor Anda'],
        progress_content: '',
        options: [
            {
                type: 'button',
                text: 'DAPATKAN PENAWARAN',
                audience_id: '61426',
                action: {
                    redirect_url: SmartURL,
                },
            },
        ],
    },
    step10_binary: {
        type: 'thank_you',
        text: 'TERIMA KASIH!',
        content:
            '<div style="text-align: center; font-size:2rem;"><p style="text-align: center; font-size:2rem; margin-bottom:2rem">Hasil Tes Anda: <span class="text--danger" style="font-weight:bold"><strong>BESAR</strong></span> (22 dari 35)</p><p style="font-size:2rem;">Anda adalah orang yang berani, keberuntungan ada di pihak Anda! <span class="text--danger blink"><b>Jangan lewatkan kesempatan Anda</b></span> untuk menjadi lebih kaya dan kelilingi diri Anda dengan kemewahan! <br> Dalam 40 detik Anda akan diarahkan ke penawaran terbaik (<span class="text--danger">paling menguntungkan untuk Anda</span>). <br> Klik tombol GET AWARAN untuk segera pergi ke penawaran terbaik! </p></div>',
        timeout: 40,
        timeout_url: SmartURL,
        progress_title: 'Anda akan membuat $5.000+ setiap hari?',
        progress_texts: ['Tunggu... Memeriksa jawaban', 'Tunggu... Menghitung skor Anda'],
        progress_content: '',
        options: [
            {
                type: 'button',
                text: 'DAPATKAN PENAWARAN',
                audience_id: '61426',
                action: {
                    redirect_url: SmartURL,
                },
            },
        ],
    },
};
