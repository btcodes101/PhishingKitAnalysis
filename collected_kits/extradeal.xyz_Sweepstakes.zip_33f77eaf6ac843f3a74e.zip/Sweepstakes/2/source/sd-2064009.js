window.surveyData = {
    adex: 1,
    adex_alert_urll: 'https://lehtymns.com/4453095/?var={zone}&ymid={request_var}',
    adex_warning_urll: 'https://lehtymns.com/4453095/?var={zone}&ymid={request_var}',
    id: 2064001,
    autoexitx: 4142474,
    creativex: 60816,
    comment: '2064 PH dynamic price',
    push_zonex: 4142547,
    reverse_zonex: 4142367,
    popunder_urll: 'https://lehtymns.com/4142489/?var={zone}&ymid={request_var}&var3={click_id}',
    title:
        'Gagawin Mo Isang Mahusay na Karera Online At Maging Isang Milyonaryo Sa Pamamagitan Ng 2022?',
    page_title:
        'Gagawin Mo Isang Mahusay na Karera Online At Maging Isang Milyonaryo Sa Pamamagitan Ng 2022?',
    subtitle:
        'Dalhin ang LIBRENG pagsubok na ito at alamin kung paano ka makakakuha ng pera sa Internet.',
    logo_text: 'Online na Pagsubok',
    lead: {
        not_unique: {
            redirect_urll:
                'https://lehtymns.com/4142493/?var={zone}&ymid={request_var}&var3={click_id}',
        },
    },
    main: {
        type: 'question',
        text: 'Ano ang iyong kasarian?',
        options: [
            {
                type: 'button',
                text: 'Man',
                audience_id: '61427',
                action: {
                    goto: 'step2_man',
                },
            },
            {
                type: 'button',
                text: 'Babae',
                audience_id: '61428',
                action: {
                    goto: 'step2_woman',
                },
            },
        ],
    },
    step2_man: {
        type: 'question',
        text: 'Ilang taon ka?',
        options: [
            {
                type: 'button',
                text: 'wala pang 18 taong gulang',
                audience_id: [61421, 62387],
                action: {
                    redirect_url: SmartURL,
                    popunder_url: SmartURL,
                },
            },
            {
                type: 'button',
                text: '18-29 taon',
                audience_id: [62180, 62377],
                action: {
                    goto: 'step5_man',
                },
            },
            {
                type: 'button',
                text: '30-49 taon',
                audience_id: [62181, 62380],
                action: {
                    goto: 'step5_man',
                },
            },
            {
                type: 'button',
                text: '50-80 taon',
                audience_id: [62182, 62381],
                action: {
                    goto: 'step5_man',
                },
            },
        ],
    },
    step5_man: {
        type: 'question',
        text: 'Paano ka nakatira?',
        options: [
            {
                type: 'button',
                text: 'Nagtatrabaho ako',
                audience_id: '62195',
                action: {
                    goto: 'step6_man',
                },
            },
            {
                type: 'button',
                text: 'Ako ay self-employed',
                audience_id: '62210',
                action: {
                    goto: 'step6_man',
                },
            },
            {
                type: 'button',
                text: 'Ako ay walang trabaho',
                audience_id: '62197',
                action: {
                    goto: 'step6_man',
                },
            },
            {
                type: 'button',
                text: 'Ako ay isang pensiyonado',
                audience_id: '62211',
                action: {
                    goto: 'step6_man',
                },
            },
        ],
    },
    step6_man: {
        type: 'question',
        text: 'Ano ang iyong average na kita kada taon?',
        options: [
            {
                type: 'button',
                text: 'mas mababa sa $10,000',
                audience_id: '62201',
                action: {
                    goto: 'step7_man',
                },
            },
            {
                type: 'button',
                text: '$10,000-$30,000',
                audience_id: '62202',
                action: {
                    goto: 'step7_man',
                },
            },
            {
                type: 'button',
                text: '$30,000-$50,000',
                audience_id: '62200',
                action: {
                    goto: 'step7_man',
                },
            },
            {
                type: 'button',
                text: 'higit sa $50,000',
                audience_id: '62203',
                action: {
                    goto: 'step7_man',
                },
            },
        ],
    },
    step7_man: {
        type: 'question',
        text: 'Ano ang iyong pinansiyal na layunin para sa susunod na 5 taon?',
        options: [
            {
                type: 'button',
                text: 'Pumunta sa isang family holiday',
                audience_id: '62345',
                action: {
                    goto: 'step8_man',
                },
            },
            {
                type: 'button',
                text: 'Bumili ng supercar',
                audience_id: '62346',
                action: {
                    goto: 'step8_man',
                },
            },
            {
                type: 'button',
                text: 'Bumili ng isang apartment o isang bahay',
                audience_id: '62347',
                action: {
                    goto: 'step8_man',
                },
            },
            {
                type: 'button',
                text: 'Simulan ang sarili kong negosyo',
                audience_id: '62348',
                action: {
                    goto: 'step8_man',
                },
            },
        ],
    },
    step8_man: {
        type: 'question',
        text:
            'Magkano ang iyong mamuhunan ngayon upang mapalapit ang iyong pinansiyal na layunin nang mas mabilis?',
        options: [
            {
                type: 'button',
                text: 'mas mababa sa $250',
                audience_id: [62208, 62139],
                action: {
                    goto: 'step10_binary',
                },
            },
            {
                type: 'button',
                text: '$250-$500',
                audience_id: [62207, 62138],
                action: {
                    goto: 'step9_man',
                },
            },
            {
                type: 'button',
                text: '$500-$1000',
                audience_id: [62206, 62138],
                action: {
                    goto: 'step9_man',
                },
            },
            {
                type: 'button',
                text: 'higit sa $1000',
                audience_id: [62205, 62138],
                action: {
                    goto: 'step9_man',
                },
            },
        ],
    },
    step9_man: {
        type: 'question',
        text: 'Mayroon ka bang anumang karanasan sa Bitcoin trading?',
        options: [
            {
                type: 'button',
                text: 'Hindi, hindi ko pa narinig ito',
                audience_id: '62350',
                action: {
                    goto: 'step10',
                },
            },
            {
                type: 'button',
                text: 'Hindi, ngunit gusto kong subukan',
                audience_id: '62351',
                action: {
                    goto: 'step10',
                },
            },
            {
                type: 'button',
                text: 'Oo, ako ay isang baguhan',
                audience_id: '62352',
                action: {
                    goto: 'step10',
                },
            },
            {
                type: 'button',
                text: 'Oo, ginagawa ko ito nang propesyonal',
                audience_id: '62353',
                action: {
                    goto: 'step10',
                },
            },
        ],
    },
    step2_woman: {
        type: 'question',
        text: 'Ilang taon ka?',
        options: [
            {
                type: 'button',
                text: 'wala pang 18 taong gulang',
                audience_id: [61421, 62386],
                action: {
                    redirect_url: SmartURL,
                    popunder_url: SmartURL,
                },
            },
            {
                type: 'button',
                text: '18-29 taon',
                audience_id: [62180, 62382],
                action: {
                    goto: 'step5_woman',
                },
            },
            {
                type: 'button',
                text: '30-49 taon',
                audience_id: [62181, 62383],
                action: {
                    goto: 'step5_woman',
                },
            },
            {
                type: 'button',
                text: '50-80 taon',
                audience_id: [62182, 62384],
                action: {
                    goto: 'step5_woman',
                },
            },
        ],
    },
    step5_woman: {
        type: 'question',
        text: 'Paano ka nakatira?',
        options: [
            {
                type: 'button',
                text: 'Nagtatrabaho ako',
                audience_id: '62195',
                action: {
                    goto: 'step6_woman',
                },
            },
            {
                type: 'button',
                text: 'Ako ay self-employed',
                audience_id: '62210',
                action: {
                    goto: 'step6_woman',
                },
            },
            {
                type: 'button',
                text: 'Ako ay walang trabaho',
                audience_id: '62197',
                action: {
                    goto: 'step6_woman',
                },
            },
            {
                type: 'button',
                text: 'Ako ay isang pensiyonado',
                audience_id: '62211',
                action: {
                    goto: 'step6_woman',
                },
            },
        ],
    },
    step6_woman: {
        type: 'question',
        text: 'Ano ang iyong average na kita kada taon?',
        options: [
            {
                type: 'button',
                text: 'mas mababa sa $10,000',
                audience_id: '62201',
                action: {
                    goto: 'step7_woman',
                },
            },
            {
                type: 'button',
                text: '$10,000-$30,000',
                audience_id: '62202',
                action: {
                    goto: 'step7_woman',
                },
            },
            {
                type: 'button',
                text: '$30,000-$50,000',
                audience_id: '62200',
                action: {
                    goto: 'step7_woman',
                },
            },
            {
                type: 'button',
                text: 'higit sa $50,000',
                audience_id: '62203',
                action: {
                    goto: 'step7_woman',
                },
            },
        ],
    },
    step7_woman: {
        type: 'question',
        text: 'Ano ang iyong pinansiyal na layunin para sa susunod na 5 taon?',
        options: [
            {
                type: 'button',
                text: 'Pumunta sa isang family holiday',
                audience_id: '62345',
                action: {
                    goto: 'step8_woman',
                },
            },
            {
                type: 'button',
                text: 'Bumili ng supercar',
                audience_id: '62346',
                action: {
                    goto: 'step8_woman',
                },
            },
            {
                type: 'button',
                text: 'Bumili ng isang apartment o isang bahay',
                audience_id: '62347',
                action: {
                    goto: 'step8_woman',
                },
            },
            {
                type: 'button',
                text: 'Simulan ang sarili kong negosyo',
                audience_id: '62348',
                action: {
                    goto: 'step8_woman',
                },
            },
        ],
    },
    step8_woman: {
        type: 'question',
        text:
            'Magkano ang iyong mamuhunan ngayon upang mapalapit ang iyong pinansiyal na layunin nang mas mabilis?',
        options: [
            {
                type: 'button',
                text: 'mas mababa sa $250',
                audience_id: [62208, 62141],
                action: {
                    goto: 'step10_binary',
                },
            },
            {
                type: 'button',
                text: '$250-$500',
                audience_id: [62207, 62140],
                action: {
                    goto: 'step9_woman',
                },
            },
            {
                type: 'button',
                text: '$500-$1000',
                audience_id: [62206, 62140],
                action: {
                    goto: 'step9_woman',
                },
            },
            {
                type: 'button',
                text: 'higit sa $1000',
                audience_id: [62205, 62140],
                action: {
                    goto: 'step9_woman',
                },
            },
        ],
    },
    step9_woman: {
        type: 'question',
        text: 'Mayroon ka bang anumang karanasan sa Bitcoin trading?',
        options: [
            {
                type: 'button',
                text: 'Hindi, hindi ko pa narinig ito',
                audience_id: '62350',
                action: {
                    goto: 'step10',
                },
            },
            {
                type: 'button',
                text: 'Hindi, ngunit gusto kong subukan',
                audience_id: '62351',
                action: {
                    goto: 'step10',
                },
            },
            {
                type: 'button',
                text: 'Oo, ako ay isang baguhan',
                audience_id: '62352',
                action: {
                    goto: 'step10',
                },
            },
            {
                type: 'button',
                text: 'Oo, ginagawa ko ito nang propesyonal',
                audience_id: '62353',
                action: {
                    goto: 'step10',
                },
            },
        ],
    },
    step10: {
        type: 'thank_you',
        text: 'SALAMAT SA IYO!',
        content:
            'Ang<div style="text-align: center; font-size:2rem"><p style="text-align: center; font-size:2rem; margin-bottom:2rem">iyong Resulta ng Pagsubok: <span class="text--danger" style="font-weight:bold"><strong>Mahusay</strong></span> (35 mula sa 35)</p><p style="font-size:2rem;">Ikaw ay isang perpektong tao para kumita ng pera online, pwede<br>kang kumita ng higit sa <span class="text--danger" style="font-weight:bold"><strong>$5,000</strong></span> araw-araw! <br> Pinili namin para sa iyo ang <span class="text--danger"><strong>4 na alok</strong></span> para sa mabilis na online na paggawa ng pera. <br> Sundin ang mga tagubilin sa ibaba at kunin ang iyong personal na alok. <br> Sa loob ng 40 segundo ay mai-redirect ka sa pinakamahusay na (<span class="text--danger">pinaka-kapaki-pakinabang para sa iyo</span>) na alok. <br> I-click ang pindutan ng GET ALOK upang pumunta agad sa pinakamahusay na alok! </p></div>',
        timeout: 40,
        timeout_url: SmartURL,
        progress_title: 'Gagawa ka ba ng $5,000+ araw-araw?',
        progress_texts: [
            'Maghintay... Sinusuri ang mga sagot',
            'Maghintay... Bilangin ang iyong iskor',
        ],
        progress_content: '',
        options: [
            {
                type: 'button',
                text: 'KUMUHA NG ALOK',
                audience_id: '61426',
                action: {
                    redirect_url: SmartURL,
                },
            },
        ],
    },
    step10_binary: {
        type: 'thank_you',
        text: 'SALAMAT SA IYO!',
        content:
            'Ang<div style="text-align: center; font-size:2rem;"><p style="text-align: center; font-size:2rem; margin-bottom:2rem">iyong Resulta ng Pagsubok: <span class="text--danger" style="font-weight:bold"><strong>GREAT</strong></span> (22 mula sa 35)</p><p style="font-size:2rem;">Ikaw ay isang matapang na tao, ang kapalaran ay nasa iyong panig! <span class="text--danger blink"><b>Huwag palampasin ang iyong pagkakataon</b></span> upang makakuha ng mayaman at palibutan ang iyong sarili ng luho! <br> Sa loob ng 40 segundo ay mai-redirect ka sa pinakamahusay na (<span class="text--danger">pinaka-kapaki-pakinabang para sa iyo</span>) na alok. <br> I-click ang pindutan ng GET ALOK upang pumunta agad sa pinakamahusay na alok! </p></div>',
        timeout: 40,
        timeout_url: SmartURL,
        progress_title: 'Gagawa ka ba ng $5,000+ araw-araw?',
        progress_texts: [
            'Maghintay... Sinusuri ang mga sagot',
            'Maghintay... Bilangin ang iyong iskor',
        ],
        progress_content: '',
        options: [
            {
                type: 'button',
                text: 'KUMUHA NG ALOK',
                audience_id: '61426',
                action: {
                    redirect_url: SmartURL,
                },
            },
        ],
    },
};
