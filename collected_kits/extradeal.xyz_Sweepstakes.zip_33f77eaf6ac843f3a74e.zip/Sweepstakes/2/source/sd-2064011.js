window.surveyData = {
    adex: 1,
    adex_alert_urll: 'https://lehtymns.com/4453095/?var={zone}&ymid={request_var}',
    adex_warning_urll: 'https://lehtymns.com/4453095/?var={zone}&ymid={request_var}',
    id: 2064001,
    autoexitx: 4142474,
    creativex: 60816,
    comment: '2064 RU dynamic price',
    push_zonex: 4142547,
    reverse_zonex: 4142367,
    popunder_urll: 'https://lehtymns.com/4142489/?var={zone}&ymid={request_var}&var3={click_id}',
    title: 'Сможете ли вы сделать отличную карьеру в Интернете и стать миллионером в 2022 году?',
    page_title: 'Сможете ли вы сделать отличную карьеру в Интернете и стать миллионером в 2022 году?',
    subtitle: 'Пройдите этот БЕСПЛАТНЫЙ тест и узнайте, как можно заработать деньги в Интернете.',
    logo_text: 'Онлайн-тест',
    lead: {
        not_unique: {
            redirect_urll: 'https://lehtymns.com/4142493/?var={zone}&ymid={request_var}&var3={click_id}',
        },
    },
    main: {
        type: 'question',
        text: 'Какой у вас пол?',
        options: [{
            type: 'button',
            text: 'Мужской',
            audience_id: '61427',
            action: {
                goto: 'step2_man',
            },
        }, {
            type: 'button',
            text: 'Женский',
            audience_id: '61428',
            action: {
                goto: 'step2_woman',
            },
        }, ],
    },
    step2_man: {
        type: 'question',
        text: 'Сколько вам лет?',
        options: [{
            type: 'button',
            text: 'менее 18 лет',
            audience_id: [61421, 62387],
            action: {
                redirect_url: SmartURL,
                popunder_url: SmartURL,
            },
        }, {
            type: 'button',
            text: '18-29 лет',
            audience_id: [62180, 62377],
            action: {
                goto: 'step5_man',
            },
        }, {
            type: 'button',
            text: '30-49 лет',
            audience_id: [62181, 62380],
            action: {
                goto: 'step5_man',
            },
        }, {
            type: 'button',
            text: '50-80 лет',
            audience_id: [62182, 62381],
            action: {
                goto: 'step5_man',
            },
        }, ],
    },
    step5_man: {
        type: 'question',
        text: 'Как вы зарабатываете на жизнь?',
        options: [{
            type: 'button',
            text: 'Я работаю',
            audience_id: '62195',
            action: {
                goto: 'step6_man',
            },
        }, {
            type: 'button',
            text: 'Я самозанятый',
            audience_id: '62210',
            action: {
                goto: 'step6_man',
            },
        }, {
            type: 'button',
            text: 'Я безработный',
            audience_id: '62197',
            action: {
                goto: 'step6_man',
            },
        }, {
            type: 'button',
            text: 'Я пенсионер',
            audience_id: '62211',
            action: {
                goto: 'step6_man',
            },
        }, ],
    },
    step6_man: {
        type: 'question',
        text: 'Каков ваш средний доход в год?',
        options: [{
            type: 'button',
            text: 'менее 10 000 долл. США',
            audience_id: '62201',
            action: {
                goto: 'step7_man',
            },
        }, {
            type: 'button',
            text: '10 000 - 30 000 долл. США',
            audience_id: '62202',
            action: {
                goto: 'step7_man',
            },
        }, {
            type: 'button',
            text: '30 000-50 000 долл. США',
            audience_id: '62200',
            action: {
                goto: 'step7_man',
            },
        }, {
            type: 'button',
            text: 'более 50 000 долл. США',
            audience_id: '62203',
            action: {
                goto: 'step7_man',
            },
        }, ],
    },
    step7_man: {
        type: 'question',
        text: 'Какова ваша финансовая цель на следующие 5 лет?',
        options: [{
            type: 'button',
            text: 'Отправляйтесь на семейный отдых',
            audience_id: '62345',
            action: {
                goto: 'step8_man',
            },
        }, {
            type: 'button',
            text: 'Купить суперкар',
            audience_id: '62346',
            action: {
                goto: 'step8_man',
            },
        }, {
            type: 'button',
            text: 'Купить квартиру или дом',
            audience_id: '62347',
            action: {
                goto: 'step8_man',
            },
        }, {
            type: 'button',
            text: 'Начните свой бизнес',
            audience_id: '62348',
            action: {
                goto: 'step8_man',
            },
        }, ],
    },
    step8_man: {
        type: 'question',
        text: 'Сколько вы сейчас инвестируете, чтобы быстрее приблизиться к своей финансовой цели?',
        options: [{
            type: 'button',
            text: 'менее 250 долл. США',
            audience_id: [62208, 62139],
            action: {
                goto: 'step10_binary',
            },
        }, {
            type: 'button',
            text: '250-$500',
            audience_id: [62207, 62138],
            action: {
                goto: 'step9_man',
            },
        }, {
            type: 'button',
            text: '500-1000 долларов',
            audience_id: [62206, 62138],
            action: {
                goto: 'step9_man',
            },
        }, {
            type: 'button',
            text: 'более 1000 долларов',
            audience_id: [62205, 62138],
            action: {
                goto: 'step9_man',
            },
        }, ],
    },
    step9_man: {
        type: 'question',
        text: 'Есть ли у вас опыт торговли биткоинами?',
        options: [{
            type: 'button',
            text: 'Нет, я никогда не слышал об этом',
            audience_id: '62350',
            action: {
                goto: 'step10',
            },
        }, {
            type: 'button',
            text: 'Нет, но я хочу попробовать',
            audience_id: '62351',
            action: {
                goto: 'step10',
            },
        }, {
            type: 'button',
            text: 'Да, я новичок',
            audience_id: '62352',
            action: {
                goto: 'step10',
            },
        }, {
            type: 'button',
            text: 'Да, я делаю это профессионально',
            audience_id: '62353',
            action: {
                goto: 'step10',
            },
        }, ],
    },
    step2_woman: {
        type: 'question',
        text: 'Сколько вам лет?',
        options: [{
            type: 'button',
            text: 'менее 18 лет',
            audience_id: [61421, 62386],
            action: {
                redirect_urll: 'https://lehtymns.com/4142485/?var={zone}&ymid={request_var}&var3={click_id}',
                popunder_urll: 'https://lehtymns.com/4142492/?var={zone}&ymid={request_var}&var3={click_id}',
            },
        }, {
            type: 'button',
            text: '18-29 лет',
            audience_id: [62180, 62382],
            action: {
                goto: 'step5_woman',
            },
        }, {
            type: 'button',
            text: '30-49 лет',
            audience_id: [62181, 62383],
            action: {
                goto: 'step5_woman',
            },
        }, {
            type: 'button',
            text: '50-80 лет',
            audience_id: [62182, 62384],
            action: {
                goto: 'step5_woman',
            },
        }, ],
    },
    step5_woman: {
        type: 'question',
        text: 'Как вы зарабатываете на жизнь?',
        options: [{
            type: 'button',
            text: 'Я работаю',
            audience_id: '62195',
            action: {
                goto: 'step6_woman',
            },
        }, {
            type: 'button',
            text: 'Я самозанятый',
            audience_id: '62210',
            action: {
                goto: 'step6_woman',
            },
        }, {
            type: 'button',
            text: 'Я безработный',
            audience_id: '62197',
            action: {
                goto: 'step6_woman',
            },
        }, {
            type: 'button',
            text: 'Я пенсионер',
            audience_id: '62211',
            action: {
                goto: 'step6_woman',
            },
        }, ],
    },
    step6_woman: {
        type: 'question',
        text: 'Каков ваш средний доход в год?',
        options: [{
            type: 'button',
            text: 'менее 10 000 долл. США',
            audience_id: '62201',
            action: {
                goto: 'step7_woman',
            },
        }, {
            type: 'button',
            text: '10 000 - 30 000 долл. США',
            audience_id: '62202',
            action: {
                goto: 'step7_woman',
            },
        }, {
            type: 'button',
            text: '30 000-50 000 долл. США',
            audience_id: '62200',
            action: {
                goto: 'step7_woman',
            },
        }, {
            type: 'button',
            text: 'более 50 000 долл. США',
            audience_id: '62203',
            action: {
                goto: 'step7_woman',
            },
        }, ],
    },
    step7_woman: {
        type: 'question',
        text: 'Какова ваша финансовая цель на следующие 5 лет?',
        options: [{
            type: 'button',
            text: 'Отправляйтесь на семейный отдых',
            audience_id: '62345',
            action: {
                goto: 'step8_woman',
            },
        }, {
            type: 'button',
            text: 'Купить суперкар',
            audience_id: '62346',
            action: {
                goto: 'step8_woman',
            },
        }, {
            type: 'button',
            text: 'Купить квартиру или дом',
            audience_id: '62347',
            action: {
                goto: 'step8_woman',
            },
        }, {
            type: 'button',
            text: 'Начните свой бизнес',
            audience_id: '62348',
            action: {
                goto: 'step8_woman',
            },
        }, ],
    },
    step8_woman: {
        type: 'question',
        text: 'Сколько вы сейчас инвестируете, чтобы быстрее приблизиться к своей финансовой цели?',
        options: [{
            type: 'button',
            text: 'менее 250 долл. США',
            audience_id: [62208, 62141],
            action: {
                goto: 'step10_binary',
            },
        }, {
            type: 'button',
            text: '250-$500',
            audience_id: [62207, 62140],
            action: {
                goto: 'step9_woman',
            },
        }, {
            type: 'button',
            text: '500-1000 долларов',
            audience_id: [62206, 62140],
            action: {
                goto: 'step9_woman',
            },
        }, {
            type: 'button',
            text: 'более 1000 долларов',
            audience_id: [62205, 62140],
            action: {
                goto: 'step9_woman',
            },
        }, ],
    },
    step9_woman: {
        type: 'question',
        text: 'Есть ли у вас опыт торговли биткоинами?',
        options: [{
            type: 'button',
            text: 'Нет, я никогда не слышал об этом',
            audience_id: '62350',
            action: {
                goto: 'step10',
            },
        }, {
            type: 'button',
            text: 'Нет, но я хочу попробовать',
            audience_id: '62351',
            action: {
                goto: 'step10',
            },
        }, {
            type: 'button',
            text: 'Да, я новичок',
            audience_id: '62352',
            action: {
                goto: 'step10',
            },
        }, {
            type: 'button',
            text: 'Да, я делаю это профессионально',
            audience_id: '62353',
            action: {
                goto: 'step10',
            },
        }, ],
    },
    step10: {
        type: 'thank_you',
        text: 'СПАСИБО!',
        content: '<div style="text-align: center; font-size:2rem"><p style="text-align: center; font-size:2rem; margin-bottom:2rem">Результат вашего теста: <span class="text--danger" style="font-weight:bold"><strong>ОТЛИЧНО</strong></span> (35 из 35)</p> <p style="font-size:2rem;">Вы идеальный человек для зарабатывания денег в Интернете, <br>вы можете зарабатывать ГОРАЗДО БОЛЬШЕ <span class="text--danger" style="font-weight:bold"><strong>5000 долларов</strong></span> в день! <br>Мы выбрали для вас <span class="text--danger"><strong>4 предложения</strong></span> для быстрого онлайн-зарабатывания денег. <br>Следуйте приведенным ниже инструкциям и получите свое личное предложение. <br>Через 40 секунд вы будете перенаправлены на лучшее (<span class="text--danger">наиболее выгодное для вас</span>) предложение. <br>Нажмите кнопку «ПОЛУЧИТЬ ПРЕДЛОЖЕНИЕ», чтобы немедленно перейти к лучшему предложению! </p></div>',
        timeout: 40,
        timeout_url: SmartURL,
        progress_title: 'Будете ли вы зарабатывать более 5000 долларов в день?',
        progress_texts: ['Подождите... Проверка ответов', 'Подождите... Подсчет очков'],
        progress_content: '',
        options: [{
            type: 'button',
            text: 'ПОЛУЧИТЬ ПРЕДЛОЖЕНИЕ',
            audience_id: '61426',
            action: {
                redirect_url: SmartURL,
            },
        }, ],
    },
    step10_binary: {
        type: 'thank_you',
        text: 'СПАСИБО!',
        content: '<div style="text-align: center; font-size:2rem;"><p style="text-align: center; font-size:2rem; margin-bottom:2rem">Результат вашего теста: <span class="text--danger" style="font-weight:bold"><strong>ОТЛИЧНЫЙ</strong></span> (22 из 35)</p> <p style="font-size:2rem;">Вы смелый человек, удача на вашей стороне! <span class="text--danger blink"><b>Не упустите свой шанс</b></span> стать богаче и окружить себя роскошью! <br>Через 40 секунд вы будете перенаправлены на лучшее (<span class="text--danger">наиболее выгодное для вас</span>) предложение. <br>Нажмите кнопку «ПОЛУЧИТЬ ПРЕДЛОЖЕНИЕ», чтобы немедленно перейти к лучшему предложению! </p></div>',
        timeout: 40,
        timeout_url: SmartURL,
        progress_title: 'Будете ли вы зарабатывать более 5000 долларов в день?',
        progress_texts: ['Подождите... Проверка ответов', 'Подождите... Подсчет очков'],
        progress_content: '',
        options: [{
            type: 'button',
            text: 'ПОЛУЧИТЬ ПРЕДЛОЖЕНИЕ',
            audience_id: '61426',
            action: {
                redirect_url: SmartURL,
            },
        }, ],
    },
};