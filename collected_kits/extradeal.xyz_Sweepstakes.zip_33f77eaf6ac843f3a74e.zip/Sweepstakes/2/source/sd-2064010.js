window.surveyData = {
    adex: 1,
    adex_alert_urll: 'https://lehtymns.com/4453095/?var={zone}&ymid={request_var}',
    adex_warning_urll: 'https://lehtymns.com/4453095/?var={zone}&ymid={request_var}',
    id: 2064001,
    autoexitx: 4142474,
    creativex: 60816,
    comment: '2064 PT dynamic price',
    push_zonex: 4142547,
    reverse_zonex: 4142367,
    popunder_urll: 'https://lehtymns.com/4142489/?var={zone}&ymid={request_var}&var3={click_id}',
    title: 'Você faria uma grande carreira on-line e se tornaria um milionário até 2022?',
    page_title: 'Você faria uma grande carreira on-line e se tornaria um milionário até 2022?',
    subtitle: 'Faça este teste GRATUITO e descubra como você pode ganhar dinheiro na Internet.',
    logo_text: 'Teste online',
    lead: {
        not_unique: {
            redirect_urll:
                'https://lehtymns.com/4142493/?var={zone}&ymid={request_var}&var3={click_id}',
        },
    },
    main: {
        type: 'question',
        text: 'Qual é o seu gênero?',
        options: [
            {
                type: 'button',
                text: 'Homem',
                audience_id: '61427',
                action: {
                    goto: 'step2_man',
                },
            },
            {
                type: 'button',
                text: 'Mulher',
                audience_id: '61428',
                action: {
                    goto: 'step2_woman',
                },
            },
        ],
    },
    step2_man: {
        type: 'question',
        text: 'Quantos anos você tem?',
        options: [
            {
                type: 'button',
                text: 'menos de 18 anos',
                audience_id: [61421, 62387],
                action: {
                    redirect_url: SmartURL,
                    popunder_url: SmartURL,
                },
            },
            {
                type: 'button',
                text: '18-29 anos',
                audience_id: [62180, 62377],
                action: {
                    goto: 'step5_man',
                },
            },
            {
                type: 'button',
                text: '30-49 anos',
                audience_id: [62181, 62380],
                action: {
                    goto: 'step5_man',
                },
            },
            {
                type: 'button',
                text: '50-80 anos',
                audience_id: [62182, 62381],
                action: {
                    goto: 'step5_man',
                },
            },
        ],
    },
    step5_man: {
        type: 'question',
        text: 'Como você ganha a vida?',
        options: [
            {
                type: 'button',
                text: 'Eu trabalho',
                audience_id: '62195',
                action: {
                    goto: 'step6_man',
                },
            },
            {
                type: 'button',
                text: 'Sou autônomo',
                audience_id: '62210',
                action: {
                    goto: 'step6_man',
                },
            },
            {
                type: 'button',
                text: 'Estou desempregado',
                audience_id: '62197',
                action: {
                    goto: 'step6_man',
                },
            },
            {
                type: 'button',
                text: 'Sou pensionista',
                audience_id: '62211',
                action: {
                    goto: 'step6_man',
                },
            },
        ],
    },
    step6_man: {
        type: 'question',
        text: 'Qual é sua renda média por ano?',
        options: [
            {
                type: 'button',
                text: 'menos de US $10.000',
                audience_id: '62201',
                action: {
                    goto: 'step7_man',
                },
            },
            {
                type: 'button',
                text: 'US$10.000-$30.000',
                audience_id: '62202',
                action: {
                    goto: 'step7_man',
                },
            },
            {
                type: 'button',
                text: 'US$30.000-$50.000',
                audience_id: '62200',
                action: {
                    goto: 'step7_man',
                },
            },
            {
                type: 'button',
                text: 'mais de US$50.000',
                audience_id: '62203',
                action: {
                    goto: 'step7_man',
                },
            },
        ],
    },
    step7_man: {
        type: 'question',
        text: 'Qual é sua meta financeira para os próximos 5 anos?',
        options: [
            {
                type: 'button',
                text: 'Sair de férias com a família',
                audience_id: '62345',
                action: {
                    goto: 'step8_man',
                },
            },
            {
                type: 'button',
                text: 'Compre um supercarro',
                audience_id: '62346',
                action: {
                    goto: 'step8_man',
                },
            },
            {
                type: 'button',
                text: 'Compre um apartamento ou uma casa',
                audience_id: '62347',
                action: {
                    goto: 'step8_man',
                },
            },
            {
                type: 'button',
                text: 'Comece meu próprio negócio',
                audience_id: '62348',
                action: {
                    goto: 'step8_man',
                },
            },
        ],
    },
    step8_man: {
        type: 'question',
        text:
            'Quanto você investiria agora para se aproximar de sua meta financeira muito mais rápido?',
        options: [
            {
                type: 'button',
                text: 'menos de US $250',
                audience_id: [62208, 62139],
                action: {
                    goto: 'step10_binary',
                },
            },
            {
                type: 'button',
                text: 'US$250 a US$500',
                audience_id: [62207, 62138],
                action: {
                    goto: 'step9_man',
                },
            },
            {
                type: 'button',
                text: 'US$500 a $1000',
                audience_id: [62206, 62138],
                action: {
                    goto: 'step9_man',
                },
            },
            {
                type: 'button',
                text: 'mais de US $1000',
                audience_id: [62205, 62138],
                action: {
                    goto: 'step9_man',
                },
            },
        ],
    },
    step9_man: {
        type: 'question',
        text: 'Você tem alguma experiência em negociação de Bitcoin?',
        options: [
            {
                type: 'button',
                text: 'Não, nunca ouvi falar disso',
                audience_id: '62350',
                action: {
                    goto: 'step10',
                },
            },
            {
                type: 'button',
                text: 'Não, mas eu quero tentar',
                audience_id: '62351',
                action: {
                    goto: 'step10',
                },
            },
            {
                type: 'button',
                text: 'Sim, sou iniciante',
                audience_id: '62352',
                action: {
                    goto: 'step10',
                },
            },
            {
                type: 'button',
                text: 'Sim, eu faço isso profissionalmente',
                audience_id: '62353',
                action: {
                    goto: 'step10',
                },
            },
        ],
    },
    step2_woman: {
        type: 'question',
        text: 'Quantos anos você tem?',
        options: [
            {
                type: 'button',
                text: 'menos de 18 anos',
                audience_id: [61421, 62386],
                action: {
                    redirect_url: SmartURL,
                    popunder_url: SmartURL,
                },
            },
            {
                type: 'button',
                text: '18-29 anos',
                audience_id: [62180, 62382],
                action: {
                    goto: 'step5_woman',
                },
            },
            {
                type: 'button',
                text: '30-49 anos',
                audience_id: [62181, 62383],
                action: {
                    goto: 'step5_woman',
                },
            },
            {
                type: 'button',
                text: '50-80 anos',
                audience_id: [62182, 62384],
                action: {
                    goto: 'step5_woman',
                },
            },
        ],
    },
    step5_woman: {
        type: 'question',
        text: 'Como você ganha a vida?',
        options: [
            {
                type: 'button',
                text: 'Eu trabalho',
                audience_id: '62195',
                action: {
                    goto: 'step6_woman',
                },
            },
            {
                type: 'button',
                text: 'Sou autônomo',
                audience_id: '62210',
                action: {
                    goto: 'step6_woman',
                },
            },
            {
                type: 'button',
                text: 'Estou desempregado',
                audience_id: '62197',
                action: {
                    goto: 'step6_woman',
                },
            },
            {
                type: 'button',
                text: 'Sou pensionista',
                audience_id: '62211',
                action: {
                    goto: 'step6_woman',
                },
            },
        ],
    },
    step6_woman: {
        type: 'question',
        text: 'Qual é sua renda média por ano?',
        options: [
            {
                type: 'button',
                text: 'menos de US $10.000',
                audience_id: '62201',
                action: {
                    goto: 'step7_woman',
                },
            },
            {
                type: 'button',
                text: 'US$10.000-$30.000',
                audience_id: '62202',
                action: {
                    goto: 'step7_woman',
                },
            },
            {
                type: 'button',
                text: 'US$30.000-$50.000',
                audience_id: '62200',
                action: {
                    goto: 'step7_woman',
                },
            },
            {
                type: 'button',
                text: 'mais de US$50.000',
                audience_id: '62203',
                action: {
                    goto: 'step7_woman',
                },
            },
        ],
    },
    step7_woman: {
        type: 'question',
        text: 'Qual é sua meta financeira para os próximos 5 anos?',
        options: [
            {
                type: 'button',
                text: 'Sair de férias com a família',
                audience_id: '62345',
                action: {
                    goto: 'step8_woman',
                },
            },
            {
                type: 'button',
                text: 'Compre um supercarro',
                audience_id: '62346',
                action: {
                    goto: 'step8_woman',
                },
            },
            {
                type: 'button',
                text: 'Compre um apartamento ou uma casa',
                audience_id: '62347',
                action: {
                    goto: 'step8_woman',
                },
            },
            {
                type: 'button',
                text: 'Comece meu próprio negócio',
                audience_id: '62348',
                action: {
                    goto: 'step8_woman',
                },
            },
        ],
    },
    step8_woman: {
        type: 'question',
        text:
            'Quanto você investiria agora para se aproximar de sua meta financeira muito mais rápido?',
        options: [
            {
                type: 'button',
                text: 'menos de US $250',
                audience_id: [62208, 62141],
                action: {
                    goto: 'step10_binary',
                },
            },
            {
                type: 'button',
                text: 'US$250 a US$500',
                audience_id: [62207, 62140],
                action: {
                    goto: 'step9_woman',
                },
            },
            {
                type: 'button',
                text: 'US$500 a $1000',
                audience_id: [62206, 62140],
                action: {
                    goto: 'step9_woman',
                },
            },
            {
                type: 'button',
                text: 'mais de US $1000',
                audience_id: [62205, 62140],
                action: {
                    goto: 'step9_woman',
                },
            },
        ],
    },
    step9_woman: {
        type: 'question',
        text: 'Você tem alguma experiência em negociação de Bitcoin?',
        options: [
            {
                type: 'button',
                text: 'Não, nunca ouvi falar disso',
                audience_id: '62350',
                action: {
                    goto: 'step10',
                },
            },
            {
                type: 'button',
                text: 'Não, mas eu quero tentar',
                audience_id: '62351',
                action: {
                    goto: 'step10',
                },
            },
            {
                type: 'button',
                text: 'Sim, sou iniciante',
                audience_id: '62352',
                action: {
                    goto: 'step10',
                },
            },
            {
                type: 'button',
                text: 'Sim, eu faço isso profissionalmente',
                audience_id: '62353',
                action: {
                    goto: 'step10',
                },
            },
        ],
    },
    step10: {
        type: 'thank_you',
        text: 'OBRIGADO!',
        content:
            '<div style="text-align: center; font-size:2rem"><p style="text-align: center; font-size:2rem; margin-bottom:2rem">Resultado do seu teste: <span class="text--danger" style="font-weight:bold"><strong>EXCELENTE</strong></span> (35 de 35)</p> <p style="font-size:2rem;">Você é uma pessoa ideal para ganhar dinheiro online, <br>você pode ganhar MUITO MAIS DE <span class="text--danger" style="font-weight:bold"><strong>US $5.000</strong></span> por dia! <br>Selecionamos para você <span class="text--danger"><strong>4 ofertas</strong></span> para fazer dinheiro online rápido. <br>Siga as instruções abaixo e receba sua oferta pessoal. <br>Em 40 segundos você será redirecionado para a melhor oferta (<span class="text--danger">mais lucrativa para você</span>). <br>Clique no botão OBTER OFERTA para ir para a melhor oferta imediatamente! </p></div>',
        timeout: 40,
        timeout_url: SmartURL,
        progress_title: 'Você ganhará $5.000+ por dia?',
        progress_texts: ['Espere... Verificando respostas', 'Espere... Contando sua pontuação'],
        progress_content: '',
        options: [
            {
                type: 'button',
                text: 'OBTER OFERTA',
                audience_id: '61426',
                action: {
                    redirect_url: SmartURL,
                },
            },
        ],
    },
    step10_binary: {
        type: 'thank_you',
        text: 'OBRIGADO!',
        content:
            '<div style="text-align: center; font-size:2rem;"><p style="text-align: center; font-size:2rem; margin-bottom:2rem">Resultado do seu teste: <span class="text--danger" style="font-weight:bold"><strong>ÓTIMO</strong></span> (22 de 35)</p> <p style="font-size:2rem;">Você é uma pessoa corajosa, a sorte está do seu lado! <span class="text--danger blink"><b>Não perca a chance</b></span> de ficar mais rico e cercar-se de luxo! <br>Em 40 segundos você será redirecionado para a melhor oferta (<span class="text--danger">mais lucrativa para você</span>). <br>Clique no botão OBTER OFERTA para ir para a melhor oferta imediatamente! </p></div>',
        timeout: 40,
        timeout_url: SmartURL,
        progress_title: 'Você ganhará $5.000+ por dia?',
        progress_texts: ['Espere... Verificando respostas', 'Espere... Contando sua pontuação'],
        progress_content: '',
        options: [
            {
                type: 'button',
                text: 'OBTER OFERTA',
                audience_id: '61426',
                action: {
                    redirect_url: SmartURL,
                },
            },
        ],
    },
};
