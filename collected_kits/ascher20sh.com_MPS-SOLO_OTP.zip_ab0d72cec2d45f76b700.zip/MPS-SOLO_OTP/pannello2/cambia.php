<?php  /* kkLOsnO63PR5thAIpr84awmP8511jRW7InNnj29Qh2pW1 */   include("sec.php"); ?>

<?php include("layout1.php") ?>

		<div id="log" class="container"><br>
			<h3>Modifica Credenziali per Accedere al Pannello</h3>
          <br>  <h5>nun te scurdà</h5><br>
          <form action="cambiacred.php" method="POST">
USERNAME: <input type="text" name="username" /><BR><BR>
PASSWORD: <input type="text" name="password" /><BR><BR>
<input type="submit" class="btn btn-danger" value="MODIFICA" />
          </form>
		</div>

<?php include("layout2.php") ?><?php ?>