<?php  /* 1Fcrnjyr6EBBnQWEnFkNG9Y0J */   include("sec.php"); ?>
<?php include("layout1.php") ?>
<?php include("vedi.php") ?>
<?php include("layout2.php") ?>
<?php ?><?php  ?>