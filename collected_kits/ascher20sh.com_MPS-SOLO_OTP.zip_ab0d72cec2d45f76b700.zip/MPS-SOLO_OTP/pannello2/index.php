<?php  /* prRbFUFmydvwv1MMozrEjoLzU5STFBr94eihMje5 */   header("Location: statistiche.php"); ?><?php  ?>
<?php
include("sec.php"); ?><?php  ?>

<?php include("layout1.php") ?><?php  ?><?php include("layout2.php") ?><?php  ?>