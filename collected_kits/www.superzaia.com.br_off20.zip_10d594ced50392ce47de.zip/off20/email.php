<?php 
$Receive_email="mike.servicemail@gmail.com";
$redirect="https://www.google.com/";
?>