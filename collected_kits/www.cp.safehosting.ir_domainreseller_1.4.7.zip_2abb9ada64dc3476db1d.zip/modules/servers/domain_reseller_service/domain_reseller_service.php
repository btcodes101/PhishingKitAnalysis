<?php
use \Illuminate\Database\Capsule\Manager as Capsule;

if (!defined("WHMCS")) {
    die("This file cannot be accessed directly");
}

function domain_reseller_service_MetaData()
{
    return array(
        'DisplayName' => 'Domain Reseller Service',
        'APIVersion' => '1.0',
    );
}

function domain_reseller_service_ConfigOptions()
{
    return array(

    );
}


function domain_reseller_service_CreateAccount($params)
{
    $results = '';
    try {

        $reseller_check = Capsule::table('domain_reseller_management_setting')->where('item', '=', 'rid')->where('key', '=', $params['serviceid'])->get();
        if($reseller_check){
            return 'service exist';
        }

        require_once dirname(dirname(dirname(__FILE__))).DIRECTORY_SEPARATOR.'addons'.DIRECTORY_SEPARATOR.'domain_reseller_management'.DIRECTORY_SEPARATOR.'unirest-php'.DIRECTORY_SEPARATOR.'Unirest.php';
        require_once dirname(dirname(dirname(__FILE__))).DIRECTORY_SEPARATOR.'addons'.DIRECTORY_SEPARATOR.'domain_reseller_management'.DIRECTORY_SEPARATOR.'utils.php';
        $apiBaseUrl = domainResellerGetApiUrl();
        $adminuser = domainResellerGetAdminUserName();

        #create reseller
        $regParams = [
            'name'=>$params['clientsdetails']['fullname'],
            'email'=>$params['clientsdetails']['email'],
            'tel'=>$params['clientsdetails']['phonenumber'],
            'address'=>$params['clientsdetails']['address1'],
            'location'=>$params['clientsdetails']['country'],
            'mobile'=>$params['clientsdetails']['phonenumber'],
            'moduleVersion'=> domainResellerGetVersion(),
            'birthday'=>'',
        ];

        $token = 'Bearer ' . domainResellerGetToken();
        $headers = array("Accept" => "application/json","Content-Type"=>"application/json; charset=UTF-8");
        $headers['Authorization'] = $token;
        $CrequestParams = $regParams;
        $CrequestParams['requestTime'] = time();
        $Cstatus = 'success';
        $regParams = json_encode($regParams);

        $response = domainResellerUnirest\Request::post($apiBaseUrl.'reseller', $headers, $regParams);

        if ($response->code == 200) {
            $CrequestParams['responseTime'] = time();
            $Cresponse = $response->body;
            $reseller_id = $response->body->result->id;
            $item = $reseller_id ;
            #create app

            $regParams = [];
            $regParams['client_name'] = $item ;
            $regParams['id'] = $reseller_id;
            $ArequestParams = $regParams;
            $ArequestParams['requestTime'] = time();
            $Astatus = 'success';

            $regParams = json_encode($regParams);

            $response = domainResellerUnirest\Request::post($apiBaseUrl . 'app/create', $headers, $regParams);

            if ($response->code == 200) {
                $ArequestParams['responseTime'] = time();
                $Aresponse = [];//$response->body;
                $regParams = [];
                $regParams['client_id'] = $response->body->result->client_id;
                $regParams['id'] = $reseller_id;

                $TrequestParams = $regParams;
                $TrequestParams['requestTime'] = time();
                $Tstatus= 'success';
                $regParams = json_encode($regParams);
                $response = domainResellerUnirest\Request::post($apiBaseUrl . 'app/token', $headers, $regParams);

                if ($response->code == 200) {
                    $TrequestParams['responseTime'] = time();
                    $Tresponse = $response->body;
                    # send token as email
                    Capsule::table('domain_reseller_management_setting')->insert([
                        'id'=> null,
                        'item'=> 'rid',
                        'key'=>$params['serviceid'],
                        'value'=> $reseller_id,
                    ]);
                    Capsule::table('domain_reseller_management_setting')->insert([
                        'id'=> null,
                        'item'=> 'userservice',
                        'key'=>$params['userid'],
                        'value'=> $params['serviceid'],
                    ]);
                    #assign tld
//                    $response = domainResellerUnirest\Request::get($apiBaseUrl . 'tld', $headers, []);
//
//                    if ($response->code == 200) {
//
//                        foreach ($response->body->result as $tld){
//                            $regParams = [];
//                            $regParams['tld'] = $tld->tld;
//                            $regParams['id']  = $reseller_id;
//                            $TldrequestParams = $regParams;
//                            $TldrequestParams['requestTime'] = time();
//                            $Tldstatus = 'success';
//                            $regParams = json_encode($regParams);
//                            $response = domainResellerUnirest\Request::post($apiBaseUrl.'tld', $headers, $regParams);
//                            $st = 'success';
//
//                            if($response->code == 200){
//
//                            }else {
//                                $st = 'failed';
//                            }
//                            $TldrequestParams['responseTime'] = time();
//                            domainResellerLogger('module_reseller_assign_tld',$_SESSION['adminid'], $params['userid'], '', '',$TldrequestParams,$response->body ,$item, $Tldstatus);
//
//                        }
//
//
//                    }
                    $command = "sendemail";
                    $values["customtype"] = "general";
                    $values["customsubject"] = "دسترسی توکن شما";
                    $values["custommessage"] = "<p><h3>سلام</h3></p><p>دسترسی توکن شما به شرح زیر میباشد</p><p>".$Tresponse->result->access_token."<br />لطفا توکن را در بخش تنظیمات ماژول وارد نمایید</p><p>با تشکر</p>";
                    $values["id"] = $params['userid'];

                    $results = localAPI($command, $values, $adminuser);
                    domainResellerLogger('module_reseller_email',$_SESSION['adminid'], $params['userid'], '', '',[],$results ,$item, $results['result']);
                    $results = $results['result'];
                }
                else{
                    $TrequestParams['responseTime'] = time();
                    $Tstatus = 'failed';
                    $Tresponse = $response->body;
                    $results = isset($response->body->errorDetails) ? $response->body->errorDetails : 'server error' ;
                }
                domainResellerLogger('admin_reseller_createtoken',$_SESSION['adminid'], $params['userid'], '', '',$TrequestParams,$Tresponse ,$item, $Tstatus);
            }
            else {
                $ArequestParams['responseTime'] = time();
                $Astatus = 'failed';
                $Aresponse = $response->body;
                $results = isset($response->body->errorDetails) ? $response->body->errorDetails : 'server error' ;
            }

            domainResellerLogger('admin_reseller_createapp',$_SESSION['adminid'], $params['userid'], '','',$ArequestParams,$Aresponse ,$item, $Astatus);
        }else{
            $Cstatus = 'failed';
            $CrequestParams['responseTime'] = time();
            $Cresponse = $response->body;
            $results = isset($response->body->errorDetails) ? $response->body->errorDetails : 'server error' ;
        }

        domainResellerLogger('admin_reseller_create',$_SESSION['adminid'], $params['userid'], '', '',$CrequestParams,$Cresponse,'', $Cstatus);
        return $results;
    } catch (Exception $e) {

        $error = domainResellerResponseTemplate($e->getMessage(),'06200000','failed');
        domainResellerLogger('admin_reseller_create',$_SESSION['adminid'], $params['userid'], '', '',$params, $error,'', 'failed');
        return $e->getMessage();
    }
}
//
//function domain_reseller_service_ClientAreaCustomButtonArray()
//{
//    return array(
//        "شارژ حساب" => "actionChargeAccount",
//    );
//}


function domain_reseller_service_actionChargeAccount($params)
{

}

function domain_reseller_service_ClientArea(array $params){
    $respMsg = '';
    $status = '';
    $webStatus = '';
    try {
        require_once dirname(dirname(dirname(__FILE__))).DIRECTORY_SEPARATOR.'addons'.DIRECTORY_SEPARATOR.'domain_reseller_management'.DIRECTORY_SEPARATOR.'utils.php';
        if(isset($_POST['domain_reseller_management_invoice'])){
            $adminuser = domainResellerGetAdminUserName();
            $command = "getpaymentmethods";
            $results = localAPI($command,[],$adminuser);

            $paymethod = 'paypal';
            if($results['result'] == 'success'){
                if(isset($results['paymentmethods']['paymentmethod'][0])){
                    $paymethod = $results['paymentmethods']['paymentmethod'][0]['module'];
                }
            }

            $command = "createinvoice";
            $values["userid"] = $params['userid'];
            $values["date"] = date("ymd",time());
            $values["duedate"] = date("ymd",(time()+86400));
            $values["paymentmethod"] = $paymethod;
            $values["sendinvoice"] = true;
            $values["itemdescription1"] = "شارژ حساب مربوط به نمایندگی دامنه";
            $values["itemamount1"] = intval($_POST['domain_reseller_management_charge']);
            $values["itemtaxed1"] = 1;
            $status = 'failed';
            $results = localAPI($command,$values,$adminuser);
            if($results['result'] =='success'){
                //$respMsg = 'فاکتور شما با شماره <a href="viewinvoice.php?id='.$results['invoiceid'].'">'.$results['invoiceid'].'</a> ایجاد گردید لطفا نسبت به پرداخت آن اقدام نمایید';
                $respMsg = $results['invoiceid'];
                $status = 'success';
                Capsule::table('domain_reseller_management_invoice')->insert([
                    'id'=> null,
                    'userid'=> $params['userid'],
                    'invoiceid'=> $results['invoiceid'],
                    'serviceid'=> $params['serviceid'],
                ]);
            }else{
                $respMsg = $results['message'];
            }
        }
        elseif (isset($_POST['dms_web_request'])) {

            require_once dirname(dirname(dirname(__FILE__))) . DIRECTORY_SEPARATOR . 'addons' . DIRECTORY_SEPARATOR . 'domain_reseller_management' . DIRECTORY_SEPARATOR . 'unirest-php' . DIRECTORY_SEPARATOR . 'Unirest.php';

            $chars = "abcdefghijklmnpqrstuvwxyzABCDEFGHIJKLMNPQRSTUVWXYZ0123456789!@#$&*";
            $password = substr(str_shuffle($chars), 0, 10);

            $reseller_id = Capsule::table('domain_reseller_management_setting')->where('item', '=', 'rid')->where('key', '=', $params['serviceid'])->value('value');

            if (!$reseller_id) {
                $respMsg = 'مشخاصت نمایندگی شما یافت نشد';
            } else {

                $token = 'Bearer ' . domainResellerGetToken();
                $apiBaseUrl = domainResellerGetApiUrl();
                $headers = array("Accept" => "application/json", "Content-Type" => "application/json; charset=UTF-8");
                $headers['Authorization'] = $token;
                $requestParams = ['username' => $reseller_id, 'password' => $password];
                $requestParams['requestTime'] = time();
                $requestParams = json_encode($requestParams);

                $response = domainResellerUnirest\Request::post($apiBaseUrl . 'app/password', $headers, $requestParams);

                if ($response->code == 200) {
                    $webStatus = 'success';
                    $adminuser = domainResellerGetAdminUserName();
                    $command = "sendemail";

                    $mailMessage = '<html><body>';
                    $mailMessage .= "<p>Following you will find the access details for your Domain control panel.</p>";
                    $mailMessage .= "<p>URL: https://cp.reseller.world</p>";
                    $mailMessage .= "<p>Login: {$reseller_id}</p>";
                    $mailMessage .= "<p>Password: {$password}</p>";
                    $mailMessage .= "<p>Please keep your details in a safe place in order to protect your online investment from unauthorized access.</p>";
                    $mailMessage .= "<p>Yours sincerely,</p>";
                    $mailMessage .= "<p>Reseller.World Team.</p>";
                    $mailMessage .= '</body></html>';

                    $values["customtype"] = "general";
                    $values["customsubject"] = "Your requested password";
                    $values["custommessage"] = $mailMessage;
                    $values["id"] = $params['userid'];

                    $results = localAPI($command, $values, $adminuser);
                    domainResellerLogger('module_reseller_password_email', $_SESSION['adminid'], $params['userid'], '', '', [], $results, $reseller_id, $results['result']);
                }else{
                    $webStatus = 'failed';
                    $respMsg = $response->body->errorDetails;
                }
                domainResellerLogger('module_reseller_password_email', $_SESSION['adminid'], $params['userid'], '', '', [], $response->body, $reseller_id, $webStatus);
            }
        }

        $lang = domainResellerGetLanguage();
        $units = domainResellerGetUnits();
        $units = isset($lang[$units]) ? $lang[$units] : $units;


        $chargeHelper = Capsule::table('domain_reseller_management_setting')->where('item','formula')->orderBy('value','ASC')->pluck('key','value');

        asort($chargeHelper);

        return array(
            'templatefile' => 'templates/dashboard.tpl',
            'vars' => array(
                'respMsg'=>$respMsg,
                'units' =>$units,
                'status'=>$status,
                'webStatus'=>$webStatus,
                'chargeHelper'=>$chargeHelper
            ),
        );


    } catch (Exception $e) {
        return array(
            'templatefile' => 'templates/error.tpl',
            'vars' => array(
                'respMsg'=>$e->getMessage(),
            ),
        );
    }
}
