<?php
use \Illuminate\Database\Capsule\Manager as Capsule;

require_once dirname(dirname(dirname(__FILE__))) . DIRECTORY_SEPARATOR . 'addons' . DIRECTORY_SEPARATOR . 'domain_reseller_management' . DIRECTORY_SEPARATOR . 'unirest-php' . DIRECTORY_SEPARATOR . 'Unirest.php';
require_once dirname(dirname(dirname(__FILE__))) . DIRECTORY_SEPARATOR . 'addons' . DIRECTORY_SEPARATOR . 'domain_reseller_management' . DIRECTORY_SEPARATOR . 'utils.php';

function domain_reseller_GetNameservers($params)
{

    $tld = $params["tld"];
    $sld = $params["sld"];
    $values = [];
    $params['original']['domainname'] = $sld . '.' . $tld;
    $domain_reseller_config = domain_reseller_getConfig();
    $regParams = [];

    # Put your code to register domain here
    $headers = array("Accept" => "application/json", "Content-Type" => "application/json; charset=UTF-8");
    $headers['Authorization'] = $domain_reseller_config['token'];
    //domainResellerLogger('domain_ns_list',  $_SESSION['adminid'], $_SESSION['uid'], '', '',$regParams, [],$params['original']['domainname'] , 'success','start');
    $response = domainResellerUnirest\Request::get("{$domain_reseller_config['apiBaseUrl']}domain/{$params['original']['domainname']}/ns", $headers, $regParams);

    // $st = 'success';
    // $trackid = '';
    // $procid = '';

    if ($response->code != 200) {
        $st = 'failed';
        $values['error'] = $response->body->errorDetails;
    } elseif (isset($response->body->result->domain_nservers_nserver_handle)) {
        foreach ($response->body->result->domain_nservers_nserver_handle as $index => $ns) {
            $values['ns' . ($index + 1)] = $ns;
        }
    }

    //domainResellerLogger('domain_ns_list',  $_SESSION['adminid'], $_SESSION['uid'],$procid, $trackid,$regParams,$response,$params['original']['domainname'] , $st,'end');
    return $values;
}

function domain_reseller_SaveNameservers($params)
{

    $values = [];
    $tld = $params["tld"];
    $sld = $params["sld"];
    $params['original']['domainname'] = $sld . '.' . $tld;
    $domain_reseller_config = domain_reseller_getConfig();
    $tld = $params['tld'];
    $ns_list[] = strtolower($params["ns1"]);
    $ns_list[] = strtolower($params["ns2"]);
    $ns_list[] = strtolower($params["ns3"]);
    $ns_list[] = strtolower($params["ns4"]);
    $checkNsValidator = domain_reseller_nsValidation($ns_list, $params['original']['domainname'], false);
    if ($checkNsValidator != '') {
        $values['error'] = $checkNsValidator;
        return $values;
    }

    $regParams = [
        'tld' => $tld,
        'ns_list' => $ns_list
    ];

    # Put your code to register domain here
    $headers = array("Accept" => "application/json", "Content-Type" => "application/json; charset=UTF-8");
    $headers['Authorization'] = $domain_reseller_config['token'];
    $requestParams = $regParams;
    $requestParams['domainid'] = $params['domainid'];
    $requestParams['requestTime'] = time();
    $regParams = json_encode($regParams);

    $response = domainResellerUnirest\Request::put("{$domain_reseller_config['apiBaseUrl']}domain/{$params['original']['domainname']}", $headers, $regParams);

    # If error, return the error message in the value below
    $values = [];
    $st = 'pending';
    $trackid = '';
    $procid = '';

    if ($response->code == 200) {
        $trackid = $response->body->result->tracking_id;
        $procid = $response->body->result->processing_id;
    } else {
        $st = 'failed';
        $values['error'] = $response->body->errorDetails;
    }

    $requestParams['responseTime'] = time();
    domainResellerLogger('domain_ns_modify', $_SESSION['adminid'], $_SESSION['uid'], $procid, $trackid, $requestParams, $response->body, $params['original']['domainname'], $st);
    return $values;
}

function domain_reseller_RegisterDomain($params)
{
    $values = [];
    $tld = $params["tld"];
    $sld = $params["sld"];

    $params['original']['domainname'] = trim($sld . '.' . $tld);
    $domain_reseller_config = domain_reseller_getConfig();
    // if (!isset($domain_reseller_config['contacts'][ $params['tld'] ])){
    //     return [ 'error' => 'invalid tld' ];
    // }


    $tld = $params['tld'];
    $ns_list[] = strtolower($params["ns1"]);
    $ns_list[] = strtolower($params["ns2"]);
    $ns_list[] = strtolower($params["ns3"]);
    $ns_list[] = strtolower($params["ns4"]);
    $checkNsValidator = domain_reseller_nsValidation($ns_list, $params['original']['domainname'], true);
    if ($checkNsValidator != '') {
        $values['error'] = $checkNsValidator;
        return $values;
    }
    $period = $params["regperiod"];
    $regParams = [
        'tld' => $tld,
        'ns_list' => $ns_list,
        'period' => $period * 12,
        'name' => $params['firstname'] . ' ' . $params['lastname'],
        'email' => $params['email'],
        'address_1' => $params['address1'],
        'address_2' => $params['address2'],
        'city' => $params['city'],
        'postal_code' => $params['postcode'],
        'country' => $params['countrycode'],
        'phone' => $params['phonenumber'],
        'organization' => $params['companyname'],
        'protection' => (isset($params['idprotection']) && $params['idprotection'] == true) ? 1 : 0,
        'dns' => (isset($params['dnsmanagement']) && $params['dnsmanagement'] == true) ? 1 : 0,

    ];

    # Put your code to register domain here
    $headers = array("Accept" => "application/json", "Content-Type" => "application/json; charset=UTF-8");
    $headers['Authorization'] = $domain_reseller_config['token'];
    $requestParams = $regParams;
    $requestParams['requestTime'] = time();
    $requestParams['domainid'] = $params['domainid'];
    $regParams = json_encode($regParams);

    $response = domainResellerUnirest\Request::post("{$domain_reseller_config['apiBaseUrl']}domain/{$params['original']['domainname']}/register", $headers, $regParams);

    $st = 'failed';
    $trackid = '';
    $procid = '';

    if ($response->code == 200) {
        $trackid = $response->body->result->tracking_id;
        $procid = $response->body->result->processing_id;
        $st = 'pending';
        if (is_numeric($response->body->result->tracking_id)) {
            domainResellerLogger('domain_contact_create', $_SESSION['adminid'], $_SESSION['uid'], $trackid, $procid, $requestParams, $response->body, $params['original']['domainname'], $st, 'end');
        }

    } else {
        $values['error'] = $response->body->errorDetails;
    }
    $requestParams['responseTime'] = time();
    domainResellerLogger('domain_register', $_SESSION['adminid'], $_SESSION['uid'], $procid, $trackid, $requestParams, $response->body, $params['original']['domainname'], $st, 'end');
    return $values;
}

function domain_reseller_RenewDomain($params)
{
    $values = [];
    $tld = $params["tld"];
    $sld = $params["sld"];
    $params['original']['domainname'] = trim($sld . '.' . $tld);
    $domain_reseller_config = domain_reseller_getConfig();
    $period = $params["regperiod"];
    $regParams = [
        'period' => $period * 12,
        'protection' => (isset($params['idprotection']) && $params['idprotection'] == true) ? 1 : 0,
        'dns' => (isset($params['dnsmanagement']) && $params['dnsmanagement'] == true) ? 1 : 0,
    ];


    $headers = array("Accept" => "application/json", "Content-Type" => "application/json; charset=UTF-8");
    $headers['Authorization'] = $domain_reseller_config['token'];
    $requestParams = $regParams;
    $requestParams['requestTime'] = time();
    $requestParams['domainid'] = $params['domainid'];
    $regParams = json_encode($regParams);
    //domainResellerLogger('domain_renew',  $_SESSION['adminid'], $_SESSION['uid'], '', '',$regParams, [],$params['original']['domainname'] , 'success','start');
    $response = domainResellerUnirest\Request::post("{$domain_reseller_config['apiBaseUrl']}domain/{$params['original']['domainname']}/renew", $headers, $regParams);
    # If error, return the error message in the value below
    $values = [];


    $st = 'failed';
    $trackid = '';
    $procid = '';

    if ($response->code == 200) {
        $trackid = $response->body->result->tracking_id;
        $procid = $response->body->result->processing_id;
        $st = 'pending';
    } else {
        $values['error'] = $response->body->errorDetails;
    }
    $requestParams['responseTime'] = time();
    domainResellerLogger('domain_renew', $_SESSION['adminid'], $_SESSION['uid'], $procid, $trackid, $requestParams, $response->body, $params['original']['domainname'], $st);
    return $values;
}

function domain_reseller_GetDNS($params)
{
    
    $domain_reseller_config = domain_reseller_getConfig();

    $headers = array("Accept" => "application/json", "Content-Type" => "application/json; charset=UTF-8");
    $headers['Authorization'] = $domain_reseller_config['token'];
    $dns = [];
    $response = domainResellerUnirest\Request::get("{$domain_reseller_config['apiBaseUrl']}dns/{$params['original']['domainname']}", $headers, []);

    if ($response->code != 200) {
        if($response->body->errorDetails == 'ns_invalid'){
            return ['external'=>true,'code'=>'‫برای استفاده از سرویس مدیریت DNS باید NS ها را روی 
, dns1.reseller.world
 dns2.reseller.world
تنظیم نماید.'];
        }else{
            return ['error' => $response->body->errorDetails];
        }
    } else {
        foreach ($response->body->result as $item) {
            if ($item->type == 'NS') {
                continue;
            }
            $dns[] = ['hostname' => $item->name, 'type' => $item->type, 'address' => $item->value, 'priority'=>isset($item->priority) ? $item->priority : null];
        }
    }

    return $dns;

}

function domain_reseller_SaveDNS($params)
{

    foreach ($params['dnsrecords'] as $dnsrecord) {
        if($dnsrecord['hostname'] == '' || $dnsrecord['address'] == ''){
            continue;
        }
        if($dnsrecord['type'] == 'MX'){
            $newDns[] = ['name' => $dnsrecord['hostname'], 'value' => $dnsrecord['address'],'type'=>$dnsrecord['type'],'priority'=>$dnsrecord['priority']];
        }else{
            $newDns[] = ['name' => $dnsrecord['hostname'], 'value' => $dnsrecord['address'],'type'=>$dnsrecord['type']];
        }
    }

    if(empty($newDns)){
        return ['error' => 'invalid records'];
    }

    $domain_reseller_config = domain_reseller_getConfig();
    $headers = array("Accept" => "application/json", "Content-Type" => "application/json; charset=UTF-8");
    $headers['Authorization'] = $domain_reseller_config['token'];
    $response = domainResellerUnirest\Request::post("{$domain_reseller_config['apiBaseUrl']}dns/{$params['original']['domainname']}/bulkAdd", $headers, json_encode($newDns));

    if ($response->code != 200) {
        domainResellerLogger('domain_dns',  $_SESSION['adminid'], $_SESSION['uid'], '', '',$newDns, $response->body,$params['original']['domainname'] , 'failed');
        return ['error'=>$response->body->errorDetails];
    }else{
        domainResellerLogger('domain_dns',  $_SESSION['adminid'], $_SESSION['uid'], '', '',$newDns, $response->body,$params['original']['domainname'] , 'success');
    }

    return [];
}

function domain_reseller_IDProtectToggle($params)
{

    $values = [];
    $tld = $params["tld"];
    $sld = $params["sld"];
    $params['original']['domainname'] = trim($sld . '.' . $tld);
    $domain_reseller_config = domain_reseller_getConfig();


    $headers = array("Accept" => "application/json", "Content-Type" => "application/json; charset=UTF-8");
    $headers['Authorization'] = $domain_reseller_config['token'];
    $requestParams['requestTime'] = time();
    $requestParams['domainid'] = $params['domainid'];

    $regParams = json_encode([]);
    $type = '';
    $updateId = 0;
    if ($params['protectenable'] === true) {
        $updateId = 0;
        $type = 'domain_protection_create';
        $response = domainResellerUnirest\Request::post("{$domain_reseller_config['apiBaseUrl']}domain/{$params['original']['domainname']}/protection", $headers, $regParams);
    } else {
        $updateId = 1;
        $type = 'domain_protection_cancel';
        $response = domainResellerUnirest\Request::delete("{$domain_reseller_config['apiBaseUrl']}domain/{$params['original']['domainname']}/protection", $headers, $regParams);
    }

    # If error, return the error message in the value below
    $values = [];


    $st = 'failed';
    $trackid = '';
    $procid = '';

    if ($response->code == 200) {
        $trackid = $response->body->result->tracking_id;
        $procid = $response->body->result->processing_id;
        $st = 'pending';
    } else {
        Capsule::table('tbldomains')->where('id', '=', $params['domainid'])->update(['idprotection' => $updateId]);
        $values['error'] = $response->body->errorDetails;
        if($response->body->errorDetails == 'domain_expire_lt_1y'){
            $setting = Capsule::table('domain_reseller_management_setting')->where('item', '=', 'protectionFailed')->pluck('value', 'key');
            if (isset($setting['enable'])) {
                $t = domainResellerTicket(array_merge($setting, ['userid' => $_SESSION['uid']]), ['[$domain]' => $params['original']['domainname']]);
                $requestParams['ticket_id'] = $t['id'];
            }
        }
        
    }
    $requestParams['responseTime'] = time();
    domainResellerLogger($type, $_SESSION['adminid'], $_SESSION['uid'], $procid, $trackid, $requestParams, $response->body, $params['original']['domainname'], $st);
    return $values;


}

function domain_reseller_TransferDomain($params)
{
    
    $tld = $params["tld"];
    $sld = $params["sld"];
    $params['original']['domainname'] = trim($sld . '.' . $tld);
    $transfersecret = trim($params["transfersecret"]);
    $values = [];
    if ($transfersecret == '') {
        $values['error'] = 'transfersecret code empty';
        return $values;
    }
    $ns_list[] = strtolower($params["ns1"]);
    $ns_list[] = strtolower($params["ns2"]);
    $ns_list[] = strtolower($params["ns3"]);
    $ns_list[] = strtolower($params["ns4"]);
    $checkNsValidator = domain_reseller_nsValidation($ns_list, $params['original']['domainname'], false);
    if ($checkNsValidator != '') {
        $values['error'] = $checkNsValidator;
        return $values;
    }
    $domain_reseller_config = domain_reseller_getConfig();


    $period = $params["regperiod"];
    $regParams = [
        'transfersecret' => $transfersecret,
        'ns_list' => $ns_list,
        'period' => $period * 12,
        'name' => $params['firstname'] . ' ' . $params['lastname'],
        'email' => $params['email'],
        'address_1' => $params['address1'],
        'address_2' => $params['address2'],
        'city' => $params['city'],
        'postal_code' => $params['postcode'],
        'country' => $params['countrycode'],
        'phone' => $params['phonenumber'],
        'organization' => $params['companyname'],
        'protection' => 0,//(isset($params['idprotection']) && $params['idprotection'] == true) ? 1 : 0,
        'dns' => (isset($params['dnsmanagement']) && $params['dnsmanagement'] == true) ? 1 : 0,
    ];

    # Put your code to register domain here
    $headers = array("Accept" => "application/json", "Content-Type" => "application/json; charset=UTF-8");
    $headers['Authorization'] = $domain_reseller_config['token'];
    $requestParams = $regParams;
    $requestParams['requestTime'] = time();
    $regParams = json_encode($regParams);
    $tmpTransferSecret = $transfersecret[0];
    for ($i = 1; $i < (strlen($transfersecret) - 1); $i++) {
        $tmpTransferSecret .= '*';
    }
    $tmpTransferSecret .= $transfersecret[strlen($transfersecret) - 1];
    $requestParams['transfersecret'] = $tmpTransferSecret;

    $response = domainResellerUnirest\Request::post("{$domain_reseller_config['apiBaseUrl']}domain/{$params['original']['domainname']}/transferIn", $headers, $regParams);
    # If error, return the error message in the value below

    $st = 'failed';
    $trackid = '';
    $procid = '';


    if ($response->code == 200) {
        $trackid = $response->body->result->tracking_id;
        $procid = $response->body->result->processing_id;
        $st = 'pending';
        if (is_numeric($response->body->result->tracking_id)) {
            domainResellerLogger('domain_contact_create', $_SESSION['adminid'], $_SESSION['uid'], $trackid, $procid, $requestParams, $response->body, $params['original']['domainname'], $st, 'end');
        }

    } else {
        $values['error'] = $response->body->errorDetails;
    }

    $requestParams['responseTime'] = time();
    $requestParams['domainid'] = $params['domainid'];
    domainResellerLogger('domain_transferin', $_SESSION['adminid'], $_SESSION['uid'], $procid, $trackid, $requestParams, $response->body, $params['original']['domainname'], $st);
    return $values;

}

function domain_reseller_GetEPPCode($params)
{
    $tld = $params["tld"];
    $sld = $params["sld"];
    $params['original']['domainname'] = trim($sld . '.' . $tld);
    $domain_reseller_config = domain_reseller_getConfig();
    $regParams = [];


    $headers = array("Accept" => "application/json", "Content-Type" => "application/json; charset=UTF-8");
    $headers['Authorization'] = $domain_reseller_config['token'];

    $requestParams = $regParams;
    $requestParams['requestTime'] = time();

    $regParams = json_encode($regParams);
    //domainResellerLogger('domain_getepp',  $_SESSION['adminid'], $_SESSION['uid'], '', '',$regParams, [],$params['original']['domainname'] , 'success','start');
    $response = domainResellerUnirest\Request::post("{$domain_reseller_config['apiBaseUrl']}domain/{$params['original']['domainname']}/getEpp", $headers, $regParams);
    # If error, return the error message in the value below
    $values = [];

    $st = 'failed';
    $trackid = '';
    $procid = '';

    if ($response->code == 200) {
        $trackid = isset($response->body->result->tracking_id) ? $response->body->result->tracking_id : '';
        $procid = isset($response->body->result->processing_id) ? $response->body->result->processing_id : '';
        $st = 'pending';
    } else {
        $values['error'] = $response->body->errorDetails;
    }
    $requestParams['responseTime'] = time();
    $requestParams['domainid'] = $params['domainid'];
    domainResellerLogger('domain_getepp', $_SESSION['adminid'], $_SESSION['uid'], $procid, $trackid, $requestParams, $response->body, $params['original']['domainname'], $st);
    return $values;

}

function domain_reseller_GetRegistrarLock($params)
{
    $tld = $params["tld"];
    $sld = $params["sld"];

    $params['original']['domainname'] = trim($sld . '.' . $tld);
    $domain_reseller_config = domain_reseller_getConfig();
    $regParams = [];

    $headers = array("Accept" => "application/json", "Content-Type" => "application/json; charset=UTF-8");
    $headers['Authorization'] = $domain_reseller_config['token'];

    $response = domainResellerUnirest\Request::get("{$domain_reseller_config['apiBaseUrl']}domain/{$params['original']['domainname']}", $headers, $regParams);


    if ($response->code == 200) {

        if ($response->body->result->domain_lock == "locked") {
            $lockstatus = "locked";
        } else {
            $lockstatus = "unlocked";
        }

        return $lockstatus;

    } else {

        $values['error'] = $response->body->errorDetails;
        return $values;
    }
    //domainResellerLogger('domain_get_lock',  $_SESSION['adminid'], $_SESSION['uid'],$procid, $trackid,$regParams, $response,$params['original']['domainname'] , $st,'end');

}

function domain_reseller_SaveRegistrarLock($params)
{


    $tld = $params["tld"];
    $sld = $params["sld"];
    $params['original']['domainname'] = trim($sld . '.' . $tld);
    $domain_reseller_config = domain_reseller_getConfig();
    $regParams = [];
    $regParams['locked'] = 0;

    if (isset($params["lockenabled"]) && $params["lockenabled"] != 'unlocked') {
        $regParams['locked'] = 1;
    }

    $headers = array("Accept" => "application/json", "Content-Type" => "application/json; charset=UTF-8");
    $headers['Authorization'] = $domain_reseller_config['token'];
    $requestParams = $regParams;
    $requestParams['requestTime'] = time();
    //domainResellerLogger('domain_save_lock',  $_SESSION['adminid'], $_SESSION['uid'], '', '',$regParams, [],$params['original']['domainname'] , 'success','start');
    $regParams = json_encode($regParams);

    $response = domainResellerUnirest\Request::put("{$domain_reseller_config['apiBaseUrl']}domain/{$params['original']['domainname']}/lock", $headers, $regParams);

    # If error, return the error message in the value below
    $st = 'failed';
    $trackid = '';
    $procid = '';
    $values = [];
    if ($response->code == 200) {
        $trackid = isset($response->body->result->tracking_id) ? $response->body->result->tracking_id : '';
        $procid = isset($response->body->result->processing_id) ? $response->body->result->processing_id : '';
        $st = 'pending';
    } else {
        $values['error'] = $response->body->errorDetails;
        if($response->body->errorDetails == 'transfer_prohibited'){
            $values['error'] = 'بر اساس قوانین مرکز ثبت تا 60 روز پس از تغییر مشخصات مالک، دامنه در وضعیت transfer prohibited lock است و امکان انتقال آن وجود ندارد';
        }
    }
    $requestParams['responseTime'] = time();
    $requestParams['domainid'] = $params['domainid'];
    domainResellerLogger('domain_save_lock', $_SESSION['adminid'], $_SESSION['uid'], $procid, $trackid, $requestParams, $response->body, $params['original']['domainname'], $st);
    return $values;
}

function domain_reseller_RegisterNameserver($params)
{
    $tld = $params["tld"];
    $sld = $params["sld"];
    $params['original']['domainname'] = trim($sld . '.' . $tld);
    $nameserver = $params["nameserver"];
    $ipaddress = $params["ipaddress"];
    $tmpNs = explode('.', $nameserver);
    $ns = trim($tmpNs[0]);
    if ($ns == '') {
        return ['error' => 'nameserver required'];
    }
    $domain_reseller_config = domain_reseller_getConfig();

    $regParams = [
        'ip' => $ipaddress,
        'ns' => $ns,
    ];

    $res = filter_var($ipaddress, FILTER_VALIDATE_IP);
    if (!$res) {
        return ['error' => 'invalid-ip'];
    }

    $headers = array("Accept" => "application/json", "Content-Type" => "application/json; charset=UTF-8");
    $headers['Authorization'] = $domain_reseller_config['token'];
    $requestParams = $regParams;
    $requestParams['requestTime'] = time();

    $regParams = json_encode($regParams);
    //domainResellerLogger('domain_child_create',  $_SESSION['adminid'], $_SESSION['uid'], '', '',$regParams, [],$params['original']['domainname'] , 'success','start');
    $response = domainResellerUnirest\Request::post("{$domain_reseller_config['apiBaseUrl']}domain/{$params['original']['domainname']}/child/{$ns}", $headers, $regParams);
    # If error, return the error message in the value below
    $values = [];

    $st = 'failed';
    $trackid = '';
    $procid = '';

    if ($response->code == 200) {
        $trackid = isset($response->body->result->tracking_id) ? $response->body->result->tracking_id : '';
        $procid = isset($response->body->result->processing_id) ? $response->body->result->processing_id : '';
        $st = 'pending';
    } else {
        $values['error'] = $response->body->errorDetails;
    }
    $requestParams['responseTime'] = time();
    $requestParams['domainid'] = $params['domainid'];
    domainResellerLogger('domain_child_create', $_SESSION['adminid'], $_SESSION['uid'], $procid, $trackid, $requestParams, $response->body, $params['original']['domainname'], $st);
    return $values;
}

function domain_reseller_ModifyNameserver($params)
{

    $tld = $params["tld"];
    $sld = $params["sld"];
    $params['original']['domainname'] = trim($sld . '.' . $tld);
    $nameserver = $params["nameserver"];
    $newipaddress = $params["newipaddress"];

    $tmpNs = explode('.', $nameserver);
    $ns = trim($tmpNs[0]);
    if ($ns == '') {
        return ['error' => 'nameserver required'];
    }
    $domain_reseller_config = domain_reseller_getConfig();

    $regParams = [
        'ip' => $newipaddress,
        'ns' => $ns,
    ];

    $res = filter_var($newipaddress, FILTER_VALIDATE_IP);
    if (!$res)
        return ['error' => 'invalid-ip'];


    $headers = array("Accept" => "application/json", "Content-Type" => "application/json; charset=UTF-8");
    $headers['Authorization'] = $domain_reseller_config['token'];
    $requestParams = $regParams;
    $requestParams['requestTime'] = time();

    $regParams = json_encode($regParams);
    //domainResellerLogger('domain_child_modify',  $_SESSION['adminid'], $_SESSION['uid'], '', '',$regParams, [],$params['original']['domainname'] , 'success','start');
    $response = domainResellerUnirest\Request::put("{$domain_reseller_config['apiBaseUrl']}domain/{$params['original']['domainname']}/child/{$ns}", $headers, $regParams);
    # If error, return the error message in the value below
    $values = [];

    $st = 'failed';
    $trackid = '';
    $procid = '';

    if ($response->code == 200) {
        $trackid = isset($response->body->result->tracking_id) ? $response->body->result->tracking_id : '';
        $procid = isset($response->body->result->processing_id) ? $response->body->result->processing_id : '';
        $st = 'pending';
    } else {
        $values['error'] = $response->body->errorDetails;
    }
    $requestParams['responseTime'] = time();
    $requestParams['domainid'] = $params['domainid'];
    domainResellerLogger('domain_child_modify', $_SESSION['adminid'], $_SESSION['uid'], $procid, $trackid, $requestParams, $response->body, $params['original']['domainname'], $st);
    return $values;
}

function domain_reseller_DeleteNameserver($params)
{
    $tld = $params["tld"];
    $sld = $params["sld"];
    $params['original']['domainname'] = trim($sld . '.' . $tld);
    $nameserver = $params["nameserver"];

    $tmpNs = explode('.', $nameserver);
    $ns = trim($tmpNs[0]);
    if ($ns == '') {
        return ['error' => 'nameserver required'];
    }
    $domain_reseller_config = domain_reseller_getConfig();

    $regParams = [
        'ns' => $ns,
    ];

    $headers = array("Accept" => "application/json", "Content-Type" => "application/json; charset=UTF-8");
    $headers['Authorization'] = $domain_reseller_config['token'];
    $requestParams = $regParams;
    $requestParams['requestTime'] = time();
    $regParams = json_encode($regParams);
    //domainResellerLogger('domain_child_delete',  $_SESSION['adminid'], $_SESSION['uid'], '', '',$regParams, [],$params['original']['domainname'] , 'success','start');

    $response = domainResellerUnirest\Request::delete("{$domain_reseller_config['apiBaseUrl']}domain/{$params['original']['domainname']}/child/{$ns}", $headers, []);
    # If error, return the error message in the value below
    $values = [];

    $st = 'failed';
    $trackid = '';
    $procid = '';

    if ($response->code == 200) {
        $trackid = isset($response->body->result->tracking_id) ? $response->body->result->tracking_id : '';
        $procid = isset($response->body->result->processing_id) ? $response->body->result->processing_id : '';
        $st = 'pending';
    } else {
        $values['error'] = $response->body->errorDetails;
    }
    $requestParams['responseTime'] = time();
    $requestParams['domainid'] = $params['domainid'];
    domainResellerLogger('domain_child_delete', $_SESSION['adminid'], $_SESSION['uid'], $procid, $trackid, $requestParams, $response->body, $params['original']['domainname'], $st);
    return $values;
}

function domain_reseller_GetContactDetails($params)
{

    $tld = $params["tld"];
    $sld = $params["sld"];
    $params['original']['domainname'] = trim($sld . '.' . $tld);
    $domain_reseller_config = domain_reseller_getConfig();
    $regParams = [];
    $values = [];
    $headers = array("Accept" => "application/json", "Content-Type" => "application/json; charset=UTF-8");
    $headers['Authorization'] = $domain_reseller_config['token'];

    //domainResellerLogger('domain_owner_getinfo',  $_SESSION['adminid'], $_SESSION['uid'], '', '',$regParams, [],$params['original']['domainname'] , 'success','start');
    $response = domainResellerUnirest\Request::get("{$domain_reseller_config['apiBaseUrl']}domain/{$params['original']['domainname']}", $headers, $regParams);

    # If error, return the error message in the value below
    //$st = 'failed';
    //$trackid = '';
    //$procid = '';

    if ($response->code == 200) {
        //$trackid = isset($response->body->result->tracking_id) ? $response->body->result->tracking_id : '' ;
        //$procid = isset($response->body->result->processing_id) ? $response->body->result->processing_id : '';
        //$st = 'success';
    } else {
        $values['error'] = $response->body->errorDetails;
        return $values;
    }
    //domainResellerLogger('domain_owner_getinfo',  $_SESSION['adminid'], $_SESSION['uid'],$procid, $trackid,$regParams, $response,$params['original']['domainname'] , $st,'end');

    if (!empty($response->body->result)) {
        $whoisData = $response->body->result;
        //$lang = domainResellerGetLanguage();

        $Registrant = 'Registrant';//$lang['Registrant'];
        $Admin = 'Admin';//$lang['Admin'];
        $adminContact = '';
        foreach ($whoisData as $key => $value) {

            if ($key == 'domain_name') {
                $values[$Registrant]["Name"] = $value;
                $values[$Admin]["Name"] = $value;
            } elseif ($key == 'domain_email') {
                $values[$Registrant]["Email"] = $value;
                $values[$Admin]["Email"] = $value;
            } elseif ($key == 'domain_organization') {
                $values[$Registrant]["Company Name"] = $value;
                $values[$Admin]["Company Name"] = $value;
            } elseif ($key == 'domain_address_1') {
                $values[$Registrant]["Address"] = $value;
                $values[$Admin]["Address"] = $value;
            } elseif ($key == 'domain_country') {
                $values[$Registrant]["Country"] = $value;
                $values[$Admin]["Country"] = $value;
            } elseif ($key == 'domain_state') {
                $values[$Registrant]["State"] = $value;
                $values[$Admin]["State"] = $value;
            } elseif ($key == 'domain_city') {
                $values[$Registrant]["City"] = $value;
                $values[$Admin]["City"] = $value;
            } elseif ($key == 'domain_postal_code') {
                $values[$Registrant]["Postcode"] = $value;
                $values[$Admin]["Postcode"] = $value;
            } elseif ($key == 'domain_phone') {
                $values[$Registrant]["Phone"] = $value;
                $values[$Admin]["Phone"] = $value;
            } elseif ($key == 'domain_fax') {
                $values[$Registrant]["Fax"] = $value;
                $values[$Admin]["Fax"] = $value;
            } elseif ($key == 'domain_admin_c') {
                $adminContact = $value;
            }
        }
        if ($adminContact != '') {
            $response = domainResellerUnirest\Request::get("{$domain_reseller_config['apiBaseUrl']}contact/{$adminContact}", $headers, []);
            if ($response->code == 200) {
                foreach ($response->body->result as $key => $value) {

                    if ($key == 'name') {
                        $values[$Admin]["Name"] = $value;
                    } elseif ($key == 'email') {
                        $values[$Admin]["Email"] = $value;
                    } elseif ($key == 'organization') {
                        $values[$Admin]["Company Name"] = $value;
                    } elseif ($key == 'address_1') {
                        $values[$Admin]["Address"] = $value;
                    } elseif ($key == 'country') {
                        $values[$Admin]["Country"] = $value;
                    } elseif ($key == 'state') {
                        $values[$Admin]["State"] = $value;
                    } elseif ($key == 'city') {
                        $values[$Admin]["City"] = $value;
                    } elseif ($key == 'postal_code') {
                        $values[$Admin]["Postcode"] = $value;
                    } elseif ($key == 'phone') {
                        $values[$Admin]["Phone"] = $value;
                    } elseif ($key == 'fax') {
                        $values[$Admin]["Fax"] = $value;
                    }
                }
            }
        }
    }

    return $values;
}

function domain_reseller_SaveContactDetails($params)
{
    $tld = $params["tld"];
    $sld = $params["sld"];
    $params['original']['domainname'] = trim($sld . '.' . $tld);
    # Data is returned as specified in the GetContactDetails() function

    //$lang = domainResellerGetLanguage();

    $Registrant = 'Registrant';//$lang['Registrant'];
    $Admin = 'Admin';//$lang['Admin'];

    $registrant = createContactDetails($params, $Registrant);
    if (isset($registrant['error'])) {
        return $registrant;
    }
    $admin = createContactDetails($params, $Admin);
    if (isset($admin['error'])) {
        return $admin;
    }
    $regParams = ['Registrant' => $registrant, 'Admin' => $admin];

    $domain_reseller_config = domain_reseller_getConfig();
    $headers = array("Accept" => "application/json", "Content-Type" => "application/json; charset=UTF-8");
    $headers['Authorization'] = $domain_reseller_config['token'];
    $requestParams = $regParams;
    $requestParams['requestTime'] = time();
    $regParams = json_encode($regParams);

    //domainResellerLogger('domain_owner_change',  $_SESSION['adminid'], $_SESSION['uid'], '', '',$regParams, [],$params['original']['domainname'] , 'success','start');
    $response = domainResellerUnirest\Request::put("{$domain_reseller_config['apiBaseUrl']}domain/{$params['original']['domainname']}/whois", $headers, $regParams);

    $requestParams['responseTime'] = time();
    $requestParams['domainid'] = $params['domainid'];

    # If error, return the error message in the value below
    $values = [];
    $trackid = '';
    $procid = '';


    if ($response->code == 200) {

        $extResponse = json_decode($response->body->extraDetails, true);
        domainResellerLogger('domain_owner_change', $_SESSION['adminid'], $_SESSION['uid'], $extResponse['registrant']['result']['processing_id'], $extResponse['registrant']['result']['tracking_id'], $requestParams, $extResponse['registrant'], $params['original']['domainname'], 'pending', 'end');
        if (isset($extResponse['contact'])) {
            if ($extResponse['contact']['status'] != 'failed') {
                domainResellerLogger('domain_contact_create', $_SESSION['adminid'], $_SESSION['uid'], $extResponse['contact']['result']['processing_id'], $extResponse['contact']['result']['tracking_id'], $requestParams, $extResponse['contact'], $params['original']['domainname'], 'pending', 'end');
            } else {
                domainResellerLogger('domain_contact_create', $_SESSION['adminid'], $_SESSION['uid'], '', '', $requestParams, $extResponse['contact'], $params['original']['domainname'], 'failed', 'end');
            }
        }
        if (isset($extResponse['admin'])) {
            if ($extResponse['admin']['status'] != 'failed') {
                domainResellerLogger('domain_modify', $_SESSION['adminid'], $_SESSION['uid'], $extResponse['admin']['result']['processing_id'], $extResponse['admin']['result']['tracking_id'], $requestParams, $extResponse['admin'], $params['original']['domainname'], 'pending', 'end');
            } else {
                domainResellerLogger('domain_modify', $_SESSION['adminid'], $_SESSION['uid'], '', '', $requestParams, $extResponse['admin'], $params['original']['domainname'], 'failed', 'end');
            }
        }

    } else {
        $values['error'] = $response->body->errorDetails;
        domainResellerLogger('domain_owner_change', $_SESSION['adminid'], $_SESSION['uid'], $procid, $trackid, $requestParams, $response->body, $params['original']['domainname'], 'failed', 'end');
    }

    return $values;
}

function createContactDetails($params, $type)
{

    if (isset($params["contactdetails"][$type]["Name"])) {
        $name = $params["contactdetails"][$type]["Name"];
    } elseif (isset($params["contactdetails"][$type]["Full Name"])) {
        $name = $params["contactdetails"][$type]["Full Name"];
    } else {
        $name = $params["contactdetails"][$type]["First Name"] . ' ' . $params["contactdetails"][$type]["Last Name"];
    }

    $email = $params["contactdetails"][$type]["Email"];
    $city = $params["contactdetails"][$type]["City"];
    $phone = $params["contactdetails"][$type]["Phone"];
    $address = $params["contactdetails"][$type]["Address"];
    $postalCode = $params["contactdetails"][$type]["Postcode"];
    $country = $params["contactdetails"][$type]["Country"];
    $fax = isset($params["contactdetails"][$type]["Fax"]) ? $params["contactdetails"][$type]["Fax"] : '';
    $state = isset($params["contactdetails"][$type]["State"]) ? $params["contactdetails"][$type]["State"] : '';
    $organization = isset($params["contactdetails"][$type]["Company Name"]) ? $params["contactdetails"][$type]["Company Name"] : '';

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        return ['error' => $type . ' "email" not valid'];
    }
    if (true !== domain_reseller_validateLatin($name)) {
        return ['error' => $type . " 'name' must be english"];
    }
    if (true !== domain_reseller_validateLatin($city)) {
        return ['error' => $type . " 'city' must be english"];
    }
    if (true !== domain_reseller_validateLatin($address)) {
        return ['error' => $type . " 'address' must be english"];
    }
    if (true !== domain_reseller_validateLatin($country)) {
        return ['error' => $type . " 'country' must be english"];
    }

    if(strlen($address) > 80){
        return ['error' => $type . " 'address' must be less than 80 character"];
    }


    if (!empty($organization) && true !== domain_reseller_validateLatin($organization)) {
        return ['error' => $type . " 'organization' must be english"];
    }
    if (!empty($state) && true !== domain_reseller_validateLatin($state)) {
            return ['error' => $type . " 'state' must be english"];
        }

    if (!empty($fax) && !preg_match('/^(\+)?([0-9]([.,])?)+$/', $fax)) {
        $values['error'] = $type . ' "fax" format invalid';
        return $values;
    }

    if (!preg_match('/^(\+)?([0-9]([.,])?)+$/', $phone)) {
        $values['error'] = $type . ' "phone" format invalid';
        return $values;
    }

    return [
        'name' => $name,
        'email' => $email,
        'organization' => $organization,
        'city' => $city,
        'phone' => $phone,
        'address_1' => $address,
        'postal_code' => $postalCode,
        'country' => $country,
        'fax' => $fax,
        'state' => $state,
    ];
}

function domain_reseller_getConfig()
{
    global $domain_reseller_config;

    if ($domain_reseller_config)
        return $domain_reseller_config;

    $domain_reseller_config['apiBaseUrl'] = domainResellerGetApiUrl();
    $domain_reseller_config['token'] = 'Bearer ' . domainResellerGetToken();
    return $domain_reseller_config;
}

function registrarmodule_MetaData()
{
    return array(
        'DisplayName' => 'Domain Reseller Registrar',
        'APIVersion' => '1.4.2',
    );
}

function domain_reseller_validateLatin($string)
{

    $result = false;
    $string = trim($string);
    if (!empty($string) && preg_match("/^[a-zA-Z0-9\\@\\*\\&\\^\\-_\\.\\+\\,\\s]+$/", $string)) {
        return true;
    }

    return $result;
}

function domain_reseller_getConfigArray()
{

    return array();
}


//function domain_reseller_ClientArea($vars){
//
//    $modulelink = $vars['modulelink'];
//    $version = $vars['version'];
//    $LANG = $vars['_lang'];
//    return array(
//        'pagetitle' => 'RESTful API',
//        'forcessl' => true,
//        'templatefile' => 'clientarea',
//        'requirelogin' => false,
//        'vars' => array(
//            'url' => $_GET['url'],
//            'lang' => $LANG,
//        ),
//    );
//}

function domain_reseller_nsValidation($nsList, $domianName, $flag = true)
{
    if (!is_array($nsList) || count($nsList) < 2) {
        return 'ns_number_error';
    }
    $i = 0;
    foreach ($nsList as $ns) {
        if ($ns == '') {
            continue;
            $i++;
        }
        if ($flag === true) {
            if (strpos($ns, $domianName) !== false) {
                return 'ns_include_domain_name';
            }
        }

        $c = array_intersect($nsList, [$ns]);
        if (count($c) > 1) {
            return 'ns_duplicate';
        }
    }
    if ($i > 2) {
        return 'ns_number_error';
    }
    return '';
}

function domain_reseller_ClientAreaCustomButtonArray()
{

    $menu = array(
        'مشاهده لاگ' => 'requestResult',
        'کنترل پنل دامنه' => 'requestPassword'
    );

    //$check = Capsule::table('domain_reseller_management_log')->where('userid','=',$_SESSION['uid'])->where('status', '=', 'pending')->where('item','=',$vars['original']['domainname'])->where('action','=','domain_transferin')->get();
    //if($check) {
    $menu['کد داخلی تایید انتقال دامنه'] = 'requestInternalTransfer';
    //}
    return $menu;
}

function domain_reseller_AdminCustomButtonArray($params)
{


    $buttonarray = [];
    $item = Capsule::table('tbldomains')->where('id', '=', $params['domainid'])->first();

    if (!$item) {
        return [];
    }
    if ($item->idprotection == 0) {
        $buttonarray["فعال سازی protection"] = "adminProtection";
    }
    if($item->dnsmanagement == 1){
        $buttonarray["غیر فعال کردن dns management"] = "adminDns";   
    }
    
    return $buttonarray;
}

//function domain_reseller_ClientArea ()
//{
//    return array(
//        'templatefile' => 'templates/log_page.tpl',
//        'vars' => [
//            'log'=>'ssdfsdf'
////            'log'=>$logs,
////            'totalPages'=>$totalPages,
//        ],
//    );
//}
//
function domain_reseller_adminProtection($params)
{

    header('Location: addonmodules.php?module=domain_reseller_management&page=domains&op=idProtection&domain=' . $params['original']['domainname']);
    exit(0);
}

function domain_reseller_adminDns($params){
    
    $domain_reseller_config = domain_reseller_getConfig();

    $headers = array("Accept" => "application/json", "Content-Type" => "application/json; charset=UTF-8");
    $headers['Authorization'] = $domain_reseller_config['token'];
    $response = domainResellerUnirest\Request::delete("{$domain_reseller_config['apiBaseUrl']}domain/{$params['original']['domainname']}/dns", $headers, json_encode([]));
    $status = 'failed';
    $reqParams = [];
    $reqParams['requestTime'] = time();
    $return = [];
    if ($response->code == 200) {
        Capsule::table('tbldomains')->where('id','=',$params['original']['domainid'])->update([
            'dnsmanagement' => 0
        ]);
        $status = 'success';
    }else{
        $return['error'] = $response->body->errorDetails;
    }
    $reqParams['responseTime'] = time();
    $reqParams['domainid'] = $params['original']['domainid'];
    domainResellerLogger('domain_dns_deactive', $_SESSION['adminid'], $_SESSION['uid'], '', '', $reqParams, $response->body, $params['original']['domainname'], $status);
    return $return;

}

function domain_reseller_requestResult($vars)
{


    $q = Capsule::table('domain_reseller_management_log')->orderBy('id', 'DESC');
    $q->where('userid', '=', $_SESSION['uid']);
    $q->where('item', '=',$vars['domainname']);

    if (isset($_GET['status']) && $_GET['status'] != 'all') {
        $status = $_GET['status'];
        $q->where('status', '=', $status);
    }

    if (isset($_GET['from']) && $_GET['from'] != '') {
        $from = trim($_GET['from']);
        $q->where('created_at', '>=', $from);
    }
    if (isset($_GET['to']) && $_GET['to'] != '') {
        $to = trim($_GET['to']);
        $q->where('created_at', '<', $to);
    }
    if (isset($_GET['act']) && $_GET['act'] != 'all') {
        $action = trim($_GET['act']);
        $q->where('action', '=', $action);
    } else {
        $q->where('action', 'like', 'domain%');
    }



    $page = 1;
    if (isset($_POST['page'])) {
        $page = $_POST['page'];
    }
    $limit = 30;
    $count = $q->count();
    $startIndex = ($page - 1) * $limit;
    $q->limit($limit);
    $q->offset($startIndex);
    $logs = $q->select()->get();
    $totalPages = ceil($count / $limit);

    return array(
        'templatefile' => 'log_page',
        'vars' => [
            'logs' => $logs,
            'totalPages' => $totalPages,
            'page' => $page
        ],
    );
}

function domain_reseller_requestPassword($vars)
{

    $msg = '';
    $domain_reseller_config = domain_reseller_getConfig();
    $headers = array("Accept" => "application/json", "Content-Type" => "application/json; charset=UTF-8");
    $headers['Authorization'] = $domain_reseller_config['token'];

    if (isset($_POST['submit'])) {

        $requestParams = [];

        $requestParams['requestTime'] = time();
        $response = domainResellerUnirest\Request::get("{$domain_reseller_config['apiBaseUrl']}resellerWorld/{$vars['original']['domainname']}/password", $headers, []);
        if ($response->code == 200) {
            $msg = '<div style="color: green;">درخواست شما با موفقیت ثبت گردید ، پسورد جدید برای ایمیل صاحب دامنه ارسال میگردد</div>';
        } else {
            $msg = '<div style="color: red;">' . $response->body->errorDetails . '</div>';
        }
        $requestParams['responseTime'] = time();
        domainResellerLogger('domain_reset_password', $_SESSION['adminid'], $_SESSION['uid'], '', '', $requestParams, $response->body, $vars['original']['domainname'], $response->body->status, 'end');
    }

    $response = domainResellerUnirest\Request::get("{$domain_reseller_config['apiBaseUrl']}domain/{$vars['original']['domainname']}", $headers, []);
    $data = [];
    if ($response->code == 200) {
        foreach ($response->body->result as $key => $item) {
            $data[$key] = $item;
        }
    } else {
        $msg = $response->body->errorDetails;
    }


    return array(
        'templatefile' => 'reset_page',
        'vars' => [
            'msg' => $msg,
            'whoisData' => $data,
            'domainID' => $vars['original']['domainid']
        ],
    );
}

function domain_reseller_requestInternalTransfer($vars)
{

    //$flag = false;
    //$check = Capsule::table('domain_reseller_management_log')->where('userid','=',$_SESSION['uid'])->where('status', '=', 'pending')->where('item','=',$vars['original']['domainname'])->where('action','=','domain_transferin')->get();
    //if($check){
    $flag = true;
    //}

    if ($flag === true) {
        $msg = '';
        if (isset($_POST['verify'])) {
            if (!empty($_POST['verify'])) {
                $domain_reseller_config = domain_reseller_getConfig();
                $headers = array("Accept" => "application/json", "Content-Type" => "application/json; charset=UTF-8");
                $headers['Authorization'] = $domain_reseller_config['token'];
                $requestParams = [];

                $transfersecret = $_POST['verify'];
                $tmpTransferSecret = $transfersecret[0];
                for ($i = 1; $i < (strlen($transfersecret) - 1); $i++) {
                    $tmpTransferSecret .= '*';
                }
                $tmpTransferSecret .= $transfersecret[strlen($transfersecret) - 1];

                $requestParams['verifyCode'] = $tmpTransferSecret;

                $requestParams['requestTime'] = time();

                $response = domainResellerUnirest\Request::post("{$domain_reseller_config['apiBaseUrl']}resellerWorld/{$vars['original']['domainname']}/verify", $headers, json_encode(['verify' => $_POST['verify']]));
                if ($response->code == 200) {
                    $msg = '<div style="color: green;">انتقال دامنه با موفقیت انجام پذیرفت</div>';
                } else {
                    $msg = '<div style="color: red;">' . $response->body->errorDetails . '</div>';
                }
                $requestParams['responseTime'] = time();
                domainResellerLogger('domain_verify_transfer', $_SESSION['adminid'], $_SESSION['uid'], '', '', $requestParams, $response->body, $vars['original']['domainname'], $response->body->status, 'end');
            } else {
                $msg = '<div style="color: red;">لطفا فیلد های ضروری را وارد نمایید</div>';
            }
        }
    }
    return array(
        'templatefile' => 'transfer_page',
        'vars' => [
            'msg' => $msg,
            'flag' => $flag
        ],
    );
}