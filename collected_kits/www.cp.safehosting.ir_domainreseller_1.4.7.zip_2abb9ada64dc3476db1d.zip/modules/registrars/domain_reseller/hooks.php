<?php
/**
 * Created by PhpStorm.
 * User: MJahanbakhsh
 * Date: 23/02/2017
 * Time: 11:56 AM
 */

use \Illuminate\Database\Capsule\Manager as Capsule;
function hook_domain_reseller_dns($vars){

    require_once __DIR__.'/../../addons/domain_reseller_management/utils.php';
    $invoice = Capsule::table('tblinvoiceitems')->where('invoiceid', '=', $vars['invoiceid'])->where('userid','=',$_SESSION['uid'])->where('type','=','DomainAddonDNS')->first();
    if(!$invoice){
        return '';
    }
    $domain = Capsule::table('tbldomains')->where('id','=',$invoice->relid)->first();
    if(!$domain){
        domainResellerLogger('domain_dns_active', $_SESSION['adminid'], $invoice->userid, '', '', $invoice, domainResellerResponseTemplate(['domain not found'],'-1','failed'), $invoice->relid, 'failed');
        return '';
    }
//    if($domain->dnsmanagement == 1){
//        domainResellerLogger('domain_dns_active', $_SESSION['adminid'], $domain->userid, '', '', $domain, domainResellerResponseTemplate(['dns management activated'],'-1','failed'), $domain->domain, 'failed');
//        return '';
//    }
    require_once __DIR__.'/../../addons/domain_reseller_management/unirest-php/Unirest.php';

    $apiBaseUrl = domainResellerGetApiUrl();
    $token = 'Bearer ' . domainResellerGetToken();

    $headers = array("Accept" => "application/json", "Content-Type" => "application/json; charset=UTF-8");
    $headers['Authorization'] = $token;

    $regParams = [];
    $regParams['requestTime'] = time();
    $response = domainResellerUnirest\Request::post($apiBaseUrl . 'domain/'.$domain->domain.'/dns', $headers, json_encode([]));
    $status = 'success';
    if ($response->code != 200) {
        Capsule::table('tbldomains')->where('id','=',$invoice->relid)->update([
            'dnsmanagement' => 0
        ]);
        $status = 'failed';
    }
    $regParams['responseTime'] = time();
    domainResellerLogger('domain_dns_active', $_SESSION['adminid'], $domain->userid, '', '', $regParams, $response->body, $domain->domain, $status);
}

add_hook('InvoicePaid', 1, 'hook_domain_reseller_dns');
