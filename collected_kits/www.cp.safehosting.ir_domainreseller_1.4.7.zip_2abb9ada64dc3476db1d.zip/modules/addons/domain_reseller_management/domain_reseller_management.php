<?php

if(!isset($_SESSION['adminid'])){
    exit;
}
use \Illuminate\Database\Capsule\Manager as Capsule;
use \Illuminate\Database\Schema\Blueprint;

require_once __DIR__ . '/utils.php';
//error_reporting(E_ALL);
//ini_set('display_errors', 'On');
$moduleParams = array();
function domain_reseller_management_config()
{


    return array(
        "name" => "Domain Reseller",
        "description" => "<div style='direction: rtl;color:#007500'> Domain Reseller</div>",
        "version" => "1.0",
        "author" => "resellerworld",
        "fields" => array()
    );

}

function domain_reseller_management_activate()
{

    $check = Capsule::schema()->hasTable('domain_reseller_management_setting');

    if (!$check) {
        Capsule::schema()->create(
            'domain_reseller_management_setting',
            function ($table) {
                $table->charset = 'utf8';
                $table->collation = 'utf8_general_ci';
                $table->increments('id');
                $table->string('item', 40);
                $table->string('key', 20);
                $table->string('value', 200);
            }
        );
    }


    $check = Capsule::schema()->hasTable('domain_reseller_management_log');
    if (!$check) {
        Capsule::schema()->create(
            'domain_reseller_management_log',
            function ($table) {
                $table->charset = 'utf8';
                $table->collation = 'utf8_general_ci';
                $table->increments('id');
                $table->integer('userid')->nullable();
                $table->integer('adminid')->nullable();
                $table->string('trackid', 100)->nullable();
                $table->string('procid', 11)->nullable();
                $table->string('status', 20)->nullable();
                $table->string('item', 200)->nullable();
                $table->string('action', 200)->nullable();
                $table->text('request')->nullable();
                $table->text('result')->nullable();
                $table->timestamps();
            }
        );

    }
    $check = Capsule::schema()->hasTable('domain_reseller_management_invoice');
    if (!$check) {
        Capsule::schema()->create(
            'domain_reseller_management_invoice',
            function ($table) {
                $table->charset = 'utf8';
                $table->collation = 'utf8_general_ci';
                $table->increments('id');
                $table->integer('userid');
                $table->integer('invoiceid');
                $table->integer('serviceid');
                $table->string('create_at', 11);
                $table->string('update_at', 11)->nullable();
                $table->timestamps();
            }
        );
    }


    $check = Capsule::schema()->hasTable('domain_reseller_management_promotion');

    if (!$check) {
        Capsule::schema()->create(
            'domain_reseller_management_promotion',
            function ($table) {
                $table->charset='utf8';
                $table->collation = 'utf8_general_ci';
                $table->increments('id');
                $table->string('tld', 50);
                $table->string('type', 50);
                $table->integer('promotionid');
                $table->string('currency',10);
                $table->integer('msetupfee');
                $table->integer('qsetupfee');
                $table->integer('ssetupfee');
                $table->integer('asetupfee');
                $table->integer('bsetupfee');
                $table->integer('monthly');
                $table->integer('quarterly');
                $table->integer('semiannually');
                $table->integer('annually');
                $table->integer('biennially');
                $table->integer('relid');
                $table->unique(['tld','type']);
                $table->timestamps();
            }
        );
    }

}

/*


*/
function domain_reseller_management_output($vars)
{

    global $moduleParams;
    $moduleParams = $vars;
    $moduleParams['apiurl'] = domainResellerGetApiUrl();
    $moduleParams['token'] = 'Bearer ' . domainResellerGetToken();
    $moduleParams['language'] = domainResellerGetLanguage();

    $baseUrl = sprintf(
        "%s://%s/",
        isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] != 'off' ? 'https' : 'http',
        $_SERVER['SERVER_NAME']
    );
    $moduleParams['baseUrl'] = $baseUrl;
   
    ob_start();
    if (isset($_SERVER['HTTP_X_REQUESTED_WITH']) && !empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest') {
        ob_clean();
        domain_reseller_management_getRoute();
    } else {
        require_once dirname(__FILE__) . DIRECTORY_SEPARATOR . 'views' . DIRECTORY_SEPARATOR . 'index.php';

    }
    ob_end_flush();
}

function domain_reseller_management_getRoute()
{
    global $moduleParams;
    $page = 'dashboard.php';
    if (isset($_GET['page'])) {
        switch ($_GET['page']) {
            case 'contact':
                $page = 'contact.php';
                break;
            case 'setting':
                $page = 'setting.php';
                break;
            case 'logs':
                $page = 'logs.php';
                break;
            case 'domaintld':
                $page = 'domaintld.php';
                break;
            case 'reseller':
                $page = 'reseller.php';
                break;
            case 'domains':
                $page = 'domains.php';
                break;
            case 'feedback':
                $page = 'feedback.php';
                break;
            case 'upgrade':
                $page = 'upgrade.php';
                break;
            case 'emails':
                $page = 'emails.php';
                break;
            default:
                $page = 'dashboard.php';
                break;
        }
    }

    require_once dirname(__FILE__) . DIRECTORY_SEPARATOR . $page;

}

function callMethod()
{
    if (isset($_GET['op'])) {
        if (function_exists($_GET['op'])) {
            call_user_func($_GET['op']);
        } else {
            echo 'invalid request';
            exit;
        }

    }
}


