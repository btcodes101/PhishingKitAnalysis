<?php
if(!isset($_SESSION['adminid'])){
    exit;
}
if(isset($_POST['domain_reseller_management_feedback'])){
    require_once dirname(__FILE__).DIRECTORY_SEPARATOR.'unirest-php'.DIRECTORY_SEPARATOR.'Unirest.php';
    $err = [];
    global $moduleParams;

    $headers = array("Accept" => "application/json","Content-Type"=>"application/json; charset=UTF-8",);
    $headers['Authorization'] = $moduleParams['token'];
    $params = [];
    $params['message'] = $_POST['domain_reseller_management_feedback'];
    $params = json_encode($params);
    $response = domainResellerUnirest\Request::post($moduleParams['apiurl'] . 'reseller/feedback', $headers, $params);

    if ($response->code != 200) {
        $err[] = $response->body->errorDetails;
    }else{
        $suc = 'باتشکر نظر شما با موفقیت ارسال گردید';
    }
}

require_once dirname(__FILE__).DIRECTORY_SEPARATOR.'views'.DIRECTORY_SEPARATOR.'feedback.php';
