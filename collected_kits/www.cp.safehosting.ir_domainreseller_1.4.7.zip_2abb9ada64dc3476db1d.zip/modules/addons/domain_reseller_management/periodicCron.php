<?php
use \Illuminate\Database\Capsule\Manager as Capsule;

#transfer out check


$setting = Capsule::table('domain_reseller_management_setting')->where('item', '=', 'transferOut')->pluck('value', 'key');

if (isset($setting['enable'])) {
    $time = time();
    $lastUpdate = Capsule::table('domain_reseller_management_setting')->where('item', '=', 'transferOutLastUpdate')->value('value');
    if (!$lastUpdate) {
        $lastUpdate = 0;
        Capsule::table('domain_reseller_management_setting')->insert([
            'value' => $time,
            'item' => 'transferOutLastUpdate'
        ]);
    }

    $offset = $setting['period'] * 86400;

    if (($lastUpdate + $offset) < $time) {


        $regParams = ['lastUpdate' => $lastUpdate, 'type' => 'transferOut'];

        $requestParams = $regParams;
        $requestParams['requestTime'] = time();

        $response = domainResellerUnirest\Request::get($apiBaseUrl . 'domain', $headers, $regParams);
        $requestParams['responseTime'] = time();

        if ($response->code == 200) {
            Capsule::table('domain_reseller_management_setting')->where('item', '=', 'transferOutLastUpdate')->update([
                'value' => $time
            ]);

            if (!empty($response->body->result)) {

                foreach ($response->body->result as $item) {
                    $tmpReq = [];
                    if (isset($setting['ticketEnable'])) {
                        $domain = Capsule::table('tbldomains')->where('domain', '=', $item->domain)->where('registrar', '=', 'domain_reseller')->where('status', '=', 'Active')->first();
                        $t = domainResellerTicket(array_merge($setting, ['userid' => $domain->userid]), ['[$domain]' => $item->domain]);
                        if (isset($t['id'])) {
                            $tmpReq['ticket_id'] = $t['id'];
                        }
                    }
                    if (isset($setting['sync'])) {
                        Capsule::table('tbldomains')->where('id', '=', $domain->id)->update(['status' => 'Cancelled']);
                        $command = "logactivity";
                        $values["description"] = isset($setting['log']) ? $setting['log'] : domainResellerTranslate('setting_transfer_out_default_log_msg');
                        $values['description'] = str_replace('[$domain]', $item->domain, $values['description']);
                        $results = localAPI($command, $values, $adminuser);
                        $tmpReq['sync'] = $results;
                    }
                    domainResellerLogger('cron_transfer_out', '', '', '', '', $tmpReq, $item, $item->domain, 'success');
                }
            } else {
                domainResellerLogger('cron_transfer_out', '', '', '', '', $requestParams, $response->body, '', 'success');
            }
        } else {
            domainResellerLogger('cron_transfer_out', '', '', '', '', $requestParams, $response->body, '', 'failed');
        }
    }
}


#email unverified

$setting = Capsule::table('domain_reseller_management_setting')->where('item', '=', 'emailUnverified')->pluck('value', 'key');
if (isset($setting['enable'])) {
    $time = time();
    $lastUpdate = Capsule::table('domain_reseller_management_setting')->where('item', '=', 'emailUnverifiedLastUpdate')->value('value');

    if (!$lastUpdate) {
        $lastUpdate = 0;
        Capsule::table('domain_reseller_management_setting')->insert([
            'value' => $time,
            'item' => 'emailUnverifiedLastUpdate'
        ]);
    }

    $offset = 86400;

    if (($lastUpdate + $offset) < $time) {
        
       
        $response = domainResellerUnirest\Request::get($apiBaseUrl . 'email', $headers, []);
  

        if ($response->code == 200) {
            if (!empty($response->body->result)) {
                Capsule::table('domain_reseller_management_setting')->where('item', '=', 'emailUnverifiedLastUpdate')->update([
                    'value' => $time
                ]);
                foreach ($response->body->result as $email) {
                    $requestParams = [];
                    $item = Capsule::table('domain_reseller_management_log')->where('status', '=', 'failed')->where('trackid','=',$email->email)->where('item', '=', $email->domain)->where('action', '=', 'email_unverified')->first();
                    if($item){
                        continue;
                    }
                    $item = Capsule::table('domain_reseller_management_log')->where('status', '=', 'pending')->where('trackid','=',$email->email)->where('item', '=', $email->domain)->where('action', '=', 'email_unverified')->first();
                    if ($item) {
                        $tmpReq = json_decode($item->request);
                        if (!isset($tmpReq->failedEmailTicket) && $email->status == 'failed') {
                            $setting['reply'] = $setting['failedReply'];
                            $setting['status'] = $setting['failedStatus'];
                            $t = domainResellerTicket(array_merge($setting, ['userid' => $item->userid]), ['[$domain]' => $email->domain, '[$email]' => $email->email],$tmpReq->pendingEmailTicket);
                            if (isset($t['id'])) {
                                $tmpReq['failedEmailTicket'] = $t['id'];
                                Capsule::table('domain_reseller_management_log')->where('id', '=', $item->id)->update(['status' => 'failed', 'request' => json_encode($tmpReq)]);
                            }
                        }
                    } else {


                        $item = Capsule::table('tbldomains')->where('status', '=', 'Active')->where('registrar','=','domain_reseller')->where('domain','=',$email->domain)->first();
                        if (!$item) {
                            domainResellerLogger('cron_email_unverified', '', '', '', '', $requestParams, array_merge((array)$email, ['error' => 'domain not found']), $email->domain , 'failed');
                        } else {

                            if($email->status == 'failed'){

                                $setting['reply'] = $setting['failedReply'];
                                $setting['status'] = $setting['failedStatus'];
                                $t = domainResellerTicket(array_merge($setting, ['userid' => $item->userid]), ['[$domain]' => $email->domain, '[$email]' => $email->email]);
                                if (isset($t['id'])) {
                                    $requestParams['failedEmailTicket'] = $t['id'];
                                }
                            }else{
                                $setting['reply'] = $setting['pendingReply'];
                                $setting['status'] = $setting['pendingStatus'];
                                $t = domainResellerTicket(array_merge($setting, ['userid' => $item->userid]), ['[$domain]' => $email->domain, '[$email]' => $email->email]);
                                if (isset($t['id'])) {
                                    $requestParams['pendingEmailTicket'] = $t['id'];
                                }
                            }
                            domainResellerLogger('cron_email_unverified', '', $item->userid, '', $email->email, $requestParams, $email, $email->domain, $email->status);
                        }
                    }
                }
            } else {
                domainResellerLogger('cron_email_unverified', '', '', '', '', $requestParams, $response->body, '', 'success');
            }
        } else {
            domainResellerLogger('cron_email_unverified', '', '', '', '', $requestParams, $response->body, '', 'failed');
        }
    }
}

#charge check
$setting = Capsule::table('domain_reseller_management_setting')->where('item', '=', 'chargeCheck')->pluck('value', 'key');
if (isset($setting['enable'])) {
    $time = time();
    $lastUpdate = Capsule::table('domain_reseller_management_setting')->where('item', '=', 'chargeCheckLastUpdate')->value('value');
    if (!$lastUpdate) {
        $lastUpdate = 0;
        Capsule::table('domain_reseller_management_setting')->insert([
            'value' => $time,
            'item' => 'chargeCheckLastUpdate'
        ]);
    }

    $offset = 86400 * $setting['period'];

    if (($lastUpdate + $offset) < $time) {


        $response = domainResellerUnirest\Request::get($apiBaseUrl . 'reseller', $headers, ['version' => domainResellerGetVersion()]);

        if ($response->code == 200) {

            Capsule::table('domain_reseller_management_setting')->where('item', '=', 'chargeCheckLastUpdate')->update([
                'value' => $time
            ]);
            
            if ($response->body->result->charge < $setting['amount']) {


                $client = Capsule::table('tbladmins')->where('id', $setting['admin'])->first();
                $subject = "اخطار کاهش میزان شارژ";
                $body = "<p><h3>سلام</h3></p><p>موجودی حساب نمایندگی دامنه شما از " . number_format($setting['amount']) . " ریال کمتر شده است</p><p>لطفا نسبت به شارژ حساب خود اقدام نمایید</p><p>با تشکر</p>";
                $php = new PHPMailer();
                $smtp = Capsule::table('tblconfiguration')->whereIn('setting',array('MailType','SMTPHost','SMTPUsername','SMTPPassword','SMTPPort','Email'))->pluck('value','setting');

                if($smtp['MailType'] == 'smtp'){
                    $command = "decryptpassword";
                    $values["password2"] = $smtp['SMTPPassword'];
                    $password = localAPI($command,$values,$adminuser);
                    $mail = new PHPMailer(true);
                    $mail->isSMTP();
                    $mail->Host = $smtp['SMTPHost'];
                    $mail->SMTPAuth = true;
                    $mail->Username = $smtp['SMTPUsername'];
                    $mail->Password = $password['password'];
                    $mail->Port = $smtp['SMTPPort'];
                    $mail->setFrom($smtp['Email'], 'ایران سرور');
                    $mail->isHTML(true);
                    $mail->CharSet = 'UTF-8';
                    $mail->XMailer = ' ';
                    $mail->SMTPOptions = array(
                        'ssl' => array(
                            'verify_peer' => false,
                            'verify_peer_name' => false,
                            'allow_self_signed' => true
                        )
                    );
                    $client_name = $client->firstname.' '.$client->lastname;
                    $mail->addAddress($client->email, $client_name);
                    
                    $mail->Subject = $subject;
                    $mail->Body  = $body;
                    //$mail->SMTPDebug = 4;
                    try{
                        $mail->send();
                    }catch (\Exception $ex){
                        var_dump($ex->getMessage());
                    }
                }else{
                    $header = "MIME-Version: 1.0\r\n";
                    $header.= "Content-Type: text/html; charset=utf-8\r\n";
                    $header.= "X-Priority: 1\r\n";
                    mail($client->email,$subject,$body,$header);
                }
            }
        }
    }
}