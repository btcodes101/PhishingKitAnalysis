<?php
if(!isset($_SESSION['adminid'])){
	exit;
}
require_once dirname(__FILE__).DIRECTORY_SEPARATOR.'unirest-php'.DIRECTORY_SEPARATOR.'Unirest.php';
callMethod();
function create(){
	if(isset($_POST['contactSubmit']) && isset($_POST['tld'])){
		$error = checkValidate();
		if(empty($error)){
			global $moduleParams;
			$headers = array("Accept" => "application/json","Content-Type"=>"application/json; charset=UTF-8");
			$headers['Authorization'] = $moduleParams['token'];

			$regParams = $_POST['contact'];
			$requestParams = $regParams;
			foreach ($_POST['tld'] as $tld) {

				$sanction = ['ir','sy','cu','sd'];
				if($_POST['sanction'][$tld] == 1 && in_array(strtolower($regParams['country']),$sanction)){
					$error[] = 'امکان انتخاب این کشور برای '.$tld.' وجود ندارد';
					continue;
				}
				
				$requestParams['requestTime'] = time();
				$regParams['tld'] = $tld;
				$requestParams['tld'] = $tld;
				$response = domainResellerUnirest\Request::post($moduleParams['apiurl'].'contact', $headers, json_encode($regParams));
				$st = 'pending';
				$trackid = '';
				$procid = '';
				if($response->code == 200){
					$trackid = $response->body->result->tracking_id;
					$procid = $response->body->result->processing_id;
					$suc = 'عملیات با موفقیت انجام پذیرفت شماره پیگیری : '. $response->body->result->tracking_id;
				}else {
					$st = 'failed';
					$error[] = isset($response->body->errorDetails) ? $response->body->errorDetails : 'Internal Error';
				}
				$requestParams['responseTime'] = time();
				domainResellerLogger('admin_contact_create',$_SESSION['adminid'], '', $procid, $trackid,$requestParams,$response->body ,$tld, $st);
			}
		}
	}
	$tldList = getTld();
	require_once dirname(__FILE__).DIRECTORY_SEPARATOR.'views'.DIRECTORY_SEPARATOR.'contact_create.php';
}
function modify(){
	global $moduleParams;
	$error = [];
	$headers = array("Accept" => "application/json","Content-Type"=>"application/json; charset=UTF-8");
	$headers['Authorization'] = $moduleParams['token'];
	if(isset($_POST['contactSubmit'])){
		$error = checkValidate();
		$sanction = ['ir','sy','cu','sd'];
		if(isset($_POST['sanction']) && in_array(strtolower($_POST['contact']['country']),$sanction)){
			$error[] = 'امکان انتخاب این کشور وجود ندارد';
			
		}
		if(empty($error)){
			$regParams = $_POST['contact'];
			$regParams['handle'] = $_GET['handle'];
			$requestParams = $regParams;
			$requestParams['requestTime'] = time();
			$regParams = json_encode($regParams);
			
			$response = domainResellerUnirest\Request::put($moduleParams['apiurl'].'contact', $headers, $regParams);
			$st = 'pending';
			$trackid = '';
			$procid = '';
			if($response->code == 200){
				$trackid = $response->body->result->tracking_id;
				$procid = $response->body->result->processing_id;
				$suc = 'عملیات با موفقیت انجام پذیرفت شماره پیگیری : '. $response->body->result->tracking_id;
			}else {
				$st = 'failed';
				$error[] = isset($response->body->errorDetails) ? $response->body->errorDetails : 'Internal Error';;
			}
			$requestParams['responseTime'] = time();
			domainResellerLogger('admin_contact_modify',$_SESSION['adminid'], '', $procid, $trackid,$requestParams,$response->body ,$_GET['handle'], $st);
		}
	}else{
		$tldList = [];
		$response = domainResellerUnirest\Request::get($moduleParams['apiurl'].'contact/'.$_GET['handle'], $headers, []);
		if($response->code != 200){
			$error[] = isset($response->body->errorDetails) ? $response->body->errorDetails : 'Internal Error';;
		}else{
			foreach($response->body->result as $k=>$c){
				$_POST['contact'][$k] = $c;
			}
			$tldList = getTld($_POST['contact']['tld']);
		}
		
	}

	require_once dirname(__FILE__).DIRECTORY_SEPARATOR.'views'.DIRECTORY_SEPARATOR.'contact_modify.php';
}
function delete(){
	if(isset($_GET['handle'])){
		global $moduleParams;
		$error = [];
		$headers = array("Accept" => "application/json","Content-Type"=>"application/json; charset=UTF-8");
		$headers['Authorization'] = $moduleParams['token'];
		$regParams['handle'] = $_GET['handle'];
		$regParams['tld'] = $_GET['tld'];
		$requestParams = $regParams;
		$requestParams['requestTime'] = time();
		$regParams = json_encode($regParams);
		
		$response = domainResellerUnirest\Request::delete($moduleParams['apiurl'].'contact', $headers, $regParams);
		$st = 'pending';
		$trackid = '';
		$procid = '';
		if($response->code == 200){
			$trackid = $response->body->result->tracking_id;
			$procid = $response->body->result->processing_id;
			$suc = 'عملیات با موفقیت انجام پذیرفت شماره پیگیری : '. $response->body->result->tracking_id;
		}else {
			$st = 'failed';
			$error[] = isset($response->body->errorDetails) ? $response->body->errorDetails : 'Internal Error';;
		}
		$requestParams['responseTime'] = time();
		domainResellerLogger('admin_contact_delete',$_SESSION['adminid'], '', $procid, $trackid,$requestParams,$response->body ,$_GET['handle'], $st);
		require_once dirname(__FILE__).DIRECTORY_SEPARATOR.'views'.DIRECTORY_SEPARATOR.'contact_delete.php';
	}else{
		header('Location: '.$_SERVER['HTTP_REFERER']);
	}
}

function defaults(){
	if(isset($_GET['handle']) && isset($_GET['tld'])){
	
		global $moduleParams;
		$error = [];
		$headers = array("Accept" => "application/json","Content-Type"=>"application/json; charset=UTF-8");
		$headers['Authorization'] = $moduleParams['token'];
		$requestParams = $_GET;
		$requestParams['requestTime'] = time();
		$regParams = json_encode([]);
		
		$response = domainResellerUnirest\Request::post($moduleParams['apiurl'].'tld/'.trim($_GET['tld']).'/contact/'.trim($_GET['handle']), $headers, $regParams);
		$st = 'success';
		$trackid = '';
		$procid = '';
		
		if($response->code == 200){
			$suc = 'عملیات با موفقیت انجام پذیرفت ';
		}else {
			$st = 'failed';
			$error[] = isset($response->body->errorDetails) ? $response->body->errorDetails : 'Internal Error';;
		}
		$requestParams['responseTime'] = time();
		domainResellerLogger('admin_contact_default',$_SESSION['adminid'], '', $procid, $trackid,$requestParams,$response->body ,$_GET['handle'], $st);
		require_once dirname(__FILE__).DIRECTORY_SEPARATOR.'views'.DIRECTORY_SEPARATOR.'tld_contact.php';
	}else{
		header('Location: '.$_SERVER['HTTP_REFERER']);
	}
}

function lists(){
	global $moduleParams;

	$headers = array("Accept" => "application/json","Content-Type"=>"application/json; charset=UTF-8");
	$headers['Authorization'] = $moduleParams['token'];
	$tld = 'all';
	$regParams = [];
	if(isset($_POST['domain_reseller_management_contact']['handle']) && $_POST['domain_reseller_management_contact']['handle'] !=''){
		$regParams['pattern'] = $_POST['domain_reseller_management_contact']['handle'];
	}
	if(isset($_POST['domain_reseller_management_contact']['tld']) && $_POST['domain_reseller_management_contact']['tld'] != 'all'){
		$regParams['tld'] = $_POST['domain_reseller_management_contact']['tld'];
		$tld = $_POST['domain_reseller_management_contact']['tld'];
	}
	if(isset($_POST['domain_reseller_management_contact']['defaults'])){
		$regParams['defaults'] = $_POST['domain_reseller_management_contact']['defaults'];
	}
	//$regParams = json_encode($regParams);
	$response = domainResellerUnirest\Request::get($moduleParams['apiurl'].'contact', $headers, $regParams);
	$tldList = getTld($tld);
	require_once dirname(__FILE__).DIRECTORY_SEPARATOR.'views'.DIRECTORY_SEPARATOR.'contact_list.php';	
}


function checkValidate(){
	$required= ['name','email','address_1','city','postal_code','country','phone'];
	$error = [];
	$suc = '';
	foreach($required as $r){
		if(!isset($_POST['contact'][$r])){
			$error[] = 'مقدار '.$r.' ضروری میباشد';
		}
	}
	$name = explode(' ',$_POST['contact']['name']);
	if(!isset($name[1]) || trim($name[1]) == ''){
		$error[] = 'مقدار Name باید شامل نام و نام خوانوادگی باشد';
	}
    if(isset($_POST['contact']['phone']) && !empty($_POST['contact']['phone'])){
        if(!preg_match('/^(\+)?([0-9]([.,])?)+$/',$_POST['contact']['phone'])){
            $error[] = 'شماره تلفن معتبر نمیباشد';
        }
    }
    if(isset($_POST['contact']['fax']) && !empty($_POST['contact']['fax'])){
        if (!preg_match('/^(\+)?([0-9]([.,])?)+$/', $_POST['contact']['fax'])) {
            $error[] = 'شماره فکس معتبر نمیباشد';
        }
    }
	return $error;
}


function getTld($tld = 'all'){
	global $moduleParams;

	$headers = array("Accept" => "application/json","Content-Type"=>"application/json; charset=UTF-8");
	$headers['Authorization'] = $moduleParams['token'];
	$regParams = [];
//	if(isset($_POST['domain_reseller_management_tld']['tld'])){
//		$regParams['pattern'] = $_POST['domain_reseller_management_tld']['tld'];
//	}
//	if(isset($_POST['domain_reseller_management_tld']['tld']) && $_POST['domain_reseller_management_tld']['tld'] != 'all'){
//		$regParams['tld'] = $_POST['domain_reseller_management_tld']['tld'];
//	}
	if($tld != 'all'){
		$regParams['tld'] = $tld;
	}
	
	$response = domainResellerUnirest\Request::get($moduleParams['apiurl'].'tld', $headers, $regParams);

	if($response->code == 200){
		return $response->body->result->tld;	
	}else{
		return [];
	}
	
}

?>