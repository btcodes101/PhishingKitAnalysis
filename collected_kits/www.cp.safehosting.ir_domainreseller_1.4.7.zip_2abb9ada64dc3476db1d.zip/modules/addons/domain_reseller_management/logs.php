<?php
if(!isset($_SESSION['adminid'])){
	exit;
}
	global $moduleParams;
	use \Illuminate\Database\Capsule\Manager as Capsule;

	if(isset($_POST['removeSubmit'])){
		if(isset($_POST['rfrom']) && $_POST['rfrom'] != ''){
			$removeDate = trim($_POST['rfrom']);
			$requestParams = $_POST;
			$requestParams['requestTime'] = time();
			$res = Capsule::table('domain_reseller_management_log')->where('created_at', '<=', $removeDate)->delete();
			
			$msg = '<div style="color:red;">مشکلی در انجام عملیات رخ داده است</div>';
			if($res){
				$msg = '<div style="color:green;">عملیات با موفقیت انجام پذیرفت</div>';
			}
			$requestParams['responseTime'] = time();
			domainResellerLogger('admin_logs_delete',$_SESSION['adminid'], '', '', '',$requestParams,[],$removeDate, 'success');
		}
	}
	$q = Capsule::table('domain_reseller_management_log')->orderBy('id', 'DESC');

	if (isset($_GET['status']) && $_GET['status'] != 'all') {
		$status = $_GET['status'];
		$q->where('status', '=', $status);
	}
	if (isset($_GET['item']) && $_GET['item']!='') {
		$item = trim($_GET['item']);
		$q->where('item', 'like', '%'.$item.'%');
	}
	if (isset($_GET['opt']) && $_GET['opt']!='all') {
		$opt = trim($_GET['opt']);
		$q->where('opt', '=', $opt);
	}
	if (isset($_GET['from']) && $_GET['from']!='') {
		$from = trim($_GET['from']);
		$q->where('created_at', '>=', $from);
	}
	if (isset($_GET['to']) && $_GET['to']!='') {
		$to = trim($_GET['to']);
		$q->where('created_at', '<', $to);
	}
	if (isset($_GET['action']) && $_GET['action']!='all') {
		$action = trim($_GET['action']);
		$q->where('action', 'like', $action.'%');
	}
	if (!isset($_GET['search'])) {
		$q->where('action', 'like', 'domain%');
		$q->orWhere('action', 'like', 'admin_contact%');
//$q->whereNotIn('action',['domain_ns_list','domain_get_lock','domain_owner_getinfo']);
//		$q->where(function($query){
//			$query->where('action', '!=', '');
//			$query->orWhere();
//		});
	}

	$page = 1;
	if(isset($_POST['page']))
	{
		$page = $_POST['page'];
	}
	$limit = 30;
	$count = $q->count();
	$startIndex = ($page -1 )* $limit;
	$q->limit($limit);
	$q->offset($startIndex);
	$logs = $q->select()->get();
	$totalPages = ceil($count/$limit);

	require_once dirname(__FILE__).DIRECTORY_SEPARATOR.'views'.DIRECTORY_SEPARATOR.'log_page.php';

?>