<?php

use \Illuminate\Database\Capsule\Manager as Capsule;


function domainResellerLogger($action, $adminId, $userId, $procId, $trackId, $request, $result, $item, $status = 'success', $opt = 'new'){
    if(!isset($action)){
        $action = 'dashboard';
    }
//    if(!is_string($result)){
//        $result['time'] = time();
//    }
    Capsule::table('domain_reseller_management_log')->insert([
        'id'=> null,
        'userid'=>$userId,
        'adminid'=>$adminId,
        'trackid'=>$trackId,
        'procid'=>$procId,
        'status'=>$status,
        'item'=>$item,
        'action'=>$action,
        'request'=>domainResellerJsonHelper($request),
        'result'=>domainResellerJsonHelper($result),
        'created_at' => date('Y-m-d H:i:s'),
    ]);
}

function domainResellerJsonHelper($item){

    if(is_string($item)){
        return $item;
    }
    $pieces = (array) $item;
    return json_encode($pieces);

}

function domainResellerGetToken(){
    
    $domain_reseller_management_settingDB = Capsule::table('domain_reseller_management_setting')->select('value')->where('item','=',"token")->get();
    if(!empty($domain_reseller_management_settingDB)){
        return $domain_reseller_management_settingDB[0]->value;
    }
    return '0';

}
function domainResellerGetApiUrl($type = 'system'){
    if($type == 'upgrade'){
        return 'https://api.reseller.world/dms/';
    }
    return 'https://api.reseller.world/v1.4/dms/';

}

function domainResellerGetAdminUserName(){
  
    $domain_reseller_management_settingDB = Capsule::table('domain_reseller_management_setting')->select('value')->where('item','=',"adminuser")->get();
    if(!empty($domain_reseller_management_settingDB)){
        return $domain_reseller_management_settingDB[0]->value;
    }
    return '0';

}

function domainResellerGetBaseUrl($baseController, $action='', $params=[], $direct = true){
    
    $query = isset($_GET['module']) ? $_GET['module'] : 'domain_reseller_management';
    $base = 'addonmodules.php?module='.$query.'&page='.$baseController;
    if($action != ''){
        $base .= '&op='.$action;
    }
    if(!empty($params)){
        $base .= '&'.http_build_query($params);
    }
    if($direct === true){
        echo $base;
    }else{
        return $base;
    }

}


function domainResellerResponseTemplate($msg, $code, $status, $extraMsg = []){
    if(!is_array($extraMsg)){
        $extraMsg = [$extraMsg];
    }
    if($status === 'failed'){
        $resp = [];
        $resp['status'] = $status;
        $resp['error']=$code;
        $resp['internalTracking']='';
        $resp['errorDetails'] =  $msg;
        $resp['extraDetails'] = json_encode($extraMsg);
        $resp['result'] = '';
    }elseif($status === 'success'){
        $resp = [];
        $resp['status'] = $status;
        $resp['error']=$code;
        $resp['internalTracking']='';
        $resp['errorDetails'] = '';
        $resp['extraDetails'] = json_encode($extraMsg);
        $resp['result'] = $msg;
    }
    return $resp;
}

function domainResellerGetUnits($flag = true){
    $unitsDB = Capsule::table('domain_reseller_management_setting')->where('item', '=', 'unit')->first();
    if($flag == true){
        return $unitsDB->key;
    }

    return domainResellerTranslate($unitsDB->key);

}

function domainResellerGetLanguage(){
    $lang = Capsule::table('domain_reseller_management_setting')->where('item', '=', 'language')->value('value');
    
    if(!$lang){
        $lang = 'fa';
    }
    $langPath = __DIR__.'/customLang/'.$lang.'.php';
    if(file_exists($langPath)){
        return require_once $langPath;    
    }

    $langPath = __DIR__.'/lang/'.$lang.'.php';
    if(file_exists($langPath)){
        return require_once $langPath;
    }
    return [];
}

function domainResellerTranslate($item,$direct = true){
    global $moduleParams;
    $item = trim($item);
    
    if($direct === false){
        return (isset($moduleParams['language'][$item])) ? $moduleParams['language'][$item] : $item;
    }

    echo (isset($moduleParams['language'][$item])) ? $moduleParams['language'][$item] : $item;

}

function domainResellerTicket($params,$extParams,$replyTicket=0){
    
    
    $values["clientid"] = $params['userid'];
    $values["deptid"] = $params['department'];
    $values["status"] = isset($params['status']) ? $params['status'] : 'Open';
    $predefiend = Capsule::table('tblticketpredefinedreplies')->where('id',$params['reply'])->first();
    if(!$predefiend){
        return '';
    }
    
    
    $subject = $predefiend->name;
    $message = $predefiend->reply;
    if(!empty($extParams)){
        $message = strtr($message, $extParams);
        $subject = strtr($subject, $extParams);
    }
    $adminUsername = domainResellerGetAdminUserName();

    $admin = Capsule::table('tbladmins')->where('username',$adminUsername)->first();
    $values['message'] = $message;

    if($replyTicket == 0){
        $values['admin'] = $admin->firstname.' '.$admin->lastname;
        $values['subject'] = $subject;
        $command = "openticket";

    }else{
        $command = "addticketreply";
        $values["ticketid"] = $replyTicket;
        $values['adminusername'] =  $admin->firstname.' '.$admin->lastname;
    }


    return localAPI($command, $values, $adminUsername);

}
function domainResellerGetVersion(){
    return '1.4.7';
}