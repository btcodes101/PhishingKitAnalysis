<?php
if(!isset($_SESSION['adminid'])){
    exit;
}
global $moduleParams;
use \Illuminate\Database\Capsule\Manager as Capsule;

$q = Capsule::table('domain_reseller_management_log')->orderBy('id', 'DESC');
$q->where('action', '=', 'email_unverified');
if (isset($_GET['status']) && $_GET['status'] != 'all') {
    $status = $_GET['status'];
    $q->where('status', '=', $status);
}
if (isset($_GET['item']) && $_GET['item']!='') {
    $item = trim($_GET['item']);
    $q->where('item', 'like', '%'.$item.'%');
}

if (isset($_GET['from']) && $_GET['from']!='') {
    $from = trim($_GET['from']);
    $q->where('created_at', '>=', $from);
}
if (isset($_GET['to']) && $_GET['to']!='') {
    $to = trim($_GET['to']);
    $q->where('created_at', '<', $to);
}

$page = 1;
if(isset($_POST['page']))
{
    $page = $_POST['page'];
}
$limit = 30;
$count = $q->count();
$startIndex = ($page -1 )* $limit;
$q->limit($limit);
$q->offset($startIndex);
$logs = $q->select()->get();
$totalPages = ceil($count/$limit);

require_once dirname(__FILE__).DIRECTORY_SEPARATOR.'views'.DIRECTORY_SEPARATOR.'emails.php';
