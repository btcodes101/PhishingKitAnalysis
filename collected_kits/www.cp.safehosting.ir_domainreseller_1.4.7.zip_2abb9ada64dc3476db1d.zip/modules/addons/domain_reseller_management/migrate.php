<?php
/**
 * Created by PhpStorm.
 * User: MJahanbakhsh
 * Date: 01/12/2016
 * Time: 09:50 AM
 */

use \Illuminate\Database\Capsule\Manager as Capsule;
use \Illuminate\Database\Schema\Blueprint;

function m11(){
    
}


#database migration for version 1.3.1
function m131(){
    $check = Capsule::schema()->hasTable('domain_reseller_management_promotion');

    if (!$check) {
        Capsule::schema()->create(
            'domain_reseller_management_promotion',
            function ($table) {
                $table->charset='utf8';
                $table->increments('id');
                $table->string('tld', 50);
                $table->string('type', 50);
                $table->integer('promotionid');
                $table->string('currency',10);
                $table->integer('msetupfee');
                $table->integer('qsetupfee');
                $table->integer('ssetupfee');
                $table->integer('asetupfee');
                $table->integer('bsetupfee');
                $table->integer('monthly');
                $table->integer('quarterly');
                $table->integer('semiannually');
                $table->integer('annually');
                $table->integer('biennially');
                $table->integer('relid');
                $table->unique(['tld','type']);
                $table->timestamps();
            }
        );
    }
}

function m145(){
    Capsule::table('domain_reseller_management_log')->where('action', 'domain_tranferin')->update(['action'=>'domain_transferin']);
}



function runMigrate($currentVersion){
    $versionControl = [131,145];
    $currentVersion = (int) str_replace('.','',$currentVersion);
    foreach ($versionControl as $version) {
        if($version > $currentVersion){
            $func = 'm'.$version;
            $func();
        }
    }
}