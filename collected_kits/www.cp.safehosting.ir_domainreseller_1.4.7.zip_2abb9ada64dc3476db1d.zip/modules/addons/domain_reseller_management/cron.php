<?php

require __DIR__ . '/../../../init.php';
ini_set('display_errors', 1);
error_reporting(-1);
use \Illuminate\Database\Capsule\Manager as Capsule;

require_once dirname(__FILE__) . DIRECTORY_SEPARATOR . 'unirest-php' . DIRECTORY_SEPARATOR . 'Unirest.php';
require_once 'utils.php';


$token = 'Bearer ' . domainResellerGetToken();
$apiBaseUrl = domainResellerGetApiUrl();

$headers = array("Accept" => "application/json",);
$headers['Authorization'] = $token;

$adminuser = domainResellerGetAdminUserName();

$err = [];

$list = Capsule::table('domain_reseller_management_log')->where('status', '=', "pending")->where('action', '!=', 'email_unverified')->get();

if (!empty($list)) {

    $setting = Capsule::table('domain_reseller_management_setting')->where('item', '=', 'ticket')->pluck('value', 'key');
    $whoisTicket = Capsule::table('domain_reseller_management_setting')->where('item', '=', 'whoisTicket')->pluck('value', 'key');
    foreach ($list as $l) {
        if (is_null($l->trackid) || trim($l->trackid) == '') {
            Capsule::table('domain_reseller_management_log')->where('id', '=', $l->id)->update(['status' => 'failed']);
            continue;
        }
        try {
            $regParams['tracking_id'] = $l->trackid;

            $requestParams = $regParams;
            $requestParams['requestTime'] = time();

            $response = domainResellerUnirest\Request::get($apiBaseUrl . 'transaction', $headers, $regParams);
            $transParams = [];

            if (is_object($response->body->extraDetails)) {
                $extraDetails = $response->body->extraDetails;
            } else {
                $extraDetails = json_decode($response->body->extraDetails);
            }

            if (!isset($response->body->status) || $response->body->status == 'pending') {
                if (isset($extraDetails->tracking_id) && $extraDetails->tracking_id != $l->trackid) {
                    $transParams['trackid'] = $extraDetails->tracking_id;
                    $transParams['procid'] = $extraDetails->processing_id;
                    if ($transParams['trackid'] !== null) {
                        Capsule::table('domain_reseller_management_log')->where('id', '=', $l->id)->update($transParams);
                    }
                }
                if (isset($response->body->result->trace)) {

                    $msg = json_decode($l->result, true);
                    $msg['trace'] = $response->body->result->trace;
                    $transParams['result'] = json_encode($msg);
                    $upCheck = Capsule::table('domain_reseller_management_log')->where('id', '=', $l->id)->update($transParams);
                }
                continue;
            }


            $requestParams['responseTime'] = time();

            $st = $response->body->status;
            $msg = json_decode($l->result, true);
            $msg['cron'] = $response->body;
            $transParams = [];
            if (isset($extraDetails->tracking_id) && $extraDetails->tracking_id != $l->trackid) {
                $transParams['trackid'] = $extraDetails->tracking_id;
                $transParams['procid'] = $extraDetails->processing_id;
            }

            $transParams['status'] = $st;
            $transParams['result'] = json_encode($msg);

            $upCheck = Capsule::table('domain_reseller_management_log')->where('id', '=', $l->id)->update($transParams);
            if (!$upCheck) {
                throw new Exception('could not update');
            }
            if ($l->action == 'domain_protection_create') {
                $updateId = 0;
                if ($st == 'success') {
                    $updateId = 1;
                }
                $item = Capsule::table('tbldomains')->where('status', '=', 'Active')->where('registrar', '=', 'domain_reseller')->where('domain', '=', $l->item)->update(['idprotection' => $updateId]);
            } elseif ($l->action == 'domain_protection_cancel') {
                $updateId = 1;
                if ($st == 'success') {
                    $updateId = 0;
                }
                $item = Capsule::table('tbldomains')->where('status', '=', 'Active')->where('registrar', '=', 'domain_reseller')->where('domain', '=', $l->item)->update(['idprotection' => $updateId]);
            }
            if ($st == 'failed') {
                if (isset($setting['enable'])) {

                    $req = json_decode($l->request, true);
                    if (!isset($req['domainid'])) {
                        continue;
                    }
                    if (isset($req['ticket_id'])) {
                        continue;
                    }
                    $domain = Capsule::table('tbldomains')->where('id', '=', $req['domainid'])->first();
                    if (!$domain) {
                        continue;
                    }
                    $userId = $domain->userid;

                    $errorMsg = (strlen($response->body->errorDetails) > 500) ? '' : $response->body->errorDetails;
                    $t = domainResellerTicket(array_merge($setting, ['userid' => $userId]), ['[$domain]' => $l->item, '[$error]' => $errorMsg, '[$action]' => $l->action]);
                    if (isset($t['id'])) {
                        $req['ticket_id'] = $t['id'];
                        Capsule::table('domain_reseller_management_log')->where('id', $l->id)->update(array('request' => json_encode($req)));
                    }
                }
            } elseif ($st == 'success') {

                if (isset($whoisTicket['enable']) && isset($extraDetails->contactReplace) && $extraDetails->contactReplace === true) {

                    $req = json_decode($l->request, true);
                    if (!isset($req['domainid'])) {
                        continue;
                    }
                    if (isset($req['ticket_id'])) {
                        continue;
                    }
                    $domain = Capsule::table('tbldomains')->where('id', '=', $req['domainid'])->first();
                    if (!$domain) {
                        continue;
                    }
                    $userId = $domain->userid;
                    $errorMsg = '';
                    if (isset($extraDetails->contactError)) {
                        $errorMsg = (strlen($extraDetails->contactError) > 500) ? 'unknown_error' : $extraDetails->contactError;
                    }
                    $t = domainResellerTicket(array_merge($whoisTicket, ['userid' => $userId]), ['[$domain]' => $l->item, '[$error]' => $errorMsg, '[$action]' => $l->action]);
                }
            }
        } catch (\Exception $ex) {
            $error = domainResellerResponseTemplate($ex->getMessage(), '06020000', 'failed');
            $requestParams['responseTime'] = time();
            domainResellerLogger('cron_' . $l->action, '', '', $l->procid, $l->trackid, $requestParams, $error, $l->item, 'failed');
        }
    }
}


#promotion check
$setting = Capsule::table('domain_reseller_management_setting')->where('item', '=', 'promotion')->pluck('value', 'key');

if (isset($setting['enable'])) {
    $lastUpdate = Capsule::table('domain_reseller_management_setting')->where('item', '=', 'promotionUpdate')->value('value');
    $time = time();
    if (!$lastUpdate) {
        $lastUpdate = 0;
        Capsule::table('domain_reseller_management_setting')->insert([
            'value' => $time,
            'item' => 'promotionUpdate'
        ]);
    }

    $offset = 3600 * 12;

    if (($lastUpdate + $offset) < $time) {
        Capsule::table('domain_reseller_management_setting')->where('item', '=', 'promotionUpdate')->update([
            'value' => $time
        ]);
        $response = domainResellerUnirest\Request::get($apiBaseUrl . 'reseller', $headers, []);

        if ($response->code == 200) {
            if ($response->body->result->promotion == 1) {
                $tldList = domainResellerUnirest\Request::get($apiBaseUrl . 'tld', $headers, []);

                if ($tldList->code == 200) {
                    $unitsKey = domainResellerGetUnits(true);

                    $expireOffset = 3600 * 6;
                    $time = time();
                    $tldListKey = [];
                    if (!empty($tldList->body->result->promotion)) {

                        foreach ($tldList->body->result->promotion as $promotion) {
                            $tldListKey[$promotion->tld] = $promotion->id;
                            $promotionPrice = $promotion->price;
                            if ($unitsKey == 'toman') {
                                $promotion->price = round($promotion->price / 10);
                            }
                            Capsule::beginTransaction();
                            try {
                                $mainPrice = Capsule::table('domain_reseller_management_promotion')->where('tld', $promotion->tld)->get();

                                if (!empty($mainPrice)) {
                                    if ($mainPrice[0]->promotionid != $promotion->id) {
                                        foreach ($mainPrice as $item) {
                                            Capsule::table('tblpricing')->where('relid', $item->relid)->where('type', $item->type)->update(
                                                [
                                                    'msetupfee' => $promotion->price,
                                                    'qsetupfee' => ($item->qsetupfee < 0) ? $item->qsetupfee : $promotion->price + $item->msetupfee,
                                                    'ssetupfee' => ($item->ssetupfee < 0) ? $item->ssetupfee : $promotion->price + ($item->msetupfee * 2),
                                                    'asetupfee' => ($item->asetupfee < 0) ? $item->asetupfee : $promotion->price + ($item->msetupfee * 3),
                                                    'bsetupfee' => ($item->bsetupfee < 0) ? $item->bsetupfee : $promotion->price + ($item->msetupfee * 4),
                                                    'monthly' => ($item->monthly < 0) ? $item->monthly : $promotion->price + ($item->msetupfee * 5),
                                                    'quarterly' => ($item->quarterly < 0) ? $item->quarterly : $promotion->price + ($item->msetupfee * 6),
                                                    'semiannually' => ($item->semiannually < 0) ? $item->semiannually : $promotion->price + ($item->msetupfee * 7),
                                                    'annually' => ($item->annually < 0) ? $item->annually : $promotion->price + ($item->msetupfee * 8),
                                                    'biennially' => ($item->biennially < 0) ? $item->biennially : $promotion->price + ($item->msetupfee * 9),
                                                ]
                                            );
                                        }
                                        Capsule::table('domain_reseller_management_promotion')->where('tld', $promotion->tld)->update([
                                            'promotionid' => $promotion->id,
                                            'updated_at' => date('Y-m-d H:i:s')
                                        ]);

                                    }

                                    // promotion expire in last 6 hours
                                    $expirePromotion = strtotime($promotion->expire_at);
                                    if ($expirePromotion <= $time + $expireOffset) {

                                        foreach ($mainPrice as $item) {
                                            Capsule::table('tblpricing')->where('relid', $item->relid)->where('type', $item->type)->update(
                                                [
                                                    'msetupfee' => $item->msetupfee,
                                                    'qsetupfee' => $item->qsetupfee,
                                                    'ssetupfee' => $item->ssetupfee,
                                                    'asetupfee' => $item->asetupfee,
                                                    'bsetupfee' => $item->bsetupfee,
                                                    'monthly' => $item->monthly,
                                                    'quarterly' => $item->quarterly,
                                                    'semiannually' => $item->semiannually,
                                                    'annually' => $item->annually,
                                                    'biennially' => $item->biennially,
                                                ]
                                            );
                                            Capsule::table('domain_reseller_management_promotion')->where('id', $item->id)->delete();
                                        }
                                    }
                                } else {

                                    $wtldDB = Capsule::table('tbldomainpricing')->where('extension', '=', '.' . $promotion->tld)->first();

                                    if (!$wtldDB) {
                                        domainResellerLogger('cron_promotion', '', '', '', '', [], ['main price of tld not found'], $promotion->tld, 'failed');
                                        continue;
                                    }
                                    $relid = $wtldDB->id;
                                    $register = Capsule::table('tblpricing')->where('relid', $relid)->where('type', 'domainregister')->first();

                                    $in = Capsule::table('domain_reseller_management_promotion')->insert(
                                        [
                                            'tld' => $promotion->tld,
                                            'type' => 'domainregister',
                                            'promotionid' => $promotion->id,
                                            'currency' => $unitsKey,
                                            'msetupfee' => $register->msetupfee,
                                            'qsetupfee' => $register->qsetupfee,
                                            'ssetupfee' => $register->ssetupfee,
                                            'asetupfee' => $register->asetupfee,
                                            'bsetupfee' => $register->bsetupfee,
                                            'monthly' => $register->monthly,
                                            'quarterly' => $register->quarterly,
                                            'semiannually' => $register->semiannually,
                                            'annually' => $register->annually,
                                            'biennially' => $register->biennially,
                                            'relid' => $relid,
                                            'created_at' => date('Y-m-d H:i:s')
                                        ]
                                    );
                                    Capsule::table('tblpricing')->where('relid', $relid)->where('type', 'domainregister')->update(
                                        [
                                            'msetupfee' => $promotion->price,
                                            'qsetupfee' => ($register->qsetupfee < 0) ? $register->qsetupfee : $promotion->price + $register->msetupfee,
                                            'ssetupfee' => ($register->ssetupfee < 0) ? $register->ssetupfee : $promotion->price + ($register->msetupfee * 2),
                                            'asetupfee' => ($register->asetupfee < 0) ? $register->asetupfee : $promotion->price + ($register->msetupfee * 3),
                                            'bsetupfee' => ($register->bsetupfee < 0) ? $register->bsetupfee : $promotion->price + ($register->msetupfee * 4),
                                            'monthly' => ($register->monthly < 0) ? $register->monthly : $promotion->price + ($register->msetupfee * 5),
                                            'quarterly' => ($register->quarterly < 0) ? $register->quarterly : $promotion->price + ($register->msetupfee * 6),
                                            'semiannually' => ($register->semiannually < 0) ? $register->semiannually : $promotion->price + ($register->msetupfee * 7),
                                            'annually' => ($register->annually < 0) ? $register->annually : $promotion->price + ($register->msetupfee * 8),
                                            'biennially' => ($register->biennially < 0) ? $register->biennially : $promotion->price + ($register->msetupfee * 9),
                                        ]
                                    );
                                    domainResellerLogger('cron_promotion', '', '', '', 'register', $register, $promotion, $promotion->tld, 'success');

                                    if ($promotion->renew == 1) {
                                        $register = Capsule::table('tblpricing')->where('relid', $relid)->where('type', 'domainrenew')->first();
                                        Capsule::table('domain_reseller_management_promotion')->insert(
                                            [
                                                'tld' => $promotion->tld,
                                                'type' => 'domainrenew',
                                                'promotionid' => $promotion->id,
                                                'currency' => $unitsKey,
                                                'msetupfee' => $register->msetupfee,
                                                'qsetupfee' => $register->qsetupfee,
                                                'ssetupfee' => $register->ssetupfee,
                                                'asetupfee' => $register->asetupfee,
                                                'bsetupfee' => $register->bsetupfee,
                                                'monthly' => $register->monthly,
                                                'quarterly' => $register->quarterly,
                                                'semiannually' => $register->semiannually,
                                                'annually' => $register->annually,
                                                'biennially' => $register->biennially,
                                                'relid' => $relid,
                                                'created_at' => date('Y-m-d H:i:s')
                                            ]
                                        );
                                        Capsule::table('tblpricing')->where('relid', $relid)->where('type', 'domainrenew')->update(
                                            [
                                                'msetupfee' => $promotion->price,
                                                'qsetupfee' => ($register->qsetupfee < 0) ? $register->qsetupfee : $promotion->price + $register->msetupfee,
                                                'ssetupfee' => ($register->ssetupfee < 0) ? $register->ssetupfee : $promotion->price + ($register->msetupfee * 2),
                                                'asetupfee' => ($register->asetupfee < 0) ? $register->asetupfee : $promotion->price + ($register->msetupfee * 3),
                                                'bsetupfee' => ($register->bsetupfee < 0) ? $register->bsetupfee : $promotion->price + ($register->msetupfee * 4),
                                                'monthly' => ($register->monthly < 0) ? $register->monthly : $promotion->price + ($register->msetupfee * 5),
                                                'quarterly' => ($register->quarterly < 0) ? $register->quarterly : $promotion->price + ($register->msetupfee * 6),
                                                'semiannually' => ($register->semiannually < 0) ? $register->semiannually : $promotion->price + ($register->msetupfee * 7),
                                                'annually' => ($register->annually < 0) ? $register->annually : $promotion->price + ($register->msetupfee * 8),
                                                'biennially' => ($register->biennially < 0) ? $register->biennially : $promotion->price + ($register->msetupfee * 9),
                                            ]
                                        );
                                        domainResellerLogger('cron_promotion', '', '', '', 'renew', $register, $promotion, $promotion->tld, 'success');

                                    }

                                    if ($promotion->transfer == 1) {
                                        $register = Capsule::table('tblpricing')->where('relid', $relid)->where('type', 'domaintransfer')->first();
                                        Capsule::table('domain_reseller_management_promotion')->insert(
                                            [
                                                'tld' => $promotion->tld,
                                                'type' => 'domaintransfer',
                                                'promotionid' => $promotion->id,
                                                'currency' => $unitsKey,
                                                'msetupfee' => $register->msetupfee,
                                                'qsetupfee' => $register->qsetupfee,
                                                'ssetupfee' => $register->ssetupfee,
                                                'asetupfee' => $register->asetupfee,
                                                'bsetupfee' => $register->bsetupfee,
                                                'monthly' => $register->monthly,
                                                'quarterly' => $register->quarterly,
                                                'semiannually' => $register->semiannually,
                                                'annually' => $register->annually,
                                                'biennially' => $register->biennially,
                                                'relid' => $relid,
                                                'created_at' => date('Y-m-d H:i:s')
                                            ]
                                        );
                                        Capsule::table('tblpricing')->where('relid', $relid)->where('type', 'domaintransfer')->update(
                                            [
                                                'msetupfee' => $promotion->price,
                                                'qsetupfee' => ($register->qsetupfee < 0) ? $register->qsetupfee : $promotion->price + $register->msetupfee,
                                                'ssetupfee' => ($register->ssetupfee < 0) ? $register->ssetupfee : $promotion->price + ($register->msetupfee * 2),
                                                'asetupfee' => ($register->asetupfee < 0) ? $register->asetupfee : $promotion->price + ($register->msetupfee * 3),
                                                'bsetupfee' => ($register->bsetupfee < 0) ? $register->bsetupfee : $promotion->price + ($register->msetupfee * 4),
                                                'monthly' => ($register->monthly < 0) ? $register->monthly : $promotion->price + ($register->msetupfee * 5),
                                                'quarterly' => ($register->quarterly < 0) ? $register->quarterly : $promotion->price + ($register->msetupfee * 6),
                                                'semiannually' => ($register->semiannually < 0) ? $register->semiannually : $promotion->price + ($register->msetupfee * 7),
                                                'annually' => ($register->annually < 0) ? $register->annually : $promotion->price + ($register->msetupfee * 8),
                                                'biennially' => ($register->biennially < 0) ? $register->biennially : $promotion->price + ($register->msetupfee * 9),
                                            ]
                                        );
                                        domainResellerLogger('cron_promotion', '', '', '', 'transfer', $register, $promotion, $promotion->tld, 'success');
                                    }
                                }

                                Capsule::commit();

                            } catch (Exception $ex) {

                                Capsule::rollBack();

                            }
                        }
                    } else {

                        $mainPrice = Capsule::table('domain_reseller_management_promotion')->get();
                        if (!empty($mainPrice)) {
                            Capsule::beginTransaction();
                            try {
                                foreach ($mainPrice as $item) {
                                    Capsule::table('tblpricing')->where('relid', $item->relid)->where('type', $item->type)->update(
                                        [
                                            'msetupfee' => $item->msetupfee,
                                            'qsetupfee' => $item->qsetupfee,
                                            'ssetupfee' => $item->ssetupfee,
                                            'asetupfee' => $item->asetupfee,
                                            'bsetupfee' => $item->bsetupfee,
                                            'monthly' => $item->monthly,
                                            'quarterly' => $item->quarterly,
                                            'semiannually' => $item->semiannually,
                                            'annually' => $item->annually,
                                            'biennially' => $item->biennially,
                                        ]
                                    );
                                    Capsule::table('domain_reseller_management_promotion')->where('id', $item->id)->delete();
                                    domainResellerLogger('cron_promotion', '', '', '', 'back', [], $item, $item->tld, 'success');
                                }
                                Capsule::commit();
                            } catch (Exception $ex) {
                                Capsule::rollBack();
                            }
                        }
                    }

                    if (!empty($tldListKey)) {
                        // check promotion go away
                        $mainPrice = Capsule::table('domain_reseller_management_promotion')->get();
                        if (!empty($mainPrice)) {
                            Capsule::beginTransaction();
                            try {
                                foreach ($mainPrice as $item) {
                                    if (!isset($tldListKey[$item->tld])) {
                                        Capsule::table('tblpricing')->where('relid', $item->relid)->where('type', $item->type)->update(
                                            [
                                                'msetupfee' => $item->msetupfee,
                                                'qsetupfee' => $item->qsetupfee,
                                                'ssetupfee' => $item->ssetupfee,
                                                'asetupfee' => $item->asetupfee,
                                                'bsetupfee' => $item->bsetupfee,
                                                'monthly' => $item->monthly,
                                                'quarterly' => $item->quarterly,
                                                'semiannually' => $item->semiannually,
                                                'annually' => $item->annually,
                                                'biennially' => $item->biennially,
                                            ]
                                        );
                                        Capsule::table('domain_reseller_management_promotion')->where('id', $item->id)->delete();
                                        domainResellerLogger('cron_promotion', '', '', '', 'back', [], $item, $item->tld, 'success');
                                    }
                                }
                                Capsule::commit();
                            } catch (Exception $ex) {
                                Capsule::rollBack();
                            }
                        }
                    }

                } else {
                    domainResellerLogger('cron_promotion', '', '', '', '', [], $tldList->body, 'tld', 'failed');
                }
            } else {
                // revert all main price in promotion price back
                $mainPrice = Capsule::table('domain_reseller_management_promotion')->get();
                if (!empty($mainPrice)) {
                    Capsule::beginTransaction();
                    try {
                        foreach ($mainPrice as $item) {
                            Capsule::table('tblpricing')->where('relid', $item->relid)->where('type', $item->type)->update(
                                [
                                    'msetupfee' => $item->msetupfee,
                                    'qsetupfee' => $item->qsetupfee,
                                    'ssetupfee' => $item->ssetupfee,
                                    'asetupfee' => $item->asetupfee,
                                    'bsetupfee' => $item->bsetupfee,
                                    'monthly' => $item->monthly,
                                    'quarterly' => $item->quarterly,
                                    'semiannually' => $item->semiannually,
                                    'annually' => $item->annually,
                                    'biennially' => $item->biennially,
                                ]
                            );
                            Capsule::table('domain_reseller_management_promotion')->where('id', $item->id)->delete();
                            domainResellerLogger('cron_promotion', '', '', '', 'back', [], $item, $item->tld, 'success');
                        }
                        Capsule::commit();
                    } catch (Exception $ex) {
                        Capsule::rollBack();
                    }
                }
            }
        } else {
            domainResellerLogger('cron_promotion', '', '', '', '', [], $response->body, 'reseller', 'failed');
        }
    }
} else {

    //remove promotion
    $mainPrice = Capsule::table('domain_reseller_management_promotion')->get();
    if (!empty($mainPrice)) {
        Capsule::beginTransaction();
        try {
            foreach ($mainPrice as $item) {
                Capsule::table('tblpricing')->where('relid', $item->relid)->where('type', $item->type)->update(
                    [
                        'msetupfee' => $item->msetupfee,
                        'qsetupfee' => $item->qsetupfee,
                        'ssetupfee' => $item->ssetupfee,
                        'asetupfee' => $item->asetupfee,
                        'bsetupfee' => $item->bsetupfee,
                        'monthly' => $item->monthly,
                        'quarterly' => $item->quarterly,
                        'semiannually' => $item->semiannually,
                        'annually' => $item->annually,
                        'biennially' => $item->biennially,
                    ]
                );
                Capsule::table('domain_reseller_management_promotion')->where('id', $item->id)->delete();
                domainResellerLogger('cron_promotion', '', '', '', 'back', [], $item, $item->tld, 'success');
            }
            Capsule::commit();
        } catch (Exception $ex) {
            Capsule::rollBack();
        }
    }
}


$lastUpdate = Capsule::table('domain_reseller_management_setting')->where('item', '=', 'periodicCronExecute')->value('value');
$time = time();
if (!$lastUpdate) {
    $lastUpdate = 0;
    Capsule::table('domain_reseller_management_setting')->insert([
        'value' => $time,
        'item' => 'periodicCronExecute'
    ]);
}

$offset = 3600 * 3;

if (($lastUpdate + $offset) < $time) {
    Capsule::table('domain_reseller_management_setting')->where('item', '=', 'periodicCronExecute')->update([
        'value' => $time
    ]);
    require_once __DIR__ . '/periodicCron.php';
}


