<?php
if(!isset($_SESSION['adminid'])){
    exit;
}
use \Illuminate\Database\Capsule\Manager as Capsule;

require_once dirname(__FILE__) . DIRECTORY_SEPARATOR . 'unirest-php' . DIRECTORY_SEPARATOR . 'Unirest.php';
callMethod();
function lists()
{
    global $moduleParams;
    //$unitsKey = domainResellerGetUnits(true);
    $unitsKey = domainResellerGetUnits();
    
    $headers = array("Accept" => "application/json", "Content-Type" => "application/json; charset=UTF-8");
    $headers['Authorization'] = $moduleParams['token'];
    $error = [];

    if (isset($_POST['protectionSubmit'])) {


        global $moduleParams;
        $headers = array("Accept" => "application/json", "Content-Type" => "application/json; charset=UTF-8");
        $headers['Authorization'] = $moduleParams['token'];

        if ($unitsKey == 'toman') {
             $_POST['protection']['price'] *= 10;
        }

        $regParams = $_POST['protection'];

        if (!isset($_POST['protection']['status'])) {
            $regParams['status'] = 0;
        }
        $requestParams = $regParams;

        $requestParams['requestTime'] = time();

        $response = domainResellerUnirest\Request::put($moduleParams['apiurl'] . 'reseller/addon/protection', $headers, json_encode($regParams));
        $st = 'pending';

        if ($response->code == 200) {
            //Capsule::table('tbldomainpricing')->where('autoreg','=','domain_reseller')->update(['idprotection'=>'on']);
            //Capsule::table('tblpricing')->where('type','=','domainaddons')->update(['ssetupfee'=>$_POST['protection']['price']]);
            $suc = 'عملیات با موفقیت انجام پذیرفت  : ';
            echo '<div style="color:green;">' . $suc . '</div>';
        } else {
            $st = 'failed';
            $error[] = isset($response->body->errorDetails) ? $response->body->errorDetails : 'Internal Error';
        }
        $requestParams['responseTime'] = time();
        domainResellerLogger('admin_reseller_protection', $_SESSION['adminid'], '', '', '', $requestParams, $response->body, '', $st);
        if (!empty($error)) {
            echo '<div style="color:red;">';
            foreach ($error as $er) {
                echo $er . '<br/>';
            }
            echo '</div>';
        }
    }


    if (isset($_POST['dnsSubmit'])) {


        global $moduleParams;
        $headers = array("Accept" => "application/json", "Content-Type" => "application/json; charset=UTF-8");
        $headers['Authorization'] = $moduleParams['token'];

        if ($unitsKey == 'toman') {
            $_POST['dns']['price'] *= 10;
        }

        $regParams = $_POST['dns'];

        if (!isset($_POST['dns']['status'])) {
            $regParams['status'] = 0;
        }
        $requestParams = $regParams;

        $requestParams['requestTime'] = time();

        $response = domainResellerUnirest\Request::put($moduleParams['apiurl'] . 'reseller/addon/dns', $headers, json_encode($regParams));

        $st = 'pending';

        if ($response->code == 200) {
            //Capsule::table('tbldomainpricing')->where('autoreg','=','domain_reseller')->update(['dnsmanagement'=>'on']);
            //Capsule::table('tblpricing')->where('type','=','domainaddons')->update(['msetupfee'=>$_POST['dns']['price']]);
            $suc = 'عملیات با موفقیت انجام پذیرفت  : ';
            echo '<div style="color:green;">' . $suc . '</div>';
        } else {
            $st = 'failed';
            $error[] = isset($response->body->errorDetails) ? $response->body->errorDetails : 'Internal Error';
        }
        $requestParams['responseTime'] = time();
        domainResellerLogger('admin_reseller_dns', $_SESSION['adminid'], '', '', '', $requestParams, $response->body, '', $st);
        if (!empty($error)) {
            echo '<div style="color:red;">';
            foreach ($error as $er) {
                echo $er . '<br/>';
            }
            echo '</div>';
        }
    }



    if (isset($_POST['syncTld']) || isset($_POST['submit'])) {
        $response = domainResellerUnirest\Request::get($moduleParams['apiurl'] . 'tld', $headers, []);
        if ($response->code != 200) {
            $error[] = isset($response->body->errorDetails) ? $response->body->errorDetails : 'server_error';
        }
        $tld = $response->body->result->tld;
        if (empty($error)) {
            $error = syncTld($tld);
        }
    }
    if (isset($_POST['submit']) && empty($error)) {
        foreach ($tld as $t) {
            $regParams = [];
//			if($unitsKey == 'toman'){
//				$regParams['register_price'] = round(($t->register_price_buy/10) + (( ($t->register_price_buy/10) * $_POST['profit']) / 100),-3);
//				$regParams['renew_price'] = round(($t->renew_price_buy/10) + (( ($t->renew_price_buy/10) * $_POST['profit']) / 100),-3);
//				$regParams['redemption_price'] = round(($t->redemption_price_buy/10) + (( ($t->redemption_price_buy/10) * $_POST['profit']) / 100),-3);
//				$regParams['transfer_price'] = round(($t->transfer_price_buy/10)  + (( ($t->transfer_price_buy/10) * $_POST['profit']) / 100),-3);
//			}else{
            $regParams['register_price'] = round($t->register_price_buy + (($t->register_price_buy * $_POST['profit']) / 100), -3);
            $regParams['renew_price'] = round($t->renew_price_buy + (($t->renew_price_buy * $_POST['profit']) / 100), -3);
            $regParams['redemption_price'] = round($t->redemption_price_buy + (($t->redemption_price_buy * $_POST['profit']) / 100), -3);
            $regParams['transfer_price'] = round($t->transfer_price_buy + (($t->transfer_price_buy * $_POST['profit']) / 100), -3);
            //}

            $regParams['tld'] = $t->tld;

            $update = domainResellerUnirest\Request::put($moduleParams['apiurl'] . 'tld', $headers, json_encode($regParams));
            $st = 'success';
            if ($update->code != 200) {
                $st = 'failed';
                $error[] = isset($update->body->errorDetails) ? $update->body->errorDetails : 'server_error';
            }
            domainResellerLogger('admin_tld_modify', $_SESSION['adminid'], '', '', '', $regParams, $update->body, $t->tld, $st);
        }
    }

    $regParams = [];
    if (isset($_POST['domain_reseller_management_tld']['tld'])) {
        $regParams['pattern'] = $_POST['domain_reseller_management_tld']['tld'];
    }

    $response = domainResellerUnirest\Request::get($moduleParams['apiurl'] . 'tld', $headers, $regParams);


    $protectionResponse = domainResellerUnirest\Request::get($moduleParams['apiurl'] . 'reseller/addon/protection', $headers, []);

    if ($response->code != 200) {
        $error[] = $protectionResponse->body->errorDetails;
    }else{
        $protectionPrice = (array)$protectionResponse->body->result;
    }

    $dnsResponse = domainResellerUnirest\Request::get($moduleParams['apiurl'] . 'reseller/addon/dns', $headers, []);

    if ($response->code != 200) {
        $error[] = $dnsResponse->body->errorDetails;
    }else{
        $dnsPrice = (array)$dnsResponse->body->result;
    }
  
    require_once dirname(__FILE__) . DIRECTORY_SEPARATOR . 'views' . DIRECTORY_SEPARATOR . 'tld_list.php';
}

function update()
{
    global $moduleParams;
    $error = [];
    $headers = array("Accept" => "application/json", "Content-Type" => "application/json; charset=UTF-8");
    $headers['Authorization'] = $moduleParams['token'];
    //$headers['x-reseller-id'] = 2;
    $unitsKey = domainResellerGetUnits(true);
    if (isset($_POST['tld']['submit'])) {
        $regParams = $_POST['tld'];
        $regParams['tld'] = $_GET['tld'];
        $_POST['tld']['tld'] = $_GET['tld'];
        $error = checkValidate();
        if (empty($error)) {
            if (!isset($regParams['active'])) {
                $regParams['active'] = 0;
            }

            if ($unitsKey == 'toman') {
                $regParams['register_price'] *= 10;
                $regParams['renew_price'] *= 10;
                $regParams['transfer_price'] *= 10;
            }

            $requestParams = $regParams;
            $requestParams['requestTime'] = time();
            $regParams = json_encode($regParams);
            $response = domainResellerUnirest\Request::put($moduleParams['apiurl'] . 'tld', $headers, $regParams);
            $st = 'success';
            $trackid = '';
            $procid = '';

            if ($response->code == 200) {
                $suc = 'عملیات با موفقیت انجام پذیرفت';
            } else {
                $st = 'failed';
                $error[] = isset($response->body->errorDetails) ? $response->body->errorDetails : 'server_error';
            }
            $requestParams['responseTime'] = time();
            domainResellerLogger('admin_tld_update', $_SESSION['adminid'], '', $procid, $trackid, $requestParams, $response->body, $_GET['tld'], $st);
        }
    } else {
        $regParams['tld'] = $_GET['tld'];
        //$regParams = json_encode($regParams);

        $response = domainResellerUnirest\Request::get($moduleParams['apiurl'] . 'tld', $headers, $regParams);

        if ($response->code != 200) {

            $error[] = isset($response->body->errorDetails) ? $response->body->errorDetails : 'server_error';
        } else {
            foreach ($response->body->result->tld[0] as $k => $c) {
                $_POST['tld'][$k] = $c;
            }
        }
    }

    $units = domainResellerGetUnits();

    require_once dirname(__FILE__) . DIRECTORY_SEPARATOR . 'views' . DIRECTORY_SEPARATOR . 'tld_update.php';
}


function checkValidate()
{
    $required = ['register_price', 'renew_price', 'transfer_price'];
    $error = [];
    foreach ($required as $r) {
        if (!isset($_POST['tld'][$r])) {
            $error[] = 'مقدار ' . $r . ' ضروری میباشد';
        }
    }
    return $error;
}

function syncTld($tld)
{
    try {


        $wtldDB = Capsule::table('tbldomainpricing')->where('autoreg','domain_reseller')->pluck('extension', 'id');
        $wtld = [];
        foreach ($wtldDB as $r => $w) {
            $w = ltrim($w, '.');
            $wtld[$w] = $r;
        }
        $unitsKey = domainResellerGetUnits(true);
        $order = Capsule::table('tbldomainpricing')->orderBy('order', 'desc')->first();
        $order = isset($order->order) ? $order->order : 0 ;

        foreach ($tld as $t) {
            $updateData = [];
            for ($i = 1; $i <= 10; $i++) {
                if ($i * $t->min_perid <= $t->max_period) {
                    if ($unitsKey == 'toman') {
                        $updateData[$i]['register'] = ($t->register_price / 10) * $i;
                        $updateData[$i]['renew'] = ($t->renew_price / 10) * $i;
                        $updateData[$i]['transfer'] = ($t->transfer_price / 10) * $i;
                    } else {
                        $updateData[$i]['register'] = $t->register_price * $i;
                        $updateData[$i]['renew'] = $t->renew_price * $i;
                        $updateData[$i]['transfer'] = $t->transfer_price * $i;
                    }

                } else {
                    $updateData[$i]['register'] = '-1.00';
                    $updateData[$i]['renew'] = '-1.00';
                    $updateData[$i]['transfer'] = '-1.00';
                }

            }
            $dataToLog = [];
            if (isset($wtld[$t->tld])) {
                $relid = $wtld[$t->tld];
                $register = Capsule::table('tblpricing')->where('relid', $relid)->where('type', 'domainregister')->first();
                $renew = Capsule::table('tblpricing')->where('relid', $relid)->where('type', 'domainrenew')->first();
                $transfer = Capsule::table('tblpricing')->where('relid', $relid)->where('type', 'domaintransfer')->first();

                Capsule::table('tbldomainpricing')->where('autoreg','domain_reseller')->where('id',$relid)->update([
                    'dnsmanagement' => ($t->dns == 1) ? 'on' :'',
                    'idprotection' => ($t->protection == 1) ? 'on' :'',
                ]);

                Capsule::table('tblpricing')->where('relid', $relid)->where('type', 'domainregister')
                    ->update(array(
                        'msetupfee' => $updateData[1]['register'],
                        'qsetupfee' => $updateData[2]['register'],
                        'ssetupfee' => $updateData[3]['register'],
                        'asetupfee' => $updateData[4]['register'],
                        'bsetupfee' => $updateData[5]['register'],
                        'monthly' => $updateData[6]['register'],
                        'quarterly' => $updateData[7]['register'],
                        'semiannually' => $updateData[8]['register'],
                        'annually' => $updateData[9]['register'],
                        'biennially' => $updateData[10]['register'],
                    ));

                Capsule::table('tblpricing')->where('relid', $relid)->where('type', 'domainrenew')
                    ->update(array(
                        'msetupfee' => $updateData[1]['renew'],
                        'qsetupfee' => $updateData[2]['renew'],
                        'ssetupfee' => $updateData[3]['renew'],
                        'asetupfee' => $updateData[4]['renew'],
                        'bsetupfee' => $updateData[5]['renew'],
                        'monthly' => $updateData[6]['renew'],
                        'quarterly' => $updateData[7]['renew'],
                        'semiannually' => $updateData[8]['renew'],
                        'annually' => $updateData[9]['renew'],
                        'biennially' => $updateData[10]['renew'],
                    ));

                Capsule::table('tblpricing')->where('relid', $relid)->where('type', 'domaintransfer')
                    ->update(array(
                        'msetupfee' => $updateData[1]['transfer'],
                        'qsetupfee' => $updateData[2]['transfer'],
                        'ssetupfee' => $updateData[3]['transfer'],
                        'asetupfee' => $updateData[4]['transfer'],
                        'bsetupfee' => $updateData[5]['transfer'],
                        'monthly' => $updateData[6]['transfer'],
                        'quarterly' => $updateData[7]['transfer'],
                        'semiannually' => $updateData[8]['transfer'],
                        'annually' => $updateData[9]['transfer'],
                        'biennially' => $updateData[10]['transfer'],
                    ));



                $dataToLog['register'] = ["$register->msetupfee to {$updateData[1]['register']}", "$register->qsetupfee to {$updateData[2]['register']}", "$register->ssetupfee to {$updateData[3]['register']}", "$register->asetupfee to {$updateData[4]['register']}", "$register->bsetupfee to {$updateData[5]['register']}", "$register->monthly to {$updateData[6]['register']}", "$register->quarterly to {$updateData[7]['register']}", "$register->semiannually to {$updateData[8]['register']}", "$register->annually to {$updateData[9]['register']}", "$register->biennially to {$updateData[10]['register']}"];
                $dataToLog['renew'] = ["$renew->msetupfee to {$updateData[1]['renew']}", "$renew->qsetupfee to {$updateData[2]['renew']}", "$renew->ssetupfee to {$updateData[3]['renew']}", "$renew->asetupfee to {$updateData[4]['renew']}", "$renew->bsetupfee to {$updateData[5]['renew']}", "$renew->monthly to {$updateData[6]['renew']}", "$renew->quarterly to {$updateData[7]['renew']}", "$renew->semiannually to {$updateData[8]['renew']}", "$renew->annually to {$updateData[9]['renew']}", "$renew->biennially to {$updateData[10]['renew']}"];
                $dataToLog['transfer'] = ["$transfer->msetupfee to {$updateData[1]['transfer']}", "$transfer->qsetupfee to {$updateData[2]['transfer']}", "$transfer->ssetupfee to {$updateData[3]['transfer']}", "$transfer->asetupfee to {$updateData[4]['transfer']}", "$transfer->bsetupfee to {$updateData[5]['transfer']}", "$transfer->monthly to {$updateData[6]['transfer']}", "$transfer->quarterly to {$updateData[7]['transfer']}", "$transfer->semiannually to {$updateData[8]['transfer']}", "$transfer->annually to {$updateData[9]['transfer']}", "$transfer->biennially to {$updateData[10]['transfer']}"];
                $resp = [];
                $resp['status'] = 'success';
                $resp['error'] = 0;
                $resp['internalTracking'] = '';
                $resp['errorDetails'] = '';
                $resp['extraDetails'] = json_encode($dataToLog);
                $resp['result'] = '';
                domainResellerLogger('admin_whmcs_update_price', $_SESSION['adminid'], '', '', '', [], $resp, $t->tld);
            } else {

                $check = Capsule::table('tbldomainpricing')->where('extension', '.' . $t->tld)->first();
                if($check){
                    continue;
                }
                $relid = Capsule::table('tbldomainpricing')->insertGetId(
                    array(
                        'id' => null,
                        'extension' => '.' . $t->tld,
                        'dnsmanagement' => ($t->dns == 1) ? 'on' :'',
                        'emailforwarding' => '',
                        'idprotection' => ($t->protection == 1) ? 'on' :'',
                        'eppcode' => 'on',
                        'autoreg' => 'domain_reseller',
                        'order' => ++$order,
                    )
                );

                Capsule::table('tblpricing')->insert(array(
                    'id' => null,
                    'type' => 'domainregister',
                    'currency' => 1,
                    'relid' => $relid,
                    'msetupfee' => $updateData[1]['register'],
                    'qsetupfee' => $updateData[2]['register'],
                    'ssetupfee' => $updateData[3]['register'],
                    'asetupfee' => $updateData[4]['register'],
                    'bsetupfee' => $updateData[5]['register'],
                    'tsetupfee' => '0.00',
                    'monthly' => $updateData[6]['register'],
                    'quarterly' => $updateData[7]['register'],
                    'semiannually' => $updateData[8]['register'],
                    'annually' => $updateData[9]['register'],
                    'biennially' => $updateData[10]['register'],
                    'triennially' => '0.00'
                ));

                Capsule::table('tblpricing')->insert(array(
                    'id' => null,
                    'type' => 'domainrenew',
                    'currency' => 1,
                    'relid' => $relid,
                    'msetupfee' => $updateData[1]['renew'],
                    'qsetupfee' => $updateData[2]['renew'],
                    'ssetupfee' => $updateData[3]['renew'],
                    'asetupfee' => $updateData[4]['renew'],
                    'bsetupfee' => $updateData[5]['renew'],
                    'tsetupfee' => '0.00',
                    'monthly' => $updateData[6]['renew'],
                    'quarterly' => $updateData[7]['renew'],
                    'semiannually' => $updateData[8]['renew'],
                    'annually' => $updateData[9]['renew'],
                    'biennially' => $updateData[10]['renew'],
                    'triennially' => '0.00'
                ));

                Capsule::table('tblpricing')->insert(array(
                    'id' => null,
                    'type' => 'domaintransfer',
                    'currency' => 1,
                    'relid' => $relid,
                    'msetupfee' => $updateData[1]['transfer'],
                    'qsetupfee' => $updateData[2]['transfer'],
                    'ssetupfee' => $updateData[3]['transfer'],
                    'asetupfee' => $updateData[4]['transfer'],
                    'bsetupfee' => $updateData[5]['transfer'],
                    'tsetupfee' => '0.00',
                    'monthly' => $updateData[6]['transfer'],
                    'quarterly' => $updateData[7]['transfer'],
                    'semiannually' => $updateData[8]['transfer'],
                    'annually' => $updateData[9]['transfer'],
                    'biennially' => $updateData[10]['transfer'],
                    'triennially' => '0.00'
                ));

                $dataToLog['register'] = ["0 to {$updateData[1]['register']}", "0 to {$updateData[2]['register']}", "0 to {$updateData[3]['register']}", "0 to {$updateData[4]['register']}", "0 to {$updateData[5]['register']}", "0 to {$updateData[6]['register']}", "0 to {$updateData[7]['register']}", "0 to {$updateData[8]['register']}", "0 to {$updateData[9]['register']}", "0 to {$updateData[10]['register']}"];
                $dataToLog['renew'] = ["0 to {$updateData[1]['renew']}", "0 to {$updateData[2]['renew']}", "0 to {$updateData[3]['renew']}", "0 to {$updateData[4]['renew']}", "0 to {$updateData[5]['renew']}", "0 to {$updateData[6]['renew']}", "0 to {$updateData[7]['renew']}", "0 to {$updateData[8]['renew']}", "0 to {$updateData[9]['renew']}", "0 to $updateData[10]['renew']}"];
                $dataToLog['transfer'] = ["0 to {$updateData[1]['transfer']}", "0 to {$updateData[2]['transfer']}", "0 to {$updateData[3]['transfer']}", "0 to {$updateData[4]['transfer']}", "0 to {$updateData[5]['transfer']}", "0 to {$updateData[6]['transfer']}", "0 to {$updateData[7]['transfer']}", "0 to {$updateData[8]['transfer']}", "0 to {$updateData[9]['transfer']}", "0 to {$updateData[10]['transfer']}"];
                $resp = [];
                $resp['status'] = 'success';
                $resp['error'] = 0;
                $resp['internalTracking'] = '';
                $resp['errorDetails'] = '';
                $resp['extraDetails'] = json_encode($dataToLog);
                $resp['result'] = '';
                domainResellerLogger('admin_whmcs_insert_tld', $_SESSION['adminid'], '', '', '', $t, [], $t->tld);
                domainResellerLogger('admin_whmcs_update_price', $_SESSION['adminid'], '', '', '', [], $resp, $t->tld);
            }
        }
        Capsule::table('domain_reseller_management_promotion')->delete();
        Capsule::table('domain_reseller_management_setting')->where('item', '=', 'promotionUpdate')->update([
            'value' => (time() - (86400 * 5))
        ]);

        return [];
    } catch (Exception $ex) {
        return [$ex->getMessage()];
    }
}