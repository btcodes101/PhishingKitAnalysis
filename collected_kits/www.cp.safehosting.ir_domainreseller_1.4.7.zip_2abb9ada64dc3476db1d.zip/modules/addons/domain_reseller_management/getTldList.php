<?php
require __DIR__ . '/../../../init.php';

use \Illuminate\Database\Capsule\Manager as Capsule;

require_once dirname(__FILE__).DIRECTORY_SEPARATOR.'unirest-php'.DIRECTORY_SEPARATOR.'Unirest.php';
require_once 'utils.php';

$token = 'Bearer '.domainResellerGetToken();
$apiBaseUrl = domainResellerGetApiUrl();

$headers = array("Accept" => "application/json","Content-Type"=>"application/json; charset=UTF-8");
$headers['Authorization'] = $token;

$response = domainResellerUnirest\Request::get($apiBaseUrl.'tld', $headers, []);
$tld = [];
if($response->code == 200){
	foreach ($response->body->result->tld as $t) {
		if($t->active == 1){
			$tld['tld'][] = ['tld'=>$t->tld,'register'=>$t->register_price,'renew'=>$t->renew_price,'redemption'=>$t->redemption_price,'transfer'=>$t->transfer_price];
		}
	}
	$tld['promotion'] = $response->body->result->promotion;
}
echo json_encode($tld);
exit;
