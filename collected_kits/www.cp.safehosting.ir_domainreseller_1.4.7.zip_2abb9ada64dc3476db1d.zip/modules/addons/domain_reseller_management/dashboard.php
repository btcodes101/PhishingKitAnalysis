<?php
if(!isset($_SESSION['adminid'])){
    exit;
}
require_once dirname(__FILE__).DIRECTORY_SEPARATOR.'unirest-php'.DIRECTORY_SEPARATOR.'Unirest.php';
    $err = [];
    global $moduleParams;
    
    $headers = array("Accept" => "application/json","Content-Type"=>"application/json; charset=UTF-8",);
    $headers['Authorization'] = $moduleParams['token'];
    $response = domainResellerUnirest\Request::get($moduleParams['apiurl'] . 'reseller', $headers, ['version'=>domainResellerGetVersion()]);

    if ($response->code != 200) {
        $err[] = $response->body->errorDetails;
    }
    require_once dirname(__FILE__).DIRECTORY_SEPARATOR.'views'.DIRECTORY_SEPARATOR.'dashboard.php';
