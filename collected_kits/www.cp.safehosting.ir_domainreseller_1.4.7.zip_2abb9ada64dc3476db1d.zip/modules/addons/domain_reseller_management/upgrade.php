<?php
if(!isset($_SESSION['adminid'])){
    exit;
}
require_once dirname(__FILE__) . DIRECTORY_SEPARATOR . 'unirest-php' . DIRECTORY_SEPARATOR . 'Unirest.php';
callMethod();
function index()
{
    $err = [];

    global $moduleParams;
    $apiUrl = domainResellerGetApiUrl('upgrade');
    if (isset($_POST['domain_reseller_management_upgrade'])) {

        $headers = array("Accept" => "application/zip", "Content-Type" => "application/json; charset=UTF-8",);
        $headers['Authorization'] = $moduleParams['token'];

        set_time_limit(0);


        $response = domainResellerUnirest\Request::get($apiUrl . 'module', $headers, ['version' => domainResellerGetVersion()]);


        if ($response->code != 200) {
            $err[] = $response->body->errorDetails;
        } else {
            $baseDest = __DIR__.'/tmp';
            if(!is_dir($baseDest)){
                mkdir($baseDest,0777);
            }
            $file_dest = $baseDest . '/module.zip';
            $file = file_put_contents($file_dest, $response->raw_body);
            $modulePath = __DIR__ . '/../..';
            $oldVersion = domainResellerGetVersion();
            $oldVersion = (int) str_replace('.','',$oldVersion);
            $templateReplace = false;
            if(isset($_POST['templateReplace']) && $_POST['templateReplace'] == 1){
                $templateReplace = true;
            }
            if ($file !== false) {
                $zip = new ZipArchive();
                if ($zip->open($file_dest) === TRUE) {
                    for ($i = 0; $i < $zip->numFiles; $i++) {
                        $item = $zip->getNameIndex($i);
                        $filename = pathinfo($item);
                        if($templateReplace !== true && $filename['extension'] == 'tpl'){
                            continue;
                        }
                        $match = strstr($item, '/', true);
                        $check = true;
                        switch ($match) {
                            case 'domain_reseller':
                                $check = $zip->extractTo($modulePath . '/registrars/', [$item]);
                                break;
                            case 'domain_reseller_management':
                                $check = $zip->extractTo($modulePath . DIRECTORY_SEPARATOR . 'addons' . DIRECTORY_SEPARATOR, [$item]);
                                break;
                            case 'domain_reseller_service':
                                $check = $zip->extractTo($modulePath . DIRECTORY_SEPARATOR . 'servers' . DIRECTORY_SEPARATOR, [$item]);
                                break;
                        }
                        if($check == false){
                            $err[] = "امکان ذخیره فایل {$item} وجود ندارد لطفا سریعا نسبت به بروزرسانی مجددا اقدام نمایید ";
                        }
                    }
                    $zip->close();
                    if(empty($err)){
                        $suc = 'بروزرسانی ماژول با موفقیت انجام پذیرفت';
                        require_once __DIR__.'/migrate.php';
                        runMigrate($oldVersion);
                    }

                    unlink($file_dest);
                } else {
                    $err[] = 'امکان استخراج فایلها وجود ندارد';
                }
            } else {
                $err[] = 'امکان ذخیره ماژول وجود ندارد';
            }
        }
    }

    $headers = array("Accept" => "application/json", "Content-Type" => "application/json; charset=UTF-8",);
    $headers['Authorization'] = $moduleParams['token'];
    $params = [];
    //$params['message'] = $_POST['domain_reseller_management_feedback'];
    $params = json_encode($params);
    $response = domainResellerUnirest\Request::get($apiUrl . 'version', $headers, $params);

    if ($response->code != 200) {
        $err[] = $response->body->errorDetails;
    } else {
        $availVersion = $response->body->result;
    }
    $curVersion = domainResellerGetVersion();

    require_once dirname(__FILE__) . DIRECTORY_SEPARATOR . 'views' . DIRECTORY_SEPARATOR . 'upgrade.php';
}
