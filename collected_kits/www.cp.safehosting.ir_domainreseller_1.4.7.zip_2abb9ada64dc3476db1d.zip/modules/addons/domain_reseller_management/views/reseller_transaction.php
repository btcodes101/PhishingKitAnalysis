<?php
require dirname(dirname(__FILE__)) . DIRECTORY_SEPARATOR . 'JDateTime.php';
$jdate = new JDateTime(false);
?>
<div class="dashboard">
    <div>
        <?php
        if (!empty($err)) {
            echo '<div style="color:red;">';
            foreach ($err as $er) {
                echo $er . '<br/>';
            }
            echo '</div>';
        } elseif (isset($suc) && $suc != '') {
            echo '<div style="color:green;">' . $suc . '</div>';
        }

        ?>

    </div>
    <h2>
        <?php if(isset($_GET['status']) && $_GET['status'] == 'locked'){
            domainResellerTranslate('reseller_locked_list');
        }else{
            domainResellerTranslate('reseller_success_list');
        } ?>
    </h2>
    <?php if ($response->code == 200) { ?>

        <?php if (isset($response->headers['X-Pagination-Total-Count'])) { ?>
            <div>
                <table>
                    <tr>
                        <td>
                            <form id="pages" method="post" action="">
                                <?php
                                $totalPage = $totalPages = ceil($response->headers['X-Pagination-Total-Count']/$response->headers['X-Pagination-Per-Page']);
                                $page = $response->headers['X-Pagination-Current-Page'];
                                ?>
                                <select name="page" onchange="submit()">
                                    <?php for ($i = 1; $i <= $totalPages; $i++) { ?>
                                        <option
                                            value="<?= $i ?>" <?php if ($i == $page) { ?> selected="" <?php } ?>><?= $i ?></option>
                                    <?php } ?>
                                </select> <input type="submit" name="filter"
                                                 value="<?php domainResellerTranslate('display') ?>"
                                                 class="btn btn-xs btn-default">
                            </form>
                        </td>
                    </tr>
                </table>
            </div>
        <?php } ?>
        <table class="datatable" width="100%" border="0" cellspacing="1" cellpadding="3">

            <tr>
                <th><?php domainResellerTranslate('index') ?></th>
                <th><?php domainResellerTranslate('type') ?></th>
                <th><?php domainResellerTranslate('item') ?></th>
                <th><?php domainResellerTranslate('action') ?></th>
                <th><?php domainResellerTranslate('amount') ?></th>
                <th><?php domainResellerTranslate('reseller_id') ?></th>
                <th><?php domainResellerTranslate('date') ?></th>
                <th><?php domainResellerTranslate('reseller_transaction_id') ?></th>
            </tr>
            <?php
            $totalAmount = 0;
            $totalCharge = 0;
            $totalPaid = 0;
            foreach ($response->body->result as $index => $item) {
                $req = json_decode($item->request_msg);
                if($item->type == 'charge'){
                    $totalCharge += isset($req->price) ? $req->price : (isset($req->charge)) ?  $req->charge : $req->amount;
                }else{
                    $totalPaid += isset($req->price) ? $req->price : $req->amount;
                }

                ?>
                <tr>
                    <td><?= $index + 1 ?></td>
                    <td><?= $item->type ?></td>
                    <td><?php
                        echo $item->domain_name;
                        if($item->type == 'charge' && isset($req->type) && $req->type == 'bonus'){
                                echo '<br/>bonus';
                        }

                        ?>
                    </td>
                    <td><?= $item->action ?></td>
                    <td style="color:<?= ($item->type == 'charge') ? 'green' : 'red' ?>"><?php
                        if(isset($req->price)) {
                            echo number_format($req->price);
                            $totalAmount += $req->price;
                        }
                        elseif(isset($req->charge)) {
                            echo number_format($req->charge);
                            $totalAmount += $req->charge;
                        }
                        elseif(isset($req->amount)) {
                            echo number_format($req->amount);
                            $totalAmount += $req->amount;
                        }
                        ?></td>
                    <td><?= (!is_null($item->reseller_id)) ? $item->reseller_id : $_GET['resellerId'] ?></td>
                    <td><?= (!is_null($item->request_time)) ? $jdate->date('Y-m-d H:i:s', $item->request_time): $jdate->date('Y-m-d H:i:s', $item->extra_time) ?></td>
                    <td><?= $item->transaction_id ?></td>
                </tr>
            <?php } ?>
        </table>

        <div>مجموع سفارش:  <?= number_format($totalPaid) ?>ریال  |  افزایش موجودی : <?= number_format($totalCharge) ?> ریال </div>(در این صفحه)
    <?php } ?>
</div>

