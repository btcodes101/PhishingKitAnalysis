<?php
/**
 * Created by PhpStorm.
 * User: MJahanbakhsh
 * Date: 18/10/2016
 * Time: 10:34 AM
 */

?>

<ul>
    <li><a href="<?php domainResellerGetBaseUrl('reseller','profile',['resellerId'=>$_GET['resellerId']]) ?>">مشاهده مشخصات</a></li>
    <li><a href="<?php domainResellerGetBaseUrl('reseller','edit',['resellerId'=>$_GET['resellerId']]) ?>">ویرایش مشخصات</a></li>
    <li><a href="<?php domainResellerGetBaseUrl('reseller','token',['resellerId'=>$_GET['resellerId']]) ?>">ارسال توکن جدید</a></li>
    <li><a href="<?php domainResellerGetBaseUrl('reseller','domains',['resellerId'=>$_GET['resellerId']]) ?>">لیست دامنه ها</a></li>
    <li><a href="<?php domainResellerGetBaseUrl('reseller','transaction',['resellerId'=>$_GET['resellerId'],'status'=>'success']) ?>">لیست تراکنش ها</a></li>
    <li><a href="<?php domainResellerGetBaseUrl('reseller','transaction',['resellerId'=>$_GET['resellerId'],'status'=>'locked']) ?>">لیست مبالغ قفل شده</a></li>
</ul>
