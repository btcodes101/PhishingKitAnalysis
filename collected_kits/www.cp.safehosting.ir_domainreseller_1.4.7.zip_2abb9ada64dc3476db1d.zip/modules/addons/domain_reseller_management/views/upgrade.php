<div class="dashboard">
	<div>
		<?php
		if (!empty($err)) {
			echo '<div style="color:red;">';
			foreach ($err as $er) {
				echo $er . '<br/>';
			}
			echo '</div>';
		} elseif (isset($suc) && $suc != '') {
			echo '<div style="color:green;">' . $suc . '</div>';
		}

		?>

	</div>

<?php if(empty($err) || !isset($suc)) { ?>
    <?php if (class_exists('ZipArchive')) { ?>
		<div>
			<form action="<?php domainResellerGetBaseUrl('upgrade', 'index') ?>" method="post">
				<div>
					<ul>
						<li><?php domainResellerTranslate('upgrade_current_version') ?>
							: <?php echo $curVersion; ?></li>

						<?php if ($curVersion != $availVersion) { ?>
							<li><?php domainResellerTranslate('upgrade_last_version') ?><?php echo $availVersion ?></li>
                            <li><input type="checkbox" name="templateReplace" value="1" /><?php domainResellerTranslate('upgrade_template_replace') ?></li>
							<li><input type="submit" name="domain_reseller_management_upgrade" value="<?= domainResellerTranslate('upgrade_submit') ?>"></li>
						<?php } else { ?>
							<li><?php domainResellerTranslate('upgrade_updated') ?></li>
						<?php } ?>
					</ul>
				</div>
			</form>
			<div id="resultUpgrade"></div>
		</div>
	<?php } else { ?>
		<div>
			لطفا ابتدا ماژول <a href="http://php.net/manual/en/zip.installation.php">zip</a> در php را فعال نمایید
		</div>
	<?php }
}?>
</div>