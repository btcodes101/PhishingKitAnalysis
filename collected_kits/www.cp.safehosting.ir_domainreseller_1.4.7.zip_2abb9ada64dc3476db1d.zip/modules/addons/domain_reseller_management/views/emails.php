<link href="<?php echo $moduleParams['baseUrl']; ?>/modules/addons/domain_reseller_management/css/js_persian_cal.css" rel="stylesheet" type="text/css" />
<script src="<?php echo $moduleParams['baseUrl']; ?>/modules/addons/domain_reseller_management/js/js_persian_cal.js" type="text/javascript" ></script>
<?php
require dirname(dirname(__FILE__)) . DIRECTORY_SEPARATOR .'JDateTime.php';
$jdate = new JDateTime(false);
if(isset($msg)){
	echo $msg;
}
?>
<form id="searchesLog" method="get" action="<?php domainResellerGetBaseUrl('logs') ?>">
	<?php
	foreach ($_GET as $key => $value) {
		echo("<input type='hidden' name='$key' value='$value'/>");
	}
	?>
	<table>
		<tr>
			<td>
				<label><?php domainResellerTranslate('item') ?></label>
			</td>
			<td>
				<input type="text" name="item" value="<?php if(isset($_GET['item'])) echo  $_GET['item'];  ?>" />
			</td>
			<td>
				<label><?php domainResellerTranslate('from_date') ?></label>
			</td>
			<td>
				<input readonly="readonly" type="text" value="<?php if(isset($_GET['g_from'])) echo  $_GET['g_from'];  ?>" class="form-control" name="g_from" id="pcal1">
				<input type="hidden" readonly="readonly" name="from" value="<?php if(isset($_GET['from'])) echo  $_GET['from'];  ?>" id="extra_from">
			</td>
			<td>
				<label><?php domainResellerTranslate('to_date') ?></label>
			</td>
			<td>
				<input readonly="readonly" type="text" value="<?php if(isset($_GET['g_to'])) echo  $_GET['g_to'];  ?>" style="" class="form-control" name="g_to" id="pcal2">
				<input type="hidden" readonly="readonly" value="<?php if(isset($_GET['to'])) echo  $_GET['to'];  ?>" name="to" id="extra_to">
			</td>

			<td>
				<label><?php domainResellerTranslate('status') ?></label>
			</td>
			<td>
				<select name="status">
					<option value="all" <?php if(isset($_GET['status']) && $_GET['status'] == 'all') echo  'selected="selected"';  ?>><?php domainResellerTranslate('all') ?></option>
					<option value="pending" <?php if(isset($_GET['status']) && $_GET['status'] == 'pending') echo  'selected="selected"';  ?>><?php domainResellerTranslate('pending') ?></option>
					<option value="failed" <?php if(isset($_GET['status']) && $_GET['status'] == 'failed') echo  'selected="selected"';  ?>><?php domainResellerTranslate('failed') ?></option>
				</select>
			</td>

			<td>
				<input type="submit" name="search" value="<?php domainResellerTranslate('search') ?>" class="btn btn-xs btn-default" />
			</td>
		</tr>
	</table>
</form>
<script type="text/javascript">
	var objCal1 = new AMIB.persianCalendar( 'pcal1',{ extraInputID: "extra_from", extraInputFormat: "YYYY-MM-DD" });
	var objCal2 = new AMIB.persianCalendar( 'pcal2',{ extraInputID: "extra_to", extraInputFormat: "YYYY-MM-DD" });
	var objCal3 = new AMIB.persianCalendar( 'pcal3',{ extraInputID: "rextra_from", extraInputFormat: "YYYY-MM-DD" });
</script>
<table>
	<tr>
		<td>
			<form id="pages" method="post" action="">
				<select name="page" onchange="submit()">
					<?php for ($i = 1;$i <= $totalPages ; $i++) {?>
						<option value="<?= $i ?>"  <?php if($i == $page) {?> selected="" <?php }?>><?= $i ?></option>
					<?php }?>
				</select> <input type="submit" name="filter" value="<?php domainResellerTranslate('display') ?>" class="btn btn-xs btn-default">
			</form>
		</td>
	</tr>
</table>
<table class="datatable" width="100%" border="0" cellspacing="1" cellpadding="3">

	<tr>
		<th><?php domainResellerTranslate('index') ?></th>
		<th><?php domainResellerTranslate('item') ?></th>
		<th><?php domainResellerTranslate('status') ?></th>
		<th><?php domainResellerTranslate('date') ?></th>
		<th><?php domainResellerTranslate('email_ticket_pending_id') ?></th>
		<th><?php domainResellerTranslate('email_ticket_failed_id') ?></th>
		<th><?php domainResellerTranslate('request') ?></th>
		<th><?php domainResellerTranslate('result') ?></th>
	</tr>

	<?php
	$index = 1;
	foreach ($logs as $log): ?>
		<?php
			$item = $log->item;
			$request =json_decode(trim($log->request),true);

		?>

		<tr>
			<td><?php echo $index++ ?></td>
			<td><?php echo $item ?></td>
			<td><?php echo $log->status ?></td>
			<td><?php echo $jdate->date('Y-m-d H:i',strtotime($log->created_at)) ?></td>
			<td><?php echo (isset($request['pendingEmailTicket'])) ? "<a href='supporttickets.php?action=viewticket&id={$request['pendingEmailTicket']}'>{$request['pendingEmailTicket']}</a>" : '' ?></td>
			<td><?php echo (isset($request['failedEmailTicket'])) ? "<a href='supporttickets.php?action=viewticket&id={$request['failedEmailTicket']}'>{$request['failedEmailTicket']}</a>" : '' ?></td>
			<td>
				<div style="display: none;" id="rq<?php echo $log->id ?>">
                    <pre>
                        <?php

						if(isset($request['requestTime'])){
							$request['requestTime'] = $jdate->date('Y-m-d H:i:s',$request['requestTime']);
							$request['responseTime'] = $jdate->date('Y-m-d H:i:s',$request['responseTime']);
						}
						print_r($request);
						?>
                    </pre>
				</div>
				<button onclick="show_page('rq<?php echo $log->id ?>')"><?php domainResellerTranslate('display') ?></button>
			</td>
			<td>
				<?php
				$result = json_decode($log->result,true);
				if(!empty($result)){
					?>
					<div style="display: none;" id="rs<?php echo $log->id ?>">
						<?php

						if(!empty($result)) {
							if(isset($result['cron']) && !empty($result['cron'])){
								echo 'Update Result: <ul>';
								joker_renderResult($result['cron']);
								echo '</ul><hr/>';
							}
							echo '<ul>';
							joker_renderResult($result);
							echo '</ul>';
						}
						?>
					</div>

					<button onclick="show_page('rs<?php echo $log->id ?>')"><?php domainResellerTranslate('display') ?></button>
				<?php } ?>
			</td>
		</tr>
	<?php endforeach; ?>
</table>

<script type="text/javascript">
	function show_page(id) {
		win = window.open('', 'data', "scrollbars=1,width=600,height=400");
		win.document.write('');
		win.document.write($('#' +id).html());
	}
</script>

<?php
function joker_renderResult($result){

	$jdate = new JDateTime(false);
	if ($result['status'] == 'failed') {
		echo '<li>Status: failed</li>';
		echo "<li>Result Code: {$result['error']}</li>";
		echo "<li>Internal Tracking: {$result['internalTracking']}</li>";

		if(isset($result['deliveryTime'])){
			//$d = new DateTime($result['deliveryTime']);
			//echo "<li>Delivery Time : ".$jdate->date('c',$d->getTimestamp(),false,true,$d->getTimezone())."</li>";
			echo "<li>Delivery Time : ".$result['deliveryTime']."</li>";
		}elseif(isset($result['resultTime'])){
			//$d = new DateTime($result['resultTime']);
			//echo "<li>Result Time: ".$jdate->date('c',$d->getTimestamp(),false,true,$d->getTimezone())."</li>";
			echo "<li>Result Time : ".$result['resultTime']."</li>";
		}
		if(is_array($result['errorDetails'])){
			$result['errorDetails'] = implode(',',$result['errorDetails']);
		}
		$result['errorDetails'] = str_replace('<','',$result['errorDetails']);
		echo "<li>Result Details: {$result['errorDetails']}</li>";
		if (is_array($result['extraDetails'])) {
			echo '<li>ExtraDetails: <ul>';
			foreach ($result['extraDetails'] as $k => $v) {
				echo "<li>$k : $v</li>";
			}
			echo '</ul></li>';
		} else {
			echo "<li>Extra Details: {$result['extraDetails']}</li>";
		}

	} else {

		echo '<li>Status: '.$result['status'].'</li>';
		echo '<li>Result Code: '.$result['error'].'</li>';
		if($result['internalTracking'] != '') {
			echo "<li>Internal Tracking: {$result['internalTracking']}</li>";
		}
		if(isset($result['deliveryTime'])){
			//$d = new DateTime($result['deliveryTime']);
			//echo "<li>Delivery Time : ".$jdate->date('c',$d->getTimestamp(),false,true,$d->getTimezone())."</li>";
			echo "<li>Delivery Time : ".$result['deliveryTime']."</li>";
		}elseif(isset($result['resultTime'])){
			//$d = new DateTime($result['resultTime']);
			//echo "<li>Result Time: ".$jdate->date('c',$d->getTimestamp(),false,true,$d->getTimezone())."</li>";
			echo "<li>Result Time : ".$result['resultTime']."</li>";
		}

		if (is_array($result['result'])) {
			echo '<li>Result Details: <ul>';
			foreach ($result['result'] as $k => $v) {
				echo "<li>$k : $v</li>";
			}
			echo '</ul></li>';
		} else {
			echo "<li>Result Details: {$result['result']}</li>";
		}

		if (is_array($result['extraDetails'])) {
			echo '<ul>Extra Details:';
			foreach ($result['extraDetails'] as $k => $v) {
				echo "<li>$k : $v</li>";
			}
			echo '<ul>';
		} else {
			echo "<li>Extra Details: {$result['extraDetails']}</li>";
		}

	}
}

?>