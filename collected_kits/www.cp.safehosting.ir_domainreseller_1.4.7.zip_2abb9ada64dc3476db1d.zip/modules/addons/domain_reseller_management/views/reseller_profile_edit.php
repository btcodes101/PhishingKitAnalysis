<div class="dashboard">
    <div>
        <?php
        if (!empty($err)) {
            echo '<div style="color:red;">';
            foreach ($err as $er) {
                echo $er . '<br/>';
            }
            echo '</div>';
        } elseif (isset($suc) && $suc != '') {
            echo '<div style="color:green;">' . $suc . '</div>';
        }

        ?>

    </div>
    <?php if ($response->code == 200) { ?>
        <div style="width: 100%">
            <div style="width: 30%; float: right">
                <?php include 'reseller_menu.php'; ?>
            </div>
            <div style="width: 30%; float: right">
                <form
                    action="<?php domainResellerGetBaseUrl('reseller', 'edit', ['resellerId' => $_GET['resellerId']]) ?>"
                    method="post">
                    <ul>
                        <li>
                            <?php domainResellerTranslate('reseller_id') ?>
                            : <?php echo $_GET['resellerId']; ?>
                        </li>
                        <li>
                            <?php domainResellerTranslate('name') ?>
                            : <input type="text" name="name" value="<?php echo $response->body->result->name; ?>"/>
                        </li>
                        <li>
                            <?php domainResellerTranslate('email') ?>
                            : <input type="text" name="email" value="<?php echo $response->body->result->email; ?>"/>
                        </li>
                        <li>
                            <?php domainResellerTranslate('mobile') ?>
                            : <input type="text" name="mobile" value="<?php echo $response->body->result->mobile; ?>"/>
                        </li>
                        <li>
                            <?php domainResellerTranslate('address') ?>
                            : <input type="text" name="address"
                                     value="<?php echo $response->body->result->address; ?>"/>
                        </li>

                        <li>
                            <input type="submit" name="editSubmit" value="<?php domainResellerTranslate('submit') ?>" />
                        </li>
                    </ul>
                </form>
            </div>

        </div>
    <?php } ?>
</div>
