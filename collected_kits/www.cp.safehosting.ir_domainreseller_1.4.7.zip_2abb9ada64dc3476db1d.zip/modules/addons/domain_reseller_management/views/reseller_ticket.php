<div class="dashboard">
	<div>
		<?php
		if (!empty($error)) {
			echo '<div style="color:red;">';
			foreach ($error as $er) {
				echo $er . '<br/>';
			}
			echo '</div>';
		} elseif (isset($suc) && $suc != '') {
			echo '<div style="color:green;">' . $suc . '</div>';
		}

		?>
	</div>
	<div>
		<form name="" method="post" action="<?php domainResellerGetBaseUrl('reseller','ticket') ?>">
            <table class="form" width="100%" border="0" cellspacing="2" cellpadding="3">
                <tbody>
                <tr>
                    <td class="fieldlabel" style="width: 25%">عنوان تیکت</td>
                    <td class="fieldarea"><input name="ticketTitle" value="" class="form-control" /></td>
                </tr>
                <tr>
                    <td class="fieldlabel" style="width: 25%">متن تیکت</td>
                    <td class="fieldarea">
                        <textarea name="ticketMsg" class="form-control" rows="5"></textarea>
                        <div><?php domainResellerTranslate('setting_params_allow') ?> : <span style="text-align: left;direction: ltr">[$name]</span></div>
                    </td>
                </tr>
                <tr>
                    <td class="fieldlabel" style="width: 25%">وضعیت تیکت</td>
                    <td class="fieldarea">
                        <select name="ticketStatus">
                            <option name="Answered">Answered</option>
                            <option name="Open">Open</option>
                            <option name="Customer-Reply">Customer-Reply</option>
                            <option name="In-Progress">In-Progress</option>
                            <option name="On Hold">On Hold</option>
                            <option name="Closed">Closed</option>
                        </select>
                    </td>
                </tr>
                <tr>
                    <td style="width: 25%" class="fieldlabel">
                        <label><?php domainResellerTranslate('setting_department') ?></label>
                    </td>
                    <td class="fieldarea">
                        <select name="ticketDepartment">
                            <?php
                            foreach ($department as $id => $name) {
                                echo '<option value="' . $id . '">' . $name . '</option>';
                            }
                            ?>
                        </select>
                    </td>
                </tr>
                </tbody>
            </table>

            <div class="btn-container">
                <input type="submit" name="ticketSubmit" value="<?php domainResellerTranslate('submit') ?>" class="button btn btn-default" />
            </div>
		</form>
	</div>


</div>
