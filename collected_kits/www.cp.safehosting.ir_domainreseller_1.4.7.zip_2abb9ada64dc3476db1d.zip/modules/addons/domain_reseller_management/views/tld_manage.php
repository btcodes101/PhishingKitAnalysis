<div class="dashboard">
	<div>
		<?php
		if (!empty($error)) {
			echo '<div style="color:red;">';
			foreach ($error as $er) {
				echo $er . '<br/>';
			}
			echo '</div>';
		} elseif (isset($suc) && $suc != '') {
			echo '<div style="color:green;">' . $suc . '</div>';
		}

		?>

	</div>
	<div>
		
        <?php if (empty($error)) { ?>
			<a href="<?php domainResellerGetBaseUrl('reseller','manage',['resellerId'=>$_GET['resellerId']]) ?>"><?php domainResellerTranslate('tld_manage') ?></a> | <a href="<?php domainResellerGetBaseUrl('reseller','assign',['resellerId'=>$_GET['resellerId']]) ?>"><?php domainResellerTranslate('tld_assign') ?></a>

			<form name="" method="post" action="<?php domainResellerGetBaseUrl('reseller','manage',['resellerId'=>$_GET['resellerId']]) ?>">
				<label><?php domainResellerTranslate('tld_profit_buy') ?></label><input type="text" name="profit" value="" />
				<input type="submit" name="submit" value="<?php domainResellerTranslate('update') ?>" />
			</form>
			<div class="tablebg">
				<table id="sortabletbl1" class="datatable" width="100%" border="0" cellspacing="1" cellpadding="3">
					<thead>
					<tr>
						<th><?php domainResellerTranslate('item') ?></th>
						<th><?php domainResellerTranslate('tld') ?></th>
						<th><?php domainResellerTranslate('register_amount') ?> (<?php domainResellerTranslate($unitsKey) ?>)</th>
						<th><?php domainResellerTranslate('renew_amount') ?> (<?php domainResellerTranslate($unitsKey) ?>)</th>
						<th><?php domainResellerTranslate('redemption_amount') ?> (<?php domainResellerTranslate($unitsKey) ?>)</th>
						<th><?php domainResellerTranslate('transfer_amount') ?> (<?php domainResellerTranslate($unitsKey) ?>)</th>
						<th><?php domainResellerTranslate('status') ?></th>
						<th><?php domainResellerTranslate('operation') ?></th>
					</tr>
					</thead>
					<tbody>
					<?php
					foreach($tld as $index=>$t){
						
						?>
						<tr>
							<td>
								<?php echo ($index+1); ?>
							</td>
							<td>
								<?php echo $t->tld ?>
							</td>
							<td>
                                <?php echo ($unitsKey == 'toman') ? $parentTld[$t->tld]->register_price_buy/10 : $parentTld[$t->tld]->register_price_buy ; ?>
                                <br/>
								<input type="text" name="register_price[<?php echo $t->tld ?>]" value="<?php echo ($unitsKey == 'toman') ? $t->register_price_buy/10 : $t->register_price_buy ?>" />
							</td>
                            <td>
                                <?php echo ($unitsKey == 'toman') ? $parentTld[$t->tld]->renew_price_buy/10 : $parentTld[$t->tld]->renew_price_buy ?>
                                <br/>
                                <input type="text" name="renew_price[<?php echo $t->tld ?>]" value="<?php echo ($unitsKey == 'toman') ? $t->renew_price_buy/10 : $t->renew_price_buy ?>"/>
                            </td>
							<td>
								<?php echo ($unitsKey == 'toman') ? $parentTld[$t->tld]->redemption_price_buy/10 : $parentTld[$t->tld]->redemption_price_buy ?>
								<br/>
								<input type="text" name="redemption_price[<?php echo $t->tld ?>]" value="<?php echo ($unitsKey == 'toman') ? $t->redemption_price_buy/10 : $t->redemption_price_buy ?>"/>
							</td>
                            <td>
                                <?php echo ($unitsKey == 'toman') ? $parentTld[$t->tld]->transfer_price_buy/10 : $parentTld[$t->tld]->transfer_price_buy ?>
                                <br/>
                                <input type="text" name="transfer_price[<?php echo $t->tld ?>]" value="<?php  echo ($unitsKey == 'toman') ? $t->transfer_price_buy/10 : $t->transfer_price_buy ?>"/>
                            </td>
                            <td>
                                <input type="checkbox" name="domain_reseller_management_tld[<?php echo $t->tld ?>][active]" <?php if ($t->active == 1) echo 'checked="checked"' ?> value="1"/>
                            </td>
                            <td>
                                <a href="#" onclick="return updateTld('<?php echo $t->tld ?>',this)"><?php domainResellerTranslate('update') ?></a>
                            </td>
						</tr>
					<?php } ?>
					</tbody>
				</table>
	<?php } ?>
    </div>
</div>

<script type="text/javascript">
    function updateTld(tld,el){

        var data = {};
        data['tld'] = tld;
        data['id'] = <?php echo intval($_GET['resellerId']); ?>;
        data['register_price'] = $('input[name="register_price['+tld+']"]').val();
        data['renew_price'] = $('input[name="renew_price['+tld+']"]').val();
		data['redemption_price'] = $('input[name="redemption_price['+tld+']"]').val();
        data['transfer_price'] = $('input[name="transfer_price['+tld+']"]').val();
        data['active'] = 0;
        if($('input[name="domain_reseller_management_tld['+tld+'][active]"]:checked').length > 0){
            data['active'] = 1;    
        }
        $(el).text('<?php domainResellerTranslate('wait') ?>');
        $.ajax({
            url: "<?php domainResellerGetBaseUrl('reseller','ajaxupdatetld',[],true) ?>",
            data : data,
            type: "POST",
            error: function(xhr,status,error){
                $(el).text('<?php domainResellerTranslate('update') ?>');
                alert(xhr.responseText);
            },
            success: function(result){
                $(el).text('<?php domainResellerTranslate('update') ?>');
                alert(result);
            }
        });
        return false;
    }
	function changeInput(id,el){
		$('.inputChk'+id).prop('disabled',!$(el).prop("checked"));
	}
	$("#checkAll").change(function () {
		$(".chkBox").prop('checked', $(this).prop("checked"));
	});
</script>