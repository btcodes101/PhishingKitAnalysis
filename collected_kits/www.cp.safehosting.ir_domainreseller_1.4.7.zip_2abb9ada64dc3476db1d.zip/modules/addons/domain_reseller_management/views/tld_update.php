<div class="tld">
    <div>
        <?php
        if (!empty($error)) {
            echo '<div style="color:red;">';
            if(is_array($error)){
                foreach ($error as $er) {
                    echo $er . '<br/>';
                }
            }else{
                echo $error . '<br/>';
            }
            echo '</div>';
        } elseif (isset($suc) && $suc != '') {
            echo '<div style="color:green;">' . $suc . '</div>';
        }

        ?>

    </div>
    <?php if (!isset($_POST['tld']['submit']) && $response->code == 200) { ?>
        <form name="" method="post" action="<?php domainResellerGetBaseUrl('domaintld','update',['tld'=>$_GET['tld']]) ?>">
            <table style="width: 100%">
                <tr>
                    <td>
                        <label><?php domainResellerTranslate('tld') ?></label>
                    </td>
                    <td>
                        <input type="text" disabled="disabled" id="tld_tld" name="tld[tld]" value="<?php if (isset($_POST['tld']['tld'])) echo $_POST['tld']['tld'] ?>" required="required"/>
                    </td>
                    <td>
                        <label><?php domainResellerTranslate('register_amount') ?> <?php domainResellerTranslate('amount_buy') ?> (<?php domainResellerTranslate($unitsKey) ?>)</label>
                        <br>
                        <label><?php domainResellerTranslate('register_amount') ?> <?php domainResellerTranslate('amount_sell') ?> (<?php domainResellerTranslate($unitsKey) ?>)</label>
                    </td>
                    <td>
                        <input type="text" disabled="disabled" value="<?php if (isset($_POST['tld']['register_price_buy'])) echo ($unitsKey == 'toman') ? $_POST['tld']['register_price_buy']/10 : $_POST['tld']['register_price_buy'] ?>" />
                        <br>
                        <input type="text" id="tld_register_price" name="tld[register_price]" value="<?php if (isset($_POST['tld']['register_price'])) echo ($unitsKey == 'toman') ? $_POST['tld']['register_price']/10 : $_POST['tld']['register_price'] ?>" required="required"/>
                    </td>
                    <td>
                        <label><?php domainResellerTranslate('renew_amount') ?> <?php domainResellerTranslate('amount_buy') ?> (<?php domainResellerTranslate($unitsKey) ?>)</label>
                        
                        <label><?php domainResellerTranslate('renew_amount') ?> <?php domainResellerTranslate('amount_sell') ?> (<?php domainResellerTranslate($unitsKey) ?>)</label>
                    </td>
                    <td>
                        <input type="text" disabled="disabled" value="<?php if (isset($_POST['tld']['renew_price_buy'])) echo ($unitsKey == 'toman') ? $_POST['tld']['renew_price_buy']/10 : $_POST['tld']['renew_price_buy'] ?>" />
                        <br>
                        <input type="text" id="tld_renew_price" name="tld[renew_price]" value="<?php if (isset($_POST['tld']['renew_price'])) echo ($unitsKey == 'toman') ? $_POST['tld']['renew_price']/10 : $_POST['tld']['renew_price'] ?>" required="required"/>
                    </td>
                    
                    <td>
                        <label><?php domainResellerTranslate('redemption_amount') ?> <?php domainResellerTranslate('amount_buy') ?> (<?php domainResellerTranslate($unitsKey) ?>)</label>
                        <br>
                        <label><?php domainResellerTranslate('redemption_amount') ?> <?php domainResellerTranslate('amount_sell') ?> (<?php domainResellerTranslate($unitsKey) ?>)</label>
                    </td>
                    <td>
                        <input type="text" disabled="disabled" value="<?php if (isset($_POST['tld']['redemption_price_buy'])) echo ($unitsKey == 'toman') ? $_POST['tld']['redemption_price_buy']/10 : $_POST['tld']['redemption_price_buy'] ?>" />
                        <br>
                        <input type="text" id="tld_redemption_price" name="tld[redemption_price]" value="<?php if (isset($_POST['tld']['redemption_price'])) echo ($unitsKey == 'toman') ? $_POST['tld']['redemption_price']/10 : $_POST['tld']['redemption_price'] ?>" required="required"/>
                    </td>
    
                    <td>
                        <label><?php domainResellerTranslate('transfer_amount') ?> <?php domainResellerTranslate('amount_buy') ?> (<?php domainResellerTranslate($unitsKey) ?>)</label>
                        <br>
                        <label><?php domainResellerTranslate('transfer_amount') ?> <?php domainResellerTranslate('amount_sell') ?> (<?php domainResellerTranslate($unitsKey) ?>)</label>
                    </td>
                    <td>
                        <input type="text" disabled="disabled" value="<?php if (isset($_POST['tld']['transfer_price_buy'])) echo ($unitsKey == 'toman') ? $_POST['tld']['transfer_price_buy']/10 : $_POST['tld']['transfer_price_buy'] ?>" />
                        <br>
                        <input type="text" id="tld_transfer_price" name="tld[transfer_price]" value="<?php if (isset($_POST['tld']['transfer_price'])) echo ($unitsKey == 'toman') ? $_POST['tld']['transfer_price']/10 : $_POST['tld']['transfer_price'] ?>" required="required"/>
                    </td>

                    <td>
                        <label><?php domainResellerTranslate('active') ?></label>
                    </td>
                    <td>

                        <input type="checkbox" id="tld_active"
                               name="tld[active]" <?php if (isset($_POST['tld']['active']) && $_POST['tld']['active'] == 1) echo 'checked="checked"' ?>
                               class="checkbox-lg" value="1"/>
                    </td>
                </tr>
            
                <tr>
                    <td colspan="9">
                        <input type="submit" name="tld[submit]" value="<?php domainResellerTranslate('edit') ?>"/>
                    </td>
                </tr>
            
            </table>
        </form>
    <?php } ?>
</div>
