<?php
require dirname(dirname(__FILE__)) . DIRECTORY_SEPARATOR . 'JDateTime.php';
$jdate = new JDateTime(false);
?>
<div class="dashboard">
    <div>
        <?php
        if (!empty($err)) {
            echo '<div style="color:red;">';
            foreach ($err as $er) {
                echo $er . '<br/>';
            }
            echo '</div>';
        } elseif (isset($suc) && $suc != '') {
            echo '<div style="color:green;">' . $suc . '</div>';
        }

        ?>

    </div>
    <h2><?php domainResellerTranslate('reseller_domain_list') ?></h2>
    <?php if ($response->code == 200) { ?>
        <?php if (isset($response->headers['X-Pagination-Total-Count'])) { ?>
            <div>
                <table>
                    <tr>
                        <td>
                            <form id="pages" method="post" action="">
                                <?php
                                $totalPage = $totalPages = ceil($response->headers['X-Pagination-Total-Count'] / $response->headers['X-Pagination-Per-Page']);
                                $page = $response->headers['X-Pagination-Current-Page'];
                                ?>
                                <select name="page" onchange="submit()">
                                    <?php for ($i = 1; $i <= $totalPages; $i++) { ?>
                                        <option
                                            value="<?= $i ?>" <?php if ($i == $page) { ?> selected="" <?php } ?>><?= $i ?></option>
                                    <?php } ?>
                                </select> <input type="submit" name="filter"
                                                 value="<?php domainResellerTranslate('display') ?>"
                                                 class="btn btn-xs btn-default">
                            </form>
                        </td>
                    </tr>
                </table>
            </div>
        <?php } ?>
        <table class="datatable" width="100%" border="0" cellspacing="1" cellpadding="3">

            <tr>
                <th><?php domainResellerTranslate('index') ?></th>
                <th><?php domainResellerTranslate('type') ?></th>
                <th><?php domainResellerTranslate('domain') ?></th>
                <th><?php domainResellerTranslate('contact') ?></th>
                <th><?php domainResellerTranslate('date') ?></th>
                <th><?php domainResellerTranslate('expire_date') ?></th>
            </tr>
            <?php foreach ($response->body->result as $index => $item) { ?>
                <tr>
                    <td><?= $index + 1 ?></td>
                    <td><?php domainResellerTranslate($item->current_opt) ?></td>
                    <td><?= $item->reseller_domain ?></td>
                    <td><?= $item->contact ?></td>
                    <td><?= $jdate->date('Y-m-d H:i:s', $item->create_time) ?></td>
                    <td><?= $jdate->date('Y-m-d H:i:s', $item->expire_time) ?></td>
                </tr>
            <?php } ?>
        </table>
    <?php } ?>
</div>
