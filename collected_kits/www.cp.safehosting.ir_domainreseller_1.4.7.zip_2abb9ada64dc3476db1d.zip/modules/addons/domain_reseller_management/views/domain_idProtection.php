<div class="dashboard">
    <div>
        <?php
        if (!empty($error)) {
            echo '<div style="color:red;">';
            foreach ($error as $er) {
                echo $er . '<br/>';
            }
            echo '</div>';
        } elseif (isset($suc) && $suc != '') {
            echo '<div style="color:green;">' . $suc . '</div>';
        }

        ?>

    </div>

    <?php if (empty($error) || !isset($suc)) { ?>

        <div>
            <p><?= domainResellerTranslate('domain') ?>: <?= $domain->domain_fqdn ?></p>
            <p><?= domainResellerTranslate('expire_date') ?> :‌<?= date('Y-m-d', $domain->domain_expires) ?></p>
            <p><?= domainResellerTranslate('renew_date') ?> :‌<?= $periodRequested ?></p>
            <p><?= domainResellerTranslate('amount') ?>:‌<?= $price . ' ' . domainResellerTranslate($unitKey, false) ?></p>
            <p>
                <form method="post" action="<?php domainResellerGetBaseUrl('domains','idProtection',['domain'=>$domain->domain_fqdn]) ?>">
                    <input type="submit" name="idProtectionOrder" value="فعال سازی محافظت ازwhois دامنه" />
                    <p><b><?= domainResellerTranslate('id_protection_msg') ?></b></p>
                </form>
            </p>
        </div>

    <?php } ?>
</div>