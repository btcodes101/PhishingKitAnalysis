<div class="dashboard">
	<div>
		<?php
		if (!empty($err)) {
			echo '<div style="color:red;">';
			foreach ($err as $er) {
				echo $er . '<br/>';
			}
			echo '</div>';
		} elseif (isset($suc) && $suc != '') {
			echo '<div style="color:green;">' . $suc . '</div>';
		}

		?>

	</div>
	
	<?php if ($response->code == 200) { ?>
	<div >
		<ul>
			<li>
				<?php domainResellerTranslate('reseller_balance') ?> : <a href="<?php domainResellerGetBaseUrl('reseller','transaction',['resellerId'=>$response->body->result->id,'status'=>'success']) ?>"><?php echo number_format($response->body->result->charge); ?> <?php domainResellerTranslate('rial') ?></a>
			</li>
			<li>
				<?php domainResellerTranslate('reseller_balance_locked') ?> : <a href="<?php domainResellerGetBaseUrl('reseller','transaction',['resellerId'=>$response->body->result->id,'status'=>'locked']) ?>"><?php echo number_format($response->body->result->locked); ?> <?php domainResellerTranslate('rial') ?></a>
			</li>
			<li>
				<?php domainResellerTranslate('reseller_subset') ?> : <a href="<?php domainResellerGetBaseUrl('reseller','index') ?>"><?php echo count($response->body->result->subset); ?></a> | <a href="<?php domainResellerGetBaseUrl('reseller','ticket') ?>"><?php domainResellerTranslate('reseller_ticket') ?></a>
			</li>
			<li>
				<?php domainResellerTranslate('reseller_active_domain') ?> : <a href="<?php domainResellerGetBaseUrl('reseller','domains',['resellerId'=>$response->body->result->id]) ?>"><?php echo $response->body->result->domain; ?></a>
			</li>
		</ul>
	</div>
	<?php } ?>
</div>
