<div class="tld">
    <div>
        <?php
        if (!empty($error)) {
            echo '<div style="color:red;">';
            if(is_array($error)){
                foreach ($error as $er) {
                    echo $er . '<br/>';
                }
            }else{
                print_r($error) . '<br/>';
            }
            echo '</div>';
        } elseif (isset($suc) && $suc != '') {
            echo '<div style="color:green;">' . $suc . '</div>';
        }

        ?>

    </div>
    <?php if (!isset($_POST['tld']['submit']) && $response->code == 200) { ?>
        <form name="" method="post" action="<?php domainResellerGetBaseUrl('reseller','updatetld',['tld'=>$_GET['tld'],'id'=>$_GET['id']]) ?>">
            <table>
                <tr>
                    <td>
                        <label>پسوند</label>
                    </td>
                    <td>
                        <input type="text" disabled="disabled" id="tld_tld" name="tld[tld]" value="<?php if (isset($_POST['tld']['tld'])) echo $_POST['tld']['tld'] ?>" required="required"/>
                    </td>
                    <td>
                        <label>مبلغ خرید ثبت(<?php echo $units ?>)</label>
                    </td>
                    <td>
                        <input type="text" id="tld_register_price" name="tld[register_price]" value="<?php if (isset($_POST['tld']['register_price_buy'])) echo $_POST['tld']['register_price_buy'] ?>" required="required"/>
                    </td>
                    <td>
                        <label>مبلغ خرید تمدید(<?php echo $units ?>)</label>
                    </td>
                    <td>
                        <input type="text" id="tld_renew_price" name="tld[renew_price]" value="<?php if (isset($_POST['tld']['renew_price_buy'])) echo $_POST['tld']['renew_price_buy'] ?>" required="required"/>
                    </td>
                    <td>
                        <label>مبلغ خرید انتقال(<?php echo $units ?>)</label>
                    </td>
                    <td>
                        <input type="text" id="tld_transfer_price" name="tld[transfer_price]" value="<?php if (isset($_POST['tld']['transfer_price_buy'])) echo $_POST['tld']['transfer_price_buy'] ?>" required="required"/>
                    </td>
                    <td>
                        <label>مبلغ فروش ثبت(<?php echo $units ?>)</label>
                    </td>
                    <td>
                        <input type="text" disabled="disabled" value="<?php if (isset($_POST['tld']['register_price'])) echo $_POST['tld']['register_price'] ?>" />
                    </td>
                    <td>
                        <label>مبلغ فروش تمدید(<?php echo $units ?>)</label>
                    </td>
                    <td>
                        <input type="text" disabled="disabled" value="<?php if (isset($_POST['tld']['renew_price'])) echo $_POST['tld']['renew_price'] ?>" />
                    </td>
                    <td>
                        <label>مبلغ فروش انتقال(<?php echo $units ?>)</label>
                    </td>
                    <td>
                        <input type="text" disabled="disabled" value="<?php if (isset($_POST['tld']['transfer_price'])) echo $_POST['tld']['transfer_price'] ?>" />
                    </td>
                    <td>
                        <label>فعال</label>
                    </td>
                    <td>

                        <input type="checkbox" id="tld_active"
                               name="tld[active]" <?php if (isset($_POST['tld']['active']) && $_POST['tld']['active'] == 1) echo 'checked="checked"' ?>
                               class="checkbox-lg" value="1"/>
                    </td>
                </tr>
            
                <tr>
                    <td colspan="9">
                        <input type="submit" name="tld[submit]" value="ویرایش"/>
                    </td>
                </tr>
            
            </table>
        </form>
    <?php } ?>
</div>
