<div class="dashboard">
	<div>
		<?php
		if (!empty($error)) {
			echo '<div style="color:red;">';
			foreach ($error as $er) {
				echo $er . '<br/>';
			}
			echo '</div>';
		} elseif (isset($suc) && $suc != '') {
			echo '<div style="color:green;">' . $suc . '</div>';
		}

		?>

	</div>
	<div>

        <?php if (empty($error)) { ?>
		<form name="" method="post" action="<?php domainResellerGetBaseUrl('reseller','assign',['resellerId'=>$_GET['resellerId']]) ?>">

			<a href="<?php domainResellerGetBaseUrl('reseller','manage',['resellerId'=>$_GET['resellerId']]) ?>"><?php domainResellerTranslate('tld_manage') ?></a> | <a href="<?php domainResellerGetBaseUrl('reseller','assign',['resellerId'=>$_GET['resellerId']]) ?>"><?php domainResellerTranslate('tld_assign') ?> <?php domainResellerTranslate('new') ?></a>
			<br>
			<input type="submit" name="domain_reseller_management_tld[submit]" value="ثبت" />

			<div class="tablebg">
				<table id="sortabletbl1" class="datatable" width="100%" border="0" cellspacing="1" cellpadding="3">
					<thead>
					<tr>
						<th><input type="checkbox" id="checkAll" value=""></th>
						<th><?php domainResellerTranslate('index') ?></th>
						<th><?php domainResellerTranslate('tld') ?></th>
						<th><?php domainResellerTranslate('register_amount') ?> (<?php domainResellerTranslate($unitsKey) ?>)</th>
						<th><?php domainResellerTranslate('renew_amount') ?> (<?php domainResellerTranslate($unitsKey) ?>)</th>
						<th><?php domainResellerTranslate('redemption_amount') ?> (<?php domainResellerTranslate($unitsKey) ?>)</th>
						<th><?php domainResellerTranslate('transfer_amount') ?> (<?php domainResellerTranslate($unitsKey) ?>)</th>
					</tr>
					</thead>
					<tbody>
					<?php
					foreach($tld as $index=>$t){
						if(isset($oldTld[$t->tld])){
							continue;
						}
						?>
						<tr>
							<td>
								<input type="checkbox" class="chkBox" name="domain_reseller_management_tld[tld][]"  value="<?php echo $t->tld ?>" />
							</td>
							<td>
								<?php echo $index; ?>
							</td>
							<td>
								<?php echo $t->tld ?>
							</td>
							<td>
                                <?php echo ($unitsKey == 'toman') ?  $t->register_price_buy/10 : $t->register_price_buy ?>
							</td>
                            <td>
                                <?php echo ($unitsKey == 'toman') ?  $t->renew_price_buy/10 : $t->renew_price_buy ?>
                            </td>
							<td>
								<?php echo ($unitsKey == 'toman') ?  $t->redemption_price_buy/10 : $t->redemption_price_buy ?>
							</td>
                            <td>
                                <?php echo ($unitsKey == 'toman') ?  $t->transfer_price_buy/10 : $t->transfer_price_buy ?>
                            </td>
                            
						</tr>
					<?php } ?>
					</tbody>
				</table>
				<input type="submit" name="domain_reseller_management_tld[submit]" value="<?php domainResellerTranslate('submit') ?>" />
		</form>
	<?php } ?>
    </div>
</div>

<script type="text/javascript">
	$("#checkAll").change(function () {
		$(".chkBox").prop('checked', $(this).prop("checked"));
	});
</script>