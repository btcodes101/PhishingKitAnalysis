<div class="dashboard">
    <div>
        <?php
        if (!empty($err)) {
            echo '<div style="color:red;">';
            foreach ($err as $er) {
                echo $er . '<br/>';
            }
            echo '</div>';
        } elseif (isset($suc) && $suc != '') {
            echo '<div style="color:green;">' . $suc . '</div>';
        }

        ?>

    </div>
    <?php if ($response->code == 200) { ?>
        <div style="width: 100%">
            <div style="width: 30%; float: right">
                <?php include 'reseller_menu.php'; ?>
            </div>
            <div style="width: 30%; float: right">
                <ul>
                    <li>
                        <?php domainResellerTranslate('reseller_id') ?>
                        : <?php echo$_GET['resellerId']; ?>
                    </li>
                    <li>
                        <?php domainResellerTranslate('name') ?>
                        : <?php echo $response->body->result->name; ?>
                    </li>
                    <li>
                        <?php domainResellerTranslate('email') ?>
                        : <?php echo $response->body->result->email; ?>
                    </li>
                    <li>
                        <?php domainResellerTranslate('service_id') ?>
                        : <?php echo $service_id ?>
                    </li>
                </ul>
            </div>
            <div style="width: 30%; float: right">
                <ul>
                    <li>
                        <?php domainResellerTranslate('status') ?>
                        : <?php echo ($response->body->result->active == 1) ? domainResellerTranslate('active') : domainResellerTranslate('inactive') ; ?>
                    </li>
                    <li>
                        <?php domainResellerTranslate('reseller_balance') ?>
                        : <a href="<?php domainResellerGetBaseUrl('reseller','transaction',['resellerId'=>$_GET['resellerId'],'status'=>'success']) ?>"><?php echo number_format($response->body->result->charge); ?> <?php domainResellerTranslate('rial') ?></a>
                    </li>
                    <li>
                        <?php domainResellerTranslate('reseller_balance_locked') ?>
                        : <a href="<?php domainResellerGetBaseUrl('reseller','transaction',['resellerId'=>$_GET['resellerId'],'status'=>'locked']) ?>"><?php echo number_format($response->body->result->locked); ?> <?php domainResellerTranslate('rial') ?></a>
                    </li>
                    <li>
                        <?php domainResellerTranslate('reseller_subset') ?>
                        : <?php echo count($response->body->result->subset); ?>
                    </li>
                    <li>
                        <?php domainResellerTranslate('reseller_active_domain') ?>
                        : <a href="<?php domainResellerGetBaseUrl('reseller','domains',['resellerId'=>$_GET['resellerId']]) ?>"><?php echo $response->body->result->domain; ?></a>
                    </li>
                </ul>
            </div>
        </div>
    <?php } ?>
</div>
