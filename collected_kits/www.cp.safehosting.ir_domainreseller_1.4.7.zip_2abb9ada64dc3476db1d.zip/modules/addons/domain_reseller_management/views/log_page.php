<link href="<?php echo $moduleParams['baseUrl']; ?>/modules/addons/domain_reseller_management/css/js_persian_cal.css" rel="stylesheet" type="text/css" />
<script src="<?php echo $moduleParams['baseUrl']; ?>/modules/addons/domain_reseller_management/js/js_persian_cal.js" type="text/javascript" ></script>
<?php
require dirname(dirname(__FILE__)) . DIRECTORY_SEPARATOR .'JDateTime.php';
$jdate = new JDateTime(false);
if(isset($msg)){
    echo $msg;
}
?>
<form id="searchesLog" method="get" action="addonmodules.php">
    <input type="hidden" name="module" value="domain_reseller_management" />
    <input type="hidden" name="page" value="logs" />
	<table>
	    <tr>
	        <td>
	            <label><?php domainResellerTranslate('item') ?></label>
	        </td>
	        <td>
	        	<input type="text" name="item" value="<?php if(isset($_GET['item'])) echo  $_GET['item'];  ?>" />
	        </td>
	        <td>
	        	<label><?php domainResellerTranslate('from_date') ?></label>
	        </td>
	        <td>
	        	<input readonly="readonly" type="text" value="<?php if(isset($_GET['g_from'])) echo  $_GET['g_from'];  ?>" class="form-control" name="g_from" id="pcal1">
                <input type="hidden" readonly="readonly" name="from" value="<?php if(isset($_GET['from'])) echo  $_GET['from'];  ?>" id="extra_from">
	        </td>
	        <td>
	        	<label><?php domainResellerTranslate('to_date') ?></label>
	        </td>
	        <td>
	        	<input readonly="readonly" type="text" value="<?php if(isset($_GET['g_to'])) echo  $_GET['g_to'];  ?>" style="" class="form-control" name="g_to" id="pcal2">
               	<input type="hidden" readonly="readonly" value="<?php if(isset($_GET['to'])) echo  $_GET['to'];  ?>" name="to" id="extra_to">
	        </td>
            <td>
                <label><?php domainResellerTranslate('action') ?></label>
            </td>
            <td>
                <select name="action">
                    <option value="all" <?php if(isset($_GET['action']) && $_GET['action'] == 'all') echo  'selected="selected"';  ?>>همه</option>
                    <option value="domain_ns_modify" <?php if(isset($_GET['action']) && $_GET['action'] == 'domain_ns_modify') echo  'selected="selected"';  ?>>domain_ns_modify</option>
                    <option value="domain_register" <?php if(isset($_GET['action']) && $_GET['action'] == 'domain_register') echo  'selected="selected"';  ?>>domain_register</option>
                    <option value="domain_renew" <?php if(isset($_GET['action']) && $_GET['action'] == 'domain_renew') echo  'selected="selected"';  ?>>domain_renew</option>
                    <option value="domain_transferin" <?php if(isset($_GET['action']) && $_GET['action'] == 'domain_tranferin') echo  'selected="selected"';  ?>>domain_tranferin</option>
                    <option value="domain_getepp" <?php if(isset($_GET['action']) && $_GET['action'] == 'domain_getepp') echo  'selected="selected"';  ?>>domain_getepp</option>
                    <option value="domain_child_create" <?php if(isset($_GET['action']) && $_GET['action'] == 'domain_child_create') echo  'selected="selected"';  ?>>domain_child_create</option>
                    <option value="domain_child_modify" <?php if(isset($_GET['action']) && $_GET['action'] == 'domain_child_modify') echo  'selected="selected"';  ?>>domain_child_modify</option>
                    <option value="domain_child_delete" <?php if(isset($_GET['action']) && $_GET['action'] == 'domain_child_delete') echo  'selected="selected"';  ?>>domain_child_delete</option>
                    <option value="domain_owner_change" <?php if(isset($_GET['action']) && $_GET['action'] == 'domain_owner_change') echo  'selected="selected"';  ?>>domain_owner_change</option>
                    <option value="domain_modify" <?php if(isset($_GET['action']) && $_GET['action'] == 'domain_modify') echo  'selected="selected"';  ?>>domain_modify</option>

                    <option value="domain_contact_create" <?php if(isset($_GET['action']) && $_GET['action'] == 'domain_contact_create') echo  'selected="selected"';  ?>>domain_contact_create</option>
                    <option value="domain_dns" <?php if(isset($_GET['action']) && $_GET['action'] == '') echo  'selected="selected"';  ?>>domain_dns</option>
                    <option value="domain_protection_create" <?php if(isset($_GET['action']) && $_GET['action'] == 'domain_dns') echo  'selected="selected"';  ?>>domain_protection_create</option>
                    <option value="domain_protection_cancel" <?php if(isset($_GET['action']) && $_GET['action'] == 'domain_protection_create') echo  'selected="selected"';  ?>>domain_protection_cancel</option>
                    <option value="domain_save_lock" <?php if(isset($_GET['action']) && $_GET['action'] == 'domain_protection_cancel') echo  'selected="selected"';  ?>>domain_save_lock</option>
                    <option value="domain_dns_deactive" <?php if(isset($_GET['action']) && $_GET['action'] == 'domain_save_lock') echo  'selected="selected"';  ?>>domain_dns_deactive</option>
                    <option value="domain_reset_password" <?php if(isset($_GET['action']) && $_GET['action'] == 'domain_dns_deactive') echo  'selected="selected"';  ?>>domain_reset_password</option>

                    <option value="admin_contact_create" <?php if(isset($_GET['action']) && $_GET['action'] == 'admin_contact_create') echo  'selected="selected"';  ?>>admin_contact_create</option>
                    <option value="admin_contact_modify" <?php if(isset($_GET['action']) && $_GET['action'] == 'admin_contact_modify') echo  'selected="selected"';  ?>>admin_contact_modify</option>
                    <option value="admin_contact_delete" <?php if(isset($_GET['action']) && $_GET['action'] == 'admin_contact_delete') echo  'selected="selected"';  ?>>admin_contact_delete</option>
                    <option value="admin_contact_default" <?php if(isset($_GET['action']) && $_GET['action'] == 'admin_contact_default') echo  'selected="selected"';  ?>>admin_contact_default</option>
                    <option value="admin_tld_create" <?php if(isset($_GET['action']) && $_GET['action'] == 'admin_tld_create') echo  'selected="selected"';  ?>>admin_tld_create</option>
                    <option value="admin_tld_modify" <?php if(isset($_GET['action']) && $_GET['action'] == 'admin_tld_modify') echo  'selected="selected"';  ?>>admin_tld_modify</option>
                    <option value="admin_tld_delete" <?php if(isset($_GET['action']) && $_GET['action'] == 'admin_tld_delete') echo  'selected="selected"';  ?>>admin_tld_delete</option>
                    <option value="admin_tld_update" <?php if(isset($_GET['action']) && $_GET['action'] == 'admin_tld_update') echo  'selected="selected"';  ?>>admin_tld_update</option>
                    <option value="admin_reseller_create" <?php if(isset($_GET['action']) && $_GET['action'] == 'admin_reseller_create') echo  'selected="selected"';  ?>>admin_reseller_create</option>
                    <option value="admin_reseller_createapp" <?php if(isset($_GET['action']) && $_GET['action'] == 'admin_reseller_createapp') echo  'selected="selected"';  ?>>admin_reseller_createapp</option>
                    <option value="admin_reseller_createtoken" <?php if(isset($_GET['action']) && $_GET['action'] == 'admin_reseller_createtoken') echo  'selected="selected"';  ?>>admin_reseller_createtoken</option>
                    <option value="admin_reseller_tld_assign" <?php if(isset($_GET['action']) && $_GET['action'] == 'admin_reseller_tld_assign') echo  'selected="selected"';  ?>>admin_reseller_tld_assign</option>
                    <option value="admin_reseller_tld_update" <?php if(isset($_GET['action']) && $_GET['action'] == 'admin_reseller_tld_update') echo  'selected="selected"';  ?>>admin_reseller_tld_update</option>
                    <option value="admin_setting_formula" <?php if(isset($_GET['action']) && $_GET['action'] == 'admin_setting_formula') echo  'selected="selected"';  ?>>admin_setting_formula</option>
                    <option value="admin_setting_token" <?php if(isset($_GET['action']) && $_GET['action'] == 'admin_setting_token') echo  'selected="selected"';  ?>>admin_setting_token</option>
                    <option value="admin_logs_delete" <?php if(isset($_GET['action']) && $_GET['action'] == 'admin_logs_delete') echo  'selected="selected"';  ?>>admin_logs_delete</option>

                    <option value="admin_reseller_protection" <?php if(isset($_GET['action']) && $_GET['action'] == 'admin_reseller_protection') echo  'selected="selected"';  ?>>admin_reseller_protection</option>
                    <option value="admin_reseller_dns" <?php if(isset($_GET['action']) && $_GET['action'] == 'admin_reseller_dns') echo  'selected="selected"';  ?>>admin_reseller_dns</option>
                    <option value="admin_whmcs_update_price" <?php if(isset($_GET['action']) && $_GET['action'] == 'admin_whmcs_update_price') echo  'selected="selected"';  ?>>admin_whmcs_update_price</option>
                    <option value="admin_whmcs_insert_tld" <?php if(isset($_GET['action']) && $_GET['action'] == 'admin_whmcs_insert_tld') echo  'selected="selected"';  ?>>admin_whmcs_insert_tld</option>
                    <option value="admin_whmcs_update_price" <?php if(isset($_GET['action']) && $_GET['action'] == 'admin_whmcs_update_price') echo  'selected="selected"';  ?>>admin_whmcs_update_price</option>
                    <option value="admin_promotion_deactive" <?php if(isset($_GET['action']) && $_GET['action'] == 'admin_promotion_deactive') echo  'selected="selected"';  ?>>admin_promotion_deactive</option>
                    <option value="admin_reseller_tld_modify" <?php if(isset($_GET['action']) && $_GET['action'] == 'admin_reseller_tld_modify') echo  'selected="selected"';  ?>>admin_reseller_tld_modify</option>
                    <option value="admin_setting_contact" <?php if(isset($_GET['action']) && $_GET['action'] == 'admin_setting_contact') echo  'selected="selected"';  ?>>admin_setting_contact</option>


                    <option value="cron" <?php if(isset($_GET['action']) && $_GET['action'] == 'cron') echo  'selected="selected"';  ?>>cron</option>
                    <option value="cron_promotion" <?php if(isset($_GET['action']) && $_GET['action'] == 'cron_promotion') echo  'selected="selected"';  ?>>cron_promotion</option>
                    <option value="cron_transfer_out" <?php if(isset($_GET['action']) && $_GET['action'] == 'cron_transfer_out') echo  'selected="selected"';  ?>>cron_transfer_out</option>
                    <option value="cron_email_unverified" <?php if(isset($_GET['action']) && $_GET['action'] == 'cron_email_unverified') echo  'selected="selected"';  ?>>cron_email_unverified</option>

                    <option value="module_reseller_email" <?php if(isset($_GET['action']) && $_GET['action'] == 'module_reseller_email') echo  'selected="selected"';  ?>>module_reseller_email</option>
                    <option value="module_reseller_charge" <?php if(isset($_GET['action']) && $_GET['action'] == 'module_reseller_charge') echo  'selected="selected"';  ?>>module_reseller_charge</option>
                    <option value="module_reseller_discount" <?php if(isset($_GET['action']) && $_GET['action'] == 'module_reseller_discount') echo  'selected="selected"';  ?>>module_reseller_discount</option>
                    <option value="email_unverified" <?php if(isset($_GET['action']) && $_GET['action'] == 'email_unverified') echo  'selected="selected"';  ?>>email_unverified</option>
                </select>
            </td>
	        <td>
	        	<label><?php domainResellerTranslate('status') ?></label>
	        </td>
	        <td>
		        <select name="status">
		        	<option value="all" <?php if(isset($_GET['status']) && $_GET['status'] == 'all') echo  'selected="selected"';  ?>><?php domainResellerTranslate('all') ?></option>
                    <option value="pending" <?php if(isset($_GET['status']) && $_GET['status'] == 'pending') echo  'selected="selected"';  ?>><?php domainResellerTranslate('pending') ?></option>
		        	<option value="success" <?php if(isset($_GET['status']) && $_GET['status'] == 'success') echo  'selected="selected"';  ?>><?php domainResellerTranslate('success') ?></option>
		        	<option value="failed" <?php if(isset($_GET['status']) && $_GET['status'] == 'failed') echo  'selected="selected"';  ?>><?php domainResellerTranslate('failed') ?></option>
		        </select>
	        </td>
            <td>
                <input type="checkbox" <?php if(isset($_GET['prologs'])) echo  'checked="checked"';  ?> name="prologs" value="1"><?php domainResellerTranslate('display') ?> <?php domainResellerTranslate('all') ?> <?php domainResellerTranslate('log') ?>
            </td>
	        <td>
	        	<input type="submit" name="search" value="<?php domainResellerTranslate('search') ?>" class="btn btn-xs btn-default" />
	        </td>
	    </tr>
	</table>
</form>

<form id="removeLog" method="post" action="">

    <fieldset>
        <legend><?php domainResellerTranslate('delete')?> <?php domainResellerTranslate('log') ?></legend>
        <table>
            <tr>
                <td>
                    <input readonly="readonly" type="text" value="<?php if(isset($_GET['r_from'])) echo  $_GET['r_from'];  ?>" class="form-control" style="width: 200px;" name="r_from" id="pcal3">
                    <input type="hidden" readonly="readonly" name="rfrom" value="<?php if(isset($_GET['rfrom'])) echo  $_GET['rfrom'];  ?>" id="rextra_from">
                </td>
                </tr>

                <tr>
                <td>
                    <input type="submit" name="removeSubmit" value="<?php domainResellerTranslate('delete') ?>" class="btn btn-xs btn-default" />
                </td>
            </tr>
        </table>


    </fieldset>
</form>
<script type="text/javascript">
  var objCal1 = new AMIB.persianCalendar( 'pcal1',{ extraInputID: "extra_from", extraInputFormat: "YYYY-MM-DD" });
  var objCal2 = new AMIB.persianCalendar( 'pcal2',{ extraInputID: "extra_to", extraInputFormat: "YYYY-MM-DD" });
  var objCal3 = new AMIB.persianCalendar( 'pcal3',{ extraInputID: "rextra_from", extraInputFormat: "YYYY-MM-DD" });
</script>
<table>
	<tr>
		<td>
			<form id="pages" method="post" action="">
                <select name="page" onchange="submit()">
                    <?php for ($i = 1;$i <= $totalPages ; $i++) {?>
                    <option value="<?= $i ?>"  <?php if($i == $page) {?> selected="" <?php }?>><?= $i ?></option>
                    <?php }?>
                </select> <input type="submit" name="filter" value="<?php domainResellerTranslate('display') ?>" class="btn btn-xs btn-default">
	        </form>
        </td>
    </tr>
</table>
<table class="datatable" width="100%" border="0" cellspacing="1" cellpadding="3">

    <tr>
        <th><?php domainResellerTranslate('index') ?></th>
        <th><?php domainResellerTranslate('item') ?></th>
        <th><?php domainResellerTranslate('action') ?></th>
        <th><?php domainResellerTranslate('status') ?></th>
        <th>processing-id</th>
        <th><?php domainResellerTranslate('date') ?></th>
        <th><?php domainResellerTranslate('admin_id') ?></th>
        <th><?php domainResellerTranslate('user_id') ?></th>
        <th><?php domainResellerTranslate('request') ?></th>
        <th><?php domainResellerTranslate('result') ?></th>
    </tr>

    <?php
    $index = 1;
    foreach ($logs as $log): ?>
        <?php
       
        $item = $log->item;
        $request =json_decode(trim($log->request),true);
        if(strpos($log->action,'domain') !== false){
            if(isset($request['domainid'])){
                $item = "<a href='clientsdomains.php?userid={$log->userid}&id={$request['domainid']}'>{$log->item}</a>";
            }else {
                $item = '<form target="_blank" action="clientsdomainlist.php" method="post"><input type="hidden" name="domain" value="' . $log->item . '"><input type="submit" value="' . $log->item . '" class="btn btn-default"></form>';
            }
        }elseif(strpos($log->action,'contact') !== false){
            $url = $_SERVER['PHP_SELF'].'?module='.$_GET['module'].'&page=contact&op=modify&handle='.$log->item;
            $item = '<a href="'.$url.'">'.$log->item.'</a>';
        }
        ?>

        <tr>
            <td> <?php echo $index++ ?></td>
            <td> <?php echo $item ?></td>
            <td> <?php echo $log->action ?></td>

            <td> <?php echo $log->status ?></td>
            <td> <?php echo $log->procid ?></td>
            <td> <?php echo $jdate->date('Y-m-d H:i',strtotime($log->created_at)) ?></td>
            <td><a target="_blank" href="configadmins.php?action=manage&id=<?php echo $log->adminid ?>"><?php echo $log->adminid ?></a></td>
            <td><a target="_blank" href="clientssummary.php?userid=<?php echo $log->userid ?>"> <?php echo $log->userid ?></a></td>
            <td>
                <div style="display: none;" id="rq<?php echo $log->id ?>">
                    <pre>
                        <?php

                            if(isset($request['requestTime'])){
                                $request['requestTime'] = $jdate->date('Y-m-d H:i:s',$request['requestTime']);
                                $request['responseTime'] = $jdate->date('Y-m-d H:i:s',$request['responseTime']);
                            }
                            print_r($request);
                        ?>
                    </pre>
                </div>
                <button onclick="show_page('rq<?php echo $log->id ?>')"><?php domainResellerTranslate('display') ?></button>
            </td>
            <td>
                <?php
                $result = json_decode($log->result,true);
                if(!$result) {
                    $result = $log->result;
                }
                if(!empty($result)){
                ?>
                <div style="display: none;" id="rs<?php echo $log->id ?>">
                    <?php
                    
                    if(!empty($result)) {
                        if(isset($result['cron']) && !empty($result['cron'])){
                            echo 'Update Result: <ul>';
                            joker_renderResult($result['cron']);
                            echo '</ul><hr/>';
                        }

                        if(isset($result['trace']) && !empty($result['trace'])){
                            echo 'Update Result:';
                            joker_renderTrace($result['trace']);
                            echo '<hr/>';
                        }

                        echo '<ul>';
                        joker_renderResult($result);
                        echo '</ul>';
                    }
                    ?>
                </div>
                
                <button onclick="show_page('rs<?php echo $log->id ?>')"><?php domainResellerTranslate('display') ?></button>
                <?php } ?>
            </td>
        </tr>
    <?php endforeach; ?>
</table>

<script type="text/javascript">
    function show_page(id) {
        win = window.open('', 'data', "scrollbars=1,width=600,height=400");
        win.document.write('');
        win.document.write($('#' +id).html());
    }
</script>

<?php 
function joker_renderResult($result){
    
    $jdate = new JDateTime(false);
    if(isset($result['status'])) {
        if ($result['status'] == 'failed') {
            echo '<li>Status: failed</li>';
            echo "<li>Result Code: {$result['error']}</li>";
            echo "<li>Internal Tracking: {$result['internalTracking']}</li>";

            if (isset($result['deliveryTime'])) {
                //$d = new DateTime($result['deliveryTime']);
                //echo "<li>Delivery Time : ".$jdate->date('c',$d->getTimestamp(),false,true,$d->getTimezone())."</li>";
                echo "<li>Delivery Time : " . $result['deliveryTime'] . "</li>";
            } elseif (isset($result['resultTime'])) {
                //$d = new DateTime($result['resultTime']);
                //echo "<li>Result Time: ".$jdate->date('c',$d->getTimestamp(),false,true,$d->getTimezone())."</li>";
                echo "<li>Result Time : " . $result['resultTime'] . "</li>";
            }
            if (is_array($result['errorDetails'])) {
                $result['errorDetails'] = implode(',', $result['errorDetails']);
            }
            $result['errorDetails'] = str_replace('<', '', $result['errorDetails']);
            echo "<li>Result Details: {$result['errorDetails']}</li>";
            if (is_array($result['extraDetails'])) {
                echo '<li>ExtraDetails: <ul>';
                foreach ($result['extraDetails'] as $k => $v) {
                    echo "<li>$k : $v</li>";
                }
                echo '</ul></li>';
            } else {
                echo "<li>Extra Details: {$result['extraDetails']}</li>";
            }

        } else {

            echo '<li>Status: ' . $result['status'] . '</li>';
            echo '<li>Result Code: ' . $result['error'] . '</li>';
            if ($result['internalTracking'] != '') {
                echo "<li>Internal Tracking: {$result['internalTracking']}</li>";
            }
            if (isset($result['deliveryTime'])) {
                //$d = new DateTime($result['deliveryTime']);
                //echo "<li>Delivery Time : ".$jdate->date('c',$d->getTimestamp(),false,true,$d->getTimezone())."</li>";
                echo "<li>Delivery Time : " . $result['deliveryTime'] . "</li>";
            } elseif (isset($result['resultTime'])) {
                //$d = new DateTime($result['resultTime']);
                //echo "<li>Result Time: ".$jdate->date('c',$d->getTimestamp(),false,true,$d->getTimezone())."</li>";
                echo "<li>Result Time : " . $result['resultTime'] . "</li>";
            }

            if (is_array($result['result'])) {
                echo '<li>Result Details: <ul>';
                foreach ($result['result'] as $k => $v) {
                    echo "<li>$k : $v</li>";
                }
                echo '</ul></li>';
            } else {
                echo "<li>Result Details: {$result['result']}</li>";
            }

            if (is_array($result['extraDetails'])) {
                echo '<ul>Extra Details:';
                foreach ($result['extraDetails'] as $k => $v) {
                    echo "<li>$k : $v</li>";
                }
                echo '</ul>';
            } else {
                echo "<li>Extra Details: {$result['extraDetails']}</li>";
            }
        }
    }else{
        echo "<pre>$result</pre>";
    }
}


function joker_renderTrace($trace){
    if(is_string($trace)){
        $trace = json_decode($trace,true);
    }

    echo '<ul>';
    foreach ($trace as $item) {
        echo '<li><h3>at '.$item['time'].' - status: '.$item['status'].'</h3>';
        echo '<div>result: '.nl2br($item['msg']).'</div>';
        echo '</li>';
        echo '<hr/>';
    }
    echo '</ul>';

}

?>