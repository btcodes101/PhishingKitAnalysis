<?php if(isset($protectionPrice) && $protectionPrice['status'] != -2){ ?>
	<div class="protection setting">

		<?php
		if($protectionPrice['status'] == 2){
			domainResellerTranslate('setting_protection_disabled');
		}else{
			?>

			<form method="post" action="<?php domainResellerGetBaseUrl('domaintld','lists') ?>">
				<div>
					<label>
						<input type="checkbox" onclick="showDiv(this,'protectionCheckHide')" name="protection[status]" <?php if ($protectionPrice['status'] == 1) echo 'checked'; ?> value="1"><?php domainResellerTranslate('setting_protection_enable') ?>
					</label>
				</div>
				<div class="protectionCheckHide" <?php if ($protectionPrice['status'] != 1) echo 'style="display: none"'; ?>>
					<div>
						<label><?php domainResellerTranslate('amount') ?> <?php domainResellerTranslate('amount_buy') ?>: <?= $unitsKey=="toman" ? $protectionPrice['buy']/10 : $protectionPrice['buy'] ?> <?php domainResellerTranslate($unitsKey) ?></label>
					</div>
					<div>
						<label>
							<?php domainResellerTranslate('amount') ?> <?php domainResellerTranslate('amount_sell') ?>:
							<input type="text" name="protection[price]" value="<?= $unitsKey=="toman" ? $protectionPrice['sell']/10 : $protectionPrice['sell'] ?>" /> <?php domainResellerTranslate($unitsKey) ?>
						</label>
					</div>
				</div>

				<input type="submit" name="protectionSubmit" value="<?php domainResellerTranslate('submit') ?>"/>
			</form>
		<?php } ?>
	</div>
<?php } ?>

<?php if(isset($dnsPrice) && $dnsPrice['status'] != -2){ ?>
	<div class="protection setting">

		<?php
		if($dnsPrice['status'] == 2){
			domainResellerTranslate('setting_dns_disabled');
		}else{
			?>

			<form method="post" action="<?php domainResellerGetBaseUrl('domaintld','lists') ?>">
				<div>
					<label>
						<input type="checkbox" onclick="showDiv(this,'dnsCheckHide')" name="dns[status]" <?php if ($dnsPrice['status'] == 1) echo 'checked'; ?> value="1"><?php domainResellerTranslate('setting_dns_enable') ?>
					</label>
				</div>
				<div class="dnsCheckHide" <?php if ($dnsPrice['status'] != 1) echo 'style="display: none"'; ?>>
					<div>
						<label><?php domainResellerTranslate('amount') ?> <?php domainResellerTranslate('amount_buy') ?>: <?= $unitsKey=="toman" ? $dnsPrice['buy']/10 : $dnsPrice['buy'] ?> <?php domainResellerTranslate($unitsKey) ?></label>
					</div>
					<div>
						<label>
							<?php domainResellerTranslate('amount') ?> <?php domainResellerTranslate('amount_sell') ?>:
							<input type="text" name="dns[price]" value="<?= $unitsKey=="toman" ? $dnsPrice['sell']/10 : $dnsPrice['sell'] ?>" /> <?php domainResellerTranslate($unitsKey) ?>
						</label>
					</div>
				</div>

				<input type="submit" name="dnsSubmit" value="<?php domainResellerTranslate('submit') ?>"/>
			</form>
		<?php } ?>
	</div>
<?php } ?>

<div class="tld">
	<a target="_blank" href="<?php echo $moduleParams['baseUrl'] ?>/modules/addons/domain_reseller_management/getTldList.php"><?php domainResellerTranslate('tld_get_list') ?></a>
	<div class="search">
		<form method="post" action="<?php domainResellerGetBaseUrl('domaintld','lists') ?>" >
			<input type="text" placeholder="Part of Tld" name="domain_reseller_management_tld[tld]" value="<?php if(isset($_POST['domain_reseller_management_tld']['tld'])) echo $_POST['domain_reseller_management_tld']['tld'] ?>" class="search" />
			<input type="submit" name="domain_reseller_management_tld[submit]" value="<?php domainResellerTranslate('search') ?>" />
		</form>
	</div>
	<?php if($response->code != 200){
		echo isset($response->body->errorDetails) ? $response->body->errorDetails : 'server_error';
	}else{ ?>
	<div class="tld_list">
		<form name="" method="post" action="<?php domainResellerGetBaseUrl('domaintld','lists') ?>">
			<label><?php domainResellerTranslate('tld_profit') ?></label><input type="text" name="profit" value="" />
			<input type="submit" name="submit" value="<?php domainResellerTranslate('update') ?>" />
		</form>

		<form name="" method="post" action="<?php domainResellerGetBaseUrl('domaintld','lists') ?>">
			<input type="submit" name="syncTld" value="<?php domainResellerTranslate('tld_whmcs_sync') ?>" />
		</form>

		<div class="tablebg">
			<table id="sortabletbl1" class="datatable" width="100%" border="0" cellspacing="1" cellpadding="3">
				<tbody>
					<tr>
						<th><?php domainResellerTranslate('item') ?></th>
						<th><?php domainResellerTranslate('tld') ?></th>
						<th><?php domainResellerTranslate('register_amount') ?> (<?php domainResellerTranslate($unitsKey) ?>)</th>
						<th><?php domainResellerTranslate('renew_amount') ?> (<?php domainResellerTranslate($unitsKey) ?>)</th>
						<th><?php domainResellerTranslate('redemption_amount') ?> (<?php domainResellerTranslate($unitsKey) ?>)</th>
						<th><?php domainResellerTranslate('transfer_amount') ?> (<?php domainResellerTranslate($unitsKey) ?>)</th>
						<th><?php domainResellerTranslate('status') ?></th>
						<th><?php domainResellerTranslate('operation') ?></th>
					</tr>
					
						<?php if(empty($response->body->result->tld)){ ?>
							<tr><td colspan="10"><?php domainResellerTranslate('not_found_record') ?></td></tr>
						<?php }else{ 
							
							foreach ($response->body->result->tld as $i=>$t) {
								echo '<tr><td>'.($i+1).'</td>';
								echo "<td>{$t->tld}</td>";
								if($unitsKey =='toman'){
									echo "<td>".($t->register_price/10)."</td>";
									echo "<td>".($t->renew_price/10)."</td>";
									echo "<td>".($t->redemption_price/10)."</td>";
									echo "<td>".($t->transfer_price/10)."</td>";	
								}else{
									echo "<td>{$t->register_price}</td>";
									echo "<td>{$t->renew_price}</td>";
									echo "<td>{$t->redemption_price}</td>";
									echo "<td>{$t->transfer_price}</td>";
								}
								if($t->active == 0){
									echo "<td>".domainResellerTranslate('inactive',false)."</td>";
								}else{
									echo "<td>".domainResellerTranslate('active',false)."</td>";
								}
								echo '<td><a href="'.domainResellerGetBaseUrl('domaintld','update',['tld'=>$t->tld],false).'">'.domainResellerTranslate('edit',false).'</a></td>';
								echo '</tr>';
							}
						}
						?>
					
				</tbody>
			</table>
		</div>
	</div>
	<?php } ?>
</div>

<script type="application/javascript">
	function deleteConfirm(hand){

		var conf = confirm("آیا از حذف پسوند "+hand+" اطمینان دارید؟");
		if(!conf){
			return false;
		}else {
			return true;
		}
	}
	function showDiv(el, item) {

		if ($(el).is(':checked')) {
			$('.' + item).show();
		} else {
			$('.' + item).hide();
		}
	}

</script>