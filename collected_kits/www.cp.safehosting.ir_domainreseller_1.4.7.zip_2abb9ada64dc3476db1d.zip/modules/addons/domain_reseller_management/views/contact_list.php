<div class="contact">
	<div><a href="<?php echo $_SERVER['PHP_SELF'].'?module='.$_GET['module'] ?>&page=contact&op=create" class="create"><?php domainResellerTranslate('create') ?></a></div>
	<div class="search">
		<form method="post" action="<?php echo $_SERVER['PHP_SELF'].'?module='.$_GET['module'] ?>&page=contact&op=lists" >
			<select class="search" name="domain_reseller_management_contact[tld]">
                <option value="all"><?php domainResellerTranslate('tld') ?></option>
				<?php foreach ($tldList as $tld) {
					if($tld->active != 0){
						if(isset($_POST['domain_reseller_management_contact']['tld']) && $_POST['domain_reseller_management_contact']['tld'] == $tld){
							echo "<option value='{$tld->tld}' selected='selected'>{$tld->tld}</option>";
						}else{
							echo "<option value='{$tld->tld}'>{$tld->tld}</option>";
						}

					}
				} ?>
			</select>
			<input type="text" placeholder="Part of Handle" name="domain_reseller_management_contact[handle]" value="<?php if(isset($_POST['domain_reseller_management_contact']['handle'])) echo $_POST['domain_reseller_management_contact']['handle'] ?>" class="search" />
			<input type="checkbox" name="domain_reseller_management_contact[defaults]" <?php if(isset($_POST['domain_reseller_management_contact']['defaults'])) echo 'checked="checked"' ?> value="1" /><?php domainResellerTranslate('default') ?>
			<input type="submit" name="domain_reseller_management_contact[submit]" value="<?php domainResellerTranslate('search') ?>" />
		</form>
	</div>
	<?php if($response->code != 200){
		echo '<div>'.$response->body->errorDetails.'</div>';
	}else{ ?>
	<div class="contact_list">
		<div class="tablebg">
			<table id="sortabletbl1" class="datatable" width="100%" border="0" cellspacing="1" cellpadding="3">
				<tbody>
					<tr>
						<th><?php domainResellerTranslate('index') ?></th>
						<th><?php domainResellerTranslate('tld') ?></th>
						<th><?php domainResellerTranslate('contact_handle') ?></th>
						<th><?php domainResellerTranslate('default') ?></th>
						<th><?php domainResellerTranslate('status') ?></th>
						<th><?php domainResellerTranslate('operation') ?></th>
					</tr>

						<?php if(empty($response->body->result)){ ?>
							<td colspan="5"><?php domainResellerTranslate('not_found_record') ?></td>
						<?php }else{ 
							$url = $_SERVER['PHP_SELF'].'?module='.$_GET['module'].'&page=contact&op=';
							foreach ($response->body->result as $i=>$c) {

								echo '<tr><td>'.($i+1).'</td>';
								echo "<td>{$c->tld}</td>";
								echo (is_numeric($c->handle)) ? '<td> - </td>' : "<td>{$c->handle}</td>";
								echo ($c->defaults == 1) ? '<td>'.domainResellerTranslate('yes',false).'</td>' : "<td>". domainResellerTranslate('no',false)."</td>";
								echo ($c->active == 1) ? "<td>".domainResellerTranslate('active',false)."</td>" : "<td>". domainResellerTranslate('inactive',false)."</td>";
								echo '<td>';
                                if($c->active != 0){
                                    echo "<a href='{$url}modify&handle={$c->handle}'>".domainResellerTranslate('edit',false)."</a> | ";
                                }
                                if($c->default != 1){
									echo "<a href='{$url}defaults&handle={$c->handle}&tld={$c->tld}'>". domainResellerTranslate('default',false) ."</a> | ";
                                    echo "<a onclick='return deleteConfirm(\"{$c->handle}\");' href='{$url}delete&handle={$c->handle}&tld={$c->tld}'>".domainResellerTranslate('delete',false)."</a> ";
								}

								echo '</td></tr>';
							}
						}
						?>

				</tbody>
			</table>
		</div>
	</div>
	<?php } ?>
</div>

<script type="application/javascript">
	function deleteConfirm(hand){

		var conf = confirm("<?php domainResellerTranslate('delete_confirm') ?> "+hand);
		if(!conf){
			return false;
		}else {
			return true;
		}
	}
</script>