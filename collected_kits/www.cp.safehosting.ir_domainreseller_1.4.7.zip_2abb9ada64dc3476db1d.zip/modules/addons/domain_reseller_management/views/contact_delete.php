<div class="contact">
	<div>
		<?php 
			if(!empty($error)){
				echo '<div style="color:red;">';
				foreach ($error as $er) {
					echo $er.'<br/>';
				}
				echo '</div>';
			}elseif($suc != ''){
				echo '<div style="color:green;">'.$suc.'</div>';
			}

		?>

	</div>
</div>