<div class="contact">
    <h3> ویرایش<b><?php echo $_GET['handle']; ?></b></h3>
    <div>
        <?php
        if (!empty($error)) {
            echo '<div style="color:red;">';
            foreach ($error as $er) {
                echo $er . '<br/>';
            }
            echo '</div>';
        } elseif (isset($suc) && $suc != '') {
            echo '<div style="color:green;">' . $suc . '</div>';
        }

        ?>

    </div>
    <?php if (!isset($_POST['contact']['submit']) && $response->code == 200) { ?>
        <form name="" method="post" action="<?php domainResellerGetBaseUrl('contact','modify',['handle'=>$_GET['handle']]) ?>">
            <table style="width: 100%;">
                <tr>
                    <td>
                        <label><?php domainResellerTranslate('organization') ?></label>
                    </td>
                    <td>
                        <input type="text" id="contact_organization" name="contact[organization]"
                               value="<?php if (isset($_POST['contact']['organization'])) echo $_POST['contact']['organization'] ?>"
                               required="required"/>
                    </td>
                    <td>
                        <label><?php domainResellerTranslate('name') ?></label>
                    </td>
                    <td>
                        <input type="text" id="contact_name" name="contact[name]"
                               value="<?php if (isset($_POST['contact']['name'])) echo $_POST['contact']['name'] ?>"
                               required="required"/>
                    </td>
                    <td>
                        <label><?php domainResellerTranslate('address') ?> 1</label>
                    </td>
                    <td>
                        <input type="text" id="contact_address1" name="contact[address_1]"
                               value="<?php if (isset($_POST['contact']['address_1'])) echo $_POST['contact']['address_1'] ?>"
                               required="required"/>
                    </td>
                </tr>
                <tr>

                    <td>
                        <label><?php domainResellerTranslate('address') ?> 2</label>
                    </td>
                    <td>
                        <input type="text" id="contact_address2" name="contact[address_2]"
                               value="<?php if (isset($_POST['contact']['address_2'])) echo $_POST['contact']['address_2'] ?>"/>
                    </td>
                    <td>

                        <label><?php domainResellerTranslate('postal_code') ?></label>
                    </td>
                    <td>
                        <input type="text" id="contact_postalCode" name="contact[postal_code]"
                               value="<?php if (isset($_POST['contact']['postal_code'])) echo $_POST['contact']['postal_code'] ?>"
                               required="required"/>
                    </td>
                    <td>
                        <label><?php domainResellerTranslate('email') ?></label>
                    </td>
                    <td>
                        <input type="email" id="contact_email" name="contact[email]"
                               value="<?php if (isset($_POST['contact']['email'])) echo $_POST['contact']['email'] ?>"
                               required="required"/>
                    </td>
                </tr>
                <tr>
                    <td>
                        <label><?php domainResellerTranslate('phone') ?></label>
                    </td>
                    <td>
                        <input type="tel" id="contact_phone" name="contact[phone]"
                               value="<?php if (isset($_POST['contact']['phone'])) echo $_POST['contact']['phone'] ?>"
                               required="required"/>
                    </td>
                    <td>
                        <label><?php domainResellerTranslate('fax') ?></label>
                    </td>
                    <td>
                        <input type="text" id="contact_fax" name="contact[fax]"
                               value="<?php if (isset($_POST['contact']['fax'])) echo $_POST['contact']['fax'] ?>"/>
                    </td>
                    <td>

                        <label><?php domainResellerTranslate('city') ?></label>
                    </td>
                    <td>
                        <input type="text" id="contact_city" name="contact[city]"
                               value="<?php if (isset($_POST['contact']['city'])) echo $_POST['contact']['city'] ?>"
                               required="required"/>
                    </td>

                </tr>
                <tr>
                    <td>
                        <label><?php domainResellerTranslate('country') ?></label>
                    </td>
                    <td>

                        <select id="contact_country" name="contact[country]">

                            <option value="AF" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'AF') echo 'selected="selected"' ?> >Afghanistan</option>
                            <option value="AX" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'AX') echo 'selected="selected"' ?> >Åland Islands</option>
                            <option value="AL" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'AL') echo 'selected="selected"' ?> >Albania</option>
                            <option value="DZ" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'DZ') echo 'selected="selected"' ?> >Algeria</option>
                            <option value="AS" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'AS') echo 'selected="selected"' ?> >American Samoa</option>
                            <option value="AD" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'AD') echo 'selected="selected"' ?> >Andorra</option>
                            <option value="AO" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'AO') echo 'selected="selected"' ?> >Angola</option>
                            <option value="AI" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'AI') echo 'selected="selected"' ?> >Anguilla</option>
                            <option value="AQ" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'AQ') echo 'selected="selected"' ?> >Antarctica</option>
                            <option value="AG" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'AG') echo 'selected="selected"' ?> >Antigua &amp; Barbuda</option>
                            <option value="AR" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'AR') echo 'selected="selected"' ?> >Argentina</option>
                            <option value="AM" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'AM') echo 'selected="selected"' ?> >Armenia</option>
                            <option value="AW" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'AW') echo 'selected="selected"' ?> >Aruba</option>
                            <option value="AC" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'AC') echo 'selected="selected"' ?> >Ascension Island</option>
                            <option value="AU" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'AU') echo 'selected="selected"' ?> >Australia</option>
                            <option value="AT" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'AT') echo 'selected="selected"' ?> >Austria</option>
                            <option value="AZ" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'AZ') echo 'selected="selected"' ?> >Azerbaijan</option>
                            <option value="BS" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'BS') echo 'selected="selected"' ?> >Bahamas</option>
                            <option value="BH" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'BH') echo 'selected="selected"' ?> >Bahrain</option>
                            <option value="BD" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'BD') echo 'selected="selected"' ?> >Bangladesh</option>
                            <option value="BB" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'BB') echo 'selected="selected"' ?> >Barbados</option>
                            <option value="BY" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'BY') echo 'selected="selected"' ?> >Belarus</option>
                            <option value="BE" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'BE') echo 'selected="selected"' ?> >Belgium</option>
                            <option value="BZ" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'BZ') echo 'selected="selected"' ?> >Belize</option>
                            <option value="BJ" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'BJ') echo 'selected="selected"' ?> >Benin</option>
                            <option value="BM" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'BM') echo 'selected="selected"' ?> >Bermuda</option>
                            <option value="BT" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'BT') echo 'selected="selected"' ?> >Bhutan</option>
                            <option value="BO" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'BO') echo 'selected="selected"' ?> >Bolivia</option>
                            <option value="BA" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'BA') echo 'selected="selected"' ?> >Bosnia &amp; Herzegovina</option>
                            <option value="BW" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'BW') echo 'selected="selected"' ?> >Botswana</option>
                            <option value="BR" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'BR') echo 'selected="selected"' ?> >Brazil</option>
                            <option value="IO" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'IO') echo 'selected="selected"' ?> >British Indian Ocean Territory</option>
                            <option value="VG" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'VG') echo 'selected="selected"' ?> >British Virgin Islands</option>
                            <option value="BN" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'BN') echo 'selected="selected"' ?> >Brunei</option>
                            <option value="BG" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'BG') echo 'selected="selected"' ?> >Bulgaria</option>
                            <option value="BF" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'BF') echo 'selected="selected"' ?> >Burkina Faso</option>
                            <option value="BI" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'BI') echo 'selected="selected"' ?> >Burundi</option>
                            <option value="KH" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'KH') echo 'selected="selected"' ?> >Cambodia</option>
                            <option value="CM" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'CM') echo 'selected="selected"' ?> >Cameroon</option>
                            <option value="CA" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'CA') echo 'selected="selected"' ?> >Canada</option>
                            <option value="IC" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'IC') echo 'selected="selected"' ?> >Canary Islands</option>
                            <option value="CV" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'CV') echo 'selected="selected"' ?> >Cape Verde</option>
                            <option value="BQ" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'BQ') echo 'selected="selected"' ?> >Caribbean Netherlands</option>
                            <option value="KY" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'KY') echo 'selected="selected"' ?> >Cayman Islands</option>
                            <option value="CF" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'CF') echo 'selected="selected"' ?> >Central African Republic</option>
                            <option value="EA" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'EA') echo 'selected="selected"' ?> >Ceuta &amp; Melilla</option>
                            <option value="TD" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'TD') echo 'selected="selected"' ?> >Chad</option>
                            <option value="CL" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'CL') echo 'selected="selected"' ?> >Chile</option>
                            <option value="CN" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'CN') echo 'selected="selected"' ?> >China</option>
                            <option value="CX" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'CX') echo 'selected="selected"' ?> >Christmas Island</option>
                            <option value="CC" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'CC') echo 'selected="selected"' ?> >Cocos (Keeling) Islands</option>
                            <option value="CO" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'CO') echo 'selected="selected"' ?> >Colombia</option>
                            <option value="KM" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'KM') echo 'selected="selected"' ?> >Comoros</option>
                            <option value="CG" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'CG') echo 'selected="selected"' ?> >Congo - Brazzaville</option>
                            <option value="CD" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'CD') echo 'selected="selected"' ?> >Congo - Kinshasa</option>
                            <option value="CK" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'CK') echo 'selected="selected"' ?> >Cook Islands</option>
                            <option value="CR" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'CR') echo 'selected="selected"' ?> >Costa Rica</option>
                            <option value="CI" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'CI') echo 'selected="selected"' ?> >Côte d’Ivoire</option>
                            <option value="HR" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'HR') echo 'selected="selected"' ?> >Croatia</option>
                            <option value="CU" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'CU') echo 'selected="selected"' ?> >Cuba</option>
                            <option value="CW" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'CW') echo 'selected="selected"' ?> >Curaçao</option>
                            <option value="CY" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'CY') echo 'selected="selected"' ?> >Cyprus</option>
                            <option value="CZ" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'CZ') echo 'selected="selected"' ?> >Czech Republic</option>
                            <option value="DK" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'DK') echo 'selected="selected"' ?> >Denmark</option>
                            <option value="DG" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'DG') echo 'selected="selected"' ?> >Diego Garcia</option>
                            <option value="DJ" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'DJ') echo 'selected="selected"' ?> >Djibouti</option>
                            <option value="DM" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'DM') echo 'selected="selected"' ?> >Dominica</option>
                            <option value="DO" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'DO') echo 'selected="selected"' ?> >Dominican Republic</option>
                            <option value="EC" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'EC') echo 'selected="selected"' ?> >Ecuador</option>
                            <option value="EG" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'EG') echo 'selected="selected"' ?> >Egypt</option>
                            <option value="SV" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'SV') echo 'selected="selected"' ?> >El Salvador</option>
                            <option value="GQ" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'GQ') echo 'selected="selected"' ?> >Equatorial Guinea</option>
                            <option value="ER" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'ER') echo 'selected="selected"' ?> >Eritrea</option>
                            <option value="EE" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'EE') echo 'selected="selected"' ?> >Estonia</option>
                            <option value="ET" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'ET') echo 'selected="selected"' ?> >Ethiopia</option>
                            <option value="FK" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'FK') echo 'selected="selected"' ?> >Falkland Islands</option>
                            <option value="FO" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'FO') echo 'selected="selected"' ?> >Faroe Islands</option>
                            <option value="FJ" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'FJ') echo 'selected="selected"' ?> >Fiji</option>
                            <option value="FI" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'FI') echo 'selected="selected"' ?> >Finland</option>
                            <option value="FR" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'FR') echo 'selected="selected"' ?> >France</option>
                            <option value="GF" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'GF') echo 'selected="selected"' ?> >French Guiana</option>
                            <option value="PF" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'PF') echo 'selected="selected"' ?> >French Polynesia</option>
                            <option value="TF" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'TF') echo 'selected="selected"' ?> >French Southern Territories</option>
                            <option value="GA" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'GA') echo 'selected="selected"' ?> >Gabon</option>
                            <option value="GM" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'GM') echo 'selected="selected"' ?> >Gambia</option>
                            <option value="GE" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'GE') echo 'selected="selected"' ?> >Georgia</option>
                            <option value="DE" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'DE') echo 'selected="selected"' ?> >Germany</option>
                            <option value="GH" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'GH') echo 'selected="selected"' ?> >Ghana</option>
                            <option value="GI" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'GI') echo 'selected="selected"' ?> >Gibraltar</option>
                            <option value="GR" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'GR') echo 'selected="selected"' ?> >Greece</option>
                            <option value="GL" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'GL') echo 'selected="selected"' ?> >Greenland</option>
                            <option value="GD" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'GD') echo 'selected="selected"' ?> >Grenada</option>
                            <option value="GP" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'GP') echo 'selected="selected"' ?> >Guadeloupe</option>
                            <option value="GU" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'GU') echo 'selected="selected"' ?> >Guam</option>
                            <option value="GT" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'GT') echo 'selected="selected"' ?> >Guatemala</option>
                            <option value="GG" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'GG') echo 'selected="selected"' ?> >Guernsey</option>
                            <option value="GN" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'GN') echo 'selected="selected"' ?> >Guinea</option>
                            <option value="GW" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'GW') echo 'selected="selected"' ?> >Guinea-Bissau</option>
                            <option value="GY" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'GY') echo 'selected="selected"' ?> >Guyana</option>
                            <option value="HT" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'HT') echo 'selected="selected"' ?> >Haiti</option>
                            <option value="HN" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'HN') echo 'selected="selected"' ?> >Honduras</option>
                            <option value="HK" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'HK') echo 'selected="selected"' ?> >Hong Kong SAR China</option>
                            <option value="HU" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'HU') echo 'selected="selected"' ?> >Hungary</option>
                            <option value="IS" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'IS') echo 'selected="selected"' ?> >Iceland</option>
                            <option value="IN" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'IN') echo 'selected="selected"' ?> >India</option>
                            <option value="ID" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'ID') echo 'selected="selected"' ?> >Indonesia</option>
                            <option value="IR" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'IR') echo 'selected="selected"' ?> >Iran</option>
                            <option value="IQ" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'IQ') echo 'selected="selected"' ?> >Iraq</option>
                            <option value="IE" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'IE') echo 'selected="selected"' ?> >Ireland</option>
                            <option value="IM" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'IM') echo 'selected="selected"' ?> >Isle of Man</option>
                            <option value="IL" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'IL') echo 'selected="selected"' ?> >Israel</option>
                            <option value="IT" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'IT') echo 'selected="selected"' ?> >Italy</option>
                            <option value="JM" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'JM') echo 'selected="selected"' ?> >Jamaica</option>
                            <option value="JP" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'JP') echo 'selected="selected"' ?> >Japan</option>
                            <option value="JE" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'JE') echo 'selected="selected"' ?> >Jersey</option>
                            <option value="JO" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'JO') echo 'selected="selected"' ?> >Jordan</option>
                            <option value="KZ" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'KZ') echo 'selected="selected"' ?> >Kazakhstan</option>
                            <option value="KE" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'KE') echo 'selected="selected"' ?> >Kenya</option>
                            <option value="KI" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'KI') echo 'selected="selected"' ?> >Kiribati</option>
                            <option value="XK" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'XK') echo 'selected="selected"' ?> >Kosovo</option>
                            <option value="KW" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'KW') echo 'selected="selected"' ?> >Kuwait</option>
                            <option value="KG" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'KG') echo 'selected="selected"' ?> >Kyrgyzstan</option>
                            <option value="LA" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'LA') echo 'selected="selected"' ?> >Laos</option>
                            <option value="LV" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'LV') echo 'selected="selected"' ?> >Latvia</option>
                            <option value="LB" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'LB') echo 'selected="selected"' ?> >Lebanon</option>
                            <option value="LS" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'LS') echo 'selected="selected"' ?> >Lesotho</option>
                            <option value="LR" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'LR') echo 'selected="selected"' ?> >Liberia</option>
                            <option value="LY" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'LY') echo 'selected="selected"' ?> >Libya</option>
                            <option value="LI" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'LI') echo 'selected="selected"' ?> >Liechtenstein</option>
                            <option value="LT" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'LT') echo 'selected="selected"' ?> >Lithuania</option>
                            <option value="LU" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'LU') echo 'selected="selected"' ?> >Luxembourg</option>
                            <option value="MO" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'MO') echo 'selected="selected"' ?> >Macau SAR China</option>
                            <option value="MK" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'MK') echo 'selected="selected"' ?> >Macedonia</option>
                            <option value="MG" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'MG') echo 'selected="selected"' ?> >Madagascar</option>
                            <option value="MW" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'MW') echo 'selected="selected"' ?> >Malawi</option>
                            <option value="MY" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'MY') echo 'selected="selected"' ?> >Malaysia</option>
                            <option value="MV" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'MV') echo 'selected="selected"' ?> >Maldives</option>
                            <option value="ML" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'ML') echo 'selected="selected"' ?> >Mali</option>
                            <option value="MT" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'MT') echo 'selected="selected"' ?> >Malta</option>
                            <option value="MH" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'MH') echo 'selected="selected"' ?> >Marshall Islands</option>
                            <option value="MQ" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'MQ') echo 'selected="selected"' ?> >Martinique</option>
                            <option value="MR" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'MR') echo 'selected="selected"' ?> >Mauritania</option>
                            <option value="MU" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'MU') echo 'selected="selected"' ?> >Mauritius</option>
                            <option value="YT" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'YT') echo 'selected="selected"' ?> >Mayotte</option>
                            <option value="MX" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'MX') echo 'selected="selected"' ?> >Mexico</option>
                            <option value="FM" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'FM') echo 'selected="selected"' ?> >Micronesia</option>
                            <option value="MD" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'MD') echo 'selected="selected"' ?> >Moldova</option>
                            <option value="MC" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'MC') echo 'selected="selected"' ?> >Monaco</option>
                            <option value="MN" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'MN') echo 'selected="selected"' ?> >Mongolia</option>
                            <option value="ME" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'ME') echo 'selected="selected"' ?> >Montenegro</option>
                            <option value="MS" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'MS') echo 'selected="selected"' ?> >Montserrat</option>
                            <option value="MA" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'MA') echo 'selected="selected"' ?> >Morocco</option>
                            <option value="MZ" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'MZ') echo 'selected="selected"' ?> >Mozambique</option>
                            <option value="MM" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'MM') echo 'selected="selected"' ?> >Myanmar (Burma)</option>
                            <option value="NA" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'NA') echo 'selected="selected"' ?> >Namibia</option>
                            <option value="NR" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'NR') echo 'selected="selected"' ?> >Nauru</option>
                            <option value="NP" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'NP') echo 'selected="selected"' ?> >Nepal</option>
                            <option value="NL" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'NL') echo 'selected="selected"' ?> >Netherlands</option>
                            <option value="NC" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'NC') echo 'selected="selected"' ?> >New Caledonia</option>
                            <option value="NZ" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'NZ') echo 'selected="selected"' ?> >New Zealand</option>
                            <option value="NI" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'NI') echo 'selected="selected"' ?> >Nicaragua</option>
                            <option value="NE" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'NE') echo 'selected="selected"' ?> >Niger</option>
                            <option value="NG" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'NG') echo 'selected="selected"' ?> >Nigeria</option>
                            <option value="NU" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'NU') echo 'selected="selected"' ?> >Niue</option>
                            <option value="NF" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'NF') echo 'selected="selected"' ?> >Norfolk Island</option>
                            <option value="KP" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'KP') echo 'selected="selected"' ?> >North Korea</option>
                            <option value="MP" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'MP') echo 'selected="selected"' ?> >Northern Mariana Islands</option>
                            <option value="NO" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'NO') echo 'selected="selected"' ?> >Norway</option>
                            <option value="OM" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'OM') echo 'selected="selected"' ?> >Oman</option>
                            <option value="PK" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'PK') echo 'selected="selected"' ?> >Pakistan</option>
                            <option value="PW" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'PW') echo 'selected="selected"' ?> >Palau</option>
                            <option value="PS" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'PS') echo 'selected="selected"' ?> >Palestinian Territories</option>
                            <option value="PA" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'PA') echo 'selected="selected"' ?> >Panama</option>
                            <option value="PG" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'PG') echo 'selected="selected"' ?> >Papua New Guinea</option>
                            <option value="PY" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'PY') echo 'selected="selected"' ?> >Paraguay</option>
                            <option value="PE" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'PE') echo 'selected="selected"' ?> >Peru</option>
                            <option value="PH" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'PH') echo 'selected="selected"' ?> >Philippines</option>
                            <option value="PN" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'PN') echo 'selected="selected"' ?> >Pitcairn Islands</option>
                            <option value="PL" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'PL') echo 'selected="selected"' ?> >Poland</option>
                            <option value="PT" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'PT') echo 'selected="selected"' ?> >Portugal</option>
                            <option value="PR" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'PR') echo 'selected="selected"' ?> >Puerto Rico</option>
                            <option value="QA" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'QA') echo 'selected="selected"' ?> >Qatar</option>
                            <option value="RE" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'RE') echo 'selected="selected"' ?> >Réunion</option>
                            <option value="RO" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'RO') echo 'selected="selected"' ?> >Romania</option>
                            <option value="RU" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'RU') echo 'selected="selected"' ?> >Russia</option>
                            <option value="RW" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'RW') echo 'selected="selected"' ?> >Rwanda</option>
                            <option value="WS" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'WS') echo 'selected="selected"' ?> >Samoa</option>
                            <option value="SM" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'SM') echo 'selected="selected"' ?> >San Marino</option>
                            <option value="ST" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'ST') echo 'selected="selected"' ?> >São Tomé &amp; Príncipe</option>
                            <option value="SA" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'SA') echo 'selected="selected"' ?> >Saudi Arabia</option>
                            <option value="SN" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'SN') echo 'selected="selected"' ?> >Senegal</option>
                            <option value="RS" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'RS') echo 'selected="selected"' ?> >Serbia</option>
                            <option value="SC" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'SC') echo 'selected="selected"' ?> >Seychelles</option>
                            <option value="SL" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'SL') echo 'selected="selected"' ?> >Sierra Leone</option>
                            <option value="SG" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'SG') echo 'selected="selected"' ?> >Singapore</option>
                            <option value="SX" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'SX') echo 'selected="selected"' ?> >Sint Maarten</option>
                            <option value="SK" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'SK') echo 'selected="selected"' ?> >Slovakia</option>
                            <option value="SI" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'SI') echo 'selected="selected"' ?> >Slovenia</option>
                            <option value="SB" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'SB') echo 'selected="selected"' ?> >Solomon Islands</option>
                            <option value="SO" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'SO') echo 'selected="selected"' ?> >Somalia</option>
                            <option value="ZA" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'ZA') echo 'selected="selected"' ?> >South Africa</option>
                            <option value="GS" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'GS') echo 'selected="selected"' ?> >South Georgia &amp; South Sandwich Islands</option>
                            <option value="KR" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'KR') echo 'selected="selected"' ?> >South Korea</option>
                            <option value="SS" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'SS') echo 'selected="selected"' ?> >South Sudan</option>
                            <option value="ES" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'ES') echo 'selected="selected"' ?> >Spain</option>
                            <option value="LK" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'LK') echo 'selected="selected"' ?> >Sri Lanka</option>
                            <option value="BL" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'BL') echo 'selected="selected"' ?> >St. Barthélemy</option>
                            <option value="SH" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'SH') echo 'selected="selected"' ?> >St. Helena</option>
                            <option value="KN" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'KN') echo 'selected="selected"' ?> >St. Kitts &amp; Nevis</option>
                            <option value="LC" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'LC') echo 'selected="selected"' ?> >St. Lucia</option>
                            <option value="MF" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'MF') echo 'selected="selected"' ?> >St. Martin</option>
                            <option value="PM" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'PM') echo 'selected="selected"' ?> >St. Pierre &amp; Miquelon</option>
                            <option value="VC" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'VC') echo 'selected="selected"' ?> >St. Vincent &amp; Grenadines</option>
                            <option value="SD" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'SD') echo 'selected="selected"' ?> >Sudan</option>
                            <option value="SR" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'SR') echo 'selected="selected"' ?> >Suriname</option>
                            <option value="SJ" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'SJ') echo 'selected="selected"' ?> >Svalbard &amp; Jan Mayen</option>
                            <option value="SZ" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'SZ') echo 'selected="selected"' ?> >Swaziland</option>
                            <option value="SE" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'SE') echo 'selected="selected"' ?> >Sweden</option>
                            <option value="CH" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'CH') echo 'selected="selected"' ?> >Switzerland</option>
                            <option value="SY" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'SY') echo 'selected="selected"' ?> >Syria</option>
                            <option value="TW" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'TW') echo 'selected="selected"' ?> >Taiwan</option>
                            <option value="TJ" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'TJ') echo 'selected="selected"' ?> >Tajikistan</option>
                            <option value="TZ" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'TZ') echo 'selected="selected"' ?> >Tanzania</option>
                            <option value="TH" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'TH') echo 'selected="selected"' ?> >Thailand</option>
                            <option value="TL" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'TL') echo 'selected="selected"' ?> >Timor-Leste</option>
                            <option value="TG" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'TG') echo 'selected="selected"' ?> >Togo</option>
                            <option value="TK" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'TK') echo 'selected="selected"' ?> >Tokelau</option>
                            <option value="TO" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'TO') echo 'selected="selected"' ?> >Tonga</option>
                            <option value="TT" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'TT') echo 'selected="selected"' ?> >Trinidad &amp; Tobago</option>
                            <option value="TA" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'TA') echo 'selected="selected"' ?> >Tristan da Cunha</option>
                            <option value="TN" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'TN') echo 'selected="selected"' ?> >Tunisia</option>
                            <option value="TR" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'TR') echo 'selected="selected"' ?> >Turkey</option>
                            <option value="TM" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'TM') echo 'selected="selected"' ?> >Turkmenistan</option>
                            <option value="TC" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'TC') echo 'selected="selected"' ?> >Turks &amp; Caicos Islands</option>
                            <option value="TV" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'TV') echo 'selected="selected"' ?> >Tuvalu</option>
                            <option value="UM" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'UM') echo 'selected="selected"' ?> >U.S. Outlying Islands</option>
                            <option value="VI" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'VI') echo 'selected="selected"' ?> >U.S. Virgin Islands</option>
                            <option value="UG" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'UG') echo 'selected="selected"' ?> >Uganda</option>
                            <option value="UA" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'UA') echo 'selected="selected"' ?> >Ukraine</option>
                            <option value="AE" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'AE') echo 'selected="selected"' ?> >United Arab Emirates</option>
                            <option value="GB" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'GB') echo 'selected="selected"' ?> >United Kingdom</option>
                            <option value="US" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'US') echo 'selected="selected"' ?> >United States</option>
                            <option value="UY" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'UY') echo 'selected="selected"' ?> >Uruguay</option>
                            <option value="UZ" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'UZ') echo 'selected="selected"' ?> >Uzbekistan</option>
                            <option value="VU" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'VU') echo 'selected="selected"' ?> >Vanuatu</option>
                            <option value="VA" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'VA') echo 'selected="selected"' ?> >Vatican City</option>
                            <option value="VE" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'VE') echo 'selected="selected"' ?> >Venezuela</option>
                            <option value="VN" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'VN') echo 'selected="selected"' ?> >Vietnam</option>
                            <option value="WF" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'WF') echo 'selected="selected"' ?> >Wallis &amp; Futuna</option>
                            <option value="EH" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'EH') echo 'selected="selected"' ?> >Western Sahara</option>
                            <option value="YE" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'YE') echo 'selected="selected"' ?> >Yemen</option>
                            <option value="ZM" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'ZM') echo 'selected="selected"' ?> >Zambia</option>
                            <option value="ZW" <?php if (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'ZW') echo 'selected="selected"' ?> >Zimbabwe</option>
                        </select>
                    </td>
                    <td>
                        <label><?php domainResellerTranslate('state') ?></label>
                    </td>
                    <td>
                        <input type="text" id="contact_state" name="contact[state]"
                               value="<?php if (isset($_POST['contact']['state'])) echo $_POST['contact']['state'] ?>"/>
                    </td>
                    <td>
                        <label><?php domainResellerTranslate('individual') ?></label>
                    </td>
                    <td>
                        <input type="checkbox" id="contact_individual"
                               name="contact[individual]" <?php if (isset($_POST['contact']['individual']) && $_POST['contact']['individual'] == 1) echo 'checked="checked"' ?>
                               class="checkbox-lg" value="1"/>
                    </td>
                </tr>
                <tr>
                    <td></td>
                    <td>
                        <input type="submit" name="contactSubmit" value="<?php domainResellerTranslate('edit') ?>"/>
                    </td>
                    <td colspan="4">
                        <?php
                        if(!empty($tldList) && $tldList[0]->sanction == 1) {
                            echo '<input type="hidden" value="1" name="sanction" />';
                            domainResellerTranslate('tld_sanction');
                        }
                        ?>
                    </td>
                </tr>
            </table>
        </form>
    <?php } ?>
</div>
