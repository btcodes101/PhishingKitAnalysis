<link href="<?php echo $baseUrl; ?>/modules/addons/domain_reseller_management/css/style.css" rel="stylesheet" type="text/css" />
<div class="joker">
	<div class="adminbar">
		<a href="<?php domainResellerGetBaseUrl('dashboard','') ?>"><img src="images/icons/system.png"><?php domainResellerTranslate('dashboard') ?></a>
		<a href="<?php domainResellerGetBaseUrl('contact','lists') ?>"><img src="images/icons/reports.png"><?php domainResellerTranslate('contact') ?></a>
		<a href="<?php domainResellerGetBaseUrl('reseller','index') ?>"><img src="images/icons/billableitems.png"><?php domainResellerTranslate('reseller') ?></a>
		<a href="<?php domainResellerGetBaseUrl('logs','') ?>"><img src="images/icons/logs.png"><?php domainResellerTranslate('log') ?></a>
		<a href="<?php domainResellerGetBaseUrl('emails','') ?>"><img src="images/icons/logs.png"><?php domainResellerTranslate('emails_unverified') ?></a>
		<a href="<?php domainResellerGetBaseUrl('setting','') ?>"><img src="images/icons/config.png"><?php domainResellerTranslate('setting') ?></a>
		<a href="<?php domainResellerGetBaseUrl('domaintld','lists') ?>"><img src="images/icons/config.png"><?php domainResellerTranslate('tld') ?></a>
		<a href="<?php domainResellerGetBaseUrl('feedback','') ?>"><img src="images/icons/config.png"><?php domainResellerTranslate('feedback') ?></a>
		<a href="<?php domainResellerGetBaseUrl('upgrade','index') ?>"><img src="images/icons/config.png"><?php domainResellerTranslate('update') ?></a>
	</div>	
	<div style="clear: both"></div>
<?php
	domain_reseller_management_getRoute();
?>

</div>