<div class="dashboard">
	<div>
		<?php
		if (!empty($err)) {
			echo '<div style="color:red;">';
			foreach ($err as $er) {
				echo $er . '<br/>';
			}
			echo '</div>';
		} elseif (isset($suc) && $suc != '') {
			echo '<div style="color:green;">' . $suc . '</div>';
		}

		?>

	</div>

	<div>
		<form name="" method="post" action="<?php domainResellerGetBaseUrl('reseller','listtld') ?>" id="resellerTld">
			<input type="hidden" name="searchResellerTld" id="resellerTldSearch" value="0" />
			<label>
				انتخاب نماینده:
				<select name="domain_reseller_management_tld[id]">
					<?php
					foreach($reseller as $r){
						echo '<option value="'.$r->id.'">'.$r->name.'</option>';
					}
					?>
				</select>
				<input type="submit" name="search" value=" جستجوی پسوند های ثبت شده برای نماینده" onclick="return addSearchFeild()" />
			</label>
			<br>
			<br>
		</form>
	</div>
	<?php if(isset($_POST['domain_reseller_management_tld']['id'])){ ?>
	<div class="tablebg">
		<table id="sortabletbl1" class="datatable" width="100%" border="0" cellspacing="1" cellpadding="3">
			<tbody>
			<tr>
				<th>ردیف</th>
				<th>tld</th>
				<th>مبلغ ثبت(<?php echo $units ?>)</th>
				<th>مبلغ تمدید(<?php echo $units ?>)</th>
				<th>مبلغ انتقال(<?php echo $units ?>)</th>
				<th>وضعیت</th>
				<th>عملیات</th>
			</tr>

			<?php if(empty($tldList)){ ?>
				<tr><td colspan="10">هیچ مقداری یافت نشد</td></tr>
			<?php }else{

				foreach ($tldList as $i=>$t) {
					echo '<tr><td>'.($i+1).'</td>';
					echo "<td>{$t->tld}</td>";
					echo "<td>{$t->register_price_buy}</td>";
					echo "<td>{$t->renew_price_buy}</td>";
					echo "<td>{$t->transfer_price_buy}</td>";
					if($t->active == 0){
						echo "<td>غیر فعال توسط نماینده</td>";
					}elseif($t->active ==1){
						echo "<td>فعال</td>";
					}elseif($t->active ==2){
						echo "<td>غیرفعال توسط پرنت</td>";
					}
					echo '<td><a href="'.domainResellerGetBaseUrl('reseller','updatetld',['tld'=>$t->tld,'id'=>$_POST['domain_reseller_management_tld']['id']],false).'">تغییر وضعیت</a></td>';
					echo '</tr>';
				}
			}
			?>

			</tbody>
		</table>
	</div>
	<?php } ?>
</div>

<script>
	function addSearchFeild() {
		$('#resellerTldSearch').val('1');
		return true;
	}
	function removeSearchFeild() {
		$('#resellerTldSearch').val('0');
		return true;
	}
</script>