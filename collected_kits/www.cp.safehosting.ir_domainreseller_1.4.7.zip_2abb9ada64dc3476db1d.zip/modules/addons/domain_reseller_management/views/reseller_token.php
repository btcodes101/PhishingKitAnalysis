<div>
	<?php
	if (!empty($error)) {
		echo '<div style="color:red;">';
		if(is_array($error)){
			foreach ($error as $er) {
				echo $er . '<br/>';
			}
		}else{
			echo $error . '<br/>';
		}
		echo '</div>';
	} elseif (isset($suc) && $suc != '') {
		echo '<div style="color:green;">' . $suc . '</div>';
	}

	?>

</div>
<?php if (empty($error)) { ?>
	<div>
		<form name="" method="post" action="<?php domainResellerGetBaseUrl('reseller','token',['resellerId'=>$_GET['resellerId']]) ?>">
			<label>
				<?php domainResellerTranslate('token_app_name') ?>
				<input type="text" name="domain_reseller_management_token[client_name]" value="<?php if(isset($domain_reseller_management_setting['client_name'])) echo $domain_reseller_management_setting['client_name'] ?>"/>
			</label>
			<input type="submit" name="domain_reseller_management_token[submit]" value="<?php domainResellerTranslate('create') ?>"/>
		</form>
	</div>
<?php } ?>