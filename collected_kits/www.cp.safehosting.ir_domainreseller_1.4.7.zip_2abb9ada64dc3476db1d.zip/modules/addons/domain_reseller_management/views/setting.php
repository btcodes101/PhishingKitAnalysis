<div>
    <?php

    if (!empty($error)) {
        echo '<div style="color:red;">';
        foreach ($error as $er) {
            echo $er . '<br/>';
        }
        echo '</div>';
    } elseif (isset($suc) && $suc != '') {
        echo '<div style="color:green;">' . $suc . '</div>';
    }

    ?>

</div>

<div class="setting">

    <form name="" method="post" action="<?php domainResellerGetBaseUrl('setting', 'save'); ?>">
        <table class="form" width="100%" border="0" cellspacing="2" cellpadding="3">
            <tbody>
            <tr>
                <td class="fieldlabel"></td>
                <td class="fieldarea">برای فعالسازی نمایندگی دامنه نیازمند فعالسازی توکن هستید.توکن را از شرکتی که نمایندگی دامنه شما از انها تهیه شده است، دریافت نمایید:</td>
            </tr>
            <tr>
                <td style="width: 25%;" class="fieldlabel">
                    <label>
                        <?php domainResellerTranslate('setting_token', $moduleParams['language']) ?>
                    </label>
                </td>
                <td class="fieldarea">
                    <input type="text" style="width:500px;" name="domain_reseller_management_setting[token]"
                           value="<?php if (isset($domain_reseller_management_setting['token'])) echo $domain_reseller_management_setting['token'] ?>"/>
                </td>
            </tr>
            </tbody>
        </table>
        <div class="btn-container">
            <input type="submit" name="domain_reseller_management_setting[submit]"
                   value="<?php domainResellerTranslate('submit') ?>"/>
        </div>
    </form>
</div>

<div class="setting">
    <form name="" method="post" action="<?php domainResellerGetBaseUrl('setting', 'formula'); ?>">
        <table class="form" width="100%" border="0" cellspacing="2" cellpadding="3">
            <tbody>
            <tr>
                <td class="fieldlabel"></td>
                <td class="fieldarea">تخفیفات شارژ برای زیرنمایندگان:</td>
            </tr>
        <?php $indexKey = 0;
        if (isset($domain_reseller_management_setting['formula'])) {
            foreach ($domain_reseller_management_setting['formula'] as $key => $value) { ?>
                <tr class="chargeArea">
                    <td style="width: 25%;" class="fieldlabel">
                        <label><?php domainResellerTranslate('setting_formula_charge') ?></label>
                    </td>
                    <td class="fieldarea">
                        <input type="text" name="domain_reseller_management_formula[charge][<?php echo $indexKey ?>]" value="<?php echo $key ?>"/>
                    </td>
                    <td style="width: 25%;" class="fieldlabel">
                        <label><?php domainResellerTranslate('setting_formula_discount') ?></label>
                    </td>
                    <td class="fieldarea">
                        <input type="text" name="domain_reseller_management_formula[discount][<?php echo $indexKey ?>]" value="<?php echo $value ?>"/>
                    </td>
                </tr>
                <?php
                $indexKey++;
            }
        } else { ?>
            <tr class="chargeArea">
                <td style="width: 25%;" class="fieldlabel">
                    <label><?php domainResellerTranslate('setting_formula_charge') ?></label>
                </td>
                <td class="fieldarea">
                    <input type="text" name="domain_reseller_management_formula[charge][0]" value="" />
                </td>
                <td style="width: 25%;" class="fieldlabel">
                    <label><?php domainResellerTranslate('setting_formula_discount') ?></label>
                </td>
                <td class="fieldarea">
                    <input type="text" name="domain_reseller_management_formula[discount][0]" value="" />
                </td>
            </tr>
            <?php $indexKey++;
        } ?>

            </tbody>
        </table>
        <div class="btn-container">
        <button onclick="return addFeild()"><?php domainResellerTranslate('create_new') ?></button>
        <input type="submit" name="domain_reseller_management_formula[chargesubmit]" value="<?php domainResellerTranslate('submit') ?>"/>
        </div>

    </form>
</div>

<div class="setting">
    <form name="" method="post" action="<?php domainResellerGetBaseUrl('setting', 'adminuser'); ?>">
        <table class="form" width="100%" border="0" cellspacing="2" cellpadding="3">
            <tbody>
            <tr>
                <td class="fieldlabel"></td>
                <td class="fieldarea">انتخاب اکانت پرسنل برای ارسال پیام‌های خودکار ماژول:</td>
            </tr>
            <tr>
                <td style="width: 25%" class="fieldlabel">
                    <label><?php domainResellerTranslate('setting_user_api') ?></label>
                </td>
                <td class="fieldarea">
                    <select name="domain_reseller_management_adminuser[admin]">
                        <?php
                        foreach ($domain_reseller_management_admin as $admin) {
                            if (isset($domain_reseller_management_setting['adminuser']) && $domain_reseller_management_setting['adminuser'] == $admin->username) {
                                echo '<option value="' . $admin->username . '" selected="selected">' . $admin->username . '</option>';
                            } else {
                                echo '<option value="' . $admin->username . '">' . $admin->username . '</option>';
                            }
                        }
                        ?>
                    </select>
                </td>
            </tr>
            </tbody>
        </table>
        <div class="btn-container">
            <input type="submit" name="domain_reseller_management_adminuser[adminsubmit]"
                   value="<?php domainResellerTranslate('submit') ?>"/>
        </div>
    </form>
</div>

<div class="setting">
    <form name="" method="post" action="<?php domainResellerGetBaseUrl('setting', 'defualtunit'); ?>">
        <table class="form" width="100%" border="0" cellspacing="2" cellpadding="3">
            <tbody>
            <tr>
                <td class="fieldlabel"></td>
                <td class="fieldarea">واحد پول ماژول نمایندگی(نمایش نرخ‌ها و همگام سازی با WHMCS):</td>
            </tr>
            <tr>

                <td style="width: 25%" class="fieldlabel">
                    <label><?php domainResellerTranslate('setting_units') ?></label>
                </td>
                <td class="fieldarea">
                    <select name="domain_reseller_management_unit[unit]">
                        <option
                                value="rial" <?php if (isset($domain_reseller_management_setting['unit']['rial'])) echo 'selected="selected"' ?>>
                            <?php domainResellerTranslate('rial') ?>
                        </option>
                        <option
                                value="toman" <?php if (isset($domain_reseller_management_setting['unit']['toman'])) echo 'selected="selected"' ?>>
                            <?php domainResellerTranslate('toman') ?>
                        </option>
                    </select>
                </td>
            </tr>
            </tbody>
        </table>
        <div class="btn-container">
            <input type="submit" name="domain_reseller_management_unit[unitsubmit]" value="<?php domainResellerTranslate('submit') ?>"/>
        </div>
    </form>
</div>

<div class="setting">
    <form name="" method="post" action="<?php domainResellerGetBaseUrl('setting', 'defualtlang'); ?>">
        <table class="form" width="100%" border="0" cellspacing="2" cellpadding="3">
            <tbody>
            <tr>
                <td class="fieldlabel"></td>
                <td class="fieldarea">زبان ماژول نمایندگی:</td>
            </tr>
            <tr>
                <td style="width: 25%" class="fieldlabel">
                    <label><?php domainResellerTranslate('setting_language') ?></label>
                </td>
                <td class="fieldarea">
                    <select name="domain_reseller_management_language">
                        <?php
                        foreach (scandir(__DIR__ . '/../lang/') as $item) {
                            if (!is_dir($item)) {

                                $item = str_replace('.php', '', $item);
                                ?>
                                <option
                                        value="<?= $item ?>" <?php if (isset($domain_reseller_management_setting['language'][$item])) echo 'selected="selected"' ?>>
                                    <?php domainResellerTranslate('setting_language_' . $item) ?>
                                </option>
                                <?php
                            }
                        }
                        ?>
                        <?php
                        foreach (scandir(__DIR__ . '/../customLang/') as $item) {
                            if (!is_dir($item)) {

                                $item = str_replace('.php', '', $item);
                                ?>
                                <option value="<?= $item ?>" <?php if (isset($domain_reseller_management_setting['language'][$item])) echo 'selected="selected"' ?>>
                                    <?php domainResellerTranslate('setting_language_' . $item) ?>
                                </option>
                                <?php
                            }
                        }
                        ?>
                    </select>
                </td>
            </tr>
            </tbody>
        </table>
        <div class="btn-container">
            <input type="submit" name="langSubmit" value="<?php domainResellerTranslate('submit') ?>"/>
        </div>
    </form>
</div>

<div class="setting">
    <form name="" method="post" action="<?php domainResellerGetBaseUrl('setting', 'ticket'); ?>">
        <table class="form" width="100%" border="0" cellspacing="2" cellpadding="3">
            <tbody>
            <tr>
                <td class="fieldlabel"></td>
                <td class="fieldarea">با فعال کردن این بخش، هنگام بروز خطا در اعمال انجام شده بروی دامنه(ثبت/تمدید/انتقال/تغییر dns و ...) یک تیکت خودکار برای مشتری ایجاد می‌شود تا امکان پیگیری ساده‌تر آن برای پرسنل فراهم گردد و مشتری نیز از بروی خطا مطلع شود.</td>
            </tr>
            <tr>
                <td style="width: 25%" class="fieldlabel">
                    <label>
                        <?php domainResellerTranslate('setting_ticket_enable') ?>
                    </label>
                </td>
                <td class="fieldarea">
                    <input type="checkbox" onclick="showDiv(this,'ticketHide')"
                           name="ticket[enable]" <?php if (isset($domain_reseller_management_setting['ticket']['enable'])) echo 'checked'; ?>
                           value="1"/>

                </td>
            </tr>
            <tr class="ticketHide" <?php if (!isset($domain_reseller_management_setting['ticket']['enable'])) echo 'style="display: none"'; ?>>
                <td style="width: 25%" class="fieldlabel">
                    <label><?php domainResellerTranslate('setting_department') ?></label>
                </td>
                <td class="fieldarea">
                    <select name="ticket[department]">
                        <?php
                        foreach ($department as $id => $name) {
                            if (isset($domain_reseller_management_setting['ticket']['department']) && $id == $domain_reseller_management_setting['ticket']['department']) {
                                echo '<option value="' . $id . '" selected="selected">' . $name . '</option>';
                            } else {
                                echo '<option value="' . $id . '">' . $name . '</option>';
                            }
                        }
                        ?>
                    </select>
                </td>
            </tr>
            <tr class="ticketHide" <?php if (!isset($domain_reseller_management_setting['ticket']['enable'])) echo 'style="display: none"'; ?>>
                <td style="width: 25%" class="fieldlabel">
                    <label><?php domainResellerTranslate('setting_ticket_reply') ?></label>
                </td>
                <td class="fieldarea">
                    <input type="text" name="ticket[reply]" style="width: 600px;"
                           value="<?php if (isset($domain_reseller_management_setting['ticket']['reply'])) echo $domain_reseller_management_setting['ticket']['reply'] ?>"/>

                    <div><?php domainResellerTranslate('setting_params_allow') ?> : <span
                                style="text-align: left;direction: ltr">[$domain], [$error], [$action]</span></div>
                </td>
            </tr>


            <tr class="ticketHide" <?php if (!isset($domain_reseller_management_setting['ticket']['enable'])) echo 'style="display: none"'; ?>>
                <td style="width: 25%" class="fieldlabel">
                    <label><?php domainResellerTranslate('setting_ticket_status') ?></label>
                </td>
                <td class="fieldarea">
                    <select name="ticket[status]">
                        <option name="Answered" <?php if (isset($domain_reseller_management_setting['ticket']['status']) && $domain_reseller_management_setting['ticket']['status'] == 'Answered') echo 'selected="selected"' ?>>
                            Answered
                        </option>
                        <option name="Open" <?php if (isset($domain_reseller_management_setting['ticket']['status']) && $domain_reseller_management_setting['ticket']['status'] == 'Open') echo 'selected="selected"' ?>>
                            Open
                        </option>
                        <option name="Customer-Reply" <?php if (isset($domain_reseller_management_setting['ticket']['status']) && $domain_reseller_management_setting['ticket']['status'] == 'Customer-Reply') echo 'selected="selected"' ?>>
                            Customer-Reply
                        </option>
                        <option name="In-Progress" <?php if (isset($domain_reseller_management_setting['ticket']['status']) && $domain_reseller_management_setting['ticket']['status'] == 'In-Progress') echo 'selected="selected"' ?>>
                            In-Progress
                        </option>
                        <option name="On Hold" <?php if (isset($domain_reseller_management_setting['ticket']['status']) && $domain_reseller_management_setting['ticket']['status'] == 'On Hold') echo 'selected="selected"' ?>>
                            On Hold
                        </option>
                        <option name="Closed" <?php if (isset($domain_reseller_management_setting['ticket']['status']) && $domain_reseller_management_setting['ticket']['status'] == 'Closed') echo 'selected="selected"' ?>>
                            Closed
                        </option>
                    </select>
                </td>
            </tr>
            </tbody>
        </table>
        <div class="btn-container">
            <input type="submit" name="ticketSubmit" value="<?php domainResellerTranslate('submit') ?>"/>
        </div>
    </form>
</div>

<div class="whois setting">
    <form name="" method="post" action="<?php domainResellerGetBaseUrl('setting', 'whoisTicket'); ?>">
        <table class="form" width="100%" border="0" cellspacing="2" cellpadding="3">
            <tbody>
            <tr>
                <td class="fieldlabel"></td>
                <td class="fieldarea">با فعال کردن این بخش، هنگام بروز خطا در استفاده از مشخصات مشتری برای WHOIS در دامنه(هنگام ثبت یا انتقال) یک تیکت خودکار برای مشتری ایجاد می‌شود تا امکان پیگیری ساده‌تر آن برای پرسنل فراهم گردد و مشتری نیز از بروی خطا مطلع شود.</td>
            </tr>
            <tr>
                <td style="width: 25%" class="fieldlabel">
                    <label>
                        <?php domainResellerTranslate('setting_whoisTicket_enable') ?>
                    </label>
                </td>
                <td class="fieldarea">
                    <input type="checkbox" onclick="showDiv(this,'whoisTicketHide')"
                           name="whoisTicket[enable]" <?php if (isset($domain_reseller_management_setting['whoisTicket']['enable'])) echo 'checked'; ?>
                           value="1"/>

                </td>
            </tr>
            <tr class="whoisTicketHide" <?php if (!isset($domain_reseller_management_setting['whoisTicket']['enable'])) echo 'style="display: none"'; ?>>
                <td style="width: 25%" class="fieldlabel">
                    <label><?php domainResellerTranslate('setting_department') ?></label>
                </td>
                <td class="fieldarea">
                    <select name="whoisTicket[department]">
                        <?php
                        foreach ($department as $id => $name) {
                            if (isset($domain_reseller_management_setting['whoisTicket']['department']) && $id == $domain_reseller_management_setting['whoisTicket']['department']) {
                                echo '<option value="' . $id . '" selected="selected">' . $name . '</option>';
                            } else {
                                echo '<option value="' . $id . '">' . $name . '</option>';
                            }
                        }
                        ?>
                    </select>
                </td>
            </tr>
            <tr class="whoisTicketHide" <?php if (!isset($domain_reseller_management_setting['whoisTicket']['enable'])) echo 'style="display: none"'; ?>>
                <td style="width: 25%" class="fieldlabel">
                    <label><?php domainResellerTranslate('setting_ticket_reply') ?></label>
                </td>
                <td class="fieldarea">
                    <input type="text" name="whoisTicket[reply]" style="width: 600px;"
                           value="<?php if (isset($domain_reseller_management_setting['whoisTicket']['reply'])) echo $domain_reseller_management_setting['whoisTicket']['reply'] ?>"/>

                    <div><?php domainResellerTranslate('setting_params_allow') ?> : <span
                                style="text-align: left;direction: ltr">[$domain], [$error], [$action]</span></div>
                </td>
            </tr>


            <tr class="whoisTicketHide" <?php if (!isset($domain_reseller_management_setting['whoisTicket']['enable'])) echo 'style="display: none"'; ?>>
                <td style="width: 25%" class="fieldlabel">
                    <label><?php domainResellerTranslate('setting_ticket_status') ?></label>
                </td>
                <td class="fieldarea">
                    <select name="whoisTicket[status]">
                        <option name="Answered" <?php if (isset($domain_reseller_management_setting['whoisTicket']['status']) && $domain_reseller_management_setting['whoisTicket']['status'] == 'Answered') echo 'selected="selected"' ?>>
                            Answered
                        </option>
                        <option name="Open" <?php if (isset($domain_reseller_management_setting['whoisTicket']['status']) && $domain_reseller_management_setting['whoisTicket']['status'] == 'Open') echo 'selected="selected"' ?>>
                            Open
                        </option>
                        <option name="Customer-Reply" <?php if (isset($domain_reseller_management_setting['whoisTicket']['status']) && $domain_reseller_management_setting['whoisTicket']['status'] == 'Customer-Reply') echo 'selected="selected"' ?>>
                            Customer-Reply
                        </option>
                        <option name="In-Progress" <?php if (isset($domain_reseller_management_setting['whoisTicket']['status']) && $domain_reseller_management_setting['whoisTicket']['status'] == 'In-Progress') echo 'selected="selected"' ?>>
                            In-Progress
                        </option>
                        <option name="On Hold" <?php if (isset($domain_reseller_management_setting['whoisTicket']['status']) && $domain_reseller_management_setting['whoisTicket']['status'] == 'On Hold') echo 'selected="selected"' ?>>
                            On Hold
                        </option>
                        <option name="Closed" <?php if (isset($domain_reseller_management_setting['whoisTicket']['status']) && $domain_reseller_management_setting['whoisTicket']['status'] == 'Closed') echo 'selected="selected"' ?>>
                            Closed
                        </option>
                    </select>
                </td>
            </tr>
            </tbody>
        </table>
        <div class="btn-container">
            <input type="submit" name="whoisTicketSubmit" value="<?php domainResellerTranslate('submit') ?>"/>
        </div>
    </form>
</div>


<div class="transferout setting">
    <form name="" method="post" action="<?php domainResellerGetBaseUrl('setting', 'transferOut'); ?>">
        <table class="form" width="100%" border="0" cellspacing="2" cellpadding="3">
            <tbody>
            <tr>
                <td class="fieldlabel"></td>
                <td class="fieldarea">با فعال کردن این بخش، هنگامی که یک دامنه به خارج از پنل شما منتقل شود، با هدف اطلاع رسانی بصورت خودکار یک تیکت برای مشتری ایجاد میشود و وضعیت دامنه‌ی وی در WHMCS نیز از حالت فعال خارج می‌گردد تا از صدور فاکتورهای آتی جلوگیری شود.</td>
            </tr>
            <tr>
                <td style="width: 25%" class="fieldlabel">
                    <label><?php domainResellerTranslate('setting_transfer_out_enable') ?></label>
                </td>
                <td class="fieldarea">
                    <input type="checkbox" onclick="showDiv(this,'transferOutHide')"
                           name="transferOut[enable]" <?php if (isset($domain_reseller_management_setting['transferOut']['enable'])) echo 'checked'; ?>
                           value="1">
                </td>
            </tr>
            <tr class="transferOutHide" <?php if (!isset($domain_reseller_management_setting['transferOut']['enable'])) echo 'style="display: none"'; ?>>
                <td style="width: 25%" class="fieldlabel">
                    <label><?php domainResellerTranslate('setting_department') ?></label>
                </td>
                <td class="fieldarea">
                    <select name="transferOut[department]">
                        <?php
                        foreach ($department as $id => $name) {
                            if (isset($domain_reseller_management_setting['transferOut']['department']) && $id == $domain_reseller_management_setting['transferOut']['department']) {
                                echo '<option value="' . $id . '" selected="selected">' . $name . '</option>';
                            } else {
                                echo '<option value="' . $id . '">' . $name . '</option>';
                            }
                        }
                        ?>
                    </select>
                </td>
            </tr>

            <tr>
                <td style="width: 25%" class="fieldlabel">
                    <label><?php domainResellerTranslate('setting_transfer_out_period') ?></label>
                </td>
                <td class="fieldarea">
                    <select name="transferOut[period]">
                        <option value="7" <?php if (isset($domain_reseller_management_setting['transferOut']['period']) && $domain_reseller_management_setting['transferOut']['period'] == '7') echo 'selected="selected"' ?>><?php domainResellerTranslate('setting_transfer_out_period_week') ?></option>
                        <option value="30" <?php if (isset($domain_reseller_management_setting['transferOut']['period']) && $domain_reseller_management_setting['transferOut']['period'] == '30') echo 'selected="selected"' ?>><?php domainResellerTranslate('setting_transfer_out_period_month') ?></option>
                    </select>
                </td>
            </tr>
            <tr>
                <td style="width: 25%" class="fieldlabel">
                    <label>
                        <?php domainResellerTranslate('setting_whmcs_sync') ?>
                    </label>
                </td>
                <td class="fieldarea">
                    <input type="checkbox" name="transferOut[sync]" onclick="showDiv(this,'transferOutSyncHide')"
                           value="1" <?php if (isset($domain_reseller_management_setting['transferOut']['sync'])) echo 'checked'; ?> />
                </td>
            </tr>

            <tr class="transferOutSyncHide" <?php if (!isset($domain_reseller_management_setting['transferOut']['sync'])) echo 'style="display: none"'; ?>>
                <td style="width: 25%" class="fieldlabel">
                    <label><?php domainResellerTranslate('setting_transfer_out_log') ?></label>
                </td>
                <td class="fieldarea">
                    <textarea name="transferOut[log]"
                              style="width: 600px;"><?php echo isset($domain_reseller_management_setting['transferOut']['log']) ? $domain_reseller_management_setting['transferOut']['log'] : domainResellerTranslate('setting_transfer_out_default_log_msg') ?></textarea>
                </td>
            </tr>

            <tr>
                <td style="width: 25%" class="fieldlabel">
                    <label>
                        <?php domainResellerTranslate('setting_transfer_out_ticket_enable') ?>
                    </label>
                </td>
                <td class="fieldarea">
                    <input type="checkbox" onclick="showDiv(this,'transferOutTicketHide')"
                           name="transferOut[ticketEnable]" <?php if (isset($domain_reseller_management_setting['transferOut']['ticketEnable'])) echo 'checked'; ?>
                           value="1">
                </td>
            </tr>
            <tr class="transferOutTicketHide" <?php if (!isset($domain_reseller_management_setting['transferOut']['ticketEnable'])) echo 'style="display: none"'; ?>>
                <td style="width: 25%" class="fieldlabel">
                    <label><?php domainResellerTranslate('setting_transfer_out_reply') ?></label>
                </td>
                <td class="fieldarea">
                    <input type="text" name="transferOut[reply]" style="width: 600px;"
                           value="<?php if (isset($domain_reseller_management_setting['transferOut']['reply'])) echo $domain_reseller_management_setting['transferOut']['reply'] ?>"/>
                    <div><?php domainResellerTranslate('setting_params_allow') ?> : <span
                                style="text-align: left;direction: ltr">[$domain]</span></div>
                </td>
            </tr>
            <tr class="transferOutTicketHide" <?php if (!isset($domain_reseller_management_setting['transferOut']['ticketEnable'])) echo 'style="display: none"'; ?>>
                <td style="width: 25%" class="fieldlabel">
                    <label><?php domainResellerTranslate('setting_ticket_status') ?></label>
                </td>
                <td class="fieldarea">
                    <select name="transferOut[status]">
                        <option name="Answered" <?php if (isset($domain_reseller_management_setting['transferOut']['status']) && $domain_reseller_management_setting['transferOut']['status'] == 'Answered') echo 'selected="selected"' ?>>
                            Answered
                        </option>
                        <option name="Open" <?php if (isset($domain_reseller_management_setting['transferOut']['status']) && $domain_reseller_management_setting['transferOut']['status'] == 'Open') echo 'selected="selected"' ?>>
                            Open
                        </option>
                        <option name="Customer-Reply" <?php if (isset($domain_reseller_management_setting['transferOut']['status']) && $domain_reseller_management_setting['transferOut']['status'] == 'Customer-Reply') echo 'selected="selected"' ?>>
                            Customer-Reply
                        </option>
                        <option name="In-Progress" <?php if (isset($domain_reseller_management_setting['transferOut']['status']) && $domain_reseller_management_setting['transferOut']['status'] == 'In-Progress') echo 'selected="selected"' ?>>
                            In-Progress
                        </option>
                        <option name="On Hold" <?php if (isset($domain_reseller_management_setting['transferOut']['status']) && $domain_reseller_management_setting['transferOut']['status'] == 'On Hold') echo 'selected="selected"' ?>>
                            On Hold
                        </option>
                        <option name="Closed" <?php if (isset($domain_reseller_management_setting['transferOut']['status']) && $domain_reseller_management_setting['transferOut']['status'] == 'Closed') echo 'selected="selected"' ?>>
                            Closed
                        </option>
                    </select>
                </td>
            </tr>
            </tbody>
        </table>
        <div class="btn-container">
            <input type="submit" name="transferOutSubmit" value="<?php domainResellerTranslate('submit') ?>"/>
        </div>
    </form>
</div>

<div>
    <form name="" method="post" action="<?php domainResellerGetBaseUrl('setting', 'emailUnverified'); ?>">
        <table class="form" width="100%" border="0" cellspacing="2" cellpadding="3">
            <tbody>
            <tr>
                <td class="fieldlabel"></td>
                <td class="fieldarea">براساس قوانین ICANN تمام ایمیل‌های موجود در WHOIS باید اعتبار سنجی شوند. با فعالسازی این بخش یادآوری از طریق تیکت برای مشتری ارسال خواهد شد تا از غیرفعال شدن دامنه به این دلیل جلوگیری شود.</td>
            </tr>
            <tr>
                <td style="width: 25%" class="fieldlabel">
                    <label>
                        <?php domainResellerTranslate('setting_email_unverified_enable') ?>
                    </label>
                </td>
                <td class="fieldarea">
                    <input type="checkbox" onclick="showDiv(this,'emailUnverifiedHide')"
                           name="emailUnverified[enable]" <?php if (isset($domain_reseller_management_setting['emailUnverified']['enable'])) echo 'checked'; ?>
                           value="1">
                </td>
            </tr>
            <tr class="emailUnverifiedHide" <?php if (!isset($domain_reseller_management_setting['emailUnverified']['enable'])) echo 'style="display: none"'; ?>>


                <td style="width: 25%" class="fieldlabel"><label><?php domainResellerTranslate('setting_department') ?></label></td>
                <td class="fieldarea">
                    <select name="emailUnverified[department]">
                        <?php
                        foreach ($department as $id => $name) {
                            if (isset($domain_reseller_management_setting['emailUnverified']['department']) && $id == $domain_reseller_management_setting['emailUnverified']['department']) {
                                echo '<option value="' . $id . '" selected="selected">' . $name . '</option>';
                            } else {
                                echo '<option value="' . $id . '">' . $name . '</option>';
                            }
                        }
                        ?>
                    </select>
                </td>
            </tr>
            <tr class="emailUnverifiedHide" <?php if (!isset($domain_reseller_management_setting['emailUnverified']['enable'])) echo 'style="display: none"'; ?>>
                <td style="width: 25%" class="fieldlabel">
                    <label><?php domainResellerTranslate('setting_email_unverified_failed_reply') ?></label>
                </td>
                <td class="fieldarea">
                    <input type="text" name="emailUnverified[failedReply]" style="width: 600px;"
                           value="<?php if (isset($domain_reseller_management_setting['emailUnverified']['failedReply'])) echo $domain_reseller_management_setting['emailUnverified']['failedReply'] ?>"/>
                    <div><?php domainResellerTranslate('setting_params_allow') ?> : <span>[$domain], [$email]</span>
                    </div>
                </td>
            </tr>
            <tr class="emailUnverifiedHide" <?php if (!isset($domain_reseller_management_setting['emailUnverified']['enable'])) echo 'style="display: none"'; ?>>
                <td style="width: 25%" class="fieldlabel">
                    <label><?php domainResellerTranslate('setting_ticket_status') ?></label>
                </td>
                <td class="fieldarea">
                    <select name="emailUnverified[failedStatus]">
                        <option name="Answered" <?php if (isset($domain_reseller_management_setting['emailUnverified']['failedStatus']) && $domain_reseller_management_setting['emailUnverified']['failedStatus'] == 'Answered') echo 'selected="selected"' ?>>
                            Answered
                        </option>
                        <option name="Open" <?php if (isset($domain_reseller_management_setting['emailUnverified']['failedStatus']) && $domain_reseller_management_setting['emailUnverified']['failedStatus'] == 'Open') echo 'selected="selected"' ?>>
                            Open
                        </option>
                        <option name="Customer-Reply" <?php if (isset($domain_reseller_management_setting['emailUnverified']['failedStatus']) && $domain_reseller_management_setting['emailUnverified']['failedStatus'] == 'Customer-Reply') echo 'selected="selected"' ?>>
                            Customer-Reply
                        </option>
                        <option name="In-Progress" <?php if (isset($domain_reseller_management_setting['emailUnverified']['failedStatus']) && $domain_reseller_management_setting['emailUnverified']['failedStatus'] == 'In-Progress') echo 'selected="selected"' ?>>
                            In-Progress
                        </option>
                        <option name="On Hold" <?php if (isset($domain_reseller_management_setting['emailUnverified']['failedStatus']) && $domain_reseller_management_setting['emailUnverified']['failedStatus'] == 'On Hold') echo 'selected="selected"' ?>>
                            On Hold
                        </option>
                        <option name="Closed" <?php if (isset($domain_reseller_management_setting['emailUnverified']['failedStatus']) && $domain_reseller_management_setting['emailUnverified']['failedStatus'] == 'Closed') echo 'selected="selected"' ?>>
                            Closed
                        </option>
                    </select>
                </td>
            </tr>

            <tr class="emailUnverifiedHide" <?php if (!isset($domain_reseller_management_setting['emailUnverified']['enable'])) echo 'style="display: none"'; ?>>
                <td style="width: 25%" class="fieldlabel"><label><?php domainResellerTranslate('setting_email_unverified_pending_reply') ?></label></td>
                <td class="fieldarea">
                    <input type="text" name="emailUnverified[pendingReply]" style="width: 600px;"
                           value="<?php if (isset($domain_reseller_management_setting['emailUnverified']['pendingReply'])) echo $domain_reseller_management_setting['emailUnverified']['pendingReply'] ?>"/>
                    <div><?php domainResellerTranslate('setting_params_allow') ?> : <span>[$domain], [$email]</span>
                    </div>
                </td>
            </tr>
            <tr class="emailUnverifiedHide" <?php if (!isset($domain_reseller_management_setting['emailUnverified']['enable'])) echo 'style="display: none"'; ?>>
                <td style="width: 25%" class="fieldlabel">
                    <label><?php domainResellerTranslate('setting_ticket_status') ?></label>
                </td>
                <td class="fieldarea">
                    <select name="emailUnverified[pendingStatus]">
                        <option name="Answered" <?php if (isset($domain_reseller_management_setting['emailUnverified']['pendingStatus']) && $domain_reseller_management_setting['emailUnverified']['pendingStatus'] == 'Answered') echo 'selected="selected"' ?>>
                            Answered
                        </option>
                        <option name="Open" <?php if (isset($domain_reseller_management_setting['emailUnverified']['pendingStatus']) && $domain_reseller_management_setting['emailUnverified']['pendingStatus'] == 'Open') echo 'selected="selected"' ?>>
                            Open
                        </option>
                        <option name="Customer-Reply" <?php if (isset($domain_reseller_management_setting['emailUnverified']['pendingStatus']) && $domain_reseller_management_setting['emailUnverified']['pendingStatus'] == 'Customer-Reply') echo 'selected="selected"' ?>>
                            Customer-Reply
                        </option>
                        <option name="In-Progress" <?php if (isset($domain_reseller_management_setting['emailUnverified']['pendingStatus']) && $domain_reseller_management_setting['emailUnverified']['pendingStatus'] == 'In-Progress') echo 'selected="selected"' ?>>
                            In-Progress
                        </option>
                        <option name="On Hold" <?php if (isset($domain_reseller_management_setting['emailUnverified']['pendingStatus']) && $domain_reseller_management_setting['emailUnverified']['pendingStatus'] == 'On Hold') echo 'selected="selected"' ?>>
                            On Hold
                        </option>
                        <option name="Closed" <?php if (isset($domain_reseller_management_setting['emailUnverified']['pendingStatus']) && $domain_reseller_management_setting['emailUnverified']['pendingStatus'] == 'Closed') echo 'selected="selected"' ?>>
                            Closed
                        </option>
                    </select>
                </td>
            </tr>
            </tbody>
        </table>
        <div class="btn-container">
            <input type="submit" name="emailUnverifiedSubmit" value="<?php domainResellerTranslate('submit') ?>"/>
        </div>
    </form>
</div>

<div class="protection setting">
    <form name="" method="post" action="<?php domainResellerGetBaseUrl('setting', 'protectionFailed'); ?>">
        <table class="form" width="100%" border="0" cellspacing="2" cellpadding="3">
            <tbody>
            <tr>
                <td class="fieldlabel"></td>
                <td class="fieldarea">بصورت پیش فرض WHMCS امکان خرید addons برای دامنه‌هایی با اعتبار بیش از یکسال را ندارد(محاسبات مالی این بخش برمبنای یکسال انجام می‌شود)، به همین دلیل در صورتی که مشتری برای دامنه با اعتبار بیش از یکسال اقدام به خرید سرویس "مخفی سازی WHOIS"، پس از پرداخت فاکتور این سرویس فعال نخواهد شد و از طریق تیکت به پرسنل برای پیگیری و اصلاح موضوع اطلاع رسانی می‌گردد. وجه سالهای مازاد باید بصورت دستی از مشتری دریافت شود.</td>
            </tr>
            <tr>
                <td style="width: 25%" class="fieldlabel">
                    <label>
                        <?php domainResellerTranslate('setting_protection_failed_enable') ?>
                    </label>
                </td>
                <td class="fieldarea">
                    <input type="checkbox" onclick="showDiv(this,'protectionFailedHide')"
                           name="protectionFailed[enable]" <?php if (isset($domain_reseller_management_setting['protectionFailed']['enable'])) echo 'checked'; ?>
                           value="1">
                </td>
            </tr>
            <tr class="protectionFailedHide" <?php if (!isset($domain_reseller_management_setting['protectionFailed']['enable'])) echo 'style="display: none"'; ?>>

                <td style="width: 25%" class="fieldlabel">
                    <label><?php domainResellerTranslate('setting_department') ?></label>
                </td>
                <td class="fieldarea">
                    <select name="protectionFailed[department]">
                        <?php
                        foreach ($department as $id => $name) {
                            if (isset($domain_reseller_management_setting['protectionFailed']['department']) && $id == $domain_reseller_management_setting['protectionFailed']['department']) {
                                echo '<option value="' . $id . '" selected="selected">' . $name . '</option>';
                            } else {
                                echo '<option value="' . $id . '">' . $name . '</option>';
                            }
                        }
                        ?>
                    </select>
                </td>
            </tr>
            <tr class="protectionFailedHide" <?php if (!isset($domain_reseller_management_setting['protectionFailed']['enable'])) echo 'style="display: none"'; ?>>
                <td style="width: 25%" class="fieldlabel">
                    <label><?php domainResellerTranslate('setting_protection_failed_reply') ?></label>
                </td>
                <td class="fieldarea">
                    <input type="text" name="protectionFailed[reply]" style="width: 600px;"
                           value="<?php if (isset($domain_reseller_management_setting['protectionFailed']['reply'])) echo $domain_reseller_management_setting['protectionFailed']['reply'] ?>"/>
                    <div><?php domainResellerTranslate('setting_params_allow') ?> : <span
                                style="text-align: left;direction: ltr">[$domain]</span></div>
                </td>
            </tr>
            <tr class="protectionFailedHide" <?php if (!isset($domain_reseller_management_setting['protectionFailed']['enable'])) echo 'style="display: none"'; ?>>

                <td style="width: 25%" class="fieldlabel">
                    <label><?php domainResellerTranslate('setting_ticket_status') ?></label>
                </td>
                <td class="fieldarea">
                    <select name="protectionFailed[status]">
                        <option name="Answered" <?php if (isset($domain_reseller_management_setting['protectionFailed']['status']) && $domain_reseller_management_setting['protectionFailed']['status'] == 'Answered') echo 'selected="selected"' ?>>
                            Answered
                        </option>
                        <option name="Open" <?php if (isset($domain_reseller_management_setting['protectionFailed']['status']) && $domain_reseller_management_setting['protectionFailed']['status'] == 'Open') echo 'selected="selected"' ?>>
                            Open
                        </option>
                        <option name="Customer-Reply" <?php if (isset($domain_reseller_management_setting['protectionFailed']['status']) && $domain_reseller_management_setting['protectionFailed']['status'] == 'Customer-Reply') echo 'selected="selected"' ?>>
                            Customer-Reply
                        </option>
                        <option name="In-Progress" <?php if (isset($domain_reseller_management_setting['protectionFailed']['status']) && $domain_reseller_management_setting['protectionFailed']['status'] == 'In-Progress') echo 'selected="selected"' ?>>
                            In-Progress
                        </option>
                        <option name="On Hold" <?php if (isset($domain_reseller_management_setting['protectionFailed']['status']) && $domain_reseller_management_setting['protectionFailed']['status'] == 'On Hold') echo 'selected="selected"' ?>>
                            On Hold
                        </option>
                        <option name="Closed" <?php if (isset($domain_reseller_management_setting['protectionFailed']['status']) && $domain_reseller_management_setting['protectionFailed']['status'] == 'Closed') echo 'selected="selected"' ?>>
                            Closed
                        </option>
                    </select>
                </td>
            </tr>
            </tbody>
        </table>
        <div class="btn-container">
            <input type="submit" name="protectionFailedSubmit" value="<?php domainResellerTranslate('submit') ?>"/>
        </div>
    </form>
</div>

<div class="charge setting">
    <form name="" method="post" action="<?php domainResellerGetBaseUrl('setting', 'chargeCheck'); ?>">
        <table class="form" width="100%" border="0" cellspacing="2" cellpadding="3">
            <tbody>
            <tr>
                <td class="fieldlabel"></td>
                <td class="fieldarea">اطلاع رسانی کم شدن شارژ نمایندگی</td>
            </tr>
            <tr>
                <td style="width: 25%" class="fieldlabel">
                    <label>
                        <?php domainResellerTranslate('setting_charge_check_enable') ?>
                    </label>
                </td>
                <td class="fieldarea">

                    <input type="checkbox" onclick="showDiv(this,'chargeCheckHide')"
                           name="chargeCheck[enable]" <?php if (isset($domain_reseller_management_setting['chargeCheck']['enable'])) echo 'checked'; ?>
                           value="1">
                </td>
            </tr>
            <tr class="chargeCheckHide" <?php if (!isset($domain_reseller_management_setting['chargeCheck']['enable'])) echo 'style="display: none"'; ?>>
                <td style="width: 25%" class="fieldlabel">

                    <label><?php domainResellerTranslate('setting_charge_check_amount') ?></label>
                </td>
                <td class="fieldarea">
                    <input type="text" name="chargeCheck[amount]" style="width: 600px;"
                           value="<?php if (isset($domain_reseller_management_setting['chargeCheck']['amount'])) echo $domain_reseller_management_setting['chargeCheck']['amount'] ?>"/> <?php domainResellerTranslate('rial') ?>

                </td>
            </tr>
            <tr class="chargeCheckHide" <?php if (!isset($domain_reseller_management_setting['chargeCheck']['enable'])) echo 'style="display: none"'; ?>>

                <td style="width: 25%" class="fieldlabel">
                    <label><?php domainResellerTranslate('setting_charge_check_admin') ?></label>
                </td>
                <td class="fieldarea">
                    <select name="chargeCheck[admin]">
                        <?php
                        foreach ($domain_reseller_management_admin as $admin) {
                            if (isset($domain_reseller_management_setting['chargeCheck']['admin']) && $domain_reseller_management_setting['chargeCheck']['admin'] == $admin->id) {
                                echo '<option value="' . $admin->id . '" selected="selected">' . $admin->username . '</option>';
                            } else {
                                echo '<option value="' . $admin->id . '">' . $admin->username . '</option>';
                            }
                        }
                        ?>
                    </select>
                </td>

            <tr class="chargeCheckHide" <?php if (!isset($domain_reseller_management_setting['chargeCheck']['enable'])) echo 'style="display: none"'; ?>>
                <td style="width: 25%" class="fieldlabel">
                    <label><?php domainResellerTranslate('setting_charge_check_period') ?></label>
                </td>
                <td class="fieldarea">
                    <select name="chargeCheck[period]">
                        <option value="1" <?php if (isset($domain_reseller_management_setting['chargeCheck']['period']) && $domain_reseller_management_setting['chargeCheck']['period'] == '1') echo 'selected="selected"' ?>><?php domainResellerTranslate('setting_charge_check_period_day') ?></option>
                        <option value="7" <?php if (isset($domain_reseller_management_setting['chargeCheck']['period']) && $domain_reseller_management_setting['chargeCheck']['period'] == '7') echo 'selected="selected"' ?>><?php domainResellerTranslate('setting_charge_check_period_week') ?></option>
                    </select>
                </td>

            </tr>
            </tbody>
        </table>
        <div class="btn-container">
            <input type="submit" name="chargeCheckSubmit" value="<?php domainResellerTranslate('submit') ?>"/>
        </div>
    </form>
</div>

<div class="promotion setting">
    <form name="" method="post" action="<?php domainResellerGetBaseUrl('setting', 'promotion'); ?>">
        <table class="form" width="100%" border="0" cellspacing="2" cellpadding="3">
            <tbody>
            <tr>
                <td class="fieldlabel"></td>
                <td class="fieldarea">در بازه‌های زمانی مختلف مرکز ثبت برای برخی از پسوندهای دامنه تخفیفاتی را ارایه می‌دهد، با فعال کردن این بخش بصورت خودکار نرخ‌های دارای تخفیف در WHMCS شما بروزرسانی می‌شوند و پس از پایان دوره‌ی تخفیف با نرخ‌های قبلی جایگزین می‌شوند.</td>
            </tr>
            <tr>
                <td style="width: 25%" class="fieldlabel">
                    <label>
                        <?php domainResellerTranslate('setting_promotion_enable') ?>
                    </label>
                </td>
                <td class="fieldarea">
                    <input type="checkbox"
                           name="promotion[enable]" <?php if (isset($domain_reseller_management_setting['promotion']['enable'])) echo 'checked'; ?>
                           value="1">
                </td>


            </tr>
            </tbody>
        </table>
        <div class="btn-container">
            <input type="submit" name="promotionSubmit" value="<?php domainResellerTranslate('submit') ?>"/>
        </div>
    </form>
</div>

<div class="contact setting">

    <form name="" method="post" action="<?php domainResellerGetBaseUrl('setting', 'contact'); ?>">
        <table class="form" width="100%" border="0" cellspacing="2" cellpadding="3">
            <tbody>
            <tr>
                <td class="fieldlabel" style="width: 45px"></td>
                <td class="fieldarea" colspan="5">در صورتی که به هردلیل امکان استفاده از مشخصات وارد شده توسط کاربر برای ثبت یا انتقال دامنه نباشد، این اطلاعات بصورت خودکار جایگزین آنها می‌شوند و عملیات ثبت یا انتقال انجام می‌شود.(غیر از ایمیل که همچنان آدرس ایمیل کاربر در دامنه ثبت می‌شود)</td>
            </tr>
            <tr>
                <td style="width: 45px;" class="fieldlabel">
                    <label><?php domainResellerTranslate('organization') ?> *</label>
                </td>
                <td class="fieldarea">
                    <input type="text" id="contact_organization" name="contact[organization]"
                           value="<?php if (isset($_POST['contact']['organization'])) echo $_POST['contact']['organization'] ?>"
                           required="required"/>
                </td>
                <td style="width: 45px;" class="fieldlabel">
                    <label><?php domainResellerTranslate('name') ?> *</label>
                </td>
                <td class="fieldarea">
                    <input type="text" id="contact_name" name="contact[name]"
                           value="<?php if (isset($_POST['contact']['name'])) echo $_POST['contact']['name'] ?>"
                           required="required"/>
                </td>
                <td style="width: 45px;" class="fieldlabel">
                    <label><?php domainResellerTranslate('address') ?> 1 *</label>
                </td>
                <td class="fieldarea">
                    <input type="text" id="contact_address1" name="contact[address_1]"
                           value="<?php if (isset($_POST['contact']['address_1'])) echo $_POST['contact']['address_1'] ?>"
                           required="required"/>
                </td>
            </tr>
            <tr>

                <td style="width: 45px;" class="fieldlabel">

                    <label><?php domainResellerTranslate('postal_code') ?> *</label>
                </td>
                <td class="fieldarea">
                    <input type="text" id="contact_postalCode" name="contact[postal_code]"
                           value="<?php if (isset($_POST['contact']['postal_code'])) echo $_POST['contact']['postal_code'] ?>"
                           required="required"/>
                </td>
                <td style="width: 45px;" class="fieldlabel">
                    <label><?php domainResellerTranslate('email') ?> *</label>
                </td>
                <td class="fieldarea">
                    <input type="email" id="contact_email" name="contact[email]"
                           value="<?php if (isset($_POST['contact']['email'])) echo $_POST['contact']['email'] ?>"
                           required="required"/>
                </td>
                <td style="width: 45px;" class="fieldlabel">
                    <label><?php domainResellerTranslate('phone') ?> *</label>
                </td>
                <td class="fieldarea">
                    <input type="tel" id="contact_phone" name="contact[phone]"
                           value="<?php if (isset($_POST['contact']['phone'])) echo $_POST['contact']['phone'] ?>"
                           required="required"/>
                </td>
            </tr>

            <tr>
                <td style="width: 45px;" class="fieldlabel">
                    <label><?php domainResellerTranslate('country') ?> *</label>
                </td>
                <td class="fieldarea">

                    <select id="contact_country" name="contact[country]">
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'AF') ? 'selected="selected"' : '' ?> value="AF">Afghanistan</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'AX') ? 'selected="selected"' : '' ?> value="AX">Åland Islands</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'AL') ? 'selected="selected"' : '' ?> value="AL">Albania</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'DZ') ? 'selected="selected"' : '' ?> value="DZ">Algeria</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'AS') ? 'selected="selected"' : '' ?> value="AS">American Samoa</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'AD') ? 'selected="selected"' : '' ?> value="AD">Andorra</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'AO') ? 'selected="selected"' : '' ?> value="AO">Angola</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'AI') ? 'selected="selected"' : '' ?> value="AI">Anguilla</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'AQ') ? 'selected="selected"' : '' ?> value="AQ">Antarctica</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'AG') ? 'selected="selected"' : '' ?> value="AG">Antigua &amp; Barbuda</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'AR') ? 'selected="selected"' : '' ?> value="AR">Argentina</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'AM') ? 'selected="selected"' : '' ?> value="AM">Armenia</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'AW') ? 'selected="selected"' : '' ?> value="AW">Aruba</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'AC') ? 'selected="selected"' : '' ?> value="AC">Ascension Island</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'AU') ? 'selected="selected"' : '' ?> value="AU">Australia</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'AT') ? 'selected="selected"' : '' ?> value="AT">Austria</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'AZ') ? 'selected="selected"' : '' ?> value="AZ">Azerbaijan</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'BS') ? 'selected="selected"' : '' ?> value="BS">Bahamas</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'BH') ? 'selected="selected"' : '' ?> value="BH">Bahrain</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'BD') ? 'selected="selected"' : '' ?> value="BD">Bangladesh</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'BB') ? 'selected="selected"' : '' ?> value="BB">Barbados</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'BY') ? 'selected="selected"' : '' ?> value="BY">Belarus</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'BE') ? 'selected="selected"' : '' ?> value="BE">Belgium</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'BZ') ? 'selected="selected"' : '' ?> value="BZ">Belize</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'BJ') ? 'selected="selected"' : '' ?> value="BJ">Benin</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'BM') ? 'selected="selected"' : '' ?> value="BM">Bermuda</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'BT') ? 'selected="selected"' : '' ?> value="BT">Bhutan</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'BO') ? 'selected="selected"' : '' ?> value="BO">Bolivia</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'BA') ? 'selected="selected"' : '' ?> value="BA">Bosnia &amp; Herzegovina</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'BW') ? 'selected="selected"' : '' ?> value="BW">Botswana</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'BR') ? 'selected="selected"' : '' ?> value="BR">Brazil</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'IO') ? 'selected="selected"' : '' ?> value="IO">British Indian Ocean Territory</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'VG') ? 'selected="selected"' : '' ?> value="VG">British Virgin Islands</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'BN') ? 'selected="selected"' : '' ?> value="BN">Brunei</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'BG') ? 'selected="selected"' : '' ?> value="BG">Bulgaria</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'BF') ? 'selected="selected"' : '' ?> value="BF">Burkina Faso</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'BI') ? 'selected="selected"' : '' ?> value="BI">Burundi</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'KH') ? 'selected="selected"' : '' ?> value="KH">Cambodia</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'CM') ? 'selected="selected"' : '' ?> value="CM">Cameroon</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'CA') ? 'selected="selected"' : '' ?> value="CA">Canada</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'IC') ? 'selected="selected"' : '' ?> value="IC">Canary Islands</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'CV') ? 'selected="selected"' : '' ?> value="CV">Cape Verde</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'BQ') ? 'selected="selected"' : '' ?> value="BQ">Caribbean Netherlands</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'KY') ? 'selected="selected"' : '' ?> value="KY">Cayman Islands</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'CF') ? 'selected="selected"' : '' ?> value="CF">Central African Republic</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'EA') ? 'selected="selected"' : '' ?> value="EA">Ceuta &amp; Melilla</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'TD') ? 'selected="selected"' : '' ?> value="TD">Chad</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'CL') ? 'selected="selected"' : '' ?> value="CL">Chile</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'CN') ? 'selected="selected"' : '' ?> value="CN">China</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'CX') ? 'selected="selected"' : '' ?> value="CX">Christmas Island</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'CC') ? 'selected="selected"' : '' ?> value="CC">Cocos (Keeling) Islands</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'CO') ? 'selected="selected"' : '' ?> value="CO">Colombia</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'KM') ? 'selected="selected"' : '' ?> value="KM">Comoros</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'CG') ? 'selected="selected"' : '' ?> value="CG">Congo - Brazzaville</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'CD') ? 'selected="selected"' : '' ?> value="CD">Congo - Kinshasa</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'CK') ? 'selected="selected"' : '' ?> value="CK">Cook Islands</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'CR') ? 'selected="selected"' : '' ?> value="CR">Costa Rica</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'CI') ? 'selected="selected"' : '' ?> value="CI">Côte d’Ivoire</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'HR') ? 'selected="selected"' : '' ?> value="HR">Croatia</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'CU') ? 'selected="selected"' : '' ?> value="CU">Cuba</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'CW') ? 'selected="selected"' : '' ?> value="CW">Curaçao</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'CY') ? 'selected="selected"' : '' ?> value="CY">Cyprus</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'CZ') ? 'selected="selected"' : '' ?> value="CZ">Czech Republic</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'DK') ? 'selected="selected"' : '' ?> value="DK">Denmark</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'DG') ? 'selected="selected"' : '' ?> value="DG">Diego Garcia</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'DJ') ? 'selected="selected"' : '' ?> value="DJ">Djibouti</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'DM') ? 'selected="selected"' : '' ?> value="DM">Dominica</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'DO') ? 'selected="selected"' : '' ?> value="DO">Dominican Republic</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'EC') ? 'selected="selected"' : '' ?> value="EC">Ecuador</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'EG') ? 'selected="selected"' : '' ?> value="EG">Egypt</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'SV') ? 'selected="selected"' : '' ?> value="SV">El Salvador</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'GQ') ? 'selected="selected"' : '' ?> value="GQ">Equatorial Guinea</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'ER') ? 'selected="selected"' : '' ?> value="ER">Eritrea</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'EE') ? 'selected="selected"' : '' ?> value="EE">Estonia</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'ET') ? 'selected="selected"' : '' ?> value="ET">Ethiopia</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'FK') ? 'selected="selected"' : '' ?> value="FK">Falkland Islands</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'FO') ? 'selected="selected"' : '' ?> value="FO">Faroe Islands</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'FJ') ? 'selected="selected"' : '' ?> value="FJ">Fiji</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'FI') ? 'selected="selected"' : '' ?> value="FI">Finland</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'FR') ? 'selected="selected"' : '' ?> value="FR">France</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'GF') ? 'selected="selected"' : '' ?> value="GF">French Guiana</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'PF') ? 'selected="selected"' : '' ?> value="PF">French Polynesia</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'TF') ? 'selected="selected"' : '' ?> value="TF">French Southern Territories</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'GA') ? 'selected="selected"' : '' ?> value="GA">Gabon</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'GM') ? 'selected="selected"' : '' ?> value="GM">Gambia</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'GE') ? 'selected="selected"' : '' ?> value="GE">Georgia</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'DE') ? 'selected="selected"' : '' ?> value="DE">Germany</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'GH') ? 'selected="selected"' : '' ?> value="GH">Ghana</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'GI') ? 'selected="selected"' : '' ?> value="GI">Gibraltar</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'GR') ? 'selected="selected"' : '' ?> value="GR">Greece</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'GL') ? 'selected="selected"' : '' ?> value="GL">Greenland</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'GD') ? 'selected="selected"' : '' ?> value="GD">Grenada</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'GP') ? 'selected="selected"' : '' ?> value="GP">Guadeloupe</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'GU') ? 'selected="selected"' : '' ?> value="GU">Guam</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'GT') ? 'selected="selected"' : '' ?> value="GT">Guatemala</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'GG') ? 'selected="selected"' : '' ?> value="GG">Guernsey</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'GN') ? 'selected="selected"' : '' ?> value="GN">Guinea</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'GW') ? 'selected="selected"' : '' ?> value="GW">Guinea-Bissau</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'GY') ? 'selected="selected"' : '' ?> value="GY">Guyana</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'HT') ? 'selected="selected"' : '' ?> value="HT">Haiti</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'HN') ? 'selected="selected"' : '' ?> value="HN">Honduras</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'HK') ? 'selected="selected"' : '' ?> value="HK">Hong Kong SAR China</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'HU') ? 'selected="selected"' : '' ?> value="HU">Hungary</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'IS') ? 'selected="selected"' : '' ?> value="IS">Iceland</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'IN') ? 'selected="selected"' : '' ?> value="IN">India</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'ID') ? 'selected="selected"' : '' ?> value="ID">Indonesia</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'IR') ? 'selected="selected"' : '' ?> value="IR" <?= (!isset($_POST['contact']['country'])) ? 'selected="selected"' : '' ?>>Iran</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'IQ') ? 'selected="selected"' : '' ?> value="IQ">Iraq</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'IE') ? 'selected="selected"' : '' ?> value="IE">Ireland</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'IM') ? 'selected="selected"' : '' ?> value="IM">Isle of Man</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'IL') ? 'selected="selected"' : '' ?> value="IL">Israel</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'IT') ? 'selected="selected"' : '' ?> value="IT">Italy</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'JM') ? 'selected="selected"' : '' ?> value="JM">Jamaica</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'JP') ? 'selected="selected"' : '' ?> value="JP">Japan</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'JE') ? 'selected="selected"' : '' ?> value="JE">Jersey</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'JO') ? 'selected="selected"' : '' ?> value="JO">Jordan</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'KZ') ? 'selected="selected"' : '' ?> value="KZ">Kazakhstan</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'KE') ? 'selected="selected"' : '' ?> value="KE">Kenya</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'KI') ? 'selected="selected"' : '' ?> value="KI">Kiribati</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'XK') ? 'selected="selected"' : '' ?> value="XK">Kosovo</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'KW') ? 'selected="selected"' : '' ?> value="KW">Kuwait</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'KG') ? 'selected="selected"' : '' ?> value="KG">Kyrgyzstan</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'LA') ? 'selected="selected"' : '' ?> value="LA">Laos</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'LV') ? 'selected="selected"' : '' ?> value="LV">Latvia</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'LB') ? 'selected="selected"' : '' ?> value="LB">Lebanon</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'LS') ? 'selected="selected"' : '' ?> value="LS">Lesotho</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'LR') ? 'selected="selected"' : '' ?> value="LR">Liberia</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'LY') ? 'selected="selected"' : '' ?> value="LY">Libya</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'LI') ? 'selected="selected"' : '' ?> value="LI">Liechtenstein</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'LT') ? 'selected="selected"' : '' ?> value="LT">Lithuania</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'LU') ? 'selected="selected"' : '' ?> value="LU">Luxembourg</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'MO') ? 'selected="selected"' : '' ?> value="MO">Macau SAR China</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'MK') ? 'selected="selected"' : '' ?> value="MK">Macedonia</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'MG') ? 'selected="selected"' : '' ?> value="MG">Madagascar</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'MW') ? 'selected="selected"' : '' ?> value="MW">Malawi</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'MY') ? 'selected="selected"' : '' ?> value="MY">Malaysia</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'MV') ? 'selected="selected"' : '' ?> value="MV">Maldives</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'ML') ? 'selected="selected"' : '' ?> value="ML">Mali</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'MT') ? 'selected="selected"' : '' ?> value="MT">Malta</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'MH') ? 'selected="selected"' : '' ?> value="MH">Marshall Islands</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'MQ') ? 'selected="selected"' : '' ?> value="MQ">Martinique</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'MR') ? 'selected="selected"' : '' ?> value="MR">Mauritania</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'MU') ? 'selected="selected"' : '' ?> value="MU">Mauritius</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'YT') ? 'selected="selected"' : '' ?> value="YT">Mayotte</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'MX') ? 'selected="selected"' : '' ?> value="MX">Mexico</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'FM') ? 'selected="selected"' : '' ?> value="FM">Micronesia</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'MD') ? 'selected="selected"' : '' ?> value="MD">Moldova</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'MC') ? 'selected="selected"' : '' ?> value="MC">Monaco</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'MN') ? 'selected="selected"' : '' ?> value="MN">Mongolia</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'ME') ? 'selected="selected"' : '' ?> value="ME">Montenegro</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'MS') ? 'selected="selected"' : '' ?> value="MS">Montserrat</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'MA') ? 'selected="selected"' : '' ?> value="MA">Morocco</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'MZ') ? 'selected="selected"' : '' ?> value="MZ">Mozambique</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'MM') ? 'selected="selected"' : '' ?> value="MM">Myanmar (Burma)</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'NA') ? 'selected="selected"' : '' ?> value="NA">Namibia</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'NR') ? 'selected="selected"' : '' ?> value="NR">Nauru</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'NP') ? 'selected="selected"' : '' ?> value="NP">Nepal</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'NL') ? 'selected="selected"' : '' ?> value="NL">Netherlands</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'NC') ? 'selected="selected"' : '' ?> value="NC">New Caledonia</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'NZ') ? 'selected="selected"' : '' ?> value="NZ">New Zealand</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'NI') ? 'selected="selected"' : '' ?> value="NI">Nicaragua</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'NE') ? 'selected="selected"' : '' ?> value="NE">Niger</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'NG') ? 'selected="selected"' : '' ?> value="NG">Nigeria</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'NU') ? 'selected="selected"' : '' ?> value="NU">Niue</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'NF') ? 'selected="selected"' : '' ?> value="NF">Norfolk Island</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'KP') ? 'selected="selected"' : '' ?> value="KP">North Korea</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'MP') ? 'selected="selected"' : '' ?> value="MP">Northern Mariana Islands</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'NO') ? 'selected="selected"' : '' ?> value="NO">Norway</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'OM') ? 'selected="selected"' : '' ?> value="OM">Oman</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'PK') ? 'selected="selected"' : '' ?> value="PK">Pakistan</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'PW') ? 'selected="selected"' : '' ?> value="PW">Palau</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'PS') ? 'selected="selected"' : '' ?> value="PS">Palestinian Territories</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'PA') ? 'selected="selected"' : '' ?> value="PA">Panama</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'PG') ? 'selected="selected"' : '' ?> value="PG">Papua New Guinea</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'PY') ? 'selected="selected"' : '' ?> value="PY">Paraguay</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'PE') ? 'selected="selected"' : '' ?> value="PE">Peru</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'PH') ? 'selected="selected"' : '' ?> value="PH">Philippines</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'PN') ? 'selected="selected"' : '' ?> value="PN">Pitcairn Islands</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'PL') ? 'selected="selected"' : '' ?> value="PL">Poland</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'PT') ? 'selected="selected"' : '' ?> value="PT">Portugal</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'PR') ? 'selected="selected"' : '' ?> value="PR">Puerto Rico</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'QA') ? 'selected="selected"' : '' ?> value="QA">Qatar</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'RE') ? 'selected="selected"' : '' ?> value="RE">Réunion</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'RO') ? 'selected="selected"' : '' ?> value="RO">Romania</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'RU') ? 'selected="selected"' : '' ?> value="RU">Russia</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'RW') ? 'selected="selected"' : '' ?> value="RW">Rwanda</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'WS') ? 'selected="selected"' : '' ?> value="WS">Samoa</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'SM') ? 'selected="selected"' : '' ?> value="SM">San Marino</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'ST') ? 'selected="selected"' : '' ?> value="ST">São Tomé &amp; Príncipe</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'SA') ? 'selected="selected"' : '' ?> value="SA">Saudi Arabia</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'SN') ? 'selected="selected"' : '' ?> value="SN">Senegal</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'RS') ? 'selected="selected"' : '' ?> value="RS">Serbia</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'SC') ? 'selected="selected"' : '' ?> value="SC">Seychelles</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'SL') ? 'selected="selected"' : '' ?> value="SL">Sierra Leone</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'SG') ? 'selected="selected"' : '' ?> value="SG">Singapore</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'SX') ? 'selected="selected"' : '' ?> value="SX">Sint Maarten</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'SK') ? 'selected="selected"' : '' ?> value="SK">Slovakia</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'SI') ? 'selected="selected"' : '' ?> value="SI">Slovenia</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'SB') ? 'selected="selected"' : '' ?> value="SB">Solomon Islands</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'SO') ? 'selected="selected"' : '' ?> value="SO">Somalia</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'ZA') ? 'selected="selected"' : '' ?> value="ZA">South Africa</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'GS') ? 'selected="selected"' : '' ?> value="GS">South Georgia &amp; South Sandwich Islands</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'KR') ? 'selected="selected"' : '' ?> value="KR">South Korea</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'SS') ? 'selected="selected"' : '' ?> value="SS">South Sudan</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'ES') ? 'selected="selected"' : '' ?> value="ES">Spain</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'LK') ? 'selected="selected"' : '' ?> value="LK">Sri Lanka</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'BL') ? 'selected="selected"' : '' ?> value="BL">St. Barthélemy</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'SH') ? 'selected="selected"' : '' ?> value="SH">St. Helena</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'KN') ? 'selected="selected"' : '' ?> value="KN">St. Kitts &amp; Nevis</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'LC') ? 'selected="selected"' : '' ?> value="LC">St. Lucia</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'MF') ? 'selected="selected"' : '' ?> value="MF">St. Martin</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'PM') ? 'selected="selected"' : '' ?> value="PM">St. Pierre &amp; Miquelon</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'VC') ? 'selected="selected"' : '' ?> value="VC">St. Vincent &amp; Grenadines</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'SD') ? 'selected="selected"' : '' ?> value="SD">Sudan</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'SR') ? 'selected="selected"' : '' ?> value="SR">Suriname</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'SJ') ? 'selected="selected"' : '' ?> value="SJ">Svalbard &amp; Jan Mayen</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'SZ') ? 'selected="selected"' : '' ?> value="SZ">Swaziland</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'SE') ? 'selected="selected"' : '' ?> value="SE">Sweden</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'CH') ? 'selected="selected"' : '' ?> value="CH">Switzerland</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'SY') ? 'selected="selected"' : '' ?> value="SY">Syria</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'TW') ? 'selected="selected"' : '' ?> value="TW">Taiwan</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'TJ') ? 'selected="selected"' : '' ?> value="TJ">Tajikistan</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'TZ') ? 'selected="selected"' : '' ?> value="TZ">Tanzania</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'TH') ? 'selected="selected"' : '' ?> value="TH">Thailand</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'TL') ? 'selected="selected"' : '' ?> value="TL">Timor-Leste</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'TG') ? 'selected="selected"' : '' ?> value="TG">Togo</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'TK') ? 'selected="selected"' : '' ?> value="TK">Tokelau</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'TO') ? 'selected="selected"' : '' ?> value="TO">Tonga</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'TT') ? 'selected="selected"' : '' ?> value="TT">Trinidad &amp; Tobago</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'TA') ? 'selected="selected"' : '' ?> value="TA">Tristan da Cunha</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'TN') ? 'selected="selected"' : '' ?> value="TN">Tunisia</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'TR') ? 'selected="selected"' : '' ?> value="TR">Turkey</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'TM') ? 'selected="selected"' : '' ?> value="TM">Turkmenistan</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'TC') ? 'selected="selected"' : '' ?> value="TC">Turks &amp; Caicos Islands</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'TV') ? 'selected="selected"' : '' ?> value="TV">Tuvalu</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'UM') ? 'selected="selected"' : '' ?> value="UM">U.S. Outlying Islands</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'VI') ? 'selected="selected"' : '' ?> value="VI">U.S. Virgin Islands</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'UG') ? 'selected="selected"' : '' ?> value="UG">Uganda</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'UA') ? 'selected="selected"' : '' ?> value="UA">Ukraine</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'AE') ? 'selected="selected"' : '' ?> value="AE">United Arab Emirates</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'GB') ? 'selected="selected"' : '' ?> value="GB">United Kingdom</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'US') ? 'selected="selected"' : '' ?> value="US">United States</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'UY') ? 'selected="selected"' : '' ?> value="UY">Uruguay</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'UZ') ? 'selected="selected"' : '' ?> value="UZ">Uzbekistan</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'VU') ? 'selected="selected"' : '' ?> value="VU">Vanuatu</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'VA') ? 'selected="selected"' : '' ?> value="VA">Vatican City</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'VE') ? 'selected="selected"' : '' ?> value="VE">Venezuela</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'VN') ? 'selected="selected"' : '' ?> value="VN">Vietnam</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'WF') ? 'selected="selected"' : '' ?> value="WF">Wallis &amp; Futuna</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'EH') ? 'selected="selected"' : '' ?> value="EH">Western Sahara</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'YE') ? 'selected="selected"' : '' ?> value="YE">Yemen</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'ZM') ? 'selected="selected"' : '' ?> value="ZM">Zambia</option>
                        <option <?= (isset($_POST['contact']['country']) && $_POST['contact']['country'] == 'ZW') ? 'selected="selected"' : '' ?> value="ZW">Zimbabwe</option>
                    </select>
                </td>

                <td style="width: 45px;" class="fieldlabel">

                    <label><?php domainResellerTranslate('city') ?> *</label>
                </td>
                <td class="fieldarea">
                    <input type="text" id="contact_city" name="contact[city]"
                           value="<?php if (isset($_POST['contact']['city'])) echo $_POST['contact']['city'] ?>"
                           required="required"/>
                </td>
                <td style="width: 45px;" class="fieldlabel"></td>
                <td class="fieldarea"></td>
            </tr>
            </tbody>
        </table>
        <div class="btn-container">
                <input type="submit" name="contactSubmit" value="<?php domainResellerTranslate('submit') ?>"/>
        </div>

    </form>

</div>


<div class="contact setting">

    <form name="" method="post" action="<?php domainResellerGetBaseUrl('setting', 'sanctionContact'); ?>">
        <table class="form" width="100%" border="0" cellspacing="2" cellpadding="3">
            <tbody>
            <tr>
                <td class="fieldlabel" style="width: 45px"></td>
                <td class="fieldarea" colspan="5">امکان استفاده از مشخصات ایرانی در برخی از پسوندهای جدید دامنه(موسوم به NewGTLD) که توسط شرکت‌های آمریکایی پیشیبانی میشوند بدلیل تحریم وجود ندارد. در صورتی که کاربر در هنگان ثبت یا انتقال این پسوندها از مشخصات ایرانی استفاده نماید، بصورت خودکار این مشخصات جایگزین آن خواهد شد.(غیر از ایمیل که همچنان آدرس ایمیل کاربر در دامنه ثبت می‌شود)</td>
            </tr>
            <tr>
                <td style="width: 45px;" class="fieldlabel">
                    <label><?php domainResellerTranslate('organization') ?> *</label>
                </td>
                <td class="fieldarea">
                    <input type="text" id="sanctionContact_organization" name="sanctionContact[organization]"
                           value="<?php if (isset($_POST['sanctionContact']['organization'])) echo $_POST['sanctionContact']['organization'] ?>"
                           required="required"/>
                </td>
                <td style="width: 45px;" class="fieldlabel">
                    <label><?php domainResellerTranslate('name') ?> *</label>
                </td>
                <td class="fieldarea">
                    <input type="text" id="sanctionContact" name="sanctionContact[name]"
                           value="<?php if (isset($_POST['sanctionContact']['name'])) echo $_POST['sanctionContact']['name'] ?>"
                           required="required"/>
                </td>
                <td style="width: 45px;" class="fieldlabel">
                    <label><?php domainResellerTranslate('address') ?> 1 *</label>
                </td>
                <td class="fieldarea">
                    <input type="text" id="sanctionContact_address1" name="sanctionContact[address_1]"
                           value="<?php if (isset($_POST['sanctionContact']['address_1'])) echo $_POST['sanctionContact']['address_1'] ?>"
                           required="required"/>
                </td>
            </tr>
            <tr>

                <td style="width: 45px;" class="fieldlabel">

                    <label><?php domainResellerTranslate('postal_code') ?> *</label>
                </td>
                <td class="fieldarea">
                    <input type="text" id="sanctionContact_postalCode" name="sanctionContact[postal_code]"
                           value="<?php if (isset($_POST['sanctionContact']['postal_code'])) echo $_POST['sanctionContact']['postal_code'] ?>"
                           required="required"/>
                </td>
                <td style="width: 45px;" class="fieldlabel">
                    <label><?php domainResellerTranslate('email') ?> *</label>
                </td>
                <td class="fieldarea">
                    <input type="email" id="sanctionContact_email" name="sanctionContact[email]"
                           value="<?php if (isset($_POST['sanctionContact']['email'])) echo $_POST['sanctionContact']['email'] ?>"
                           required="required"/>
                </td>
                <td style="width: 45px;" class="fieldlabel">
                    <label><?php domainResellerTranslate('phone') ?> *</label>
                </td>
                <td class="fieldarea">
                    <input type="tel" id="sanctionContact_phone" name="sanctionContact[phone]"
                           value="<?php if (isset($_POST['sanctionContact']['phone'])) echo $_POST['sanctionContact']['phone'] ?>"
                           required="required"/>
                </td>
            </tr>

            <tr>
                <td style="width: 45px;" class="fieldlabel">
                    <label><?php domainResellerTranslate('country') ?> *</label>
                </td>
                <td class="fieldarea">
                    <select id="sanctionContact_country" name="sanctionContact[country]">
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'AF') ? 'selected="selected"' : '' ?> value="AF">Afghanistan</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'AX') ? 'selected="selected"' : '' ?> value="AX">Åland Islands</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'AL') ? 'selected="selected"' : '' ?> value="AL">Albania</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'DZ') ? 'selected="selected"' : '' ?> value="DZ">Algeria</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'AS') ? 'selected="selected"' : '' ?> value="AS">American Samoa</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'AD') ? 'selected="selected"' : '' ?> value="AD">Andorra</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'AO') ? 'selected="selected"' : '' ?> value="AO">Angola</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'AI') ? 'selected="selected"' : '' ?> value="AI">Anguilla</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'AQ') ? 'selected="selected"' : '' ?> value="AQ">Antarctica</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'AG') ? 'selected="selected"' : '' ?> value="AG">Antigua &amp; Barbuda</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'AR') ? 'selected="selected"' : '' ?> value="AR">Argentina</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'AM') ? 'selected="selected"' : '' ?> value="AM">Armenia</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'AW') ? 'selected="selected"' : '' ?> value="AW">Aruba</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'AC') ? 'selected="selected"' : '' ?> value="AC">Ascension Island</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'AU') ? 'selected="selected"' : '' ?> value="AU">Australia</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'AT') ? 'selected="selected"' : '' ?> value="AT">Austria</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'AZ') ? 'selected="selected"' : '' ?> value="AZ">Azerbaijan</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'BS') ? 'selected="selected"' : '' ?> value="BS">Bahamas</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'BH') ? 'selected="selected"' : '' ?> value="BH">Bahrain</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'BD') ? 'selected="selected"' : '' ?> value="BD">Bangladesh</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'BB') ? 'selected="selected"' : '' ?> value="BB">Barbados</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'BY') ? 'selected="selected"' : '' ?> value="BY">Belarus</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'BE') ? 'selected="selected"' : '' ?> value="BE">Belgium</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'BZ') ? 'selected="selected"' : '' ?> value="BZ">Belize</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'BJ') ? 'selected="selected"' : '' ?> value="BJ">Benin</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'BM') ? 'selected="selected"' : '' ?> value="BM">Bermuda</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'BT') ? 'selected="selected"' : '' ?> value="BT">Bhutan</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'BO') ? 'selected="selected"' : '' ?> value="BO">Bolivia</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'BA') ? 'selected="selected"' : '' ?> value="BA">Bosnia &amp; Herzegovina</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'BW') ? 'selected="selected"' : '' ?> value="BW">Botswana</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'BR') ? 'selected="selected"' : '' ?> value="BR">Brazil</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'IO') ? 'selected="selected"' : '' ?> value="IO">British Indian Ocean Territory</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'VG') ? 'selected="selected"' : '' ?> value="VG">British Virgin Islands</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'BN') ? 'selected="selected"' : '' ?> value="BN">Brunei</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'BG') ? 'selected="selected"' : '' ?> value="BG">Bulgaria</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'BF') ? 'selected="selected"' : '' ?> value="BF">Burkina Faso</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'BI') ? 'selected="selected"' : '' ?> value="BI">Burundi</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'KH') ? 'selected="selected"' : '' ?> value="KH">Cambodia</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'CM') ? 'selected="selected"' : '' ?> value="CM">Cameroon</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'CA') ? 'selected="selected"' : '' ?> value="CA">Canada</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'IC') ? 'selected="selected"' : '' ?> value="IC">Canary Islands</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'CV') ? 'selected="selected"' : '' ?> value="CV">Cape Verde</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'BQ') ? 'selected="selected"' : '' ?> value="BQ">Caribbean Netherlands</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'KY') ? 'selected="selected"' : '' ?> value="KY">Cayman Islands</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'CF') ? 'selected="selected"' : '' ?> value="CF">Central African Republic</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'EA') ? 'selected="selected"' : '' ?> value="EA">Ceuta &amp; Melilla</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'TD') ? 'selected="selected"' : '' ?> value="TD">Chad</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'CL') ? 'selected="selected"' : '' ?> value="CL">Chile</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'CN') ? 'selected="selected"' : '' ?> value="CN">China</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'CX') ? 'selected="selected"' : '' ?> value="CX">Christmas Island</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'CC') ? 'selected="selected"' : '' ?> value="CC">Cocos (Keeling) Islands</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'CO') ? 'selected="selected"' : '' ?> value="CO">Colombia</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'KM') ? 'selected="selected"' : '' ?> value="KM">Comoros</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'CG') ? 'selected="selected"' : '' ?> value="CG">Congo - Brazzaville</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'CD') ? 'selected="selected"' : '' ?> value="CD">Congo - Kinshasa</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'CK') ? 'selected="selected"' : '' ?> value="CK">Cook Islands</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'CR') ? 'selected="selected"' : '' ?> value="CR">Costa Rica</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'CI') ? 'selected="selected"' : '' ?> value="CI">Côte d’Ivoire</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'HR') ? 'selected="selected"' : '' ?> value="HR">Croatia</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'CU') ? 'selected="selected"' : '' ?> value="CU">Cuba</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'CW') ? 'selected="selected"' : '' ?> value="CW">Curaçao</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'CY') ? 'selected="selected"' : '' ?> value="CY">Cyprus</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'CZ') ? 'selected="selected"' : '' ?> value="CZ">Czech Republic</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'DK') ? 'selected="selected"' : '' ?> value="DK">Denmark</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'DG') ? 'selected="selected"' : '' ?> value="DG">Diego Garcia</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'DJ') ? 'selected="selected"' : '' ?> value="DJ">Djibouti</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'DM') ? 'selected="selected"' : '' ?> value="DM">Dominica</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'DO') ? 'selected="selected"' : '' ?> value="DO">Dominican Republic</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'EC') ? 'selected="selected"' : '' ?> value="EC">Ecuador</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'EG') ? 'selected="selected"' : '' ?> value="EG">Egypt</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'SV') ? 'selected="selected"' : '' ?> value="SV">El Salvador</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'GQ') ? 'selected="selected"' : '' ?> value="GQ">Equatorial Guinea</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'ER') ? 'selected="selected"' : '' ?> value="ER">Eritrea</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'EE') ? 'selected="selected"' : '' ?> value="EE">Estonia</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'ET') ? 'selected="selected"' : '' ?> value="ET">Ethiopia</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'FK') ? 'selected="selected"' : '' ?> value="FK">Falkland Islands</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'FO') ? 'selected="selected"' : '' ?> value="FO">Faroe Islands</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'FJ') ? 'selected="selected"' : '' ?> value="FJ">Fiji</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'FI') ? 'selected="selected"' : '' ?> value="FI">Finland</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'FR') ? 'selected="selected"' : '' ?> value="FR">France</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'GF') ? 'selected="selected"' : '' ?> value="GF">French Guiana</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'PF') ? 'selected="selected"' : '' ?> value="PF">French Polynesia</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'TF') ? 'selected="selected"' : '' ?> value="TF">French Southern Territories</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'GA') ? 'selected="selected"' : '' ?> value="GA">Gabon</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'GM') ? 'selected="selected"' : '' ?> value="GM">Gambia</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'GE') ? 'selected="selected"' : '' ?> value="GE">Georgia</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'DE') ? 'selected="selected"' : '' ?> value="DE">Germany</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'GH') ? 'selected="selected"' : '' ?> value="GH">Ghana</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'GI') ? 'selected="selected"' : '' ?> value="GI">Gibraltar</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'GR') ? 'selected="selected"' : '' ?> value="GR">Greece</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'GL') ? 'selected="selected"' : '' ?> value="GL">Greenland</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'GD') ? 'selected="selected"' : '' ?> value="GD">Grenada</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'GP') ? 'selected="selected"' : '' ?> value="GP">Guadeloupe</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'GU') ? 'selected="selected"' : '' ?> value="GU">Guam</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'GT') ? 'selected="selected"' : '' ?> value="GT">Guatemala</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'GG') ? 'selected="selected"' : '' ?> value="GG">Guernsey</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'GN') ? 'selected="selected"' : '' ?> value="GN">Guinea</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'GW') ? 'selected="selected"' : '' ?> value="GW">Guinea-Bissau</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'GY') ? 'selected="selected"' : '' ?> value="GY">Guyana</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'HT') ? 'selected="selected"' : '' ?> value="HT">Haiti</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'HN') ? 'selected="selected"' : '' ?> value="HN">Honduras</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'HK') ? 'selected="selected"' : '' ?> value="HK">Hong Kong SAR China</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'HU') ? 'selected="selected"' : '' ?> value="HU">Hungary</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'IS') ? 'selected="selected"' : '' ?> value="IS">Iceland</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'IN') ? 'selected="selected"' : '' ?> value="IN">India</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'ID') ? 'selected="selected"' : '' ?> value="ID">Indonesia</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'IR') ? 'selected="selected"' : '' ?> value="IR" <?= (!isset($_POST['sanctionContact']['country'])) ? 'selected="selected"' : '' ?>>Iran</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'IQ') ? 'selected="selected"' : '' ?> value="IQ">Iraq</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'IE') ? 'selected="selected"' : '' ?> value="IE">Ireland</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'IM') ? 'selected="selected"' : '' ?> value="IM">Isle of Man</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'IL') ? 'selected="selected"' : '' ?> value="IL">Israel</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'IT') ? 'selected="selected"' : '' ?> value="IT">Italy</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'JM') ? 'selected="selected"' : '' ?> value="JM">Jamaica</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'JP') ? 'selected="selected"' : '' ?> value="JP">Japan</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'JE') ? 'selected="selected"' : '' ?> value="JE">Jersey</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'JO') ? 'selected="selected"' : '' ?> value="JO">Jordan</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'KZ') ? 'selected="selected"' : '' ?> value="KZ">Kazakhstan</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'KE') ? 'selected="selected"' : '' ?> value="KE">Kenya</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'KI') ? 'selected="selected"' : '' ?> value="KI">Kiribati</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'XK') ? 'selected="selected"' : '' ?> value="XK">Kosovo</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'KW') ? 'selected="selected"' : '' ?> value="KW">Kuwait</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'KG') ? 'selected="selected"' : '' ?> value="KG">Kyrgyzstan</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'LA') ? 'selected="selected"' : '' ?> value="LA">Laos</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'LV') ? 'selected="selected"' : '' ?> value="LV">Latvia</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'LB') ? 'selected="selected"' : '' ?> value="LB">Lebanon</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'LS') ? 'selected="selected"' : '' ?> value="LS">Lesotho</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'LR') ? 'selected="selected"' : '' ?> value="LR">Liberia</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'LY') ? 'selected="selected"' : '' ?> value="LY">Libya</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'LI') ? 'selected="selected"' : '' ?> value="LI">Liechtenstein</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'LT') ? 'selected="selected"' : '' ?> value="LT">Lithuania</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'LU') ? 'selected="selected"' : '' ?> value="LU">Luxembourg</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'MO') ? 'selected="selected"' : '' ?> value="MO">Macau SAR China</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'MK') ? 'selected="selected"' : '' ?> value="MK">Macedonia</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'MG') ? 'selected="selected"' : '' ?> value="MG">Madagascar</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'MW') ? 'selected="selected"' : '' ?> value="MW">Malawi</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'MY') ? 'selected="selected"' : '' ?> value="MY">Malaysia</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'MV') ? 'selected="selected"' : '' ?> value="MV">Maldives</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'ML') ? 'selected="selected"' : '' ?> value="ML">Mali</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'MT') ? 'selected="selected"' : '' ?> value="MT">Malta</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'MH') ? 'selected="selected"' : '' ?> value="MH">Marshall Islands</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'MQ') ? 'selected="selected"' : '' ?> value="MQ">Martinique</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'MR') ? 'selected="selected"' : '' ?> value="MR">Mauritania</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'MU') ? 'selected="selected"' : '' ?> value="MU">Mauritius</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'YT') ? 'selected="selected"' : '' ?> value="YT">Mayotte</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'MX') ? 'selected="selected"' : '' ?> value="MX">Mexico</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'FM') ? 'selected="selected"' : '' ?> value="FM">Micronesia</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'MD') ? 'selected="selected"' : '' ?> value="MD">Moldova</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'MC') ? 'selected="selected"' : '' ?> value="MC">Monaco</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'MN') ? 'selected="selected"' : '' ?> value="MN">Mongolia</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'ME') ? 'selected="selected"' : '' ?> value="ME">Montenegro</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'MS') ? 'selected="selected"' : '' ?> value="MS">Montserrat</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'MA') ? 'selected="selected"' : '' ?> value="MA">Morocco</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'MZ') ? 'selected="selected"' : '' ?> value="MZ">Mozambique</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'MM') ? 'selected="selected"' : '' ?> value="MM">Myanmar (Burma)</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'NA') ? 'selected="selected"' : '' ?> value="NA">Namibia</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'NR') ? 'selected="selected"' : '' ?> value="NR">Nauru</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'NP') ? 'selected="selected"' : '' ?> value="NP">Nepal</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'NL') ? 'selected="selected"' : '' ?> value="NL">Netherlands</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'NC') ? 'selected="selected"' : '' ?> value="NC">New Caledonia</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'NZ') ? 'selected="selected"' : '' ?> value="NZ">New Zealand</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'NI') ? 'selected="selected"' : '' ?> value="NI">Nicaragua</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'NE') ? 'selected="selected"' : '' ?> value="NE">Niger</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'NG') ? 'selected="selected"' : '' ?> value="NG">Nigeria</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'NU') ? 'selected="selected"' : '' ?> value="NU">Niue</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'NF') ? 'selected="selected"' : '' ?> value="NF">Norfolk Island</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'KP') ? 'selected="selected"' : '' ?> value="KP">North Korea</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'MP') ? 'selected="selected"' : '' ?> value="MP">Northern Mariana Islands</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'NO') ? 'selected="selected"' : '' ?> value="NO">Norway</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'OM') ? 'selected="selected"' : '' ?> value="OM">Oman</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'PK') ? 'selected="selected"' : '' ?> value="PK">Pakistan</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'PW') ? 'selected="selected"' : '' ?> value="PW">Palau</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'PS') ? 'selected="selected"' : '' ?> value="PS">Palestinian Territories</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'PA') ? 'selected="selected"' : '' ?> value="PA">Panama</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'PG') ? 'selected="selected"' : '' ?> value="PG">Papua New Guinea</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'PY') ? 'selected="selected"' : '' ?> value="PY">Paraguay</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'PE') ? 'selected="selected"' : '' ?> value="PE">Peru</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'PH') ? 'selected="selected"' : '' ?> value="PH">Philippines</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'PN') ? 'selected="selected"' : '' ?> value="PN">Pitcairn Islands</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'PL') ? 'selected="selected"' : '' ?> value="PL">Poland</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'PT') ? 'selected="selected"' : '' ?> value="PT">Portugal</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'PR') ? 'selected="selected"' : '' ?> value="PR">Puerto Rico</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'QA') ? 'selected="selected"' : '' ?> value="QA">Qatar</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'RE') ? 'selected="selected"' : '' ?> value="RE">Réunion</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'RO') ? 'selected="selected"' : '' ?> value="RO">Romania</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'RU') ? 'selected="selected"' : '' ?> value="RU">Russia</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'RW') ? 'selected="selected"' : '' ?> value="RW">Rwanda</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'WS') ? 'selected="selected"' : '' ?> value="WS">Samoa</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'SM') ? 'selected="selected"' : '' ?> value="SM">San Marino</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'ST') ? 'selected="selected"' : '' ?> value="ST">São Tomé &amp; Príncipe</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'SA') ? 'selected="selected"' : '' ?> value="SA">Saudi Arabia</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'SN') ? 'selected="selected"' : '' ?> value="SN">Senegal</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'RS') ? 'selected="selected"' : '' ?> value="RS">Serbia</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'SC') ? 'selected="selected"' : '' ?> value="SC">Seychelles</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'SL') ? 'selected="selected"' : '' ?> value="SL">Sierra Leone</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'SG') ? 'selected="selected"' : '' ?> value="SG">Singapore</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'SX') ? 'selected="selected"' : '' ?> value="SX">Sint Maarten</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'SK') ? 'selected="selected"' : '' ?> value="SK">Slovakia</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'SI') ? 'selected="selected"' : '' ?> value="SI">Slovenia</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'SB') ? 'selected="selected"' : '' ?> value="SB">Solomon Islands</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'SO') ? 'selected="selected"' : '' ?> value="SO">Somalia</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'ZA') ? 'selected="selected"' : '' ?> value="ZA">South Africa</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'GS') ? 'selected="selected"' : '' ?> value="GS">South Georgia &amp; South Sandwich Islands</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'KR') ? 'selected="selected"' : '' ?> value="KR">South Korea</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'SS') ? 'selected="selected"' : '' ?> value="SS">South Sudan</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'ES') ? 'selected="selected"' : '' ?> value="ES">Spain</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'LK') ? 'selected="selected"' : '' ?> value="LK">Sri Lanka</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'BL') ? 'selected="selected"' : '' ?> value="BL">St. Barthélemy</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'SH') ? 'selected="selected"' : '' ?> value="SH">St. Helena</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'KN') ? 'selected="selected"' : '' ?> value="KN">St. Kitts &amp; Nevis</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'LC') ? 'selected="selected"' : '' ?> value="LC">St. Lucia</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'MF') ? 'selected="selected"' : '' ?> value="MF">St. Martin</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'PM') ? 'selected="selected"' : '' ?> value="PM">St. Pierre &amp; Miquelon</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'VC') ? 'selected="selected"' : '' ?> value="VC">St. Vincent &amp; Grenadines</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'SD') ? 'selected="selected"' : '' ?> value="SD">Sudan</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'SR') ? 'selected="selected"' : '' ?> value="SR">Suriname</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'SJ') ? 'selected="selected"' : '' ?> value="SJ">Svalbard &amp; Jan Mayen</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'SZ') ? 'selected="selected"' : '' ?> value="SZ">Swaziland</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'SE') ? 'selected="selected"' : '' ?> value="SE">Sweden</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'CH') ? 'selected="selected"' : '' ?> value="CH">Switzerland</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'SY') ? 'selected="selected"' : '' ?> value="SY">Syria</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'TW') ? 'selected="selected"' : '' ?> value="TW">Taiwan</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'TJ') ? 'selected="selected"' : '' ?> value="TJ">Tajikistan</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'TZ') ? 'selected="selected"' : '' ?> value="TZ">Tanzania</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'TH') ? 'selected="selected"' : '' ?> value="TH">Thailand</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'TL') ? 'selected="selected"' : '' ?> value="TL">Timor-Leste</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'TG') ? 'selected="selected"' : '' ?> value="TG">Togo</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'TK') ? 'selected="selected"' : '' ?> value="TK">Tokelau</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'TO') ? 'selected="selected"' : '' ?> value="TO">Tonga</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'TT') ? 'selected="selected"' : '' ?> value="TT">Trinidad &amp; Tobago</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'TA') ? 'selected="selected"' : '' ?> value="TA">Tristan da Cunha</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'TN') ? 'selected="selected"' : '' ?> value="TN">Tunisia</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'TR') ? 'selected="selected"' : '' ?> value="TR">Turkey</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'TM') ? 'selected="selected"' : '' ?> value="TM">Turkmenistan</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'TC') ? 'selected="selected"' : '' ?> value="TC">Turks &amp; Caicos Islands</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'TV') ? 'selected="selected"' : '' ?> value="TV">Tuvalu</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'UM') ? 'selected="selected"' : '' ?> value="UM">U.S. Outlying Islands</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'VI') ? 'selected="selected"' : '' ?> value="VI">U.S. Virgin Islands</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'UG') ? 'selected="selected"' : '' ?> value="UG">Uganda</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'UA') ? 'selected="selected"' : '' ?> value="UA">Ukraine</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'AE') ? 'selected="selected"' : '' ?> value="AE">United Arab Emirates</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'GB') ? 'selected="selected"' : '' ?> value="GB">United Kingdom</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'US') ? 'selected="selected"' : '' ?> value="US">United States</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'UY') ? 'selected="selected"' : '' ?> value="UY">Uruguay</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'UZ') ? 'selected="selected"' : '' ?> value="UZ">Uzbekistan</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'VU') ? 'selected="selected"' : '' ?> value="VU">Vanuatu</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'VA') ? 'selected="selected"' : '' ?> value="VA">Vatican City</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'VE') ? 'selected="selected"' : '' ?> value="VE">Venezuela</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'VN') ? 'selected="selected"' : '' ?> value="VN">Vietnam</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'WF') ? 'selected="selected"' : '' ?> value="WF">Wallis &amp; Futuna</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'EH') ? 'selected="selected"' : '' ?> value="EH">Western Sahara</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'YE') ? 'selected="selected"' : '' ?> value="YE">Yemen</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'ZM') ? 'selected="selected"' : '' ?> value="ZM">Zambia</option>
                        <option <?= (isset($_POST['sanctionContact']['country']) && $_POST['sanctionContact']['country'] == 'ZW') ? 'selected="selected"' : '' ?> value="ZW">Zimbabwe</option>
                    </select>
                </td>

                <td style="width: 45px;" class="fieldlabel">

                    <label><?php domainResellerTranslate('city') ?> *</label>
                </td>
                <td class="fieldarea">
                    <input type="text" id="sanctionContact_city" name="sanctionContact[city]"
                           value="<?php if (isset($_POST['sanctionContact']['city'])) echo $_POST['sanctionContact']['city'] ?>"
                           required="required"/>
                </td>
                <td style="width: 45px;" class="fieldlabel"></td>
                <td class="fieldarea"></td>
            </tr>
            </tbody>
        </table>
        <div class="btn-container">
            <input type="submit" name="sanctionContactSubmit" value="<?php domainResellerTranslate('submit') ?>"/>
        </div>
    </form>

</div>

<script>
    var index = <?php echo $indexKey ?>;

    function addFeild() {

        var html = '<div class="chargeArea"> <label><?php domainResellerTranslate('setting_formula_charge') ?><input type="text" name="domain_reseller_management_formula[charge][' + index + ']" value=""/> </label> <label><?php domainResellerTranslate('setting_formula_discount') ?><input type="text" name="domain_reseller_management_formula[discount][' + index + ']" value=""/> </label> </div>';
        $('.chargeArea').last().append(html);
        index++;
        return false;
    }

    function showDiv(el, item) {

        if ($(el).is(':checked')) {
            $('.' + item).show();
        } else {
            $('.' + item).hide();
        }
    }
</script>