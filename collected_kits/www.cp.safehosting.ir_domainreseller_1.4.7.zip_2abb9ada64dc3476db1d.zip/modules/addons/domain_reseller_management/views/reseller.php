<div class="dashboard">
	<div>
		<?php
		if (!empty($error)) {
			echo '<div style="color:red;">';
			foreach ($error as $er) {
				echo $er . '<br/>';
			}
			echo '</div>';
		} elseif (isset($suc) && $suc != '') {
			echo '<div style="color:green;">' . $suc . '</div>';
		}

		?>
	</div>
	<div>
		<form name="" method="post" action="<?php domainResellerGetBaseUrl('reseller','index') ?>">
			<?php 
			if ($reseller[0]->promotion == 1){ ?>
				<input type="submit" name="promotionSubmit" value="<?php domainResellerTranslate('tld_promotion_deactive') ?>" />
				<input type="hidden" name="promotionType" value="0" />
			<?php }else{ ?>
				<input type="submit" name="promotionSubmit" value="<?php domainResellerTranslate('tld_promotion_active') ?>" />
				<input type="hidden" name="promotionType" value="1" />
			<?php } ?>
		</form>
	</div>

    <table id="sortabletbl1" class="datatable" width="100%" border="0" cellspacing="1" cellpadding="3">
		<thead>
		<tr>
			<th><?php domainResellerTranslate('index') ?></th>
			<th><?php domainResellerTranslate('service_id') ?></th>
			<th><?php domainResellerTranslate('reseller_id') ?></th>
			<th><?php domainResellerTranslate('name') ?></th>
			<th><?php domainResellerTranslate('email') ?></th>
			<th><?php domainResellerTranslate('phone') ?></th>
			<th><?php domainResellerTranslate('reseller_balance') ?></th>
			<th><?php domainResellerTranslate('reseller_balance_locked') ?></th>
			<th><?php domainResellerTranslate('operation') ?></th>
		</tr>
		</thead>
		<tbody>
		<?php foreach($reseller as $k=>$r){ ?>
			<tr>
				<td><?= $k+1; ?></td>
				<td><?= isset($services[$r->id]) ? '<a href="clientsservices.php?id='.$services[$r->id].'">'.$services[$r->id].'</a>' : 'NULL' ?></td>
				<td><a href="<?php domainResellerGetBaseUrl('reseller','profile',['resellerId'=>$r->id])  ?>"><?= $r->id ?></a></td>
				<td><a href="<?php domainResellerGetBaseUrl('reseller','profile',['resellerId'=>$r->id])  ?>"><?= $r->name ?></a></td>
				<td><a href="<?php domainResellerGetBaseUrl('reseller','profile',['resellerId'=>$r->id])  ?>"><?= $r->email ?></a></td>
				<td><a href="<?php domainResellerGetBaseUrl('reseller','profile',['resellerId'=>$r->id])  ?>"><?= $r->mobile ?></a></td>
				<td><a href="<?php domainResellerGetBaseUrl('reseller','transaction',['resellerId'=>$r->id,'status'=>'success']) ?>"><?= number_format($r->charge) ?></a></td>
				<td><a href="<?php domainResellerGetBaseUrl('reseller','transaction',['resellerId'=>$r->id,'status'=>'locked']) ?>"><?= number_format($r->locked) ?></a></td>
				<td>
					<a href="<?php domainResellerGetBaseUrl('reseller','token',['resellerId'=>$r->id]) ?>"><?php domainResellerTranslate('create') ?><?php domainResellerTranslate('token') ?></a> |
					<a href="<?php domainResellerGetBaseUrl('reseller','manage',['resellerId'=>$r->id]) ?>"><?php domainResellerTranslate('tld') ?></a>
				</td>
			</tr>
		
		<?php } ?>
		</tbody>
	</table>

</div>
