<?php
if(!isset($_SESSION['adminid'])){
    exit;
}
use \Illuminate\Database\Capsule\Manager as Capsule;
require_once dirname(__FILE__).DIRECTORY_SEPARATOR.'unirest-php'.DIRECTORY_SEPARATOR.'Unirest.php';
callMethod();
function token()
    {
        $error = [];
        if(isset($_GET['resellerId'])) {
            global $moduleParams;
            if (isset($_POST['domain_reseller_management_token']['submit'])) {
                $headers = array("Accept" => "application/json", "Content-Type" => "application/json; charset=UTF-8", 'Authorization' => $moduleParams['token']);
                if (isset($_POST['domain_reseller_management_token']['client_name'])) {
                    $regParams = [];
                    $regParams['client_name'] = $_POST['domain_reseller_management_token']['client_name'];
                    $regParams['id'] = intval($_GET['resellerId']);

                    $CrequestParams = $regParams;
                    $CrequestParams['requestTime'] = time();

                    $regParams = json_encode($regParams);

                    $response = domainResellerUnirest\Request::post($moduleParams['apiurl'] . 'app/create', $headers, $regParams);

                    $sta = 'failed';
                    if ($response->code == 200) {
                        $sta = 'success';
                        $suc = 'شناسه برنامه ایجاد شده :‌' . $response->body->result->client_id;
                        $regParams = [];
                        $regParams['client_id'] = $response->body->result->client_id;
                        $regParams['id'] = intval($_GET['resellerId']);

                        $TrequestParams = $regParams;
                        $TrequestParams['requestTime'] = time();

                        $regParams = json_encode($regParams);
                        $response = domainResellerUnirest\Request::post($moduleParams['apiurl'] . 'app/token', $headers, $regParams);
                        $st = 'failed';
                        if ($response->code == 200) {
                            $TrequestParams['responseTime'] = time();
                            $st = 'success';
                            $suc = 'توکن با موفقیت ایجاد گردید :‌' . $response->body->result->access_token;

                            $serviceID =  Capsule::table('domain_reseller_management_setting')->where('item', '=', 'rid')->where('value','=',(int) $_GET['resellerId'])->first();
                            if(!empty($serviceID)){
                                $userID = Capsule::table('domain_reseller_management_setting')->where('item', '=', 'userservice')->where('value','=',$serviceID->key)->first();

                                if(!empty($userID)) {
                                    $adminuser = domainResellerGetAdminUserName();
                                    $command = "sendemail";
                                    $values["customtype"] = "general";
                                    $values["customsubject"] = "دسترسی توکن شما";
                                    $values["custommessage"] = "<p><h3>سلام</h3></p><p>دسترسی توکن شما به شرح زیر میباشد</p><p>" . $response->body->result->access_token . "<br />لطفا توکن را در بخش تنظیمات ماژول وارد نمایید</p><p>با تشکر</p>";
                                    $values["id"] = $userID->key;
                                    $results = localAPI($command, $values, $adminuser);
                                    domainResellerLogger('admin_reseller_email',$_SESSION['adminid'], $userID->key, '', '',[],$results ,$_POST['domain_reseller_management_token']['client_name'], $results['result']);
                                }
                            }
                        } else {
                            $TrequestParams['responseTime'] = time();
                            $error[] = $response->body->errorDetails;
                        }
                        domainResellerLogger('admin_reseller_createtoken', $_SESSION['adminid'], '', '', '', $TrequestParams, $response->body, $_POST['domain_reseller_management_token']['client_name'], $st);
                    } else {
                        $CrequestParams['responseTime'] = time();
                        $error[] = $response->body->errorDetails;
                    }
                    domainResellerLogger('admin_reseller_createapp', $_SESSION['adminid'], '', '', '', $CrequestParams, $response->body, $_POST['domain_reseller_management_token']['client_name'], $sta);
                } else {
                    $error[] = 'لطفا فیلدهای ضروری را پر نمایید';
                }
            }
        }else{
            $error[] = 'آدرس درخواست شده نامعتبر است';
        }
        require_once dirname(__FILE__).DIRECTORY_SEPARATOR.'views'.DIRECTORY_SEPARATOR.'reseller_token.php';
    }

function index(){
    global $moduleParams;
    $unitsKey = domainResellerGetUnits(true);
    $headers = array("Accept" => "application/json", "Content-Type" => "application/json; charset=UTF-8",);
    $headers['Authorization'] = $moduleParams['token'];
    if(isset($_POST['promotionSubmit'])){
        $regParams = [];
        $regParams['status'] =(int) $_POST['promotionType'];
        $response = domainResellerUnirest\Request::put($moduleParams['apiurl'] . 'reseller/promotion', $headers, json_encode($regParams));
        domainResellerLogger('admin_promotion_deactive',$_SESSION['adminid'],'','','',$regParams,$response->body,'','success');
        if($response->code != 200){
            $error[] = $response->body->errorDetails;
        }else{
            $suc = 'عملیات با موفقیت انجام پذیرفت';
        }
    }
    $response = domainResellerUnirest\Request::get($moduleParams['apiurl'] . 'reseller', $headers, []);
    $reseller = [];
    if ($response->code != 200) {
        $error[] = $response->body->errorDetails;
    }else{
        $reseller = $response->body->result->subset;
        if(empty($reseller)){
            $error[] = 'هیچ نماینده ای برای شما تعریف نشده است';
        }
    }

    $servicesDB= Capsule::table('domain_reseller_management_setting')->where('item', '=', 'rid')->get();
    $services = [];
    foreach ($servicesDB as $s){
        $services[$s->value] = $s->key;
    }

    require_once dirname(__FILE__).DIRECTORY_SEPARATOR.'views'.DIRECTORY_SEPARATOR.'reseller.php';
}

function assign(){
    if(isset($_GET['resellerId'])) {
        global $moduleParams;
        $headers = array("Accept" => "application/json", "Content-Type" => "application/json; charset=UTF-8");
        $headers['Authorization'] = $moduleParams['token'];
        $unitsKey = domainResellerGetUnits(true);
        $error = [];
        if (isset($_POST['domain_reseller_management_tld']['submit'])) {

            if (isset($_GET['resellerId']) && isset($_POST['domain_reseller_management_tld']['tld'])) {
                $regParams = [];
                $regParams['id'] = intval($_GET['resellerId']);
                $ArequestParams = $regParams;
                foreach ($_POST['domain_reseller_management_tld']['tld'] as $tld){
                    $regParams['tld'] = $tld;
                    $ArequestParams['requestTime'] = time();
                    $ArequestParams['tld'] = $tld;
                    $response = domainResellerUnirest\Request::post($moduleParams['apiurl'] . 'tld', $headers, json_encode($regParams));
                    $stAssign = 'success';
                    if ($response->code != 200) {
                        $stAssign = 'failed';
                        $ArequestParams['responseTime'] = time();
                        $error[] = isset($response->body->errorDetails) ? $response->body->errorDetails : 'server_error';
                    }
                    domainResellerLogger('admin_reseller_tld_assign', $_SESSION['adminid'], '', '', '', $ArequestParams, $response->body, $tld, $stAssign);
                }
            }else{
                $error[] = 'لطفا پارامتر های ضروری را پر نمایید';
            }
        }

        $regParams = [];
        $regParams['id'] =intval($_GET['resellerId']);
        $getOldTld = domainResellerUnirest\Request::get($moduleParams['apiurl'] . 'tld', $headers, $regParams);
        $oldTld = [];
        if ($getOldTld->code == 200) {
            foreach ($getOldTld->body->result->tld as $ot) {
                $oldTld[$ot->tld] = $ot;
            }
        }
        $response = domainResellerUnirest\Request::get($moduleParams['apiurl'] . 'tld', $headers, []);

        if ($response->code != 200) {
            $error[] = $response->body->errorDetails;
        } else {
            $tld = $response->body->result->tld;
            if (empty($tld)) {
                $error[] = 'هیچ پسوند دامنه ای برای شما تعریف نشده است';
            }
        }

        $units = domainResellerGetUnits();
    }else{
        $error[] = 'آدرس درخواست شده نامعتبر است';
    }
    require_once dirname(__FILE__).DIRECTORY_SEPARATOR.'views'.DIRECTORY_SEPARATOR.'tld_assign.php';
}

function manage(){
    if(isset($_GET['resellerId'])) {
        global $moduleParams;


        $headers = array("Accept" => "application/json", "Content-Type" => "application/json; charset=UTF-8");
        $headers['Authorization'] = $moduleParams['token'];
        $error = [];


        $regParams = [];
        $regParams['id'] =intval($_GET['resellerId']);
        $id = $regParams['id'];
        if(isset($_POST['submit']) && empty($error)){

            $tldList = domainResellerUnirest\Request::get($moduleParams['apiurl'] . 'tld', $headers, []);
            $parentTld = [];
            if ($tldList->code == 200) {
                foreach ($tldList->body->result->tld as $ot) {
                    $parentTld[$ot->tld] = $ot;
                }
            }

            $response = domainResellerUnirest\Request::get($moduleParams['apiurl'] . 'tld', $headers, $regParams);
            if ($response->code != 200) {
                $error[] = $response->body->errorDetails;
            } else {
                $tld = $response->body->result->tld;
            }
            if(empty($error)) {
                foreach ($tld as $t) {
                    $regParams = [];

                    $regParams['register_price'] = round($parentTld[$t->tld]->register_price_buy + (($parentTld[$t->tld]->register_price_buy * $_POST['profit']) / 100), -3);
                    $regParams['renew_price'] = round($parentTld[$t->tld]->renew_price_buy + (($parentTld[$t->tld]->renew_price_buy * $_POST['profit']) / 100), -3);
                    $regParams['redemption_price'] = round($parentTld[$t->tld]->redemption_price_buy + (($parentTld[$t->tld]->redemption_price_buy * $_POST['profit']) / 100), -3);
                    $regParams['transfer_price'] = round($parentTld[$t->tld]->transfer_price_buy + (($parentTld[$t->tld]->transfer_price_buy * $_POST['profit']) / 100), -3);


                    $regParams['tld'] = $t->tld;
                    $regParams['id'] = $id;
                    $update = domainResellerUnirest\Request::put($moduleParams['apiurl'] . 'tld', $headers, json_encode($regParams));
                    $st = 'success';
                    if ($update->code != 200) {
                        $st = 'failed';
                        $error[] = isset($update->body->errorDetails) ? $update->body->errorDetails : 'server_error';
                    }
                    domainResellerLogger('admin_reseller_tld_modify', $_SESSION['adminid'], '', '', '', $regParams, $update->body, $t->tld, $st);
                }
            }
        }


        $tldList = domainResellerUnirest\Request::get($moduleParams['apiurl'] . 'tld', $headers, []);
        $parentTld = [];
        if ($tldList->code == 200) {
            foreach ($tldList->body->result->tld as $ot) {
                $parentTld[$ot->tld] = $ot;
            }
        }

        $regParams = [];
        $regParams['id'] =intval($_GET['resellerId']);
        $response = domainResellerUnirest\Request::get($moduleParams['apiurl'] . 'tld', $headers, $regParams);
        if ($response->code != 200) {
            $error[] = $response->body->errorDetails;
        } else {
            $tld = $response->body->result->tld;
        }

        $units = domainResellerGetUnits();
    }else{
        $error[] = 'آدرس درخواست شده نامعتبر است';
    }
    require_once dirname(__FILE__).DIRECTORY_SEPARATOR.'views'.DIRECTORY_SEPARATOR.'tld_manage.php';
}

function ajaxupdatetld(){
    if(!isset($_POST['id']) || !isset($_POST['tld'])){
        http_response_code(400);
        echo 'invalid params';
        exit;
    }

    global $moduleParams;
    $headers = array("Accept" => "application/json","Content-Type"=>"application/json; charset=UTF-8");
    $headers['Authorization'] = $moduleParams['token'];
    //$headers['x-reseller-id'] = 1;


    $regParams['tld'] = $_POST['tld'];
    $regParams['id'] = $_POST['id'];
    $unitsKey = domainResellerGetUnits(true);
    if($unitsKey == 'toman'){
        $regParams['register_price'] = $_POST['register_price']*10;
        $regParams['renew_price'] = $_POST['renew_price']*10;
        $regParams['redemption_price'] = $_POST['redemption_price']*10;
        $regParams['transfer_price'] = $_POST['transfer_price']*10;
    }else{
        $regParams['register_price'] = $_POST['register_price'];
        $regParams['renew_price'] = $_POST['renew_price'];
        $regParams['redemption_price'] = $_POST['redemption_price'];
        $regParams['transfer_price'] = $_POST['transfer_price'];
    }

    $regParams['active'] = 1;
    if(!isset($_POST['active'])){
        $regParams['active'] = 0;
    }

    $requestParams = $regParams;
    $requestParams['requestTime'] = time();

    $regParams = json_encode($regParams);
    $response = domainResellerUnirest\Request::put($moduleParams['apiurl'].'tld', $headers, $regParams);
    $st = 'success';
    $trackid = '';
    $procid = '';

    if($response->code == 200){
        $resp = 'عملیات با موفقیت انجام پذیرفت';
        http_response_code(200);
    }else {
        http_response_code(400);
        $st = 'failed';
        $resp = isset($response->body->errorDetails) ? $response->body->errorDetails : 'server_error' ;
    }
    $requestParams['responseTime'] = time();
    domainResellerLogger('admin_reseller_tld_update',$_SESSION['adminid'], '', $procid, $trackid,$requestParams,$response->body ,$_POST['tld'], $st);
    echo $resp;
   exit;
}

function profile(){
    if(isset($_GET['resellerId'])){

        global $moduleParams;

        $headers = array("Accept" => "application/json","Content-Type"=>"application/json; charset=UTF-8",);
        $headers['Authorization'] = $moduleParams['token'];
        $response = domainResellerUnirest\Request::get($moduleParams['apiurl'] . 'reseller', $headers, ['id'=>$_GET['resellerId']]);
        if ($response->code != 200) {
            $err[] = $response->body->errorDetails;
        }
        $service_id= Capsule::table('domain_reseller_management_setting')->where('item', '=', 'rid')->where('value','=',$_GET['resellerId'])->value('key');
        require_once dirname(__FILE__).DIRECTORY_SEPARATOR.'views'.DIRECTORY_SEPARATOR.'reseller_profile.php';

    }else{
        $err[] = 'آدرس درخواست شده نامعتبر است';
    }
}

function edit(){
    if(isset($_GET['resellerId'])){

        global $moduleParams;
        $headers = array("Accept" => "application/json","Content-Type"=>"application/json; charset=UTF-8",);
        $headers['Authorization'] = $moduleParams['token'];
        if(isset($_POST['editSubmit'])){

            $dataToSend = [];
            $dataToSend['name'] = $_POST['name'];
            $dataToSend['email'] = $_POST['email'];
            $dataToSend['mobile'] = $_POST['mobile'];
            $dataToSend['address'] = $_POST['address'];
            $dataToSend['id'] = (int)$_GET['resellerId'];
            $profile = domainResellerUnirest\Request::put($moduleParams['apiurl'] . 'reseller', $headers, json_encode($dataToSend));
            if ($profile->code != 200) {
                $err[] = $profile->body->errorDetails;
            }else{
                $suc = 'درخواست شما با موفقیت ثبت گردید';
            }

        }

        $response = domainResellerUnirest\Request::get($moduleParams['apiurl'] . 'reseller', $headers, ['id'=>$_GET['resellerId']]);
        if ($response->code != 200) {
            $err[] = $response->body->errorDetails;
        }
        $service_id= Capsule::table('domain_reseller_management_setting')->where('item', '=', 'rid')->where('value','=',$_GET['resellerId'])->value('key');

    }else{
        $err[] = 'آدرس درخواست شده نامعتبر است';
    }
    require_once dirname(__FILE__).DIRECTORY_SEPARATOR.'views'.DIRECTORY_SEPARATOR.'reseller_profile_edit.php';
}

function transaction(){
    if(isset($_GET['resellerId'])){

        global $moduleParams;

        $page = 1;
        if(isset($_POST['page']))
        {
            $page = $_POST['page'];
        }

        $headers = array("Accept" => "application/json","Content-Type"=>"application/json; charset=UTF-8",);
        $headers['Authorization'] = $moduleParams['token'];
        $headers['X-Pagination-Current-Page'] = $page;
        $response = domainResellerUnirest\Request::get($moduleParams['apiurl'] . 'reseller/transaction', $headers, ['id'=>$_GET['resellerId'],'status'=>$_GET['status']]);
        if ($response->code != 200) {
            $err[] = $response->body->errorDetails;
        }

    }else{
        $err[] = 'آدرس درخواست شده نامعتبر است';
    }

    require_once dirname(__FILE__).DIRECTORY_SEPARATOR.'views'.DIRECTORY_SEPARATOR.'reseller_transaction.php';
}

function domains(){
    if(isset($_GET['resellerId'])){

        global $moduleParams;

        $page = 1;
        if(isset($_POST['page']))
        {
            $page = $_POST['page'];
        }


        $headers = array("Accept" => "application/json","Content-Type"=>"application/json; charset=UTF-8",);
        $headers['Authorization'] = $moduleParams['token'];
        $headers['X-Pagination-Current-Page'] = $page;
        $response = domainResellerUnirest\Request::get($moduleParams['apiurl'] . 'reseller/domainList', $headers, ['id'=>$_GET['resellerId']]);
        if ($response->code != 200) {
            $err[] = $response->body->errorDetails;
        }

    }else{
        $err[] = 'آدرس درخواست شده نامعتبر است';
    }

    require_once dirname(__FILE__).DIRECTORY_SEPARATOR.'views'.DIRECTORY_SEPARATOR.'reseller_domain.php';
}

function ticket(){
    $err = [];
    if(isset($_POST['ticketSubmit'])){
        if(!empty($_POST['ticketMsg']) && !empty($_POST['ticketTitle'])){
            global $moduleParams;
            $headers = array("Accept" => "application/json","Content-Type"=>"application/json; charset=UTF-8",);
            $headers['Authorization'] = $moduleParams['token'];
            $response = domainResellerUnirest\Request::get($moduleParams['apiurl'] . 'reseller', $headers, ['version'=>domainResellerGetVersion()]);

            if ($response->code != 200) {
                $err[] = $response->body->errorDetails;
            }else{
                $reseller = $response->body->result->subset;
                if(!empty($reseller)){

                    foreach ($reseller as $item) {

                        $serviceId = Capsule::table('domain_reseller_management_setting')->where('item', '=', 'rid')->where('value','=',$item->id)->whereNotNull('key')->value('key');

                        if($serviceId){
                            $userId = Capsule::table('domain_reseller_management_setting')->where('item', '=', 'userservice')->where('value','=',$serviceId)->value('key');
                            
                            if($userId){
                                $values["clientid"] = $userId;
                                $values["deptid"] = $_POST['ticketDepartment'];
                                $values["status"] = $_POST['ticketStatus'];
                                $subject = $_POST['ticketTitle'];
                                $message = $_POST['ticketMsg'];
                                $message = strtr($message, ['[$name]'=>$item->name]);
                                $adminUsername = domainResellerGetAdminUserName();

                                $admin = Capsule::table('tbladmins')->where('username',$adminUsername)->first();
                                $values['message'] = $message;
                                $values['admin'] = $admin->firstname.' '.$admin->lastname;
                                $values['subject'] = $subject;
                                $command = "OpenTicket";

                                localAPI($command, $values, $adminUsername);
                            }else{
                                $err [] = "اطلاعات کاربری نماینده {$item->id} یافت نشد";
                                continue;
                            }
                        }
                    }
                }else{
                    $err[] = 'نماینده ای یافت نشد';
                }
            }
        }else{
            $err[] = 'لطفا فیلدها را پر نمایید';
        }
    }


    $department = Capsule::table('tblticketdepartments')->pluck('name', 'id');

    require_once dirname(__FILE__).DIRECTORY_SEPARATOR.'views'.DIRECTORY_SEPARATOR.'reseller_ticket.php';
}