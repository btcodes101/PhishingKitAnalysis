<?php
/**
 * Created by PhpStorm.
 * User: MJahanbakhsh
 * Date: 28/01/2017
 * Time: 08:39 AM
 */
if(!isset($_SESSION['adminid'])){
    exit;
}
use \Illuminate\Database\Capsule\Manager as Capsule;
require_once dirname(__FILE__).DIRECTORY_SEPARATOR.'unirest-php'.DIRECTORY_SEPARATOR.'Unirest.php';
callMethod();
function idProtection()
{
    global $moduleParams;
    $error = [];
    $suc= '';
    $unitKey = domainResellerGetUnits(true);
    $headers = array("Accept" => "application/json", "Content-Type" => "application/json; charset=UTF-8", 'Authorization' => $moduleParams['token']);
    if(isset($_POST['idProtectionOrder'])){
        $requestParams['requestTime'] = time();
        $requestParams['requestType'] = 'unlimited';
  
        $response = domainResellerUnirest\Request::post("{$moduleParams['apiurl']}domain/{$_GET['domain']}/protection/unlimitedRequest", $headers, json_encode([]));

        $st = 'failed';
        $trackid = '';
        $procid = '';

        if($response->code == 200){
            $trackid = $response->body->result->tracking_id;
            $procid = $response->body->result->processing_id;
            $st = 'pending';
            $suc = 'عملیات با موفقیت ثبت گردید';
        }
        $requestParams['responseTime'] = time();
        domainResellerLogger('domain_protection_create',  $_SESSION['adminid'], '',$procid, $trackid,$requestParams, $response->body,$_GET['domain'] , $st);
    }


    $response = domainResellerUnirest\Request::get($moduleParams['apiurl'] . 'domain/'.$_GET['domain'], $headers, []);
    if($response->code != 200){
        $error[] = $response->body->errorDetails;
    }else{
        $domain = $response->body->result;
        $domain->domain_expires = strtotime($domain->domain_expires);
        #calc period requested
        $curTime = new \DateTime();
        $expTime = new \DateTime(date('Y-m-d', $domain->domain_expires));
        $diff = $expTime->diff($curTime);
        $inMonth = (int)$diff->format('%m');
        $periodRequested = (int)$diff->format('%y');
        if($periodRequested == 0){
            $periodRequested = 1;
        }else if ($inMonth > 0) {
            $periodRequested += 1;
        }
    }
    $protectionPrice = domainResellerUnirest\Request::get($moduleParams['apiurl'] . 'reseller/addon/protection', $headers, []);
    if($protectionPrice->code != 200){
        $error[] = $protectionPrice->body->errorDetails;
    }else{
        if($protectionPrice->body->result->status == 0){
            $error[] = 'ماژول محافظت شما غیر فعال است لطفا ابتدا نسبت به فعال سازی آن اقدام نمایید';
        }elseif($protectionPrice->body->result->status == 2){
            $error[] = 'ماژول محافظت شما توسط پرنت غیر فعال شده است';
        }
        $price = $protectionPrice->body->result->sell * $periodRequested;
        if($unitKey == 'toman'){
            $price /= 10;
        }
    }
  
    if($domain->domain_protection == 1 && $suc == ''){
        $error[] = 'محافظت از whois برای این دامنه فعال است';
    }
  
    require_once dirname(__FILE__).DIRECTORY_SEPARATOR.'views'.DIRECTORY_SEPARATOR.'domain_idProtection.php';
}