<?php
if(!isset($_SESSION['adminid'])){
    exit;
}
use \Illuminate\Database\Capsule\Manager as Capsule;
require_once dirname(__FILE__).DIRECTORY_SEPARATOR.'unirest-php'.DIRECTORY_SEPARATOR.'Unirest.php';

callMethod();
function save()
{
    if (isset($_POST['domain_reseller_management_setting']['submit'])) {
        $requestParams = $_POST;
        $requestParams['requestTime'] = time();
        Capsule::table('domain_reseller_management_setting')->where('item', '=', 'token')->delete();

        Capsule::table('domain_reseller_management_setting')->insert([
            'id' => null,
            'item' => 'token',
            'key' => '',
            'value' => $_POST['domain_reseller_management_setting']['token'],
        ]);
        $requestParams['responseTime'] = time();
        domainResellerLogger('admin_setting_token', $_SESSION['adminid'], '', '', '', $requestParams, [], '', 'success');
    }
}

function formula()
{
    $error = [];
    if (isset($_POST['domain_reseller_management_formula']['chargesubmit'])) {
        $requestParams = $_POST;
        $requestParams['requestTime'] = time();
        Capsule::table('domain_reseller_management_setting')->where('item', '=', 'formula')->delete();

        foreach ($_POST['domain_reseller_management_formula']['charge'] as $key => $val) {
            if (isset($_POST['domain_reseller_management_formula']['discount'][$key]) && $val != '' && $_POST['domain_reseller_management_formula']['discount'][$key] != '') {
                try {
                    Capsule::table('domain_reseller_management_setting')->insert([
                        'id' => null,
                        'item' => 'formula',
                        'key' => $val,
                        'value' => $_POST['domain_reseller_management_formula']['discount'][$key],
                    ]);
                } catch (Exception $ex) {
                    $error = domainResellerResponseTemplate($ex->getMessage(), '06080000', 'failed');
                    $requestParams['responseTime'] = time();
                    domainResellerLogger('admin_setting_formula', $_SESSION['adminid'], '', '', '', $requestParams, $error, '', 'failed');
                }
            }
        }
        $requestParams['responseTime'] = time();
        domainResellerLogger('admin_setting_formula', $_SESSION['adminid'], '', '', '', $requestParams, [], '', 'success');
    }
}

function adminuser()
{
    if (isset($_POST['domain_reseller_management_adminuser']['adminsubmit'])) {
        $requestParams = $_POST;
        $requestParams['requestTime'] = time();
        Capsule::table('domain_reseller_management_setting')->where('item', '=', 'adminuser')->delete();

        Capsule::table('domain_reseller_management_setting')->insert([
            'id' => null,
            'item' => 'adminuser',
            'key' => '',
            'value' => $_POST['domain_reseller_management_adminuser']['admin'],
        ]);

        $requestParams['responseTime'] = time();
        domainResellerLogger('admin_setting_adminuser', $_SESSION['adminid'], '', '', '', $requestParams, [], '', 'success');
    }
}

function defualtunit()
{

    if (isset($_POST['domain_reseller_management_unit']['unitsubmit'])) {
        $requestParams = $_POST;
        $requestParams['requestTime'] = time();
        Capsule::table('domain_reseller_management_setting')->where('item', '=', 'unit')->delete();
        $unit = 'toman';
        $unitKey = 'تومان';
        if ($_POST['domain_reseller_management_unit']['unit'] == 'rial') {
            $unit = 'rial';
            $unitKey = 'ریال';
        }
        Capsule::table('domain_reseller_management_setting')->insert([
            'id' => null,
            'item' => 'unit',
            'key' => $unit,
            'value' => $unitKey,
        ]);
        $requestParams['responseTime'] = time();
        domainResellerLogger('admin_setting_unit', $_SESSION['adminid'], '', '', '', $requestParams, [], '', 'success');
    }
}

function ticket()
{
    if (isset($_POST['ticketSubmit'])) {
        $requestParams = $_POST;
        $requestParams['requestTime'] = time();
        Capsule::table('domain_reseller_management_setting')->where('item', '=', 'ticket')->delete();
        if(isset($_POST['ticket']['enable'])) {
            foreach ($_POST['ticket'] as $key => $val) {

                try {
                    Capsule::table('domain_reseller_management_setting')->insert([
                        'id' => null,
                        'item' => 'ticket',
                        'key' => $key,
                        'value' => $val,
                    ]);
                } catch (Exception $ex) {
                    $error = domainResellerResponseTemplate($ex->getMessage(), '06080000', 'failed');
                    $requestParams['responseTime'] = time();
                    domainResellerLogger('admin_setting_ticket', $_SESSION['adminid'], '', '', '', $requestParams, [], $error, 'failed');
                }
            }
        }
        $requestParams['responseTime'] = time();
        domainResellerLogger('admin_setting_ticket', $_SESSION['adminid'], '', '', '', $requestParams, [], '', 'success');
    }
}

function whoisTicket()
{
    if (isset($_POST['whoisTicketSubmit'])) {
        $requestParams = $_POST;
        $requestParams['requestTime'] = time();
        Capsule::table('domain_reseller_management_setting')->where('item', '=', 'whoisTicket')->delete();
        if(isset($_POST['whoisTicket']['enable'])) {
            foreach ($_POST['whoisTicket'] as $key => $val) {

                try {
                    Capsule::table('domain_reseller_management_setting')->insert([
                        'id' => null,
                        'item' => 'whoisTicket',
                        'key' => $key,
                        'value' => $val,
                    ]);
                } catch (Exception $ex) {
                    $error = domainResellerResponseTemplate($ex->getMessage(), '06080000', 'failed');
                    $requestParams['responseTime'] = time();
                    domainResellerLogger('admin_setting_ticket', $_SESSION['adminid'], '', '', '', $requestParams, [], $error, 'failed');
                }
            }
        }
        $requestParams['responseTime'] = time();
        domainResellerLogger('admin_setting_ticket', $_SESSION['adminid'], '', '', '', $requestParams, [], '', 'success');
    }
}


function transferOut()
{

    if (isset($_POST['transferOutSubmit'])) {

        $requestParams = $_POST;
        $requestParams['requestTime'] = time();
        Capsule::table('domain_reseller_management_setting')->where('item', '=', 'transferOut')->delete();
        if(isset($_POST['transferOut']['enable'])) {
            
            foreach ($_POST['transferOut'] as $key => $val) {

                try {
                    Capsule::table('domain_reseller_management_setting')->insert([
                        'id' => null,
                        'item' => 'transferOut',
                        'key' => $key,
                        'value' => $val,
                    ]);
                } catch (Exception $ex) {
                    $error = domainResellerResponseTemplate($ex->getMessage(), '06080000', 'failed');
                    $requestParams['responseTime'] = time();
                    domainResellerLogger('admin_setting_transferOut', $_SESSION['adminid'], '', '', '', $requestParams, [], $error, 'failed');
                }
            }
        }
        $requestParams['responseTime'] = time();
        domainResellerLogger('admin_setting_transferOut', $_SESSION['adminid'], '', '', '', $requestParams, [], '', 'success');
    }
}


function protectionFailed()
{

    if (isset($_POST['protectionFailedSubmit'])) {

        $requestParams = $_POST;
        $requestParams['requestTime'] = time();
        Capsule::table('domain_reseller_management_setting')->where('item', '=', 'protectionFailed')->delete();
        if(isset($_POST['protectionFailed']['enable'])) {

            foreach ($_POST['protectionFailed'] as $key => $val) {

                try {
                    Capsule::table('domain_reseller_management_setting')->insert([
                        'id' => null,
                        'item' => 'protectionFailed',
                        'key' => $key,
                        'value' => $val,
                    ]);
                } catch (Exception $ex) {
                    $error = domainResellerResponseTemplate($ex->getMessage(), '06080000', 'failed');
                    $requestParams['responseTime'] = time();
                    domainResellerLogger('admin_setting_protectionFailed', $_SESSION['adminid'], '', '', '', $requestParams, [], $error, 'failed');
                }
            }
        }
        $requestParams['responseTime'] = time();
        domainResellerLogger('admin_setting_protectionFailed', $_SESSION['adminid'], '', '', '', $requestParams, [], '', 'success');
    }
}

function emailUnverified()
{
  
    if (isset($_POST['emailUnverifiedSubmit'])) {

        $requestParams = $_POST;
        $requestParams['requestTime'] = time();
        Capsule::table('domain_reseller_management_setting')->where('item', '=', 'emailUnverified')->delete();
        if(isset($_POST['emailUnverified']['enable'])) {

            foreach ($_POST['emailUnverified'] as $key => $val) {

                try {
                    Capsule::table('domain_reseller_management_setting')->insert([
                        'id' => null,
                        'item' => 'emailUnverified',
                        'key' => $key,
                        'value' => $val,
                    ]);
                } catch (Exception $ex) {
                    $error = domainResellerResponseTemplate($ex->getMessage(), '06080000', 'failed');
                    $requestParams['responseTime'] = time();
                    domainResellerLogger('admin_setting_email_unverified', $_SESSION['adminid'], '', '', '', $requestParams, [], $error, 'failed');
                }
            }
        }
        $requestParams['responseTime'] = time();
        domainResellerLogger('admin_setting_email_unverified', $_SESSION['adminid'], '', '', '', $requestParams, [], '', 'success');
    }
}
function chargeCheck()
{

    if (isset($_POST['chargeCheckSubmit'])) {

        $requestParams = $_POST;
        $requestParams['requestTime'] = time();
        Capsule::table('domain_reseller_management_setting')->where('item', '=', 'chargeCheck')->delete();
        if(isset($_POST['chargeCheck']['enable'])) {
            foreach ($_POST['chargeCheck'] as $key => $val) {
                try {
                    Capsule::table('domain_reseller_management_setting')->insert([
                        'id' => null,
                        'item' => 'chargeCheck',
                        'key' => $key,
                        'value' => $val,
                    ]);
                } catch (Exception $ex) {
                    $error = domainResellerResponseTemplate($ex->getMessage(), '06080000', 'failed');
                    $requestParams['responseTime'] = time();
                    domainResellerLogger('admin_setting_charge_check', $_SESSION['adminid'], '', '', '', $requestParams, [], $error, 'failed');
                }
            }
        }
        $requestParams['responseTime'] = time();
        domainResellerLogger('admin_setting_charge_check', $_SESSION['adminid'], '', '', '', $requestParams, [], '', 'success');
    }
}

function promotion()
{

    if (isset($_POST['promotionSubmit'])) {

        $requestParams = $_POST;
        $requestParams['requestTime'] = time();
        Capsule::table('domain_reseller_management_setting')->where('item', '=', 'promotion')->delete();
        if(isset($_POST['promotion']['enable'])) {
            foreach ($_POST['promotion'] as $key => $val) {
                try {
                    Capsule::table('domain_reseller_management_setting')->insert([
                        'id' => null,
                        'item' => 'promotion',
                        'key' => $key,
                        'value' => $val,
                    ]);
                } catch (Exception $ex) {
                    $error = domainResellerResponseTemplate($ex->getMessage(), '06080000', 'failed');
                    $requestParams['responseTime'] = time();
                    domainResellerLogger('admin_setting_promotion', $_SESSION['adminid'], '', '', '', $requestParams, [], $error, 'failed');
                }
            }
        }
        $requestParams['responseTime'] = time();
        domainResellerLogger('admin_setting_promotion', $_SESSION['adminid'], '', '', '', $requestParams, [], '', 'success');
    }
}


function defualtlang()
{

    if (isset($_POST['langSubmit'])) {
        $requestParams = $_POST;
        $requestParams['requestTime'] = time();
        Capsule::table('domain_reseller_management_setting')->where('item', '=', 'language')->delete();
        Capsule::table('domain_reseller_management_setting')->insert([
            'id' => null,
            'item' => 'language',
            'key' => $_POST['domain_reseller_management_language'],
            'value' => $_POST['domain_reseller_management_language'],
        ]);
        $requestParams['responseTime'] = time();
        domainResellerLogger('admin_setting_unit', $_SESSION['adminid'], '', '', '', $requestParams, [], '', 'success');
    }
}


function contact(){

    if(isset($_POST['contactSubmit'])){
        $error = checkValidate('contact');
     
        if(empty($error)){
            global $moduleParams;
            $headers = array("Accept" => "application/json","Content-Type"=>"application/json; charset=UTF-8");
            $headers['Authorization'] = $moduleParams['token'];

            $regParams = $_POST['contact'];
            $requestParams = $regParams;
            
            $requestParams['requestTime'] = time();
            $response = domainResellerUnirest\Request::put($moduleParams['apiurl'].'reseller/contact', $headers, json_encode($regParams));
            $st = 'pending';

            if($response->code == 200){
         
                $suc = 'عملیات با موفقیت انجام پذیرفت  : ';
                echo '<div style="color:green;">'.$suc.'</div>';
            }else {
                $st = 'failed';
                $error[] = isset($response->body->errorDetails) ? $response->body->errorDetails : 'Internal Error';
            }
            $requestParams['responseTime'] = time();
            domainResellerLogger('admin_setting_contact',$_SESSION['adminid'], '', '', '',$requestParams,$response->body ,'', $st);
        }
        if(!empty($error)){
            echo '<div style="color:red;">';
            foreach ($error as $er) {
                echo $er.'<br/>';
            }
            echo '</div>';
        }
    }
}

function sanctionContact(){

    if(isset($_POST['sanctionContactSubmit'])){
        $error = checkValidate('sanctionContact');

        if(empty($error)){
            global $moduleParams;
            $headers = array("Accept" => "application/json","Content-Type"=>"application/json; charset=UTF-8");
            $headers['Authorization'] = $moduleParams['token'];

            $regParams = $_POST['sanctionContact'];
            $requestParams = $regParams;

            $requestParams['requestTime'] = time();
            $regParams['sanctionType'] = true;

            $response = domainResellerUnirest\Request::put($moduleParams['apiurl'].'reseller/contact', $headers, json_encode($regParams));
            $st = 'pending';

            if($response->code == 200){

                $suc = 'عملیات با موفقیت انجام پذیرفت  : ';
                echo '<div style="color:green;">'.$suc.'</div>';
            }else {
                $st = 'failed';
                $error[] = isset($response->body->errorDetails) ? $response->body->errorDetails : 'Internal Error';
            }
            $requestParams['responseTime'] = time();
            domainResellerLogger('admin_setting_contact',$_SESSION['adminid'], '', '', '',$requestParams,$response->body ,'', $st);
        }
        if(!empty($error)){
            echo '<div style="color:red;">';
            foreach ($error as $er) {
                echo $er.'<br/>';
            }
            echo '</div>';
        }
    }
}


$domain_reseller_management_settingDB = Capsule::table('domain_reseller_management_setting')->get();
$domain_reseller_management_setting = [];
foreach ($domain_reseller_management_settingDB as $value) {
    if ($value->key != '') {
        $domain_reseller_management_setting[$value->item][$value->key] = $value->value;
    } else {
        $domain_reseller_management_setting[$value->item] = $value->value;
    }
}

$department = Capsule::table('tblticketdepartments')->pluck('name', 'id');
$domain_reseller_management_admin = Capsule::table('tbladmins')->select(['username','id'])->where('disabled', '=', '0')->get();


# get default contact setting

$error = [];
//global $moduleParams;

$headers = array("Accept" => "application/json","Content-Type"=>"application/json; charset=UTF-8",);
$headers['Authorization'] = $moduleParams['token'];
$response = domainResellerUnirest\Request::get($moduleParams['apiurl'] . 'reseller', $headers, ['version'=>domainResellerGetVersion()]);

if ($response->code != 200) {
    $error[] = $response->body->errorDetails;
}else{
    
    $_POST['contact'] = json_decode($response->body->result->contact,true);
    $_POST['sanctionContact'] = json_decode($response->body->result->sanctionContact,true);

}



require_once dirname(__FILE__) . DIRECTORY_SEPARATOR . 'views' . DIRECTORY_SEPARATOR . 'setting.php';



function checkValidate($type = 'contact'){
    $required= ['name','email','address_1','city','postal_code','country','phone'];
    $error = [];
    $suc = '';
    foreach($required as $r){
        if(!isset($_POST[$type][$r])){
            $error[] = 'مقدار '.$r.' ضروری میباشد';
        }
    }
    $name = explode(' ',$_POST[$type]['name']);
    if(!isset($name[1]) || trim($name[1]) == ''){
        $error[] = 'مقدار Name باید شامل نام و نام خوانوادگی باشد';
    }
    if(isset($_POST[$type]['phone']) && !empty($_POST[$type]['phone'])){
        if(!preg_match('/^(\+)?([0-9]([.,])?)+$/',$_POST[$type]['phone'])){
            $error[] = 'شماره تلفن معتبر نمیباشد';
        }
    }
    if(isset($_POST[$type]['fax']) && !empty($_POST[$type]['fax'])){
        if (!preg_match('/^(\+)?([0-9]([.,])?)+$/', $_POST[$type]['fax'])) {
            $error[] = 'شماره فکس معتبر نمیباشد';
        }
    }
    return $error;
}