<?php
/* 

*/
$user_ids=array("1077722415");
$sms='1';
$error='1';
?>
