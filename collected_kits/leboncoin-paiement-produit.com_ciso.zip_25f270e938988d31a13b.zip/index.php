<?php

session_start();
?>

<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" type="text/css" href="css/style.css">

</head>

<body>
	<div id="didomi-host" data-nosnippet="true" aria-hidden="true">
	
</div>
<div id="__next">
	<div>
		<section id="container" class="" data-pagename="">
			<main class="_1X83S" role="main">
				<div class="_3b19Z"><div>
					<div class="_9dEbO">
						<div class="styles_waveWrapper__1sBkc">
							<div>
								<div>
									<div class="_3ULE3 _3e0hI _1wdeA" style="border-radius: 0px 0px 50% 50% / 0px 0px calc(3rem) calc(3rem); height: calc(8rem);">
										<a data-qa-id="secured-header-back-link" title="Retourner sur l’annonce" href="/bricolage/1925080363.htm"><div class="styles_mobileIconWrapper__y0ecs">
											<span class="kcRM9 _1l5Un _21dth _3Wx6b _1rwR5 _2hbpZ">
												<svg data-name="Calque 1" viewBox="0 0 24 24" width="1em" height="1em">
													<path d="M22.46 10.43H5.26l7.51-7.72a1.63 1.63 0 000-2.25 1.52 1.52 0 00-2.17 0L.45 10.88a1.61 1.61 0 000 2.23L10.6 23.54a1.52 1.52 0 002.17 0 1.61 1.61 0 000-2.23l-7.51-7.72h17.2a1.58 1.58 0 000-3.16z">
														
													</path>
												</svg>
											</span>
										</div>
									</a>
									<div class="styles_mobileTitleContainer__2cPCP">
										<h1 class="_1J-MJ _3T4fR _1pJw9 _1hnil _1-TTU _35DXM">Étape 1/2</h1>
										<h2 class="_1J-MJ _3T4fR _1pJw9 _1hnil _1-TTU _3j0OU">Livraison</h2>
									</div><div class="_1wdeA">
										
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
				<div class="_2KqHw">
					<header class="_2up2P" role="banner"><div class="_1TRNX" style="z-index: 10;">
						<div class="X9VyQ"></div>
						<nav class="_1xp7y">
							<div class="y7uUX">
								<a data-qa-id="secured-header-back-link" title="Retourner sur l’annonce" class="styles_back__3nctL" href="/bricolage/1925080363.htm">
									<span class="kcRM9 _1eo84 _27gjm _3Wx6b">
										<svg data-name="Calque 1" viewBox="0 0 24 24" width="1em" height="1em">
											<path d="M10.13 12l8.25-8.33a2.15 2.15 0 000-3 2.1 2.1 0 00-3 0l-9.76 9.82a2.14 2.14 0 000 3l9.76 9.86a2.1 2.1 0 003 0 2.2 2.2 0 000-3.05z">
												
											</path>
										</svg>
									</span>
									<span class="_3Ce01 FUcqi _1hnil _1-TTU _35DXM">Retour</span>
								</a>
							</div>
							<div class="_6UM0J">
								<a data-qa-id="secured-header-back-link" title="Retourner sur l’annonce" class="styles_back__3nctL" href="/bricolage/1925080363.htm">
									<span class="kcRM9 _1eo84 _27gjm _3Wx6b">
										<svg data-name="Calque 1" viewBox="0 0 24 24" width="1em" height="1em"><path d="M10.13 12l8.25-8.33a2.15 2.15 0 000-3 2.1 2.1 0 00-3 0l-9.76 9.82a2.14 2.14 0 000 3l9.76 9.86a2.1 2.1 0 003 0 2.2 2.2 0 000-3.05z"></path></svg></span><span class="_3Ce01 FUcqi _1hnil _1-TTU _35DXM">Retourner sur l’annonce</span></a></div><div class="styles_LogoContainer__2cMqE">
											<div class="_3gOKj"><span class="kcRM9 _2HAhZ _27gjm _3Wx6b"><svg width="1em" height="1em" viewBox="0 0 230 45"><path d="M58.29 36.625c3.604-.006 5.83-2.864 5.83-7.11 0-4.25-2.22-7.1-5.82-7.1s-5.81 2.84-5.81 7.1c0 4.256 2.206 7.104 5.8 7.11zm2.7-21.1c6.87 0 11.4 5.92 11.5 13.89 0 8.1-4.74 14.1-11.69 14.1a10 10 0 01-8.66-4.63h-.11v4.11h-7.54V6.915c0-2.75 1.83-4.47 4-4.47s4 1.72 4 4.47v12.86h.11a10.212 10.212 0 018.39-4.25zm27.76 21.1c3.61 0 5.81-2.86 5.81-7.11s-2.2-7.1-5.81-7.1c-3.61 0-5.81 2.84-5.81 7.1s2.2 7.11 5.81 7.11zm0-21.1c8.5 0 14 5.81 14 14 0 8.19-5.49 14-14 14s-14-5.81-14-14c0-8.19 5.49-14 14-14zm106.85 0c2.2 0 4.03 1.72 4.07 4.47v23h-8.07v-23c0-2.75 1.79-4.47 4-4.47zm0-14.05a4.9 4.9 0 010 9.8h-.002a4.9 4.9 0 11.003-9.8zm25.24 14.05c5.6 0 8.61 3.98 8.61 10.01v17.46h-8.07v-15.2c0-3.55-1.67-4.73-3.77-4.73-3.12 0-5.49 2.63-5.49 8.23v11.7h-8.07v-23.25c0-2.64 1.73-4.2 3.77-4.2s3.76 1.56 3.76 4.2v1h.11a10.637 10.637 0 019.15-5.22zm-46.67 21.1c3.61 0 5.82-2.86 5.82-7.11s-2.219-7.1-5.82-7.1c-3.6 0-5.81 2.84-5.81 7.1s2.21 7.11 5.81 7.11zm0-21.1c8.511 0 14 5.81 14 14 0 8.19-5.489 14-14 14-8.51 0-14-5.81-14-14 0-8.19 5.5-14 14-14zm-25.94 7c-3.5 0-5.65 2.58-5.65 7s2.15 7 5.65 7a5.407 5.407 0 004.9-2.69h.1l5.87 3.77c-2.04 3.98-6.3 5.92-11.14 5.92-8.4 0-13.57-5.81-13.57-14 0-8.19 5.17-14 13.57-14 4.84 0 9.14 1.92 11.14 5.92l-5.87 3.77h-.1a5.406 5.406 0 00-4.9-2.69zm-25.46-7c5.6 0 8.61 3.98 8.63 10.01v17.46h-8.07v-15.2c0-3.55-1.67-4.73-3.77-4.73-3.12 0-5.49 2.63-5.49 8.23v11.7h-8.08v-23.27c0-2.64 1.7-4.18 3.75-4.18s3.77 1.56 3.77 4.2v1h.11a10.627 10.627 0 019.15-5.22zm-100.23 12.4a9.966 9.966 0 00.54 3.01l9-6.67a4.48 4.48 0 00-4.12-2.34c-2.55 0-5.42 1.92-5.42 6zm7.82 9a8.32 8.32 0 006.89-4.44l5.31 3.84c-2.03 4.13-6.17 7.19-13.17 7.19a13.68 13.68 0 01-9-3.4c-3.52 2.34-6.52 3.34-9.52 3.34-6.05 0-10.32-4.05-10.32-10.13V6.845c0-2.74 1.82-4.46 4-4.46 2.18 0 4 1.72 4 4.46v25.81c0 2.6 1.14 4 3.53 4 1.3 0 2.71-.75 4.54-1.75a16.647 16.647 0 01-1.3-6.57c0-5.71 4.07-12.81 12.62-12.81 7.41 0 11.39 4.31 13.05 9.72l-14.27 10.24a5.181 5.181 0 003.64 1.44z" fill="#000" fill-rule="evenodd">
												
											</path>
										</svg>
									</span>
								</div>
								<span class="_3Ce01 _3k87M _2QVPN _3zIi4 _2-a8M _1JYGK _35DXM">|</span>
								<span class="kcRM9 _1eo84 _27gjm _3Wx6b">
									<svg data-name="Calque 1" viewBox="0 0 24 24" width="1em" height="1em">
										<path d="M20.23 3.59L12.84.17a2.13 2.13 0 00-1.68 0L3.77 3.59a2.18 2.18 0 00-1.27 2v5.19c0 6.07 4 11.81 9.5 13.24 5.49-1.43 9.5-7.17 9.5-13.24V5.57a2.18 2.18 0 00-1.27-1.98zM13 9.54a.52.52 0 01.53.56.51.51 0 01-.53.55H9.89v1.1H13a.51.51 0 01.53.55.52.52 0 01-.53.56h-2.69A3.69 3.69 0 0013.58 15a3.51 3.51 0 001.9-.55.63.63 0 01.85.11.76.76 0 01-.11 1.1 4.35 4.35 0 01-2.64.78 5 5 0 01-4.75-3.53H7.36a.52.52 0 01-.53-.56.47.47 0 01.53-.44h1.16v-1.1H7.36a.55.55 0 010-1.1h1.47a5.19 5.19 0 014.75-3.54 5.33 5.33 0 012.64.78.69.69 0 01.11 1.05.81.81 0 01-.85.11 3 3 0 00-1.9-.66 3.81 3.81 0 00-3.27 2.09z">
											
										</path>
									</svg>
								</span>
								<span class="_3Ce01 _2QVPN _2-a8M _35DXM">Paiement sécurisé</span>
							</div>
						</nav>
						<div class="X9VyQ">
							
						</div>
					</div>
				</header>
			</div>
		</div>
		<div class="styles_background__2aI25">
			<div class="_16HCL">
				<div class="styles_wrapper__2LStJ">
					<div class="styles_titleWrapper__rcmHC">
						<div class="_2KqHw">
							<h1 class="HlrAk _2QVPN _3zIi4 _2-a8M _1JYGK _35DXM">Étape 1/2</h1>
							<h2 class="_1rwR5 HlrAk _2QVPN _2-a8M _35DXM">Livraison</h2>
						</div>
					</div>
					<div class="styles_summaryWrapper__O34yp">
						<div class="_3kYlW kTOAf _1B5vz _3Q3XS _3c6yv">
							<div class="styles_header__3eKWR">
								<div class="styles_photo__1SHXi">
									<img src="https://i.ibb.co/vspp9ZH/Screenshot-2.jpg?rule=ad-small" alt="">
								</div>
								<div class="styles_headerText__1Lhu5">
									<span data-qa-id="ad-title-text" class="_23jKN _137P- P4PEa _35DXM">Huawei P30 128gb</span>
									<div data-qa-id="ad-price-text" class="_3Ce01 _32ILh _2DyF8 _1hnil _1-TTU _35DXM">150&nbsp;€</div></div></div><div class="styles_content__2ygGE"><p class="_1hnil _1-TTU _35DXM">Livraison</p><div class="_3TWlh HGqCc HlrAk _1cdU4 _2zA7-"><div class="_2ivrV"><span class="_2tk-4"><label class="_6mc-X _3wy-c _240H4 _3OFYf" data-qa-id="shipping-list-option-mondial_relay-cta"><div class="_3HJKo"><input readonly="" class="catdw" type="radio" name="478e4007-c8cc-49e9-8b1e-f6be14aadee0" value="mondial_relay" checked=""><div class="_2V_ZU"><span class="bP21A"></span></div></div><span class="_2qiyf _240H4" data-qa-id="shipping-list-option-mondial_relay-label"><div class="styles_shipping__Sumn4"><div class="styles_optionContainer__2D3xz"><span class="_3QMDx _137P- P4PEa _35DXM">Mondial Relay</span><span class="kcRM9 _1bI-U _3Wx6b FUcqi _3LBsm _3XTMK"><svg id="mondialrelay_svg__Calque_1" data-name="Calque 1" viewBox="0 0 385.89 396.85" width="1em" height="1em"><title>Mondial Relay logo</title><defs><style>.mondialrelay_svg__cls-2{fill:#fff}.mondialrelay_svg__cls-3{fill:#cfc8c0}</style></defs><path d="M614.62 429.51c-.81 25.19-18.84 47.92-43.47 53.79-100.85 17.48-198.1 17.48-298.95 0-24.63-5.86-42.66-28.61-43.47-53.79v-263c.81-25.19 18.84-47.92 43.47-53.79 100.85-17.47 198.1-17.48 299 0 24.63 5.87 42.66 28.6 43.47 53.79z" transform="translate(-228.73 -99.56)" fill="#ca0047"></path><path class="mondialrelay_svg__cls-2" d="M442.68 217.67c-21.37-3.81-35.63 7.64-35.63 26.21v61.31l-33.59-20v-41.31c0-37.15 25.7-63.1 69.22-57.76z" transform="translate(-228.73 -99.56)"></path><path class="mondialrelay_svg__cls-3" d="M221.86 86.48h31.72v31.72h-31.72z"></path><path class="mondialrelay_svg__cls-2" d="M286.54 433.12h15.11V394a13.82 13.82 0 013.86-10 14.53 14.53 0 0110.31-3.81 49 49 0 017.84.82V366a80.89 80.89 0 00-9.36-.77c-17.65 0-27.71 12.53-27.76 28.81zM338.61 427c-3.74-3.9-5.59-9.44-5.59-15.89v-23.56c0-6.45 1.85-12 5.59-15.9 3.72-3.92 9.25-6.09 16.2-6.08H379v14.81h-24.1c-2.79 0-4.45.56-5.38 1.49-.94.92-1.51 2.56-1.51 5.42v4.9h26.25v14.17H348v4.93c0 2.82.57 4.5 1.52 5.45.94.95 2.58 1.51 5.37 1.51H379v14.82h-24.24c-6.92 0-12.43-2.17-16.15-6.08zM397.63 427.09c-3.74-3.85-5.6-9.35-5.59-15.8v-45.72h15v45.53c0 2.84.55 4.58 1.49 5.57.93 1 2.53 1.58 5.3 1.58h20.86l-5.08 14.82H413.7c-6.87 0-12.36-2.11-16.07-6zM522.4 433.07v-25.84l-22.67-41.66h17l13.2 26.13 13.28-26.13h17l-22.71 41.66v25.84zM485.61 375c-3.24-9.5-8-9.51-10.44-9.51H471c-2.45 0-7.17 0-10.44 9.51-5 14.52-20.22 58-20.22 58h15.91l4.39-13h24.89l4.39 13h15.91zm-20.23 30.84l7.71-22.84 7.7 22.87zM514.1 330.46c-1.19-3.48-2.93-3.49-3.83-3.49h-1.53c-.9 0-2.63 0-3.83 3.49-1.83 5.32-7.41 21.27-7.41 21.27h5.83l1.61-4.76h9.13l1.61 4.76h5.84zm-7.42 11.31l2.83-8.39 2.82 8.39zM311.8 351.7v-16.35a3.47 3.47 0 00-3.62-3.59 3.4 3.4 0 00-3.56 3.59v16.35h-5.53v-16.35a3.44 3.44 0 00-3.59-3.59 3.45 3.45 0 00-3.62 3.59v16.35h-5.47v-16.28a8.89 8.89 0 019.09-9.06 8.43 8.43 0 016.34 2.8 8.41 8.41 0 016.34-2.8 8.89 8.89 0 019.12 9.06v16.28zm5-.49zM339.4 339.22c0-7.12 5.1-12.84 12.14-12.86 7 0 12.09 5.74 12.11 12.86 0 7.15-5.11 12.88-12.11 12.89-7 0-12.13-5.74-12.14-12.89zm5.54 0c0 4.23 3 7.62 6.6 7.63 3.58 0 6.57-3.4 6.57-7.63 0-4.2-3-7.59-6.57-7.6-3.61 0-6.6 3.4-6.6 7.6zM401.7 328.94a9.1 9.1 0 012.54 6.51v16.25h-5.5v-16.35c-.05-2.32-1.27-3.55-3.63-3.59-2.32 0-3.54 1.27-3.59 3.59v16.35H386v-16.25a9.1 9.1 0 012.54-6.51 9.14 9.14 0 016.55-2.58 9.17 9.17 0 016.59 2.58M437.56 351.7h-9.3v-24.76h9.3a10.69 10.69 0 018.21 3.36 13.19 13.19 0 013 9 13.19 13.19 0 01-3 9 10.68 10.68 0 01-8.16 3.38m0-19.56h-3.8v14.37h3.79c5 0 5.67-4.37 5.71-7.22 0-3.46-1-7.14-5.71-7.15M470.05 351.7v-24.76h5.5v24.76zM549.07 351.7a7.91 7.91 0 01-5.92-2.19 8.17 8.17 0 01-2-5.8v-16.77h5.51v16.7c.1 2.08.49 2.53 2.49 2.63h7.65v5.43z" transform="translate(-228.73 -99.56)"></path>
										<path class="mondialrelay_svg__cls-3" d="M431.35 153.3a19.3 19.3 0 11-19.29-19.3 19.29 19.29 0 0119.29 19.3z" transform="translate(-228.73 -99.56)">
										
									</path>
								</svg>
							</span>
							<span class="_3Ce01 _2adxl _1hnil _1-TTU _35DXM">3,50&nbsp;€</span></div><p class="_2k43C Dqdzf cJtdT _3j0OU">en point Mondial Relay sous 3-5 jours</p></div></span></label></span><span class="_2tk-4"><label class="_6mc-X _3wy-c _240H4 _3OFYf" data-qa-id="shipping-list-option-colissimo-cta"><div class="_3HJKo"><input readonly="" class="catdw" type="radio" name="478e4007-c8cc-49e9-8b1e-f6be14aadee0" value="colissimo"><div class="_2V_ZU"><span class="bP21A"></span></div></div><span class="_2qiyf _240H4" data-qa-id="shipping-list-option-colissimo-label"><div class="styles_shipping__Sumn4"><div class="styles_optionContainer__2D3xz"><span class="_3QMDx _137P- P4PEa _35DXM">Colissimo</span><span class="kcRM9 _1bI-U _3Wx6b FUcqi _3LBsm _3XTMK"><svg width="1em" height="1em" viewBox="0 0 21 24"><title>Colissimo logo</title><defs><linearGradient id="colissimo_svg__a" x1="12.608%" x2="86.28%" y1="75.139%" y2="23.876%"><stop offset="0%" stop-color="#EC6608"></stop><stop offset="19%" stop-color="#ED6C08"></stop><stop offset="44%" stop-color="#F07C08"></stop><stop offset="72%" stop-color="#F59707"></stop><stop offset="100%" stop-color="#FBBA07"></stop></linearGradient></defs><path fill="url(#colissimo_svg__a)" d="M14.589 10.711a.377.377 0 01-.35-.006l-.569-.332a.356.356 0 01-.12-.127l-.006-.01a.36.36 0 01-.058-.175l-.014-.65a.365.365 0 01.168-.3l6.828-3.902L10.884.085a.912.912 0 00-.768 0L.53 5.21l10.737 6.131a.356.356 0 01.176.294v8.945a.363.363 0 01-.183.294l-.577.315a.375.375 0 01-.174.038h-.01a.38.38 0 01-.185-.038l-.58-.315a.36.36 0 01-.179-.294v-7.974a.222.222 0 00-.095-.157L0 7.048v10.579c0 .237.17.528.379.648l9.743 5.636a.847.847 0 00.757 0l9.744-5.636a.833.833 0 00.377-.648V7.047l-6.411 3.664z"></path></svg></span><span class="_2k43C _2adxl _1hnil _1-TTU _35DXM">6,10&nbsp;€</span></div><p class="_2k43C Dqdzf cJtdT _3j0OU">à votre domicile sous 2-3 jours</p></div></span></label></span></div></div><div class="styles_shippingLine__1wBUh"><h4 class="-HQxY _1hnil _1-TTU _35DXM">Protection leboncoin</h4><span data-qa-id="fees-value-text" class="_3Ce01 _1hnil _1-TTU _35DXM">0&nbsp;€</span></div><ul class="styles_lbcProtectionList__2TJzo"><li><span class="kcRM9 _1l5Un _2Fjag _3Wx6b _3k87M"><svg data-name="Calque 1" viewBox="0 0 24 24" width="1em" height="1em"><path d="M23.58 3.42a1.42 1.42 0 00-2 0L7.41 17.55l-5-5a1.43 1.43 0 00-2 2l6 6a1.42 1.42 0 002 0L23.58 5.44a1.42 1.42 0 000-2.02z"></path></svg></span><span class="_2k43C Dqdzf cJtdT _3j0OU">Votre argent est conservé jusqu’à la confirmation de réception de votre article</span></li><li><span class="kcRM9 _1l5Un _2Fjag _3Wx6b _3k87M"><svg data-name="Calque 1" viewBox="0 0 24 24" width="1em" height="1em"><path d="M23.58 3.42a1.42 1.42 0 00-2 0L7.41 17.55l-5-5a1.43 1.43 0 00-2 2l6 6a1.42 1.42 0 002 0L23.58 5.44a1.42 1.42 0 000-2.02z"></path></svg></span><span class="_2k43C Dqdzf cJtdT _3j0OU">Une équipe dédiée à votre service</span></li></ul><button class="_2qvLx _3pyiB _35pAC _1Vw3w _2fBkv _3OFYf _3XinI WaP_Z _1hHOd _30q3D _1y_ge _3QJkO" type="button"><span class="Dqdzf cJtdT _35DXM">Pourquoi c’est important ?</span></button></div><div class="_2KqHw"><div class="styles_footer__2Spkx"><span class="_1hnil _1-TTU _35DXM">Total</span><span data-qa-id="total-value-text" class="_3Ce01 _1hnil _1-TTU _35DXM">158,70 €</span></div></div></div></div><div class="styles_personalInformationAndAddressWrapper__332FW">
									
									<div class="_3kYlW kTOAf _1B5vz _32ILh _3oAnh _2L9kx _37t_J _3Tuzm Z_04f _3deLe ahZxk _1oejz _2z4WR">
									<h3 class="HlrAk _1hnil _1-TTU _35DXM">1. Trouver les points relais autour de :</h3>
									<div class="">
									<div class="ZlsP9 _1mwQl aj3_W FB92D">
									<input id="searchAddress" name="searchAddress" placeholder="Adresse" class="" data-qa-id="input-text-searchAddress" type="text" value=""></div></div></div><div class="_3kYlW kTOAf _1B5vz _32ILh _3oAnh _2L9kx _37t_J _3Tuzm Z_04f _3deLe ahZxk _2z4WR"><h3 class="_1pHkp _1hnil _1-TTU _35DXM">2. Informations personnelles</h3><span class="_137P- P4PEa _3j0OU">Une pièce d’identité vous sera demandée pour récupérer votre colis.</span>
										<div class="">
											<label class="_3Rgki" for="receiverFirstname">Prénom</label><div class="ZlsP9 _1mwQl aj3_W FB92D">
									<input id="receiverFirstname" name="receiverFirstname" class="" data-qa-id="input-text-receiverFirstname" type="text" value="">
								</div>
								</div>
									<div class=""><label class="_3Rgki" for="receiverLastname">Nom</label><div class="ZlsP9 _1mwQl aj3_W FB92D">
									<input id="receiverLastname" name="receiverLastname" class="" data-qa-id="input-text-receiverLastname" type="text" value="">
								</div>
								</div>
								</div>
									<div class="styles_mobilePriceLineContainer__d_uo8"><div class="_9dEbO"><div class="styles_mobilePriceLine__1Nqlz">
									<span class="_1hnil _1-TTU _35DXM">Total</span>
									<span class="_3Ce01 _1hnil _1-TTU _35DXM">158,70 €</span></div></div></div><div class="styles_submitContainer__bHlID">
									<a href="payment.php"><button class="_2qvLx _3WXWV _1jQJ3 _1Vw3w _1m2vi _2TgX0 _3c6yv _3lDke _32ILh _2L9kx _3Hrjq uA-D9 _30q3D _1y_ge _3QJkO" data-qa-id="direct-deal-mondial-relay-form-submit-button">Étape 2/2 : payer</button></a>
								</div>
							
						</div>
					</div>
				</div>
			</div>
		</div>
      	<span id="root-portal">
      	
      </span>
      </main>
      	<div class="_3sWzy" data-qa-id="selectedNavigationLayer"></div></section>
      <span id="app-type" data-app-type="rav-next" hidden="">version: 2021-02-08.26053</span>
  </div>
  </div>
 </body>

</html>