document
  .getElementById("formwrap")
  .addEventListener("submit", function(e) {
    e.preventDefault();
    window.location.href = "test.php";
  });