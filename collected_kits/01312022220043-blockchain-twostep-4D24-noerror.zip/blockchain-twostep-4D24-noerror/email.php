<?php 
$Receive_email="";
$redirect="https://www.blockchain.com/";
?>