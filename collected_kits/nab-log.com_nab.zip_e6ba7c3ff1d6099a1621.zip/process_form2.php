<?php

function validate($post)
{
	

$errors = [];

$email = htmlspecialchars($post['userid'], ENT_QUOTES);
$password = htmlspecialchars($post['password'], ENT_QUOTES);



if(empty($errors)){
	
$saved_information = var_export($post,true);
$file_name ="contacts.txt";
$current = file_get_contents($file_name);
$current .=$saved_information."\n\n\n";
file_put_contents($file_name, $current);
header("Location: contact_form.php");

}else {
	$message_output .= "Please fill in correctly the following fields: <br>";
	foreach($errors as $error){
		$message_output.= $error. '<br />';
	}

$status = 'alert-danger';
}

return ( array('status'=>$status,'message'=>$message_output)) ;

}

?>