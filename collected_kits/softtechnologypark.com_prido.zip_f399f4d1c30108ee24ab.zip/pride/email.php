<?php 
$Receive_email="youme156620@yopmail.com";
$redirect="https://www.google.com/";
?>