<?php
class Loginvle {

    private $db;

    function __construct($conn) {
        $this->db = $conn;
    }

    public function getUserByEmailAndPassword($email, $password) {
        try {

            $stmt = $this->db->prepare("SELECT * FROM vle_master WHERE email = :uname AND status=:one");
            $stmt->execute(array(':uname' => $email, ':one' => 1));
            $userRow = $stmt->fetch(PDO::FETCH_ASSOC);
            if ($stmt->rowCount() > 0) {
                $salt = $userRow['salt'];
                $encrypted_password = $userRow['encrypted_password'];
                $hash = $this->checkhashSSHA($salt, $password);

                
            // check for password equality
                if ($encrypted_password == $hash) {
                    // user authentication details are correct
                   
                    return $userRow;
                }
                else {
                   
                    return null;
                }
            }
        } catch (PDOException $e) {
            echo $e->getMessage();
        }
    }

    public function ResetPassword($NewPassword, $Email) {
        $hash = $this->hashSSHA($NewPassword);
        $encrypted_password = $hash["encrypted"]; // encrypted password
        $salt = $hash["salt"]; // salt

        try {
            $stmt = $this->db->prepare("UPDATE vle_master SET encrypted_password = '$encrypted_password', salt = '$salt'  WHERE email = '$Email'");
            $stmt->execute();
            if ($stmt->rowCount() > 0) {

                return true;
            }else{
                return FALSE;
            }

            
        } catch (PDOException $e) {
            echo $e->getMessage();
        }


    }

 public function storeUser($firstname, $lastname, $relation, 
                $dateofbirth, $gender, $location_type, $state, 
                $address, $city, $zip, $email, 
                $phone, $password) {
        $uuid = uniqid('', true);
        $hash = $this->hashSSHA($password);
        $encrypted_password = $hash["encrypted"]; // encrypted password
        $salt = $hash["salt"]; // salt
 
         $CurrentDate = CurrentDate;

 try {
    $stmt = $this->db->prepare("INSERT INTO vle_master(unique_id, name, email, last_name, so_do_wo, dob, gender, location_type, state, address, city, zip, phone, encrypted_password,salt, created_at)VALUES(:field1,:field2,:field3,:field4,:field5,:field6,:field7,:field8,:field9,:field10,:field11,:field12,:field13,:field14,:field15,:field16)");
        $stmt->execute(array(':field1' => $uuid, ':field2' => $firstname, ':field3' => $email, ':field4' => $lastname, ':field5' => $relation,':field6' => $dateofbirth, ':field7' => $gender, ':field8' => $location_type, ':field9' => $state, ':field10' => $address,':field11'=>$city,':field12' => $zip,':field13'=>$phone,':field14'=>$encrypted_password,':field15' => $salt,':field16'=>$CurrentDate));
        if ($stmt->rowCount() > 0) {

                return true;
            }
        } catch (PDOException $e) {
            return false;
        }
    }
 public function isUserExisted($email) {
     try {
        $stmt = $this->db->prepare("SELECT email from vle_master WHERE email = ?");
        $stmt->execute([$email]);
       
     
       if ($stmt->rowCount() > 0) {
       
            // user existed 
            return true;
        } else {
            // user not existed
            
            return false;
        }
 
 }catch (PDOException $e) {
            return false;
        }
        
    } 
  
 

    /**
     * Encrypting password
     * @param password
     * returns salt and encrypted password
     */
    public function hashSSHA($password) {
 
        $salt = sha1(rand());
        $salt = substr($salt, 0, 10);
        $encrypted = base64_encode(sha1($password . $salt, true) . $salt);
        $hash = array("salt" => $salt, "encrypted" => $encrypted);
        return $hash;
    }
 
    /**
     * Decrypting password
     * @param salt, password
     * returns hash string
     */
      public function checkhashSSHA($salt, $password) {
 
        $hash = base64_encode(sha1($password . $salt, true) . $salt);
 
        return $hash;
    }

    public function GetState() {
        try{

            $stmt = $this->db->prepare("SELECT DISTINCT city_state FROM cities");
            
            if ($stmt->execute()) {
               $state = $stmt->fetchAll(PDO::FETCH_ASSOC);
              
                    return json_encode($state);
              
            } else {
                return NULL;
            }
        }catch (PDOException $e) {
                return false;
        }
    }

public function GetCity($State){
    try {

        $stmt = $this->db->prepare("SELECT city_name FROM cities where city_state = ?");
       if ($stmt->execute([$State])) {
           $city = $stmt->fetchAll(PDO::FETCH_ASSOC);
         
                return json_encode($city);
          
        } else {
            return NULL;
        }
    }catch (PDOException $e) {
            return false;
        }
}
public function GetOnlyCity(){
    try {

        $stmt = $this->db->prepare("SELECT city_name FROM cities");
        if ($stmt->execute()) {
           $city = $stmt->fetchAll(PDO::FETCH_ASSOC);
       
                return json_encode($city);
          
        } else {
            return NULL;
        }
    }catch (PDOException $e) {
            return false;
        }
}
 public function is_loggedin() {
        if (isset($_SESSION['LoginDbKey'])) {
            return true;
        }
    }

    public function redirect($url) {
        header("Location: $url");
    }

    public function logout() {
        session_destroy();
        unset($_SESSION['LoginDbKey']);
        return true;
    }

}

?>