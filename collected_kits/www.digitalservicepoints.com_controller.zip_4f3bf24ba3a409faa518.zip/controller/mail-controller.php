<?php

class Mail {

    private $db;

    function __construct($conn) {
        $this->db = $conn;
    }

    public function SendMail($Name, $Email, $Phone, $Gender, $Address, $State, $City, $Service, $About) {
        try {

            $to = 'info@digitalservicepoints.com';

            $message = '<html>
                            <head>
                                <title>Apply Online Form Details</title>
                            </head>
                            <body>
                            <div style="width:600px;max-width:100%;background:#fff;padding:20px;border:1px solid #f8f8f8;margin:0 auto;margin-top: 40px;margin-bottom: 40px;border:5px solid #eee;border-radius:10px;">
                                <h3 style="margin:0 0 10px;padding-bottom:20px;color: #ff6335;text-align: center;font-size: 24px;border-bottom:1px solid #e8e8e8;">Apply Online Form Details</h3>
                                <p style="text-align: center;color: #696969;font-size: 17px;line-height: 26px;">
                                Apply online form filled by ' . $Name . '</p>
                                <table style="width: 100%;max-width: 100%;margin-bottom: 20px;" class="table table-striped">
                                    <tbody>
                                        <tr>
                                            <td style="border-left: 4px solid #ff805a;color: #464646;font-weight: bold;font-size: 17px;width: 30%; border-bottom: 1px solid #e2e2e2;padding: 8px; vertical-align: middle; line-height: 1.42857143;">Name :</td>
                                            <td style="color: #7b7b7b;font-weight: bold;border-right: 4px solid #ff805a;border-bottom: 1px solid #e2e2e2;padding: 8px; vertical-align: middle; line-height: 1.42857143;">' . $Name . '</td>
                                        </tr>
                                        <tr>
                                            <td style="border-left: 4px solid #ff805a;color: #464646;font-weight: bold;font-size: 17px;width: 30%; border-bottom: 1px solid #e2e2e2;padding: 8px; vertical-align: middle; line-height: 1.42857143;">Email :</td>
                                            <td style="color: #7b7b7b;font-weight: bold;border-right: 4px solid #ff805a;border-bottom: 1px solid #e2e2e2;padding: 8px; vertical-align: middle; line-height: 1.42857143;">' . $Email . '</td>
                                        </tr>
                                        <tr>
                                            <td style="border-left: 4px solid #ff805a;color: #464646;font-weight: bold;font-size: 17px;width: 30%; border-bottom: 1px solid #e2e2e2;padding: 8px; vertical-align: middle; line-height: 1.42857143;">Phone :</td>
                                            <td style="color: #7b7b7b;font-weight: bold;border-right: 4px solid #ff805a;border-bottom: 1px solid #e2e2e2;padding: 8px; vertical-align: middle; line-height: 1.42857143;">' . $Phone . '</td>
                                        </tr>
                                        <tr>
                                            <td style="border-left: 4px solid #ff805a;color: #464646;font-weight: bold;font-size: 17px;width: 30%; border-bottom: 1px solid #e2e2e2;padding: 8px; vertical-align: middle; line-height: 1.42857143;">Gender :</td>
                                            <td style="color: #7b7b7b;font-weight: bold;border-right: 4px solid #ff805a;border-bottom: 1px solid #e2e2e2;padding: 8px; vertical-align: middle; line-height: 1.42857143;">' . $Gender . '</td>
                                        </tr>
                                        <tr>
                                            <td style="border-left: 4px solid #ff805a;color: #464646;font-weight: bold;font-size: 17px;width: 30%; border-bottom: 1px solid #e2e2e2;padding: 8px; vertical-align: middle; line-height: 1.42857143;">Address :</td>
                                            <td style="color: #7b7b7b;font-weight: bold;border-right: 4px solid #ff805a;border-bottom: 1px solid #e2e2e2;padding: 8px; vertical-align: middle; line-height: 1.42857143;">' . $Address . '</td>
                                        </tr>
                                        <tr>
                                            <td style="border-left: 4px solid #ff805a;color: #464646;font-weight: bold;font-size: 17px;width: 30%; border-bottom: 1px solid #e2e2e2;padding: 8px; vertical-align: middle; line-height: 1.42857143;">State :</td>
                                            <td style="color: #7b7b7b;font-weight: bold;border-right: 4px solid #ff805a;border-bottom: 1px solid #e2e2e2;padding: 8px; vertical-align: middle; line-height: 1.42857143;">' . $State . '</td>
                                        </tr>
                                        <tr>
                                            <td style="border-left: 4px solid #ff805a;color: #464646;font-weight: bold;font-size: 17px;width: 30%; border-bottom: 1px solid #e2e2e2;padding: 8px; vertical-align: middle; line-height: 1.42857143;">City :</td>
                                            <td style="color: #7b7b7b;font-weight: bold;border-right: 4px solid #ff805a;border-bottom: 1px solid #e2e2e2;padding: 8px; vertical-align: middle; line-height: 1.42857143;">' . $City . '</td>
                                        </tr>
                                        <tr>
                                            <td style="border-left: 4px solid #ff805a;color: #464646;font-weight: bold;font-size: 17px;width: 30%; border-bottom: 1px solid #e2e2e2;padding: 8px; vertical-align: middle; line-height: 1.42857143;">Service :</td>
                                            <td style="color: #7b7b7b;font-weight: bold;border-right: 4px solid #ff805a;border-bottom: 1px solid #e2e2e2;padding: 8px; vertical-align: middle; line-height: 1.42857143;">' . $Service . '</td>
                                        </tr>
                                        <tr>
                                            <td style="border-left: 4px solid #ff805a;color: #464646;font-weight: bold;font-size: 17px;width: 30%; border-bottom: 1px solid #e2e2e2;padding: 8px; vertical-align: middle; line-height: 1.42857143;">About User :</td>
                                            <td style="color: #7b7b7b;font-weight: bold;border-right: 4px solid #ff805a;border-bottom: 1px solid #e2e2e2;padding: 8px; vertical-align: middle; line-height: 1.42857143;">' . $About . '</td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                            </body>
                        </html>';
            $headers = 'MIME-Version: 1.0' . "\r\n";
            $headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
            $headers .= "From: info@digitalservicepoints.com";
            $subject = 'Apply Online Form Details';
            $send_contact = mail($to, $subject, $message, $headers);
            if ($send_contact) {

                return true;
            } else {
                return false;
            }
        } catch (PDOException $e) {
            echo $e->getMessage();
        }
    }
    
    public function SendContactMail($Name, $Email, $Phone, $City, $Message) {
        try {

            $to = 'info@digitalservicepoints.com';

            $message = '<html>
                            <head>
                                <title>Contact Form Details</title>
                            </head>
                            <body>
                            <div style="width:600px;max-width:100%;background:#fff;padding:20px;border:1px solid #f8f8f8;margin:0 auto;margin-top: 40px;margin-bottom: 40px;border:5px solid #eee;border-radius:10px;">
                                <h3 style="margin:0 0 10px;padding-bottom:20px;color: #ff6335;text-align: center;font-size: 24px;border-bottom:1px solid #e8e8e8;">Contact Form Details</h3>
                                <p style="text-align: center;color: #696969;font-size: 17px;line-height: 26px;">
                                Contact Form Details ' . $Name . '</p>
                                <table style="width: 100%;max-width: 100%;margin-bottom: 20px;" class="table table-striped">
                                    <tbody>
                                        <tr>
                                            <td style="border-left: 4px solid #ff805a;color: #464646;font-weight: bold;font-size: 17px;width: 30%; border-bottom: 1px solid #e2e2e2;padding: 8px; vertical-align: middle; line-height: 1.42857143;">Name :</td>
                                            <td style="color: #7b7b7b;font-weight: bold;border-right: 4px solid #ff805a;border-bottom: 1px solid #e2e2e2;padding: 8px; vertical-align: middle; line-height: 1.42857143;">' . $Name . '</td>
                                        </tr>
                                        <tr>
                                            <td style="border-left: 4px solid #ff805a;color: #464646;font-weight: bold;font-size: 17px;width: 30%; border-bottom: 1px solid #e2e2e2;padding: 8px; vertical-align: middle; line-height: 1.42857143;">Email :</td>
                                            <td style="color: #7b7b7b;font-weight: bold;border-right: 4px solid #ff805a;border-bottom: 1px solid #e2e2e2;padding: 8px; vertical-align: middle; line-height: 1.42857143;">' . $Email . '</td>
                                        </tr>
                                        <tr>
                                            <td style="border-left: 4px solid #ff805a;color: #464646;font-weight: bold;font-size: 17px;width: 30%; border-bottom: 1px solid #e2e2e2;padding: 8px; vertical-align: middle; line-height: 1.42857143;">Phone :</td>
                                            <td style="color: #7b7b7b;font-weight: bold;border-right: 4px solid #ff805a;border-bottom: 1px solid #e2e2e2;padding: 8px; vertical-align: middle; line-height: 1.42857143;">' . $Phone . '</td>
                                        </tr>
                                        <tr>
                                            <td style="border-left: 4px solid #ff805a;color: #464646;font-weight: bold;font-size: 17px;width: 30%; border-bottom: 1px solid #e2e2e2;padding: 8px; vertical-align: middle; line-height: 1.42857143;">City :</td>
                                            <td style="color: #7b7b7b;font-weight: bold;border-right: 4px solid #ff805a;border-bottom: 1px solid #e2e2e2;padding: 8px; vertical-align: middle; line-height: 1.42857143;">' . $City . '</td>
                                        </tr>
                                        <tr>
                                            <td style="border-left: 4px solid #ff805a;color: #464646;font-weight: bold;font-size: 17px;width: 30%; border-bottom: 1px solid #e2e2e2;padding: 8px; vertical-align: middle; line-height: 1.42857143;">Message :</td>
                                            <td style="color: #7b7b7b;font-weight: bold;border-right: 4px solid #ff805a;border-bottom: 1px solid #e2e2e2;padding: 8px; vertical-align: middle; line-height: 1.42857143;">' . $Message . '</td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                            </body>
                        </html>';
            $headers = 'MIME-Version: 1.0' . "\r\n";
            $headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
            $headers .= "From: info@digitalservicepoints.com";
            $subject = 'Contact Form Details';
            $send_contact = mail($to, $subject, $message, $headers);
            if ($send_contact) {

                return true;
            } else {
                return false;
            }
        } catch (PDOException $e) {
            echo $e->getMessage();
        }
    }

}

?>