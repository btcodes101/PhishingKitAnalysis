<?php
/*
  $Id: virtualmerchant.php,v 1.00 2007/11/09 08:46:00 roberto Exp $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2007 Robertas Dereskevicius <roberto@mikrolineage.lt>
*/

  define('MODULE_PAYMENT_VIRTUALMERCHANT_CC_TEXT_TITLE', 'VirtualMerchant (Credit Card)');
  define('MODULE_PAYMENT_VIRTUALMERCHANT_CC_TEXT_PUBLIC_TITLE', 'Credit Card');
  define('MODULE_PAYMENT_VIRTUALMERCHANT_CC_TEXT_DESCRIPTION', '<img src="images/icon_popup.gif" border="0">&nbsp;<a href="http://www.myvirtualmerchant.com" style="text-decoration: underline; font-weight: bold;">Visit VirtualMerchant Website</a><br><br>VirtualMerchant Credit Card Processing<br><br>cURL is required for this module to function properly (either as an extension to PHP or as an executable program)');
  define('MODULE_PAYMENT_VIRTUALMERCHANT_CC_CREDIT_CARD_OWNER', 'Credit Card Owner:');
  define('MODULE_PAYMENT_VIRTUALMERCHANT_CC_CREDIT_CARD_NUMBER', 'Credit Card Number:');
  define('MODULE_PAYMENT_VIRTUALMERCHANT_CC_CREDIT_CARD_EXPIRES', 'Credit Card Expiry Date:');
  define('MODULE_PAYMENT_VIRTUALMERCHANT_CC_CREDIT_CARD_CVC', 'Credit Card Check Number (CVC):');
  define('MODULE_PAYMENT_VIRTUALMERCHANT_CC_ERROR_GENERAL', 'There has been an error processing your credit card. Please try again.');
  define('MODULE_PAYMENT_VIRTUALMERCHANT_CC_TEXT_ERROR', 'Credit Card Error!');
?>
