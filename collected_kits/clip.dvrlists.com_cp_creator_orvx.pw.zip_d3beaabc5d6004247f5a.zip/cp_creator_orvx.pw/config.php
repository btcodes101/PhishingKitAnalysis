<?php
$cpanel_email = ""; // write cpanel email you want
$pkg_name = "default";// write your package name
?>
