<?php
$yourmail  = 'zans101@outlook.com,mrmakg6@gmail.com';  // PUT YOUR E-MAIL HERE
?>