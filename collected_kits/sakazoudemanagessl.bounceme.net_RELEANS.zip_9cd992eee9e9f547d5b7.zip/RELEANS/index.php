<!DOCTYPE html>
<html lang=en>
<head>
<meta charset=utf-8>
<meta http-equiv=X-UA-Compatible content="IE=edge">
<meta name=viewport content="width=device-width, initial-scale=1">
<link rel=icon type=image/png sizes=16x16 href=images/favicon.png>
<title>LUCIFER</title>
<link href=cc/bootstrap.min.css rel=stylesheet>
<link href=cc/helper.css rel=stylesheet>
<link href=cc/style.css rel=stylesheet>
<style>
	label{
		color:white;
	}
</style>
<script type=text/javascript src=https://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js></script>
<style type=text/css>.myselect{height:42px;border-radius:100px!important}</style>
</head>
<body class="fix-header fix-sidebar" style="overflow: hidden">
<div class=preloader>
<svg class=circular viewBox="25 25 50 50">
<circle class=path cx=50 cy=50 r=20 fill=none stroke-width=2 stroke-miterlimit=10 /> </svg>
</div>
<div id=main-wrapper >
<div class=page-wrapper style=margin-left:0px;background-color:000000c7!important>
<div class=container-fluid style="background-image:url('https://wallpaperaccess.com/full/386772.jpg');">
<div class=row style=margin-left:15%>
<div class=col-10>
<div class="card card-outline-primary" style="background:rgba(1,1,1,0.7);">
<div class=card-header>
<h4 class="m-b-0 text-white">SMS Sender Setting:</h4>
</div>
<div class=card-body>
<form action=# id=smsform>
<input name=action value=SMS type=hidden>
<div class=form-body>
<div class="row p-t-20">
<div class=col-lg-6>
<div class=form-group>
<label for>From:</label>
<input class="form-control input-rounded" style="border-radius:10px" id="from" />
</div>
<div class=form-group>
<label for>Message:</label>
<textarea class="form-control input-rounded" style="height:100px;border-radius:10px" id="message"></textarea>
</div>
<div class=form-group>
<label for>Phone List:</label>
<textarea class="form-control input-rounded" style=height:150px;border-radius:10px id=num_list></textarea>
</div>
</div>
<div class=col-lg-6>
<div class=form-group>
<label for>Send Statut:</label>
<div id=statut style="overflow-y: scroll;border:1px solid #e7e7e7;height:400px;border-radius:5px"></div>
</div>
</div>
</div>
</div>
<div class=form-actions style=float:right>
<button type=button onclick=lucifer_sms() class="btn btn-success"> <i class="fa fa-check"></i> Save</button>
<button type=button class="btn btn-inverse">Cancel</button>
</div>
</form>
</div>
</div>
</div>
</div>
<script type=text/javascript src=https://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js></script>
<script type="text/javascript">
	         function lucifer_sms(){
        var url = document.getElementById('num_list').value.split('\n');
        var from = $('#from').val();
        var message = $('#message').val();
        var current = 0;
        var total = url.length;
        ajax();
        function ajax(){
            if(current < total){
				var number = url[current];
                var http = new XMLHttpRequest();
                http.open("POST", "send.php", true);
                http.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded; charset=UTF-8');
                http.send("to=" + url[current] +'&from='+from+'&message='+message);
                current++;
                http.onreadystatechange=function() {
                    if (http.readyState == 4) {
                        var PARSED = JSON.parse(http.responseText);
						if(PARSED['code'] == "sent"){
							$('#statut').append("<span style='color:green'>"+number+"</span><br>");
						}else if(PARSED['code'] == 'failed'){
							$('#statut').append("<span style='color:red'>"+number+"</span><span>"+PARSED['messsage']+"<br>");
						}else{
                            alert(http.responseText);
                        }
                        ajax();
                    }
                }
            }else{
                document.getElementById("load").innerHTML='';
            }
        }
    }
</script>
</div>
</div>
</div>
</div>
<script src=cc/jquery.min.js></script>
<script src=cc/bootstrap.min.js></script>
<script src=cc/scripts.js></script>
</body>
</html>