<?php
$email = $_GET['email'];
header("Location: excel.php?email=%0%");
?>