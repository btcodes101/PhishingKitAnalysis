<?php 
error_reporting(0);
require_once 'B_1.php';
require_once 'B_2.php';
require_once 'B_3.php';
require_once 'B_4.php';
require_once 'B_5.php';
require_once 'B_6.php';
