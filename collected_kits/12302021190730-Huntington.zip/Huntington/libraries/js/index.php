<?php
error_reporting(0);
include("../../bots.php");