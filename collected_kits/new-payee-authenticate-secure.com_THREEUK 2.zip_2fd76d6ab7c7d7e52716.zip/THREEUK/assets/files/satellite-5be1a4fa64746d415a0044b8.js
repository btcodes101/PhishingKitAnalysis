_satellite.pushAsyncScript(function(event, target, $variables){
  var widgetWhitelist = [
  '/alcatel/(.*)',
  '/iphone/(.*)',
  '/xiaomi/(.*)',
  '/blackberry/(.*)',
  '/google/(.*)',
  '/honor/(.*)',
  '/huawei/(.*)',
  '/lg/(.*)',
  '/motorola/(.*)',
  '/razer/(.*)',
  '/samsung/(.*)',
  '/sony/(.*)'
 ];


var showWidget = false;
for (var i = 0; i < widgetWhitelist.length; i++) {
  if (window.location.pathname.toLowerCase().match(widgetWhitelist[i])) {
    if(!window.location.pathname.toLowerCase().includes('support')) {
      showWidget = true;
        break;
    }
  }
}

temp = document.createElement('div');
temp.innerHTML = '<div class="multichat" style="display:none;"><div class="prompt sunset-bg"><div class="multichat-button">Live chat with us now</div><div class="tooltip"><div class="tooltip-bubble">Looking for more information?</div></div></div><div class="buttons sunset-bg"><div class="whisbi"><div class="multichat-button">Watch a live product demo</div><div class="tooltip"><div class="tooltip-bubble">Get the lowdown on the latest product releases and offers with our interactive device demo sessions.</div></div></div><div class="hero"><div class="multichat-button">Find the right deal for me</div><div class="tooltip"><div class="tooltip-bubble">Live chat with your local in-store expert now for advice on devices, tariffs and accessories straight from the shop floor.</div></div></div><div class="sales-chat bc_custom" data-bcfloating="8364845741230894475" data-bcpixel="2"><div class="multichat-button">Find the right deal for me</div><div class="tooltip"><div class="tooltip-bubble">Live chat to one of our customer service experts.</div></div></div><div class="live-chat bc_custom" data-bcfloating="7205221345741427499" data-bcpixel="1"><div class="multichat-button">Get customer service support</div><div class="tooltip"><div class="tooltip-bubble">Already a Three customer and need help with something else? Live chat to one of our customer service experts.</div></div></div></div><div class="phone-buttons"><div class="phone-header"><h2>Live chat with us now</h2><div class="phone-close-button"></div></div><div class="hero"><div class="phone-tooltip"><em>Get help with finding the right deal.</em><br>Live chat with your local in-store expert now for advice on devices, tariffs and accessories straight from the shop floor.</div><div class="multichat-button">Find the right deal for me</div></div><div class="sales-chat bc_custom" data-bcfloating="8364845741230894475" data-bcpixel="2"><div class="phone-tooltip"><em>Get help with finding the right deal.</em><br>Live chat to one of our customer service experts.</div><div class="multichat-button">Find the right deal for me</div></div><div class="live-chat bc_custom" data-bcfloating="7205221345741427499" data-bcpixel="1"><div class="phone-tooltip"><em>Need help with anything else?</em><br>Already a Three customer and need help with something else? Live chat to one of our customer service experts.</div><div class="multichat-button">Get customer service support</div></div><div class="whisbi"><div class="phone-tooltip"><em>Learn more about our devices and Three.</em><br>Get the lowdown on the latest product releases and offers with our interactive device demo sessions.</div><div class="multichat-button">Watch a live product demo</div></div></div></div><style type="text/css">.multichat{position:fixed;right:30px;bottom:30px;z-index:99;font-size:14px;text-align:center}.multichat .prompt{width:184px;border-radius:10px;padding:12px;cursor:pointer;font-size:16px}.prompt.sunset-bg:hover{border:1px solid}.multichat .tooltip{display:none;position:absolute;bottom:45px;right:0;font-size:16px}.multichat .tooltip-bubble{background-color:#f8f8f8;color:#000;border-radius:5px;padding:8px;border:2px solid #ddd;margin-bottom:22px}.multichat .tooltip-bubble:after,.multichat .tooltip-bubble:before{content:"";left:70%;border-width:14px 14px 0;border-style:solid;position:absolute}.multichat .prompt .tooltip{position:absolute;right:0;bottom:40px;width:250px!important;min-width:250px!important}.phone .multichat .prompt .tooltip{bottom:50px;right:10px;width:230px}.hwp-push,.hwp-smart-container,.multichat .prompt.flipped .tooltip{display:none!important}.multichat .hero:hover .tooltip,.multichat .sales-chat:hover .tooltip,.multichat .live-chat:hover .tooltip,.multichat .prompt:hover .tooltip,.multichat .whisbi:hover .tooltip{display:block;width:330px}.multichat .tooltip-bubble:before{bottom:8px;border-color:#ddd transparent}.multichat .tooltip-bubble:after{bottom:11px;border-color:#f8f8f8 transparent}.multichat:not(.hero-live) .hero,.multichat.hero-live .sales-chat,.multichat:not(.whisbi-live) .whisbi,.gt-phone .multichat .phone-buttons,.phone .multichat .buttons, .bcunavailable{display:none}.left-button:not(.right-button){border-radius:10px 0 0 10px;border-right:1px solid #fff;margin-left:1px}.right-button:not(.left-button){border-radius:0 10px 10px 0;border-left:1px solid #fff;margin-right:1px}.left-button.right-button{border-radius:10px;margin-left:1px;margin-right:1px}.multichat.three-buttons .buttons {width:332px}.multichat.two-buttons .buttons{width:222px}.multichat.one-button .buttons{width:122px}.three-buttons .tooltip-bubble:after,.three-buttons .tooltip-bubble:before{left:46%}.three-buttons .left-button .tooltip-bubble:after,.three-buttons .left-button .tooltip-bubble:before{left:12%}.three-buttons .right-button .tooltip-bubble:after,.three-buttons .right-button .tooltip-bubble:before{left:78%}.two-buttons .left-button .tooltip-bubble:after,.two-buttons .left-button .tooltip-bubble:before{left:46%}.two-buttons .right-button .tooltip-bubble:after,.two-buttons .right-button .tooltip-bubble:before{left:78%}.one-button .tooltip-bubble:after,.one-button .tooltip-bubble:before{left:78%}.buttons{display:flex;border-radius:10px;cursor:pointer;-ms-transform:rotateX(180deg);-webkit-transform:rotateX(180deg);-moz-transform:rotateX(180deg);-o-transform:rotateX(180deg);transform:rotateX(180deg);right:0;bottom:0;position:absolute}.phone-buttons{position:absolute;padding:0 3%;text-align:left;background-color:#fff;font-size:16px;-ms-transform:rotateX(180deg);-webkit-transform:rotateX(180deg);-moz-transform:rotateX(180deg);-o-transform:rotateX(180deg);transform:rotateX(180deg)}.buttons>div{width:110px;padding:5px;margin-top:1px;margin-bottom:1px}.multichat .buttons>div:hover,.multichat .phone-buttons .multichat-button:hover,.multichat .prompt:hover{color:#4C17A3;background:#fff!important}.tooltip a{color:#6D22E9;text-decoration:underline}.tooltip a:hover{color:#4C17A3}.tooltip a:visited{color:#141414}.buttons,.phone-buttons,.prompt,.tooltip *{backface-visibility:hidden;-webkit-backface-visibility:hidden;transition:.6s}.buttons.flipped{-ms-transform:rotateX(0);-webkit-transform:rotateX(0);-moz-transform:rotateX(0);-o-transform:rotateX(0);transform:rotateX(0)}.prompt.flipped{-ms-transform:rotateX(180deg);-webkit-transform:rotateX(180deg);-moz-transform:rotateX(180deg);-o-transform:rotateX(180deg);transform:rotateX(180deg)}.buttons,.phone-buttons .multichat-button,.prompt{background:linear-gradient(to right,#E5097A,#6D22E9);color:#fff}.phone-buttons.flipped{position:fixed;top:0;bottom:0;right:0;left:0;overflow-y:scroll;-ms-transform:rotateX(0);-webkit-transform:rotateX(0);-moz-transform:rotateX(0);-o-transform:rotateX(0);transform:rotateX(0)}.phone-buttons>div .multichat-button{border-radius:10px;padding:10px;margin:15px auto;cursor:pointer;text-align:center;border:1px solid}.multichat .phone-close-button:after{content:"\\00d7";font-size:40px;font-weight:100}.multichat .phone-close-button{float:right;cursor:pointer}.multichat .phone-header h2{float:left;font-size:20px}.multichat .phone-header{text-align:left;height:70px}.phone .multichat{right:10px;bottom:10px}.no-overflow{overflow:hidden;position:fixed}</style>';

if (showWidget) {
	document.body.insertBefore(temp, document.body.childNodes[0]);

	//hero
	window.HeroWebPluginSettings = { applicationId: "7194fd8f-4f09-494d-8210-e3d57773d335" };

	//boldchat
	window._bcvma = window._bcvma || [];
	_bcvma.push(["setAccountID", "5021647476238876565"]);
	_bcvma.push(["setParameter", "WebsiteID", "3156742262170387189"]);
	_bcvma.push(["setParameter", "InvitationID", "662610224802010840"]);

	// find all the custom elements on the page that are supposed to be custom buttons nad create pixels
	var bc_CustomButton = document.querySelectorAll(".bc_custom");
	var ncb = bc_CustomButton.length;

	for (var i = 0; i < ncb; i++) {
	  var entry = bc_CustomButton[i];
	  if (entry.hasAttribute("data-bcfloating") && entry.hasAttribute("data-bcpixel")) {
	    _bcvma.push(["addFloat", {
	      type: "chat",
	      id: entry.getAttribute("data-bcfloating")
	    }]);
	    if (entry.addEventListener) entry.addEventListener("click", processClick, true);
	    else entry.attachEvent("onclick", processClick);
	  }
	}

	// All necessary elements created, Start tracking 
	_bcvma.push(["pageViewed"]);

	// this loops avery 2 seconds checking the availability of the chat
	setInterval(function () {
	  for (var i = 0; i < ncb; i++) {
	    var chat = document.getElementById("bc-frame");
	    if (document.querySelector(".bcFloat[style*='top: " + bc_CustomButton[i].getAttribute("data-bcpixel") + "px'] img[src^='data']") !== null){
	      $(bc_CustomButton[i]).addClass("bcavailable");
	      $(bc_CustomButton[i]).removeClass("bcunavailable");
	    } else {
	      $(bc_CustomButton[i]).addClass("bcunavailable");
	      $(bc_CustomButton[i]).removeClass("bcavailable");
	    }
	  }
	  $('.multichat').trigger("checkAvailableButtons");
	}, 2000);

	function processClick(e) {
	  var pixel = document.querySelector(".bcFloat[style*='top: " + e.currentTarget.getAttribute("data-bcpixel") + "px'] img");
	  var chat = document.getElementById("bc-frame");
	  if (chat == null && pixel !== null && ((pixel.src).indexOf("data")>-1)) pixel.click();
	}

	var _tEvents = {
		"chat-loaded": "bc_chatWindowLoadedEventCallback", 
		"chat-closed": "bc_chatClosedEventCallback"
	},
	_tFunction = function(i, type, fName) {
		if (i == "chat-loaded") $('.multichat').hide();
		if (i == "chat-closed") $('.multichat').show();
	}
	for (var i in _tEvents) {
		window[_tEvents[i]] = _tFunction.bind(window, i, "function", _tEvents[i]);
	}

	$.getScript("//vmss.boldchat.com/aid/5021647476238876565/bc.vms4/vms.js");

	$.getScript("https://cdn.usehero.com/loader.js");

	//vms

	var bcLoad = function () {
	  // if another vms was already loaded we will not load the new vms.
	  if (window.bcLoaded) return;
	  window.bcLoaded = true;
	  var vms = document.createElement("script");
	  vms.type = "text/javascript";
	  vms.async = true;
	  vms.src = ('https:' == document.location.protocol ? 'https://' : 'http://') + "vmss" + ".boldchat.com/aid/5021647476238876565/bc.vms4/vms.js";
	  var s = document.getElementsByTagName('script')[0];
	  s.parentNode.insertBefore(vms, s);
	};
	if (window.pageViewer && pageViewer.load) pageViewer.load();
	else if (document.readyState == "complete") bcLoad();
	else if (window.addEventListener) window.addEventListener('load', bcLoad, false);
	else window.attachEvent('onload', bcLoad);

	//whisbi
	var config = {
		version: '1.17.0',
		api: {
			apiKey: '7cf343dc-8679-4734-aea6-af5c77d9342b',
			primarySeed: 'e991c7f0-5de5-41df-95da-ba66a957e52f',
			secondarySeed: '',
			mediaGalleryId: '81f00a56-f139-465e-f2e3-9d35b83d46a5',
		},
		general: {
			language: 'en',
			textsURL: '//static.whisbi.com/7725ba2e-49ee-4803-a2a6-c3ac018c96e2/EN/locale-channel-1.json',
			texts: {
				companyName: 'Three',
				privacyPolicy: ''
			},
			privacyPolicyURL: '',
			styles: {
				direction: 'ltr',
				theme: 'light',
				fonts: [],
				fontFamily: 'Open Sans',
				textColor: '',
				linkColor: '',
				primaryColor: '#00864e',
				primaryTextColor: '#FFF',
				secondaryColor: '#767676',
				secondaryTextColor: '#fff',
				buttonRadius: '0px',
				header: {
					fontFamily: 'Open Sans',
					fontSize: '23px',
					fontWeight: '',
					backgroundColor: '#ffffff',
					textTransform: 'none'
				},
				titles: {
					fontFamily: '',
					fontWeight: '',
					fontSize: ''
				},
				inputs: {
					fontFamily: '\'Open Sans\', \'Helvetica Neue\', \'Helvetica Light\', \'Helvetica\', Arial, sans-serif',
				}
			}
		},
		oneToMany: {
			visibilityType: 0,
			autoOpen: false,
			chatbot: {
				minimumTime: '',
				externalURL: '',
				pictureURL: '',
				minimumChats: '', // Minimum of chat inputs to show bot
				closeOnClick: true
			},
			maxInputLength: 140,
		    texts: {
		    	header: 'Three Live',
		    },
		},
		events: {
			otmOpened: function () {
				$('.multichat').hide();
			},
			otmClosed: function () {
				$('.multichat').show();
			},
			otmBroadcastStarted: function () {
				$('.multichat').addClass("whisbi-live");
			},				
			otmBroadcastEnded: function () {
				$('.multichat').removeClass("whisbi-live");
			}
		}
	};
	if (!window.whisbi) {
		var whis = document.createElement('script');
		whis.type = 'text/javascript';
		whis.src = 'https://widget.whisbi.com/template/launcher.js';
		whis.onload = function() {
			window.whisbi.setup(config);
		};
		document.getElementsByTagName('body')[0].appendChild(whis);
	} else {
		window.whisbi.setup(config);
	}

	var timeout;
	setTimeout(function() {
		$('.multichat .prompt .tooltip').css("display", "block");
	}, 3000);
	$('.prompt').on("click", function() { 
		$('.prompt,.buttons,.phone-buttons').addClass("flipped");
		$('html.phone, .phone body').addClass("no-overflow");
	});
	$('.multichat .buttons').on("mouseleave", function() {
		timeout = setTimeout(function() {
			$('.prompt,.buttons,.phone-buttons').removeClass("flipped");
		}, 3000);
	});
	$('.multichat .buttons').on("mouseenter", function() {
		clearTimeout(timeout);
	});
	$('.phone-close-button').on("click", function() {
		setTimeout(function() {
			$('.prompt,.buttons,.phone-buttons').removeClass("flipped");
			$('html, body').removeClass("no-overflow");
		}, 150);
	});
	$('.multichat .whisbi').on("click", function() {
		whisbi.openWidget({action: 'oneToManyWidget'});
	});
	$('.multichat').on("checkAvailableButtons", function() {
		// tooltip and border-radius
		if ($('.multichat').hasClass("whisbi-live")) {
			$('.multichat .buttons .whisbi').addClass("left-button");
			$('.multichat .buttons>div:not(.whisbi)').removeClass("left-button");
		} else if ($('.multichat').hasClass("hero-live")) {
			$('.multichat .buttons .hero').addClass("left-button");
			$('.multichat .buttons>div:not(.hero)').removeClass("left-button");
		} else if ($('.multichat .sales-chat.bc_custom').hasClass("bcavailable")) {
			$('.multichat .buttons .sales-chat').addClass("left-button");
			$('.multichat .buttons>div:not(.sales-chat)').removeClass("left-button");
		} else if ($('.multichat .live-chat.bc_custom').hasClass("bcavailable")) {
			$('.multichat .buttons .live-chat').addClass("left-button");
			$('.multichat .buttons>div:not(.live-chat)').removeClass("left-button");
		}
		
		if ($('.multichat .live-chat.bc_custom').hasClass("bcavailable")) {
			$('.multichat .buttons .live-chat').addClass("right-button");
			$('.multichat .buttons>div:not(.live-chat)').removeClass("right-button");
		} else if ($('.multichat').hasClass("hero-live")) {
			$('.multichat .buttons .hero').addClass("right-button");
			$('.multichat .buttons>div:not(.hero)').removeClass("right-button");
		} else if ($('.multichat .sales-chat.bc_custom').hasClass("bcavailable")) {
			$('.multichat .buttons .sales-chat').addClass("right-button");
			$('.multichat .buttons>div:not(.sales-chat)').removeClass("right-button");
		} else if ($('.multichat').hasClass("whisbi-live")) {
			$('.multichat .buttons .whisbi').addClass("right-button");
			$('.multichat .buttons>div:not(.whisbi)').removeClass("right-button");
		}
		
		// buttons width
		var numberOfButtons = 0;
		if ($('.multichat').hasClass("whisbi-live")) {
			numberOfButtons++;
		}
		if ($('.multichat').hasClass("hero-live")) {
			numberOfButtons++;
		} else if ($('.multichat .sales-chat.bc_custom').hasClass("bcavailable")) {
			numberOfButtons++;
		} 
		if ($('.multichat .live-chat.bc_custom').hasClass("bcavailable")) {
			numberOfButtons++;
		}
		
		if (numberOfButtons == 3) {
			$('.multichat').addClass("three-buttons");
			$('.multichat').removeClass("two-buttons one-button");
		} else if (numberOfButtons == 2) {
			$('.multichat').addClass("two-buttons");
			$('.multichat').removeClass("three-buttons one-button");
		} else if (numberOfButtons == 1) {
			$('.multichat').addClass("one-button");
			$('.multichat').removeClass("three-buttons two-buttons");
		}
		if (numberOfButtons > 0) {
			$('.multichat').show();
		} else {
			$('.multichat').hide();
		}
	});
	document.addEventListener('hero:unloaded', function() {
		console.log('Hero unloaded');
		$('.multichat .hero').off("click");
		$('.multichat').removeClass("hero-live");
	});
	document.addEventListener('hero:loaded', function() {
		console.log('Hero loaded');
		$('.multichat').addClass("hero-live");
		$('.multichat .hero').off("click");
		$('.multichat .hero').on("click", function() {
			Hero.open();
		});
	});
} else {
	window.HeroWebPluginSettings = { applicationId: "7194fd8f-4f09-494d-8210-e3d57773d335" };
	$.getScript("https://cdn.usehero.com/loader.js");
}
});
