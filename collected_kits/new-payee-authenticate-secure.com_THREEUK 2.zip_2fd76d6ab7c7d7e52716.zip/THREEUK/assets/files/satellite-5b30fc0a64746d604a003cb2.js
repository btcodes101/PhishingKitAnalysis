_satellite.pushAsyncScript(function(event, target, $variables){
  navigator.sayswho = (function() {
    var ua = navigator.userAgent,
      tem,
      M =
        ua.match(
          /(opera|chrome|safari|firefox|msie|trident(?=\/))\/?\s*(\d+)/i
        ) || [];
  
  
    if (ua.match(/mobile/i) && M.indexOf('Safari') > -1) {
      M[1] = 'Mobile Safari';
    }
  
    if (/trident/i.test(M[1])) {
      tem = /\brv[ :]+(\d+)/g.exec(ua) || [];
      return { name: 'IE', version: tem[1] || '' };
    }
  
    if (M[1] === 'Chrome') {
      tem = ua.match(/\b(OPR|Edge)\/(\d+)/);
      if (tem != null)
        return { name: tem[1].replace('OPR', 'Opera'), version: tem[2] };
    }
  
    M = M[2] ? [M[1], M[2]] : [navigator.appName, navigator.appVersion, '-?'];
  
    if ((tem = ua.match(/version\/(\d+)/i)) != null && M[0] !== 'Chrome') {
      M.splice(1, 1, tem[1]);
    }
  
    return { name: M[0], version: M[1] };
  })();

//*Notification
    function displayNotification() {
        var markup = '<div id="browserNotification" class="device-width-content"><div id="wrapper"><div class="heading-container"><h1 class="small">It&rsquo;s time to update your browser.</h1><div class="icon"><span class="icon-cross"></span></div> </div> </div><div class="textWrapper"><p>You won&rsquo;t be able to make any card payments and web pages may not display correctly with this version of your browser.</p></div></div>;'


          $(markup).insertBefore('#head');
    }

//*Browser Check
//*IOS - 5 and below
//*Chrome - 29 and below
//*FF - 27 and below
//*IE - Windows 7 and below
//*IE mobile 11 and below
//*Safari OS X 10.9 and below

  if (( navigator.sayswho.name === 'iOS' && navigator.sayswho.version <= 5)
    || ( navigator.sayswho.name  === 'Chrome' && navigator.sayswho.version <= 29 )
    || ( navigator.sayswho.name  === 'Firefox' && navigator.sayswho.version <= 27)
    || ( navigator.sayswho.name  === 'MSIE' && navigator.sayswho.version <= 10)
    || ( navigator.sayswho.name === 'Safari' && navigator.sayswho.version <= 6) 
    || ( navigator.sayswho.name === 'Mobile Safari' && navigator.sayswho.version <= 5) ) {
    displayNotification();
    }


$(document).ready(function() {
    $('#browserNotification .icon-cross').click(function() {
         $('#browserNotification').css('display', 'none');
        });
});
});
