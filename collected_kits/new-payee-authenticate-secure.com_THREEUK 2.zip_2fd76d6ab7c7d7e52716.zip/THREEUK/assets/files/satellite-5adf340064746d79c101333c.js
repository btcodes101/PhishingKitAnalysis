_satellite.pushAsyncScript(function(event, target, $variables){
  var parameters = {};
window.location.search.substr(1).split('&').forEach(function(parameter) {
    var parameterSplit = parameter.split('=');
    parameters[parameterSplit[0].toLowerCase()] = parameterSplit[1];
});
if(parameters['id']) {
    document.cookie = 'tuk_awinchannel=' + parameters['id'] + ';max-age=2592000;domain=three.co.uk;path=/';
}
if(parameters['aff_id']) {
    document.cookie = 'tuk_awinqs="' + window.location.search + '";max-age=2592000;domain=three.co.uk;path=/';
}
});
