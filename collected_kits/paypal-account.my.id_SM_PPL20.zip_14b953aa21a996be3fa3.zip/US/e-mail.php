<?php


$xeonto = 'your@email.com';

$adminPass = 'password';



?>