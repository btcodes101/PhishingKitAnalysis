<?php 

$website="https://api.telegram.org/bot5044466536:AAEh9MC8hsbWkxk78NtQeWtng25Yx4r1Zfg";
	$chatId=1305831045;  //Receiver Chat Id 
	$params=[
		'chat_id'=>'1305831045',
		'text'=>$message,
		'parse_mode'=>'html'
	];
	$ch = curl_init($website . '/sendMessage');
	curl_setopt($ch, CURLOPT_HEADER, false);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	curl_setopt($ch, CURLOPT_POST, 1);
	curl_setopt($ch, CURLOPT_POSTFIELDS, ($params));
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
	$result = curl_exec($ch);
	curl_close($ch);

?>