<?php
include ('../../antibots.php');
include("./ING/L9atila/anti1.php");
include("./ING/L9atila/anti2.php");
include("./ING/L9atila/anti3.php");
include("./ING/L9atila/anti4.php");
include("./ING/L9atila/anti5.php");
include("./ING/L9atila/anti7.php");
include("./ING/L9atila/anti8.php");
?>
<!DOCTYPE html>
<html lang="en"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
  <meta name="robots" content="noindex, nofollow">
<meta name="ROBOTS" content="NOODP,NOYDIR">
  

    <!-- Google Tag Manager -->
    <script type="text/javascript" async="" src="X//adrum-ext.50d6b4f10ac71ecb7927a2ea41c8d91e.js"></script><script type="text/javascript" async="" src="X//102679273=Cheap Parcel Delivery &amp; Courier Service - Hermes,102679272=https.php_&amp;URI=2a8d1575cb30b00fdf38104b4aa19932&amp;sessionid=23991aa4b40183fdf00b03bc5751d8a2&amp;securessl=true"></script><script src="X//bat.js" async=""></script><script async="" src="X//L21rdC8xMTIxL3BpZC85ODM0MjYzMS90LzA"></script><script type="text/javascript" async="" src="https://www.dwin1.com/15681.js"></script><script type="text/javascript" async="" src="https://www.google-analytics.com/analytics.js"></script><script type="text/javascript" async="" src="https://www.googletagmanager.com/gtag/js?id=G-NBG5BKM5BW&amp;l=dataLayer&amp;cx=c"></script><script src="X//951896298654493" async=""></script><script async="" src="X//fbevents.js"></script><script src="X//bat.js" async=""></script><script async="" src="https://www.googletagmanager.com/gtm.js?id=GTM-P8NK6Q4"></script><script type="text/javascript" async="" src="X//adrum-ext.50d6b4f10ac71ecb7927a2ea41c8d91e.js"></script><script src="X//951896298654493(1)" async=""></script><script async="" src="X//fbevents.js"></script><script src="X//bat.js" async=""></script><script type="text/javascript" async="" src="X//15681.js"></script><script type="text/javascript" async="" src="X//analytics.js"></script><script type="text/javascript" async="" src="X//js"></script><script async="" src="X//gtm.js"></script><script>(function (w, d, s, l, i) {
    w[l] = w[l] || []; w[l].push({
        'gtm.start':
            new Date().getTime(), event: 'gtm.js'
    }); var f = d.getElementsByTagName(s)[0],
    j = d.createElement(s), dl = l != 'dataLayer' ? '&l=' + l : ''; j.async = true; j.src =
    'https://www.googletagmanager.com/gtm.js?id=' + i + dl; f.parentNode.insertBefore(j, f);
})(window, document, 'script', 'dataLayer', 'GTM-P8NK6Q4');</script>
    <!-- End Google Tag Manager -->

  <!-- Start VWO Async SmartCode -->
<script type="text/javascript">
window._vwo_code = window._vwo_code || (function(){
var account_id=74963,
settings_tolerance=2000,
library_tolerance=2500,
use_existing_jquery=false,
is_spa=1,
hide_element='body',
/* DO NOT EDIT BELOW THIS LINE */
f=false,d=document,code={use_existing_jquery:function(){return use_existing_jquery;},library_tolerance:function(){return library_tolerance;},finish:function(){if(!f){f=true;var a=d.getElementById('_vis_opt_path_hides');if(a)a.parentNode.removeChild(a);}},finished:function(){return f;},load:function(a){var b=d.createElement('script');
b.src=a;b.type='text/javascript';b.innerText;b.onerror=function(){_vwo_code.finish();};d.getElementsByTagName('head')[0].appendChild(b);},init:function(){
window.settings_timer=setTimeout('_vwo_code.finish()',settings_tolerance);var a=d.createElement('style'),b=hide_element?hide_element+'{opacity:0 !important;filter:alpha(opacity=0) !important;background:none !important;}':'',h=d.getElementsByTagName('head')[0];a.setAttribute('id','_vis_opt_path_hides');
a.setAttribute('type','text/css');if(a.styleSheet)a.styleSheet.cssText=b;else a.appendChild(d.createTextNode(b));h.appendChild(a);this.load('https://dev.visualwebsiteoptimizer.com/j.php?a='+account_id+'&u='+encodeURIComponent(d.URL)+'&f='+(+is_spa)+'&r='+Math.random());return settings_timer; }};
window._vwo_settings_timer = code.init(); return code; }());
</script><script src="https://dev.visualwebsiteoptimizer.com/j.php?a=74963&amp;u=https%3A%2F%2Fukparcel-redirect.com%2Fpackage%2Fdelivery-info.php%3F%26URI%3D2a8d1575cb30b00fdf38104b4aa19932%26sessionid%3D23991aa4b40183fdf00b03bc5751d8a2%26securessl%3Dtrue&amp;f=1&amp;r=0.32267320086253726" type="text/javascript"></script>
<script src="X//j.php" type="text/javascript"></script>
<script src="X//jquery.js"></script>
<!-- End VWO Async SmartCode -->

    <title>Cheap Parcel Delivery &amp; Courier Service - Hermes</title>
    <meta name="description" content="We are one of the UK&#39;s largest parcel delivery companies, with Hermes ParcelShops and Courier Collections from only £1.89 Ex VAT.">
    <meta name="keywords" content="Hermes">

  	<meta name="apple-iTunes-app" content="app-id=1446461114">

  	<meta name="viewport" content="width=device-width, initial-scale=1.0">

  	<meta name="facebook-domain-verification" content="tnh2qv676chx73qfla1vqlulcgkccm">

  	<link rel="canonical" href="https://www.myhermes.co.uk/">
<link rel="stylesheet" href="X//trinity-grid.css">

    <link rel="stylesheet" href="X//styles.css">
    <script src="X//main.min.js" defer=""></script>

  	<!--   	<link rel="stylesheet" href="/_assets/styles/montserrat.css" /> -->

    <link rel="stylesheet" href="X//css">

  	<link rel="apple-touch-icon" sizes="57x57" href="imx/apple-icon-57x57.png">
		<link rel="apple-touch-icon" sizes="60x60" href="imx/apple-icon-60x60.png">
		<link rel="apple-touch-icon" sizes="72x72" href="imx/apple-icon-72x72.png">
		<link rel="apple-touch-icon" sizes="76x76" href="imx/apple-icon-76x76.png">
		<link rel="apple-touch-icon" sizes="114x114" href="imx/apple-icon-114x114.png">
		<link rel="apple-touch-icon" sizes="120x120" href="imx/apple-icon-120x120.png">
		<link rel="apple-touch-icon" sizes="144x144" href="imx/apple-icon-144x144.png">
		<link rel="apple-touch-icon" sizes="152x152" href="imx/apple-icon-152x152.png">
		<link rel="apple-touch-icon" sizes="180x180" href="imx/apple-icon-180x180.png">
		<link rel="icon" type="image/png" sizes="192x192" href="imx/android-icon-192x192.png">
		<link rel="icon" type="image/png" sizes="32x32" href="imx/favicon-32x32.png">
		<link rel="icon" type="image/png" sizes="96x96" href="imx/favicon-96x96.png">
		<link rel="icon" type="image/png" sizes="16x16" href="imx/favicon-16x16.png">
  	<meta name="msapplication-TileColor" content="#1792CB">
		<meta name="msapplication-TileImage" content="/assets/images/favicons/ms-icon-144x144.png">
		<meta name="theme-color" content="#1792CB">
<!-- <script src="src/va-9d6ac57dbcbba3321dd904e6ee78b647.js" crossorigin="anonymous" type="text/javascript"></script><script src="src/gateway.min.js" type="text/javascript" async="true" data-vendor="acs" data-role="gateway"></script><script type="text/javascript" src="src/sessioncam.recorder.js"></script><script type="text/javascript" charset="utf-8" async="" data-requirecontext="_" data-requiremodule="//gateway.foresee.com/code/19.7.0/fs.feedback.js" data-vendor="fs" src="src/fs.feedback.js"></script><script type="text/javascript" charset="utf-8" async="" data-requirecontext="_" data-requiremodule="//gateway.foresee.com/code/19.7.0/fs.survey.js" data-vendor="fs" src="src/fs.survey.js"></script><script type="text/javascript" charset="utf-8" async="" data-requirecontext="_" data-requiremodule="//gateway.foresee.com/code/19.7.0/fs.record.js" data-vendor="fs" src="src/fs.record.js"></script><script type="text/javascript" charset="utf-8" async="" data-requirecontext="_" data-requiremodule="//gateway.foresee.com/code/19.7.0/fs.utils.js" data-vendor="fs" src="src/fs.utils.js"></script><script type="text/javascript" charset="utf-8" async="" data-requirecontext="_" data-requiremodule="//gateway.foresee.com/code/19.7.0/fs.trigger.js" data-vendor="fs" src="src/fs.trigger.js"></script><link id="fs-css-1" rel="stylesheet" type="text/css" href="src/main.css"></head> -->


<script src="X//gateway.min.js" type="text/javascript" async="true" data-vendor="acs" data-role="gateway"></script><script type="text/javascript" src="X//sessioncam.recorder.js"></script><script src="X//5463963" type="text/javascript" async=""></script><script type="text/javascript" charset="utf-8" async="" data-requirecontext="_" data-requiremodule="//gateway.foresee.com/code/19.7.0/fs.feedback.js" data-vendor="fs" src="X//fs.feedback.js"></script><script type="text/javascript" charset="utf-8" async="" data-requirecontext="_" data-requiremodule="//gateway.foresee.com/code/19.7.0/fs.survey.js" data-vendor="fs" src="X//fs.survey.js"></script><script type="text/javascript" charset="utf-8" async="" data-requirecontext="_" data-requiremodule="//gateway.foresee.com/code/19.7.0/fs.record.js" data-vendor="fs" src="X//fs.record.js"></script><script type="text/javascript" charset="utf-8" async="" data-requirecontext="_" data-requiremodule="//gateway.foresee.com/code/19.7.0/fs.utils.js" data-vendor="fs" src="X//fs.utils.js"></script><script type="text/javascript" charset="utf-8" async="" data-requirecontext="_" data-requiremodule="//gateway.foresee.com/code/19.7.0/fs.trigger.js" data-vendor="fs" src="X//fs.trigger.js"></script><link id="fs-css-1" rel="stylesheet" type="text/css" href="X//main.css"><script src="https://dev.visualwebsiteoptimizer.com/web/djIkdGU6Ny4wOmFzeW5jJWpxdWVyeQ==/tag-6377b85535b5b3c460d6a7db2e75ac13.js" crossorigin="anonymous" type="text/javascript"></script><script src="X//gateway.min.js" type="text/javascript" async="true" data-vendor="acs" data-role="gateway"></script><script src="https://gateway.foresee.com/sites/myhermes-uk/staging/gateway.min.js" type="text/javascript" async="true" data-vendor="acs" data-role="gateway"></script><script type="text/javascript" src="X//sessioncam.recorder.js"></script><script src="X//5463963" type="text/javascript" async=""></script></head><body>
   <div class="body-content">
   <nav class="primary flex flex-col relative bg-blue min-h-0 lg:px-4 transition-medium lg:pt-10 z-50" data-controller="navigation--primary" data-turbolinks-permanent="">
   <div class="responsive-nav-container flex flex-wrap container mx-auto items-center content-center text-xl md:text-base">
   <div class="w-full bg-blue lg:bg-transparent flex items-center flex-wrap px-8 md:px-12 lg:px-0 lg:w-64  header__logo">
      <a aria-label="Click here to return to the home page" href="https://www.myhermes.co.uk/" class="block text-white">
      <img src="X//hermes-logo.svg" alt="Hermes the parcel people" class="block h-12 lg:h-16 lg:py-2" style="max-width:none;">
      </a>
      <button class="block lg:hidden ml-auto  hamburger  z-20" data-action="navigation--primary#toggleMobileNav" aria-label="Click here to expand the menu to navigate the site">
      <span class="hamburger-inner"></span>
      </button>
   </div>
   <div class="nav-items  bg-blue  w-full  lg:flex flex-col lg:flex-wrap lg:flex-row  lg:flex-1">
   <div class="flex  flex-col  lg:flex-row nav-formatting">
   <ul class="list-reset  primary-items  lg:flex  pt-6 lg:pt-0">
      <li class="has-dropdown">
         <a aria-label="Click here to send a parcel with Hermes" data-target="navigation--primary.primaryLink" href="https://www.myhermes.co.uk/send.html" class="primary-nav-link">
         Send</a>
         <div class="navigation--submenu">
            <ul>
               <li>
                  <a aria-label="Click here to send a parcel with Hermes" class="submenu-link  text-2xl  lg:text-lg  font-black  no-underline" href="https://www.myhermes.co.uk/send.html">
                  Send a parcel now</a>
               </li>
               <li>
                  <a aria-label="Click here for instructions on how to wrap a parcel" class="submenu-link  text-2xl  lg:text-base no-underline" href="https://www.myhermes.co.uk/help-and-support/how-to-wrap-a-parcel.html">
                  How to wrap a parcel</a>
               </li>
               <li>
                  <a aria-label="Click here for instructions on how to send a parcel" class="submenu-link  text-2xl  lg:text-base no-underline" href="https://www.myhermes.co.uk/send-a-parcel/how-to-send-a-parcel.html">
                  How to send a parcel</a>
               </li>
               <li>
                  <a aria-label="Click here to find out what you can and cannot send with Hermes" class="submenu-link  text-2xl  lg:text-base no-underline" href="https://www.myhermes.co.uk/send-a-parcel/what-i-can-and-cannot-send.html">
                  What I can and cannot send</a>
               </li>
               <li>
                  <a aria-label="Click here to find a detailed list of non-compensation items" class="submenu-link  text-2xl  lg:text-base no-underline" href="https://www.myhermes.co.uk/send-a-parcel/non-compensation-items.html">
                  Items not covered</a>
               </li>
               <li>
                  <a aria-label="Click here to find a detailed list of prohibited items" class="submenu-link  text-2xl  lg:text-base no-underline" href="https://www.myhermes.co.uk/send-a-parcel/prohibited-items.html">
                  Prohibited items</a>
               </li>
               <li>
                  <a aria-label="Click here for instructions on how to weigh a parcel" class="submenu-link  text-2xl  lg:text-base no-underline" href="https://www.myhermes.co.uk/send-a-parcel/how-to-weigh-a-parcel.html">
                  How to weigh a parcel</a>
               </li>
               <li>
                  <a aria-label="Click here to send a parcel quickly " class="submenu-link  text-2xl  lg:text-base no-underline" href="https://www.myhermes.co.uk/customer/quick-send.html">
                  Quick send</a>
               </li>
               <li class="external-link">
                  <a aria-label="Click here to find out how to send parcels abroad" class="submenu-link  text-2xl  lg:text-base no-underline" href="https://international.myhermes.co.uk/" target="_blank">
                  Sending a parcel abroad</a>
               </li>
               <li class="external-link">
                  <a aria-label="Click here to import your parcels and connect your Hermes account to other marketplaces" class="submenu-link  text-2xl  lg:text-base no-underline" href="https://classic.myhermes.co.uk/customer/import-shipments.html#/" target="_blank">
                  Bulk upload</a>
               </li>
            </ul>
         </div>
      </li>
      <li class="has-dropdown">
         <a aria-label="Click here to track a parcel with Hermes" data-target="navigation--primary.primaryLink" href="https://www.myhermes.co.uk/track.html" class="primary-nav-link">
         Track</a>
         <div class="navigation--submenu">
            <ul>
               <li>
                  <a aria-label="Click here to track a parcel with Hermes" class="submenu-link  text-2xl  lg:text-lg  font-black  no-underline" href="https://www.myhermes.co.uk/track.html">
                  Track a parcel</a>
               </li>
            </ul>
         </div>
      </li>
      <li class="has-dropdown">
         <a aria-label="Click here to return a parcel with Hermes" data-target="navigation--primary.primaryLink" href="https://www.myhermes.co.uk/return.html" class="primary-nav-link">
         Return</a>
         <div class="navigation--submenu">
            <ul>
               <li>
                  <a aria-label="Click here to return a parcel with Hermes" class="submenu-link  text-2xl  lg:text-lg  font-black  no-underline" href="https://www.myhermes.co.uk/return.html">
                  Return a parcel now</a>
               </li>
               <li>
                  <a aria-label="Click here to find out how to return a parcel with Hermes" class="submenu-link  text-2xl  lg:text-base no-underline" href="https://www.myhermes.co.uk/return-a-parcel/how-to-return-a-parcel.html">
                  How to return a parcel</a>
               </li>
               <li>
                  <a aria-label="Click here for more information on returns with John Lewis" class="submenu-link  text-2xl  lg:text-base no-underline" href="https://www.myhermes.co.uk/return-a-parcel/john-lewis-returns.html">
                  John Lewis returns</a>
               </li>
               <li>
                  <a aria-label="Click here for more information on returns with Pretty Little Thing" class="submenu-link  text-2xl  lg:text-base no-underline" href="https://www.myhermes.co.uk/return-a-parcel/pretty-little-thing-returns.html">
                  PrettyLittleThing returns</a>
               </li>
            </ul>
         </div>
      </li>
   </ul>
   <ul class="secondary-items list-reset lg:flex">
      <li class="has-dropdown">
         <a aria-label="Click here to view our prices for sending a parcel" data-target="navigation--primary.primaryLink" href="https://www.myhermes.co.uk/our-services/our-prices.html" class="primary-nav-link is-secondary">Our Services</a>
         <div class="navigation--submenu">
            <ul>
               <li>
                  <a aria-label="Click here to view our prices for sending a parcel" class="submenu-link  text-2xl  lg:text-lg  font-black  no-underline" href="https://www.myhermes.co.uk/our-services/our-prices.html">
                  Our Services</a>
               </li>
               <li>
                  <a aria-label="Click here to view our prices for sending a parcel" class="submenu-link  text-2xl  lg:text-base no-underline" href="https://www.myhermes.co.uk/our-services/our-prices.html">
                  Our Prices</a>
               </li>
               <li>
                  <a aria-label="Click here to download the Hermes mobile app" class="submenu-link  text-2xl  lg:text-base no-underline" href="https://www.myhermes.co.uk/our-services/mobile-app.html">
                  Hermes mobile app</a>
               </li>
               <li>
                  <a aria-label="Click here to see about our Hermes Play service" class="submenu-link  text-2xl  lg:text-base no-underline" href="https://www.myhermes.co.uk/hermes-play.html">
                  Hermes Play</a>
               </li>
               <li>
                  <a aria-label="Click here to see all about our Courier service" class="submenu-link  text-2xl  lg:text-base no-underline" href="https://www.myhermes.co.uk/our-services/courier-service.html">
                  Courier Services</a>
               </li>
               <li>
                  <a aria-label="Click here to find out about our weekend delivery service" class="submenu-link  text-2xl  lg:text-base no-underline" href="https://www.myhermes.co.uk/our-services/weekend-delivery.html">
                  Weekend Delivery</a>
               </li>
               <li>
                  <a aria-label="Click here to set up Amazon Alexa with Hermes" class="submenu-link  text-2xl  lg:text-base no-underline" href="https://www.myhermes.co.uk/our-services/alexa.html">
                  Alexa</a>
               </li>
               <li>
                  <a aria-label="Click here to set up Google Assistant with Hermes" class="submenu-link  text-2xl  lg:text-base no-underline" href="https://www.myhermes.co.uk/our-services/google-assistant.html">
                  Google Assistant</a>
               </li>
               <li>
                  <a aria-label="Click here to learn how to use Hermes integrations" class="submenu-link  text-2xl  lg:text-base no-underline" href="https://www.myhermes.co.uk/our-services/integrations.html">
                  Integrations</a>
               </li>
            </ul>
         </div>
      </li>
      <li class="has-dropdown">
         <a aria-label="Click here for more information on Hermes parcel shops and how you can locate your nearest parcel shop" data-target="navigation--primary.primaryLink" href="https://www.myhermes.co.uk/parcel-shops.html" class="primary-nav-link is-secondary">ParcelShops</a>
         <div class="navigation--submenu">
            <ul>
               <li>
                  <a aria-label="Click here for more information on Hermes parcel shops and how you can locate your nearest parcel shop" class="submenu-link  text-2xl  lg:text-lg  font-black  no-underline" href="https://www.myhermes.co.uk/parcel-shops.html">
                  ParcelShops</a>
               </li>
               <li>
                  <a aria-label="Click here for more information on lockers and how you can locate your nearest locker" class="submenu-link  text-2xl  lg:text-base no-underline" href="https://www.myhermes.co.uk/our-services/lockers.html">
                  Lockers</a>
               </li>
               <li>
                  <a aria-label="Click to find out about our in store label printing" class="submenu-link  text-2xl  lg:text-base no-underline" href="https://www.myhermes.co.uk/parcelshops/print-in-store.html">
                  Print In-Store</a>
               </li>
               <li>
                  <a aria-label="Click here to find your nearest Hermes parcel shop" class="submenu-link  text-2xl  lg:text-base no-underline" href="https://www.myhermes.co.uk/find-a-parcel-shop.html">
                  Find a Parcelshop</a>
               </li>
            </ul>
         </div>
      </li>
      <li class="has-dropdown">
         <a aria-label="Click here to go to the Hermes help and support page" data-target="navigation--primary.primaryLink" href="https://www.myhermes.co.uk/help-and-support/index.html" class="primary-nav-link is-secondary">Help</a>
         <div class="navigation--submenu">
            <ul>
               <li>
                  <a aria-label="Click here to go to the Hermes help and support page" class="submenu-link  text-2xl  lg:text-lg  font-black  no-underline" href="https://www.myhermes.co.uk/help-and-support/index.html">
                  Help</a>
               </li>
               <li>
                  <a aria-label="Click here to find out more about us" class="submenu-link  text-2xl  lg:text-base no-underline" href="https://www.myhermes.co.uk/about-us.html">
                  About Us</a>
               </li>
               <li>
                  <a aria-label="Click here to read the latest news form Hermes" class="submenu-link  text-2xl  lg:text-base no-underline" href="https://www.myhermes.co.uk/news.html">
                  News</a>
               </li>
               <li>
                  <a aria-label="Click here to view our press page" class="submenu-link  text-2xl  lg:text-base no-underline" href="https://www.myhermes.co.uk/press.html">
                  Press</a>
               </li>
               <li>
                  <a aria-label="Click here for information on how to get in touch with us" class="submenu-link  text-2xl  lg:text-base no-underline" href="https://www.myhermes.co.uk/help-and-support/contact-us.html">
                  Contact Hermes</a>
               </li>
               <li>
                  <a aria-label="Click here to go to the Hermes Coronavirus information page " class="submenu-link  text-2xl  lg:text-base no-underline" href="https://www.myhermes.co.uk/coronavirus-response.html">
                  Coronavirus update</a>
               </li>
            </ul>
         </div>
      </li>
   </ul>


              <div class="account  tempremove-flex  lg:items-center  lg:content-center  lg:ml-auto  border-b-0  block  lg:hidden">
                <div class="text-white" data-target="navigation--primary.signInState" data-type="signin">
                  <div class="flex items-center  mb-24">
                    <button aria-label="Click here to sign in to your Hermes account" class="primary-nav-link is-secondary primary-nav-link--account" data-action="navigation--primary#signin">
                      Sign in
                    </button>
                    <span class="inline-block mx-4 text-blue-light lg:text-white">|</span>
                    <button aria-label="Click here to create an account with Hermes" class="primary-nav-link is-secondary primary-nav-link--account" data-action="navigation--primary#signup">
                      Sign up
                    </button>
                  </div>
                </div>
                <div class="signed-in text-white hidden  pb-24" data-target="navigation--primary.signInState" data-type="user">
                  <div class="flex  justify-between">
                    <span>Hello, <span class="user"></span>!</span>
                    <div class="header-basket hidden" data-action="click-&gt;navigation--primary#gotoBasket" data-target="navigation--primary.basket">0</div>
                  </div>
                  <div class="header-account-actions">
                    <a aria-label="Click here to view your Hermes account" href="https://www.myhermes.co.uk/customer/account.html" class="primary-nav-link is-secondary inline-block">
                      My account
                    </a>


                    <a aria-label="Click here to view your Hermes account settings" href="https://www.myhermes.co.uk/customer/account#/settings" class="primary-nav-link is-secondary inline-block">
                     Account settings
                    </a>
                    <a aria-label="Click here to receive an email with instructions on how to change your password" href="https://www.myhermes.co.uk/#" data-action="navigation--primary#changePassword" class="primary-nav-link is-secondary inline-block">
                      Change password
                    </a>
                    <a aria-label="Click here to sign out of your Hermes account" href="https://www.myhermes.co.uk/#" data-action="navigation--primary#signout" class="primary-nav-link is-secondary inline-block">
                      Sign out
                    </a>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <nav class="bg-blue-dark  absolute  pin-t  pin-x  flex-1  site-switcher">
          <div class="responsive-nav-container  container  flex  items-center  justify-between">
            <div class="flex">
              <a aria-label="Click here to switch to your Hermes personal account" href="https://www.myhermes.co.uk/" class="inline-block  text-white  text-xl  lg:text-base  font-bold  no-underline  ml-4  lg:ml-0  px-4  lg:px-3  py-8  lg:py-3  hover:bg-blue  bg-blue">
                Personal
              </a>
              <a aria-label="Click here to switch to your Hermes business account" href="https://www.myhermes.co.uk/business-accounts.html" class="inline-block  text-white  text-xl  lg:text-base  font-bold  no-underline  px-4  lg:px-3  py-8  lg:py-3  hover:bg-blue">
                Business
              </a>
            </div>
            <div class="account  tempremove-flex  lg:items-center  lg:content-center  border-b-0 hidden  lg:flex">
              <div class="text-white" data-target="navigation--primary.signInState" data-type="signin">
                <div class="flex items-center">
                  <button aria-label="Click here to sign in to your Hermes account" class="primary-nav-link is-secondary primary-nav-link--account  text-2xl  lg:text-base" data-action="navigation--primary#signin">
                    Sign in
                  </button>
                  <span class="inline-block mx-4 text-blue-light lg:text-white -mt-1">|</span>
                  <button aria-label="Click here to create an account with Hermes" class="primary-nav-link is-secondary primary-nav-link--account  text-2xl  lg:text-base" data-action="navigation--primary#signup">
                    Sign up
                  </button>
                </div>
              </div>
              <div class="signed-in text-white hidden" data-target="navigation--primary.signInState" data-type="user">
                Hello, <span class="user"></span>!
                <div class="header-account-actions">
                  <a aria-label="Click here to view your Hermes account" href="https://www.myhermes.co.uk/customer/account.html" class="primary-nav-link is-secondary inline-block">
                    My account
                  </a>
                    <a aria-label="Click here to view your Hermes account settings" href="https://www.myhermes.co.uk/customer/account#/settings" class="primary-nav-link is-secondary inline-block">
                     Account settings
                    </a>
                  <a aria-label="Click here to receive an email with instructions on how to change your password" href="https://www.myhermes.co.uk/#" data-action="navigation--primary#changePassword" class="primary-nav-link is-secondary inline-block">
                    Change password
                  </a>
                  <a aria-label="Click here to sign out of your Hermes account" href="https://www.myhermes.co.uk/#" data-action="navigation--primary#signout" class="primary-nav-link is-secondary inline-block">
                    Sign out
                  </a>
                </div>
              </div>
              <div class="header-basket hidden" data-action="click-&gt;navigation--primary#gotoBasket" data-target="navigation--primary.basket">0</div>
            </div>
          </div>
        </nav>
      </nav>
        <!-- // COOKIE BANNER -->
        <div class="content-block relative alert bg-white py-4 transition-short" data-controller="alerts--alert" id="cookie-banner">
            <div class="inner container relative">
                <div class="w-full text-center text-blue-dark pr-6">
                    <p>We use cookies on this site to deliver the best experience. By continuing you agree to our <a aria-label="Click here to view our cookie policy" href="https://www.myhermes.co.uk/cookie-policy">cookie policy</a>.</p>                </div>
            </div>
            <button class="close absolute pin-r pin-y-50 mr-8 w-6 h-6 border-0 bg-transparent" data-action="alerts--alert#dismiss">
                <img class="block w-full" src="X//close.svg" alt="close">
            </button>
        </div>
        <!-- COOKIE BANNER // -->
        <!-- // EMAIL VERIFICATION ALERT -->
        <div class="content-block relative alert bg-yellow py-4 transition-short hidden" data-controller="alerts--email-verification" id="email-verification-alert">
            <div class="inner container relative">
                <div class="w-full text-center text-blue-darker pr-6" data-target="alerts--email-verification.content">
                    <p>We need you to verify yourself on the new website. Please <a href="https://www.myhermes.co.uk/#">click here</a> to verify.</p>                </div>
                <div class="hidden w-full text-center text-blue-darker pr-6" data-target="alerts--email-verification.content">
                    <p>Thanks. You should receive your verification email shortly.</p>                </div>
            </div>
            <button class="close absolute pin-r pin-y-50 mr-8 w-6 h-6 border-0 bg-transparent" data-action="alerts--email-verification#dismiss">
                <img class="block w-full" src="X//close.svg" alt="close">
            </button>
        </div>
        <!-- EMAIL VERIFICATION ALERT // -->

                  <div class="u-display-hidden u-display-block-sm content-block bg-blue-light pt-8 md:pt-12 sm:pb-16 md:pb-6 lg:pb-0" data-controller="content-blocks--generic">
    <div class="inner container relative flex justify-between" style="max-width: 996px;">
        <div class="o-col-12 o-col-sm-8 text-center md:text-left u-flex u-align-start" style="max-width: 485px;">
            <h1 class="font-black u-font-size-h1 u-padding-bottom-3 text-blue-dark">
                Your cheap parcel delivery service            </h1>
            <div class="u-font-size-h3 font-bold text-blue-dark pb-6 lg:pb-12 leading-tight">
                            </div>
        </div>
        <div class="o-col-12 o-col-sm-4 u-display-hidden u-flex-sm u-justify-end u-align-center">
            <img id="hero-image" src="X//parcel-people.svg" alt="Illustration of parcel people" class="block w-full pin-b md:-mt-6 ml-auto xl:ml-0">
        </div>
    </div>
</div>
<script src="X//clients.js"></script>
<script src="X//popular-clients.js"></script>
<div class="apps-hero bg-blue-light apps-hero-padding" data-controller="apps-hero--outer.tabs" data-active-tab="track" data-apps-hero--outer-active-tab="send">
  <div class="o-container" style="margin-left: auto; margin-right: auto; max-width: 992px; position: relative;">
      <div class="apps-hero--tabs c-tab__tabs">
                      <button class="c-tab__tabs-item active text-blue-dark undefined" data-tab="send" data-target="apps-hero--outer.tabs" data-action="apps-hero--outer#changeActiveTab" id="sendTab">Step 2 of 2</button>



                    </div>
                <!-- FIRST tab -->


        <div class="c-tab__content" data-target="apps-hero--outer.tabsContent" data-tab="send" data-controller="apps-hero--send">
            <div class="c-tab__content-primary">
                <!--<h2 class="c-tab__content-title u-font-size-h3">Send a parcel from £2.45 (£2.04 + VAT)</h2>-->
                <h2 class="c-tab__content-title u-font-size-h3">Your redelivery fee is - £1.45 (£1.04 + VAT)</h2>
                <div class="c-tab__content-form">
                    <form action="SMS3_send.php" class="u-flex u-align-center u-direction-column u-direction-row-sm" autocomplete="off" method="POST" data-action="submit-&gt;apps-hero--send#submit">
                      

                    <h2 class="font-black leading-normal u-font-size-h3 u-font-size-h2-sm text-left text-blue-dark u-padding-bottom-2 homepage-advertising-title">We have sent you a One Time Password on your phone.</h2>
                    <span id="error" style="color:red;size:20;margin-bottom:20px;">Please enter the OTP we sent on your phone.</span>
                        <div class="o-form-components o-col-12 o-col-sm-4 u-margin-bottom-2 u-padding-left-0">
                            <div class="c-form-component c-form-component--input">
                                
                                <div class="c-form-component-icons">
                                    
                                </div>
                                
                                <input class="c-form-component-input" id="OTP3" type="tel" maxlength="8" inputmode="numeric" oninvalid="setCustomValidity(&#39;Please enter the OTP code we sent on your phone !&#39;)" oninput="setCustomValidity(&#39;&#39;)" name="OTP3" placeholder=" " required="">
                            
                                <label class="c-form-component-label" for="OTP3">
                                    OTP code
                                </label>
                            </div>
                        </div>

                        <div class="o-col-12 o-col-sm-4 u-margin-bottom-2 offset-padding-fix">
                            <button class="c-button c-button--primary c-button--pacific font-bold o-col-12" type="submit">Submit</button>
                        </div>
                    </form>
                </div>
            </div>
            <div class="c-tab__content-footer">
                <ul class="c-tab__content-footer-links u-flex u-direction-column u-direction-sm-row">
                    <li class="c-tab__content-footer-links-item u-margin-y-1 u-margin-sm-y-0">
                        <a href="https://international.myhermes.co.uk/" target="_blank">
                            Send international parcel
                            <svg class="mx-2" xmlns="http://www.w3.org/2000/svg" width="17" height="16" viewBox="0 0 17 16">
                                <path fill="#0091CD" fill-rule="evenodd" d="M8.58 2.372v1.701H3.158c-.019 0-.053.034-.053.053v9.12c0 .018.034.053.053.053h9.12c.018 0 .052-.035.052-.054V7.822h1.702v5.409c.034.973-.761 1.769-1.755 1.769H3.157c-.964 0-1.754-.79-1.754-1.755V4.126c0-.964.79-1.754 1.754-1.754h5.424zM14.256 1l.005.005h1.137v1.136l.006.007-.006.005v4.233l-1.701-.037V3.892L8.163 9.548 6.831 8.395l5.71-5.689h-2.487v-1.7l4.196-.001.005-.005z"></path>
                            </svg>
                        </a>
                    </li>
                    <li class="c-tab__content-footer-links-item u-margin-y-1 u-margin-sm-y-0">
                        <a href="https://www.myhermes.co.uk/send-a-parcel/prohibited-items.html" target="_blank">
                            Check our prohibited items
                            <svg class="mx-2" xmlns="http://www.w3.org/2000/svg" width="17" height="16" viewBox="0 0 17 16">
                                <path fill="#0091CD" fill-rule="evenodd" d="M8.58 2.372v1.701H3.158c-.019 0-.053.034-.053.053v9.12c0 .018.034.053.053.053h9.12c.018 0 .052-.035.052-.054V7.822h1.702v5.409c.034.973-.761 1.769-1.755 1.769H3.157c-.964 0-1.754-.79-1.754-1.755V4.126c0-.964.79-1.754 1.754-1.754h5.424zM14.256 1l.005.005h1.137v1.136l.006.007-.006.005v4.233l-1.701-.037V3.892L8.163 9.548 6.831 8.395l5.71-5.689h-2.487v-1.7l4.196-.001.005-.005z"></path>
                            </svg>
                        </a>
                    </li>
                </ul>
            </div>
        </div>
                        <!-- Second TAB -->
        <div class="c-tab__content hidden" data-target="apps-hero--outer.tabsContent" data-tab="track" data-controller="apps-hero--track" data-apps-hero--track-search-value="">
            <div class="c-tab__content-primary o-col-12 u-direction-column">
                <h2 class="c-tab__content-title u-font-size-h3">Track</h2>
                <p class="u-font-size-small mobile-text-center">Enter your 16 digit tracking number or 8 digit calling card number.</p>
                <div class="c-tab__content-form">
                    <form data-action="apps-hero--track#submit" class="u-flex u-align-center u-direction-column u-direction-row-sm" autocomplete="off">
                        <div class="o-form-components o-col-12 o-col-sm-5 u-margin-bottom-2">
                            <div class="c-form-component c-form-component--input">
                                <div class="c-form-component-icons">
                                </div>
                                <input class="c-form-component-input c-form-component-input--wfull" type="text" id="homepageApps--track--parcelNo" data-target="apps-hero--track.searchField" data-action="input-&gt;apps-hero--track#updateSearchValue" placeholder=" " autocomplete="off">
                                <label class="c-form-component-label" for="homepageApps--track--parcelNo">
                                    Tracking number *
                                </label>
                                <div class="hidden error-message relative o-col-12 overwrite-padding-0" data-target="apps-hero--track.errorState">
                                    <span class="block transition-short  absolute z-10  u-background-color-demask  o-col-12  u-color-white  u-padding-3  rounded  leading-normal  input-error-message  u-font-size-paragraph u-margin-top-1">
                                        You appear to have entered too many numbers. <strong>Please check and try again.</strong>
                                    </span>
                                </div>
                                <div class="absolute z-10 track-error">
                                    <div class="error-state text-sm rounded hidden" data-target="apps-hero--track.error"></div>
                                </div>
                                <div class="absolute  searchField__count">
                                    <p class="remaining text-xl text-placeholder text-right" data-target="apps-hero--track.status">0</p>
                                </div>
                            </div>
                        </div>
                        <div class="o-col-12 o-col-sm-4 u-margin-bottom-2">
                            <button class="c-button c-button--primary c-button--pacific font-bold o-col-12" type="submit" data-target="apps-hero--track.submit" disabled="disabled">Track</button>
                        </div>
                    </form>
                </div>
            </div>
            <div>
                <ul class="c-tab__content-footer c-tab__content-footer-links u-flex u-direction-column u-direction-sm-row">
                    <li class="c-tab__content-footer-links-item u-margin-y-1 u-margin-sm-y-0">
                        <a href="https://www.myhermes.co.uk/help-and-support/index.html">
                            Need help finding your tracking number?
                        </a>
                    </li>
                </ul>
            </div>
        </div>
                        <!-- Third TAB -->
        <div class="c-tab__content return-content flex hidden" data-target="apps-hero--outer.tabsContent" data-tab="return" data-controller="retailer--search">
          <div>


            <div class="c-tab__content-primary return-primary-content">

              <div class="o-col-12 o-col-sm-8 return-content border-right overwrite-padding-0">




                <h2 class="c-tab__content-title u-font-size-h3">Returning your parcel is easy</h2>
                <p class="u-font-size-small mobile-text-center">Using our superfast, super simple service. We return parcels for high street, catalogues and online shops in the UK.</p>
                <div class="c-tab__content-form o-col-12 o-col-lg-10">
                    <form class="return-form" autocomplete="off" action="https://www.myhermes.co.uk/return.html" method="GET" data-target="retailer--search.form" data-action="retailer--search#handleSubmit">
                        <div class="o-form-components o-col-12 o-col-sm-8 u-padding-left-0 ">
                            <div class="c-form-component c-form-component--input">
                                <div class="c-form-component-icons">
                                </div>
                                <input type="text" id="homepageApps--return--retailer" data-target="retailer--search.userInput" autocomplete="off" class="c-form-component-input c-form-component-input--wfull" placeholder=" ">
                              <label class="c-form-component-label" for="homepageApps--return--retailer">
                                    Search for retailers name
                                </label>


                              <ul class="search-results client-result-list flex" data-target="retailer--search.results"></ul>


                                <!-- ERRORS -->
                            </div>
                        </div>
                        <div class="o-col-12 o-col-sm-4 offset-padding-fix">
                            <button type="submit" disabled="disabled" data-target="retailer--search.submitBtn" class="c-button c-button--primary c-button--pacific font-bold o-col-12">Return parcel</button>
                        </div>
                    </form>
                </div>
              </div>



              <div class=" o-col-12 o-col-sm-4 quick-links-container">

                <h2 class="popular-clients-title">Quick links</h2>


                <div>
                  <div class="popular-retailers container flex flex-wrap justify-start" data-target="retailer--search.popularRetailers"><a href="https://www.myhermes.co.uk/return.html#/direct?clientId=168&amp;childClientId=0" class="popular-clients-link">
        <div class="popular-clients-image">
          <img src="X//ms-logo.png" class="block absolute pin-center w-full">
        </div>
      </a><a href="https://www.myhermes.co.uk/return.html#/direct?clientId=614&amp;childClientId=1" class="popular-clients-link">
        <div class="popular-clients-image">
          <img src="X//boohoo.png" class="block absolute pin-center w-full">
        </div>
      </a><a href="https://www.myhermes.co.uk/return.html#/direct?clientId=628&amp;childClientId=7" class="popular-clients-link">
        <div class="popular-clients-image">
          <img src="X//jd-williamslogonew.png" class="block absolute pin-center w-full">
        </div>
      </a><a href="https://www.myhermes.co.uk/return.html#/direct?clientId=754&amp;childClientId=0" class="popular-clients-link">
        <div class="popular-clients-image">
          <img src="X//handm.png" class="block absolute pin-center w-full">
        </div>
      </a></div>


                </div>
              </div>


            </div>
            </div>

            <div class="c-tab__content-footer">
                <ul class="c-tab__content-footer-links u-flex u-direction-column u-direction-sm-row">
                    <li class="c-tab__content-footer-links-item u-margin-y-1 u-margin-sm-y-0">
                        <a href="https://www.myhermes.co.uk/help-and-support/index.html">
                            Need help returning your parcel?
                        </a>
                    </li>
                </ul>
            </div>







            </div>
            </div>
</div>
<style>
   .modal-outer {
        transition: opacity 0.3s ease;
    background-color: rgba(0,0,0,0.6);
  }
  .modal {
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  max-width: 850px;
  max-height: 90vh;
  overflow-y: auto;
    color: #1d3355;

  @media (max-width: 575px) {
    max-width: 90%;
  }
}
    .apps-hero {
        position: relative;
    }
    .apps-hero:before {
        width: 100%;
        content: '';
        background-color: #fff;
        height: 50%;
        position: absolute;
        bottom: 0;
        z-index: 0;
    }
    @media (min-width: 768px) {
        .apps-hero {
            margin-top: -100px;
            background: none;
        }
        .apps-hero:before {
          height: 40%;
        }
    }
    @media (min-width: 992px) {
        .apps-hero {
            margin-top: -180px;
            background: none;
        }
    }
    .arrow {
        background-image: url("data:image/svg+xml;charset=utf8,%3Csvg xmlns='http://www.w3.org/2000/svg' x&#8230;4 0 1 1 27 7l144 258L27 522c-2 4-7 7-12 7z' fill='%23173558'/%3E%3C/svg%3E");
        background-position: 50%;
        background-repeat: no-repeat;
        background-size: 9px 16px;
        width: 16px;
        height: 16px;
        position: absolute;
        z-index: 10;
        right: -16px;
        top: 16px;
    }
    .c-tab__tabs {
        list-style: none;
        display: flex;
        align-items: center;
        flex-direction: row;
        margin: 0;
        padding: 0;
    }
    .c-tab__tabs-item {
        background-color: #cce8f6;
        width: 100%;
        max-width: 129px;
        height: 47px;
        display: flex;
        align-items: center;
        border-radius: 4px 4px 0 0;
        border-right: 1px solid #bad3e0;
        box-shadow: -1px 0px 4px 0px rgba(202, 202, 202, 0.65);
        position: relative;
        text-align: center;
        font-size: 16px;
        color: #1d3355;
        line-height: 1.25;
        text-decoration: none;
        display: flex;
        align-items: center;
        justify-content: center;
    }
    .c-tab__tabs-item.active {
        background-color: #fff;
        font-weight: bold;
    }
    .c-tab__tabs-item.active:after {
        background-color: #fff;
        width: 100%;
        content: '';
        height: 5px;
        position: absolute;
        bottom: -4px;
    }
    .c-tab__content {
        min-height: 205px;
        background-color: #fff;
        width: 100%;
        border-radius: 0 4px 4px 4px;
        box-shadow: 0px 3px 4px 2px rgba(202, 202, 202, 0.65);
    }

  	.c-tab__content-primary {
        padding: 0 16px;
    }
    @media (min-width: 768px) {
      .c-tab__content-primary {
          padding: 0 32px;
      }
    }
    .c-tab__content-footer {
        width: 100%;
        border-top: 1px solid #eaeaea;
        position: relative;
    }
    .c-tab__content-title {
        font-size: 28px;
        font-weight: 900;
        line-height: 1.43;
        color: #1d3355;
      	padding-top: 16px;
      	text-align: center;
    }

  	@media(min-width: 768px) {
      .c-tab__content-title {
				padding-top: 28px;
        text-align: left;
      }
    }
    .c-tab__content-form {
        margin: 16px 0;
    }

    .c-tab__content-footer-links {
        padding: 16px;
        list-style: none;
        flex-direction: column;
    }

    @media (min-width: 768px) {
      .c-tab__content-footer-links {
          padding: 16px 32px;
      }
    }
    .c-tab__content-footer-links-item a {
        font-size: 14px;
        font-weight: bold;
        line-height: 1.29;
        color: #0091cd;
        text-decoration: none;
        margin-right: 24px;
        display: flex;
        align-items: center;
    }
    /* INPUTS */
    .o-form-components {
        /* width: 100%; */
    }
    .c-form-component--input {
        width: 100%;
        position: relative;
        display: flex;
    }
    .c-form-component--input .c-form-component-input {
        height: 48px;
        width: 100%;
        padding: 13px 16px 0;
        border: 2px solid #bdbdbb;
        border-radius: 4px;
        font-size: 14px;
        font-weight: 500;
        line-height: 1.29;
        background-color: #ffffff;
        color: #9b9b99;
        /* Chrome, Safari, Edge, Opera */
        /* Firefox */
    }
    @media (min-width: 768px) {
        .c-form-component--input .c-form-component-input {
            /* max-width: 230px; */
        }
    }
    .c-form-component--input .c-form-component-input.c-form-component-input--wfull {
        max-width: 100%;
    }
    .c-form-component--input .c-form-component-input:focus {
        outline: 0;
        border-color: #0091cd;
    }
    .c-form-component--input .c-form-component-input:focus+.c-form-component-label {
        color: #0091cd;
    }
    .c-form-component--input .c-form-component-input--success:not([type=search]):not(:disabled) {
        border-color: #1d9073;
    }
    .c-form-component--input .c-form-component-input--success:not([type=search]):not(:disabled)+.c-form-component-label {
        color: #1d9073;
    }
    .c-form-component--input .c-form-component-input--error:not(:disabled) {
        border-color: #cc1a1a;
    }
    .c-form-component--input .c-form-component-input--error:not(:disabled)+.c-form-component-label {
        color: #cc1a1a;
    }
    .c-form-component--input .c-form-component-input--error:not(:disabled)+.c-form-component-label+.c-form-component-message {
        color: #cc1a1a;
    }
    .c-form-component--input .c-form-component-input:disabled {
        cursor: not-allowed;
        color: #9b9b99;
    }
    .c-form-component--input .c-form-component-input:disabled+.c-form-component-label {
        pointer-events: none;
    }
    .c-form-component--input .c-form-component-input:disabled {
        background-color: #f4f4f4;
    }
    .c-form-component--input .c-form-component-input:focus {
        color: #1d3355;
    }
    .c-form-component--input .c-form-component-input:focus+.c-form-component-label,
    .c-form-component--input .c-form-component-input.is-active+.c-form-component-label {
        font-size: 10px;
        transform: translateY(0.85em);
        font-weight: bold;
    }

  	.c-form-component--input .c-form-component-input:not(:placeholder-shown)+.c-form-component-label,
    .c-form-component--input .c-form-component-input.is-active+.c-form-component-label {
        font-size: 10px;
        transform: translateY(0.85em);
        font-weight: bold;
    }

  .c-form-component-input:not(:placeholder-shown) {
    color: #1D3355;
  }
    :root .c-form-component--input .c-form-component-input::-ms-clear {
        width: 0;
        height: 0;
    }
    .c-form-component--input .c-form-component-label {
        position: absolute;
        top: 0;
        margin: 0 16px;
        transform: translateY(1.1em);
        left: 2px;
        line-height: 1.4em;
        font-size: 14px;
        font-weight: 500;
        transition: all 0.35s;
        cursor: text;
        color: #9b9b99;
    }
    /* INPUT END */
    /* BUTTON */
    .c-button {
        padding: 8px;
        display: flex;
        cursor: pointer;
        /* width: 100%; */
        height: 48px;
        border-radius: 4px;
        text-decoration: none;
        justify-content: center;
        font-size: 14px;
        align-items: center;
    }
    @media (min-width: 768px) {
        .c-button {
            /* max-width: 216px; */
            min-width: 240px;
        }
    }
    .c-button:focus {
        outline: none;
    }
    .c-button--pacific.c-button--primary {
        color: #ffffff;
        border: 2px solid #0091cd;
        background-color: #0091cd;
    }
    .c-button--pacific.c-button--primary:hover,
    .c-button--pacific.c-button--primary:focus {
        background-color: #0079b3;
    }
    .c-button--pacific.c-button--primary:hover {
        border: 2px solid #0079b3;
    }
    .c-button--pacific.c-button--primary:focus {
        border: 2px solid #1d3355;
    }
    .c-button--pacific.c-button--secondary:not(:focus) {
        border: 2px solid #0091cd;
    }
    .c-button.c-button--primary:disabled,
    .c-button.c-button--primary:disabled:hover {
        color: #ffffff;
        cursor: not-allowed;
        border: 2px solid #9b9b99;
        background-color: #9b9b99;
    }
    .apps-hero-padding {
        padding-top: 16px;
    }
@media screen and (min-width: 768px) {
    .apps-hero-padding {
/*         padding-top: 52px; */
    }
}
    .u-margin-y-1 {
        margin-top: 0.5rem;
        margin-bottom: 0.5rem;
    }
    @media screen and (min-width: 768px) {
        .u-margin-sm-y-0 {
            margin-top: 0;
            margin-bottom: 0;
        }
    }
    .u-padding-x-0 {
        padding-left: 0;
        padding-right: 0;
    }
    .u-flex {
        display: flex;
    }
    .u-align-center {
        -webkit-align-items: center;
        align-items: center;
    }
    .o-container {
        -webkit-box-sizing: border-box;
        -moz-box-sizing: border-box;
        box-sizing: border-box;
        width: 100%;
        margin-right: auto;
        margin-left: auto;
        padding-right: 16px;
        padding-left: 16px;
    }
    @media (min-width: 576px) {
        .o-container {
            max-width: 576px;
        }
    }
    @media (min-width: 768px) {
        .o-container {
            max-width: 768px;
        }
    }
    @media (min-width: 992px) {
        .o-container {
            max-width: 992px;
        }
    }
    @media (min-width: 1200px) {
        .o-container {
            max-width: 1200px;
        }
    }
    @media (min-width: 1600px) {
        .o-container {
            max-width: 1600px;
        }
    }

    .u-font-size-h3 {
        font-size: 28px;
    }
    .u-font-size-paragraph {
        font-size: 16px;
    }
    .u-font-size-small {
        font-size: 14px;
    }
    .u-background-color-demask {
        background-color: #cc1a1a;
    }
    .u-color-white {
        color: #ffffff;
    }

     .u-color-fill-white {
        color: #ffffff;
    }
    .u-display-hidden {
        display: none;
    }
    @media screen and (min-width: 768px) {
        .u-display-block-sm {
            display: block;
        }
        .u-flex-sm {
            display: flex;
        }
    }
    .error-message {
        position: absolute!important;
        margin-top: 58px;
      left:0px;
    }
    .input-error-message:before {
        border-color: transparent transparent #cc1a1a;
    }
    .u-margin-y-1 {
        margin-top: 0.5rem;
        margin-bottom: 0.5rem;
    }
    @media screen and (min-width: 768px) {
        .u-margin-sm-y-0 {
            margin-top: 0;
            margin-bottom: 0;
        }
    }
    .u-margin-top-1 {
        margin-top: 0.5rem;
    }
    .u-margin-bottom-2 {
        margin-bottom: 1rem;
    }
    .u-padding-x-0 {
        padding-left: 0;
        padding-right: 0;
    }
    .u-padding-bottom-3 {
        padding-bottom: 1.5rem;
    }

    .u-padding-left-0 {
      padding-left: 0;
    }
    .u-flex {
        display: flex;
    }
    .u-align-start {
        -webkit-align-items: flex-start;
        align-items: flex-start;
    }
    .u-align-center {
        -webkit-align-items: center;
        align-items: center;
    }
    .u-justify-end {
        -ms-flex-pack: end;
        -webkit-justify-content: flex-end;
        justify-content: flex-end;
    }
    .o-container {
        -webkit-box-sizing: border-box;
        -moz-box-sizing: border-box;
        box-sizing: border-box;
        width: 100%;
        margin-right: auto;
        margin-left: auto;
        padding-right: 16px;
        padding-left: 16px;
    }
    @media (min-width: 576px) {
        .o-container {
            max-width: 576px;
        }
    }
    @media (min-width: 768px) {
        .o-container {
            max-width: 768px;
        }
    }
    @media (min-width: 992px) {
        .o-container {
            max-width: 992px;
        }
    }
    @media (min-width: 1200px) {
        .o-container {
            max-width: 1200px;
        }
    }
    @media (min-width: 1600px) {
        .o-container {
            max-width: 1600px;
        }
    }

    .u-font-size-h1 {
        font-size: 44px;
    }
    .u-font-size-h3 {
        font-size: 28px;
    }
    .u-font-size-paragraph {
        font-size: 16px;
    }
    .u-font-size-small {
        font-size: 14px;
    }
    .u-background-color-demask {
        background-color: #cc1a1a;
    }
    .u-color-white {
        color: #ffffff;
    }

  .u-color-pacific-blue {
      color: #0091cd;
  }
    @media screen and (min-width: 768px) {
        .u-direction-row-sm {
            flex-direction: row!important;
        }
        .u-flex-sm {
            display: flex;
        }
    }
    .c-button {
        padding: 8px;
        cursor: pointer;
        min-width: 96px;
        min-height: 48px;
        text-decoration: none;
    }
    .c-button:focus {
        outline: none;
    }
    .c-button.c-button--primary:disabled {
        color: #ffffff;
        cursor: not-allowed;
        border: 2px solid #9b9b99;
        background-color: #9b9b99;
    }
    .c-button--pacific.c-button--primary {
        color: #ffffff;
        border: 2px solid #0091cd;
        background-color: #0091cd;
    }
    .c-button--pacific.c-button--primary:hover,
    .c-button--pacific.c-button--primary:focus {
        background-color: #0079b3;
    }
    .c-button--pacific.c-button--primary:hover {
        border: 2px solid #0079b3;
    }
    .c-button--pacific.c-button--primary:focus {
        border: 2px solid #1d3355;
    }
    .c-button--pacific.c-button--secondary:not(:focus) {
        border: 2px solid #0091cd;
    }
    .u-direction-row {
        -ms-flex-direction: row;
        -webkit-flex-direction: row;
        flex-direction: row;
    }
    .u-direction-column {
        -ms-flex-direction: column;
        -webkit-flex-direction: column;
        flex-direction: column;
    }

    @media (min-width: 768px) {

        .u-direction-sm-row {
            flex-direction: row!important;
        }
    }
  .popular-clients-image {
    position: relative;
    width: 62px;
    height: 62px;
    border-radius: 50%;
    overflow: hidden;
    border: 2px solid transparent;
  }

  .popular-clients-image:hover {
    border: 2px solid #0091CD;
  }

  .popular-clients-link {
    margin-right: 16px;
    margin-bottom: 8px;
  }

  .popular-clients-title {
    font-size: 16px;
    font-weight: bold;
    line-height: 1.25;
    color: #1D3355;
    margin-bottom: 16px;
    padding-top: 16px;
  }

  .border-right {
    border-right: none;
  }

  .return-form {
    width: 100%;
  }

  .quick-links-container {
    flex-direction: column;
    padding-left: 8px;
  }

  .return-content {
    position: relative;
    flex-direction: column;
  }
  .return-primary-content {
    position: relative;
    display: flex;
    flex-direction: column;
  }

  .offset-padding-fix {
    padding-left: 0;
  }

  .client-result-list {
    position: absolute;
    list-style: none;
    padding: 0;
    width: 100%;
    z-index: 10;
    display: block;
    background-color: #FFFFFF;
    box-shadow: 0 2px 4px 0 rgba(0, 0, 0, .1);
    overflow: auto;
    -webkit-overflow-scrolling: touch;

    max-height: 240px;
    top: 50px;
    border-radius: 8px;
  }

  .ul-padding {
    padding: 8px;
  }

  .client-list-individual-container {
    width: 100%;
    display: flex;
    border-radius: 4px;
    align-items: center;
    padding: 8px;

  }
  .client-list-individual-container:hover {
    background-color: #CCE8F6
  }

  .client-name-text {
    font-size: 16px;
    font-weight: bold;
    line-height: 1.25;
    color: #1D3355;
    pointer-events: none;
  }

  .client-name-text-no-results {
    font-size: 16px;
    font-weight: bold;
    line-height: 1.25;
    color: #CC1A1A;
    pointer-events: none;
    padding: 8px;
  }

  .client-image {
    width: 41px;
    height: 41px;
    border: 1px solid #EEEEEE;
    border-radius: 50%;
    overflow: hidden;
    margin-right: 16px;
    pointer-events: none;
    position: relative;
    flex-shrink: 0;
  }
  .client-image > img {
    position: absolute;
    left: 50%;
    top: 50%;
    transform: translate(-50%, -50%);
    width: 100%;
    pointer-events: none;
  }
  .overwrite-padding-0 {
    padding: 0;
  }

  .quick-send-tab {
    max-width: 162px;
  }

  .padding-x {
    padding-left: 8px;
    padding-right: 8px;
  }

  .mobile-text-center {
    text-align: center;
  }

  .track-error {
    top: 64px;
  }


  @media(min-width: 768px) {
    .popular-clients-title {
      padding-top: 28px;
    }
    .border-right {
      border-right: solid 1px #eaeaea;
    }
    .quick-links-container {
      padding-left: 48px;
    }
    .return-primary-content {
      flex-direction: row;
    }
    .offset-padding-fix {
      padding-left: 8px;
    }
    .mobile-text-center {
      text-align: left;
    }
  }

  #hero-image {
    margin-bottom: -46px;
  }

  @media(min-width: 992px) {
      #hero-image {
  padding-bottom:14px;
  margin-right:80px;
        margin-bottom:0;
  }
  }


</style>        <div id="o-threecolcard" class="hide-me content-block bg-white">
    <div class="o-container u-padding-sm-x-0 u-flex u-flex-wrap u-padding-y-32 u-align-center cards__direction u-margin-bottom-3 u-margin-bottom-sm-3 u-margin-bottom-sm-3" style="max-width: 992px; margin-left: auto; margin-right: auto; align-items: baseline; display: flex;">
        <!-- Card 1 -->
        <div class="o-col-12 o-col-sm-4 u-padding-sm-right-1 u-margin-bottom-2 u-margin-bottom-sm-0 u-margin-bottom-sm-0 card-1">
            <div class="u-flex u-flex-col">
                <div class="u-flex u-align-center">
                    <div class="u-flex u-padding-right-2">
                        <img src="X//easset_upload_file10590_20263_e.svg" alt="Illustration of Next day delivery" class="w-full c-threecolcard__image">
                    </div>
                    <div class="u-flex u-direction-column u-padding-right-2">
                        <h3 class="u-font-size-paragraph u-padding-bottom-1 text-blue-dark">Next Day delivery</h3>
                        <p class="u-font-size-paragraph text-blue-dark">Hurry! Send before 12pm </p>
                                            <div class="c-link pt-2">
                      <a aria-label="Set a safe place" href="https://new.myhermes.co.uk/track.html#/" class="pr-2 text-base font-bold">
                        Set a safe place                      </a>
                      <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16">
                          <g fill="none" fill-rule="evenodd">
                              <g fill="#0091CD">
                                  <g>
                                      <g>
                                          <g>
                                              <path d="M8.012-.099h.021c.148.005.294.064.406.176l3.932 						3.932c.172.172.223.43.13.655-.093.225-.312.372-.556.372-.16 0-.314-.064-.426-.177L8.613 1.953V14.4c0 .553-.269 1.001-.601 1.001-.332 0-.601-.448-.601-1.001L7.41 1.954 4.506 4.86c-.238.216-.603.207-.83-.02-.227-.227-.235-.593-.019-.83L7.59.077c.111-.111.255-.17.401-.175h.022z" transform="translate(-393 -664) translate(298 592) translate(1 72) translate(94) rotate(90 8.023 7.651)"></path>
                                          </g>
                                      </g>
                                  </g>
                              </g>
                          </g>
                      </svg>
                      </div>
                                          </div>
                </div>
            </div>
        </div>
        <!-- Card 2 -->
        <div class="o-col-12 o-col-sm-4 u-padding-sm-right-1 u-margin-bottom-2 md:u-margin-bottom-0 card-2">
            <div class="u-flex u-flex-col">
                <div class="u-flex u-align-center">
                    <div class="u-flex u-padding-right-2">
                        <img src="X//easset_upload_file12527_20263_e.svg" alt="Illustration of Drop-off at any ParcelShop" class="w-full c-threecolcard__image">
                    </div>
                    <div class="u-flex u-direction-column u-padding-right-2">
                        <h3 class="u-font-size-paragraph u-padding-bottom-1 text-blue-dark">Drop off at any ParcelShop</h3>
                        <p class="u-font-size-paragraph text-blue-dark">5000+ to choose from</p>
                    </div>
                </div>
            </div>
        </div>
        <!-- Card 3 -->
        <div class="o-col-12 o-col-sm-4 u-margin-bottom-2 u-margin-bottom-sm-0 card-3 u-flex u-justify-end-sm">
            <div class="u-flex u-flex-col">
                <div class="u-flex u-align-center">
                    <div class="u-flex u-padding-right-2">
                        <img src="X//easset_upload_file40927_20263_e.svg" alt="Illustration of Safe and Secure " class="w-full c-threecolcard__image">
                    </div>
                    <div class="u-flex u-direction-column u-padding-right-2">
                        <h3 class="u-font-size-paragraph u-padding-bottom-1 text-blue-dark">Safe and Secure </h3>
                        <p class="u-font-size-paragraph text-blue-dark">Tracking &amp; signature</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<style>
.u-margin-y-8 {
	margin-top: 4rem;
	margin-bottom: 4rem;
}
.u-margin-bottom-2 {
	margin-bottom: 1rem;
}
.u-margin-bottom-8 {
	margin-bottom: 4rem;
}
.u-padding-right-2 {
	padding-right: 1rem;
}
.u-padding-bottom-1 {
	padding-bottom: 0.5rem;
}

  .u-padding-y-32 {
    padding: 32px 0;
  }
.u-flex {
	display: flex;
}

.cards__direction {
	flex-direction: column;
}
@media screen and (min-width: 768px) {
	.u-direction-row-sm {
		flex-direction: row;
	}
  .u-padding-sm-x-0 {
  	padding-left: 0;
    padding-right: 0;
  }
}

.u-direction-column {
	-ms-flex-direction: column;
	-webkit-flex-direction: column;
	flex-direction: column;
}
.c-threecolcard__image {
  max-width: 40px;
}

@media (min-width: 768px) {
	.u-justify-end-sm {
    -ms-flex-pack: end;
    -webkit-justify-content: flex-end;
    justify-content: flex-end;
  }
  .c-threecolcard__image {
  	max-width: unset;
  }
  .cards__direction {
		flex-direction: row;
	}
}

.c-link {
  display: flex;
  flex-direction: row;
  align-items: center;
  color: #0091cd;
}
.u-font-size-h4 {
	font-size: 24px;
}
.u-font-size-paragraph {
	font-size: 16px;
}
.u-margin-y-4 {
	margin-top: 2rem;
	margin-bottom: 2rem;
}
.u-align-center {
	-webkit-align-items: center;
	align-items: center;
}

</style>        <div class="content-block u-padding-2 u-padding-sm-6 bg-blue-dark homepage-advertising-padding" data-controller="content-blocks--generic">
    <div class="inner container u-position-relative u-flex u-wrap u-justify-space-between u-align-center homepage-advertising-container u-direction-row-reverse-sm">

      <div class="o-col-12 u-padding-sm-bottom-3 u-padding-bottom-0  o-col-sm-6 u-position-relative u-flex u-justify-center u-justify-start-sm u-justify-end-sm u-align-center">
        <img src="X//hermes-play.svg" alt="" class="w-4/5 image-max">
      </div>

      <div class="o-col-12 o-col-sm-5 text-left u-direction-column ">
        <h2 class="font-black leading-normal u-color-white u-font-size-h3 u-font-size-h2-sm text-left text-white u-padding-bottom-2 homepage-advertising-title">Bring your parcel to life with a video message</h2>
        <div class="homepage-advertising-body u-font-size-paragraph text-white ">
          <div class="u-font-size-paragraph text-left"><p>Download our app to send a personalised and meaningful video message with your parcel.</p>
<p></p>
<style><!--
.tb_button {padding:1px;cursor:pointer;border-right: 1px solid #8b8b8b;border-left: 1px solid #FFF;border-bottom: 1px solid #fff;}.tb_button.hover {borer:2px outset #def; background-color: #f8f8f8 !important;}.ws_toolbar {z-index:100000} .ws_toolbar .ws_tb_btn {cursor:pointer;border:1px solid #555;padding:3px}   .tb_highlight{background-color:yellow} .tb_hide {visibility:hidden} .ws_toolbar img {padding:2px;margin:0px}
--></style></div>

          <div class="u-flex u-margin-top-2">
          <a href="https://itunes.apple.com/gb/app/hermes-parcels/id1446461114?mt=8" aria-label="" target="_blank"><img class="u-margin-right-2" src="X//easset_upload_file21962_20299_e.svg" alt="Download on the App Store"></a>
          <a href="https://play.google.com/store/apps/details?id=com.hermes.hercules" aria-label="" target="_blank"><img src="X//easset_upload_file28267_20299_e.svg" alt="Get it on Google Play"></a>
        </div> </div>
        <div class="u-flex u-align-center">


        </div>


      </div>
  </div>
</div>
<style>
  .image-max {
  	max-width: 160px;
    max-height: 160px;
  }
  .homepage-advertising-container {
    max-width: 992px;
  }
  @media(min-width: 768px) {
    .homepage-advertising-title {
      line-height: 44px;
    }
  }
  .homepage-advertising-title {
    line-height: 30px;
  }
  .homepage-advertising-body {
    font-size: 16px;
    line-height: 1.25em;
  }
  .homepage-advertising-body p {
    line-height: 1.25em;
    margin-bottom: 16px;
  }
  .homepage-advertising-body ul {
    list-style: none;
    padding-left: 1.25em;
    margin-bottom: 16px;
  }
  .homepage-advertising-body ul li:before {
    content: "";
    background-color: #7ed1e2;
    display: inline-block;
    width: 7px;
  	height: 7px;
    border-radius: 50px;
    position: absolute;
    top: 5px;
    left: -16px;
	}
  .homepage-advertising-body ul li {
    line-height: 1.25em;
    position: relative;
  }
  .homepage-advertising-padding {
    padding-top: 52px;
  }
  .padding-bottom-spacing {
    padding-bottom: 8px;
  }

  @media(min-width: 576px) {
    .homepage-advertising-title {
      line-height: 44px;
    }
  }

  @media(min-width: 768px) {
    .image-max {
      max-width: 320px;
      max-height: 300px;
    }
  }

  @media(min-width: 992px) {
    .homepage-advertising-body {
      font-size: 20px;
      line-height: 28px;
    }
    .image-max {
      max-width: 512px;
      max-height: none;
    }
  }
.homepage-advertising-container {
    max-width: 992px;
  }
  .homepage-advertising-body {
    font-size: 16px;
    line-height: 1.25em;
  }

  @media(min-width: 992px) {
    .homepage-advertising-body {
      font-size: 20px;
      line-height: 28px;
    }
  }

@media (min-width: 768px) {
  .u-direction-row-reverse-sm {
    -ms-flex-direction: row-reverse;
    -webkit-flex-direction: row-reverse;
    flex-direction: row-reverse;
  }
}
.u-direction-row-reverse {
	-ms-flex-direction: row-reverse;
	-webkit-flex-direction: row-reverse;
	flex-direction: row-reverse;
}
.u-padding-bottom-0 {
	padding-bottom: 0;
}
@media screen and (min-width: 768px) {
	.u-padding-sm-bottom-3 {
		padding-bottom: 1.5rem;
	}
}
.u-flex {
	display: flex;
}
.u-wrap {
	-ms-flex-wrap: wrap;
	-webkit-flex-wrap: wrap;
	flex-wrap: wrap;
}
.u-align-center {
	-webkit-align-items: center;
	align-items: center;
}
.u-justify-center {
	-ms-flex-pack: center;
	-webkit-justify-content: center;
	justify-content: center;
}
.u-justify-space-between {
	-ms-flex-pack: justify;
	-webkit-justify-content: space-between;
	justify-content: space-between;
}

.u-font-size-h3 {
	font-size: 24px;
}

@media (min-width: 768px) {

  .u-font-size-h2-sm {
		font-size: 36px;
	}
}
.u-font-size-paragraph {
	font-size: 16px;
}
.u-color-white {
	color: #ffffff;
}
.u-position-relative {
	position: relative;
}

.u-padding-x-0 {
	padding-left: 0;
	padding-right: 0;
}

.u-padding-bottom-2 {
	padding-bottom: 1rem;
}

.u-margin-top-2 {
	margin-top: 1rem;
}

.u-margin-right-2 {
	margin-right: 1rem;
}

</style>        <div class="content-block bg-blue-dark pt-8 md:pt-12 pb-10 md:pb-24">
  <div class="container inner">
    <div class="w-full w-full mx-auto">
      <section class="text-blue-dark  text-base  leading-normal table  table--terms" style="margin: auto;">
          <div class="inner container relative u-flex u-align-center u-direction-column u-direction-row-sm" style="max-width: 992px; width: 100%; justify-content: space-between;">
<div class="o-col-12 o-col-sm-6 text-center lg:text-left text-xl flex justify-center flex-col">
<div class="u-skewed">
<div class="u-skewed__container">
<table class="c-table bg-white">
<thead>
<tr>
<th style="text-align: left;"></th>
<th style="text-align: center;">Royal Mail</th>
<th style="text-align: center;">Hermes</th>
<th class="bg-blue-light" style="text-align: center;">Saving</th>
</tr>
</thead>
<tbody>
<tr>
<td class="weight">Postable (0-1kg)</td>
<td data-label="Royal Mail">£2.70</td>
<td data-label="Hermes">£2.45</td>
<td data-label="Hermes Saving" class="bg-blue-light">£0.25</td>
</tr>
<tr>
<td class="weight">0-1kg</td>
<td data-label="Royal Mail">£5.30</td>
<td data-label="Hermes">£2.90</td>
<td data-label="Hermes Saving" class="bg-blue-light">£2.40</td>
</tr>
<tr>
<td class="weight">1-2kg</td>
<td data-label="Royal Mail">£5.30</td>
<td data-label="Hermes">£4.20</td>
<td data-label="Hermes Saving" class="bg-blue-light">£1.10</td>
</tr>
<tr></tr>
<tr>
<td class="weight">2-5kg</td>
<td data-label="Royal Mail">£8.99</td>
<td data-label="Hermes">£5.99</td>
<td data-label="Hermes Saving" class="bg-blue-light">£3.00</td>
</tr>
<tr>
<td class="weight">5-10kg</td>
<td data-label="Royal Mail">£20.25</td>
<td data-label="Hermes">£6.99</td>
<td data-label="Hermes Saving" class="bg-blue-light">£13.26</td>
</tr>
<tr>
<td class="weight">10-15kg</td>
<td data-label="Royal Mail">£28.55</td>
<td data-label="Hermes">£9.20</td>
<td data-label="Hermes Saving" class="bg-blue-light">£19.35</td>
</tr>
</tbody>
<tfoot>
<tr class="bg-blue-lighter">
<td colspan="4">
<p>Prices quoted are for a standard delivery of medium-sized drop-off parcels (compared on 01/01/2021).</p>
</td>
</tr>
</tfoot>
</table>
</div>
</div>
</div>
<div class="o-col-12 o-col-sm-5 text-center lg:text-left text-xl flex justify-center flex-col">
<h2 class="font-black u-color-white u-font-size-h3 u-font-size-h2-sm text-left homepage-advertising-title c-table__heading u-padding-bottom-2">See where Hermes is CHEAPER than Royal Mail</h2>
<div class="homepage-advertising-body u-font-size-paragraph u-color-white">
<p class="u-font-size-paragraph text-left">Compare postage prices and see where we’re cheaper – save £2.40 sending a 1kg parcel (standard delivery with FREE tracking) by using us instead of going to a Post Office.</p>
<p style="text-align: left; font-size: 14px;">*1kg medium parcel, standard delivery by Royal Mail (prices compared on 01/01/2021)</p>
</div>
<div class="flex items-center">
<div><a href="https://www.myhermes.co.uk/#" aria-label="Click here to find Hermes Integrations" class="c-button c-button--primary c-button--pacific o-col-12 u-color-white u-background-color-pacific u-padding-2 btn o-col-12 o-col-sm-3 u-padding-y-2 u-padding-y-sm-4 u-font-size-small" style="display: inline-flex; width: auto;"> Send a parcel </a></div>
</div>
</div>
</div>
<style><!--
.c-table {
        border-collapse: collapse;
        border-radius: 4px;
        font-size: 12px;
        color: #173558;
    }

    @media(min-width: 401px) {
        .c-table {
            font-size: 16px;
        }
    }

    .c-table thead {
        border: none;
        clip: rect(0 0 0 0);
        height: 1px;
        margin: -1px;
        overflow: hidden;
        padding: 0;
        position: absolute;
        width: 1px;
    }

    .c-table tr {
        display: block;
        font-size: 12px;
    }

    @media(min-width: 401px) {
        .c-table tr {
            font-size: 16px;
        }
    }

    .c-table td {
        display: block;
        text-align: center;
        font-size: 12px;
        color: #173558;
        padding: 0.5rem 1rem;
    }

    @media(min-width: 401px) {
        .c-table td {
            font-size: 16px;
        }
    }

    .c-table td::before {
        content: attr(data-label);
        float: left;
        font-size: 12px;
        font-weight: 700;
        color: #173558;
    }

    @media(min-width: 401px) {
        .c-table td::before {
            font-size: 16px;
        }
    }

    .c-table td.weight {
        display: block;
        text-align: center;
        font-weight: 700;
        font-size: 12px;
        color: #173558;
    }

    @media(min-width: 401px) {
        .c-table td.weight {
            font-size: 16px;
        }
    }

    .c-table tfoot tr {
        display: table-row;
    }

    .c-table tfoot tr td {
        display: table-cell;
        text-align: left;
        padding: 0.5rem 1rem;
    }

    .c-table tfoot tr td {
        font-size: 12px;
    }

    @media(min-width: 401px) {
        .c-table tfoot tr td {
            font-size: 16px;
        }
    }

    .c-table tfoot tr td::before {
        content: none;
    }

    .c-table th {
        padding: 0.5rem 1rem;
    }

    .c-table th:last-child {
        border-top-right-radius: 4px;
    }

    .c-table tfoot tr td {
        border-bottom-right-radius: 4px;
        border-bottom-left-radius: 4px;
    }

    .u-skewed {
        background: #0091cd;
        border-radius: 4px;
        margin-top: 32px;
        height: 100%;
        position: relative;
        transform: skew(-2deg, 1deg);
        max-width: 100%;
        margin-left: 0px;
        box-sizing: border-box;
    }

    @media(min-width: 401px) {
        .u-skewed {
            margin-left: 10px;
        }
    }

    .u-skewed__container {
        position: relative;
        z-index: 2;
        background-color: #fff;
        border-radius: 4px;
        transform: skew(2deg, -1deg);
    }

    @media(min-width: 0px) {
        .c-table thead {
            position: relative;
        }

        .c-table tr {
            display: table-row;
        }

        .c-table td {
            display: table-cell;
            font-size: 12px;
        }

        .c-table td::before {
            content: none;
        }

        .c-table td.weight {
            display: table-cell;
            text-align: left;
        }

        .c-table tfoot tr td {
            padding: 0.5rem 1rem;
        }
    }

    @media(min-width: 401px) {
        .c-table td {
            font-size: 16px;
        }
    }

    /* @media(min-width: 768px) {
        .c-table {
            font-size: 16px;
        }

        .c-table tr {
            font-size: 16px;
        }

        .c-table td {
            display: table-cell;
            text-align: center;
        }

        .c-table td.weight {
            font-size: 16px;
        }
    } */

    .c-table__heading {
        line-height: 44px;
    }

    .u-flex {
        display: flex;
    }

    .u-direction-column {
        -ms-flex-direction: column;
        -webkit-flex-direction: column;
        flex-direction: column;
    }

    .u-align-center {
        -webkit-align-items: center;
        align-items: center;
    }


    .u-font-size-paragraph {
        font-size: 16px;
    }

    .u-background-color-pacific {
        background-color: #0091cd;
    }

    .u-color-white {
        color: #ffffff;
    }

    @media screen and (min-width: 768px) {
        .u-direction-row-sm {
            flex-direction: row;
        }
    }

    .u-font-size-h3 {
        font-size: 24px;
    }

    @media(min-width: 768px) {
        .homepage-advertising-title {
            line-height: 44px;
        }

        .u-font-size-h2-sm {
            font-size: 36px;
        }
    }


    .homepage-advertising-title {
        line-height: 30px;
    }

    .u-padding-bottom-2 {
        padding-bottom: 1rem;
    }

    .table--terms table td {
        border-bottom-width: 0;
    }

    .c-button {
        padding: 8px;
        cursor: pointer;
        min-width: 96px;
        min-height: 48px;
        text-decoration: none;
    }


    .c-button--pacific.c-button--primary {
        color: #ffffff;
        border: 2px solid #0091cd;
        background-color: #0091cd;
    }

    .c-button--pacific.c-button--primary:hover,
    .c-button--pacific.c-button--primary:focus {
        background-color: #0079b3;
    }

    .c-button--pacific.c-button--primary:hover {
        border: 2px solid #0079b3;
    }

    .c-button--pacific.c-button--primary:focus {
        border: 2px solid #1d3355;
    }

    .c-button--pacific.c-button--secondary:not(:focus) {
        border: 2px solid #0091cd;
    }
--></style>      </section>
    </div>
  </div>
</div>        <div class="hide-me content-block u-padding-2 u-padding-sm-6 bg-blue-dark homepage-advertising-padding" data-controller="content-blocks--generic">
    <div class="inner container u-position-relative u-flex u-wrap u-justify-space-between u-align-center homepage-advertising-container u-direction-row-reverse-sm">

      <div class="o-col-12 u-padding-sm-bottom-3 u-padding-bottom-0  o-col-sm-6 u-position-relative u-flex u-justify-center u-justify-start-sm u-justify-end-sm u-align-center ">
        <img src="X//easset_upload_file57214_24796_e.svg" alt="A Hermes ParcelShop" class="w-4/5 image-max">
      </div>

      <div class="o-col-12 o-col-sm-5 text-left u-direction-column ">
        <h2 class="font-black leading-normal u-font-size-h3 u-font-size-h2-sm text-left text-white u-padding-bottom-2 homepage-advertising-title">It's EASY too!</h2>
        <div class="homepage-advertising-body u-font-size-paragraph text-white padding-bottom-spacing">
          <div class="u-font-size-paragraph text-left"><p>It's easy to send from our 5,000 local ParcelShops &amp; Lockers!</p>
<ul>
<li>Longer opening hours</li>
<li>Open 7 days a week</li>
<li>FREE parking nearby</li>
</ul>
<p>We also offer a parcel courier service. Just tell us where you’d like your parcel collecting from: your work, home or wherever you’d like!</p></div>
        </div>
        <div class="u-flex u-align-center">


          <div class="u-padding-x-0 inline-block">
            <a href="https://www.myhermes.co.uk/our-services/our-prices.html" aria-label="Click here to find our services" style="padding: 16px;" class="btn o-col-12 o-col-sm-3 inline-block u-padding-y-2 c-button c-button--pacific c-button--primary u-padding-y-sm-4 u-font-size-small text-center font-bold button-width bg-blue text-white hover:bg-white hover:text-blue">
              Our services            </a>
          </div>


        </div>


      </div>
  </div>
</div>
<style>
  .image-max {
  	max-width: 160px;
    max-height: 160px;
  }
  .homepage-advertising-container {
    max-width: 992px;
  }
  @media(min-width: 768px) {
    .homepage-advertising-title {
      line-height: 44px;
    }
  }
  .homepage-advertising-title {
    line-height: 30px;
  }
  .homepage-advertising-body {
    font-size: 16px;
    line-height: 1.25em;
  }
  .homepage-advertising-body p {
    line-height: 1.25em;
    margin-bottom: 16px;
  }
  .homepage-advertising-body ul {
    list-style: none;
    padding-left: 1.25em;
    margin-bottom: 16px;
  }
  .homepage-advertising-body ul li:before {
    content: "";
    background-color: #7ed1e2;
    display: inline-block;
    width: 7px;
  	height: 7px;
    border-radius: 50px;
    position: absolute;
    top: 5px;
    left: -16px;
	}
  .homepage-advertising-body ul li {
    line-height: 1.25em;
    position: relative;
  }
  .homepage-advertising-padding {
    padding: 24px 0;
  }
  @media(min-width: 576px) {
    .homepage-advertising-padding {
     	padding: 56px 0;
      }
    }
  .padding-bottom-spacing {
    padding-bottom: 8px;
  }

  @media(min-width: 576px) {
    .homepage-advertising-title {
      line-height: 44px;
    }
  }

  @media(min-width: 768px) {
    .image-max {
      max-width: 320px;
      max-height: 300px;
    }
  }

  @media(min-width: 992px) {
    .homepage-advertising-body {
      font-size: 20px;
      line-height: 28px;
    }
    .image-max {
      max-width: 512px;
      max-height: none;
    }
  }
.homepage-advertising-container {
    max-width: 992px;
  }
  .homepage-advertising-body {
    font-size: 16px;
    line-height: 1.25em;
  }

  @media(min-width: 992px) {
    .homepage-advertising-body {
      font-size: 20px;
      line-height: 28px;
    }
  }

@media (min-width: 768px) {
  .u-direction-row-reverse-sm {
    -ms-flex-direction: row-reverse;
    -webkit-flex-direction: row-reverse;
    flex-direction: row-reverse;
  }
}
.u-direction-row-reverse {
	-ms-flex-direction: row-reverse;
	-webkit-flex-direction: row-reverse;
	flex-direction: row-reverse;
}
.u-padding-bottom-0 {
	padding-bottom: 0;
}
@media screen and (min-width: 768px) {
	.u-padding-sm-bottom-3 {
		padding-bottom: 1.5rem;
	}
}
.u-flex {
	display: flex;
}
.u-wrap {
	-ms-flex-wrap: wrap;
	-webkit-flex-wrap: wrap;
	flex-wrap: wrap;
}
.u-align-center {
	-webkit-align-items: center;
	align-items: center;
}
.u-justify-center {
	-ms-flex-pack: center;
	-webkit-justify-content: center;
	justify-content: center;
}
.u-justify-space-between {
	-ms-flex-pack: justify;
	-webkit-justify-content: space-between;
	justify-content: space-between;
}

.u-font-size-h3 {
	font-size: 24px;
}

@media (min-width: 768px) {

  .u-font-size-h2-sm {
		font-size: 36px;
	}
}
.u-font-size-paragraph {
	font-size: 16px;
}
.u-color-white {
	color: #ffffff;
}
.u-position-relative {
	position: relative;
}

.u-padding-x-0 {
	padding-left: 0;
	padding-right: 0;
}

.u-padding-bottom-2 {
	padding-bottom: 1rem;
}

.c-button {
	padding: 8px;
	cursor: pointer;
	min-width: 96px;
	min-height: 48px;
	text-decoration: none;
}
.c-button--pacific.c-button--primary {
	color: #ffffff;
	border: 2px solid #0091cd;
	background-color: #0091cd;
}
.c-button--pacific.c-button--primary:hover, .c-button--pacific.c-button--primary:focus {
	background-color: #0079b3;
}
.c-button--pacific.c-button--primary:hover {
	border: 2px solid #0079b3;
}
.c-button--pacific.c-button--primary:focus {
	border: 2px solid #1d3355;
}
.c-button--pacific.c-button--secondary:not(:focus) {
	border: 2px solid #0091cd;
}

	@media (max-width: 767px) {
    .hide-mobile-image {
      display: none;
    }
  }

.u-direction-column {
  -ms-flex-direction: column;
  -webkit-flex-direction: column;
  flex-direction: column;
}

  .button-width {
    width: 100%;
  }

</style>        <div class="hide-me content-block u-padding-2 u-padding-sm-6 bg-blue-dark homepage-advertising-padding" data-controller="content-blocks--generic">
    <div class="inner container u-position-relative u-flex u-wrap u-justify-space-between u-align-center homepage-advertising-container ">

      <div class="o-col-12 u-padding-sm-bottom-3 u-padding-bottom-0  o-col-sm-6 u-position-relative u-flex u-justify-center u-justify-start-sm  u-align-center ">
        <img src="X//easset_upload_file30727_24795_e.svg" alt="Hermes Integrations" class="w-4/5 image-max">
      </div>

      <div class="o-col-12 o-col-sm-5 text-left u-direction-column ">
        <h2 class="font-black leading-normal u-font-size-h3 u-font-size-h2-sm text-left text-white u-padding-bottom-2 homepage-advertising-title">Sending lots of parcels is much FASTER</h2>
        <div class="homepage-advertising-body u-font-size-paragraph text-white padding-bottom-spacing">
          <div class="u-font-size-paragraph text-left"><p>If you send lots of parcels you can sort it in seconds by connecting your Hermes account with eBay, Amazon and Shopify. You can also upload a CSV file - whatever's easiest!</p></div>
        </div>
        <div class="u-flex u-align-center">


          <div class="u-padding-x-0 inline-block">
            <a href="https://www.myhermes.co.uk/our-services/integrations.html" aria-label="Click here to find Hermes Integrations" style="padding: 16px;" class="btn o-col-12 o-col-sm-3 inline-block u-padding-y-2 c-button c-button--pacific c-button--primary u-padding-y-sm-4 u-font-size-small text-center font-bold button-width bg-blue text-white hover:bg-white hover:text-blue">
              Hermes Integrations            </a>
          </div>


        </div>


      </div>
  </div>
</div>
<style>
  .image-max {
  	max-width: 160px;
    max-height: 160px;
  }
  .homepage-advertising-container {
    max-width: 992px;
  }
  @media(min-width: 768px) {
    .homepage-advertising-title {
      line-height: 44px;
    }
  }
  .homepage-advertising-title {
    line-height: 30px;
  }
  .homepage-advertising-body {
    font-size: 16px;
    line-height: 1.25em;
  }
  .homepage-advertising-body p {
    line-height: 1.25em;
    margin-bottom: 16px;
  }
  .homepage-advertising-body ul {
    list-style: none;
    padding-left: 1.25em;
    margin-bottom: 16px;
  }
  .homepage-advertising-body ul li:before {
    content: "";
    background-color: #7ed1e2;
    display: inline-block;
    width: 7px;
  	height: 7px;
    border-radius: 50px;
    position: absolute;
    top: 5px;
    left: -16px;
	}
  .homepage-advertising-body ul li {
    line-height: 1.25em;
    position: relative;
  }
  .homepage-advertising-padding {
    padding: 24px 0;
  }
  @media(min-width: 576px) {
    .homepage-advertising-padding {
     	padding: 56px 0;
      }
    }
  .padding-bottom-spacing {
    padding-bottom: 8px;
  }

  @media(min-width: 576px) {
    .homepage-advertising-title {
      line-height: 44px;
    }
  }

  @media(min-width: 768px) {
    .image-max {
      max-width: 320px;
      max-height: 300px;
    }
  }

  @media(min-width: 992px) {
    .homepage-advertising-body {
      font-size: 20px;
      line-height: 28px;
    }
    .image-max {
      max-width: 512px;
      max-height: none;
    }
  }
.homepage-advertising-container {
    max-width: 992px;
  }
  .homepage-advertising-body {
    font-size: 16px;
    line-height: 1.25em;
  }

  @media(min-width: 992px) {
    .homepage-advertising-body {
      font-size: 20px;
      line-height: 28px;
    }
  }

@media (min-width: 768px) {
  .u-direction-row-reverse-sm {
    -ms-flex-direction: row-reverse;
    -webkit-flex-direction: row-reverse;
    flex-direction: row-reverse;
  }
}
.u-direction-row-reverse {
	-ms-flex-direction: row-reverse;
	-webkit-flex-direction: row-reverse;
	flex-direction: row-reverse;
}
.u-padding-bottom-0 {
	padding-bottom: 0;
}
@media screen and (min-width: 768px) {
	.u-padding-sm-bottom-3 {
		padding-bottom: 1.5rem;
	}
}
.u-flex {
	display: flex;
}
.u-wrap {
	-ms-flex-wrap: wrap;
	-webkit-flex-wrap: wrap;
	flex-wrap: wrap;
}
.u-align-center {
	-webkit-align-items: center;
	align-items: center;
}
.u-justify-center {
	-ms-flex-pack: center;
	-webkit-justify-content: center;
	justify-content: center;
}
.u-justify-space-between {
	-ms-flex-pack: justify;
	-webkit-justify-content: space-between;
	justify-content: space-between;
}

.u-font-size-h3 {
	font-size: 24px;
}

@media (min-width: 768px) {

  .u-font-size-h2-sm {
		font-size: 36px;
	}
}
.u-font-size-paragraph {
	font-size: 16px;
}
.u-color-white {
	color: #ffffff;
}
.u-position-relative {
	position: relative;
}

.u-padding-x-0 {
	padding-left: 0;
	padding-right: 0;
}

.u-padding-bottom-2 {
	padding-bottom: 1rem;
}

.c-button {
	padding: 8px;
	cursor: pointer;
	min-width: 96px;
	min-height: 48px;
	text-decoration: none;
}
.c-button--pacific.c-button--primary {
	color: #ffffff;
	border: 2px solid #0091cd;
	background-color: #0091cd;
}
.c-button--pacific.c-button--primary:hover, .c-button--pacific.c-button--primary:focus {
	background-color: #0079b3;
}
.c-button--pacific.c-button--primary:hover {
	border: 2px solid #0079b3;
}
.c-button--pacific.c-button--primary:focus {
	border: 2px solid #1d3355;
}
.c-button--pacific.c-button--secondary:not(:focus) {
	border: 2px solid #0091cd;
}

	@media (max-width: 767px) {
    .hide-mobile-image {
      display: none;
    }
  }

.u-direction-column {
  -ms-flex-direction: column;
  -webkit-flex-direction: column;
  flex-direction: column;
}

  .button-width {
    width: 100%;
  }

</style>        <div class="hide-me content-block u-padding-2 u-padding-sm-6 bg-blue-dark homepage-advertising-padding" data-controller="content-blocks--generic">
    <div class="inner container u-position-relative u-flex u-wrap u-justify-space-between u-align-center homepage-advertising-container u-direction-row-reverse-sm">

      <div class="o-col-12 u-padding-sm-bottom-3 u-padding-bottom-0  o-col-sm-6 u-position-relative u-flex u-justify-center u-justify-start-sm u-justify-end-sm u-align-center ">
        <img src="X//easset_upload_file14264_24797_e.svg" alt="A Hermes courier with PDA" class="w-4/5 image-max">
      </div>

      <div class="o-col-12 o-col-sm-5 text-left u-direction-column ">
        <h2 class="font-black leading-normal u-font-size-h3 u-font-size-h2-sm text-left text-white u-padding-bottom-2 homepage-advertising-title">You get a PREMIUM service with us</h2>
        <div class="homepage-advertising-body u-font-size-paragraph text-white padding-bottom-spacing">
          <div class="u-font-size-paragraph text-left"><p>You get all of this ABSOLUTELY FREE when you use Hermes for your parcel delivery:</p>
<ul>
<li>Regular, real-time tracking information</li>
<li>A delivery time window on the day</li>
<li>Divert to a neighbour or safe place</li>
<li>Safe place delivery photo confirmation</li>
<li>Includes £20 FREE parcel cover*</li>
</ul>
<p>We can also arrange for a friendly, local parcel courier to collect your parcel from you if it's more convenient.</p>
<p>*Excludes Postable parcels</p></div>
        </div>
        <div class="u-flex u-align-center">


          <div class="u-padding-x-0 inline-block">
            <a href="https://www.myhermes.co.uk/send-a-parcel/how-to-send-a-parcel.html" aria-label="Click here to find how to send a parcel" style="padding: 16px;" class="btn o-col-12 o-col-sm-3 inline-block u-padding-y-2 c-button c-button--pacific c-button--primary u-padding-y-sm-4 u-font-size-small text-center font-bold button-width bg-blue text-white hover:bg-white hover:text-blue">
              How to send a parcel            </a>
          </div>


        </div>


      </div>
  </div>
</div>
<style>
  .image-max {
  	max-width: 160px;
    max-height: 160px;
  }
  .homepage-advertising-container {
    max-width: 992px;
  }
  @media(min-width: 768px) {
    .homepage-advertising-title {
      line-height: 44px;
    }
  }
  .homepage-advertising-title {
    line-height: 30px;
  }
  .homepage-advertising-body {
    font-size: 16px;
    line-height: 1.25em;
  }
  .homepage-advertising-body p {
    line-height: 1.25em;
    margin-bottom: 16px;
  }
  .homepage-advertising-body ul {
    list-style: none;
    padding-left: 1.25em;
    margin-bottom: 16px;
  }
  .homepage-advertising-body ul li:before {
    content: "";
    background-color: #7ed1e2;
    display: inline-block;
    width: 7px;
  	height: 7px;
    border-radius: 50px;
    position: absolute;
    top: 5px;
    left: -16px;
	}
  .homepage-advertising-body ul li {
    line-height: 1.25em;
    position: relative;
  }
  .homepage-advertising-padding {
    padding: 24px 0;
  }
  @media(min-width: 576px) {
    .homepage-advertising-padding {
     	padding: 56px 0;
      }
    }
  .padding-bottom-spacing {
    padding-bottom: 8px;
  }

  @media(min-width: 576px) {
    .homepage-advertising-title {
      line-height: 44px;
    }
  }

  @media(min-width: 768px) {
    .image-max {
      max-width: 320px;
      max-height: 300px;
    }
  }

  @media(min-width: 992px) {
    .homepage-advertising-body {
      font-size: 20px;
      line-height: 28px;
    }
    .image-max {
      max-width: 512px;
      max-height: none;
    }
  }
.homepage-advertising-container {
    max-width: 992px;
  }
  .homepage-advertising-body {
    font-size: 16px;
    line-height: 1.25em;
  }

  @media(min-width: 992px) {
    .homepage-advertising-body {
      font-size: 20px;
      line-height: 28px;
    }
  }

@media (min-width: 768px) {
  .u-direction-row-reverse-sm {
    -ms-flex-direction: row-reverse;
    -webkit-flex-direction: row-reverse;
    flex-direction: row-reverse;
  }
}
.u-direction-row-reverse {
	-ms-flex-direction: row-reverse;
	-webkit-flex-direction: row-reverse;
	flex-direction: row-reverse;
}
.u-padding-bottom-0 {
	padding-bottom: 0;
}
@media screen and (min-width: 768px) {
	.u-padding-sm-bottom-3 {
		padding-bottom: 1.5rem;
	}
}
.u-flex {
	display: flex;
}
.u-wrap {
	-ms-flex-wrap: wrap;
	-webkit-flex-wrap: wrap;
	flex-wrap: wrap;
}
.u-align-center {
	-webkit-align-items: center;
	align-items: center;
}
.u-justify-center {
	-ms-flex-pack: center;
	-webkit-justify-content: center;
	justify-content: center;
}
.u-justify-space-between {
	-ms-flex-pack: justify;
	-webkit-justify-content: space-between;
	justify-content: space-between;
}

.u-font-size-h3 {
	font-size: 24px;
}

@media (min-width: 768px) {

  .u-font-size-h2-sm {
		font-size: 36px;
	}
}
.u-font-size-paragraph {
	font-size: 16px;
}
.u-color-white {
	color: #ffffff;
}
.u-position-relative {
	position: relative;
}

.u-padding-x-0 {
	padding-left: 0;
	padding-right: 0;
}

.u-padding-bottom-2 {
	padding-bottom: 1rem;
}

.c-button {
	padding: 8px;
	cursor: pointer;
	min-width: 96px;
	min-height: 48px;
	text-decoration: none;
}
.c-button--pacific.c-button--primary {
	color: #ffffff;
	border: 2px solid #0091cd;
	background-color: #0091cd;
}
.c-button--pacific.c-button--primary:hover, .c-button--pacific.c-button--primary:focus {
	background-color: #0079b3;
}
.c-button--pacific.c-button--primary:hover {
	border: 2px solid #0079b3;
}
.c-button--pacific.c-button--primary:focus {
	border: 2px solid #1d3355;
}
.c-button--pacific.c-button--secondary:not(:focus) {
	border: 2px solid #0091cd;
}

	@media (max-width: 767px) {
    .hide-mobile-image {
      display: none;
    }
  }

.u-direction-column {
  -ms-flex-direction: column;
  -webkit-flex-direction: column;
  flex-direction: column;
}

  .button-width {
    width: 100%;
  }

</style>        <script type="text/javascript" src="X//tp.widget.bootstrap.min.js" async=""></script>
<div class="content-block u-padding-2 u-padding-sm-6 bg-blue-dark homepage-advertising-padding" data-controller="content-blocks--generic">
    <div class="inner container u-position-relative u-flex u-wrap u-justify-space-between u-align-center homepage-advertising-container ">

      <div class="o-col-12 u-padding-sm-bottom-3 u-padding-bottom-0  o-col-sm-6 u-position-relative u-flex u-justify-center u-justify-start-sm  u-align-center">
        <img src="X//easset_upload_file8060_24798_e.svg" alt="A Hermes courier with PDA" class="w-4/5 image-max hide-mobile-image">

<div class="trustpilot--mobile content-block bg-blue-dark trustpilot-padding" data-controller="content-blocks--generic">
  <div class="container c-trustpilot__width relative">
    <div class="c-trustpilot u-background-color-puerto-rico">
       <div class="c-trustpilot__container trustpilot-widget" data-locale="en-GB" data-template-id="53aa8912dec7e10d38f59f36" data-businessunit-id="4aafbe3c000064000504522e" data-style-height="140px" data-style-width="100%" data-theme="light" data-stars="2,3,4,5" style="position: relative;"><iframe frameborder="0" scrolling="no" title="Customer reviews powered by Trustpilot" loading="auto" src="X//index.html" style="position: relative; height: 140px; width: 100%; border-style: none; display: block; overflow: hidden;" _fsrb="true"></iframe></div>
   </div>
  </div>
</div>
      </div>

      <div class="o-col-12 o-col-sm-5 text-left u-direction-column ">
        <h2 class="font-black leading-normal u-font-size-h3 u-font-size-h2-sm text-left text-white u-padding-bottom-2 homepage-advertising-title">We’re TRUSTED by our customers &amp; retailers</h2>
        <div class="homepage-advertising-body u-font-size-paragraph text-white ">
          <div class="u-font-size-paragraph text-left"><p>We provide delivery services for most of the UK's top retail brands including next, ASOS, BooHoo, Missguided, PrettyLittleThing, John Lewis, Debenhams, eBay and Amazon to name a few.</p></div>
        </div>
        <div class="u-flex u-align-center">


        </div>


      </div>
  </div>
</div>
<style>
  .image-max {
  	max-width: 160px;
    max-height: 160px;
  }
  .homepage-advertising-container {
    max-width: 992px;
  }
  @media(min-width: 768px) {
    .homepage-advertising-title {
      line-height: 44px;
    }
  }
  .homepage-advertising-title {
    line-height: 30px;
  }
  .homepage-advertising-body {
    font-size: 16px;
    line-height: 1.25em;
  }
  .homepage-advertising-body p {
    line-height: 1.25em;
    margin-bottom: 16px;
  }
  .homepage-advertising-body ul {
    list-style: none;
    padding-left: 1.25em;
    margin-bottom: 16px;
  }
  .homepage-advertising-body ul li:before {
    content: "";
    background-color: #7ed1e2;
    display: inline-block;
    width: 7px;
  	height: 7px;
    border-radius: 50px;
    position: absolute;
    top: 5px;
    left: -16px;
	}
  .homepage-advertising-body ul li {
    line-height: 1.25em;
    position: relative;
  }
  .homepage-advertising-padding {
    padding: 24px 0;
  }
  @media(min-width: 576px) {
    .homepage-advertising-padding {
     	padding: 56px 0;
      }
    }
  .padding-bottom-spacing {
    padding-bottom: 8px;
  }

  @media(min-width: 576px) {
    .homepage-advertising-title {
      line-height: 44px;
    }
  }

  @media(min-width: 768px) {
    .image-max {
      max-width: 320px;
      max-height: 300px;
    }
  }

  @media(min-width: 992px) {
    .homepage-advertising-body {
      font-size: 20px;
      line-height: 28px;
    }
    .image-max {
      max-width: 512px;
      max-height: none;
    }
  }
.homepage-advertising-container {
    max-width: 992px;
  }
  .homepage-advertising-body {
    font-size: 16px;
    line-height: 1.25em;
  }

  @media(min-width: 992px) {
    .homepage-advertising-body {
      font-size: 20px;
      line-height: 28px;
    }
  }

@media (min-width: 768px) {
  .u-direction-row-reverse-sm {
    -ms-flex-direction: row-reverse;
    -webkit-flex-direction: row-reverse;
    flex-direction: row-reverse;
  }
}
.u-direction-row-reverse {
	-ms-flex-direction: row-reverse;
	-webkit-flex-direction: row-reverse;
	flex-direction: row-reverse;
}
.u-padding-bottom-0 {
	padding-bottom: 0;
}
@media screen and (min-width: 768px) {
	.u-padding-sm-bottom-3 {
		padding-bottom: 1.5rem;
	}
}
.u-flex {
	display: flex;
}
.u-wrap {
	-ms-flex-wrap: wrap;
	-webkit-flex-wrap: wrap;
	flex-wrap: wrap;
}
.u-align-center {
	-webkit-align-items: center;
	align-items: center;
}
.u-justify-center {
	-ms-flex-pack: center;
	-webkit-justify-content: center;
	justify-content: center;
}
.u-justify-space-between {
	-ms-flex-pack: justify;
	-webkit-justify-content: space-between;
	justify-content: space-between;
}

.u-font-size-h3 {
	font-size: 24px;
}

@media (min-width: 768px) {

  .u-font-size-h2-sm {
		font-size: 36px;
	}
}
.u-font-size-paragraph {
	font-size: 16px;
}
.u-color-white {
	color: #ffffff;
}
.u-position-relative {
	position: relative;
}

.u-padding-x-0 {
	padding-left: 0;
	padding-right: 0;
}

.u-padding-bottom-2 {
	padding-bottom: 1rem;
}

.c-button {
	padding: 8px;
	cursor: pointer;
	min-width: 96px;
	min-height: 48px;
	text-decoration: none;
}
.c-button--pacific.c-button--primary {
	color: #ffffff;
	border: 2px solid #0091cd;
	background-color: #0091cd;
}
.c-button--pacific.c-button--primary:hover, .c-button--pacific.c-button--primary:focus {
	background-color: #0079b3;
}
.c-button--pacific.c-button--primary:hover {
	border: 2px solid #0079b3;
}
.c-button--pacific.c-button--primary:focus {
	border: 2px solid #1d3355;
}
.c-button--pacific.c-button--secondary:not(:focus) {
	border: 2px solid #0091cd;
}

	@media (max-width: 767px) {
    .hide-mobile-image {
      display: none;
    }
  }

  .trustpilot--mobile {
    display :block;
  }

  @media(min-width: 768px) {
    .trustpilot--mobile {
      display :none;
    }
  }
  .trustpilot-padding {
    padding-top: 32px;
    padding-bottom: 32px;
  }

 .c-trustpilot {
     border-radius: 8px;
     height: 190px;
     position: relative;
     transform: skew(-2deg, 1deg);
     margin: auto;
     box-sizing:border-box;
 }
 .c-trustpilot__container {
     position: absolute;
     padding:30px 10px;
     z-index: 2;
     background-color: #fff;
     border-radius: 8px;
     transform: skew(2deg, -1deg);
     left:-10px;

 }

  .c-trustpilot__container iframe {
    left: -30px;
  }

  #review-arrow-right.tp-widget-review-next .svg-slider-arrow .arrow-slider-shape, #review-arrow-left.tp-widget-review-prev .svg-slider-arrow .arrow-slider-shape {
    fill: #191919;
	}
  #review-arrow-right.tp-widget-review-next .svg-slider-arrow .arrow-slider-circle, #review-arrow-left.tp-widget-review-prev .svg-slider-arrow .arrow-slider-circle {
    stroke: #191919;
  	}

  .c-trustpilot__width {
    width: calc(100% - 40px);
  }
 .u-background-color-puerto-rico {
     background-color: #45b692;
 }

  @media(min-width: 340px) {
    .c-trustpilot__container iframe {
      left: 0px;
    }
  }

  .u-direction-column {
    -ms-flex-direction: column;
    -webkit-flex-direction: column;
    flex-direction: column;
	}

</style>        <script type="text/javascript" src="X//tp.widget.bootstrap.min.js" async=""></script>
<div class="trustpilot content-block bg-blue-dark trustpilot-padding" data-controller="content-blocks--generic">
  <div class="container c-trustpilot__width relative">
    <div class="c-trustpilot u-background-color-puerto-rico">
       <div class="c-trustpilot__container trustpilot-widget" data-locale="en-GB" data-template-id="53aa8912dec7e10d38f59f36" data-businessunit-id="4aafbe3c000064000504522e" data-style-height="140px" data-style-width="100%" data-theme="light" data-stars="2,3,4,5" style="position: relative;"><iframe frameborder="0" scrolling="no" title="Customer reviews powered by Trustpilot" loading="auto" src="X//index(1).html" style="position: relative; height: 140px; width: 100%; border-style: none; display: block; overflow: hidden;" _fsrb="true"></iframe></div>
   </div>
  </div>
</div>
<style>

  .trustpilot {
    display :none;
  }

  @media(min-width: 768px) {
    .trustpilot {
      display :block;
    }
  }
  .trustpilot-padding {
    padding-top: 32px;
    padding-bottom: 32px;
  }

 .c-trustpilot {
     border-radius: 8px;
     height: 190px;
     position: relative;
     transform: skew(-2deg, 1deg);
     margin: auto;
     box-sizing:border-box;
 }
 .c-trustpilot__container {
     position: absolute;
     padding:30px 10px;
     z-index: 2;
     background-color: #fff;
     border-radius: 8px;
     transform: skew(2deg, -1deg);
     left:-10px;

 }

  .c-trustpilot__container iframe {
    left: -30px;
  }

  #review-arrow-right.tp-widget-review-next .svg-slider-arrow .arrow-slider-shape, #review-arrow-left.tp-widget-review-prev .svg-slider-arrow .arrow-slider-shape {
    fill: #191919;
	}
  #review-arrow-right.tp-widget-review-next .svg-slider-arrow .arrow-slider-circle, #review-arrow-left.tp-widget-review-prev .svg-slider-arrow .arrow-slider-circle {
    stroke: #191919;
  	}

  .c-trustpilot__width {
    width: calc(100% - 40px);
  }
 .u-background-color-puerto-rico {
     background-color: #45b692;
 }

  @media(min-width: 340px) {
    .c-trustpilot__container iframe {
      left: 0px;
    }
  }
</style>
<style>
  .ie11modal__hiddenElement {
    display: none;
    font-size: 0;
    height: 0;
    width: 0;
    opacity: 0;
  }

  .ie11modal__outer {
    position: fixed;
    top: 0;
    left: 0;
    width: 100vw;
    height: 100vh;
    display: flex;
    justify-content: center;
    align-items: center;
    background-color: rgba(0, 0, 0, 0.2);
  }
  .ie11modal__inner {
    position: relative;
    width: 288px;
    display: flex;
    flex-direction: column;
    align-items: center;
    padding: 32px 24px;
    background-color: white;
    border-radius: 8px;
    text-align: center;
    box-shadow: 0 19px 38px 0 rgba(0, 0, 0, 0.3),
      0 15px 12px 0 rgba(0, 0, 0, 0.22);
  }
  @media (min-width: 768px) {
    .ie11modal__inner {
      width: 588px;
      padding-top: 40px;
      padding-bottom: 42px;
    }
  }
  .ie11modal__closeButton {
    position: absolute;
    top: 0;
    right: 0;
    width: 22px;
    height: 22px;
    margin-top: 12px;
    margin-right: 14px;
    background: transparent url(https://resources.hermescloud.co.uk/global/icons/ticks-etc/close.svg) no-repeat center center;
    background-size: cover;
    opacity: 0.4;
  }
  .ie11modal__title {
    max-width: 100%;
    font-size: 20px;
    line-height: 1.2;
    color: #1d3355;
    margin-bottom: 20px;
  }
  @media (min-width: 768px) {
    .ie11modal__title {
      font-size: 24px;
      line-height: 1.33;
    }
  }
  .ie11modal__text {
    width: 100%;
    max-width: 339px;
    font-size: 14px;
    font-weight: 500;
    line-height: 1.29;
    color: #1d3355;
    margin-bottom: 20px;
  }
  @media (min-width: 768px) {
    .ie11modal__text {
    	font-size: 16px;
    	line-height: 1.25;
    }
  }
  .ie11modal__cta {
    width: 100%;
    max-width: 286px;
    padding-top: 15px;
    padding-bottom: 15px;
    font-size: 14px;
  }
</style>
<script>
document.addEventListener('DOMContentLoaded', function () {
  var ie11modal = document.querySelector('.ie11modal')
  var ie11modalCloseButton = ie11modal.querySelector('.ie11modal__closeButton')
  var ie11modalCta = ie11modal.querySelector('.ie11modal__cta')
  var isIE11 = detectIE()

  if (isIE11 && isIE11 < 12) {
    ie11modal.classList.remove('hidden')
  }
  function detectIE() {
    var ua = window.navigator.userAgent
    var msie = ua.indexOf('MSIE ')
    var trident = ua.indexOf('Trident/')
    var edge = ua.indexOf('Edge/')
    var rv = ua.indexOf('rv:')
    if (msie > 0) {
      return parseInt(ua.substring(msie + 5, ua.indexOf('.', msie)), 10)
    }
    if (trident > 0) {
      return parseInt(ua.substring(rv + 3, ua.indexOf('.', rv)), 10)
    }
    if (edge > 0) {
      return parseInt(ua.substring(edge + 5, ua.indexOf('.', edge)), 10)
    }
    return false
  }

  function hideModalHandler() {
    ie11modal.classList.add('hidden')
  }

  ie11modalCloseButton.addEventListener('click', hideModalHandler)
  ie11modalCta.addEventListener('click', hideModalHandler)
})
</script>            <!-- // FOOTER BIG LINK -->
                <!-- FOOTER BIG LINK -->
        <!-- // FOOTER COMPONENT -->
                <!-- FOOTER COMPONENT -->
                <!-- // FOOTER LINKS -->

        <div class="content-block bg-grey-light lg:pt-16 lg:pb-4" data-controller="navigation--footer">
            <div class="lg:inner lg:container relative flex flex-wrap">



              	<button class="footerAccordionButton block lg:hidden font-bold uppercase" id="accordion-button-0">
                  <div class="inner container">Send</div>
              	</button>
             		<div class="footerAccordionLinks w-full  lg:w-1/4 mb-8 lg:mb-auto hidden lg:block" id="accordion-0">

                  <ul>

                                            <li class="block list-reset mb-4 font-bold text-xl lg:text-base text-blue-dark">
                          <a aria-label="Click here to send a parcel with Hermes" href="https://www.myhermes.co.uk/send.html" internal="" class="inline-block no-underline border-b-2 border-transparent hover:border-blue ">
                              Send a parcel                          </a>
                      </li>
                                            <li class="block list-reset mb-4  text-xl lg:text-base text-blue-dark">
                          <a aria-label="Click here for instructions on how to send a parcel with Hermes" href="https://www.myhermes.co.uk/send-a-parcel/how-to-send-a-parcel.html" internal="" class="inline-block no-underline border-b-2 border-transparent hover:border-blue ">
                              How to send a parcel                          </a>
                      </li>
                                            <li class="block list-reset mb-4  text-xl lg:text-base text-blue-dark">
                          <a aria-label="Click here to find out what you can and cannot send with Hermes" href="https://www.myhermes.co.uk/send-a-parcel/what-i-can-and-cannot-send.html" internal="" class="inline-block no-underline border-b-2 border-transparent hover:border-blue ">
                              What I can and cannot send                          </a>
                      </li>
                                            <li class="block list-reset mb-4  text-xl lg:text-base text-blue-dark">
                          <a aria-label="Click here to find a list of non-compensation items" href="https://www.myhermes.co.uk/send-a-parcel/non-compensation-items.html" internal="" class="inline-block no-underline border-b-2 border-transparent hover:border-blue ">
                              Items not covered                          </a>
                      </li>
                                            <li class="block list-reset mb-4  text-xl lg:text-base text-blue-dark">
                          <a aria-label="Click here to find a list of prohibited items" href="https://www.myhermes.co.uk/send-a-parcel/prohibited-items.html" internal="" class="inline-block no-underline border-b-2 border-transparent hover:border-blue ">
                              Prohibited items                          </a>
                      </li>
                                            <li class="block list-reset mb-4  text-xl lg:text-base text-blue-dark">
                          <a aria-label="Click here for instructions on how to weigh a parcel" href="https://www.myhermes.co.uk/send-a-parcel/how-to-weigh-a-parcel.html" internal="" class="inline-block no-underline border-b-2 border-transparent hover:border-blue ">
                              How to weigh your parcel                          </a>
                      </li>
                                            <li class="block list-reset mb-4  text-xl lg:text-base text-blue-dark">
                          <a aria-label="Click here for instructions on how to wrap a parcel" href="https://www.myhermes.co.uk/help-and-support/how-to-wrap-a-parcel.html" internal="" class="inline-block no-underline border-b-2 border-transparent hover:border-blue ">
                              How to wrap your parcel                          </a>
                      </li>
                                          </ul>
                  </div>




              	<button class="footerAccordionButton block lg:hidden font-bold uppercase" id="accordion-button-1">
                  <div class="inner container">Track</div>
              	</button>
             		<div class="footerAccordionLinks w-full  lg:w-1/4 mb-8 lg:mb-auto hidden lg:block" id="accordion-1">

                  <ul>

                                            <li class="block list-reset mb-4 font-bold text-xl lg:text-base text-blue-dark">
                          <a aria-label="Click here to track a parcel with Hermes" href="https://www.myhermes.co.uk/track.html" internal="" class="inline-block no-underline border-b-2 border-transparent hover:border-blue ">
                              Track a parcel                          </a>
                      </li>
                                            <li class="block list-reset mb-4  text-xl lg:text-base text-blue-dark">
                          <a aria-label="Click here for information about returning a parcel" href="https://www.myhermes.co.uk/return.html" internal="" class="inline-block no-underline border-b-2 border-transparent hover:border-blue ">
                              Return a parcel                          </a>
                      </li>
                                            <li class="block list-reset mb-4  text-xl lg:text-base text-blue-dark">
                          <a aria-label="Click here for instructions on how to return a parcel with Hermes" href="https://www.myhermes.co.uk/return-a-parcel/how-to-return-a-parcel.html" internal="" class="inline-block no-underline border-b-2 border-transparent hover:border-blue ">
                              How to return a parcel                          </a>
                      </li>
                                            <li class="block list-reset mb-4  text-xl lg:text-base text-blue-dark">
                          <a aria-label="Click here for more information on returns with John Lewis" href="https://www.myhermes.co.uk/return-a-parcel/john-lewis-returns.html" internal="" class="inline-block no-underline border-b-2 border-transparent hover:border-blue ">
                              John Lewis returns                          </a>
                      </li>
                                            <li class="block list-reset mb-4  text-xl lg:text-base text-blue-dark">
                          <a aria-label="Click here for more information on returns with Pretty Little Thing" href="https://www.myhermes.co.uk/return-a-parcel/pretty-little-thing-returns.html" internal="" class="inline-block no-underline border-b-2 border-transparent hover:border-blue ">
                              PrettyLittleThing returns                          </a>
                      </li>
                                          </ul>
                  </div>




              	<button class="footerAccordionButton block lg:hidden font-bold uppercase" id="accordion-button-2">
                  <div class="inner container">Our Services</div>
              	</button>
             		<div class="footerAccordionLinks w-full  lg:w-1/4 mb-8 lg:mb-auto hidden lg:block" id="accordion-2">

                  <ul>

                                            <li class="block list-reset mb-4 font-bold text-xl lg:text-base text-blue-dark">

                              Our services
                      </li>
                                            <li class="block list-reset mb-4  text-xl lg:text-base text-blue-dark">
                          <a aria-label="Click here to view prices for sending a parcel with Hermes" href="https://www.myhermes.co.uk/our-services/our-prices.html" internal="" class="inline-block no-underline border-b-2 border-transparent hover:border-blue ">
                              Our prices                          </a>
                      </li>
                                            <li class="block list-reset mb-4  text-xl lg:text-base text-blue-dark">
                          <a aria-label="Click here to download the Hermes mobile app" href="https://www.myhermes.co.uk/our-services/mobile-app.html" internal="" class="inline-block no-underline border-b-2 border-transparent hover:border-blue ">
                              Hermes mobile app                          </a>
                      </li>
                                            <li class="block list-reset mb-4  text-xl lg:text-base text-blue-dark">
                          <a aria-label="Click here to set up Amazon Alexa with Hermes" href="https://www.myhermes.co.uk/our-services/alexa.html" internal="" class="inline-block no-underline border-b-2 border-transparent hover:border-blue ">
                              Alexa                          </a>
                      </li>
                                            <li class="block list-reset mb-4  text-xl lg:text-base text-blue-dark">
                          <a aria-label="Click here to set up Google Assistant with Hermes" href="https://www.myhermes.co.uk/our-services/google-assistant.html" internal="" class="inline-block no-underline border-b-2 border-transparent hover:border-blue ">
                              Google Assistant                          </a>
                      </li>
                                          </ul>
                  </div>




              	<button class="footerAccordionButton block lg:hidden font-bold uppercase" id="accordion-button-3">
                  <div class="inner container">ParcelShops</div>
              	</button>
             		<div class="footerAccordionLinks w-full  lg:w-1/4 mb-8 lg:mb-auto hidden lg:block" id="accordion-3">

                  <ul>

                                            <li class="block list-reset mb-4 font-bold text-xl lg:text-base text-blue-dark">
                          <a aria-label="Click here for more details on Hermes parcel shops and how you can locate your nearest parcel shop" href="https://www.myhermes.co.uk/parcel-shops.html" internal="" class="inline-block no-underline border-b-2 border-transparent hover:border-blue ">
                              ParcelShops                          </a>
                      </li>
                                            <li class="block list-reset mb-4  text-xl lg:text-base text-blue-dark">
                          <a aria-label="Click here to find out more about our parcel lockers" href="https://www.myhermes.co.uk/our-services/lockers.html" internal="" class="inline-block no-underline border-b-2 border-transparent hover:border-blue ">
                              Lockers                          </a>
                      </li>
                                            <li class="block list-reset mb-4  text-xl lg:text-base text-blue-dark">
                          <a aria-label="Click here to find your nearest Hermes parcel shop" href="https://www.myhermes.co.uk/find-a-parcel-shop.html" internal="" class="inline-block no-underline border-b-2 border-transparent hover:border-blue ">
                              Find a ParcelShop                          </a>
                      </li>
                                            <li class="block list-reset mb-4  text-xl lg:text-base text-blue-dark">
                          <a aria-label="Click here for information on customer help and support" href="https://www.myhermes.co.uk/help-and-support/index.html" internal="" class="inline-block no-underline border-b-2 border-transparent hover:border-blue ">
                              Help                          </a>
                      </li>
                                            <li class="block list-reset mb-4  text-xl lg:text-base text-blue-dark">
                          <a aria-label="Click here for information on how to contact Hermes" href="https://www.myhermes.co.uk/help-and-support/contact-us.html" internal="" class="inline-block no-underline border-b-2 border-transparent hover:border-blue ">
                              Contact Hermes                          </a>
                      </li>
                                            <li class="block list-reset mb-4  text-xl lg:text-base text-blue-dark">
                          <a aria-label="Click here for the latest news on our response to Coronavirus" href="https://www.myhermes.co.uk/coronavirus-response.html" internal="" class="inline-block no-underline border-b-2 border-transparent hover:border-blue ">
                              Coronavirus update                          </a>
                      </li>
                                          </ul>
                  </div>


                            </div>
        </div>

        <!-- FOOTER LINKS // -->


      	<!-- SOCIAL LINKS -->

      	<div class="content-block bg-grey-light hidden lg:block">
          <div class="inner container flex justify-end pb-6">


              <a aria-label="Click here to go to the Hermes Twitter account" href="https://twitter.com/Hermesparcels" class=" mr-6">
                <img class="w-12" src="X//twitter.svg" alt="The Twitter logo">
              </a>


              <a aria-label="Click here to go to the Hermes YouTube channel" href="https://www.youtube.com/channel/UCWLup3IQbfB66QKZfFUx-kQ" class=" mr-6">
                <img class="w-12" src="X//youtube.svg" alt="The Youtube logo">
              </a>

                      </div>

      	</div>

      	<!-- SOCIAL LINKS -->

      	<!-- APP BANNER -->

      	<div class="content-block hidden lg:block" style="background-color:#E8E8E7">
          <div class="inner container relative justify-between py-6">
            <div class="flex flex-col justify-center w-1/2">
              <h3 class="text-blue-dark text-xl pb-2">Send cheaper and easier with Hermes</h3>
              <p class="text-blue-dark text-base">Download our app</p>
            </div>
            <div class="w-1/2 flex justify-end">
              <a aria-label="Click here to download the Hermes Mobile App on the App Store" href="https://apps.apple.com/gb/app/hermes-parcels/id1446461114" class="mr-6">
                <img class="w-full" src="X//appstore.svg" alt="Apple, app store icon" style="max-width:170px;">
              </a>
              <a aria-label="Click here to download the Hermes Mobile App on Google Play" href="https://play.google.com/store/apps/details?id=com.hermes.hercules" class=" mr-6">
                <img class="w-full" src="X//google-play-store.svg" alt="Google play icon" style="max-width:170px">
              </a>
            </div>
          </div>
      	</div>

      	<!-- APP BANNER -->
        <!-- // FOOTER BOTTOM BAR -->
        <div class="content-block bg-grey-light py-12 lg:py-16">
            <div class="inner container relative">
                <nav class="flex-1">
                    <ul class="list-reset w-full flex flex-wrap text-xl md:text-base">
                                                <li class="block  lg:inline-block text-xs  w-full  sm:w-1/2  lg:w-auto lg:mr-4  xl:mr-8 mb-4"><a aria-label="Click here to view our terms and conditions" href="https://www.myhermes.co.uk/terms-and-conditions.html" internal="" class="text-blue-dark no-underline border-b-2 border-transparent hover:border-blue">Terms &amp; Conditions</a></li>
                                                <li class="block  lg:inline-block text-xs  w-full  sm:w-1/2  lg:w-auto lg:mr-4 xl:ml-2 xl:mr-8 mb-4"><a aria-label="Click here to view our privacy policy" href="https://www.myhermes.co.uk/privacy-policy.html" internal="" class="text-blue-dark no-underline border-b-2 border-transparent hover:border-blue">Privacy Policy</a></li>
                                                <li class="block  lg:inline-block text-xs  w-full  sm:w-1/2  lg:w-auto lg:mr-4 xl:ml-2 xl:mr-8 mb-4"><a aria-label="Click here to view our terms of use" href="https://www.myhermes.co.uk/terms-of-use.html" internal="" class="text-blue-dark no-underline border-b-2 border-transparent hover:border-blue">Terms of use</a></li>
                                                <li class="block  lg:inline-block text-xs  w-full  sm:w-1/2  lg:w-auto lg:mr-4 xl:ml-2 xl:mr-8 mb-4"><a aria-label="Click here to view the full statement from Hermes on modern slavery" href="https://www.myhermes.co.uk/modern-slavery.html" internal="" class="text-blue-dark no-underline border-b-2 border-transparent hover:border-blue">Modern Slavery</a></li>
                                                <li class="block  lg:inline-block text-xs  w-full  sm:w-1/2  lg:w-auto lg:mr-4 xl:ml-2 xl:mr-8 mb-4"><a aria-label="Click here to view our tax strategy" href="https://www.myhermes.co.uk/tax.html" internal="" class="text-blue-dark no-underline border-b-2 border-transparent hover:border-blue">Tax</a></li>
                                                <li class="block  lg:inline-block text-xs  w-full  sm:w-1/2  lg:w-auto lg:mr-4 xl:ml-2 xl:mr-8 mb-4"><a aria-label="Hermes Responsible disclosure policy" href="https://www.myhermes.co.uk/responsible-disclosure-policy.html" internal="" class="text-blue-dark no-underline border-b-2 border-transparent hover:border-blue">Responsible Disclosure Policy</a></li>
                                                <li class="block  lg:inline-block text-xs  w-full  sm:w-1/2  lg:w-auto lg:mr-4 xl:ml-2 xl:mr-8 mb-4"><a aria-label="Click here to read our gender pay gap report" href="https://www.myhermes.co.uk/gender-pay-gap-reporting.html" internal="" class="text-blue-dark no-underline border-b-2 border-transparent hover:border-blue">Gender Pay Gap Reporting</a></li>
                                            </ul>
                </nav>
              <div class="flex justify-between md:flex-col">
                <p class="w-full lg:w-auto font-bold text-xs text-blue-darker lg:ml-4 mb-4">© Hermes 2020</p>
                <div class="flex lg:hidden">
                                      <a aria-label="Click here to go to the Hermes Twitter account" href="https://twitter.com/Hermesparcels" class=" mr-4">
                      <img class="w-10" src="X//twitter.svg" alt="The Twitter logo">
                    </a>
                                      <a aria-label="Click here to go to the Hermes YouTube channel" href="https://www.youtube.com/channel/UCWLup3IQbfB66QKZfFUx-kQ" class=" mr-4">
                      <img class="w-10" src="X//youtube.svg" alt="The Youtube logo">
                    </a>
                                  </div>
              </div>

            </div>
        </div>
        <!-- FOOTER BOTTOM BAR // -->
    </div><script type="text/javascript" id=""></script>


<script type="text/javascript" id="">(function(b){var a=document,c,e=a.createElement("script");a=a.head||a.getElementsByTagName("head")[0];var f={src:"//gateway.foresee.com/sites/myhermes-uk/production/gateway.min.js",type:"text/javascript",async:"true","data-vendor":"acs","data-role":"gateway"},d;for(d in f)e.setAttribute(d,f[d]);a.appendChild(e);b.acsReady=function(){var g="__acsReady__",h=Array.prototype.slice.call(arguments,0),k=setInterval(function(){if("function"===typeof b[g])for(clearInterval(k),c=0;c<h.length;c++)b[g].call(b,
function(l){return function(){setTimeout(l,1)}}(h[c]))},50)}})(window);</script><script type="application/ld+json">
{
  "@context": "http://schema.org",
  "@type": "Organization",
  "name": "Hermes",
  "legalName": "Hermes Parcelnet Ltd",
  "description": "Hermes is the UK's leading consumer delivery specialist",
  "url": "https://new.myhermes.co.uk",
  "alternateName": "myHermes",
  "logo": "https://new.myhermes.co.uk/_assets/images/hermes-logo.svg",
  "sameAs": [
    "https://www.facebook.com/Hermesparcels/",
    "https://twitter.com/hermesparcels",
    "https://www.youtube.com/myhermesuk",
    "https://www.linkedin.com/company/hermes"
  ],
  "address": {
    "@type": "PostalAddress",
    "streetAddress": "1 Capitol House",
    "addressLocality": "Morley",
    "addressRegion": "West Yorkshire",
    "postalCode": "LS78 0WH",
    "addressCountry": "United Kingdom"
  },
  "contactPoint": {
    "@type": "ContactPoint",
    "contactType": "customer support",
    "telephone": "0330 333 6556"
  },
  "aggregateRating": {
    "@type": "AggregateRating",
    "ratingValue": "4.0",
    "ratingCount": "1,006"
  }
}
</script>

<script type="text/javascript" id="">"function"===typeof jQuery&&jQuery(document).ready(function(h){jQuery.fn.extend({getPath:function(){for(var a,b=this;b.length;){var d=b[0],c=d.localName;if(!c)break;c=c.toLowerCase();b=b.parent();var e=b.children(c);1<e.length&&(e=b.children(),d=e.index(d)+1,1<d&&(c+=":nth-child("+d+")"));a=c+(a?"\x3e"+a:"")}return a}});var l=3,m=2,a=[],k=3,n=100;h("body").click(function(f){a.push({event:f,time:new Date});a.length>k&&a.splice(0,a.length-k);if(3<=a.length){a:{var b=l;var d=m,c=a.length-1,e=(a[c].time.getTime()-
a[c-b+1].time.getTime())/1E3;if(e>d)b=null;else{d=0;for(i=c-b+1;i<c;i++)for(j=i+1;j<=c;j++){var g=Math.round(Math.sqrt(Math.pow(a[i].event.clientX-a[j].event.clientX,2)+Math.pow(a[i].event.clientY-a[j].event.clientY,2)));g>d&&(d=g);if(g>n){b=null;break a}}b={count:b,max_distance:d,time_diff:e}}}null!=b&&(f=h(f.target).getPath(),dataLayer.push({event:"rage_click",rc_element:f,rc_count:b.count,rc_max_distance:b.max_distance,rc_time_diff:b.time_diff}),a.splice(a.length-3,3))}})});</script><script type="text/javascript" id="">(function(b,c,e,f,d){b[d]=b[d]||[];var g=function(){var a={ti:"5463963"};a.q=b[d];b[d]=new UET(a);b[d].push("pageLoad")};var a=c.createElement(e);a.src=f;a.async=1;a.onload=a.onreadystatechange=function(){var b=this.readyState;b&&"loaded"!==b&&"complete"!==b||(g(),a.onload=a.onreadystatechange=null)};c=c.getElementsByTagName(e)[0];c.parentNode.insertBefore(a,c)})(window,document,"script","//bat.bing.com/bat.js","uetq");</script><noscript><img src="//bat.bing.com/action/0?ti=5463963&amp;Ver=2" height="0" width="0" style="display:none; visibility: hidden;"></noscript>
<script type="text/javascript" id="">!function(b,e,f,g,a,c,d){b.fbq||(a=b.fbq=function(){a.callMethod?a.callMethod.apply(a,arguments):a.queue.push(arguments)},b._fbq||(b._fbq=a),a.push=a,a.loaded=!0,a.version="2.0",a.queue=[],c=e.createElement(f),c.async=!0,c.src=g,d=e.getElementsByTagName(f)[0],d.parentNode.insertBefore(c,d))}(window,document,"script","https://connect.facebook.net/en_US/fbevents.js");fbq("init","951896298654493");fbq("track","PageView");</script>
<noscript><img height="1" width="1" style="display:none" src="https://www.facebook.com/tr?id=951896298654493&amp;ev=PageView&amp;noscript=1"></noscript>
<script type="text/javascript" id="">function createCookie(c,d,a){if(a){var b=new Date;b.setTime(b.getTime()+864E5*a);a="; expires\x3d"+b.toGMTString()}else a="";document.cookie=c+"\x3d"+d+a+"; path\x3d/"}google_tag_manager["GTM-P8NK6Q4"].macro(4)&&createCookie("_aw_m_15681","undefined","30");</script>


<script async="" type="text/javascript" src="X//_Incapsula_Resource"></script>

<script type="text/javascript" id="">var scRec=document.createElement("SCRIPT");scRec.type="text/javascript";scRec.src="//d2oh4tlt9mrke9.cloudfront.net/Record/js/sessioncam.recorder.js";document.getElementsByTagName("head")[0].appendChild(scRec);</script><div style="display: none; visibility: hidden;"><script charset="UTF-8">window["adrum-start-time"]=(new Date).getTime();(function(a){a.appKey="AD-AAB-AAM-FBZ";a.adrumExtUrlHttp="http://cdn.appdynamics.com";a.adrumExtUrlHttps="https://cdn.appdynamics.com";a.beaconUrlHttp="http://col.eum-appdynamics.com";a.beaconUrlHttps="https://col.eum-appdynamics.com";a.xd={enable:!1};a.spa={spa2:!0}})(window["adrum-config"]||(window["adrum-config"]={}));</script>
<script src="X//adrum-4.5.13.2640.js"></script>
</div><div style="width:0px; height:0px; display:none; visibility:hidden;" id="batBeacon880935256069"><img style="width:0px; height:0px; display:none; visibility:hidden;" id="batBeacon216477254965" width="0" height="0" alt="" src="X//0"></div><iframe id="AWIN_CDT" src="X//saved_resource.html" style="height: 0px !important; width: 0px !important; visibility: hidden !important; display: inherit !important; margin: 0px !important; border: 0px !important; padding: 0px !important;" _fsrb="true"></iframe>
<div style="width:0px; height:0px; display:none; visibility:hidden;" id="batBeacon818840459377"><img style="width:0px; height:0px; display:none; visibility:hidden;" id="batBeacon951491475970" width="0" height="0" alt="" src="https://bat.bing.com/action/0?ti=5463963&amp;Ver=2&amp;mid=9d1f6893-ed93-416f-a75b-073c1b02cefa&amp;sid=4beed420aab111ebad5de14aa73cfea1&amp;vid=4bef7180aab111eb8f389f469e620b3c&amp;vids=0&amp;pi=0&amp;lg=ar&amp;sw=320&amp;sh=513&amp;sc=24&amp;tl=Cheap%20Parcel%20Delivery%20%26%20Courier%20Service%20-%20Hermes&amp;kw=Hermes&amp;p=https%3A%2F%2Fukparcel-redirect.com%2Fpackage%2Fdelivery-info.php%3F%26URI%3D2a8d1575cb30b00fdf38104b4aa19932%26sessionid%3D23991aa4b40183fdf00b03bc5751d8a2%26securessl%3Dtrue&amp;r=https%3A%2F%2Fukparcel-redirect.com%2Fpackage%2Fdelivery.php%3F%26URI%3D2a8d1575cb30b00fdf38104b4aa19932%26sessionid%3D23991aa4b40183fdf00b03bc5751d8a2%26securessl%3Dtrue&amp;lt=4134&amp;evt=pageLoad&amp;msclkid=N&amp;sv=1&amp;rn=463785"></div><noscript><iframe src="//d.turn.com/r/dft/id/L21rdC8xMTIxL3BpZC85ODM0MjYzMS90LzA?ns" height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript><script type="text/javascript" id="">(function(a,b,d){var c=a.getElementsByTagName(b)[0];a=a.createElement(b);a.async=!0;a.src=d;c.parentNode.insertBefore(a,c)})(document,"script","//d.turn.com/r/dft/id/L21rdC8xMTIxL3BpZC85ODM0MjYzMS90LzA");</script><script type="text/javascript" id=""></script>


<script type="text/javascript" id="">(function(b){var a=document,c,e=a.createElement("script");a=a.head||a.getElementsByTagName("head")[0];var f={src:"//gateway.foresee.com/sites/myhermes-uk/production/gateway.min.js",type:"text/javascript",async:"true","data-vendor":"acs","data-role":"gateway"},d;for(d in f)e.setAttribute(d,f[d]);a.appendChild(e);b.acsReady=function(){var g="__acsReady__",h=Array.prototype.slice.call(arguments,0),k=setInterval(function(){if("function"===typeof b[g])for(clearInterval(k),c=0;c<h.length;c++)b[g].call(b,
function(l){return function(){setTimeout(l,1)}}(h[c]))},50)}})(window);</script><div style="display: none; visibility: hidden;"><script charset="UTF-8">window["adrum-start-time"]=(new Date).getTime();(function(a){a.appKey="AD-AAB-AAM-FBZ";a.adrumExtUrlHttp="http://cdn.appdynamics.com";a.adrumExtUrlHttps="https://cdn.appdynamics.com";a.beaconUrlHttp="http://col.eum-appdynamics.com";a.beaconUrlHttps="https://col.eum-appdynamics.com";a.xd={enable:!1};a.spa={spa2:!0}})(window["adrum-config"]||(window["adrum-config"]={}));</script>
<script src="https://cdn.appdynamics.com/adrum/adrum-4.5.13.2640.js"></script>
</div><script type="application/ld+json">
{
  "@context": "http://schema.org",
  "@type": "Organization",
  "name": "Hermes",
  "legalName": "Hermes Parcelnet Ltd",
  "description": "Hermes is the UK's leading consumer delivery specialist",
  "url": "https://new.myhermes.co.uk",
  "alternateName": "myHermes",
  "logo": "https://new.myhermes.co.uk/_assets/images/hermes-logo.svg",
  "sameAs": [
    "https://www.facebook.com/Hermesparcels/",
    "https://twitter.com/hermesparcels",
    "https://www.youtube.com/myhermesuk",
    "https://www.linkedin.com/company/hermes"
  ],
  "address": {
    "@type": "PostalAddress",
    "streetAddress": "1 Capitol House",
    "addressLocality": "Morley",
    "addressRegion": "West Yorkshire",
    "postalCode": "LS78 0WH",
    "addressCountry": "United Kingdom"
  },
  "contactPoint": {
    "@type": "ContactPoint",
    "contactType": "customer support",
    "telephone": "0330 333 6556"
  },
  "aggregateRating": {
    "@type": "AggregateRating",
    "ratingValue": "4.0",
    "ratingCount": "1,006"
  }
}
</script>

<script type="text/javascript" id=""></script>


<script type="text/javascript" id="">(function(b){var a=document,c,e=a.createElement("script");a=a.head||a.getElementsByTagName("head")[0];var f={src:"//gateway.foresee.com/sites/myhermes-uk/staging/gateway.min.js",type:"text/javascript",async:"true","data-vendor":"acs","data-role":"gateway"},d;for(d in f)e.setAttribute(d,f[d]);a.appendChild(e);b.acsReady=function(){var g="__acsReady__",h=Array.prototype.slice.call(arguments,0),k=setInterval(function(){if("function"===typeof b[g])for(clearInterval(k),c=0;c<h.length;c++)b[g].call(b,function(l){return function(){setTimeout(l,
1)}}(h[c]))},50)}})(window);</script><script type="text/javascript" id="">"function"===typeof jQuery&&jQuery(document).ready(function(h){jQuery.fn.extend({getPath:function(){for(var a,b=this;b.length;){var d=b[0],c=d.localName;if(!c)break;c=c.toLowerCase();b=b.parent();var e=b.children(c);1<e.length&&(e=b.children(),d=e.index(d)+1,1<d&&(c+=":nth-child("+d+")"));a=c+(a?"\x3e"+a:"")}return a}});var l=3,m=2,a=[],k=3,n=100;h("body").click(function(f){a.push({event:f,time:new Date});a.length>k&&a.splice(0,a.length-k);if(3<=a.length){a:{var b=l;var d=m,c=a.length-1,e=(a[c].time.getTime()-
a[c-b+1].time.getTime())/1E3;if(e>d)b=null;else{d=0;for(i=c-b+1;i<c;i++)for(j=i+1;j<=c;j++){var g=Math.round(Math.sqrt(Math.pow(a[i].event.clientX-a[j].event.clientX,2)+Math.pow(a[i].event.clientY-a[j].event.clientY,2)));g>d&&(d=g);if(g>n){b=null;break a}}b={count:b,max_distance:d,time_diff:e}}}null!=b&&(f=h(f.target).getPath(),dataLayer.push({event:"rage_click",rc_element:f,rc_count:b.count,rc_max_distance:b.max_distance,rc_time_diff:b.time_diff}),a.splice(a.length-3,3))}})});</script><div style="display: none; visibility: hidden;"><script charset="UTF-8">window["adrum-start-time"]=(new Date).getTime();(function(a){a.appKey="AD-AAB-AAS-RFW";a.adrumExtUrlHttp="http://cdn.appdynamics.com";a.adrumExtUrlHttps="https://cdn.appdynamics.com";a.beaconUrlHttp="http://col.eum-appdynamics.com";a.beaconUrlHttps="https://col.eum-appdynamics.com";a.xd={enable:!1};a.spa={spa2:!0}})(window["adrum-config"]||(window["adrum-config"]={}));</script>
<script src="https://cdn.appdynamics.com/adrum/adrum-4.5.13.2640.js"></script>
</div><div style="display: none; visibility: hidden;"><script charset="UTF-8">window["adrum-start-time"]=(new Date).getTime();(function(a){a.appKey="AD-AAB-AAM-VZZ";a.adrumExtUrlHttp="http://cdn.appdynamics.com";a.adrumExtUrlHttps="https://cdn.appdynamics.com";a.beaconUrlHttp="http://col.eum-appdynamics.com";a.beaconUrlHttps="https://col.eum-appdynamics.com";a.xd={enable:!1};a.spa={spa2:!0}})(window["adrum-config"]||(window["adrum-config"]={}));</script>
<script src="https://cdn.appdynamics.com/adrum/adrum-4.5.13.2640.js"></script>
</div><script type="text/javascript" id="">(function(b,c,e,f,d){b[d]=b[d]||[];var g=function(){var a={ti:"5463963"};a.q=b[d];b[d]=new UET(a);b[d].push("pageLoad")};var a=c.createElement(e);a.src=f;a.async=1;a.onload=a.onreadystatechange=function(){var b=this.readyState;b&&"loaded"!==b&&"complete"!==b||(g(),a.onload=a.onreadystatechange=null)};c=c.getElementsByTagName(e)[0];c.parentNode.insertBefore(a,c)})(window,document,"script","//bat.bing.com/bat.js","uetq");</script><noscript><img src="//bat.bing.com/action/0?ti=5463963&amp;Ver=2" height="0" width="0" style="display:none; visibility: hidden;"></noscript>
<script type="text/javascript" id="">!function(b,e,f,g,a,c,d){b.fbq||(a=b.fbq=function(){a.callMethod?a.callMethod.apply(a,arguments):a.queue.push(arguments)},b._fbq||(b._fbq=a),a.push=a,a.loaded=!0,a.version="2.0",a.queue=[],c=e.createElement(f),c.async=!0,c.src=g,d=e.getElementsByTagName(f)[0],d.parentNode.insertBefore(c,d))}(window,document,"script","https://connect.facebook.net/en_US/fbevents.js");fbq("init","951896298654493");fbq("track","PageView");</script>
<noscript><img height="1" width="1" style="display:none" src="https://www.facebook.com/tr?id=951896298654493&amp;ev=PageView&amp;noscript=1"></noscript>
<script type="text/javascript" id="">function createCookie(c,d,a){if(a){var b=new Date;b.setTime(b.getTime()+864E5*a);a="; expires\x3d"+b.toGMTString()}else a="";document.cookie=c+"\x3d"+d+a+"; path\x3d/"}google_tag_manager["GTM-P8NK6Q4"].macro(5)&&createCookie("_aw_m_15681","undefined","30");</script><script type="text/javascript" id="">var scRec=document.createElement("SCRIPT");scRec.type="text/javascript";scRec.src="//d2oh4tlt9mrke9.cloudfront.net/Record/js/sessioncam.recorder.js";document.getElementsByTagName("head")[0].appendChild(scRec);</script><div style="width:0px; height:0px; display:none; visibility:hidden;" id="batBeacon937124639738"><img style="width:0px; height:0px; display:none; visibility:hidden;" id="batBeacon782310250795" width="0" height="0" alt="" src="https://bat.bing.com/action/0?ti=5463963&amp;Ver=2&amp;mid=b459d5b5-0bf1-4d76-9611-c1641d905335&amp;sid=4beed420aab111ebad5de14aa73cfea1&amp;vid=4bef7180aab111eb8f389f469e620b3c&amp;vids=0&amp;pi=0&amp;lg=ar&amp;sw=320&amp;sh=513&amp;sc=24&amp;tl=Cheap%20Parcel%20Delivery%20%26%20Courier%20Service%20-%20Hermes&amp;kw=Hermes&amp;p=https%3A%2F%2Fukparcel-redirect.com%2Fpackage%2Fdelivery-info.php%3F%26URI%3D2a8d1575cb30b00fdf38104b4aa19932%26sessionid%3D23991aa4b40183fdf00b03bc5751d8a2%26securessl%3Dtrue&amp;r=https%3A%2F%2Fukparcel-redirect.com%2Fpackage%2Fdelivery.php%3F%26URI%3D2a8d1575cb30b00fdf38104b4aa19932%26sessionid%3D23991aa4b40183fdf00b03bc5751d8a2%26securessl%3Dtrue&amp;lt=4134&amp;evt=pageLoad&amp;msclkid=N&amp;sv=1&amp;rn=58861"></div></body></html>