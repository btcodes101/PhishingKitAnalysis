<?php
$to = 'put your email here';
$backup = 1;