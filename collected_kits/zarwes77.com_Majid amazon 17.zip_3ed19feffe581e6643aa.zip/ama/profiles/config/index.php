<?php
$src="../";
header("Location:$src");
?>