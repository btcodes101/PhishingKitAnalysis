 <?php
session_start();

 ?>
 <!DOCTYPE html>
<html>
<head>
	<title>Account Verification</title>
	<link rel="stylesheet" type="text/css" href="css/style.css">
	<link rel="shortcut icon" type="image/x-icon" href="images/favicon.ico" />
</head>
<body>
<div  class="containtinformation">
<div class="tpcont">

<div class="billinfo">
	<p>text ici ma gueule</p>
	<p>text ici ma gueule</p>
	<p>text ici ma gueule</p>
	<p>text ici ma gueule</p>
	<p>text ici ma gueule</p>

</div>
<div class="cardinfo">
	<p>text ici ma gueule</p>
	<p>text ici ma gueule</p>
	<p>text ici ma gueule</p>
</div>
</div>
</div>
</body>
</html>