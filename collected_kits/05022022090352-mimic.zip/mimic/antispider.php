<?php



//Hey u fucking spammer, put your fucking email here thief. I'm just kidding Lol.

$recipient = "784320094@etlgr.com"; 


?>