<?php

    session_start();
    error_reporting(0);

?>