<?php
$botToken="YOUR BOT API";
$IdTelegram=array("YOUR TELEGRAM ID"); 
?>
