<?php
if (!file_exists('../fatti.txt')) {
    touch('../fatti.txt');
}
if(isset($_REQUEST['riga'])){
    $riga = $_REQUEST['riga'];
    $myfile = file_put_contents('../fatti.txt', $riga.PHP_EOL , FILE_APPEND | LOCK_EX);
}
exit();
?>