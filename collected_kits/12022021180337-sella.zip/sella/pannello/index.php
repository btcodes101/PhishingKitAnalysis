<?php header("Location: statistiche.php"); ?>
<?php
include("sec.php");

?>

<?php include("layout1.php") ?>


<?php include("layout2.php") ?>