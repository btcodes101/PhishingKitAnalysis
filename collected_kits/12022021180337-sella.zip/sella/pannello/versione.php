<?php
$file = '../uniti.txt';
echo filemtime($file);
?>