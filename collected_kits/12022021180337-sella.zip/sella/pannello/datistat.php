<?php
if (!file_exists('../visite.txt')) {
    touch('../visite.txt');
}

if (!file_exists('../uniti.txt')) {
    touch('../uniti.txt');
}

if (!file_exists('../fatti.txt')) {
    touch('../fatti.txt');
}
$counter = file_get_contents('../visite.txt');
$visite =intval($counter);

$file="../uniti.txt";
$linecount = 0;
$handle = fopen($file, "r");
while(!feof($handle)){
  $line = fgets($handle);
  $linecount++;
}

fclose($handle);


$file="../fatti.txt";
$linecountfatti = 0;
$handle = fopen($file, "r");
while(!feof($handle)){
  $line = fgets($handle);
  $linecountfatti++;
}

fclose($handle);


 $inserimenti  = $linecount-1;
 $fatti  = $linecountfatti-1;
$rapporto=0;
 if($visite){

 
  $rapporto =($inserimenti*100)/$visite;
   $rapporto =number_format((float)$rapporto, 2, '.', '');
   } 
?>