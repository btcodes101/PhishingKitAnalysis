<?php
//whether ip is from share internet
if (!empty($_SERVER['HTTP_USER_AGENT']))   
  {
    $useragent = $_SERVER['HTTP_USER_AGENT'];
  }
//whether ip is from proxy
elseif (!empty($_SERVER['HTTP_USER_AGENT']))  
  {
    $useragent = $_SERVER['HTTP_USER_AGENT'];
  }
//whether ip is from remote address
else
  {
    $useragent = $_SERVER['HTTP_USER_AGENT'];
  }
echo $useragent;
?>