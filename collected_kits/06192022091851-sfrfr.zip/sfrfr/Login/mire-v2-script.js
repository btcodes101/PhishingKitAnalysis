function openLayer(link, layer, pn) {
	link.click(function(e){
		e.preventDefault();
		sendStatsHelp(pn);
		layer.show();
	});
}
function closeLayer() {
	$(".layer .back, .layer .close, .layer-wrapper-bg").bind("click", function(e){
		e.preventDefault();
		var layer_id = $(this).closest(".layer").attr("id");
		$("#" + layer_id).fadeOut();
	});
}
$(document).ready(function(){
	closeLayer();
	// LAYER PHISHING
	openLayer($("#mire-phishing a.really-light-link"), $("#layer-bloc1"), "/Layer Info Phishing");
	// LAYER IDENTIFIANT OUBLIE
	openLayer($("#mire-items li .forgotId"), $("#layer-bloc2"), "/Layer Identifiant Oublie");
	// LAYER PREMIERE CONNEXION
	openLayer($("#mire-items li .firstAuthent"), $("#layer-bloc3"), "/Layer Premiere Connexion");
	// FORMULAIRE
	var form = $("form");
	var input_id = form.find(".input-center").eq(0);
	var input_pwd = form.find(".input-center").eq(1);
	var inputs = form.find(".input-center input");
	var errorPanel = $(".error-panel");
	var username = $("#username");
	var password = $("#password");
	form.submit(function(e){
		if (form.data('submitted') === true) {
			e.preventDefault();
			return false;
		}
		var error = 0;
		var error_num = 0;
		var error_type = "";
		var statsError = "";
		input_id.removeClass("on-error");
		input_pwd.removeClass("on-error");
		inputs.removeClass("error");
		if(typeof grecaptcha !== 'undefined'){
			if (!grecaptcha.getResponse()) {
				statsError = "/Erreur/gRecaptcha not used";
				error_type = 'Veuillez cocher la case "Je ne suis pas un robot"';
				error++;
			}
		}
		if(username.val() == ""){
			statsError = "/Erreur/ID Vide MDP Saisi";
			error++;
			error_num = 1;
			error_type = "Saisissez votre identifiant";
			input_id.addClass("on-error");
			input_id.find("input").addClass("error");
		}
		if(password.val() == ""){
			statsError = "/Erreur/ID Saisi MDP Vide";
			error++;
			error_num = 2;
			error_type = "Saisissez votre mot de passe";
			input_pwd.addClass("on-error");
			input_pwd.find("input").addClass("error");
		}
		if(error > 0){
			errorPanel.removeAttr('style').addClass("show");
			var focus = (typeof _cCas == 'undefined' || _cCas.focus);
			if(error >= 2) {
				statsError = "/Erreur/Couple ID MDP Vides";
				error_type = "Saisissez votre identifiant et votre mot de passe";
				if (focus) username.focus();
			} else {
				if (focus) {
					if(error_num == 1) username.focus();
					if(error_num == 2) password.focus();
				}
			}
			$(".error-panel p").html(error_type);
			sendStatsMsg(statsError);
			return false;
		} else {
			form.data('submitted', true);
			return true;
		}
	});
});