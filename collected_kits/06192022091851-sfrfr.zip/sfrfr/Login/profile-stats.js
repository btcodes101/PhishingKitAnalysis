!function(_,Z,v,D){if(_){
Z=window.zvars||[];Z["eVar4"]='';Z[5]='';Z[6]='';Z[8]='99';Z[10]='1';Z[13]='99';Z[14]='99';Z[18]='99';Z[19]='99';Z["eVar51"]='';Z["eVar52"]='';Z["eVar72"]='';zvars=Z



_.ckW('eTeCli=X',1)
}}(window._eT)
