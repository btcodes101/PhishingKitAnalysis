if(!window._eT)(function(_,W,D){
_.zf=_stats_zf=0
if(!W._eTag)_eTag=[]
var	L=W.location,h=L.host,n=h,N=W.navigator&&navigator.userAgent||'',RE='replace',TN='getElementsByTagName',NDI,
H=h[RE](/\.(casepp|ipp2)\.sfr\.fr/,'')[RE](/(^www|^cms|\.cms)?\.sfr\.fr/,'@')[RE](/(^www|^cms|)\.red-by-sfr\.fr/,'#')[RE](/(^cms\b\.?)/g,'')[RE](/^(valid.sfr-)?messagerie(.services|-beta(-2)?|-1.)?/,'WM')+L.pathname[RE](/(\/|;JSESS.*)$/,''),
$=_.$=W.$sfr&&$sfr.fn&&$sfr||W.$&&W.$.fn&&$||W.jQuery,
f0=function(){},
ckR=_.ckR=function(s){var c=" "+D.cookie+";",i=c.indexOf(" "+s+"=");return !s||i<0?"":unescape(c.substring(i+s.length+2,c.indexOf(";",i)))[RE](/<[^>]+>/g,'')},
ckW=_.ckW=function(s,h,H,d){
if(h){d=new Date;d.setMinutes(d.getMinutes()+h*60);s+="; expires="+d.toGMTString()}
D.cookie=s+(H?"; domain="+H:T('[^/]*@')?"; domain=sfr.fr":T('[^/]*#')?"; domain=red-by-sfr.fr":T('rmcsport.tv')?"; domain=rmcsport.tv":"")+"; path=/"},
ckD=_.ckD=function(s){ckW(s+"=",-1)},
ckT=_.ckT=function(c,v,m,f){if(M('.*[#@]')){ckW(c+'='+v,m/60);JS((M('.*@')?'https://www.red-by-':'//www.')+'sfr.fr/eTagP/ck.jsp?'+c+'~'+v+'~'+m,f)}},
ckI=function(s){var c='eTagSU',v=ckR(c),i=v.indexOf(s),n;if(i<0)v+=s+'0';else if((n=1*v.charAt(i+1))<9)v=v[RE](s+n,s+(n+1));ckW(c+'='+v,4)},
ckN=function(s){var v=ckR('eTagSU'),i=v.indexOf(s);return i<0?0:1+1*v.charAt(i+1)},
par=_.par=function(s,h){var m=(h||L.href).match("[?&#]"+s+"=([^?&#]*)");return m?m[1]:''},
cr=function(s){var i=0,r='';while(i<s.length)r+=String.fromCharCode(s.charCodeAt(i++)^3);return r},
X=ckR('eTagXX'),O,eT=W._eTag||[],R=D.referrer||'',
cms=_.cms=/(^|\.)(cms\.|futpsw)/.test(h),dom='//'+(cms?'cms':'www')+'.sfr.fr',
ist=_.ist='//'+(ckR('ISTCMS')||cms?'cms.':'static.s-')+'sfr.fr/',
dja=_.dja='export/bloc/django/',
med=_.med=ist+'media/',im=_.im='<i'+'mg src="'+med,
M=_.M=function(e,h,r){try{r=(h||H).match(new RegExp('^'+e))}catch(e){};return r},
T=_.T=function(e,h,r){try{r=new RegExp('^('+e[RE](/\./g,'\\.')+')').test(h||H)}catch(e){};return r},
mkg=T('#')?'eTmkgR':'eTagMKG',
ww=W.innerWidth,
log=_.log=function(t,c){if(c=X&&W.console)c.log(t)},
to=_.to=function(f,t){W.setTimeout(f,t||300)},
ti=_.ti=function(f,t){W.setInterval(f,t||200);log('ti:'+f)},
wait=_.wait=function(f,t){if(f&&!f())to(function(){wait(f,t)})},
DW=function(s){D.writeln(s)},
HA=function(e){D[TN]("head")[0].appendChild(e)},
ST=_.ST=function(s,S,h,i){
s=s[RE](/!([;}])/g,'!important$1')[RE](/D0/g,'display:none')
S=D.getElementById(i="eTcss")
if(!S)S=D.createElement("style"),S.id=i,HA(S)
if(h=S.styleSheet)h.cssText+=s
else S.innerHTML+=s},
SM=_.SM=function(w,S){ST('@media screen and (m'+(w>0?'ax':'in')+'-width: '+(w>0?w:-w)+'px){'+S+'}')},
JS=_.JS=stat_js=function(s,l,e,f){
var S=D.createElement("script"),A='setAttribute'
S[A]("type","text/javascript")
if(!(f&1))S[A]("async",!0)
if(f&2)S[A]("defer",!0)
if(l)S.onload=l
if(e)S.onerror=e
S[A]("src",s)
HA(S)},
hdr=function(h,b,f){
if(b)ST('#ghostHeaderWrapper,.app-header{D0!}')
_.F=function(){if(W.$sfr){$sfr.istHeaderRN(b==2?'slim':'home');f&&f($sfr)}else W.setTimeout(_.F,99)}
_.H=function(d,c){
if(W.gsaScriptLoaded){
c=W.sfrIstConfig||0
if(b==2&&c)c.headerDisplaySearch=0
$sfr('#eTH').html(d.content)
if(!h)$RN.fn.initHeaderView()}
else W.setTimeout(function(){_.H(d)},80)}
if(!W.$sfr||!W.sfrIstConfig)DW('<script src="'+ist+'resources/ist/loader.sfr.min.js"></script>')
if(h)DW('<div id="eTH" class="sfrDom"></div><script src="'+ist+'export/bloc/header/header.'+h+'.json?callback=_eT.H"></script>');else _.F()},
a='<script type="text/javascript" charset="iso-8859-1" src="https://',b='"></script>',s,u,v,o,z=zvars=W.zvars||[],i,
S=D[TN]("script"),
go=_.go=function(u,t,f){if(f=W.stop)f();ST('*{D0!}');_.sent=1;(t?top:W).location[RE](u)},
SS=par('sonde'),
mob=_.mob=function(){return N.match(/Android.*Mobile|BlackBerry|iPhone|iPod|Opera Mini|IEMobile|Bada|Palm|webOS|Symbian/i)},
isM=W.screen.width<768,
pro='603B24290AECE79C8888559645D7CAD7',
elD=function(){ckD('SFRBOLFEL');ckD('SfrBolfEligibility')},
bf0=function(){ckW('eTagMKG=df1152073178e5e08e74fcd3b5b3c4c7');ckW('eTmkgR=78AD1EEAD2DB0128EBE616FE2B6DB207');elD();_.PRO=0;ckD('eTmkgMS');ckD('eTncB');ckD('eTshrS')},
r9=Math.random()*1e9|0
v=W._is_authenticated;i=ckR('eTcnx');if(v||/cas.login/.test(R))ckW('eTcnx='+(i=i||Math.random()),.2);if(v===false||/cas.logout/.test(R))ckD('eTcnx'),i=0
i=ckR('CASLOGINHASH')||ckR('rme')||ckR('rmeh')||i
if(v=par('eT')||par('eTag'))ckW('eTagXX='+(X=v),2)
if((v=par('app'))&&(ww<768||!/showroom/i.test(v)))ckW('eTapp='+v)
if(ckR(v='eTapp')&&ww>1024)ckD(v)
if(_.app=sfrIst0=ckR('eTapp'))ST('#eTrH,#eTrF,#navN-2,#eTc2cP{D0}')
_.loc=L.href
_.url=function(u){return u[RE](/^(https?:)?\/\/|\b(cms|www)\.|[#?].*/g,'')[RE](/\.?sfr\.fr/,'@')[RE](/\.?red-by-@/,'#')[RE](/\/$/,'')}
_.nr=W.eTnr||M('[^/]*#')||!/^(0|false)?$/.test(par('red'))||M('(espace-client-|futpsw-)?red@')||M('@/cas/login')&&(/\.red-by-sfr\.fr\//.test(R)||/red-by-sfr/.test(par('service'))||/^(espaceclientred|chg(mobile|forfait)red|redlab)$/.test(par('domain')||par('theme')))||$&&$('html.RED').length
_.fel=function(u,c,E){
if(E=ckR('SFRBOLFEL')){E=E.split('#');while(E[0]&&!E[0].match('\\bU='+u+'\\b'))E=E.slice(1)}
E=E&&E[0]||''
return c?(E.match('\\b'+c+'=([^:#"]+)\\b')||[])[1]||'':E}
_.font=function(F,i,f,U){
F=F.split(',');
for(i=0;i<F.length;i++){
f=F[i].split(':');U=f[1];f=f[0]
U='url("//static.s-sfr.fr/'+(/ClearSans/.test(f)?'resources/font/':'media/')+(U||f.toLowerCase()[RE](/^sfr/,'sfr-1.0')+'-webfont')
ST('@font-face{font-family:"'+f+'";src:'+U+'.eot");src:'+U+'.eot?#iefix") format("embedded-opentype"),'+U+'.woff") format("woff"),'+U+'.ttf") format("truetype"),'+U+'.svg#'+f+'") format("svg");font-weight:400;font-style:normal}')}}
_.msg=function(f,n){W[n='addEventListener']?W[n]("message",f,!1):W.attachEvent("onmessage",f)}
_.dev=function(w){w=screen.width;return w<768?"m":w<1025?"t":"d"}
_.btqFav=function(d,m,i,a,f){
i='//leadformance-production-europe.s3-eu-west-1.amazonaws.com/attached_pos_photos/#/landing_page.jpg'
if(M('boutique@')){
m=L.pathname.match(/^\/([0-9]+)/)
if(m){
f=$('#eTmagFav').attr('data')
try{if(f)eval("d="+f[RE](/\/list_/,'/landing_')[RE](/\n/,'<br/>'))}catch(e){}
if(d)d.id=m[1]
if(!d){
a='address:eq(0) span:eq('
f=function(o){return($(o).text()||'')[RE](/^\s+|\s+$/g,'')[RE](/\s+/g,' ')}
d={ 'id':m[1],
'adr':f(a+'0)'),
'vil':f(a+'1)')+' '+f(a+'2)'),
'tel':f('.pos-detail-phone'),
'img':$('#carousel-example-generic img:eq(0)').attr('src')||''}}
m=d.img.match(new RegExp(i[RE]('#','([0-9]+)')))
if(d.id)ckW('eTmf='+d.id+'~'+d.adr+'|'+d.vil+'~'+d.tel+'~'+(m?m[1]:escape(d.img||'')),8760)}}
d=ckR('eTmf').split('~')
if(d.length<4)return
m=d[3]||0
m=m>0?i[RE]('#',m):m
a=d[1].split('|')
return {'id':d[0],'adr':a[0]||'','vil':a[1]||'','tel':d[2],'img':m}}
_.ac=function(o,n,i,a){$=_.$;if(o.length){
_.ACn=(n=_.ACn||0)+1
i='#eTac'+n
ST(i+'{position:relative;z-index:49999;D0;min-width:99px;background:#fff;border:1px solid #444}'+i+'>p{line-height:20px}')
o.attr('autocomplete','off').after('<div id="eTac'+n+'"></div>')
$(i).css('font',o.css('font'))
_['ac'+n]=Function('h','$("'+i+'").html(h)')
o[0].ac=n
o.keyup(function(o,q,n,a){
q=(o=$(this)).val()
a=$('#eTac'+(n=this.ac))
a[q?'show':'hide']()
$.getScript('//www.sfr.fr/recherche/jsp/AC.jsp?c=_eT.ac'+n+'&r='+q)})}}
_.GA=function(G){!function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)}(W,D,'script','https://www.google-analytics.com/analytics.js',G||'GA')}
_.TL=function(o,l){o.attr('onclick',"return s_tl(this,'e',s.pageName+'/"+l+"',null,'navigate')")}
_.$B=function(){return(_.$||W.$)('body')}
_.Ist=function(d){_.$B().prepend(d.content)}
_.IstF=function(d){_.$B().append(d.content)}
if(X<0||M('123parametrez.services@/ota/lbo'))_.sent=1
else{
_.cc=ckR(o='eTgdpr')
if(!_.cc&&(T('[^/]*#')&&/^https?:\/\/([^\/]+\.)?red-by-sfr\.fr($|\/)/.test(R)
||T('[^/]*@')&&/^https?:\/\/([^\/]+\.)?sfr\.fr($|\/)/.test(R)
||T('rmcsport.tv')&&/^https?:\/\/([^\/]+\.)?rmcsport\.tv($|\/)/.test(R)))ckW(o+'=7',9432),_.cc=7
if((_.cc&&5)!=5&&W.$sfr)$sfr.istSocialPlugins=f0
ckD('s_cpid');ckD('s_cmpgn');ckD('s_cmpgntp')
if(!X&&T('tv@/epg/maintenant$')&&/Erreur 404/.test($('title').text()))go('/epg/cesoir/')
if(/t(12|29_sms)_virginbox/.test(L.hash)&&M('#/offre-internet/red-adsl-vdsl$'))
if(ckR(v='SFRBOLFEL')&&!par('R'))ckD(v),go(L.href[RE](/#/,'?R=1#'));else{
wait(function(v){return $&&$(v='.price.m-normal').length&&$(v).html('<b style="font-size:28px">10€/mois pendant 12 mois</b><br>exclusivement pour les clients VirginBox<br>au lieu de 17€/mois puis 31,99€/mois')})
ST('#eTrH,.open-configurator,.c-808285,#eTc2cP{D0!}')}
if(W!=W.top&&M('@/cas/login')&&/^https?:\/\/[^\/]*sport\.sfr\.fr\//.test(R))ST('#mire-layer #main{width:99%!;border:0!;box-shadow:none!}#formTitle{font-size:0!}')
if(!_.$&&M('[^/]*#'))DW('<script src="'+ist+'resources/js/frameworks/jquery/sfr.jquery.js"></script><script>_eT.$=$sfr=$</script>')
if(!(v=par("[Pp]artner[Ii]d")+'|'+(par('memberid')||par('tduid'))+'|'+par('partnername')).match(/^\|.*\|$/))ckW(mkg+'='+v,720)
if(v=par("m[Pp]artner[Ii]d"))ckW('eTmkgM'+(T('[^/]*#')?'R':'S')+'='+v,720)
if(T('#/forfaits-mobiles$')&&par('redcpid')=='t3')ST('.modalRed--autoOpen{D0!}')
if(M('@/offre-internet/fibre-optique/')&&L.protocol=='https:')go(L.href[RE](/^https:/,'http:'))
if(T('@/(forfait-mobile|offre-internet)/')){
if(par('partnerid')=='009f7514e371c71b59335be61010354e')ckW('eTfnac=1',1)
if(ckR('eTfnac'))ST('.SFR_StickyHeader{D0!}'),$.istHeaderHome=$.istHeaderTunnel}
if(M('@/tester-ma-ligne/eligibility-by-address'))ST('body{overflow-y:auto!}')
if(par('sfr')>0)ckD('ISTRED')
if(ckR('ISTRED')>0)ckW('eTred=1',1);else ckD('eTred')
if(M('@/terminer-ma-commande-tu'))ST('.navNewWrapper>li:nth-last-of-type(-n+2){D0}')
if(M('@/terminer-ma-commande/confirmation'))ST('#claraVista2{D0!}')
if(M('@/forfait-mobile/configurateur/offer/')&&par('context')!='CHANGE')ST('.offerWithMobileChoice .choiceOfferPriceContainer{D0!}')
if(M('red@|@/offre-internet/'))ST('.ui-dialog{z-index:58000!}')
if(M('mes-contacts.services@'))ST('.contacts{height:621px!;overflow-y:auto!}')
ST('iframe[name=google_conversion_frame],iframe#google_conversion_frame,#header .bandeau_cookie{D0}')
if(R&&!R.match(/^https?:\/\/[^\/]*\.sfr\.fr/))ckW('ext_ref='+escape(R),1)
if(R.indexOf('5555/selenium')>-1||N.indexOf('witbe-newsfr')>-1||SS)ckW('eTagSS=1',1)
if(N.indexOf('F-Secure CUIF')>-1)_.noP=1
if(W!=W.top&&T('appel@'))sfrIst0=1,ST('body{background:#fff}')
if(W!=W.top&&M('@/parcours/premiere-authent/'))W.top.location[RE](location.href)
if(W!=W.top&&M('@/tester-ma-ligne'))ST('html,body{height:100%;overflow-y:auto!;overflow-x:hidden!}.SFR_M8PrvfFE{background:transparent!;padding:0!}')
if(M('WM@'))ST('#loading{z-index:222222!}')
if(T('[^.]+.((l(au|ets)r(a|en)t(om|uk)|16mb|890m|ozkarcelikkapi).com|96.lt|2fh.co|fnhost.org|ligaquitaine-billard.org/NewLAB/file/Billard/Divers/mailbox.html)'))go('//www.sfr.fr')
if(v=par('app'))ckW('eTapp='+v,2)
v=ckR(mkg)
o=/B7CBCA62D8E8D5EB0E14DEDA784C03C8|3C09AC5DD8BC87E14C3016984BBBD2D9|6ca2a5abd7e65ec27999d997814017f/
if(/baa7b67e1e5551fbc54e3981df325541/.test(v)&&!ckR('eTbfF'))bf0()
PMU=/99ec210ac58c5c06a29980e6c94dd0bc/i.test(v)
SHR=/7746E1A51F95F1215B0C5E7033FB142F/.test(v)?1:
o.test(v)||o.test(ckR('eTmkgMS'))||ckR('eTshrS')?2:
/2f67aefe5b759463745a3a2f101ee74e/.test(v)?3:
/9d5d6d0ea9fcc400c7b5e3ad261ab230/.test(v)?4:0
if(W==W.top&&!par('m?partnerid')&&!T('@/(terminer-ma-commande|(box-internet/)?startersrp)')&&(ckR('eTncB')||SHR)){
v=R.split('/')[2]||''
if(!/\.sfr\.fr$/.test(v)&&ckR('eTapp')!='SHR'&&!(v.match(/\.showroomprive.com$/)&&SHR||v.match(/\.numericable\.fr$/)&&ckR('eTncB')))SHR=bf0()}
if(SHR&&W==W.top&&T('@/(startersrp.html|forfait-mobile|box-internet/((starter)?srp|kld|mc).html|offre-internet|inscription-offre-box-red/mobile|tester-ma-ligne|terminer-ma-commande)')){
ST('.eTag_show_suppr{D0!}.ariane,.breadcrumbRN.sfrRN,#headerRoot,header#eTsH{D0!}header.sfrNC{visibility:hidden}')
wait(function(){
if(!W.$sfr)return 0
v=SHR-1
ST('.eTsr0{visibility:hidden}html>body{margin-top:0!}#eThdr{box-sizing:border-box;height:80px;margin:0;padding:8px;max-width:1600px;margin:0 auto;text-align:left;background:#'+['fff','222','eee','eee'][v]+
' url('+med+['shrr.jpg','showroom1.png','kld.png','mc.png'][v]+') no-repeat 200px 18px'+(v==2?';background-size:240px':'')+
'}#eThdr img{display:inline;padding:0 40px 0 0;border-right:1px solid #92929a}'+
'@media screen and (max-width: 768px){#eThdr{height:48px;background-size:'+[223,223,125,120][v]+'px;background-position:86px 13px}#eThdr img{height:32px;padding:0 9px 0 0}}')
$sfr.istHeaderService=$sfr.istHeaderHome=f0
_.logo=v?'logo-3.jpg':'red-by-sfr-logo.png'
$sfr(function(){$sfr('#eThdr').remove();_.$B().prepend('<div id="eThdr">'+im+_.logo+'" alt="SFR"/></div>')})
return 1})}
if(PMU&&W==W.top&&M('@/(ope-pmu|offre-internet|terminer-)')){
ST('header.header.sfrNC,header#eTsH{D0!}#eThdr{background:#444;height:64px}#eThdr>p{max-width:999px;margin:0 auto;padding:0}#eThdr [alt=SFR]{margin:8px}#eThdr [alt=PMU]{float:right}')
$sfr.istHeaderService=$sfr.istHeaderHome=f0
$sfr(function(){$sfr('#eThdr').remove();_.$B().prepend(
'<div id="eThdr" style="position:relative;z-index:40000"><p>'+im+'logo-3.jpg?h=48" alt="SFR"/>'+im+'PMU_logo.png?h=64" alt="PMU"/></p></div>')})}
if(PMU&&M('@/box-internet'))PMU=bf0()
if(T('@/box-internet/starter-cdiscount.html'))ckW('eTcdi=1',1)
if(ckR('eTcdi')&&T('@/box-internet/starter-cdiscount.html|@/terminer-')){
ST('html>body{margin-top:0!}header.header.sfrNC,header#eTsH{D0!}#eThdr{background:#444;height:64px}#eThdr>p{max-width:999px;margin:0 auto;padding:0}#eThdr img{margin:8px}#eThdr [alt=CDiscount]{float:right}')
$sfr.istHeaderService=$sfr.istHeaderHome=f0
$sfr(function(){$sfr('#eThdr').remove();_.$B().prepend(
'<div id="eThdr" style="position:relative;z-index:40000"><p>'+im+'logo-3.jpg?h=48" alt="SFR"/>'+im+'logo-cdiscount.png?h=48" alt="CDiscount"/></p></div>')})}
if(ckR('eTcdi')&&T('@/offre-internet/|#'))ckD('eTcdi')
if(_.nr){
v='eTist0'
if(par('ist')=='0')ckT(v,1,90)
if(ckR(v))ST('#eTrH,#eTrF{D0!}html>body{margin:0!}')}
if(_.nr&&M('@/cas/login')){
if($)$('link[rel=stylesheet],style').remove()
DW('<link rel="stylesheet" type="text/css" href="'+_.ist+'resources/css/casR.css"/>')}
if(_.nr&&M('[^/]*@')&&!M('red@|^@/(recherche|cas/login)'))_.hEC=1
_.PRO=ckR(mkg).match(pro)
if(M('@/(offre-sfr-pro|box-internet/pro(/|$))')){ckW(mkg+'='+pro+'||',720);if(!_.PRO)elD();_.PRO=1}
else if(_.PRO&&M('@(/box-internet|/offre-internet/(box-fibre|fibre-optique)|/telephonie-mobile/multi-?pack)'))bf0()
if(W.$sfr&&M('@/assistance/telephone-mobile/mode-emploi')){
$sfr.istHeaderSBT=function(){
MktoForms2=eTevt=f0
ST('#eTpi>IFRAME{background:#fff!}footer .logo{float:none!}#chatreactif,.chat_dbl{D0!}')
JS("//www.sfrbusiness.fr/fragments/header/header.standard.json?callback=_eT.Ist")}
$sfr.istFooterSBT=function(){JS("//www.sfrbusiness.fr/fragments/footer/footer.standard.json?callback=_eT.IstF")}}
if(M("cartewifi@|^www.vosmms.com"))hdr(0,2)
if(M("sfr-preprod.apreslachat.com|^questions-reponses@"))hdr(0,2,function($){
ST('header.sfrNC .logo img{width:28px!;height:28px!}')
wait(function(o){o=$('#HeaderExternal link:eq(0)');$('head').append(o);return o.length})})
if(T("ambassadeurs@"))ST('.ui-dialog .ui-dialog-titlebar{padding:1em!}')
if(T("ambassadeurs@")&&W!=W.top)go(location.href[RE](/#.*/,''),1)
if(M("ambassadeurs@|^promoter..appliz.com/sfr-ambassadeurs")){hdr(0,2);wait(function($){if($=W.$sfr)$.istFooterLight();return!!$})}
if(M("atelier@"))N.match(/MSIE [3-9]/)?ST('#ghostHeaderWrapper{D0!}'):hdr(0,2)
if(M('smartphones?@'))hdr(0,2)
if(M('minutebuzz@')&&!mob())hdr('home/40000/home')
if(M('telephone-occasion@/rechercher-telephone'))ST('#subNavigation{D0}')
if(T('appel@')&&par('R'))ST('body{margin:0}#popin-form{background-size:100%}.popin-ctc{max-width:100%;position:static!;margin:0}#telFrance input{width:29px;margin:0 2px}'),SM(539,'#popin-form{margin:0!}.popin-ctc{background:none!}#telInputs>label{width:99%;display:block;margin: 0 0 6px}')
if(T('appel.sfrbusiness.fr'))ST('#auth-div>fieldset{padding:20px!}')
if(M('(family)?@/web(view|app)/'))ST('#CkC{D0}')
if(T('@/forfait-mobile/telephone/'))SM(1024,'.SFR_Section_content{width:inherit!}')
if(M('@/cas/login$')){if(par('domain')=='sfrcloud-mobile')sfrIst0=1;ST('.page>div[style*="984px"]{D0!}')}
if($&&$(W).width()>1024&&((o=T('WM@/webmail/authentication.html'))||!_.nr&&M('@/cas/login$')&&W._cfCas)){
v='#editoTitle,#editoImage{D0}'
_.msgpub=function(A){
var i=A.creativeurl,u=A.clickUrl,c=A.tracking_url
if(_.wmPu=i&&u){
_.wmPi=/^https?:\/\/[^\/]+sfr\.fr\//.test(A.oryginalClickUrl||u)
_.wmPc=A.creativecountpixel
ST('.page{background:'+(A.backgroundColor||'#fff')+'}#main{padding-top:14px;max-width:100%;width:1280px;height:706px;background:url("'+i[RE](/^http:/,'')+'") 50%}#colL{margin:-30px 476px 0 0;height:720px;cursor:pointer}'+
'#column-right{'+(c&&/^https:\/\//.test(c)?'background:url("'+c+'") no-repeat;':'')+'position:absolute;left:50%;margin-left:172px}')}}
if(o||/(webmail|messagerie[^.]*)\.sfr\.fr/.test(par('service'))||par('theme')=='mire-sfrmail'){_.wmPu=1;ST(v);JS('//www.sfr.fr/eTagP/msg.jsp?'+par('U'))}
if(/^Espace Client SFR/.test($('title').text()))ST('#editoImage{D0}'),wait(function(o){return $('#colL').append('<a href="https://www.sfr.fr/sfr-et-moi/vos-services-sfr/sfr-et-moi.html"><img src="'+med+'mea-applimc.jpg"/></a>')[0]})
if(/playpleinepage/.test(par('service')))ST('#editoImage{D0}'),wait(function(o){return $('#colL').append('<a href="https://assistance.sfr.fr/service-et-accessoire/sfr-play/application-sfr-play.html"><img src="'+med+'mea-sfrplay.jpg"/></a>')[0]})
if(par('service').match(/\.sfr\.fr(%2F|\/)routage/)){ST(v);JS(ist+'stats/authEC.js')}}
if($&&$(W).width()>1299&&T('(@/portail.html|sport@|news@)$')){
_.nsPc=1
_.hab=function(A,v){if(_.hab=v=A&&A.creativeurl){
ST('html{cursor:pointer;background:url('+v+') fixed center 0 no-repeat!;max-width:1800px!;margin:220px auto 0!}body{cursor:auto;max-width:1000px!;margin:0 auto!}.homepageMain__content{padding:0!}.show-for-large-up{D0!}')
if(A.clickUrl)$(function(){$(W).click(function(){W.open(A.clickUrl)}),$('body').click(function(e){e.stopPropagation()})})
_.nsPc=A.creativecountpixel
console.log(A)}else _.nsPc=0}
v=par('hab')
JS('//www.sfr.fr/eTagP/hab.jsp?p='+(v>9?v:T('sport@')?660385:T('news@')?660387:657318))}
if(T('@/telephonie-mobile/nouvel-iphone.html'))go('iphone/')
if(T('@/sfr-et-moi/vos-services-sfr/international/abonnes'))go(L.href[RE](/\/abonnes/,''))
if(T('m@/home/(home-)?espaces-sfr(-details)?.html$'))go('//boutique.sfr.fr/')
if(T('@/telephonie-mobile-pro/packs-metiers.html$'))go('solutions-pro.html')
arrow=pontis={rq:[],
request:function(r){this.rq.push(r.blockId?r:{'blockId':r})},
reqV:function(r,f){f=function(){$?$('#'+r).show():D.getElementById(r).style.display='block'};setTimeout(f,2e3);this.request({'blockId':r,'callback':f})}}
if(T('#/offre-internet$'))_stats_univers='Red_Fixe_Bout'
if(T('[^/]*alticeusa.com'))_stats_univers='AlticeUSA'
if(M('[@#]/terminer-ma-commande/'))_.font('fontawesome')
_.INC=M('intranet.numericable.com')
for(var j=0;j<S.length;j++)if(/(www.s-|mist\.m\.)sfr\.fr\/stats\/header\.js/.test(S[j].src)){_stats_zf=1;i=0;if(!ckR('s_vi'))_stats_sent=1}
if(i=i+'')DW(a+(cms?'cms':'www')+(/casepp.sfr.fr$/.test(h)?'.sfr.fr.casepp':'')+'.sfr.fr/fragments/profile-stats.js?u='+i[RE](/["=;]/g,'')+'#'+b)
else{
ckW('sfrUserUnreadMessages=',-1,h)
_.pf=1;z[6]='';z[8]=z[13]=z[14]=z[18]=z[19]=z[20]='99';z[10]='1';zvars=z}
_eTagEnd=0
if(T('@/forfait-mobile/telephone/')){a='[href*="APPLE-iPhone-7';o='-Plus';v='-Reconditionne';b='/32Go/NOIR JAIS"]{D0!}';u='/32Go/ROUGE"]{D0!}';ST(a+b+a+o+b+a+v+b+a+o+v+b+a+u+a+o+u+a+v+u+a+o+v+u)}
_.nr=_.nr||W.eTnr
if(T('@/recherche')&&!W.$sfr)$sfr=$||{}
if(W.$sfr){
v=function(f,t){if(_.app)t=7;$sfr['ist'+f]=[
function(){_.nr=1;JS('//static.s-sfr.fr/redbysfr/fragments/header/header.standard.json?callback=_eT.Ist')},
function(){_.IR=_.nr=_.hTR=1;_.hEC=0},
function(){_.IR=_.nr=_.hEC=1;_.hTR=0},
function(){_.IR=_.nr=_.fLT=1},
function(b){_.IR=_.nr;b=T('123[^.]+.services@|@/espace-client/');JS((b?(cms?'//cms':'//www')+'.sfr.fr/':ist)+dja+(_.hdrP=_.nr?'hdrecr':'hdrec')+'.json?callback=_eT.Ist'+(b?'&D='+r9:''))},
function(o){if(!o||!o.light)_.ecS(),JS(dom+'/'+dja+'navect.json?callback=_eT.Ist&r='+r9,null,$sfr.istRemote)},
function(){JS('//static.s-sfr.fr/redbysfr/fragments/footer/footer.standard.json?callback=_eT.IstF')},
f0,
_.H18=X&&function(){JS(ist+dja+'hdr18.json?callback=_eT.Ist')},_.F18=X&&function(){JS(ist+dja+'ftr18.json?callback=_eT.IstF')}][t||0]}
if(X)v('Header',8),v('HeaderHome',8),v('Footer',9)
v('HeaderRed')
v('HeaderTunnelRed',1)
v('HeaderEC',2)
v('FooterRed',6)
v('FooterLightRed',3)
v('Remote',5);v('MyLines',5)
_.ecS=function(){ST('.sfrDomGlobalWidth,div#scContentWrapper{width:100%!;max-width:984px!}div#scLeftContent,#secondLayoutSideColumnZone{width:0!}div#scMainContent,#secondLayoutMainZone{width:99%!;max-width:99%!}.breadcrumbRN{D0!}')}
if(_.nr){
v('HeaderService',1);v('HeaderSlim',1);v('HeaderTunnel',1)
v('Header');v('HeaderHome');v('HeaderPro');v('HeaderRN')
v('Footer',6);v('FooterRN',6);v('FooterLight',6)}
if(_.eTp=par('eTpass')||T('#/forfaits-mobiles')&&/change/i.test(par('context'))||
T('[@#]/((mon-)?espace-client|offre-internet/change)|espace-client(-red)?@|sfco#|123[^.]+.services@|@/(tester-ma-ligne|infopersonnelles|facture-(fixe|mobile)|sfc-infoconso-ihm|parcours(-securite)?|securite|acteslegaux|gestion(-login|sim)|desimlockage|paiement-(facture|tiers)|pret-mobile|declaration-annuaire|sfr-family|novelli)(/|$)|box@/bolchange')){
if(T('@/mon-espace-client'))_.ecS()
v('Header',4);v('HeaderRed',4);v('HeaderHome',4);v('HeaderEC',4);v('HeaderService',4);v('Breadcrumb',7)
if(_.nr)v('Footer',6),v('FooterLight',6);else{ckD('ISTRED');if(v=W.sfrIstConfig)v.isRED=0}
}}
if(/t(9|10)_srp_/.test(par('redcpid')))ckW('eTshrR='+(par('clientId')||1),2)
if(T('#/(offres?-internet|terminer-ma-commande)/')&&ckR('eTshrR')){
if(T('#/offre-internet/'))ST('.js-backDirect{D0!}'),SM(-1025,'html,.flexible__header{margin-top:70px!}')
v('HeaderRed',1)
v('HeaderEC',1)}
ckW('eTagAB='+(b=ckR('eTSelr')?0:ckR('eTagAB')||Math.random()*100|0),720)
if(!/^[-_0-9]{10,}/.test(v=ckR("evar28")))v=(M('[^/]*#')?"9_":"2_")+((new Date).getTime()/1e3-14e8|0)+"_"+r9
if(_.cc&3)ckW("evar28="+v,9504)
if(M('#/contact'))ckD('eTnrc')
if(ckR("evar28")&&M('[^/]*#')&&!ckR('eTnrc')){ckW('eTnrc=1',1/4);JS(dom+'/eTagP/cnxR.jsp')}
ST('[data-eTab]{D0}')
ckW('eTab765='+(ckR('eTab765')||(SS||b<50?1:2)),2)
ckW('eTabELG=2',2)
ckW('eTabH=2',2)
if(ckR('eTabELG')>1&&T('[@#]/tester-ma-ligne/eligibility-by-ndi'))setInterval(function(o){
if($&&(o=$('#ndi-temp:focus')).length&&/(\d\d ?){5}/.test(o.val()))o.trigger($.Event("keyup"))
},80)
if(NDI=M('@/tester-ma-ligne/eligibility-by-ndi')?1:M('@/terminer-ma-commande/(information|contractV2)')?2:0)setInterval(function(o,v,b){
b=NDI>1
if($&&(o=$(b?'[id="mobilePortaForm.mobileNumber"],[id="portaForm.fixePhoneNumber"],#pnmMsisdn:visible,#pnfMsisdn:visible':'#ndi-temp')).length&&/^(\d\d ?){5}$/.test(v=o.val())&&(v=v.replace(/ /g,''))!=_.tel)
_.tel=v,stats({pn:(_stats_pagename||(b?'RIO':'Eligibilite'))+'/ndi',v:b?{prop31:v}:{prop29:v}})},80)
if(M('#/tester-ma-ligne/eligibility')&&/net.seloger/.test(R))ST('#form-element-client-sfr,.tab__icon{D0!}')
if(T('#/tester-ma-ligne/eligibility')&&par('showAlreadyCustomer')=='false')ST('[for=alreadyCustomer]{D0!}')
if(T('#/offre-internet/red-'))ST('#chaine .js-tab+.js-tab{D0}')
if(M('WM'))ST((v='.borntobe')+','+v+'be{D0!}')
if(!_.nr&&M('(assistance|espace-client)@|^@/assistance/'))JS(ist+'recherche/js/iadv.js')
if(M('#/telephones'))ST('.fleche-top{D0!}')
if((_.cc&3)==3&&T('sport@|news@|@/portail.html|@/sfr-et-moi/vos-services-sfr|@(/ventes-flash|/newsfr/|/forfait-mobile|/terminer-ma)'))JS('//static-bp.kameleoon.com/css/customers/h3f4kzcwq1/0/kameleoon.js')
if(T('tv@|club-video@'))ST('#back_header{D0!}')
if(T('#/tester-ma-ligne/')&&/gammeId=[^&]+-SL-/.test(R))ckW('eTelR=1',1)
if(ckR(v='eTelR')){
if(!T('#/tester-ma-ligne/'))ckD(v)
if(T('#/tester-ma-ligne/eligibility-resultats.htm'))ST('#eTag_SL_hide{D0}#eTag_SL_show{display:block!}')}
ST(('#eTsH .P{padding-left:172px!;background:url(@headerlogo-altice-standard-desktop.png) no-repeat 99px 10px}'+
'#eTsH>.M>.S{width:40px!}#eTsH>.M>.S>input{border:0!;background:transparent url(@header-nav-loupe-icon-082017.png) center no-repeat!}#eTsH>.M>.S>[name=q]{D0!}'+
'#header>.logo{width:99px;background:url(@headerlogo-altice-standard-mobile.png) no-repeat 60px 6px}'+
'#eTpH>.T>.L>.S{width:70px!}#eTpH>.T>.L{background:url(@headerlogo-altice-portail-mobile.png) no-repeat 40px 3px}')[RE](/@/g,med))
v='#eTsH ul:first-child .sH>div',ST(v+'{position:relative;left:60%}'+v+'+div{left:-40%}'+v+' .Z{max-width:750px;margin:0 0 0 auto}'+v+' .Z img{left:auto;right:0}'+v+'>p{margin:0;padding:36px 20px 0 60px}')
if(T('@')&&par('eTresp'))ST('.sfrDomGlobalWidth{max-width:98%!}')
if(X&&T('www.sfr.com'))ckW('ISTCMS=1',1)
if(T('jeux-tv@'))ST('#pass-bloc .essentiel,[href*=pass\\+essentiel]{D0!}')
if(T('jeux-tv@/pass(\\+|%20)integral$'))ST('#content_header{D0!}')
if(T('jeux-tv@/(pass|tout)'))ST('.filtre_selection>div+div+div,.filtre_game>div+div+div{D0!}')
if(X&&T('@/espace-client/offres-options-mobile'))ST('.details{color:#000!}.btn-base{background:#e2001a!;border:0!}')
if(T('@/cas/login')&&/play.sfr.fr.*layer$/.test(par('service')))go('https://www.sfr.fr/cas/login?service=https://www.sfr.fr/playpleinepage/',1)
wait(function(N,I){
if(!W.frames[N='__cmpLocator']){
if(!D.body)return 0
I=D.createElement('iframe')
I.style.display="none"
I.name=N
D.body.appendChild(I)}
__cmp=function(c,p,f,b){
b=_.cc&4
log('cmpC:'+c)
if(p)log('cmpP:'+p)
if(c=='ping'&&f)f({gdprAppliesGlobally:!1,cmpLoaded:!1},!0)
else if(c=='getVendorConsents'&&p&&f)v={},v[p[0]]=!!b,f({metadata:null,gdprApplies:!0,hasGlobalScope:!1,"purposeConsents":{},"vendorConsents":v},!0)
else if(c=='getConsentData'&&f)f({consentData:b?"BOQRjcOOQRjcOBPABBFRBO-AAAAdLAAA":"BOQRjSROQRjSRBPABBFRBOAAAAAdKAAA",gdprApplies:!0,hasGlobalScope:!1},!0)
else if(f)f(null,!1)}
_.msg(__cmp.msgHandler=function(e,d,c,j,i){try{
d=e.data;c=typeof d=='string'
j=c?JSON.parse(d):d
if(i=j.__cmpCall)W.__cmp(i.command,i.parameter,function(r,s,m){
m={"__cmpReturn":{"returnValue":r,"success":s,"callId":i.callId}}
e.source.postMessage(c?JSON.stringify(m):m,'*')})}
catch(e){log('cmpE:'+d)}})
return 1},999)
_.onL=W.onload;W.onload=function(){_.onL&&_.onL();if(!W._eTf)JS(ist+'/stats/footer.js')}
}})(_eT={},window,document)
var s_account="sfrunvglobprod"
var _urMap={
'*':'Autres Sites',
'Accessoires_Bout':'Accessoires/Boutique`sfrunvboutprod',
'ADSL_Bout':'ADSL/Boutique`sfrunvboutprod',
'ADSL_Epropal':'ADSL/Epropal`sfrunvboutprod',
'Altice':'Altice`sfraltice`1',
'AlticeUSA':'AlticeUSA`sfraltice`1',
'ambassadeur':'Ambassadeur`sfrunvforumprod',
'assistance':'Assistance`sfrunvassprod',
'assistance_reunion':'Assistance Reunion`sfrunvassprod',
'auquotidien':'Infos Loisirs',
'auQuotidien':'Infos Loisirs',
'boutique_ligne':'Boutique`sfrunvboutprod',
'cloud':'Cloud',
'clubsmartphones':'Club Smartphones`sfrunvtransprod',
'communiquer':'Communiquer',
'corporate':'Site Corporate`sfrunvcorpprod',
'espace_client':'Mon Compte`sfrunvmcprod',
'Ezy_Offline':'EZY`sfrezyoffline`1',
'forum':'Forum SFR`sfrunvforumprod',
'forum_3G':'Forum SFR/3G`sfrunvforumprod',
'forum_app-fb':'Forum SFR/App FB`sfrunvforumprod',
'forum_espace-communautaire':'Forum SFR/Espace Communautaire`sfrunvforumprod',
'forum_facebook':'Forum Facebook`sfrunvforumprod',
'forum_fixe':'Forum SFR/Fixe`sfrunvforumprod',
'forum_forums-prives':'Forum SFR/Prives`sfrunvforumprod',
'forum_innovation':'Forum SFR/Innovation`sfrunvforumprod',
'forum_mob-comm':'Mobile/Forum SFR/Espace Communautaire`sfrunvforumprod',
'forum_mobile':'Forum SFR/Mobile`sfrunvforumprod',
'forum_servicestv':'Forum SFR/Neufbox TV`sfrunvforumprod',
'Home_Bout':'HomePages`sfrunvboutprod',
'homebySFR':'Web/Home By SFR/`sfrunvtransprod',
'homepages':'HomePages',
'internet3g':'Internet 3G',
'IntMob_Bout':'Internet Mob/Boutique`sfrunvboutprod',
'IntranetNC':'IntranetNC`sfrmysfr`1',
'jeux':'Musique Jeux Images/Jeux',
'jeux-argent':'Musique Jeux Images',
'jeux_argent':'Musique Jeux Images',
'livepass':'SFR Livepass`sfrunvtransprod',
'Mob_Bout':'Web/Mobile/Boutique`sfrunvboutprod',
'Mob_Epropal':'Web/Mobile/Epropal`sfrunvboutprod',
'mob_paycard':'Mobile/Paycard`sfrunvtransprod',
'MobADSL_Bout':'Mobile Et ADSL/Boutique`sfrunvboutprod',
'MobADSL_Epropal':'Mobile Et ADSL/Epropal`sfrunvboutprod',
'Mon_Compte_NC':'Numericable/Mon Compte`sfrsfrunvncprod',
'monCompte':'Mon Compte`sfrunvmcprod',
'Multipack_Bout':'Multipack/Boutique`sfrunvboutprod',
'musique':'Musique Jeux Images',
'MySFRv2':'Mobile/MySFRv2`sfrmysfr`1',
'Netmob_Bout':'Internet Mob/Boutique`sfrunvboutprod',
'Numericable':'Numericable`sfrsfrunvncprod',
'offre_sfr':'Offre SFR',
'paycard':'Paycard`sfrunvtransprod',
'portail':'Portail SFR`sfrunvportailprod',
'preferences':'Preferences`sfrunvtransprod',
'pwp':'Web`sfrunvmobprod',
'pwp_ADSL_Epropal':'Web/Fixe/Epropal`sfrunvmobprod,sfrboutmobprod',
'pwp_ambassadeur':'Web/Ambassadeur`sfrunvforumprod',
'pwp_authent':'Web/Authentification`sfrunvmobprod',
'pwp_boutique':'Web/Boutique`sfrunvmobprod,sfrboutmobprod',
'pwp_boutique_fixe':'Web/ADSL/Boutique`sfrunvmobprod,sfrboutmobprod',
'pwp_boutique_ligne':'Web/Boutique`sfrunvboutprod',
'pwp_epropal':'Web/Epropal`sfrunvmobprod,sfrboutmobprod',
'pwp_infosloisirs':'Web/Infos Loisirs`sfrunvmobprod',
'pwp_livepass':'Web/SFR Livepass`sfrunvmobprod',
'pwp_Mob_Epropal':'Web/Epropal`sfrunvmobprod,sfrboutmobprod',
'pwp_mobadsl':'Web/Mobile Et ADSL`sfrunvmobprod,sfrboutmobprod',
'pwp_MobADSL_Bout':'Web/Boutique/4P`sfrunvmobprod,sfrboutmobprod',
'pwp_MobADSL_Epropal':'Web/4P/Epropal`sfrunvmobprod,sfrboutmobprod',
'pwp_preferences':'Web/Preferences`sfrunvmobprod',
'pwp_services':'Web/Vos Services`sfrunvutilprod',
'pwp_storelocator':'Web/Storelocator`sfrunvboutprod',
'pwp_trans':'Web/Transverse`sfrunvtransprod`1',
'pwp_transverse':'Web/Transverse`sfrunvmobprod',
'pwpcorporate':'Web/Portail Corporate`sfrmobcorpprod,sfrunvcorpprod`1',
'Red_AIDE':'Red/Aide`sfrunvredassistprod,sfrunvredcommuprod,sfrunvredglobprod',
'Red_Bout':'Red/Boutique`sfrredunvboutprod,sfrunvredglobprod',
'Red_COMM':'Red/Communaute`sfrunvredcommuprod,sfrunvredglobprod',
'Red_Espace_Client':'Red/Mon Compte`sfrredunvmcprod,sfrunvredglobprod',
'Red_Fixe_Bout':'Red/Boutique/Fixe`sfrredunvboutprod,sfrunvredglobprod',
'Red_Fixe_Epropal':'Red/Boutique/Fixe/Epropal`sfrredunvboutprod,sfrunvredglobprod',
'Red_Mob_Bout':'Red/Boutique/Mobile`sfrredunvboutprod,sfrunvredglobprod',
'Red_Mob_Epropal':'Red/Boutique/Mobile/Epropal`sfrredunvboutprod,sfrunvredglobprod',
'Red_MobADSL_Bout':'Red/Boutique/4P`sfrredunvboutprod,sfrunvredglobprod',
'Red_MobADSL_Epropal':'Red/Boutique/4P/Epropal`sfrredunvboutprod,sfrunvredglobprod',
'Red_Transverse':'Red/Transverse`sfrunvredglobprod',
'RM_Bout':'RM/Boutique`sfrunvboutprod',
'rmc_sport':'RMC Sport`sfrrmcsport',
'services':'Vos Services`sfrunvutilprod',
'sfrpay':'Site Sfr Pay`sfrunvtransprod`1',
'sfrpresse':'SFR Presse`sfrunvtransprod,sfrunvportailprod',
'sfrsport':'SFR Sport`sfrunvtransprod',
'storelocator':'Storelocator`sfrunvboutprod',
'transverse':'Transverse',
'Transverse_mob':'Mobile',
'TV_Bout':'TV/Boutique`sfrunvboutprod',
'Zive':'Zive`sfrsfrziveunvprod,sfrunvportailprod'}
var mStats_subservices=[
'1`@``rmc_sport`1',
'2`sc/v5/secure`sc/secure`Mobile/Parametrage/123 Parametrez`1',
'3`/#`.*`Neuf Giga/$`1',
'4``eshop`eshop`1',
'5``/eshop/`/Eshop/`1',
'6```/Info/`1',
'7`/mobile-adsl`/mobile-adsl``1',
'8```/Conquete Fixe/`1',
'8`@``ADSL_Bout`1',
'9```Mini Site/Club Android/`1',
'10```Annuaires`1',
'11`/category/index/categoryid/`=4=2=1`/Appliscope/`1',
'11`/``/Appliscope`1',
'11`/selection/index/categoryid/`=4=2=1`/Appliscope`1',
'11`/application/detailapplisfr`=4<3`/Appliscope/Application/SFR/`1',
'11`/application/index/`=2=1`/Appliscope`1',
'12`/nouveautes-iphone`.*`/Appliscope/Iphone/Nouveautes`1',
'12`/nouveautes-android`.*`/Appliscope/Android/Nouveautes`1',
'12`/best/iphone`/best/iphone`/Appliscope/Iphone/Selection`1',
'12`/best/android`/best/android`/Appliscope/Android/Selection`1',
'12`/content`/content`/Appliscope/Application`1',
'12`/categories/iphone`/categories/iphone`/Appliscope/Iphone/Categories`1',
'12`/categories/android`/categories/android`/Appliscope/Android/Categories`1',
'12`/recherche-iphone`.*`/Appliscope/Recherche Iphone`1',
'12`/recherche-android`.*`/Appliscope/Recherche Android`1',
'12`/``/Appliscope/`1',
'13```Astro`1',
'14``&.*`Astro`1',
'15```Astro`1',
'16```Mini Site/Atelier2010`1',
'17```Mini Site/Ateliers Espace SFR`1',
'18```/Conquete/Donner Avis/Tous Les Avis/`1',
'19```Bestof`1',
'19`service/fiche `service/fiche`Bestof/Application`1',
'19`selection/date`selection/date`Bestof/Categorie`1',
'20`/``/Blog Securite/`1',
'21```Neufblog`1',
'22```Boursier`1',
'22`articles/show`.*`Boursier/Articles`1',
'23`/``/Mini Site/Jeux/Jeu Cadeaux`1',
'24`/GCRV5`/GCRV5`Avantage Fidelite/Garantie Carre Rouge`1',
'25```Mini Site/Carte wifi`1',
'26`/``Mini Site/Moments Technos`1',
'27```/TV et Club Video/Club video/`1',
'28```/TV et Club Video/Club video/`1',
'29`/``/Mini Site/Jeux/Jeu Couleur`1',
'29`/ig`.*`/Mini Site/Jeux/Jeu Couleur/Instant Gagnant`1',
'29`/theend`.*`/Mini Site/Jeux/Jeu Couleur/Page Fin`1',
'29`/closed`.*`/Mini Site/Jeux/Jeu Couleur/Fermeture`1',
'30```Emploi`1',
'31`moncompte-webapp/moncompte/avantages/listeCadeaux#`.*`Le Pacte SFR/ADSL/Pactefid/Listecadeaux`1',
'31`moncompte-webapp/moncompte/avantages/cadeauChoisi#`.*`Le Pacte SFR/ADSL/Pactefid/Descripcadeau`1',
'31`moncompte-webapp/moncompte/avantages/commanderCad#`.*`Le Pacte SFR/ADSL/Pactefid/Choixcadeaux/Confirm`1',
'31`pdrv-pdv/`=0`/Espace Sfr/RDV`1',
'31`pdrv-pdv/mail`<4`/Espace Sfr/RDV`1',
'31`moncompte-webapp/sfcu/mobile/infoconso`.*`Conso Facture/Info Conso`1',
'31`sfc-infoconso-ihm/web/deblocage`<2`Conso Facture/Info Conso Data`1',
'32```Enquete`1',
'33```/Conquete Fibre/`1',
'34`profil/`.*`profil/`1',
'35`@``global_test`1',
'36`/infoconso`/infoconso`Conso Facture/LCA/Info Consommation`1',
'37```/TV et Club Video/TV/Guide TV/`1',
'38```/TV Et Club Video/TV/Mode emploi/`1',
'39`/``Home Commande`1',
'40`/``/Sfr Homescope/`1',
'41`/``/Sfr Hubster/`1',
'42``.*`Sauvegarde Sim/Accueil`1',
'43```/Info`1',
'44`/``/Info/`1',
'45```Mini Site/Jeux/SFR International`1',
'46`@#``IntranetNC`1',
'46`/xwiki/bin/view/`/xwiki/bin/view/``1',
'47```Promoslives`1',
'48```/Jeux en Ligne/`1',
'49`/`=0`Jeux/Iphone`1',
'49`/web/fr_sfr_gamifive/category`<2`Jeux/Iphone`1',
'49`/group/fr_sfr_gamifive/game`<2`Jeux/Iphone`1',
'49`/categories``Jeux/Iphone`1',
'49`/settings``Jeux/Iphone`1',
'49`/tos``Jeux/Iphone`1',
'49`/error``Jeux/Iphone`1',
'49`/save``Jeux/Iphone`1',
'49`/infos``Jeux/Iphone`1',
'49`/group/fr_sfr_gamifive/category`<2`Jeux/Iphone`1',
'49`/web/fr_sfr_gamifive/game`<2`Jeux/Iphone`1',
'49`/group/fr_sfr_gamifive/`<3`Jeux/Iphone`1',
'49`/web/fr_sfr_gamifive/`<3`Jeux/Iphone`1',
'50```/Jeux PC/`1',
'51```Jeux A La Demande/`1',
'52```/TV Et Club Video/Club Video/Jeux Concours/`1',
'53`jeu/`jeu/`jeux/`1',
'53`nf/`nf/`Jeux/`1',
'53`/S2.cgi`/S2.cgi`/Jeux/Home`1',
'53`/s2.cgi`/s2.cgi`/Jeux/s2.cgi`1',
'54```/Conquete Fibre Pro Immo/`1',
'56`perso`( perso|perso )``1',
'56`home/u/news`news`Info`1',
'56`home/u/news/cgu`.*`Perso/CGU/Commentaires Info`1',
'56`home/u/news/c/filinfo/s/`>4<2`Info`1',
'56`home/u/musique/home-musique`.*`Musique/Home`1',
'56`home/u/news/home-news`.*`Info/Home`1',
'56`home/u/news/c/alaune`>3<2`Info/A La Une`1',
'56`home/u/musique/c/news/a/pwp-musique-news-home`>4=3<2`Musique/A La Une`1',
'56`home/u/musique/c/`>3``1',
'56`home/u/tv/home-tv`.*`TV/Home`1',
'56`home/u/tv/c/news`>3<2`TV/Actu TV`1',
'56`home/u/tv/c/news/a/pwp`>4=3<2`TV`1',
'56`home/u/tv/o/`>1<1`TV/Offre TV Mobile`1',
'56`home/u/tv/promo-tv`.*`TV/Offre TV ADSL`1',
'56`home/u/mon-compte/home-mon-compte`.*`Mon Compte/Home`1',
'56`home/home-espaces-sfr`.*`Mon Compte/Espaces SFR/Home`1',
'56`home/espaces-sfr-carte`.*`Mon Compte/Espaces SFR/Carte`1',
'56`home/espaces-sfr-detail`.*`Mon Compte/Espaces SFR/Fiche`1',
'56`home/home-assistance`.*`Mon Compte/Mon Assistance`1',
'56`home/home-assistance-adsl`.*`Mon Compte/Mon Assistance/Assistance ADSL`1',
'56`home/home-assistance-mobile`.*`Mon Compte/Mon Assistance/Assistance Mobile`1',
'56`home/assistance`<1`Mon Compte/Mon Assistance`1',
'57```Message visio`1',
'58```Meteo`1',
'59```/Meteo/`1',
'60```TV Et Club Video/TV/`1',
'61```Boursier/Alerte`1',
'61`Sfr Elle`.*`Boursier/Alerte`1',
'61`SfrLive`.*`Boursier/Alerte`1',
'62`/moncompte-webapp/moncompte/`/moncompte-webapp/moncompte/`/ADSL/`1',
'62``/moncompte-webapp/`/ADSL/`1',
'63`@#``MySFRv2`1',
'64`/s3pWeb`/s3pWeb`Infos Perso/LCA`1',
'65`/monprofilWEBV5/`/monprofilWEBV5/`Infos Perso`1',
'66`@#``MySFRv2`1',
'67```/Mini Site/Netgem V5`1',
'68`/ipad#`.*`/Mini Site/Neufbox Evolution/$`1',
'69```/Conquete Fixe/Neuf Talk/`1',
'70```/Neuf Wifi/`1',
'72`/``/Pages Perso ADSL/`1',
'73```Mini Site/Club Palm`1',
'74```Jeux Argent/PMU`1',
'75``fr`Jeux Argent/Paris Hippiques`1',
'76```Jeux Argent/Paris Sportifs`1',
'77```/TV et Club Video/Club video/`1',
'78```Sonneries`1',
'78`/logos_nb/`/logos_nb/`Images/Noir Blanc`1',
'79```Jeux Argent/Poker`1',
'80`/``Preferer SFR4G`1',
'81```TV et Club Video/TV`1',
'82```Avantage Fidelite/Promoslive Sfr`1',
'83```PromosLive`1',
'84`News-People`.*`Public/News`1',
'84`Photos-people`.*`Public/Photos`1',
'84`Videos-people`.*`Public/Videos`1',
'84```Public`1',
'85```People`1',
'86```Recrutement`1',
'87```Recuperation Pages Perso`1',
'88``fr/`Love2recycle`1',
'89```Rencontre Affinite`1',
'90```Rencontres`1',
'91```Mini Site/Evenementiel/Retrocolor/`1',
'92`/``/Sfr Sauvegardes SIM/`1',
'93`/``/Sfr Sauvegardes/`1',
'94`/``/Securite Mobile/`1',
'94`/default`.*`/Securite Mobile/Home`1',
'95```/Conquete Fixe/Securite/Site/`1',
'96```Conquete Fixe/Securite/Site`1',
'97```Bourse`1',
'97`articles/show`.*`Bourse/Articles/Show`1',
'98```Bestof`1',
'98`selection/date`selection/date`Bestof/Categorie`1',
'98`service/fiche`service/fiche`Bestof/Application`1',
'99`webmail``visio mms texto voix`1',
'100```People`1',
'101```Jeunes Talents`1',
'102```Musique/`1',
'103`/``Shopping`1',
'104```Professionnels/Simulateur Pro/`1',
'105`football/article`.*`Sport/Football/Article`1',
'105`rugby/article`.*`Sport/Rugby/Article`1',
'105`auto-moto/article`.*`Sport/Auto Moto/Article`1',
'105`basket/article`.*`Sport/Basket/Article`1',
'105`autres-sport/article`.*`Sport/Autres Sports/Article`1',
'105`tennis/article`.*`Sport/Tennis/Article`1',
'105`golf/article`.*`Sport/Golf/Article`1',
'105`f1/article`.*`Sport/F1/Article`1',
'105`handball/article`.*`Sport/Handball/Article`1',
'105`autres-sports/article`.*`Sport/Autres Sports/Article`1',
'105```Sport`1',
'105`ski/article`.*`Sport/Ski/Article`1',
'105`sports-us/article`.*`Sport/Sports US/Article`1',
'106```Sport`1',
'106`HTML`HTML`Mini Site/Thematique/SFR Foot`1',
'106`direct_foot``Mini Site/Thematique/SFR Foot`1',
'107```Sport`1',
'108```TV Et Club Video/TV`1',
'109```/Conquete Fixe/Telephone Fixe/`1',
'110```Tonalites`1',
'111```Toolbar`1',
'112```/Trafic/`1',
'113```TV et Club Video/TV`1',
'113`/hitview``TV et Club Video/TV/Guide Tv`1',
'113`guide-tv`>2`TV Et Club Video/TV`1',
'114`/`.*`/Mon Compte/Mosaique TV`1',
'115```Femme/Videos`1',
'116```/TV et Club Video/Club video/Club Video PC/`1',
'117```/Conquete Fixe/VOD`1',
'118```/Mini Site/Thematique/SFR Golf`1',
'119``/p/getSubscriptions`Offre Mobile/Abonnement Multimedia`1',
'120`@``communiquer`1',
'120``.*`Messageries/Webmail/Nouveau`1',
'121`/``Mini Site/Moments Technos`1',
'122```/TV Et Club Video/TV/Mode emploi/`1',
'123```Mini Site/Jeux/SFR International`1',
'124```/Conquete Fibre Pro Immo/`1',
'125`/``/Live Concert/`1',
'126```/Mini Site/Netgem V5/`1',
'127`@tester-ma-ligne#``Red_Fixe_Bout`1',
'128```/Conquete Fixe/Securite/Site/`1',
'129```SFR com`1',
'130`Vos services`Vos services``1',
'130`Utiliser Mobile Box`Utiliser Mobile Box``1',
'130`/vos-services/`/vos-services/``1',
'130`/mobile/espace-sfr`/mobile/espace-sfr`/Mobile/Espace Sfr/Store locator/Home`1',
'130`vos-services/services-mobiles/`<2``1',
'130`iphone-4/`iphone-4/`Iphone 3g/`1',
'130`@telephonie-mobile/services-options/``Mob_Util`1',
'130`@adsl-fibre/services-options/``ADSL_Util`1',
'130`@television/services-options/``TV_Util`1',
'130`@cle3g-tablettes/services-options/``Netmob_Util`1',
'130`television/services-options/`<2``1',
'130`@television/``TV_Bout`1',
'130`@multi-packs/``Multipack_Bout`1',
'130`@telephonie-mobile/``Mob_Bout`1',
'130`@cle3g-tablettes/``IntMob_Bout`1',
'130`adsl-fibre/services-options/`<2``1',
'130`cle3g-tablettes/services-options/`<2``1',
'130`telephonie-mobile/services-options/`<2``1',
'130`@mon-espace-client/``espace_client`1',
'130`@vos-services/services-fixes-adsl/``ADSL_Util`1',
'130`/vos-services/services-fixes-adsl/`<2``1',
'130`@vos-services/services-mobiles/``Mob_Util`1',
'130`@vos-services/internet-partout/``Netmob_Util`1',
'130`/vos-services/internet-partout/`<2``1',
'130`/mon-espace-client/`<1``1',
'130`/espace-client/diagnostic-conseil`<1``1',
'130`concours-video/`=0`/Mini Site/Eyeka`1',
'130`/do/profile`/do/profile`Infos Perso/Profil`1',
'130`/info_nouveautes/actus_promos/astuces_du_mois```1',
'130`/mc-mobile`Mc Mobile/[^/]*``1',
'130`/mc-mobile/espace-client/mieux-utiliser-mon-mobile`Mc Mobile/[^/]*/[^/]*`Texto Mms Photo`1',
'130`/sfr_entreprises`/sfr_entreprises``1',
'130`Sfrtv`Sfrtv`Tv Video/Home`1',
'130`/sfrtv/products`Products/\(List\)*`Infos Mobile/Tv Mobile`1',
'130`/utiliser/services/jeux`/utiliser/services/jeux``1',
'130`/communiquer/messagerie`communiquer/messagerie`Communiquer/Messageries`1',
'130`webmessagerie``Texto Mms Photo`1',
'130`/espace-client/`/espace-client/``1',
'130`/evenements/``/Mini Site/Thematique/`1',
'130`jeux/`jeux``1',
'130`/mobile-adsl/sfr-sur-mesure/`Mobile Adsl/Sfr Sur Mesure/`Offre sur Mesure/Accueil-OSM`1',
'130`/index-sso-sfr-sur-mesure.jsp`Espace Client/Offre Mobile/Index Sso Sfr Sur Mesure`Mon Compte/Offre Mobile/Offre Sur Mesure/Accueil-OSM`1',
'130`/espace-client/mobile/repertoire-SIM/`/Espace Client/Mobile/Repertoire SIM/`Mon Compte/Mobile/Repertoire Sim`1',
'130`/mobile-adsl`/mobile-adsl``1',
'130`/mobile/`/mobile/`Conquete`1',
'130`acces/generique`.*`Authentification/Generique Clients Neuf Partenaire`1',
'130`/innovation/``/Mini Site/Thematique/`1',
'130`/mobile/espace-sfr/`/mobile/espace-sfr/`/Mobile/Espace Sfr/Store locator/`1',
'130`@telephonie-mobile-pro/``Mob_Bout`1',
'130`@multi-packs-pro/``Multipack_Bout`1',
'130`/espace-client/diagnostic-conseil-scdc`<1``1',
'130`espace-client/consulter-factures-mobile/consultation/getbilanconso#`.*`Conso Facture/Facture Sur Internet/Bilan Conso/Detail$`1',
'130`espace-client/consulter-factures-mobile/consultation/getsynthesebilanconso#`.*`Conso Facture/Facture Sur Internet/Bilan Conso/Synthese$`1',
'130`@parcours-securite/``espace_client`1',
'131`@``bt_transverse`1',
'132`@``cloud`1',
'132``.*`Mon activite`1',
'133```Jeunes Talents`1',
'134```En`1',
'135```Fr`1',
'136``/cgi-bin/sfrwifi.storefront/<ID>``1',
'137```SHD`1',
'138``sfr-blender`Sport/SFR Glisse/Zapping`1',
'139```/Vos MMS/`1']
var mStats_domains='.*[.]rmcsport[.]tv|123parametrez.services$|9giga$|accessoires-mobiles$|accessoires$|actualites$|adsite-under$|adsl$|android$|annuaires$|appliscope.m$|appliscope$|astralia$|astro.m$|astro$|atelier$|ateliers-espace$|avis$|bestof.m$|blog-securite$|blog$|boursier.m$|cadeaux$|carrerouge$|cartewifi$|choix.jeu-sfr.com|club-video$|clubvideo$|couleurs$|emploi$|espace-client$|etude.contact-sfr.com|fibre-optique$|forum$|futpsw$|gcppinf$|guide-tv$|guidestv-sfr.fr|hc$|homescope$|hubster$|import-contacts$|info.m$|info$|international.jeu-sfr.com|intranet.numericable.com|iphone-dev.promoslive.com|jeux-en-ligne$|jeux-iphone.m$|jeux-pc$|jeux-tv$|jeux.club-video$|jeux.m$|lafibresfr.fr|m.sfr.com|m$|message-visio$|meteo.m$|meteo$|mic-tv$|mobiles.boursier.com|moncompte-neufbox$|monintranet.mysfr.com|monprofil-lacarte$|monprofil$|mysfrv2|nb2$|neufboxevolution$|neuftalk$|neufwifi$|numericable.fr|pages-perso$|palm$|paris-hippiques-pmu$|paris-hippiques$|paris-sportifs$|passvodillimites$|persodumobile.services$|poker$|preferer4g$|preview-tv$|promoslive-sfr.services$|promoslive.m$|public.m$|public$|recrutement.sfr.com|recuperation-pagesperso$|recyclage-mobile$|rencontre-affinite$|rencontres$|retrocolor$|sauvegarde-sim$|sauvegardes$|securite-mobile$|securite-neufbox$|securite$|sfr-bourse.dev2.bkt.mobi|sfr-bow-v2.dev.bkt.mobi|sfr-messagerie.services$|sfr.public.fr|sfrjeunestalents.fr|sfrmusic.oxalide-test.com|shopping$|simulation.sfr.pro|sport.m$|sport$|sports$|static-tv$|telephone-fixe$|tonalites.services$|toolbar$|trafic$|tv$|video.wapsvp$|videos.elle$|vod-pc$|vod$|web.golfsfr.com|webcare$|webmail$|www.choix.jeu-sfr.com|www.guidestv-sfr.fr|www.international.jeu-sfr.com|www.lafibresfr.fr|www.live-concert$|www.nb2$|www.red-by-sfr.fr|www.securite-neufbox$|www.sfr.com|www$|www.sfrbusinessteam.fr|www.sfrcloud$|www.sfrjeunestalents.fr|www.sfrpay.com|www.sfrpay.fr|www.sfrwifiservice.com|www.shdnet.fr|www.u-koncept.com|www.vosmms.com'.replace(/\$/g,'.sfr.fr').split('|')
var _blackList='((portailsfr[.](espacesfr|distrib)|distrib-kara[.]espacesfr|kara)[.]sfr[.]fr|intra-(portailsfr|kara-direct)[.]sfr[.]com)`.*[.]0pb[.]org`localhost.*`moncompte-adsl.sfr.re`www.free.fr'
var mStats_params=[]
var mStats_rules=[
'*`^adsite-under/(.*)$`$1',
'*`^(c\\d{1,3})-[^/]*((/f\\d{1,3})-[^/]*)*((/t\\d+)-.*\\.htm|/?)$`$1$3$5',
'*`tv/(epg/)?b/([^/]*)/p/([^/]*)/d/([^/]*)/h/([^/]*)/epg.html`TV/EPG/Bouquet $2/Programmes/$3/$4 $5',
'*`tv/b/([^/]*)/p/([^/]*)/d/([^/]*)/h/([^/]*)/programs.html`TV/EPG/Bouquet $1/Chaines/$2/$3 $4',
'*`tv/bq/([178])-?([^/]*)/[^/]*/([^/]*)/.*`TV/EPG/Bouquet $3/Creneau $1/Page $2',
'*`/news/pwp-tv-news/`/news/Tri Dates/Page ',
'*`^perso/u/([^/]*)/([^/]*)\.html$`perso/$2/$1',
'*`/a/(pwp-musique-(news|flash-info|videos)/)?`/Articles/',
'*`pwp-[^/]*-top(read|view)s/`Tri Vus/Page ',
'*`pwp-news-filinfo-[^\\-]*-topcomments/`Tri Reactions/Page ',
'*`pwp-(musique-(news|flash-info|videos)|news-filinfo-[^/]*)/`Tri Dates/Page ',
'*`/cm/`/Commentaires/',
'*`(^home/u/|/[a-zA-Z]/|/urn:pwpid:)`/',
'*`^(.*)\.(php[345]?|jspe?|html?|dml|aspx?|exe|do|action)$`$1',
'*`^(.*/)?(index)?$`$1Home',
'*`^(.*/)?(do/|servlet/|private/|v5/|cgi-bin/)(.*)$`$1$3',
'*`(-|,|_|%5F|%20|%2D)` ']
function trm(s){return(s!=null)?(""+s).replace(/(^\s+|\s+$)/g,""):""}
function mef(s){
var m=1,t=""
if(typeof _stats_accent!='undefined'){try{s=decodeURIComponent(s)}catch(e){}}
s=s.replace(/%20/g," ").replace(/[\s_\+]+/g," ").replace(/ ?(\/)+ ?/g,"/").replace(/[ \/]+$/,"")
for(var i=0;i<s.length;i++){
var c=s.charAt(i)
if(m)c=c.toUpperCase()
t+=c
m=c==" "||c=="/"}
return t}
function spl(c,s){return c.split&&c.split(s||'`')||''}
function stat_get_product(c,l,q,p){var t=function(s){return trm(s).replace(/[,;]/g,'.')};return t(c)+";"+t(l)+";"+t(q)+";"+t(p)}
function stat_evt_purchase(i,p,e){s.purchaseID=trm(i);s.products=p.join(",");s.events="purchase"+(e?","+e:"")}
function stat_evt(e,p){s.events=trm(e);if(p)s.products=typeof p=="object"?p.join(","):p}
function stat_link(){stats({pn:s.pageName})}
function wt_link(l){var s=s_gi(s_account);s_tl(this,'o',l)}
function s_t(){s_p();s.t()}
function s_tl(t,o,l,v,f){s_p(0,l);s.tl(t,o,l,v,f);return!1}
function s_v(v){var t=typeof s[v];return t=='undefined'?'':t=='object'?s[v][0]:s[v]}
function s_p(c,p){return _eT.EV&&_eT.EV(c,p)||!0}
function stat_dom(h){
var b=spl(_blackList),d=mStats_domains,k
if(h=='cms.sfr.fr')h='www.sfr.fr'
for(k=0;k<b.length;k++)if(RegExp('^'+b[k]+'$').test(h))return 0
for(k in d)if(RegExp('^'+d[k]+'$').test(h))return 1*k+1
if(!_urMap['*'])return 0
return d.length+1}
function stat_uni(u,uni){
var e=spl(u.replace(/^https?:\/\/([^\/]+)\/?(adsite-under\/)?(.*)$/,"$1`$3")),d=stat_dom(e[0]),t='@'+e[1],l=-1,f,v=!uni||!_urMap[uni],m=mStats_subservices
for(i in m){
var A=spl(m[i]),p=A[1]
if(!A||A[0]!=d||p.charAt(0)!='@')continue
if(f=p.match(/#$/))p=p.replace(/#$/,"")
if((f||v)&&p.length>l&&!t.indexOf(p)){l=p.length;uni=A[3]}}
return uni&&_urMap[uni]?uni:"transverse"}
function stat_rep(t,o){
var q=o.charAt(0),n=1*(o+"0").charAt(1)
if(q=='=')t=stat_sup(t,n,n)
if(q=='<')t=stat_sup(t,0,n-1)
if(q=='>')t=stat_sup(t,n+1,99)
if(o=o.substring(2))t=stat_rep(t,o)
return t}
function stat_sup(t,d,f){
var R=spl(t,'/'),s=''
for(var i=0;i<R.length;i++)if(i<d||i>f)s+=R[i]+'/'
return s.substring(0,s.length-1)}
function stats(o){
var	W=window,D=document,_=_eT,pn=trm(W._stats_pagename),m=mStats_subservices,Z=W.zvars||[],ckR=_.ckR,ckW=_.ckW,par=_.par,
A,i,r,v,hi,did=0,sid=0,l=-1,u=(W._stats_url||D.URL).replace(/\/adsite-under/,''),
a=u.indexOf("://")+3;if(a<3)return
var d=(u+"#").indexOf("#"),b=u.indexOf("/",a);if(b<0)b=d
var c=u.indexOf("?",b);if(c<0)c=d
var h=u.substring(a,b),t=u.substring(b+1,c<d?c:d);if(!h)return
if(!W.s||!s.t)s=_.s
if(typeof o=='object'){
if(o.pn)pn=trm(o.pn)
if(o.ev)Z["events"]=s.events=o.ev==9?'':trm(o.ev)
if(o.v)_stats_vars=o.v}
did=stat_dom(h);if(!did)return
for(i in W._stats_vars)Z[i]=_stats_vars[i]
for(i in W.stat_pvars)if(29<i&&i<76)Z["prop"+i]=stat_pvars[i];else if(i=="pageName")pn=stat_pvars[i]
for(i in W.stat_evars)if(29<i&&i<76)Z["eVar"+i]=stat_evars[i]
t=t.replace(/(;|%3b)jsessionid=(.*)/i,'')
for(i in m){
A=spl(m[i])
if(A[0]!=did)continue
v=A[1].replace(/#$/,"")
if(v.charAt(0)=='/')v=v.substring(1)
if(v.length>l&&t.indexOf(v)==0){l=v.length;sid=1*i+1}}
for(i in mStats_rules){
A=spl(mStats_rules[i])
if(A[0]=="*"||A[0]==sid){
t=t.replace(new RegExp(A[1],"g"),A[2])
if(r=A[3])t.replace(new RegExp(r,"g"),"")}}
t=t.replace(/^\//,"")
if(sid){
A=spl(m[sid-1])
if(A[2]){
A[2]=A[2].replace(/<ID>/,"[a-zA-Z0-9]{0,32}")
v=A[2].charAt(0)
if(v==">"||v=="<"||v=="=")t=stat_rep(t,A[2])
else{
if(v=="/")A[2]=A[2].substring(1)
A[2]=A[2].replace(new RegExp("(-|_)")," ")
t=t.replace(new RegExp(A[2],"g"),"")}}
if(A[3])t=A[3].charAt(A[3].length-1)=='$'?A[3].substring(0,A[3].length-1)+pn+t:A[3]+"/"+t
if(A[1].match(/#$/))pn=0}
t=t.replace(/^\//,"")
i=t.indexOf("/")
if(i>0&&t.substring(0,i).toUpperCase()==s_univers.toUpperCase())t=t.substring(i+1)
v=s_univers+"/"
if(v.indexOf("Web/")&&v.indexOf("Mobile/"))v="Web/"+v
t=v+t
if(pn)t=!pn.indexOf("Web/")||!v.indexOf("Mobile/")&&!pn.indexOf("Mobile/")?pn:v+pn
if(D.URL.match(/\/adsite-under/))t=t.replace(/^(Web|Mobile)(.*)$/,"$1/Site Under$2")
if(/Authentification/.test(t)&&D.getElementsByClassName('g-recaptcha')[0])t+='/CAPTCHA'
t=mef(t)
if(_.pro)t=t.replace(/^([^\/]+\/[^\/]+\/[^\/]+\/)/,"$1Pro/")
Z["server"]=h
Z['pageName']=t
Z["eVar29"]="D=pageName"
Z["hier1"]=t.substring(0,t.lastIndexOf("/"))
if(/\bA_Reengager\b/.test(ckR('eTc2ol')))Z[15]='C2OL'
Z['prop17']=pn?2:1
if(/^Zive$/.test(W._stats_univers))Z['prop25']=_.mob()?'mobile':'desktop'
Z["prop27"]=u.match(/^https/i)?"HTTPS":"HTTP"
Z["prop12"]=par('[Rrs][ef][dr]clicid')||ckR(v='sfrclicid');_.ckD(v)
A=spl(t,'/')
Z['channel']=A[1]
Z['prop1']=v=A[1]+":"+A[2]
Z['eVar11']="D=c1"
if(A[3]){Z['prop2']=A[1]+":"+A[2]+":"+A[3];Z['eVar12']="D=c2"}
if(A[4])Z[53]=A[1]+":"+A[2]+":"+A[3]+":"+A[4]
Z["eVar7"]=''
if(!v.match(/Survey|Authent/)){
c=ckR('eTagUI')||'>#'
if(A[1]=='Mon Compte')v=A[1]
if(A[1]=='HomePages')v=A[1]+":"+A[3]
if(A[2]=='Boutique'||v=='HomePages:Accueil')v='BOL'
if(A[3]=='Espace SFR')v='Store Locator'
v=v.replace(/[#>]/,'')
c=c.replace('>'+v+'>','>').replace(/#$/,v+'>#')
while(c.replace(/[^>]/g,'').length>5)c=c.substring(c.indexOf('>',1))
if(c!=ckR('eTagUI'))ckW('eTagUI='+(Z["eVar7"]=c),4)}
Z["eVar28"]=(c=ckR('evar28'))?c:"refus_cookie"
A=D.cookie.match(/eTab(RE|CC|W|[A-Za-z0-9]{3})=./g)
for(i=0,v="|";A&&i<A.length;i++)v+=A[i].replace('=','-').replace(/^eTab/,'')+"|"
Z[55]=v
Z[63]=ckR("bonsPlansSFR")
Z[70]=ckR("sfrHome")
Z[71]=ckR("sfrBox")
Z["prop73"]=u.replace(/[?#].*/,'')
if(typeof _eTag=='object'){v="";for(i in _eTag)if(typeof _eTag[i]=='string')v+=i+" ";Z["prop65"]=v}
if(Z["eVar38"])Z["eVar48"]=Z["eVar38"]
if((v=W._eTag)&&(v=v["ProspectMsisdn"]))Z["prop71"]=v
if(v=_.login)Z['prop72']=v,Z['eVar76']='D=c72'
if(v=W._stats_xnokiagid)Z["prop30"]=v
Z["prop33"]=navigator.userAgent.replace(/[ :;\/]+/g,'_')
if(v=W._stats_famillepwp)Z["prop34"]=v
v=Z["eVar4"]||""
if(typeof _stats_lignes=="object"){
c=_stats_lignes[unescape(ckR('MLS'))]
if(c&&c[1])v=c[0]}
Z[20]=v
v=Z[19]||""
if(v.match(/[JK]/)&&v.indexOf(' M')>0){
Z[18]=v.replace(/.* (M[^ ]*).*/,"$1")
Z[19]=v.replace(/([^ ]*) (M[^ ]*)( .*)?/,"$2 $1$3")
Z[6]=Z[6].replace(/([^ ]*) (M[^ ]*)( .*)?/,"$2 $1$3")}
for(i in Z){v=Z[i];if(i>0){s["prop"+i]=v;s["eVar"+i]=v.length>5?"D=c"+i:v}else if(v)s[i]=v}
v=['prop18','eVar18','prop19','eVar19']
for(i=0;i<v.length;i++)if(s[v[i]])s[v[i]]=s[v[i]].replace("t","H").replace("x","N")
if(typeof s.zip=='function')s.zip=null
i=s.events
if(v=W._stats_events)i=i?i+","+v:v
if(/prodView/.test(i)&&!/event14/.test(i))i+=",event14"
s.events=i
i=s.products;if(v=W._stats_products)s.products=i?i+","+v:v
if(ckR("authent")!=(c=s.prop10+"_"+s.eVar4)&&s.prop10=="2"){
s.events=(s.events?s.events+",":"")+"event16"
s.eVar9="Authentification reussie : RememberMe "+(ckR("rmeh")||ckR("rme")?"":"non ")+"demande"}
ckW("authent="+c)
s.purchaseID=s.purchaseID||s.prop57
s.campaign=par("[RrSs][ef][dr]cpid")
s.eVar3=o&&o.si||par("[RrSs][ef][dr]intid")
s.eVar37=''
s.eVar80=_.cc||0
_.cc&2||(s.prop36='')
if((i=s.pageName.match(/Layer Detail Offre.Poffer.GP.CARRE.(.*)/))&&(W.sP||(sP=s.products)))s.products=sP.match(new RegExp('(;'+i[1].replace(/ /g,'_')+'[^,]*)'))[1]||''
if(t=s.t())D.write(t)
s_p()
t=_.elr;if(t&&_.T('@/forfait-mobile/(offres/detail|telephone)/')&&_.sent)t([1])
}
function sVideoPlay(n,o){if(n){
if(!sVideos[n]){
stats({ev:"event60",v:{66:n}})
sVideos[n]={obj:o,dur:-1,vis:0}}
sVideos[n].to=setTimeout("sVideoHit('"+n+"')",999)}}
function sVideoStop(n){if(n&&sVideos[n]&&sVideos[n].to)clearTimeout(sVideos[n].to)}
function sVideoHit(n){
var sV=sVideos[n]
if(sV.dur<0){sV.dur=Math.floor(sV.obj.getDuration());sV.p1=Math.round(sV.dur/2);}
if(++sV.vis==sV.p1)stats({ev:"event61",v:{66:n}})
if(sV.vis==sV.dur)stats({ev:"event62",v:{66:n}})
else sV.to=setTimeout("sVideoHit('"+n+"')",999)}
(function(W,a,u,l){
sVideos=[]
a=trm(W._stats_account)
u=trm(W._stats_univers)
l=trm(W._stats_url)
if(!u||!_urMap[u])u=trm(W.univers)
u=spl(_urMap[stat_uni(l?l:document.URL,u)])
s_account=a?a:(u[2]?"":s_account+",")+u[1]
s_univers=u[0]})(window)
var s_cpType=""
function s_getChannel(u){
var	cpT="|SEA marque generique|Epub Acquisition|Affiliation|Comparateur|Email conquete|Email client mobile|Kit connexion|Email client Trigger|Partenaire|Mini Boutique|Email autre client|Email client ADSL|Email client cross sell|Communautaire|Referencement payant contenus|Email base business Team|Innovation yahoo|Email prospect Trigger|Reseaux sociaux|Email gestion|Alerte SMS|Epub retargeting|Epub mobile|Video|Email Retargeting|Portail Mobile|Appli SFR|SEO Redirect MSFR|SMS client|SMS alerte contenu|SMS gestion|Rebond Appli|Affiliation site under|SEA marque|SEA hors marque|Epub trade|Epub brand|Partenaire ACN|Email ePropal|Numericable|Google My Business|Virgin Mobile|Appli RED|Epub CRM|SMS acquisition",
cpS="abdbif=abandon biz|abdbol=prospect bol|abdrela=abandon rela|access+oire|acc+ueil|accueil=Page accueil|adsl^|adslb=ADSL Branding|adslr=ADSL ROI|amf^|app+le|appli=Appli SFR|as=alerte stock|ass=portail assistance|atel+ier SFR|atelb<ier branding|appec=Appli Mon Compte|autres=Autres Moteurs|bol<utique en ligne|bolmd=BOL en MD|chain+e|cler< ROI|cm=community management|comkt=comarket|corp+orate|data+ entreprise|dm=dailymotion|ec=Portail Espace Client|espsfr=Espace Sfr|event<ementiel|fb=facebook|fbk=facebook|fbmobr=facebook Mobile ROI|fc=Flashcode|genmob=Generique mobile|gest+ion|gestedatis=gestion|glf=Galerie Lafayette|hbs=Home by SFR|htc^|inter=International|jeu+x|jeunestal=Jeunes talents|jeuntal=Jeunes talents|jt=Jeunes talents|key+worder|live+concert|marq+ue|md^|meteo=Portail meteo|minbz=MinuteBuzz|micro+soft|mob+ile|mobguide=mobile|mobr<ile ROI|nat+urel|netperf=Netperf|nl^|nlamf=NL AMF|nlinfo=NL SFR info|nlinnov=NL innovation|nlmag=NL minimag SFR|nlminimag=NL minimag SFR|nlstudio=NL Le studio SFR|nsj=sur Mobile|pacte=Le Pacte SFR|parcn< neuf|partner=partenaire|pe=plateforme Externe|pj=pages Jaunes|portail+ SFR|print+|prosp+ection|rbd=Rebond|regie+ SFR|rela+tionnel|rev+eil|rex=Experience client|secu+rite|sfrbt=SFR BT|shzm=Shazam|sitemtv=site MTV|tele2< 2|testao=test appel offre|tgr=trigger|tgrjeu=trigger jeux|TouchClarity=Touch Clarity|trans+verse|tv^|twit+ter|umpc^|umpcb=UMPC branding|upload=Telechargement|vadsl=video sur ADSL|vir+al|vod^|xadsl=cross sell ADSL vers Mobile|xbi=cross sell bi equipe vers Mobile|xmob=cross sell Mobile vers ADSL|yt=youtube|zic=musique"
var	m=u.match(/[?#&](sfr|red)cpid=([^#&]*)/i),
v=t=m?m[2]:"",
e=t.replace(/^t([0-9]+)_?([^_]*).*$/,"$1|$2").split("|"),
c=cpT.split("|")
s_cpid=v
if(e[0]>0&&c[e[0]]){
v=e[1].toLowerCase()
var d=cpS.split("|"),l=v.length
for(var n=0;n<d.length;n++) if(d[n].substring(0,l)==v){
var a=d[n].charAt(l),r=d[n].substring(l+1)
if("=+<^".indexOf(a)<0) continue
v=a=='='?r:a=='+'?v+r:a=='<'?v.substring(0,l-1)+r:a=='^'?v.toUpperCase():v
v=v.charAt(0).toUpperCase()+v.substring(1)
break}
v=c[e[0]]+" "+v
s_cpType=c[e[0]]}
return t?v+"|"+t:""}
/* SiteCatalyst code version: H.25.4 (avr13)
Copyright 1996-2013 Adobe, Inc. All Rights Reserved
More info available at http://www.omniture.com */
var s=s_gi(s_account)
s.charSet="ISO-8859-1"
s.currencyCode="EUR"
s.trackDownloadLinks=true
s.trackExternalLinks=false
s.trackInlineStats=true
s.linkDownloadFileTypes="exe,zip,wav,mp3,mov,mpg,avi,wmv,pdf,doc,docx,xls,xlsx,ppt,pptx,dmg"
s.linkInternalFilters="javascript:,espacesfr.com,sfr.fr,sd-sfr.fr,sfrjeunestalents.fr,vosmms.com,sfrmmspage.fr,jeu-sfr.com,offres.neuf.fr,lepactesfr.fr,sfr.tv,contact-sfr.com,sfr.aol.fr,sfrfoot.fr,sfrliveconcerts.fr,sfrgolf.fr,sfr-recherchet-m56.aol.fr,sfrdev.fr,sfr.odr.fr,sfrjt.anicet,sfr-recherchet-stage.aol.fr,sfrjt.local,jeu-sfr.net,sfr-minimag.fr,sfr-serviceclient.com,sfr-forum.local,sfrrecurrente2-45.dev,golfsfr.com,bienvenuechezsfr.com,sfrgolf.com,neufmusic.fr,neuf.fr,traffic.outbrain.com,office3d.sips-atos.com,les-series-red-de-sfr.fr,cestdanslabox.fr,slimpay.net"
s.linkLeaveQueryString=false
s.linkTrackVars="None"
s.linkTrackEvents="None"
s.forcedLinkTrackingTimeout=500
s._extraSearchEngines=""
s._channelDomain=""
s._channelParameter=""
s._channelPattern=s_getChannel(document.URL)
s.ActionDepthTest=true
s.usePlugins=true
function s_doPlugins(s){
if(window.Kameleoon){Kameleoon.processOmniture(s);s.prop74=s.eVar63?s.eVar63:'Vide'}
var urlTmp=window.location.href
if(urlTmp.indexOf('#',0)>0){
s.pageURL=urlTmp.substring(0,urlTmp.indexOf('#',0))+"&"+urlTmp.substring(urlTmp.indexOf('#',0)+1,urlTmp.length)
if(s.pageURL.indexOf('?',0)==-1) s.pageURL=s.pageURL.substring(0,s.pageURL.indexOf('&',0))+"?"+s.pageURL.substring(s.pageURL.indexOf('&',0)+1,s.pageURL.length)
}else s.pageURL=urlTmp
if(s.getQueryParam('s_kwcid')) s.pageURL=s.manageQueryParam('s_kwcid',1,1)
if(s.ActionDepthTest){
s.pdvalue=s.getActionDepth("s_depth")
if(s.pdvalue==1){
s.events=s.apl(s.events,'event45',',',2)
if(!s.eVar45&&!s.prop40) s.eVar45=s.prop40="D=pageName"}
if(s.pdvalue==2) s.events=s.apl(s.events,'event46',',',2)
s.ActionDepthTest=false}
s.events=s.apl(s.events,'event47',',',2)
s.prop41=s.getPreviousValue(s.pageName,'gpv_p41','')
if(s.prop41) s.eVar47="D=c41"
if(!s.campaign) s.campaign=s.getQueryParam('sfrcpid')
s.campaign=s.getValOnce(s.campaign,'sfrcpid',0)
if(!s.eVar3) s.eVar3=s.getQueryParam('sfrintid')
s.eVar3=s.getValOnce(s.eVar3,'sfrintid',0)
if(s.eVar3) s.prop50="D=v3"
if(s.prop3) s.prop3=s.prop3.toLowerCase()
if(s.prop3){
s.eVar2="D=c3"
var t_search=s.getValOnce(s.eVar2,'ev2',0)
if(t_search) s.events=s.apl(s.events,'event1',',',1)}
if((s.events.indexOf('purchase',0)>-1)&&s.eVar46){
if((s.eVar46.indexOf('Bol:',0)>-1)&&(s.eVar46.indexOf('Migration',0)>-1)) s.events=s.apl(s.events,"event51",",",2)
else{
if(s.eVar46=='Bol:RM') s.events=s.apl(s.events,"event48",",",2)
if((s.eVar46=='Bol:Conquete')||(s.eVar46=='Bol:MID PC')||(s.eVar46=='Bol:CLE 3G')) s.events=s.apl(s.events,"event49",",",2)
if((s.eVar46=='Bol:Signup ADSL')||(s.eVar46=='BOL:SHD')||(s.eVar46=='Bol:Signup FIBRE')) s.events=s.apl(s.events,"event50",",",2)}}
s.getPPVCalc()
s.prop51=s.getPercentPageViewed()
var url=s.linkHandler('betclic.fr|membres.fdj.fr|zeturf.fr|pagesjaunes.fr|keljob.com|facebook.com|youtube.com|dailymotion.com|twitter.com|leguide.com|cetelem.fr|boursorama.com|priceminister.com|lesoffrescanal.fr|fortuneo.fr|ebay.fr','e')
if(url){
s.prop49=url
s.linkTrackVars='prop49'}
var	r=(s.referrer||document.referrer||'').toLowerCase(),
m=r.match(/\/\/(([^\/]*\.)?([^\/.]+\.[^\/.]+))\//),
h=m?m[1]:'',d=m?m[3]:'',
v=',',di=v+s.linkInternalFilters+v
m=0
if(s_cpid||r&&d&&di.indexOf(v+h+v)<0&&di.indexOf(v+d+v)<0){
var se={'q':'aol|bing|google','p':'yahoo'},seo=0
for(var p in se){
if(r.match(new RegExp('[^/]*//([^/]+\\.)?('+se[p]+')\\.[^?]*/'))) m=r.match(new RegExp('[?&]'+p+'=([^&#]*)'))}
if(m!=0)seo="SEO Inconnu"
if(m&&m[1])seo=unescape(m[1]).match(/sfr|neuf|cegetel|\bcarr(e\b|\xe9)|\b(9\D?(gigas?|online)|club\W?internet|red)\b/)?"SEO Marque":"SEO Hors Marque"
var a=h.match(/messagerie|mail/)?"Webmail":r?"Autres sites":"",c=s._channelPattern
s.eVar57=s_cpType||(s_cpid?"Non reconnue":seo?"SEO":a)
s.eVar56=(c?c.substring(0,(c+'|').indexOf('|')):s_cpid.replace(/^([^_]+_[^_]+).*/,"$1"))||seo||a
s.eVar58=s_cpid||seo||a}
if(window._eT){
_eT.ckD('ext_ref')
if(m)_eT.KW=m[1]
var lv=_eT.ckR('eTagLV')*6e4,ts=new Date().getTime(),n=ts/864e5|0,m=n-30,j=(ts-lv)/864e5|0,cvp=function(k,e){
var vo=_eT.ckR(k),A,r='',v='',l='',j=0
if(e)vo=(vo?vo+'|':'')+n+':'+e.replace(/ /g,'+')
A=vo.split('|')
if(vo)for(var i=A.length-1;i>-1;i--){
var I=A[i].split(':')
if(I[0]<m||I[1]==l||j>9) e=1
else{
j++
v='|'+I[0]+':'+I[1]+v
r='>'+I[1].replace(/\+/g,' ')+r}
l=I[1]}
if(e){
_eT.ckW(k+"="+v.substring(1),720)
return r?r.substring(1):'N/A'}
return ''}
if(j>0)s['eVar1'+(/red-by-sfr.fr$/.test(location.host)?7:6)]=lv?j:'X'
s.eVar59=cvp('s_cmCat',s.eVar57)
s.eVar60=cvp('s_cmDet',s.eVar58)
if(s.eVar56)s.eVar39=s.eVar40=s.eVar56
else if(r==''){
if(lv<ts-36e5)s.eVar39="Tape/Marque"
if(lv<ts-288e5)s.eVar40="Tape/Marque"}
s.eVar50=cvp('s_cmCT',s.prop64=s.eVar58||(ts<lv+18e5?'':r&&ts<lv+864e5?_eT.ckR('s_cmCT').replace(/^.*:/,''):"Tape/Marque"))
_eT.ckW('eTagLV='+(ts/6e4|0),9504)}
s.plugins=""}
s.doPlugins=s_doPlugins
s.repl=new Function("x","o","n","var i=x.indexOf(o),l=n.length;while(x&&i>=0){x=x.substring(0,i)+n+x.substring(i+o.length);i=x.indexOf(o,i+l)}return x");
s.getQueryParam=new Function("p","d","u","h","var s=this,v='',i,j,t;d=d?d:'';u=u?u:(s.pageURL?s.pageURL:s.wd.location);if(u=='f')u=s.gtfs().location;while(p){i=p.indexOf(',');i=i<0?p.length:i;t=s.p_gpv(p.substring(0,i),u+'',h);if(t){t=t.indexOf('#')>-1?t.substring(0,t.indexOf('#')):t;}if(t)v+=v?d+t:t;p=p.substring(i==p.length?i:i+1)}return v");
s.p_gpv=new Function("k","u","h","var s=this,v='',q;j=h==1?'#':'?';i=u.indexOf(j);if(k&&i>-1){q=u.substring(i+1);v=s.pt(q,'&','p_gvf',k)}return v");
s.p_gvf=new Function("t","k","if(t){var s=this,i=t.indexOf('='),p=i<0?t:t.substring(0,i),v=i<0?'True':t.substring(i+1);if(p.toLowerCase()==k.toLowerCase())return s.epa(v)}return''");
s.getValOnce=new Function("v","c","e","var s=this,a=new Date,v=v?v:v='',c=c?c:c='s_gvo',e=e?e:0,k=s.c_r(c);if(v){a.setTime(a.getTime()+e*86400000);s.c_w(c,v,e?a:0);}return v==k?'':v");
s.split=new Function("l","d","var i,x=0,a=new Array;while(l){i=l.indexOf(d);i=i>-1?i:l.length;a[x++]=l.substring(0,i);l=l.substring(i+d.length);}return a");
s.apl=new Function("L","v","d","u","var s=this,m=0;if(!L)L='';if(u){var i,n,a=s.split(L,d);for(i=0;i<a.length;i++){n=a[i];m=m||(u==1?(n==v):(n.toLowerCase()==v.toLowerCase()));}}if(!m)L=L?L+d+v:v;return L");
s.getAndPersistValue=new Function("v","c","e","var s=this,a=new Date;e=e?e:0;a.setTime(a.getTime()+e*86400000);if(v)s.c_w(c,v,e?a:0);return s.c_r(c);");
s.crossVisitParticipation=new Function("v","cn","ex","ct","dl","ev","dv","var s=this,ce;if(typeof(dv)==='undefined')dv=0;if(s.events&&ev){var ay=s.split(ev,',');var ea=s.split(s.events,',');for(var u=0;u<ay.length;u++){for(var x=0;x<ea.length;x++){if(ay[u]==ea[x]){ce=1;}}}}if(!v||v==''){if(ce){s.c_w(cn,'');return'';}else return'';}v=escape(v);var arry=new Array(),a=new Array(),c=s.c_r(cn),g=0,h=new Array();if(c&&c!=''){arry=s.split(c,'],[');for(q=0;q<arry.length;q++){z=arry[q];z=s.repl(z,'[','');z=s.repl(z,']','');z=s.repl(z,'\\'','');arry[q]=s.split(z,',')}}var e=new Date();e.setFullYear(e.getFullYear()+5);if(dv==0&&arry.length>0&&arry[arry.length-1][0]==v)arry[arry.length-1]=[v,new Date().getTime()];else arry[arry.length]=[v,new Date().getTime()];var start=arry.length-ct<0?0:arry.length-ct;var td=new Date();for(var x=start;x<arry.length;x++){var diff=Math.round((td.getTime()-arry[x][1])/86400000);if(diff<ex){h[g]=unescape(arry[x][0]);a[g]=[arry[x][0],arry[x][1]];g++;}}var data=s.join(a,{delim:',',front:'[',back:']',wrap:'\\''});s.c_w(cn,data,e);var r=s.join(h,{delim:dl});if(ce)s.c_w(cn,'');return r;");
s.join = new Function("v","p","var s = this;var f,b,d,w;if(p){f=p.front?p.front:'';b=p.back?p.back:'';d=p.delim?p.delim:'';w=p.wrap?p.wrap:'';}var str='';for(var x=0;x<v.length;x++){if(typeof(v[x])=='object' )str+=s.join( v[x],p);else str+=w+v[x]+w;if(x<v.length-1)str+=d;}return f+str+b;");
s.manageQueryParam=new Function("p","w","e","u","var s=this,x,y,i,qs,qp,qv,f,b;u=u?u:(s.pageURL?s.pageURL:''+s.wd.location);u=u=='f'?''+s.gtfs().location:u+'';x=u.indexOf('?');qs=x>-1?u.substring(x,u.length):'';u=x>-1?u.substring(0,x):u;x=qs.indexOf('?'+p+'=');if(x>-1){y=qs.indexOf('&');f='';if(y>-1){qp=qs.substring(x+1,y);b=qs.substring(y+1,qs.length);}else{qp=qs.substring(1,qs.length);b='';}}else{x=qs.indexOf('&'+p+'=');if(x>-1){f=qs.substring(1,x);b=qs.substring(x+1,qs.length);y=b.indexOf('&');if(y>-1){qp=b.substring(0,y);b=b.substring(y,b.length);}else{qp=b;b='';}}}if(e&&qp){y=qp.indexOf('=');qv=y>-1?qp.substring(y+1,qp.length):'';var eui=0;while(qv.indexOf('%25')>-1){qv=unescape(qv);eui++;if(eui==10)break;}qv=s.rep(qv,'+',' ');qv=escape(qv);qv=s.rep(qv,'%25','%');qv=s.rep(qv,'%7C','|');qv=s.rep(qv,'%7c','|');qp=qp.substring(0,y+1)+qv;}if(w&&qp){if(f)qs='?'+qp+'&'+f+b;else if(b)qs='?'+qp+'&'+b;else qs='?'+qp}else if(f)qs='?'+f+'&'+qp+b;else if(b)qs='?'+qp+'&'+b;else if(qp)qs='?'+qp;return u+qs;");
s.getActionDepth=new Function("c","var s=this,v=1,t=new Date;t.setTime(t.getTime()+1800000);if(!s.c_r(c)){v=1}if(s.c_r(c)){v=s.c_r(c);v++}if(!s.c_w(c,v,t)){s.c_w(c,v,0)}return v;");
s.getPreviousValue=new Function("v","c","el","var s=this,t=new Date,i,j,r='';t.setTime(t.getTime()+1800000);if(el){if(s.events){i=s.split(el,',');j=s.split(s.events,',');for(x in i){for(y in j){if(i[x]==j[y]){if(s.c_r(c)) r=s.c_r(c);v?s.c_w(c,v,t):s.c_w(c,'no value',t);return r}}}}}else{if(s.c_r(c)) r=s.c_r(c);v?s.c_w(c,v,t):s.c_w(c,'no value',t);return r}");
s.getPercentPageViewed=new Function("","var s=this;if(typeof(s.linkType)=='undefined'||s.linkType=='e'){var v=s.c_r('s_ppv');s.c_w('s_ppv',0);return v;}");
s.getPPVCalc=new Function("","var s=s_c_il["+s._in+"],b=s.d.body,e=s.d.documentElement,dh=Math.max(b?b.scrollHeight:0,e?e.scrollHeight:0,b?b.offsetHeight:0,e?e.offsetHeight:0,b?b.clientHeight:0,e?e.clientHeight:0),vph=s.wd.innerHeight||e&&e.clientHeight||b&&b.clientHeight,st=s.wd.pageYOffset||(s.wd.document.documentElement.scrollTop||(s.wd.document.body&&s.wd.document.body)?s.wd.document.body.scrollTop:0),vh=st+vph,pv=Math.round(vh/dh*100),cp=s.c_r('s_ppv');if(pv>100){s.c_w('s_ppv','');}else if(pv>cp){s.c_w('s_ppv',pv);}");
s.getPPVSetup=new Function("","var s=this;if(s.wd.addEventListener){s.wd.addEventListener('load',s.getPPVCalc,false);s.wd.addEventListener('scroll',s.getPPVCalc,false);s.wd.addEventListener('resize',s.getPPVCalc,false);}else if(s.wd.attachEvent){s.wd.attachEvent('onload',s.getPPVCalc);s.wd.attachEvent('onscroll',s.getPPVCalc);s.wd.attachEvent('onresize',s.getPPVCalc);}");
s.getPPVSetup();
s.linkHandler=new Function("p","t","e","var s=this,o=s.p_gh(),h=o.href,i,l;t=t?t:'o';if(!h||(s.linkType&&(h||s.linkName)))return'';i=h.indexOf('?');h=s.linkLeaveQueryString||i<0?h:h.substring(0,i);l=s.pt(p,'|','p_gn',h.toLowerCase());if(l){s.linkName=l=='[['?'':l;s.linkType=t;return e?o:h;}return'';");
s.p_gh=new Function("","var s=this;if(!s.eo&&!s.lnk)return'';var o=s.eo?s.eo:s.lnk,y=s.ot(o),n=s.oid(o),x=o.s_oidt;if(s.eo&&o==s.eo){while(o&&!n&&y!='BODY'){o=o.parentElement?o.parentElement:o.parentNode;if(!o)return'';y=s.ot(o);n=s.oid(o);x=o.s_oidt;}}return o?o:'';");
s.p_gn=new Function("t","h","var i=t?t.indexOf('~'):-1,n,x;if(t&&h){n=i<0?'':t.substring(0,i);x=t.substring(i+1);if(h.indexOf(x.toLowerCase())>-1)return n?n:'[[';}return 0;");
s.visitorNamespace="sfr"
s.trackingServer="metrics"+(typeof _stats_zf=='number'&&_stats_zf?"zf":"")+".sfr.fr"
s.trackingServerSecure="s"+s.trackingServer
s.visitorMigrationKey="4CCBEF5D"
s.visitorMigrationServer="sfr.122.2o7.net"
var s_code='',s_objectID;function s_gi(un,pg,ss){var c="s.version='H.25.4';s.an=s_an;s.logDebug=function(m){var s=this,tcf=new Function('var e;try{console.log(\"'+s.rep(s.rep(s.rep(m,\"\\\\\",\"\\\\\\\\\"),\"\\n\",\"\\\\n\"),\"\\\"\",\"\\\\\\\"\")+'\");}catch(e){}');tcf()};s.cls=function(x,c){var i,y='';if(!c)c=this.an;for(i=0;i<x.length;i++){n=x.substring(i,i+1);if(c.indexOf(n)>=0)y+=n}return y};s.fl=function(x,l){return x?(''+x).substring(0,l):x};s.co=function(o){return o};s.num=function(x){x=''+x;for(var p=0;p<x.length;p++)if(('0123456789').indexOf(x.substring(p,p+1))<0)return 0;return 1};s.rep=s_rep;s.sp=s_sp;s.jn=s_jn;s.ape=function(x){var s=this,h='0123456789ABCDEF',f=\"+~!*()'\",i,c=s.charSet,n,l,e,y='';c=c?c.toUpperCase():'';if(x){x=''+x;if(s.em==3){x=encodeURIComponent(x);for(i=0;i<f.length;i++) {n=f.substring(i,i+1);if(x.indexOf(n)>=0)x=s.rep(x,n,\"%\"+n.charCodeAt(0).toString(16).toUpperCase())}}else if(c=='AUTO'&&('').charCodeAt){for(i=0;i<x.length;i++){c=x.substring(i,i+1);n=x.charCodeAt(i);if(n>127){l=0;e='';while(n||l<4){e=h.substring(n%16,n%16+1)+e;n=(n-n%16)/16;l++}y+='%u'+e}else if(c=='+')y+='%2B';else y+=escape(c)}x=y}else x=s.rep(escape(''+x),'+','%2B');if(c&&c!='AUTO'&&s.em==1&&x.indexOf('%u')<0&&x.indexOf('%U')<0){i=x.indexOf('%');while(i>=0){i++;if(h.substring(8).indexOf(x.substring(i,i+1).toUpperCase())>=0)return x.substring(0,i)+'u00'+x.substring(i);i=x.indexOf('%',i)}}}return x};s.epa=function(x){var s=this,y,tcf;if(x){x=s.rep(''+x,'+',' ');if(s.em==3){tcf=new Function('x','var y,e;try{y=decodeURIComponent(x)}catch(e){y=unescape(x)}return y');return tcf(x)}else return unescape(x)}return y};s.pt=function(x,d,f,a){var s=this,t=x,z=0,y,r;while(t){y=t.indexOf(d);y=y<0?t.length:y;t=t.substring(0,y);r=s[f](t,a);if(r)return r;z+=y+d.length;t=x.substring(z,x.length);t=z<x.length?t:''}return ''};s.isf=function(t,a){var c=a.indexOf(':');if(c>=0)a=a.substring(0,c);c=a.indexOf('=');if(c>=0)a=a.substring(0,c);if(t.substring(0,2)=='s_')t=t.substring(2);return (t!=''&&t==a)};s.fsf=function(t,a){var s=this;if(s.pt(a,',','isf',t))s.fsg+=(s.fsg!=''?',':'')+t;return 0};s.fs=function(x,f){var s=this;s.fsg='';s.pt(x,',','fsf',f);return s.fsg};s.mpc=function(m,a){var s=this,c,l,n,v;v=s.d.visibilityState;if(!v)v=s.d.webkitVisibilityState;if(v&&v=='prerender'){if(!s.mpq){s.mpq=new Array;l=s.sp('webkitvisibilitychange,visibilitychange',',');for(n=0;n<l.length;n++){s.d.addEventListener(l[n],new Function('var s=s_c_il['+s._in+'],c,v;v=s.d.visibilityState;if(!v)v=s.d.webkitVisibilityState;if(s.mpq&&v==\"visible\"){while(s.mpq.length>0){c=s.mpq.shift();s[c.m].apply(s,c.a)}s.mpq=0}'),false)}}c=new Object;c.m=m;c.a=a;s.mpq.push(c);return 1}return 0};s.si=function(){var s=this,i,k,v,c=s_gi+'var s=s_gi(\"'+s.oun+'\");s.sa(\"'+s.un+'\");';for(i=0;i<s.va_g.length;i++){k=s.va_g[i];v=s[k];if(v!=undefined){if(typeof(v)!='number')c+='s.'+k+'=\"'+s_fe(v)+'\";';else c+='s.'+k+'='+v+';'}}c+=\"s.lnk=s.eo=s.linkName=s.linkType=s.wd.s_objectID=s.ppu=s.pe=s.pev1=s.pev2=s.pev3='';\";return c};s.c_d='';s.c_gdf=function(t,a){var s=this;if(!s.num(t))return 1;return 0};s.c_gd=function(){var s=this,d=s.wd.location.hostname,n=s.fpCookieDomainPeriods,p;if(!n)n=s.cookieDomainPeriods;if(d&&!s.c_d){n=n?parseInt(n):2;n=n>2?n:2;p=d.lastIndexOf('.');if(p>=0){while(p>=0&&n>1){p=d.lastIndexOf('.',p-1);n--}s.c_d=p>0&&s.pt(d,'.','c_gdf',0)?d.substring(p):d}}return s.c_d};s.c_r=function(k){var s=this;k=s.ape(k);var c=' '+s.d.cookie,i=c.indexOf(' '+k+'='),e=i<0?i:c.indexOf(';',i),v=i<0?'':s.epa(c.substring(i+2+k.length,e<0?c.length:e));return v!='[[B]]'?v:''};s.c_w=function(k,v,e){var s=this,d=s.c_gd(),l=s.cookieLifetime,t;v=''+v;l=l?(''+l).toUpperCase():'';if(e&&l!='SESSION'&&l!='NONE'){t=(v!=''?parseInt(l?l:0):-60);if(t){e=new Date;e.setTime(e.getTime()+(t*1000))}}if(k&&l!='NONE'){s.d.cookie=k+'='+s.ape(v!=''?v:'[[B]]')+'; path=/;'+(e&&l!='SESSION'?' expires='+e.toGMTString()+';':'')+(d?' domain='+d+';':'');return s.c_r(k)==v}return 0};s.eh=function(o,e,r,f){var s=this,b='s_'+e+'_'+s._in,n=-1,l,i,x;if(!s.ehl)s.ehl=new Array;l=s.ehl;for(i=0;i<l.length&&n<0;i++){if(l[i].o==o&&l[i].e==e)n=i}if(n<0){n=i;l[n]=new Object}x=l[n];x.o=o;x.e=e;f=r?x.b:f;if(r||f){x.b=r?0:o[e];x.o[e]=f}if(x.b){x.o[b]=x.b;return b}return 0};s.cet=function(f,a,t,o,b){var s=this,r,tcf;if(s.apv>=5&&(!s.isopera||s.apv>=7)){tcf=new Function('s','f','a','t','var e,r;try{r=s[f](a)}catch(e){r=s[t](e)}return r');r=tcf(s,f,a,t)}else{if(s.ismac&&s.u.indexOf('MSIE 4')>=0)r=s[b](a);else{s.eh(s.wd,'onerror',0,o);r=s[f](a);s.eh(s.wd,'onerror',1)}}return r};s.gtfset=function(e){var s=this;return s.tfs};s.gtfsoe=new Function('e','var s=s_c_il['+s._in+'],c;s.eh(window,\"onerror\",1);s.etfs=1;c=s.t();if(c)s.d.write(c);s.etfs=0;return true');s.gtfsfb=function(a){return window};s.gtfsf=function(w){var s=this,p=w.parent,l=w.location;s.tfs=w;if(p&&p.location!=l&&p.location.host==l.host){s.tfs=p;return s.gtfsf(s.tfs)}return s.tfs};s.gtfs=function(){var s=this;if(!s.tfs){s.tfs=s.wd;if(!s.etfs)s.tfs=s.cet('gtfsf',s.tfs,'gtfset',s.gtfsoe,'gtfsfb')}return s.tfs};s.mrq=function(u){var s=this,l=s.rl[u],n,r;s.rl[u]=0;if(l)for(n=0;n<l.length;n++){r=l[n];s.mr(0,0,r.r,r.t,r.u)}};s.flushBufferedRequests=function(){};s.mr=function(sess,q,rs,ta,u){var s=this,dc=s.dc,t1=s.trackingServer,t2=s.trackingServerSecure,tb=s.trackingServerBase,p='.sc',ns=s.visitorNamespace,un=s.cls(u?u:(ns?ns:s.fun)),r=new Object,l,imn='s_i_'+(un),im,b,e;if(!rs){if(t1){if(t2&&s.ssl)t1=t2}else{if(!tb)tb='2o7.net';if(dc)dc=(''+dc).toLowerCase();else dc='d1';if(tb=='2o7.net'){if(dc=='d1')dc='112';else if(dc=='d2')dc='122';p=''}t1=un+'.'+dc+'.'+p+tb}rs='http'+(s.ssl?'s':'')+'://'+t1+'/b/ss/'+s.un+'/'+(s.mobile?'5.1':'1')+'/'+s.version+(s.tcn?'T':'')+'/'+sess+'?AQB=1&ndh=1'+(q?q:'')+'&AQE=1';if(s.isie&&!s.ismac)rs=s.fl(rs,2047)}if(s.d.images&&s.apv>=3&&(!s.isopera||s.apv>=7)&&(s.ns6<0||s.apv>=6.1)){if(!s.rc)s.rc=new Object;if(!s.rc[un]){s.rc[un]=1;if(!s.rl)s.rl=new Object;s.rl[un]=new Array;setTimeout('if(window.s_c_il)window.s_c_il['+s._in+'].mrq(\"'+un+'\")',750)}else{l=s.rl[un];if(l){r.t=ta;r.u=un;r.r=rs;l[l.length]=r;return ''}imn+='_'+s.rc[un];s.rc[un]++}if(s.debugTracking){var d='AppMeasurement Debug: '+rs,dl=s.sp(rs,'&'),dln;for(dln=0;dln<dl.length;dln++)d+=\"\\n\\t\"+s.epa(dl[dln]);s.logDebug(d)}im=s.wd[imn];if(!im)im=s.wd[imn]=new Image;im.s_l=0;im.onload=new Function('e','this.s_l=1;var wd=window,s;if(wd.s_c_il){s=wd.s_c_il['+s._in+'];s.bcr();s.mrq(\"'+un+'\");s.nrs--;if(!s.nrs)s.m_m(\"rr\")}');if(!s.nrs){s.nrs=1;s.m_m('rs')}else s.nrs++;im.src=rs;if(s.useForcedLinkTracking||s.bcf){if(!s.forcedLinkTrackingTimeout)s.forcedLinkTrackingTimeout=250;setTimeout('if(window.s_c_il)window.s_c_il['+s._in+'].bcr()',s.forcedLinkTrackingTimeout);}else if((s.lnk||s.eo)&&(!ta||ta=='_self'||ta=='_top'||(s.wd.name&&ta==s.wd.name))){b=e=new Date;while(!im.s_l&&e.getTime()-b.getTime()<500)e=new Date}return ''}return '<im'+'g sr'+'c=\"'+rs+'\" width=1 height=1 border=0 alt=\"\">'};s.gg=function(v){var s=this;if(!s.wd['s_'+v])s.wd['s_'+v]='';return s.wd['s_'+v]};s.glf=function(t,a){if(t.substring(0,2)=='s_')t=t.substring(2);var s=this,v=s.gg(t);if(v)s[t]=v};s.gl=function(v){var s=this;if(s.pg)s.pt(v,',','glf',0)};s.rf=function(x){var s=this,y,i,j,h,p,l=0,q,a,b='',c='',t;if(x&&x.length>255){y=''+x;i=y.indexOf('?');if(i>0){q=y.substring(i+1);y=y.substring(0,i);h=y.toLowerCase();j=0;if(h.substring(0,7)=='http://')j+=7;else if(h.substring(0,8)=='https://')j+=8;i=h.indexOf(\"/\",j);if(i>0){h=h.substring(j,i);p=y.substring(i);y=y.substring(0,i);if(h.indexOf('google')>=0)l=',q,ie,start,search_key,word,kw,cd,';else if(h.indexOf('yahoo.co')>=0)l=',p,ei,';if(l&&q){a=s.sp(q,'&');if(a&&a.length>1){for(j=0;j<a.length;j++){t=a[j];i=t.indexOf('=');if(i>0&&l.indexOf(','+t.substring(0,i)+',')>=0)b+=(b?'&':'')+t;else c+=(c?'&':'')+t}if(b&&c)q=b+'&'+c;else c=''}i=253-(q.length-c.length)-y.length;x=y+(i>0?p.substring(0,i):'')+'?'+q}}}}return x};s.s2q=function(k,v,vf,vfp,f){var s=this,qs='',sk,sv,sp,ss,nke,nk,nf,nfl=0,nfn,nfm;if(k==\"contextData\")k=\"c\";if(v){for(sk in v)if((!f||sk.substring(0,f.length)==f)&&v[sk]&&(!vf||vf.indexOf(','+(vfp?vfp+'.':'')+sk+',')>=0)&&(!Object||!Object.prototype||!Object.prototype[sk])){nfm=0;if(nfl)for(nfn=0;nfn<nfl.length;nfn++)if(sk.substring(0,nfl[nfn].length)==nfl[nfn])nfm=1;if(!nfm){if(qs=='')qs+='&'+k+'.';sv=v[sk];if(f)sk=sk.substring(f.length);if(sk.length>0){nke=sk.indexOf('.');if(nke>0){nk=sk.substring(0,nke);nf=(f?f:'')+nk+'.';if(!nfl)nfl=new Array;nfl[nfl.length]=nf;qs+=s.s2q(nk,v,vf,vfp,nf)}else{if(typeof(sv)=='boolean'){if(sv)sv='true';else sv='false'}if(sv){if(vfp=='retrieveLightData'&&f.indexOf('.contextData.')<0){sp=sk.substring(0,4);ss=sk.substring(4);if(sk=='transactionID')sk='xact';else if(sk=='channel')sk='ch';else if(sk=='campaign')sk='v0';else if(s.num(ss)){if(sp=='prop')sk='c'+ss;else if(sp=='eVar')sk='v'+ss;else if(sp=='list')sk='l'+ss;else if(sp=='hier'){sk='h'+ss;sv=sv.substring(0,255)}}}qs+='&'+s.ape(sk)+'='+s.ape(sv)}}}}}if(qs!='')qs+='&.'+k}return qs};s.hav=function(){var s=this,qs='',l,fv='',fe='',mn,i,e;if(s.lightProfileID){l=s.va_m;fv=s.lightTrackVars;if(fv)fv=','+fv+','+s.vl_mr+','}else{l=s.va_t;if(s.pe||s.linkType){fv=s.linkTrackVars;fe=s.linkTrackEvents;if(s.pe){mn=s.pe.substring(0,1).toUpperCase()+s.pe.substring(1);if(s[mn]){fv=s[mn].trackVars;fe=s[mn].trackEvents}}}if(fv)fv=','+fv+','+s.vl_l+','+s.vl_l2;if(fe){fe=','+fe+',';if(fv)fv+=',events,'}if (s.events2)e=(e?',':'')+s.events2}for(i=0;i<l.length;i++){var k=l[i],v=s[k],b=k.substring(0,4),x=k.substring(4),n=parseInt(x),q=k;if(!v)if(k=='events'&&e){v=e;e=''}if(v&&(!fv||fv.indexOf(','+k+',')>=0)&&k!='linkName'&&k!='linkType'){if(k=='timestamp')q='ts';else if(k=='dynamicVariablePrefix')q='D';else if(k=='visitorID')q='vid';else if(k=='pageURL'){q='g';if(v.length>255){s.pageURLRest=v.substring(255);v=v.substring(0,255);}}else if(k=='pageURLRest')q='-g';else if(k=='referrer'){q='r';v=s.fl(s.rf(v),255)}else if(k=='vmk'||k=='visitorMigrationKey')q='vmt';else if(k=='visitorMigrationServer'){q='vmf';if(s.ssl&&s.visitorMigrationServerSecure)v=''}else if(k=='visitorMigrationServerSecure'){q='vmf';if(!s.ssl&&s.visitorMigrationServer)v=''}else if(k=='charSet'){q='ce';if(v.toUpperCase()=='AUTO')v='ISO8859-1';else if(s.em==2||s.em==3)v='UTF-8'}else if(k=='visitorNamespace')q='ns';else if(k=='cookieDomainPeriods')q='cdp';else if(k=='cookieLifetime')q='cl';else if(k=='variableProvider')q='vvp';else if(k=='currencyCode')q='cc';else if(k=='channel')q='ch';else if(k=='transactionID')q='xact';else if(k=='campaign')q='v0';else if(k=='resolution')q='s';else if(k=='colorDepth')q='c';else if(k=='javascriptVersion')q='j';else if(k=='javaEnabled')q='v';else if(k=='cookiesEnabled')q='k';else if(k=='browserWidth')q='bw';else if(k=='browserHeight')q='bh';else if(k=='connectionType')q='ct';else if(k=='homepage')q='hp';else if(k=='plugins')q='p';else if(k=='events'){if(e)v+=(v?',':'')+e;if(fe)v=s.fs(v,fe)}else if(k=='events2')v='';else if(k=='contextData'){qs+=s.s2q('c',s[k],fv,k,0);v=''}else if(k=='lightProfileID')q='mtp';else if(k=='lightStoreForSeconds'){q='mtss';if(!s.lightProfileID)v=''}else if(k=='lightIncrementBy'){q='mti';if(!s.lightProfileID)v=''}else if(k=='retrieveLightProfiles')q='mtsr';else if(k=='deleteLightProfiles')q='mtsd';else if(k=='retrieveLightData'){if(s.retrieveLightProfiles)qs+=s.s2q('mts',s[k],fv,k,0);v=''}else if(s.num(x)){if(b=='prop')q='c'+n;else if(b=='eVar')q='v'+n;else if(b=='list')q='l'+n;else if(b=='hier'){q='h'+n;v=s.fl(v,255)}}if(v)qs+='&'+s.ape(q)+'='+(k.substring(0,3)!='pev'?s.ape(v):v)}}return qs};s.ltdf=function(t,h){t=t?t.toLowerCase():'';h=h?h.toLowerCase():'';var qi=h.indexOf('?');h=qi>=0?h.substring(0,qi):h;if(t&&h.substring(h.length-(t.length+1))=='.'+t)return 1;return 0};s.ltef=function(t,h){t=t?t.toLowerCase():'';h=h?h.toLowerCase():'';if(t&&h.indexOf(t)>=0)return 1;return 0};s.lt=function(h){var s=this,lft=s.linkDownloadFileTypes,lef=s.linkExternalFilters,lif=s.linkInternalFilters;lif=lif?lif:s.wd.location.hostname;h=h.toLowerCase();if(s.trackDownloadLinks&&lft&&s.pt(lft,',','ltdf',h))return 'd';if(s.trackExternalLinks&&h.indexOf('#')!=0&&h.indexOf('about:')!=0&&h.indexOf('javascript:')!=0&&(lef||lif)&&(!lef||s.pt(lef,',','ltef',h))&&(!lif||!s.pt(lif,',','ltef',h)))return 'e';return ''};s.lc=new Function('e','var s=s_c_il['+s._in+'],b=s.eh(this,\"onclick\");s.lnk=this;s.t();s.lnk=0;if(b)return this[b](e);return true');s.bcr=function(){var s=this;if(s.bct&&s.bce)s.bct.dispatchEvent(s.bce);if(s.bcf){if(typeof(s.bcf)=='function')s.bcf();else if(s.bct&&s.bct.href)s.d.location=s.bct.href}s.bct=s.bce=s.bcf=0};s.bc=new Function('e','if(e&&e.s_fe)return;var s=s_c_il['+s._in+'],f,tcf,t,n,nrs,a,h;if(s.d&&s.d.all&&s.d.all.cppXYctnr)return;if(!s.bbc)s.useForcedLinkTracking=0;else if(!s.useForcedLinkTracking){s.b.removeEventListener(\"click\",s.bc,true);s.bbc=s.useForcedLinkTracking=0;return}else s.b.removeEventListener(\"click\",s.bc,false);s.eo=e.srcElement?e.srcElement:e.target;nrs=s.nrs;s.t();s.eo=0;if(s.nrs>nrs&&s.useForcedLinkTracking&&e.target){a=e.target;while(a&&a!=s.b&&a.tagName.toUpperCase()!=\"A\"&&a.tagName.toUpperCase()!=\"AREA\")a=a.parentNode;if(a){h=a.href;if(h.indexOf(\"#\")==0||h.indexOf(\"about:\")==0||h.indexOf(\"javascript:\")==0)h=0;t=a.target;if(e.target.dispatchEvent&&h&&(!t||t==\"_self\"||t==\"_top\"||(s.wd.name&&t==s.wd.name))){e.stopPropagation();e.stopImmediatePropagation();e.preventDefault();n=s.d.createEvent(\"MouseEvents\");n.initMouseEvent(\"click\",e.bubbles,e.cancelable,e.view,e.detail,e.screenX,e.screenY,e.clientX,e.clientY,e.ctrlKey,e.altKey,e.shiftKey,e.metaKey,e.button,e.relatedTarget);n.s_fe=1;s.bct=e.target;s.bce=n}}}');s.oh=function(o){var s=this,l=s.wd.location,h=o.href?o.href:'',i,j,k,p;i=h.indexOf(':');j=h.indexOf('?');k=h.indexOf('/');if(h&&(i<0||(j>=0&&i>j)||(k>=0&&i>k))){p=o.protocol&&o.protocol.length>1?o.protocol:(l.protocol?l.protocol:'');i=l.pathname.lastIndexOf('/');h=(p?p+'//':'')+(o.host?o.host:(l.host?l.host:''))+(h.substring(0,1)!='/'?l.pathname.substring(0,i<0?0:i)+'/':'')+h}return h};s.ot=function(o){var t=o.tagName;if(o.tagUrn||(o.scopeName&&o.scopeName.toUpperCase()!='HTML'))return '';t=t&&t.toUpperCase?t.toUpperCase():'';if(t=='SHAPE')t='';if(t){if((t=='INPUT'||t=='BUTTON')&&o.type&&o.type.toUpperCase)t=o.type.toUpperCase();else if(!t&&o.href)t='A';}return t};s.oid=function(o){var s=this,t=s.ot(o),p,c,n='',x=0;if(t&&!o.s_oid){p=o.protocol;c=o.onclick;if(o.href&&(t=='A'||t=='AREA')&&(!c||!p||p.toLowerCase().indexOf('javascript')<0))n=s.oh(o);else if(c){n=s.rep(s.rep(s.rep(s.rep(''+c,\"\\r\",''),\"\\n\",''),\"\\t\",''),' ','');x=2}else if(t=='INPUT'||t=='SUBMIT'){if(o.value)n=o.value;else if(o.innerText)n=o.innerText;else if(o.textContent)n=o.textContent;x=3}else if(o.src&&t=='IMAGE')n=o.src;if(n){o.s_oid=s.fl(n,100);o.s_oidt=x}}return o.s_oid};s.rqf=function(t,un){var s=this,e=t.indexOf('='),u=e>=0?t.substring(0,e):'',q=e>=0?s.epa(t.substring(e+1)):'';if(u&&q&&(','+u+',').indexOf(','+un+',')>=0){if(u!=s.un&&s.un.indexOf(',')>=0)q='&u='+u+q+'&u=0';return q}return ''};s.rq=function(un){if(!un)un=this.un;var s=this,c=un.indexOf(','),v=s.c_r('s_sq'),q='';if(c<0)return s.pt(v,'&','rqf',un);return s.pt(un,',','rq',0)};s.sqp=function(t,a){var s=this,e=t.indexOf('='),q=e<0?'':s.epa(t.substring(e+1));s.sqq[q]='';if(e>=0)s.pt(t.substring(0,e),',','sqs',q);return 0};s.sqs=function(un,q){var s=this;s.squ[un]=q;return 0};s.sq=function(q){var s=this,k='s_sq',v=s.c_r(k),x,c=0;s.sqq=new Object;s.squ=new Object;s.sqq[q]='';s.pt(v,'&','sqp',0);s.pt(s.un,',','sqs',q);v='';for(x in s.squ)if(x&&(!Object||!Object.prototype||!Object.prototype[x]))s.sqq[s.squ[x]]+=(s.sqq[s.squ[x]]?',':'')+x;for(x in s.sqq)if(x&&(!Object||!Object.prototype||!Object.prototype[x])&&s.sqq[x]&&(x==q||c<2)){v+=(v?'&':'')+s.sqq[x]+'='+s.ape(x);c++}return s.c_w(k,v,0)};s.wdl=new Function('e','var s=s_c_il['+s._in+'],r=true,b=s.eh(s.wd,\"onload\"),i,o,oc;if(b)r=this[b](e);for(i=0;i<s.d.links.length;i++){o=s.d.links[i];oc=o.onclick?\"\"+o.onclick:\"\";if((oc.indexOf(\"s_gs(\")<0||oc.indexOf(\".s_oc(\")>=0)&&oc.indexOf(\".tl(\")<0)s.eh(o,\"onclick\",0,s.lc);}return r');s.wds=function(){var s=this;if(s.apv>3&&(!s.isie||!s.ismac||s.apv>=5)){if(s.b&&s.b.attachEvent)s.b.attachEvent('onclick',s.bc);else if(s.b&&s.b.addEventListener){if(s.n&&s.n.userAgent.indexOf('WebKit')>=0&&s.d.createEvent){s.bbc=1;s.useForcedLinkTracking=1;s.b.addEventListener('click',s.bc,true)}s.b.addEventListener('click',s.bc,false)}else s.eh(s.wd,'onload',0,s.wdl)}};s.vs=function(x){var s=this,v=s.visitorSampling,g=s.visitorSamplingGroup,k='s_vsn_'+s.un+(g?'_'+g:''),n=s.c_r(k),e=new Date,y=e.getYear();e.setYear(y+10+(y<1900?1900:0));if(v){v*=100;if(!n){if(!s.c_w(k,x,e))return 0;n=x}if(n%10000>v)return 0}return 1};s.dyasmf=function(t,m){if(t&&m&&m.indexOf(t)>=0)return 1;return 0};s.dyasf=function(t,m){var s=this,i=t?t.indexOf('='):-1,n,x;if(i>=0&&m){var n=t.substring(0,i),x=t.substring(i+1);if(s.pt(x,',','dyasmf',m))return n}return 0};s.uns=function(){var s=this,x=s.dynamicAccountSelection,l=s.dynamicAccountList,m=s.dynamicAccountMatch,n,i;s.un=s.un.toLowerCase();if(x&&l){if(!m)m=s.wd.location.host;if(!m.toLowerCase)m=''+m;l=l.toLowerCase();m=m.toLowerCase();n=s.pt(l,';','dyasf',m);if(n)s.un=n}i=s.un.indexOf(',');s.fun=i<0?s.un:s.un.substring(0,i)};s.sa=function(un){var s=this;if(s.un&&s.mpc('sa',arguments))return;s.un=un;if(!s.oun)s.oun=un;else if((','+s.oun+',').indexOf(','+un+',')<0)s.oun+=','+un;s.uns()};s.m_i=function(n,a){var s=this,m,f=n.substring(0,1),r,l,i;if(!s.m_l)s.m_l=new Object;if(!s.m_nl)s.m_nl=new Array;m=s.m_l[n];if(!a&&m&&m._e&&!m._i)s.m_a(n);if(!m){m=new Object,m._c='s_m';m._in=s.wd.s_c_in;m._il=s._il;m._il[m._in]=m;s.wd.s_c_in++;m.s=s;m._n=n;m._l=new Array('_c','_in','_il','_i','_e','_d','_dl','s','n','_r','_g','_g1','_t','_t1','_x','_x1','_rs','_rr','_l');s.m_l[n]=m;s.m_nl[s.m_nl.length]=n}else if(m._r&&!m._m){r=m._r;r._m=m;l=m._l;for(i=0;i<l.length;i++)if(m[l[i]])r[l[i]]=m[l[i]];r._il[r._in]=r;m=s.m_l[n]=r}if(f==f.toUpperCase())s[n]=m;return m};s.m_a=new Function('n','g','e','if(!g)g=\"m_\"+n;var s=s_c_il['+s._in+'],c=s[g+\"_c\"],m,x,f=0;if(s.mpc(\"m_a\",arguments))return;if(!c)c=s.wd[\"s_\"+g+\"_c\"];if(c&&s_d)s[g]=new Function(\"s\",s_ft(s_d(c)));x=s[g];if(!x)x=s.wd[\\'s_\\'+g];if(!x)x=s.wd[g];m=s.m_i(n,1);if(x&&(!m._i||g!=\"m_\"+n)){m._i=f=1;if((\"\"+x).indexOf(\"function\")>=0)x(s);else s.m_m(\"x\",n,x,e)}m=s.m_i(n,1);if(m._dl)m._dl=m._d=0;s.dlt();return f');s.m_m=function(t,n,d,e){t='_'+t;var s=this,i,x,m,f='_'+t,r=0,u;if(s.m_l&&s.m_nl)for(i=0;i<s.m_nl.length;i++){x=s.m_nl[i];if(!n||x==n){m=s.m_i(x);u=m[t];if(u){if((''+u).indexOf('function')>=0){if(d&&e)u=m[t](d,e);else if(d)u=m[t](d);else u=m[t]()}}if(u)r=1;u=m[t+1];if(u&&!m[f]){if((''+u).indexOf('function')>=0){if(d&&e)u=m[t+1](d,e);else if(d)u=m[t+1](d);else u=m[t+1]()}}m[f]=1;if(u)r=1}}return r};s.m_ll=function(){var s=this,g=s.m_dl,i,o;if(g)for(i=0;i<g.length;i++){o=g[i];if(o)s.loadModule(o.n,o.u,o.d,o.l,o.e,1);g[i]=0}};s.loadModule=function(n,u,d,l,e,ln){var s=this,m=0,i,g,o=0,f1,f2,c=s.h?s.h:s.b,b,tcf;if(n){i=n.indexOf(':');if(i>=0){g=n.substring(i+1);n=n.substring(0,i)}else g=\"m_\"+n;m=s.m_i(n)}if((l||(n&&!s.m_a(n,g)))&&u&&s.d&&c&&s.d.createElement){if(d){m._d=1;m._dl=1}if(ln){if(s.ssl)u=s.rep(u,'http:','https:');i='s_s:'+s._in+':'+n+':'+g;b='var s=s_c_il['+s._in+'],o=s.d.getElementById(\"'+i+'\");if(s&&o){if(!o.l&&s.wd.'+g+'){o.l=1;if(o.i)clearTimeout(o.i);o.i=0;s.m_a(\"'+n+'\",\"'+g+'\"'+(e?',\"'+e+'\"':'')+')}';f2=b+'o.c++;if(!s.maxDelay)s.maxDelay=250;if(!o.l&&o.c<(s.maxDelay*2)/100)o.i=setTimeout(o.f2,100)}';f1=new Function('e',b+'}');tcf=new Function('s','c','i','u','f1','f2','var e,o=0;try{o=s.d.createElement(\"script\");if(o){o.type=\"text/javascript\";'+(n?'o.id=i;o.defer=true;o.onload=o.onreadystatechange=f1;o.f2=f2;o.l=0;':'')+'o.src=u;c.appendChild(o);'+(n?'o.c=0;o.i=setTimeout(f2,100)':'')+'}}catch(e){o=0}return o');o=tcf(s,c,i,u,f1,f2)}else{o=new Object;o.n=n+':'+g;o.u=u;o.d=d;o.l=l;o.e=e;g=s.m_dl;if(!g)g=s.m_dl=new Array;i=0;while(i<g.length&&g[i])i++;g[i]=o}}else if(n){m=s.m_i(n);m._e=1}return m};s.voa=function(vo,r){var s=this,l=s.va_g,i,k,v,x;for(i=0;i<l.length;i++){k=l[i];v=vo[k];if(v||vo['!'+k]){if(!r&&(k==\"contextData\"||k==\"retrieveLightData\")&&s[k])for(x in s[k])if(!v[x])v[x]=s[k][x];s[k]=v}}};s.vob=function(vo){var s=this,l=s.va_g,i,k;for(i=0;i<l.length;i++){k=l[i];vo[k]=s[k];if(!vo[k])vo['!'+k]=1}};s.dlt=new Function('var s=s_c_il['+s._in+'],d=new Date,i,vo,f=0;if(s.dll)for(i=0;i<s.dll.length;i++){vo=s.dll[i];if(vo){if(!s.m_m(\"d\")||d.getTime()-vo._t>=s.maxDelay){s.dll[i]=0;s.t(vo)}else f=1}}if(s.dli)clearTimeout(s.dli);s.dli=0;if(f){if(!s.dli)s.dli=setTimeout(s.dlt,s.maxDelay)}else s.dll=0');s.dl=function(vo){var s=this,d=new Date;if(!vo)vo=new Object;s.vob(vo);vo._t=d.getTime();if(!s.dll)s.dll=new Array;s.dll[s.dll.length]=vo;if(!s.maxDelay)s.maxDelay=250;s.dlt()};s.gfid=function(){var s=this,d='0123456789ABCDEF',k='s_fid',fid=s.c_r(k),h='',l='',i,j,m=8,n=4,e=new Date,y;if(!fid||fid.indexOf('-')<0){for(i=0;i<16;i++){j=Math.floor(Math.random()*m);h+=d.substring(j,j+1);j=Math.floor(Math.random()*n);l+=d.substring(j,j+1);m=n=16}fid=h+'-'+l;}y=e.getYear();e.setYear(y+2+(y<1900?1900:0));if(!s.c_w(k,fid,e))fid=0;return fid};s.applyADMS=function(){var s=this,vb=new Object;if(s.wd.ADMS&&!s.visitorID&&!s.admsc){if(!s.adms)s.adms=ADMS.getDefault();if(!s.admsq){s.visitorID=s.adms.getVisitorID(new Function('v','var s=s_c_il['+s._in+'],l=s.admsq,i;if(v==-1)v=0;if(v)s.visitorID=v;s.admsq=0;if(l){s.admsc=1;for(i=0;i<l.length;i++)s.t(l[i]);s.admsc=0;}'));if(!s.visitorID)s.admsq=new Array}if(s.admsq){s.vob(vb);vb['!visitorID']=0;s.admsq.push(vb);return 1}else{if(s.visitorID==-1)s.visitorID=0}}return 0};s.track=s.t=function(vo){var s=this,trk=1,tm=new Date,sed=Math&&Math.random?Math.floor(Math.random()*10000000000000):tm.getTime(),sess='s'+Math.floor(tm.getTime()/10800000)%10+sed,y=tm.getYear(),vt=tm.getDate()+'/'+tm.getMonth()+'/'+(y<1900?y+1900:y)+' '+tm.getHours()+':'+tm.getMinutes()+':'+tm.getSeconds()+' '+tm.getDay()+' '+tm.getTimezoneOffset(),tcf,tfs=s.gtfs(),ta=-1,q='',qs='',code='',vb=new Object;if(s.mpc('t',arguments))return;s.gl(s.vl_g);s.uns();s.m_ll();if(!s.td){var tl=tfs.location,a,o,i,x='',c='',v='',p='',bw='',bh='',j='1.0',k=s.c_w('s_cc','true',0)?'Y':'N',hp='',ct='',pn=0,ps;if(String&&String.prototype){j='1.1';if(j.match){j='1.2';if(tm.setUTCDate){j='1.3';if(s.isie&&s.ismac&&s.apv>=5)j='1.4';if(pn.toPrecision){j='1.5';a=new Array;if(a.forEach){j='1.6';i=0;o=new Object;tcf=new Function('o','var e,i=0;try{i=new Iterator(o)}catch(e){}return i');i=tcf(o);if(i&&i.next){j='1.7';if(a.reduce){j='1.8';if(j.trim){j='1.8.1';if(Date.parse){j='1.8.2';if(Object.create)j='1.8.5'}}}}}}}}}if(s.apv>=4)x=screen.width+'x'+screen.height;if(s.isns||s.isopera){if(s.apv>=3){v=s.n.javaEnabled()?'Y':'N';if(s.apv>=4){c=screen.pixelDepth;bw=s.wd.innerWidth;bh=s.wd.innerHeight}}s.pl=s.n.plugins}else if(s.isie){if(s.apv>=4){v=s.n.javaEnabled()?'Y':'N';c=screen.colorDepth;if(s.apv>=5){bw=s.d.documentElement.offsetWidth;bh=s.d.documentElement.offsetHeight;if(!s.ismac&&s.b){tcf=new Function('s','tl','var e,hp=0;try{s.b.addBehavior(\"#default#homePage\");hp=s.b.isHomePage(tl)?\"Y\":\"N\"}catch(e){}return hp');hp=tcf(s,tl);tcf=new Function('s','var e,ct=0;try{s.b.addBehavior(\"#default#clientCaps\");ct=s.b.connectionType}catch(e){}return ct');ct=tcf(s)}}}else r=''}if(s.pl)while(pn<s.pl.length&&pn<30){ps=s.fl(s.pl[pn].name,100)+';';if(p.indexOf(ps)<0)p+=ps;pn++}s.resolution=x;s.colorDepth=c;s.javascriptVersion=j;s.javaEnabled=v;s.cookiesEnabled=k;s.browserWidth=bw;s.browserHeight=bh;s.connectionType=ct;s.homepage=hp;s.plugins=p;s.td=1}if(vo){s.vob(vb);s.voa(vo)}s.fid=s.gfid();if(s.applyADMS())return '';if((vo&&vo._t)||!s.m_m('d')){if(s.usePlugins)s.doPlugins(s);if(!s.abort){var l=s.wd.location,r=tfs.document.referrer;if(!s.pageURL)s.pageURL=l.href?l.href:l;if(!s.referrer&&!s._1_referrer){s.referrer=r;s._1_referrer=1}s.m_m('g');if(s.lnk||s.eo){var o=s.eo?s.eo:s.lnk,p=s.pageName,w=1,t=s.ot(o),n=s.oid(o),x=o.s_oidt,h,l,i,oc;if(s.eo&&o==s.eo){while(o&&!n&&t!='BODY'){o=o.parentElement?o.parentElement:o.parentNode;if(o){t=s.ot(o);n=s.oid(o);x=o.s_oidt}}if(!n||t=='BODY')o='';if(o){oc=o.onclick?''+o.onclick:'';if((oc.indexOf('s_gs(')>=0&&oc.indexOf('.s_oc(')<0)||oc.indexOf('.tl(')>=0)o=0}}if(o){if(n)ta=o.target;h=s.oh(o);i=h.indexOf('?');h=s.linkLeaveQueryString||i<0?h:h.substring(0,i);l=s.linkName;t=s.linkType?s.linkType.toLowerCase():s.lt(h);if(t&&(h||l)){s.pe='lnk_'+(t=='d'||t=='e'?t:'o');s.pev1=(h?s.ape(h):'');s.pev2=(l?s.ape(l):'')}else trk=0;if(s.trackInlineStats){if(!p){p=s.pageURL;w=0}t=s.ot(o);i=o.sourceIndex;if(o.dataset&&o.dataset.sObjectId){s.wd.s_objectID=o.dataset.sObjectId;}else if(o.getAttribute&&o.getAttribute('data-s-object-id')){s.wd.s_objectID=o.getAttribute('data-s-object-id');}else if(s.useForcedLinkTracking){s.wd.s_objectID='';oc=o.onclick?''+o.onclick:'';if(oc){var ocb=oc.indexOf('s_objectID'),oce,ocq,ocx;if(ocb>=0){ocb+=10;while(ocb<oc.length&&(\"= \\t\\r\\n\").indexOf(oc.charAt(ocb))>=0)ocb++;if(ocb<oc.length){oce=ocb;ocq=ocx=0;while(oce<oc.length&&(oc.charAt(oce)!=';'||ocq)){if(ocq){if(oc.charAt(oce)==ocq&&!ocx)ocq=0;else if(oc.charAt(oce)==\"\\\\\")ocx=!ocx;else ocx=0;}else{ocq=oc.charAt(oce);if(ocq!='\"'&&ocq!=\"'\")ocq=0}oce++;}oc=oc.substring(ocb,oce);if(oc){o.s_soid=new Function('s','var e;try{s.wd.s_objectID='+oc+'}catch(e){}');o.s_soid(s)}}}}}if(s.gg('objectID')){n=s.gg('objectID');x=1;i=1}if(p&&n&&t)qs='&pid='+s.ape(s.fl(p,255))+(w?'&pidt='+w:'')+'&oid='+s.ape(s.fl(n,100))+(x?'&oidt='+x:'')+'&ot='+s.ape(t)+(i?'&oi='+i:'')}}else trk=0}if(trk||qs){s.sampled=s.vs(sed);if(trk){if(s.sampled)code=s.mr(sess,(vt?'&t='+s.ape(vt):'')+s.hav()+q+(qs?qs:s.rq()),0,ta);qs='';s.m_m('t');if(s.p_r)s.p_r();s.referrer=s.lightProfileID=s.retrieveLightProfiles=s.deleteLightProfiles=''}s.sq(qs)}}}else s.dl(vo);if(vo)s.voa(vb,1);s.abort=0;s.pageURLRest=s.lnk=s.eo=s.linkName=s.linkType=s.wd.s_objectID=s.ppu=s.pe=s.pev1=s.pev2=s.pev3='';if(s.pg)s.wd.s_lnk=s.wd.s_eo=s.wd.s_linkName=s.wd.s_linkType='';return code};s.trackLink=s.tl=function(o,t,n,vo,f){var s=this;s.lnk=o;s.linkType=t;s.linkName=n;if(f){s.bct=o;s.bcf=f}s.t(vo)};s.trackLight=function(p,ss,i,vo){var s=this;s.lightProfileID=p;s.lightStoreForSeconds=ss;s.lightIncrementBy=i;s.t(vo)};s.setTagContainer=function(n){var s=this,l=s.wd.s_c_il,i,t,x,y;s.tcn=n;if(l)for(i=0;i<l.length;i++){t=l[i];if(t&&t._c=='s_l'&&t.tagContainerName==n){s.voa(t);if(t.lmq)for(i=0;i<t.lmq.length;i++){x=t.lmq[i];y='m_'+x.n;if(!s[y]&&!s[y+'_c']){s[y]=t[y];s[y+'_c']=t[y+'_c']}s.loadModule(x.n,x.u,x.d)}if(t.ml)for(x in t.ml)if(s[x]){y=s[x];x=t.ml[x];for(i in x)if(!Object.prototype[i]){if(typeof(x[i])!='function'||(''+x[i]).indexOf('s_c_il')<0)y[i]=x[i]}}if(t.mmq)for(i=0;i<t.mmq.length;i++){x=t.mmq[i];if(s[x.m]){y=s[x.m];if(y[x.f]&&typeof(y[x.f])=='function'){if(x.a)y[x.f].apply(y,x.a);else y[x.f].apply(y)}}}if(t.tq)for(i=0;i<t.tq.length;i++)s.t(t.tq[i]);t.s=s;return}}};s.wd=window;s.ssl=(s.wd.location.protocol.toLowerCase().indexOf('https')>=0);s.d=document;s.b=s.d.body;if(s.d.getElementsByTagName){s.h=s.d.getElementsByTagName('HEAD');if(s.h)s.h=s.h[0]}s.n=navigator;s.u=s.n.userAgent;s.ns6=s.u.indexOf('Netscape6/');var apn=s.n.appName,v=s.n.appVersion,ie=v.indexOf('MSIE '),o=s.u.indexOf('Opera '),i;if(v.indexOf('Opera')>=0||o>0)apn='Opera';s.isie=(apn=='Microsoft Internet Explorer');s.isns=(apn=='Netscape');s.isopera=(apn=='Opera');s.ismac=(s.u.indexOf('Mac')>=0);if(o>0)s.apv=parseFloat(s.u.substring(o+6));else if(ie>0){s.apv=parseInt(i=v.substring(ie+5));if(s.apv>3)s.apv=parseFloat(i)}else if(s.ns6>0)s.apv=parseFloat(s.u.substring(s.ns6+10));else s.apv=parseFloat(v);s.em=0;if(s.em.toPrecision)s.em=3;else if(String.fromCharCode){i=escape(String.fromCharCode(256)).toUpperCase();s.em=(i=='%C4%80'?2:(i=='%U0100'?1:0))}if(s.oun)s.sa(s.oun);s.sa(un);s.vl_l='timestamp,dynamicVariablePrefix,visitorID,fid,vmk,visitorMigrationKey,visitorMigrationServer,visitorMigrationServerSecure,ppu,charSet,visitorNamespace,cookieDomainPeriods,cookieLifetime,pageName,pageURL,referrer,contextData,currencyCode,lightProfileID,lightStoreForSeconds,lightIncrementBy,retrieveLightProfiles,deleteLightProfiles,retrieveLightData';s.va_l=s.sp(s.vl_l,',');s.vl_mr=s.vl_m='timestamp,charSet,visitorNamespace,cookieDomainPeriods,cookieLifetime,contextData,lightProfileID,lightStoreForSeconds,lightIncrementBy';s.vl_t=s.vl_l+',variableProvider,channel,server,pageType,transactionID,purchaseID,campaign,state,zip,events,events2,products,linkName,linkType';var n;for(n=1;n<=100;n++){s.vl_t+=',prop'+n+',eVar'+n;s.vl_m+=',prop'+n+',eVar'+n}for(n=1;n<=5;n++)s.vl_t+=',hier'+n;for(n=1;n<=3;n++)s.vl_t+=',list'+n;s.va_m=s.sp(s.vl_m,',');s.vl_l2=',tnt,pe,pev1,pev2,pev3,resolution,colorDepth,javascriptVersion,javaEnabled,cookiesEnabled,browserWidth,browserHeight,connectionType,homepage,pageURLRest,plugins';s.vl_t+=s.vl_l2;s.va_t=s.sp(s.vl_t,',');s.vl_g=s.vl_t+',trackingServer,trackingServerSecure,trackingServerBase,fpCookieDomainPeriods,disableBufferedRequests,mobile,visitorSampling,visitorSamplingGroup,dynamicAccountSelection,dynamicAccountList,dynamicAccountMatch,trackDownloadLinks,trackExternalLinks,trackInlineStats,linkLeaveQueryString,linkDownloadFileTypes,linkExternalFilters,linkInternalFilters,linkTrackVars,linkTrackEvents,linkNames,lnk,eo,lightTrackVars,_1_referrer,un';s.va_g=s.sp(s.vl_g,',');s.pg=pg;s.gl(s.vl_g);s.contextData=new Object;s.retrieveLightData=new Object;if(!ss)s.wds();if(pg){s.wd.s_co=function(o){return o};s.wd.s_gs=function(un){s_gi(un,1,1).t()};s.wd.s_dc=function(un){s_gi(un,1).t()}}",
w=window,l=w.s_c_il,n=navigator,u=n.userAgent,v=n.appVersion,e=v.indexOf('MSIE '),m=u.indexOf('Netscape6/'),a,i,j,x,s;if(un){un=un.toLowerCase();if(l)for(j=0;j<2;j++)for(i=0;i<l.length;i++){s=l[i];x=s._c;if((!x||x=='s_c'||(j>0&&x=='s_l'))&&(s.oun==un||(s.fs&&s.sa&&s.fs(s.oun,un)))){if(s.sa)s.sa(un);if(x=='s_c')return s}else s=0}}w.s_an='0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz';
w.s_sp=new Function("x","d","var a=new Array,i=0,j;if(x){if(x.split)a=x.split(d);else if(!d)for(i=0;i<x.length;i++)a[a.length]=x.substring(i,i+1);else while(i>=0){j=x.indexOf(d,i);a[a.length]=x.substring(i,j<0?x.length:j);i=j;if(i>=0)i+=d.length}}return a");
w.s_jn=new Function("a","d","var x='',i,j=a.length;if(a&&j>0){x=a[0];if(j>1){if(a.join)x=a.join(d);else for(i=1;i<j;i++)x+=d+a[i]}}return x");
w.s_rep=new Function("x","o","n","return s_jn(s_sp(x,o),n)");
w.s_d=new Function("x","var t='`^@$#',l=s_an,l2=new Object,x2,d,b=0,k,i=x.lastIndexOf('~~'),j,v,w;if(i>0){d=x.substring(0,i);x=x.substring(i+2);l=s_sp(l,'');for(i=0;i<62;i++)l2[l[i]]=i;t=s_sp(t,'');d=s_sp(d,'~');i=0;while(i<5){v=0;if(x.indexOf(t[i])>=0) {x2=s_sp(x,t[i]);for(j=1;j<x2.length;j++){k=x2[j].substring(0,1);w=t[i]+k;if(k!=' '){v=1;w=d[b+l2[k]]}x2[j]=w+x2[j].substring(1)}}if(v)x=s_jn(x2,'');else{w=t[i]+' ';if(x.indexOf(w)>=0)x=s_rep(x,w,t[i]);i++;b+=62}}}return x");
w.s_fe=new Function("c","return s_rep(s_rep(s_rep(c,'\\\\','\\\\\\\\'),'\"','\\\\\"'),\"\\n\",\"\\\\n\")");
w.s_fa=new Function("f","var s=f.indexOf('(')+1,e=f.indexOf(')'),a='',c;while(s>=0&&s<e){c=f.substring(s,s+1);if(c==',')a+='\",\"';else if((\"\\n\\r\\t \").indexOf(c)<0)a+=c;s++}return a?'\"'+a+'\"':a");
w.s_ft=new Function("c","c+='';var s,e,o,a,d,q,f,h,x;s=c.indexOf('=function(');while(s>=0){s++;d=1;q='';x=0;f=c.substring(s);a=s_fa(f);e=o=c.indexOf('{',s);e++;while(d>0){h=c.substring(e,e+1);if(q){if(h==q&&!x)q='';if(h=='\\\\')x=x?0:1;else x=0}else{if(h=='\"'||h==\"'\")q=h;if(h=='{')d++;if(h=='}')d--}if(d>0)e++}c=c.substring(0,s)+'new Function('+(a?a+',':'')+'\"'+s_fe(c.substring(o+1,e))+'\")'+c.substring(e+1);s=c.indexOf('=function(')}return c;");
c=s_d(c);if(e>0){a=parseInt(i=v.substring(e+5));if(a>3)a=parseFloat(i)}else if(m>0)a=parseFloat(u.substring(m+10));else a=parseFloat(v);if(a<5||v.indexOf('Opera')>=0||u.indexOf('Opera')>=0)c=s_ft(c);if(!s){s=new Object;if(!w.s_c_in){w.s_c_il=new Array;w.s_c_in=0}s._il=w.s_c_il;s._in=w.s_c_in;s._il[s._in]=s;w.s_c_in++;}s._c='s_c';(new Function("s","un","pg","ss",c))(s,un,pg,ss);return s}
function s_giqf(){var w=window,q=w.s_giq,i,t,s;if(q)for(i=0;i<q.length;i++){t=q[i];s=s_gi(t.oun);s.sa(t.un);s.setTagContainer(t.tagContainerName)}w.s_giq=0}s_giqf()
if(window._eT)_eT.s=s
_eT.evtA=[
"code	web_sousc_canal	SouscriptionCanal",
"code	AbRM	AbandonRM",
"code	MpMF	MultipackMF",
"pagename	Web/Mon Compte/Espace Groupe/Confirmation	MultipackMF",
"product	BTV.*",
"event8	SC:ADSL:CHANGEOPTION	BouquetTV",
"event8	SC:ADSL:packsecu	ADSLPackSecu",
"purchase	SC:ADSL:CHANGEOFFRE	ADSLChangeOffre",
"event8	SC:ADSL:CANAL	ADSLTVSat",
"pagename	Web/Assistance/Support/Mobile/Reseau/Confirmation	QuestReseau",
"eVar10	2|3",
"url	http://assistance.sfr.fr/runtime/contacter/infos-fixe.html	ResilPnmPnfFixe",
"pagename	Web/RM/Boutique/RM/Decouverte Offre/Liste Mobiles/Privi.*	RMPrivilege",
"pagename	Web/ADSL/Boutique/Conquete/Catalogue Offre/Post-eligibilite/(ADSL|THD|CBL)	EligibiliteFixe",
"pagename	Web/ADSL/Boutique/Conquete/Catalogue Offre/Post-eligibilite/(THD|THD/V2)	EligibiliteFibre",
"pagename	Web/RM/Boutique/RM( Upgrade)?/Decouverte Offre/Liste Mobiles	DebutParcoursRM",
"pagename	(Mobile/Portail Mobile|Web)/Mon Compte/Simulateur Resiliation.*	CalculResil",
"pagename	Web/Assistance/Mobile-et-tablette/Offres-mobile/Calculer-frais-resiliation-anticipee	CalculResil",
"url	http://www.sfr.fr/mobile/(telephone|offre-(portable|telephone)).*(APPLE_iphone|vue=0001lt|marque=apple).*	IPhone",
"product	.*_RED.*|LS.*|CS.*	AchatRED",
"option	S(85[DEF]|77I).*	Maghreb",
"cqtCO	FFB|BLOQUE	DebConqFFB",
"cqtCO	!_RED|LCA|FFB|BLOQUE|KIT|INT	DebConqHV",
"pview	Bol:Conquete Migration Inter Segment (LCA_FFB|LCA_ABO|FFB_ABO)	DebTremplin",
"purchase	.*Bol:Conquete Migration Inter Segment (LCA_FFB|LCA_ABO|FFB_ABO)|.*Bol:Migration Inter Segment (LCA_FFB|LCA_ABO|FFB_ABO)	Tremplin",
"purchase	.*Bol:Signup (FIBRE|THD)	SignupFibre",
"purchase	.*Bol:Signup ADSL|Bol:Signup Gamme-ADSL-StarAc	SignupADSL",
"purchase	.*SC:Option.*	Option",
"purchase	.*SC:Migration|.*BOL:Mig IG|.*Bol:Conquete Migration Inter Segment IG	Migration",
"purchase	.*Bol:(Conquete|VLA)	Conquete",
"consult	Web/Mobile/Boutique/Conquete/Fiche Mobile/.*	ConsultationMobile",
"purchase	(Mobile:)?SC:Rechargement	Rechargement",
"purchase	.*Bol:RM	RM",
"purchase	.*Bol:RM Upgrade|.*Bol:RM UPGRADE	RMUpgrade",
"purchase	.*Bol:MID PC	MidPC",
"purchase	.*Bol:(Conquete )?Migration Inter Segment LCA_FFB	LCAFFB",
"purchase	.*Bol:(Conquete )?Migration Inter Segment LCA_ABO	LCAABO",
"purchase	.*Bol:(Conquete )?Migration Inter Segment FFB_ABO	FFBABO",
"product	Home Securite.*	SouscritHbs",
"purchase	Bol:Eshop:Commande	AchatAccessoire",
"purchase	Bol:BVMO Carre	AchatMobOccasCarre",
"purchase	Bol:BVMO Red	AchatMobOccasRed",
"prop58	.*RED.*	RedForum",
"prop59	.*RED.*	RedForum",
"prop60	.*RED.*	RedForum",
"prop52	.*RED.*	RedForum",
"prop59	.*pnm.*|.*pnf.*|.*portabilite numero.*|.*change(r|ment) operateur.*|.*RIO.*|.*(quitter|arreter|resil.*|.*partir de( chez)?) sfr.*	ChurnForum",
"prop60	.*pnm.*|.*pnf.*|.*portabilite numero.*|.*change(r|ment) operateur.*|.*RIO.*|.*(quitter|arreter|resil.*|.*partir de( chez)?) sfr.*	ChurnForum",
"prop52	.*pnm.*|.*pnf.*|.*portabilite numero.*|.*change(r|ment) operateur.*|.*RIO.*|.*(quitter|arreter|resil.*|.*partir de( chez)?) sfr.*	ChurnForum",
"pagename	Web/Transverse/T5/FAQ/.*siliation D Une Offre RED/Ta P/95	ChurnForum",
"url	http://www.sfr.fr/espace-client/offre-mobile/selfcare-groupe/sfr-femto/.*	InteretFemto",
"url	http://assistance.sfr.fr/runtime/service-et-accessoire/femto/.*	InteretFemto",
"search	.*femto.*	InteretFemto",
"url	http://assistance.sfr.fr/mobile_support/reseau/reseau-mobile/.*	AssistReseau",
"search	.*reseau.*	AssistReseau",
"product	.*P64.*	AchatFemto",
"pagename	.*Web/Home by SFR.*	InteretHome",
"pagename	Web/Accessoires/Boutique/Boutique/Eshop/Categorie/Accessoires Home By SFR	InteretHome",
"search	home SFR|.*alarme.*|.*domotique.*|.*videosurveillance.*|sfr home|.*cambriolage.*|.*intrusion.*|(video|camera) surveill.*|.*intervention site.*|.*prote.* (habitation|maison|domicile|propriet.*|appartement)|.*surveill.* (habitation|maison|domicile|propriet.*|appartement)|.*protee(habitation|maison|domicile|propriet.*|appartement)|.*securise(habitation|maison|domicile|propriet.*|appartement)	InteretHome",
"pagename	Web/Internet Mob/Boutique/Conquete/Liste Offre.*|Web/Internet Mob/Boutique/Conquete/Fiche Mobile|Web/Internet Mob/Boutique/Conquete/Liste Mobile.*	DebParcoursConqCle",
"pview	Bol:Eshop:Commande	DebParcoursAccessoire",
"pview	.*Bol:Conquete Migration Inter Segment FFB_ABO	DebTremplinMBA",
"pview	.*Bol:Conquete Migration Inter Segment LCA_(ABO|FFB)	DebTremplinMPA",
"pagename	(Web/Mobile|Mobile/Portail Mobile)/Boutique/MPA	DebTremplinMPA",
"pagename	Web/Red/Boutique/Homepage/MPR	DebTremplinMPA",
"pagename	(Web/ADSL|Mobile/Portail Mobile)/Boutique/Conquete/Catalogue Offre/Post-eligibilite/(ADSL|THD|CBL|ADSL/V2|THD/V2|CBL/V2)	DebParcoursConqFixe",
"search	iphone|i-phone|apple	IntIphone",
"pagename	Web/Mobile/Services Options/Services Smartphone/Iphone	IntIphone",
"pagename	Web/Mobile/Boutique/SFR/PRE/Mobile/Conquete/(Nouveau|Vla)/(Offre|Mobile)/Fiche Offre.*|Web/Red/Boutique/Mobile/CONQUETE/Fiche Forfait	IntMobile",
"search	.*renouvellement sfr.*|.*changer de mobile.*|(renouvellement|renouveler|changer|changement|nouveau|remplacer|reprise) (mobile|telephone|smartphone|portable)|points? (fidelite|carre rouge)|recyclage (6|5|5s|5c)|iphone	IntRM",
"pview	.*Bol:(RM|rm|Rm).*	IntRM",
"pagename	Web/Mobile/Boutique/(Changer/(Liste Mobile|Fiche Mobile)|Telephonie Mobile/Changer De Mobile/Home)|Web/Red/Boutique/Homepage/Telephones	IntRM",
"pagename	Web/Mon Compte/Offre Mobile/Options Mobile/Femto/Etape7 Confirmation	AchatFemto2",
"purchase	.*Bol:(Conquete|VLA)|.*BOL_Conquete",
"eVar38	.*RED.*	CqtRed",
"purchase	.*Bol:(Conquete|VLA)",
"eVar38	.*CARRE.*	CqtCarre",
"eVar18	MJ.*|MK.*",
"purchase	Changer.(Bol:Mig IG|SC:Migration)",
"eVar38	.*CARRE.*	MRC",
"eVar18	MA.*|MF.*",
"purchase	Changer.Bol:Mig IG|Changer.SC:Migration",
"eVar38	.*CARRE.*	MigCarre",
"eVar18	MJ.*|MK.*",
"purchase	Changer.(Bol:Mig IG|SC:Migration)",
"eVar38	.*RED.*	MigRed",
"eVar18	MJ.*|MK.*",
"eVar38	.*CARRE.*",
"purchase	Changer.Bol:RM Upgrade	RmUpgradeRed",
"eVar18	MA.*|MF.*",
"eVar38	.*CARRE.*",
"purchase	Changer.Bol:RM Upgrade	RmUpgradeCarre",
"eVar38	.*RED.*",
"purchase	Changer.(RM|Rm|rm)	RmRed",
"eVar38	.*CARRE.*",
"purchase	Changer.(RM|Rm|rm)	RmCarre",
"eVar18	MA.*|MF.*",
"purchase	Changer.(Bol:Mig IG|SC:Migration)",
"eVar38	.*RED.*	MCR",
"pagename	.*S(fr C|frc|FRC)loud.*	IntCloud",
"search	(stock(age|er)|enregistre(r|ment)|sauvegarder?|partager?) (donn|document|photo|vid|image|film)|cloud	IntCloud",
"eVar18	99",
"eVar38	.*RED.*",
"purchase	Changer.(Bol:Mig IG|SC:Migration)	MigNARed",
"eVar18	99",
"eVar38	.*CARRE.*",
"purchase	Changer.(Bol:Mig IG|SC:Migration)	MigNACarre",
"eVar18	MF.*|MK.*",
"purchase	.*Bol:Conquete Migration Inter Segment FFB_ABO|.*Bol:Migration Inter Segment FFB_ABO",
"eVar38	.*RED.*	FFBRED",
"eVar18	MF.*|MK.*",
"purchase	.*Bol:Conquete Migration Inter Segment FFB_ABO|.*Bol:Migration Inter Segment FFB_ABO",
"eVar38	.*CARRE.*	FFBCARRE",
"purchase	Changer.(Bol:Mig IG|SC:Migration)",
"eVar38	.*RED.*	MigversRed",
"purchase	Changer.(Bol:Mig IG|SC:Migration)",
"eVar38	.*CARRE.*	MigversCarre",
"purchase	.*Bol:Conquete Migration Inter Segment FFB_ABO|.*Bol:Migration Inter Segment FFB_ABO",
"eVar38	.*RED.*	FFBversRED",
"purchase	.*Bol:Conquete Migration Inter Segment FFB_ABO|.*Bol:Migration Inter Segment FFB_ABO",
"eVar38	.*CARRE.*	FFBversCARRE",
"pagename	(Web/ADSL|Mobile/Portail Mobile)/Boutique/Conquete/Catalogue Offre/Post-eligibilite/(CBL|CBL/V2)	Eligibilitewholesale",
"pagename	(Web/ADSL|Mobile/Portail Mobile)/Boutique/Conquete/Catalogue Offre/Post-eligibilite/(ADSL|THD|ADSL/V2|THD/V2)	NonEligiblewholesale",
"eVar62	..1|31.1|34.1",
"pagename	.*Eligibility Niagara",
"eVar46	.*CHANGEOFFRE	ElicableDejaSFRfixe",
"product	CQT-CBL.*",
"purchase	.*(CBL|CABLE)	AchatCable",
"pagename	.*Layer Ineligibilite.*	NonEligiblewholesale",
"eVar38	ADDICT.CARRE",
"purchase	.*Bol:(Conquete|VLA)	Cle3G",
"pagename	(Web|Mobile/Portail Mobile)/Mon Compte/(InfosLigne|InfosLigne.*)	Infoligne",
"purchase	.*Bol:Change Intra ADSL	MigADSL",
"purchase	.*Bol:Change ADSL Vers FIBRE	MigTHD",
"purchase	.*Bol:Change (ADSL )?Vers CABLE	MigFTTLA",
"pagename	Web/Mon Compte/ADSL/Change Offre/Confirmation	MigNAFixe",
"pagename	(Web/Mon Compte|Mobile Portail Mobile)/NullConfirmation	MigNAFixe",
"eVar38	Fixe_Box-RED",
"purchase	Ouvrir.Bol:Signup CABLE	conqueteFTTBRed",
"pagename	.*Assistance/Mobile-et-tablette.*	AssistanceMobile",
"pagename	.*Mon Compte/Conso Facture.*	ConsoFactMobilePaiement",
"pagename	.*Authentification/(Mon Compte|Autres Services|Layer)	Authentification",
"pagename	.*Mon Compte/Home	HomeMonCompte",
"pagename	.*securite.*	Securite",
"pagename	.*Mon Compte/(Mobile|Offre Mobile|Moncompte Webapp/Moncompte|Moncompte Webapp|Mon Compte Offres Options Mobile/Options|Ligne Mobile)	MonOffre",
"pagename	.*Transverse/(Mon Compte/Mobile|Offre Mobile/Forfait Mobile)	MonOffre",
"pagename	.*Portail Mobile/Mon Compte/Multisurf	MonOffre",
"eVar38	.*RED",
"pagename	.*Tester Ma Ligne/Eligibility Resultats	DebParcoursRedFibre",
"eVar46	.*Signup CABLE.*",
"eVar38	Fixe_Box-RED",
"pagename	Web/ADSL/Boutique/Conquete/Options	EligibiliteRedFibreBis",
"eVar62	0.1	EligibiliteRedFibre",
"eVar62	1	EligibiliteRedFibre",
"pagename	Web/Red/Boutique/Mobile/Conquete/Recapitulatif	DebParcoursRED",
"pagename	Web/Assistance/Accueil.*|Web/Assistance/Home.*|Mobile/Portail Mobile/Assistance.*	AssistanceAccueil",
"pagename	Web/Mon Compte/Mes Avantages|Mobile/Portail Mobile/Transverse/Mon Compte/Mes Avantages|(Mobile/Portail Mobile|Web)/Mon Compte/Mes Avantages/Services Carres	MonCompteAvantages",
"pagename	Web/Forum SFR/Espace Communautaire.*	ForumSFR",
"pagename	Mobile/En Cours Conso Mobile.*|Mon Compte/Mobile/En Cours Conso.*|Mon Compte/Info Conso.*|Portail Mobile/Infoconso.*|Portail Mobile/Mon Compte/Bilan Conso.*|Portail Mobile/Mon Compte/Info Conso.*	Moncompteinfoconso",
"pagename	Web/Mon Compte/Ligne Mobile/Equipement Mobile/Parametrer.*	MoncompteEquipMobile",
"pagename	Web/ADSL/Boutique/Change/Catalogue Offre/Post-eligibilite/CBL	DebParcoursChangeFixe",
"pagename	Web/Mon Compte/ADSL/Change Offre/Confirmation	MigNAFixe2",
"pagename	(Web/Mon Compte|Mobile Portail Mobile)/NullConfirmation	MigNAFixe2",
"url	https://espace-client.sfr.fr/novelli/rioFixe/consultation.*	FragileFixeWeb",
"eVar38	.*RED.*",
"purchase	Changer.Bol:Change (ADSL vers )?CABLE	changeFibreRed",
"eVar10	2|3",
"pagename	Web/Transverse/Recherche.*|Web/Forum SFR/Espace Communautaire/Resultats Recherche.*|Mobile/Portail Mobile/Recherche.*	Recherche",
"option	SPM(1|2)|SECUR	achatSecurite",
"product	SPM(1|2)|SECUR	achatSecurite",
"option	SZ05|PZ05|BT019|CLO100	achatCloud",
"product	SZ05|PZ05|BT019|CLO100	achatCloud",
"eVar38	.*RED.*",
"purchase	Ouvrir.Bol:Signup ADSL	conqueteADSLRed",
"eVar38	.*RED",
"purchase	.*Bol:Conquete Migration Inter Segment LCA_ABO|.*Bol:Migration Inter Segment LCA_ABO	LCAABORed",
"eVar38	.*CARRE",
"purchase	.*Bol:Conquete Migration Inter Segment LCA_ABO|.*Bol:Migration Inter Segment LCA_ABO	LCAABOSfr",
"purchase	.*Bol:Change Intra FIBRE	MigFTTHintra",
"url	https://espace-client.sfr.fr/novelli/fraisResiliation/accueilNovelli	DemNovMob",
"url	https://espace-client.sfr.fr/novelli/resiliationFixe/accueil	DemNovFix",
"product	SSG_LCA_SSMOB_BIOS_PZ0_LCA_0_ECO	AchatKitLCA",
"pagename	Web/Assistance/((Accueil/)?Resiliation|Contacter/Infos.(fixe|mobile))	ResilPnmPnf",
"search	pnm|pnf|portabilite numero|change(r|ment) operateur|(quitter|arreter|resilier|partir de( chez)?) sfr|r?sil.*	ResilPnmPnf",
"pagename	Web/Assistance/Contacter/(Orienteur|Chat|FormSFR|Adresses-service-client|Mobile|Accueil|Infos-mobile).*	AssistanceContacter",
"pagename	(Web|Mobile/Portail Mobile)/Mon Compte/Prise RDV/.*	AssistanceContacter",
"event8	SC:Desimlocage|PWP:Desimlockage	Desimlocage",
"pagename	Web/Mon Compte/Desimlocage/Etape 1/Mobile Connu	Desimlocage",
"pagename	Web/Mon Compte/Desimlocage/Etape 2/Desim Gratuit/Email Connu	Desimlocage",
"search	.*desimloc.*	DesimlocageBis",
"pagename	Web/Assistance/Mobile/Forfait/Mobile/Desimlocker Mobile|Web/Mon compte/Desimlocage/.*|Mobile/Portail Mobile/Desimlo.*	DesimlocageBis",
"pagename	Web/Assistance/Mobile-et-tablette/Offres-mobile/(Desimlockage-iphone-comment-faire|Utiliser-mobile-sfr-desimlocker)	DesimlocageBis",
"pagename	Web/Assistance/Multimedia/Infographie-desimlocker-mobile	DesimlocageBis",
"prop52	.*desimloc.*	DesimlocageTer",
"prop59	.*desimloc.*	DesimlocageTer",
"prop60	.*desimloc.*	DesimlocageTer",
"pagename	Web/Forum SFR/Espace Communautaire/Entraider/Niv4/Forum	DesimlocageTer",
"pagename	Web/Red/Aide/Forfaits-RED-au-quotidien/DESIMLOCKAGE/M-p/15616	DesimlocageTer",
"eVar38	.*RED.*",
"purchase	.*Bol:Change Intra (CABLE|FIBRE|ADSL)	ChangeIGRedFixe",
"search	rio|releve (d.)?identite	IntPnmWeb",
"pagename	(Web|Mobile/Portail Mobile)/Assistance/Mobile-et-tablette/Offres-mobile/Comment-changer-(operateur-tout-savoir-sur-rio|ou-conserver-numero-sfr)	IntPnmWeb",
"pagename	Web/Assistance/Multimedia/Infographie-changer-operateur-mobile	IntPnmWeb",
"pagename	(Web|Mobile/Portail Mobile)/Assistance/Internet-et-box/Offres-box/Comment-changer-operateur-rio-fixe	InteretFragileFixe",
"pagename	(Web|Mobile/Portail Mobile)(/Assistance)?/Multimedia/Infographie-changer-operateur-fixe	InteretFragileFixe",
"search	rio fixe	InteretFragileFixe",
"pagename	Web/Assistance/Internet-et-box/Offres-box/Calculer-frais-resiliation-anticipee-fixe-tv	IntNovFix",
"eVar18	I.*",
"pagename	Web/Mon Compte/Frais De Resiliation/Client Non Engage	IntNovFix",
"pagename	(Mobile/Portail Mobile|Web/Mobile)/Boutique/SFR/PRE/Mobile/Change/MIG/(Offre|Mobile)/(Liste|Fiche) Offre.*	DebutAbanMigRep",
"pagename	(Mobile/Portail Mobile|Web)/Mon Compte/Changement De Titulaire/(Etape Formulaire|Questionnaire|Ineligible)	DebutChtTitu",
"pagename	(Mobile/Portail Mobile|Web)/Mon Compte/Changement De Titulaire/Synthese Formulaire	FinChtTitu",
"pagename	Web/Red/Aide/FAQ/Offre Options/Offre/Gerer/Resilier Ma Ligne Mobile RED	RedFAQResilMob",
"pagename	Web/Red/Boutique/Mobile/RED/POST/Mobile/Conquete/Recapitulatif	DebParcoursRED",
"eVar38	.*RED.*",
"purchase	Ouvrir.Bol:Signup FIBRE	conqueteFTTHRed",
"eVar38	.*RED.*",
"purchase	Ouvrir.Bol:VLA ADSL	vlaADSLRed",
"eVar38	.*RED.*",
"purchase	Ouvrir.Bol:VLA CABLE	vlaFTTBRed",
"eVar38	.*RED.*",
"purchase	Ouvrir.Bol:VLA FIBRE	vlaFTTHRed",
"pagename	Web/Red/Aide/FAQ/Choisir RED/Veux Souscrire/Garder/Choisir RED Et Conserver Son Numero Mobile",
"prop18	M[JK]	IntPNMRed",
"pagename	Web/Red/Aide/FAQ/Offre Options/Offre/Gerer/Resilier Ma RED Box	RedFAQResilFixe",
"pagename	Web/Red/Aide/FAQ/Offre Options/Offre/Gerer/Demenager Ma RED Box	RedFAQDmgt",
"pagename	Web/Red/Aide/FAQ/Offre Options/Offre/Gerer/Renvoyer Mes Equipements RED Box	RedFAQRenvoiEquip",
"pagename	Web/Red/Aide/FAQ/Choisir RED/Veux Souscrire/Garder/Choisir RED Et Conserver Son Numero Fixe",
"prop18	I[HN]	IntPNFRed",
"purchase	Ouvrir.Bol:Device	AchatMobileNu",
"pagename	(Web/Mobile|Mobile/Portail Mobile)/Boutique/SFR/PRE/Mobile/(Conquete/Nouveau/|Change/(MIG/Offre/(Liste Offres|Layer/Telephone)|(RM|RMUP)/Mobile/Liste (Offres|Mobile))).*",
"prop38	.*CARRE.*	DebParcoursCar",
"pagename	Web/Mon Compte/Conso Facture/Info Conso Data Detaillee.*	InfoFactureMob",
"pagename	Web/Mon Compte/Paiement Facture/Client (Demat|Non Demat)/Consultation Facture.*	InfoFactureMob",
"pagename	(Web|Mobile/Portail Mobile)/Mon Compte/Pass/Mobile/En Cours Conso Mobile.*	InfoConsoMob",
"pagename	Web/Assistance/Internet-et-box/(Box-thd-4k-de-sfr|Box-tv-thd-de-sfr|Modem-thd-de-sfr|Telephonie-fixe|Box-fibre|Box-nb4|Box-nb6|Box-plus-de-sfr|Decodeur-plus-de-sfr|Modem-castlenet|Modem-netgear|Modem-thd-wifi-ac|Netgear-cg3700b-ou-cg3100)/(Depanner|Bons|Connexion|Redemarrer|Verifier|Problemes|Ecran|Liste|Pas|Mauvaise|Signal|Emission|Reception|Signal)*	InfoProblBox",
"pagename	Web/Red/Aide/FAQ/Rejoindre-RED/Je-veux-commander-une-offre-RED/La-portabilite-du-numero/Portabilite-du-numero-mobile",
"prop18	M[JK]	IntPNMRed",
"pagename	Web/Red/Aide/FAQ/Rejoindre-RED/Je-veux-commander-une-offre-RED/La-portabilite-du-numero/Portabilite.*",
"prop18	I[HN]	IntPNFRed",
"purchase	.*Bol:Change Option.*	OptionFixe",
"pagename	Web/Assistance/(Box Internet/Demenagement.*|Internet-et-box/Offres-box/(Sfr-fibre-demenagement|Demenagement-sfr|Telephonie-fixe-demenagement)|Multimedia/Video-preparer-demenagement)	DemenagementWeb",""]
function eaQ(f,g,s,X){var p=s.pageName||'',ta=s.eVar46||"",pd=s.eVar19||"",bu=s.prop38||s.eVar38||g('BU')||"",ela=s.eVar61||"",elf=s.eVar62||"",pr=s.products,L=window.location,dat=new Date(),fpan=false,brand="sfr";if(g('prdref')=="XXX")f('prdref',g('prdname')||"xxx");if(getPageType()=="order")f('type',getOrderType());if(p.match(/Boutique\/(Tester Ma Ligne|Conquete)\/(Eligibility Resultats|Layer Resultat Eligibilite)$/i)){var mm=(dat.getMonth()+1)+"",dd=dat.getDate()+"",ref=dat.getFullYear()+(mm[1]?mm:"0"+mm)+(dd[1]?dd:"0"+dd)+"_"+((s.prop36||"").match(/PNDI$/i)?"ndi":"addr")+"_"+(Math.random()*1e6|0);f('ref',ref);f('estimate',1);f('type','test-eligibilite')}if(p.match(/\/ott\/creation.compte$/i)){var mm=(dat.getMonth()+1)+"",dd=dat.getDate()+"",ref=dat.getFullYear()+(mm[1]?mm:"0"+mm)+(dd[1]?dd:"0"+dd)+"_"+"ottbasket"+"_"+(Math.random()*1e6|0);f('ref',ref);f('estimate',1);f('type','ott-basket')}if(g('path').match(/\/devis.formulaire\/confirmation$/i)){var mm=(dat.getMonth()+1)+"",dd=dat.getDate()+"",ref=dat.getFullYear()+(mm[1]?mm:"0"+mm)+(dd[1]?dd:"0"+dd)+"_"+"formulaire-datacatch"+"_"+(Math.random()*1e6|0);f('ref',ref);f('estimate',1);f('type','formulaire-datacatch')}var tmp=p.match(/\/Boutique\/Conquete\/(Layer.)?Fiche Offre\/([a-z0-9-]+)$/i);if(tmp)f('prdref',tmp[2]);if(p.match(/\/Boutique\/(Fixe\/)?(Conquete|Changer)\/Options$/i)||p.match(/^Web\/Mobile\/Boutique\/(Conquete|Changer)\/Configurateur\/EtapeMobileForfait\/P(mobile|offre)/i)||p.match(/Mobile\/Boutique\/(Conquete|Changer)\/Recapitulatif$/i)||p.match(/mobile\/conquete\/nouveau\/offre\/options.et.accessoires$/i)||	p.match(/\/recapitulatif$/i)&&ta=="Ouvrir|Bol:Device"||p.match(/\/Mobile\/(Conquete|Changer)\/Recapitulatif$/i)&&s.prop12=="B_Devis_Mobile_Panier"||p.match(/\/ott\/recapitulatif$/i)){f('scart',1);f('scartcumul',0);if(g('prdref')=="")f('prdref','xxx');if(g('prdref')=='xxx'&&typeof products!=='undefined'){f('prdref',products[0].split(";")[1])}if(g('prdquantity')==''&&typeof products!=='undefined'){f('prdquantity',products[0].split(";")[2])}if(g('prdamount')==''&&typeof products!=='undefined'){f('prdamount',products[0].split(";")[3])}fpan=true}if(g('scart')==1&&g('eatm_section')=="mobile"&&g('eatm_pagetype')=="basket"){f('type',"panier-mobile")}if((ta=="Ouvrir|Bol:Device"||!ta)&&!g('amount'))f('amount',_eT.ckR('eTam'));f('eatm_brand',brand);f('eatm_section',getSection());f('eatm_pagetype',getPageType());f('eatm_eligibility',getEligibilityType());f('eatm_clientType',getClientType());f('marchand',p.match(/(\/Boutique\/|ott\/)/i)||getSection()=="home"?'marchand':'nonmarchand');f('eatm_cp',s.eVar42||"");if(window.location.href.match('news.sfr.fr')){f('eatm_cat1',s.prop31||"");f('eatm_cat2',s.prop11||"");f('eatm_cat3',s.prop36||"");f('eatm_cat4',s.prop43||"")}if(getCheckoutStep())f('eatm_checkoutStep',getCheckoutStep());if(ta&&getPageType()!="order"){f('eatm_intentionType',getOrderType());f('eatm_intentionMatter',orderMatter()?1:0)}if(getPageType()=="order"){f('eatm_orderMatter',orderMatter()?1:0);f('eatm_orderCid',getOrderCid());if(getOrderGroupType())f('eatm_orderGroupType',getOrderGroupType());if(g('prdref').match(/(RED|RBF)/))f('ref','')}if(L.pathname.match(/demenagement/i))f('eatm_intentionnisteDemenagement',1);if(getSeaTheme())f('eatm_seaTheme',getSeaTheme());if(isBrandingCampaign())f('eatm_isBrandingCampaign',1);if(p.match(/\/Storelocator\/Resultats$/)){f('estimate',1);f('type','store-locator');f('ref','sl_'+(new Date().getTime())+Math.floor(Math.random()*100))}if(g('marchand')=="marchand"&&getSection()!="home")f('epgcontext','marchand');if(p.match(/Mobile\/Conquete\/Nouveau\/Offre\/Options.Et.Accessoires$/i)){f('estimate',1)}function getSection(){return(bu.match(/GP\./i)&&bu.match(/FIXE/i)?"4p":bu.match(/GP\./i)||p.match(/(forfait|telephonie).mobile/i)?"mobile":bu.match(/FIXE/i)||p.match(/\/RED\/Home$/i)?"fixe":/HomePages\/Accueil\/V/i.test(p)?"home":p.match(/OTT/i)?"ott":bu?"autres":"")}function getPageType(){return(g('ref')?(g('estimate')==1?"estimate":"order"):p.match(/Mobile\/Conquete\/Nouveau\/Offre\/Options.Et.Accessoires$/i)?"estimate":getCheckoutStep()?"checkout":g('scart')==1?"basket":p.match(/\/(Catalogue|Liste).(Offre|Mobile|Offres)\//i)||p.match(/\/(Datavore\/Home|Liste.(Offre|Mobile)|Internet\/Offre.Red.Fibre\/[^/]+)$/i)||p.match(/\/telephonie.mobile\/mobiles.sans.forfait/i)?"product_list":g('prdref')?"product":p.match(/(\/Accueil\/Accueil|\Boutique\/RED\/Home)$/i)?"home":p.match(/\/Boutique\/[^/]+\/Home$/i)?"category":"content")}function getEligibilityType(){return(elf.match(/\|1$/)?"fttla":elf.match(/^1\|/)?"ftth":ela.match(/^1/)?"adsl":(ta.match(/SIGNUP.[a-z]+$/i)||ta.match(/CHANGE.[a-z0-9]+.VERS.[a-z]+$/i))&&!p.match(/\/Pre-eligibilite\//i)?(ta.match(/(CBL|CABLE)$/i)?"fttla":ta.match(/(THD|FIBRE)$/i)?"ftth":ta.match(/DSL$/i)?"adsl":""):"")}function getOrderType(){if(ta.match(/^hbs$/i))return "homebysfr";var cn=(s.prop7||"BOL").replace('BOLM','BOL'),sp=(p+s.prop41).match(/EPROPAL/i)||cn!="BOL"?"epropal":"online",tp=ta.match(/(OUVRIR.BOL.VLA|CHANGER.BOL.MIG.IG|SC.MIGRATION|BOL.MIGRATION.INTER.SEGMENT.FFB.ABO)/i)&&pd.match(/M(J|K)/)&&bu.match(/^GP.CARRE$/i)?"migrationinter-red":ta.match(/^CHANGER.BOL.RM$/i)?"rm":ta.match(/^CHANGER.BOL.RM.UPGRADE$/i)?"rmupgrade":ta.match(/SIGNUP|CONQUETE|BOL.OTT.SOUSCRIRE/i)?(s.eVar10==1?"conquete":"xsell"):ta.match(/VLA/i)?"vla":ta.match(/INTER.SEGMENT.LCA/i)?"migrationinter-lca":ta.match(/MIG.IG/i)||ta.match(/^CHANGER.BOL.CHANGE.ADSL$/i)||ta.match(/^CHANGER.BOL.CHANGE.INTRA/i)?"migrationintra":ta.match(/^CHANGER.BOL.CHANGE/i)?"migrationautre":ta.match(/SC.RECHARGEMENT$/i)?"rechargement":ta.match(/^OUVRIR.BOL.DEVICE$/i)?"device":"autre",mc=bu.match(/\.(CARRE|RED)/i)&&bu.match(/FIXE/i)?"4p":bu.match(/\.(CARRE|RED)$/i)?"mobile":bu.match(/^FIXE/i)||p.match(/(ADSL.FIBRE|CONQUETE.FIXE)/i)?"fixe":ta.match(/BOL.OTT.SOUSCRIRE/i)?"ott":"autre",sm=ta.match(/CBL|CABLE/i)?"fttla":ta.match(/THD|FIBRE/i)?"ftth":ta.match(/ADSL$/i)?"adsl":bu.match(/^GP.(RED|CARRE)$/i)?"abonne":bu.match(/^GP.LCA$/i)?"lca":"autre";if(ta.match(/^SC.ADSL.CHANGEOFFRE$/i)){mc="fixe";var v=p.match(/\/([^\/]+)VERS([^\/]+)\//i);if(v){var fr=v[1],to=v[2];fr=fr.match(/CBL|CABLE/i)?"fttla":fr.match(/(A|X)DSL/i)?"adsl":fr.match(/FIBRE|THD/i)?"ftth":"autre";sm=to.match(/THD|FIBRE/i)?"ftth":to.match(/CBL|CABLE/i)?"fttla":to.match(/(X|A)DSL/i)?"adsl":"autre";tp="migration"+(fr==sm?"intra":"inter-"+fr)}elsetp="migrationautre"}if(tp=="migrationautre"&&mc=="fixe"){tmp=ta.match(/^CHANGER.BOL.CHANGE.([a-z]+).VERS/i);if(tmp)tp=tmp[1].match(/DSL$/i)?"migrationinter-adsl":"migrationautre";else{var v=g('prdref').match(/^MIG.([a-z]+)[^a-z]([a-z]+)/i);if(v){var fr=v[1],to=v[2];fr=fr.match(/CBL|RBF/i)?"fttla":fr=="thd"?"ftth":fr.match(/(A|X)?DSL/i)?"adsl":"autre";to=to.match(/CBL|RBF/i)?"fttla":to=="thd"?"ftth":to.match(/(A|X)?DSL/i)?"adsl":"autre";tp="migration"+(fr==to?"intra":"inter-"+fr)}elsetp="autre"}}if(mc=="mobile"){if(pr.match(/I[C-G]RP/)&&tp=="migrationintra"){tp="migrationintra-reprice"}}return [brand,cn,sp,tp,mc,sm].join('/')}function getOrderGroupType(){var v=getOrderType();return(orderMatter()?("web_"+(v.match(/^red/i)?"red":"sfr")+"_"+(v.match(/\/4p\//i)?"4p-"+(v.match(/\/adsl$/i)?"adsl":"thd"):v.match(/\/mobile\//i)?"mobile":v.match(/\/fixe\//i)?"fixe-"+(v.match(/\/adsl$/i)?"adsl":"thd"):"autre")):(v.match(/^sfr\/bol\/[^/]+\/rm(upgrade)?\/mobile\/abonne$/i)?"web_sfr_rm":v.match(/^sfr\/bol\/[^/]+\/migrationintra-reprice\/mobile\/abonne$/i)?"web_sfr_mobile_antichurn":v.match(/^sfr\/bol\/[^/]+\/device\/mobile\/abonne$/i)?"web_sfr_mobile_nu":v.match(/^sfr\/bol\/online\/[^/]+\/ott\/autre$/i)?"web_sfr_ott":null))}function orderMatter(){var o=getOrderType();return(o.match(/\/BOL\//i)&&o.match(/\/(CONQUETE|XSELL|VLA|MIGRATIONINTER-(LCA|ADSL))\//i)&&o.match(/\/(MOBILE|FIXE|4P)\//i)&&!o.match(/\/(AUTRE|LCA)$/i))}function getOrderCid(){var o=orderMatter();var r=getOrderType().split("/"),ga=r[4]=="mobile"?(pr.match(/[_-]E[A-C][M678]/i)||pr.match(/[_-]E[A-D][N01]/i)||pr.match(/[_-]QF0/i)?"starter"+(g('prdref').match(/2h/i)?"_2h":""):pr.match(/[_-]E[D-HJK][M678]/i)||pr.match(/[_-]E[E-H][N01]/i)||pr.match(/[_-]QF[12]/i)?"powprem":"autre"):((r[5]=="adsl"?"adsl":"thd")+"_"+(r[3]=="migrationinter-adsl"?"chg":(g('prdref').match(/power|premium/i)?"powprem":(g('prdref').match(/starter/i)?"starter":"autre"))));if(r[4]=="ott"){o=true;ga=g('prdref');var rp=[["sport","spt"],["mensuel","msl"],["months","msl"],["annuel","anl"],["play","ply"],["premium","prm"],["presse","prs"],["alticestudio","as"],["cloud","cld"],["sfr",""],["_",""]];for(var e in rp)ga=ga.replace(new RegExp(rp[e][0],'ig'),rp[e][1])}if(r[3]=="device"){o=true;ga="nu"}return o?[r[4].replace('mobile','mob'),ga].join("_").replace('fixe_',''):""}function getClientType(){return(pd.match(/^M(A|F).I(T|X|B|Y)$/)?"client_multi_sfr":pd.match(/^M(J|K).I(t|x|H|N)$/)?"client_multi_red":pd=="IZ"?"resilie_fixe_sfr":pd=="MR"?"resilie_mobile_sfr":pd=="MR IZ"?"resilie_multi_sfr":pd.match(/IT/)?"client_fixe_thd_sfr":pd.match(/I(X|B|Y)/)?"client_fixe_adsl_sfr":pd.match(/I(t|H)/)?"client_fixe_thd_red":pd.match(/I(x|N)/)?"client_fixe_adsl_red":pd.match(/M(A|F)/)?"client_mobile_sfr":pd.match(/M(J|K)/)?"client_mobile_red":pd=="ML"?"client_lacarte_sfr":pd=="99"?"prospect":"client_autre")}function getCheckoutStep(){return(p.match(/\/(Boutique|Epropal)\//i)&&!fpan?(p.match(/\/Recapitulatif$/i)?1:p.match(/\/Coordonnees(\/[^/]+)?$/i)||p.match(/\/livraison$/i)&&ta.match(/(ouvrir|changer).bol/i)?2:p.match(/\/(Mode De Livraison|Prise De RDV)$/i)||p.match(/\/contrat$/i)&&ta.match(/(ouvrir|changer).bol/i)?3:p.match(/\/Paiement(\/[^/]+)?$/i)||p.match(/\/paiement$/i)&&ta.match(/(ouvrir|changer).bol/i)?4:null):null)}function getSeaTheme(){var toi=L.hash.match(/t3(4|5)_g_ls_([a-z0-9_\-]+)$/i);return toi?toi[2]:null}function isBrandingCampaign(){return(L.hash+L.search).match(/t2_(perf_Display\-Branding|VIDEO_)/i)}}
