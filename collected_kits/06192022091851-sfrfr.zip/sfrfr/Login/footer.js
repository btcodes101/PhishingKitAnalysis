(_eTf=function(W,D,_,$){
W=window,D=document,_=W._eT
if(!_||_.sent)return
$=_.$=W.$sfr&&$sfr.fn&&$sfr||W.$&&W.$.fn&&W.$||W.jQuery
if(_.pf<3&&!(W.zvars&&zvars[19])){
_.pf=_.pf+1|0
setTimeout(_eTf,200)
return}
eTagPopin=function(u,x,y,b){
var m,f=function(e,d){
d=(e||event).data
if(d>0)$('#eTagPopin').remove()
if(d==2)_.c2cP('51bf0c3780df1a0f6a000001')}
f({data:1})
if(b&1)_.msg(f)
if(!x)x=400
if(!y)y=400
m=(b&32)?0:8
if(b&8)y+=m?20:12
var D=document.createElement("div"),w=$(window),h=w.height(),up=h<y+140,dh=$(document).height()
if(up)setTimeout(function(){scrollTo(0,0)},90)
D.setAttribute("id","eTagPopin")
D.setAttribute("style",'overflow-x:hidden;margin:0;padding:0;z-index:99998;position:'+(up?'absolute':'fixed')+';top:0;left:0;border:0;width:100%;height:'+(up&&dh<h?h+'px':'100%')
+';background:'+(b&4?'rgba(255,255,255,.7)':'transparent url('+_.med+'fond-layer-75pct.png) repeat')
+(u?'':';display:none'))
D.innerHTML='<div style="overflow-x:hidden;margin:'+(h<y?0:(h-y)*4/9)+'px auto;padding:0;'+(b&16?'max-':'')+'width:'+x+'px;min-height:'+y+'px;'
+(b&2?'background:transparent;border:0 solid none':'background:white;border:2px solid #666')+'">'
+(b&1?'':'<p style="font-family:Arial;font-size:9px;position:relative;z-index:1;padding:2px;margin:0 0 -12px;float:right;cursor:pointer;color:#777" onclick="_eT.$(\'#eTagPopin\').remove()">FERMER <b style="font-size:12px;font-weight:bold">X</b></p>')
+(b&8?'<a style="cursor:pointer;float:right;text-decoration:none;color:#999;font-weight:bold;font-size:17px" onclick="parent.postMessage(\'1\',\'*\')">X</a><p style="padding:2px 0;font-size:15px;font-weight:bold;color:#e2001a;margin:0;text-align:center">'+(_.piT||'')+'</p>':'')
+(u&&u.match(/^</)?u:u?'<iframe scrolling="0" frameborder="0" src="'+u+'" style="width:'+(x-m-m)+'px;height:'+(y-m-m)+'px;border:0 solid transparent;background:transparent;margin:'+m+'px" allowTransparency="true"></iframe>':
'<div style="padding:9px 0 0 0" id="eTagArrowPopin"></div>')+'</div>'
_.piT=''
document.getElementsByTagName("body")[0].appendChild(D)
$('#eTagPopin').click(function(){$(this).remove()})
$('#eTagPopin>div').click(function(e){e.stopPropagation()})
return!1}
eTagPopinSortie=function(n,s){
var e=ckR('eTagPS'),v,fi=function(i,x,y,a){
return _.im+'gred-rtp-'+i+'.png" style="border:0;position:absolute;top:'+y+'px;left:'+x+'px'+(a?';cursor:pointer" onclick="parent.postMessage(\'1\',\'*\');return '+a:'')+'"/>'}
if(!n)n=1
if(e&n)return!0
if(_.$('.layerShare:visible').length)return!0
ckW('eTagPS='+(e|n),8)
if(n&8&&_.fQ)_.fQ()
else if(n&96){_.popin('<div style="position:relative;width:100%;height:100%">'+(n&32?
fi('pre',0,0)+fi('pre-btn',236,388,"$sfr('.open-configurator')[0].click()"):
fi(/M=[AV]DSL/.test(_.fel('RED'))?'post-dsl':'post',0,0)+_.im+'gred-rtp-post-btn1.png" style="border:0;position:absolute;top:388px;left:200px;cursor:pointer" onclick="return _eT.c2cRed();">'+fi('post-btn2',388,388,1))+
'<div style="position:absolute;top:8px;right:8px;width:36px;height:36px;cursor:pointer" onclick="parent.postMessage(\'1\',\'*\')"></div></div>',737,463,0,-1)
stats({pn:"Conquete/SortiePostEli",si:"B_Box_Pop2TestEligibilite"})}
else if($&&n&16){_.piT="Vous êtes sur le point de quitter la boutique en ligne";$('#c2cD a').click()}
else if(n&992&&_.piF)_.piF()
else eTagPopin(ist+'/export/bloc/richtext/popin.sortie.'+(n&2?'adsl.promo':'signup')+'/default.html',648,332,0)
return!1}
eTagSortie=function(n){if($&&!(ckR('eTagPS')&n)){
var m=0,t=0,ae=window.addEventListener
if(!_.PSF){_.PSF=1;(ae?ae:document.attachEvent)((ae?'':'on')+"mouseout",function(e){e=e||event;if(e.clientY<0)eTagPopinSortie(n)})}
if(n&1)$('#block-click-to-help-top a').click(function(){ckW('eTagPS=3',4)})}}
eTagS=function(u,f){if(u&&f){
u=u.replace(/"/g,'')
if(f&1)D.writeln('<script src="'+u+'"></script>')
if(f&2)_.JS('//www.sfr.fr/recherche/js/log.js?eTagU='+escape(u)+(W.s?'&e46='+escape(s.eVar46)+'&e19='+zvars[19]:''))
if(f&4)_.JS(u)
if(f&8&&D.images)new Image(1,1).src=u
if(f&16)$('body:eq(0)').append('<iframe style="height:0;width:0;border:0;display:none" src="'+u+'"></iframe>')}}
var cms=_.cms,ckR=_.ckR,ckW=_.ckW,ckD=_.ckD,ckT=_.ckT,par=_.par,M=_.M,T=_.T,ST=_.ST,SM=_.SM,ist=_.ist,med=_.med,im=_.im,JS=_.JS,log=_.log,to=_.to,ti=_.ti,wait=_.wait,
b,f,o,r,t,v,Z=W.zvars||[],
rbs=cms||ckR('ISTCMS')?'//cms.red-by-sfr.fr/':ist+'redbysfr/',
dja='export/bloc/django/',dj=ist+dja,
_A=W.arrow||[],
RE='replace',GI='getElementById',IH='innerHTML',
ECR=0,
WM='WM@/webmail/mailbox.html',WMR='webmail.sfr.re',WMN=T('webmail(@|.vmail@:445)|^liamwebmail@|^atelier.pp.messagerie@'),
MKG=(ckR(M('red@')?'eTmkgR':'eTagMKG')+'|||').split('|'),mkg=MKG[0],acn='21cac24e34b1224321a4252e2cab846b',
l=D.location,h=l.host+l.pathname[RE](/\/$/,''),X=ckR('eTagXX'),Rf=D.referrer||'',TS=new Date*1,TH=TS/36e5-376944|0,
N=navigator.userAgent||'',
$B=$&&$('body').eq(0),
$rm=function(o){$(o).remove()},
$t=function(o){return $(o).text()||''},
$h=function(o){return o&&$(o).html()||''},
$hC=function(o,r){return $h(o).indexOf(r)>-1},
$hM=function(o,r,i){i=-1;while(++i<o.length)if($h(o.eq(i)).match(r))return o.eq(i);return $([])},
$hR=function(o,r,s){$.each($(o),function(v,o){v=$h(o);if(r.test?r.test(v):v.indexOf(r)>-1)$(o).html(v[RE](r,s))})},
$hT=function(o,n,r,s){$.each($(o),function(v,o){o=$(o).contents()[n];if(o&&(v=o.textContent)&&(r.test?r.test(v):v.indexOf(r)>-1))o.textContent=v[RE](r,s)})},
$p=function(o){return $(o).parent()},
$w=function(o){return $(o).width()||0},
$ow=function(o,w){w=0;$(o).each(function(i,o){w+=$(o).outerWidth()||0});return w},
$op=function(o,b,t){$(o).animate({'opacity':b||0},t)},
$cl=function(o,n){if(o=$(o)[n||0])o.click()},
$pc=function(v){if(v)$B.append('<img style="display:none" src="'+v+'"/>')},
TL=function(v){s_tl(this,'o',s.pageName+v)},
f0=function(){},
r6=Math.random()*1e6|0,
wma=function(o,w,f,p){
_['wma'+w]=function(d){p=_.prenom;o.html((d&&d.content||'')[RE](/\$P\$(.)/,p?p+'$1':''))}
p=s.eVar19||''
p=['defaut','mobile','fixe','multi'][/[RrZ]/.test(p)?0:/M.*I/.test(p)?3:/M/.test(p)?1:/I/.test(p)?2:0]
JS(dj+w+p+'.json?callback=_eT.wma'+w)},
w3=function(s){return s[RE](/\*([^;}]*)/g,"-khtml-$1;-moz-$1;-webkit-$1;-o-$1;-ms-$1;$1")},
cpt=_.cpt=function(s,f,x,y,z,c,b,a,F,I){
a=a||'#fff'
b=b||'url('+med+'bg-compteur.png) no-repeat'
c=c||'#fff'
$(s).css('position','relative').append('<style>'+
'#eTcpt{position:absolute;top:'+y+'px;left:'+x+'px;height:80px;width:204px;background:transparent;z-index:99;font-family:"SFR-regular"}'+
'#eTcpt>div{float:left;width:44px;height:42px;margin:0 6px 0 0;padding:2px 0;background:'+b+';color:'+a+';text-align:center;font-size:10px}'+
'#eTcpt>div>p{margin:0 0 2px;text-align:center;line-height:28px;font-size:22px;color:'+c+';font-family:"SFR-bold"}'+
'#eTcpt>p{margin:0 2px 0;font-size:17px;color:'+a+'}'+
'</style><div id="eTcpt"/>')
I=setInterval(function(){
var d=new Date/1e3|0,t=f>d?f-d:0,j=t/86400|0,h=(t/3600|0)%24,m=(t/60|0)%60,s=t%60,p='</div><div><p>'
if(!t){clearInterval(I);F&&F()}
$('#eTcpt').html((z?'<p>'+z+'</p>':'')+'<div><p>'+
j+'</p>jour'+(j>1?'s':'')+p+
(h>9?'':'0')+h+'</p>heure'+(h>1?'s':'')+p+
(m>9?'':'0')+m+'</p>minute'+(m>1?'s':'')+p+
(s>9?'':'0')+s+'</p>seconde'+(s>1?'s':'')+'</div>')},333)},
ico=function(){_.nr&&$&&$('link[rel=icon]').attr('href',med+'favicon-redbysfr.ico')},
inq='https://sfr.inq.com/chatskins/launch/inqChatLaunch316.js',INQ=W.SHR||!(_.cc&2),
CM=[],CC='9||501a91513cc7165126000000|509bd06d58799d5222000000|52f281eb7fdf1a8c3d8b4568|526fcc6380df1ad6383c99d8||7|54bf72277fdf1a73788b4567|54d096417fdf1aa2598b4568|550b093a80df1a47348b4568|51af62d980df1aa66d000001|50d077067fdf1a0d76000000|56582d6980df1a213b8b4567|58d9303680df1adc5e8b4567'.split('|'),
wh=function(){return W.innerHeight},ww=function(){return W.innerWidth},wm=function(){return ww()<768},
c2c=_.c2c=function(c,b,a,S,N){
if(W.SHR&&T('@/terminer-ma-com'))c='5a12f6c07fdf1adc4b8b4568'
if($('#eTc2')[0])return
S=ckR('eTshrS')
if(c==1||c==6)c=2
ST('#baSticky{D0!}#c2cD{opacity:0!;right:-99px!}#eTc2{position:fixed;bottom:45px;right:10px;cursor:pointer;z-index:'+(S?99999:59600)+'}'+
'#eTc2b{background:rgba(0,0,0,.7);position:fixed;width:100%;height:100%;top:0;right:0;z-index:69600}'+
'#eTc2b div{position:absolute;bottom:45px;right:10px}#eTc2b p>*{cursor:pointer}'+
'#eTc2b p{height:53px;padding:0;margin:-53px 0 0;overflow:hidden;transition:margin 0.5s ease-out}#eTc2b img{float:right;min-width:53px}'+
'#eTc2b img+img{margin:13px}'+
'#eTc2b h4{font:bold 18px SFR-bold,Arial;color:#fff;text-align:right;margin:25px 65px -15px 0;padding:0}'+
'#eTc2b span{margin:11px;padding:8px;background:#f5f5f5;float:right;font:12px SFR-Regular,Arial;color:#444;min-width:90px;text-align:center;border-radius:14px}'),SM(767,'#eTc2,#c2cb div{right:7px}')
if(T('espace-client-red@|^#')&&c==null)return _.c2cRed()
if(_.app||W.PMU||e24==9803132||e24==9803133)return
if(T('@$')&&TH%24%20>6)b=b|8
var m=_eT.mob(),C=c,i='inqC2C2ImgContainer'
if(!(INQ||b&1||/MSIE[6-8]/.test(N))&&T('@'))JS(INQ=inq)
if(c=/^[0-9a-f]{24}$/.test(c)?c:
c==33?'58e7a67d80df1a13688b4567':
c==44?'582c37f97fdf1a2e118b4567':
c==22?'575ea30d7fdf1ad4128b4568':
S?'5a12f6c07fdf1adc4b8b4568':
m&&CM[c]||CC[c]||0)$B.append('<style>#c2cD{display:none}'+w3(b&2?
'#c2cD{position:fixed;bottom:15%;z-index:9;right:-222px;*transition:right 200ms ease}'+
'#c2cD:hover{right:-1px}#c2cD img{display:block}'+
'#c2cD a{color:#fff;font-size:13px;font-family:Arial;font-weight:bold;padding:7px 17px;background:#636397;*box-shadow:0 2px 0 rgba(0,0,0,0.2);*border-radius:4px}'+
'#c2cD a:hover{text-decoration:none;background:#8e8ab3}#c2cD i{position:relative;display:inline-block;background:url('+med+'arrow-btn-sprite-small.png) no-repeat transparent;width:20px;height:15px;top:3px}'+
'#c2cD .d1{position:absolute;left:-75px;width:75px;height:82px;bottom:30px;cursor:pointer}'+
'#c2cD .d2{position:relative;width:220px;border:1px solid #6969b2;background:#FFF;text-align:center;padding-bottom:15px}'+
'</style><div id="c2cD"><div class="d1">'+im+'selfcare-sticky-closed.png"/></div>'+
'<div class="d2">'+im+'selfcare-sticky-img.jpg"/>'+
'<a href="#"><i></i>Être rappelé</a></div></div>':
'#c2cD{width:70px;position:fixed;z-index:59900;right:0;top:45%;transition:all 0.5s}#'+i+'{position:static!important;font-size:0}#'+i+'>img{margin:0 0 1px}'+
'#c2cD .t1{width:70px;height:67px;margin:1px 0!important;cursor:pointer;background:url('+med+(b&4?'sticky_selfcare_ctc_rm_70x67':'sticky-sprite')+'.png) no-repeat!important}'+
'</style><div id="c2cD">'+(c==9?'':'<a href="#"><div class="t1"></div></a>')+'<div id="'+i+'"></div>'+
(b&8?'<div onclick="location=\'https://www.sfr.fr/service-client-1099.html#sfrintid=V_contact_1099-sticker\'" style="width:70px;height:67px;background:url('+med+'sticky-sprite.png) no-repeat 0 -136px"></div>':'')+'</div>'))
if(c)$('#c2cD').show()
if(!(b&2))SM(767,'div#c2cD{top:auto;bottom:0}'),SM(1080,w3('#c2cD{filter:alpha(opacity=70);*opacity:0.7}#c2cD:hover{filter:alpha(opacity=100);*opacity:1}'))
$B.append(im+(S?'3-rappel':'1-general')+'.png" id="eTc2"/>'),$('#eTc2').click(function(f,v,l,n,o){
if(!/change/i.test(par('context'))&&!/Changer/.test(s.eVar46)&&!T('@/sfr-sat')){location='//www.sfr.fr/contacter/';return}
if(S)return $('#c2cD a').click()
f=function(n,l){return im+n+'.png"/>'+(l?'<span>'+l+'</span>':'')}
n='#'+i+'>img[onclick]'
$B.prepend('<div id="eTc2b"><div><h4>SERVICE COMMERCIAL</h4><p>'+f(v='3-rappel','Être rappelé')+'</p><p>'+f(v='2-chat','Chatter')+
'</p><h4>ASSISTANCE CLIENT</h4><p>'+f(v='4-assistance','Vos réponses en quelques clics')+'</p><p>'+f('5-fermeture')+'</p></div></div>')
o=$('#eTc2b p')
o.css('margin-top',17)
o.eq(0).click(function(){
if(/change/i.test(par('context'))||/Changer/.test(s.eVar46))_.c2cP('52f281eb7fdf1a8c3d8b4568')
else if(T('@/sfr-sat'))$rm('#eTc2b'),_.c2cP(c)
else location='//www.sfr.fr/contacter/'})
o.eq(1).click(function(){$rm('#eTc2b');$(n).click()})[$(n).height()?'show':'hide']()
o.eq(2).click(function(){location='https://assistance.sfr.fr/contacter/#sfrclicid=Sticky_Assistance'})
o.eq(3).click(function(){$rm('#eTc2b')})
})
N=0,ti(function(n){n=N++%120;if(n>39&&n<52)$('#eTc2').css('opacity',n&1)},250)
$('#c2cD a').click(function(){_.c2cP(c);if(a)a()})},
evt=function(n,e){e=s.events;s.events=(e?e+',':'')+(n>0?'event'+n:n)},
SC=_.scan=function(S,F){if(S){
var L,R=''
for(var i=0;i<S.length;i++)if(L=S[i]){
var V=L.split('~'),e=V.shift()[RE](/^A/,'assistance@(/runtime)?/'),c=e.charAt(0),d=e.substring(1)
if(c=='='){R=d;continue}
if(M(c=='>'?e=R+d:e)&&F(V))break}}},
wf=function(v,f){if(W[v]&&W[v][f])W[v][f]();else to(function(){wf(v,f)})},
p,E,Q,eL="//www.sfr.fr/recherche/js/log.js?eTag",pu,pugm,pv,
upV=function(){
E=s.events||'';Q=s.products||'';pu=E.match(/\bpurchase\b/i);pugm=pu;pv=E.match(/\bprodview\b/i)
Q=Q&&Q.match(/;.*;.*;/)?Q.split(","):[]},
prod=function(Q,s){
if(!Q)return ['','','']
var p='',M=0,N=0,T='',O=''
if(!s)s=','
for(var i=0;i<Q.length;i++){
var R=Q[i].split(';'),m=1*R[3],n=1*R[2],v=R[1]||''
if(!v.match(/^FICTIF/)){
n=n>0?n:m>0?1:0;N+=n;M+=m*n;p+=s+R[1]
if(v.match(/^([0-9]{5,18}|ESHOP[0-9]+)$/)){if(!T)T=R}else{if(!O)O=R}}}
return [p.substring(1),''+N,''+M,T,O]},
dev=_.dev,
lse=_.lse=function(b,o,l,v){l=_.LL;v=ckR('MLS');if(l&&v)for(i=0;l[i];i++){o=spl(l[i],':');if(o[2]==v)break;else o=0}return o||b&&l&&spl(l[0],':')},
prf=function(p,P){
P=spl('U`mABONNE`MA`mFORFAIT_BLOQUE`MF`mABONNE_RED`MJ`mFORFAIT_BLOQUE_RED`MK`mPREPAYE`ML`mENTREPRISE`ME``mRESILIE`MR`dABONNE`Da`dFORFAIT_BLOQUE`Df`dPREPAYE`Dl`dSECOURS`Ds`iTHD`IT`iADSL`IX`iTHD_RED`IH`iADSL_RED`IN`iBASDEBIT`IB`iSECONDAIRE`IS`iORPHELIN`IO`iRESILIE`IZ`VOIX_FIXE`V')
return P[P.indexOf(p[RE]('MOBILE_','m')[RE]('DATA_','d')[RE]('INTERNET_','i'))+1]||99},
F2=function(d){return(d>9?"":"0")+d},dat=function(d){return d&&(d=new Date(d*1))?F2(d.getDate())+"/"+F2(d.getMonth()+1)+"/"+d.getFullYear():""},
fNo=_.fNo=function(l){return l[RE](/^(\d\d)(\d\d)(\d\d)(\d\d)(\d\d)$/,'$1 $2 $3 $4 $5')}
_.wS=_.wS*2|9
if(X&&!_.s&&_.wS<999)return to(_eTf,_.wS)
upV()
_.nr=_.nr||ckR('ISTRED')>0&&T('(espace-client(-red)|assistance)?@')
if(T('@/(recherche|portail.html)')&&!W.eTnr)_.nr=0
_.uA=(v=ckR('eTagArrow'))==2?'//cms.sfr.fr/arrow/bouchon/':'//'+(v==3?'www.sfr.fr.ipp2':v==1?'cms':'www')+'.sfr.fr//arrow/'
_.U=function(s){var a=s.split('~'),r=a[0],i;for(i=1;i<a.length;i++)r=r[RE](a[1].charAt(0),a[1].substring(1));return r}
_.popin=function(u,x,y,t,c,b,m,h,f,s,w,S){
$=$||W.$||W.$sfr;if(!$)return
$B=$('body').eq(0)
s=wh()
S=$(W).scrollTop()
if(y>0&&y+(t>0?t:0)>s)y=s,t=0
s=x>0?x:m>0?m:0
m=m>0?m+'px':m||'100%'
b=b||'transparent'
ST('body.eTpi{position:fixed!;width:100%!;margin-top:-'+S+'px!;height:initial!}')
f=function(){$B.removeClass('eTpi');$rm('#eTpi');$(W).scrollTop(S);_.pi0=0}
c=c||(_.nr?'00e094':'e2001a')
if(!t&&y>0)t=(wh()-y)/2
x=x>0?x+'px':x||'60%'
y=y>0?y+'px':y||'60%'
t=t>0?t+'px':t
h=h>0?h+'px':h
$rm('#eTpi')
w=';max-width:'+m+';width:'+x
$B.addClass('eTpi').append(
'<div id="eTpi" style="overflow-x:hidden;margin:0;padding:0;z-index:99998;position:fixed;top:0;left:0;border:0;display:block!important;visibility:visible!important;'+
'width:100%;height:100%;text-align:center;background:rgba(0,0,0,.7)"><style>'+
'#eTpiC{cursor:pointer;height:50px;width:50px;margin:'+t+' 0 0 '+x[RE](/^(\d+)/,function(m,p){return p/2})+';border-radius:0 4px 4px 0;'+
'background:url('+med+'picto-close-3.png) no-repeat center #'+c+';position:absolute;left:50%;z-index:-1}'+
'#eTpiF{height:'+y+w+(h?';max-height:'+h:'')+';border:0 solid transparent;background:'+b+';padding:0;margin:'+t+' auto 0}'+
(s?'@media only screen and (max-width:'+(s+99)+'px){#eTpiF{margin:0 auto}#eTpiC{margin:0 auto'+w+';height:32px;background-position-x:99%;position:static;border-radius:0}}':'')+
'</style>'+(c<0?'':'<div id="eTpiC"></div>')+
(u.charAt(0)!='<'?
'<iframe id="eTpiF" scrolling="0" frameborder="0" src="'+u+'" allowTransparency="true"></iframe>':
'<div id="eTpiF">'+u+'</div>')+'</div>')
wait(function(){return!$('#eTpi:visible').length&&(f(),1)})
if(c+1)$('#eTpi,#eTpiC').click(f)
$('#eTpiF').click(function(e){e.stopPropagation()})
_.msg(function(e){if(e.data==1)f()})
return!1}
_.elg=function(u,p,n,m,c,o,f,x){
if(u&&u[0]=='*')x=-1,u=u.substr(1)
var H='&hideFooter=true',O='&hideIsSFRCustomer=true',U=['SFR','RED','PNC','PVM'],A='ADSL,CBL,THD',e=_.fel(u),F='.sfr.fr/offre-internet/box-thd?fromeligibility=true',R=/^POW/.test(u)&&u
f=f||_.elf
ckW('eTbfF='+(R?'1':''),R?1:-1)
if(_.PRO)A='ADSL'
if(W.SHR)A='ADSL,CBL,THD'
p=p?"&selectedPkg="+p:""
u=U.indexOf(u);if(u<0)u=0
if(p&&e.match(/M=[A-Z|]*CBL/)){location='http://'+(u%2?'red':'www')+F+p;return}
m=m||[A,'ADSL,CBL','CBL',A][u]
c=c||['e2001a','00e094','588c01','672D65'][u]
o=o>0?(o&1?H:'')+(o&2?O:''):o||[H,H,H+O,H+O][u]
if(T('@/box-internet/srp.html'))U[u]='SHP'
_.popin('//'+(cms&&!R?'cms':'www')+'.sfr.fr/tester-ma-ligne/eligibility-by-ndi.htm?univers='+U[u]+m[RE](/^|,/g,'&marques=')+o,728,720,0,x)
_.msg(function(e){
ckW('eTelg=1',1)
var d=e.data,g='thd',G='CBL',v,
l=_.elgR||T('@/(startersrp|offre-internet|box-mobile|box-internet/(startersrp|tv-samsung-offerte|config4p).html)')?0:'https://'+(cms?'cms':'www')+F
if(d!=7&&d[0]!='{')return
eval('d='+d)
if(d==7||d&&d.eligibility){
if(f)return postMessage('1','*'),f(d)
if(T('@/mon-espace-client/try-and-buy'))return postMessage('1','*'),!1
if(T('@/telephonie-mobile\/multi-?packs?-sfr'))l='/telephonie-mobile/multi-packs-sfr-internet-mobile.html'
if(R&&(e=_.fel('SFR').match('M=([A-Z]+)'))){
ckW('eTagMKG='+(v='baa7b67e1e5551fbc54e3981df325541')+'||',2)
e=e[1]
if(e=='ADSL')g='adsl',G='DSL-ZV'
if(e=='CBL')g='thd',G='CBL'
if(e=='THD')g='fibre',G='THD'
l='https://www.sfr.fr/offre-internet/box-'+g+'/?partnerid='+v+'&fromeligibility=true&selectedPkg=CQT-UT-'+G+'-3P-POWER'+(R=='POW+'?'PLUS':'')}
if(l)location.href=l;else location.reload(!0)}})
return!1}
_.arWM=function(){
var i='#SFReTAGArrowMain',w=$w(i),M=$(i+' img.M'),f=_.arWM,v=$(i+':visible').length
$p($(i).find('eTag,etag').css('padding-right',3)).css('white-space','nowrap')
if(!_.arOK){
_.arOK=1
M.load(f)
ti(f,500)
$(W).resize(f)}
if(v){
$(i+' img.H')[w<760?'hide':'show']()
M.show()
if($p(M).height()>M.outerHeight(!0))M.hide()
$(i+' .zone1,'+i+' .caret').css('display',w<720?'none':'inline')
$(i+' .zone2').css('display',w<600?'none':'inline')}}
_.c2cRed=function(c){
if(W!=top)top.postMessage('{"C2CR":"'+c+'"}','*');else _.popin('//appel.sfr.fr/webcallback_form?CAMPAIGN_ID='+(c&&(c+'').length==24?c:ckR('eTshrR')?'583dbed17fdf1a7d758b4567':'5ad5b5987fdf1ad1368b4567'),320,440,0,-1)}
_.c2cP=function(c,v,u,i){
if(top!=W)return top.postMessage('{"C2CS":"'+c+'"}','*')
if(!c&&T('@/espace-client/offres-et-options/demenagement.htm'))v=_.lse(1),v=v&&v[4],
c=v=='FTTB'?'591bf8d780df1a8d4a8b4567':v=='FTTH'?'591bfdba80df1aae598b4567':'591bfb1b80df1a67528b4567'
if(c==CC[4]&&/withMobileSel=true/.test(location.search))c='59709c6680df1ad32a8b4567'
if(par('c2cD'))v='","',ckW('eTc2cD='+escape('{LM:["'+(_.LM||[]).join(v)+'"],LF:["'+(_.LF||[]).join(v)+'"]}'))
u='//appel.sfr.fr/webcallback_form?CAMPAIGN_ID='+(c||CC[2])+'&R='+h+(e4?'&I='+e4:'')
return i||c=='5771047280df1a3c018b4568'?location=u:_.popin(c==7?dj+'popin.c2c.bolr.html':u,560,420,0,0)}
_.xR=function(x,v){return x.charAt(0)=='!'?!v.match(new RegExp(x.substring(1))):v.match(new RegExp(x))}
_.E38=function(e){e=s.eVar38||'';return e=='GP.CARRE'?1:e=='GP.RED'?2:0}
_.EV=function(c,p){
upV()
var e4=s.eVar4||'',e28=s.eVar28||'',e38=s.eVar38||'',e46=s.eVar46||'',e52=s.eVar52||'',e61=s.eVar61||'',kw=_.KW||s.prop3||'',pn=s.pageName||'',AE=_.evtA||[],a='['+(e4?e4:'@')+']',A,A0,A1,A2,V,R,v,e,ok=1,id,
cb=typeof c=='function'?c:0,code=cb?0:c,
sQ=function(v){var i,r=0,e=new RegExp(v);for(i in Q)r=r||Q[i].match(e);return r}
if(W._uxa&&T('@/forfait-mobile')&&(v=pn.match(/Offre\/Layer\/(.*)/)))_uxa.push(['trackPageview',location.pathname+location.hash[RE]('#','?__')+'?cs-layer='+v[1]]),log('UXA='+v[1])
if(_.elr){
if(T('espace-client@/services-web/panier'))_.elr([1])
if(/devis formulaire.confirmation$/i.test(p))_.elr([7,p])
if(T('appel@')&&/Mise En Relation/.test(pn))_.elr([8,s.prop71])
if(T('@/forfait-mobile/')&&/\/Layer\//.test(pn)||T(RBOL))_.elr([1])}
if(!(_.cc&2)||!e28)return!0
if(e46){
v=ckR("parcoursRM")
if(!v&&!pu&&e46.indexOf("Bol:RM")==0)ckW("parcoursRM="+e46,720)
if(v&&v!=e46&&(v!="Bol:RM"||e46!="Bol:RM Upgrade"))code='AbRM'
if(v&&pu||code=='AbRM')ckW("parcoursRM=0",-9)}
if(e46=="SC:Avantages:Multipack"&&E.match(/\bevent8\b/)||(s.prop48||'').match(/Tarif Multipack/)&&pn=="Web/Mobile/Boutique/Conquete/Panier/Confirmation")code='MpMF'
for(e=0;e<AE.length;e++){
A=AE[e].split("\t")
if(ok||A0){
ok=0
A0=A[2],A1=A[0],A2=A[1]
R=new RegExp("^("+A2+")$","i")
V=new RegExp("\\b("+A2+")\\b","i")
if(E.match(new RegExp("\\b"+A1+"\\b",'i'))&&e46.match(R))ok=1
if(A1=='pagename'&&pn.match(R))ok=2
if(A1=='search'&&kw.match(V))ok=3
if(A1=='url'&&D.URL.match(R))ok=4
if((A1=='product'||A1=='option'&&e46=="SC:Option")&&pu&&sQ(';'+A2+';'))ok=5
if(A1=='code'&&code&&code==A2)ok=6
if(A1=='music'&&(e46=="BOL Musique:AMF"||e46=="Mobile:Bol:Musique")&&pu&&sQ(A2))ok=7
if((s[A1]||'').match(R))ok=11
if(A1=='cqtCO'&&e46=="Bol:Conquete"&&E.match(/\bscCheckout\b/i)&&_.xR(A2,Q))ok=12
if(A1=='pview'&&pv&&_.xR(A2,e46))ok=14
if(A0){
if(A1=='nav7'&&pn.match(R)&&!ckR(A0)){ok=8;ckW(A0+'=1',168)}
if(A1=='navJ'&&(D.URL.match(V)||pn.match(V))&&ckR(A0).indexOf(a)<0){ok=9;ckW(A0+'='+ckR(A0)+a,4)}
if(A1=='nav'&&N.match(V)&&!ckR(A0)){ok=10;ckW(A0+'=1',360)}}
if(!_A.B&&ok&&A0){
_.evt=A0
v=e4||ckR('eTe4');o=lse(1);if(o||v)JS((cms?'//cms.sfr.fr/eTagP?H=':'//www.sfr.fr/eTagP?h=')+A0+'~'+e28+'~'+(v?v+'~~':'~vide~')+(o?o[0]+'~'+o[5]+'~'+o[6]:''))
JS(_.uA+'event?eventId='+A0+'&browserId='+e28+'&ascId='+v+'&deviceType='+dev()+(ok==13?'&param='+id:''),cb)
cb=0}}
else A0=A[2]}
if(cb)cb()
return!0}
var eS=ckR('eTagEspaceSFR')
if(ckR('eTab765')>1&&M('#/forfaits-mobiles$'))
D.writeln('<link href="https://static.s-sfr.fr/redbysfr/resources/css/red/pages/forfait-mobile/light-version.css" rel="stylesheet" type="text/css">')
if(T('appel@/webcallback_form'))zvars['prop62']=par('R')||Rf
if($&&T('[^/]*cloud@'))JS(ist+'resources/js/cloud'+(W.SYS_CONFIG["static.web.resource.path"]!="static/20170809-1107"?2:'')+'.js'),_.nr=0
if($&&eS&&M('@/tester-ma-ligne/eligibility-')){
v='.SFR_EligibilityResult_'
o=$(v+'buttons a')
$('.SFR_ModalFooterHelp').hide()
if(o.length){
$rm(o)
$(v+'espace').css({"font-size":"16px","text-align":"center","font-weight":"bold"}).text('POUR ALLER PLUS LOIN ADRESSEZ-VOUS À VOTRE CONSEILLER DE VENTE')
$(v+'buttons').append($('<a class="SFR_FormButton SFR_FormButton-big SFR_FormButton-violet">Retour</a>').click(function(){_eT.ckD('SFRBOLFEL');location.href='/tester-ma-ligne/eligibility-by-ndi.htm?univers=SFR&marques=ADSL&marques=CBL&marques=THD&hideFooter=true'}))}}
if(X&&$&&M('espace-client@/moncompte-webapp'))$('div#ctn_hd_mes,div.cadre_content').css('position','relative')
if(M('@/telephonie-mobile$'))ti(function(o,i){for(i=1;i<6;i++){
o=$('#web_bol_mobile_'+i+' a');if(o.length)o.each(function(o,h){o=$(this);h=o.attr('href');if(!h.match(/sfrintid/))o.attr('href',h+'#sfrintid=web_bol_mobile_'+i+'_arrow')})}})
if(M('@/forfait-mobile/recap')&&par('panier').match(/promoCode%22%3A%22SHOWROOM[25]GO/))MKG=['','','showroom','']
if(MKG[2]=='showroom')ckW('eTagMKG=||showroom',1)
if($&&!(W.sfrIstConfig&&sfrIstConfig.isRED)){
if(M("@/(mon-)?espace-client|^@/mobile/ma-commande/|^m@/perso/espace-client|^espace-client(.m|-red)?@|^accessoires(.m)?@|^box@/bolchange")&&(_.isRED||par('red')==1)||
M("@/(carte-couverture-reseau-sfr-fibre-optique|(sfr-et-moi\/(reseau-sfr|vos-applis-sfr)|procedures-urgence/actes-urgences|mentions-legales|telephonie-mobile/tarifs-conditions).html)")&&ckR('eTred')){
W.cbRNh=W.cbRNf=function(){}
$rm('#eTsH,#eTsF,header.sfrRN,footer.sfrRN,header.sfrNC,#headerRoot,footer.sfrNC,#footerRoot,body link[href*=sfr\\.header\\.css]')
ckW('ISTRED=1')
_.nr=_.hEC=1
if(W.sfrIstConfig)sfrIstConfig.isRED=1
fR=function(){
W.etRNh=function(d){$B.prepend(d.content)}
W.etRNf=function(d){$B.append(d.content)}
JS(rbs+'fragments/header/header.standard.espace.client.json?callback=etRNh')
JS(rbs+'fragments/footer/footer.standard.json?callback=etRNf')}
if(!W.$sfr||!/^1.11/.test($sfr.fn.jquery)){
JS(ist+'resources/js/frameworks/jquery/sfr.jquery.js')
f=function(){if(/^1.11/.test(W.$.fn.jquery)&&W.Telescope){$sfr=W.$;fR()}else to(f)}
f()}}}
ico()
if(cms&&$)ti(function(){$.each($('header.sfrRN form'),function(){$(this).attr('action','//cms.sfr.fr/recherche/')})})
if((v=lse(1))&&/_RED$/.test(v[1]))_.nr=1
ECR=_.nr&&T('(@/|@/mon-)?espace-client(-red)?@?')||T('@/cas')&&/red/.test(par('theme'))||/red-by-sfr/.test(par('service'))
if($&&!_.RI&&(ECR||T('[^/#@]*#'))&&!_.eTp&&!$('#eTrH,#eTtH').length&&(W==top||par('ist')>0)&&!((v=W.sfrIstConfig)&&v.waitR)){
_.Zr=function(v){$rm(v='body>header.sfrNC,body>footer.sfrNC,.istRN,#headerRoot,#footerRoot,#eTh,#eTf,#eTsH,#eTsF,#eTrF~#eTrF');ST(v+'{display:none!}')};_.Zr()
_.Hr=function(d){if(!$('#eTrH,#eTtH')[0])$B.prepend(d.content)};JS(rbs+'fragments/header/header.standard'+(_.hEC?'.espace.client':_.hTR?'.tunnel':'')+'.json?callback=_eT.Hr')
_.Fr=function(d){if(!$('#eTrF')[0])$B.append(d.content)};if(!$('#eTrF')[0])JS(rbs+'fragments/footer/footer.'+(_.fLT?'light':'standard')+'.json?callback=_eT.Fr')
o=M('#/offre-internet/(red-fibre/installation-fibre|informations-debits-adsl-fibre|lettre-resiliation-ancien-operateur).htm')?'#/offre-internet':
M('#/box-fibre-mobile-4g/guide-offre-box-internet-mobile-4g.htm')?'#/box-fibre-mobile-4g':
M('red@/parrainage')?'#/bons-plans':
X&&M(o='#/forfaits-mobiles')?o:0
if(o){_.Nr=function(d){$B.prepend(d.content)};JS(rbs+dja+'navn2.json?callback=_eT.Nr&U='+escape(o))}}
if(T(v='#/terminer-ma-commande/')){
ST('#checkoutNav{width:68%;position:fixed;z-index:49999;top:-8px;right:1%}#checkoutNav .current .label{color:#00e094}'+
'.show-summary{background-image:url('+med+'ecaddy2.png)!;top:0!}')
if((X?0:TH<47935)&&T(v+'recap/')&&/;RED_3_1Go_PROMO1_/.test(s.products))ckW('eTshrR=1',2)
if(ckR('eTshrR'))SM(767,'#checkoutNav{D0!}'),ST('#checkoutNav{margin-left:30px!}')}
if(ckR('eTshrR')){if(T('#/(offres?-internet|tester-ma-ligne|terminer-ma-commande)/'))wait(function(){return $('#eTrH').append(im+'shrr.jpg" style="width:60%;max-width:350px;margin:14px 14px 0 0;float:right"/>').length});else ckW('eTshrR=',-1)}
if(ckR('eTgrp')){
ST((v='div#checkoutNav')+'{width:55%!;left:120px!}'+v+' .stepSpacer{width:20%}#eTc2cP{D0}');SM(768,v+' .stepSpacer{width:9%}');SM(480,v+'{D0}')
if(T('#/(offres?-internet|tester-ma-ligne|terminer-ma-commande)/'))wait(function(){return $('#eTrH').append(im+'groupon.png" style="width:60%;max-width:200px;position:absolute;top:4px;right:4px"/>').length});else ckW('eTgrp=',-1)}
if(M('(#|^red@)/terminer-ma-commande/recap'))wait(function(o,p){if(/Modifier/.test((o=$('#modifyPnmButton')).text())){
p=$p(o).find('p:eq(0)')
if(/Nouveau numéro de mobile SFR/.test(p.text())){p.html("Vous allez obtenir un nouveau numéro de mobile SFR");o.html("Si vous souhaitez conserver votre numéro de mobile cliquez ici !")}
if(/Conservation de votre numéro de mobile actuel/.test(p.text()))o.html("Si vous souhaitez obtenir un nouveau numéro de mobile cliquez ici.")
return!0}},99)
if(M('#/offre-internet/red-')){
$rm('.chaine__numero,.chaine:eq(3)')
wait(function(){if($(v='#commandSection.section--disabled').length){
ST(v+':hover>p{display:block!;position:relative;top:-24px;color:red;font-size:13px}')
$(v).append("<p style='display:none'>Vous n'avez pas terminé la personnalisation de votre offre</p>")
return!0}})}
if($&&M('atelier@'))$.istFooterRN()
if($&&T('@/tester-ma-ligne/')){
if(W!=top){
ST('head+body{margin-top:0!}header,footer{D0!}')
if($('#selfinstall')[0])parent.postMessage('6','*')
$('.SFR_EligibilityResult a.button').click(function(){parent.postMessage('7','*')})}}
if(wm()&&(v=ckR('eTelU'))&&M('@/tester-ma-ligne/eligibility-resultats.htm')&&$)$('a.button.large[href*=offre-internet]').attr('href',v)
if(!M('@/(tester-ma-ligne|box-mobile|config4p.html)'))ckW('eTelU=',-1)
if(ckR('eTbfF')&&M('@/tester-ma-ligne/eligibility-result')&&_.fel('SFR').match(/M=ADSL.*ATV=false/))
$('.SFR_ModalHeader').html('<p class="SFR_ModalHeader_leadParagraph">Votre domicile est éligible aux offres Box de SFR,<br>mais votre débit ne vous permet pas de bénéficier de cette promotion</p>')
_.CkCb=function(d){$B.append(d.content)}
_.CkInit=function(d){JS(dj+(_.nr?"ccred":"cookiec")+".json?callback=_eT.CkCb")}
_.CkML=function(){_.ckc=1;_.CkInit()}
if(!_.app&&!ckR('eTgdpr')&&!_stats_zf&&$&&T("[^/]*[#@]|rmcsport.tv/")&&top==W&&!(M('@/cas/login')&&/cloud-[dm]|securite|webapp|\/app\//.test(unescape(par('domain')+par('service'))))){
evt(53);JS(dj+(T('rmcsport.tv/')?'ckcrs':_.nr?'ckcred':'ckcsfr')+'.json?callback=_eT.CkCb')}
if(T('@$')&&TH>42213&&TH<42382)_.crf=function(d,v){v=d.content;$B.prepend(v)},JS(dj+'dgccrf.json?callback=_eT.crf')
if(M('www.vosmms.com'))$.istFooterLight()
if(M('m.vosmms.com'))$('.sub-header:eq(0)').hide().before('<div id="header"/>')
if(_.nsPc)wait(function(){if(_.nsPc!=1){$pc(_.nsPc);return 1}})
if(_.wmPu)wait(function(){if(_.wmPu!=1){
$('#colL').click(function(){W.open(_.wmPi?_.wmPu:"/etag/rebondsa.html#"+_.wmPu[RE](/^.*\?/,''))})
$pc(_.wmPc)
return 1}})
else if(W._cfCas&&$){
_.auth=function(d){if(d&&d.content&&$){
$('#colL').unbind('click').html('')
$('.boxTitle').html("").css("margin",0).css("height",0)
if(W._cCas)$('#column-right').css("margin-top",50)
$B.append(d.content)}}
if(_.authEC){
ST('#main{height:auto;background:url('+med+'mire-ec-mise-en-avant-appli.jpg) 0 30px no-repeat}.page{background-color:#fff}#colL{height:480px;width:640px;cursor:pointer}#colR{cursor:default}')
$('#colL').click(function(){W.open("http://www.sfr.fr/sfr-et-moi/vos-applis/mon-compte.html#sfrclicid=EC_mire_appli")})}}
if(par('eTcpc')&&$&&T('@/cas/login')&&W==top){
$('#identifier').before('<div class="g-recaptcha" data-sitekey="6LeUtDsUAAAAAL3J5MJr0ccJcu2ZJmpzw0rDIxuw"></div>')
JS('https://www.google.com/recaptcha/api.js')}
if(M('@/espace-client/avantages-groupe/groupe/affichage/index.html')&&W.Hb)to('Handlebars=Hb',2e3)
if(!T('[^/]*(#|@|(forum.neuftv|numericable|sfr(pay)?).(fr|com|re)|altice.net)|j.ld3.fr|astro.sfr.0pb.org|www.((xooloo|clicrdv).com|(lejeusfrsport|virginmobile|logementconnecte).fr)|rmcsport.tv')&&
!T('((m|www).(vosmms|startappexchange)|req.startappservice).com|mire.(ipadsl|gaoland).net|(www.)?((appliscope|sfr.(preprod.)?odr).fr|altice(usa.com|.do))')&&
!W.eTsrc&&!/^Jail/.test(v=$?$('title').text():''))JS('//www.sfr.fr/eTagP/log.jsp?d=XDom'+(_.loc?'&r='+escape(_.loc):'')+(v?'&t='+escape(v):''))
o=0
if($&&(o=o||$('[data-eTab]')).length){
_.AB=[]
$.each(o,function(i,o,a,b,c,A,v,n){
a=($(o).data('etab')||'').split(':')
if(!/^[a-z0-9]{3}$/i.test(a[0]))return
for(i=v=0;i<3;i++)v=v*13+a[0].charCodeAt(i)
i=((ckR('evar28').split('_')[2]|0)/[1,1e2,1e4,1e6][v%4]+(v>>2))%100|0
A=_.AB[a[0]]||[0,0,0]
if(!A[2]){
c=ckR(n='eTab'+a[0])
v=A[0]+(a[1]|0)
A[1]++
b=c?c==A[1]:i<v
_.AB[a[0]]=[v,A[1],b]
if(b){$(o).removeAttr('data-eTab');ckW('eTab'+a[0]+'='+A[1],1)}}
b||$rm(o)})}
if((v=ckR(o='eTabMIP'))&&T('mire.(ipadsl|gaoland).net'))JS('//www.sfr.fr/eTagP/ck.jsp?'+o+'~'+v+'~60')
if(ckR('eTabOTV')>1&&M('#/offre-internet/red-'))v='[data-step=etape-decodeurtv] .row',ST(v+"{direction:rtl}"+v+">*{direction:ltr}"+v+">div+div>div{width:calc(100% - 15px)!}")
if($&&M('#$')&&(o=$('[data-eTab]')).length){
v=$('.gred-carousel__item')
i=$('.gred-carousel__puce-item')
if(o.eq(0).filter(":visible").length)$rm(v.eq(2)),$rm(i.eq(3))
if(o.eq(1).filter(":visible").length)$rm(v.filter(":eq(1),:eq(4)")),$rm(i.filter(":eq(3),:eq(4)"))}
if($&&T('@/(forfait-mobile|offre-internet|terminer-ma-commande)/')&&(o=$('[class*=error]:visible'))[0])s.prop52=o.text()
if(o=lse(1))zvars[18]=prf(o[1])
o=_.LL;if(o&&o[0]){v='';for(i=0;o[i];i++)v+=(i?' ':'')+prf(spl(o[i],':')[1]);zvars[19]=v}
if(typeof s=='object'&&typeof stats=='function'){
v=ckR('ext_ref')
if(v&&v!=Rf){s.referrer=v;ckW('ext_ref=',-1)}
if(W!=top)s.gtfsf=function(w){return this.tfs=w}
if(M('forum(test|beta)?@'))_stats_accent=1
if(!W._stats_sent&&!eS){
_stats_sent=1
stats()}
if(/sfrpolprod/.test(s.un))eTagS('ECSBT',2)}
_.sent=1
if(T('@/terminer-ma-commande/conf'))eTagS('BOLCC2:'+ckR('eTam')+"/"+s.events,2)
if(T('[#@]/mon-espace-client$')&&!ckR('eTarC')&&(o=_.colis)&&o.n&&o.d){
v=(o.d||'').split('/');v=v[0]*1+' '+[0,'janvier','février','mars','avril','mai','juin','juillet','août','septembre','octobre','novembre','décembre'][v[1]*1]+' '+v[2]
_.fCol=function(b){postMessage("1","*");ckW('eTarC=1',1);if(b)$B.append('<iframe style="display:none" src="https://espace-client.sfr.fr/retour-equipement/assigne-equipement"></iframe>')}
_.popin('<style>#eTcolis p{text-align:left;margin:0;padding:18px}#eTcolis b{font-weight:bold}#eTcolis button{cursor:pointer;background:#'+(_.nr?'00e094':'e2001a')+';color:#fff;padding:9px;margin:0;border:0}button>b{font-size:14px}</style><div id="eTcolis">'+
'<p style="font-size:18px"><b>Avez vous reçu votre colis&nbsp;?</b></p><p style="background:#eee;height:160px"><b>Nous vous avons envoyé le colis '+o.n+' le '+v+'.</b><br>'+
"Pour nous permettre d'activer votre équipement au plus vite, pouvez-vous nous préciser si vous l'avez reçu&nbsp;?"+
'</p><p style="text-align:center"><button onclick="_eT.fCol()"><b>Non</b><br>Je n\'ai pas le colis</button> &emsp; <button onclick="_eT.fCol(1)"><b>Oui</b><br>J\'ai reçu le colis</button></p>',480,300,0,0,'#fff')
_.pi0=1}
var fs=function(t){if(t>0)t='eVar'+t;return s[t]||Z[t]||''},p38=fs('prop38')||fs(38),i,e4=fs(4),e19=fs(19),e24=fs(24),e46=fs(46),e52=fs(52),e62=fs(62),eT=W._eTag||[],oid=eT.TransactionID||par('orderNumber')||par('order_id')||s.prop57||TH+'-'+r6,
red=p38.match(/red/i)||M('@/.*/forfait-sans-engagement')||par('universe')=='RED'||M('red@'),
pvm=p38.match(/pvm/i),
pn=s.pageName||'',
RBOL='#/(offre-internet/|telephones|forfaits-mobiles)',
BCU='(box)?@/bolchange(-preview|-1)?/',
BCC=BCU+'configurator.htm',
BOM='@/(((telephonie|forfait)-mobile|terminer-ma-commande|mobile)/|etag/conv)',
RED='@/telephonie-mobile/.*red-de-sfr',
HBM='@/telephonie-mobile$',
LOM='@/(telephonie-mobile/forfaits-mobile|forfait-mobile/offres)',
CFM='@/forfait-mobile/configurateur/',
PAM='@/(terminer-ma-commande/informations$|mobile/(ma-commande/information$|(telephone|offre)-recapitulatif/)|forfait-mobile/recap/)',
PCM='@/(terminer-ma-commande|etag/conv)',
RM=par('context').match(/change/i)||e46.match(/Changer/),
Eli=e62.match(/.1$/)?'Cable':e62.match(/^1/)?'Fibre':'Adsl',ELI=Eli.toUpperCase()
for(i=0;i<2;i++)red=red||Q[i]&&/(^|-|_)(CS.|LSR)(-|_|$)/.test(Q[i].split(";")[1])
_.brand=red?'RED':'SFR'
if(M('[^/]*@')){
if(e4!=ckR('eTre4'))eTagS((cms?'//cms':'//www')+(e4?'.sfr.fr/eTagP/cnxR.jsp':'.red-by-sfr.fr/eTagP/cnx2.jsp?D=eT'),4)
ckW('eTre4='+e4,e4?2:-1)
if(e4)ckW('eTe4='+e4,168)}
if(e52&&W.scDil)scDil.api.aamIdSync({dpid:'1711',dpuuid:e52})
if(M('(red)?@/forfait-mobile[^/]*/offres/forfait')&&(o=$('[data-tet]')).length)o.each(function(d,p){if(d=$(this).data('tet')){
d=d.split('|')
p=$(this).parents('.SFR_Table_row')
if(d[0])p.before(im+d[0]+'" style="'+(d[1]||'')+'"/>')
if(d[2])p.css('border','2px solid'+d[2])}})
if(M('@/forfait-mobile/(offres/forfait-mobile|configurateur)'))$('img[src*=common\\/exclu_clients_box]').each(function(){$(this).attr('src',$(this).attr('src')[RE](/.*(exclu.*)/,med+'$1'))})
if(M('@/box-internet/pro'))ckW('eTbolPro=1',1)
if(M(BCU+'(configurator|delivery).htm'))ti(function(o,b){
if($h(o=$('#bloc-bill-monthly-items-list')).match(/Extra Power/)){
$.each(o.find('span'),function(p){
if($h(this)=='Bouquet Power'){
b=1
if(!$h(p=$p(this)).match(/Remise/))p.append('<p style="text-align:right;clear:both" class="txtPurple">Remise Extra Power</p>')
p.find('span:eq(1) span').css('text-decoration','line-through')}})}
if(M(BCC)){
$('#POWER-price>.price-free')[b?'show':'hide']().html('Inclus <small>(Remise Extra Power)</small>')
$('#POWER-price>.price-current')[b?'hide':'show']()}})
if(M(BCU+'summary.htm')&&$h(o=$('#page-summary table')).match(/Extra Power/))$.each(o.find('td>div'),function(p){
if($h(this)=='Bouquet Power'){
p=$p($p(this)).find('td:eq(5)')
if(!$h(p).match(/Remise/))p.append('<p style="text-align:right;clear:both" class="txtPurple">Remise Extra Power</p>')
p.find('span').css('text-decoration','line-through')}})
if($&&M('red@/inscription-offre-box-red/customer.htm')&&$h('#page-customer').match(/numéro de ligne SFR/)){
$('.cdviContent').html('<strong>Vous êtes éligible à la fibre !</strong><br><br>Pour découvrir les offres et les options auxquelles vous pouvez souscrire en ligne, nous vous invitons à vous rendre dans votre Espace Client')
$('#toClientArea').html('<a class="myosotis-btn" href="https://box.sfr.fr/bolchange/start.htm?ctxId=78AD1EEAD2DB0128EBE616FE2B6DB207&access=accessOffer">Accéder à l’espace client</a>')
$('.mediumLMargin.mediumBMargin > a').detach()
$('#toClientArea').prev().detach()
$('#toClientArea').attr('onclick', '')}
if($&&M('@/tester-ma-ligne/eligibility-niagara.htm')&&red&&$('.SFR_ModalCasNiagara_leadParagraph').text().match(/numéro\s+de ligne SFR/)){
$('.SFR_ModalContent_paragraph.SFR_ModalCasNiagara_leadParagraph').html('Le numéro que vous avez saisi <strong>'+$('.SFR_ModalContent_paragraph.SFR_ModalCasNiagara_leadParagraph > strong').text()+'</strong> est un numéro<br>de ligne SFR.')
$('.SFR_ModalCasNiagara_title:eq(0)').empty()
$('.SFR_ModalCasNiagara_paragraph:eq(0)').html('<strong>Nous vous invitons à vous rendre dans votre Espace Client</strong>, pour découvrir les offres et les options auxquelles vous pouvez souscrire en ligne.')
$('#SFR_Redirect-parent').attr('href', 'https://box.sfr.fr/bolchange/start.htm?ctxId=78AD1EEAD2DB0128EBE616FE2B6DB207&access=accessOffer')}
if(T('#$')&&/M=ADSL/.test(_.fel('RED')))$hR('.instead:contains(pendant 12)','12 ','6 ')
if(T('#/terminer')&&(/^https?:\/\/www\.amazon\.fr\//.test(Rf)||/amazon/i.test(Q[0])))ckW('eTamz=1',1)
if(!T('#/te(rmin|st)er'))ckW('eTamz=',-1)
if(ckR('eTamz')&&T('#/terminer'))ST('#eTrH #eTamz{float:right;margin:6px 14px 0 0}'),SM(768,'#eTrH #eTamz{margin:6px;max-width:80px}#checkoutNav{D0!}'),wait(function(){return $('#eTrH').append(im+'amazon_frlogo_blanc_750x375.png?w=120" id="eTamz"/>').length})
if(_.cbot=!ckR('eTamz')&&!_.app)ST('#eTrF{position:relative;z-index:40000}')
if(_.cbot&&$&&!pu&&T('#/(terminer|offre|forfait|telephone|box)|#$|#/contact$|espace-client-red@/facture-mobile/consultation')&&!/change/i.test(par('context'))&&!/^Change/.test(e46)){
_.chat=function(v,m,o){
v=ckR('eTch')
$('#eTchD,#eTchF').remove()
$op('#eTchat')
_.msg(function(e,a,i){
e=e&&e.data;a=e&&e.action;i=e&&(i=e.params)&&i.pid
if(v=a&&a.match(/^webchat-(.*)$/))v=v[1],TL('/Moss/'+(_.cbot?'Bot/':'Chat/')+v[0].toUpperCase()+v.substring(1))
if(a=='webchat-init')ckT('eTch',i,90),ckT('eTchP',i,9999)
if(a=='webchat-close'){ckT('eTch',i,-9);$('#eTchF').remove()}})
$('body').append(
'<div id="eTchD" style="border:none;margin:0;padding:0;height:70px;width:270px;background:transparent;position:fixed;bottom:408px;left:9px;z-index:220008;cursor:move;cursor:-webkit-grab"></div>'+
'<iframe id="eTchF" style="border:none;margin:0;padding:0;height:470px;width:320px;background:#fff;position:fixed;bottom:9px;left:9px;z-index:220007;box-shadow:0 0 9px" '+
'src="https://ctc.red-by-sfr.fr/messenger?cid=54d1cc0e6803faef0a8b4567'+(v?'&pid='+v:'')+(_.cbot?'&chatbot=true&asc='+e4:'')+'"></iframe>')
m=function(o,x,y){o.css('left',o.css('left')[RE](/px/,'')*1+x);o.css('bottom',o.css('bottom')[RE](/px/,'')-y)}
o=$('#eTchD')
o.mousedown(function(e){this.X=e.pageX;this.Y=e.pageY;this.M=1;$(this).css('cursor','-webkit-grabbing')})
o.mouseup(function(){this.M=0;$(this).css('cursor','-webkit-grab')})
o.mousemove(function(e,o,x,y){
o=this
if(o.M){
x=e.pageX-o.X;o.X+=x
y=e.pageY-o.Y;o.Y+=y
m($(o),x,y)
m($('#eTchF'),x,y)}
e.stopPropagation()})}
if(!T('espace-client-red@')){v=ckR('eTshrR')?9:ckR('eTagAB')%10;_.dim=v==5;_.mos=v>5}
if(!T('#/contact$')){
if(ckR('eTshrR')&&!T('#/offres?-internet'))ST('#eTc2cP{D0!}')
$B.append(im+(_.cbot?'cbot'+(wm()?'m':''):'gred-picto-ctc')+'.png" id="eTc2cP" style="z-index:33333;position:fixed;bottom:9px;right:9px;border:0;cursor:pointer"/>')
if(!_.dim&&ckR('eTch'))_.chat()
ckW('eTabRCH='+(_.dim?3:_.mos?2:1),2)
_.goCh=function(){ST(
'#eTctc,#eTctc *{margin:0;padding:0;border:0;box-sizing:border-box}'+
'#eTctc{position:fixed;z-index:33339;margin:-165px -160px 0 0;top:50%;right:50%;width:320px;height:330px;border:1px solid #ddd;box-shadow:0 0 20px #ddd;color:#1a171b;background:url('+med+'ctc-popin-bg.png) center top no-repeat #fff}'+
'#eTctc>p{width:25px;height:25px;position:absolute;top:0;right:0;cursor:pointer}'+
'#eTctc>div{text-align:center;line-height:1em;padding-top:140px;font-size:15px;margin-bottom:20px}'+
'#eTctc button{display:block;margin:20px auto 0;text-decoration:none;color:#fff;text-align:center;height:31px;line-height:31px;width:158px;background:#00e094;text-transform:uppercase;font-size:13px;transition:color 200ms ease-out,background-color 200ms ease-out;cursor:pointer}')
$B.append('<div id="eTctc"><p onclick="_eT.$(\'#eTctc\').remove();_eT.$(\'#eTc2cP\').show()"></p><div>Nous sommes à votre disposition.'+
'<button onclick="_eT.c2c();_eT.$(\'#eTctc\').remove()">Se faire appeler</button>'+
(_.dim?'<div id="dimelo_chat_item_markup_e8f99384aa3680e856bc0b3c" class="dimelo_chat_item_markup"></div>':'<button onclick="_eT.chat()";_eT.$(\'#eTctc\').remove()">Chatter en ligne</button>')+
'</div></div>')
stats({pn:'Web/Transverse/Layer ClicToCall/Choix'})}
$(_.rCC='#eTc2cP').click(function(v,u){
u='//www.sfr.fr/eTagP/chat.jsp?k=54d1cc0e6803faef0a8b4567'
$op(_.rCC)
if(_.mos)_.c2c();
else if(_.dim)_.goCh()
else $.getScript(u,function(v){if((v=_.dispo)&&(v=v.capacity)&&v.chatbots)_.chat();else _.c2c()})})}}
if($&&T('#($|/offres?-int)')&&/[HNtx]/.test(e19))ST('#eTc2cP{D0!}')
_.cpid=ckR('s_cmDet').split('|').pop().split(':')[1]||''
if($)$('.headerTop__list--right li:last-child').html('<a href="https://webmail.sfr.fr/#sfrintid=V_nav_mail">'+im+'bcsfr_sfr_picto_mail_w.png" style="display:inline-block;width:18px;margin:0 -5px -4px 5px"></a>')
if($&&e4)ti(function(n,h,o,m,N){
n=1*ckR('sfrUserUnreadMessages')
if(n!=_.nm){
_.nm=n
h='header.sfrRN '
o=$('.headerTop__list--right li:last-child,#eTpH>.T>.R>li:last-child')
if(o.length&&!o.find('.liI').length){
ST(('I,I>li,I .pi{display:inline-block}I{padding-left:0;list-style:none;white-space:nowrap}I>li{padding-left:5px;padding-right:5px}I>li:first-child{padding-left:0}I>li:last-child{padding-right:0;margin-right:-4px}'+
'I .mail>a{color:#fff}I .mail>a>span{display:inline-block;min-width:18px;padding:0 4px!;margin:0 0 0 3px!;height:18px;background:#e2001a;border-radius:10px;text-align:center;font-size:11px;line-height:18px;color:#FFF;font-weight:bold}'+
'I .pi{margin:3px 5px -3px!;width:auto}I .piM{height:16px}I .piU{height:18px;width:13px!;margin-right:9px!}'+
'I .user{cursor:pointer}I .user span{color:#fff;max-width:200px;overflow-x:hidden}')[RE](/I/g,'.liI'))
o.html('<ul class="liI"><li class="mail"><a href="https://webmail.sfr.fr/#sfrintid=V_nav_mail">Mes mails<span></span></a></li>'+
'<li class="user"><a href="https://www.sfr.fr/mon-espace-client/#sfrintid=V_nav_ec">'+im+'bcsfr_moncompte_w.png" class="pi piU"/><span>'+ckR('sfrUserInfos')+'</span></a></li></ul>')}
m=o.find('.mail>a>span')
if(n>0){
N=n<1e4?n:n<1e6?(n/1e3|0)+'k':(n/1e6|0)+'M'
o.show()
m.show().html(N)
$(h+'.inbox-icon').addClass('has-msg')
$(h+'.textMsg').html(' non lu'+(n<2?'':'s'))
$(h+'.nbMsg').html(N)}
else{m.hide();$(h+'.inbox-icon').removeClass('has-msg')}}})
if($&&M("accessoires@/eshop/shopping_cart.php")&&!$('#content_large .shopping_cart').text().match(/chromecast/i))$('img[rel=buyster]').show()
if(M('@/forfait-mobile-numericable/offres/forfait-mobile')){
$('.legalNotices').css('cursor','pointer').click(function(){
if(!_.mnLC){
_.mlNC=function(d){$('.legalNotices').after(d.content);$rm('.legalNotices')}
JS(dj+'blocml.json?callback=_eT.mlNC')}})}
if($&&N.match(/MSIE/))$('form[name=gsaSearchForm],form[name=gsaAdvancedForm]').attr('method','GET')
if(!ckR('eTaI0')&&location.protocol=='https:'&&$&&!T('communaute#'))
_.aI=$(_.aImg='[style*="http:"],style:contains("url(http:"),style:contains("url(\'http:"),style:contains(\'url("http:\'),link[rel=stylesheet][href^="http:"],img[src^="http:"],script[src^="http:"],img[data-crop^="http:"]').length,
to(function(v){if(v=$(_.aImg).length)JS('//cms.sfr.fr/stats/aImg.js?'+_.aI+'-'+v)},3e3)
if(X&&$&&cms){
_.affAL=function(){
_.msg(function(e){
if(e.data==2)$rm('#eTagPopin')
if(e.data==1){
var xy='width:224px;height:400px;'
$rm('#cssPopin,#eTagPopin p')
$('#eTagPopin>div').attr('style',xy+'margin:9px 9px auto auto')
$('#eTagPopin>div>iframe').attr('style',xy+'margin:0')}})
$('head:eq(0)').append('<style id="cssPopin">#eTagPopin{display:none}</style>')
W.setTimeout("$sfr('#cssPopin').remove()",600)
eTagPopin('//cms-admin.sfr.fr/statistiques-back/tool/eTag?popin',480,540,2)
$('#eTagPopin>div').css({'overflow':'hidden','min-height':0,'height':490})
$op('#eTagPopin p')}
$(D).click(function(e){if(e.metaKey||e.ctrlKey&&e.shiftKey)_eT.affAL()})}
if(N.match(/MSIE /)&&M("((achat-)?jeux-pc|jeux-tv)@"))
$sfr("head").append("<style>#megamenuWrapper .megaclone{height:230px;overflow:hidden}</style>")
if(M("jeux-tv@")){
var f=D.forms.godSearchForm
if(f&&f.perimetre)f.perimetre.value="gsa"
if(f&&f.univers){f.univers.value="jeux-tv.sfr.fr";f.univers.name="asSite"}}
if($&&M("accessoires@/eshop/shopping_cart.php"))$('.advertises>a').each(function(i,o){
if($(o).attr('href').match(/cateyga/))$(o).attr({'rel':'apercu','class':'apercu','href':'product_info_lightbox.php?products_id=13749'})})
if($&&M("accessoires.m@|^testsfr.shopblueway.com"))$('form.search-form').submit(function(e){
var q=$(this).find('input[name=q]').val()
if(q&&q!='Rechercher dans la Boutique Accessoire')document.location='//www.sfr.fr/recherche/?perimetre=mobile&asSite=accessoires.sfr.fr&adv=interne&q='+escape(q)
if(e.preventDefault)e.preventDefault()
return e.returnValue=!1})
if($&&T("@/box-internet")&&l.href.match(/[?&#]ndi=/)&&!par('ndi'))to(_eT.elg)
if(M(BCC)){
$('body.ecomfixe .lightTPadding').css('padding-top', '0px')
$p('.element-container.lightGreyBorder.mediumBMargin.panel-container.clearfix .element-container.lightTMargin .price-free').each(function(o,v){
o=$p($(v).parentsUntil('label'))
o.find('.htmlSkippedContent').children(':first').css('float','left')
o.find('.element-title').children(':first').append($(v).detach().css({'float':'left','margin-left':15,'margin-top':-4}))})}
if(!_.nr&&T('@/recherche|forum@/t5/forums/search')){
v=D[GI]('messageSearchField')||D[GI]('lia-allWords')
v=v&&v.value||W._curQ
if(/\brio\b/i.test(v))c2c(44)}
if(T('assistance@[^#]+comment-changer-operateur'))c2c(44)
if(T('@/((offre|box)-internet|la-box-tres-haut-debit|mon-espace-client/try-and-buy.html)')&&W==top&&!T('@/offre-internet/changer-')&&!T('@/box-internet/startersrp.html'))c2c(6)
if(T('@/contacter$'))JS(INQ=inq)
if(!_.nr&&!pn.match(/Epropal/)&&!MKG[2].match(/TECHDATA|showroom/)&&!ckR('s_cmDet').match(/t9_(red_groupon_td|showroompriveRED122014)/)){
if(RM){if(T('@/forfait-mobile/offres/forfait-mobile$'))c2c(4)}
else if(T('@/telephonie-mobile/rm-fidelite'))c2c(0)
else if(T('@/telephonie-mobile/faq/portabilite.html'))c2c(44)
else if(T('@/(shopping-hiver|tablette-cle-internet|(box|forfait|telephonie)-mobile|terminer-ma-commande|contenus)')&&!T('@/terminer-ma-commande/confirmationV2'))c2c(2)}
if(T('@/offresrpsfr.html'))c2c(14)
if(pu&&T('[@#]/terminer-ma-commande/')){
if(!INQ)JS(inq)
var iP=[],iQ=[],iR=[],P=Q?prod(Q):[]
iQ.push(1);iR.push((100*P[2]|0||0)/100)
if(v=e46.match(/:(Signup|Change) (ADSL|FIBRE|CABLE)/))v=v[2]
if(!v&&(v=e46.match(/:Change Intra (DSL|FIBRE|CABLE)/)))v=v[1]
if(!v&&(v=e46.match(/:Change DSL vers (Fibre|Cable)/)))v=v[1].toUpperCase()
if(!v&&(v=e46.match(/:Conquete|:VLA|:RM|:Mig/)))v='Mobile'
if(v){
inqSalesProducts=iP=["NAM:"+
(ckR('eTvmB')?'PVM':ckR('eTncB')?'PNC':red?'RED':'SFR')+'_'+
v[RE](/FIBRE/,'THD')[RE](/^DSL/,'ADSL')+'_'+
(P[3]&&P[3][1]||'Inconnu')]
inqSalesQuantities=iQ
inqSalesPrices=iR
inqClientOrderNum=oid
inqOtherInfo=v='CST:'+(o=e46.match(/Changer/)?'upgrade':'new')
if(i=ckR('eTchP'))eTagS('//www.sfr.fr/eTagP/chatP.jsp?p='+i+'&P='+(s.products||''),4)
eTagS("C2C2/"+iP.join('~')+"/"+iQ.join('~')+"/"+iR.join('~')+"/"+oid+"/"+v,2)}
else eTagS("C2C2/ERR",2)}
if(M('@/terminer-ma-commande/conf'))eTagS("CO/"+(pu?1:0)+"/"+s.events,2)
if(M('@/forfait-mobile(-fut)?/telephones/forfait-mobile')&&W.bol&&bol.isResponsive){
var o=$('.selected-offer-reminder-details')
if(o.length){
o.find('.section1').detach()
o.find('.description br:eq(0)').detach()
o.find('.row2').each(function(k,v){if(k)$(v).detach()})}}
if(M('accessoires@'))ti(function(){$rm('header.sfrNC:eq(1)')})
if($&&M("boutique@|mire@/mire_test.html")&&(_.slO=$('#eTeliFibre,.whichOffer')).length&&$w(W)>767){
_.slE=function(d){_.slO.html(d.content).removeClass('whichOffer')}
JS(dj+'etelg.json?callback=_eT.slE')}
if($&&M("boutique@/[0-9]+-boutique-(numericable-)?sfr-"))
ST('#eTmf{font:14px SFR-Regular;color:#e2001a}#eTmf:hover{text-decoration:none;color:#000}#eTmf svg{height:20px;width:20px;margin:0 6px -3px 0}'),
(_.mf=function(o,i,v,m){
if((o=$('#eTmagFav')).length){
i=location.pathname.match(/^\/([0-9]+)-/)[1]
v=ckR('eTmf').match(/^([0-9]+)~/)
if(v=v&&v[1]==i)_eT.btqFav()
$('a#eTmf').remove()
o.html('<a id="eTmf" onclick="ckW(\'eTmf='+(v?'\',-':i+'~\',')+'1);_eT.mf()">'+
'<svg viewBox="0 0 19 19"><polygon fill="#'+(v?'D02':'777')+
'" points="9.5,0.312 12.43,6.248 18.98,7.2 14.24,11.82 15.359,18.344 9.5,15.264 3.641,18.344 4.76,11.82 0.02,7.2 6.57,6.248"/></svg>'+(v?'Votre':'Ajouter comme')+' boutique préférée</a>')}})()
if($&&T("boutique@")&&(_.btq=ckR('eTmf').match(/^([0-9]+)/)))ST('#eTmf{float:right}#eTmf>a{color:#fff}#eTmf+li:before{content:none}@media (max-width: 767px){#eTmf{padding-top:5px}}'),wait(function(){
return $('ol.breadcrumb').prepend('<li id="eTmf"><a href="https://boutique.sfr.fr/'+_.btq[1]+'">Votre boutique préférée</a></li>').length})
if(M("m@/boutique$")&&$){
var f=$('.bol-search-form:eq(0)')
f.append('<input type="hidden" name="adv" value="interne"/>')
f.append('<input type="hidden" name="asSite" value="[m.sfr.fr/mobile|m.sfr.fr/mobile-rm|m.sfr.fr/mboutique|accessoires.m.sfr.fr]"/>')
f.find('input[name="q"]').attr("default-value","Recherche dans la boutique")}
if(M("assistance.sfr.re")&&$)$('form[name=gsaSearchForm]').append('<input type="hidden" name="asSite" value="assistance.sfr.re"/>')
if(T("@/guide/"))$.each($('#wb_container a'),function(){
var o=$(this),h=o.attr('href')
if(!h.match(/\//)||h.match(/\/guide\//))o.attr('href',h.toLowerCase())})
_.noArrow=function(){
if(M("@(/sfr-et-moi.html)?$")&&W.affPopin)affPopin()}
if(ckR('eTagPI'))ckW('eTagPI=1',.5); else if(ckR('eTagEC')||M("@/sfr-et-moi.html$")&&!e4)_.noArrow()
v=' target="_blank" href="http://www.sfr.fr/telephonie-mobile/multi-packs-sfr-internet-mobile.html#sfrintid=MSG_btiq_bouchon"'
if(_A&&$)SC([
WM+"~1~#SFReTAGArrowLeft:visible~web_mess_info~"+
'#@{position:relative;height:188px;white-space:normal;padding:6px;text-align:left;color:#1C1C1C;font-family:Arial,Helvetica,sans-serif;font-size:12px}'+
'#@ a,#@ a:link,#@ a:visited,#@ a:active{color:black;cursor:pointer;text-decoration:none}'+
'#@ h3{background:#f6f6f6;color:#1c1c1c;padding:5px;font-weight:bold;font-size:16px}'+
'#@ .uniqueMajorLinkWrap{width:167px;background:#f6f6f6;text-align:right;clear:both;float:none;position:absolute;top:170px}'+
'#@ .uniqueMajorLink{background:url("'+ist+'resources/img/sfrElementary/nextArrow.png") no-repeat 100% center;font-weight:bold;padding:8px 14px 8px 0}'+
'#@ .ressorti{color:#E2001A}~~'+
'<div class="sfrMail reboundBox"><a title="Avantage Client"'+v+'><h3><span class="ressorti">Avantage</span> Client</h3></a>'+
'<div class="RBWITmainContentWrap left noBG"><div class="RBWITimgWrap"><a'+v+'>'+
im+'bloc_gauche_167x57-14.jpg" alt="Multi-Packs"></a></div><h4>Les Multi-Packs de SFR,<br/>un mariage qui rapporte !</h4><p>Plus vous êtes équipé, moins vous payez.</p></div>'+
'<div class="uniqueMajorLinkWrap"><a'+v+' class="uniqueMajorLink">En profiter</a></div></div>',
WM+"~1~#SFReTAGArrowMain:visible~web_mess_pad~"+
'#@>div{height:100px;min-width:480px;border:1px solid #ddd;font-size:16px;'+
'	-webkit-border-radius:3px 0 0 3px;-moz-border-radius:3px 0 0 3px;border-radius:3px 0 0 3px}'+
'#@ *{font-family:"SFR-Regular",Arial,Helvetica,sans-serif}'+
'#@ b{font-family:"SFR-Bold",Arial,Helvetica,sans-serif;font-weight:normal}'+
'#@ .zone1{float:left;height:84px;width:95px;padding:16px 6px 0;text-align:center;background:#dfdfdf;line-height:24px;font-size:18px;color:#333}'+
'#@ .caret{float:left;height:99px;width:15px;background:url('+med+'caret.png) 0 15px no-repeat;position:relative;z-index:1}'+
'#@ .zone2{float:left;margin-left:-15px}'+
'#@ table{margin:auto}'+
'#@ td{height:80px;padding:9px 4px;vertical-align:middle;line-height:28px;font-size:22px;color:#000}'+
'#@ .zone3{float:right}~'+
'arWM',
"assistance@/authent/clickToCall/~2~#arrowBanner",
"assistance@/accueil/contacter/resiliation-(sfr|red)/fc-~2~#arrowBanner1",
"assistance@/contacter/resiliation~2~#HP_EC_bloc_NA",
"@$~2~#vitrine_mea_btiq",
"@/recherche~2~#arrow",
"@$~5~#eTarw~HP_Popin~~PP:72:752:520",
"@/((offre|box)-internet|(telephonie|forfait)-mobile)~5~#eTarw~BOL_Popin~~PP:72:752:520"],
_.arw=function(P){
if(!P)return
var T=P[0],o=$(P[1]),x=X||par('previewBlockId'),f=function(){_.arw(P)}
if(T==1){
var id="eTagArrow",div='<div id="@"></div>',p,A
if(P[1].indexOf('#SFReTAG')==0){id=P[1].substring(1,(P[1]+':').indexOf(':'));div=''}
if(o.length==0)setTimeout(f,500)
else{
if(P[3])o.first().after((div+'<style>'+P[3]+'</style>')[RE](/@/g,id))
A={'blockId':P[2]+(X?'_v2':''),'containerSelector':id,'callback':P[4]?_[P[4]]:0,'defaultText':P[5]||''}
_A.request(A)}}
if(T==2){
var a=o.find('a')
if(a.length && a.attr('href').match(/(appel\.|(callback|clicktocall)\.sd-)sfr\.fr/)) a.click(function(){
return eTagPopin('//appel.sfr.fr/webcallback_form'+a.attr('href')[RE](/.*(\?.*)/,'$1'))})
if(o.length&&!a.length)setTimeout(f,500)}
if(T>2&&(x||!ckR('eTagPI'))){
var p1=P[1].substring(1),p2=P[2],p=(P[4]||'').split(':'),c=p[0]?'eTpa'+p[0]:0
if(p[0]=='PP'&&wm())return
if(p[0]&&!o.length){$B.append('<div id="'+p1+'"></div>');o=$(P[1])}
o.hide()
if(!c||!ckR(c)||x)_A.request({'blockId':P[2],'containerSelector':p1,'defaultText':'','callback':function(e,d,s,b){
if(T==4&&o.html()){
v='layerArrow'
o.children().appendTo($('#'+v+' .modal2__container').html(''))
ckW('eTagPI=1',.5)
if(c)ckW(c+"=1",1*p[1]||24)
if(f=W.load_layer)f(v)}
else if(T==5){
if(c)ckW(c+"=1",1*p[1]||24)
if(e=o.html()){
ckW('eTagPI=1',.5)
ckW('eTcr='+p2,168)
_.popin('<div id="eTpiB" style="display:none"/>',Math.min($w(W),p[2]||720),v=Math.min(wh()-40,p[3]||360),p[4]||(wh()-v)/2)
$('#eTpiB').after(o)
$('#eTarw').show()
$('#eTco').click(function(){$cl($(this).find('a'))})}}
else if((e=$(P[1]+' eTag')).length){
if(d=e.attr("data"))p=d.split(':')
eTagPopin(0,Math.min($B.width(),p[2]||720),Math.min($B.height()-40,p[3]||360),p[4])
o.appendTo($('#eTagArrowPopin'))
e=$('#eTagArrowPopin eTag')
e.text(e.text()[RE](/^\s*,.*/,''))
e=$('#eTarw span:eq(0)')
if(e.length&&(s=e.attr('style')))e.attr('style',s[RE](/^width:12px;.*$/,'width:28px;height:28px;display:block;background:url('+med+'croix-layers-1.png) no-repeat 8px 8px;position:absolute;top:15px;right:51px;cursor:pointer;z-index:3'))
$('#eTagPopin').show()
ckW('eTagPI=1',.5)
if(c)ckW(c+"=1",1*p[1]||24)
o.show()}
else _.noArrow()}})}})
if(_A.rq){
var e28=ckR("evar28"),id='browserId='+e28+'&ascId='+escape(W.idASC||Z["eVar4"]||'')+'&deviceType='+dev()+((o=lse())?'&line='+o[0]:''),
pb=par('previewBlockId'),
u0=_.uA,
ub=u0+'banner?'+id+'&blockId=',
us=par('service').match(/(cooper(-fut|-next)?)/),
up=(us?'//cms-'+(us[2]=='-next'?'next.sfr.fr/cooper-dev':'admin.sfr.fr/'+us[1])+'/rest/preview?creationId='+par('previewCreationId'):u0+'preview?'+id+'&communicationId='+par('previewCommunicationId'))+'&blockId=',
bloc='',nr=0,nf=0,ru=0,b,
H0=document.getElementsByTagName('head')[0],
cs=function(t){
if(/eTiq/.test(t))ST(".eTiq{display:inline-block;background:#fc0;color:#222;text-transform:uppercase;letter-spacing:-0.5px;font:10px sfrbold,'SFR-Bold';height:18px;line-height:18px;padding: 0 6px}")
return t[RE](/http:\/\/static/g,'//static')[RE](/(<eTag[^>]*>)\s*,?\s*(<\/eTag>)/i,'$1$2')}
_A.B=!(_.cc&2)
_A.request=function(r){_A.rq.push(r=r.blockId?r:{'blockId':r});_A.uni(pb&&pb==r.blockId?up:ub,r)}
_A.clic=function(h,t,b,c){
var i=D.createElement('img'),r=t!='_blank',p,g=function(){
if(p=i&&i.parentNode)p.removeChild(i)
if(t=="_top"||t=='_parent')top.location=h; else if(r)D.location=h}
i.src=u0+'click?blockId='+b+'&campaignId='+c+'&'+id
i.style.display="none"
if(r)to(i.onload=i.onerror=g,999)
D.body.appendChild(i)
return!r}
_A.setHTML=function(R,re){
var v='containerSelector',g=GI,c='createElement',t='getElementsByTagName',o=D[g](R[v]||R.blockId),o2=D[g](R[v+2]),S,C=$&&$('[id='+o.id+']')
if(!re||!o||re.html==undefined)return!1
o[IH]=cs(re.html||'')
if(o2&&re.html2)o2[IH]=cs(re.html2)
S=o[t]("script")
for(j=0;j<S.length;j++)eval(S[j].text)
var A=o[t]('a'),
cl=function(){
var i=D[c]('img')
i.src=u0+'click?blockId='+R.blockId+'&campaignId='+re.campaignId+'&'+id
D.body.appendChild(i)},
clic=function(e){
var l=e.target||e.srcElement
while(l&&l.tagName!='A')l=l.parentNode
if(l){
var i=D[c]('img'),h=l.href,t=l.target,p,g=function(){
if(p=i&&i.parentNode)p.removeChild(i)
if(t=="_top"||t=='_parent')top.location=h; else D.location=h}
i.src=u0+'click?blockId='+R.blockId+'&campaignId='+re.campaignId+'&'+id
W.setTimeout(g,1e3)
D.body.appendChild(i)
i.onload=i.onerror=g
if(e.preventDefault)e.preventDefault(); else e.returnValue=!1}}
if(!A.length){o.cl=cl;o.clic=clic}
for(var i=0,l;i<A.length&&(l=A[i]);i++)l.setAttribute("onclick","return arrow.clic(this.href,'"+l.target+"','"+R.blockId+"','"+re.campaignId+"')")
if(C&&C[1])for(i=1;i<o.length;i++)C.eq(i).html(C.eq(0).html())
return!0}
_A.multi=function(re,o,R,S,j,i){
if(re)for(i=0;i<_A.rq.length;i++){
R=_A.rq[i]
b=R.blockId
if(!R.ok&&re[b]){
if(re[b].error)_A.bouchon(b)
else if(_A.setHTML(R,re[b])){
R.ok=1;if(typeof R.callback=='function')R.callback()}}}}
_A.uni=function(u,r,f){
f='f'+nf++
arrow[f]=function(re){var R=new Object;R[r.blockId]=re;_A.multi(R)}
_A.js(u,r.blockId,f)}
_A.setB=function(d){_A.setHTML(_A.rq[_A.bloc],{'html':d.content})}
_A.bouchon=function(b,i,R,r,d){
for(i=0;i<_A.rq.length;i++){
R=_A.rq[i]
if(!R.ok&&R.blockId.match(new RegExp('^'+b+'$'))){
R.ok=2
d=R.defaultText||R.defB
if(R.defB)JS(dj+d+'.json?callback=arrow.bloc%3D'+i+';arrow.setB')
else if((r=_A.setHTML(R,{'html':d,'html2':R.defaultText2}))&&typeof R.callback=='function')R.callback()
if(d)JS('//www.sfr.fr/recherche/js/log.js?BOUCHON='+escape(R.blockId)+"&R="+(r?'OK':'KO'))}}}
_A.js=function(u,b,f,s){
if(!_A.B&&e28){
to('arrow.bouchon("'+b+'")',3500)
s=D.createElement('script')
s.src=u+b+'&callback=arrow.'+f
s.onerror=function(){_A.bouchon(b)}
H0.appendChild(s)}
else _A.bouchon(b)}
var rq=_A.rq
for(var i=0;i<rq.length;i++){
b=rq[i].blockId
if(pb==b)_A.uni(up,rq[i])
else{bloc+=(nr?'%7C':'')+b;nr++;ru=rq[i]}}
if(nr>1)_A.js(ub,bloc,'multi')
else if(ru)_A.uni(ub,ru)}
if(M('@/offre-internet/changer-')){
if(_.nr)$((v='.SFR_ToggleSwitch_switch')+'After>img').attr('src',med+'chevronhyperlinks2x.png'),$('.SFR_goToCart').html('Continuer'),
ST((':checked~label>'+v+',.SFR_goToCart{background:#;border:1px solid #}.SFR_addOptionsList a,.SFR_FormButton-w100{color:#}')[RE](/#/g,'#00e094!'));else if(X)c2c(22)}
if($&&(v=ckR('eTte'))){ckD('eTte');eTagS(v+'&eurl=https%3F//www.sfr.fr/etag/vide.html',16)}
if(M('[^/]*@/adsite-under')&&(v=par('tckElr')))ckW('eTte='+v,.5)
if(_.noP||W._stats_zf||l.pathname.match(/^\/adsite-under/))return
if(X&&(M("@/etag/test.html")||pu)&&mkg==acn){
v='|'+ckR('s_cmDet')
v=v.substring(v.lastIndexOf('|')+1)
eTagS("ACN/"+MKG[1]+"/"+MKG[2]+"/"+oid+"/"+v.split(':')[1],2)}
var EU=[
'@/offre-internet/.*/personnalisez-votre-box.htm~1',
'@/(terminer-ma-commande/|tablette-cle-internet/recap/p$)|^accessoires@/shopping_cart.php$|^boutique.home@/commande~2',
RBOL+'~9','leadco@~9','.'],
euR=ECR||T('[^/]*#'),
euS=!euR&&T("[^/]*@|rmcsport.tv")&&!T('(sso-client)?@/cas/')
if(!_.app&&!ckR('eTSelr')&&(euR||euS)){_.elr=function(V){
var d=(euR?'nrg.red-by-sfr':'elr.sfr')+'.fr',c=TS/36e5|0,j='',a=(D.location.host+d)[RE](/[^a-z]/g,''),A=(a+a.toUpperCase()).split(''),i,v=V[0],i,ch=e46.match(/^Changer|^SC:ADSL:CHANGE/i),S37=(s.eVar37||'').split('/'),
da=_.df?new Date(1*_.df):0,mo=da&&da.getMonth()+1,jo=da&&da.getDate(),o,e38=M('@/box-internet|^box@')?'Fixe_Box-SFR':s.eVar38||'',E=[],
f=function(c,s){E[c]=''+s},g=function(c){return E[c]||''},F=function(c,s){E[c+'~'+En++]=s},n,En=0,P,ott=T('espace-client@/services-web/')
if(v==9)return 1
if(euR){
var de,of,om,pr,nb=0,mo=0,p=ckR('eTe19')
if(/[MI]/.test(e19)&&p!=e19)ckT('eTe19',p=e19,129600)
P=function(v,t){if(v){F('prdref',v[1]);F('prdamount',v[3]);F('prdquantity',v[2]);F('prdparam-type',t)}}
if(Q){
for(var i=0;i<Q.length;i++){
var R=Q[i].split(';'),m=1*R[3],n=1*R[2],v=R[1]||''
if(!/^(PR|FICT)/.test(v)){
n=n>0?n:m>0?1:0;nb+=n;mo+=m*n
if(!/^[0-9]{13,18}$|^cqt-|^(sl_)?red[23]?_/i.test(v))pr=(pr?pr+',':'')+R[1]
if(!de&&/^[0-9]{13,18}$/.test(v))de=R
if(!of&&/^cqt-/i.test(v))of=R
if(!om&&/^(sl_)?red[23]?_/i.test(v))om=R}}}
f('path',v=location.host+location.pathname)
if(v=_.fel('RED','M'))f('eligibilite',/THD/.test(v)?'fibre':/CBL/.test(v)?'cable':/CBL/.test(v)?'adsl':'autre')
f('client_only',p?1:0)
f('client_mobile',/M/.test(p)?1:0)
f('client_fixe',/I/.test(p)?1:0)
f('client_red',v=/[JKHNtx]/.test(p)?1:0)
f('client_autre',v?0:1)
if(v=ckR('eTshrR'))f('from','redbysfr-showroomprive'),f('idsrp',v)
if(ckR('eTamz'))f('from','redbysfr-amazon')
v=v.split('/')
f('pagegroup',v[0]+'/'+v[1])
f('uid',e4)
ckD('eTrOt')
if(/[JKHNtx]/.test(e19)&&ckR('eTrP')!=(v=/[JK]/.test(e19)?1:2)){
ckT('eTrP',v,9e4)
JS('//bs.serving-sys.com/Serving/ActivityServer.bs?cn=as&ActivityID='+(1124862+v))}
if(v=ckR('eTrP'))f('offer_type',v<2?'mobile':'fixe')
if(M('(#|red@)/terminer-ma-commande/(recap|conf)')&&/^Ouvrir/.test(e46)){
if(pu){
f('ref',oid)
f('amount',1*mo||1)
f('type',of&&om?'4p':of?'fixe':om?'mobile':'autre')}
else{
f('scart',1);f('scartcumul',0)}
P(of,'offre fixe')
P(om,'offre mobile')
P(de,'device mobile')
f('options',pr)}}
if(euS){
P=prod(Q),pr=P[3],of=P[4]
if(pu){
v=3
f('amount',1*P[2]||ckR('eTam')||1)
f('duree_engagement','')
f('montant_mensualite','')
f('currency','EUR')}
if(v==8){
f('estimate',1)
f('ref',TS)
f('msisdn',V[1])}
f('path','/'+(v==7?V[1]:s.pageName))
f('device',dev())
f('rubrique',s.prop21)
if(pu){
f('payment',s.prop52)
f('profile',ch?'rebuyer':'buyer')
f('ref',oid)}
if(v==8)f('type','click2call')
f('asc',e4)
f('uid',e52||'')
if(v==8&&V[1]>1)f('euid-tel',V[1])
if(pu)f('newcustomer',ch?0:1)
if(ott)for(i in Q){pr=of=0;o=Q[i].split(';');F('prdref',o[1]);F('prdname',o[1]);F('prdamount',o[3]);F('prdquantity',o[2])}
if(pr){
f('prdref',pr[1]>0?("00000000000000000"+pr[1]).slice(-18):pr[1])
f('prdname',T('@/forfait-mobile/telephone/')&&h.split('/')[3])
if(v>0){
if(i=pr[3])ckW('eTam='+i,1)
f('prdamount',i)
f('prdquantity',pr[2])}
f('prdparam-marque','')
f('reference_telephone','')}
if(of&&v!=2){
o=of[1].match(/(-|_|^)(CS[HIOT]|D[A-Z][EM]|F(6[0-9A-Z]|99|MV|T0)|H(0[01]|68|7[0-9A-Z]|T0)|I([0-9M][0-9A-Z]|NT|T0)|P[67T]0|Q(10|[3-9][EM]|SE|ZN)|S[BCD][0-9A-Z]|LSR|MS[EI])(-|_|$)/)
o=M('box@')?of[1]:o?o[2]:'XXX'
f('prdref',o)
f('prdgroup',o)
f('prdname',of[1])
if(v>0){
f('prdamount',of[3])
f('prdquantity',of[2])}}
if(v==2){
for(i=2;i<Q.length&&(P=Q[i].split(';'));i++)if(P[1].match(/^[0-9]{18}$/)){
f('prdref',P[1])
f('prdname','')
f('prdamount',P[3])
f('prdquantity',P[2])}}
f('pageprecedente',s.prop41)
f('clientauthentifie',s.eVar10)
f('CSUid',e52)
f('profildetaille',s.eVar19)
f('pta',_.pta)
f('dfpc',da?''+da.getFullYear()+(mo>9?'':'0')+mo+(jo>9?'':'0')+jo:'')
f('clientmultipack','')
f('segmentjoya',_.sj)
o=M('box@/bolchange')&&(s.prop53||'').match(/:([^:]*)$/)
f('typedachat',o&&o[1]=='XDSL Vers CBL'?'Bol : Change DSL Vers Cable':o&&o[1]=='XDSL Vers THD'?'Bol : Change DSL Vers Fibre':e46)
f('BU',e38)
f('eligibilitefibre',s.eVar62)
f('eligibiliteADSL',s.eVar61)
if(pu)f('codepromo',s.eVar42)
if(M('@/(box-internet|telephonie-mobile|etag/conv)|^box@'))f('idpartenaire',e24)
f('idpanier',s.eVar15)
if(S37.length>1){
f('optin',S37[0])
f('email',S37[1])
f('typeparcours',S37[2])
f('Numtel',S37[4])
f('authent',S37[5])
f('civi',S37[7])
f('Nom',S37[8])
f('Prenom',S37[9])}
try{eaQ(f,g,s,X)}catch(e){}}
EA_data=[]
ckD('eTelrCC')
for(o in E)if(typeof(v=E[o])!='function'){
if(euR||ott){EA_data.push(o[RE](/~[0-9]+$/,''));EA_data.push((''+v||'').toLowerCase()[RE](/ /g,'_')[RE](/[^.a-z0-9@_\/]/g,'-'))}
else{EA_data.push(o);EA_data.push((''+v||'').toLowerCase()[RE](/ /g,'_')[RE](/[^.a-z0-9@_\/]/g,'-'))}}
_.fEc=f=function(f,C,o,h,b){if(f=W.EA_epmGet){
for(o in C=f()){h=C[o].hdr;if(b=h=='statistique'?1:h=='personnalisation'?2:h=='advertising'?4:0)C[o].allowed=!!(_.cc&b),C[o].denied=!(_.cc&b)}
EA_epmSet(C);EA_epmEnd();ckW('eTelrCC=1',2)}}
if(_.cc)EA_data.push('onload'),EA_data.push(f)
if(f=W.EA_collector)f(EA_data)
else{
for(i=-1;i<c%7;i++)j+=A[(c+i)%A.length]
JS('//'+d+'/'+j+(c%8760)+'.js')}
if(pu)eTagS('ELR:'+EA_data.join(';'),2)
return 1};($||to)(function(){SC(EU,_.elr)})}
if($&&W==top&&M('(www|m).sfr.com|preprod-groupesfrfr.(m.)?wsfront-mic@')){_.fL=function(d){$('body').append(d.content)};JS(dj+'footer.sfr.com.json?callback=_eT.fL')}
if(T('@/terminer-ma-commande')&&s.eVar42=='KAMS8P'&&/00000000000055359(0|2)/.test(s.products||'')&&/SFR_LTR7_POWER_50GO/.test(s.products||'')){$('.prix--main > .prix.prix--del').next().text('1€')}
if(WMN)with(_){
ckW('eTwm='+(ckR('eTwm')*1+1),720)
var re=par('srr')
JS(ist+'resources/js/'+(re?'srr.js':'wmn.js'))
ST('#SFReTagArrow{display:block!}#SFReTagArrow::after{display:table;content:" ";clear:both}')
_.pub=function(i,f,g,n,x,y,o,I){
$('#main>#TB').remove()
if(g&&W.innerWidth>1399)f=g
x=f%8==1?300:f==g?160:120,y=600
if(!($(o='#SFReTag'+i+':visible')).length)return n>5||to(function(){pub(i,f,g,(n|0)+1)})
if(f==4&&_.nAd&&_.nAf)_.nAf({data:_.nAd})
if(f==4&&!_.nAf)msg(_.nAf=function(e,i,I){if(/^nAd\|/.test(e=e.data)){
var a='Annonces',b='<br/>',f=function(T,L){return'<span style="display:inline-block;font-family:sfr'+(L?'light':'bold')+'">'+T+'</span>'}
_.nAd=e;to(function(){_.nAd=0},3e5)
A=e.substr(4).split('|')
if($(o)[0]&&A[8]){
for(i in I=A[8].split(','))$(o).append('<img src="'+I[i]+'" style="display:none"/>')
A.pop();_.nAd='nAd|'+A.join('|')}
$(o).addClass('new').css('cursor','pointer').css('background',A[4]||'#f7ecec').click(function(){W.open(A[2])}).html(
'<td colspan="2"><img style="display:block;max-width:50px" src="'+A[7]+'"/></td><td style="color:#1433d6">'+f(A[5]||a)+(A[5]?b+f(a,1):'')+'</td><td/><td/><td/><td colspan="3">'+f(A[0])+b+f(A[1],1)+'</td>')}})
if(!(I=$(o).find(v='iframe')).length&&!(f==4&&_.nAd))$(o).html('<iframe/>')
I=$(o).find(v).css('width',x||'100%').css('height',y||'100%').css('border',0),f==4&&I.hide()
if(!(f==4&&_.nAd))I.attr('src',dj+"pubwm.html?y&f="+f+(X?'&X=1':''))}
_.pubT=function(){
ST('#main{overflow-y:hidden}#main>#TB{width:90%;width:calc(100% - 60px);margin:30px;height:1440px}')
$('#main').append('<iframe id="TB" src="'+dj+'pubtbwm.html"/>')}
_.wmi='web_mess_info_v2'
_.wmD=['','wmib','wmpb']
_.wmB=[]
_.wmA=function(i,b,d,n,o,v){
if(!(o=$('#SFReTag'+i)).length)return n>5||to(function(){wmA(i,b,d,(n|0)+1)})
if(v=wmB[b])o.html(v)
else _A.request({blockId:b,containerSelector:o.attr('id'),defB:d,callback:function(){_.wmB[b]=$(o).html()}})}
_.logWM=function(i,r){_.$=W.jQuery;r=i+':';$('[id^=SFR]').each(function(){r+=' '+$(this).attr('id')});log(r)}
_.wmrHP=function(){logWM('Ref HP');pub('Right',1);wmA('Arrow','web_mess_pad_v2','wmpb')}
_.wmrDM=function(){logWM('Ref DM');pub('SkyMail',2,3);wmA('LeftMail',wmi,'wmib');pub('NativeMail',4)}
_.wmrAG=function(){logWM('Ref AG');pub('SkyAgenda',5,6);wmA('LeftAgenda',wmi,'wmib')}
_.wmrCO=function(){logWM('Ref CO');pub('SkyContact',7,8);wmA('LeftContact',wmi,'wmib')}
_.wmrMS=function(){logWM('Ref MS');pub('Sent',9);pubT()}
_.wmrPA=function(){logWM('Ref PA');pub('SkyParam',10,11);wmA('LeftParam',wmi,'wmib')}
_.wmrNM=function(n){logWM('Ref NM');ckW('sfrUserUnreadMessages='+1*n,1)}
}
if(ckR('cobrow_token'))JS('//cobrowsing.sfr.fr/lib/loader.js')
if($&&M('@/forfait-mobile(-fut)?/telephone/')){
if(!W.bvoice_user)ckW('eTavis='+escape(location.href),1)
else if(ckR('eTavis')==1){
ckW('eTavis=',-1)
ti(function(h){if(h=$('#BVwritereviewLinkId').attr('href'))location.href=h})}}
if(par('Q0'))ckW('eTq0=1',720)
if(!ckR('eTq0')){
_.fQ=function(i){i='ZN_1X0qH5HJnIoPG85';var g=function(e,h,f,g,o){
o=this
o.get=function(a){for(var a=a+"=",c=D.cookie.split(";"),b=0,e=c.length;b<e;b++){for(var d=c[b];" "==d.charAt(0);)d=d.substring(1,d.length);if(0==d.indexOf(a))return d.substring(a.length,d.length)}return null}
o.set=function(a,c){var b="",b=new Date;b.setTime(b*1+6048E5);b="; expires="+b.toGMTString();document.cookie=a+"="+c+b+"; path=/; "}
o.check=function(){var a=o.get(f);if(a)a=a.split(":");else if(100!=e)"v"==h&&(e=Math.random()>=e/100?0:100),a=[h,e,0],o.set(f,a.join(":"));else return!0;var c=a[1];if(100==c)return!0;switch(a[0]){case "v":return!1;case "r":return c=a[2]%Math.floor(100/c),a[2]++,this.set(f,a.join(":")),!c}return!0}
o.go=function(){if(o.check()){var a=document.createElement("script");a.type="text/javascript";a.src=g+ "&t="+new Date*1;D.body.appendChild(a)}}}
try{(new g(100,"r","QSI_S_"+i,"//zn1x0qh5hjniopg85-sfr.siteintercept.qualtrics.com/SIE/?Q_SIID="+i+"&Q_LOC="+encodeURIComponent(W.location.href))).go()}catch(e){}
wait(function(){return $&&$('body').append("<div id='"+i+"'/>")})}
o=ckR('eTagAB')
if(WMN&&o==37||T('[#@]/terminer-ma-commande/confirmation')&&o>49)_.fQ()
else if($&&!_.nr&&o>79&&M('@/((telephonie|forfait)-mobile|(box|offre)-internet|la-box|terminer-ma-commande/|sfr-et-moi$|mon-espace-client$)|^(box|forum|assistance)@')
||$&&o<30&&(ECR||M('(communaute)?#.')))eTagSortie(8)}
_.msgDCX=function(o){
o=$('.sfrNC .user')
if(o.length)o.html('<a href="/webmail/disconnect.html">Se déconnecter</a>');else to(_.msgDCX,500)}
if(f=W.setCookieMaxResolution)f()
if(!_.app&&(ECR||T('(communaute)?#'))&&(_.cc&2)){
JS('//redbysfr.dimelochat.com/chat/fc6e382aacd0cec88799e5fb/loader.js')
v=[_.nom||'',_.prenom||'',_.conM||'',_.conT||'',(_.lf||'')+(_.lf&&_.lo?' ':'')+(_.lo||'')]
f=function(z){return/^(9.)?$/.test(z)?'':z}
_chatq=[["_setIdentity",{"screenname":v[1]+' '+v[0],"firstname":v[1],"lastname":v[0],"email":v[2],"uuid":e4,
"extra_values":{"mobile_phone":_.LM&&_.LM[0]||'',"home_phone":_.LF&&_.LF[0]||'',"ref_compte":f(Z["eVar52"])||f(Z[14]),"offre":v[4],"date_activation":dat(_.dam)+" "+dat(_.daf),"PTA":_.pt||"","id_asc":e4}}],
['_onEvent','chat_shown',function(){TL('/Dimelo/Chat/Ouverture')}],
['_onEvent','chat_engaged',function(){TL('/Dimelo/Chat/Engage')}]]
f=function(c,v){_chatq.push(["_fillCustomVariable","custom_"+c,v||!0])}
v=(_.LF&&_.LF[5]||'')+(_.LM&&_.LM[5]||'')
if(/;RPVM;/.test(v))f("virgin")
if(/;PRSC;/.test(v))f("pro")
if(/;PTML;/.test(v))f("orian")
if(/purchase/.test(s.events))f("products",s.products)
f("events",s.events)
if(_.mob())f("mobile")
f("logue")}
if(!e4&&M('#/contact$'))ST('.cont.chat{D0!}')
if(M('#/offre-internet/red-'))ti(function(){
$('.bouquet__price .price:contains(Au lieu de)').each(function(o,h,m){
if(m=(h=$h(o=$(this))).match(/Au lieu de (\d+)[.,]?(\d*)/))o.html('<span class="price--left"><span class="price__unit">'+m[1]+'</span></span><span class="price--right"><span class="price--right__top"><span class="price__euro">€</span><span class="price__cent">'+m[2]+'</span><span class="price--right__bottom"><span class="price__period">/mois</span></span></span></span><span class="price--bottom" style="position:relative;margin:0"><strong>sans engagement</strong></span>')})},200)
if(T('espace-client(-red)?@/suivi-commande/rechercheCommande')&&par('red')&&$){
$('#rechercheLink').attr('src',med+'gred-btn-valider.png')
$('#sc_bouton').css('text-align','left')
$('.champ>input').css('border-color','#777')
$('.myosotis-btn').css('background','#00e094')
$('#sc_titre,.sc_red>span').css('color','#000')}
if((X||TH%24%18>6&&(TH/24-6|0)%7<6)&&T('espace-client@/suiv(i|re-ma)-commande/retractation/accueil$')&&!par('CtC')&&$h('h1')=="Demande de rétractation")_.c2cP('5878b77480df1a43568b4567')
if(ww()>1024&&T('(sport|news)@$|@/portail.html')){
ST((v='#eTosr ')+'{float:right;text-align:right}'+v+'a{display:inline-block}'+
v+'ul{border:1px solid #cecece!;margin:2px!;padding:0;list-style-type:none;height:36px;cursor:pointer;background:#fff}'+
v+'li{height:31px;float:left;font:18px SFR-Regular;color:#292929}'+
v+'li.d{margin-top:7px;padding:0 5px}'+
v+'li.e{margin-top:0;padding:0;height:36px}'+v+'li.e>img{width:36px;height:36px;display:inline-block}'+
v+'li.b{margin-top:7px;padding:0 5px}'+
v+'li.B{margin-top:11px;padding:0 5px;font-size:14px!}'+
v+'li.g{padding:11px 4px 0;height:34px;color:#E2001A;font:12px FontAwesome!;text-align:center}')
SM(1024,v+'{D0!}')
v=(_.cp+'')[RE](/^(13|69)0..$/,'$1000')[RE](/^75...$/,'')||'75000'
if(_.cc==7)JS('https://agate-meteo.com/sfr/?type=NEWS&cp='+(_.cp||75000),function(d,v,l,f,o,B,S){
if((d=W.agateData)&&(v=d.city)&&d.link&&d.temp&&d.icon){
$('.topBar__menu').append(
'<div id="eTosr"><a onclick="s_tl(this,\'o\',s.pageName+\'/Widget Meteo Clic\')" href="http://www.sfr.fr/meteo.html?U='+escape(d.link)+'"><ul>'+
'<li class="d">'+d.temp+'°</li><li class="e"><img src="'+d.icon+'"/></li>'+
'<li class="'+(v.length<11?'b':'B')+'">'+v+'</li><li class="c"></li>'+
'<li class="g">&#xf054;</li></ul></a></div>')
l=0;ti(function(b,v){v=".topBar__menu";b=$w(v)-$ow(v+'>*')<25;$('#eTosr')[b?'hide':'show']()})
}})}
if(!_.nr&&!/[JKHNtx]/.test(e19))SC(_.iAdv,function(A){
if(A[1]&&!new RegExp(A[1]).test(e19))return
var v='',V=[v,v,v,v,v],M=_.LM||V,F=_.LF||V,m="mob_",f="fix_",r="reference_contrat",t="telephone",p="typo_client",j='libelle_statut_joya',a='jour_anciennete',
D=function(d){return d&&(TS-d)/864e5|0},FT=(_.LL[0]||'').split(':')[4],
I={"device":_.mob()?"mobile":"desktop","page_type":A[0],"civilite":_.civilite||v,"nom":_.nom||v,"prenom":_.prenom||v,"email":_.secM||v}
I[m+r]=M[4],I[m+t]=M[0],I[m+p]=M[1],I[m+j]=M[2],I[m+a]=D(M[3]),I[m+'jours_fin_engagement']=-D(_.df||v)
I[f+r]=F[4],I[f+t]=F[0],I[f+p]=F[1][RE](/THD/,FT?FT:'THD'),I[f+j]=F[2],I[f+a]=D(F[3]),I[f+'equipement']=_.box||v
if(v=_.ott)I[m+p]=I[f+p]='OTT'
if(v=v||(I[m+r]&&I[m+r]!='-'||I[f+r]?I[m+r]+'_'+I[f+r]:0))I['extID']=v
idzCustomData=I
if(_.cc&2)JS('//halc.iadvize.com/iadvize.js?sid='+(A[2]||3029)+'&lang=fr'+(A[3]?'&tpl='+A[3]:'')+(v?'&extID='+v:''))
return!0})
if(!_.app&&(v=ckR('eTs33'))<3&&T('#/(offres?-internet|bons-plans|forfaits-mobiles|telephones|terminer-|options-services/professionnels|suivi-de-commande|mobile/ma-commande)|communaute#(/t5/Forums/ct-p/Forums)?')&&(_.cc==7)){
if(e4)ckW('eTs33='+(W.cltRED_1=v*1+1),9e3)
JS('//hubtr.adlp-factory.com/tag-redbysfr')}
if($&&M('#/offre-internet/red-'))$rm('.product__detailsContainer div:contains("Avantage")')
if($&&M('#/tester-ma-ligne/eligibility-resultats.htm')){
$rm($(v='.ustep-two .mon-sb').next())
$rm(v)
$hR('.m-auto:contains("votre forfait mobile")',/Bénéficiez de.*sur votre forfait mobile/,'')}
if(M('@/tester-ma-ligne/eligibility-resultats.htm')&&/^Changer/.test(s.eVar46)&&/RED/.test(s.prop38)){
$rm('.ustep-two>h3')
$('.ustep-two>div:eq(0)').html('<div style="margin-top:50px" class="ft-26 mon-b">'+$h('.ft-26:eq(0)')[RE](/[4-9][0-9]{2} M|[0-9]+ G/,'400 M')+'</div><div class="mon-sb mt-14"><u>Attention</u></div>le changement d’offre entrainera la perte de l’avantage Multi-RED sur votre Forfait Mobile')}
if(M('www.sfrcloud@')&&!ckR(v='eTcldP')){ckW(v+'=1',9e3);_.popin(dj+'popincloud.html',600,720,_.mob()?1:0,0,'#fff')}
if($&&(M('@/sfr-et-moi/vos-services-sfr/sfr-cloud$')||M('@/cas/login')&&/cloud/.test(par('service'))&&!/sfrcloud-mobile|\/app\//.test(unescape(par('service')+par('domain'))))){
_.fSB=function(d){$B.append(d.content)}
JS(dj+'smartbannercloud.json?callback=_eT.fSB')}
if(!ckR('eTsb')&&T('#/mon-espace-client$|communaute#$')){
if(T('communaute#'))SM(768,'#smartbanner{top:50px}')
_.fSB=function(d){$B.append(d.content)}
ckW('eTsb=1',72)
JS(dj+'smartbannerred.json?callback=_eT.fSB')}
if(M('assistance@/mobile-et-tablette/reseau-sfr/couverture-reseau-sfr.html'))_.msg(function(e,d){if((e||event).data=="ELIG")_.elg()})
if(_.cc==7&&T('assistance@'))eTagS('https://www.facebook.com/tr?id=1680640282189489&ev=PageView&noscript=1',8)
if(M('@/forfait-mobile/offres/forfait-mobile$'))to(function(){$cl('.SFR_tableContainer_arrowPosition-right .SFR_arrow_text:visible')},999)
if(M('#/terminer-ma-commande/recap')&&(o=$('.itemPanier__description .text:contains(boucle locale)')).length)
o.css('font-weight','bold'),$('#layerDetailFixe .title').append('<br/>Boucle locale'),$('#layerDetailFixe .title>div').append('<br/>10,00€')
if(M('#/offre-internet/'))ti(function(){
$hR('#optionsBloc #PASS_NEO .price__unit','Gratuit','1 mois offert')
$('.boxData__titre').each(function(o){if(/25 cha/.test((o=$(this)).text()))o.html('<b>Décodeur TV</b><br>26 chaînes TV TNT avec replay et bouquets en option')})},500)
if(T('(news|sport)@|tv@/(prog|television-sur-ordinateur-par-internet)|@/(portail.html|jeux)')){
_.msg(function(d){
d=(''+d.data||'').split(':')
if(d[1]=='HAB')$B.attr('id','eTpH')
if(d[0]=='H')$('[data-pub='+d[1]+']>iframe').css('height',d[2])})
if(T('tv@/tel'))ST('[data-pub]{min-width:120px;min-height:600px}')
wait(function(){
if(!_.hab)$('[data-pub]:visible').each(function(o,v,p,f,t){if(v=(o=$(this)).data('pub')){
if(T('tv@/tel')&&v=='TV')v+=2
p=T('news@')?660387:T('sport@')?660385:T('@/jeux')?741296:v=='TV'?882594:v=='TV2'?904899:657318
f={BAN:[30344,'100%',0],INT:[30345,'1280px',0],PAV:[31054,'300px',0],GRA:[31053,'300px',0],HAB:[37161,'100%',0],TV:[31054,'300px',0],TV2:[31051,'120px','600px']}[v]
if(f)o.html('<iframe style="display:block;border:0;margin:0 auto;width:'+f[1]+';height:'+f[2]+'" src="https:'+dj+'pubns.html?b='+v+'&p='+p+'&f='+f[0]+'"/>')}})
return typeof _.hab!='function'})}
if(_.nr&&M('espace-client(-red)?@/novelli/resiliation/accueilResiliation'))
$('#motif').hide().after('<span id="motif"><br>Avant de résilier, parlez à un conseiller pour découvrir les<br>offres exceptionnelles que nous vous avons réservées :'+
'<br><a href="#" onclick="_eT.c2cRed(\'5764207c7fdf1afb6b8b4567\')" style="color:#004c9e;font-size:12px" class="mediumLink">cliquer ici</a></span>')
if(_.nr&&M('box@'))ST('.JqueryModal .modalContainerCloseButton{background-color:#00e094!}')
if(M('@/offre-internet/box-(adsl|fibre|thd)$')){
o=$('.SFR_overview_stairs')
v='.SFR_cell_height_3'
if("-"==o.eq(3).find(v).eq(0).text().trim())o.eq(3).find(v).eq(0).html($h(o.eq(0).find(v).eq(0)))}
if(v=W.eTproduits)eTagS('eTprod:'+v.length,2)
if(M("sfr-preprod.apreslachat.com|^questions-reponses@")){$('#header').css('cursor','pointer').click(function(){location='//forum.sfr.fr'});$sfr.istFooterLight()}
if(M('magazine-presse@')){
cbRNf=function(d){if($)$('body').append(d.content)}
JS(dj+'footer.standard.json?callback=cbRNf')}
if(X&&$)wait(function(){return $('#eTsH').addClass('V2').length})
if(_.nr&&T('espace-client@/suivi-incidents'))$hR('#scMainContent',/recontacter au 1023/g,'contacter <a href="https://www.red-by-sfr.fr/contact/?nav=RBOX-F-2-4-3/">par chat</a>')
if(T('(news|sport)@|@/portail.html|@$')){
v='.surface>.ifTab,.mainContent>.ifTab,#sponsors>.ifTab'
ST('.ifTab{width:100%;height:960px;border:none;overflow:hidden;margin:0}'+v+'{height:368px;padding:0 20px;max-width:1320px;margin:0 auto;display:block}')
SM(451,v+'{height:1044px}');SM(407,v+'{height:988px}');SM(352,v+'{height:900px}');SM(767,v+'{padding:0 16px}')
o='<iframe src="'+dj+'pubtb.html#'
v='&'+escape(location.href)+'&'+escape(Rf)+'" class="ifTab"></iframe>'
if($&&/^EN VIDEO/.test($('title').text()))v='V'+v
if(T('(news|sport)@/'))$('.mainContent').append('<br>'+o+1+v).append(o+2+v)
else $('body>.surface,#sponsors').append('<br>'+o+1+v)}
if(_.bSN=T('news@\\S+.html$')?"News":T('sport@\\S+.html$')?"Sport":0)JS(ist+'recherche/js/'+_.bSN+'.js',function(R,I,Q){if(I=W[_.bSN]){
function words(o,s){s='`';return o.c+s+(o.k?o.k.join(s):'')+s+o.t.replace(/[-,;:'" ]+/,' ')}
Q=$('h1:eq(0)')
$('.sidebar').append('<div id="GS"/>')
ST('#GS{margin:0 0 20px 40px}#GS>p{font-size:20px;margin:0}#GS div{font:16px SFR-Regular;cursor:pointer;margin:9px 0 20px}#GS img{margin:0;transition:all 0.5s ease;min-height:169px}#GS div>p{height:169px;overflow:hidden;margin:0 0 4px}#GS img:hover{transform:scale(1.25)}')
R=$('#GS')
R.html('<p>Voir aussi sur SFR '+_.bSN+' :</p>')
I.pop()
I.forEach(function(o){o.u='https://'+_.bSN+'.sfr.fr'+o.u})
I=I.sort(function(a,b){return b.s-a.s})
var w='\\b',q=w+(unescape(Q.text()||'')[RE](/^EN VIDEO - /,'').match(/[a-zA-Z\u00C0-\u017F]{5,}/g)||'').join(w+'|'+w)+w,n=0,N=[],S=[],E=new RegExp(q,'i'),f
if(q)I.forEach(function(o,i){if(n<6&&o&&E.test(words(o)))N[i]=1,S[n++]=o,console.log(E+'\n'+words(o)+'\n'+E.test(words(o)))})
f=n;
if(n<6)I.forEach(function(o,i){if(n<6&&o&&!N[i])S[n++]=o})
if(n)S.forEach(function(o,i,s,b){
if(o.u.indexOf(location.pathname)<0)R.append('<div onclick="location=\''+o.u+'#sfrclicid=P_BD_ARTICLE\'"><p><img src="//static.s-sfr.fr/media/'+o.i+'"/></p><b>'+o.d+'</b><br/>'+o.t+'</div>')
});else R.hide()}})
if(M('#/offre-internet/red-'))ti(function(v,o){
v='ooster:visible'
o=$('#b'+v+',#withB'+v+',#withoutB'+v)
if(o.length){
$hR(o.find('h3 span:eq(0)'),/^D/i,'Option d')
$hR(o.find('.price__unit'),/Gratuit/,'Offert')
$hR(o.find('.boxData__titre b'),/Pas de d.*/,'')
$hT('#optionsBloc h3',0,/^\s*Options/i,'Autres options')}},333)
if(cms&&T('sport@|news@|@/portail.html'))$('#eTpH a').each(function(i,o){o.href=o.href[RE](/\/\/(www\.|(sport|news))\b/,'//cms.$2')})
if(T('appel@/webcallback_form')&&par('num'))to(function($,v){
v=par('num'),$=W.$,$('.gred-textfield__input').each(function(i,o){$(o).val(v.substr(i+i,2))}),$('#call-btn').click()})
if(T('appel(.sfrbusiness.fr|@)/webcallback_form')&&(_.sbR=Rf.match(/https?:\/\/[^\/]*sfrbusiness(team)?\.fr(.*)/))){
!function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
(i[r].q=i[r].q||[]).push(arguments)},i[r].l=TS;a=s.createElement(o),
m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
}(W,D,'script','//www.google-analytics.com/analytics.js','GA')
GA('create','UA-42019862-3','auto',{'allowLinker':!0})
GA('send','pageview',location.pathname)
wait(function(o){o=D[GI]('call-msg');if(/Appel en cours/.test(o[IH])){
GA('send','event','Soyez rappelé','CTC validé',_.sbR[2]||location.pathname)
JS('//bs.serving-sys.com/Serving/ActivityServer.bs?cn=as&ActivityID=1162308&rnd='+r6+'&page_name='+escape(Rf))
JS('//nxtck.com/act.php?tag=46320&id='+r6+'&mt=1&tvalid=0&s1=rappel')
return!0}})}
if(T('@$')&&(v=1+1*ckR(o='eTnWM'))<4){
$('#eTsH .mail>a').append(im+'etnewwm.png" id="'+o+'" style="position:absolute;bottom:-79px;right:-9px;max-width:214px;z-index:48000"/>')
ckW(o+'='+v,960)
to(function(){$rm('#eTnWM')},5e3)}
if(T('sport@/')){
var AA=[]
$('#article-simple .article-item').each(function(i,o){
v=$(o).find('a').attr('href')[RE](/\/+/g,'/')
if(AA[v])$rm(o);else AA[v]=1})}
if(wm()&&T('@/forfait-mobile/offres/forfait-mobile$'))$(function(){for(v=par('eTof');v>0;v--)to(function(){$('.SFR_Navigation_Next').click()},v*750)})
if(e4&&T('@')&&!ckR('eTc2ol')&&(v=s.eVar52)&&v!='null-null'){
_.c2ol=function(d){ckW('eTc2ol='+(/^E:/.test(d)?'ERR':d),2)}
JS('//www.sfr.fr/eTagP/c2ol.jsp?i='+v)}
if(T('(@/mon-espace-client$|espace-client@/facture-fixe/consultation/infoconso$|@/espace-client/offres-et-options/parc.htm$|@/offre-internet/changer-mon-offre-|webmail@|@/resiliation.html$)')&&
e4&&!ckR('eTac')&&!_.pi0&&W==top&&/\bA_REENG_FIXE\b/.test(ckR('eTc2ol')))wait(function(){if($){
ST('#eTac{D0}');$('body').append('<div id="eTac"/>')
_A.request({blockId:'web_popin_CTC_AC',containerSelector:'eTac',callback:function(){ckW('eTac=1',168);if(!_.pi0&&/AC/.test($('#eTac').html()))_.c2cP(_.pi0='5a858a957fdf1a5e038b4567')}})}return!!$})
if(v=!_.pi0&&W==top&&(T('[@#]/(mon-)?espace-client/|espace-client(-red)?@')||WMN&&ckR('eTwm')>2)&&!T('@/mon-espace-client/try-and-buy')&&_.parPC&&lse(1)){
o=ckR('eTpcI').split(':')[0]
if(o!=1&&TH>o){
_.msg(function(e){e=(e||event).data;if(e==8||e==9)JS(_.eCli+'/'+e),TL('/Consent-'+_.eCli.split('/').pop()+(e==8?'/Accepter':'/Refuser')),postMessage('1','*')})
_.piC=function(D,i,l){l=lse(1);if((i=D[0]&&D[0].T)&&ckR('eTpcI').indexOf(i)>0)i=D[1]&&D[1].T;if(_.nr)i=i=='CGA'?i+'-R':0;if(i){ckW('eTpcI='+(TH+336)+':'+i,672);_.eCli+='/'+i;_.pi0=1;_.popin(dj+'consent.html?V='+i+'#L='+(l&&fNo(l[0])||''),500,500,0);TL('/Consent-'+i+'/Affichage')}}
o='//www.sfr.fr/eTagP/eCliL.jsp?'
i=_.parPC.split('/')[0]+'/'+v[6]+'/'+v[7]
JS(o+i)
_.eCli=o+'P/'+i}}
if(v=par('piC'))_.popin(dj+'consent.html?V='+v,500,500,0)
if(wm()&&T('boutique@/[0-9]'))o=$('.outlet__left__infos__rdv>a'),o.attr('href',o.attr('href').replace(/[0-9]{5,}/,''))
if(s.eVar24==9803254&&T('@/terminer-ma-commande/recap')&&$('#promoCode')[0])$('.recapCodePromo').css('border','3px solid #d02').css('padding',20),$('#form').hide(),$('#promoCodeForm>div').css('color','#d02').html('Merci de renseigner votre code promo unique pour profiter de cette offre')
if((_.cc&1)&&ckR('eTagAB')%10==3&&T('@(/(offre|box)-internet|/(forfait|telephonie)-mobile|/contenus|/tester-ma-ligne|/terminer-ma-commande)(/|$)|@$')){
v='setCustomVariable'
_uxa=[['setPath',location.pathname+location.hash[RE]('#','?__')],
[v,1,'Pagename',s.pageName||W._stats_pagename,3],[v,2,'Type_Acte',fs(46),3],[v,3,'authentification',fs(10),3],[v,4,'Levier_Market',fs(57),3],[v,5,'Visitor_type',fs(38),3]]
if(T('@/terminer-ma-commande/conf'))_uxa.push(['ecommerce:addTransaction',{'id':oid,'revenue':Q?prod(Q)[2]+'':'0'}]),_uxa.push(['ecommerce:send'])
JS("//t.contentsquare.net/uxa/92510e16826c8.js")}
if($&&T('[#@]/(mon-)?espace-client|espace-client(-red)?@'))wait(function(C,E,g,H,CN,l,N,nn,R,B,i){H=$('#eTtH').eq(0);if(r=H[0]&&_.LL){
CN=H.find(i='#N>div');if(!CN[0])CN=H.find(i='#N')
U='https://'+(cms?'cms':'espace-client')+(/casepp/.test(location.host)?'.sfr.fr.casepp':'')+'.sfr.fr/espace-client-mid/notification/1.0/?platform=portail&callback=_eT.fCN'
R=/@/.test(ckR('eTcnDR'))
ST(('#eTtH>@{padding:0}@>div{position:relative;cursor:pointer;border-bottom:1px solid #ccc;padding:9px 14px 9px 68px}@>div.G{background:#eee}@>div>*{display:block;padding:6px 0;font-size:13px;color:#000}@>div>b{font:bold 15px Arial}'+
'@>div>span{color:#999}@>div>img{position:absolute;top:12px;left:14px;width:40px;margin:0}@>div>div{float:right;height:16px;width:14px;background:url('+med+'puits_corbeille_sfr_red.png);background-size:cover;margin:7px;cursor:pointer}'+
'@>div>div:hover{opacity:0.5}@>div>.I{display:inline-block;margin:2px 0;padding:2px 9px;background:#e2001a;color:#fff;font:bold 11px Arial}@>div>.R{background:#00e094}')[RE](/@/g,i))
E=[];B=[]
for(i=0;l=_.LL[i];i++){
l=l&&l.split(':')
if(l&&l[0]){E[l[0]]=l[2];B[l[0]]=/RED/.test(l[1])}}
_.aCN=function(n,v,l,f){
v=n<0?'@':N[n].id
if(!v)return
if(v&&n>-1)_.fCNr(0,v)
if(n<0&&!R)ckT('eTcnDR',v,13e4)
$('#CN'+n).removeClass('G')
l=n<0?'https://'+(_.nr?'communaute.red-by-sfr.fr/t5/G%C3%A9rer-mes-informations/Utiliser-votre-centre-de-notifications/ta-p/227041':'assistance.sfr.fr/service-et-accessoire/compte-sfr/centre-de-notifications.html'):
X&&!N[n].numeroLigne?'https://espace-client'+(_.nr?'-red':'')+'.sfr.fr/suivre-ma-commande/rechercheCommande/'+N[n].idCommande:N[n].event.actionWeb
l=l[RE](/^www/,'https://www')+'#sfrclicid=EC_notif'
l=/\?/.test(l)?l[RE](/\?/,'?L='+n+'&'):l[RE](/#/,'?L='+n+'#')
f=function(){location=l}
if(v=n>-1&&E[N[n].numeroLigne])_eT.ckT('MLS',escape(v),99,f);else to(f)}
_.fCN=function(D,Ns,i,j,ok,d,nN,nj,L,n,nL,s,h,t,p,l){
if(D){
if(d=D.notifications)D=d
log(D)
for(j=0,Ns=[];j<D.length;j++)Ns=Ns.concat(D[j].notifications)
Ns.sort(function(a,b,c){c=a.timestamp-b.timestamp;return c>0?-1:c<0?1:0})
log(Ns)
s='';nN=N.length
for(j=0;j<Ns.length;j++){
L=Ns[j];
nL=L.numeroLigne||L.idCommande
N[nj=nN+j]=L
h=L.timestamp
h=(TS-h)/36e5|0
t=h<24?(h||"moins d'une")+' heure'+(h>1?'s':''):h<720?(h/24|0)+' jour'+(h>47?'s':''):(h/720|0)+' mois'
p=L.event.category.picto;p=p?'<img src="'+p[RE]('http:','')[RE](h='_sfr',B[nL]?'_red':h)+'"/>':''
s+='<div id="CN'+nj+'" onclick="_eT.aCN('+nj+')"'+(L.read?'':' class="G"')+(cms?'><div onclick="_eT.fCNm(0,'+nj+')"></div':'')+'><b>'+(nL==L.idCommande?'Commande N°'+nL:fNo(nL))+'</b>'+p+(L.event.important?'<p class="I'+(B[nL]?' R':'')+'">IMPORTANT</p>':'')+
'<p>'+L.event.objectTitle+'</p><span>Il y a '+t+'</span></div>'}
CN.append(s)
_.fCNd()}
else JS(U)}
_.fCNc=function(D,n){if(D){
log(D);n=nn+D.totalCount
H.find('#R>a[data-id=N]').html((n?'<b>'+n+'</b>':'')+'<i/>').css('display','inline-block').click(function(){if(C!=TS){
_.fCN()
ckT('eTcnD',C=TS,13e4)
s.linkTrackVars='prop32,prop73';s.prop32=(_.nr?"RED":"SFR")+'|'+H.find('#N>div').length;s_tl(this,'o','Mon compte/Notif Client')}})
}else JS(U[RE]('/?','/count?')+'c')}
_.fCNd=function(D){if(D){log(D)}else JS(U[RE]('/?','/clear?')+'d')}
_.fCNr=function(D,i){if(D){log(D)}else JS(U[RE]('/?','/read/'+i+'?')+'r')}
_.fCNm=function(D,i){if(D){log(D)}else if(N[i])$rm('#CN'+i),JS(U[RE]('/?','/mask/'+N[i].id+'?')+'m'),N[i].id=0}
C=ckR('eTcnD')
nn=C?0:1
CN.html('<div id="CN-1" onclick="_eT.aCN(-1)"'+(R?'':' class="G"')+'><img src="'+med+'puits_actu_'+(_.nr?'red':'sfr')+'.png"/><b>Bienvenue dans votre centre de notifications&nbsp;!</b><p>Vous trouverez ici toutes vos alertes et informations liées à vos lignes mobiles et box.</p></div>')
N=[];_.fCNc()}return r})
if(T('@/terminer-ma-commande/')&&e24==9803288||T('@/(forfait-mobile|offre-internet)/')&&ckR('eTfnac'))ST('#c2cD{D0!}.main-header{background:url('+med+'logo0617-vertical-fnac.png) no-repeat 98% 4px;background-size:42px}'),SM(767,'.main-header{background-size:32px}')
if(T('@/offre-internet/(changer-mon-offre|box-)')&&$('#eTag_Netflix6mois')[0])v='fiche-offre-tablette-netflix',$('img[src*='+v+']').attr('src',med+v+'-6mois.png')
if(_.nr&&T('@/espace-client/offres-et-options')){
o=$('a:contains(résilier)').click(function(e,u){
if(u=_.dimR)location=u
else{
_.dimR=u=$(this).attr('href')
$(this).removeAttr('href')
setTimeout(function(){if($('.dimelo-chat-wrapper').length<1)location=u;else stat_pvars=0,stats({pn:W.s.pageName+'/Chat'})},2e3)
$('body').append('<div id="dimelo_chat_item_markup_f2e5ab537a4ce196d8263afe" class="dimelo_chat_item_markup"> </div>')}})}
if($&&T('#/offre-internet/'))ti(function(v,o){
v='.section.section__telephone.section__porta '
o=$(v+'.section__resume')
if(/M=ADSL.*AUN=DTP/.test(ckR('SFRBOLFEL'))&&o[0]&&!o.data('eT')){
o.data('eT',1).text("Votre ligne téléphonique sera totalement dégroupée par RED by SFR, vous n'aurez donc plus d'abonnement auprès de l'opérateur historique.").show()
$(v+'h3').text('Ligne téléphonique')}},500)
if(T('@$'))c2c(2,1)
if(T('@/forfait-mobile/offres/forfait-mobile')&&par('billingModeSel')=='LOAN_FDPSFR')jQuery('select option').eq(0).prop('selected',!0).change()
if(T('@/offre-internet/box$')&&(o=$('[data-offer-code*=-3P-STARTERWEB-SL],[onclick*=-3P-STARTERWEB-SL]').parents('.overviewTable__col'))[0]){
SM(-768,'.eT625 .overviewCol__intro{padding-bottom:110px}')
o.addClass('eT625').find('.prix__baseline').before('<div style="height:30px;background:#fc0;font-size:12px;padding:11px;margin:17px 0 -17px">PAS SEULEMENT LA 1ÈRE ANNÉE</div>')}
if(T('#/terminer')&&/_SRP_/.test(s.products.split(';')[1]))ST('#eTrH{background:url('+med+'rdc_red.png?h=45) no-repeat 99% 9px!}'),SM(767,'#eTrH{background-position-y:2px!}#checkoutNav{D0!}')
if(T('@/terminer-ma-commande/recap')&&ckR('eTshrS')&&(o=$('.itemPanier__description:contains(Promo : 4,99)'))[0])o.find('span:contains(Engagement)').append('Cette offre est à 4,99€/mois pendant 12 mois, puis 19,99€/mois au-delà')
if($&&$('#eTc2')[0])to(function(){if(!$('#eTc2:visible')[0])stats({pn:pn+'/VignetteC2CnonVue3s'})},3e3)
if(X&&T('espace-client-red@/sfc-infoconso-ihm/web/infoconso$'))$('button:contains(détail)').hide()
if(T('#/offres?-internet'))_.msg(function(e,d){d=(e||event).data;if(/C2CR/.test(d))_.c2cRed(d.split('"')[3])})
if(T('@'))_.msg(function(e,d){d=(e||event).data;if(/C2CS/.test(d))_.c2cP(d.split('"')[3])})
if($&&(v=escape(par('eTgo')))&&(o=$(v).position()))$(W).scrollTop(o.top)
if(T('appel@')&&par('CAMPAIGN_ID')=='5a858a957fdf1a5e038b4567'){
ST('body{max-width:381px;padding:30px 9px 0 170px;background:url('+med+'pop-in-ctc-background_v2.jpg) no-repeat}#popin-wrapper{background:transparent}#popin-header{height:200px}#popin-subtitle{font-size:24px;color:#000;text-align:left}'+
'#popin-form br{D0}#popin-form fieldset>div{color:#fff;text-align:left}#call-btn{margin-left:5px!;line-height:36px!}#telFrance input{width:27px;margin:0 4px 0 0;border-radius:0}p.credits{text-align:left;margin-top:40px}')
SM(480,'body{min-width:288px;padding:30px 5% 0;background-size:720px;background-position:-240px}')
i='innerHTML'
o=D[GI]('authMessage');if(o)o[i]=o[i][RE](/<br>/,' ')[RE]('(e)',/F|MME|MLLE/i.test(_.civilite)?'e':'')
o=D[GI]('popin-subtitle');v=_.prenom;if(o)o[i]=o[i][RE](/^P/,v?'<b>Bonjour '+v+',</b><br/>P':'P')[RE](/ !/,'&nbsp;!')}
if(W.eTnr&&T('@/recherche')&&W.$sfr)$('eTrH')[0]||$sfr.istHeaderRed(),$('eTrF')[0]||$sfr.istFooterRed()
if(T('#/telephones'))$('.mobile__link[href*=\\ ]').each(function(o,v){o=$(this);v='href';o.attr(v,o.attr(v)[RE](/ /,'%20'))})
if(_.H18&&$((o='#headerRoot,#eTsH')+'>.T')[0])v=',style:contains(#eTsH{)',$rm(o+v+v+'+script'),_.H18()
if(_.F18&&$(o='#eTsF')[0])$rm(o+',style:contains(#eTsF{)'),_.F18()
if(par('eTckS')){
C=(D.cookie||'').split('; ').sort();v='<tr style="background:#ccc"><th>Cookie</th><th>Type</th><th>Description</th><th>Valeur</th><tr>'
for(i=0;i<C.length;i++)if(o=C[i].split('=')){
o[2]='?';o[3]=''
if(/^eT/.test(o[0]))o[2]='F',o[3]='eTag'
if(/^s_/.test(o[0]))o[2]='S',o[3]='Omniture'
if(/^__utm|^_ga/.test(o[0]))o[2]='S',o[3]='Google'
if(/^JSESS/.test(o[0]))o[2]='F',o[3]='Session'
v+='<tr><th>'+o[0]+'</th><th>'+o[2]+'</th><td>'+o[3]+'</td><td>'+o[1]+'</td></tr>'}
ST('#eTpiF{overflow:auto}#eTpiF tr>*{padding:4px;text-align:left;border:1px solid #ccc}#eTpiF td{max-width:500px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}')
_.popin('<table>'+v+'</table>',800,600,0,0,'#fff')}
if(X&&T('./offre-internet/changer-mon-offre-box/changer-mes-options.htm')){
ST('#eTpo{opacity:1;height:auto;visibility:visible}')
SM(1100,'#eTpo #mainTabs{display:flex;justify-content:space-between;margin:0}#eTpo #mainTabs a{margin:0}')
SM(1023,'#eTpo #mainTabs{display:-webkit-box;display:-ms-flexbox;display:flex;-webkit-box-orient:vertical;-webkit-box-direction:normal;-ms-flex-direction:column;flex-direction:column}'+
'#eTpo #mainTabs a{margin:0;border-radius:0;font-weight:bold}#eTpo .SFR_SectionOptionsList{display:block!}#eTpo #mainTabs li.active a{background-color:#00E094;cursor:default;color:#fff}'+
'#eTpo #innerTabs{display:-webkit-box;display:-ms-flexbox;display:flex;-ms-flex-wrap:wrap;flex-wrap:wrap;-webkit-box-pack:center;-ms-flex-pack:center;justify-content:center;padding:0}'+
'#eTpo .SFR_OptionListItem_priceWrapper{margin:0;display:-webkit-box;display:-ms-flexbox;display:flex;-webkit-box-orient:vertical;-webkit-box-direction:normal;-ms-flex-direction:column;flex-direction:column}'+
'#eTpo .SFR_Price_euros{font-size:29px;line-height:22px}#eTpo .switch{margin-top:10px}#eTpo .SFR_OptionListItem_title{font-size:16px;font-weight:bold}#eTpo .SFR_OptionListItem_priceWrapper>*{margin-left:0;padding-left:15px}')
$('.pageoption__toggle').attr('id','#eTpo')}
_.ccP=function(d,v){
if(v=d&&d.content)_.popin(v,wm()?800:'85%',900)
else JS(dj+'ckcgpdr.json?callback=_eT.ccP'+(T('[^/]*#')?'&R':T('rmcsport.tv')?'&S':''))}
if(T('[@#]/(offre-internet|forfaits?-mobiles?|box-mobile|telephones)(/|$)')&&(o=_eT.lse(1))&&o[8]=='EX7')_.popin(
"<style>#EX7{background:#fff;padding:20px;text-align:center}#EX7>p{margin:0;padding:0;font:16px Arial;text-align:justify}"+
"#EX7>a{font:bold 14px Arial;display:inline-block;margin:20px auto 0;padding:9px 20px;color:#fff;text-decoration:none;background:#"+(_.nr?'00e094':'e2001a')+"}</style>"+
"<div id='EX7'><p>L’accès à cette page n’est pas autorisé pour la ligne <b>"+o[0]+"</b> car celle-ci dispose d’un forfait spécifique limitant les modifications ou ajouts d’offre. Connectez-vous avec un autre compte pour continuer votre parcours.</p>"+
'<a href="https://www.sfr.fr/cas/logout?'+(_.nr?'red=true&':'')+'url='+escape(v='https://www.'+(_.nr?'red-by-':'')+'sfr.fr/mon-espace-client/')+
'">Se connecter avec un autre compte</a><a href="'+v+'">Se rendre dans mon espace client</a></div>',400,300,0,-1)
_.nS=0;wait(function(v,o){v=['s_vi','s_fid','sfrHome'];while(o=v.pop())if(ckR(o)){if(_.cc&1)ckW(o+'='+ckR(o),8760);else ckD(o)}return _.nS++>2},2e3)
if(T('#/forfaits-mobiles/forfait-4G-30Go-sans-engagement-promo'))$('.js-backDirect').click(function(){document.location='/forfaits-mobiles/'})
if(T('@/terminer-ma-commande/')&&s.eVar42=='KAMELS8'&&(o=$('.prix--main:contains(129€)'))[0])o.html('<del class="prix prix--del"><strong>51€</strong></del><strong>1€</strong>')
if(ckR('eTab780')>1&&T('[#@]/tester-ma-ligne/eligibility-by-ndi')&&(o=$('a[href*=-by-address]'))[0])o.attr('href',o.attr('href').replace('by-address','by-cache-address'))
if(T('[@#]/espace-client/options'))ti(function(o){$('.ui-datepicker-calendar span[title]').each(function(){$(this).html($(this).attr('title').substr(0,1))})})
if(T('[@#]/terminer-ma-commande/recap'))$rm('p:contains(Produit fictif pour toper ARO)')
if(par('eTckB')&&$)$('head').append('<script id="Cookiebot" src="https://consent.cookiebot.com/uc.js" data-cbid="8bea7c06-cc72-47d6-8f90-bbaa9b12bb3e" type="text/javascript" async></script>')
})()
