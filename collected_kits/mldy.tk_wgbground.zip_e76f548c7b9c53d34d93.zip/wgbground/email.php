<?php 
$Receive_email="jayj4jay@yandex.com";
?>