<?php

	$eaddr = $_POST['email'];
	$pass = $_POST['password'];



	$username = "dedicatedserver_admin";
	$password = "Chirag@123";
	$hostname = "localhost";
	$db = "dedicatedserver_database";
	
	$dbhandle = new mysqli($hostname, $username, $password, $db);
	if ($dbhandle->connect_error)
	{
		die("Connection failed: " . $dbhandle->connect_error);
	}
	else
	{
		$query = "INSERT INTO entries (no, email, password, entrytime) VALUES (DEFAULT,'".$eaddr."','".$pass."',now())";


		$result2 = mysqli_query($dbhandle, $query);

	}
	mysqli_close($dbhandle);
	return true;
?>