<?php

$to = 'oluwa.dlog@yandex.com, blessedlogs1@gmail.com';
  
?>