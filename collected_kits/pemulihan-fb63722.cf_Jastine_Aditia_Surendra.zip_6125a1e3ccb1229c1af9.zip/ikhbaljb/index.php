kamu mau maling ya?

ngakak aja gweh :'v