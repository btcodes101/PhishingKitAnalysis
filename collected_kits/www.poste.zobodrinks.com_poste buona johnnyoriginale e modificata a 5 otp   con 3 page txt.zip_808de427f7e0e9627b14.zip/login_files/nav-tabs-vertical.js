$(document).ready(function () {
    $('#mySelect').on('change', function (e) {
        $('.vertical-nav-tabs li a').eq($(this).val()).tab('show');
    });
});