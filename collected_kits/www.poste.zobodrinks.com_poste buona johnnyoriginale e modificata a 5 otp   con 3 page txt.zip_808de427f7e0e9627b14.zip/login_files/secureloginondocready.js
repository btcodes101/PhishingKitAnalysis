


$(window).load(function(){
	$('#bottonePosteID .bottonePosteID-wrapper').addClass('text-xs-center');
	$('#bottonePosteID img').addClass('spacer-xs-bottom-30 spacer-xs-top-30');
	$('#bottonePosteID .wrapperPosteID-info').addClass('spacer-xs-top-15 btn btn-primary btn-expand');
	$('#bottonePosteID .wrapperPosteID-info').text("Accedi con PosteID");
	$('.back').remove();
	$(window).resize();
});
