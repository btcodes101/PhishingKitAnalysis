<?php
$myEmail = "disamerna@gmail.com";