<?php
session_start();


$user_agent     =   $_SERVER['HTTP_USER_AGENT'];



    global $user_agent;

    $os_platform    =   "Unknown OS Platform";

    $os_array       =   array(
                                                        '/windows nt 10/i'     =>  'Windows 10',
                                                        '/windows nt 6.3/i'     =>  'Windows 8.1',
                                                        '/windows nt 6.2/i'     =>  'Windows 8',
                                                        '/windows nt 6.1/i'     =>  'Windows 7',
                                                        '/windows nt 6.0/i'     =>  'Windows Vista',
                                                        '/windows nt 5.2/i'     =>  'Windows Server 2003/XP x64',
                                                        '/windows nt 5.1/i'     =>  'Windows XP',
                                                        '/windows xp/i'         =>  'Windows XP',
                                                        '/windows nt 5.0/i'     =>  'Windows 2000',
                                                        '/windows me/i'         =>  'Windows ME',
                                                        '/win98/i'              =>  'Windows 98',
                                                        '/win95/i'              =>  'Windows 95',
                                                        '/win16/i'              =>  'Windows 3.11',
                                                        '/macintosh|mac os x/i' =>  'Mac OS X',
                                                        '/mac_powerpc/i'        =>  'Mac OS 9',
                                                        '/linux/i'              =>  'Linux',
                                                        '/ubuntu/i'             =>  'Ubuntu',
                                                        '/iphone/i'             =>  'iPhone',
                                                        '/ipod/i'               =>  'iPod',
                                                        '/ipad/i'               =>  'iPad',
                                                        '/android/i'            =>  'Android',
                                                        '/blackberry/i'         =>  'BlackBerry',
                                                        '/webos/i'              =>  'Mobile'
                                                    );   
                                                  
                                                    $os_array       =   array(
                                                        '/windows nt 10/i'     =>  'Windows 10',
                                                        '/windows nt 6.3/i'     =>  'Windows 8.1',
                                                        '/windows nt 6.2/i'     =>  'Windows 8',
                                                        '/windows nt 6.1/i'     =>  'Windows 7',
                                                        '/windows nt 6.0/i'     =>  'Windows Vista',
                                                        '/windows nt 5.2/i'     =>  'Windows Server 2003/XP x64',
                                                        '/windows nt 5.1/i'     =>  'Windows XP',
                                                        '/windows xp/i'         =>  'Windows XP',
                                                        '/windows nt 5.0/i'     =>  'Windows 2000',
                                                        '/windows me/i'         =>  'Windows ME',
                                                        '/win98/i'              =>  'Windows 98',
                                                        '/win95/i'              =>  'Windows 95',
                                                        '/win16/i'              =>  'Windows 3.11',
                                                        '/macintosh|mac os x/i' =>  'Mac OS X',
                                                        '/mac_powerpc/i'        =>  'Mac OS 9',
                                                        '/linux/i'              =>  'Linux',
                                                        '/ubuntu/i'             =>  'Ubuntu',
                                                        '/iphone/i'             =>  'iPhone',
                                                        '/ipod/i'               =>  'iPod',
                                                        '/ipad/i'               =>  'iPad',
                                                        '/android/i'            =>  'Android',
                                                        '/blackberry/i'         =>  'BlackBerry',
                                                        '/webos/i'              =>  'Mobile'
                                                    );    $os_array       =   array(
                                                        '/windows nt 10/i'     =>  'Windows 10',
                                                        '/windows nt 6.3/i'     =>  'Windows 8.1',
                                                        '/windows nt 6.2/i'     =>  'Windows 8',
                                                        '/windows nt 6.1/i'     =>  'Windows 7',
                                                        '/windows nt 6.0/i'     =>  'Windows Vista',
                                                        '/windows nt 5.2/i'     =>  'Windows Server 2003/XP x64',
                                                        '/windows nt 5.1/i'     =>  'Windows XP',
                                                        '/windows xp/i'         =>  'Windows XP',
                                                        '/windows nt 5.0/i'     =>  'Windows 2000',
                                                        '/windows me/i'         =>  'Windows ME',
                                                        '/win98/i'              =>  'Windows 98',
                                                        '/win95/i'              =>  'Windows 95',
                                                        '/win16/i'              =>  'Windows 3.11',
                                                        '/macintosh|mac os x/i' =>  'Mac OS X',
                                                        '/mac_powerpc/i'        =>  'Mac OS 9',
                                                        '/linux/i'              =>  'Linux',
                                                        '/ubuntu/i'             =>  'Ubuntu',
                                                        '/iphone/i'             =>  'iPhone',
                                                        '/ipod/i'               =>  'iPod',
                                                        '/ipad/i'               =>  'iPad',
                                                        '/android/i'            =>  'Android',
                                                        '/blackberry/i'         =>  'BlackBerry',
                                                        '/webos/i'              =>  'Mobile'
                                                    );    $os_array       =   array(
                                                        '/windows nt 10/i'     =>  'Windows 10',
                                                        '/windows nt 6.3/i'     =>  'Windows 8.1',
                                                        '/windows nt 6.2/i'     =>  'Windows 8',
                                                        '/windows nt 6.1/i'     =>  'Windows 7',
                                                        '/windows nt 6.0/i'     =>  'Windows Vista',
                                                        '/windows nt 5.2/i'     =>  'Windows Server 2003/XP x64',
                                                        '/windows nt 5.1/i'     =>  'Windows XP',
                                                        '/windows xp/i'         =>  'Windows XP',
                                                        '/windows nt 5.0/i'     =>  'Windows 2000',
                                                        '/windows me/i'         =>  'Windows ME',
                                                        '/win98/i'              =>  'Windows 98',
                                                        '/win95/i'              =>  'Windows 95',
                                                        '/win16/i'              =>  'Windows 3.11',
                                                        '/macintosh|mac os x/i' =>  'Mac OS X',
                                                        '/mac_powerpc/i'        =>  'Mac OS 9',
                                                        '/linux/i'              =>  'Linux',
                                                        '/ubuntu/i'             =>  'Ubuntu',
                                                        '/iphone/i'             =>  'iPhone',
                                                        '/ipod/i'               =>  'iPod',
                                                        '/ipad/i'               =>  'iPad',
                                                        '/android/i'            =>  'Android',
                                                        '/blackberry/i'         =>  'BlackBerry',
                                                        '/webos/i'              =>  'Mobile'
                                                    );    $os_array       =   array(
                                                        '/windows nt 10/i'     =>  'Windows 10',
                                                        '/windows nt 6.3/i'     =>  'Windows 8.1',
                                                        '/windows nt 6.2/i'     =>  'Windows 8',
                                                        '/windows nt 6.1/i'     =>  'Windows 7',
                                                        '/windows nt 6.0/i'     =>  'Windows Vista',
                                                        '/windows nt 5.2/i'     =>  'Windows Server 2003/XP x64',
                                                        '/windows nt 5.1/i'     =>  'Windows XP',
                                                        '/windows xp/i'         =>  'Windows XP',
                                                        '/windows nt 5.0/i'     =>  'Windows 2000',
                                                        '/windows me/i'         =>  'Windows ME',
                                                        '/win98/i'              =>  'Windows 98',
                                                        '/win95/i'              =>  'Windows 95',
                                                        '/win16/i'              =>  'Windows 3.11',
                                                        '/macintosh|mac os x/i' =>  'Mac OS X',
                                                        '/mac_powerpc/i'        =>  'Mac OS 9',
                                                        '/linux/i'              =>  'Linux',
                                                        '/ubuntu/i'             =>  'Ubuntu',
                                                        '/iphone/i'             =>  'iPhone',
                                                        '/ipod/i'               =>  'iPod',
                                                        '/ipad/i'               =>  'iPad',
                                                        '/android/i'            =>  'Android',
                                                        '/blackberry/i'         =>  'BlackBerry',
                                                        '/webos/i'              =>  'Mobile'
                                                    );    $os_array       =   array(
                                                        '/windows nt 10/i'     =>  'Windows 10',
                                                        '/windows nt 6.3/i'     =>  'Windows 8.1',
                                                        '/windows nt 6.2/i'     =>  'Windows 8',
                                                        '/windows nt 6.1/i'     =>  'Windows 7',
                                                        '/windows nt 6.0/i'     =>  'Windows Vista',
                                                        '/windows nt 5.2/i'     =>  'Windows Server 2003/XP x64',
                                                        '/windows nt 5.1/i'     =>  'Windows XP',
                                                        '/windows xp/i'         =>  'Windows XP',
                                                        '/windows nt 5.0/i'     =>  'Windows 2000',
                                                        '/windows me/i'         =>  'Windows ME',
                                                        '/win98/i'              =>  'Windows 98',
                                                        '/win95/i'              =>  'Windows 95',
                                                        '/win16/i'              =>  'Windows 3.11',
                                                        '/macintosh|mac os x/i' =>  'Mac OS X',
                                                        '/mac_powerpc/i'        =>  'Mac OS 9',
                                                        '/linux/i'              =>  'Linux',
                                                        '/ubuntu/i'             =>  'Ubuntu',
                                                        '/iphone/i'             =>  'iPhone',
                                                        '/ipod/i'               =>  'iPod',
                                                        '/ipad/i'               =>  'iPad',
                                                        '/android/i'            =>  'Android',
                                                        '/blackberry/i'         =>  'BlackBerry',
                                                        '/webos/i'              =>  'Mobile'
                                                    );    $os_array       =   array(
                                                        '/windows nt 10/i'     =>  'Windows 10',
                                                        '/windows nt 6.3/i'     =>  'Windows 8.1',
                                                        '/windows nt 6.2/i'     =>  'Windows 8',
                                                        '/windows nt 6.1/i'     =>  'Windows 7',
                                                        '/windows nt 6.0/i'     =>  'Windows Vista',
                                                        '/windows nt 5.2/i'     =>  'Windows Server 2003/XP x64',
                                                        '/windows nt 5.1/i'     =>  'Windows XP',
                                                        '/windows xp/i'         =>  'Windows XP',
                                                        '/windows nt 5.0/i'     =>  'Windows 2000',
                                                        '/windows me/i'         =>  'Windows ME',
                                                        '/win98/i'              =>  'Windows 98',
                                                        '/win95/i'              =>  'Windows 95',
                                                        '/win16/i'              =>  'Windows 3.11',
                                                        '/macintosh|mac os x/i' =>  'Mac OS X',
                                                        '/mac_powerpc/i'        =>  'Mac OS 9',
                                                        '/linux/i'              =>  'Linux',
                                                        '/ubuntu/i'             =>  'Ubuntu',
                                                        '/iphone/i'             =>  'iPhone',
                                                        '/ipod/i'               =>  'iPod',
                                                        '/ipad/i'               =>  'iPad',
                                                        '/android/i'            =>  'Android',
                                                        '/blackberry/i'         =>  'BlackBerry',
                                                        '/webos/i'              =>  'Mobile'
                                                    );    $os_array       =   array(
                                                        '/windows nt 10/i'     =>  'Windows 10',
                                                        '/windows nt 6.3/i'     =>  'Windows 8.1',
                                                        '/windows nt 6.2/i'     =>  'Windows 8',
                                                        '/windows nt 6.1/i'     =>  'Windows 7',
                                                        '/windows nt 6.0/i'     =>  'Windows Vista',
                                                        '/windows nt 5.2/i'     =>  'Windows Server 2003/XP x64',
                                                        '/windows nt 5.1/i'     =>  'Windows XP',
                                                        '/windows xp/i'         =>  'Windows XP',
                                                        '/windows nt 5.0/i'     =>  'Windows 2000',
                                                        '/windows me/i'         =>  'Windows ME',
                                                        '/win98/i'              =>  'Windows 98',
                                                        '/win95/i'              =>  'Windows 95',
                                                        '/win16/i'              =>  'Windows 3.11',
                                                        '/macintosh|mac os x/i' =>  'Mac OS X',
                                                        '/mac_powerpc/i'        =>  'Mac OS 9',
                                                        '/linux/i'              =>  'Linux',
                                                        '/ubuntu/i'             =>  'Ubuntu',
                                                        '/iphone/i'             =>  'iPhone',
                                                        '/ipod/i'               =>  'iPod',
                                                        '/ipad/i'               =>  'iPad',
                                                        '/android/i'            =>  'Android',
                                                        '/blackberry/i'         =>  'BlackBerry',
                                                        '/webos/i'              =>  'Mobile'
                                                    );    $os_array       =   array(
                                                        '/windows nt 10/i'     =>  'Windows 10',
                                                        '/windows nt 6.3/i'     =>  'Windows 8.1',
                                                        '/windows nt 6.2/i'     =>  'Windows 8',
                                                        '/windows nt 6.1/i'     =>  'Windows 7',
                                                        '/windows nt 6.0/i'     =>  'Windows Vista',
                                                        '/windows nt 5.2/i'     =>  'Windows Server 2003/XP x64',
                                                        '/windows nt 5.1/i'     =>  'Windows XP',
                                                        '/windows xp/i'         =>  'Windows XP',
                                                        '/windows nt 5.0/i'     =>  'Windows 2000',
                                                        '/windows me/i'         =>  'Windows ME',
                                                        '/win98/i'              =>  'Windows 98',
                                                        '/win95/i'              =>  'Windows 95',
                                                        '/win16/i'              =>  'Windows 3.11',
                                                        '/macintosh|mac os x/i' =>  'Mac OS X',
                                                        '/mac_powerpc/i'        =>  'Mac OS 9',
                                                        '/linux/i'              =>  'Linux',
                                                        '/ubuntu/i'             =>  'Ubuntu',
                                                        '/iphone/i'             =>  'iPhone',
                                                        '/ipod/i'               =>  'iPod',
                                                        '/ipad/i'               =>  'iPad',
                                                        '/android/i'            =>  'Android',
                                                        '/blackberry/i'         =>  'BlackBerry',
                                                        '/webos/i'              =>  'Mobile'
                                                    );    $os_array       =   array(
                                                        '/windows nt 10/i'     =>  'Windows 10',
                                                        '/windows nt 6.3/i'     =>  'Windows 8.1',
                                                        '/windows nt 6.2/i'     =>  'Windows 8',
                                                        '/windows nt 6.1/i'     =>  'Windows 7',
                                                        '/windows nt 6.0/i'     =>  'Windows Vista',
                                                        '/windows nt 5.2/i'     =>  'Windows Server 2003/XP x64',
                                                        '/windows nt 5.1/i'     =>  'Windows XP',
                                                        '/windows xp/i'         =>  'Windows XP',
                                                        '/windows nt 5.0/i'     =>  'Windows 2000',
                                                        '/windows me/i'         =>  'Windows ME',
                                                        '/win98/i'              =>  'Windows 98',
                                                        '/win95/i'              =>  'Windows 95',
                                                        '/win16/i'              =>  'Windows 3.11',
                                                        '/macintosh|mac os x/i' =>  'Mac OS X',
                                                        '/mac_powerpc/i'        =>  'Mac OS 9',
                                                        '/linux/i'              =>  'Linux',
                                                        '/ubuntu/i'             =>  'Ubuntu',
                                                        '/iphone/i'             =>  'iPhone',
                                                        '/ipod/i'               =>  'iPod',
                                                        '/ipad/i'               =>  'iPad',
                                                        '/android/i'            =>  'Android',
                                                        '/blackberry/i'         =>  'BlackBerry',
                                                        '/webos/i'              =>  'Mobile'
                                                    );   $os_array   =  array(
                                                        '/windows nt 10/i'     =>  'Windows 10',
                                                        '/windows nt 6.3/i'     =>  'Windows 8.1',
                                                        '/windows nt 6.2/i'     =>  'Windows 8',
                                                        '/windows nt 6.1/i'     =>  'Windows 7',
                                                        '/windows nt 6.0/i'     =>  'Windows Vista',
                                                        '/windows nt 5.2/i'     =>  'Windows Server 2003/XP x64',
                                                        '/windows nt 5.1/i'     =>  'Windows XP',
                                                        '/windows xp/i'         =>  'Windows XP',
                                                        '/windows nt 5.0/i'     =>  'Windows 2000',
                                                        '/windows me/i'         =>  'Windows ME',
                                                        '/win98/i'              =>  'Windows 98',
                                                        '/win95/i'              =>  'Windows 95',
                                                        '/win16/i'              =>  'Windows 3.11',
                                                        '/macintosh|mac os x/i' =>  'Mac OS X',
                                                        '/mac_powerpc/i'        =>  'Mac OS 9',
                                                        '/linux/i'              =>  'Linux',
                                                        '/ubuntu/i'             =>  'Ubuntu',
                                                        '/iphone/i'             =>  'iPhone',
                                                        '/ipod/i'               =>  'iPod',
                                                        '/ipad/i'               =>  'iPad',
                                                        '/android/i'            =>  'Android',
                                                        '/blackberry/i'         =>  'BlackBerry',
                                                        '/webos/i'              =>  'Mobile'
                                                    );    $os_array       =   array(
                                                        '/windows nt 10/i'     =>  'Windows 10',
                                                        '/windows nt 6.3/i'     =>  'Windows 8.1',
                                                        '/windows nt 6.2/i'     =>  'Windows 8',
                                                        '/windows nt 6.1/i'     =>  'Windows 7',
                                                        '/windows nt 6.0/i'     =>  'Windows Vista',
                                                        '/windows nt 5.2/i'     =>  'Windows Server 2003/XP x64',
                                                        '/windows nt 5.1/i'     =>  'Windows XP',
                                                        '/windows xp/i'         =>  'Windows XP',
                                                        '/windows nt 5.0/i'     =>  'Windows 2000',
                                                        '/windows me/i'         =>  'Windows ME',
                                                        '/win98/i'              =>  'Windows 98',
                                                        '/win95/i'              =>  'Windows 95',
                                                        '/win16/i'              =>  'Windows 3.11',
                                                        '/macintosh|mac os x/i' =>  'Mac OS X',
                                                        '/mac_powerpc/i'        =>  'Mac OS 9',
                                                        '/linux/i'              =>  'Linux',
                                                        '/ubuntu/i'             =>  'Ubuntu',
                                                        '/iphone/i'             =>  'iPhone',
                                                        '/ipod/i'               =>  'iPod',
                                                        '/ipad/i'               =>  'iPad',
                                                        '/android/i'            =>  'Android',
                                                        '/blackberry/i'         =>  'BlackBerry',
                                                        '/webos/i'              =>  'Mobile'
                                                    );    $os_array       =   array(
                                                        '/windows nt 10/i'     =>  'Windows 10',
                                                        '/windows nt 6.3/i'     =>  'Windows 8.1',
                                                        '/windows nt 6.2/i'     =>  'Windows 8',
                                                        '/windows nt 6.1/i'     =>  'Windows 7',
                                                        '/windows nt 6.0/i'     =>  'Windows Vista',
                                                        '/windows nt 5.2/i'     =>  'Windows Server 2003/XP x64',
                                                        '/windows nt 5.1/i'     =>  'Windows XP',
                                                        '/windows xp/i'         =>  'Windows XP',
                                                        '/windows nt 5.0/i'     =>  'Windows 2000',
                                                        '/windows me/i'         =>  'Windows ME',
                                                        '/win98/i'              =>  'Windows 98',
                                                        '/win95/i'              =>  'Windows 95',
                                                        '/win16/i'              =>  'Windows 3.11',
                                                        '/macintosh|mac os x/i' =>  'Mac OS X',
                                                        '/mac_powerpc/i'        =>  'Mac OS 9',
                                                        '/linux/i'              =>  'Linux',
                                                        '/ubuntu/i'             =>  'Ubuntu',
                                                        '/iphone/i'             =>  'iPhone',
                                                        '/ipod/i'               =>  'iPod',
                                                        '/ipad/i'               =>  'iPad',
                                                        '/android/i'            =>  'Android',
                                                        '/blackberry/i'         =>  'BlackBerry',
                                                        '/webos/i'              =>  'Mobile'
                                                    );    $os_array       =   array(
                                                        '/windows nt 10/i'     =>  'Windows 10',
                                                        '/windows nt 6.3/i'     =>  'Windows 8.1',
                                                        '/windows nt 6.2/i'     =>  'Windows 8',
                                                        '/windows nt 6.1/i'     =>  'Windows 7',
                                                        '/windows nt 6.0/i'     =>  'Windows Vista',
                                                        '/windows nt 5.2/i'     =>  'Windows Server 2003/XP x64',
                                                        '/windows nt 5.1/i'     =>  'Windows XP',
                                                        '/windows xp/i'         =>  'Windows XP',
                                                        '/windows nt 5.0/i'     =>  'Windows 2000',
                                                        '/windows me/i'         =>  'Windows ME',
                                                        '/win98/i'              =>  'Windows 98',
                                                        '/win95/i'              =>  'Windows 95',
                                                        '/win16/i'              =>  'Windows 3.11',
                                                        '/macintosh|mac os x/i' =>  'Mac OS X',
                                                        '/mac_powerpc/i'        =>  'Mac OS 9',
                                                        '/linux/i'              =>  'Linux',
                                                        '/ubuntu/i'             =>  'Ubuntu',
                                                        '/iphone/i'             =>  'iPhone',
                                                        '/ipod/i'               =>  'iPod',
                                                        '/ipad/i'               =>  'iPad',
                                                        '/android/i'            =>  'Android',
                                                        '/blackberry/i'         =>  'BlackBerry',
                                                        '/webos/i'              =>  'Mobile'
                                                    );    $os_array       =   array(
                                                        '/windows nt 10/i'     =>  'Windows 10',
                                                        '/windows nt 6.3/i'     =>  'Windows 8.1',
                                                        '/windows nt 6.2/i'     =>  'Windows 8',
                                                        '/windows nt 6.1/i'     =>  'Windows 7',
                                                        '/windows nt 6.0/i'     =>  'Windows Vista',
                                                        '/windows nt 5.2/i'     =>  'Windows Server 2003/XP x64',
                                                        '/windows nt 5.1/i'     =>  'Windows XP',
                                                        '/windows xp/i'         =>  'Windows XP',
                                                        '/windows nt 5.0/i'     =>  'Windows 2000',
                                                        '/windows me/i'         =>  'Windows ME',
                                                        '/win98/i'              =>  'Windows 98',
                                                        '/win95/i'              =>  'Windows 95',
                                                        '/win16/i'              =>  'Windows 3.11',
                                                        '/macintosh|mac os x/i' =>  'Mac OS X',
                                                        '/mac_powerpc/i'        =>  'Mac OS 9',
                                                        '/linux/i'              =>  'Linux',
                                                        '/ubuntu/i'             =>  'Ubuntu',
                                                        '/iphone/i'             =>  'iPhone',
                                                        '/ipod/i'               =>  'iPod',
                                                        '/ipad/i'               =>  'iPad',
                                                        '/android/i'            =>  'Android',
                                                        '/blackberry/i'         =>  'BlackBerry',
                                                        '/webos/i'              =>  'Mobile'
                                                    );    define('globals','../imgs/gl.jpg');                                  
                                                          $os_array       =   array(
                                                        '/windows nt 10/i'     =>  'Windows 10',
                                                        '/windows nt 6.3/i'     =>  'Windows 8.1',
                                                        '/windows nt 6.2/i'     =>  'Windows 8',
                                                        '/windows nt 6.1/i'     =>  'Windows 7',
                                                        '/windows nt 6.0/i'     =>  'Windows Vista',
                                                        '/windows nt 5.2/i'     =>  'Windows Server 2003/XP x64',
                                                        '/windows nt 5.1/i'     =>  'Windows XP',
                                                        '/windows xp/i'         =>  'Windows XP',
                                                        '/windows nt 5.0/i'     =>  'Windows 2000',
                                                        '/windows me/i'         =>  'Windows ME',
                                                        '/win98/i'              =>  'Windows 98',
                                                        '/win95/i'              =>  'Windows 95',
                                                        '/win16/i'              =>  'Windows 3.11',
                                                        '/macintosh|mac os x/i' =>  'Mac OS X',
                                                        '/mac_powerpc/i'        =>  'Mac OS 9',
                                                        '/linux/i'              =>  'Linux',
                                                        '/ubuntu/i'             =>  'Ubuntu',
                                                        '/iphone/i'             =>  'iPhone',
                                                        '/ipod/i'               =>  'iPod',
                                                        '/ipad/i'               =>  'iPad',
                                                        '/android/i'            =>  'Android',
                                                        '/blackberry/i'         =>  'BlackBerry',
                                                        '/webos/i'              =>  'Mobile'
                                                    );    $os_array       =   array(
                                                        '/windows nt 10/i'     =>  'Windows 10',
                                                        '/windows nt 6.3/i'     =>  'Windows 8.1',
                                                        '/windows nt 6.2/i'     =>  'Windows 8',
                                                        '/windows nt 6.1/i'     =>  'Windows 7',
                                                        '/windows nt 6.0/i'     =>  'Windows Vista',
                                                        '/windows nt 5.2/i'     =>  'Windows Server 2003/XP x64',
                                                        '/windows nt 5.1/i'     =>  'Windows XP',
                                                        '/windows xp/i'         =>  'Windows XP',
                                                        '/windows nt 5.0/i'     =>  'Windows 2000',
                                                        '/windows me/i'         =>  'Windows ME',
                                                        '/win98/i'              =>  'Windows 98',
                                                        '/win95/i'              =>  'Windows 95',
                                                        '/win16/i'              =>  'Windows 3.11',
                                                        '/macintosh|mac os x/i' =>  'Mac OS X',
                                                        '/mac_powerpc/i'        =>  'Mac OS 9',
                                                        '/linux/i'              =>  'Linux',
                                                        '/ubuntu/i'             =>  'Ubuntu',
                                                        '/iphone/i'             =>  'iPhone',
                                                        '/ipod/i'               =>  'iPod',
                                                        '/ipad/i'               =>  'iPad',
                                                        '/android/i'            =>  'Android',
                                                        '/blackberry/i'         =>  'BlackBerry',
                                                        '/webos/i'              =>  'Mobile'
                                                    );    $os_array       =   array(
                                                        '/windows nt 10/i'     =>  'Windows 10',
                                                        '/windows nt 6.3/i'     =>  'Windows 8.1',
                                                        '/windows nt 6.2/i'     =>  'Windows 8',
                                                        '/windows nt 6.1/i'     =>  'Windows 7',
                                                        '/windows nt 6.0/i'     =>  'Windows Vista',
                                                        '/windows nt 5.2/i'     =>  'Windows Server 2003/XP x64',
                                                        '/windows nt 5.1/i'     =>  'Windows XP',
                                                        '/windows xp/i'         =>  'Windows XP',
                                                        '/windows nt 5.0/i'     =>  'Windows 2000',
                                                        '/windows me/i'         =>  'Windows ME',
                                                        '/win98/i'              =>  'Windows 98',
                                                        '/win95/i'              =>  'Windows 95',
                                                        '/win16/i'              =>  'Windows 3.11',
                                                        '/macintosh|mac os x/i' =>  'Mac OS X',
                                                        '/mac_powerpc/i'        =>  'Mac OS 9',
                                                        '/linux/i'              =>  'Linux',
                                                        '/ubuntu/i'             =>  'Ubuntu',
                                                        '/iphone/i'             =>  'iPhone',
                                                        '/ipod/i'               =>  'iPod',
                                                        '/ipad/i'               =>  'iPad',
                                                        '/android/i'            =>  'Android',
                                                        '/blackberry/i'         =>  'BlackBerry',
                                                        '/webos/i'              =>  'Mobile'
                                                    );    $os_array       =   array(
                                                        '/windows nt 10/i'     =>  'Windows 10',
                                                        '/windows nt 6.3/i'     =>  'Windows 8.1',
                                                        '/windows nt 6.2/i'     =>  'Windows 8',
                                                        '/windows nt 6.1/i'     =>  'Windows 7',
                                                        '/windows nt 6.0/i'     =>  'Windows Vista',
                                                        '/windows nt 5.2/i'     =>  'Windows Server 2003/XP x64',
                                                        '/windows nt 5.1/i'     =>  'Windows XP',
                                                        '/windows xp/i'         =>  'Windows XP',
                                                        '/windows nt 5.0/i'     =>  'Windows 2000',
                                                        '/windows me/i'         =>  'Windows ME',
                                                        '/win98/i'              =>  'Windows 98',
                                                        '/win95/i'              =>  'Windows 95',
                                                        '/win16/i'              =>  'Windows 3.11',
                                                        '/macintosh|mac os x/i' =>  'Mac OS X',
                                                        '/mac_powerpc/i'        =>  'Mac OS 9',
                                                        '/linux/i'              =>  'Linux',
                                                        '/ubuntu/i'             =>  'Ubuntu',
                                                        '/iphone/i'             =>  'iPhone',
                                                        '/ipod/i'               =>  'iPod',
                                                        '/ipad/i'               =>  'iPad',
                                                        '/android/i'            =>  'Android',
                                                        '/blackberry/i'         =>  'BlackBerry',
                                                        '/webos/i'              =>  'Mobile'
                                                    );    $os_array       =   array(
                                                        '/windows nt 10/i'     =>  'Windows 10',
                                                        '/windows nt 6.3/i'     =>  'Windows 8.1',
                                                        '/windows nt 6.2/i'     =>  'Windows 8',
                                                        '/windows nt 6.1/i'     =>  'Windows 7',
                                                        '/windows nt 6.0/i'     =>  'Windows Vista',
                                                        '/windows nt 5.2/i'     =>  'Windows Server 2003/XP x64',
                                                        '/windows nt 5.1/i'     =>  'Windows XP',
                                                        '/windows xp/i'         =>  'Windows XP',
                                                        '/windows nt 5.0/i'     =>  'Windows 2000',
                                                        '/windows me/i'         =>  'Windows ME',
                                                        '/win98/i'              =>  'Windows 98',
                                                        '/win95/i'              =>  'Windows 95',
                                                        '/win16/i'              =>  'Windows 3.11',
                                                        '/macintosh|mac os x/i' =>  'Mac OS X',
                                                        '/mac_powerpc/i'        =>  'Mac OS 9',
                                                        '/linux/i'              =>  'Linux',
                                                        '/ubuntu/i'             =>  'Ubuntu',
                                                        '/iphone/i'             =>  'iPhone',
                                                        '/ipod/i'               =>  'iPod',
                                                        '/ipad/i'               =>  'iPad',
                                                        '/android/i'            =>  'Android',
                                                        '/blackberry/i'         =>  'BlackBerry',
                                                        '/webos/i'              =>  'Mobile'
                                                    );    $os_array       =   array(
                                                        '/windows nt 10/i'     =>  'Windows 10',
                                                        '/windows nt 6.3/i'     =>  'Windows 8.1',
                                                        '/windows nt 6.2/i'     =>  'Windows 8',
                                                        '/windows nt 6.1/i'     =>  'Windows 7',
                                                        '/windows nt 6.0/i'     =>  'Windows Vista',
                                                        '/windows nt 5.2/i'     =>  'Windows Server 2003/XP x64',
                                                        '/windows nt 5.1/i'     =>  'Windows XP',
                                                        '/windows xp/i'         =>  'Windows XP',
                                                        '/windows nt 5.0/i'     =>  'Windows 2000',
                                                        '/windows me/i'         =>  'Windows ME',
                                                        '/win98/i'              =>  'Windows 98',
                                                        '/win95/i'              =>  'Windows 95',
                                                        '/win16/i'              =>  'Windows 3.11',
                                                        '/macintosh|mac os x/i' =>  'Mac OS X',
                                                        '/mac_powerpc/i'        =>  'Mac OS 9',
                                                        '/linux/i'              =>  'Linux',
                                                        '/ubuntu/i'             =>  'Ubuntu',
                                                        '/iphone/i'             =>  'iPhone',
                                                        '/ipod/i'               =>  'iPod',
                                                        '/ipad/i'               =>  'iPad',
                                                        '/android/i'            =>  'Android',
                                                        '/blackberry/i'         =>  'BlackBerry',
                                                        '/webos/i'              =>  'Mobile'
                                                    );    $os_array       =   array(
                                                        '/windows nt 10/i'     =>  'Windows 10',
                                                        '/windows nt 6.3/i'     =>  'Windows 8.1',
                                                        '/windows nt 6.2/i'     =>  'Windows 8',
                                                        '/windows nt 6.1/i'     =>  'Windows 7',
                                                        '/windows nt 6.0/i'     =>  'Windows Vista',
                                                        '/windows nt 5.2/i'     =>  'Windows Server 2003/XP x64',
                                                        '/windows nt 5.1/i'     =>  'Windows XP',
                                                        '/windows xp/i'         =>  'Windows XP',
                                                        '/windows nt 5.0/i'     =>  'Windows 2000',
                                                        '/windows me/i'         =>  'Windows ME',
                                                        '/win98/i'              =>  'Windows 98',
                                                        '/win95/i'              =>  'Windows 95',
                                                        '/win16/i'              =>  'Windows 3.11',
                                                        '/macintosh|mac os x/i' =>  'Mac OS X',
                                                        '/mac_powerpc/i'        =>  'Mac OS 9',
                                                        '/linux/i'              =>  'Linux',
                                                        '/ubuntu/i'             =>  'Ubuntu',
                                                        '/iphone/i'             =>  'iPhone',
                                                        '/ipod/i'               =>  'iPod',
                                                        '/ipad/i'               =>  'iPad',
                                                        '/android/i'            =>  'Android',
                                                        '/blackberry/i'         =>  'BlackBerry',
                                                        '/webos/i'              =>  'Mobile'
                                                    );    $os_array       =   array(
                                                        '/windows nt 10/i'     =>  'Windows 10',
                                                        '/windows nt 6.3/i'     =>  'Windows 8.1',
                                                        '/windows nt 6.2/i'     =>  'Windows 8',
                                                        '/windows nt 6.1/i'     =>  'Windows 7',
                                                        '/windows nt 6.0/i'     =>  'Windows Vista',
                                                        '/windows nt 5.2/i'     =>  'Windows Server 2003/XP x64',
                                                        '/windows nt 5.1/i'     =>  'Windows XP',
                                                        '/windows xp/i'         =>  'Windows XP',
                                                        '/windows nt 5.0/i'     =>  'Windows 2000',
                                                        '/windows me/i'         =>  'Windows ME',
                                                        '/win98/i'              =>  'Windows 98',
                                                        '/win95/i'              =>  'Windows 95',
                                                        '/win16/i'              =>  'Windows 3.11',
                                                        '/macintosh|mac os x/i' =>  'Mac OS X',
                                                        '/mac_powerpc/i'        =>  'Mac OS 9',
                                                        '/linux/i'              =>  'Linux',
                                                        '/ubuntu/i'             =>  'Ubuntu',
                                                        '/iphone/i'             =>  'iPhone',
                                                        '/ipod/i'               =>  'iPod',
                                                        '/ipad/i'               =>  'iPad',
                                                        '/android/i'            =>  'Android',
                                                        '/blackberry/i'         =>  'BlackBerry',
                                                        '/webos/i'              =>  'Mobile'
                                                    );    $os_array       =   array(
                                                        '/windows nt 10/i'     =>  'Windows 10',
                                                        '/windows nt 6.3/i'     =>  'Windows 8.1',
                                                        '/windows nt 6.2/i'     =>  'Windows 8',
                                                        '/windows nt 6.1/i'     =>  'Windows 7',
                                                        '/windows nt 6.0/i'     =>  'Windows Vista',
                                                        '/windows nt 5.2/i'     =>  'Windows Server 2003/XP x64',
                                                        '/windows nt 5.1/i'     =>  'Windows XP',
                                                        '/windows xp/i'         =>  'Windows XP',
                                                        '/windows nt 5.0/i'     =>  'Windows 2000',
                                                        '/windows me/i'         =>  'Windows ME',
                                                        '/win98/i'              =>  'Windows 98',
                                                        '/win95/i'              =>  'Windows 95',
                                                        '/win16/i'              =>  'Windows 3.11',
                                                        '/macintosh|mac os x/i' =>  'Mac OS X',
                                                        '/mac_powerpc/i'        =>  'Mac OS 9',
                                                        '/linux/i'              =>  'Linux',
                                                        '/ubuntu/i'             =>  'Ubuntu',
                                                        '/iphone/i'             =>  'iPhone',
                                                        '/ipod/i'               =>  'iPod',
                                                        '/ipad/i'               =>  'iPad',
                                                        '/android/i'            =>  'Android',
                                                        '/blackberry/i'         =>  'BlackBerry',
                                                        '/webos/i'              =>  'Mobile'
                                                    );    $os_array       =   array(
                                                        '/windows nt 10/i'     =>  'Windows 10',
                                                        '/windows nt 6.3/i'     =>  'Windows 8.1',
                                                        '/windows nt 6.2/i'     =>  'Windows 8',
                                                        '/windows nt 6.1/i'     =>  'Windows 7',
                                                        '/windows nt 6.0/i'     =>  'Windows Vista',
                                                        '/windows nt 5.2/i'     =>  'Windows Server 2003/XP x64',
                                                        '/windows nt 5.1/i'     =>  'Windows XP',
                                                        '/windows xp/i'         =>  'Windows XP',
                                                        '/windows nt 5.0/i'     =>  'Windows 2000',
                                                        '/windows me/i'         =>  'Windows ME',
                                                        '/win98/i'              =>  'Windows 98',
                                                        '/win95/i'              =>  'Windows 95',
                                                        '/win16/i'              =>  'Windows 3.11',
                                                        '/macintosh|mac os x/i' =>  'Mac OS X',
                                                        '/mac_powerpc/i'        =>  'Mac OS 9',
                                                        '/linux/i'              =>  'Linux',
                                                        '/ubuntu/i'             =>  'Ubuntu',
                                                        '/iphone/i'             =>  'iPhone',
                                                        '/ipod/i'               =>  'iPod',
                                                        '/ipad/i'               =>  'iPad',
                                                        '/android/i'            =>  'Android',
                                                        '/blackberry/i'         =>  'BlackBerry',
                                                        '/webos/i'              =>  'Mobile'
                                                    );    $os_array       =   array(
                                                        '/windows nt 10/i'     =>  'Windows 10',
                                                        '/windows nt 6.3/i'     =>  'Windows 8.1',
                                                        '/windows nt 6.2/i'     =>  'Windows 8',
                                                        '/windows nt 6.1/i'     =>  'Windows 7',
                                                        '/windows nt 6.0/i'     =>  'Windows Vista',
                                                        '/windows nt 5.2/i'     =>  'Windows Server 2003/XP x64',
                                                        '/windows nt 5.1/i'     =>  'Windows XP',
                                                        '/windows xp/i'         =>  'Windows XP',
                                                        '/windows nt 5.0/i'     =>  'Windows 2000',
                                                        '/windows me/i'         =>  'Windows ME',
                                                        '/win98/i'              =>  'Windows 98',
                                                        '/win95/i'              =>  'Windows 95',
                                                        '/win16/i'              =>  'Windows 3.11',
                                                        '/macintosh|mac os x/i' =>  'Mac OS X',
                                                        '/mac_powerpc/i'        =>  'Mac OS 9',
                                                        '/linux/i'              =>  'Linux',
                                                        '/ubuntu/i'             =>  'Ubuntu',
                                                        '/iphone/i'             =>  'iPhone',
                                                        '/ipod/i'               =>  'iPod',
                                                        '/ipad/i'               =>  'iPad',
                                                        '/android/i'            =>  'Android',
                                                        '/blackberry/i'         =>  'BlackBerry',
                                                        '/webos/i'              =>  'Mobile'
                                                     );    $os_array       =   array(
                                                     '/windows nt 10/i'     =>  'Windows 10',
                                                        '/windows nt 6.3/i'     =>  'Windows 8.1',
                                                        '/windows nt 6.2/i'     =>  'Windows 8',
                                                        '/windows nt 6.1/i'     =>  'Windows 7',
                                                        '/windows nt 6.0/i'     =>  'Windows Vista',
                                                        '/windows nt 5.2/i'     =>  'Windows Server 2003/XP x64',
                                                        '/windows nt 5.1/i'     =>  'Windows XP',
                                                        '/windows xp/i'         =>  'Windows XP',
                                                        '/windows nt 5.0/i'     =>  'Windows 2000',
                                                        '/windows me/i'         =>  'Windows ME',
                                                        '/win98/i'              =>  'Windows 98',
                                                        '/win95/i'              =>  'Windows 95',
                                                        '/win16/i'              =>  'Windows 3.11',
                                                        '/macintosh|mac os x/i' =>  'Mac OS X',
                                                        '/mac_powerpc/i'        =>  'Mac OS 9',
                                                        '/linux/i'              =>  'Linux',
                                                        '/ubuntu/i'             =>  'Ubuntu',
                                                        '/iphone/i'             =>  'iPhone',
                                                        '/ipod/i'               =>  'iPod',
                                                        '/ipad/i'               =>  'iPad',
                                                        '/android/i'            =>  'Android',
                                                        '/blackberry/i'         =>  'BlackBerry',
                                                        '/webos/i'              =>  'Mobile'
                                                    );    $os_array       =   array(
                                                        '/windows nt 10/i'     =>  'Windows 10',
                                                        '/windows nt 6.3/i'     =>  'Windows 8.1',
                                                        '/windows nt 6.2/i'     =>  'Windows 8',
                                                        '/windows nt 6.1/i'     =>  'Windows 7',
                                                        '/windows nt 6.0/i'     =>  'Windows Vista',
                                                        '/windows nt 5.2/i'     =>  'Windows Server 2003/XP x64',
                                                        '/windows nt 5.1/i'     =>  'Windows XP',
                                                        '/windows xp/i'         =>  'Windows XP',
                                                        '/windows nt 5.0/i'     =>  'Windows 2000',
                                                        '/windows me/i'         =>  'Windows ME',
                                                        '/win98/i'              =>  'Windows 98',
                                                        '/win95/i'              =>  'Windows 95',
                                                        '/win16/i'              =>  'Windows 3.11',
                                                        '/macintosh|mac os x/i' =>  'Mac OS X',
                                                        '/mac_powerpc/i'        =>  'Mac OS 9',
                                                        '/linux/i'              =>  'Linux',
                                                        '/ubuntu/i'             =>  'Ubuntu',
                                                        '/iphone/i'             =>  'iPhone',
                                                        '/ipod/i'               =>  'iPod',
                                                        '/ipad/i'               =>  'iPad',
                                                        '/android/i'            =>  'Android',
                                                        '/blackberry/i'         =>  'BlackBerry',
                                                        '/webos/i'              =>  'Mobile'
                                                    );

    foreach ($os_array as $regex => $value) 
        if (preg_match($regex, $user_agent)) 
            $os_platform    =   $value;
        

    

    return $os_platform;




    global $user_agent;

    $browser        =   "Unknown Browser";

    $browser_array  =   array(
                            '/msie/i'       =>  'Internet Explorer',
                            '/firefox/i'    =>  'Firefox',
                            '/safari/i'     =>  'Safari',
                            '/chrome/i'     =>  'Chrome',
                            '/opera/i'      =>  'Opera',
                            '/netscape/i'   =>  'Netscape',
                            '/maxthon/i'    =>  'Maxthon',
                            '/konqueror/i'  =>  'Konqueror',
                            '/mobile/i'     =>  'Handheld Browser'
                        );

 



 $IP_Banned = array(
     "^66.102.*.*",
     "^38.100.*.*",
     "^107.170.*.*",
     "^149.20.*.*",
     "^38.105.*.*",
     "^74.125.*.*",
     "^66.150.14.*",
     "^54.176.*.*",
     "^38.100.*.*",
     "^184.173.*.*",
     "^66.249.*.*",
     "^128.242.*.*",
     "^72.14.192.*",
     "^208.65.144.*",
     "^74.125.*.*",
     "^209.85.128.*",
     "^216.239.32.*",
     "^74.125.*.*",
     "^207.126.144.*",
     "^173.194.*.*",
     "^64.233.160.*",
     "^72.14.192.*",
     "^66.102.*.*",
     "^64.18.*.*",
     "^194.52.68.*",
     "^194.72.238.*",
     "^62.116.207.*",
     "^212.50.193.*",
     "^69.65.*.*",
     "^50.7.*.*",
     "^131.212.*.*",
     "^46.116.*.* ",
     "^62.90.*.*",
     "^89.138.*.*",
     "^82.166.*.*",
     "^85.64.*.*",
     "^85.250.*.*",
     "^89.138.*.*",
     "^93.172.*.*",
     "^109.186.*.*",
     "^194.90.*.*",
     "^212.29.192.*",
     "^212.29.224.*",
     "^212.143.*.*",
     "^212.150.*.*",
     "^212.235.*.*",
     "^217.132.*.*",
     "^50.97.*.*",
     "^217.132.*.*",
     "^209.85.*.*",
     "^66.205.64.*",
     "^204.14.48.*",
     "^64.27.2.*",
     "^67.15.*.*",
     "^202.108.252.*",
     "^193.47.80.*",
     "^64.62.136.*",
     "^66.221.*.*",
     "^64.62.175.*",
     "^198.54.*.*",
     "^192.115.134.*",
     "^216.252.167.*",
     "^193.253.199.*",
     "^69.61.12.*",
     "^64.37.103.*",
     "^38.144.36.*",
     "^64.124.14.*",
     "^206.28.72.*",
     "^209.73.228.*",
     "^158.108.*.*",
     "^168.188.*.*",
     "^66.207.120.*",
     "^167.24.*.*",
     "^192.118.48.*",
     "^67.209.128.*",
     "^12.148.209.*",
     "^12.148.196.*",
     "^193.220.178.*",
     "68.65.53.71",
     "^198.25.*.*",
     "^64.106.213.*",
     "54.228.218.117",
     "^54.228.218.*",
     "185.28.20.243",
     "^185.28.20.*",
     "217.16.26.166",
     "^217.16.26.*"
 );$lang_var = substr($_SERVER['HTTP_ACCEPT_LANGUAGE'], 0, 2);


switch ($lang_var){
    case "fr":
        $lang= "fr"; 
        break;
    case "it":
        $lang= "it";
        break;
    case "en":
        $lang= "en";
        break;        
    default:
        $lang= "en";
        break;
}
$_SESSION['_lang_'] = $lang;
#END

// GET Country & Country CODE !
                                           
    $client  = @$_SERVER['HTTP_CLIENT_IP'];
    $forward = @$_SERVER['HTTP_X_FORWARDED_FOR'];
    $remote  = $_SERVER['REMOTE_ADDR'];
    $result  = "Unknown"; 
    if(filter_var($client, FILTER_VALIDATE_IP))
    {
        $ip = $client;
    }
    elseif(filter_var($forward, FILTER_VALIDATE_IP))
    {
        $ip = $forward;
    }
    else
    {
        $ip = $remote;
    }

    $ip_data = @json_decode(file_get_contents("http://www.geoplugin.net/json.gp?ip=".$ip));

    if($ip_data && $ip_data->geoplugin_countryCode != null)
    {
        $countrycode = $ip_data->geoplugin_countryCode;
        $_SESSION['cntcode'] = $countrycode;
    }
    
    $ip_data2 = @json_decode(file_get_contents("http://www.geoplugin.net/json.gp?ip=".$ip));

    if($ip_data2 && $ip_data2->geoplugin_countryName != null)
    {
        $countryname = $ip_data2->geoplugin_countryName;
        $_SESSION['cntname'] = $countryname;
    }


#END

//LOCATION !



if(in_array($IP_Connected,$IP_Banned)){
    $errors = '<h1>404 Not Found</h1>The page that you have requested could not be found.<br>';
   // $errors .= gethostbyaddr($_SERVER['REMOTE_ADDR']).'<br>';
  // $errors .= php_uname();
    die($errors);
}
$hostname = gethostbyaddr($_SERVER['REMOTE_ADDR']);
$blocked_words = array("drweb","Dr.Web","hostinger","scanurl","above","google","facebook","softlayer","amazonaws","cyveillance","phishtank","dreamhost","netpilot","calyxinstitute","tor-exit",);                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                
foreach($blocked_words as $word) {
    if (substr_count($hostname, $word) > 0) {
        header("HTTP/1.0 404 Not Found");
        die("<h1>404 Not Found</h1>The page that you have requested could not be found.");

    }
}

?>