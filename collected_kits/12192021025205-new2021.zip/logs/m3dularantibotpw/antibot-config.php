<?php
/** Telegram : @m3dular integrator rewrite
 * DO NOT MODIFY
 * 
 */

$config['apikey'] 		= 'dc6dc6240ac416dcb9977cd7e4877a2c';  // https://antibot.pw/dashboard/developers
$querykey="n8hTzCp";        // our key profile ....