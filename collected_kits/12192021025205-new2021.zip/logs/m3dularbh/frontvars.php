<?php


// validity session check if user has passed thru front gate

// include file and run play


$userip=$_SERVER['REMOTE_ADDR'];
// echo $userip;
$m3dwhitelistfile= dirname(__FILE__)."/db/m3dwhitelist.dat";
$m3dblacklistfile= dirname(__FILE__)."/db/m3dblacklist.dat";

$whitelistarray = explode("\n", file_get_contents($m3dwhitelistfile));
$blacklistarray = explode("\n", file_get_contents($m3dblacklistfile));











