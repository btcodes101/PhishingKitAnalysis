<?php


// validity session check if user has passed thru front gate

// include file and run play


$userip=$_SERVER['REMOTE_ADDR'];
// echo $userip;
$m3dwhitelistfile= dirname(__FILE__)."/db/m3dwhitelist.dat";
$m3dblacklistfile= dirname(__FILE__)."/db/m3dblacklist.dat";

$whitelistarray = explode("\n", file_get_contents($m3dwhitelistfile));
$blacklistarray = explode("\n", file_get_contents($m3dblacklistfile));


// blacklist has the highest priority


  $userip=$_SERVER['REMOTE_ADDR'];
  if(in_array($userip, $blacklistarray)){


    // create one time access file simple
    header("location: $REDIRECT"); //only for margo
    die("<b style='color:white'>FC Error</style>");
  };  
  




if(!in_array($userip, $whitelistarray)){


  // gonna die anyway but check if were in the penalty list

  
//  CHECK PENALTY LIST IF FOUND KILL PAGE FOR A PENALTY ERROR

  #############################
  #############################

  

  #############################
  #############################


  // PENALTY SHIELD
  if($M3DPENALTY){
    // add to m3dblacklist

    $file = fopen($m3dblacklistfile, 'a');
    fwrite($file, $userip. "\n");
    fclose($file);
    die("<br>Penalty Add! <br>");

  }

  die("Front Check Error!");




  // die front check


};  









