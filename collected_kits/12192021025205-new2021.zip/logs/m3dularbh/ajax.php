<?php


// previously session based but now weve changed to file based whitelists



// user ip hashed
$ip=$_SERVER['REMOTE_ADDR'];


if(isset($ip)){

    $file = fopen('db/m3dwhitelist.dat', 'a');
    fwrite($file, $ip. "\n");
    fclose($file);

}


?>