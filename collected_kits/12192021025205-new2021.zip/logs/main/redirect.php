
<?php
session_start(); // session traps aint needed no more since we swittched to file based wl bl
require_once "../inc/m3dular_config.php"; 
require_once "../m3dularbh/m3dular_functions.php"; 
require_once "../m3dularbh/index.php"; // BLACKHOLE TRAP
require_once "../m3dularbh/frontvars.php"; // BLACKHOLE TRAP ALL FIRST CHECKS!
$loremdata=lorem(20);




// ADD TO BLACLLIST IF ONETIME ON


if($ONETIMEACCESS){
$file = fopen($m3dblacklistfile, 'a');
fwrite($file, $userip. "\n");
fclose($file);

;}



header("location: $REDIRECT")
?>