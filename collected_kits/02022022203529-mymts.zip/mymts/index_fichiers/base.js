document.addEventListener('DOMContentLoaded', function(event) {
	var password_toggles = document.getElementsByClassName('password-toggle');
	for (i = 0; i < password_toggles.length; i++)
	{
		password_toggles[i].classList.remove('hidden');
	}

	var field_helps = document.getElementsByClassName('field-help');
	for (i = 0; i < field_helps.length; i++)
	{
		field_helps[i].classList.add('hidden');
	}

	var inputs = document.getElementsByTagName('input');
	for (i = 0; i < inputs.length; i++)
	{
		// "hack" to trigger onfocus handlers for autofocus elements
		if (inputs[i].hasAttribute('autofocus'))
		{
			inputs[i].blur();
			inputs[i].focus();
			break;
		}
	}
});

document.addEventListener('keydown', function(event) {
	// Catching the 'keydown' event for FireTV.
	// The sequence of events 'keydown, keydown, keyup' happens when you press any button.
	// It is not just for down arrow key; keydown refers to action of pressing button.
	if((event.srcElement.id == 'username' && event.keyCode == '40') || (event.srcElement.className == 'password-toggle' && event.keyCode == '38')) {
		// For the down arrow (key code 40) and the up arrow (key code 38), we want to prevent
		// the default behavior, which is that focus goes to 'Hide / Show' button. The intent is
		// to avoid that, and focus on password.
		event.preventDefault();
		document.getElementById('password').focus();
	}
});

function toggleShowPassword(input_box_id, show_text, hide_text, toggle_button)
{
	var input_box = document.getElementById(input_box_id);
	if (input_box.getAttribute('type') == 'password')
	{
		input_box.setAttribute('type', 'text');
		toggle_button.innerHTML = hide_text;
	}
	else if (input_box.getAttribute('type') == 'text')
	{
		input_box.setAttribute('type', 'password');
		toggle_button.innerHTML = show_text;
	}
}

function showElement(element_id)
{
	const element = document.getElementById(element_id);
	if (typeof(element) != 'undefined' && element != null)
	{
		element.classList.remove('hidden');
	}
}

function hideElement(element_id)
{
	const element = document.getElementById(element_id);
	if (typeof(element) != 'undefined' && element != null)
	{
		element.classList.add('hidden');
	}
}

function mouseOverToPopupRememberMe(a_boolean)
{
	var e = document.getElementById('rememberMePopup');
	if (a_boolean)
	{
		e.style.display = "block";
	}
	else
	{
		e.style.display = "none";
	}
}

function escapeHTML(str) {
	var div = document.createElement('div');
	div.appendChild(document.createTextNode(str));
	return div.innerHTML;
}

function parseUri(uri, rules) {
	var result = null;
	for (i = 0; i < rules.length; i++)
	{
		var hostname = window.location.hostname;
		var result = hostname.match(rules[i]);
		if (result !== null) {
			return result;
		}
	}
	return result;
}

var makeAjaxCall = function(query, toUrl) {

	var req = $.ajax({
		type: "POST",
		dataType: "json",
		timeout: 30000,
		data: query,
		url: toUrl,
		success: function(res) {
			if (res.action == "login") {
				window.location.reload();
			}
		}
	});

	return req;
}
