<?php
# Author: G66K
# ICQ: 747246257
# TeleGram: G66k1337
error_reporting(0);
$ur_email = "g66ktvhome@gmail.com";


define("EMAIL", "$ur_email");
$my_email=$ur_email;