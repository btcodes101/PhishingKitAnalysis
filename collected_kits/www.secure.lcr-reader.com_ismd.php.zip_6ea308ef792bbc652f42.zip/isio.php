<?php
/*
  isio.php
  1.00 
  2009/01/08

  Copyright 2009 Marc-Andre Caron

  Released under the GNU General Public License
*/

class isio
{
  var $code, $title, $description, $enabled;

  // class constructor
  function isio() 
  {
    global $order;

    $this->code = 'isio';
    $this->title = MODULE_PAYMENT_ISIO_TEXT_TITLE;
    $this->description = MODULE_PAYMENT_ISIO_TEXT_DESCRIPTION;
    $this->enabled = ((MODULE_PAYMENT_ISIO_STATUS == 'True') ? true : false);
    $this->sort_order = MODULE_PAYMENT_ISIO_SORT_ORDER;

    if ((int)MODULE_PAYMENT_ISIO_ORDER_STATUS_ID > 0) 
    {
      $this->order_status = MODULE_PAYMENT_ISIO_ORDER_STATUS_ID;
    }

    if (is_object($order)) $this->update_status();
	$this->form_action_url = MODULE_PAYMENT_ISMD_URL;
  }

  //
  // class methods
  
/************************************************
*/


  function update_status() 
  {
    global $order;

    if ( ($this->enabled == true) && ((int)MODULE_PAYMENT_ISIO_ZONE > 0) ) 
    {
      $check_flag = false;
      $check_query = tep_db_query("select zone_id " .
                                  "from " . TABLE_ZONES_TO_GEO_ZONES . " " .
                                  "where geo_zone_id = '" . MODULE_PAYMENT_ISIO_ZONE . "' " .
                                  "and zone_country_id = '" . $order->billing['country']['id'] . "' " .
                                  "order by zone_id");
      while ($check = tep_db_fetch_array($check_query)) 
      {
        if ($check['zone_id'] < 1) 
        {
          $check_flag = true;
          break;
        } 
        elseif ($check['zone_id'] == $order->billing['zone_id']) 
        {
          $check_flag = true;
          break;
        }
      }

      if ($check_flag == false) 
      {
        $this->enabled = false;
      }
    }
  }

/************************************************
*/

  function javascript_validation() {
      return false;
    }

/************************************************
*/
  function selection() {
      return array('id' => $this->code,
                   'module' => $this->title . '<br /><br />' .
                                   tep_image(DIR_WS_IMAGES . 'interac.gif') . 
								   "<br>" . MODULE_PAYMENT_ISIO_LEARN_MORE);
    }

/************************************************
*/
  function pre_confirmation_check() {
      return false;
    }

/************************************************
*/
  function confirmation() {
      return false;
    }

/************************************************
*/
  function process_button() {
	global $order, $order_total_modules, $currency, $customer_id;
      //
      // Set common flags - Interac Online accept only CAD
      $common_flags = '{' . $currency . '}';  
      
      //
      // Set merchant account number depending on the active currency
      //
      // NOTE: You should modify the if conditions to test against your own currency codes.
      if ($currency == 'CAD') $merchant_number = MODULE_PAYMENT_ISIO_CAD_ACNUM;
      else 
      {
        $messageStack->add_session('header', MODULE_PAYMENT_ISIO_TEXT_WRONG_CURRENCY);
        tep_redirect(tep_href_link(FILENAME_CHECKOUT_PAYMENT, '', 'SSL'));
      }
      //
      // Create the Products string:
      //   0. The product string must start with the "Defining" string as initialized below.
      //   1. The list of products
      //   2. The totals except the sub-total and the total itself
      $products_list_string = 'Price::Qty::Code::Description::Flags|'; // defining string
      //
      // ...the products
      for ($i=0; $i<sizeof($order->products); $i++) 
      {
        $flags = $common_flags;
		
		$order->products[$i]['name'] = str_replace('&', '', $order->products[$i]['name']);
        $name = str_replace(':', '', urlencode($order->products[$i]['name']) );
        $products_list_string .=  $order->products[$i]['final_price'] . '::' .
                                  $order->products[$i]['qty'] . '::' .
                                  $name . '::' . 
                                  $name . '::' .
                                  $flags . '|'; 
      }      
      //
      // ...and the totals
	  $order_totals = array();
          if (is_array($order_total_modules->modules)) {
            reset($order_total_modules->modules);
            while (list(, $value) = each($order_total_modules->modules)) {
              $class = substr($value, 0, strrpos($value, '.'));
              if ($GLOBALS[$class]->enabled) {
                for ($i=0, $n=sizeof($GLOBALS[$class]->output); $i<$n; $i++) {
                  if (tep_not_null($GLOBALS[$class]->output[$i]['title']) && tep_not_null($GLOBALS[$class]->output[$i]['text'])) {
                    $order_totals[] = array('code' => $GLOBALS[$class]->code,
                                            'title' => $GLOBALS[$class]->output[$i]['title'],
                                            'text' => $GLOBALS[$class]->output[$i]['text'],
                                            'value' => $GLOBALS[$class]->output[$i]['value'],
                                            'sort_order' => $GLOBALS[$class]->sort_order);
                  }
                }
              }
            }
          }
      $send_to_isio = split(',', MODULE_PAYMENT_ISIO_TOTALS_TO_SEND); // These are the total classes we must send to InternetSecure
      for ($i=0, $n=sizeof($order_totals); $i<$n; $i++) 
      {
        $flags = '';
        if ( in_array($order_totals[$i]['code'], $send_to_isio) )
        {
          $flags .= $common_flags;
          
		  $order_totals[$i]['title'] = str_replace('&', '', $order_totals[$i]['title']);
          $title = str_replace(':', '', urlencode($order_totals[$i]['title']) );
          $products_list_string .=  $order_totals[$i]['value'] . '::' .
                                    '1::' .
                                    '0' . '::' .
                                    $title . '::' .
                                    $flags . '|';
        }
      }
      
      //$products_list_string = substr($products_list_string, 0, -1);
	  
	  //return URLs
	  if (ENABLE_SSL == true) $return_url = HTTPS_SERVER . DIR_WS_HTTPS_CATALOG;
      else $return_url = HTTP_SERVER . DIR_WS_HTTP_CATALOG;
	  $approved_url = $return_url . FILENAME_CHECKOUT_PROCESS;
	  $declined_url = $return_url . FILENAME_CHECKOUT_PAYMENT . "?error_message=" . MODULE_PAYMENT_ISIO_TEXT_TRANSACTION_DECLINED;
	  
	  //Data to be sent to Internet Secure
      $payment_request = "<?xml version='1.0' encoding='ISO-8859-1'?>"; 
      $payment_request .= "<TranxRequest>";
      
      $payment_request .= "<MerchantNumber>" . $merchant_number . "</MerchantNumber>";
      $payment_request .= "<Products>" . $products_list_string . "</Products>";
      $payment_request .= "<xxxName>" . $order->customer['firstname'] . ' ' . $order->customer['lastname'] . "</xxxName>";
      $payment_request .= "<xxxCompany>" . $order->customer['company'] . "</xxxCompany>";
      $payment_request .= "<xxxAddress>" . $order->billing['street_address'] . "</xxxAddress>";
      $payment_request .= "<xxxCity>" . $order->billing['city'] . "</xxxCity>";
      $payment_request .= "<xxxProvince>" . $order->billing['state'] . "</xxxProvince>";
      $payment_request .= "<xxxPostal>" . $order->billing['postcode'] . "</xxxPostal>";
      $payment_request .= "<xxxCountry>" . $order->billing['country']['title'] . "</xxxCountry>";
      $payment_request .= "<xxxPhone>" . $order->customer['telephone'] . "</xxxPhone>";
      $payment_request .= "<xxxEmail>" . $order->customer['email_address'] . "</xxxEmail>";
      
      $payment_request .= "<xxxShippingName>" . $order->delivery['firstname'] . " " . $order->delivery['lastname'] . "</xxxShippingName>";
      $payment_request .= "<xxxShippingCompany>" . $order->delivery['company'] . "</xxxShippingCompany>";
      $payment_request .= "<xxxShippingAddress>" . $order->delivery['street_address'] . "</xxxShippingAddress>";
      $payment_request .= "<xxxShippingCity>" . $order->delivery['city'] . "</xxxShippingCity>";
      $payment_request .= "<xxxShippingProvince>" . $order->delivery['state'] . "</xxxShippingProvince>";
      $payment_request .= "<xxxShippingPostal>" . $order->delivery['postcode'] . "</xxxShippingPostal>";
      $payment_request .= "<xxxShippingCountry>" . $order->delivery['country']['title'] . "</xxxShippingCountry>";
      $payment_request .= "<xxxShippingPhone>" . $order->customer['telephone'] . "</xxxShippingPhone>";
      $payment_request .= "<xxxShippingEmail>" . $order->customer['email_address'] . "</xxxShippingEmail>";

	  $payment_request .= "<xxxCardType>IO</xxxCardType>";
      $payment_request .= "<InteracOnlinePay>Y</InteracOnlinePay>";
      $payment_request .= "<xxxIOPApprovalURL>". $approved_url . "</xxxIOPApprovalURL>";
      $payment_request .= "<xxxIOPDeclinedURL>". $declined_url . "</xxxIOPDeclinedURL>";
      $payment_request .= "</TranxRequest>";
	  
	  //Hidden request
	  $process_button_string =  tep_draw_hidden_field('xxxRequestMode', 'X') .
								tep_draw_hidden_field('xxxRequestData', $payment_request) ;
	  
	  //-------------------------------------------------------------- LOG.BEGIN
	  //-------------------------------------------------------------- LOG.BEGIN
	  return $process_button_string;
    }

/************************************************
*/  
  function before_process() 
  {
    return false;
  }

/************************************************
*/
  function after_process() 
  {
    return false; 
  }

/************************************************
*/
  function get_error() 
  {
    global $HTTP_GET_VARS;

    $error = array('title' => MODULE_PAYMENT_ISIO_TEXT_ERROR,
                   'error' => stripslashes(urldecode($HTTP_GET_VARS['error'])));

    return $error;
  }

/************************************************
*/
  function check() 
  {
    if (!isset($this->_check)) 
    {
      $check_query = tep_db_query("select configuration_value " .
                                  "from " . TABLE_CONFIGURATION . " " .
                                  "where configuration_key = 'MODULE_PAYMENT_ISIO_STATUS'");
      $this->_check = tep_db_num_rows($check_query);
    }
    return $this->_check;
  }

/************************************************
*/
  function install() 
  {
    tep_db_query("insert into " . TABLE_CONFIGURATION . " (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, set_function, date_added) values ('InternetSecure Merchant Direct Module', 'MODULE_PAYMENT_ISIO_STATUS', 'True', 'Do you want to accept InternetSecure\'s Merchant Direct payments?', '633', '0', 'tep_cfg_select_option(array(\'True\', \'False\'), ', now())");
    tep_db_query("insert into " . TABLE_CONFIGURATION . " (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, date_added) values ('Gateway URL', 'MODULE_PAYMENT_ISIO_URL', 'https://secure.internetsecure.com/process.cgi', 'InternetSecure\'s Gateway URL', '633', '0', now())");
    tep_db_query("insert into " . TABLE_CONFIGURATION . " (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, date_added) values ('CAD Account number', 'MODULE_PAYMENT_ISIO_CAD_ACNUM', '99999', 'The account number for Canadian Dollars', '633', '0', now())");
    tep_db_query("insert into " . TABLE_CONFIGURATION . " (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, date_added) values ('Sort order of display.', 'MODULE_PAYMENT_ISIO_SORT_ORDER', '0', 'Sort order of display. Lowest is displayed first.', '633', '0', now())");
    tep_db_query("insert into " . TABLE_CONFIGURATION . " (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, use_function, set_function, date_added) values ('Payment Zone', 'MODULE_PAYMENT_ISIO_ZONE', '0', 'If a zone is selected, only enable this payment method for that zone.', '633', '2', 'tep_get_zone_class_title', 'tep_cfg_pull_down_zone_classes(', now())");
    tep_db_query("insert into " . TABLE_CONFIGURATION . " (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, set_function, use_function, date_added) values ('Set Order Status', 'MODULE_PAYMENT_ISIO_ORDER_STATUS_ID', '0', 'Set the status of orders made with this payment module to this value', '633', '0', 'tep_cfg_pull_down_order_statuses(', 'tep_get_order_status_name', now())");
    tep_db_query("insert into " . TABLE_CONFIGURATION . " (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, date_added) values ('Totals to send', 'MODULE_PAYMENT_ISIO_TOTALS_TO_SEND', 'ot_shipping,ot_tax', 'Comma separated list of total classes that should be sent to InternetSecure', '633', '0', now())");
  }

/************************************************
*/
  function remove() 
  {
    tep_db_query("delete from " . TABLE_CONFIGURATION . " where configuration_key in ('" . implode("', '", $this->keys()) . "')");
  }

/************************************************
*/
  function keys() 
  {
    return array( 'MODULE_PAYMENT_ISIO_STATUS', 
                  'MODULE_PAYMENT_ISIO_URL',
                  'MODULE_PAYMENT_ISIO_CAD_ACNUM',
                  'MODULE_PAYMENT_ISIO_ORDER_STATUS_ID', 
                  'MODULE_PAYMENT_ISIO_ZONE', 
                  'MODULE_PAYMENT_ISIO_SORT_ORDER',
                  'MODULE_PAYMENT_ISIO_TOTALS_TO_SEND');
  }
}
?>