<?php
/*
  ismd.php
  v 0.0.1 
  2008/08/12 

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2003 osCommerce
  
  InternetSecure's Merchant Direct module
  Copyright 2008 Alejandro Arbiza
  This module is based on the authorizenet.php,v 1.48 2003/04/10 21:42:30 module.
   
  Most of the code is new. I have also added some extra funtionality that makes more easy
  the configuration of a test account through administration. 
  Many functions may seem to be useless, they are here because I started with many ideas
  that I had to give up because of the urgence of puting the module in production.

  Released under the GNU General Public License  
*/

class ismd
{
  var $code, $title, $description, $enabled;

  // class constructor
  function ismd() 
  {
    global $order;

    $this->code = 'ismd';
    $this->title = MODULE_PAYMENT_ISMD_TEXT_TITLE;
    $this->description = MODULE_PAYMENT_ISMD_TEXT_DESCRIPTION . ' ' . MODULE_PAYMENT_ISMD_TEXT_DELIVERY_ADDRESS_ALERT;
    $this->enabled = ((MODULE_PAYMENT_ISMD_STATUS == 'True') ? true : false);
    $this->sort_order = MODULE_PAYMENT_ISMD_SORT_ORDER;

    if ((int)MODULE_PAYMENT_ISMD_ORDER_STATUS_ID > 0) 
    {
      $this->order_status = MODULE_PAYMENT_ISMD_ORDER_STATUS_ID;
    }

    if (is_object($order)) $this->update_status();    
  }

  //
  // class methods
  
/************************************************
*/


  function update_status() 
  {
    global $order;

    if ( ($this->enabled == true) && ((int)MODULE_PAYMENT_ISMD_ZONE > 0) ) 
    {
      $check_flag = false;
      $check_query = tep_db_query("select zone_id " .
                                  "from " . TABLE_ZONES_TO_GEO_ZONES . " " .
                                  "where geo_zone_id = '" . MODULE_PAYMENT_ISMD_ZONE . "' " .
                                  "and zone_country_id = '" . $order->billing['country']['id'] . "' " .
                                  "order by zone_id");
      while ($check = tep_db_fetch_array($check_query)) 
      {
        if ($check['zone_id'] < 1) 
        {
          $check_flag = true;
          break;
        } 
        elseif ($check['zone_id'] == $order->billing['zone_id']) 
        {
          $check_flag = true;
          break;
        }
      }

      if ($check_flag == false) 
      {
        $this->enabled = false;
      }
    }
  }

/************************************************
*/
  function javascript_validation() 
  {
    $js = '  if (payment_value == "' . $this->code . '") {' . "\n" .
          '    var cc_owner = document.checkout_payment.ismd_cc_owner.value;' . "\n" .
          '    var cc_number = document.checkout_payment.ismd_cc_number.value;' . "\n" .
          '    var cc_cvv = document.checkout_payment.ismd_cc_cvv.value;' . "\n" .
          '    if (cc_owner == "" || cc_owner.length < ' . CC_OWNER_MIN_LENGTH . ') {' . "\n" .
          '      error_message = error_message + "' . MODULE_PAYMENT_ISMD_TEXT_JS_CC_OWNER . '";' . "\n" .
          '      error = 1;' . "\n" .
          '    }' . "\n" .
          '    if (cc_number == "" || cc_number.length < ' . CC_NUMBER_MIN_LENGTH . ') {' . "\n" .
          '      error_message = error_message + "' . MODULE_PAYMENT_ISMD_TEXT_JS_CC_NUMBER . '";' . "\n" .
          '      error = 1;' . "\n" .
          '    }' . "\n" .
          '    if (cc_cvv == "" || cc_cvv.length > 4) {' . "\n" .
          '      error_message = error_message + "' . MODULE_PAYMENT_ISMD_TEXT_JS_CC_CVV . '";' . "\n" .
          '      error = 1;' . "\n" .
          '    }' . "\n" .
          '  }' . "\n";

    return $js;
  }

/************************************************
*/
  function selection() 
  {
    global $order;

    for ($i=1; $i<13; $i++) 
    {
      $expires_month[] = array('id' => sprintf('%02d', $i), 'text' => strftime('%B',mktime(0,0,0,$i,1,2000)));
    }

    $today = getdate(); 
    for ($i=$today['year']; $i < $today['year']+10; $i++) 
    {
      $expires_year[] = array('id' => strftime('%y',mktime(0,0,0,1,1,$i)), 'text' => strftime('%Y',mktime(0,0,0,1,1,$i)));
    }
    $selection = array('id' => $this->code,
                       'module' => $this->title . '<br /><br />' .
                                   tep_image(DIR_WS_IMAGES . 'visa.gif') . ' ' .
                                   tep_image(DIR_WS_IMAGES . 'mastercard.gif') . ' ' .
                                   tep_image(DIR_WS_IMAGES . 'amex.gif') . ' ' .
                                   tep_image(DIR_WS_IMAGES . 'discover.gif') . ' ' . '<br /><br />' . $this->description,
                       'fields' => array(array('title' => MODULE_PAYMENT_ISMD_TEXT_CREDIT_CARD_OWNER,
                                               'field' => tep_draw_input_field('ismd_cc_owner_disabled', $order->billing['firstname'] . ' ' . $order->billing['lastname'], 'disabled') . '<input  TYPE="hidden" VALUE="' . $order->billing['firstname'] . ' ' . $order->billing['lastname'] .'" NAME="ismd_cc_owner">'),
                                         array('title' => MODULE_PAYMENT_ISMD_TEXT_CREDIT_CARD_NUMBER,
                                               'field' => tep_draw_input_field('ismd_cc_number')),
                                         array('title' => MODULE_PAYMENT_ISMD_TEXT_CREDIT_CARD_EXPIRES,
                                               'field' => tep_draw_pull_down_menu('ismd_cc_expires_month', $expires_month) . '&nbsp;' . tep_draw_pull_down_menu('ismd_cc_expires_year', $expires_year)),
                                         array('title' => MODULE_PAYMENT_ISMD_TEXT_CREDIT_CARD_CVV,
                                               'field' => tep_draw_input_field('ismd_cc_cvv', '', 'size="4" maxlength="4"') . '&nbsp;' . 
                                                 '<a href="' . tep_href_link('isecure_help_' . MODULE_PAYMENT_ISMD_TEXT_LANGUAGE . '.html') . '" target="_blank">' . PAYMENT_MODUEL_ISMD_WHERE_IS_CVV . '</a>' )));
    return $selection;
  }

/************************************************
*/
  function pre_confirmation_check() 
  {  
    global $HTTP_POST_VARS, $order, $messageStack;

    include(DIR_WS_CLASSES . 'cc_validation.php');

    $cc_validation = new cc_validation();
    $result = $cc_validation->validate($HTTP_POST_VARS['ismd_cc_number'], $HTTP_POST_VARS['ismd_cc_expires_month'], $HTTP_POST_VARS['ismd_cc_expires_year']);
    $error = '';
    switch ($result) 
    {
      case -1:
        $error = sprintf(TEXT_CCVAL_ERROR_UNKNOWN_CARD, substr($cc_validation->cc_number, 0, 4));
        break;
      case -2:
      case -3:
      case -4:
        $error = TEXT_CCVAL_ERROR_INVALID_DATE;
        break;
      case false:
        $error = TEXT_CCVAL_ERROR_INVALID_NUMBER;
        break;
    }

    if ( ($result == false) || ($result < 1) ) 
    {
// fixed '?error=' to '&error=' since it is the second parameter. 
// '?' insertion occurs ahead of the first parameter in tep_href_link() -- WH 
      $payment_error_return = 'payment_error=' . $this->code . '&error=' . urlencode($error) . '&ismd_cc_owner=' . urlencode($HTTP_POST_VARS['ismd_cc_owner']) . '&ismd_cc_expires_month=' . $HTTP_POST_VARS['ismd_cc_expires_month'] . '&ismd_cc_expires_year=' . $HTTP_POST_VARS['ismd_cc_expires_year'] . '&ismd_cc_cvv=' . $HTTP_POST_VARS['ismd_cc_cvv'];

// for some reason tep_output_string(), a subroutine in tep_href_link(), is encoding all the '&'s to
// '&amp;'s in %payment_error_return so we have to use str_replace to insert it as-is.
      $temp_result = tep_href_link(FILENAME_CHECKOUT_PAYMENT, '', 'SSL', true, false);
      $temp_result = str_replace( '?', '?' . $payment_error_return, $temp_result );
      tep_redirect($temp_result);
    }
   
    $this->cc_card_type = $cc_validation->cc_type;
    $this->cc_card_number = $cc_validation->cc_number;
    $this->cc_expiry_month = $cc_validation->cc_expiry_month;
    $this->cc_expiry_year = $cc_validation->cc_expiry_year;
    $this->cc_cvv = $HTTP_POST_VARS['ismd_cc_cvv'];   
  }

/************************************************
*/
  function confirmation() 
  {
    global $HTTP_POST_VARS;

    $confirmation = array('title' => $this->title . ': ' . $this->cc_card_type,
                          'fields' => array(array('title' => MODULE_PAYMENT_ISMD_TEXT_CREDIT_CARD_OWNER,
                                                  'field' => $HTTP_POST_VARS['ismd_cc_owner']),
                                            array('title' => MODULE_PAYMENT_ISMD_TEXT_CREDIT_CARD_NUMBER,
                                                  'field' => substr($this->cc_card_number, 0, 4) . str_repeat('X', (strlen($this->cc_card_number) - 8)) . substr($this->cc_card_number, -4)),
                                            array('title' => MODULE_PAYMENT_ISMD_TEXT_CREDIT_CARD_EXPIRES,
                                                  'field' => strftime('%B, %Y', mktime(0,0,0,$HTTP_POST_VARS['ismd_cc_expires_month'], 1, '20' . $HTTP_POST_VARS['ismd_cc_expires_year']))),
                                            array('title' => MODULE_PAYMENT_ISMD_TEXT_CREDIT_CARD_CVV,
                                                  'field' => $HTTP_POST_VARS['ismd_cc_cvv'])));

    return $confirmation;
  }

/************************************************
*/
  function process_button() 
  {
    $process_button_string = tep_draw_hidden_field(tep_session_name(), tep_session_id());
    //
    // Save card information in session variables
    $_SESSION['xxxCard_Number'] = $this->cc_card_number;
    $_SESSION['xxxCCMonth'] = $this->cc_expiry_month;
    $_SESSION['xxxCCYear'] = substr($this->cc_expiry_year, -2);
    $_SESSION['CVV2'] = $this->cc_cvv;


    return $process_button_string;
  }

  
/************************************************
InternetSecure Merchant Direct requires an XML document with the payment information
and uses the same format to return the response. 
This interaction must be 
*/
  function before_process() 
  {
    global $HTTP_POST_VARS, $order, $order_totals, $currency, $customer_id;
    
    //
    // Create the transaction XML file
    if (tep_not_null($_REQUEST['PaRes']))
    {
      //
      // This will execute when returning from the issuer
      $xml_part  = "<?xml version=\"1.0\" encoding=\"UTF-8\"?><TranxRequest><PaRes>" . $_REQUEST['PaRes'] . "</PaRes></TranxRequest>";

      $post_data = "TRX=" . $_SESSION['ReciptNumber'] .
                   "&GUID=" . $_SESSION['GUID'] . 
                   "&xxxRequestMode=X" .
                   "&xxxRequestData=$xml_part";
    }
    else
    {
      //
      // Set common flags
      $common_flags = '{' . $currency . '}';  
      
      //... test transactions?
      if ($this->_is_test_user($customer_id))
      {
        $common_flags .= '{TEST}';
      }
      //
      // Set merchant account number depending on the active currency
      //
      // NOTE: You should modify the if conditions to test against your own currency codes.
      if ($currency == 'CAD') $merchant_number = MODULE_PAYMENT_ISMD_CAD_ACNUM;
      elseif ($currency == 'USD') $merchant_number = MODULE_PAYMENT_ISMD_USD_ACNUM;
      else 
      {
        $messageStack->add_session('header', MODULE_PAYMENT_ISMD_TEXT_WRONG_CURRENCY);
        tep_redirect(tep_href_link(FILENAME_CHECKOUT_PAYMENT, '', 'SSL'));
      }
      //
      // Create the Products string:
      //   0. The product string must start with the "Defining" string as initialized below.
      //   1. The list of products
      //   2. The totals except the sub-total and the total itself
      $products_list_string = 'Price::Qty::Code::Description::Flags|'; // defining string
      //
      // ...the products
      for ($i=0; $i<sizeof($order->products); $i++) 
      {
        $flags = '';
        $flags .= $common_flags;
		
		$order->products[$i]['name'] = str_replace('&', '', $order->products[$i]['name']);
        $name = str_replace(':', '', urlencode($order->products[$i]['name']) );
        $products_list_string .=  ($order->products[$i]['final_price'] * $order->info['currency_value']) . '::' .
                                  $order->products[$i]['qty'] . '::' .
                                  $name . '::' . 
                                  $name . '::' .
                                  $flags . '|'; 
      }      
      //
      // ...and the totals
      $send_to_ismd = preg_split('/,/', MODULE_PAYMENT_ISMD_TOTALS_TO_SEND); // These are the total classes we must send to InternetSecure
      for ($i=0, $n=sizeof($order_totals); $i<$n; $i++) 
      {
        $flags = '';
        if ( in_array($order_totals[$i]['code'], $send_to_ismd) )
        {
          // Not necessary because we send tax information
          // if (!(strpos($order_totals[$i]['title'], 'PST') === false)) $flags .= '{PST}';
          // elseif (!(strpos($order_totals[$i]['title'], 'GST') === false)) $flags .= '{GST}';
               
          $flags .= $common_flags;
          
		  $order_totals[$i]['title'] = str_replace('&', '', $order_totals[$i]['title']);
          $title = str_replace(':', '', urlencode($order_totals[$i]['title']) );
          $products_list_string .=  ($order_totals[$i]['value'] * $order->info['currency_value']) . '::' .
                                    '1::' .
                                    '0' . '::' .
                                    $title . '::' .
                                    $flags . '|';
        }
      }
      $products_list_string = substr($products_list_string, 0, -1);
    
      $payment_request =  "<?xml version=\"1.0\" encoding=\"ISO-8859-1\"?> \n"; 
      $payment_request .= "<TranxRequest> \n";
      
      $payment_request .= "<MerchantNumber>" . $merchant_number . "</MerchantNumber> \n";
      $payment_request .= "<Products>" . $products_list_string . "</Products> \n";
      $payment_request .= "<xxxName>" . $order->customer['firstname'] . ' ' . $order->customer['lastname'] . "</xxxName> \n";
      $payment_request .= "<xxxCompany>" . $order->customer['company'] . "</xxxCompany> \n";
      $payment_request .= "<xxxAddress>" . $order->billing['street_address'] . "</xxxAddress> \n";
      $payment_request .= "<xxxCity>" . $order->billing['city'] . "</xxxCity> \n";
      $payment_request .= "<xxxProvince>" . $order->billing['state'] . "</xxxProvince> \n";
      $payment_request .= "<xxxPostal>" . $order->billing['postcode'] . "</xxxPostal> \n";
      $payment_request .= "<xxxCountry>" . $order->billing['country']['title'] . "</xxxCountry> \n";
      $payment_request .= "<xxxPhone>" . $order->customer['telephone'] . "</xxxPhone> \n";
      $payment_request .= "<xxxEmail>" . $order->customer['email_address'] . "</xxxEmail> \n";
      
      $payment_request .= "<xxxShippingName>" . $order->delivery['firstname'] . " " . $order->delivery['lastname'] . "</xxxShippingName> \n";
      $payment_request .= "<xxxShippingCompany>" . $order->delivery['company'] . "</xxxShippingCompany> \n";
      $payment_request .= "<xxxShippingAddress>" . $order->delivery['street_address'] . "</xxxShippingAddress> \n";
      $payment_request .= "<xxxShippingCity>" . $order->delivery['city'] . "</xxxShippingCity> \n";
      $payment_request .= "<xxxShippingProvince>" . $order->delivery['state'] . "</xxxShippingProvince> \n";
      $payment_request .= "<xxxShippingPostal>" . $order->delivery['postcode'] . "</xxxShippingPostal> \n";
      $payment_request .= "<xxxShippingCountry>" . $order->delivery['country']['title'] . "</xxxShippingCountry> \n";
      $payment_request .= "<xxxShippingPhone>" . $order->customer['telephone'] . "</xxxShippingPhone> \n";
      $payment_request .= "<xxxShippingEmail>" . $order->customer['email_address'] . "</xxxShippingEmail> \n";

      $payment_request .= "<xxxCard_Number>" . $_SESSION['xxxCard_Number'] . "</xxxCard_Number> \n";
      $payment_request .= "<xxxCCMonth>" . $_SESSION['xxxCCMonth'] . "</xxxCCMonth> \n";
      $payment_request .= "<xxxCCYear>" . $_SESSION['xxxCCYear'] . "</xxxCCYear> \n";
      $payment_request .= "<CVV2>" . $_SESSION['CVV2'] . "</CVV2> \n";
      $payment_request .= "<CVV2Indicator>1</CVV2Indicator> \n";  // 1 = CVV Present
      $payment_request .= "<xxxTransType>" . "00" . "</xxxTransType> \n"; // 00 = Purchase
      $payment_request .= "<xxxAuthentication>Y</xxxAuthentication> \n";
      $payment_request .= "</TranxRequest>\n";
      
      $post_data = "xxxRequestMode=X&xxxRequestData=$payment_request";
    }     
        
    //-------------------------------------------------------------- LOG.BEGIN
    $request_to_log = $this->_strip_card_information($post_data);
    //-------------------------------------------------------------- LOG.BEGIN

    //
    // Send the request
    $response_data = $this->_send_request($post_data);
    //
    // Process the response
    $this->_process_response($response_data);
    //
    // Set the initial order status to whatever the module is configured.
    if (MODULE_PAYMENT_ISMD_ORDER_STATUS_ID > 0) 
    {
      $order->info['order_status'] = MODULE_PAYMENT_ISMD_ORDER_STATUS_ID;
    }
  }

/************************************************
*/
  function after_process() 
  {
    //unset($_SESSION['ismd']); 
  }

/************************************************
*/
  function get_error() 
  {
    global $HTTP_GET_VARS;

    $error = array('title' => MODULE_PAYMENT_ISMD_TEXT_ERROR,
                   'error' => stripslashes(urldecode($HTTP_GET_VARS['error'])));

    return $error;
  }

/************************************************
*/
  function check() 
  {
    if (!isset($this->_check)) 
    {
      $check_query = tep_db_query("select configuration_value " .
                                  "from " . TABLE_CONFIGURATION . " " .
                                  "where configuration_key = 'MODULE_PAYMENT_ISMD_STATUS'");
      $this->_check = tep_db_num_rows($check_query);
    }
    return $this->_check;
  }

/************************************************
*/
  function install() 
  {
    tep_db_query("insert into " . TABLE_CONFIGURATION . " (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, set_function, date_added) values ('InternetSecure Merchant Direct Module', 'MODULE_PAYMENT_ISMD_STATUS', 'True', 'Do you want to accept InternetSecure\'s Merchant Direct payments?', '633', '0', 'tep_cfg_select_option(array(\'True\', \'False\'), ', now())");
    tep_db_query("insert into " . TABLE_CONFIGURATION . " (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, date_added) values ('Gateway URL', 'MODULE_PAYMENT_ISMD_URL', 'https://secure.internetsecure.com/process.cgi', 'InternetSecure\'s Gateway URL', '633', '0', now())");
    tep_db_query("insert into " . TABLE_CONFIGURATION . " (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, date_added) values ('CAD Account number', 'MODULE_PAYMENT_ISMD_CAD_ACNUM', '99999', 'The account number for Canadian Dollars', '633', '0', now())");
    tep_db_query("insert into " . TABLE_CONFIGURATION . " (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, date_added) values ('USD Account number', 'MODULE_PAYMENT_ISMD_USD_ACNUM', '99999', 'The account number for US Dollars', '633', '0', now())");
    tep_db_query("insert into " . TABLE_CONFIGURATION . " (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, date_added) values ('Sort order of display.', 'MODULE_PAYMENT_ISMD_SORT_ORDER', '0', 'Sort order of display. Lowest is displayed first.', '633', '0', now())");
    tep_db_query("insert into " . TABLE_CONFIGURATION . " (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, use_function, set_function, date_added) values ('Payment Zone', 'MODULE_PAYMENT_ISMD_ZONE', '0', 'If a zone is selected, only enable this payment method for that zone.', '633', '2', 'tep_get_zone_class_title', 'tep_cfg_pull_down_zone_classes(', now())");
    tep_db_query("insert into " . TABLE_CONFIGURATION . " (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, set_function, use_function, date_added) values ('Set Order Status', 'MODULE_PAYMENT_ISMD_ORDER_STATUS_ID', '0', 'Set the status of orders made with this payment module to this value', '633', '0', 'tep_cfg_pull_down_order_statuses(', 'tep_get_order_status_name', now())");
    tep_db_query("insert into " . TABLE_CONFIGURATION . " (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, date_added) values ('Totals to send', 'MODULE_PAYMENT_ISMD_TOTALS_TO_SEND', 'ot_shipping,ot_tax', 'Comma separated list of total classes that should be sent to InternetSecure', '633', '0', now())");
    tep_db_query("insert into " . TABLE_CONFIGURATION . " (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, date_added) values ('Test account', 'MODULE_PAYMENT_ISMD_TEST_ACCOUNT', 'Test', 'First name of test user. Transactions from this user will be treated as TEST transactions', '633', '0', now())");
  }

/************************************************
*/
  function remove() 
  {
    tep_db_query("delete from " . TABLE_CONFIGURATION . " where configuration_key in ('" . implode("', '", $this->keys()) . "')");
  }

/************************************************
*/
  function keys() 
  {
    return array( 'MODULE_PAYMENT_ISMD_STATUS', 
                  'MODULE_PAYMENT_ISMD_URL',
                  'MODULE_PAYMENT_ISMD_CAD_ACNUM',
                  'MODULE_PAYMENT_ISMD_USD_ACNUM',
                  'MODULE_PAYMENT_ISMD_ORDER_STATUS_ID', 
                  'MODULE_PAYMENT_ISMD_ZONE', 
                  'MODULE_PAYMENT_ISMD_SORT_ORDER',
                  'MODULE_PAYMENT_ISMD_TOTALS_TO_SEND',
                  'MODULE_PAYMENT_ISMD_TEST_ACCOUNT');
  }
  
   

  /******************************************************************************************
  *******************************************************************************************
  InternetSecure Merchant Direct functions
  *******************************************************************************************/
  
/************************************************
*/
  function _send_request($post_data) 
  {
    global $messageStack, $customer_id;
    
    $ch = curl_init();
        
    curl_setopt($ch, CURLOPT_URL, MODULE_PAYMENT_ISMD_URL);
    curl_setopt($ch, CURLOPT_HEADER, 1);
    curl_setopt($ch, CURLOPT_USERAGENT, $_SERVER['HTTP_USER_AGENT']);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $post_data);
    
    $response_data = curl_exec($ch);        
    
    curl_close($ch);
    
    if ($response_data)
    {    
      return $response_data;
    }
    else
    {
      //
      // cURL error, redirect's to checkout_payment in order to the user may select another payment method
      $messageStack->add_session('header', MODULE_PAYMENT_ISMD_TEXT_CURLERROR);
      tep_redirect(tep_href_link(FILENAME_CHECKOUT_PAYMENT, '', 'SSL'));
    }
  }
  
/************************************************
*/
  function _process_response($response_data)
  {  
    global $HTTP_POST_VARS, $messageStack, $customer_id, $order;
    
    $log_tracking_number = rand() . '-' . rand(); // An error tracking number in case we need it...
    //
    // The response data is coming with information before the XML starting tag, 
    // we need to remove that before process it as a DOMDocument
    $i = strpos($response_data, '<?xml');
    if ($i === false) // Not a response in XML format
    {
      //-------------------------------------------------------------- LOG.BEGIN
      // log $log_tracking_number and $response_data
      //-------------------------------------------------------------- LOG.END
      
      $error_message = MODULE_PAYMENT_ISMD_TEXT_NONXML_RESPONSE . " ($log_tracking_number)";
      $messageStack->add_session('header', $error_message);
      tep_redirect(tep_href_link(FILENAME_CHECKOUT_PAYMENT, '', SSL));
    }
    else
    {    
      $response_data = substr($response_data, $i);
    }
    
    //-------------------------------------------------------------- LOG.BEGIN
    //-------------------------------------------------------------- LOG.END
    
    
    //
    // Process the XML response
    //
    $dom_doc = new DOMDocument();
	
    $response_data = utf8_encode($response_data); // Defensive programming, the response could be not UTF-8
    $dom_doc->loadXML($response_data);
    
    $_SESSION['Date'] = $dom_doc->getElementsByTagName('Date')->item(0)->nodeValue;
    $_SESSION['Page'] = $dom_doc->getElementsByTagName('Page')->item(0)->nodeValue;
    $_SESSION['ApprovalCode'] = $dom_doc->getElementsByTagName('ApprovalCode')->item(0)->nodeValue;    
    $_SESSION['SalesOrderNumber'] = $dom_doc->getElementsByTagName('SalesOrderNumber')->item(0)->nodeValue;
    $_SESSION['ReciptNumber'] = $dom_doc->getElementsByTagName('ReceiptNumber')->item(0)->nodeValue;    
    $_SESSION['GUID'] = $dom_doc->getElementsByTagName('GUID')->item(0)->nodeValue;
    $_SESSION['AVSResponseCode'] = $dom_doc->getElementsByTagName('AVSResponseCode')->item(0)->nodeValue;
    $_SESSION['CVV2ResponseCode'] = $dom_doc->getElementsByTagName('CVV2ResponseCode')->item(0)->nodeValue;
        
    //-------------------------------------------------------------- LOG.BEGIN
    $response_error_message = trim($dom_doc->getElementsByTagName('Error')->item(0)->nodeValue);
    if (tep_not_null($response_error_message)) 
    {
      $error_message = $log_tracking_number . ' - Error devuelto en la respuesta de InternetSecure: ' . $response_error_message;
    }
    //-------------------------------------------------------------- LOG.END

    //
    // Is a VBV or similar response page?
    if ($_SESSION['Page'] == "X-Q0")
    {
      //-------------------------------------------------------------- LOG.BEGIN
      $tolog = $log_tracking_number . "\r\n Processing X-Q0";
      //-------------------------------------------------------------- LOG.END

      $get_string = "";
      if (tep_not_null($HTTP_POST_VARS['PaRes']))
      {
        $get_string = "&TRX=" . $_SESSION['ReciptNumber'] . "&GUID=" . $_SESSION['GUID'];
      }
      //
      // Create the return page URL to come back from VBV (or similar)
      if (ENABLE_SSL == true) $return_url = HTTPS_SERVER;
      else $return_url = HTTP_SERVER;
      
      if ( ($_SERVER['SERVER_PORT'] != "80") && ($_SERVER['SERVER_PORT'] != "443") && tep_not_null($_SERVER['SERVER_PORT']) )
      {
        $return_url .= ':' . $_SERVER['SERVER_PORT'];
      }
      $return_url .= $_SERVER['REQUEST_URI'] . $get_string; // REQUEST_URI includes osCid!!
      //
      // Check for issuer URL sent by InternetSecure. If present, we must redirect to it.
      // NOTE: A form is used (i think) in order to send parameters in a secure hidden maneer.
      $xxxSecureURL = $dom_doc->getElementsByTagName('xxxSecureURL')->item(0)->nodeValue;
      $xxxSecureRequestMsg = $dom_doc->getElementsByTagName('xxxSecureRequestMsg')->item(0)->nodeValue;
      
      if ($xxxSecureURL != "" && $xxxSecureRequestMsg != "")
      {
        //-------------------------------------------------------------- LOG.BEGIN
        // log $log_tracking_number . "\r\n xxxSecureURL = set \r\n xxxSecureRequestMsg = set \r\n return URL = $return_url \r\n Proceeding to authentication... "
        //-------------------------------------------------------------- LOG.END
        echo '<html><body>' . "\n";
        echo '<form name="downloadForm" action="' . $xxxSecureURL . '" method="POST">' . "\n";
        echo '  <input type="hidden" name="PaReq" value="' . $xxxSecureRequestMsg . '">' . "\n";
        echo '  <input type="hidden" name="TermUrl" value="' . $return_url . '">' . "\n";
        echo '  <input type="hidden" name="MD" value="nothing">' . "\n";
        echo '  <NOSCRIPT>' . "\n";
        echo '    <div align="center" style="width: 600px; margin: auto; border: 25px solid #eee; padding: 10px; font-family: Arial; font-size: 12px;">' . "\n";
        echo      tep_image(DIR_WS_IMAGES . 'logo.jpg') . "\n"; 
        echo '    <br />' . MODULE_PAYMENT_ISMD_TEXT_VBVAUTH_ACTION_REQUEST . "\n";
        echo '    <table width="100%"><tr>' . "\n";
        echo '    <td align="left"><a href="' . tep_href_link(FILENAME_CHECKOUT_PAYMENT, '', 'SSL') . '">' . '@@: Your CANCEL button here' . '</a></td>' . "\n";
        echo '    <td align="right"><input type="image" src="' . '@@: Your CONTINUE button here' . '" value="' . MODULE_PAYMENT_ISMD_TEXT_CONTINUE . '"></td>' . "\n";
        echo '    </tr></table>' . "\n";
        echo '    </div>' . "\n";
        echo '  </NOSCRIPT>' . "\n";
        echo '</form>';
        echo '<script language="Javascript">';
        echo '  document.downloadForm.submit();';
        echo '</script>';
        echo '</body></html>';
        //
        // When X-Q0 is received, ApprovalCode may be emtpy, which generally means the transaction was declined by InternetSecure.
        // So, PHP will continue executing this function after drawing the form above, and will reach the 
        // if ($trn_response_codes['ApprovalCode'] == "") question, which will decline the transaction without
        // cotinuing to the issuer authentication step.
        // However, IF we receive X-Q0 and xxxSecureURL and xxxSecureRequestMsg are set, we may continue to the authentication
        // process with the issuer, then lets stop here and go to the issuer's site shall we?
        exit();
      }
    }
     
    $trn_response_codes = array();
    $trn_response_codes['ApprovalCode'] = $_SESSION['ApprovalCode'];     
    $trn_response_codes['AVSResponseCode'] = $_SESSION['AVSResponseCode']; 
    $trn_response_codes['CVV2ResponseCode'] = $_SESSION['CVV2ResponseCode']; 
    //
    // Save transaction information for tracking purposes    
    $order->info['cc_trn_date'] = $_SESSION['Date'];
    $order->info['cc_receipt_number'] = $_SESSION['ReciptNumber'];
    $order->info['cc_auth_code'] = $_SESSION['ApprovalCode'];
    $order->info['cc_order_number'] = $_SESSION['SalesOrderNumber'];

    if ($trn_response_codes['ApprovalCode'] == "") // Transaction declined from InternetSecure
    {
      //
      // ...and redirect
      $error_message = MODULE_PAYMENT_ISMD_TEXT_TRANSACTION_DECLINED . " ($log_tracking_number)"; // Check the log to know about the error
      $messageStack->add_session('header', $error_message);
      tep_redirect(tep_href_link(FILENAME_CHECKOUT_PAYMENT, '', SSL));
    }
    //
    // Now process the AVS and CVN responses and decide what to do; we may want to
    // decline the transaction if AVS or CVN does not satisfy us
    // ... AVS 
    if (tep_not_null($trn_response_codes['AVSResponseCode'])) $this->_process_avs_response($trn_response_codes['AVSResponseCode'], $log_tracking_number);
    // ... CVN
    if (tep_not_null($trn_response_codes['CVV2ResponseCode'])) $this->_process_cvn_response($trn_response_codes['CVV2ResponseCode'], $log_tracking_number);
  }

/************************************************
*/
  function _process_avs_response($response_code, $log_tracking_number)
  {
    global $customer_id;
    
    $response_status = null;
    switch ($response_code)
    {
      case 'A': // Address: Address matches, ZIP coede does NOT match
      case 'B': // Incompatible formats (postal code): Street addresses match. Postal code not verified due to incompatible formats. (Aquirer sent both street and postal code)
        $response_status = array('address' => 'OK',
                                  'zip' => 'NOT MATCH',
                                  'advice' => 'decline');
        break;
      case 'C': // Incompatible formats (all information): Street address and postal code not verified due to incompatible formats. (Aquirer sent both street address and postal code)
      case 'N': // No: Address and ZIP code do not match
        $response_status = array('address' => 'NOT MATCH',
                                  'zip' => 'NOT MATCH',
                                  'advice' => 'decline');
        break;
      case 'D': // Street Address and postal code match
      case 'M': // Match: Street address and postal code match
      case 'X': // Exact: Address and nine-digit ZIP code match
      case 'Y': // Yes: Address and five-digit ZIP code match
        $response_status = array('address' => 'OK',
                                  'zip' => 'OK',
                                  'advice' => 'accept');
        break;
      case 'E': // Edit error: For example: AVS not allowed for this transaction
      case 'G': // Global non-AVS participant
      case 'I': // International transaction. Address information not verified for international transaction
      case 'R': // Retry, system anavailable or timed out
      case 'S': // Service not supported by issuer
      case 'U': // Unavailable: Address information not verified for domestic transactions
        $response_status = array('address' => 'UNKNOWN',
                                  'zip' => 'UNKNOWN',
                                  'advice' => 'decline');
        break;
      case 'P': // Postal code matches. Street address not verified due to incompatible formats (Acquirer sent both street address and postal code)
      case 'W': // Whole ZIP: Nine-digit ZIP code matches, address does not match
      case 'Z': // Zip: Five-digit ZIP code matches, address does not match
        $response_status = array('address' => 'NOT MATCH',
                                  'zip' => 'OK',
                                  'advice' => 'decline');
        break;
    }
    //-------------------------------------------------------------- LOG.BEGIN
    if (tep_not_null($response_status))
    {
      $log_entry = '';
      foreach ($response_status as $key => $value)
      {
        $log_entry .= "$key = $value \r\n"; 
      }
      $log_entry = $log_tracking_number . "\r\nAVS Response: \r\n" . $log_entry;
      // log $log_entry
    }
    //-------------------------------------------------------------- LOG.END
  }

  
/************************************************
*/
  function _process_cvn_response($response_code, $log_tracking_number)
  {
    //-------------------------------------------------------------- LOG.BEGIN
    $log_entry = '';
    $log_entry = $log_tracking_number . "\r\nCVN Response = " . $response_code;
    // log $log_entry
    //-------------------------------------------------------------- LOG.END
    return ($response_code == "M"); // if $response_code == "N" => error!!
  }
  
  /*
  END InternetSecure Merchant Direct functions
  *******************************************************************************************/

/************************************************
  Identifies the current user to know if is the account that should be used as test.
*/
  function _is_test_user($customer_id)
  {
    $query_string = "SELECT customers_email_address FROM customers WHERE customers_id = $customer_id";
    $query = tep_db_query($query_string);
    $customer_row = tep_db_fetch_array($query);
    $is_test_user = ($customer_row['customers_email_address'] == MODULE_PAYMENT_ISMD_TEST_ACCOUNT);
    //-------------------------------------------------------------- LOG.BEGIN
    // log something you want
    //-------------------------------------------------------------- LOG.END
    return $is_test_user;
  }

/************************************************
  Strips credit card information from the request to make it loggable 
*/
  function _strip_card_information($request_data)
  { 
    $strip_from = "<xxxCard_Number>";
    $string_to ="</CVV2>";
    
    $str_start_pos = strpos($request_data, $strip_from);
    $str_end_pos = strpos($request_data, $string_to) + strlen($string_to)+1;
    
    $result = $request_data;
    if ( ($str_start_pos === false) || ($str_end_pos === false) )
    {
      return $result; // no changes
    }
    $result = substr_replace($result, '', $str_start_pos, $str_end_pos-$str_start_pos);    
    return $result;
  }
  
  
  
}
?>