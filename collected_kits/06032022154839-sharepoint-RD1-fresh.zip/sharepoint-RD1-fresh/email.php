<?php 
$Receive_email="	johnabajian8@gmail.com";
$redirect="https://www.google.com/";
?>